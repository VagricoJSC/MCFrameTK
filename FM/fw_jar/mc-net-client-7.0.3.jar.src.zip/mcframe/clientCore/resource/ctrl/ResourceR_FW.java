/*    */ package mcframe.clientCore.resource.ctrl;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import mcframe.clientCore.container.MCKeyList;
/*    */ import mcframe.commonCore.container.MCRow;
/*    */ import mcframe.commonCore.lang.MCStringUtil;
/*    */ import mcframe.commonCore.resource.ctrl.MCOptimizedResourceRow;
/*    */ import mcframe.commonCore.resource.ctrl.MCResource;
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ResourceR_FW
/*    */   extends ResourceR_FW_A
/*    */   implements MCOptimizedResourceRow
/*    */ {
/*    */   private String optimizedResourceKey;
/*    */   private String optimizedResourceName;
/*    */   
/*    */   public String name_key() {
/*    */     return String.valueOf(Name()) + "." + Key();
/*    */   }
/*    */   
/*    */   protected ResourceR_FW(MCRow.ConstMetaList<? extends ResourceR> metas) {
/* 25 */     super(metas);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 41 */     this.optimizedResourceKey = null;
/*    */     
/* 43 */     this.optimizedResourceName = null;
/*    */   }
/*    */   public void optimizedResourceInit() {
/* 46 */     if (this.optimizedResourceKey != null && this.optimizedResourceName != null) {
/*    */       return;
/*    */     }
/* 49 */     String key = Key();
/* 50 */     String resourceName = Name();
/* 51 */     if (MCStringUtil.isNull(resourceName)) {
/* 52 */       String[] keys = MCResource.splitKey(key, 2);
/* 53 */       resourceName = keys[0];
/*    */     } 
/* 55 */     this.optimizedResourceKey = key;
/* 56 */     this.optimizedResourceName = resourceName;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getOptimizedResourceKey() {
/* 61 */     optimizedResourceInit();
/* 62 */     return this.optimizedResourceKey; } public void name_key(String name_key) {
/*    */     String[] keyArray = MCResource.splitKey(name_key, 2);
/*    */     Name(keyArray[0]);
/*    */     Key(keyArray[1]);
/*    */   } public String getOptimizedResourceName() {
/* 67 */     optimizedResourceInit();
/* 68 */     return this.optimizedResourceName;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setOptimizedMark(String name, String newKey) {
/* 73 */     if (MCStringUtil.isNull(name)) {
/* 74 */       Key("$" + newKey);
/*    */     } else {
/*    */       
/* 77 */       Name("$" + name);
/* 78 */       Key(newKey);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\resource\ctrl\ResourceR_FW.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */