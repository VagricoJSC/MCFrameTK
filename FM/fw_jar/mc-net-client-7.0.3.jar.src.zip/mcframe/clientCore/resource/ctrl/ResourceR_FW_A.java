/*     */ package mcframe.clientCore.resource.ctrl;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.clientCore.container.MCKeyList;
/*     */ import mcframe.commonCore.container.MCExtMap;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ import mcframe.commonCore.meta.M_META;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class ResourceR_FW_A
/*     */   extends MCConstRow
/*     */ {
/*     */   public static final String $UserID = "UserID";
/*     */   public static final String $CoCD = "CoCD";
/*     */   public static final String $ExtAttr1 = "ExtAttr1";
/*     */   public static final String $ExtAttr2 = "ExtAttr2";
/*     */   public static final String $ExtAttr3 = "ExtAttr3";
/*     */   public static final String $PgmID = "PgmID";
/*     */   public static final String $Locale = "Locale";
/*     */   public static final String $Name = "Name";
/*     */   public static final String $Key = "Key";
/*     */   public static final String $Value = "Value";
/*  41 */   public static final MCMeta UserID_META = createCommonMeta("UserID", M_META.USR_ID);
/*  42 */   public static final MCMeta CoCD_META = createCommonMeta("CoCD", M_META.CO_CD);
/*  43 */   public static final MCMeta ExtAttr1_META = createCommonMeta("ExtAttr1", M_META.USR_EXT_ATTR);
/*  44 */   public static final MCMeta ExtAttr2_META = createCommonMeta("ExtAttr2", M_META.USR_EXT_ATTR);
/*  45 */   public static final MCMeta ExtAttr3_META = createCommonMeta("ExtAttr3", M_META.USR_EXT_ATTR);
/*  46 */   public static final MCMeta PgmID_META = createCommonMeta("PgmID", M_META.RES_KEY);
/*  47 */   public static final MCMeta Locale_META = createCommonMeta("Locale", M_META.LOCALE_CD);
/*  48 */   public static final MCMeta Name_META = createStringMeta("Name");
/*  49 */   public static final MCMeta Key_META = createStringMeta("Key");
/*  50 */   public static final MCMeta Value_META = createCommonMeta("Value", M_META.RES_VAL);
/*     */   
/*  52 */   protected static final MCRow.ConstMetaList<ResourceR> constMetas = new MCRow.ConstMetaList(
/*  53 */       MCConstRow.constMetas, 
/*  54 */       new MCMeta[] {
/*  55 */         UserID_META, 
/*  56 */         CoCD_META, 
/*  57 */         ExtAttr1_META, 
/*  58 */         ExtAttr2_META, 
/*  59 */         ExtAttr3_META, 
/*  60 */         PgmID_META, 
/*  61 */         Locale_META, 
/*  62 */         Name_META, 
/*  63 */         Key_META, 
/*  64 */         Value_META
/*     */       },
/*  66 */       new String[][] { {}, {} });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  77 */   protected static final MCKeyList KEYS = new MCKeyList(
/*  78 */       null, 
/*  79 */       new String[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   protected static final MCExtMap EXTMAP = new MCExtMap(
/*  88 */       null, new MCExtMap.Entry[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] colnames() {
/* 100 */     return constMetas.toNameArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMeta[] colmetas() {
/* 112 */     return constMetas.toMetaArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 118 */   private static final int offset = constMetas.offset();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCKeyList getKeys() {
/* 124 */     return KEYS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getExtMap(String aGroup) {
/* 131 */     if (aGroup == null) return null; 
/* 132 */     return (Map<String, String>)EXTMAP.get(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCKeyList getKeys(String aGroup) {
/* 139 */     if (aGroup == null) return null; 
/* 140 */     return new MCKeyList(EXTMAP.getKeyList(aGroup));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExtGroups() {
/* 147 */     Set<String> ret = EXTMAP.keySet();
/* 148 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ResourceR_FW_A(MCRow.ConstMetaList<? extends ResourceR> metas) {
/* 155 */     super(metas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceR clone() {
/* 162 */     return (ResourceR)super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceR createInstance() {
/* 169 */     return (ResourceR)super.createInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceR getValues(String... names) {
/* 176 */     return (ResourceR)super.getValues(names);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String UserID() {
/* 182 */     return getConstString(offset + 0, "UserID");
/*     */   }
/*     */   
/*     */   public void UserID(String value) {
/* 186 */     setConstString(offset + 0, "UserID", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String CoCD() {
/* 191 */     return getConstString(offset + 1, "CoCD");
/*     */   }
/*     */   
/*     */   public void CoCD(String value) {
/* 195 */     setConstString(offset + 1, "CoCD", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String ExtAttr1() {
/* 200 */     return getConstString(offset + 2, "ExtAttr1");
/*     */   }
/*     */   
/*     */   public void ExtAttr1(String value) {
/* 204 */     setConstString(offset + 2, "ExtAttr1", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String ExtAttr2() {
/* 209 */     return getConstString(offset + 3, "ExtAttr2");
/*     */   }
/*     */   
/*     */   public void ExtAttr2(String value) {
/* 213 */     setConstString(offset + 3, "ExtAttr2", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String ExtAttr3() {
/* 218 */     return getConstString(offset + 4, "ExtAttr3");
/*     */   }
/*     */   
/*     */   public void ExtAttr3(String value) {
/* 222 */     setConstString(offset + 4, "ExtAttr3", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String PgmID() {
/* 227 */     return getConstString(offset + 5, "PgmID");
/*     */   }
/*     */   
/*     */   public void PgmID(String value) {
/* 231 */     setConstString(offset + 5, "PgmID", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String Locale() {
/* 236 */     return getConstString(offset + 6, "Locale");
/*     */   }
/*     */   
/*     */   public void Locale(String value) {
/* 240 */     setConstString(offset + 6, "Locale", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String Name() {
/* 245 */     return getConstString(offset + 7, "Name");
/*     */   }
/*     */   
/*     */   public void Name(String value) {
/* 249 */     setConstString(offset + 7, "Name", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String Key() {
/* 254 */     return getConstString(offset + 8, "Key");
/*     */   }
/*     */   
/*     */   public void Key(String value) {
/* 258 */     setConstString(offset + 8, "Key", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String Value() {
/* 263 */     return getConstString(offset + 9, "Value");
/*     */   }
/*     */   
/*     */   public void Value(String value) {
/* 267 */     setConstString(offset + 9, "Value", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString(String name) {
/* 272 */     if ("UserID".equalsIgnoreCase(name)) {
/* 273 */       return UserID();
/*     */     }
/* 275 */     if ("CoCD".equalsIgnoreCase(name)) {
/* 276 */       return CoCD();
/*     */     }
/* 278 */     if ("ExtAttr1".equalsIgnoreCase(name)) {
/* 279 */       return ExtAttr1();
/*     */     }
/* 281 */     if ("ExtAttr2".equalsIgnoreCase(name)) {
/* 282 */       return ExtAttr2();
/*     */     }
/* 284 */     if ("ExtAttr3".equalsIgnoreCase(name)) {
/* 285 */       return ExtAttr3();
/*     */     }
/* 287 */     if ("PgmID".equalsIgnoreCase(name)) {
/* 288 */       return PgmID();
/*     */     }
/* 290 */     if ("Locale".equalsIgnoreCase(name)) {
/* 291 */       return Locale();
/*     */     }
/* 293 */     if ("Name".equalsIgnoreCase(name)) {
/* 294 */       return Name();
/*     */     }
/* 296 */     if ("Key".equalsIgnoreCase(name)) {
/* 297 */       return Key();
/*     */     }
/* 299 */     if ("Value".equalsIgnoreCase(name)) {
/* 300 */       return Value();
/*     */     }
/* 302 */     return super.getString(name);
/*     */   }
/*     */   
/*     */   public String getStringNE(String name) {
/* 306 */     if ("UserID".equalsIgnoreCase(name)) {
/* 307 */       return UserID();
/*     */     }
/* 309 */     if ("CoCD".equalsIgnoreCase(name)) {
/* 310 */       return CoCD();
/*     */     }
/* 312 */     if ("ExtAttr1".equalsIgnoreCase(name)) {
/* 313 */       return ExtAttr1();
/*     */     }
/* 315 */     if ("ExtAttr2".equalsIgnoreCase(name)) {
/* 316 */       return ExtAttr2();
/*     */     }
/* 318 */     if ("ExtAttr3".equalsIgnoreCase(name)) {
/* 319 */       return ExtAttr3();
/*     */     }
/* 321 */     if ("PgmID".equalsIgnoreCase(name)) {
/* 322 */       return PgmID();
/*     */     }
/* 324 */     if ("Locale".equalsIgnoreCase(name)) {
/* 325 */       return Locale();
/*     */     }
/* 327 */     if ("Name".equalsIgnoreCase(name)) {
/* 328 */       return Name();
/*     */     }
/* 330 */     if ("Key".equalsIgnoreCase(name)) {
/* 331 */       return Key();
/*     */     }
/* 333 */     if ("Value".equalsIgnoreCase(name)) {
/* 334 */       return Value();
/*     */     }
/* 336 */     return super.getStringNE(name);
/*     */   }
/*     */   
/*     */   public void setString(String name, String value) {
/* 340 */     if ("UserID".equalsIgnoreCase(name)) {
/* 341 */       UserID(value);
/*     */       return;
/*     */     } 
/* 344 */     if ("CoCD".equalsIgnoreCase(name)) {
/* 345 */       CoCD(value);
/*     */       return;
/*     */     } 
/* 348 */     if ("ExtAttr1".equalsIgnoreCase(name)) {
/* 349 */       ExtAttr1(value);
/*     */       return;
/*     */     } 
/* 352 */     if ("ExtAttr2".equalsIgnoreCase(name)) {
/* 353 */       ExtAttr2(value);
/*     */       return;
/*     */     } 
/* 356 */     if ("ExtAttr3".equalsIgnoreCase(name)) {
/* 357 */       ExtAttr3(value);
/*     */       return;
/*     */     } 
/* 360 */     if ("PgmID".equalsIgnoreCase(name)) {
/* 361 */       PgmID(value);
/*     */       return;
/*     */     } 
/* 364 */     if ("Locale".equalsIgnoreCase(name)) {
/* 365 */       Locale(value);
/*     */       return;
/*     */     } 
/* 368 */     if ("Name".equalsIgnoreCase(name)) {
/* 369 */       Name(value);
/*     */       return;
/*     */     } 
/* 372 */     if ("Key".equalsIgnoreCase(name)) {
/* 373 */       Key(value);
/*     */       return;
/*     */     } 
/* 376 */     if ("Value".equalsIgnoreCase(name)) {
/* 377 */       Value(value);
/*     */       return;
/*     */     } 
/* 380 */     super.setString(name, value);
/*     */   }
/*     */   
/*     */   public void setStringNE(String name, String value) {
/* 384 */     if ("UserID".equalsIgnoreCase(name)) {
/* 385 */       UserID(value);
/*     */       return;
/*     */     } 
/* 388 */     if ("CoCD".equalsIgnoreCase(name)) {
/* 389 */       CoCD(value);
/*     */       return;
/*     */     } 
/* 392 */     if ("ExtAttr1".equalsIgnoreCase(name)) {
/* 393 */       ExtAttr1(value);
/*     */       return;
/*     */     } 
/* 396 */     if ("ExtAttr2".equalsIgnoreCase(name)) {
/* 397 */       ExtAttr2(value);
/*     */       return;
/*     */     } 
/* 400 */     if ("ExtAttr3".equalsIgnoreCase(name)) {
/* 401 */       ExtAttr3(value);
/*     */       return;
/*     */     } 
/* 404 */     if ("PgmID".equalsIgnoreCase(name)) {
/* 405 */       PgmID(value);
/*     */       return;
/*     */     } 
/* 408 */     if ("Locale".equalsIgnoreCase(name)) {
/* 409 */       Locale(value);
/*     */       return;
/*     */     } 
/* 412 */     if ("Name".equalsIgnoreCase(name)) {
/* 413 */       Name(value);
/*     */       return;
/*     */     } 
/* 416 */     if ("Key".equalsIgnoreCase(name)) {
/* 417 */       Key(value);
/*     */       return;
/*     */     } 
/* 420 */     if ("Value".equalsIgnoreCase(name)) {
/* 421 */       Value(value);
/*     */       return;
/*     */     } 
/* 424 */     super.setStringNE(name, value);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\resource\ctrl\ResourceR_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */