/*     */ package mcframe.clientCore.resource.ctrl;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import mcframe.clientCore.requester.MCCaller;
/*     */ import mcframe.clientCore.resource.MCConfig;
/*     */ import mcframe.clientCore.resource.MCUserInfo;
/*     */ import mcframe.clientCore.sys.MCSys;
/*     */ import mcframe.commonCore.container.MCContainer;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.param.MCOperationInfo;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.commonCore.resource.ctrl.MCOptimizedResourceManager;
/*     */ import mcframe.commonCore.resource.ctrl.MCResourceBundle;
/*     */ import mcframe.commonCore.resource.ctrl.MCResourceIOBase;
/*     */ import mcframe.commonCore.resource.ctrl.MCResourceLayerType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MCDBResourceCaller
/*     */   extends MCResourceIOBase
/*     */   implements MCDBResourceReader, MCDBResourceWriter
/*     */ {
/*     */   private MCParam createParam(MCOperationInfo info) {
/*  51 */     MCParam p = new MCParam(info);
/*  52 */     p.setLimitDLSize(MCNumber.valueOf(-1));
/*  53 */     return p;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCCaller createCaller(MCParam p) {
/*  65 */     return new MCCaller(p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   private static boolean isOptimizedPersonalResource = MCConfig.client
/*  79 */     .getBoolean("net.personalResource.optimization", true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void selectSystemUserResource(MCResourceBundle resource, String base, String userid, Locale locale) {
/*  86 */     if (!MCSys.user.isLogin()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  91 */     String log = MCResourceBundle.getSourceString(null, 
/*  92 */         MCResourceBundle.Source.DATABASE);
/*  93 */     traceTargetResource(log);
/*  94 */     long stime = System.currentTimeMillis();
/*  95 */     long etime = stime;
/*     */     
/*  97 */     MCParam p = createParam(PDef.FC_FCBJL0100_Srch01_INFO);
/*     */     
/*  99 */     ResourceR cnd = ResourceR.create();
/* 100 */     cnd.UserID(userid);
/*     */     
/* 102 */     cnd.Name(base);
/* 103 */     p.addUpBlock((MCContainer)cnd);
/*     */     
/* 105 */     MCList<ResourceR> rslt = MCList.create(ResourceR.class);
/* 106 */     p.addDownBlock((MCContainer)rslt);
/*     */     
/*     */     try {
/* 109 */       createCaller(p).exec();
/*     */     }
/* 111 */     catch (MCException ex) {
/* 112 */       etime = System.currentTimeMillis();
/* 113 */       traceReadErrorResource(log, stime, etime);
/* 114 */       throw ex;
/*     */     } 
/*     */     
/* 117 */     if (rslt.size() > 0) {
/*     */       
/* 119 */       etime = System.currentTimeMillis();
/* 120 */       if (traceFoundResource(log, stime, etime) == stime) {
/* 121 */         traceReadResource(log, true, stime, etime);
/*     */       }
/*     */       
/* 124 */       MCOptimizedResourceManager.deOptimizedResourceKey(false, rslt);
/*     */     }
/*     */     else {
/*     */       
/* 128 */       etime = System.currentTimeMillis();
/* 129 */       traceNotFoundResource(log, stime, etime);
/*     */     } 
/* 131 */     resource.setList(rslt);
/*     */     
/* 133 */     MCCommonCtrlProxy.PROXY.addSearchedProgram(resource, 
/* 134 */         "ALL");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void selectResource(Map<String, MCResourceBundle> usermap, Map<String, MCResourceBundle> extmap, Map<String, MCResourceBundle> sysmap, Map<String, MCResourceBundle> barcodemap, String userid, String cocd, String extattr1, String extattr2, String extattr3, Locale locale) {
/* 142 */     if (!MCSys.user.isLogin()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 147 */     String log = MCResourceBundle.getSourceString(null, 
/* 148 */         MCResourceBundle.Source.DATABASE);
/* 149 */     traceTargetResource(log);
/* 150 */     long stime = System.currentTimeMillis();
/* 151 */     long etime = stime;
/*     */     
/* 153 */     MCParam p = createParam(PDef.FC_FCBJL0100_Srch02_INFO);
/*     */     
/* 155 */     MCList<ResourceR> cndl = MCList.create(ResourceR.class);
/* 156 */     if (usermap != null) {
/* 157 */       ResourceR cnd = (ResourceR)cndl.createRow();
/* 158 */       cnd.UserID(userid);
/*     */       
/* 160 */       cnd.Locale(null);
/* 161 */       cndl.add((MCRow)cnd);
/*     */     } 
/* 163 */     if (extmap != null) {
/* 164 */       ResourceR cnd = (ResourceR)cndl.createRow();
/* 165 */       cnd.UserID("?EXT");
/* 166 */       cnd.CoCD(cocd);
/* 167 */       cnd.ExtAttr1(extattr1);
/* 168 */       cnd.ExtAttr2(extattr2);
/* 169 */       cnd.ExtAttr3(extattr3);
/*     */       
/* 171 */       cnd.Locale(null);
/* 172 */       cndl.add((MCRow)cnd);
/*     */     } 
/* 174 */     if (sysmap != null) {
/* 175 */       ResourceR cnd = (ResourceR)cndl.createRow();
/* 176 */       cnd.UserID("?ALL");
/*     */       
/* 178 */       cnd.Locale(null);
/* 179 */       cndl.add((MCRow)cnd);
/*     */     } 
/* 181 */     if (barcodemap != null) {
/* 182 */       ResourceR cnd = (ResourceR)cndl.createRow();
/* 183 */       cnd.UserID("?ALL");
/*     */       
/* 185 */       cnd.Locale(null);
/* 186 */       cndl.add((MCRow)cnd);
/*     */     } 
/*     */     
/* 189 */     p.addUpBlock((MCContainer)cndl);
/*     */     
/* 191 */     MCList<ResourceR> rslt = MCList.create(ResourceR.class);
/* 192 */     p.addDownBlock((MCContainer)rslt);
/*     */     
/*     */     try {
/* 195 */       createCaller(p).exec();
/*     */     }
/* 197 */     catch (MCException ex) {
/* 198 */       etime = System.currentTimeMillis();
/* 199 */       traceReadErrorResource(log, stime, etime);
/* 200 */       throw ex;
/*     */     } 
/*     */     
/* 203 */     boolean ret = (rslt.size() > 0);
/* 204 */     if (ret) {
/*     */       
/* 206 */       etime = System.currentTimeMillis();
/* 207 */       if (traceFoundResource(log, stime, etime) == stime) {
/* 208 */         traceReadResource(log, ret, stime, etime);
/*     */       }
/*     */       
/* 211 */       MCOptimizedResourceManager.deOptimizedResourceKey(false, rslt);
/*     */     }
/*     */     else {
/*     */       
/* 215 */       etime = System.currentTimeMillis();
/* 216 */       traceNotFoundResource(log, stime, etime);
/*     */     } 
/*     */     
/* 219 */     Map<String, MCList<ResourceR>> um = new HashMap<>();
/* 220 */     Map<String, MCList<ResourceR>> em = new HashMap<>();
/* 221 */     Map<String, MCList<ResourceR>> sm = new HashMap<>();
/* 222 */     Map<String, MCList<ResourceR>> bm = new HashMap<>();
/*     */     
/* 224 */     if ("?ALL".equals("?ALL")) {
/* 225 */       bm = sm;
/*     */     }
/*     */     
/* 228 */     for (ResourceR o : rslt) {
/* 229 */       Map<String, MCList<ResourceR>> m = null;
/* 230 */       if (userid.equals(o.UserID())) {
/* 231 */         m = um;
/*     */       }
/* 233 */       else if ("?EXT".equals(o.UserID())) {
/* 234 */         m = em;
/*     */       }
/* 236 */       else if ("?ALL".equals(o.UserID())) {
/* 237 */         m = sm;
/*     */       }
/* 239 */       else if ("?ALL".equals(o.UserID())) {
/* 240 */         m = bm;
/*     */       } else {
/*     */         continue;
/*     */       } 
/*     */ 
/*     */       
/* 246 */       if (m == null) {
/*     */         continue;
/*     */       }
/*     */       
/* 250 */       MCList<ResourceR> l = m.get(o.Name());
/* 251 */       if (l == null) {
/* 252 */         l = MCList.create(ResourceR.class);
/* 253 */         m.put(o.Name(), l);
/*     */       } 
/* 255 */       l.add((MCRow)o);
/*     */     } 
/*     */     
/* 258 */     if (usermap != null) {
/* 259 */       for (Map.Entry<String, MCResourceBundle> e : usermap.entrySet()) {
/* 260 */         MCResourceBundle o = e.getValue();
/* 261 */         MCCommonCtrlProxy.PROXY.addSearchedProgram(o, 
/* 262 */             "ALL");
/* 263 */         o.setList(um.get(e.getKey()));
/*     */       } 
/*     */     }
/* 266 */     if (extmap != null) {
/* 267 */       for (Map.Entry<String, MCResourceBundle> e : extmap.entrySet()) {
/* 268 */         MCResourceBundle o = e.getValue();
/* 269 */         MCCommonCtrlProxy.PROXY.addSearchedProgram(o, 
/* 270 */             "ALL");
/* 271 */         o.setList(em.get(e.getKey()));
/*     */       } 
/*     */     }
/* 274 */     if (sysmap != null) {
/* 275 */       for (Map.Entry<String, MCResourceBundle> e : sysmap.entrySet()) {
/* 276 */         MCResourceBundle o = e.getValue();
/* 277 */         MCCommonCtrlProxy.PROXY.addSearchedProgram(o, 
/* 278 */             "ALL");
/* 279 */         o.setList(sm.get(e.getKey()));
/*     */       } 
/*     */     }
/* 282 */     if (barcodemap != null) {
/* 283 */       for (Map.Entry<String, MCResourceBundle> e : barcodemap.entrySet()) {
/* 284 */         MCResourceBundle o = e.getValue();
/* 285 */         MCCommonCtrlProxy.PROXY.addSearchedProgram(o, 
/* 286 */             "ALL");
/* 287 */         o.setList(bm.get(e.getKey()));
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void selectPgmResource(Map<String, MCResourceBundle> usermap, Map<String, MCResourceBundle> extmap, Map<String, MCResourceBundle> sysmap, Map<String, MCResourceBundle> barcodemap, String pgmid, String userid, String cocd, String extattr1, String extattr2, String extattr3, Locale locale) {
/* 298 */     if (!MCSys.user.isLogin()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 303 */     String log = MCResourceBundle.getSourceString(null, 
/* 304 */         MCResourceBundle.Source.DATABASE);
/* 305 */     traceTargetResource(log);
/* 306 */     long stime = System.currentTimeMillis();
/* 307 */     long etime = stime;
/*     */     
/* 309 */     MCParam a = createParam(PDef.FC_FCBJL0100_Srch03_INFO);
/*     */     
/* 311 */     MCList<ResourceR> cndl = MCList.create(ResourceR.class);
/* 312 */     if (usermap != null) {
/* 313 */       ResourceR cnd = ResourceR.create();
/* 314 */       cnd.UserID(userid);
/* 315 */       cnd.PgmID(pgmid);
/*     */       
/* 317 */       cnd.Locale(null);
/* 318 */       cndl.add((MCRow)cnd);
/*     */     } 
/* 320 */     if (extmap != null) {
/* 321 */       ResourceR cnd = ResourceR.create();
/* 322 */       cnd.UserID("?EXT");
/* 323 */       cnd.CoCD(cocd);
/* 324 */       cnd.ExtAttr1(extattr1);
/* 325 */       cnd.ExtAttr2(extattr2);
/* 326 */       cnd.ExtAttr3(extattr3);
/* 327 */       cnd.PgmID(pgmid);
/*     */       
/* 329 */       cnd.Locale(null);
/* 330 */       cndl.add((MCRow)cnd);
/*     */     } 
/* 332 */     if (sysmap != null) {
/* 333 */       ResourceR cnd = ResourceR.create();
/* 334 */       cnd.UserID("?ALL");
/* 335 */       cnd.PgmID(pgmid);
/*     */       
/* 337 */       cnd.Locale(null);
/* 338 */       cndl.add((MCRow)cnd);
/*     */     } 
/* 340 */     if (barcodemap != null) {
/* 341 */       ResourceR cnd = ResourceR.create();
/* 342 */       cnd.UserID("?ALL");
/* 343 */       cnd.PgmID(pgmid);
/*     */       
/* 345 */       cnd.Locale(null);
/* 346 */       cndl.add((MCRow)cnd);
/*     */     } 
/* 348 */     a.addUpBlock((MCContainer)cndl);
/*     */     
/* 350 */     MCList<ResourceR> rslt = MCList.create(ResourceR.class);
/* 351 */     a.addDownBlock((MCContainer)rslt);
/*     */     
/*     */     try {
/* 354 */       createCaller(a).exec();
/*     */     }
/* 356 */     catch (MCException ex) {
/* 357 */       etime = System.currentTimeMillis();
/* 358 */       traceReadErrorResource(log, stime, etime);
/* 359 */       throw ex;
/*     */     } 
/*     */     
/* 362 */     boolean ret = (rslt.size() > 0);
/* 363 */     if (ret) {
/*     */       
/* 365 */       etime = System.currentTimeMillis();
/* 366 */       if (traceFoundResource(log, stime, etime) == stime) {
/* 367 */         traceReadResource(log, ret, stime, etime);
/*     */       }
/*     */       
/* 370 */       MCOptimizedResourceManager.deOptimizedResourceKey(false, rslt);
/*     */     }
/*     */     else {
/*     */       
/* 374 */       etime = System.currentTimeMillis();
/* 375 */       traceNotFoundResource(log, stime, etime);
/*     */     } 
/*     */     
/* 378 */     Map<String, MCList<ResourceR>> um = new HashMap<>();
/* 379 */     Map<String, MCList<ResourceR>> em = new HashMap<>();
/* 380 */     Map<String, MCList<ResourceR>> sm = new HashMap<>();
/* 381 */     Map<String, MCList<ResourceR>> bm = new HashMap<>();
/*     */     
/* 383 */     if ("?ALL".equals("?ALL")) {
/* 384 */       bm = sm;
/*     */     }
/*     */     
/* 387 */     for (ResourceR o : rslt) {
/* 388 */       Map<String, MCList<ResourceR>> m = null;
/* 389 */       if (o.UserID().equals(userid)) {
/* 390 */         m = um;
/*     */       }
/* 392 */       else if ("?EXT".equals(o.UserID())) {
/* 393 */         m = em;
/*     */       }
/* 395 */       else if ("?ALL".equals(o.UserID())) {
/* 396 */         m = sm;
/*     */       }
/* 398 */       else if ("?ALL".equals(o.UserID())) {
/* 399 */         m = bm;
/*     */       } else {
/*     */         continue;
/*     */       } 
/*     */       
/* 404 */       MCList<ResourceR> l = m.get(o.Name());
/* 405 */       if (l == null) {
/* 406 */         l = MCList.create(ResourceR.class);
/* 407 */         m.put(o.Name(), l);
/*     */       } 
/* 409 */       l.add((MCRow)o);
/*     */     } 
/*     */     
/* 412 */     if (usermap != null) {
/* 413 */       for (Map.Entry<String, MCResourceBundle> e : usermap.entrySet()) {
/* 414 */         MCResourceBundle o = e.getValue();
/* 415 */         MCCommonCtrlProxy.PROXY.addSearchedProgram(o, pgmid);
/* 416 */         o.setList(um.get(e.getKey()));
/*     */       } 
/*     */     }
/* 419 */     if (extmap != null) {
/* 420 */       for (Map.Entry<String, MCResourceBundle> e : extmap.entrySet()) {
/* 421 */         MCResourceBundle o = e.getValue();
/* 422 */         MCCommonCtrlProxy.PROXY.addSearchedProgram(o, pgmid);
/* 423 */         o.setList(em.get(e.getKey()));
/*     */       } 
/*     */     }
/* 426 */     if (sysmap != null) {
/* 427 */       for (Map.Entry<String, MCResourceBundle> e : sysmap.entrySet()) {
/* 428 */         MCResourceBundle o = e.getValue();
/* 429 */         MCCommonCtrlProxy.PROXY.addSearchedProgram(o, pgmid);
/* 430 */         o.setList(sm.get(e.getKey()));
/*     */       } 
/*     */     }
/* 433 */     if (barcodemap != null) {
/* 434 */       for (Map.Entry<String, MCResourceBundle> e : barcodemap.entrySet()) {
/* 435 */         MCResourceBundle o = e.getValue();
/* 436 */         MCCommonCtrlProxy.PROXY.addSearchedProgram(o, pgmid);
/* 437 */         o.setList(bm.get(e.getKey()));
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateUserResource(MCResourceBundle resource, String base, String userid, Locale locale) {
/* 445 */     if (!MCSys.user.isLogin()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 450 */     MCResourceBundle.Source y = MCResourceBundle.Source.DATABASE;
/* 451 */     String log = MCResourceBundle.getSourceString(null, y);
/* 452 */     traceTargetResource(log);
/*     */     
/* 454 */     MCParam p = createParam(PDef.FC_FCBJL0100_Upd01_INFO);
/*     */     
/* 456 */     MCList<ResourceR> dtl = MCList.create(ResourceR.class);
/* 457 */     MCUserInfo i = new MCUserInfo();
/* 458 */     i.userid(userid);
/* 459 */     resource.addHistoryList(dtl, base, i.userid(), i.cocd(), i.extattr1(), 
/* 460 */         i.extattr2(), i.extattr3(), i.locale());
/* 461 */     p.addUpBlock((MCContainer)dtl);
/*     */     
/*     */     try {
/* 464 */       createCaller(p).exec();
/*     */     }
/* 466 */     catch (MCException ex) {
/*     */       
/* 468 */       traceWriteErrorResource(log);
/* 469 */       throw ex;
/*     */     } 
/*     */     
/* 472 */     resource.commit(null, y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource(Map<String, MCResourceBundle> usermap, Map<String, MCResourceBundle> extmap, Map<String, MCResourceBundle> sysmap, Map<String, MCResourceBundle> barcodemap, String userid, String cocd, String extattr1, String extattr2, String extattr3, Locale locale) {
/* 480 */     if (!MCSys.user.isLogin()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 485 */     MCResourceBundle.Source y = MCResourceBundle.Source.DATABASE;
/* 486 */     String log = MCResourceBundle.getSourceString(null, y);
/* 487 */     traceTargetResource(log);
/*     */     
/* 489 */     MCParam p = createParam(PDef.FC_FCBJL0100_Upd01_INFO);
/*     */     
/* 491 */     MCList<ResourceR> dtl = MCList.create(ResourceR.class);
/*     */     
/* 493 */     MCUserInfo i = new MCUserInfo();
/* 494 */     i.userid(userid);
/* 495 */     for (Map.Entry<String, MCResourceBundle> e : usermap.entrySet()) {
/* 496 */       ((MCResourceBundle)e.getValue()).addHistoryList(dtl, e.getKey(), i.userid(), i.cocd(), 
/* 497 */           i.extattr1(), i.extattr2(), i.extattr3(), i.locale());
/*     */     }
/*     */     
/* 500 */     i = new MCUserInfo();
/* 501 */     i.userid("?EXT");
/* 502 */     i.cocd(cocd);
/* 503 */     i.extattr1(extattr1);
/* 504 */     i.extattr2(extattr2);
/* 505 */     i.extattr3(extattr3);
/* 506 */     for (Map.Entry<String, MCResourceBundle> e : extmap.entrySet()) {
/* 507 */       ((MCResourceBundle)e.getValue()).addHistoryList(dtl, e.getKey(), i.userid(), i.cocd(), 
/* 508 */           i.extattr1(), i.extattr2(), i.extattr3(), i.locale());
/*     */     }
/*     */     
/* 511 */     i = new MCUserInfo();
/* 512 */     i.userid("?ALL");
/* 513 */     for (Map.Entry<String, MCResourceBundle> e : sysmap.entrySet()) {
/* 514 */       ((MCResourceBundle)e.getValue()).addHistoryList(dtl, e.getKey(), i.userid(), i.cocd(), 
/* 515 */           i.extattr1(), i.extattr2(), i.extattr3(), i.locale());
/*     */     }
/*     */     
/* 518 */     i = new MCUserInfo();
/* 519 */     i.userid("?ALL");
/* 520 */     for (Map.Entry<String, MCResourceBundle> e : barcodemap.entrySet()) {
/* 521 */       ((MCResourceBundle)e.getValue()).addHistoryList(dtl, e.getKey(), i.userid(), i.cocd(), 
/* 522 */           i.extattr1(), i.extattr2(), i.extattr3(), i.locale());
/*     */     }
/*     */     
/* 525 */     p.addUpBlock((MCContainer)dtl);
/*     */     
/*     */     try {
/* 528 */       createCaller(p).exec();
/*     */     }
/* 530 */     catch (MCException ex) {
/*     */       
/* 532 */       traceWriteErrorResource(log);
/* 533 */       throw ex;
/*     */     } 
/*     */     
/* 536 */     for (Map.Entry<String, MCResourceBundle> e : usermap.entrySet()) {
/* 537 */       ((MCResourceBundle)e.getValue()).commit(null, y);
/*     */     }
/* 539 */     for (Map.Entry<String, MCResourceBundle> e : extmap.entrySet()) {
/* 540 */       ((MCResourceBundle)e.getValue()).commit(null, y);
/*     */     }
/* 542 */     for (Map.Entry<String, MCResourceBundle> e : sysmap.entrySet()) {
/* 543 */       ((MCResourceBundle)e.getValue()).commit(null, y);
/*     */     }
/* 545 */     for (Map.Entry<String, MCResourceBundle> e : barcodemap.entrySet()) {
/* 546 */       ((MCResourceBundle)e.getValue()).commit(null, y);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deleteResource(String name, MCResourceLayerType type, String prefix, String userid, String cocd, String extattr1, String extattr2, String extattr3, Locale locale) {
/* 554 */     if (!MCSys.user.isLogin()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 559 */     MCResourceBundle.Source y = MCResourceBundle.Source.DATABASE;
/* 560 */     String log = MCResourceBundle.getSourceString(null, y);
/* 561 */     traceTargetResource(log);
/*     */     
/* 563 */     MCParam p = createParam(PDef.FC_FCBJL0100_Del01_INFO);
/*     */     
/* 565 */     ResourceR hdr = ResourceR.create();
/* 566 */     hdr.Name(name);
/* 567 */     hdr.Key(String.valueOf(prefix) + "%");
/* 568 */     switch (type) {
/*     */       case USER:
/* 570 */         hdr.UserID(userid);
/*     */         break;
/*     */       case EXT:
/* 573 */         hdr.UserID("?EXT");
/* 574 */         hdr.CoCD(cocd);
/* 575 */         hdr.ExtAttr1(extattr1);
/* 576 */         hdr.ExtAttr2(extattr2);
/* 577 */         hdr.ExtAttr3(extattr3);
/*     */         break;
/*     */       case SYS:
/* 580 */         hdr.UserID("?ALL");
/*     */         break;
/*     */       case null:
/* 583 */         hdr.UserID("?ALL");
/*     */         break;
/*     */       
/*     */       default:
/*     */         return;
/*     */     } 
/* 589 */     p.addUpBlock((MCContainer)hdr);
/*     */     
/*     */     try {
/* 592 */       createCaller(p).exec();
/*     */     }
/* 594 */     catch (MCException ex) {
/*     */       
/* 596 */       traceWriteErrorResource(log);
/* 597 */       throw ex;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void exportData(MCResourceBundle resource, MCUserInfo info) {
/* 603 */     if (!MCSys.user.isLogin()) {
/*     */       return;
/*     */     }
/*     */     
/* 607 */     MCParam p = createParam(PDef.FC_FCBJL0100_Exp01_INFO);
/*     */     
/* 609 */     ResourceR cnd = ResourceR.create();
/* 610 */     cnd.UserID(info.userid());
/* 611 */     cnd.CoCD(info.cocd());
/* 612 */     cnd.ExtAttr1(info.extattr1());
/* 613 */     cnd.ExtAttr2(info.extattr2());
/* 614 */     cnd.ExtAttr3(info.extattr3());
/*     */     
/* 616 */     p.addUpBlock((MCContainer)cnd);
/*     */     
/* 618 */     MCList<ResourceR> rslt = MCList.create(ResourceR.class);
/* 619 */     p.addDownBlock((MCContainer)rslt);
/*     */     
/* 621 */     createCaller(p).exec();
/*     */     
/* 623 */     if (rslt.size() > 0) {
/* 624 */       MCOptimizedResourceManager.deOptimizedResourceKey(false, rslt);
/*     */     }
/*     */     
/* 627 */     resource.setList(rslt);
/*     */   }
/*     */ 
/*     */   
/*     */   public void importData(MCResourceBundle resource, MCUserInfo... infos) {
/* 632 */     if (!MCSys.user.isLogin()) {
/*     */       return;
/*     */     }
/*     */     
/* 636 */     MCParam p = createParam(PDef.FC_FCBJL0100_Imp01_INFO);
/*     */     
/* 638 */     MCList<ResourceR> cnd = MCList.create(ResourceR.class); byte b; int i; MCUserInfo[] arrayOfMCUserInfo;
/* 639 */     for (i = (arrayOfMCUserInfo = infos).length, b = 0; b < i; ) { MCUserInfo mCUserInfo = arrayOfMCUserInfo[b];
/* 640 */       ResourceR o = (ResourceR)cnd.createRow();
/* 641 */       o.UserID(mCUserInfo.userid());
/* 642 */       o.CoCD(mCUserInfo.cocd());
/* 643 */       o.ExtAttr1(mCUserInfo.extattr1());
/* 644 */       o.ExtAttr2(mCUserInfo.extattr2());
/* 645 */       o.ExtAttr3(mCUserInfo.extattr3());
/*     */       
/* 647 */       cnd.add((MCRow)o); b++; }
/*     */     
/* 649 */     p.addUpBlock((MCContainer)cnd);
/*     */ 
/*     */     
/* 652 */     MCList<ResourceR> data = MCList.create(ResourceR.class);
/* 653 */     for (Map.Entry<String, String> e : (Iterable<Map.Entry<String, String>>)resource.toMap().entrySet()) {
/* 654 */       ResourceR o = (ResourceR)data.createRow();
/* 655 */       o.Key(e.getKey());
/* 656 */       o.Value(e.getValue());
/* 657 */       data.add((MCRow)o);
/*     */     } 
/*     */     
/* 660 */     if (isOptimizedPersonalResource) {
/* 661 */       MCOptimizedResourceManager.optimizeResourceKey(data);
/*     */     }
/*     */ 
/*     */     
/* 665 */     p.addUpBlock((MCContainer)data);
/*     */ 
/*     */     
/* 668 */     createCaller(p).exec();
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\resource\ctrl\MCDBResourceCaller.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */