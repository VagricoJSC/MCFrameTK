/*     */ package mcframe.clientCore.resource.ctrl;
/*     */ 
/*     */ import mcframe.commonCore.param.MCContainerDef;
/*     */ import mcframe.commonCore.param.MCDef;
/*     */ import mcframe.commonCore.param.MCGeneralContainerDef;
/*     */ import mcframe.commonCore.param.MCItemDef;
/*     */ import mcframe.commonCore.param.MCOperationInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PDef_FW_A
/*     */   extends MCDef
/*     */ {
/*     */   public MCContainerDef getCustomDef(String id) {
/*  18 */     if (id == null) {
/*  19 */       return null;
/*     */     }
/*     */     
/*  22 */     if (id.equals("FC.FCBJL0100.Upd01.UP.BLOCK0")) {
/*  23 */       return FC_FCBJL0100_Upd01_UP_BLOCK0();
/*     */     }
/*  25 */     if (id.equals("FC.FCBJL0100.Del01.UP.BLOCK0")) {
/*  26 */       return FC_FCBJL0100_Del01_UP_BLOCK0();
/*     */     }
/*  28 */     if (id.equals("FC.FCBJL0100.Srch01.UP.BLOCK0")) {
/*  29 */       return FC_FCBJL0100_Srch01_UP_BLOCK0();
/*     */     }
/*  31 */     if (id.equals("FC.FCBJL0100.Srch01.DOWN.BLOCK0")) {
/*  32 */       return FC_FCBJL0100_Srch01_DOWN_BLOCK0();
/*     */     }
/*  34 */     if (id.equals("FC.FCBJL0100.Srch02.UP.BLOCK0")) {
/*  35 */       return FC_FCBJL0100_Srch02_UP_BLOCK0();
/*     */     }
/*  37 */     if (id.equals("FC.FCBJL0100.Srch02.DOWN.BLOCK0")) {
/*  38 */       return FC_FCBJL0100_Srch02_DOWN_BLOCK0();
/*     */     }
/*  40 */     if (id.equals("FC.FCBJL0100.Srch03.UP.BLOCK0")) {
/*  41 */       return FC_FCBJL0100_Srch03_UP_BLOCK0();
/*     */     }
/*  43 */     if (id.equals("FC.FCBJL0100.Srch03.DOWN.BLOCK0")) {
/*  44 */       return FC_FCBJL0100_Srch03_DOWN_BLOCK0();
/*     */     }
/*  46 */     if (id.equals("FC.FCBJL0100.Imp01.UP.BLOCK0")) {
/*  47 */       return FC_FCBJL0100_Imp01_UP_BLOCK0();
/*     */     }
/*  49 */     if (id.equals("FC.FCBJL0100.Imp01.UP.BLOCK1")) {
/*  50 */       return FC_FCBJL0100_Imp01_UP_BLOCK1();
/*     */     }
/*  52 */     if (id.equals("FC.FCBJL0100.Exp01.UP.BLOCK0")) {
/*  53 */       return FC_FCBJL0100_Exp01_UP_BLOCK0();
/*     */     }
/*  55 */     if (id.equals("FC.FCBJL0100.Exp01.DOWN.BLOCK0")) {
/*  56 */       return FC_FCBJL0100_Exp01_DOWN_BLOCK0();
/*     */     }
/*     */ 
/*     */     
/*  60 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   static final MCOperationInfo FC_FCBJL0100_Upd01_INFO = new MCOperationInfo("FC", "FCBJL0100", "Upd01", "000000", new PDef());
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBJL0100_Upd01_UP_BLOCK0() {
/*  70 */     return (MCContainerDef)new MCGeneralContainerDef(
/*  71 */         new MCItemDef[] {
/*  72 */           MCItemDef.create("UserID", "user_id"), 
/*  73 */           MCItemDef.create("CoCD", "co_cd"), 
/*  74 */           MCItemDef.create("ExtAttr1", "ext_attr1"), 
/*  75 */           MCItemDef.create("ExtAttr2", "ext_attr2"), 
/*  76 */           MCItemDef.create("ExtAttr3", "ext_attr3"), 
/*  77 */           MCItemDef.create("Locale", "locale"), 
/*  78 */           MCItemDef.create("Name", "name"), 
/*  79 */           MCItemDef.create("Key", "res_key"), 
/*  80 */           MCItemDef.create("Value", "res_val")
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*  85 */   static final MCOperationInfo FC_FCBJL0100_Del01_INFO = new MCOperationInfo("FC", "FCBJL0100", "Del01", "000000", new PDef());
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBJL0100_Del01_UP_BLOCK0() {
/*  89 */     return (MCContainerDef)new MCGeneralContainerDef(
/*  90 */         new MCItemDef[] {
/*  91 */           MCItemDef.create("UserID", "user_id"), 
/*  92 */           MCItemDef.create("CoCD", "co_cd"), 
/*  93 */           MCItemDef.create("ExtAttr1", "ext_attr1"), 
/*  94 */           MCItemDef.create("ExtAttr2", "ext_attr2"), 
/*  95 */           MCItemDef.create("ExtAttr3", "ext_attr3"), 
/*  96 */           MCItemDef.create("Locale", "locale"), 
/*  97 */           MCItemDef.create("Name", "name"), 
/*  98 */           MCItemDef.create("Key", "res_key_prefix")
/*     */         });
/*     */   }
/*     */ 
/*     */   
/* 103 */   static final MCOperationInfo FC_FCBJL0100_Srch01_INFO = new MCOperationInfo("FC", "FCBJL0100", "Srch01", "000000", new PDef());
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBJL0100_Srch01_UP_BLOCK0() {
/* 107 */     return (MCContainerDef)new MCGeneralContainerDef(
/* 108 */         new MCItemDef[] {
/* 109 */           MCItemDef.create("UserID", "user_id"), 
/* 110 */           MCItemDef.create("Locale", "locale"), 
/* 111 */           MCItemDef.create("Name", "name")
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBJL0100_Srch01_DOWN_BLOCK0() {
/* 119 */     return (MCContainerDef)new MCGeneralContainerDef(
/* 120 */         new MCItemDef[] {
/* 121 */           MCItemDef.create("Key", "res_key"), 
/* 122 */           MCItemDef.create("Value", "res_val")
/*     */         });
/*     */   }
/*     */ 
/*     */   
/* 127 */   static final MCOperationInfo FC_FCBJL0100_Srch02_INFO = new MCOperationInfo("FC", "FCBJL0100", "Srch02", "000000", new PDef());
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBJL0100_Srch02_UP_BLOCK0() {
/* 131 */     return (MCContainerDef)new MCGeneralContainerDef(
/* 132 */         new MCItemDef[] {
/* 133 */           MCItemDef.create("UserID", "user_id"), 
/* 134 */           MCItemDef.create("CoCD", "co_cd"), 
/* 135 */           MCItemDef.create("ExtAttr1", "ext_attr1"), 
/* 136 */           MCItemDef.create("ExtAttr2", "ext_attr2"), 
/* 137 */           MCItemDef.create("ExtAttr3", "ext_attr3"), 
/* 138 */           MCItemDef.create("Locale", "locale")
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBJL0100_Srch02_DOWN_BLOCK0() {
/* 146 */     return (MCContainerDef)new MCGeneralContainerDef(
/* 147 */         new MCItemDef[] {
/* 148 */           MCItemDef.create("UserID", "user_id"), 
/* 149 */           MCItemDef.create("CoCD", "co_cd"), 
/* 150 */           MCItemDef.create("ExtAttr1", "ext_attr1"), 
/* 151 */           MCItemDef.create("ExtAttr2", "ext_attr2"), 
/* 152 */           MCItemDef.create("ExtAttr3", "ext_attr3"), 
/* 153 */           MCItemDef.create("Name", "name"), 
/* 154 */           MCItemDef.create("Key", "res_key"), 
/* 155 */           MCItemDef.create("Value", "res_val")
/*     */         });
/*     */   }
/*     */ 
/*     */   
/* 160 */   static final MCOperationInfo FC_FCBJL0100_Srch03_INFO = new MCOperationInfo("FC", "FCBJL0100", "Srch03", "000000", new PDef());
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBJL0100_Srch03_UP_BLOCK0() {
/* 164 */     return (MCContainerDef)new MCGeneralContainerDef(
/* 165 */         new MCItemDef[] {
/* 166 */           MCItemDef.create("UserID", "user_id"), 
/* 167 */           MCItemDef.create("CoCD", "co_cd"), 
/* 168 */           MCItemDef.create("ExtAttr1", "ext_attr1"), 
/* 169 */           MCItemDef.create("ExtAttr2", "ext_attr2"), 
/* 170 */           MCItemDef.create("ExtAttr3", "ext_attr3"), 
/* 171 */           MCItemDef.create("PgmID", "pgm_id"), 
/* 172 */           MCItemDef.create("Locale", "locale")
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBJL0100_Srch03_DOWN_BLOCK0() {
/* 180 */     return (MCContainerDef)new MCGeneralContainerDef(
/* 181 */         new MCItemDef[] {
/* 182 */           MCItemDef.create("UserID", "user_id"), 
/* 183 */           MCItemDef.create("CoCD", "co_cd"), 
/* 184 */           MCItemDef.create("ExtAttr1", "ext_attr1"), 
/* 185 */           MCItemDef.create("ExtAttr2", "ext_attr2"), 
/* 186 */           MCItemDef.create("ExtAttr3", "ext_attr3"), 
/* 187 */           MCItemDef.create("Name", "name"), 
/* 188 */           MCItemDef.create("Key", "res_key"), 
/* 189 */           MCItemDef.create("Value", "res_val")
/*     */         });
/*     */   }
/*     */ 
/*     */   
/* 194 */   static final MCOperationInfo FC_FCBJL0100_Imp01_INFO = new MCOperationInfo("FC", "FCBJL0100", "Imp01", "000000", new PDef());
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBJL0100_Imp01_UP_BLOCK0() {
/* 198 */     return (MCContainerDef)new MCGeneralContainerDef(
/* 199 */         new MCItemDef[] {
/* 200 */           MCItemDef.create("UserID", "user_id"), 
/* 201 */           MCItemDef.create("CoCD", "co_cd"), 
/* 202 */           MCItemDef.create("ExtAttr1", "ext_attr1"), 
/* 203 */           MCItemDef.create("ExtAttr2", "ext_attr2"), 
/* 204 */           MCItemDef.create("ExtAttr3", "ext_attr3"), 
/* 205 */           MCItemDef.create("Locale", "locale")
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBJL0100_Imp01_UP_BLOCK1() {
/* 212 */     return (MCContainerDef)new MCGeneralContainerDef(
/* 213 */         new MCItemDef[] {
/* 214 */           MCItemDef.create("Key", "name_key"), 
/* 215 */           MCItemDef.create("Value", "res_val")
/*     */         });
/*     */   }
/*     */ 
/*     */   
/* 220 */   static final MCOperationInfo FC_FCBJL0100_Exp01_INFO = new MCOperationInfo("FC", "FCBJL0100", "Exp01", "000000", new PDef());
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBJL0100_Exp01_UP_BLOCK0() {
/* 224 */     return (MCContainerDef)new MCGeneralContainerDef(
/* 225 */         new MCItemDef[] {
/* 226 */           MCItemDef.create("UserID", "user_id"), 
/* 227 */           MCItemDef.create("CoCD", "co_cd"), 
/* 228 */           MCItemDef.create("ExtAttr1", "ext_attr1"), 
/* 229 */           MCItemDef.create("ExtAttr2", "ext_attr2"), 
/* 230 */           MCItemDef.create("ExtAttr3", "ext_attr3"), 
/* 231 */           MCItemDef.create("Locale", "locale")
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBJL0100_Exp01_DOWN_BLOCK0() {
/* 239 */     return (MCContainerDef)new MCGeneralContainerDef(
/* 240 */         new MCItemDef[] {
/* 241 */           MCItemDef.create("Key", "name_key"), 
/* 242 */           MCItemDef.create("Value", "res_val")
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\resource\ctrl\PDef_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */