/*    */ package mcframe.clientCore.listLogic;
/*    */ 
/*    */ import mcframe.clientCore.requester.MCCaller;
/*    */ import mcframe.commonCore.container.MCRow;
/*    */ import mcframe.commonCore.param.MCParam;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface MCLLCallerSupplier
/*    */ {
/*    */   default MCCaller createListLogicRowCaller(MCParam p, MCRow bind) {
/* 26 */     return createListLogicCaller(p, bind);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   default MCCaller createListLogicListCaller(MCParam p, MCRow bind) {
/* 38 */     return createListLogicCaller(p, bind);
/*    */   }
/*    */   
/*    */   MCCaller createListLogicCaller(MCParam paramMCParam, MCRow paramMCRow);
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\listLogic\MCLLCallerSupplier.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */