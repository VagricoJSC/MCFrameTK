/*    */ package mcframe.clientCore.listLogic;
/*    */ 
/*    */ import mcframe.commonCore.param.MCContainerDef;
/*    */ import mcframe.commonCore.param.MCDef;
/*    */ import mcframe.commonCore.param.MCGeneralContainerDef;
/*    */ import mcframe.commonCore.param.MCItemDef;
/*    */ import mcframe.commonCore.param.MCOperationInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PDef_FW_A
/*    */   extends MCDef
/*    */ {
/*    */   public MCContainerDef getCustomDef(String id) {
/* 18 */     if (id == null) {
/* 19 */       return null;
/*    */     }
/*    */     
/* 22 */     if (id.equals("FC.FCBAL1000.Srch03.UP.BLOCK0")) {
/* 23 */       return FC_FCBAL1000_Srch03_UP_BLOCK0();
/*    */     }
/* 25 */     if (id.equals("FC.FCBAL1000.Srch04.UP.BLOCK0")) {
/* 26 */       return FC_FCBAL1000_Srch04_UP_BLOCK0();
/*    */     }
/*    */ 
/*    */     
/* 30 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 36 */   static final MCOperationInfo FC_FCBAL1000_Srch03_INFO = new MCOperationInfo("FC", "FCBAL1000", "Srch03", "000000", new PDef());
/*    */ 
/*    */   
/*    */   public static MCContainerDef FC_FCBAL1000_Srch03_UP_BLOCK0() {
/* 40 */     return (MCContainerDef)new MCGeneralContainerDef(
/* 41 */         new MCItemDef[] {
/* 42 */           MCItemDef.create("CLASS", "CLASS"), 
/* 43 */           MCItemDef.create("METHOD", "METHOD")
/*    */         });
/*    */   }
/*    */ 
/*    */   
/* 48 */   static final MCOperationInfo FC_FCBAL1000_Srch04_INFO = new MCOperationInfo("FC", "FCBAL1000", "Srch04", "000000", new PDef());
/*    */ 
/*    */   
/*    */   public static MCContainerDef FC_FCBAL1000_Srch04_UP_BLOCK0() {
/* 52 */     return (MCContainerDef)new MCGeneralContainerDef(
/* 53 */         new MCItemDef[] {
/* 54 */           MCItemDef.create("CLASS", "CLASS"), 
/* 55 */           MCItemDef.create("METHOD", "METHOD")
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\listLogic\PDef_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */