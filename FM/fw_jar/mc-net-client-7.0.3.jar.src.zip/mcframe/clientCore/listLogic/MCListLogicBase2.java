/*     */ package mcframe.clientCore.listLogic;
/*     */ 
/*     */ import mcframe.clientCore.requester.MCCaller;
/*     */ import mcframe.commonCore.container.MCContainer;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCDataType;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MCListLogicBase2
/*     */ {
/*  25 */   private static final MCListLogicBase2 INSTANCE = new MCListLogicBase2();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCListLogicBase2 getInstance() {
/*  44 */     return INSTANCE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCCaller createListCaller(MCRow condition, String clazz, String method, MCList<MCRow> l, MCLLCallerSupplier cs) {
/*  61 */     MCParam p = new MCParam(PDef.FC_FCBAL1000_Srch03_INFO);
/*  62 */     setupTarget(p, clazz, method);
/*     */     
/*  64 */     if (cs != null) {
/*  65 */       return cs.createListLogicListCaller(p, condition);
/*     */     }
/*     */     
/*  68 */     setupLimitParam(p);
/*  69 */     setupCondition(p, condition);
/*  70 */     p.addDownBlock((MCContainer)l);
/*  71 */     return new MCCaller(p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCCaller createRowCaller(MCRow condition, String clazz, String method, MCRow r, MCLLCallerSupplier cs) {
/*  89 */     MCParam p = new MCParam(PDef.FC_FCBAL1000_Srch04_INFO);
/*  90 */     setupTarget(p, clazz, method);
/*  91 */     if (cs != null) {
/*  92 */       return cs.createListLogicRowCaller(p, condition);
/*     */     }
/*     */     
/*  95 */     setupLimitParam(p);
/*  96 */     setupCondition(p, condition);
/*  97 */     p.addDownBlock((MCContainer)r);
/*  98 */     return new MCCaller(p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setupTarget(MCParam p, String clazz, String method) {
/* 108 */     InfoR r = InfoR.create();
/* 109 */     r.CLASS(clazz);
/* 110 */     r.METHOD(method);
/* 111 */     p.addUpBlock((MCContainer)r);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setupCondition(MCParam p, MCRow condition) {
/* 122 */     String[] na = condition.getColumnPathArray();
/* 123 */     MCRow up0 = MCRow.create();
/* 124 */     MCRow up1 = MCRow.create();
/* 125 */     MCRow up2 = MCRow.create();
/*     */     
/* 127 */     for (int i = 0; i < na.length; i++) {
/* 128 */       String n = na[i];
/* 129 */       MCDataType mt = condition.getMeta(n).type();
/* 130 */       String mn = mt.name();
/* 131 */       String[] as = condition.getAlias(n);
/* 132 */       String a = n;
/* 133 */       String[] cp = MCRow.splitColumnPath(n);
/* 134 */       if (as.length > 0) {
/* 135 */         a = as[0];
/*     */       
/*     */       }
/* 138 */       else if (cp == null || cp.length > 1) {
/*     */         continue;
/*     */       } 
/* 141 */       up0.addStringColumn(a, a);
/* 142 */       up1.addStringColumn(a, mn);
/* 143 */       up2.addValueColumn(a, mt, condition.getValue(n)); continue;
/*     */     } 
/* 145 */     p.addUpBlock((MCContainer)up0);
/* 146 */     p.addUpBlock((MCContainer)up1);
/* 147 */     p.addUpBlock((MCContainer)up2);
/*     */   }
/*     */   
/*     */   private void setupLimitParam(MCParam p) {
/* 151 */     p.setLimitULSize(MCNumber.valueOf(-1));
/* 152 */     p.setLimitDLSize(MCNumber.valueOf(-1));
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\listLogic\MCListLogicBase2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */