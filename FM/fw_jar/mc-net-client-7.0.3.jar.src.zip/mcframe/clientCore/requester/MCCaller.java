/*     */ package mcframe.clientCore.requester;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import mcframe.clientCore.requester.async.MCAsyncCaller;
/*     */ import mcframe.clientCore.resource.MCConfig;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ import mcframe.clientCore.sys.MCSys;
/*     */ import mcframe.commonCore.container.MCContainer;
/*     */ import mcframe.commonCore.lang.MCBinary;
/*     */ import mcframe.commonCore.lang.MCTimestamp;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.notice.MCMessage;
/*     */ import mcframe.commonCore.notice.MCServerAppException;
/*     */ import mcframe.commonCore.notice.MCServerException;
/*     */ import mcframe.commonCore.param.MCContainerParam;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.commonCore.param.MCParamFileUtil;
/*     */ import mcframe.commonCore.param.MCParamHandler;
/*     */ import mcframe.commonCore.pio.MCDPReaderFactory;
/*     */ import mcframe.commonCore.pio.MCT2PBodyReader;
/*     */ import mcframe.commonCore.pio.MCT2PHeaderReader;
/*     */ import mcframe.commonCore.pio.util.MCDPFormat;
/*     */ import mcframe.commonCore.pio.util.MCDPToken;
/*     */ import mcframe.commonCore.pio.util.MCParseTypeUtil;
/*     */ import mcframe.commonCore.requester.MCControlRequester;
/*     */ import mcframe.commonCore.requester.MCParamHeaderUtil;
/*     */ import mcframe.commonCore.resource.ctrl.MCReadableResource;
/*     */ import mcframe.commonCore.sys.MCClientOperation;
/*     */ import mcframe.commonCore.sys.MCFactory;
/*     */ import mcframe.commonCore.util.MCFileUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCCaller
/*     */ {
/*     */   private final MCParam param;
/*     */   private boolean _autotest;
/*     */   private Object _bridgeCaller;
/*     */   
/*     */   public MCCaller(MCParam p) {
/*  62 */     if (p == null) {
/*  63 */       throw new MCException(Core_Msg_FW_A.FCBGC0034, new Object[0]);
/*     */     }
/*  65 */     this._autotest = Boolean.valueOf(MCSys.env.getVMEnv("autotest")).booleanValue();
/*  66 */     this._bridgeCaller = MCConst.plugin.create(Object.class, "autotest.bridge.callerClass");
/*  67 */     this.param = p;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCParam param() {
/*  78 */     return this.param;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setClientOperation(MCClientOperation ope) {
/*  90 */     this.param.setOperationHis(ope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void exec() {
/* 111 */     call();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void call() {
/* 133 */     call(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void call(MCParamHandler handler) {
/* 156 */     MCParam param = param();
/* 157 */     if (isAsync()) {
/*     */ 
/*     */       
/* 160 */       MCAsyncCaller mCAsyncCaller = getScrContainer().isEmpty() ? 
/* 161 */         new MCAsyncCaller(param, handler, getAsyncPushMsg()) : 
/* 162 */         new MCAsyncCaller(param, handler, getAsyncPushMsg(), getScrContainer());
/*     */       
/* 164 */       mCAsyncCaller.exec();
/*     */     } else {
/*     */       
/* 167 */       callImpl(handler);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void callImpl(MCParamHandler handler) {
/* 173 */     setHdrInfo(this.param);
/*     */ 
/*     */     
/* 176 */     _execLogicRequester();
/*     */ 
/*     */     
/* 179 */     syncMCSysTime(this.param);
/*     */ 
/*     */     
/* 182 */     handleErr(this.param, handler);
/* 183 */     throwErr(this.param);
/* 184 */     setRequestTime(this.param);
/* 185 */     setCommitTime(this.param);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void request() {
/* 201 */     MCControlRequester requester = MCRequesterFactory.createRequester();
/* 202 */     requester.request(param());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void _execLogicRequester() {
/* 217 */     String START_LOG_ID = Core_Msg_FW_A.FCBGC0201;
/* 218 */     String END_LOG_ID = Core_Msg_FW_A.FCBGC0202;
/*     */     
/* 220 */     MCLog.write(new MCMessage(START_LOG_ID, new Object[0]));
/* 221 */     request();
/* 222 */     MCLog.write(new MCMessage(END_LOG_ID, new Object[0]));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void syncMCSysTime(MCParam p) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setRequestTime(MCParam p) {
/* 251 */     setRequestTime(p, p.getRequestTime());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setCommitTime(MCParam p) {
/* 262 */     setCommitTime(p, p.getCommitTime());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void setRequestTime(MCParam p, MCTimestamp d) {
/* 274 */     MCContainerParam c = p.getContainerParam();
/* 275 */     if (c != null) {
/* 276 */       for (MCContainer t : c.down()) {
/* 277 */         t.setRefTime(d);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void setCommitTime(MCParam p, MCTimestamp d) {
/* 291 */     MCContainerParam c = p.getContainerParam();
/* 292 */     if (c != null) {
/* 293 */       for (MCContainer t : c.up()) {
/* 294 */         t.setRefTime(d);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void handleErr(MCParam p, MCParamHandler h) {
/* 311 */     if (h == null || p.getExceptionParam().isEmpty()) {
/*     */       return;
/*     */     }
/*     */     
/* 315 */     h.handle(p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void throwErr(MCParam p) {
/*     */     MCServerException mCServerException;
/* 328 */     if (p.getExceptionParam().isEmpty()) {
/*     */       return;
/*     */     }
/* 331 */     MCException tar = p.getExceptionParam().getException();
/*     */     
/* 333 */     if (tar instanceof mcframe.commonCore.notice.MCAppException) {
/* 334 */       MCServerAppException mCServerAppException = new MCServerAppException(tar.getID(), new Object[0]);
/*     */     } else {
/*     */       
/* 337 */       mCServerException = new MCServerException(tar.getID(), new Object[0]);
/*     */     } 
/*     */     
/* 340 */     mCServerException.setBind((Object[])tar.getBindArray());
/* 341 */     mCServerException.setCauseMessageList(tar.getCauseMessageList());
/* 342 */     mCServerException.setCauseRow(tar.getCauseRow(), tar.getCauseColumn());
/*     */     
/* 344 */     throw mCServerException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void setHdrInfo(MCParam p) {
/* 357 */     String ERR_ID = Core_Msg_FW_A.FCBGC0032;
/* 358 */     String LOG_ID = Core_Msg_FW_A.FCBGC0200;
/*     */ 
/*     */     
/* 361 */     MCLog.write(LOG_ID, new Object[0]);
/*     */     try {
/* 363 */       MCParamHeaderUtil.toUpHeader(p, MCSys.user.clientID(), MCSys.nextRequestNum(), 
/* 364 */           MCConfig.client.getNumber("net.response.limitSize"));
/*     */     }
/* 366 */     catch (MCException e) {
/* 367 */       throw new MCException(e, ERR_ID, new Object[0]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean _async = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 383 */   private String _async_push_msg = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 390 */   private List<File> _scr_container = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isAsync() {
/* 400 */     if (this._autotest) {
/* 401 */       return isAsyncAutotest();
/*     */     }
/* 403 */     return this._async;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAsync(boolean async) {
/* 418 */     this._async = async;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getAsyncPushMsg() {
/* 429 */     return this._async_push_msg;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAsyncPushMsg(String async_push_msg) {
/* 440 */     this._async_push_msg = async_push_msg;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<File> getScrContainer() {
/* 450 */     return this._scr_container;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<File> createScrContainerFiles(int containerCount) {
/* 463 */     List<File> result = new ArrayList<>();
/* 464 */     for (int i = 0; i < containerCount; i++) {
/* 465 */       result.add(MCParamFileUtil.getScrContainerFile(this.param, i));
/*     */     }
/* 467 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setScrContainers(List<File> scr_containers) {
/* 478 */     this._scr_container = scr_containers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isOperationMightBeSuccess(MCException e) {
/* 497 */     if (e == null) {
/* 498 */       return false;
/*     */     }
/* 500 */     String id = e.getID();
/*     */     
/* 502 */     if (Core_Msg_FW_A.FCBGC1102.equals(id)) {
/* 503 */       return true;
/*     */     }
/*     */     
/* 506 */     if (Core_Msg_FW_A.FCBGC0051.equals(id)) {
/* 507 */       return true;
/*     */     }
/* 509 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setParamData(MCParam param, MCBinary up, MCBinary down) {
/* 534 */     if (param == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 539 */     if (up != null) {
/*     */       
/* 541 */       String uptext = downloadResultText(up);
/* 542 */       MCDPToken tkn = MCDPToken.create(uptext);
/* 543 */       MCDPFormat fmt = tkn.getFormat();
/* 544 */       parseParam(tkn, param, MCDPReaderFactory.upHeaderToParam(fmt), 
/* 545 */           MCDPReaderFactory.upBodyToParam(fmt, 
/* 546 */             MCParseTypeUtil.getParseType(param)));
/*     */     } 
/*     */     
/* 549 */     if (down != null) {
/*     */       
/* 551 */       String downtext = downloadResultText(down);
/* 552 */       MCDPToken tkn = MCDPToken.create(downtext);
/* 553 */       MCDPFormat fmt = tkn.getFormat();
/* 554 */       parseParam(tkn, param, MCDPReaderFactory.downHeaderToParam(fmt), 
/* 555 */           MCDPReaderFactory.downBodyToParam(fmt, 
/* 556 */             MCParseTypeUtil.getParseType(param)));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setParamMessage(MCParam param, MCBinary down) {
/* 583 */     if (param == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 588 */     if (down != null) {
/*     */       
/* 590 */       String downtext = downloadResultText(down);
/* 591 */       MCDPToken tkn = MCDPToken.create(downtext);
/* 592 */       MCDPFormat fmt = tkn.getFormat();
/* 593 */       parseParam(tkn, param, MCDPReaderFactory.downHeaderToParam(fmt), 
/* 594 */           (MCT2PBodyReader)MCDPReaderFactory.downMessageToParam(fmt));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String downloadResultText(MCBinary bin) {
/* 611 */     if (bin == null) {
/* 612 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 617 */     MCDownloader dl = new MCDownloader(bin);
/* 618 */     File file = dl.exec(null, null);
/*     */ 
/*     */     
/* 621 */     checkParamFileSize(file);
/*     */ 
/*     */     
/* 624 */     StringBuilder sb = new StringBuilder();
/* 625 */     MCFileUtil.readText(sb, file, "UTF-8");
/* 626 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void checkParamFileSize(File file) {
/* 643 */     long limit = MCConfig.getByteValue((MCReadableResource)MCConfig.client, "net.response.limitByte");
/*     */     
/* 645 */     if (limit > 0L) {
/* 646 */       long size = file.length();
/* 647 */       if (size > limit)
/*     */       {
/* 649 */         throw new MCException(Core_Msg_FW_A.FCBGC1003, new Object[] { Long.valueOf(limit), Long.valueOf(size) });
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void parseParam(MCDPToken tkn, MCParam param, MCT2PHeaderReader hr, MCT2PBodyReader br) {
/* 668 */     hr.parse(tkn, param);
/* 669 */     br.parse(tkn, param);
/*     */   }
/*     */   
/*     */   private boolean isAsyncAutotest() {
/* 673 */     if (!this._autotest) return this._async; 
/* 674 */     if (this._bridgeCaller != null) {
/* 675 */       Class[] argCls = { MCCaller.class };
/* 676 */       Object[] argVal = { this };
/* 677 */       boolean rtn = ((Boolean)MCFactory.invoke(this._bridgeCaller, "isTestActRecCaller", argCls, argVal)).booleanValue();
/* 678 */       if (rtn) {
/* 679 */         return false;
/*     */       }
/* 681 */       return this._async;
/*     */     } 
/*     */     
/* 684 */     return this._async;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\requester\MCCaller.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */