/*     */ package mcframe.clientCore.requester.paging;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.clientCore.container.MCKeyList;
/*     */ import mcframe.commonCore.container.MCExtMap;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class PageR_FW_A
/*     */   extends MCConstRow
/*     */ {
/*     */   public static final String $tar_blk = "tar_blk";
/*     */   public static final String $page_size = "page_size";
/*     */   public static final String $page_size_rtn = "page_size_rtn";
/*     */   public static final String $page_size_bef = "page_size_bef";
/*     */   public static final String $total = "total";
/*     */   public static final String $cache_id = "cache_id";
/*     */   public static final String $from = "from";
/*  38 */   public static final MCMeta tar_blk_META = createNumberMeta("tar_blk");
/*  39 */   public static final MCMeta page_size_META = createNumberMeta("page_size");
/*  40 */   public static final MCMeta page_size_rtn_META = createNumberMeta("page_size_rtn");
/*  41 */   public static final MCMeta page_size_bef_META = createNumberMeta("page_size_bef");
/*  42 */   public static final MCMeta total_META = createNumberMeta("total");
/*  43 */   public static final MCMeta cache_id_META = createStringMeta("cache_id");
/*  44 */   public static final MCMeta from_META = createNumberMeta("from");
/*     */   
/*  46 */   protected static final MCRow.ConstMetaList<PageR> constMetas = new MCRow.ConstMetaList(
/*  47 */       MCConstRow.constMetas, 
/*  48 */       new MCMeta[] {
/*  49 */         tar_blk_META, 
/*  50 */         page_size_META, 
/*  51 */         page_size_rtn_META, 
/*  52 */         page_size_bef_META, 
/*  53 */         total_META, 
/*  54 */         cache_id_META, 
/*  55 */         from_META
/*     */       },
/*  57 */       new String[][] { {}, {} });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   protected static final MCKeyList KEYS = new MCKeyList(
/*  69 */       null, 
/*  70 */       new String[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   protected static final MCExtMap EXTMAP = new MCExtMap(
/*  79 */       null, new MCExtMap.Entry[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] colnames() {
/*  91 */     return constMetas.toNameArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMeta[] colmetas() {
/* 103 */     return constMetas.toMetaArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   private static final int offset = constMetas.offset();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCKeyList getKeys() {
/* 115 */     return KEYS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getExtMap(String aGroup) {
/* 122 */     if (aGroup == null) return null; 
/* 123 */     return (Map<String, String>)EXTMAP.get(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCKeyList getKeys(String aGroup) {
/* 130 */     if (aGroup == null) return null; 
/* 131 */     return new MCKeyList(EXTMAP.getKeyList(aGroup));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExtGroups() {
/* 138 */     Set<String> ret = EXTMAP.keySet();
/* 139 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PageR_FW_A(MCRow.ConstMetaList<? extends PageR> metas) {
/* 146 */     super(metas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PageR clone() {
/* 153 */     return (PageR)super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PageR createInstance() {
/* 160 */     return (PageR)super.createInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PageR getValues(String... names) {
/* 167 */     return (PageR)super.getValues(names);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MCNumber tar_blk() {
/* 173 */     return getConstNumber(offset + 0, "tar_blk");
/*     */   }
/*     */   
/*     */   public void tar_blk(MCNumber value) {
/* 177 */     setConstNumber(offset + 0, "tar_blk", value);
/*     */   }
/*     */   
/*     */   public void tar_blk(int value) {
/* 181 */     setConstNumber(offset + 0, "tar_blk", value);
/*     */   }
/*     */   
/*     */   public void tar_blk(long value) {
/* 185 */     setConstNumber(offset + 0, "tar_blk", value);
/*     */   }
/*     */   
/*     */   public void tar_blk(float value) {
/* 189 */     setConstNumber(offset + 0, "tar_blk", value);
/*     */   }
/*     */   
/*     */   public void tar_blk(double value) {
/* 193 */     setConstNumber(offset + 0, "tar_blk", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCNumber page_size() {
/* 198 */     return getConstNumber(offset + 1, "page_size");
/*     */   }
/*     */   
/*     */   public void page_size(MCNumber value) {
/* 202 */     setConstNumber(offset + 1, "page_size", value);
/*     */   }
/*     */   
/*     */   public void page_size(int value) {
/* 206 */     setConstNumber(offset + 1, "page_size", value);
/*     */   }
/*     */   
/*     */   public void page_size(long value) {
/* 210 */     setConstNumber(offset + 1, "page_size", value);
/*     */   }
/*     */   
/*     */   public void page_size(float value) {
/* 214 */     setConstNumber(offset + 1, "page_size", value);
/*     */   }
/*     */   
/*     */   public void page_size(double value) {
/* 218 */     setConstNumber(offset + 1, "page_size", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCNumber page_size_rtn() {
/* 223 */     return getConstNumber(offset + 2, "page_size_rtn");
/*     */   }
/*     */   
/*     */   public void page_size_rtn(MCNumber value) {
/* 227 */     setConstNumber(offset + 2, "page_size_rtn", value);
/*     */   }
/*     */   
/*     */   public void page_size_rtn(int value) {
/* 231 */     setConstNumber(offset + 2, "page_size_rtn", value);
/*     */   }
/*     */   
/*     */   public void page_size_rtn(long value) {
/* 235 */     setConstNumber(offset + 2, "page_size_rtn", value);
/*     */   }
/*     */   
/*     */   public void page_size_rtn(float value) {
/* 239 */     setConstNumber(offset + 2, "page_size_rtn", value);
/*     */   }
/*     */   
/*     */   public void page_size_rtn(double value) {
/* 243 */     setConstNumber(offset + 2, "page_size_rtn", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCNumber page_size_bef() {
/* 248 */     return getConstNumber(offset + 3, "page_size_bef");
/*     */   }
/*     */   
/*     */   public void page_size_bef(MCNumber value) {
/* 252 */     setConstNumber(offset + 3, "page_size_bef", value);
/*     */   }
/*     */   
/*     */   public void page_size_bef(int value) {
/* 256 */     setConstNumber(offset + 3, "page_size_bef", value);
/*     */   }
/*     */   
/*     */   public void page_size_bef(long value) {
/* 260 */     setConstNumber(offset + 3, "page_size_bef", value);
/*     */   }
/*     */   
/*     */   public void page_size_bef(float value) {
/* 264 */     setConstNumber(offset + 3, "page_size_bef", value);
/*     */   }
/*     */   
/*     */   public void page_size_bef(double value) {
/* 268 */     setConstNumber(offset + 3, "page_size_bef", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCNumber total() {
/* 273 */     return getConstNumber(offset + 4, "total");
/*     */   }
/*     */   
/*     */   public void total(MCNumber value) {
/* 277 */     setConstNumber(offset + 4, "total", value);
/*     */   }
/*     */   
/*     */   public void total(int value) {
/* 281 */     setConstNumber(offset + 4, "total", value);
/*     */   }
/*     */   
/*     */   public void total(long value) {
/* 285 */     setConstNumber(offset + 4, "total", value);
/*     */   }
/*     */   
/*     */   public void total(float value) {
/* 289 */     setConstNumber(offset + 4, "total", value);
/*     */   }
/*     */   
/*     */   public void total(double value) {
/* 293 */     setConstNumber(offset + 4, "total", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String cache_id() {
/* 298 */     return getConstString(offset + 5, "cache_id");
/*     */   }
/*     */   
/*     */   public void cache_id(String value) {
/* 302 */     setConstString(offset + 5, "cache_id", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCNumber from() {
/* 307 */     return getConstNumber(offset + 6, "from");
/*     */   }
/*     */   
/*     */   public void from(MCNumber value) {
/* 311 */     setConstNumber(offset + 6, "from", value);
/*     */   }
/*     */   
/*     */   public void from(int value) {
/* 315 */     setConstNumber(offset + 6, "from", value);
/*     */   }
/*     */   
/*     */   public void from(long value) {
/* 319 */     setConstNumber(offset + 6, "from", value);
/*     */   }
/*     */   
/*     */   public void from(float value) {
/* 323 */     setConstNumber(offset + 6, "from", value);
/*     */   }
/*     */   
/*     */   public void from(double value) {
/* 327 */     setConstNumber(offset + 6, "from", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString(String name) {
/* 332 */     if ("cache_id".equalsIgnoreCase(name)) {
/* 333 */       return cache_id();
/*     */     }
/* 335 */     return super.getString(name);
/*     */   }
/*     */   public MCNumber getNumber(String name) {
/* 338 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 339 */       return tar_blk();
/*     */     }
/* 341 */     if ("page_size".equalsIgnoreCase(name)) {
/* 342 */       return page_size();
/*     */     }
/* 344 */     if ("page_size_rtn".equalsIgnoreCase(name)) {
/* 345 */       return page_size_rtn();
/*     */     }
/* 347 */     if ("page_size_bef".equalsIgnoreCase(name)) {
/* 348 */       return page_size_bef();
/*     */     }
/* 350 */     if ("total".equalsIgnoreCase(name)) {
/* 351 */       return total();
/*     */     }
/* 353 */     if ("from".equalsIgnoreCase(name)) {
/* 354 */       return from();
/*     */     }
/* 356 */     return super.getNumber(name);
/*     */   }
/*     */   
/*     */   public String getStringNE(String name) {
/* 360 */     if ("cache_id".equalsIgnoreCase(name)) {
/* 361 */       return cache_id();
/*     */     }
/* 363 */     return super.getStringNE(name);
/*     */   }
/*     */   public MCNumber getNumberNE(String name) {
/* 366 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 367 */       return tar_blk();
/*     */     }
/* 369 */     if ("page_size".equalsIgnoreCase(name)) {
/* 370 */       return page_size();
/*     */     }
/* 372 */     if ("page_size_rtn".equalsIgnoreCase(name)) {
/* 373 */       return page_size_rtn();
/*     */     }
/* 375 */     if ("page_size_bef".equalsIgnoreCase(name)) {
/* 376 */       return page_size_bef();
/*     */     }
/* 378 */     if ("total".equalsIgnoreCase(name)) {
/* 379 */       return total();
/*     */     }
/* 381 */     if ("from".equalsIgnoreCase(name)) {
/* 382 */       return from();
/*     */     }
/* 384 */     return super.getNumberNE(name);
/*     */   }
/*     */   
/*     */   public void setString(String name, String value) {
/* 388 */     if ("cache_id".equalsIgnoreCase(name)) {
/* 389 */       cache_id(value);
/*     */       return;
/*     */     } 
/* 392 */     super.setString(name, value);
/*     */   }
/*     */   public void setNumber(String name, MCNumber value) {
/* 395 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 396 */       tar_blk(value);
/*     */       return;
/*     */     } 
/* 399 */     if ("page_size".equalsIgnoreCase(name)) {
/* 400 */       page_size(value);
/*     */       return;
/*     */     } 
/* 403 */     if ("page_size_rtn".equalsIgnoreCase(name)) {
/* 404 */       page_size_rtn(value);
/*     */       return;
/*     */     } 
/* 407 */     if ("page_size_bef".equalsIgnoreCase(name)) {
/* 408 */       page_size_bef(value);
/*     */       return;
/*     */     } 
/* 411 */     if ("total".equalsIgnoreCase(name)) {
/* 412 */       total(value);
/*     */       return;
/*     */     } 
/* 415 */     if ("from".equalsIgnoreCase(name)) {
/* 416 */       from(value);
/*     */       return;
/*     */     } 
/* 419 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, int value) {
/* 422 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 423 */       tar_blk(value);
/*     */       return;
/*     */     } 
/* 426 */     if ("page_size".equalsIgnoreCase(name)) {
/* 427 */       page_size(value);
/*     */       return;
/*     */     } 
/* 430 */     if ("page_size_rtn".equalsIgnoreCase(name)) {
/* 431 */       page_size_rtn(value);
/*     */       return;
/*     */     } 
/* 434 */     if ("page_size_bef".equalsIgnoreCase(name)) {
/* 435 */       page_size_bef(value);
/*     */       return;
/*     */     } 
/* 438 */     if ("total".equalsIgnoreCase(name)) {
/* 439 */       total(value);
/*     */       return;
/*     */     } 
/* 442 */     if ("from".equalsIgnoreCase(name)) {
/* 443 */       from(value);
/*     */       return;
/*     */     } 
/* 446 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, long value) {
/* 449 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 450 */       tar_blk(value);
/*     */       return;
/*     */     } 
/* 453 */     if ("page_size".equalsIgnoreCase(name)) {
/* 454 */       page_size(value);
/*     */       return;
/*     */     } 
/* 457 */     if ("page_size_rtn".equalsIgnoreCase(name)) {
/* 458 */       page_size_rtn(value);
/*     */       return;
/*     */     } 
/* 461 */     if ("page_size_bef".equalsIgnoreCase(name)) {
/* 462 */       page_size_bef(value);
/*     */       return;
/*     */     } 
/* 465 */     if ("total".equalsIgnoreCase(name)) {
/* 466 */       total(value);
/*     */       return;
/*     */     } 
/* 469 */     if ("from".equalsIgnoreCase(name)) {
/* 470 */       from(value);
/*     */       return;
/*     */     } 
/* 473 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, float value) {
/* 476 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 477 */       tar_blk(value);
/*     */       return;
/*     */     } 
/* 480 */     if ("page_size".equalsIgnoreCase(name)) {
/* 481 */       page_size(value);
/*     */       return;
/*     */     } 
/* 484 */     if ("page_size_rtn".equalsIgnoreCase(name)) {
/* 485 */       page_size_rtn(value);
/*     */       return;
/*     */     } 
/* 488 */     if ("page_size_bef".equalsIgnoreCase(name)) {
/* 489 */       page_size_bef(value);
/*     */       return;
/*     */     } 
/* 492 */     if ("total".equalsIgnoreCase(name)) {
/* 493 */       total(value);
/*     */       return;
/*     */     } 
/* 496 */     if ("from".equalsIgnoreCase(name)) {
/* 497 */       from(value);
/*     */       return;
/*     */     } 
/* 500 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, double value) {
/* 503 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 504 */       tar_blk(value);
/*     */       return;
/*     */     } 
/* 507 */     if ("page_size".equalsIgnoreCase(name)) {
/* 508 */       page_size(value);
/*     */       return;
/*     */     } 
/* 511 */     if ("page_size_rtn".equalsIgnoreCase(name)) {
/* 512 */       page_size_rtn(value);
/*     */       return;
/*     */     } 
/* 515 */     if ("page_size_bef".equalsIgnoreCase(name)) {
/* 516 */       page_size_bef(value);
/*     */       return;
/*     */     } 
/* 519 */     if ("total".equalsIgnoreCase(name)) {
/* 520 */       total(value);
/*     */       return;
/*     */     } 
/* 523 */     if ("from".equalsIgnoreCase(name)) {
/* 524 */       from(value);
/*     */       return;
/*     */     } 
/* 527 */     super.setNumber(name, value);
/*     */   }
/*     */   
/*     */   public void setStringNE(String name, String value) {
/* 531 */     if ("cache_id".equalsIgnoreCase(name)) {
/* 532 */       cache_id(value);
/*     */       return;
/*     */     } 
/* 535 */     super.setStringNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, MCNumber value) {
/* 538 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 539 */       tar_blk(value);
/*     */       return;
/*     */     } 
/* 542 */     if ("page_size".equalsIgnoreCase(name)) {
/* 543 */       page_size(value);
/*     */       return;
/*     */     } 
/* 546 */     if ("page_size_rtn".equalsIgnoreCase(name)) {
/* 547 */       page_size_rtn(value);
/*     */       return;
/*     */     } 
/* 550 */     if ("page_size_bef".equalsIgnoreCase(name)) {
/* 551 */       page_size_bef(value);
/*     */       return;
/*     */     } 
/* 554 */     if ("total".equalsIgnoreCase(name)) {
/* 555 */       total(value);
/*     */       return;
/*     */     } 
/* 558 */     if ("from".equalsIgnoreCase(name)) {
/* 559 */       from(value);
/*     */       return;
/*     */     } 
/* 562 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, int value) {
/* 565 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 566 */       tar_blk(value);
/*     */       return;
/*     */     } 
/* 569 */     if ("page_size".equalsIgnoreCase(name)) {
/* 570 */       page_size(value);
/*     */       return;
/*     */     } 
/* 573 */     if ("page_size_rtn".equalsIgnoreCase(name)) {
/* 574 */       page_size_rtn(value);
/*     */       return;
/*     */     } 
/* 577 */     if ("page_size_bef".equalsIgnoreCase(name)) {
/* 578 */       page_size_bef(value);
/*     */       return;
/*     */     } 
/* 581 */     if ("total".equalsIgnoreCase(name)) {
/* 582 */       total(value);
/*     */       return;
/*     */     } 
/* 585 */     if ("from".equalsIgnoreCase(name)) {
/* 586 */       from(value);
/*     */       return;
/*     */     } 
/* 589 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, long value) {
/* 592 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 593 */       tar_blk(value);
/*     */       return;
/*     */     } 
/* 596 */     if ("page_size".equalsIgnoreCase(name)) {
/* 597 */       page_size(value);
/*     */       return;
/*     */     } 
/* 600 */     if ("page_size_rtn".equalsIgnoreCase(name)) {
/* 601 */       page_size_rtn(value);
/*     */       return;
/*     */     } 
/* 604 */     if ("page_size_bef".equalsIgnoreCase(name)) {
/* 605 */       page_size_bef(value);
/*     */       return;
/*     */     } 
/* 608 */     if ("total".equalsIgnoreCase(name)) {
/* 609 */       total(value);
/*     */       return;
/*     */     } 
/* 612 */     if ("from".equalsIgnoreCase(name)) {
/* 613 */       from(value);
/*     */       return;
/*     */     } 
/* 616 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, float value) {
/* 619 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 620 */       tar_blk(value);
/*     */       return;
/*     */     } 
/* 623 */     if ("page_size".equalsIgnoreCase(name)) {
/* 624 */       page_size(value);
/*     */       return;
/*     */     } 
/* 627 */     if ("page_size_rtn".equalsIgnoreCase(name)) {
/* 628 */       page_size_rtn(value);
/*     */       return;
/*     */     } 
/* 631 */     if ("page_size_bef".equalsIgnoreCase(name)) {
/* 632 */       page_size_bef(value);
/*     */       return;
/*     */     } 
/* 635 */     if ("total".equalsIgnoreCase(name)) {
/* 636 */       total(value);
/*     */       return;
/*     */     } 
/* 639 */     if ("from".equalsIgnoreCase(name)) {
/* 640 */       from(value);
/*     */       return;
/*     */     } 
/* 643 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, double value) {
/* 646 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 647 */       tar_blk(value);
/*     */       return;
/*     */     } 
/* 650 */     if ("page_size".equalsIgnoreCase(name)) {
/* 651 */       page_size(value);
/*     */       return;
/*     */     } 
/* 654 */     if ("page_size_rtn".equalsIgnoreCase(name)) {
/* 655 */       page_size_rtn(value);
/*     */       return;
/*     */     } 
/* 658 */     if ("page_size_bef".equalsIgnoreCase(name)) {
/* 659 */       page_size_bef(value);
/*     */       return;
/*     */     } 
/* 662 */     if ("total".equalsIgnoreCase(name)) {
/* 663 */       total(value);
/*     */       return;
/*     */     } 
/* 666 */     if ("from".equalsIgnoreCase(name)) {
/* 667 */       from(value);
/*     */       return;
/*     */     } 
/* 670 */     super.setNumberNE(name, value);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\requester\paging\PageR_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */