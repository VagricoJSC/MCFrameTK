/*     */ package mcframe.clientCore.requester.paging;
/*     */ 
/*     */ import mcframe.commonCore.param.MCContainerDef;
/*     */ import mcframe.commonCore.param.MCDef;
/*     */ import mcframe.commonCore.param.MCGeneralContainerDef;
/*     */ import mcframe.commonCore.param.MCItemDef;
/*     */ import mcframe.commonCore.param.MCOperationInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PDef_FW_A
/*     */   extends MCDef
/*     */ {
/*     */   public MCContainerDef getCustomDef(String id) {
/*  18 */     if (id == null) {
/*  19 */       return null;
/*     */     }
/*     */     
/*  22 */     if (id.equals("FC.FCBGL2000.CallPaging.UP.BLOCK0")) {
/*  23 */       return FC_FCBGL2000_CallPaging_UP_BLOCK0();
/*     */     }
/*  25 */     if (id.equals("FC.FCBGL2000.CallPaging.UP.BLOCK1")) {
/*  26 */       return FC_FCBGL2000_CallPaging_UP_BLOCK1();
/*     */     }
/*  28 */     if (id.equals("FC.FCBGL2000.CallPaging.UP.BLOCK2")) {
/*  29 */       return FC_FCBGL2000_CallPaging_UP_BLOCK2();
/*     */     }
/*  31 */     if (id.equals("FC.FCBGL2000.CallPaging.DOWN.BLOCK0")) {
/*  32 */       return FC_FCBGL2000_CallPaging_DOWN_BLOCK0();
/*     */     }
/*  34 */     if (id.equals("FC.FCBGL2000.CallPaging.DOWN.BLOCK1")) {
/*  35 */       return FC_FCBGL2000_CallPaging_DOWN_BLOCK1();
/*     */     }
/*  37 */     if (id.equals("FC.FCBGL2000.GetPage.UP.BLOCK0")) {
/*  38 */       return FC_FCBGL2000_GetPage_UP_BLOCK0();
/*     */     }
/*  40 */     if (id.equals("FC.FCBGL2000.GetPage.UP.BLOCK1")) {
/*  41 */       return FC_FCBGL2000_GetPage_UP_BLOCK1();
/*     */     }
/*  43 */     if (id.equals("FC.FCBGL2000.GetPage.DOWN.BLOCK0")) {
/*  44 */       return FC_FCBGL2000_GetPage_DOWN_BLOCK0();
/*     */     }
/*  46 */     if (id.equals("FC.FCBGL2000.CallBufferPaging.UP.BLOCK0")) {
/*  47 */       return FC_FCBGL2000_CallBufferPaging_UP_BLOCK0();
/*     */     }
/*  49 */     if (id.equals("FC.FCBGL2000.CallBufferPaging.UP.BLOCK1")) {
/*  50 */       return FC_FCBGL2000_CallBufferPaging_UP_BLOCK1();
/*     */     }
/*  52 */     if (id.equals("FC.FCBGL2000.CallBufferPaging.UP.BLOCK2")) {
/*  53 */       return FC_FCBGL2000_CallBufferPaging_UP_BLOCK2();
/*     */     }
/*  55 */     if (id.equals("FC.FCBGL2000.CallBufferPaging.DOWN.BLOCK0")) {
/*  56 */       return FC_FCBGL2000_CallBufferPaging_DOWN_BLOCK0();
/*     */     }
/*  58 */     if (id.equals("FC.FCBGL2000.CallBufferPaging.DOWN.BLOCK1")) {
/*  59 */       return FC_FCBGL2000_CallBufferPaging_DOWN_BLOCK1();
/*     */     }
/*     */ 
/*     */     
/*  63 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   static final MCOperationInfo FC_FCBGL2000_CallPaging_INFO = new MCOperationInfo("FC", "FCBGL2000", "CallPaging", "000000", new PDef());
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL2000_CallPaging_UP_BLOCK0() {
/*  73 */     return (MCContainerDef)new MCGeneralContainerDef(
/*  74 */         new MCItemDef[] {
/*  75 */           MCItemDef.create("denbun", "denbun")
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL2000_CallPaging_UP_BLOCK1() {
/*  82 */     return (MCContainerDef)new MCGeneralContainerDef(
/*  83 */         new MCItemDef[] {
/*  84 */           MCItemDef.create("tar_blk", "tar_blk"), 
/*  85 */           MCItemDef.create("page_size", "page_size")
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL2000_CallPaging_UP_BLOCK2() {
/*  92 */     return (MCContainerDef)new MCGeneralContainerDef(
/*  93 */         new MCItemDef[] {
/*  94 */           MCItemDef.create("tar_blk", "tar_blk"), 
/*  95 */           MCItemDef.create("sort_no", "sort_no"), 
/*  96 */           MCItemDef.create("nm", "nm"), 
/*  97 */           MCItemDef.create("sort_typ", "sort_typ")
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL2000_CallPaging_DOWN_BLOCK0() {
/* 105 */     return (MCContainerDef)new MCGeneralContainerDef(
/* 106 */         new MCItemDef[] {
/* 107 */           MCItemDef.create("denbun", "denbun")
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL2000_CallPaging_DOWN_BLOCK1() {
/* 113 */     return (MCContainerDef)new MCGeneralContainerDef(
/* 114 */         new MCItemDef[] {
/* 115 */           MCItemDef.create("tar_blk", "tar_blk"), 
/* 116 */           MCItemDef.create("page_size", "page_size"), 
/* 117 */           MCItemDef.create("total", "total"), 
/* 118 */           MCItemDef.create("cache_id", "cache_id")
/*     */         });
/*     */   }
/*     */ 
/*     */   
/* 123 */   static final MCOperationInfo FC_FCBGL2000_GetPage_INFO = new MCOperationInfo("FC", "FCBGL2000", "GetPage", "000000", new PDef());
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL2000_GetPage_UP_BLOCK0() {
/* 127 */     return (MCContainerDef)new MCGeneralContainerDef(
/* 128 */         new MCItemDef[] {
/* 129 */           MCItemDef.create("denbun", "denbun")
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL2000_GetPage_UP_BLOCK1() {
/* 136 */     return (MCContainerDef)new MCGeneralContainerDef(
/* 137 */         new MCItemDef[] {
/* 138 */           MCItemDef.create("tar_blk", "tar_blk"), 
/* 139 */           MCItemDef.create("page_size", "page_size"), 
/* 140 */           MCItemDef.create("from", "from"), 
/* 141 */           MCItemDef.create("cache_id", "cache_id")
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL2000_GetPage_DOWN_BLOCK0() {
/* 149 */     return (MCContainerDef)new MCGeneralContainerDef(
/* 150 */         new MCItemDef[] {
/* 151 */           MCItemDef.create("denbun", "denbun")
/*     */         });
/*     */   }
/*     */ 
/*     */   
/* 156 */   static final MCOperationInfo FC_FCBGL2000_CallBufferPaging_INFO = new MCOperationInfo("FC", "FCBGL2000", "CallBufferPaging", "000000", new PDef());
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL2000_CallBufferPaging_UP_BLOCK0() {
/* 160 */     return (MCContainerDef)new MCGeneralContainerDef(
/* 161 */         new MCItemDef[] {
/* 162 */           MCItemDef.create("denbun", "denbun")
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL2000_CallBufferPaging_UP_BLOCK1() {
/* 169 */     return (MCContainerDef)new MCGeneralContainerDef(
/* 170 */         new MCItemDef[] {
/* 171 */           MCItemDef.create("tar_blk", "tar_blk"), 
/* 172 */           MCItemDef.create("page_size", "page_size")
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL2000_CallBufferPaging_UP_BLOCK2() {
/* 179 */     return (MCContainerDef)new MCGeneralContainerDef(
/* 180 */         new MCItemDef[] {
/* 181 */           MCItemDef.create("tar_blk", "tar_blk"), 
/* 182 */           MCItemDef.create("sort_no", "sort_no"), 
/* 183 */           MCItemDef.create("nm", "nm"), 
/* 184 */           MCItemDef.create("sort_typ", "sort_typ")
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL2000_CallBufferPaging_DOWN_BLOCK0() {
/* 192 */     return (MCContainerDef)new MCGeneralContainerDef(
/* 193 */         new MCItemDef[] {
/* 194 */           MCItemDef.create("denbun", "denbun")
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL2000_CallBufferPaging_DOWN_BLOCK1() {
/* 200 */     return (MCContainerDef)new MCGeneralContainerDef(
/* 201 */         new MCItemDef[] {
/* 202 */           MCItemDef.create("tar_blk", "tar_blk"), 
/* 203 */           MCItemDef.create("page_size", "page_size"), 
/* 204 */           MCItemDef.create("total", "total"), 
/* 205 */           MCItemDef.create("cache_id", "cache_id")
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\requester\paging\PDef_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */