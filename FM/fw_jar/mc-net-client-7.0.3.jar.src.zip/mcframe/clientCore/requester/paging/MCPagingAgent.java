/*      */ package mcframe.clientCore.requester.paging;
/*      */ 
/*      */ import java.math.BigDecimal;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import mcframe.clientCore.requester.decorator.MCDecoratorCaller;
/*      */ import mcframe.commonCore.container.MCContainer;
/*      */ import mcframe.commonCore.container.MCList;
/*      */ import mcframe.commonCore.container.MCRow;
/*      */ import mcframe.commonCore.container.MCSortPolicy;
/*      */ import mcframe.commonCore.lang.MCNumber;
/*      */ import mcframe.commonCore.lang.MCStringUtil;
/*      */ import mcframe.commonCore.lang.MCTimestamp;
/*      */ import mcframe.commonCore.param.MCContainerDef;
/*      */ import mcframe.commonCore.param.MCDef;
/*      */ import mcframe.commonCore.param.MCItemDef;
/*      */ import mcframe.commonCore.param.MCParam;
/*      */ import mcframe.commonCore.param.MCParamHandler;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MCPagingAgent
/*      */ {
/*   36 */   private MCParam p_tar = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final MCList<PageR> pages;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MCTimestamp rt;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MCTimestamp ct;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MCParamHandler _handler;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int SINGLE_TARGET = -2147483648;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCPagingAgent() {
/*   95 */     this(null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCPagingAgent(MCParamHandler handler) {
/*  106 */     this.pages = MCList.create(PageR.class);
/*      */     
/*  108 */     this._handler = handler;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MCParam param() {
/*  120 */     return this.p_tar;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private PageR getPageR(int blk) {
/*  144 */     if (blk == Integer.MIN_VALUE) {
/*  145 */       Iterator<PageR> iterator = this.pages.iterator(); if (iterator.hasNext()) { PageR r = iterator.next();
/*  146 */         return r; }
/*      */     
/*      */     } else {
/*      */       
/*  150 */       for (PageR r : this.pages) {
/*  151 */         if (r.tar_blk().eq(blk)) {
/*  152 */           return r;
/*      */         }
/*      */       } 
/*      */     } 
/*  156 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int total() {
/*  165 */     return total(-2147483648);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int total(int blk) {
/*  176 */     PageR p = getPageR(blk);
/*  177 */     if (p == null) {
/*  178 */       return 0;
/*      */     }
/*  180 */     return p.total().intValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int size() {
/*  192 */     return size(-2147483648);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int pageSizeRtn(int blk) {
/*  206 */     PageR p = getPageR(blk);
/*  207 */     if (p == null) {
/*  208 */       return 0;
/*      */     }
/*  210 */     return pageSize(p);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int size(int blk) {
/*  224 */     PageR p = getPageR(blk);
/*  225 */     if (p == null) {
/*  226 */       return 0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  232 */     return pageSizeRtn(blk);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int pagesize() {
/*  243 */     return pagesize(-2147483648);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int pagesize(int blk) {
/*  258 */     PageR p = getPageR(blk);
/*  259 */     if (p == null) {
/*  260 */       return 0;
/*      */     }
/*  262 */     return p.page_size().intValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isCached() {
/*  271 */     return isCached(-2147483648);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isCached(int blk) {
/*  283 */     PageR p = getPageR(blk);
/*  284 */     if (p == null) {
/*  285 */       return false;
/*      */     }
/*      */     
/*  288 */     return (total(blk) > size(blk));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasNext() {
/*  297 */     return hasNext(-2147483648);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasNext(int blk) {
/*  309 */     if (!isCached(blk)) {
/*  310 */       return false;
/*      */     }
/*      */     
/*  313 */     return (total(blk) > to(blk));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasPrevious() {
/*  322 */     return hasPrevious(-2147483648);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean hasPrevious(int blk) {
/*  334 */     PageR p = getPageR(blk);
/*  335 */     if (p == null) {
/*  336 */       return false;
/*      */     }
/*  338 */     return (p.from().intValue() > 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int from() {
/*  349 */     return from(-2147483648);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int from(int blk) {
/*  363 */     PageR p = getPageR(blk);
/*  364 */     if (p == null) {
/*  365 */       return 0;
/*      */     }
/*  367 */     return p.from().intValue() + 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int to() {
/*  378 */     return to(-2147483648);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int to(int blk) {
/*  392 */     PageR p = getPageR(blk);
/*  393 */     if (p == null) {
/*  394 */       return 0;
/*      */     }
/*      */     
/*  397 */     return p.from().intValue() + size(blk);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void jump(int from, int to, MCList<?> list) {
/*  417 */     jump(0, from, to, this.p_tar, list);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void jump(int blk, int from, int to, MCParam param, MCList<?> list) {
/*  439 */     PageR p = getPageR(blk);
/*  440 */     if (p == null) {
/*      */       return;
/*      */     }
/*      */     
/*  444 */     MCList<PageR> pl = MCList.create(PageR.class, 1);
/*  445 */     ArrayList<Integer> f = new ArrayList<>(1);
/*  446 */     ArrayList<Integer> t = new ArrayList<>(1);
/*      */     
/*  448 */     ArrayList<MCList> l = null;
/*  449 */     if (list != null) {
/*  450 */       l = new ArrayList<>(1);
/*  451 */       pl.add((MCRow)p);
/*  452 */       f.add(Integer.valueOf(from - 1));
/*  453 */       t.add(Integer.valueOf(from - to + 1));
/*  454 */       l.add(list);
/*      */     } 
/*  456 */     doGetPage(pl, f, t, param, l);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void jump(int blk, int from, int to, MCParam param) {
/*  477 */     jump(blk, from, to, param, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void doPrevious(MCList<?> list) {
/*  488 */     int[] blks = {
/*  489 */         Integer.MIN_VALUE
/*      */       };
/*  491 */     int[] cnts = new int[blks.length];
/*      */     
/*  493 */     MCList[] lists = {
/*  494 */         list
/*      */       };
/*  496 */     doPrevNext(true, this.p_tar, blks, cnts, (MCList<?>[])lists);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void doPrevious(MCParam param, List<? extends MCPagingParam> pps) {
/*  509 */     if (param != null && pps != null && !pps.isEmpty()) {
/*  510 */       int[] blks = new int[pps.size()];
/*  511 */       int[] cnts = new int[pps.size()];
/*  512 */       for (int i = 0; i < pps.size(); i++) {
/*  513 */         MCPagingParam pp = pps.get(i);
/*  514 */         blks[i] = pp.getParamBlockIndex(param);
/*  515 */         cnts[i] = pp.getSize();
/*      */       } 
/*  517 */       doPrevNext(true, param, blks, cnts, null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doPrevNext(boolean isPrev, MCParam param, int[] blks, int[] cnts, MCList[] lists) {
/*  536 */     if (blks == null || cnts == null || blks.length != cnts.length || (
/*  537 */       lists != null && blks.length != lists.length)) {
/*      */       return;
/*      */     }
/*      */     
/*  541 */     MCList<PageR> pl = MCList.create(PageR.class, 1);
/*  542 */     ArrayList<Integer> from = new ArrayList<>(blks.length);
/*  543 */     ArrayList<Integer> to = new ArrayList<>(blks.length);
/*  544 */     ArrayList<MCList> l = null;
/*  545 */     if (lists != null) {
/*  546 */       l = new ArrayList<>(blks.length);
/*      */     }
/*  548 */     for (int i = 0; i < blks.length; i++) {
/*  549 */       Integer blk = Integer.valueOf(blks[i]);
/*  550 */       if (blk != null) {
/*      */ 
/*      */         
/*  553 */         PageR p = getPageR(blk.intValue());
/*  554 */         if (p != null) {
/*      */ 
/*      */           
/*  557 */           int cnt = p.page_size().intValue();
/*  558 */           if (cnts[i] != 0) {
/*  559 */             cnt = cnts[i];
/*  560 */             p.page_size(cnt);
/*      */           } 
/*  562 */           if (isCached(blk.intValue()) && (!isPrev || hasPrevious(blk.intValue())) && (
/*  563 */             isPrev || hasNext(blk.intValue())))
/*      */           
/*      */           { 
/*  566 */             pl.add((MCRow)p);
/*      */             
/*  568 */             int f = p.from().intValue();
/*      */ 
/*      */             
/*  571 */             if (isPrev) {
/*  572 */               f -= cnt;
/*  573 */               if (f < 0) {
/*  574 */                 f = 0;
/*      */               
/*      */               }
/*      */             }
/*      */             else {
/*      */               
/*  580 */               f += pageSize(p);
/*      */             } 
/*      */             
/*  583 */             from.add(Integer.valueOf(f));
/*  584 */             to.add(Integer.valueOf(f + cnt));
/*  585 */             if (l != null)
/*  586 */             { MCList list = lists[i];
/*  587 */               l.add(list); }  } 
/*      */         } 
/*      */       } 
/*  590 */     }  doGetPage(pl, from, to, param, l);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int pageSize(PageR p) {
/*  603 */     MCNumber n = p.page_size_rtn();
/*  604 */     if (n != null) {
/*  605 */       return n.intValue();
/*      */     }
/*  607 */     return p.page_size().intValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void doNext(MCList<?> list) {
/*  618 */     int[] blks = {
/*  619 */         Integer.MIN_VALUE
/*      */       };
/*  621 */     int[] cnts = new int[blks.length];
/*      */     
/*  623 */     MCList[] lists = {
/*  624 */         list
/*      */       };
/*  626 */     doPrevNext(false, this.p_tar, blks, cnts, (MCList<?>[])lists);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void doNext(MCParam param, List<? extends MCPagingParam> pps) {
/*  639 */     if (param != null && pps != null && !pps.isEmpty()) {
/*  640 */       int[] blks = new int[pps.size()];
/*  641 */       int[] cnts = new int[pps.size()];
/*  642 */       for (int i = 0; i < pps.size(); i++) {
/*  643 */         MCPagingParam pp = pps.get(i);
/*  644 */         blks[i] = pp.getParamBlockIndex(param);
/*  645 */         cnts[i] = pp.getSize();
/*      */       } 
/*  647 */       doPrevNext(false, param, blks, cnts, null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doGetPage(MCList<PageR> pl, ArrayList<Integer> from, ArrayList<Integer> to, MCParam param, ArrayList<MCList> list) {
/*  666 */     if (pl == null || pl.isEmpty() || (list != null && pl.size() != list.size())) {
/*      */       return;
/*      */     }
/*      */     
/*  670 */     if (param != null) {
/*  671 */       this.p_tar = param;
/*      */     }
/*      */     
/*  674 */     callGetPage(this.p_tar, pl, from, to);
/*      */ 
/*      */     
/*  677 */     if (!isCanceled()) {
/*  678 */       for (int i = 0; i < pl.size(); i++) {
/*  679 */         PageR p = (PageR)pl.get(i);
/*  680 */         int f = ((Integer)from.get(i)).intValue();
/*  681 */         MCList dblk = (MCList)this.p_tar.getContainerParam().getDownBlock(
/*  682 */             p.tar_blk().intValue());
/*      */         
/*  684 */         p.from(f);
/*  685 */         p.page_size_rtn(dblk.size());
/*  686 */         if (list != null) {
/*  687 */           MCList l = list.get(i);
/*  688 */           l.clear();
/*  689 */           l.addAll((Collection)dblk);
/*      */         } 
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void callGetPage(MCParam param, MCList<PageR> pl, ArrayList<Integer> from, ArrayList<Integer> to) {
/*  712 */     if (pl == null || pl.isEmpty()) {
/*      */       return;
/*      */     }
/*      */     
/*  716 */     param.getMessageParam().getMessageRowParamList().clear();
/*      */ 
/*      */ 
/*      */     
/*  720 */     W_FCBGL2000_GetPageCaller cllr = getGetPageCaller(param);
/*  721 */     for (int i = 0; i < pl.size(); i++) {
/*  722 */       PageR p = (PageR)pl.get(i);
/*  723 */       p.tar_blk().intValue();
/*  724 */       int f = ((Integer)from.get(i)).intValue();
/*  725 */       int t = ((Integer)to.get(i)).intValue();
/*  726 */       PageR upR = PageR.create();
/*  727 */       upR.tar_blk(p.tar_blk());
/*  728 */       upR.from(f);
/*  729 */       upR.page_size(t - f);
/*  730 */       upR.page_size_bef(p.page_size_bef());
/*  731 */       upR.cache_id(p.cache_id());
/*  732 */       cllr.up1.add((MCRow)upR);
/*      */     } 
/*  734 */     cllr.exec();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected W_FCBGL2000_GetPageCaller getGetPageCaller(MCParam tar) {
/*  748 */     return new W_FCBGL2000_GetPageCaller(tar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void callPaging(MCParam p, int size) {
/*  763 */     callPaging(p, size, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void callPaging(MCParam p, int size, int idx) {
/*  777 */     callPaging(p, size, idx, MCList.create(SortItemR.class));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void callPaging(MCParam p, int size, MCSortPolicy sort) {
/*  792 */     callPaging(p, size, 0, sort);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void callPaging(MCParam p, int size, MCList<SortItemR> sort) {
/*  807 */     callPaging(p, size, 0, sort);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void callPaging(MCParam p, int size, int idx, MCSortPolicy sort) {
/*  821 */     MCList<SortItemR> l = MCList.create(SortItemR.class);
/*  822 */     if (sort != null) {
/*  823 */       for (int i = 0; i < (sort.nameArray()).length; i++) {
/*  824 */         SortItemR r = SortItemR.create();
/*  825 */         r.nm(sort.nameArray()[i]);
/*  826 */         r.sort_typ(sort.typeArray()[i].name());
/*  827 */         r.sort_no(i);
/*  828 */         l.add((MCRow)r);
/*      */       } 
/*      */     }
/*      */     
/*  832 */     callPaging(p, size, idx, l);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void callPaging(MCParam p, int size, int idx, MCList<SortItemR> sort) {
/*  847 */     if (sort != null) {
/*  848 */       for (int i = 0; i < sort.size(); i++) {
/*  849 */         SortItemR sr = (SortItemR)sort.get(i);
/*  850 */         sr.tar_blk(idx);
/*  851 */         sr.sort_no(i);
/*      */       } 
/*      */     }
/*  854 */     callPaging(p, new int[] {
/*  855 */           size
/*  856 */         }, new int[] {
/*  857 */           idx
/*  858 */         }, sort);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void callPaging(MCParam p, int[] sizes, int[] indices, MCSortPolicy[] sorts) {
/*  875 */     if (sizes == null || indices == null) {
/*      */       return;
/*      */     }
/*  878 */     if (sizes.length != indices.length) {
/*      */       return;
/*      */     }
/*  881 */     MCList<SortItemR> sortsList = null;
/*  882 */     if (sorts != null) {
/*  883 */       if (indices.length != sorts.length) {
/*      */         return;
/*      */       }
/*      */       
/*  887 */       sortsList = MCList.create(SortItemR.class);
/*  888 */       for (int i = 0; i < sorts.length; i++) {
/*  889 */         int idx = indices[i];
/*  890 */         MCSortPolicy s = sorts[i];
/*  891 */         if (s != null) {
/*  892 */           for (int sortNo = 0; i < (s.nameArray()).length; i++) {
/*  893 */             SortItemR r = SortItemR.create();
/*  894 */             r.nm(s.nameArray()[sortNo]);
/*  895 */             r.sort_typ(s.typeArray()[sortNo].name());
/*  896 */             r.sort_no(sortNo);
/*  897 */             r.tar_blk(idx);
/*  898 */             sortsList.add((MCRow)r);
/*      */           } 
/*      */         }
/*      */       } 
/*      */     } 
/*  903 */     callPaging(p, sizes, indices, sortsList);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void callPaging(MCParam p, int[] sizes, int[] indices, MCList<SortItemR> sorts) {
/*  919 */     if (sizes == null || indices == null) {
/*      */       return;
/*      */     }
/*  922 */     if (sizes.length != indices.length) {
/*      */       return;
/*      */     }
/*      */     
/*  926 */     this.p_tar = p;
/*      */     
/*  928 */     W_FCBGL2000_CallPagingCaller cllr = getCallPagingCaller(this.p_tar);
/*  929 */     for (int i = 0; i < indices.length; i++) {
/*  930 */       int idx = indices[i];
/*  931 */       int size = sizes[i];
/*  932 */       if (size >= 1 && idx >= 0) {
/*      */ 
/*      */         
/*  935 */         PageR upR = PageR.create();
/*  936 */         upR.tar_blk(idx);
/*  937 */         upR.page_size(size);
/*  938 */         cllr.up1.add((MCRow)upR);
/*      */         
/*  940 */         if (sorts != null) {
/*  941 */           MCList<SortItemR> sort = sorts.subList("tar_blk", 
/*  942 */               (Comparable)MCNumber.valueOf(idx));
/*  943 */           if (!sort.isEmpty()) {
/*  944 */             resolveSort(cllr.up2, sort, this.p_tar, idx);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  950 */     cllr.exec();
/*  951 */     this.pages.clear();
/*  952 */     if (!isCanceled()) {
/*  953 */       for (PageR dr : cllr.down1) {
/*  954 */         PageR pr = PageR.create();
/*  955 */         pr.tar_blk(dr.tar_blk());
/*  956 */         pr.page_size(dr.page_size());
/*  957 */         pr.page_size_bef(pr.page_size());
/*  958 */         MCList dblk = (MCList)this.p_tar.getContainerParam().getDownBlock(
/*  959 */             dr.tar_blk().intValue());
/*  960 */         pr.page_size_rtn(dblk.size());
/*  961 */         pr.from(0);
/*  962 */         pr.total(dr.total());
/*  963 */         pr.cache_id(dr.cache_id());
/*  964 */         this.pages.add((MCRow)pr);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isCanceled() {
/*  978 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void callPaging(MCParam p, List<? extends MCPagingParam> pps) {
/*  993 */     if (pps == null || pps.isEmpty()) {
/*      */       return;
/*      */     }
/*  996 */     int[] sizes = new int[pps.size()];
/*  997 */     int[] indices = new int[pps.size()];
/*  998 */     MCList<SortItemR> sortsList = MCList.create(SortItemR.class, pps.size());
/*      */     
/* 1000 */     for (int i = 0; i < pps.size(); i++) {
/* 1001 */       MCPagingParam pp = pps.get(i);
/* 1002 */       sizes[i] = pp.getSize();
/* 1003 */       indices[i] = pp.getParamBlockIndex(p);
/* 1004 */       MCSortPolicy s = pp.getSortPolicy();
/* 1005 */       if (s != null) {
/* 1006 */         for (int sortNo = 0; sortNo < (s.nameArray()).length; sortNo++) {
/* 1007 */           SortItemR r = SortItemR.create();
/* 1008 */           r.nm(s.nameArray()[sortNo]);
/* 1009 */           r.sort_typ(s.typeArray()[sortNo].name());
/* 1010 */           r.sort_no(sortNo);
/* 1011 */           r.tar_blk(indices[i]);
/* 1012 */           sortsList.add((MCRow)r);
/*      */         } 
/*      */       }
/*      */     } 
/*      */     
/* 1017 */     callPaging(p, sizes, indices, sortsList);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected W_FCBGL2000_CallPagingCaller getCallPagingCaller(MCParam tar) {
/* 1031 */     return new W_FCBGL2000_CallPagingCaller(tar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void callBufferPaging(MCParam p, int size) {
/* 1046 */     callBufferPaging(p, size, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void callBufferPaging(MCParam p, int size, int idx) {
/* 1060 */     callBufferPaging(p, size, idx, MCList.create(SortItemR.class));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void callBufferPaging(MCParam p, int size, MCSortPolicy sort) {
/* 1075 */     callBufferPaging(p, size, 0, sort);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void callBufferPaging(MCParam p, int size, MCList<SortItemR> sort) {
/* 1090 */     callBufferPaging(p, size, 0, sort);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void callBufferPaging(MCParam p, int size, int idx, MCSortPolicy sort) {
/* 1104 */     MCList<SortItemR> l = MCList.create(SortItemR.class);
/* 1105 */     for (int i = 0; i < (sort.nameArray()).length; i++) {
/* 1106 */       SortItemR r = SortItemR.create();
/* 1107 */       r.nm(sort.nameArray()[i]);
/* 1108 */       r.sort_typ(sort.typeArray()[i].name());
/* 1109 */       l.add((MCRow)r);
/*      */     } 
/*      */     
/* 1112 */     callBufferPaging(p, size, idx, l);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void callBufferPaging(MCParam p, int size, int idx, MCList<SortItemR> sort) {
/* 1127 */     if (sort != null) {
/* 1128 */       for (int i = 0; i < sort.size(); i++) {
/* 1129 */         SortItemR sr = (SortItemR)sort.get(i);
/* 1130 */         sr.tar_blk(idx);
/* 1131 */         sr.sort_no(i);
/*      */       } 
/*      */     }
/* 1134 */     callBufferPaging(p, new int[] {
/* 1135 */           size
/* 1136 */         }, new int[] {
/* 1137 */           idx
/* 1138 */         }, sort);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void callBufferPaging(MCParam p, int[] sizes, int[] indices, MCSortPolicy[] sorts) {
/* 1156 */     if (sizes == null || indices == null) {
/*      */       return;
/*      */     }
/* 1159 */     if (sizes.length != indices.length) {
/*      */       return;
/*      */     }
/* 1162 */     MCList<SortItemR> sortsList = null;
/* 1163 */     if (sorts != null) {
/* 1164 */       if (indices.length != sorts.length) {
/*      */         return;
/*      */       }
/*      */       
/* 1168 */       sortsList = MCList.create(SortItemR.class);
/* 1169 */       for (int i = 0; i < sorts.length; i++) {
/* 1170 */         int idx = indices[i];
/* 1171 */         MCSortPolicy s = sorts[i];
/* 1172 */         if (s != null) {
/* 1173 */           for (int sortNo = 0; i < (s.nameArray()).length; i++) {
/* 1174 */             SortItemR r = SortItemR.create();
/* 1175 */             r.nm(s.nameArray()[sortNo]);
/* 1176 */             r.sort_typ(s.typeArray()[sortNo].name());
/* 1177 */             r.sort_no(sortNo);
/* 1178 */             r.tar_blk(idx);
/* 1179 */             sortsList.add((MCRow)r);
/*      */           } 
/*      */         }
/*      */       } 
/*      */     } 
/* 1184 */     callBufferPaging(p, sizes, indices, sortsList);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void callBufferPaging(MCParam p, List<? extends MCPagingParam> pps) {
/* 1199 */     if (pps == null || pps.isEmpty()) {
/*      */       return;
/*      */     }
/* 1202 */     int[] sizes = new int[pps.size()];
/* 1203 */     int[] indices = new int[pps.size()];
/* 1204 */     MCList<SortItemR> sortsList = MCList.create(SortItemR.class, pps.size());
/*      */     
/* 1206 */     for (int i = 0; i < pps.size(); i++) {
/* 1207 */       MCPagingParam pp = pps.get(i);
/* 1208 */       sizes[i] = pp.getSize();
/* 1209 */       indices[i] = pp.getParamBlockIndex(p);
/* 1210 */       MCSortPolicy s = pp.getSortPolicy();
/* 1211 */       for (int sortNo = 0; i < (s.nameArray()).length; i++) {
/* 1212 */         SortItemR r = SortItemR.create();
/* 1213 */         r.nm(s.nameArray()[sortNo]);
/* 1214 */         r.sort_typ(s.typeArray()[sortNo].name());
/* 1215 */         r.sort_no(sortNo);
/* 1216 */         r.tar_blk(indices[i]);
/* 1217 */         sortsList.add((MCRow)r);
/*      */       } 
/*      */     } 
/*      */     
/* 1221 */     callBufferPaging(p, sizes, indices, sortsList);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void callBufferPaging(MCParam p, int[] sizes, int[] indices, MCList<SortItemR> sorts) {
/* 1237 */     if (sizes == null || indices == null) {
/*      */       return;
/*      */     }
/* 1240 */     if (sizes.length != indices.length) {
/*      */       return;
/*      */     }
/*      */     
/* 1244 */     this.p_tar = p;
/*      */ 
/*      */     
/* 1247 */     W_FCBGL2000_CallBufferPagingCaller cllr = getCallBufferPagingCaller(this.p_tar);
/* 1248 */     for (int i = 0; i < indices.length; i++) {
/* 1249 */       int idx = indices[i];
/* 1250 */       int size = sizes[i];
/* 1251 */       PageR upR = PageR.create();
/* 1252 */       upR.tar_blk(idx);
/* 1253 */       upR.page_size(size);
/* 1254 */       cllr.up1.add((MCRow)upR);
/*      */       
/* 1256 */       if (sorts != null) {
/* 1257 */         MCList<SortItemR> sort = sorts.subList("tar_blk", 
/* 1258 */             (Comparable)MCNumber.valueOf(idx));
/* 1259 */         if (!sort.isEmpty()) {
/* 1260 */           resolveSort(cllr.up2, sort, this.p_tar, idx);
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1266 */     cllr.exec();
/* 1267 */     this.pages.clear();
/* 1268 */     if (!isCanceled()) {
/* 1269 */       for (PageR dr : cllr.down1) {
/* 1270 */         PageR pr = PageR.create();
/* 1271 */         pr.tar_blk(dr.tar_blk());
/* 1272 */         pr.page_size(dr.page_size());
/* 1273 */         pr.from(0);
/* 1274 */         pr.total(dr.total());
/* 1275 */         pr.cache_id(dr.cache_id());
/* 1276 */         this.pages.add((MCRow)pr);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected W_FCBGL2000_CallBufferPagingCaller getCallBufferPagingCaller(MCParam tar) {
/* 1292 */     return new W_FCBGL2000_CallBufferPagingCaller(tar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void resolveSort(MCList<SortItemR> dest, MCList<SortItemR> src, MCParam p, int blk) {
/* 1308 */     if (src == null || src.size() == 0 || p == null) {
/*      */       return;
/*      */     }
/* 1311 */     MCDef def = p.getDef();
/* 1312 */     MCContainerDef cdef = def.getDef(MCDef.toDefId(p, false, blk));
/* 1313 */     if (cdef == null) {
/*      */       return;
/*      */     }
/* 1316 */     MCItemDef[] idefs = cdef.transItems();
/* 1317 */     for (SortItemR s : src) {
/* 1318 */       for (int i = 0; i < idefs.length; i++) {
/*      */ 
/*      */         
/* 1321 */         if (MCStringUtil.eq((idefs[i]).id, s.nm())) {
/* 1322 */           SortItemR d = SortItemR.create();
/* 1323 */           d.sort_no(s.sort_no());
/* 1324 */           d.tar_blk(s.tar_blk());
/* 1325 */           d.nm(String.valueOf(i));
/* 1326 */           d.sort_typ(s.sort_typ());
/* 1327 */           dest.add((MCRow)d);
/*      */           break;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected class W_FCBGL2000_CallPagingCaller
/*      */     extends MCDecoratorCaller
/*      */   {
/* 1338 */     public final MCList<PageR> up1 = MCList.create(PageR.class);
/*      */     
/* 1340 */     public final MCList<SortItemR> up2 = MCList.create(SortItemR.class);
/*      */     
/* 1342 */     public final MCList<PageR> down1 = MCList.create((MCRow)PageR.create());
/*      */     
/*      */     protected W_FCBGL2000_CallPagingCaller(MCParam tar) {
/* 1345 */       super(new MCParam(PDef.FC_FCBGL2000_CallPaging_INFO), tar);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1350 */       param().setLimitDLSize(MCNumber.valueOf(-1));
/*      */       
/* 1352 */       param().addUpBlock((MCContainer)this.up1);
/* 1353 */       param().addUpBlock((MCContainer)this.up2);
/* 1354 */       param().addDownBlock((MCContainer)this.down1);
/*      */       
/* 1356 */       setParamHandler(MCPagingAgent.this._handler);
/*      */     }
/*      */ 
/*      */     
/*      */     protected void reqTm2decPrm() {
/* 1361 */       MCPagingAgent.this.rt = this.tar.getRequestTime();
/* 1362 */       setRequestTime(this.tar, MCPagingAgent.this.rt);
/*      */     }
/*      */ 
/*      */     
/*      */     protected void cmtTm2decPrm() {
/* 1367 */       MCPagingAgent.this.ct = this.tar.getCommitTime();
/* 1368 */       setCommitTime(this.tar, MCPagingAgent.this.ct);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected class W_FCBGL2000_CallBufferPagingCaller
/*      */     extends MCDecoratorCaller
/*      */   {
/* 1377 */     public final MCList<PageR> up1 = MCList.create(PageR.class);
/*      */     
/* 1379 */     public final MCList<SortItemR> up2 = MCList.create(SortItemR.class);
/*      */     
/* 1381 */     public final MCList<PageR> down1 = MCList.create((MCRow)PageR.create());
/*      */     
/*      */     protected W_FCBGL2000_CallBufferPagingCaller(MCParam tar) {
/* 1384 */       super(new MCParam(PDef.FC_FCBGL2000_CallBufferPaging_INFO), tar);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1389 */       param().setLimitDLSize(MCNumber.valueOf(-1));
/*      */       
/* 1391 */       param().addUpBlock((MCContainer)this.up1);
/* 1392 */       param().addUpBlock((MCContainer)this.up2);
/* 1393 */       param().addDownBlock((MCContainer)this.down1);
/*      */       
/* 1395 */       setParamHandler(MCPagingAgent.this._handler);
/*      */     }
/*      */ 
/*      */     
/*      */     protected void reqTm2decPrm() {
/* 1400 */       MCPagingAgent.this.rt = this.tar.getRequestTime();
/* 1401 */       setRequestTime(this.tar, MCPagingAgent.this.rt);
/*      */     }
/*      */ 
/*      */     
/*      */     protected void cmtTm2decPrm() {
/* 1406 */       MCPagingAgent.this.ct = this.tar.getCommitTime();
/* 1407 */       setCommitTime(this.tar, MCPagingAgent.this.ct);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected class W_FCBGL2000_GetPageCaller
/*      */     extends MCDecoratorCaller
/*      */   {
/* 1415 */     public final MCList<PageR> up1 = MCList.create(PageR.class);
/*      */     
/*      */     protected W_FCBGL2000_GetPageCaller(MCParam tar) {
/* 1418 */       super(new MCParam(PDef.FC_FCBGL2000_GetPage_INFO), tar);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1424 */       param().setLimitDLSize(MCNumber.valueOf(-1));
/*      */       
/* 1426 */       param().addUpBlock((MCContainer)this.up1);
/*      */       
/* 1428 */       setParamHandler(MCPagingAgent.this._handler);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void decorateUp() {
/* 1435 */       MCNumber curCurSizeSum = this.up1.sum("page_size");
/* 1436 */       MCNumber curBefSizeSum = this.up1.sum("page_size_bef");
/* 1437 */       if (curCurSizeSum.lte((BigDecimal)curBefSizeSum)) {
/* 1438 */         this.tar.setLimitDLSize(MCNumber.valueOf(-1));
/*      */       } else {
/*      */         
/* 1441 */         this.tar.setLimitDLSize(null);
/*      */       } 
/* 1443 */       super.decorateUp();
/*      */     }
/*      */ 
/*      */     
/*      */     public void exec() {
/* 1448 */       super.exec();
/*      */     }
/*      */ 
/*      */     
/*      */     protected void reqTm2decPrm() {
/* 1453 */       if (this.tar != null) {
/* 1454 */         setRequestTime(this.tar, MCPagingAgent.this.rt);
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     protected void cmtTm2decPrm() {
/* 1460 */       if (this.tar != null) {
/* 1461 */         setCommitTime(this.tar, MCPagingAgent.this.ct);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPageSizeRtn(int blk, int rtnsize) {
/* 1474 */     PageR r = getPageR(blk);
/* 1475 */     if (r != null) {
/* 1476 */       r.page_size_rtn(rtnsize);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPageSizeBef(int blk) {
/* 1487 */     PageR r = getPageR(blk);
/* 1488 */     if (r != null) {
/* 1489 */       r.page_size_bef(r.page_size());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFrom(int blk, int from) {
/* 1501 */     PageR r = getPageR(blk);
/* 1502 */     if (r != null)
/*      */     {
/* 1504 */       r.from(from - 1);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\requester\paging\MCPagingAgent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */