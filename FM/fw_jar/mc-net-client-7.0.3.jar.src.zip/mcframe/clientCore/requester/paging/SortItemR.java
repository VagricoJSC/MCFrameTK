/*    */ package mcframe.clientCore.requester.paging;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import mcframe.clientCore.container.MCKeyList;
/*    */ import mcframe.commonCore.annotation.EI;
/*    */ import mcframe.commonCore.container.MCRow;
/*    */ import mcframe.commonCore.lang.MCNumber;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @EI
/*    */ public class SortItemR
/*    */   extends SortItemR_FW_A
/*    */ {
/*    */   public static SortItemR create() {
/* 67 */     SortItemR row = new SortItemR(constMetas);
/* 68 */     return row;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static <T extends MCRow> SortItemR createByName(T proto) {
/* 78 */     SortItemR row = create();
/* 79 */     copyByName((MCRow)row, (MCRow)proto);
/* 80 */     return row;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SortItemR(MCRow.ConstMetaList<? extends SortItemR> metas) {
/* 87 */     super(metas);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\requester\paging\SortItemR.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */