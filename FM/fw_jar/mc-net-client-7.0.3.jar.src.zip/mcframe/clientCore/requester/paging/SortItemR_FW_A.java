/*     */ package mcframe.clientCore.requester.paging;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.clientCore.container.MCKeyList;
/*     */ import mcframe.commonCore.container.MCExtMap;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class SortItemR_FW_A
/*     */   extends MCConstRow
/*     */ {
/*     */   public static final String $tar_blk = "tar_blk";
/*     */   public static final String $sort_no = "sort_no";
/*     */   public static final String $nm = "nm";
/*     */   public static final String $sort_typ = "sort_typ";
/*  35 */   public static final MCMeta tar_blk_META = createNumberMeta("tar_blk");
/*  36 */   public static final MCMeta sort_no_META = createNumberMeta("sort_no");
/*  37 */   public static final MCMeta nm_META = createStringMeta("nm");
/*  38 */   public static final MCMeta sort_typ_META = createStringMeta("sort_typ");
/*     */   
/*  40 */   protected static final MCRow.ConstMetaList<SortItemR> constMetas = new MCRow.ConstMetaList(
/*  41 */       MCConstRow.constMetas, 
/*  42 */       new MCMeta[] {
/*  43 */         tar_blk_META, 
/*  44 */         sort_no_META, 
/*  45 */         nm_META, 
/*  46 */         sort_typ_META
/*     */       },
/*  48 */       new String[][] { {}, {} });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   protected static final MCKeyList KEYS = new MCKeyList(
/*  60 */       null, 
/*  61 */       new String[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   protected static final MCExtMap EXTMAP = new MCExtMap(
/*  70 */       null, new MCExtMap.Entry[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] colnames() {
/*  82 */     return constMetas.toNameArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMeta[] colmetas() {
/*  94 */     return constMetas.toMetaArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   private static final int offset = constMetas.offset();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCKeyList getKeys() {
/* 106 */     return KEYS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getExtMap(String aGroup) {
/* 113 */     if (aGroup == null) return null; 
/* 114 */     return (Map<String, String>)EXTMAP.get(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCKeyList getKeys(String aGroup) {
/* 121 */     if (aGroup == null) return null; 
/* 122 */     return new MCKeyList(EXTMAP.getKeyList(aGroup));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExtGroups() {
/* 129 */     Set<String> ret = EXTMAP.keySet();
/* 130 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SortItemR_FW_A(MCRow.ConstMetaList<? extends SortItemR> metas) {
/* 137 */     super(metas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SortItemR clone() {
/* 144 */     return (SortItemR)super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SortItemR createInstance() {
/* 151 */     return (SortItemR)super.createInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SortItemR getValues(String... names) {
/* 158 */     return (SortItemR)super.getValues(names);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MCNumber tar_blk() {
/* 164 */     return getConstNumber(offset + 0, "tar_blk");
/*     */   }
/*     */   
/*     */   public void tar_blk(MCNumber value) {
/* 168 */     setConstNumber(offset + 0, "tar_blk", value);
/*     */   }
/*     */   
/*     */   public void tar_blk(int value) {
/* 172 */     setConstNumber(offset + 0, "tar_blk", value);
/*     */   }
/*     */   
/*     */   public void tar_blk(long value) {
/* 176 */     setConstNumber(offset + 0, "tar_blk", value);
/*     */   }
/*     */   
/*     */   public void tar_blk(float value) {
/* 180 */     setConstNumber(offset + 0, "tar_blk", value);
/*     */   }
/*     */   
/*     */   public void tar_blk(double value) {
/* 184 */     setConstNumber(offset + 0, "tar_blk", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCNumber sort_no() {
/* 189 */     return getConstNumber(offset + 1, "sort_no");
/*     */   }
/*     */   
/*     */   public void sort_no(MCNumber value) {
/* 193 */     setConstNumber(offset + 1, "sort_no", value);
/*     */   }
/*     */   
/*     */   public void sort_no(int value) {
/* 197 */     setConstNumber(offset + 1, "sort_no", value);
/*     */   }
/*     */   
/*     */   public void sort_no(long value) {
/* 201 */     setConstNumber(offset + 1, "sort_no", value);
/*     */   }
/*     */   
/*     */   public void sort_no(float value) {
/* 205 */     setConstNumber(offset + 1, "sort_no", value);
/*     */   }
/*     */   
/*     */   public void sort_no(double value) {
/* 209 */     setConstNumber(offset + 1, "sort_no", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String nm() {
/* 214 */     return getConstString(offset + 2, "nm");
/*     */   }
/*     */   
/*     */   public void nm(String value) {
/* 218 */     setConstString(offset + 2, "nm", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String sort_typ() {
/* 223 */     return getConstString(offset + 3, "sort_typ");
/*     */   }
/*     */   
/*     */   public void sort_typ(String value) {
/* 227 */     setConstString(offset + 3, "sort_typ", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString(String name) {
/* 232 */     if ("nm".equalsIgnoreCase(name)) {
/* 233 */       return nm();
/*     */     }
/* 235 */     if ("sort_typ".equalsIgnoreCase(name)) {
/* 236 */       return sort_typ();
/*     */     }
/* 238 */     return super.getString(name);
/*     */   }
/*     */   public MCNumber getNumber(String name) {
/* 241 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 242 */       return tar_blk();
/*     */     }
/* 244 */     if ("sort_no".equalsIgnoreCase(name)) {
/* 245 */       return sort_no();
/*     */     }
/* 247 */     return super.getNumber(name);
/*     */   }
/*     */   
/*     */   public String getStringNE(String name) {
/* 251 */     if ("nm".equalsIgnoreCase(name)) {
/* 252 */       return nm();
/*     */     }
/* 254 */     if ("sort_typ".equalsIgnoreCase(name)) {
/* 255 */       return sort_typ();
/*     */     }
/* 257 */     return super.getStringNE(name);
/*     */   }
/*     */   public MCNumber getNumberNE(String name) {
/* 260 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 261 */       return tar_blk();
/*     */     }
/* 263 */     if ("sort_no".equalsIgnoreCase(name)) {
/* 264 */       return sort_no();
/*     */     }
/* 266 */     return super.getNumberNE(name);
/*     */   }
/*     */   
/*     */   public void setString(String name, String value) {
/* 270 */     if ("nm".equalsIgnoreCase(name)) {
/* 271 */       nm(value);
/*     */       return;
/*     */     } 
/* 274 */     if ("sort_typ".equalsIgnoreCase(name)) {
/* 275 */       sort_typ(value);
/*     */       return;
/*     */     } 
/* 278 */     super.setString(name, value);
/*     */   }
/*     */   public void setNumber(String name, MCNumber value) {
/* 281 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 282 */       tar_blk(value);
/*     */       return;
/*     */     } 
/* 285 */     if ("sort_no".equalsIgnoreCase(name)) {
/* 286 */       sort_no(value);
/*     */       return;
/*     */     } 
/* 289 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, int value) {
/* 292 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 293 */       tar_blk(value);
/*     */       return;
/*     */     } 
/* 296 */     if ("sort_no".equalsIgnoreCase(name)) {
/* 297 */       sort_no(value);
/*     */       return;
/*     */     } 
/* 300 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, long value) {
/* 303 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 304 */       tar_blk(value);
/*     */       return;
/*     */     } 
/* 307 */     if ("sort_no".equalsIgnoreCase(name)) {
/* 308 */       sort_no(value);
/*     */       return;
/*     */     } 
/* 311 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, float value) {
/* 314 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 315 */       tar_blk(value);
/*     */       return;
/*     */     } 
/* 318 */     if ("sort_no".equalsIgnoreCase(name)) {
/* 319 */       sort_no(value);
/*     */       return;
/*     */     } 
/* 322 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, double value) {
/* 325 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 326 */       tar_blk(value);
/*     */       return;
/*     */     } 
/* 329 */     if ("sort_no".equalsIgnoreCase(name)) {
/* 330 */       sort_no(value);
/*     */       return;
/*     */     } 
/* 333 */     super.setNumber(name, value);
/*     */   }
/*     */   
/*     */   public void setStringNE(String name, String value) {
/* 337 */     if ("nm".equalsIgnoreCase(name)) {
/* 338 */       nm(value);
/*     */       return;
/*     */     } 
/* 341 */     if ("sort_typ".equalsIgnoreCase(name)) {
/* 342 */       sort_typ(value);
/*     */       return;
/*     */     } 
/* 345 */     super.setStringNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, MCNumber value) {
/* 348 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 349 */       tar_blk(value);
/*     */       return;
/*     */     } 
/* 352 */     if ("sort_no".equalsIgnoreCase(name)) {
/* 353 */       sort_no(value);
/*     */       return;
/*     */     } 
/* 356 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, int value) {
/* 359 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 360 */       tar_blk(value);
/*     */       return;
/*     */     } 
/* 363 */     if ("sort_no".equalsIgnoreCase(name)) {
/* 364 */       sort_no(value);
/*     */       return;
/*     */     } 
/* 367 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, long value) {
/* 370 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 371 */       tar_blk(value);
/*     */       return;
/*     */     } 
/* 374 */     if ("sort_no".equalsIgnoreCase(name)) {
/* 375 */       sort_no(value);
/*     */       return;
/*     */     } 
/* 378 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, float value) {
/* 381 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 382 */       tar_blk(value);
/*     */       return;
/*     */     } 
/* 385 */     if ("sort_no".equalsIgnoreCase(name)) {
/* 386 */       sort_no(value);
/*     */       return;
/*     */     } 
/* 389 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, double value) {
/* 392 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 393 */       tar_blk(value);
/*     */       return;
/*     */     } 
/* 396 */     if ("sort_no".equalsIgnoreCase(name)) {
/* 397 */       sort_no(value);
/*     */       return;
/*     */     } 
/* 400 */     super.setNumberNE(name, value);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\requester\paging\SortItemR_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */