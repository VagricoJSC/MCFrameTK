/*     */ package mcframe.clientCore.requester.paging;
/*     */ 
/*     */ import mcframe.commonCore.container.MCSortPolicy;
/*     */ import mcframe.commonCore.param.MCBlockDef;
/*     */ import mcframe.commonCore.param.MCContainerDef;
/*     */ import mcframe.commonCore.param.MCDef;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.commonCore.util.MCUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCPagingParam
/*     */ {
/*     */   final String _blkId;
/*     */   int _size;
/*     */   MCSortPolicy _sort;
/*     */   
/*     */   public MCPagingParam(String blkId, int size, MCSortPolicy sort) {
/*  51 */     this._blkId = (String)MCUtil.requireNonNull(blkId, "blkId");
/*  52 */     this._size = size;
/*  53 */     this._sort = sort;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCPagingParam(String blkId, int size) {
/*  65 */     this(blkId, size, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCPagingParam(String blkId) {
/*  77 */     this(blkId, 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSize(int _size) {
/*  87 */     this._size = _size;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSortPolicy(MCSortPolicy _sort) {
/*  96 */     this._sort = _sort;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSize() {
/* 108 */     return this._size;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getParamBlockIndex(MCParam param) {
/* 118 */     if (param != null) {
/* 119 */       int i = 0;
/*     */       while (true) {
/* 121 */         MCContainerDef def = param.getDef()
/* 122 */           .getDef(MCDef.toDefId(param, false, i));
/* 123 */         if (def == null) {
/*     */           break;
/*     */         }
/* 126 */         MCBlockDef blkDef = def.block();
/* 127 */         if (blkDef != null) {
/* 128 */           String tgtBlkId = blkDef.toParamString();
/* 129 */           if (getTargetBlockId().equals(tgtBlkId)) {
/* 130 */             return i;
/*     */           }
/*     */         } 
/* 133 */         i++;
/*     */       } 
/*     */     } 
/* 136 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCSortPolicy getSortPolicy() {
/* 146 */     return this._sort;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTargetBlockId() {
/* 155 */     return this._blkId;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 160 */     return "BlockID:" + getTargetBlockId() + "PageSize:" + getSize();
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\requester\paging\MCPagingParam.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */