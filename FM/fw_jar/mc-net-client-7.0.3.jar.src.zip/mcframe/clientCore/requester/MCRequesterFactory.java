/*     */ package mcframe.clientCore.requester;
/*     */ 
/*     */ import mcframe.clientCore.resource.MCConfig;
/*     */ import mcframe.clientCore.sys.MCSys;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.requester.MCControlRequester;
/*     */ import mcframe.commonCore.sys.MCFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCRequesterFactory
/*     */ {
/*     */   private static final String CLASSNAME_2TIER = "mcframe.serverCore.requester.MCServerRequester";
/*     */   private static final String CLASSNAME_3TIER = "mcframe.clientCore.requester.MCWinClientRequester";
/*     */   private static final String CLASSNAME_3TIER_JAVA = "mcframe.clientCore.requester.MCClientRequester";
/*     */   private static final String CLASSNAME_1TIER = "mcframe.clientMNX.MNX1000.MCClientUnitTestRequester";
/*     */   
/*     */   public static final MCControlRequester createRequester() {
/*  95 */     String ERR_ID = Core_Msg_FW_A.FCBGC0028;
/*     */     
/*  97 */     String className = createRequesterName();
/*     */     
/*     */     try {
/* 100 */       return (MCControlRequester)MCFactory.create(MCControlRequester.class, className);
/* 101 */     } catch (MCException e) {
/* 102 */       throw new MCException(e, ERR_ID, new Object[] { property() });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String createRequesterName() {
/* 114 */     String className, T3_LOG_ID = Core_Msg_FW_A.FCBGC0203;
/* 115 */     String T2_LOG_ID = Core_Msg_FW_A.FCBGC0204;
/*     */     
/* 117 */     String id = property();
/*     */     
/* 119 */     if (id.equals("3")) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 124 */       String type = MCConfig.client.getString("net.request.type", "");
/* 125 */       if (MCSys.env.isWin() && !type.startsWith("java")) {
/* 126 */         className = "mcframe.clientCore.requester.MCWinClientRequester";
/*     */       } else {
/*     */         
/* 129 */         className = "mcframe.clientCore.requester.MCClientRequester";
/*     */       } 
/*     */ 
/*     */       
/* 133 */       MCLog.write(T3_LOG_ID, new Object[] { id, className });
/*     */     }
/* 135 */     else if (id.equals("1")) {
/* 136 */       className = "mcframe.clientMNX.MNX1000.MCClientUnitTestRequester";
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 141 */       className = "mcframe.serverCore.requester.MCServerRequester";
/*     */ 
/*     */       
/* 144 */       MCLog.write(T2_LOG_ID, new Object[] { id, className });
/*     */     } 
/* 146 */     return className;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String property() {
/* 158 */     String id = MCSys.env.MCF_TIER();
/*     */ 
/*     */     
/* 161 */     if (id == null) {
/* 162 */       id = "2";
/*     */     }
/* 164 */     return id;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\requester\MCRequesterFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */