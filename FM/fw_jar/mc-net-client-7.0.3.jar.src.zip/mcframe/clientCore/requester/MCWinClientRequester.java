/*     */ package mcframe.clientCore.requester;
/*     */ 
/*     */ import java.io.File;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.param.MCUploadFileParam;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCWinClientRequester
/*     */   extends MCClientRequester
/*     */ {
/*     */   protected String httpRequest(String url, String up, MCUploadFileParam upf) {
/*  36 */     MCNetNativeIf net = createNetIf(url);
/*     */ 
/*     */     
/*  39 */     net.up = up;
/*     */     
/*  41 */     if (upf != null && upf.requestSize() > 0) {
/*  42 */       String[][] uploads = upf.toRequestArrays();
/*  43 */       net.upnames = uploads[0];
/*  44 */       net.upfiles = uploads[1];
/*     */     } 
/*     */ 
/*     */     
/*  48 */     MCLog.write(Core_Msg_FW_A.FCBGC0208, new Object[] { url });
/*     */ 
/*     */     
/*  51 */     net.callRequest();
/*     */ 
/*     */     
/*  54 */     MCLog.write(Core_Msg_FW_A.FCBGC0209, new Object[] { net.errcd, url });
/*     */ 
/*     */     
/*  57 */     checkNetIfError(net);
/*     */ 
/*     */     
/*  60 */     return net.down;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected File httpDownload(String url, String up, File dir, String name) {
/*  80 */     MCNetNativeIf net = createNetIf(url);
/*     */ 
/*     */     
/*  83 */     if (up != null) {
/*  84 */       MCLog.write(Core_Msg_FW_A.FCBGC0205, new Object[] { up });
/*  85 */       net.up = up;
/*     */     } 
/*     */ 
/*     */     
/*  89 */     setDownloadFile(net, dir, name);
/*     */ 
/*     */     
/*  92 */     net.callDownload();
/*     */ 
/*     */     
/*  95 */     checkNetIfError(net);
/*     */     
/*  97 */     return getDownloadFile(net);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkNetIfError(MCNetNativeIf net) {
/* 113 */     if (net == null) {
/*     */       return;
/*     */     }
/*     */     
/* 117 */     if (net.errcd != null) {
/* 118 */       if (net.errcd.equals("0")) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 123 */       if (net.errcd.equals("90017"))
/*     */       {
/* 125 */         throw new MCException(Core_Msg_FW_A.FCBGC1003, new Object[] {
/* 126 */               Long.valueOf(net.limit_byte), net.down
/*     */             });
/*     */       }
/*     */       
/* 130 */       if (net.errcd.startsWith("93")) {
/*     */         
/* 132 */         int status = Integer.valueOf(net.errcd).intValue() - 93000;
/* 133 */         checkHTTPStatus(status, net.url);
/*     */       } 
/*     */     } 
/*     */     
/* 137 */     throw new MCException(Core_Msg_FW_A.FCBGC1102, new Object[] { net.errcd, net.url });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private File getDownloadFile(MCNetNativeIf net) {
/* 150 */     return new File(net.downdir, net.downfile);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setDownloadFile(MCNetNativeIf net, File dir, String name) {
/* 179 */     String dir_s = checkDownloadDir(dir);
/*     */ 
/*     */     
/* 182 */     if (name != null) {
/* 183 */       File file = new File(dir, name);
/* 184 */       if (file.exists()) {
/* 185 */         file.delete();
/*     */       }
/*     */     } 
/*     */     
/* 189 */     net.downdir = dir_s;
/* 190 */     net.downfile = name;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\requester\MCWinClientRequester.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */