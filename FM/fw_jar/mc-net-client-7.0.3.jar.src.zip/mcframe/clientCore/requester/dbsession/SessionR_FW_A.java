/*     */ package mcframe.clientCore.requester.dbsession;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.clientCore.container.MCKeyList;
/*     */ import mcframe.commonCore.container.MCExtMap;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCTimestamp;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ import mcframe.commonCore.meta.M_META;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class SessionR_FW_A
/*     */   extends MCConstRow
/*     */ {
/*     */   public static final String $mcf_db_sid = "mcf_db_sid";
/*     */   public static final String $user_id = "user_id";
/*     */   public static final String $co_cd = "co_cd";
/*     */   public static final String $ext_attr1 = "ext_attr1";
/*     */   public static final String $ext_attr2 = "ext_attr2";
/*     */   public static final String $ext_attr3 = "ext_attr3";
/*     */   public static final String $clt_id = "clt_id";
/*     */   public static final String $c_req_no = "c_req_no";
/*     */   public static final String $c_req_ts = "c_req_ts";
/*     */   public static final String $c_locale = "c_locale";
/*     */   public static final String $c_time_zone = "c_time_zone";
/*     */   public static final String $call_pg_id = "call_pg_id";
/*     */   public static final String $operation_cd = "operation_cd";
/*     */   public static final String $btn_res_key = "btn_res_key";
/*     */   public static final String $action_id = "action_id";
/*     */   public static final String $srv_req_no = "srv_req_no";
/*     */   public static final String $module_id = "module_id";
/*     */   public static final String $logic_id = "logic_id";
/*     */   public static final String $ope_id = "ope_id";
/*     */   public static final String $srv_id = "srv_id";
/*     */   public static final String $sid_mode = "sid_mode";
/*  52 */   public static final MCMeta mcf_db_sid_META = createCommonMeta("mcf_db_sid", M_META.MCF_DB_SESSION_ID);
/*  53 */   public static final MCMeta user_id_META = createCommonMeta("user_id", M_META.USR_ID);
/*  54 */   public static final MCMeta co_cd_META = createCommonMeta("co_cd", M_META.CO_CD);
/*  55 */   public static final MCMeta ext_attr1_META = createCommonMeta("ext_attr1", M_META.USR_EXT_ATTR);
/*  56 */   public static final MCMeta ext_attr2_META = createCommonMeta("ext_attr2", M_META.USR_EXT_ATTR);
/*  57 */   public static final MCMeta ext_attr3_META = createCommonMeta("ext_attr3", M_META.USR_EXT_ATTR);
/*  58 */   public static final MCMeta clt_id_META = createCommonMeta("clt_id", M_META.MACHINE);
/*  59 */   public static final MCMeta c_req_no_META = createCommonMeta("c_req_no", M_META.SRV_REQ_NO);
/*  60 */   public static final MCMeta c_req_ts_META = createCommonMeta("c_req_ts", M_META.TS);
/*  61 */   public static final MCMeta c_locale_META = createCommonMeta("c_locale", M_META.LOCALE_CD);
/*  62 */   public static final MCMeta c_time_zone_META = createCommonMeta("c_time_zone", M_META.TIME_ZONE);
/*  63 */   public static final MCMeta call_pg_id_META = createCommonMeta("call_pg_id", M_META.SCREEN_ID);
/*  64 */   public static final MCMeta operation_cd_META = createCommonMeta("operation_cd", M_META.OPERATION_CD);
/*  65 */   public static final MCMeta btn_res_key_META = createCommonMeta("btn_res_key", M_META.RES_KEY);
/*  66 */   public static final MCMeta action_id_META = createCommonMeta("action_id", M_META.ACTION_ID);
/*  67 */   public static final MCMeta srv_req_no_META = createCommonMeta("srv_req_no", M_META.SRV_REQ_NO);
/*  68 */   public static final MCMeta module_id_META = createCommonMeta("module_id", M_META.MODULE_ID);
/*  69 */   public static final MCMeta logic_id_META = createCommonMeta("logic_id", M_META.LOGIC_ID);
/*  70 */   public static final MCMeta ope_id_META = createCommonMeta("ope_id", M_META.OPERATION_ID);
/*  71 */   public static final MCMeta srv_id_META = createCommonMeta("srv_id", M_META.MACHINE);
/*  72 */   public static final MCMeta sid_mode_META = createBooleanMeta("sid_mode");
/*     */   
/*  74 */   protected static final MCRow.ConstMetaList<SessionR> constMetas = new MCRow.ConstMetaList(
/*  75 */       MCConstRow.constMetas, 
/*  76 */       new MCMeta[] { 
/*  77 */         mcf_db_sid_META, 
/*  78 */         user_id_META, 
/*  79 */         co_cd_META, 
/*  80 */         ext_attr1_META, 
/*  81 */         ext_attr2_META, 
/*  82 */         ext_attr3_META, 
/*  83 */         clt_id_META, 
/*  84 */         c_req_no_META, 
/*  85 */         c_req_ts_META, 
/*  86 */         c_locale_META, 
/*  87 */         c_time_zone_META, 
/*  88 */         call_pg_id_META, 
/*  89 */         operation_cd_META, 
/*  90 */         btn_res_key_META, 
/*  91 */         action_id_META, 
/*  92 */         srv_req_no_META, 
/*  93 */         module_id_META, 
/*  94 */         logic_id_META, 
/*  95 */         ope_id_META, 
/*  96 */         srv_id_META, 
/*  97 */         sid_mode_META
/*     */       },
/*  99 */       new String[][] { {}, {} });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   protected static final MCKeyList KEYS = new MCKeyList(
/* 111 */       null, 
/* 112 */       new String[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 120 */   protected static final MCExtMap EXTMAP = new MCExtMap(
/* 121 */       null, new MCExtMap.Entry[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] colnames() {
/* 133 */     return constMetas.toNameArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMeta[] colmetas() {
/* 145 */     return constMetas.toMetaArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 151 */   private static final int offset = constMetas.offset();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCKeyList getKeys() {
/* 157 */     return KEYS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getExtMap(String aGroup) {
/* 164 */     if (aGroup == null) return null; 
/* 165 */     return (Map<String, String>)EXTMAP.get(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCKeyList getKeys(String aGroup) {
/* 172 */     if (aGroup == null) return null; 
/* 173 */     return new MCKeyList(EXTMAP.getKeyList(aGroup));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExtGroups() {
/* 180 */     Set<String> ret = EXTMAP.keySet();
/* 181 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SessionR_FW_A(MCRow.ConstMetaList<? extends SessionR> metas) {
/* 188 */     super(metas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SessionR clone() {
/* 195 */     return (SessionR)super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SessionR createInstance() {
/* 202 */     return (SessionR)super.createInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SessionR getValues(String... names) {
/* 209 */     return (SessionR)super.getValues(names);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String mcf_db_sid() {
/* 215 */     return getConstString(offset + 0, "mcf_db_sid");
/*     */   }
/*     */   
/*     */   public void mcf_db_sid(String value) {
/* 219 */     setConstString(offset + 0, "mcf_db_sid", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String user_id() {
/* 224 */     return getConstString(offset + 1, "user_id");
/*     */   }
/*     */   
/*     */   public void user_id(String value) {
/* 228 */     setConstString(offset + 1, "user_id", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String co_cd() {
/* 233 */     return getConstString(offset + 2, "co_cd");
/*     */   }
/*     */   
/*     */   public void co_cd(String value) {
/* 237 */     setConstString(offset + 2, "co_cd", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String ext_attr1() {
/* 242 */     return getConstString(offset + 3, "ext_attr1");
/*     */   }
/*     */   
/*     */   public void ext_attr1(String value) {
/* 246 */     setConstString(offset + 3, "ext_attr1", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String ext_attr2() {
/* 251 */     return getConstString(offset + 4, "ext_attr2");
/*     */   }
/*     */   
/*     */   public void ext_attr2(String value) {
/* 255 */     setConstString(offset + 4, "ext_attr2", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String ext_attr3() {
/* 260 */     return getConstString(offset + 5, "ext_attr3");
/*     */   }
/*     */   
/*     */   public void ext_attr3(String value) {
/* 264 */     setConstString(offset + 5, "ext_attr3", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String clt_id() {
/* 269 */     return getConstString(offset + 6, "clt_id");
/*     */   }
/*     */   
/*     */   public void clt_id(String value) {
/* 273 */     setConstString(offset + 6, "clt_id", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String c_req_no() {
/* 278 */     return getConstString(offset + 7, "c_req_no");
/*     */   }
/*     */   
/*     */   public void c_req_no(String value) {
/* 282 */     setConstString(offset + 7, "c_req_no", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCTimestamp c_req_ts() {
/* 287 */     return getConstTimestamp(offset + 8, "c_req_ts");
/*     */   }
/*     */   
/*     */   public void c_req_ts(MCTimestamp value) {
/* 291 */     setConstTimestamp(offset + 8, "c_req_ts", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String c_locale() {
/* 296 */     return getConstString(offset + 9, "c_locale");
/*     */   }
/*     */   
/*     */   public void c_locale(String value) {
/* 300 */     setConstString(offset + 9, "c_locale", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String c_time_zone() {
/* 305 */     return getConstString(offset + 10, "c_time_zone");
/*     */   }
/*     */   
/*     */   public void c_time_zone(String value) {
/* 309 */     setConstString(offset + 10, "c_time_zone", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String call_pg_id() {
/* 314 */     return getConstString(offset + 11, "call_pg_id");
/*     */   }
/*     */   
/*     */   public void call_pg_id(String value) {
/* 318 */     setConstString(offset + 11, "call_pg_id", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String operation_cd() {
/* 323 */     return getConstString(offset + 12, "operation_cd");
/*     */   }
/*     */   
/*     */   public void operation_cd(String value) {
/* 327 */     setConstString(offset + 12, "operation_cd", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String btn_res_key() {
/* 332 */     return getConstString(offset + 13, "btn_res_key");
/*     */   }
/*     */   
/*     */   public void btn_res_key(String value) {
/* 336 */     setConstString(offset + 13, "btn_res_key", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String action_id() {
/* 341 */     return getConstString(offset + 14, "action_id");
/*     */   }
/*     */   
/*     */   public void action_id(String value) {
/* 345 */     setConstString(offset + 14, "action_id", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String srv_req_no() {
/* 350 */     return getConstString(offset + 15, "srv_req_no");
/*     */   }
/*     */   
/*     */   public void srv_req_no(String value) {
/* 354 */     setConstString(offset + 15, "srv_req_no", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String module_id() {
/* 359 */     return getConstString(offset + 16, "module_id");
/*     */   }
/*     */   
/*     */   public void module_id(String value) {
/* 363 */     setConstString(offset + 16, "module_id", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String logic_id() {
/* 368 */     return getConstString(offset + 17, "logic_id");
/*     */   }
/*     */   
/*     */   public void logic_id(String value) {
/* 372 */     setConstString(offset + 17, "logic_id", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String ope_id() {
/* 377 */     return getConstString(offset + 18, "ope_id");
/*     */   }
/*     */   
/*     */   public void ope_id(String value) {
/* 381 */     setConstString(offset + 18, "ope_id", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String srv_id() {
/* 386 */     return getConstString(offset + 19, "srv_id");
/*     */   }
/*     */   
/*     */   public void srv_id(String value) {
/* 390 */     setConstString(offset + 19, "srv_id", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean sid_mode() {
/* 395 */     return getConstBoolean(offset + 20, "sid_mode");
/*     */   }
/*     */   
/*     */   public void sid_mode(boolean value) {
/* 399 */     setConstBoolean(offset + 20, "sid_mode", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString(String name) {
/* 404 */     if ("mcf_db_sid".equalsIgnoreCase(name)) {
/* 405 */       return mcf_db_sid();
/*     */     }
/* 407 */     if ("user_id".equalsIgnoreCase(name)) {
/* 408 */       return user_id();
/*     */     }
/* 410 */     if ("co_cd".equalsIgnoreCase(name)) {
/* 411 */       return co_cd();
/*     */     }
/* 413 */     if ("ext_attr1".equalsIgnoreCase(name)) {
/* 414 */       return ext_attr1();
/*     */     }
/* 416 */     if ("ext_attr2".equalsIgnoreCase(name)) {
/* 417 */       return ext_attr2();
/*     */     }
/* 419 */     if ("ext_attr3".equalsIgnoreCase(name)) {
/* 420 */       return ext_attr3();
/*     */     }
/* 422 */     if ("clt_id".equalsIgnoreCase(name)) {
/* 423 */       return clt_id();
/*     */     }
/* 425 */     if ("c_req_no".equalsIgnoreCase(name)) {
/* 426 */       return c_req_no();
/*     */     }
/* 428 */     if ("c_locale".equalsIgnoreCase(name)) {
/* 429 */       return c_locale();
/*     */     }
/* 431 */     if ("c_time_zone".equalsIgnoreCase(name)) {
/* 432 */       return c_time_zone();
/*     */     }
/* 434 */     if ("call_pg_id".equalsIgnoreCase(name)) {
/* 435 */       return call_pg_id();
/*     */     }
/* 437 */     if ("operation_cd".equalsIgnoreCase(name)) {
/* 438 */       return operation_cd();
/*     */     }
/* 440 */     if ("btn_res_key".equalsIgnoreCase(name)) {
/* 441 */       return btn_res_key();
/*     */     }
/* 443 */     if ("action_id".equalsIgnoreCase(name)) {
/* 444 */       return action_id();
/*     */     }
/* 446 */     if ("srv_req_no".equalsIgnoreCase(name)) {
/* 447 */       return srv_req_no();
/*     */     }
/* 449 */     if ("module_id".equalsIgnoreCase(name)) {
/* 450 */       return module_id();
/*     */     }
/* 452 */     if ("logic_id".equalsIgnoreCase(name)) {
/* 453 */       return logic_id();
/*     */     }
/* 455 */     if ("ope_id".equalsIgnoreCase(name)) {
/* 456 */       return ope_id();
/*     */     }
/* 458 */     if ("srv_id".equalsIgnoreCase(name)) {
/* 459 */       return srv_id();
/*     */     }
/* 461 */     return super.getString(name);
/*     */   }
/*     */   public MCTimestamp getTimestamp(String name) {
/* 464 */     if ("c_req_ts".equalsIgnoreCase(name)) {
/* 465 */       return c_req_ts();
/*     */     }
/* 467 */     return super.getTimestamp(name);
/*     */   }
/*     */   public boolean getBoolean(String name) {
/* 470 */     if ("sid_mode".equalsIgnoreCase(name)) {
/* 471 */       return sid_mode();
/*     */     }
/* 473 */     return super.getBoolean(name);
/*     */   }
/*     */   
/*     */   public String getStringNE(String name) {
/* 477 */     if ("mcf_db_sid".equalsIgnoreCase(name)) {
/* 478 */       return mcf_db_sid();
/*     */     }
/* 480 */     if ("user_id".equalsIgnoreCase(name)) {
/* 481 */       return user_id();
/*     */     }
/* 483 */     if ("co_cd".equalsIgnoreCase(name)) {
/* 484 */       return co_cd();
/*     */     }
/* 486 */     if ("ext_attr1".equalsIgnoreCase(name)) {
/* 487 */       return ext_attr1();
/*     */     }
/* 489 */     if ("ext_attr2".equalsIgnoreCase(name)) {
/* 490 */       return ext_attr2();
/*     */     }
/* 492 */     if ("ext_attr3".equalsIgnoreCase(name)) {
/* 493 */       return ext_attr3();
/*     */     }
/* 495 */     if ("clt_id".equalsIgnoreCase(name)) {
/* 496 */       return clt_id();
/*     */     }
/* 498 */     if ("c_req_no".equalsIgnoreCase(name)) {
/* 499 */       return c_req_no();
/*     */     }
/* 501 */     if ("c_locale".equalsIgnoreCase(name)) {
/* 502 */       return c_locale();
/*     */     }
/* 504 */     if ("c_time_zone".equalsIgnoreCase(name)) {
/* 505 */       return c_time_zone();
/*     */     }
/* 507 */     if ("call_pg_id".equalsIgnoreCase(name)) {
/* 508 */       return call_pg_id();
/*     */     }
/* 510 */     if ("operation_cd".equalsIgnoreCase(name)) {
/* 511 */       return operation_cd();
/*     */     }
/* 513 */     if ("btn_res_key".equalsIgnoreCase(name)) {
/* 514 */       return btn_res_key();
/*     */     }
/* 516 */     if ("action_id".equalsIgnoreCase(name)) {
/* 517 */       return action_id();
/*     */     }
/* 519 */     if ("srv_req_no".equalsIgnoreCase(name)) {
/* 520 */       return srv_req_no();
/*     */     }
/* 522 */     if ("module_id".equalsIgnoreCase(name)) {
/* 523 */       return module_id();
/*     */     }
/* 525 */     if ("logic_id".equalsIgnoreCase(name)) {
/* 526 */       return logic_id();
/*     */     }
/* 528 */     if ("ope_id".equalsIgnoreCase(name)) {
/* 529 */       return ope_id();
/*     */     }
/* 531 */     if ("srv_id".equalsIgnoreCase(name)) {
/* 532 */       return srv_id();
/*     */     }
/* 534 */     return super.getStringNE(name);
/*     */   }
/*     */   public MCTimestamp getTimestampNE(String name) {
/* 537 */     if ("c_req_ts".equalsIgnoreCase(name)) {
/* 538 */       return c_req_ts();
/*     */     }
/* 540 */     return super.getTimestampNE(name);
/*     */   }
/*     */   public boolean getBooleanNE(String name) {
/* 543 */     if ("sid_mode".equalsIgnoreCase(name)) {
/* 544 */       return sid_mode();
/*     */     }
/* 546 */     return super.getBooleanNE(name);
/*     */   }
/*     */   
/*     */   public void setString(String name, String value) {
/* 550 */     if ("mcf_db_sid".equalsIgnoreCase(name)) {
/* 551 */       mcf_db_sid(value);
/*     */       return;
/*     */     } 
/* 554 */     if ("user_id".equalsIgnoreCase(name)) {
/* 555 */       user_id(value);
/*     */       return;
/*     */     } 
/* 558 */     if ("co_cd".equalsIgnoreCase(name)) {
/* 559 */       co_cd(value);
/*     */       return;
/*     */     } 
/* 562 */     if ("ext_attr1".equalsIgnoreCase(name)) {
/* 563 */       ext_attr1(value);
/*     */       return;
/*     */     } 
/* 566 */     if ("ext_attr2".equalsIgnoreCase(name)) {
/* 567 */       ext_attr2(value);
/*     */       return;
/*     */     } 
/* 570 */     if ("ext_attr3".equalsIgnoreCase(name)) {
/* 571 */       ext_attr3(value);
/*     */       return;
/*     */     } 
/* 574 */     if ("clt_id".equalsIgnoreCase(name)) {
/* 575 */       clt_id(value);
/*     */       return;
/*     */     } 
/* 578 */     if ("c_req_no".equalsIgnoreCase(name)) {
/* 579 */       c_req_no(value);
/*     */       return;
/*     */     } 
/* 582 */     if ("c_locale".equalsIgnoreCase(name)) {
/* 583 */       c_locale(value);
/*     */       return;
/*     */     } 
/* 586 */     if ("c_time_zone".equalsIgnoreCase(name)) {
/* 587 */       c_time_zone(value);
/*     */       return;
/*     */     } 
/* 590 */     if ("call_pg_id".equalsIgnoreCase(name)) {
/* 591 */       call_pg_id(value);
/*     */       return;
/*     */     } 
/* 594 */     if ("operation_cd".equalsIgnoreCase(name)) {
/* 595 */       operation_cd(value);
/*     */       return;
/*     */     } 
/* 598 */     if ("btn_res_key".equalsIgnoreCase(name)) {
/* 599 */       btn_res_key(value);
/*     */       return;
/*     */     } 
/* 602 */     if ("action_id".equalsIgnoreCase(name)) {
/* 603 */       action_id(value);
/*     */       return;
/*     */     } 
/* 606 */     if ("srv_req_no".equalsIgnoreCase(name)) {
/* 607 */       srv_req_no(value);
/*     */       return;
/*     */     } 
/* 610 */     if ("module_id".equalsIgnoreCase(name)) {
/* 611 */       module_id(value);
/*     */       return;
/*     */     } 
/* 614 */     if ("logic_id".equalsIgnoreCase(name)) {
/* 615 */       logic_id(value);
/*     */       return;
/*     */     } 
/* 618 */     if ("ope_id".equalsIgnoreCase(name)) {
/* 619 */       ope_id(value);
/*     */       return;
/*     */     } 
/* 622 */     if ("srv_id".equalsIgnoreCase(name)) {
/* 623 */       srv_id(value);
/*     */       return;
/*     */     } 
/* 626 */     super.setString(name, value);
/*     */   }
/*     */   public void setTimestamp(String name, MCTimestamp value) {
/* 629 */     if ("c_req_ts".equalsIgnoreCase(name)) {
/* 630 */       c_req_ts(value);
/*     */       return;
/*     */     } 
/* 633 */     super.setTimestamp(name, value);
/*     */   }
/*     */   public void setBoolean(String name, boolean value) {
/* 636 */     if ("sid_mode".equalsIgnoreCase(name)) {
/* 637 */       sid_mode(value);
/*     */       return;
/*     */     } 
/* 640 */     super.setBoolean(name, value);
/*     */   }
/*     */   
/*     */   public void setStringNE(String name, String value) {
/* 644 */     if ("mcf_db_sid".equalsIgnoreCase(name)) {
/* 645 */       mcf_db_sid(value);
/*     */       return;
/*     */     } 
/* 648 */     if ("user_id".equalsIgnoreCase(name)) {
/* 649 */       user_id(value);
/*     */       return;
/*     */     } 
/* 652 */     if ("co_cd".equalsIgnoreCase(name)) {
/* 653 */       co_cd(value);
/*     */       return;
/*     */     } 
/* 656 */     if ("ext_attr1".equalsIgnoreCase(name)) {
/* 657 */       ext_attr1(value);
/*     */       return;
/*     */     } 
/* 660 */     if ("ext_attr2".equalsIgnoreCase(name)) {
/* 661 */       ext_attr2(value);
/*     */       return;
/*     */     } 
/* 664 */     if ("ext_attr3".equalsIgnoreCase(name)) {
/* 665 */       ext_attr3(value);
/*     */       return;
/*     */     } 
/* 668 */     if ("clt_id".equalsIgnoreCase(name)) {
/* 669 */       clt_id(value);
/*     */       return;
/*     */     } 
/* 672 */     if ("c_req_no".equalsIgnoreCase(name)) {
/* 673 */       c_req_no(value);
/*     */       return;
/*     */     } 
/* 676 */     if ("c_locale".equalsIgnoreCase(name)) {
/* 677 */       c_locale(value);
/*     */       return;
/*     */     } 
/* 680 */     if ("c_time_zone".equalsIgnoreCase(name)) {
/* 681 */       c_time_zone(value);
/*     */       return;
/*     */     } 
/* 684 */     if ("call_pg_id".equalsIgnoreCase(name)) {
/* 685 */       call_pg_id(value);
/*     */       return;
/*     */     } 
/* 688 */     if ("operation_cd".equalsIgnoreCase(name)) {
/* 689 */       operation_cd(value);
/*     */       return;
/*     */     } 
/* 692 */     if ("btn_res_key".equalsIgnoreCase(name)) {
/* 693 */       btn_res_key(value);
/*     */       return;
/*     */     } 
/* 696 */     if ("action_id".equalsIgnoreCase(name)) {
/* 697 */       action_id(value);
/*     */       return;
/*     */     } 
/* 700 */     if ("srv_req_no".equalsIgnoreCase(name)) {
/* 701 */       srv_req_no(value);
/*     */       return;
/*     */     } 
/* 704 */     if ("module_id".equalsIgnoreCase(name)) {
/* 705 */       module_id(value);
/*     */       return;
/*     */     } 
/* 708 */     if ("logic_id".equalsIgnoreCase(name)) {
/* 709 */       logic_id(value);
/*     */       return;
/*     */     } 
/* 712 */     if ("ope_id".equalsIgnoreCase(name)) {
/* 713 */       ope_id(value);
/*     */       return;
/*     */     } 
/* 716 */     if ("srv_id".equalsIgnoreCase(name)) {
/* 717 */       srv_id(value);
/*     */       return;
/*     */     } 
/* 720 */     super.setStringNE(name, value);
/*     */   }
/*     */   public void setTimestampNE(String name, MCTimestamp value) {
/* 723 */     if ("c_req_ts".equalsIgnoreCase(name)) {
/* 724 */       c_req_ts(value);
/*     */       return;
/*     */     } 
/* 727 */     super.setTimestampNE(name, value);
/*     */   }
/*     */   public void setBooleanNE(String name, boolean value) {
/* 730 */     if ("sid_mode".equalsIgnoreCase(name)) {
/* 731 */       sid_mode(value);
/*     */       return;
/*     */     } 
/* 734 */     super.setBooleanNE(name, value);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\requester\dbsession\SessionR_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */