/*    */ package mcframe.clientCore.requester.dbsession;
/*    */ 
/*    */ import mcframe.clientCore.requester.MCCaller;
/*    */ import mcframe.commonCore.container.MCContainer;
/*    */ import mcframe.commonCore.lang.MCTimestamp;
/*    */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*    */ import mcframe.commonCore.notice.MCException;
/*    */ import mcframe.commonCore.notice.MCMessageLevel;
/*    */ import mcframe.commonCore.param.MCParam;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCDBSessionAgentClient
/*    */   extends MCCaller
/*    */ {
/*    */   public MCDBSessionAgentClient(MCParam p) {
/* 28 */     super(p);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void dbSessionKill(String user_id, String co_cd, String ext_attr1, String ext_attr2, String ext_attr3, String c_req_no, MCTimestamp c_req_ts, String module_id, String logic_id, String ope_id) {
/* 50 */     MCDBSessionAgentClient agent = new MCDBSessionAgentClient(new MCParam(
/* 51 */           PDef.FC_FCBCL0000_SessionKill_INFO));
/* 52 */     SessionR up = SessionR.create();
/* 53 */     up.user_id(user_id);
/* 54 */     up.co_cd(co_cd);
/* 55 */     up.ext_attr1(ext_attr1);
/* 56 */     up.ext_attr2(ext_attr2);
/* 57 */     up.ext_attr3(ext_attr3);
/* 58 */     up.c_req_no(c_req_no);
/* 59 */     up.c_req_ts(c_req_ts);
/* 60 */     up.module_id(module_id);
/* 61 */     up.logic_id(logic_id);
/* 62 */     up.ope_id(ope_id);
/* 63 */     agent.param().addUpBlock((MCContainer)up);
/*    */     try {
/* 65 */       agent.exec();
/*    */     }
/* 67 */     catch (MCException ex) {
/*    */       
/* 69 */       MCMessageLevel l = ex.getLevel();
/* 70 */       if ((l != MCMessageLevel.FATAL && l != MCMessageLevel.ERROR) || 
/* 71 */         ex.getID().equals(Core_Msg_FW_A.FCBCC0169)) {
/* 72 */         throw ex;
/*    */       }
/* 74 */       throw new MCException(ex, Core_Msg_FW_A.FCBAC0407, new Object[0]);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\requester\dbsession\MCDBSessionAgentClient.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */