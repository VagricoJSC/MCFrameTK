/*    */ package mcframe.clientCore.requester.dbsession;
/*    */ 
/*    */ import mcframe.commonCore.param.MCBlockDef;
/*    */ import mcframe.commonCore.param.MCContainerDef;
/*    */ import mcframe.commonCore.param.MCDef;
/*    */ import mcframe.commonCore.param.MCGeneralContainerDef;
/*    */ import mcframe.commonCore.param.MCItemDef;
/*    */ import mcframe.commonCore.param.MCOperationInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PDef_FW_A
/*    */   extends MCDef
/*    */ {
/*    */   public MCContainerDef getCustomDef(String id) {
/* 19 */     if (id == null) {
/* 20 */       return null;
/*    */     }
/*    */     
/* 23 */     if (id.equals("FC.FCBCL0000.SessionKill.UP.BLOCK0")) {
/* 24 */       return FC_FCBCL0000_SessionKill_UP_BLOCK0();
/*    */     }
/*    */ 
/*    */     
/* 28 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 34 */   static final MCOperationInfo FC_FCBCL0000_SessionKill_INFO = new MCOperationInfo("FC", "FCBCL0000", "SessionKill", "000000", new PDef());
/*    */ 
/*    */   
/*    */   public static MCContainerDef FC_FCBCL0000_SessionKill_UP_BLOCK0() {
/* 38 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBCL0000", "SessionKill", 
/* 39 */         new MCItemDef[] { 
/* 40 */           MCItemDef.create("mcf_db_sid", "mcf_db_sid"), 
/* 41 */           MCItemDef.create("user_id", "user_id"), 
/* 42 */           MCItemDef.create("co_cd", "co_cd"), 
/* 43 */           MCItemDef.create("ext_attr1", "ext_attr1"), 
/* 44 */           MCItemDef.create("ext_attr2", "ext_attr2"), 
/* 45 */           MCItemDef.create("ext_attr3", "ext_attr3"), 
/* 46 */           MCItemDef.create("clt_id", "clt_id"), 
/* 47 */           MCItemDef.create("c_req_no", "c_req_no"), 
/* 48 */           MCItemDef.create("c_req_ts", "c_req_ts"), 
/* 49 */           MCItemDef.create("c_locale", "c_locale"), 
/* 50 */           MCItemDef.create("c_time_zone", "c_time_zone"), 
/* 51 */           MCItemDef.create("call_pg_id", "call_pg_id"), 
/* 52 */           MCItemDef.create("operation_cd", "operation_cd"), 
/* 53 */           MCItemDef.create("btn_res_key", "btn_res_key"), 
/* 54 */           MCItemDef.create("action_id", "action_id"), 
/* 55 */           MCItemDef.create("srv_req_no", "srv_req_no"), 
/* 56 */           MCItemDef.create("module_id", "module_id"), 
/* 57 */           MCItemDef.create("logic_id", "logic_id"), 
/* 58 */           MCItemDef.create("ope_id", "ope_id"), 
/* 59 */           MCItemDef.create("srv_id", "srv_id"), 
/* 60 */           MCItemDef.create("sid_mode", "sid_mode")
/*    */ 
/*    */         
/* 63 */         }MCBlockDef.create("Session"));
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\requester\dbsession\PDef_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */