/*     */ package mcframe.clientCore.requester;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.net.URL;
/*     */ import mcframe.clientCore.requester.download.PDef;
/*     */ import mcframe.clientCore.resource.MCConfig;
/*     */ import mcframe.clientCore.sys.MCSys;
/*     */ import mcframe.commonCore.container.MCContainer;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCBinary;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.param.MCDef;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.commonCore.requester.MCControlRequester;
/*     */ import mcframe.commonCore.requester.MCDownloadUtil;
/*     */ import mcframe.commonCore.requester.MCParamHeaderUtil;
/*     */ import mcframe.commonCore.util.MCFileUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCDownloader
/*     */ {
/*     */   private final URL _url;
/*     */   private final String _path;
/*     */   private final MCBinary _bin;
/*     */   
/*     */   private static MCControlRequester getRequester() {
/*  42 */     return MCRequesterFactory.createRequester();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final File getDownloadDir() {
/*  64 */     String dirstr = getDownloadPath();
/*  65 */     File dir = new File(dirstr);
/*  66 */     MCFileUtil.mkDir(dir);
/*  67 */     return dir;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getDownloadPath() {
/*  82 */     return MCConfig.client.getString("net.download.dir", 
/*  83 */         MCDownloadUtil.downloadPath());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final URL getBinaryURL(MCBinary bin) {
/*  99 */     if (bin == null) {
/* 100 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 106 */       return !bin.isLocalFile() ? 
/*     */         
/* 108 */         getRemoteBinaryURL(bin, null, null) : 
/*     */         
/* 110 */         getLocalBinaryURL(bin);
/* 111 */     } catch (Exception ex) {
/*     */       
/* 113 */       throw new MCException(ex, Core_Msg_FW_A.FCBGC0081, new Object[] { bin });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static URL getLocalBinaryURL(MCBinary bin) {
/* 127 */     return MCFileUtil.fileToURL(bin.toFile());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static URL getRemoteBinaryURL(MCBinary bin, File dir, String name) {
/* 164 */     boolean cache = (dir == null && name == null);
/*     */     
/* 166 */     if (dir == null)
/*     */     {
/* 168 */       dir = getDownloadDir();
/*     */     }
/*     */     
/* 171 */     URL url = MCLangProxy.proxy.binDblinkURL(bin);
/* 172 */     if (url != null) {
/*     */       
/* 174 */       File url_f = MCFileUtil.URLToFile(url);
/* 175 */       if (url_f.exists()) {
/*     */         
/* 177 */         if (name == null) {
/* 178 */           name = url_f.getName();
/*     */         }
/* 180 */         File file1 = new File(dir, name);
/*     */ 
/*     */         
/* 183 */         MCLog.write(Core_Msg_FW_A.FCBGC0161, new Object[] { "bin cache", 
/* 184 */               url_f.getAbsolutePath(), dir.getAbsolutePath() });
/* 185 */         MCFileUtil.copy(url_f, file1);
/* 186 */         MCLog.write(Core_Msg_FW_A.FCBGC0162, new Object[] { file1.getAbsolutePath() });
/*     */         
/* 188 */         return MCFileUtil.fileToURL(file1);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 194 */     if (bin.isDBFile()) {
/* 195 */       MCLog.write(Core_Msg_FW_A.FCBGC0104, new Object[] { "bin db", 
/* 196 */             String.valueOf(bin.toDBPointer()), dir.getAbsolutePath() });
/*     */     }
/* 198 */     else if (bin.isRemoteFile()) {
/* 199 */       MCLog.write(Core_Msg_FW_A.FCBGC0104, new Object[] { "bin remote", 
/* 200 */             bin.toRemotePath(), dir.getAbsolutePath() });
/*     */     }
/* 202 */     else if (bin.isLocalFile()) {
/* 203 */       MCLog.write(Core_Msg_FW_A.FCBGC0104, new Object[] { "bin local", 
/* 204 */             bin.toFile().getAbsolutePath(), dir.getAbsolutePath() });
/*     */     } 
/* 206 */     MCParam param = createMCBinDownloadParam(bin);
/* 207 */     File file = getRequester().download(param, dir, name);
/* 208 */     MCLog.write(Core_Msg_FW_A.FCBGC0105, new Object[] { file.getAbsolutePath() });
/*     */     
/* 210 */     url = MCFileUtil.fileToURL(file);
/* 211 */     if (cache)
/*     */     {
/* 213 */       MCLangProxy.proxy.binDblinkURL(bin, url);
/*     */     }
/* 215 */     return url;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCDownloader(String path) {
/* 263 */     if (path == null) {
/* 264 */       throw new MCException(Core_Msg_FW_A.FCBGC0080, new Object[0]);
/*     */     }
/* 266 */     this._path = path;
/* 267 */     this._url = null;
/* 268 */     this._bin = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCDownloader(URL url) {
/* 280 */     if (url == null) {
/* 281 */       throw new MCException(Core_Msg_FW_A.FCBGC0080, new Object[0]);
/*     */     }
/* 283 */     this._url = url;
/* 284 */     this._path = null;
/* 285 */     this._bin = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCDownloader(MCBinary bin) {
/* 299 */     if (bin == null) {
/* 300 */       throw new MCException(Core_Msg_FW_A.FCBGC0080, new Object[0]);
/*     */     }
/* 302 */     this._bin = bin;
/* 303 */     this._url = null;
/* 304 */     this._path = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final File exec(File dir, String name) {
/* 326 */     if (dir == null) {
/* 327 */       dir = getDownloadDir();
/*     */     }
/* 329 */     if (this._path != null)
/*     */     {
/* 331 */       return pathExec(dir, name);
/*     */     }
/* 333 */     if (this._bin != null)
/*     */     {
/* 335 */       return binExec(dir, name);
/*     */     }
/*     */     
/* 338 */     return urlExec(dir, name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private File pathExec(File dir, String name) {
/*     */     try {
/* 361 */       MCParam param = createFileDownloadParam(this._path);
/*     */ 
/*     */       
/* 364 */       MCLog.write(Core_Msg_FW_A.FCBGC0104, new Object[] { "server", this._path, dir.getAbsolutePath() });
/* 365 */       File file = getRequester().download(param, dir, name);
/* 366 */       MCLog.write(Core_Msg_FW_A.FCBGC0105, new Object[] { file.getAbsolutePath() });
/*     */       
/* 368 */       return file;
/* 369 */     } catch (Exception ex) {
/*     */       
/* 371 */       throw downloadError(ex, this._path, dir, name);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private File urlExec(File dir, String name) {
/* 394 */     String protocol = this._url.getProtocol();
/*     */     try {
/* 396 */       if (protocol.equalsIgnoreCase("file")) {
/*     */         
/* 398 */         if (name == null) {
/* 399 */           File src = new File(this._url.toURI());
/* 400 */           name = src.getName();
/*     */         } 
/* 402 */         File file1 = new File(dir, name);
/*     */ 
/*     */         
/* 405 */         MCLog.write(Core_Msg_FW_A.FCBGC0104, new Object[] { "url", this._url.toString(), dir.getAbsolutePath() });
/* 406 */         MCFileUtil.copy(MCFileUtil.URLToFile(this._url), file1);
/* 407 */         MCLog.write(Core_Msg_FW_A.FCBGC0105, new Object[] { file1.getAbsolutePath() });
/*     */         
/* 409 */         return file1;
/*     */       } 
/*     */ 
/*     */       
/* 413 */       MCClientRequester req = 
/* 414 */         (MCClientRequester)MCRequesterFactory.createRequester();
/*     */ 
/*     */       
/* 417 */       MCLog.write(Core_Msg_FW_A.FCBGC0104, new Object[] { "url", this._url.toString(), dir.getAbsolutePath() });
/* 418 */       File file = req.download(this._url, dir, name);
/* 419 */       MCLog.write(Core_Msg_FW_A.FCBGC0105, new Object[] { file.getAbsolutePath() });
/*     */       
/* 421 */       return file;
/*     */     }
/* 423 */     catch (Exception ex) {
/*     */       
/* 425 */       throw downloadError(ex, this._url, dir, name);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private File binExec(File dir, String name) {
/*     */     try {
/* 446 */       if (!this._bin.isLocalFile())
/*     */       {
/* 448 */         return MCFileUtil.URLToFile(getRemoteBinaryURL(this._bin, dir, name));
/*     */       }
/*     */       
/* 451 */       File local = this._bin.toFile();
/* 452 */       File to = new File(dir, (name != null) ? name : local.getName());
/*     */ 
/*     */       
/* 455 */       MCLog.write(Core_Msg_FW_A.FCBGC0104, new Object[] { "bin local", 
/* 456 */             local.getAbsolutePath(), dir.getAbsolutePath() });
/* 457 */       MCFileUtil.copy(local, to);
/* 458 */       MCLog.write(Core_Msg_FW_A.FCBGC0105, new Object[] { to.getAbsolutePath() });
/*     */       
/* 460 */       return to;
/* 461 */     } catch (Exception ex) {
/*     */       
/* 463 */       throw downloadError(ex, this._bin, dir, name);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCException downloadError(Throwable cause, Object src, File dir, String name) {
/* 481 */     return new MCException(cause, Core_Msg_FW_A.FCBGC0079, new Object[] {
/* 482 */           src, 
/* 483 */           dir, 
/* 484 */           (name != null) ? name : ""
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final MCParam createMCBinDownloadParam(MCBinary bin) {
/* 502 */     MCRow cond = MCRow.create();
/* 503 */     cond.setBinaryNE("bin", bin);
/*     */ 
/*     */     
/* 506 */     MCParam param = createDownloadParam(
/* 507 */         "MCBinDl", "000000");
/* 508 */     param.getContainerParam().addUpBlock((MCContainer)cond);
/* 509 */     return param;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final MCParam createFileDownloadParam(String path) {
/* 522 */     MCRow cond = MCRow.create();
/* 523 */     cond.setStringNE("path", path);
/*     */ 
/*     */     
/* 526 */     MCParam param = createDownloadParam(
/* 527 */         "FileDl", "000000");
/* 528 */     param.getContainerParam().addUpBlock((MCContainer)cond);
/* 529 */     return param;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static MCParam createDownloadParam(String opeid, String version) {
/* 542 */     MCParam param = new MCParam("FC", 
/* 543 */         "FCBGL0020", opeid, version);
/* 544 */     param.setLimitDLSize(MCNumber.valueOf(-1));
/* 545 */     param.setDef((MCDef)new PDef());
/*     */ 
/*     */     
/* 548 */     MCParamHeaderUtil.toUpHeader(
/* 549 */         param, 
/* 550 */         MCSys.user.clientID(), 
/* 551 */         MCSys.nextRequestNum(), 
/* 552 */         MCConfig.client.getNumber("net.response.limitSize"));
/*     */     
/* 554 */     return param;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\requester\MCDownloader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */