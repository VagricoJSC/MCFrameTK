/*     */ package mcframe.clientCore.requester.decorator;
/*     */ 
/*     */ import mcframe.clientCore.requester.MCCaller;
/*     */ import mcframe.clientCore.requester.MCRequesterFactory;
/*     */ import mcframe.commonCore.container.MCContainer;
/*     */ import mcframe.commonCore.lang.MCTimestamp;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.commonCore.param.MCParamHandler;
/*     */ import mcframe.commonCore.param.MCUploadFileParam;
/*     */ import mcframe.commonCore.pio.MCDPReaderFactory;
/*     */ import mcframe.commonCore.pio.MCP2TBodyReader;
/*     */ import mcframe.commonCore.pio.MCP2THeaderReader;
/*     */ import mcframe.commonCore.pio.MCT2PBodyReader;
/*     */ import mcframe.commonCore.pio.MCT2PHeaderReader;
/*     */ import mcframe.commonCore.pio.util.MCDPFormat;
/*     */ import mcframe.commonCore.pio.util.MCDPToken;
/*     */ import mcframe.commonCore.pio.util.MCParseTypeUtil;
/*     */ import mcframe.commonCore.requester.MCControlRequester;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCDecoratorCaller
/*     */   extends MCCaller
/*     */ {
/*     */   public final MCParam tar;
/*  38 */   public final DecR up0 = DecR.create();
/*  39 */   public final DecR down0 = DecR.create();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  47 */   private MCParamHandler _handler = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCDecoratorCaller(MCParam prnt, MCParam chd) {
/*  59 */     super(prnt);
/*  60 */     param().addUpBlock((MCContainer)this.up0);
/*  61 */     param().addDownBlock((MCContainer)this.down0);
/*  62 */     this.tar = chd;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void request() {
/*  67 */     MCControlRequester requester = MCRequesterFactory.createRequester();
/*     */     
/*  69 */     MCUploadFileParam ufp = this.tar.getUploadFileParam();
/*  70 */     param().getUploadFileParam().addAll(ufp);
/*  71 */     requester.request(param());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setParamHandler(MCParamHandler handler) {
/*  82 */     this._handler = handler;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void call() {
/*  88 */     call(this._handler);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void call(MCParamHandler handler) {
/*  93 */     decorateUp();
/*     */     
/*  95 */     parseUp();
/*     */     
/*  97 */     beforeCall();
/*     */     
/*  99 */     if (strictCall()) {
/*     */       
/* 101 */       afterCall();
/*     */       
/* 103 */       decorateDown();
/*     */       
/* 105 */       parseDown();
/*     */       
/* 107 */       handleDecErr(handler);
/*     */       
/* 109 */       throwDecPrmErr();
/*     */       
/* 111 */       reqTm2decPrm();
/*     */       
/* 113 */       cmtTm2decPrm();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean strictCall() {
/* 127 */     callMain();
/* 128 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void callMain() {
/* 138 */     super.call(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void decorateUp() {
/* 150 */     setHdrInfo(this.tar);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void parseUp() {
/* 162 */     MCDPFormat format = MCDPFormat.forClient();
/* 163 */     MCP2THeaderReader hr = MCDPReaderFactory.upHeaderToText(format);
/* 164 */     String hdr = hr.parse(this.tar);
/* 165 */     MCP2TBodyReader br = 
/* 166 */       MCDPReaderFactory.upBodyToText(
/* 167 */         format, MCParseTypeUtil.getParseType(this.tar));
/* 168 */     String bdy = br.parse(this.tar);
/* 169 */     this.up0.denbun(String.valueOf(hdr) + bdy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void beforeCall() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void afterCall() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void parseDown() {
/* 192 */     MCDPToken tkn = MCDPToken.create(this.down0.denbun());
/* 193 */     MCDPFormat fmt = tkn.getFormat();
/* 194 */     MCT2PHeaderReader hr = MCDPReaderFactory.downHeaderToParam(fmt);
/* 195 */     hr.parse(tkn, this.tar);
/* 196 */     MCT2PBodyReader br = MCDPReaderFactory.downBodyToParam(
/* 197 */         fmt, MCParseTypeUtil.getParseType(this.tar));
/* 198 */     br.parse(tkn, this.tar);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void decorateDown() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handleDecErr(MCParamHandler h) {
/* 214 */     if (this.tar != null) {
/* 215 */       handleErr(this.tar, h);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void throwDecPrmErr() {
/* 228 */     if (this.tar != null) {
/* 229 */       throwErr(this.tar);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void reqTm2decPrm() {
/* 240 */     if (this.tar != null) {
/* 241 */       MCTimestamp d = param().getRequestTime();
/* 242 */       setRequestTime(this.tar, d);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void cmtTm2decPrm() {
/* 253 */     if (this.tar != null) {
/* 254 */       MCTimestamp d = param().getCommitTime();
/* 255 */       setCommitTime(this.tar, d);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\requester\decorator\MCDecoratorCaller.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */