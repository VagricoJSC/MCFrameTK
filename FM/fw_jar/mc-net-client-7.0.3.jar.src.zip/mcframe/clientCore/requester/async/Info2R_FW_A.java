/*     */ package mcframe.clientCore.requester.async;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.clientCore.container.MCKeyList;
/*     */ import mcframe.commonCore.container.MCExtMap;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCBinary;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class Info2R_FW_A
/*     */   extends MCConstRow
/*     */ {
/*     */   public static final String $scr_container = "scr_container";
/*  36 */   public static final MCMeta scr_container_META = createBinaryMeta("scr_container");
/*     */   
/*  38 */   protected static final MCRow.ConstMetaList<Info2R> constMetas = new MCRow.ConstMetaList(
/*  39 */       MCConstRow.constMetas, 
/*  40 */       new MCMeta[] {
/*  41 */         scr_container_META
/*     */       },
/*  43 */       new String[][] { {}, {} });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   protected static final MCKeyList KEYS = new MCKeyList(
/*  55 */       null, 
/*  56 */       new String[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   protected static final MCExtMap EXTMAP = new MCExtMap(
/*  65 */       null, new MCExtMap.Entry[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] colnames() {
/*  77 */     return constMetas.toNameArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMeta[] colmetas() {
/*  89 */     return constMetas.toMetaArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   private static final int offset = constMetas.offset();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCKeyList getKeys() {
/* 101 */     return KEYS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getExtMap(String aGroup) {
/* 108 */     if (aGroup == null) return null; 
/* 109 */     return (Map<String, String>)EXTMAP.get(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCKeyList getKeys(String aGroup) {
/* 116 */     if (aGroup == null) return null; 
/* 117 */     return new MCKeyList(EXTMAP.getKeyList(aGroup));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExtGroups() {
/* 124 */     Set<String> ret = EXTMAP.keySet();
/* 125 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Info2R_FW_A(MCRow.ConstMetaList<? extends Info2R> metas) {
/* 132 */     super(metas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Info2R clone() {
/* 139 */     return (Info2R)super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Info2R createInstance() {
/* 146 */     return (Info2R)super.createInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Info2R getValues(String... names) {
/* 153 */     return (Info2R)super.getValues(names);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCBinary scr_container() {
/* 163 */     return getConstBinary(offset + 0, "scr_container");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void scr_container(MCBinary value) {
/* 171 */     setConstBinary(offset + 0, "scr_container", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCBinary getBinary(String name) {
/* 176 */     if ("scr_container".equalsIgnoreCase(name)) {
/* 177 */       return scr_container();
/*     */     }
/* 179 */     return super.getBinary(name);
/*     */   }
/*     */   
/*     */   public MCBinary getBinaryNE(String name) {
/* 183 */     if ("scr_container".equalsIgnoreCase(name)) {
/* 184 */       return scr_container();
/*     */     }
/* 186 */     return super.getBinaryNE(name);
/*     */   }
/*     */   
/*     */   public void setBinary(String name, MCBinary value) {
/* 190 */     if ("scr_container".equalsIgnoreCase(name)) {
/* 191 */       scr_container(value);
/*     */       return;
/*     */     } 
/* 194 */     super.setBinary(name, value);
/*     */   }
/*     */   
/*     */   public void setBinaryNE(String name, MCBinary value) {
/* 198 */     if ("scr_container".equalsIgnoreCase(name)) {
/* 199 */       scr_container(value);
/*     */       return;
/*     */     } 
/* 202 */     super.setBinaryNE(name, value);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\requester\async\Info2R_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */