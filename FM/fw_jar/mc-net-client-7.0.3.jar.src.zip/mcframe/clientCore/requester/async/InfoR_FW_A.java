/*     */ package mcframe.clientCore.requester.async;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.clientCore.container.MCKeyList;
/*     */ import mcframe.commonCore.container.MCExtMap;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class InfoR_FW_A
/*     */   extends MCConstRow
/*     */ {
/*     */   public static final String $reqid = "reqid";
/*     */   public static final String $push_msg = "push_msg";
/*  41 */   public static final MCMeta reqid_META = createStringMeta("reqid");
/*  42 */   public static final MCMeta push_msg_META = createStringMeta("push_msg");
/*     */   
/*  44 */   protected static final MCRow.ConstMetaList<InfoR> constMetas = new MCRow.ConstMetaList(
/*  45 */       MCConstRow.constMetas, 
/*  46 */       new MCMeta[] {
/*  47 */         reqid_META, 
/*  48 */         push_msg_META
/*     */       },
/*  50 */       new String[][] { {}, {} });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   protected static final MCKeyList KEYS = new MCKeyList(
/*  62 */       null, 
/*  63 */       new String[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   protected static final MCExtMap EXTMAP = new MCExtMap(
/*  72 */       null, new MCExtMap.Entry[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] colnames() {
/*  84 */     return constMetas.toNameArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMeta[] colmetas() {
/*  96 */     return constMetas.toMetaArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   private static final int offset = constMetas.offset();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCKeyList getKeys() {
/* 108 */     return KEYS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getExtMap(String aGroup) {
/* 115 */     if (aGroup == null) return null; 
/* 116 */     return (Map<String, String>)EXTMAP.get(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCKeyList getKeys(String aGroup) {
/* 123 */     if (aGroup == null) return null; 
/* 124 */     return new MCKeyList(EXTMAP.getKeyList(aGroup));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExtGroups() {
/* 131 */     Set<String> ret = EXTMAP.keySet();
/* 132 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected InfoR_FW_A(MCRow.ConstMetaList<? extends InfoR> metas) {
/* 139 */     super(metas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InfoR clone() {
/* 146 */     return (InfoR)super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InfoR createInstance() {
/* 153 */     return (InfoR)super.createInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InfoR getValues(String... names) {
/* 160 */     return (InfoR)super.getValues(names);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String reqid() {
/* 170 */     return getConstString(offset + 0, "reqid");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reqid(String value) {
/* 178 */     setConstString(offset + 0, "reqid", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String push_msg() {
/* 187 */     return getConstString(offset + 1, "push_msg");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void push_msg(String value) {
/* 195 */     setConstString(offset + 1, "push_msg", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString(String name) {
/* 200 */     if ("reqid".equalsIgnoreCase(name)) {
/* 201 */       return reqid();
/*     */     }
/* 203 */     if ("push_msg".equalsIgnoreCase(name)) {
/* 204 */       return push_msg();
/*     */     }
/* 206 */     return super.getString(name);
/*     */   }
/*     */   
/*     */   public String getStringNE(String name) {
/* 210 */     if ("reqid".equalsIgnoreCase(name)) {
/* 211 */       return reqid();
/*     */     }
/* 213 */     if ("push_msg".equalsIgnoreCase(name)) {
/* 214 */       return push_msg();
/*     */     }
/* 216 */     return super.getStringNE(name);
/*     */   }
/*     */   
/*     */   public void setString(String name, String value) {
/* 220 */     if ("reqid".equalsIgnoreCase(name)) {
/* 221 */       reqid(value);
/*     */       return;
/*     */     } 
/* 224 */     if ("push_msg".equalsIgnoreCase(name)) {
/* 225 */       push_msg(value);
/*     */       return;
/*     */     } 
/* 228 */     super.setString(name, value);
/*     */   }
/*     */   
/*     */   public void setStringNE(String name, String value) {
/* 232 */     if ("reqid".equalsIgnoreCase(name)) {
/* 233 */       reqid(value);
/*     */       return;
/*     */     } 
/* 236 */     if ("push_msg".equalsIgnoreCase(name)) {
/* 237 */       push_msg(value);
/*     */       return;
/*     */     } 
/* 240 */     super.setStringNE(name, value);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\requester\async\InfoR_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */