/*    */ package mcframe.clientCore.requester.async;
/*    */ 
/*    */ import mcframe.commonCore.param.MCBlockDef;
/*    */ import mcframe.commonCore.param.MCContainerDef;
/*    */ import mcframe.commonCore.param.MCDef;
/*    */ import mcframe.commonCore.param.MCGeneralContainerDef;
/*    */ import mcframe.commonCore.param.MCItemDef;
/*    */ import mcframe.commonCore.param.MCOperationInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PDef_FW_A
/*    */   extends MCDef
/*    */ {
/*    */   public MCContainerDef getCustomDef(String id) {
/* 19 */     if (id == null) {
/* 20 */       return null;
/*    */     }
/*    */     
/* 23 */     if (id.equals("FC.FCBGL4000.CallAsync.UP.BLOCK0")) {
/* 24 */       return FC_FCBGL4000_CallAsync_UP_BLOCK0();
/*    */     }
/* 26 */     if (id.equals("FC.FCBGL4000.CallAsync.UP.BLOCK1")) {
/* 27 */       return FC_FCBGL4000_CallAsync_UP_BLOCK1();
/*    */     }
/* 29 */     if (id.equals("FC.FCBGL4000.CallAsync.UP.BLOCK2")) {
/* 30 */       return FC_FCBGL4000_CallAsync_UP_BLOCK2();
/*    */     }
/* 32 */     if (id.equals("FC.FCBGL4000.CallAsync.DOWN.BLOCK0")) {
/* 33 */       return FC_FCBGL4000_CallAsync_DOWN_BLOCK0();
/*    */     }
/* 35 */     if (id.equals("FC.FCBGL4000.CallAsync.DOWN.BLOCK1")) {
/* 36 */       return FC_FCBGL4000_CallAsync_DOWN_BLOCK1();
/*    */     }
/*    */ 
/*    */     
/* 40 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 46 */   static final MCOperationInfo FC_FCBGL4000_CallAsync_INFO = new MCOperationInfo("FC", "FCBGL4000", "CallAsync", "000000", new PDef());
/*    */ 
/*    */   
/*    */   public static MCContainerDef FC_FCBGL4000_CallAsync_UP_BLOCK0() {
/* 50 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL4000", "CallAsync", 
/* 51 */         new MCItemDef[] {
/* 52 */           MCItemDef.create("denbun", "denbun")
/*    */ 
/*    */         
/* 55 */         }MCBlockDef.create("Dec"));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static MCContainerDef FC_FCBGL4000_CallAsync_UP_BLOCK1() {
/* 61 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL4000", "CallAsync", 
/* 62 */         new MCItemDef[] {
/* 63 */           MCItemDef.create("push_msg", "push_msg")
/*    */ 
/*    */         
/* 66 */         }MCBlockDef.create("Info"));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static MCContainerDef FC_FCBGL4000_CallAsync_UP_BLOCK2() {
/* 72 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL4000", "CallAsync", 
/* 73 */         new MCItemDef[] {
/* 74 */           MCItemDef.create("scr_container", "scr_container")
/*    */ 
/*    */         
/* 77 */         }MCBlockDef.create("Info2"));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static MCContainerDef FC_FCBGL4000_CallAsync_DOWN_BLOCK0() {
/* 84 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL4000", "CallAsync", 
/* 85 */         new MCItemDef[] {
/* 86 */           MCItemDef.create("denbun", "denbun")
/*    */ 
/*    */         
/* 89 */         }MCBlockDef.create("Dec"));
/*    */   }
/*    */ 
/*    */   
/*    */   public static MCContainerDef FC_FCBGL4000_CallAsync_DOWN_BLOCK1() {
/* 94 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL4000", "CallAsync", 
/* 95 */         new MCItemDef[] {
/* 96 */           MCItemDef.create("reqid", "reqid")
/*    */ 
/*    */         
/* 99 */         }MCBlockDef.create("Info"));
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\requester\async\PDef_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */