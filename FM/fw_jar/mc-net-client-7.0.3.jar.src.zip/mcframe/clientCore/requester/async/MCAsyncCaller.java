/*     */ package mcframe.clientCore.requester.async;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.List;
/*     */ import mcframe.clientCore.requester.decorator.MCDecoratorCaller;
/*     */ import mcframe.commonCore.container.MCContainer;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.lang.MCBinary;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCMessage;
/*     */ import mcframe.commonCore.param.MCMessageRowParam;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.commonCore.param.MCParamHandler;
/*     */ import mcframe.commonCore.pio.MCDPReaderFactory;
/*     */ import mcframe.commonCore.pio.MCT2PBodyReader;
/*     */ import mcframe.commonCore.pio.MCT2PHeaderReader;
/*     */ import mcframe.commonCore.pio.util.MCDPFormat;
/*     */ import mcframe.commonCore.pio.util.MCDPToken;
/*     */ import mcframe.commonCore.pio.util.MCDPTokenMCDP;
/*     */ import mcframe.commonCore.pio.util.MCParseTypeUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCAsyncCaller
/*     */   extends MCDecoratorCaller
/*     */ {
/*  41 */   private final InfoR up1 = InfoR.create();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   private final MCList<Info2R> up2 = MCList.create(Info2R.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   private final InfoR down1 = InfoR.create();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCAsyncCaller(MCParam param) {
/*  65 */     this(param, (MCParamHandler)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCAsyncCaller(MCParam param, MCParamHandler handler) {
/*  77 */     this(param, handler, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCAsyncCaller(MCParam param, MCParamHandler handler, String push_msg) {
/*  90 */     this(param, handler, (String)null, (List<File>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCAsyncCaller(MCParam param, MCParamHandler handler, String push_msg, List<File> scr_container) {
/* 105 */     super(new MCParam(PDef.FC_FCBGL4000_CallAsync_INFO), param);
/* 106 */     this.up1.push_msg(push_msg);
/* 107 */     if (scr_container != null && !scr_container.isEmpty()) {
/* 108 */       scr_container.forEach(r -> ((Info2R)this.up2.add()).scr_container(MCBinary.valueOf(r)));
/*     */     }
/* 110 */     param().addUpBlock((MCContainer)this.up1);
/* 111 */     param().addUpBlock((MCContainer)this.up2);
/* 112 */     param().addDownBlock((MCContainer)this.down1);
/* 113 */     setParamHandler(handler);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void parseDown() {
/* 120 */     MCDPTokenMCDP tkn = (MCDPTokenMCDP)MCDPToken.create(this.down0.denbun());
/* 121 */     MCDPFormat fmt = tkn.getFormat();
/* 122 */     MCT2PHeaderReader hr = MCDPReaderFactory.downHeaderToParam(fmt);
/* 123 */     hr.parse((MCDPToken)tkn, this.tar);
/* 124 */     if (tkn.hasNext()) {
/*     */ 
/*     */       
/* 127 */       MCT2PBodyReader br = MCDPReaderFactory.downBodyToParam(fmt, 
/* 128 */           MCParseTypeUtil.getParseType(this.tar));
/* 129 */       br.parse((MCDPToken)tkn, this.tar);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 134 */       MCMessage msg = new MCMessage(Core_Msg_FW_A.FCBGC1200, new Object[] { this.down1.reqid(), this.tar.getModuleId(), 
/* 135 */             this.tar.getLogicId(), this.tar.getOperationId() });
/* 136 */       MCMessageRowParam row = new MCMessageRowParam();
/*     */       
/* 138 */       row.setMsg(msg);
/*     */       
/* 140 */       row.setLevel(String.valueOf(msg.getLevel().getOmission()));
/*     */       
/* 142 */       row.setId(msg.getID()); byte b; int i;
/*     */       String[] arrayOfString;
/* 144 */       for (i = (arrayOfString = msg.getBindArray()).length, b = 0; b < i; ) { String bind = arrayOfString[b];
/* 145 */         row.getBind().add(bind);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         b++; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 157 */       this.tar.getMessageParam().addMessageRow(row);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\requester\async\MCAsyncCaller.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */