/*    */ package mcframe.clientCore.requester.async;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import mcframe.clientCore.container.MCKeyList;
/*    */ import mcframe.commonCore.annotation.EI;
/*    */ import mcframe.commonCore.container.MCRow;
/*    */ import mcframe.commonCore.lang.MCBinary;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @EI
/*    */ public class Info2R
/*    */   extends Info2R_FW_A
/*    */ {
/*    */   public static Info2R create() {
/* 43 */     Info2R row = new Info2R(constMetas);
/* 44 */     return row;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static <T extends MCRow> Info2R createByName(T proto) {
/* 54 */     Info2R row = create();
/* 55 */     copyByName((MCRow)row, (MCRow)proto);
/* 56 */     return row;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Info2R(MCRow.ConstMetaList<? extends Info2R> metas) {
/* 63 */     super(metas);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\requester\async\Info2R.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */