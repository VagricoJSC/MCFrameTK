/*     */ package mcframe.clientCore.requester.cap;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.clientCore.container.MCKeyList;
/*     */ import mcframe.commonCore.container.MCExtMap;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class CacheR_FW_A
/*     */   extends MCConstRow
/*     */ {
/*     */   public static final String $total = "total";
/*     */   public static final String $cache_id = "cache_id";
/*  33 */   public static final MCMeta total_META = createNumberMeta("total");
/*  34 */   public static final MCMeta cache_id_META = createStringMeta("cache_id");
/*     */   
/*  36 */   protected static final MCRow.ConstMetaList<CacheR> constMetas = new MCRow.ConstMetaList(
/*  37 */       MCConstRow.constMetas, 
/*  38 */       new MCMeta[] {
/*  39 */         total_META, 
/*  40 */         cache_id_META
/*     */       },
/*  42 */       new String[][] { {}, {} });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   protected static final MCKeyList KEYS = new MCKeyList(
/*  54 */       null, 
/*  55 */       new String[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  63 */   protected static final MCExtMap EXTMAP = new MCExtMap(
/*  64 */       null, new MCExtMap.Entry[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] colnames() {
/*  76 */     return constMetas.toNameArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMeta[] colmetas() {
/*  88 */     return constMetas.toMetaArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  94 */   private static final int offset = constMetas.offset();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCKeyList getKeys() {
/* 100 */     return KEYS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getExtMap(String aGroup) {
/* 107 */     if (aGroup == null) return null; 
/* 108 */     return (Map<String, String>)EXTMAP.get(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCKeyList getKeys(String aGroup) {
/* 115 */     if (aGroup == null) return null; 
/* 116 */     return new MCKeyList(EXTMAP.getKeyList(aGroup));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExtGroups() {
/* 123 */     Set<String> ret = EXTMAP.keySet();
/* 124 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CacheR_FW_A(MCRow.ConstMetaList<? extends CacheR> metas) {
/* 131 */     super(metas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CacheR clone() {
/* 138 */     return (CacheR)super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CacheR createInstance() {
/* 145 */     return (CacheR)super.createInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CacheR getValues(String... names) {
/* 152 */     return (CacheR)super.getValues(names);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MCNumber total() {
/* 158 */     return getConstNumber(offset + 0, "total");
/*     */   }
/*     */   
/*     */   public void total(MCNumber value) {
/* 162 */     setConstNumber(offset + 0, "total", value);
/*     */   }
/*     */   
/*     */   public void total(int value) {
/* 166 */     setConstNumber(offset + 0, "total", value);
/*     */   }
/*     */   
/*     */   public void total(long value) {
/* 170 */     setConstNumber(offset + 0, "total", value);
/*     */   }
/*     */   
/*     */   public void total(float value) {
/* 174 */     setConstNumber(offset + 0, "total", value);
/*     */   }
/*     */   
/*     */   public void total(double value) {
/* 178 */     setConstNumber(offset + 0, "total", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String cache_id() {
/* 183 */     return getConstString(offset + 1, "cache_id");
/*     */   }
/*     */   
/*     */   public void cache_id(String value) {
/* 187 */     setConstString(offset + 1, "cache_id", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString(String name) {
/* 192 */     if ("cache_id".equalsIgnoreCase(name)) {
/* 193 */       return cache_id();
/*     */     }
/* 195 */     return super.getString(name);
/*     */   }
/*     */   public MCNumber getNumber(String name) {
/* 198 */     if ("total".equalsIgnoreCase(name)) {
/* 199 */       return total();
/*     */     }
/* 201 */     return super.getNumber(name);
/*     */   }
/*     */   
/*     */   public String getStringNE(String name) {
/* 205 */     if ("cache_id".equalsIgnoreCase(name)) {
/* 206 */       return cache_id();
/*     */     }
/* 208 */     return super.getStringNE(name);
/*     */   }
/*     */   public MCNumber getNumberNE(String name) {
/* 211 */     if ("total".equalsIgnoreCase(name)) {
/* 212 */       return total();
/*     */     }
/* 214 */     return super.getNumberNE(name);
/*     */   }
/*     */   
/*     */   public void setString(String name, String value) {
/* 218 */     if ("cache_id".equalsIgnoreCase(name)) {
/* 219 */       cache_id(value);
/*     */       return;
/*     */     } 
/* 222 */     super.setString(name, value);
/*     */   }
/*     */   public void setNumber(String name, MCNumber value) {
/* 225 */     if ("total".equalsIgnoreCase(name)) {
/* 226 */       total(value);
/*     */       return;
/*     */     } 
/* 229 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, int value) {
/* 232 */     if ("total".equalsIgnoreCase(name)) {
/* 233 */       total(value);
/*     */       return;
/*     */     } 
/* 236 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, long value) {
/* 239 */     if ("total".equalsIgnoreCase(name)) {
/* 240 */       total(value);
/*     */       return;
/*     */     } 
/* 243 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, float value) {
/* 246 */     if ("total".equalsIgnoreCase(name)) {
/* 247 */       total(value);
/*     */       return;
/*     */     } 
/* 250 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, double value) {
/* 253 */     if ("total".equalsIgnoreCase(name)) {
/* 254 */       total(value);
/*     */       return;
/*     */     } 
/* 257 */     super.setNumber(name, value);
/*     */   }
/*     */   
/*     */   public void setStringNE(String name, String value) {
/* 261 */     if ("cache_id".equalsIgnoreCase(name)) {
/* 262 */       cache_id(value);
/*     */       return;
/*     */     } 
/* 265 */     super.setStringNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, MCNumber value) {
/* 268 */     if ("total".equalsIgnoreCase(name)) {
/* 269 */       total(value);
/*     */       return;
/*     */     } 
/* 272 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, int value) {
/* 275 */     if ("total".equalsIgnoreCase(name)) {
/* 276 */       total(value);
/*     */       return;
/*     */     } 
/* 279 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, long value) {
/* 282 */     if ("total".equalsIgnoreCase(name)) {
/* 283 */       total(value);
/*     */       return;
/*     */     } 
/* 286 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, float value) {
/* 289 */     if ("total".equalsIgnoreCase(name)) {
/* 290 */       total(value);
/*     */       return;
/*     */     } 
/* 293 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, double value) {
/* 296 */     if ("total".equalsIgnoreCase(name)) {
/* 297 */       total(value);
/*     */       return;
/*     */     } 
/* 300 */     super.setNumberNE(name, value);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\requester\cap\CacheR_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */