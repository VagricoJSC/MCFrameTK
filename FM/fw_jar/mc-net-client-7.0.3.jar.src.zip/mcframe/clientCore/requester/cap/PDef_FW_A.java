/*    */ package mcframe.clientCore.requester.cap;
/*    */ 
/*    */ import mcframe.commonCore.param.MCContainerDef;
/*    */ import mcframe.commonCore.param.MCDef;
/*    */ import mcframe.commonCore.param.MCGeneralContainerDef;
/*    */ import mcframe.commonCore.param.MCItemDef;
/*    */ import mcframe.commonCore.param.MCOperationInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PDef_FW_A
/*    */   extends MCDef
/*    */ {
/*    */   public MCContainerDef getCustomDef(String id) {
/* 18 */     if (id == null) {
/* 19 */       return null;
/*    */     }
/*    */     
/* 22 */     if (id.equals("FC.FCBGL1000.GetCache.UP.BLOCK0")) {
/* 23 */       return FC_FCBGL1000_GetCache_UP_BLOCK0();
/*    */     }
/* 25 */     if (id.equals("FC.FCBGL1000.GetCache.UP.BLOCK1")) {
/* 26 */       return FC_FCBGL1000_GetCache_UP_BLOCK1();
/*    */     }
/* 28 */     if (id.equals("FC.FCBGL1000.GetCache.DOWN.BLOCK0")) {
/* 29 */       return FC_FCBGL1000_GetCache_DOWN_BLOCK0();
/*    */     }
/*    */ 
/*    */     
/* 33 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 39 */   static final MCOperationInfo FC_FCBGL1000_GetCache_INFO = new MCOperationInfo("FC", "FCBGL1000", "GetCache", "000000", new PDef());
/*    */ 
/*    */   
/*    */   public static MCContainerDef FC_FCBGL1000_GetCache_UP_BLOCK0() {
/* 43 */     return (MCContainerDef)new MCGeneralContainerDef(
/* 44 */         new MCItemDef[] {
/* 45 */           MCItemDef.create("denbun", "denbun")
/*    */         });
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static MCContainerDef FC_FCBGL1000_GetCache_UP_BLOCK1() {
/* 52 */     return (MCContainerDef)new MCGeneralContainerDef(
/* 53 */         new MCItemDef[] {
/* 54 */           MCItemDef.create("cache_id", "cache_id")
/*    */         });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static MCContainerDef FC_FCBGL1000_GetCache_DOWN_BLOCK0() {
/* 62 */     return (MCContainerDef)new MCGeneralContainerDef(
/* 63 */         new MCItemDef[] {
/* 64 */           MCItemDef.create("denbun", "denbun")
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\requester\cap\PDef_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */