/*     */ package mcframe.clientCore.requester.cap;
/*     */ 
/*     */ import mcframe.clientCore.requester.decorator.MCDecoratorCaller;
/*     */ import mcframe.commonCore.container.MCContainer;
/*     */ import mcframe.commonCore.lang.MCTimestamp;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.commonCore.param.MCParamHandler;
/*     */ import mcframe.commonCore.pio.MCDPReaderFactory;
/*     */ import mcframe.commonCore.pio.MCP2THeaderReader;
/*     */ import mcframe.commonCore.pio.util.MCDPFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCCacheGetter
/*     */   extends MCDecoratorCaller
/*     */ {
/*  20 */   public final CacheR up1 = CacheR.create();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final MCTimestamp rt;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final MCTimestamp ct;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCCacheGetter(MCParam tar) {
/*  45 */     this(tar, (MCParamHandler)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCCacheGetter(MCParam tar, MCParamHandler handler) {
/*  57 */     super(new MCParam(PDef.FC_FCBGL1000_GetCache_INFO), tar);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  66 */     param().addUpBlock((MCContainer)this.up1);
/*  67 */     this.rt = tar.getRequestTime();
/*  68 */     this.ct = tar.getCommitTime();
/*     */     
/*  70 */     setParamHandler(handler);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void decorateUp() {
/*  75 */     setHdrInfo(param());
/*  76 */     this.up1.cache_id(crtCacheId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void parseUp() {
/*  83 */     MCP2THeaderReader hr = MCDPReaderFactory.upHeaderToText(MCDPFormat.forClient());
/*  84 */     String hdr = hr.parse(this.tar);
/*  85 */     this.up0.denbun(hdr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String crtCacheId() {
/*  96 */     return String.valueOf(this.tar.getClientRequestNo()) + "_" + this.tar.getServerRequestNo();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void reqTm2decPrm() {
/* 101 */     if (this.tar != null) {
/* 102 */       setRequestTime(this.tar, this.rt);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void cmtTm2decPrm() {
/* 108 */     if (this.tar != null)
/* 109 */       setCommitTime(this.tar, this.ct); 
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\requester\cap\MCCacheGetter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */