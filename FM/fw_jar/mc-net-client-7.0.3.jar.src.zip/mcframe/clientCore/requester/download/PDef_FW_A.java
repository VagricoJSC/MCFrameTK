/*    */ package mcframe.clientCore.requester.download;
/*    */ 
/*    */ import mcframe.commonCore.param.MCContainerDef;
/*    */ import mcframe.commonCore.param.MCDef;
/*    */ import mcframe.commonCore.param.MCGeneralContainerDef;
/*    */ import mcframe.commonCore.param.MCItemDef;
/*    */ import mcframe.commonCore.param.MCOperationInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PDef_FW_A
/*    */   extends MCDef
/*    */ {
/*    */   public MCContainerDef getCustomDef(String id) {
/* 18 */     if (id == null) {
/* 19 */       return null;
/*    */     }
/*    */     
/* 22 */     if (id.equals("FC.FCBGL0020.BinDl.UP.BLOCK0")) {
/* 23 */       return FC_FCBGL0020_BinDl_UP_BLOCK0();
/*    */     }
/* 25 */     if (id.equals("FC.FCBGL0020.FileDl.UP.BLOCK0")) {
/* 26 */       return FC_FCBGL0020_FileDl_UP_BLOCK0();
/*    */     }
/* 28 */     if (id.equals("FC.FCBGL0020.MCBinDl.UP.BLOCK0")) {
/* 29 */       return FC_FCBGL0020_MCBinDl_UP_BLOCK0();
/*    */     }
/*    */ 
/*    */     
/* 33 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 39 */   static final MCOperationInfo FC_FCBGL0020_BinDl_INFO = new MCOperationInfo("FC", "FCBGL0020", "BinDl", "000000", new PDef());
/*    */ 
/*    */   
/*    */   public static MCContainerDef FC_FCBGL0020_BinDl_UP_BLOCK0() {
/* 43 */     return (MCContainerDef)new MCGeneralContainerDef(
/* 44 */         new MCItemDef[] {
/* 45 */           MCItemDef.create("pointer", "pointer")
/*    */         });
/*    */   }
/*    */ 
/*    */   
/* 50 */   static final MCOperationInfo FC_FCBGL0020_FileDl_INFO = new MCOperationInfo("FC", "FCBGL0020", "FileDl", "000000", new PDef());
/*    */ 
/*    */   
/*    */   public static MCContainerDef FC_FCBGL0020_FileDl_UP_BLOCK0() {
/* 54 */     return (MCContainerDef)new MCGeneralContainerDef(
/* 55 */         new MCItemDef[] {
/* 56 */           MCItemDef.create("path", "path")
/*    */         });
/*    */   }
/*    */ 
/*    */   
/* 61 */   static final MCOperationInfo FC_FCBGL0020_MCBinDl_INFO = new MCOperationInfo("FC", "FCBGL0020", "MCBinDl", "000000", new PDef());
/*    */ 
/*    */   
/*    */   public static MCContainerDef FC_FCBGL0020_MCBinDl_UP_BLOCK0() {
/* 65 */     return (MCContainerDef)new MCGeneralContainerDef(
/* 66 */         new MCItemDef[] {
/* 67 */           MCItemDef.create("bin", "bin")
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\requester\download\PDef_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */