/*    */ package mcframe.clientCore.requester;
/*    */ 
/*    */ import java.net.URL;
/*    */ import mcframe.commonCore.lang.AbsMCPackageProxy;
/*    */ import mcframe.commonCore.lang.MCBinary;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MCLangProxy
/*    */   extends AbsMCPackageProxy
/*    */ {
/* 15 */   public static final MCLangProxy proxy = new MCLangProxy();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected URL binDblinkURL(MCBinary bin) {
/* 33 */     return super.binDblinkURL(bin);
/*    */   }
/*    */   
/*    */   protected void binDblinkURL(MCBinary bin, URL url) {
/* 37 */     super.binDblinkURL(bin, url);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\requester\MCLangProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */