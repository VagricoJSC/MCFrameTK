/*     */ package mcframe.clientCore.requester;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.Proxy;
/*     */ import java.net.ProxySelector;
/*     */ import java.net.SocketAddress;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import mcframe.clientCore.resource.MCConfig;
/*     */ import mcframe.clientCore.sys.MCSys;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.net.MCHttpClient;
/*     */ import mcframe.commonCore.net.MCPostMethod;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.param.MCUploadFileParam;
/*     */ import mcframe.commonCore.requester.MCHTTPRequester;
/*     */ import mcframe.commonCore.resource.ctrl.MCReadableResource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCClientRequester
/*     */   extends MCHTTPRequester
/*     */ {
/*     */   protected static final String SERVLET_KEY = "net.servlet";
/*     */   protected static final String SERVLET_ORDER_KEY = "order";
/*     */   protected static final String SERVLET_URL_KEY = "url";
/*     */   protected static final String SERVLET_PTN_KEY = "ptn";
/*     */   protected static final String DOWNLOAD_URL_KEY = "net.download.url";
/*     */   
/*     */   static class MCClientProxySelector
/*     */     extends ProxySelector
/*     */   {
/*  89 */     private ProxySelector _def = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  95 */     private MCClientRequester _req = new MCClientRequester();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean _use_dll = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     MCClientProxySelector() {
/* 110 */       this._def = ProxySelector.getDefault();
/* 111 */       this._req = new MCClientRequester();
/* 112 */       String type = MCConfig.client.getString("net.request.type");
/* 113 */       this._use_dll = "java".equals(type);
/*     */     }
/*     */     
/*     */     public List<Proxy> select(URI uri) {
/* 117 */       if (uri == null) {
/* 118 */         throw new IllegalArgumentException("URI can't be null.");
/*     */       }
/* 120 */       if (!this._use_dll || !MCSys.env.isWin())
/*     */       {
/* 122 */         return this._def.select(uri);
/*     */       }
/* 124 */       return selectImpl(uri);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private synchronized List<Proxy> selectImpl(URI uri) {
/* 146 */       List<Proxy> list = new ArrayList<>();
/*     */ 
/*     */       
/* 149 */       String uristr = uri.toString();
/* 150 */       if (uristr.toLowerCase().startsWith("socket:")) {
/*     */ 
/*     */         
/* 153 */         if (!MCConfig.client.getBoolean("net.proxy.usesocks", false)) {
/* 154 */           list.add(Proxy.NO_PROXY);
/* 155 */           return list;
/*     */         } 
/*     */         
/* 158 */         uristr = "socks:" + uristr.substring("socket:".length());
/*     */       } 
/* 160 */       MCNetNativeIf net = this._req.createNetIf(uristr);
/* 161 */       String[] setting = net.getProxy();
/*     */ 
/*     */ 
/*     */       
/* 165 */       Map<String, String> proxyMap = new HashMap<>();
/* 166 */       String entries = setting[0];
/* 167 */       if (entries != null) {
/*     */         
/* 169 */         String[] entryArray = entries.split(";", -1); byte b; int i; String[] arrayOfString1;
/* 170 */         for (i = (arrayOfString1 = entryArray).length, b = 0; b < i; ) { String entry = arrayOfString1[b];
/*     */           
/* 172 */           String[] typesrv = entry.split("=", -1);
/* 173 */           if (typesrv.length == 1) {
/*     */             
/* 175 */             proxyMap.put(null, typesrv[0]);
/*     */           } else {
/*     */             
/* 178 */             proxyMap.put(typesrv[0].toLowerCase(), typesrv[1]);
/*     */           } 
/*     */           b++; }
/*     */       
/*     */       } 
/* 183 */       if (setting[1] != null) {
/*     */         
/* 185 */         String u = uri.getHost().toLowerCase();
/* 186 */         String[] excludeArray = setting[1].toLowerCase().split("\\|"); byte b; int i; String[] arrayOfString1;
/* 187 */         for (i = (arrayOfString1 = excludeArray).length, b = 0; b < i; ) { String exclude = arrayOfString1[b];
/* 188 */           if (exclude.equals("<local>") && u.indexOf('.') < 0) {
/*     */             
/* 190 */             list.add(Proxy.NO_PROXY);
/*     */             break;
/*     */           } 
/* 193 */           exclude = exclude.replaceAll("\\.", "[.]");
/* 194 */           exclude = exclude.replaceAll("\\*", ".*");
/* 195 */           if (u.matches(exclude)) {
/*     */             
/* 197 */             list.add(Proxy.NO_PROXY);
/*     */             break;
/*     */           } 
/*     */           b++; }
/*     */       
/*     */       } 
/* 203 */       if (list.isEmpty() && proxyMap.size() > 0) {
/*     */ 
/*     */         
/* 206 */         String protocol = uri.getScheme().toLowerCase();
/* 207 */         if ("socket".equals(protocol)) {
/* 208 */           protocol = "socks";
/*     */         }
/* 210 */         String server = proxyMap.get(protocol);
/* 211 */         if (server == null)
/*     */         {
/* 213 */           server = proxyMap.get(null);
/*     */         }
/* 215 */         if (server != null) {
/* 216 */           String[] hostport = server.split(":");
/* 217 */           String host = hostport[0];
/* 218 */           int port = (hostport.length < 2) ? 
/* 219 */             getDefaultPort(protocol) : 
/* 220 */             Integer.parseInt(hostport[1]);
/* 221 */           InetSocketAddress isa = new InetSocketAddress(host, port);
/* 222 */           Proxy.Type type = getProxyType(protocol);
/* 223 */           Proxy p = new Proxy(type, isa);
/* 224 */           list.add(p);
/*     */         } 
/*     */       } 
/* 227 */       if (list.isEmpty())
/*     */       {
/* 229 */         list.add(Proxy.NO_PROXY);
/*     */       }
/* 231 */       return list;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Proxy.Type getProxyType(String protocol) {
/* 242 */       Proxy.Type type = Proxy.Type.DIRECT;
/* 243 */       if (protocol != null) {
/*     */         String str;
/* 245 */         switch ((str = protocol).hashCode()) { case -897048717: if (!str.equals("socket")) {
/*     */               break;
/*     */             }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 256 */             type = Proxy.Type.SOCKS; break;case 3804: if (!str.equals("ws")) break;  type = Proxy.Type.HTTP; break;case 101730: if (!str.equals("ftp")) break;  type = Proxy.Type.HTTP; break;case 118039: if (!str.equals("wss")) break;  type = Proxy.Type.HTTP; break;case 3213448: if (!str.equals("http")) break;  type = Proxy.Type.HTTP; break;case 99617003: if (!str.equals("https")) break;  type = Proxy.Type.HTTP; break;case 109610287: if (!str.equals("socks")) break;  type = Proxy.Type.SOCKS;
/*     */             break; }
/*     */ 
/*     */       
/*     */       } 
/* 261 */       return type;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private int getDefaultPort(String protocol) {
/* 276 */       if (protocol != null) {
/*     */         String str;
/* 278 */         switch ((str = protocol).hashCode()) { case -1240214131: if (!str.equals("gopher")) {
/*     */               break;
/*     */             }
/*     */             
/* 282 */             return 80;
/*     */           case -897048717:
/*     */             if (!str.equals("socket")) {
/*     */               break;
/*     */             }
/* 287 */             return 1080;case 101730: if (!str.equals("ftp")) break;  return 80;case 3213448: if (!str.equals("http")) break;  return 80;case 99617003: if (!str.equals("https")) break;  return 443;case 109610287: if (!str.equals("socks")) break;  return 1080; }
/*     */ 
/*     */       
/*     */       } 
/* 291 */       return -1;
/*     */     }
/*     */     
/*     */     public void connectFailed(URI uri, SocketAddress sa, IOException ioe) {
/* 295 */       if (uri == null || sa == null || ioe == null) {
/* 296 */         throw new IllegalArgumentException("Arguments can't be null.");
/*     */       }
/* 298 */       this._def.connectFailed(uri, sa, ioe);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setProxy() {
/* 319 */     String sys = System.getProperty("java.net.useSystemProxies");
/* 320 */     if (sys == null) {
/*     */       
/* 322 */       sys = "true";
/* 323 */       System.setProperty("java.net.useSystemProxies", sys);
/*     */       
/* 325 */       if (!(ProxySelector.getDefault() instanceof MCClientProxySelector)) {
/* 326 */         ProxySelector.setDefault(new MCClientProxySelector());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getServletURL(String id) {
/* 336 */     String[] srvIds = getServletKeys();
/* 337 */     String[] ids = { id }; byte b; int i; String[] arrayOfString1;
/* 338 */     for (i = (arrayOfString1 = srvIds).length, b = 0; b < i; ) { String srvId = arrayOfString1[b];
/* 339 */       String value = MCConfig.client.getString(MCConfig.createKey(new String[] { srvId, "ptn" }));
/* 340 */       if (!MCStringUtil.isNull(value)) {
/*     */         
/* 342 */         String[] ptns = MCStringUtil.split(",", value); byte b1; int j; String[] arrayOfString2;
/* 343 */         for (j = (arrayOfString2 = ptns).length, b1 = 0; b1 < j; ) { String ptn = arrayOfString2[b1];
/* 344 */           String[] results = MCStringUtil.match(ptn, ids, '.');
/* 345 */           if (results.length > 0) {
/* 346 */             String url = MCConfig.client.getString(MCConfig.createKey(new String[] { srvId, "url" }));
/* 347 */             MCLog.write(Core_Msg_FW_A.FCBGC0402, new Object[] { url, srvId });
/* 348 */             return url;
/*     */           } 
/*     */           
/*     */           b1++; }
/*     */       
/*     */       } else {
/* 354 */         String url = MCConfig.client.getString(MCConfig.createKey(new String[] { srvId, "url" }));
/* 355 */         if (!MCStringUtil.isNull(url)) {
/* 356 */           MCLog.write(Core_Msg_FW_A.FCBGC0402, new Object[] { url, srvId });
/* 357 */           return url;
/*     */         } 
/*     */       }  b++; }
/*     */     
/* 361 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String[] getServletKeys() {
/* 370 */     String srvIds[], order = MCConfig.client.getString(MCConfig.createKey(new String[] { "net.servlet", "order" }));
/*     */     
/* 372 */     if (MCStringUtil.isNull(order)) {
/*     */       
/* 374 */       srvIds = MCConfig.client.findPattern(MCConfig.createKey(new String[] { "net.servlet", "*", "url" }));
/* 375 */       Arrays.sort((Object[])srvIds);
/* 376 */       for (int i = 0; i < srvIds.length; i++) {
/* 377 */         srvIds[i] = srvIds[i].substring(0, srvIds[i].lastIndexOf('.'));
/*     */       }
/*     */     }
/*     */     else {
/*     */       
/* 382 */       String[] orders = MCStringUtil.split(",", order);
/* 383 */       srvIds = new String[orders.length];
/* 384 */       for (int i = 0; i < orders.length; i++) {
/* 385 */         srvIds[i] = MCConfig.createKey(new String[] { "net.servlet", orders[i] });
/*     */       } 
/*     */     } 
/* 388 */     return srvIds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCHttpClient createHttpClient() {
/* 395 */     MCHttpClient http = super.createHttpClient();
/*     */ 
/*     */     
/* 398 */     long limit = MCConfig.getByteValue((MCReadableResource)MCConfig.client, 
/* 399 */         "net.response.limitByte");
/* 400 */     http.setLimitResponseByte(limit);
/*     */ 
/*     */     
/* 403 */     int retry = MCConfig.client.getInteger(
/* 404 */         "net.request.retry", -1);
/* 405 */     http.setRetry(retry);
/*     */ 
/*     */     
/* 408 */     int timeout = MCConfig.client.getInteger(
/* 409 */         "net.request.receive_timeout", -1);
/* 410 */     http.setTimeout(timeout);
/*     */     
/* 412 */     return http;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCPostMethod createPostMethod(String url, String up, MCUploadFileParam upf, File dir, String file) {
/* 420 */     MCPostMethod method = super.createPostMethod(url, up, upf, dir, file);
/*     */ 
/*     */     
/* 423 */     boolean ignore = MCConfig.client.getBoolean(
/* 424 */         "net.request.java.ignoreCertification", false);
/* 425 */     method.setIgnoreCertification(ignore);
/*     */     
/* 427 */     return method;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getDownloadURL() {
/* 432 */     String url = MCConfig.client.getString("net.download.url");
/* 433 */     if (url == null)
/*     */     {
/* 435 */       throw new MCException(Core_Msg_FW_A.FCBGC0084, new Object[] {
/* 436 */             MCConfig.client.getFileBase(), "net.download.url"
/*     */           }); } 
/* 438 */     return url;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected File download(URL url, File dir, String name) {
/* 463 */     if (url == null) {
/* 464 */       throw new MCException(Core_Msg_FW_A.FCBGC0083, new Object[] { url });
/*     */     }
/* 466 */     return httpDownload(url.toString(), null, dir, name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 477 */   private static String _log_dir = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCNetNativeIf createNetIf(String url) {
/* 489 */     MCNetNativeIf net = new MCNetNativeIf();
/*     */ 
/*     */     
/* 492 */     if (_log_dir == null)
/*     */     {
/*     */ 
/*     */       
/* 496 */       _log_dir = MCConfig.client.getString("log.dir", "{MCF_HOME}/log");
/*     */     }
/* 498 */     net.log_dir = _log_dir;
/*     */ 
/*     */     
/* 501 */     net.url = url;
/*     */ 
/*     */     
/* 504 */     net.retry = MCConfig.client.getInteger(
/* 505 */         "net.request.retry", -1);
/* 506 */     net.receive_timeout = MCConfig.client.getInteger(
/* 507 */         "net.request.receive_timeout", -1);
/*     */     
/* 509 */     net.limit_byte = MCConfig.getByteValue((MCReadableResource)MCConfig.client, 
/* 510 */         "net.response.limitByte");
/*     */     
/* 512 */     return net;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\requester\MCClientRequester.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */