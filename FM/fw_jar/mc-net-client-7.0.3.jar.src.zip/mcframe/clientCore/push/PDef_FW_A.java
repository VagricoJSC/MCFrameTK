/*     */ package mcframe.clientCore.push;
/*     */ 
/*     */ import mcframe.commonCore.param.MCBlockDef;
/*     */ import mcframe.commonCore.param.MCContainerDef;
/*     */ import mcframe.commonCore.param.MCDef;
/*     */ import mcframe.commonCore.param.MCGeneralContainerDef;
/*     */ import mcframe.commonCore.param.MCItemDef;
/*     */ import mcframe.commonCore.param.MCOperationInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PDef_FW_A
/*     */   extends MCDef
/*     */ {
/*     */   public MCContainerDef getCustomDef(String id) {
/*  19 */     if (id == null) {
/*  20 */       return null;
/*     */     }
/*     */     
/*  23 */     if (id.equals("FC.FCBGL0100.Notice.DOWN.BLOCK0")) {
/*  24 */       return FC_FCBGL0100_Notice_DOWN_BLOCK0();
/*     */     }
/*  26 */     if (id.equals("FC.FCBGL0100.Notice.DOWN.BLOCK1")) {
/*  27 */       return FC_FCBGL0100_Notice_DOWN_BLOCK1();
/*     */     }
/*  29 */     if (id.equals("FC.FCBGL0100.Unread.UP.BLOCK0")) {
/*  30 */       return FC_FCBGL0100_Unread_UP_BLOCK0();
/*     */     }
/*  32 */     if (id.equals("FC.FCBGL0100.Read.UP.BLOCK0")) {
/*  33 */       return FC_FCBGL0100_Read_UP_BLOCK0();
/*     */     }
/*  35 */     if (id.equals("FC.FCBGL0100.Read.UP.BLOCK1")) {
/*  36 */       return FC_FCBGL0100_Read_UP_BLOCK1();
/*     */     }
/*  38 */     if (id.equals("FC.FCBGL0100.ClientSend.UP.BLOCK0")) {
/*  39 */       return FC_FCBGL0100_ClientSend_UP_BLOCK0();
/*     */     }
/*  41 */     if (id.equals("FC.FCBGL0100.ClientSend.UP.BLOCK1")) {
/*  42 */       return FC_FCBGL0100_ClientSend_UP_BLOCK1();
/*     */     }
/*  44 */     if (id.equals("FC.FCBGL0100.ClientSend.UP.BLOCK2")) {
/*  45 */       return FC_FCBGL0100_ClientSend_UP_BLOCK2();
/*     */     }
/*     */ 
/*     */     
/*  49 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   static final MCOperationInfo FC_FCBGL0100_Notice_INFO = new MCOperationInfo("FC", "FCBGL0100", "Notice", "000000", new PDef());
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL0100_Notice_DOWN_BLOCK0() {
/*  60 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL0100", "Notice", 
/*  61 */         new MCItemDef[] {
/*  62 */           MCItemDef.create("pushid", "pushid"), 
/*  63 */           MCItemDef.create("userid", "userid"), 
/*  64 */           MCItemDef.create("cocd", "cocd"), 
/*  65 */           MCItemDef.create("title", "title"), 
/*  66 */           MCItemDef.create("importance", "importance")
/*     */ 
/*     */         
/*  69 */         }MCBlockDef.create("Notice"));
/*     */   }
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL0100_Notice_DOWN_BLOCK1() {
/*  74 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL0100", "Notice", 
/*  75 */         new MCItemDef[] {
/*  76 */           MCItemDef.create("type", "type"), 
/*  77 */           MCItemDef.create("key", "key"), 
/*  78 */           MCItemDef.create("val", "val")
/*     */ 
/*     */         
/*  81 */         }MCBlockDef.create("Screen"));
/*     */   }
/*     */ 
/*     */   
/*  85 */   static final MCOperationInfo FC_FCBGL0100_Unread_INFO = new MCOperationInfo("FC", "FCBGL0100", "Unread", "000000", new PDef());
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL0100_Unread_UP_BLOCK0() {
/*  89 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL0100", "Unread", 
/*  90 */         new MCItemDef[] {
/*  91 */           MCItemDef.create("userid", "userid")
/*     */ 
/*     */         
/*  94 */         }MCBlockDef.create("User"));
/*     */   }
/*     */ 
/*     */   
/*  98 */   static final MCOperationInfo FC_FCBGL0100_Read_INFO = new MCOperationInfo("FC", "FCBGL0100", "Read", "000000", new PDef());
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL0100_Read_UP_BLOCK0() {
/* 102 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL0100", "Read", 
/* 103 */         new MCItemDef[] {
/* 104 */           MCItemDef.create("pushid", "pushid")
/*     */ 
/*     */         
/* 107 */         }MCBlockDef.create("Read"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL0100_Read_UP_BLOCK1() {
/* 113 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL0100", "Read", 
/* 114 */         new MCItemDef[] {
/* 115 */           MCItemDef.create("userid", "userid")
/*     */ 
/*     */         
/* 118 */         }MCBlockDef.create("Own"));
/*     */   }
/*     */ 
/*     */   
/* 122 */   static final MCOperationInfo FC_FCBGL0100_ClientSend_INFO = new MCOperationInfo("FC", "FCBGL0100", "ClientSend", "000000", new PDef());
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL0100_ClientSend_UP_BLOCK0() {
/* 126 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL0100", "ClientSend", 
/* 127 */         new MCItemDef[] {
/* 128 */           MCItemDef.create("userid", "userid"), 
/* 129 */           MCItemDef.create("cocd", "cocd"), 
/* 130 */           MCItemDef.create("modid", "modid"), 
/* 131 */           MCItemDef.create("logid", "logid"), 
/* 132 */           MCItemDef.create("msgid", "msgid"), 
/* 133 */           MCItemDef.create("msgbind", "msgbind"), 
/* 134 */           MCItemDef.create("titleid", "titleid"), 
/* 135 */           MCItemDef.create("titlebind", "titlebind"), 
/* 136 */           MCItemDef.create("importance", "importance")
/*     */ 
/*     */         
/* 139 */         }MCBlockDef.create("Notice"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL0100_ClientSend_UP_BLOCK1() {
/* 145 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL0100", "ClientSend", 
/* 146 */         new MCItemDef[] {
/* 147 */           MCItemDef.create("userid", "userid")
/*     */ 
/*     */         
/* 150 */         }MCBlockDef.create("User"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL0100_ClientSend_UP_BLOCK2() {
/* 156 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL0100", "ClientSend", 
/* 157 */         new MCItemDef[] {
/* 158 */           MCItemDef.create("type", "type"), 
/* 159 */           MCItemDef.create("key", "key"), 
/* 160 */           MCItemDef.create("val", "val")
/*     */ 
/*     */         
/* 163 */         }MCBlockDef.create("Screen"));
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\push\PDef_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */