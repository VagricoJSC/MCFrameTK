/*     */ package mcframe.clientCore.push;
/*     */ 
/*     */ import mcframe.clientCore.requester.MCCaller;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ import mcframe.clientCore.sys.MCSys;
/*     */ import mcframe.commonCore.container.MCContainer;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.notice.MCMessage;
/*     */ import mcframe.commonCore.notice.MCMessageList;
/*     */ import mcframe.commonCore.param.MCMessageRowParam;
/*     */ import mcframe.commonCore.param.MCOperationInfo;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.commonCore.pio.MCDPReaderFactory;
/*     */ import mcframe.commonCore.pio.MCT2PBodyReader;
/*     */ import mcframe.commonCore.pio.MCT2PHeaderReader;
/*     */ import mcframe.commonCore.pio.util.MCDPFormat;
/*     */ import mcframe.commonCore.pio.util.MCDPParseType;
/*     */ import mcframe.commonCore.pio.util.MCDPToken;
/*     */ import mcframe.commonCore.push.MCPushMessage;
/*     */ import mcframe.commonCore.push.MCServerPushManager;
/*     */ import mcframe.commonCore.push.MCServerPushProxy;
/*     */ import mcframe.commonCore.sys.MCFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCServerPushManager
/*     */   extends MCServerPushManager
/*     */ {
/*     */   static class RecvMessage
/*     */   {
/*     */     MCNumber pushid;
/*     */     String cocd;
/*     */     String title;
/*     */     boolean importance;
/*     */     MCMessage msg;
/*     */     MCList<ScreenR> screenL;
/*     */   }
/*  63 */   private static MCServerPushManager _mgr = new MCServerPushManager();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCServerPushManager getManager() {
/*  73 */     return _mgr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCServerPushManager() {
/*  91 */     super(MCStringUtil.eq(MCSys.env.MCF_TIER(), "3") ? null : (MCServerPushProxy)MCFactory.create(MCServerPushProxy.class, 
/*  92 */           "mcframe.clientCore.push.MCPushClient$MCServerPushProxyImpl"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void init() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canPush() {
/* 118 */     String id = MCSys.env.MCF_TIER();
/* 119 */     return (id != null && id.equals("3"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCParam createParam(String mid, String lid, String oid, String version) {
/* 136 */     MCOperationInfo ope = new MCOperationInfo(
/* 137 */         mid, lid, oid, version, new PDef());
/* 138 */     MCParam param = new MCParam(ope);
/* 139 */     param.setLimitDLSize(MCNumber.valueOf(-1));
/* 140 */     return param;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   RecvMessage analyzeMessage(String message) {
/* 155 */     NoticeR noticeR = NoticeR.create();
/* 156 */     MCList<ScreenR> screenL = MCList.create(ScreenR.class);
/* 157 */     MCParam param = createParam("FC", "FCBGL0100", "Notice", "000000");
/* 158 */     param.addDownBlock((MCContainer)noticeR);
/* 159 */     param.addDownBlock((MCContainer)screenL);
/*     */ 
/*     */     
/* 162 */     MCDPFormat format = MCDPFormat.JSON;
/* 163 */     MCDPToken tkn = MCDPToken.create(message);
/* 164 */     MCT2PHeaderReader dRdrH = MCDPReaderFactory.downHeaderToParam(format);
/* 165 */     dRdrH.parse(tkn, param);
/* 166 */     MCT2PBodyReader dRdrB = MCDPReaderFactory.downBodyToParam(format, MCDPParseType.NOMAL);
/* 167 */     dRdrB.parse(tkn, param);
/*     */ 
/*     */     
/* 170 */     for (MCMessageRowParam p : param.getMessageParam().getMessageRowParamList()) {
/* 171 */       p.getMsg().wrapMessage(p.getCompMsg());
/*     */     }
/*     */ 
/*     */     
/* 175 */     MCMessage msg = null;
/* 176 */     MCList<ScreenR> xaL = null;
/* 177 */     MCMessageList msgList = param.getMessageParam().getMessage();
/* 178 */     if (msgList.size() > 1) {
/*     */       
/* 180 */       msg = new MCMessage(Core_Msg_FW_A.FCBGC0413, new Object[] { Integer.valueOf(msgList.size()) });
/*     */       
/* 182 */       xaL = MCList.create(ScreenR.class);
/* 183 */       ScreenR screenR = (ScreenR)xaL.createRow();
/* 184 */       screenR.type("PC");
/* 185 */       screenR.key("$screen$");
/* 186 */       screenR.val(createScreenValue("FS", "FSBGP0120"));
/* 187 */       xaL.add((MCRow)screenR);
/* 188 */       screenR = (ScreenR)xaL.createRow();
/* 189 */       screenR.type("PC");
/* 190 */       screenR.key("$action$");
/* 191 */       screenR.val("__search__");
/* 192 */       xaL.add((MCRow)screenR);
/*     */     }
/* 194 */     else if (msgList.size() == 1) {
/* 195 */       msg = (MCMessage)msgList.get(0);
/*     */       
/* 197 */       String usr_cocd = MCSys.user.coCD();
/* 198 */       String msg_cocd = noticeR.cocd();
/* 199 */       if (usr_cocd == msg_cocd || (usr_cocd != null && usr_cocd.equals(msg_cocd))) {
/* 200 */         xaL = screenL.subList("type", "PC");
/*     */       }
/*     */     } 
/* 203 */     RecvMessage recv = new RecvMessage();
/* 204 */     recv.pushid = noticeR.pushid();
/* 205 */     recv.cocd = noticeR.cocd();
/* 206 */     recv.title = noticeR.title();
/* 207 */     recv.importance = noticeR.importance();
/* 208 */     recv.msg = msg;
/* 209 */     recv.screenL = xaL;
/*     */     
/* 211 */     return recv;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sendMessage(MCPushMessage msg, String mid, String sid, String... users) {
/* 228 */     MCMessage message = msg.getMessage();
/* 229 */     if (message == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 234 */     NoticeR noticeR = NoticeR.create();
/* 235 */     noticeR.userid(MCSys.user.ID());
/* 236 */     noticeR.cocd(MCSys.user.coCD());
/* 237 */     noticeR.modid(mid);
/* 238 */     noticeR.logid(sid);
/* 239 */     noticeR.msgid(message.getID());
/* 240 */     noticeR.msgbind(createMessageBindForDB(message));
/* 241 */     MCMessage title = msg.getTitle();
/* 242 */     if (title == null)
/*     */     {
/* 244 */       title = new MCMessage(Core_Msg_FW_A.FCBAC0444, new Object[] {
/* 245 */             MCConst.label.getLabel(MCConst.createKey(new String[] { mid, sid, "label" }))
/*     */           });
/*     */     }
/* 248 */     noticeR.titleid(title.getID());
/* 249 */     noticeR.titlebind(createMessageBindForDB(title));
/* 250 */     noticeR.importance(msg.isImportance());
/*     */ 
/*     */     
/* 253 */     MCList<ScreenR> screenL = MCList.create(ScreenR.class);
/* 254 */     convScreenParamToList(msg, screenL, "type", "key", "val");
/*     */ 
/*     */     
/* 257 */     if (users == null || users.length == 0) {
/* 258 */       users = new String[] { MCSys.user.ID() };
/*     */     }
/* 260 */     MCList<UserR> userL = MCList.create(UserR.class); byte b; int i; String[] arrayOfString;
/* 261 */     for (i = (arrayOfString = users).length, b = 0; b < i; ) { String user = arrayOfString[b];
/* 262 */       UserR userR = (UserR)userL.createRow();
/* 263 */       userR.userid(user);
/* 264 */       userL.add((MCRow)userR);
/*     */       
/*     */       b++; }
/*     */     
/* 268 */     MCParam param = createParam("FC", "FCBGL0100", "ClientSend", "000000");
/* 269 */     param.getContainerParam().addUpBlock((MCContainer)noticeR);
/* 270 */     param.getContainerParam().addUpBlock((MCContainer)userL);
/* 271 */     param.getContainerParam().addUpBlock((MCContainer)screenL);
/* 272 */     MCCaller caller = new MCCaller(param);
/* 273 */     caller.exec();
/* 274 */     if (!param.getExceptionParam().isEmpty())
/*     */     {
/* 276 */       throw param.getExceptionParam().getException();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void checkUnread(boolean async) {
/* 291 */     Runnable r = new Runnable()
/*     */       {
/*     */         public void run()
/*     */         {
/*     */           try {
/* 296 */             MCList<UserR> userL = MCList.create(UserR.class);
/* 297 */             UserR userR = (UserR)userL.add();
/* 298 */             userR.userid(MCSys.user.ID());
/*     */             
/* 300 */             MCParam param = MCServerPushManager.this.createParam("FC", "FCBGL0100", "Unread", "000000");
/* 301 */             param.getContainerParam().addUpBlock((MCContainer)userL);
/* 302 */             MCCaller caller = new MCCaller(param);
/* 303 */             caller.exec();
/*     */           }
/* 305 */           catch (Throwable e) {
/* 306 */             MCException mce = (e instanceof MCException) ? (MCException)e : new MCException(e);
/* 307 */             MCLog.write((Throwable)mce);
/*     */           } 
/*     */         }
/*     */       };
/* 311 */     if (async) {
/* 312 */       (new Thread(r, "Push Message Unread")).start();
/*     */     } else {
/*     */       
/* 315 */       r.run();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRead(MCNumber... pushid) {
/*     */     try {
/* 329 */       MCList<NoticeR> noticeL = MCList.create(NoticeR.class); byte b; int i; MCNumber[] arrayOfMCNumber;
/* 330 */       for (i = (arrayOfMCNumber = pushid).length, b = 0; b < i; ) { MCNumber id = arrayOfMCNumber[b];
/* 331 */         NoticeR noticeR = (NoticeR)noticeL.add();
/* 332 */         noticeR.pushid(id); b++; }
/*     */       
/* 334 */       UserR userR = UserR.create();
/* 335 */       userR.userid(MCSys.user.ID());
/*     */       
/* 337 */       MCParam param = createParam("FC", "FCBGL0100", "Read", "000000");
/* 338 */       param.getContainerParam().addUpBlock((MCContainer)noticeL);
/* 339 */       param.getContainerParam().addUpBlock((MCContainer)userR);
/* 340 */       MCCaller caller = new MCCaller(param);
/* 341 */       caller.exec();
/*     */     }
/* 343 */     catch (Throwable e) {
/* 344 */       MCException mce = (e instanceof MCException) ? (MCException)e : new MCException(e);
/* 345 */       MCLog.write((Throwable)mce);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\push\MCServerPushManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */