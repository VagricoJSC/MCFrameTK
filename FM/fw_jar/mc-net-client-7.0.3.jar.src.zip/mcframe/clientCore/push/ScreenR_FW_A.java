/*     */ package mcframe.clientCore.push;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.clientCore.container.MCKeyList;
/*     */ import mcframe.commonCore.container.MCExtMap;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class ScreenR_FW_A
/*     */   extends MCConstRow
/*     */ {
/*     */   public static final String $type = "type";
/*     */   public static final String $key = "key";
/*     */   public static final String $val = "val";
/*  46 */   public static final MCMeta type_META = createStringMeta("type");
/*  47 */   public static final MCMeta key_META = createStringMeta("key");
/*  48 */   public static final MCMeta val_META = createStringMeta("val");
/*     */   
/*  50 */   protected static final MCRow.ConstMetaList<ScreenR> constMetas = new MCRow.ConstMetaList(
/*  51 */       MCConstRow.constMetas, 
/*  52 */       new MCMeta[] {
/*  53 */         type_META, 
/*  54 */         key_META, 
/*  55 */         val_META
/*     */       },
/*  57 */       new String[][] { {}, {} });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   protected static final MCKeyList KEYS = new MCKeyList(
/*  69 */       null, 
/*  70 */       new String[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   protected static final MCExtMap EXTMAP = new MCExtMap(
/*  79 */       null, new MCExtMap.Entry[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] colnames() {
/*  91 */     return constMetas.toNameArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMeta[] colmetas() {
/* 103 */     return constMetas.toMetaArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   private static final int offset = constMetas.offset();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCKeyList getKeys() {
/* 115 */     return KEYS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getExtMap(String aGroup) {
/* 122 */     if (aGroup == null) return null; 
/* 123 */     return (Map<String, String>)EXTMAP.get(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCKeyList getKeys(String aGroup) {
/* 130 */     if (aGroup == null) return null; 
/* 131 */     return new MCKeyList(EXTMAP.getKeyList(aGroup));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExtGroups() {
/* 138 */     Set<String> ret = EXTMAP.keySet();
/* 139 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ScreenR_FW_A(MCRow.ConstMetaList<? extends ScreenR> metas) {
/* 146 */     super(metas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ScreenR clone() {
/* 153 */     return (ScreenR)super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ScreenR createInstance() {
/* 160 */     return (ScreenR)super.createInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ScreenR getValues(String... names) {
/* 167 */     return (ScreenR)super.getValues(names);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String type() {
/* 177 */     return getConstString(offset + 0, "type");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void type(String value) {
/* 185 */     setConstString(offset + 0, "type", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String key() {
/* 194 */     return getConstString(offset + 1, "key");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void key(String value) {
/* 202 */     setConstString(offset + 1, "key", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String val() {
/* 211 */     return getConstString(offset + 2, "val");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void val(String value) {
/* 219 */     setConstString(offset + 2, "val", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString(String name) {
/* 224 */     if ("type".equalsIgnoreCase(name)) {
/* 225 */       return type();
/*     */     }
/* 227 */     if ("key".equalsIgnoreCase(name)) {
/* 228 */       return key();
/*     */     }
/* 230 */     if ("val".equalsIgnoreCase(name)) {
/* 231 */       return val();
/*     */     }
/* 233 */     return super.getString(name);
/*     */   }
/*     */   
/*     */   public String getStringNE(String name) {
/* 237 */     if ("type".equalsIgnoreCase(name)) {
/* 238 */       return type();
/*     */     }
/* 240 */     if ("key".equalsIgnoreCase(name)) {
/* 241 */       return key();
/*     */     }
/* 243 */     if ("val".equalsIgnoreCase(name)) {
/* 244 */       return val();
/*     */     }
/* 246 */     return super.getStringNE(name);
/*     */   }
/*     */   
/*     */   public void setString(String name, String value) {
/* 250 */     if ("type".equalsIgnoreCase(name)) {
/* 251 */       type(value);
/*     */       return;
/*     */     } 
/* 254 */     if ("key".equalsIgnoreCase(name)) {
/* 255 */       key(value);
/*     */       return;
/*     */     } 
/* 258 */     if ("val".equalsIgnoreCase(name)) {
/* 259 */       val(value);
/*     */       return;
/*     */     } 
/* 262 */     super.setString(name, value);
/*     */   }
/*     */   
/*     */   public void setStringNE(String name, String value) {
/* 266 */     if ("type".equalsIgnoreCase(name)) {
/* 267 */       type(value);
/*     */       return;
/*     */     } 
/* 270 */     if ("key".equalsIgnoreCase(name)) {
/* 271 */       key(value);
/*     */       return;
/*     */     } 
/* 274 */     if ("val".equalsIgnoreCase(name)) {
/* 275 */       val(value);
/*     */       return;
/*     */     } 
/* 278 */     super.setStringNE(name, value);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\push\ScreenR_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */