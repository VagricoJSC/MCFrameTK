/*    */ package mcframe.clientCore.push;
/*    */ 
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import mcframe.clientCore.container.MCKeyList;
/*    */ import mcframe.commonCore.annotation.EI;
/*    */ import mcframe.commonCore.container.MCRow;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @EI
/*    */ public class ScreenR
/*    */   extends ScreenR_FW_A
/*    */ {
/*    */   public static ScreenR create() {
/* 59 */     ScreenR row = new ScreenR(constMetas);
/* 60 */     return row;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static <T extends MCRow> ScreenR createByName(T proto) {
/* 70 */     ScreenR row = create();
/* 71 */     copyByName((MCRow)row, (MCRow)proto);
/* 72 */     return row;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ScreenR(MCRow.ConstMetaList<? extends ScreenR> metas) {
/* 79 */     super(metas);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\push\ScreenR.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */