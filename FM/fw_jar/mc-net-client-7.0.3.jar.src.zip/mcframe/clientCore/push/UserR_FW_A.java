/*     */ package mcframe.clientCore.push;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.clientCore.container.MCKeyList;
/*     */ import mcframe.commonCore.container.MCExtMap;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class UserR_FW_A
/*     */   extends MCConstRow
/*     */ {
/*     */   public static final String $userid = "userid";
/*  36 */   public static final MCMeta userid_META = createStringMeta("userid");
/*     */   
/*  38 */   protected static final MCRow.ConstMetaList<UserR> constMetas = new MCRow.ConstMetaList(
/*  39 */       MCConstRow.constMetas, 
/*  40 */       new MCMeta[] {
/*  41 */         userid_META
/*     */       },
/*  43 */       new String[][] { {}, {} });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   protected static final MCKeyList KEYS = new MCKeyList(
/*  55 */       null, 
/*  56 */       new String[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   protected static final MCExtMap EXTMAP = new MCExtMap(
/*  65 */       null, new MCExtMap.Entry[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] colnames() {
/*  77 */     return constMetas.toNameArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMeta[] colmetas() {
/*  89 */     return constMetas.toMetaArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   private static final int offset = constMetas.offset();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCKeyList getKeys() {
/* 101 */     return KEYS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getExtMap(String aGroup) {
/* 108 */     if (aGroup == null) return null; 
/* 109 */     return (Map<String, String>)EXTMAP.get(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCKeyList getKeys(String aGroup) {
/* 116 */     if (aGroup == null) return null; 
/* 117 */     return new MCKeyList(EXTMAP.getKeyList(aGroup));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExtGroups() {
/* 124 */     Set<String> ret = EXTMAP.keySet();
/* 125 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected UserR_FW_A(MCRow.ConstMetaList<? extends UserR> metas) {
/* 132 */     super(metas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UserR clone() {
/* 139 */     return (UserR)super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UserR createInstance() {
/* 146 */     return (UserR)super.createInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public UserR getValues(String... names) {
/* 153 */     return (UserR)super.getValues(names);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String userid() {
/* 163 */     return getConstString(offset + 0, "userid");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void userid(String value) {
/* 171 */     setConstString(offset + 0, "userid", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString(String name) {
/* 176 */     if ("userid".equalsIgnoreCase(name)) {
/* 177 */       return userid();
/*     */     }
/* 179 */     return super.getString(name);
/*     */   }
/*     */   
/*     */   public String getStringNE(String name) {
/* 183 */     if ("userid".equalsIgnoreCase(name)) {
/* 184 */       return userid();
/*     */     }
/* 186 */     return super.getStringNE(name);
/*     */   }
/*     */   
/*     */   public void setString(String name, String value) {
/* 190 */     if ("userid".equalsIgnoreCase(name)) {
/* 191 */       userid(value);
/*     */       return;
/*     */     } 
/* 194 */     super.setString(name, value);
/*     */   }
/*     */   
/*     */   public void setStringNE(String name, String value) {
/* 198 */     if ("userid".equalsIgnoreCase(name)) {
/* 199 */       userid(value);
/*     */       return;
/*     */     } 
/* 202 */     super.setStringNE(name, value);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\push\UserR_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */