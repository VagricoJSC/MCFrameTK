/*     */ package mcframe.clientCore.push;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.clientCore.container.MCKeyList;
/*     */ import mcframe.commonCore.container.MCExtMap;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class NoticeR_FW_A
/*     */   extends MCConstRow
/*     */ {
/*     */   public static final String $pushid = "pushid";
/*     */   public static final String $userid = "userid";
/*     */   public static final String $cocd = "cocd";
/*     */   public static final String $modid = "modid";
/*     */   public static final String $logid = "logid";
/*     */   public static final String $opeid = "opeid";
/*     */   public static final String $msgid = "msgid";
/*     */   public static final String $msgbind = "msgbind";
/*     */   public static final String $titleid = "titleid";
/*     */   public static final String $titlebind = "titlebind";
/*     */   public static final String $title = "title";
/*     */   public static final String $importance = "importance";
/*  91 */   public static final MCMeta pushid_META = createNumberMeta("pushid");
/*  92 */   public static final MCMeta userid_META = createStringMeta("userid");
/*  93 */   public static final MCMeta cocd_META = createStringMeta("cocd");
/*  94 */   public static final MCMeta modid_META = createStringMeta("modid");
/*  95 */   public static final MCMeta logid_META = createStringMeta("logid");
/*  96 */   public static final MCMeta opeid_META = createStringMeta("opeid");
/*  97 */   public static final MCMeta msgid_META = createStringMeta("msgid");
/*  98 */   public static final MCMeta msgbind_META = createStringMeta("msgbind");
/*  99 */   public static final MCMeta titleid_META = createStringMeta("titleid");
/* 100 */   public static final MCMeta titlebind_META = createStringMeta("titlebind");
/* 101 */   public static final MCMeta title_META = createStringMeta("title");
/* 102 */   public static final MCMeta importance_META = createBooleanMeta("importance");
/*     */   
/* 104 */   protected static final MCRow.ConstMetaList<NoticeR> constMetas = new MCRow.ConstMetaList(
/* 105 */       MCConstRow.constMetas, 
/* 106 */       new MCMeta[] { 
/* 107 */         pushid_META, 
/* 108 */         userid_META, 
/* 109 */         cocd_META, 
/* 110 */         modid_META, 
/* 111 */         logid_META, 
/* 112 */         opeid_META, 
/* 113 */         msgid_META, 
/* 114 */         msgbind_META, 
/* 115 */         titleid_META, 
/* 116 */         titlebind_META, 
/* 117 */         title_META, 
/* 118 */         importance_META
/*     */       },
/* 120 */       new String[][] { {}, {} });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 131 */   protected static final MCKeyList KEYS = new MCKeyList(
/* 132 */       null, 
/* 133 */       new String[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 141 */   protected static final MCExtMap EXTMAP = new MCExtMap(
/* 142 */       null, new MCExtMap.Entry[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] colnames() {
/* 154 */     return constMetas.toNameArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMeta[] colmetas() {
/* 166 */     return constMetas.toMetaArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 172 */   private static final int offset = constMetas.offset();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCKeyList getKeys() {
/* 178 */     return KEYS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getExtMap(String aGroup) {
/* 185 */     if (aGroup == null) return null; 
/* 186 */     return (Map<String, String>)EXTMAP.get(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCKeyList getKeys(String aGroup) {
/* 193 */     if (aGroup == null) return null; 
/* 194 */     return new MCKeyList(EXTMAP.getKeyList(aGroup));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExtGroups() {
/* 201 */     Set<String> ret = EXTMAP.keySet();
/* 202 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected NoticeR_FW_A(MCRow.ConstMetaList<? extends NoticeR> metas) {
/* 209 */     super(metas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NoticeR clone() {
/* 216 */     return (NoticeR)super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NoticeR createInstance() {
/* 223 */     return (NoticeR)super.createInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NoticeR getValues(String... names) {
/* 230 */     return (NoticeR)super.getValues(names);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCNumber pushid() {
/* 240 */     return getConstNumber(offset + 0, "pushid");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pushid(MCNumber value) {
/* 248 */     setConstNumber(offset + 0, "pushid", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pushid(int value) {
/* 256 */     setConstNumber(offset + 0, "pushid", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pushid(long value) {
/* 264 */     setConstNumber(offset + 0, "pushid", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pushid(float value) {
/* 272 */     setConstNumber(offset + 0, "pushid", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pushid(double value) {
/* 280 */     setConstNumber(offset + 0, "pushid", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String userid() {
/* 289 */     return getConstString(offset + 1, "userid");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void userid(String value) {
/* 297 */     setConstString(offset + 1, "userid", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String cocd() {
/* 306 */     return getConstString(offset + 2, "cocd");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cocd(String value) {
/* 314 */     setConstString(offset + 2, "cocd", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String modid() {
/* 323 */     return getConstString(offset + 3, "modid");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void modid(String value) {
/* 331 */     setConstString(offset + 3, "modid", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String logid() {
/* 340 */     return getConstString(offset + 4, "logid");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logid(String value) {
/* 348 */     setConstString(offset + 4, "logid", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String opeid() {
/* 357 */     return getConstString(offset + 5, "opeid");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void opeid(String value) {
/* 365 */     setConstString(offset + 5, "opeid", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String msgid() {
/* 374 */     return getConstString(offset + 6, "msgid");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void msgid(String value) {
/* 382 */     setConstString(offset + 6, "msgid", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String msgbind() {
/* 391 */     return getConstString(offset + 7, "msgbind");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void msgbind(String value) {
/* 399 */     setConstString(offset + 7, "msgbind", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String titleid() {
/* 408 */     return getConstString(offset + 8, "titleid");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void titleid(String value) {
/* 416 */     setConstString(offset + 8, "titleid", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String titlebind() {
/* 425 */     return getConstString(offset + 9, "titlebind");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void titlebind(String value) {
/* 433 */     setConstString(offset + 9, "titlebind", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String title() {
/* 442 */     return getConstString(offset + 10, "title");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void title(String value) {
/* 450 */     setConstString(offset + 10, "title", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean importance() {
/* 459 */     return getConstBoolean(offset + 11, "importance");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void importance(boolean value) {
/* 467 */     setConstBoolean(offset + 11, "importance", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString(String name) {
/* 472 */     if ("userid".equalsIgnoreCase(name)) {
/* 473 */       return userid();
/*     */     }
/* 475 */     if ("cocd".equalsIgnoreCase(name)) {
/* 476 */       return cocd();
/*     */     }
/* 478 */     if ("modid".equalsIgnoreCase(name)) {
/* 479 */       return modid();
/*     */     }
/* 481 */     if ("logid".equalsIgnoreCase(name)) {
/* 482 */       return logid();
/*     */     }
/* 484 */     if ("opeid".equalsIgnoreCase(name)) {
/* 485 */       return opeid();
/*     */     }
/* 487 */     if ("msgid".equalsIgnoreCase(name)) {
/* 488 */       return msgid();
/*     */     }
/* 490 */     if ("msgbind".equalsIgnoreCase(name)) {
/* 491 */       return msgbind();
/*     */     }
/* 493 */     if ("titleid".equalsIgnoreCase(name)) {
/* 494 */       return titleid();
/*     */     }
/* 496 */     if ("titlebind".equalsIgnoreCase(name)) {
/* 497 */       return titlebind();
/*     */     }
/* 499 */     if ("title".equalsIgnoreCase(name)) {
/* 500 */       return title();
/*     */     }
/* 502 */     return super.getString(name);
/*     */   }
/*     */   public MCNumber getNumber(String name) {
/* 505 */     if ("pushid".equalsIgnoreCase(name)) {
/* 506 */       return pushid();
/*     */     }
/* 508 */     return super.getNumber(name);
/*     */   }
/*     */   public boolean getBoolean(String name) {
/* 511 */     if ("importance".equalsIgnoreCase(name)) {
/* 512 */       return importance();
/*     */     }
/* 514 */     return super.getBoolean(name);
/*     */   }
/*     */   
/*     */   public String getStringNE(String name) {
/* 518 */     if ("userid".equalsIgnoreCase(name)) {
/* 519 */       return userid();
/*     */     }
/* 521 */     if ("cocd".equalsIgnoreCase(name)) {
/* 522 */       return cocd();
/*     */     }
/* 524 */     if ("modid".equalsIgnoreCase(name)) {
/* 525 */       return modid();
/*     */     }
/* 527 */     if ("logid".equalsIgnoreCase(name)) {
/* 528 */       return logid();
/*     */     }
/* 530 */     if ("opeid".equalsIgnoreCase(name)) {
/* 531 */       return opeid();
/*     */     }
/* 533 */     if ("msgid".equalsIgnoreCase(name)) {
/* 534 */       return msgid();
/*     */     }
/* 536 */     if ("msgbind".equalsIgnoreCase(name)) {
/* 537 */       return msgbind();
/*     */     }
/* 539 */     if ("titleid".equalsIgnoreCase(name)) {
/* 540 */       return titleid();
/*     */     }
/* 542 */     if ("titlebind".equalsIgnoreCase(name)) {
/* 543 */       return titlebind();
/*     */     }
/* 545 */     if ("title".equalsIgnoreCase(name)) {
/* 546 */       return title();
/*     */     }
/* 548 */     return super.getStringNE(name);
/*     */   }
/*     */   public MCNumber getNumberNE(String name) {
/* 551 */     if ("pushid".equalsIgnoreCase(name)) {
/* 552 */       return pushid();
/*     */     }
/* 554 */     return super.getNumberNE(name);
/*     */   }
/*     */   public boolean getBooleanNE(String name) {
/* 557 */     if ("importance".equalsIgnoreCase(name)) {
/* 558 */       return importance();
/*     */     }
/* 560 */     return super.getBooleanNE(name);
/*     */   }
/*     */   
/*     */   public void setString(String name, String value) {
/* 564 */     if ("userid".equalsIgnoreCase(name)) {
/* 565 */       userid(value);
/*     */       return;
/*     */     } 
/* 568 */     if ("cocd".equalsIgnoreCase(name)) {
/* 569 */       cocd(value);
/*     */       return;
/*     */     } 
/* 572 */     if ("modid".equalsIgnoreCase(name)) {
/* 573 */       modid(value);
/*     */       return;
/*     */     } 
/* 576 */     if ("logid".equalsIgnoreCase(name)) {
/* 577 */       logid(value);
/*     */       return;
/*     */     } 
/* 580 */     if ("opeid".equalsIgnoreCase(name)) {
/* 581 */       opeid(value);
/*     */       return;
/*     */     } 
/* 584 */     if ("msgid".equalsIgnoreCase(name)) {
/* 585 */       msgid(value);
/*     */       return;
/*     */     } 
/* 588 */     if ("msgbind".equalsIgnoreCase(name)) {
/* 589 */       msgbind(value);
/*     */       return;
/*     */     } 
/* 592 */     if ("titleid".equalsIgnoreCase(name)) {
/* 593 */       titleid(value);
/*     */       return;
/*     */     } 
/* 596 */     if ("titlebind".equalsIgnoreCase(name)) {
/* 597 */       titlebind(value);
/*     */       return;
/*     */     } 
/* 600 */     if ("title".equalsIgnoreCase(name)) {
/* 601 */       title(value);
/*     */       return;
/*     */     } 
/* 604 */     super.setString(name, value);
/*     */   }
/*     */   public void setNumber(String name, MCNumber value) {
/* 607 */     if ("pushid".equalsIgnoreCase(name)) {
/* 608 */       pushid(value);
/*     */       return;
/*     */     } 
/* 611 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, int value) {
/* 614 */     if ("pushid".equalsIgnoreCase(name)) {
/* 615 */       pushid(value);
/*     */       return;
/*     */     } 
/* 618 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, long value) {
/* 621 */     if ("pushid".equalsIgnoreCase(name)) {
/* 622 */       pushid(value);
/*     */       return;
/*     */     } 
/* 625 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, float value) {
/* 628 */     if ("pushid".equalsIgnoreCase(name)) {
/* 629 */       pushid(value);
/*     */       return;
/*     */     } 
/* 632 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, double value) {
/* 635 */     if ("pushid".equalsIgnoreCase(name)) {
/* 636 */       pushid(value);
/*     */       return;
/*     */     } 
/* 639 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setBoolean(String name, boolean value) {
/* 642 */     if ("importance".equalsIgnoreCase(name)) {
/* 643 */       importance(value);
/*     */       return;
/*     */     } 
/* 646 */     super.setBoolean(name, value);
/*     */   }
/*     */   
/*     */   public void setStringNE(String name, String value) {
/* 650 */     if ("userid".equalsIgnoreCase(name)) {
/* 651 */       userid(value);
/*     */       return;
/*     */     } 
/* 654 */     if ("cocd".equalsIgnoreCase(name)) {
/* 655 */       cocd(value);
/*     */       return;
/*     */     } 
/* 658 */     if ("modid".equalsIgnoreCase(name)) {
/* 659 */       modid(value);
/*     */       return;
/*     */     } 
/* 662 */     if ("logid".equalsIgnoreCase(name)) {
/* 663 */       logid(value);
/*     */       return;
/*     */     } 
/* 666 */     if ("opeid".equalsIgnoreCase(name)) {
/* 667 */       opeid(value);
/*     */       return;
/*     */     } 
/* 670 */     if ("msgid".equalsIgnoreCase(name)) {
/* 671 */       msgid(value);
/*     */       return;
/*     */     } 
/* 674 */     if ("msgbind".equalsIgnoreCase(name)) {
/* 675 */       msgbind(value);
/*     */       return;
/*     */     } 
/* 678 */     if ("titleid".equalsIgnoreCase(name)) {
/* 679 */       titleid(value);
/*     */       return;
/*     */     } 
/* 682 */     if ("titlebind".equalsIgnoreCase(name)) {
/* 683 */       titlebind(value);
/*     */       return;
/*     */     } 
/* 686 */     if ("title".equalsIgnoreCase(name)) {
/* 687 */       title(value);
/*     */       return;
/*     */     } 
/* 690 */     super.setStringNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, MCNumber value) {
/* 693 */     if ("pushid".equalsIgnoreCase(name)) {
/* 694 */       pushid(value);
/*     */       return;
/*     */     } 
/* 697 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, int value) {
/* 700 */     if ("pushid".equalsIgnoreCase(name)) {
/* 701 */       pushid(value);
/*     */       return;
/*     */     } 
/* 704 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, long value) {
/* 707 */     if ("pushid".equalsIgnoreCase(name)) {
/* 708 */       pushid(value);
/*     */       return;
/*     */     } 
/* 711 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, float value) {
/* 714 */     if ("pushid".equalsIgnoreCase(name)) {
/* 715 */       pushid(value);
/*     */       return;
/*     */     } 
/* 718 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, double value) {
/* 721 */     if ("pushid".equalsIgnoreCase(name)) {
/* 722 */       pushid(value);
/*     */       return;
/*     */     } 
/* 725 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setBooleanNE(String name, boolean value) {
/* 728 */     if ("importance".equalsIgnoreCase(name)) {
/* 729 */       importance(value);
/*     */       return;
/*     */     } 
/* 732 */     super.setBooleanNE(name, value);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\push\NoticeR_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */