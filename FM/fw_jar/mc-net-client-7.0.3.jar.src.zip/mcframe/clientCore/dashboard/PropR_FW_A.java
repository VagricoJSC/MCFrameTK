/*     */ package mcframe.clientCore.dashboard;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.clientCore.container.MCKeyList;
/*     */ import mcframe.commonCore.container.MCExtMap;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class PropR_FW_A
/*     */   extends MCConstRow
/*     */ {
/*     */   public static final String $gadget = "gadget";
/*     */   public static final String $key = "key";
/*     */   public static final String $value = "value";
/*  46 */   public static final MCMeta gadget_META = createStringMeta("gadget");
/*  47 */   public static final MCMeta key_META = createStringMeta("key");
/*  48 */   public static final MCMeta value_META = createStringMeta("value");
/*     */   
/*  50 */   protected static final MCRow.ConstMetaList<PropR> constMetas = new MCRow.ConstMetaList(
/*  51 */       MCConstRow.constMetas, 
/*  52 */       new MCMeta[] {
/*  53 */         gadget_META, 
/*  54 */         key_META, 
/*  55 */         value_META
/*     */       },
/*  57 */       new String[][] { {}, {} });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   protected static final MCKeyList KEYS = new MCKeyList(
/*  69 */       null, 
/*  70 */       new String[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   protected static final MCExtMap EXTMAP = new MCExtMap(
/*  79 */       null, new MCExtMap.Entry[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] colnames() {
/*  91 */     return constMetas.toNameArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMeta[] colmetas() {
/* 103 */     return constMetas.toMetaArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   private static final int offset = constMetas.offset();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCKeyList getKeys() {
/* 115 */     return KEYS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getExtMap(String aGroup) {
/* 122 */     if (aGroup == null) return null; 
/* 123 */     return (Map<String, String>)EXTMAP.get(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCKeyList getKeys(String aGroup) {
/* 130 */     if (aGroup == null) return null; 
/* 131 */     return new MCKeyList(EXTMAP.getKeyList(aGroup));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExtGroups() {
/* 138 */     Set<String> ret = EXTMAP.keySet();
/* 139 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PropR_FW_A(MCRow.ConstMetaList<? extends PropR> metas) {
/* 146 */     super(metas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropR clone() {
/* 153 */     return (PropR)super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropR createInstance() {
/* 160 */     return (PropR)super.createInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropR getValues(String... names) {
/* 167 */     return (PropR)super.getValues(names);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String gadget() {
/* 177 */     return getConstString(offset + 0, "gadget");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void gadget(String value) {
/* 185 */     setConstString(offset + 0, "gadget", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String key() {
/* 194 */     return getConstString(offset + 1, "key");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void key(String value) {
/* 202 */     setConstString(offset + 1, "key", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String value() {
/* 211 */     return getConstString(offset + 2, "value");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void value(String value) {
/* 219 */     setConstString(offset + 2, "value", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString(String name) {
/* 224 */     if ("gadget".equalsIgnoreCase(name)) {
/* 225 */       return gadget();
/*     */     }
/* 227 */     if ("key".equalsIgnoreCase(name)) {
/* 228 */       return key();
/*     */     }
/* 230 */     if ("value".equalsIgnoreCase(name)) {
/* 231 */       return value();
/*     */     }
/* 233 */     return super.getString(name);
/*     */   }
/*     */   
/*     */   public String getStringNE(String name) {
/* 237 */     if ("gadget".equalsIgnoreCase(name)) {
/* 238 */       return gadget();
/*     */     }
/* 240 */     if ("key".equalsIgnoreCase(name)) {
/* 241 */       return key();
/*     */     }
/* 243 */     if ("value".equalsIgnoreCase(name)) {
/* 244 */       return value();
/*     */     }
/* 246 */     return super.getStringNE(name);
/*     */   }
/*     */   
/*     */   public void setString(String name, String value) {
/* 250 */     if ("gadget".equalsIgnoreCase(name)) {
/* 251 */       gadget(value);
/*     */       return;
/*     */     } 
/* 254 */     if ("key".equalsIgnoreCase(name)) {
/* 255 */       key(value);
/*     */       return;
/*     */     } 
/* 258 */     if ("value".equalsIgnoreCase(name)) {
/* 259 */       value(value);
/*     */       return;
/*     */     } 
/* 262 */     super.setString(name, value);
/*     */   }
/*     */   
/*     */   public void setStringNE(String name, String value) {
/* 266 */     if ("gadget".equalsIgnoreCase(name)) {
/* 267 */       gadget(value);
/*     */       return;
/*     */     } 
/* 270 */     if ("key".equalsIgnoreCase(name)) {
/* 271 */       key(value);
/*     */       return;
/*     */     } 
/* 274 */     if ("value".equalsIgnoreCase(name)) {
/* 275 */       value(value);
/*     */       return;
/*     */     } 
/* 278 */     super.setStringNE(name, value);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\dashboard\PropR_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */