/*     */ package mcframe.clientCore.dashboard;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.clientCore.container.MCKeyList;
/*     */ import mcframe.commonCore.container.MCExtMap;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class ListR_FW_A
/*     */   extends MCConstRow
/*     */ {
/*     */   public static final String $gkey = "gkey";
/*     */   public static final String $item = "item";
/*     */   public static final String $value = "value";
/*     */   public static final String $name = "name";
/*     */   public static final String $parent = "parent";
/*     */   public static final String $filter = "filter";
/*  61 */   public static final MCMeta gkey_META = createStringMeta("gkey");
/*  62 */   public static final MCMeta item_META = createStringMeta("item");
/*  63 */   public static final MCMeta value_META = createStringMeta("value");
/*  64 */   public static final MCMeta name_META = createStringMeta("name");
/*  65 */   public static final MCMeta parent_META = createStringMeta("parent");
/*  66 */   public static final MCMeta filter_META = createStringMeta("filter");
/*     */   
/*  68 */   protected static final MCRow.ConstMetaList<ListR> constMetas = new MCRow.ConstMetaList(
/*  69 */       MCConstRow.constMetas, 
/*  70 */       new MCMeta[] {
/*  71 */         gkey_META, 
/*  72 */         item_META, 
/*  73 */         value_META, 
/*  74 */         name_META, 
/*  75 */         parent_META, 
/*  76 */         filter_META
/*     */       },
/*  78 */       new String[][] { {}, {} });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   protected static final MCKeyList KEYS = new MCKeyList(
/*  90 */       null, 
/*  91 */       new String[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  99 */   protected static final MCExtMap EXTMAP = new MCExtMap(
/* 100 */       null, new MCExtMap.Entry[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] colnames() {
/* 112 */     return constMetas.toNameArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMeta[] colmetas() {
/* 124 */     return constMetas.toMetaArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 130 */   private static final int offset = constMetas.offset();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCKeyList getKeys() {
/* 136 */     return KEYS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getExtMap(String aGroup) {
/* 143 */     if (aGroup == null) return null; 
/* 144 */     return (Map<String, String>)EXTMAP.get(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCKeyList getKeys(String aGroup) {
/* 151 */     if (aGroup == null) return null; 
/* 152 */     return new MCKeyList(EXTMAP.getKeyList(aGroup));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExtGroups() {
/* 159 */     Set<String> ret = EXTMAP.keySet();
/* 160 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ListR_FW_A(MCRow.ConstMetaList<? extends ListR> metas) {
/* 167 */     super(metas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ListR clone() {
/* 174 */     return (ListR)super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ListR createInstance() {
/* 181 */     return (ListR)super.createInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ListR getValues(String... names) {
/* 188 */     return (ListR)super.getValues(names);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String gkey() {
/* 198 */     return getConstString(offset + 0, "gkey");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void gkey(String value) {
/* 206 */     setConstString(offset + 0, "gkey", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String item() {
/* 215 */     return getConstString(offset + 1, "item");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void item(String value) {
/* 223 */     setConstString(offset + 1, "item", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String value() {
/* 232 */     return getConstString(offset + 2, "value");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void value(String value) {
/* 240 */     setConstString(offset + 2, "value", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String name() {
/* 249 */     return getConstString(offset + 3, "name");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void name(String value) {
/* 257 */     setConstString(offset + 3, "name", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String parent() {
/* 266 */     return getConstString(offset + 4, "parent");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void parent(String value) {
/* 274 */     setConstString(offset + 4, "parent", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String filter() {
/* 283 */     return getConstString(offset + 5, "filter");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void filter(String value) {
/* 291 */     setConstString(offset + 5, "filter", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString(String name) {
/* 296 */     if ("gkey".equalsIgnoreCase(name)) {
/* 297 */       return gkey();
/*     */     }
/* 299 */     if ("item".equalsIgnoreCase(name)) {
/* 300 */       return item();
/*     */     }
/* 302 */     if ("value".equalsIgnoreCase(name)) {
/* 303 */       return value();
/*     */     }
/* 305 */     if ("name".equalsIgnoreCase(name)) {
/* 306 */       return name();
/*     */     }
/* 308 */     if ("parent".equalsIgnoreCase(name)) {
/* 309 */       return parent();
/*     */     }
/* 311 */     if ("filter".equalsIgnoreCase(name)) {
/* 312 */       return filter();
/*     */     }
/* 314 */     return super.getString(name);
/*     */   }
/*     */   
/*     */   public String getStringNE(String name) {
/* 318 */     if ("gkey".equalsIgnoreCase(name)) {
/* 319 */       return gkey();
/*     */     }
/* 321 */     if ("item".equalsIgnoreCase(name)) {
/* 322 */       return item();
/*     */     }
/* 324 */     if ("value".equalsIgnoreCase(name)) {
/* 325 */       return value();
/*     */     }
/* 327 */     if ("name".equalsIgnoreCase(name)) {
/* 328 */       return name();
/*     */     }
/* 330 */     if ("parent".equalsIgnoreCase(name)) {
/* 331 */       return parent();
/*     */     }
/* 333 */     if ("filter".equalsIgnoreCase(name)) {
/* 334 */       return filter();
/*     */     }
/* 336 */     return super.getStringNE(name);
/*     */   }
/*     */   
/*     */   public void setString(String name, String value) {
/* 340 */     if ("gkey".equalsIgnoreCase(name)) {
/* 341 */       gkey(value);
/*     */       return;
/*     */     } 
/* 344 */     if ("item".equalsIgnoreCase(name)) {
/* 345 */       item(value);
/*     */       return;
/*     */     } 
/* 348 */     if ("value".equalsIgnoreCase(name)) {
/* 349 */       value(value);
/*     */       return;
/*     */     } 
/* 352 */     if ("name".equalsIgnoreCase(name)) {
/* 353 */       name(value);
/*     */       return;
/*     */     } 
/* 356 */     if ("parent".equalsIgnoreCase(name)) {
/* 357 */       parent(value);
/*     */       return;
/*     */     } 
/* 360 */     if ("filter".equalsIgnoreCase(name)) {
/* 361 */       filter(value);
/*     */       return;
/*     */     } 
/* 364 */     super.setString(name, value);
/*     */   }
/*     */   
/*     */   public void setStringNE(String name, String value) {
/* 368 */     if ("gkey".equalsIgnoreCase(name)) {
/* 369 */       gkey(value);
/*     */       return;
/*     */     } 
/* 372 */     if ("item".equalsIgnoreCase(name)) {
/* 373 */       item(value);
/*     */       return;
/*     */     } 
/* 376 */     if ("value".equalsIgnoreCase(name)) {
/* 377 */       value(value);
/*     */       return;
/*     */     } 
/* 380 */     if ("name".equalsIgnoreCase(name)) {
/* 381 */       name(value);
/*     */       return;
/*     */     } 
/* 384 */     if ("parent".equalsIgnoreCase(name)) {
/* 385 */       parent(value);
/*     */       return;
/*     */     } 
/* 388 */     if ("filter".equalsIgnoreCase(name)) {
/* 389 */       filter(value);
/*     */       return;
/*     */     } 
/* 392 */     super.setStringNE(name, value);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\dashboard\ListR_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */