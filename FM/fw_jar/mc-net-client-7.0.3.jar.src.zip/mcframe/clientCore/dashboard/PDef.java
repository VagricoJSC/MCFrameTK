package mcframe.clientCore.dashboard;

import mcframe.commonCore.annotation.EI;

@EI
public class PDef extends PDef_FW_A {}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\dashboard\PDef.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */