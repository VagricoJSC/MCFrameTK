/*     */ package mcframe.clientCore.dashboard;
/*     */ 
/*     */ import mcframe.commonCore.param.MCBlockDef;
/*     */ import mcframe.commonCore.param.MCContainerDef;
/*     */ import mcframe.commonCore.param.MCDef;
/*     */ import mcframe.commonCore.param.MCGeneralContainerDef;
/*     */ import mcframe.commonCore.param.MCItemDef;
/*     */ import mcframe.commonCore.param.MCOperationInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PDef_FW_A
/*     */   extends MCDef
/*     */ {
/*     */   public MCContainerDef getCustomDef(String id) {
/*  19 */     if (id == null) {
/*  20 */       return null;
/*     */     }
/*     */     
/*  23 */     if (id.equals("FC.FCBAL0020.Srch01.UP.BLOCK0")) {
/*  24 */       return FC_FCBAL0020_Srch01_UP_BLOCK0();
/*     */     }
/*  26 */     if (id.equals("FC.FCBAL0020.Srch01.UP.BLOCK1")) {
/*  27 */       return FC_FCBAL0020_Srch01_UP_BLOCK1();
/*     */     }
/*  29 */     if (id.equals("FC.FCBAL0020.Srch01.DOWN.BLOCK0")) {
/*  30 */       return FC_FCBAL0020_Srch01_DOWN_BLOCK0();
/*     */     }
/*  32 */     if (id.equals("FC.FCBAL0020.Srch02.UP.BLOCK0")) {
/*  33 */       return FC_FCBAL0020_Srch02_UP_BLOCK0();
/*     */     }
/*  35 */     if (id.equals("FC.FCBAL0020.Srch02.UP.BLOCK1")) {
/*  36 */       return FC_FCBAL0020_Srch02_UP_BLOCK1();
/*     */     }
/*  38 */     if (id.equals("FC.FCBAL0020.Srch02.DOWN.BLOCK0")) {
/*  39 */       return FC_FCBAL0020_Srch02_DOWN_BLOCK0();
/*     */     }
/*  41 */     if (id.equals("FC.FCBAL0020.Srch03.UP.BLOCK0")) {
/*  42 */       return FC_FCBAL0020_Srch03_UP_BLOCK0();
/*     */     }
/*  44 */     if (id.equals("FC.FCBAL0020.Srch03.UP.BLOCK1")) {
/*  45 */       return FC_FCBAL0020_Srch03_UP_BLOCK1();
/*     */     }
/*  47 */     if (id.equals("FC.FCBAL0020.Srch03.DOWN.BLOCK0")) {
/*  48 */       return FC_FCBAL0020_Srch03_DOWN_BLOCK0();
/*     */     }
/*     */ 
/*     */     
/*  52 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   static final MCOperationInfo FC_FCBAL0020_Srch01_INFO = new MCOperationInfo("FC", "FCBAL0020", "Srch01", "000000", new PDef());
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBAL0020_Srch01_UP_BLOCK0() {
/*  62 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBAL0020", "Srch01", 
/*  63 */         new MCItemDef[] {
/*  64 */           MCItemDef.create("devtype", "devtype")
/*     */ 
/*     */         
/*  67 */         }MCBlockDef.create("Dev"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBAL0020_Srch01_UP_BLOCK1() {
/*  73 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBAL0020", "Srch01", 
/*  74 */         new MCItemDef[] {
/*  75 */           MCItemDef.create("gadget", "gadget")
/*     */ 
/*     */         
/*  78 */         }MCBlockDef.create("Cnd"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBAL0020_Srch01_DOWN_BLOCK0() {
/*  85 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBAL0020", "Srch01", 
/*  86 */         new MCItemDef[] {
/*  87 */           MCItemDef.create("gadget", "gadget"), 
/*  88 */           MCItemDef.create("key", "key"), 
/*  89 */           MCItemDef.create("value", "value")
/*     */ 
/*     */         
/*  92 */         }MCBlockDef.create("Prop"));
/*     */   }
/*     */ 
/*     */   
/*  96 */   static final MCOperationInfo FC_FCBAL0020_Srch02_INFO = new MCOperationInfo("FC", "FCBAL0020", "Srch02", "000000", new PDef());
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBAL0020_Srch02_UP_BLOCK0() {
/* 100 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBAL0020", "Srch02", 
/* 101 */         new MCItemDef[] {
/* 102 */           MCItemDef.create("devtype", "devtype")
/*     */ 
/*     */         
/* 105 */         }MCBlockDef.create("Dev"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBAL0020_Srch02_UP_BLOCK1() {
/* 111 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBAL0020", "Srch02", 
/* 112 */         new MCItemDef[] {
/* 113 */           MCItemDef.create("gkey", "gkey"), 
/* 114 */           MCItemDef.create("gadget", "gadget"), 
/* 115 */           MCItemDef.create("item", "item"), 
/* 116 */           MCItemDef.create("strval", "strval"), 
/* 117 */           MCItemDef.create("numval", "numval"), 
/* 118 */           MCItemDef.create("booval", "booval"), 
/* 119 */           MCItemDef.create("dtval", "dtval"), 
/* 120 */           MCItemDef.create("tsval", "tsval"), 
/* 121 */           MCItemDef.create("binval", "binval")
/*     */ 
/*     */         
/* 124 */         }MCBlockDef.create("Cnd"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBAL0020_Srch02_DOWN_BLOCK0() {
/* 131 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBAL0020", "Srch02", 
/* 132 */         new MCItemDef[] {
/* 133 */           MCItemDef.create("gkey", "gkey"), 
/* 134 */           MCItemDef.create("item", "item"), 
/* 135 */           MCItemDef.create("strval", "strval"), 
/* 136 */           MCItemDef.create("numval", "numval"), 
/* 137 */           MCItemDef.create("booval", "booval"), 
/* 138 */           MCItemDef.create("dtval", "dtval"), 
/* 139 */           MCItemDef.create("tsval", "tsval"), 
/* 140 */           MCItemDef.create("binval", "binval")
/*     */ 
/*     */         
/* 143 */         }MCBlockDef.create("Data"));
/*     */   }
/*     */ 
/*     */   
/* 147 */   static final MCOperationInfo FC_FCBAL0020_Srch03_INFO = new MCOperationInfo("FC", "FCBAL0020", "Srch03", "000000", new PDef());
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBAL0020_Srch03_UP_BLOCK0() {
/* 151 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBAL0020", "Srch03", 
/* 152 */         new MCItemDef[] {
/* 153 */           MCItemDef.create("devtype", "devtype")
/*     */ 
/*     */         
/* 156 */         }MCBlockDef.create("Dev"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBAL0020_Srch03_UP_BLOCK1() {
/* 162 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBAL0020", "Srch03", 
/* 163 */         new MCItemDef[] {
/* 164 */           MCItemDef.create("gkey", "gkey"), 
/* 165 */           MCItemDef.create("gadget", "gadget"), 
/* 166 */           MCItemDef.create("item", "item")
/*     */ 
/*     */         
/* 169 */         }MCBlockDef.create("Cnd"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBAL0020_Srch03_DOWN_BLOCK0() {
/* 176 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBAL0020", "Srch03", 
/* 177 */         new MCItemDef[] {
/* 178 */           MCItemDef.create("gkey", "gkey"), 
/* 179 */           MCItemDef.create("item", "item"), 
/* 180 */           MCItemDef.create("value", "value"), 
/* 181 */           MCItemDef.create("name", "name"), 
/* 182 */           MCItemDef.create("parent", "parent"), 
/* 183 */           MCItemDef.create("filter", "filter")
/*     */ 
/*     */         
/* 186 */         }MCBlockDef.create("List"));
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\dashboard\PDef_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */