/*     */ package mcframe.clientCore.dashboard;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.clientCore.container.MCKeyList;
/*     */ import mcframe.commonCore.container.MCExtMap;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class DevR_FW_A
/*     */   extends MCConstRow
/*     */ {
/*     */   public static final String $devtype = "devtype";
/*  36 */   public static final MCMeta devtype_META = createStringMeta("devtype");
/*     */   
/*  38 */   protected static final MCRow.ConstMetaList<DevR> constMetas = new MCRow.ConstMetaList(
/*  39 */       MCConstRow.constMetas, 
/*  40 */       new MCMeta[] {
/*  41 */         devtype_META
/*     */       },
/*  43 */       new String[][] { {}, {} });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   protected static final MCKeyList KEYS = new MCKeyList(
/*  55 */       null, 
/*  56 */       new String[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   protected static final MCExtMap EXTMAP = new MCExtMap(
/*  65 */       null, new MCExtMap.Entry[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] colnames() {
/*  77 */     return constMetas.toNameArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMeta[] colmetas() {
/*  89 */     return constMetas.toMetaArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   private static final int offset = constMetas.offset();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCKeyList getKeys() {
/* 101 */     return KEYS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getExtMap(String aGroup) {
/* 108 */     if (aGroup == null) return null; 
/* 109 */     return (Map<String, String>)EXTMAP.get(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCKeyList getKeys(String aGroup) {
/* 116 */     if (aGroup == null) return null; 
/* 117 */     return new MCKeyList(EXTMAP.getKeyList(aGroup));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExtGroups() {
/* 124 */     Set<String> ret = EXTMAP.keySet();
/* 125 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DevR_FW_A(MCRow.ConstMetaList<? extends DevR> metas) {
/* 132 */     super(metas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DevR clone() {
/* 139 */     return (DevR)super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DevR createInstance() {
/* 146 */     return (DevR)super.createInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DevR getValues(String... names) {
/* 153 */     return (DevR)super.getValues(names);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String devtype() {
/* 163 */     return getConstString(offset + 0, "devtype");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void devtype(String value) {
/* 171 */     setConstString(offset + 0, "devtype", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString(String name) {
/* 176 */     if ("devtype".equalsIgnoreCase(name)) {
/* 177 */       return devtype();
/*     */     }
/* 179 */     return super.getString(name);
/*     */   }
/*     */   
/*     */   public String getStringNE(String name) {
/* 183 */     if ("devtype".equalsIgnoreCase(name)) {
/* 184 */       return devtype();
/*     */     }
/* 186 */     return super.getStringNE(name);
/*     */   }
/*     */   
/*     */   public void setString(String name, String value) {
/* 190 */     if ("devtype".equalsIgnoreCase(name)) {
/* 191 */       devtype(value);
/*     */       return;
/*     */     } 
/* 194 */     super.setString(name, value);
/*     */   }
/*     */   
/*     */   public void setStringNE(String name, String value) {
/* 198 */     if ("devtype".equalsIgnoreCase(name)) {
/* 199 */       devtype(value);
/*     */       return;
/*     */     } 
/* 202 */     super.setStringNE(name, value);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\dashboard\DevR_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */