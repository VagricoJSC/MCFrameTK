/*     */ package mcframe.clientCore.dashboard;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.clientCore.container.MCKeyList;
/*     */ import mcframe.commonCore.container.MCExtMap;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCBinary;
/*     */ import mcframe.commonCore.lang.MCDate;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.lang.MCTimestamp;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class DataR_FW_A
/*     */   extends MCConstRow
/*     */ {
/*     */   public static final String $gkey = "gkey";
/*     */   public static final String $item = "item";
/*     */   public static final String $strval = "strval";
/*     */   public static final String $numval = "numval";
/*     */   public static final String $booval = "booval";
/*     */   public static final String $dtval = "dtval";
/*     */   public static final String $tsval = "tsval";
/*     */   public static final String $binval = "binval";
/*  71 */   public static final MCMeta gkey_META = createStringMeta("gkey");
/*  72 */   public static final MCMeta item_META = createStringMeta("item");
/*  73 */   public static final MCMeta strval_META = createStringMeta("strval");
/*  74 */   public static final MCMeta numval_META = createNumberMeta("numval");
/*  75 */   public static final MCMeta booval_META = createBooleanMeta("booval");
/*  76 */   public static final MCMeta dtval_META = createDateMeta("dtval");
/*  77 */   public static final MCMeta tsval_META = createTimestampMeta("tsval");
/*  78 */   public static final MCMeta binval_META = createBinaryMeta("binval");
/*     */   
/*  80 */   protected static final MCRow.ConstMetaList<DataR> constMetas = new MCRow.ConstMetaList(
/*  81 */       MCConstRow.constMetas, 
/*  82 */       new MCMeta[] {
/*  83 */         gkey_META, 
/*  84 */         item_META, 
/*  85 */         strval_META, 
/*  86 */         numval_META, 
/*  87 */         booval_META, 
/*  88 */         dtval_META, 
/*  89 */         tsval_META, 
/*  90 */         binval_META
/*     */       },
/*  92 */       new String[][] { {}, {} });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 103 */   protected static final MCKeyList KEYS = new MCKeyList(
/* 104 */       null, 
/* 105 */       new String[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 113 */   protected static final MCExtMap EXTMAP = new MCExtMap(
/* 114 */       null, new MCExtMap.Entry[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] colnames() {
/* 126 */     return constMetas.toNameArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMeta[] colmetas() {
/* 138 */     return constMetas.toMetaArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 144 */   private static final int offset = constMetas.offset();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCKeyList getKeys() {
/* 150 */     return KEYS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getExtMap(String aGroup) {
/* 157 */     if (aGroup == null) return null; 
/* 158 */     return (Map<String, String>)EXTMAP.get(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCKeyList getKeys(String aGroup) {
/* 165 */     if (aGroup == null) return null; 
/* 166 */     return new MCKeyList(EXTMAP.getKeyList(aGroup));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExtGroups() {
/* 173 */     Set<String> ret = EXTMAP.keySet();
/* 174 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DataR_FW_A(MCRow.ConstMetaList<? extends DataR> metas) {
/* 181 */     super(metas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataR clone() {
/* 188 */     return (DataR)super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataR createInstance() {
/* 195 */     return (DataR)super.createInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataR getValues(String... names) {
/* 202 */     return (DataR)super.getValues(names);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String gkey() {
/* 212 */     return getConstString(offset + 0, "gkey");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void gkey(String value) {
/* 220 */     setConstString(offset + 0, "gkey", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String item() {
/* 229 */     return getConstString(offset + 1, "item");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void item(String value) {
/* 237 */     setConstString(offset + 1, "item", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String strval() {
/* 246 */     return getConstString(offset + 2, "strval");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void strval(String value) {
/* 254 */     setConstString(offset + 2, "strval", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCNumber numval() {
/* 263 */     return getConstNumber(offset + 3, "numval");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void numval(MCNumber value) {
/* 271 */     setConstNumber(offset + 3, "numval", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void numval(int value) {
/* 279 */     setConstNumber(offset + 3, "numval", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void numval(long value) {
/* 287 */     setConstNumber(offset + 3, "numval", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void numval(float value) {
/* 295 */     setConstNumber(offset + 3, "numval", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void numval(double value) {
/* 303 */     setConstNumber(offset + 3, "numval", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean booval() {
/* 312 */     return getConstBoolean(offset + 4, "booval");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void booval(boolean value) {
/* 320 */     setConstBoolean(offset + 4, "booval", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCDate dtval() {
/* 329 */     return getConstDate(offset + 5, "dtval");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dtval(MCDate value) {
/* 337 */     setConstDate(offset + 5, "dtval", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCTimestamp tsval() {
/* 346 */     return getConstTimestamp(offset + 6, "tsval");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void tsval(MCTimestamp value) {
/* 354 */     setConstTimestamp(offset + 6, "tsval", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCBinary binval() {
/* 363 */     return getConstBinary(offset + 7, "binval");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void binval(MCBinary value) {
/* 371 */     setConstBinary(offset + 7, "binval", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString(String name) {
/* 376 */     if ("gkey".equalsIgnoreCase(name)) {
/* 377 */       return gkey();
/*     */     }
/* 379 */     if ("item".equalsIgnoreCase(name)) {
/* 380 */       return item();
/*     */     }
/* 382 */     if ("strval".equalsIgnoreCase(name)) {
/* 383 */       return strval();
/*     */     }
/* 385 */     return super.getString(name);
/*     */   }
/*     */   public MCNumber getNumber(String name) {
/* 388 */     if ("numval".equalsIgnoreCase(name)) {
/* 389 */       return numval();
/*     */     }
/* 391 */     return super.getNumber(name);
/*     */   }
/*     */   public MCDate getDate(String name) {
/* 394 */     if ("dtval".equalsIgnoreCase(name)) {
/* 395 */       return dtval();
/*     */     }
/* 397 */     return super.getDate(name);
/*     */   }
/*     */   public MCTimestamp getTimestamp(String name) {
/* 400 */     if ("tsval".equalsIgnoreCase(name)) {
/* 401 */       return tsval();
/*     */     }
/* 403 */     return super.getTimestamp(name);
/*     */   }
/*     */   public boolean getBoolean(String name) {
/* 406 */     if ("booval".equalsIgnoreCase(name)) {
/* 407 */       return booval();
/*     */     }
/* 409 */     return super.getBoolean(name);
/*     */   }
/*     */   public MCBinary getBinary(String name) {
/* 412 */     if ("binval".equalsIgnoreCase(name)) {
/* 413 */       return binval();
/*     */     }
/* 415 */     return super.getBinary(name);
/*     */   }
/*     */   
/*     */   public String getStringNE(String name) {
/* 419 */     if ("gkey".equalsIgnoreCase(name)) {
/* 420 */       return gkey();
/*     */     }
/* 422 */     if ("item".equalsIgnoreCase(name)) {
/* 423 */       return item();
/*     */     }
/* 425 */     if ("strval".equalsIgnoreCase(name)) {
/* 426 */       return strval();
/*     */     }
/* 428 */     return super.getStringNE(name);
/*     */   }
/*     */   public MCNumber getNumberNE(String name) {
/* 431 */     if ("numval".equalsIgnoreCase(name)) {
/* 432 */       return numval();
/*     */     }
/* 434 */     return super.getNumberNE(name);
/*     */   }
/*     */   public MCDate getDateNE(String name) {
/* 437 */     if ("dtval".equalsIgnoreCase(name)) {
/* 438 */       return dtval();
/*     */     }
/* 440 */     return super.getDateNE(name);
/*     */   }
/*     */   public MCTimestamp getTimestampNE(String name) {
/* 443 */     if ("tsval".equalsIgnoreCase(name)) {
/* 444 */       return tsval();
/*     */     }
/* 446 */     return super.getTimestampNE(name);
/*     */   }
/*     */   public boolean getBooleanNE(String name) {
/* 449 */     if ("booval".equalsIgnoreCase(name)) {
/* 450 */       return booval();
/*     */     }
/* 452 */     return super.getBooleanNE(name);
/*     */   }
/*     */   public MCBinary getBinaryNE(String name) {
/* 455 */     if ("binval".equalsIgnoreCase(name)) {
/* 456 */       return binval();
/*     */     }
/* 458 */     return super.getBinaryNE(name);
/*     */   }
/*     */   
/*     */   public void setString(String name, String value) {
/* 462 */     if ("gkey".equalsIgnoreCase(name)) {
/* 463 */       gkey(value);
/*     */       return;
/*     */     } 
/* 466 */     if ("item".equalsIgnoreCase(name)) {
/* 467 */       item(value);
/*     */       return;
/*     */     } 
/* 470 */     if ("strval".equalsIgnoreCase(name)) {
/* 471 */       strval(value);
/*     */       return;
/*     */     } 
/* 474 */     super.setString(name, value);
/*     */   }
/*     */   public void setNumber(String name, MCNumber value) {
/* 477 */     if ("numval".equalsIgnoreCase(name)) {
/* 478 */       numval(value);
/*     */       return;
/*     */     } 
/* 481 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, int value) {
/* 484 */     if ("numval".equalsIgnoreCase(name)) {
/* 485 */       numval(value);
/*     */       return;
/*     */     } 
/* 488 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, long value) {
/* 491 */     if ("numval".equalsIgnoreCase(name)) {
/* 492 */       numval(value);
/*     */       return;
/*     */     } 
/* 495 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, float value) {
/* 498 */     if ("numval".equalsIgnoreCase(name)) {
/* 499 */       numval(value);
/*     */       return;
/*     */     } 
/* 502 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, double value) {
/* 505 */     if ("numval".equalsIgnoreCase(name)) {
/* 506 */       numval(value);
/*     */       return;
/*     */     } 
/* 509 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setDate(String name, MCDate value) {
/* 512 */     if ("dtval".equalsIgnoreCase(name)) {
/* 513 */       dtval(value);
/*     */       return;
/*     */     } 
/* 516 */     super.setDate(name, value);
/*     */   }
/*     */   public void setTimestamp(String name, MCTimestamp value) {
/* 519 */     if ("tsval".equalsIgnoreCase(name)) {
/* 520 */       tsval(value);
/*     */       return;
/*     */     } 
/* 523 */     super.setTimestamp(name, value);
/*     */   }
/*     */   public void setBoolean(String name, boolean value) {
/* 526 */     if ("booval".equalsIgnoreCase(name)) {
/* 527 */       booval(value);
/*     */       return;
/*     */     } 
/* 530 */     super.setBoolean(name, value);
/*     */   }
/*     */   public void setBinary(String name, MCBinary value) {
/* 533 */     if ("binval".equalsIgnoreCase(name)) {
/* 534 */       binval(value);
/*     */       return;
/*     */     } 
/* 537 */     super.setBinary(name, value);
/*     */   }
/*     */   
/*     */   public void setStringNE(String name, String value) {
/* 541 */     if ("gkey".equalsIgnoreCase(name)) {
/* 542 */       gkey(value);
/*     */       return;
/*     */     } 
/* 545 */     if ("item".equalsIgnoreCase(name)) {
/* 546 */       item(value);
/*     */       return;
/*     */     } 
/* 549 */     if ("strval".equalsIgnoreCase(name)) {
/* 550 */       strval(value);
/*     */       return;
/*     */     } 
/* 553 */     super.setStringNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, MCNumber value) {
/* 556 */     if ("numval".equalsIgnoreCase(name)) {
/* 557 */       numval(value);
/*     */       return;
/*     */     } 
/* 560 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, int value) {
/* 563 */     if ("numval".equalsIgnoreCase(name)) {
/* 564 */       numval(value);
/*     */       return;
/*     */     } 
/* 567 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, long value) {
/* 570 */     if ("numval".equalsIgnoreCase(name)) {
/* 571 */       numval(value);
/*     */       return;
/*     */     } 
/* 574 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, float value) {
/* 577 */     if ("numval".equalsIgnoreCase(name)) {
/* 578 */       numval(value);
/*     */       return;
/*     */     } 
/* 581 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, double value) {
/* 584 */     if ("numval".equalsIgnoreCase(name)) {
/* 585 */       numval(value);
/*     */       return;
/*     */     } 
/* 588 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setDateNE(String name, MCDate value) {
/* 591 */     if ("dtval".equalsIgnoreCase(name)) {
/* 592 */       dtval(value);
/*     */       return;
/*     */     } 
/* 595 */     super.setDateNE(name, value);
/*     */   }
/*     */   public void setTimestampNE(String name, MCTimestamp value) {
/* 598 */     if ("tsval".equalsIgnoreCase(name)) {
/* 599 */       tsval(value);
/*     */       return;
/*     */     } 
/* 602 */     super.setTimestampNE(name, value);
/*     */   }
/*     */   public void setBooleanNE(String name, boolean value) {
/* 605 */     if ("booval".equalsIgnoreCase(name)) {
/* 606 */       booval(value);
/*     */       return;
/*     */     } 
/* 609 */     super.setBooleanNE(name, value);
/*     */   }
/*     */   public void setBinaryNE(String name, MCBinary value) {
/* 612 */     if ("binval".equalsIgnoreCase(name)) {
/* 613 */       binval(value);
/*     */       return;
/*     */     } 
/* 616 */     super.setBinaryNE(name, value);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\dashboard\DataR_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */