/*     */ package mcframe.clientCore.dashboard;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.clientCore.container.MCKeyList;
/*     */ import mcframe.commonCore.container.MCExtMap;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCBinary;
/*     */ import mcframe.commonCore.lang.MCDate;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.lang.MCTimestamp;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class CndR_FW_A
/*     */   extends MCConstRow
/*     */ {
/*     */   public static final String $gkey = "gkey";
/*     */   public static final String $gadget = "gadget";
/*     */   public static final String $item = "item";
/*     */   public static final String $strval = "strval";
/*     */   public static final String $numval = "numval";
/*     */   public static final String $booval = "booval";
/*     */   public static final String $dtval = "dtval";
/*     */   public static final String $tsval = "tsval";
/*     */   public static final String $binval = "binval";
/*  76 */   public static final MCMeta gkey_META = createStringMeta("gkey");
/*  77 */   public static final MCMeta gadget_META = createStringMeta("gadget");
/*  78 */   public static final MCMeta item_META = createStringMeta("item");
/*  79 */   public static final MCMeta strval_META = createStringMeta("strval");
/*  80 */   public static final MCMeta numval_META = createNumberMeta("numval");
/*  81 */   public static final MCMeta booval_META = createBooleanMeta("booval");
/*  82 */   public static final MCMeta dtval_META = createDateMeta("dtval");
/*  83 */   public static final MCMeta tsval_META = createTimestampMeta("tsval");
/*  84 */   public static final MCMeta binval_META = createBinaryMeta("binval");
/*     */   
/*  86 */   protected static final MCRow.ConstMetaList<CndR> constMetas = new MCRow.ConstMetaList(
/*  87 */       MCConstRow.constMetas, 
/*  88 */       new MCMeta[] {
/*  89 */         gkey_META, 
/*  90 */         gadget_META, 
/*  91 */         item_META, 
/*  92 */         strval_META, 
/*  93 */         numval_META, 
/*  94 */         booval_META, 
/*  95 */         dtval_META, 
/*  96 */         tsval_META, 
/*  97 */         binval_META
/*     */       },
/*  99 */       new String[][] { {}, {} });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   protected static final MCKeyList KEYS = new MCKeyList(
/* 111 */       null, 
/* 112 */       new String[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 120 */   protected static final MCExtMap EXTMAP = new MCExtMap(
/* 121 */       null, new MCExtMap.Entry[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] colnames() {
/* 133 */     return constMetas.toNameArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMeta[] colmetas() {
/* 145 */     return constMetas.toMetaArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 151 */   private static final int offset = constMetas.offset();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCKeyList getKeys() {
/* 157 */     return KEYS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getExtMap(String aGroup) {
/* 164 */     if (aGroup == null) return null; 
/* 165 */     return (Map<String, String>)EXTMAP.get(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCKeyList getKeys(String aGroup) {
/* 172 */     if (aGroup == null) return null; 
/* 173 */     return new MCKeyList(EXTMAP.getKeyList(aGroup));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExtGroups() {
/* 180 */     Set<String> ret = EXTMAP.keySet();
/* 181 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CndR_FW_A(MCRow.ConstMetaList<? extends CndR> metas) {
/* 188 */     super(metas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CndR clone() {
/* 195 */     return (CndR)super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CndR createInstance() {
/* 202 */     return (CndR)super.createInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CndR getValues(String... names) {
/* 209 */     return (CndR)super.getValues(names);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String gkey() {
/* 219 */     return getConstString(offset + 0, "gkey");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void gkey(String value) {
/* 227 */     setConstString(offset + 0, "gkey", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String gadget() {
/* 236 */     return getConstString(offset + 1, "gadget");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void gadget(String value) {
/* 244 */     setConstString(offset + 1, "gadget", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String item() {
/* 253 */     return getConstString(offset + 2, "item");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void item(String value) {
/* 261 */     setConstString(offset + 2, "item", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String strval() {
/* 270 */     return getConstString(offset + 3, "strval");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void strval(String value) {
/* 278 */     setConstString(offset + 3, "strval", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCNumber numval() {
/* 287 */     return getConstNumber(offset + 4, "numval");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void numval(MCNumber value) {
/* 295 */     setConstNumber(offset + 4, "numval", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void numval(int value) {
/* 303 */     setConstNumber(offset + 4, "numval", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void numval(long value) {
/* 311 */     setConstNumber(offset + 4, "numval", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void numval(float value) {
/* 319 */     setConstNumber(offset + 4, "numval", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void numval(double value) {
/* 327 */     setConstNumber(offset + 4, "numval", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean booval() {
/* 336 */     return getConstBoolean(offset + 5, "booval");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void booval(boolean value) {
/* 344 */     setConstBoolean(offset + 5, "booval", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCDate dtval() {
/* 353 */     return getConstDate(offset + 6, "dtval");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dtval(MCDate value) {
/* 361 */     setConstDate(offset + 6, "dtval", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCTimestamp tsval() {
/* 370 */     return getConstTimestamp(offset + 7, "tsval");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void tsval(MCTimestamp value) {
/* 378 */     setConstTimestamp(offset + 7, "tsval", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCBinary binval() {
/* 387 */     return getConstBinary(offset + 8, "binval");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void binval(MCBinary value) {
/* 395 */     setConstBinary(offset + 8, "binval", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString(String name) {
/* 400 */     if ("gkey".equalsIgnoreCase(name)) {
/* 401 */       return gkey();
/*     */     }
/* 403 */     if ("gadget".equalsIgnoreCase(name)) {
/* 404 */       return gadget();
/*     */     }
/* 406 */     if ("item".equalsIgnoreCase(name)) {
/* 407 */       return item();
/*     */     }
/* 409 */     if ("strval".equalsIgnoreCase(name)) {
/* 410 */       return strval();
/*     */     }
/* 412 */     return super.getString(name);
/*     */   }
/*     */   public MCNumber getNumber(String name) {
/* 415 */     if ("numval".equalsIgnoreCase(name)) {
/* 416 */       return numval();
/*     */     }
/* 418 */     return super.getNumber(name);
/*     */   }
/*     */   public MCDate getDate(String name) {
/* 421 */     if ("dtval".equalsIgnoreCase(name)) {
/* 422 */       return dtval();
/*     */     }
/* 424 */     return super.getDate(name);
/*     */   }
/*     */   public MCTimestamp getTimestamp(String name) {
/* 427 */     if ("tsval".equalsIgnoreCase(name)) {
/* 428 */       return tsval();
/*     */     }
/* 430 */     return super.getTimestamp(name);
/*     */   }
/*     */   public boolean getBoolean(String name) {
/* 433 */     if ("booval".equalsIgnoreCase(name)) {
/* 434 */       return booval();
/*     */     }
/* 436 */     return super.getBoolean(name);
/*     */   }
/*     */   public MCBinary getBinary(String name) {
/* 439 */     if ("binval".equalsIgnoreCase(name)) {
/* 440 */       return binval();
/*     */     }
/* 442 */     return super.getBinary(name);
/*     */   }
/*     */   
/*     */   public String getStringNE(String name) {
/* 446 */     if ("gkey".equalsIgnoreCase(name)) {
/* 447 */       return gkey();
/*     */     }
/* 449 */     if ("gadget".equalsIgnoreCase(name)) {
/* 450 */       return gadget();
/*     */     }
/* 452 */     if ("item".equalsIgnoreCase(name)) {
/* 453 */       return item();
/*     */     }
/* 455 */     if ("strval".equalsIgnoreCase(name)) {
/* 456 */       return strval();
/*     */     }
/* 458 */     return super.getStringNE(name);
/*     */   }
/*     */   public MCNumber getNumberNE(String name) {
/* 461 */     if ("numval".equalsIgnoreCase(name)) {
/* 462 */       return numval();
/*     */     }
/* 464 */     return super.getNumberNE(name);
/*     */   }
/*     */   public MCDate getDateNE(String name) {
/* 467 */     if ("dtval".equalsIgnoreCase(name)) {
/* 468 */       return dtval();
/*     */     }
/* 470 */     return super.getDateNE(name);
/*     */   }
/*     */   public MCTimestamp getTimestampNE(String name) {
/* 473 */     if ("tsval".equalsIgnoreCase(name)) {
/* 474 */       return tsval();
/*     */     }
/* 476 */     return super.getTimestampNE(name);
/*     */   }
/*     */   public boolean getBooleanNE(String name) {
/* 479 */     if ("booval".equalsIgnoreCase(name)) {
/* 480 */       return booval();
/*     */     }
/* 482 */     return super.getBooleanNE(name);
/*     */   }
/*     */   public MCBinary getBinaryNE(String name) {
/* 485 */     if ("binval".equalsIgnoreCase(name)) {
/* 486 */       return binval();
/*     */     }
/* 488 */     return super.getBinaryNE(name);
/*     */   }
/*     */   
/*     */   public void setString(String name, String value) {
/* 492 */     if ("gkey".equalsIgnoreCase(name)) {
/* 493 */       gkey(value);
/*     */       return;
/*     */     } 
/* 496 */     if ("gadget".equalsIgnoreCase(name)) {
/* 497 */       gadget(value);
/*     */       return;
/*     */     } 
/* 500 */     if ("item".equalsIgnoreCase(name)) {
/* 501 */       item(value);
/*     */       return;
/*     */     } 
/* 504 */     if ("strval".equalsIgnoreCase(name)) {
/* 505 */       strval(value);
/*     */       return;
/*     */     } 
/* 508 */     super.setString(name, value);
/*     */   }
/*     */   public void setNumber(String name, MCNumber value) {
/* 511 */     if ("numval".equalsIgnoreCase(name)) {
/* 512 */       numval(value);
/*     */       return;
/*     */     } 
/* 515 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, int value) {
/* 518 */     if ("numval".equalsIgnoreCase(name)) {
/* 519 */       numval(value);
/*     */       return;
/*     */     } 
/* 522 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, long value) {
/* 525 */     if ("numval".equalsIgnoreCase(name)) {
/* 526 */       numval(value);
/*     */       return;
/*     */     } 
/* 529 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, float value) {
/* 532 */     if ("numval".equalsIgnoreCase(name)) {
/* 533 */       numval(value);
/*     */       return;
/*     */     } 
/* 536 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, double value) {
/* 539 */     if ("numval".equalsIgnoreCase(name)) {
/* 540 */       numval(value);
/*     */       return;
/*     */     } 
/* 543 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setDate(String name, MCDate value) {
/* 546 */     if ("dtval".equalsIgnoreCase(name)) {
/* 547 */       dtval(value);
/*     */       return;
/*     */     } 
/* 550 */     super.setDate(name, value);
/*     */   }
/*     */   public void setTimestamp(String name, MCTimestamp value) {
/* 553 */     if ("tsval".equalsIgnoreCase(name)) {
/* 554 */       tsval(value);
/*     */       return;
/*     */     } 
/* 557 */     super.setTimestamp(name, value);
/*     */   }
/*     */   public void setBoolean(String name, boolean value) {
/* 560 */     if ("booval".equalsIgnoreCase(name)) {
/* 561 */       booval(value);
/*     */       return;
/*     */     } 
/* 564 */     super.setBoolean(name, value);
/*     */   }
/*     */   public void setBinary(String name, MCBinary value) {
/* 567 */     if ("binval".equalsIgnoreCase(name)) {
/* 568 */       binval(value);
/*     */       return;
/*     */     } 
/* 571 */     super.setBinary(name, value);
/*     */   }
/*     */   
/*     */   public void setStringNE(String name, String value) {
/* 575 */     if ("gkey".equalsIgnoreCase(name)) {
/* 576 */       gkey(value);
/*     */       return;
/*     */     } 
/* 579 */     if ("gadget".equalsIgnoreCase(name)) {
/* 580 */       gadget(value);
/*     */       return;
/*     */     } 
/* 583 */     if ("item".equalsIgnoreCase(name)) {
/* 584 */       item(value);
/*     */       return;
/*     */     } 
/* 587 */     if ("strval".equalsIgnoreCase(name)) {
/* 588 */       strval(value);
/*     */       return;
/*     */     } 
/* 591 */     super.setStringNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, MCNumber value) {
/* 594 */     if ("numval".equalsIgnoreCase(name)) {
/* 595 */       numval(value);
/*     */       return;
/*     */     } 
/* 598 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, int value) {
/* 601 */     if ("numval".equalsIgnoreCase(name)) {
/* 602 */       numval(value);
/*     */       return;
/*     */     } 
/* 605 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, long value) {
/* 608 */     if ("numval".equalsIgnoreCase(name)) {
/* 609 */       numval(value);
/*     */       return;
/*     */     } 
/* 612 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, float value) {
/* 615 */     if ("numval".equalsIgnoreCase(name)) {
/* 616 */       numval(value);
/*     */       return;
/*     */     } 
/* 619 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, double value) {
/* 622 */     if ("numval".equalsIgnoreCase(name)) {
/* 623 */       numval(value);
/*     */       return;
/*     */     } 
/* 626 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setDateNE(String name, MCDate value) {
/* 629 */     if ("dtval".equalsIgnoreCase(name)) {
/* 630 */       dtval(value);
/*     */       return;
/*     */     } 
/* 633 */     super.setDateNE(name, value);
/*     */   }
/*     */   public void setTimestampNE(String name, MCTimestamp value) {
/* 636 */     if ("tsval".equalsIgnoreCase(name)) {
/* 637 */       tsval(value);
/*     */       return;
/*     */     } 
/* 640 */     super.setTimestampNE(name, value);
/*     */   }
/*     */   public void setBooleanNE(String name, boolean value) {
/* 643 */     if ("booval".equalsIgnoreCase(name)) {
/* 644 */       booval(value);
/*     */       return;
/*     */     } 
/* 647 */     super.setBooleanNE(name, value);
/*     */   }
/*     */   public void setBinaryNE(String name, MCBinary value) {
/* 650 */     if ("binval".equalsIgnoreCase(name)) {
/* 651 */       binval(value);
/*     */       return;
/*     */     } 
/* 654 */     super.setBinaryNE(name, value);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\dashboard\CndR_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */