/*     */ package mcframe.clientCore.dashboard;
/*     */ 
/*     */ import mcframe.clientCore.date.MCCoTodayAgent;
/*     */ import mcframe.commonCore.dashboard.MCValueSupply;
/*     */ import mcframe.commonCore.lang.MCDate;
/*     */ import mcframe.commonCore.lang.MCTimestamp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface MCValueSupply
/*     */   extends MCValueSupply
/*     */ {
/*     */   static MCValueSupply create(String col, String name, String type, boolean required, boolean editable) {
/*  41 */     return create(col, name, type, required, editable, (MCDate)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static MCValueSupply create(String col, String name, String type, boolean required, boolean editable, MCDate coToday) {
/*     */     DateVS dateVs;
/*     */     TimestampVS tsVs;
/*  68 */     if (type == null)
/*  69 */       return null; 
/*     */     String str;
/*  71 */     switch ((str = type).hashCode()) { case 49: if (!str.equals("1")) {
/*     */           break;
/*     */         }
/*     */         
/*  75 */         return new StringVS(col, name, type, required, editable);
/*     */       case 50:
/*     */         if (!str.equals("2"))
/*  78 */           break;  return new NumberVS(col, name, type, required, editable);
/*     */ 
/*     */       
/*     */       case 51:
/*     */         if (!str.equals("3")) {
/*     */           break;
/*     */         }
/*  85 */         dateVs = new DateVS(col, name, type, required, editable);
/*  86 */         dateVs.setCoToday(coToday);
/*  87 */         return dateVs;
/*     */       case 52:
/*     */         if (!str.equals("4"))
/*     */           break; 
/*  91 */         tsVs = new TimestampVS(col, name, type, required, editable);
/*  92 */         tsVs.setCoToday(coToday);
/*  93 */         return tsVs;
/*     */       case 53: if (!str.equals("5"))
/*     */           break;  return new BooleanVS(col, name, type, required, editable);
/*     */       case 54: if (!str.equals("6")); break;
/*     */       case 1584: if (!str.equals("1A"))
/*     */           break;  return new StringVS(col, name, type, required, editable);
/*     */       case 1586: if (!str.equals("1C"))
/* 100 */           break;  return new StringVS(col, name, type, required, editable); }  return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCValueSupply clone();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class StringVS
/*     */     extends MCValueSupply.StringBase
/*     */     implements MCValueSupply
/*     */   {
/*     */     protected StringVS(String col, String name, String type, boolean required, boolean editable) {
/* 134 */       super(col, name, type, required, editable);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected MCValueSupply.StringBase createInstance(String col, String name, String type, boolean required, boolean editable) {
/* 140 */       return new StringVS(column(), name(), type(), required(), editable());
/*     */     }
/*     */ 
/*     */     
/*     */     public StringVS clone() {
/* 145 */       return (StringVS)cloneImpl();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class NumberVS
/*     */     extends MCValueSupply.NumberBase
/*     */     implements MCValueSupply
/*     */   {
/*     */     protected NumberVS(String col, String name, String type, boolean required, boolean editable) {
/* 169 */       super(col, name, type, required, editable);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected NumberVS createInstance(String col, String name, String type, boolean required, boolean editable) {
/* 175 */       return new NumberVS(column(), name(), type(), required(), editable());
/*     */     }
/*     */ 
/*     */     
/*     */     public NumberVS clone() {
/* 180 */       return (NumberVS)cloneImpl();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class BooleanVS
/*     */     extends MCValueSupply.BooleanBase
/*     */     implements MCValueSupply
/*     */   {
/*     */     protected BooleanVS(String col, String name, String type, boolean required, boolean editable) {
/* 204 */       super(col, name, type, required, editable);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected BooleanVS createInstance(String col, String name, String type, boolean required, boolean editable) {
/* 210 */       return new BooleanVS(column(), name(), type(), required(), editable());
/*     */     }
/*     */ 
/*     */     
/*     */     public BooleanVS clone() {
/* 215 */       return (BooleanVS)cloneImpl();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class DateVS
/*     */     extends MCValueSupply.DateBase
/*     */     implements MCValueSupply
/*     */   {
/* 234 */     private MCDate _coToday = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected DateVS(String col, String name, String type, boolean required, boolean editable) {
/* 248 */       super(col, name, type, required, editable);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected DateVS createInstance(String col, String name, String type, boolean required, boolean editable) {
/* 254 */       return new DateVS(column(), name(), type(), required(), editable());
/*     */     }
/*     */ 
/*     */     
/*     */     public DateVS clone() {
/* 259 */       return (DateVS)cloneImpl();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected MCDate getCoToday() {
/* 265 */       if (this._coToday == null) {
/* 266 */         this._coToday = MCCoTodayAgent.getCoToday();
/*     */       }
/* 268 */       return this._coToday;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void setCoToday(MCDate coToday) {
/* 280 */       this._coToday = coToday;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class TimestampVS
/*     */     extends DateVS
/*     */     implements MCValueSupply
/*     */   {
/*     */     protected TimestampVS(String col, String name, String type, boolean required, boolean editable) {
/* 304 */       super(col, name, type, required, editable);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected TimestampVS createInstance(String col, String name, String type, boolean required, boolean editable) {
/* 310 */       return new TimestampVS(column(), name(), type(), required(), editable());
/*     */     }
/*     */ 
/*     */     
/*     */     public TimestampVS clone() {
/* 315 */       return (TimestampVS)cloneImpl();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void value(Comparable<?> val) {
/* 321 */       super.value((Comparable)MCDate.valueOf((MCTimestamp)val));
/*     */     }
/*     */ 
/*     */     
/*     */     public Comparable<?> value() {
/* 326 */       return (Comparable<?>)MCTimestamp.valueOf((MCDate)super.value());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\dashboard\MCValueSupply.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */