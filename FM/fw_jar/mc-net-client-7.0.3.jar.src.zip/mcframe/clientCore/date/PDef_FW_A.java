/*    */ package mcframe.clientCore.date;
/*    */ 
/*    */ import mcframe.commonCore.param.MCBlockDef;
/*    */ import mcframe.commonCore.param.MCContainerDef;
/*    */ import mcframe.commonCore.param.MCDef;
/*    */ import mcframe.commonCore.param.MCGeneralContainerDef;
/*    */ import mcframe.commonCore.param.MCItemDef;
/*    */ import mcframe.commonCore.param.MCOperationInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PDef_FW_A
/*    */   extends MCDef
/*    */ {
/*    */   public MCContainerDef getCustomDef(String id) {
/* 19 */     if (id == null) {
/* 20 */       return null;
/*    */     }
/*    */     
/* 23 */     if (id.equals("FC.FCBGL0150.Srch01.DOWN.BLOCK0")) {
/* 24 */       return FC_FCBGL0150_Srch01_DOWN_BLOCK0();
/*    */     }
/*    */ 
/*    */     
/* 28 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 34 */   static final MCOperationInfo FC_FCBGL0150_Srch01_INFO = new MCOperationInfo("FC", "FCBGL0150", "Srch01", "000000", new PDef());
/*    */ 
/*    */ 
/*    */   
/*    */   public static MCContainerDef FC_FCBGL0150_Srch01_DOWN_BLOCK0() {
/* 39 */     return (MCContainerDef)new MCGeneralContainerDef(
/* 40 */         new MCItemDef[] {
/* 41 */           MCItemDef.create("today", "today")
/*    */ 
/*    */         
/* 44 */         }MCBlockDef.create("CoToday"));
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\date\PDef_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */