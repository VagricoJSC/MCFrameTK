/*     */ package mcframe.clientCore.date;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.clientCore.container.MCKeyList;
/*     */ import mcframe.commonCore.container.MCExtMap;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCDate;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ import mcframe.commonCore.meta.M_META;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class CoTodayR_FW_A
/*     */   extends MCConstRow
/*     */ {
/*     */   public static final String $today = "today";
/*  32 */   public static final MCMeta today_META = createCommonMeta("today", M_META.DT);
/*     */   
/*  34 */   protected static final MCRow.ConstMetaList<CoTodayR> constMetas = new MCRow.ConstMetaList(
/*  35 */       MCConstRow.constMetas, 
/*  36 */       new MCMeta[] {
/*  37 */         today_META
/*     */       },
/*  39 */       new String[][] { {}, {} });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   protected static final MCKeyList KEYS = new MCKeyList(
/*  51 */       null, 
/*  52 */       new String[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   protected static final MCExtMap EXTMAP = new MCExtMap(
/*  61 */       null, new MCExtMap.Entry[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] colnames() {
/*  73 */     return constMetas.toNameArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMeta[] colmetas() {
/*  85 */     return constMetas.toMetaArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  91 */   private static final int offset = constMetas.offset();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCKeyList getKeys() {
/*  97 */     return KEYS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getExtMap(String aGroup) {
/* 104 */     if (aGroup == null) return null; 
/* 105 */     return (Map<String, String>)EXTMAP.get(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCKeyList getKeys(String aGroup) {
/* 112 */     if (aGroup == null) return null; 
/* 113 */     return new MCKeyList(EXTMAP.getKeyList(aGroup));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExtGroups() {
/* 120 */     Set<String> ret = EXTMAP.keySet();
/* 121 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CoTodayR_FW_A(MCRow.ConstMetaList<? extends CoTodayR> metas) {
/* 128 */     super(metas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CoTodayR clone() {
/* 135 */     return (CoTodayR)super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CoTodayR createInstance() {
/* 142 */     return (CoTodayR)super.createInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CoTodayR getValues(String... names) {
/* 149 */     return (CoTodayR)super.getValues(names);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MCDate today() {
/* 155 */     return getConstDate(offset + 0, "today");
/*     */   }
/*     */   
/*     */   public void today(MCDate value) {
/* 159 */     setConstDate(offset + 0, "today", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCDate getDate(String name) {
/* 164 */     if ("today".equalsIgnoreCase(name)) {
/* 165 */       return today();
/*     */     }
/* 167 */     return super.getDate(name);
/*     */   }
/*     */   
/*     */   public MCDate getDateNE(String name) {
/* 171 */     if ("today".equalsIgnoreCase(name)) {
/* 172 */       return today();
/*     */     }
/* 174 */     return super.getDateNE(name);
/*     */   }
/*     */   
/*     */   public void setDate(String name, MCDate value) {
/* 178 */     if ("today".equalsIgnoreCase(name)) {
/* 179 */       today(value);
/*     */       return;
/*     */     } 
/* 182 */     super.setDate(name, value);
/*     */   }
/*     */   
/*     */   public void setDateNE(String name, MCDate value) {
/* 186 */     if ("today".equalsIgnoreCase(name)) {
/* 187 */       today(value);
/*     */       return;
/*     */     } 
/* 190 */     super.setDateNE(name, value);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\date\CoTodayR_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */