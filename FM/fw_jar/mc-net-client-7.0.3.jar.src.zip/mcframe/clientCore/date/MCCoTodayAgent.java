/*    */ package mcframe.clientCore.date;
/*    */ 
/*    */ import mcframe.clientCore.requester.MCCaller;
/*    */ import mcframe.commonCore.container.MCContainer;
/*    */ import mcframe.commonCore.lang.MCDate;
/*    */ import mcframe.commonCore.lang.MCNumber;
/*    */ import mcframe.commonCore.param.MCParam;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCCoTodayAgent
/*    */ {
/*    */   public static MCDate getCoToday() {
/* 27 */     CoTodayR downR = CoTodayR.create();
/*    */     
/* 29 */     MCParam param = createParam("Srch01", "000000");
/* 30 */     param.getContainerParam().addDownBlock((MCContainer)downR);
/* 31 */     MCCaller caller = createCaller(param);
/* 32 */     caller.exec();
/*    */     
/* 34 */     return downR.today();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static MCParam createParam(String ope, String ver) {
/* 47 */     MCParam param = new MCParam("FC", "FCBGL0150", ope, ver);
/* 48 */     param.setLimitDLSize(MCNumber.valueOf(-1));
/* 49 */     param.setDef(new PDef());
/* 50 */     return param;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static MCCaller createCaller(MCParam p) {
/* 62 */     return new MCCaller(p);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-client-7.0.3.jar!\mcframe\clientCore\date\MCCoTodayAgent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */