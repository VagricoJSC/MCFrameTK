/*     */ package mcframe.commonCore.sys;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCFactory
/*     */ {
/*     */   public static final String createClassName(String... names) {
/*  40 */     StringBuilder classname = new StringBuilder();
/*  41 */     if (names.length < 1) {
/*  42 */       return "";
/*     */     }
/*     */     
/*  45 */     classname.append(names[0]);
/*  46 */     for (int i = 1; i < names.length; i++) {
/*  47 */       classname.append('.');
/*  48 */       classname.append(names[i]);
/*     */     } 
/*  50 */     return classname.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> Class<? extends T> getClass(Class<T> proto, String classname) {
/*  69 */     Class<?> c = null;
/*     */     
/*     */     try {
/*  72 */       ClassLoader cl = Thread.currentThread().getContextClassLoader();
/*  73 */       c = cl.loadClass(classname);
/*     */     
/*     */     }
/*  76 */     catch (Exception ex) {
/*     */ 
/*     */ 
/*     */       
/*  80 */       throw new MCException(ex, Core_Msg_FW_A.FCBEC0001, new Object[] { classname });
/*     */     } 
/*     */     try {
/*  83 */       return c.asSubclass(proto);
/*  84 */     } catch (Exception ex) {
/*     */ 
/*     */       
/*  87 */       throw new MCException(ex, Core_Msg_FW_A.FCBEC0002, new Object[] { classname, proto.getName() });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T create(Class<T> proto, String classname) {
/* 110 */     return create(proto, classname, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T create(Class<T> proto, String... names) {
/* 140 */     String classname = createClassName(names);
/* 141 */     return create(proto, classname, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T create(Class<T> proto, String classname, Class[] types, Object[] args) {
/* 164 */     Class<? extends T> clazz = getClass(proto, classname);
/* 165 */     return create((Class)clazz, types, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T create(Class<T> clazz, Class[] types, Object[] args) {
/* 184 */     Object obj = null;
/*     */     try {
/* 186 */       if (clazz != null) {
/* 187 */         Constructor<T> con = clazz.getDeclaredConstructor(types);
/* 188 */         con.setAccessible(true);
/* 189 */         obj = con.newInstance(args);
/*     */       } 
/* 191 */       return clazz.cast(obj);
/*     */ 
/*     */     
/*     */     }
/* 195 */     catch (InvocationTargetException ex) {
/*     */       
/* 197 */       throw MCException.getInvocationTargetMCException(
/* 198 */           ex, Core_Msg_FW_A.FCBEC0003, new Object[] { clazz.getName() });
/*     */     }
/* 200 */     catch (Exception ex) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 205 */       throw new MCException(ex, Core_Msg_FW_A.FCBEC0003, new Object[] { clazz.getName() });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object invoke(Object target, String name, Class[] types, Object[] args) {
/* 232 */     if (target == null)
/*     */     {
/* 234 */       throw new MCException(Core_Msg_FW_A.FCBEC0010, new Object[0]);
/*     */     }
/* 236 */     if (name == null)
/*     */     {
/* 238 */       throw new MCException(Core_Msg_FW_A.FCBEC0011, new Object[0]);
/*     */     }
/* 240 */     Class<?> c = target.getClass();
/* 241 */     return invoke(c, target, name, types, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Object invokeStatic(Class<?> target, String name, Class[] types, Object[] args) {
/* 266 */     if (target == null)
/*     */     {
/* 268 */       throw new MCException(Core_Msg_FW_A.FCBEC0012, new Object[0]);
/*     */     }
/* 270 */     if (name == null)
/*     */     {
/* 272 */       throw new MCException(Core_Msg_FW_A.FCBEC0011, new Object[0]);
/*     */     }
/* 274 */     return invoke(target, null, name, types, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final Object invoke(Class<?> c, Object o, String name, Class[] types, Object[] args) {
/* 299 */     Class<?> clazz = c;
/* 300 */     while (clazz != null) {
/*     */       try {
/* 302 */         Method m = clazz.getDeclaredMethod(name, types);
/* 303 */         m.setAccessible(true);
/* 304 */         return m.invoke(o, args);
/*     */       }
/* 306 */       catch (NoSuchMethodException noSuchMethodException) {
/*     */ 
/*     */       
/*     */       }
/* 310 */       catch (SecurityException ex) {
/*     */ 
/*     */         
/* 313 */         throw new MCException(ex, Core_Msg_FW_A.FCBEC0013, new Object[] {
/* 314 */               clazz.getName(), name, msgParamString(types)
/*     */             });
/* 316 */       } catch (IllegalAccessException ex) {
/*     */ 
/*     */         
/* 319 */         throw new MCException(ex, Core_Msg_FW_A.FCBEC0013, new Object[] {
/* 320 */               clazz.getName(), name, msgParamString(types)
/*     */             });
/* 322 */       } catch (IllegalArgumentException ex) {
/*     */ 
/*     */ 
/*     */         
/* 326 */         throw new MCException(ex, Core_Msg_FW_A.FCBEC0014, new Object[] {
/* 327 */               clazz.getName(), name, msgParamString(types)
/*     */             });
/* 329 */       } catch (InvocationTargetException ex) {
/*     */ 
/*     */ 
/*     */         
/* 333 */         throw MCException.getInvocationTargetMCException(ex);
/*     */       } 
/*     */ 
/*     */       
/* 337 */       clazz = clazz.getSuperclass();
/*     */     } 
/*     */     
/* 340 */     throw new MCException(Core_Msg_FW_A.FCBEC0015, new Object[] {
/* 341 */           c.getName(), name, msgParamString(types)
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String msgParamString(Class[] types) {
/* 353 */     StringBuilder sb = new StringBuilder();
/* 354 */     if (types != null) {
/* 355 */       int len = types.length;
/* 356 */       for (int i = 0; i < len; i++) {
/* 357 */         if (i > 0) {
/* 358 */           sb.append(", ");
/*     */         }
/* 360 */         sb.append(types[i]);
/*     */       } 
/*     */     } 
/* 363 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean checkInvokeError(MCException e) {
/* 393 */     String id = e.getID();
/* 394 */     return !(!id.equals(Core_Msg_FW_A.FCBEC0003) && 
/* 395 */       !id.equals(Core_Msg_FW_A.FCBEC0010) && 
/* 396 */       !id.equals(Core_Msg_FW_A.FCBEC0011) && 
/* 397 */       !id.equals(Core_Msg_FW_A.FCBEC0012) && 
/* 398 */       !id.equals(Core_Msg_FW_A.FCBEC0013) && 
/* 399 */       !id.equals(Core_Msg_FW_A.FCBEC0014) && 
/* 400 */       !id.equals(Core_Msg_FW_A.FCBEC0015));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final <T> T getFieldValue(Class<?> clazz, Class<T> type, String name) {
/* 427 */     Field f = getField(clazz, name);
/* 428 */     if (f != null) {
/*     */       
/*     */       try {
/*     */ 
/*     */         
/* 433 */         return (T)f.get(type);
/*     */       }
/* 435 */       catch (IllegalAccessException illegalAccessException) {
/* 436 */         return null;
/*     */       }
/* 438 */       catch (ClassCastException classCastException) {
/* 439 */         return null;
/*     */       } 
/*     */     }
/* 442 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final <T> T getFieldValue(Class<?> clazz, Class<T> type, Object obj, String name) {
/* 469 */     Field f = getField(clazz, name);
/* 470 */     if (f != null) {
/*     */       try {
/* 472 */         return (T)f.get(obj);
/*     */       }
/* 474 */       catch (IllegalAccessException illegalAccessException) {
/* 475 */         return null;
/*     */       }
/* 477 */       catch (ClassCastException classCastException) {
/* 478 */         return null;
/*     */       } 
/*     */     }
/* 481 */     return null;
/*     */   }
/*     */   
/*     */   private static final Field getField(Class<?> clazz, String name) {
/* 485 */     if (clazz != null && name != null) {
/*     */       try {
/* 487 */         Field f = clazz.getDeclaredField(name);
/* 488 */         f.setAccessible(true);
/* 489 */         return f;
/*     */       }
/* 491 */       catch (NoSuchFieldException noSuchFieldException) {
/* 492 */         clazz = clazz.getSuperclass();
/* 493 */         return getField(clazz, name);
/*     */       } 
/*     */     }
/* 496 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\sys\MCFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */