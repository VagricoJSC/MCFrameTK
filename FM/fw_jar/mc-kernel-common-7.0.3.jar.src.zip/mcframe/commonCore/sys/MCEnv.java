/*     */ package mcframe.commonCore.sys;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import mcframe.commonCore.lang.MCTimestamp;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.resource.MCConfig;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCEnv
/*     */ {
/*     */   public static final String MCF_HOME = "MCF_HOME";
/*     */   public static final String MCF_TIER = "MCF_TIER";
/*     */   public static final String MCF_1TIER = "1";
/*     */   public static final String MCF_2TIER = "2";
/*     */   public static final String MCF_3TIER = "3";
/*     */   private static final String COMMON_USERID = ".all";
/*     */   private static final String USER_BASE = "users";
/*     */   
/*     */   public static final String createUserHomePath(String root, String userid) {
/* 130 */     userid = (userid != null) ? userid : ".all";
/* 131 */     File base = new File(root, "users");
/* 132 */     File home = new File(base, userid);
/* 133 */     return home.getAbsolutePath();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 157 */   private String _mcf_home = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String MCF_HOME() {
/* 179 */     if (this._mcf_home == null) {
/* 180 */       this._mcf_home = System.getProperty("MCF_HOME", 
/* 181 */           System.getProperty("user.dir"));
/* 182 */       this._mcf_home = (new File(this._mcf_home)).getAbsolutePath();
/*     */     } 
/* 184 */     return this._mcf_home;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 192 */   private String _mcf_tier = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String MCF_TIER() {
/* 218 */     if (this._mcf_tier == null) {
/* 219 */       this._mcf_tier = System.getProperty("MCF_TIER", "2");
/* 220 */       if (this._mcf_tier.equals("1")) {
/* 221 */         this._mcf_tier = "1";
/* 222 */       } else if (this._mcf_tier.equals("2")) {
/* 223 */         this._mcf_tier = "2";
/* 224 */       } else if (this._mcf_tier.equals("3")) {
/* 225 */         this._mcf_tier = "3";
/*     */       } 
/*     */     } 
/* 228 */     return this._mcf_tier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean is3Tier() {
/* 239 */     return "3".equals(MCF_TIER());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String COMMONPROFILE() {
/* 299 */     return createUserHomePath(MCF_HOME(), ".all");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String USERPROFILE() {
/* 314 */     String profile = null;
/* 315 */     String user = MCSys.user.ID();
/* 316 */     if (user != null) {
/* 317 */       profile = createUserHomePath(MCF_HOME(), user);
/*     */     }
/* 319 */     return profile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String USERHOME() {
/* 334 */     String home = USERPROFILE();
/* 335 */     if (home == null) {
/* 336 */       home = COMMONPROFILE();
/*     */     }
/* 338 */     return home;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getOSEnv(String key) {
/* 352 */     return System.getenv(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getOSEnv(String key, String def) {
/* 365 */     String val = getOSEnv(key);
/* 366 */     return (val != null) ? val : def;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getVMEnv(String key) {
/* 378 */     return System.getProperty(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getVMEnv(String key, String def) {
/* 391 */     String val = getVMEnv(key);
/* 392 */     return (val != null) ? val : def;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getVMProcessID() {
/* 403 */     return getMCProcessID();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isWin() {
/* 414 */     String os = System.getProperty("os.name").toLowerCase();
/* 415 */     return (os != null && os.startsWith("windows"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isWin9x() {
/* 428 */     if (!isWin()) {
/* 429 */       return false;
/*     */     }
/*     */     
/* 432 */     String[] win9xs = {
/* 433 */         "95", 
/* 434 */         "98", 
/* 435 */         "me"
/*     */       };
/* 437 */     String os = System.getProperty("os.name").toLowerCase(); byte b; int i; String[] arrayOfString1;
/* 438 */     for (i = (arrayOfString1 = win9xs).length, b = 0; b < i; ) { String win9x = arrayOfString1[b];
/* 439 */       if (os.indexOf(win9x) > -1)
/* 440 */         return true; 
/*     */       b++; }
/*     */     
/* 443 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 461 */   private long _mcsystime_diff = 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int getMCProcessID();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean setMCSysTimeDiff(long diff) {
/* 489 */     long interval = getMCSysTimeInterval();
/* 490 */     if (interval < 0L)
/*     */     {
/* 492 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 496 */     this._mcsystime_diff = diff;
/* 497 */     MCLog.write(Core_Msg_FW_A.FCBEC0051, new Object[] { String.valueOf(this._mcsystime_diff) });
/* 498 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setMCSysTime(MCTimestamp systs) {
/* 517 */     long time = System.currentTimeMillis();
/*     */     
/* 519 */     if (systs == null) {
/*     */       return;
/*     */     }
/* 522 */     long diff = systs.toDate().getTime() - time;
/* 523 */     setMCSysTimeDiff(diff);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final long getMCSysTimeDiff() {
/* 541 */     long interval = getMCSysTimeInterval();
/* 542 */     return (interval < 0L) ? 0L : this._mcsystime_diff;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final long getMCSysTimeInterval() {
/* 559 */     return MCConfig.common.getInteger("mcsystime.interval", -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 567 */   private final Map<String, Long> _coSystime_diff = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Integer _client_port_no;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean setMCCoSysTimeDiff(String coCd, long diff) {
/* 586 */     long interval = getMCSysTimeInterval();
/* 587 */     if (interval < 0L)
/*     */     {
/* 589 */       return false;
/*     */     }
/*     */     
/* 592 */     this._coSystime_diff.put(coCd, Long.valueOf(diff));
/* 593 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setMCCoSysTime(String coCd, MCTimestamp systs) {
/* 609 */     long time = System.currentTimeMillis();
/*     */     
/* 611 */     if (systs == null) {
/*     */       return;
/*     */     }
/* 614 */     long diff = systs.toDate().getTime() - time;
/* 615 */     setMCCoSysTimeDiff(coCd, diff);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final long getMCCoSysTimeDiff(String coCd) {
/* 627 */     long interval = getMCSysTimeInterval();
/* 628 */     Long diff = this._coSystime_diff.get(coCd);
/* 629 */     return (interval < 0L || diff == null) ? 0L : diff.longValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public final void _setClientPortNO(Integer port) {
/* 636 */     this._client_port_no = port;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public final Integer _getClientPortNO() {
/* 641 */     return this._client_port_no;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\sys\MCEnv.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */