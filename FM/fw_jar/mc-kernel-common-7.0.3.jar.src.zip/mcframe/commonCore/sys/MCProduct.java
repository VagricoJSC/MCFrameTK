/*     */ package mcframe.commonCore.sys;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.resource.ctrl.MCResource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCProduct
/*     */ {
/*  32 */   private Product[] _product = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final File _dir;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class Product
/*     */   {
/*     */     private final String _name;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final String _version;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final String _build;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final String _module;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final String _vendor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Product(MCINIFile version) {
/*  80 */       this._name = version.get("VERSION", "NAME");
/*  81 */       this._version = version.get("VERSION", "VERSION");
/*  82 */       this._build = version.get("VERSION", "BUILD");
/*  83 */       this._module = version.get("VERSION", "MODULE");
/*  84 */       this._vendor = version.get("VERSION", "VENDOR");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String name() {
/*  95 */       return this._name;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String version() {
/* 105 */       return this._version;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String build() {
/* 115 */       return this._build;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String module() {
/* 125 */       return this._module;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String vendor() {
/* 135 */       return this._vendor;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCProduct(File dir) {
/* 155 */     this._dir = dir;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCProduct() {
/* 167 */     this(new File(MCSys.env.MCF_HOME()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initProduct() {
/* 177 */     if (this._product != null) {
/*     */       return;
/*     */     }
/*     */     
/* 181 */     if (this._dir == null || !this._dir.isDirectory()) {
/* 182 */       this._product = new Product[0];
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 193 */     List<Product> products = new ArrayList<>();
/*     */     
/* 195 */     String[] ps = MCResource.getProjectPath();
/* 196 */     String[] msorg = MCResource.getModulePath();
/* 197 */     String[] ms = new String[msorg.length + 1];
/* 198 */     System.arraycopy(msorg, 0, ms, 0, msorg.length);
/* 199 */     ms[msorg.length] = "Core";
/*     */     
/* 201 */     int mpos = 7;
/* 202 */     StringBuilder sb = new StringBuilder("version"); byte b; int i; String[] arrayOfString1;
/* 203 */     for (i = (arrayOfString1 = ms).length, b = 0; b < i; ) { String m = arrayOfString1[b];
/* 204 */       sb.delete(mpos, sb.length());
/* 205 */       sb.append(m);
/* 206 */       int ppos = sb.length(); byte b1; int j; String[] arrayOfString;
/* 207 */       for (j = (arrayOfString = ps).length, b1 = 0; b1 < j; ) { String p = arrayOfString[b1];
/* 208 */         sb.delete(ppos, sb.length());
/* 209 */         if (p.length() > 0) {
/* 210 */           sb.append("@");
/* 211 */           sb.append(p);
/*     */         } 
/* 213 */         sb.append(".txt");
/* 214 */         File file = new File(this._dir, sb.toString());
/* 215 */         if (file.isFile()) {
/*     */ 
/*     */           
/* 218 */           MCINIFile version = new MCINIFile();
/*     */           try {
/* 220 */             version.read(file);
/* 221 */           } catch (MCException ex) {
/*     */ 
/*     */             
/* 224 */             MCLog.write((Throwable)ex);
/*     */           } 
/*     */           
/* 227 */           Product product = new Product(version);
/* 228 */           products.add(product);
/*     */         }  b1++; }
/*     */        b++; }
/* 231 */      this._product = products.<Product>toArray(new Product[products.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Product[] producs() {
/* 242 */     initProduct();
/* 243 */     int size = this._product.length;
/* 244 */     Product[] copy = new Product[size];
/* 245 */     System.arraycopy(this._product, 0, copy, 0, size);
/* 246 */     return copy;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\sys\MCProduct.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */