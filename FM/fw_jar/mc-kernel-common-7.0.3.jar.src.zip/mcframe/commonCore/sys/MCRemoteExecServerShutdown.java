/*    */ package mcframe.commonCore.sys;
/*    */ 
/*    */ import java.rmi.RemoteException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MCRemoteExecServerShutdown
/*    */ {
/*    */   private void execute() {
/* 27 */     MCRemoteExec stub = MCRemoteExecUtil.getStub();
/*    */ 
/*    */     
/*    */     try {
/* 31 */       stub.shutdown();
/* 32 */     } catch (RemoteException ex) {
/* 33 */       throw MCRemoteExecUtil.analyzeRemoteException(ex);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void main(String[] args) {
/* 53 */     MCRemoteExecServerShutdown remote = new MCRemoteExecServerShutdown();
/*    */     try {
/* 55 */       remote.execute();
/* 56 */     } catch (Exception e) {
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 65 */       e.printStackTrace();
/* 66 */       System.exit(1);
/*    */     } 
/* 68 */     System.exit(0);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\sys\MCRemoteExecServerShutdown.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */