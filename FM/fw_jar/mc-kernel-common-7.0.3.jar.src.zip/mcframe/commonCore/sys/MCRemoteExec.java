package mcframe.commonCore.sys;

import java.rmi.Remote;
import java.rmi.RemoteException;

interface MCRemoteExec extends Remote {
  MCRemoteExecResponse execute(MCRemoteExecRequest paramMCRemoteExecRequest) throws RemoteException;
  
  void shutdown() throws RemoteException;
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\sys\MCRemoteExec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */