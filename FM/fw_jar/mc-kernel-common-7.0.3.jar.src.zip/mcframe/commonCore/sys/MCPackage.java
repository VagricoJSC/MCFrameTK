/*      */ package mcframe.commonCore.sys;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.net.URI;
/*      */ import java.net.URISyntaxException;
/*      */ import java.net.URL;
/*      */ import java.net.URLClassLoader;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.jar.JarEntry;
/*      */ import java.util.jar.JarFile;
/*      */ import java.util.regex.Pattern;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class MCPackage
/*      */ {
/*   47 */   private static final List<String> _userPathList = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   54 */   private static final List<String> _customPathList = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   61 */   private static final List<String> _servletPathList = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   68 */   private static final List<String> _systemPathList = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   76 */   private static final List<?>[] _pathListArray = new List[] {
/*   77 */       _userPathList, 
/*   78 */       _customPathList, 
/*   79 */       _servletPathList, 
/*   80 */       _systemPathList
/*      */     };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   91 */   private static final MCPackageInfo _root = new MCPackageInfo();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final char PACKAGE_DELIMITER = '/';
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  105 */   private static final String PATH_SEPARATOR = System.getProperty(
/*  106 */       "path.separator");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean _mod = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static {
/*  124 */     setSystemClassPath();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void setSystemClassPath() {
/*  146 */     _systemPathList.clear();
/*  147 */     _mod = true;
/*      */     
/*  149 */     String path = System.getProperty("java.class.path");
/*  150 */     String[] patharray = path.split(PATH_SEPARATOR); byte b; int i; String[] arrayOfString1;
/*  151 */     for (i = (arrayOfString1 = patharray).length, b = 0; b < i; ) { String item = arrayOfString1[b];
/*  152 */       item = item.trim();
/*  153 */       if (item.length() > 0) {
/*  154 */         _systemPathList.add(item);
/*      */       }
/*      */       b++; }
/*      */     
/*  158 */     ClassLoader cl = Thread.currentThread().getContextClassLoader();
/*  159 */     if (cl instanceof URLClassLoader) {
/*  160 */       addURLLoaderClassPath((URLClassLoader)cl);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void addURLLoaderClassPath(URLClassLoader cl) {
/*  175 */     if (cl == null) {
/*      */       return;
/*      */     }
/*      */     
/*  179 */     URL[] urls = cl.getURLs();
/*  180 */     for (int i = 0; i < urls.length; i++) {
/*      */       try {
/*  182 */         URI uri = urls[i].toURI();
/*      */         try {
/*  184 */           File file = new File(uri);
/*  185 */           _customPathList.add(file.getAbsolutePath());
/*  186 */           _mod = true;
/*  187 */         } catch (IllegalArgumentException illegalArgumentException) {
/*      */           
/*  189 */           System.out.println("Not Local Classpath Entry >>>>> " + urls[i].toString());
/*      */         } 
/*  191 */       } catch (URISyntaxException uRISyntaxException) {
/*      */         
/*  193 */         System.out.println("Bad Classpath Entry >>>>> " + urls[i].toString());
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  198 */     ClassLoader parentcl = cl.getParent();
/*  199 */     if (parentcl instanceof URLClassLoader) {
/*  200 */       addURLLoaderClassPath((URLClassLoader)parentcl);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setServletClassPath(List<String> list) {
/*  216 */     if (list != null) {
/*  217 */       _servletPathList.addAll(list);
/*  218 */       _mod = true;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void addClassPath(String path) {
/*  237 */     if (path == null) {
/*      */       return;
/*      */     }
/*      */     
/*  241 */     String[] patharray = path.split(PATH_SEPARATOR); byte b; int i; String[] arrayOfString1;
/*  242 */     for (i = (arrayOfString1 = patharray).length, b = 0; b < i; ) { String item = arrayOfString1[b];
/*  243 */       item = item.trim();
/*  244 */       if (item.length() > 0) {
/*  245 */         _userPathList.add(item);
/*  246 */         _mod = true;
/*      */       } 
/*      */       b++; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> getClassPathList() {
/*  259 */     List<String> list = new ArrayList<>(
/*  260 */         _userPathList.size() + 
/*  261 */         _customPathList.size() + 
/*  262 */         _servletPathList.size() + 
/*  263 */         _systemPathList.size());
/*      */     
/*  265 */     list.addAll(_userPathList);
/*  266 */     list.addAll(_customPathList);
/*  267 */     list.addAll(_servletPathList);
/*  268 */     list.addAll(_systemPathList);
/*  269 */     return list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String createPackagePath(String... items) {
/*  285 */     if (items == null) {
/*  286 */       return null;
/*      */     }
/*  288 */     StringBuilder sb = new StringBuilder();
/*  289 */     int len = items.length;
/*  290 */     if (len > 0) {
/*  291 */       sb.append(items[0]);
/*  292 */       for (int i = 1; i < len; i++) {
/*  293 */         if (items[i] != null) {
/*  294 */           sb.append('/');
/*  295 */           sb.append(items[i]);
/*      */         } 
/*      */       } 
/*      */     } 
/*  299 */     return sb.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void analyze() {
/*  315 */     if (!_mod) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  320 */     _root.clear();
/*      */ 
/*      */     
/*  323 */     for (int l = 0; l < _pathListArray.length; l++) {
/*  324 */       for (int i = 0; i < _pathListArray[l].size(); i++) {
/*  325 */         File temp = new File((String)_pathListArray[l].get(i));
/*  326 */         if (temp.isDirectory()) {
/*      */           
/*  328 */           analyzeDirctory(temp, _root);
/*  329 */         } else if (temp.isFile()) {
/*      */           
/*  331 */           analyzeArchive(temp, _root);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  336 */     _mod = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void jarAnalyzeError(File jar, String msg, Throwable ex) {
/*  440 */     System.out.print("[MCPackage] The error occurred when package information was acquired.");
/*  441 */     System.out.println();
/*  442 */     System.out.print(msg);
/*  443 */     System.out.print(" [" + jar.getPath() + "]");
/*  444 */     System.out.println();
/*  445 */     System.out.print(ex.getMessage());
/*  446 */     System.out.println();
/*  447 */     ex.printStackTrace();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void analyzeDirctory(File dir, MCPackageInfo info) {
/*  987 */     File[] files = dir.listFiles();
/*  988 */     if (files == null) {
/*      */       return;
/*      */     }
/*  991 */     for (int i = 0; i < files.length; i++) {
/*  992 */       if (files[i].isDirectory()) {
/*      */         
/*  994 */         MCPackageInfo addinfo = info.addPackage(files[i].getName());
/*  995 */         analyzeDirctory(files[i], addinfo);
/*  996 */       } else if (files[i].isFile()) {
/*      */         
/*  998 */         info.addFile(files[i].getName(), files[i].getPath());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void analyzeArchive(File jar, MCPackageInfo info) {
/* 1021 */     if (jar.getName().endsWith(".pack")) {
/*      */       
/* 1023 */       System.out.println("[MCPackage] Unsupport \"Pack200\". [" + jar.getPath() + "]");
/*      */       return;
/*      */     } 
/* 1026 */     JarFile jarFile = null;
/*      */     try {
/* 1028 */       jarFile = new JarFile(jar);
/* 1029 */     } catch (IOException ex) {
/* 1030 */       jarAnalyzeError(jar, "Jar File Open Error", ex);
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*      */     try {
/* 1036 */       Enumeration<JarEntry> list = jarFile.entries();
/* 1037 */       MCPackageInfo pkgInfo = null;
/* 1038 */       while (list.hasMoreElements()) {
/* 1039 */         String entry = ((JarEntry)list.nextElement()).toString();
/* 1040 */         int delimiter = entry.lastIndexOf('/');
/* 1041 */         if (delimiter != entry.length() - 1)
/*      */         {
/* 1043 */           if (delimiter > 0) {
/* 1044 */             String pkg = entry.substring(0, delimiter);
/*      */             
/* 1046 */             if (pkgInfo == null || !pkg.equals(pkgInfo.path())) {
/* 1047 */               pkgInfo = info.getPackage(pkg);
/* 1048 */               if (pkgInfo == null) {
/* 1049 */                 pkgInfo = info.addPackage(pkg);
/*      */               }
/*      */             } 
/*      */             
/* 1053 */             pkgInfo.addFile(entry.substring(delimiter + 1), 
/* 1054 */                 jar.getPath()); continue;
/*      */           } 
/* 1056 */           info.addFile(entry, jar.getPath());
/*      */         }
/*      */       
/*      */       } 
/* 1060 */     } catch (Exception ex) {
/* 1061 */       jarAnalyzeError(jar, "Jar File Read Error", ex);
/*      */       
/*      */       return;
/*      */     } finally {
/*      */       try {
/* 1066 */         jarFile.close();
/* 1067 */       } catch (IOException ex) {
/* 1068 */         jarAnalyzeError(jar, "Jar File Close Error", ex);
/*      */         return;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getRealPath(String name) {
/* 1104 */     analyze();
/*      */ 
/*      */     
/* 1107 */     int d = name.lastIndexOf('/');
/* 1108 */     String pkg = (d != -1) ? name.substring(0, d) : null;
/* 1109 */     String file = (d != -1) ? name.substring(d + 1) : name;
/*      */     
/* 1111 */     MCPackageInfo pkginfo = (pkg != null) ? _root.getPackage(pkg) : _root;
/* 1112 */     if (pkginfo == null) {
/* 1113 */       return null;
/*      */     }
/* 1115 */     MCFileInfo fileinfo = pkginfo.getFile(file);
/* 1116 */     return (fileinfo != null) ? fileinfo.getRealPath() : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> lsPackage(String path) {
/* 1143 */     analyze();
/*      */     
/* 1145 */     path = (path != null && 
/* 1146 */       path.charAt(path.length() - 1) != '/') ? (
/* 1147 */       String.valueOf(path) + '/') : path;
/* 1148 */     return ls(path);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> lsResource(String path) {
/* 1176 */     return ls(path);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> ls(String path) {
/* 1205 */     if (path == null) {
/* 1206 */       return null;
/*      */     }
/*      */     
/* 1209 */     analyze();
/*      */ 
/*      */     
/* 1212 */     int type = (path.charAt(path.length() - 1) == '/') ? 
/* 1213 */       1 : 2;
/*      */ 
/*      */     
/* 1216 */     List<MCPathInfo> infolist = getPathInfoList(path, type, _root, 0);
/* 1217 */     int size = infolist.size();
/* 1218 */     List<String> list = new ArrayList<>(size);
/* 1219 */     for (int i = 0; i < size; i++) {
/* 1220 */       MCPathInfo info = infolist.get(i);
/*      */       
/* 1222 */       list.add(info.path());
/*      */     } 
/*      */ 
/*      */     
/* 1226 */     Collections.sort(list);
/* 1227 */     return list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static List<MCPathInfo> getPathInfoList(String path, int type, MCPackageInfo current, int begin) {
/* 1246 */     if (!current.isReady())
/*      */     {
/*      */       
/* 1249 */       analyze();
/*      */     }
/*      */ 
/*      */     
/* 1253 */     int end = path.indexOf('/', begin);
/*      */     
/* 1255 */     boolean file = (end == -1);
/*      */     
/* 1257 */     boolean last = !(!file && end != path.length() - 1);
/*      */     
/* 1259 */     String name = file ? 
/* 1260 */       path.substring(begin) : path.substring(begin, end);
/*      */     
/* 1262 */     return name.equals("**") ? 
/*      */       
/* 1264 */       recurrentlySearch(path, type, current, begin, last, end + 1) : 
/*      */       
/* 1266 */       currentlySearch(path, type, current, name, last, end + 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static List<MCPathInfo> recurrentlySearch(String path, int type, MCPackageInfo current, int begin, boolean last, int next) {
/* 1294 */     List<MCPathInfo> list = new ArrayList<>();
/*      */ 
/*      */     
/* 1297 */     if (last) {
/*      */       
/* 1299 */       list.addAll(currentlySearch(path, type, current, 
/* 1300 */             "*", last, next));
/*      */     } else {
/*      */       
/* 1303 */       list.addAll(getPathInfoList(path, type, current, next));
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1308 */     MCPackageInfo[] children = current.getPackageArray(); byte b; int i; MCPackageInfo[] arrayOfMCPackageInfo1;
/* 1309 */     for (i = (arrayOfMCPackageInfo1 = children).length, b = 0; b < i; ) { MCPackageInfo info = arrayOfMCPackageInfo1[b];
/* 1310 */       List<MCPathInfo> clist = getPathInfoList(path, type, info, begin);
/* 1311 */       list.addAll(clist);
/*      */       b++; }
/*      */     
/* 1314 */     return list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static List<MCPathInfo> currentlySearch(String path, int type, MCPackageInfo current, String name, boolean last, int next) {
/* 1341 */     List<MCPathInfo> list = new ArrayList<>();
/*      */     
/* 1343 */     String regex = getRegularExpression(name);
/* 1344 */     Pattern p = Pattern.compile(regex);
/* 1345 */     if (last) {
/*      */       
/* 1347 */       MCPathInfo[] infos = (type == 2) ? 
/*      */         
/* 1349 */         (MCPathInfo[])current.getFileArray() : 
/*      */         
/* 1351 */         (MCPathInfo[])current.getPackageArray(); byte b; int i; MCPathInfo[] arrayOfMCPathInfo1;
/* 1352 */       for (i = (arrayOfMCPathInfo1 = infos).length, b = 0; b < i; ) { MCPathInfo info = arrayOfMCPathInfo1[b];
/* 1353 */         if (p.matcher(info.name()).matches()) {
/* 1354 */           list.add(info);
/*      */         }
/*      */         b++; }
/*      */     
/*      */     } else {
/* 1359 */       MCPackageInfo[] infos = current.getPackageArray(); byte b; int i; MCPackageInfo[] arrayOfMCPackageInfo1;
/* 1360 */       for (i = (arrayOfMCPackageInfo1 = infos).length, b = 0; b < i; ) { MCPackageInfo info = arrayOfMCPackageInfo1[b];
/* 1361 */         if (p.matcher(info.name()).matches()) {
/* 1362 */           List<MCPathInfo> clist = getPathInfoList(
/* 1363 */               path, type, info, next);
/* 1364 */           list.addAll(clist);
/*      */         }  b++; }
/*      */     
/*      */     } 
/* 1368 */     return list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String getRegularExpression(String str) {
/* 1386 */     StringBuilder rtn = new StringBuilder();
/* 1387 */     boolean asterisk = false;
/*      */     
/* 1389 */     for (int i = 0; i < str.length(); i++) {
/* 1390 */       char temp = str.charAt(i);
/* 1391 */       if (temp == '*') {
/* 1392 */         if (asterisk) {
/*      */           
/* 1394 */           rtn = rtn.append(".*");
/* 1395 */           asterisk = false;
/*      */         } else {
/* 1397 */           asterisk = true;
/*      */         } 
/* 1399 */       } else if (temp == '?') {
/* 1400 */         rtn = rtn.append("[^/]");
/* 1401 */       } else if (temp == '.') {
/*      */         
/* 1403 */         if (asterisk) {
/* 1404 */           rtn = rtn.append("[^/]*");
/* 1405 */           asterisk = false;
/*      */         } 
/*      */         
/* 1408 */         rtn = rtn.append("[.]");
/*      */       } else {
/*      */         
/* 1411 */         if (asterisk) {
/* 1412 */           rtn = rtn.append("[^/]*");
/* 1413 */           asterisk = false;
/*      */         } 
/*      */         
/* 1416 */         rtn = rtn.append(String.valueOf(temp));
/*      */       } 
/*      */     } 
/*      */     
/* 1420 */     if (asterisk) {
/* 1421 */       rtn = rtn.append("[^/]*");
/*      */     }
/* 1423 */     return rtn.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class MCPackageInfo
/*      */     extends MCPathInfo
/*      */   {
/* 1443 */     private final Map<String, MCPackage.MCPathInfo> entryMap = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1449 */     private int pkgsize = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1455 */     private int filesize = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean ready = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     MCPackageInfo() {
/* 1472 */       this("", (MCPackageInfo)null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private MCPackageInfo(String name, MCPackageInfo parent) {
/* 1484 */       super(1, name, parent);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     MCPackageInfo getPackage(String name) {
/* 1501 */       MCPackage.MCPathInfo info = get(name);
/* 1502 */       return (info != null && info.type() == 1) ? 
/* 1503 */         (MCPackageInfo)info : null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     MCPackage.MCFileInfo getFile(String name) {
/* 1518 */       MCPackage.MCPathInfo info = get(name);
/* 1519 */       return (info != null && info.type() == 2) ? 
/* 1520 */         (MCPackage.MCFileInfo)info : null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     MCPackage.MCPathInfo get(String name) {
/* 1535 */       return get(name, 0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private MCPackage.MCPathInfo get(String name, int begin) {
/* 1552 */       int end = name.indexOf('/', begin);
/* 1553 */       String item = (end != -1) ? 
/* 1554 */         name.substring(begin, end) : name.substring(begin);
/* 1555 */       MCPackage.MCPathInfo info = this.entryMap.get(item);
/* 1556 */       if (info != null && end != -1 && end != name.length() - 1)
/*      */       {
/* 1558 */         info = (info.type() == 1) ? (
/* 1559 */           (MCPackageInfo)info).get(name, end + 1) : null;
/*      */       }
/* 1561 */       return info;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     MCPackageInfo addPackage(String name) {
/* 1580 */       return (MCPackageInfo)add(1, name, (String)null, 0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     MCPackage.MCFileInfo addFile(String name, String path) {
/* 1598 */       return (MCPackage.MCFileInfo)add(2, name, path, 0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private MCPackage.MCPathInfo add(int type, String name, String path, int begin) {
/* 1621 */       int end = name.indexOf('/', begin);
/* 1622 */       boolean last = !(end != -1 && end != name.length() - 1);
/* 1623 */       String item = (end != -1) ? 
/* 1624 */         name.substring(begin, end) : name.substring(begin);
/* 1625 */       MCPackage.MCPathInfo info = this.entryMap.get(item);
/* 1626 */       if (info == null) {
/* 1627 */         if (!last) {
/*      */           
/* 1629 */           info = new MCPackageInfo(item, this);
/* 1630 */           this.pkgsize++;
/*      */         } else {
/* 1632 */           switch (type) {
/*      */             case 1:
/* 1634 */               info = new MCPackageInfo(item, this);
/* 1635 */               this.pkgsize++;
/*      */               break;
/*      */             case 2:
/* 1638 */               info = new MCPackage.MCFileInfo(item, this, path);
/* 1639 */               this.filesize++;
/*      */               break;
/*      */           } 
/*      */         } 
/* 1643 */         this.entryMap.put(item, info);
/* 1644 */         this.ready = true;
/*      */       } 
/* 1646 */       if (!last)
/*      */       {
/* 1648 */         info = (info.type() == 1) ? (
/* 1649 */           (MCPackageInfo)info).add(type, name, path, end + 1) : 
/* 1650 */           null;
/*      */       }
/* 1652 */       return info;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void clear() {
/* 1663 */       this.entryMap.clear();
/* 1664 */       this.pkgsize = 0;
/* 1665 */       this.filesize = 0;
/* 1666 */       this.ready = false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean isReady() {
/* 1680 */       return this.ready;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     MCPackage.MCPathInfo[] toArray() {
/* 1693 */       int size = this.entryMap.size();
/* 1694 */       return (MCPackage.MCPathInfo[])this.entryMap.values().toArray((Object[])new MCPackage.MCPathInfo[size]);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     MCPackageInfo[] getPackageArray() {
/* 1707 */       int pos = 0;
/* 1708 */       MCPackageInfo[] a = new MCPackageInfo[this.pkgsize];
/* 1709 */       for (MCPackage.MCPathInfo info : this.entryMap.values()) {
/* 1710 */         if (info.type() == 1) {
/* 1711 */           a[pos++] = (MCPackageInfo)info;
/*      */         }
/*      */       } 
/* 1714 */       return a;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     MCPackage.MCFileInfo[] getFileArray() {
/* 1727 */       int pos = 0;
/* 1728 */       MCPackage.MCFileInfo[] a = new MCPackage.MCFileInfo[this.filesize];
/* 1729 */       for (MCPackage.MCPathInfo info : this.entryMap.values()) {
/* 1730 */         if (info.type() == 2) {
/* 1731 */           a[pos++] = (MCPackage.MCFileInfo)info;
/*      */         }
/*      */       } 
/* 1734 */       return a;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class MCFileInfo
/*      */     extends MCPathInfo
/*      */   {
/*      */     private final String path;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     MCFileInfo(String name, MCPackage.MCPackageInfo parent, String path) {
/* 1763 */       super(2, name, parent);
/* 1764 */       this.path = path;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     String getRealPath() {
/* 1775 */       return this.path;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static abstract class MCPathInfo
/*      */   {
/*      */     public static final int TYPE_PACKAGE = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static final int TYPE_FILE = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final int type;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final String name;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final String path;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     MCPathInfo(int type, String name, MCPackage.MCPackageInfo parent) {
/* 1829 */       this.type = type;
/* 1830 */       this.name = name;
/* 1831 */       this.path = (parent != null && parent.path().length() > 0) ? (
/* 1832 */         String.valueOf(parent.path()) + '/' + name) : name;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int type() {
/* 1842 */       return this.type;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String name() {
/* 1852 */       return this.name;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String path() {
/* 1862 */       return this.path;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\sys\MCPackage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */