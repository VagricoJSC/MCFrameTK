/*     */ package mcframe.commonCore.sys;
/*     */ 
/*     */ import java.rmi.RMISecurityManager;
/*     */ import java.rmi.RemoteException;
/*     */ import java.rmi.registry.LocateRegistry;
/*     */ import java.rmi.registry.Registry;
/*     */ import java.rmi.server.ServerNotActiveException;
/*     */ import java.rmi.server.UnicastRemoteObject;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MCRemoteExecServer
/*     */   extends MCExec
/*     */   implements MCRemoteExec
/*     */ {
/*     */   class Exit
/*     */     implements Runnable
/*     */   {
/*     */     public void run() {
/*  44 */       int sec = 5;
/*  45 */       MCLog.write(Core_Msg_FW_A.FCBEC0043, new Object[] { "wait for " + sec + " sec." });
/*     */       try {
/*  47 */         for (int i = sec; i > 0; i--) {
/*  48 */           Thread.sleep(1000L);
/*     */         }
/*  50 */       } catch (InterruptedException e) {
/*  51 */         e.printStackTrace();
/*     */       } 
/*  53 */       MCLog.write(Core_Msg_FW_A.FCBEC0043, new Object[] { "MCRemoteExec shutdown." });
/*  54 */       System.exit(0);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean _shutdown = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   private int _count = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  77 */   private int _reqno = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCRemoteExecServer() {
/*  88 */     super(false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MCRemoteExecResponse execute(MCRemoteExecRequest req) throws RemoteException {
/*  94 */     int reqno = requestNo();
/*     */     
/*  96 */     if (req == null)
/*     */     {
/*  98 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 103 */       setCommand(new String[] { req.getCommand() });
/* 104 */       setWait(req.isWait());
/* 105 */       keepStdout(req.isKeepStdout());
/* 106 */       keepStderr(req.isKeepStderr());
/*     */       
/* 108 */       mergeStderr(req.isMergeStderr());
/*     */       
/* 110 */       setStdEncode(req.getStdEncode());
/*     */       
/* 112 */       startlog(reqno, req);
/*     */ 
/*     */       
/* 115 */       int ret = execute();
/*     */ 
/*     */       
/* 118 */       MCRemoteExecResponse res = new MCRemoteExecResponse();
/* 119 */       res.exitcode = ret;
/* 120 */       res.stdout = getStdout();
/* 121 */       res.stderr = getStderr();
/* 122 */       res.rmiReqNo = reqno;
/*     */       
/* 124 */       endlog(reqno, res);
/* 125 */       return res;
/*     */     }
/* 127 */     catch (Exception e) {
/* 128 */       MCLog.write(e);
/* 129 */       throw new RemoteException("Command Execute Error!", e);
/*     */     }
/*     */     finally {
/*     */       
/* 133 */       requestFinished();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void shutdown() throws RemoteException {
/* 138 */     startShutdown();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized int requestNo() throws RemoteException {
/* 151 */     if (this._shutdown) {
/* 152 */       throw new RemoteException("MCRemoteExec shutdown now.");
/*     */     }
/* 154 */     this._count++;
/* 155 */     return this._reqno++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void requestFinished() {
/* 167 */     this._count--;
/* 168 */     confirmExit();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void startShutdown() {
/* 180 */     if (this._shutdown) {
/*     */       return;
/*     */     }
/*     */     
/* 184 */     MCLog.write(Core_Msg_FW_A.FCBEC0043, new Object[] { "MCRemoteExec shutdown start." });
/* 185 */     this._shutdown = true;
/* 186 */     confirmExit();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void confirmExit() {
/* 198 */     if (this._count > 0 || !this._shutdown) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 204 */     Exit exit = new Exit();
/* 205 */     Thread t = new Thread(exit);
/* 206 */     t.start();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void startlog(int reqno, MCRemoteExecRequest req) {
/* 219 */     String client = null;
/*     */     try {
/* 221 */       client = UnicastRemoteObject.getClientHost();
/* 222 */     } catch (ServerNotActiveException serverNotActiveException) {
/*     */ 
/*     */       
/* 225 */       client = "unknown host.";
/*     */     } 
/*     */     
/* 228 */     String s_reqno = String.valueOf(reqno);
/* 229 */     MCLog.write(Core_Msg_FW_A.FCBEC0036, new Object[] { s_reqno, Thread.currentThread() });
/* 230 */     MCLog.write(Core_Msg_FW_A.FCBEC0037, new Object[] { s_reqno, client, req.user, req.srvReqNo });
/* 231 */     MCLog.write(Core_Msg_FW_A.FCBEC0039, new Object[] { s_reqno, req.command, 
/* 232 */           String.valueOf(req.wait), 
/* 233 */           String.valueOf(req.keepStdout), 
/* 234 */           String.valueOf(req.keepStderr) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void endlog(int reqno, MCRemoteExecResponse res) {
/* 246 */     String s_reqno = String.valueOf(reqno);
/* 247 */     MCLog.write(Core_Msg_FW_A.FCBEC0040, new Object[] { s_reqno, String.valueOf(res.getExitcode()) });
/* 248 */     MCLog.write(Core_Msg_FW_A.FCBEC0041, new Object[] { s_reqno, res.getStdout() });
/* 249 */     MCLog.write(Core_Msg_FW_A.FCBEC0042, new Object[] { s_reqno, res.getStderr() });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 263 */   private static MCRemoteExecServer impl = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 279 */     MCRemoteExecSys.init();
/*     */     
/* 281 */     if (args.length > 0) {
/* 282 */       startLocal(args);
/*     */     } else {
/* 284 */       startRMI();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void startRMI() {
/* 295 */     if (System.getSecurityManager() == null) {
/* 296 */       System.setSecurityManager(new RMISecurityManager());
/*     */     }
/*     */ 
/*     */     
/* 300 */     impl = new MCRemoteExecServer();
/*     */ 
/*     */     
/* 303 */     MCRemoteExec stub = null;
/*     */     try {
/* 305 */       stub = (MCRemoteExec)UnicastRemoteObject.exportObject(impl, 0);
/* 306 */       MCLog.write(Core_Msg_FW_A.FCBEC0043, new Object[] { "MCRemoteExec export." });
/* 307 */     } catch (Exception e) {
/*     */       
/* 309 */       MCLog.write((Throwable)new MCException(e, Core_Msg_FW_A.FCBEC0044, new Object[] {
/* 310 */               "MCRemoteExec export ERROR." }));
/* 311 */       System.exit(1);
/*     */     } 
/*     */ 
/*     */     
/* 315 */     Registry registry = null;
/*     */     try {
/* 317 */       int port = Integer.parseInt(MCRemoteExecUtil.getPort());
/*     */ 
/*     */ 
/*     */       
/* 321 */       registry = LocateRegistry.createRegistry(port);
/* 322 */       MCLog.write(Core_Msg_FW_A.FCBEC0043, new Object[] { "Registry created. port[" + port + "]" });
/* 323 */     } catch (Exception e) {
/*     */       
/* 325 */       MCLog.write((Throwable)new MCException(e, Core_Msg_FW_A.FCBEC0044, new Object[] {
/* 326 */               "Registry create ERROR. port[" + 
/* 327 */               MCRemoteExecUtil.getPort() + 
/* 328 */               "]" }));
/* 329 */       System.exit(2);
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 334 */       registry.rebind(MCRemoteExecUtil.getStubBindName(), stub);
/* 335 */     } catch (Exception e) {
/*     */       
/* 337 */       MCLog.write((Throwable)new MCException(e, Core_Msg_FW_A.FCBEC0044, new Object[] { "Registry bind ERROR." }));
/* 338 */       System.exit(3);
/*     */     } 
/*     */ 
/*     */     
/* 342 */     MCLog.write(Core_Msg_FW_A.FCBEC0043, new Object[] { "MCRemoteExec ready" });
/* 343 */     MCLog.write(Core_Msg_FW_A.FCBEC0043, new Object[] { "Current Dir: " + 
/* 344 */           impl._current.getAbsolutePath() });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void startLocal(String[] args) {
/* 356 */     MCRemoteExecServer impl = new MCRemoteExecServer();
/* 357 */     impl.setCommand(args);
/*     */     
/* 359 */     MCRemoteExecRequest req = new MCRemoteExecRequest();
/* 360 */     req.command = impl.getCommand();
/* 361 */     req.wait = true;
/* 362 */     req.keepStdout = true;
/* 363 */     req.keepStderr = true;
/*     */     
/*     */     try {
/* 366 */       MCRemoteExecResponse res = impl.execute(req);
/* 367 */       System.exit(res.getExitcode());
/* 368 */     } catch (Exception e) {
/*     */       
/* 370 */       MCLog.write((Throwable)new MCException(e, Core_Msg_FW_A.FCBEC0044, new Object[] { "Commnad Execute ERROR." }));
/* 371 */       System.exit(-1);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\sys\MCRemoteExecServer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */