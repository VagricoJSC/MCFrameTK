/*     */ package mcframe.commonCore.sys;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.Arrays;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.resource.MCConfig;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MCCatalogFile
/*     */ {
/*     */   private final File _file;
/*     */   
/*     */   public static class Entry
/*     */     implements Comparable<Entry>
/*     */   {
/*  42 */     public final char SEPARATOR = '|';
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final String _file;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final long _size;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final String _stamp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final String _hash;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final boolean _lazy;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Entry(String entry) {
/*  86 */       this(entry, false);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Entry(String entry, boolean lazy) {
/* 107 */       String[] col = new String[4];
/* 108 */       for (int i = 0, s = 0, e = 0; i < 4; i++) {
/* 109 */         e = entry.indexOf('|', s);
/* 110 */         if (e != -1) {
/* 111 */           col[i] = entry.substring(s, e);
/* 112 */           s = e + 1;
/*     */         } else {
/*     */           
/* 115 */           col[i] = entry.substring(s);
/*     */           break;
/*     */         } 
/*     */       } 
/* 119 */       this._file = col[0];
/* 120 */       this._size = parseSize(col[1]);
/* 121 */       this._stamp = col[2];
/* 122 */       this._hash = col[3];
/* 123 */       this._lazy = lazy;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private long parseSize(String size) {
/* 135 */       if (size != null) {
/*     */         try {
/* 137 */           return Long.parseLong(size);
/*     */         }
/* 139 */         catch (NumberFormatException numberFormatException) {}
/*     */       }
/*     */ 
/*     */       
/* 143 */       return -1L;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String file() {
/* 154 */       return this._file;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public long size() {
/* 164 */       return this._size;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String timestamp() {
/* 174 */       return this._stamp;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String hash() {
/* 184 */       return this._hash;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean lazy() {
/* 194 */       return this._lazy;
/*     */     }
/*     */ 
/*     */     
/*     */     public int compareTo(Entry o) {
/* 199 */       if (o == null) {
/* 200 */         return 1;
/*     */       }
/*     */ 
/*     */       
/* 204 */       return this._file.compareToIgnoreCase(o.file());
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 209 */       if (super.equals(obj)) {
/* 210 */         return true;
/*     */       }
/* 212 */       if (obj instanceof Entry) {
/* 213 */         return (compareTo((Entry)obj) == 0);
/*     */       }
/* 215 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 220 */       return this._file.hashCode();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean _completed = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean _init = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCCatalogFile(File file) {
/* 257 */     this._file = file;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void init() {
/* 270 */     if (this._init) {
/*     */       return;
/*     */     }
/*     */     
/* 274 */     File catalogFile = file();
/* 275 */     if (catalogFile == null) {
/*     */       
/* 277 */       this._init = true;
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 282 */     MCINIFile catalog = new MCINIFile();
/*     */     try {
/* 284 */       catalog.read(catalogFile);
/* 285 */       this._completed = true;
/*     */     }
/* 287 */     catch (MCException ex) {
/*     */       
/* 289 */       boolean notfound = ex.getID().equals(Core_Msg_FW_A.FCBEC0024);
/* 290 */       String path = catalogFile.getAbsolutePath();
/*     */ 
/*     */       
/* 293 */       if (MCConfig.isInitialized()) {
/*     */         
/* 295 */         ex = notfound ? 
/* 296 */           new MCException((Throwable)ex, Core_Msg_FW_A.FCBEC0026, new Object[] { path
/* 297 */             }) : new MCException((Throwable)ex, Core_Msg_FW_A.FCBEC0027, new Object[] { path });
/* 298 */         MCLog.write((Throwable)ex);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 304 */       this._completed = false;
/*     */     } 
/*     */ 
/*     */     
/* 308 */     initValue(catalog);
/*     */     
/* 310 */     this._init = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract void initValue(MCINIFile paramMCINIFile);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Entry[] createEntry(MCINIFile catalog, String section, boolean lazy) {
/* 334 */     String[] keys = catalog.getKeys(section);
/* 335 */     if (keys == null)
/*     */     {
/* 337 */       keys = new String[0];
/*     */     }
/* 339 */     Entry[] entry = new Entry[keys.length];
/*     */     
/* 341 */     int index = 0; byte b; int i; String[] arrayOfString1;
/* 342 */     for (i = (arrayOfString1 = keys).length, b = 0; b < i; ) { String key = arrayOfString1[b];
/* 343 */       entry[index++] = new Entry(key, lazy); b++; }
/*     */     
/* 345 */     Arrays.sort((Object[])entry);
/* 346 */     return entry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File file() {
/* 357 */     return this._file;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean completed() {
/* 368 */     init();
/* 369 */     return this._completed;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\sys\MCCatalogFile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */