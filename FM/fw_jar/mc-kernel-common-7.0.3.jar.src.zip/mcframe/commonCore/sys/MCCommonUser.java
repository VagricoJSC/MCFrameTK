/*     */ package mcframe.commonCore.sys;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ import mcframe.commonCore.lang.MCBinary;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MCCommonUser
/*     */   implements MCUser
/*     */ {
/*  22 */   private MCUser _userimpl = new NoInitUser(null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean _init = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void init(MCUser user) {
/*  50 */     if (user != null && 
/*  51 */       !this._init) {
/*  52 */       this._userimpl = user;
/*  53 */       this._init = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String ID() {
/*  60 */     return this._userimpl.ID();
/*     */   }
/*     */ 
/*     */   
/*     */   public String name() {
/*  65 */     return this._userimpl.name();
/*     */   }
/*     */ 
/*     */   
/*     */   public String loginSequence() {
/*  70 */     return this._userimpl.loginSequence();
/*     */   }
/*     */ 
/*     */   
/*     */   public Locale locale() {
/*  75 */     return this._userimpl.locale();
/*     */   }
/*     */ 
/*     */   
/*     */   public TimeZone timezone() {
/*  80 */     return this._userimpl.timezone();
/*     */   }
/*     */ 
/*     */   
/*     */   public String clientID() {
/*  85 */     return this._userimpl.clientID();
/*     */   }
/*     */ 
/*     */   
/*     */   public String coCD() {
/*  90 */     return this._userimpl.coCD();
/*     */   }
/*     */ 
/*     */   
/*     */   public String coNm() {
/*  95 */     return this._userimpl.coNm();
/*     */   }
/*     */ 
/*     */   
/*     */   public String extattr1() {
/* 100 */     return this._userimpl.extattr1();
/*     */   }
/*     */ 
/*     */   
/*     */   public String extattr2() {
/* 105 */     return this._userimpl.extattr2();
/*     */   }
/*     */ 
/*     */   
/*     */   public String extattr3() {
/* 110 */     return this._userimpl.extattr3();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCBinary image() {
/* 115 */     return this._userimpl.image();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] licmods() {
/* 121 */     return this._userimpl.licmods();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class NoInitUser
/*     */     implements MCUser
/*     */   {
/*     */     private NoInitUser() {}
/*     */ 
/*     */ 
/*     */     
/*     */     public String ID() {
/* 134 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public String name() {
/* 139 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public String loginSequence() {
/* 144 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public Locale locale() {
/* 149 */       return Locale.getDefault();
/*     */     }
/*     */ 
/*     */     
/*     */     public TimeZone timezone() {
/* 154 */       return TimeZone.getDefault();
/*     */     }
/*     */ 
/*     */     
/*     */     public String clientID() {
/* 159 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public String coCD() {
/* 164 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public String coNm() {
/* 169 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public String extattr1() {
/* 174 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public String extattr2() {
/* 179 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public String extattr3() {
/* 184 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String[] licmods() {
/* 190 */       return new String[0];
/*     */     }
/*     */ 
/*     */     
/*     */     public MCBinary image() {
/* 195 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\sys\MCCommonUser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */