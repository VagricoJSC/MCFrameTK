/*     */ package mcframe.commonCore.sys;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import mcframe.commonCore.lang.MCDate;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCError;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.resource.MCConfig;
/*     */ import mcframe.commonCore.resource.MCConst;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MCRemoteExecSys
/*     */   extends MCSys
/*     */ {
/*     */   private static boolean _init = false;
/*     */   
/*     */   static final void init() {
/*  46 */     if (!_init) {
/*     */       try {
/*     */         String trace;
/*     */         
/*  50 */         MCDate starttime = new MCDate();
/*     */ 
/*     */         
/*  53 */         System.out.println(
/*  54 */             "[" + starttime.toString() + "] Server MCF_HOME:" + 
/*  55 */             env.MCF_HOME());
/*  56 */         if (!validateMCF_HOME()) {
/*  57 */           throw initError("Invalid \"MCF_HOME\".\nMCF_HOME: {1}", new String[] {
/*  58 */                 env.MCF_HOME()
/*     */               });
/*     */         }
/*     */ 
/*     */         
/*     */         try {
/*  64 */           StringBuilder sb = new StringBuilder();
/*  65 */           sb.append(Config.init());
/*  66 */           sb.append(Const.init());
/*  67 */           trace = sb.toString();
/*  68 */         } catch (MCException ex) {
/*  69 */           throw ex.getID().equals(Core_Msg_FW_A.FCBJC0024) ? 
/*  70 */             initError(ex, 
/*  71 */               "Resource Load Failed.\nFile: {1}", new String[] {
/*  72 */                 ex.getBind(1)
/*  73 */               }) : initError(ex, "Resource Load Failed.", new String[0]);
/*  74 */         } catch (Throwable ex) {
/*  75 */           throw initError(ex, "Resource Load Failed.", new String[0]);
/*     */         } 
/*     */ 
/*     */         
/*  79 */         String df = MCConfig.common.getString("log.dateformat", 
/*  80 */             "yyyyMMddHHmmss");
/*  81 */         MCLog.write(Core_Msg_FW_A.FCBEC0008, new Object[] { starttime.toString(df) });
/*  82 */         MCLog.write(Core_Msg_FW_A.FCBEC0007, new Object[] { env.MCF_HOME() });
/*  83 */         MCConfig.tracelog(true, "Server Initialize", trace);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  88 */         MCLog.write(Core_Msg_FW_A.FCBEC0009, new Object[0]);
/*  89 */         _init = true;
/*     */       }
/*  91 */       catch (Throwable t) {
/*  92 */         MCError err = (t instanceof MCError) ? 
/*  93 */           (MCError)t : initError(t);
/*  94 */         err.dump();
/*  95 */         throw err;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class Config
/*     */     extends MCConfig
/*     */   {
/*     */     protected static String init() {
/* 118 */       return MCConfig.init();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class Const
/*     */     extends MCConst
/*     */   {
/*     */     protected static String init() {
/* 139 */       return MCConst.loadInit(Locale.getDefault());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\sys\MCRemoteExecSys.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */