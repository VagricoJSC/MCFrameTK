/*     */ package mcframe.commonCore.sys;
/*     */ 
/*     */ import java.io.File;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCDownloadHistory
/*     */   extends MCCatalogFile
/*     */ {
/*     */   public static File getDefaultDir() {
/*  39 */     return new File(MCSys.env.MCF_HOME(), "history");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static File createDefaultFile(File dir) {
/*  54 */     return new File(dir, "dwnld_history.txt");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  63 */   private String _host = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   private String _port = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  75 */   private String _code_base = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   private MCCatalogFile.Entry[] _history = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCDownloadHistory(File file) {
/* 102 */     super((file != null) ? (file.isDirectory() ? createDefaultFile(file) : file) : createDefaultFile(getDefaultDir()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCDownloadHistory() {
/* 113 */     this((File)null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initValue(MCINIFile catalog) {
/* 119 */     this._host = catalog.get("SOURCE", "HOST");
/* 120 */     this._port = catalog.get("SOURCE", "PORT");
/* 121 */     this._code_base = catalog.get("SOURCE", "CODE_BASE");
/*     */ 
/*     */     
/* 124 */     this._history = createEntry(catalog, "HISTORY", false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String host() {
/* 136 */     init();
/* 137 */     return this._host;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String port() {
/* 148 */     init();
/* 149 */     return this._port;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String code_base() {
/* 160 */     init();
/* 161 */     return this._code_base;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCCatalogFile.Entry[] entries() {
/* 177 */     init();
/* 178 */     if (this._history == null) {
/* 179 */       return null;
/*     */     }
/* 181 */     int size = this._history.length;
/* 182 */     MCCatalogFile.Entry[] copy = new MCCatalogFile.Entry[size];
/* 183 */     System.arraycopy(this._history, 0, copy, 0, size);
/* 184 */     return copy;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\sys\MCDownloadHistory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */