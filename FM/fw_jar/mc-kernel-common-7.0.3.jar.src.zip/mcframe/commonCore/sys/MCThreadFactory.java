/*     */ package mcframe.commonCore.sys;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCThreadFactory
/*     */   implements ThreadFactory
/*     */ {
/*  34 */   private static Map<String, AtomicInteger> _nummap = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Thread createThread(String name, Runnable r) {
/*  49 */     return (new MCThreadFactory(name)).newThread(r);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   private String _name = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCThreadFactory(String name) {
/*  83 */     this._name = (name == null || name.length() <= 0) ? "MCThread" : name;
/*  84 */     _nummap.put(this._name, new AtomicInteger(1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Thread newThread(Runnable r) {
/*  91 */     SecurityManager s = System.getSecurityManager();
/*  92 */     ThreadGroup group = (s != null) ? 
/*  93 */       s.getThreadGroup() : 
/*  94 */       Thread.currentThread().getThreadGroup();
/*  95 */     Thread t = new Thread(group, r);
/*     */ 
/*     */     
/*  98 */     t.setName(String.valueOf(this._name) + "-" + ((AtomicInteger)_nummap.get(this._name)).getAndIncrement());
/*     */ 
/*     */     
/* 101 */     t.setDaemon(true);
/*     */ 
/*     */     
/* 104 */     if (t.getPriority() != 5) {
/* 105 */       t.setPriority(5);
/*     */     }
/*     */     
/* 108 */     return t;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\sys\MCThreadFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */