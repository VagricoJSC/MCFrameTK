package mcframe.commonCore.sys;

import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCTimestamp;

public interface MCRequest {
  String clientRequestNo();
  
  String clientId();
  
  String serverRequestNo();
  
  String serverThreadNo();
  
  String cooperateCd();
  
  String serverId();
  
  String moduleId();
  
  String logicId();
  
  String operationId();
  
  String version();
  
  MCTimestamp createTime();
  
  MCNumber limitDLSize();
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\sys\MCRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */