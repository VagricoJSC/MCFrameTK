/*     */ package mcframe.commonCore.sys;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.resource.ctrl.MCResource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MCINIFile
/*     */ {
/*     */   private static final String MULTI_START = ">>>>>";
/*     */   private static final String MULTI_END = "<<<<<";
/*  79 */   private final Map<String, Map<String, String>> _entryMap = new LinkedHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String get(String section, String key) {
/* 107 */     Map<String, String> map = this._entryMap.get(section);
/* 108 */     if (map != null) {
/* 109 */       return map.get(key);
/*     */     }
/* 111 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getSections() {
/* 124 */     int size = this._entryMap.size();
/* 125 */     return (String[])this._entryMap.keySet().toArray((Object[])new String[size]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getKeys(String section) {
/* 139 */     Map<String, String> map = this._entryMap.get(section);
/* 140 */     if (map == null) {
/* 141 */       return null;
/*     */     }
/* 143 */     int size = map.size();
/* 144 */     return (String[])map.keySet().toArray((Object[])new String[size]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void read(File file) {
/* 163 */     this._entryMap.clear();
/*     */     
/*     */     try {
/* 166 */       Exception exception2, exception1 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 175 */     catch (FileNotFoundException e) {
/*     */       
/* 177 */       throw new MCException(e, Core_Msg_FW_A.FCBEC0024, new Object[] { file.getAbsolutePath() });
/*     */     }
/* 179 */     catch (UnsupportedEncodingException unsupportedEncodingException) {
/*     */ 
/*     */     
/* 182 */     } catch (Exception ex) {
/*     */       
/* 184 */       throw new MCException(ex, Core_Msg_FW_A.FCBEC0025, new Object[] { file.getAbsolutePath() });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void analyze(BufferedReader br, File file) throws IOException {
/* 206 */     String line = null;
/* 207 */     String section = null;
/* 208 */     while ((line = br.readLine()) != null) {
/* 209 */       if (line.length() > 0) {
/* 210 */         int end; char head = line.charAt(0);
/* 211 */         switch (head) {
/*     */           case '#':
/*     */             continue;
/*     */           case '[':
/* 215 */             end = line.indexOf(']');
/* 216 */             if (end > -1) {
/* 217 */               section = createSection(line, 1, end);
/*     */               continue;
/*     */             } 
/*     */             break;
/*     */         } 
/* 222 */         setEntry(br, file, section, line);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String createSection(String text, int start, int end) {
/* 242 */     String section = text.substring(start, end);
/* 243 */     section = trimValue(section);
/* 244 */     if (!this._entryMap.containsKey(section))
/*     */     {
/* 246 */       this._entryMap.put(section, 
/* 247 */           new LinkedHashMap<>());
/*     */     }
/* 249 */     return section;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setEntry(BufferedReader br, File file, String section, String line) throws IOException {
/* 268 */     String key = line;
/* 269 */     String val = null;
/* 270 */     int eq = line.indexOf('=');
/* 271 */     if (eq > -1) {
/* 272 */       key = line.substring(0, eq++);
/* 273 */       if (eq < line.length()) {
/* 274 */         val = line.substring(eq);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 279 */     key = trimKey(key);
/*     */ 
/*     */     
/* 282 */     val = trimValue(val);
/* 283 */     if (val != null && val.equals(">>>>>"))
/*     */     {
/* 285 */       val = multiLineValue(br);
/*     */     }
/*     */ 
/*     */     
/* 289 */     Map<String, String> map = this._entryMap.get(section);
/* 290 */     if (map == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 297 */     if (!map.containsKey(key)) {
/* 298 */       map.put(key, val);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String multiLineValue(BufferedReader br) throws IOException {
/* 315 */     StringBuilder sb = new StringBuilder();
/* 316 */     String line = null;
/* 317 */     while ((line = br.readLine()) != null) {
/*     */       
/* 319 */       line = trimValue(line);
/* 320 */       if (line.equals("<<<<<")) {
/*     */         break;
/*     */       }
/* 323 */       sb.append(line);
/* 324 */       sb.append(MCResource.LINE_SEP);
/*     */     } 
/* 326 */     return (sb.length() > 0) ? sb.toString() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String trimKey(String key) {
/* 338 */     return MCStringUtil.trimTail(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String trimValue(String value) {
/* 350 */     return MCStringUtil.trim(value);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\sys\MCINIFile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */