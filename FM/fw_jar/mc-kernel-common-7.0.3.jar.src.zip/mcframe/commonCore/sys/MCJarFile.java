/*     */ package mcframe.commonCore.sys;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.jar.Attributes;
/*     */ import java.util.jar.JarFile;
/*     */ import java.util.jar.Manifest;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCJarFile
/*     */   implements Comparable<MCJarFile>
/*     */ {
/*     */   public static final String APP_TITLE = "Specification-Title";
/*     */   public static final String APP_VERSION = "Specification-Version";
/*     */   public static final String APP_VENDOR = "Specification-Vendor";
/*     */   public static final String JAR_TITLE = "Implementation-Title";
/*     */   public static final String JAR_BUILD = "Implementation-Version";
/*     */   public static final String JAR_VENDOR = "Implementation-Vendor";
/*     */   public static final String APP_MAIN = "Application-Main";
/*     */   public static final String APP_SUBMODULEID = "Application-Submoduleid";
/*     */   
/*     */   public static MCJarFile[] selectMCFrameJar(MCJarFile[] jars) {
/*  90 */     if (jars == null) {
/*  91 */       return null;
/*     */     }
/*  93 */     List<MCJarFile> list = new ArrayList<>(jars.length); byte b; int i; MCJarFile[] arrayOfMCJarFile;
/*  94 */     for (i = (arrayOfMCJarFile = jars).length, b = 0; b < i; ) { MCJarFile jar = arrayOfMCJarFile[b];
/*  95 */       if (jar != null && jar.isMCFrameJar())
/*  96 */         list.add(jar); 
/*     */       b++; }
/*     */     
/*  99 */     return list.<MCJarFile>toArray(new MCJarFile[list.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   private File _file = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 116 */   private Manifest _manifest = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean _mcfjar = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 130 */   private Throwable _initException = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCJarFile(File file) {
/* 141 */     this._file = file;
/* 142 */     JarFile jar = null;
/*     */     try {
/* 144 */       jar = new JarFile(this._file, false, 1);
/* 145 */       this._manifest = jar.getManifest();
/* 146 */       this._mcfjar = isMCFrameJar(jar);
/* 147 */     } catch (Throwable ex) {
/*     */       
/* 149 */       this._initException = ex;
/*     */     } finally {
/* 151 */       if (jar != null) {
/*     */         try {
/* 153 */           jar.close();
/* 154 */         } catch (IOException iOException) {}
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isMCFrameJar(JarFile jar) {
/* 169 */     if (jar != null)
/*     */     {
/* 171 */       if (jar.getJarEntry("mcframe/") != null || 
/* 172 */         jar.getJarEntry("conf/") != null || 
/* 173 */         jar.getJarEntry("const/") != null) {
/*     */         return true;
/*     */       }
/*     */     }
/*     */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isMCFrameJar() {
/* 186 */     return this._mcfjar;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getValue(String key) {
/* 198 */     if (this._manifest == null) {
/* 199 */       return null;
/*     */     }
/* 201 */     Attributes attrMain = this._manifest.getMainAttributes();
/* 202 */     if (attrMain == null) {
/* 203 */       return null;
/*     */     }
/* 205 */     return attrMain.getValue(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final File getFile() {
/* 216 */     return this._file;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Throwable getInitializeException() {
/* 227 */     return this._initException;
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(MCJarFile jar) {
/* 232 */     return this._file.compareTo(jar._file);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 237 */     if (obj != null && obj instanceof MCJarFile) {
/* 238 */       return this._file.equals(((MCJarFile)obj)._file);
/*     */     }
/* 240 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 245 */     return this._file.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\sys\MCJarFile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */