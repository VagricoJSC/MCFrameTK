/*     */ package mcframe.commonCore.sys;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.nio.charset.Charset;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.StringTokenizer;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.resource.MCConfig;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCExec
/*     */ {
/* 117 */   String _command = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean _wait = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean _keepStdout = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean _keepStderr = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean _mergeStderr = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 155 */   String _stdEncode = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 162 */   StringBuilder _stdout = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 169 */   StringBuilder _stderr = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 177 */   File _current = new File(MCConfig.common.getString("exec.current", 
/* 178 */         MCSys.env.MCF_HOME()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 185 */   boolean _remote = MCConfig.common.getBoolean("exec.execsrv.active", false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 193 */   MCRemoteExec stub = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCExec(String... command) {
/* 207 */     setCommand(command);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCExec(boolean remote) {
/* 220 */     this(new String[0]);
/* 221 */     this._remote = remote;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 226 */     StringBuilder sb = new StringBuilder();
/* 227 */     sb.append(this._command);
/* 228 */     sb.append(" [");
/* 229 */     if (!this._wait) {
/* 230 */       sb.append("no wait");
/*     */     } else {
/*     */       
/* 233 */       sb.append("wait");
/* 234 */       sb = this._keepStdout ? sb.append(", stdout") : sb;
/* 235 */       sb = this._keepStderr ? sb.append(", stderr") : sb;
/*     */     } 
/* 237 */     if (this._remote) {
/* 238 */       sb.append(", remote(")
/* 239 */         .append(MCRemoteExecUtil.getHost())
/* 240 */         .append(":")
/* 241 */         .append(MCRemoteExecUtil.getPort())
/* 242 */         .append(")");
/*     */     }
/* 244 */     sb.append("]");
/* 245 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCommand() {
/* 256 */     return this._command;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCommand(String... command) {
/* 274 */     this._command = createCommand(command);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String createCommand(String... command) {
/* 298 */     if (command == null || command.length == 0) {
/* 299 */       return null;
/*     */     }
/* 301 */     StringBuilder sb = new StringBuilder(); byte b; int i; String[] arrayOfString;
/* 302 */     for (i = (arrayOfString = command).length, b = 0; b < i; ) { String c = arrayOfString[b];
/* 303 */       if (c != null) {
/* 304 */         sb.append(c);
/* 305 */         sb.append(" ");
/*     */       }  b++; }
/*     */     
/* 308 */     return sb.substring(0, sb.length() - 1).toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWait(boolean wait) {
/* 327 */     this._wait = wait;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void keepStdout(boolean keep) {
/* 351 */     this._keepStdout = !MCSys.env.isWin9x() ? keep : false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void keepStderr(boolean keep) {
/* 375 */     this._keepStderr = !MCSys.env.isWin9x() ? keep : false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mergeStderr(boolean merge) {
/* 394 */     this._mergeStderr = merge;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getStdout() {
/* 416 */     return (this._stdout != null) ? this._stdout.toString() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getStderr() {
/* 439 */     return (this._stderr != null) ? this._stderr.toString() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStdEncode(String enc) {
/* 460 */     this._stdEncode = enc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int execute() {
/* 478 */     MCLog.write(Core_Msg_FW_A.FCBEC0028, new Object[] { toString() });
/* 479 */     int ret = 0;
/*     */     try {
/* 481 */       ret = this._remote ? executeRemote() : executeLocal();
/*     */     }
/* 483 */     catch (Exception e) {
/*     */       
/* 485 */       MCException ex = new MCException(e, Core_Msg_FW_A.FCBEC0030, new Object[0]);
/* 486 */       MCLog.write((Throwable)ex);
/* 487 */       throw ex;
/*     */     } 
/*     */     
/* 490 */     MCLog.write(Core_Msg_FW_A.FCBEC0029, new Object[] { this._wait ? String.valueOf(ret) : "-" });
/* 491 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int executeLocal() {
/* 505 */     if (this._command == null || this._command.length() == 0)
/*     */     {
/* 507 */       throw new MCException(Core_Msg_FW_A.FCBEC0031, new Object[0]);
/*     */     }
/*     */ 
/*     */     
/* 511 */     Process process = startProcess();
/*     */ 
/*     */     
/* 514 */     resetStdBuffer();
/* 515 */     StdThread thread = new StdThread(process);
/* 516 */     thread.start();
/*     */ 
/*     */     
/* 519 */     int ret = 0;
/* 520 */     if (this._wait) {
/*     */       
/*     */       try {
/*     */ 
/*     */         
/* 525 */         ret = process.waitFor();
/*     */         
/* 527 */         thread.join();
/*     */       }
/* 529 */       catch (InterruptedException interruptedException) {}
/*     */     }
/*     */ 
/*     */     
/* 533 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Process startProcess() {
/* 547 */     StringTokenizer st = new StringTokenizer(this._command);
/* 548 */     String[] cmdarray = new String[st.countTokens()];
/* 549 */     for (int i = 0; st.hasMoreTokens(); i++) {
/* 550 */       cmdarray[i] = st.nextToken();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 559 */     ProcessBuilder pb = new ProcessBuilder(cmdarray);
/* 560 */     pb.directory(this._current);
/* 561 */     pb.redirectErrorStream(this._mergeStderr);
/*     */     try {
/* 563 */       return pb.start();
/*     */     }
/* 565 */     catch (IOException e) {
/*     */ 
/*     */ 
/*     */       
/* 569 */       throw new MCException(e, Core_Msg_FW_A.FCBEC0032, new Object[] { this._command });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void resetStdBuffer() {
/* 650 */     if (this._wait) {
/* 651 */       this._stdout = this._keepStdout ? new StringBuilder(100) : null;
/* 652 */       this._stderr = this._mergeStderr ? 
/* 653 */         null : (
/* 654 */         this._keepStderr ? new StringBuilder(100) : null);
/*     */     } else {
/*     */       
/* 657 */       this._stdout = null;
/* 658 */       this._stderr = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class StdThread
/*     */   {
/*     */     private final Thread outth;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final Thread errth;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Process process;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 696 */     private Throwable cause = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     StdThread(Process p) {
/* 707 */       this.process = p;
/* 708 */       this.outth = new Thread(new MCExec.StdReader(this.process.getInputStream(), MCExec.this._stdout, this));
/* 709 */       this.errth = new Thread(new MCExec.StdReader(this.process.getErrorStream(), MCExec.this._stderr, this));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void start() {
/* 719 */       this.outth.start();
/* 720 */       this.errth.start();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void join() throws InterruptedException {
/* 733 */       this.outth.join();
/* 734 */       this.errth.join();
/* 735 */       if (this.process == null)
/*     */       {
/* 737 */         throw new MCException(this.cause, Core_Msg_FW_A.FCBEC0057, new Object[0]);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void destroyProcess(Throwable ex) {
/* 750 */       if (this.process != null) {
/* 751 */         this.process.destroy();
/* 752 */         this.process = null;
/* 753 */         this.cause = ex;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class StdReader
/*     */     implements Runnable
/*     */   {
/*     */     private final InputStream _is;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final StringBuilder _buf;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final MCExec.StdThread _parent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     StdReader(InputStream is, StringBuilder buf, MCExec.StdThread parent) {
/* 798 */       this._parent = parent;
/* 799 */       this._is = is;
/*     */       
/* 801 */       this._buf = buf;
/*     */     }
/*     */ 
/*     */     
/*     */     public void run() {
/* 806 */       String nl = System.getProperty("line.separator", "\n");
/*     */ 
/*     */ 
/*     */       
/* 810 */       String encode = MCExec.this._stdEncode;
/* 811 */       if (encode != null && !Charset.isSupported(encode))
/*     */       {
/* 813 */         encode = null;
/*     */       }
/*     */       
/* 816 */       BufferedReader errBr = null;
/*     */       try {
/* 818 */         errBr = new BufferedReader(
/*     */ 
/*     */             
/* 821 */             (encode == null) ? new InputStreamReader(this._is) : 
/* 822 */             new InputStreamReader(this._is, encode));
/*     */       }
/* 824 */       catch (IOException ex) {
/*     */         
/* 826 */         MCLog.write(ex);
/*     */         
/*     */         return;
/*     */       } 
/* 830 */       String errLine = null;
/*     */       
/*     */       try {
/* 833 */         if (this._buf != null)
/* 834 */         { while ((errLine = errBr.readLine()) != null) {
/* 835 */             this._buf.append(errLine);
/* 836 */             this._buf.append(nl);
/*     */           }  }
/*     */         else { do {
/*     */           
/* 840 */           } while (errBr.readLine() != null); }
/*     */ 
/*     */       
/*     */       }
/* 844 */       catch (Throwable ex) {
/*     */         
/* 846 */         this._parent.destroyProcess(ex);
/*     */       } finally {
/*     */         
/*     */         try {
/* 850 */           errBr.close();
/*     */         }
/* 852 */         catch (IOException iOException) {}
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int executeRemote() {
/* 876 */     if (this.stub == null) {
/* 877 */       this.stub = MCRemoteExecUtil.getStub();
/*     */     }
/* 879 */     MCRemoteExecRequest req = new MCRemoteExecRequest();
/* 880 */     req.command = this._command;
/* 881 */     req.wait = this._wait;
/* 882 */     req.keepStdout = this._keepStdout;
/* 883 */     req.keepStderr = this._keepStderr;
/*     */     
/* 885 */     req.mergeStderr = this._mergeStderr;
/*     */     
/* 887 */     req.stdEncode = this._stdEncode;
/* 888 */     req.user = MCSys.user.ID();
/* 889 */     req.srvReqNo = MCSys.request.serverRequestNo();
/*     */ 
/*     */     
/* 892 */     MCRemoteExecResponse res = null;
/*     */     try {
/* 894 */       res = this.stub.execute(req);
/*     */     }
/* 896 */     catch (RemoteException ex) {
/* 897 */       throw MCRemoteExecUtil.analyzeRemoteException(ex);
/*     */     } 
/*     */     
/* 900 */     resetStdBuffer();
/* 901 */     if (this._stdout != null) {
/* 902 */       this._stdout.append(res.getStdout());
/*     */     }
/* 904 */     if (this._stderr != null) {
/* 905 */       this._stderr.append(res.getStderr());
/*     */     }
/*     */ 
/*     */     
/* 909 */     return res.getExitcode();
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\sys\MCExec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */