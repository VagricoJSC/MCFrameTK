/*     */ package mcframe.commonCore.sys;
/*     */ 
/*     */ import java.rmi.NotBoundException;
/*     */ import java.rmi.RemoteException;
/*     */ import java.rmi.registry.LocateRegistry;
/*     */ import java.rmi.registry.Registry;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.resource.MCConfig;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MCRemoteExecUtil
/*     */ {
/*  25 */   private static final String _host = MCConfig.common.getString(
/*  26 */       "exec.execsrv.host", "localhost");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  33 */   private static final String _port = MCConfig.common.getString(
/*  34 */       "exec.execsrv.port", "11099");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String getHost() {
/*  45 */     return _host;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String getPort() {
/*  56 */     return _port;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String getStubBindName() {
/*  67 */     return "mcframe.commonCore.sys.MCRemoteExec";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static MCRemoteExec getStub() {
/*  82 */     Registry registry = null;
/*     */     try {
/*  84 */       int port = Integer.parseInt(_port);
/*  85 */       registry = LocateRegistry.getRegistry(_host, port);
/*  86 */     } catch (NumberFormatException e) {
/*     */       
/*  88 */       throw new MCException(e, Core_Msg_FW_A.FCBEC0033, new Object[] { _host, _port });
/*  89 */     } catch (RemoteException e) {
/*     */       
/*  91 */       throw new MCException(analyzeRemoteException(e), 
/*  92 */           Core_Msg_FW_A.FCBEC0033, new Object[] { _host, _port });
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/*  97 */       return (MCRemoteExec)registry.lookup(getStubBindName());
/*  98 */     } catch (NotBoundException e) {
/*     */       
/* 100 */       throw new MCException(e, Core_Msg_FW_A.FCBEC0034, new Object[] { getStubBindName() });
/* 101 */     } catch (RemoteException e) {
/*     */       
/* 103 */       throw new MCException(analyzeRemoteException(e), 
/* 104 */           Core_Msg_FW_A.FCBEC0035, new Object[] { _host, _port });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static MCException analyzeRemoteException(RemoteException ex) {
/*     */     MCException mCException;
/* 117 */     Throwable t = ex.getCause();
/* 118 */     if (t instanceof RemoteException) {
/* 119 */       mCException = analyzeRemoteException((RemoteException)t);
/*     */     }
/* 121 */     return (mCException instanceof MCException) ? 
/* 122 */       mCException : new MCException((Throwable)mCException);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\sys\MCRemoteExecUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */