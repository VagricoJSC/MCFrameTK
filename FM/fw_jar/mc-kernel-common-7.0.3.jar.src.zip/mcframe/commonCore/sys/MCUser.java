package mcframe.commonCore.sys;

import java.util.Locale;
import java.util.TimeZone;
import mcframe.commonCore.lang.MCBinary;

public interface MCUser {
  String ID();
  
  String name();
  
  String loginSequence();
  
  Locale locale();
  
  TimeZone timezone();
  
  String clientID();
  
  String coCD();
  
  String coNm();
  
  String extattr1();
  
  String extattr2();
  
  String extattr3();
  
  MCBinary image();
  
  String[] licmods();
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\sys\MCUser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */