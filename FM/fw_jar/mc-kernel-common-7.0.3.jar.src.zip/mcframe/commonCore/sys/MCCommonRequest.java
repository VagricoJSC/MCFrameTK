/*     */ package mcframe.commonCore.sys;
/*     */ 
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.lang.MCTimestamp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MCCommonRequest
/*     */   implements MCRequest
/*     */ {
/*  20 */   private MCRequest _reqimpl = new NoInitRequest(null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean _init = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void init(MCRequest req) {
/*  48 */     if (req != null && 
/*  49 */       !this._init) {
/*  50 */       this._reqimpl = req;
/*  51 */       this._init = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String clientRequestNo() {
/*  58 */     return this._reqimpl.clientRequestNo();
/*     */   }
/*     */ 
/*     */   
/*     */   public String clientId() {
/*  63 */     return this._reqimpl.clientId();
/*     */   }
/*     */ 
/*     */   
/*     */   public String serverRequestNo() {
/*  68 */     return this._reqimpl.serverRequestNo();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String serverThreadNo() {
/*  74 */     return this._reqimpl.serverThreadNo();
/*     */   }
/*     */ 
/*     */   
/*     */   public String cooperateCd() {
/*  79 */     return this._reqimpl.cooperateCd();
/*     */   }
/*     */ 
/*     */   
/*     */   public String serverId() {
/*  84 */     return this._reqimpl.serverId();
/*     */   }
/*     */ 
/*     */   
/*     */   public String moduleId() {
/*  89 */     return this._reqimpl.moduleId();
/*     */   }
/*     */ 
/*     */   
/*     */   public String logicId() {
/*  94 */     return this._reqimpl.logicId();
/*     */   }
/*     */ 
/*     */   
/*     */   public String operationId() {
/*  99 */     return this._reqimpl.operationId();
/*     */   }
/*     */ 
/*     */   
/*     */   public String version() {
/* 104 */     return this._reqimpl.version();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCTimestamp createTime() {
/* 109 */     return this._reqimpl.createTime();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCNumber limitDLSize() {
/* 114 */     return this._reqimpl.limitDLSize();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class NoInitRequest
/*     */     implements MCRequest
/*     */   {
/*     */     private NoInitRequest() {}
/*     */ 
/*     */ 
/*     */     
/*     */     public String clientRequestNo() {
/* 127 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public String clientId() {
/* 132 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public String serverRequestNo() {
/* 137 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public String serverThreadNo() {
/* 143 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public String cooperateCd() {
/* 148 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public String serverId() {
/* 153 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public String moduleId() {
/* 158 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public String logicId() {
/* 163 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public String operationId() {
/* 168 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public String version() {
/* 173 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public MCTimestamp createTime() {
/* 178 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public MCNumber limitDLSize() {
/* 183 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\sys\MCCommonRequest.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */