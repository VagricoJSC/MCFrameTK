/*     */ package mcframe.commonCore.sys;
/*     */ 
/*     */ import java.io.File;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCCatalog
/*     */   extends MCCatalogFile
/*     */ {
/*  35 */   private String _name = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  41 */   private String _version = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  47 */   private String _build = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   private String _vendor = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   private String _systemid = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   private MCCatalogFile.Entry[] _catalog = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   private MCCatalogFile.Entry[] _lazy = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCCatalog(File file) {
/*  89 */     super((file != null && file.isDirectory()) ? new File(file, "vercatalog.txt") : file);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCCatalog() {
/* 102 */     this(new File(MCSys.env.MCF_HOME()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initValue(MCINIFile catalog) {
/* 108 */     this._name = catalog.get("VERSION", "NAME");
/* 109 */     this._version = catalog.get("VERSION", "VERSION");
/* 110 */     this._build = catalog.get("VERSION", "BUILD");
/* 111 */     this._vendor = catalog.get("VERSION", "VENDOR");
/* 112 */     this._systemid = catalog.get("VERSION", "SYSTEMID");
/*     */ 
/*     */     
/* 115 */     this._catalog = createEntry(catalog, "CATALOG", false);
/*     */ 
/*     */     
/* 118 */     this._lazy = createEntry(catalog, "LAZY", true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String name() {
/* 130 */     init();
/* 131 */     return this._name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String version() {
/* 142 */     init();
/* 143 */     return this._version;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String build() {
/* 154 */     init();
/* 155 */     return this._build;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String vendor() {
/* 166 */     init();
/* 167 */     return this._vendor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String systemid() {
/* 178 */     init();
/* 179 */     return this._systemid;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCCatalogFile.Entry[] entries() {
/* 207 */     init();
/* 208 */     if (this._catalog == null) {
/* 209 */       return null;
/*     */     }
/* 211 */     int size = this._catalog.length;
/* 212 */     MCCatalogFile.Entry[] copy = new MCCatalogFile.Entry[size];
/* 213 */     System.arraycopy(this._catalog, 0, copy, 0, size);
/* 214 */     return copy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCCatalogFile.Entry[] lazyEntries() {
/* 230 */     init();
/* 231 */     if (this._lazy == null) {
/* 232 */       return null;
/*     */     }
/* 234 */     int size = this._lazy.length;
/* 235 */     MCCatalogFile.Entry[] copy = new MCCatalogFile.Entry[size];
/* 236 */     System.arraycopy(this._lazy, 0, copy, 0, size);
/* 237 */     return copy;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\sys\MCCatalog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */