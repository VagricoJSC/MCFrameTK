/*     */ package mcframe.commonCore.sys;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.net.CookieHandler;
/*     */ import java.net.CookieManager;
/*     */ import java.net.CookiePolicy;
/*     */ import mcframe.commonCore.lang.MCCalendarDate;
/*     */ import mcframe.commonCore.lang.MCTimestamp;
/*     */ import mcframe.commonCore.login.MCAuth;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCError;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.notice.MCMessage;
/*     */ import mcframe.commonCore.notice.MCMessageList;
/*     */ import mcframe.commonCore.resource.MCConfig;
/*     */ import mcframe.commonCore.resource.MCLocaleConst;
/*     */ import mcframe.commonCore.resource.ctrl.MCReadableResource;
/*     */ import mcframe.commonCore.resource.ctrl.MCResource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCSys
/*     */ {
/*  48 */   public static final MCEnv env = new MCEnv();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   public static final MCUser user = new MCCommonUser();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   public static final MCRequest request = new MCCommonRequest();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   public static final MCCatalog catalog = new MCCatalog();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   public static final MCProduct product = new MCProduct();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  92 */   protected static final String ERR_LINESEP = env.getVMEnv("line.separator", "\n");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   private static final String ERR_HEADER = "MCFrame Initialize ERROR." + ERR_LINESEP + ERR_LINESEP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean _init = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean _loadlib = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 121 */   private static final Object _lock_loadlib = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void init(MCUser tieruser, MCRequest tierreq) {
/* 144 */     if (!_init) {
/*     */       
/*     */       try {
/*     */         
/* 148 */         loadNativeLibrary();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 155 */         MCLocaleConst.loadInit();
/*     */ 
/*     */         
/* 158 */         MCAuth.isDefaultAuthMode();
/*     */ 
/*     */         
/* 161 */         CookieManager cm = new CookieManager();
/* 162 */         cm.setCookiePolicy(getCookiePolicy());
/* 163 */         CookieHandler.setDefault(cm);
/*     */ 
/*     */         
/* 166 */         _init = true;
/*     */       }
/* 168 */       catch (Throwable t) {
/*     */         
/* 170 */         throw (t instanceof MCError) ? (MCError)t : initError(t);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 176 */       ((MCCommonUser)user).init(tieruser);
/* 177 */       ((MCCommonRequest)request).init(tierreq);
/* 178 */     } catch (Throwable t) {
/*     */       
/* 180 */       throw (t instanceof MCError) ? (MCError)t : initError(t);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void loadNativeLibrary() {
/* 198 */     String name = null;
/*     */     try {
/* 200 */       synchronized (_lock_loadlib) {
/* 201 */         if (!_loadlib) {
/* 202 */           String[] libs = {
/* 203 */               "mc_rt"
/*     */             };
/* 205 */           int cnt = libs.length;
/* 206 */           for (int i = 0; i < cnt; i++) {
/* 207 */             name = libs[i];
/* 208 */             System.loadLibrary(name);
/*     */           } 
/* 210 */           _loadlib = true;
/*     */         } 
/*     */       } 
/* 213 */     } catch (Throwable ex) {
/*     */       
/* 215 */       throw initError(ex, "Native Library Load Error!! [" + name + "]", new String[0]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static CookiePolicy getCookiePolicy() {
/* 228 */     String policy = MCConfig.common.getString("http.cookie.policy");
/* 229 */     if (policy == null) {
/* 230 */       return null;
/*     */     }
/*     */     String str1;
/* 233 */     switch ((str1 = policy).hashCode()) { case -1483924465: if (!str1.equals("ACCEPT_NONE")) {
/*     */           break;
/*     */         }
/*     */         
/* 237 */         return CookiePolicy.ACCEPT_NONE;case -740617782: if (!str1.equals("ACCEPT_ALL"))
/*     */           break;  return CookiePolicy.ACCEPT_ALL;case -386852806: if (!str1.equals("ACCEPT_ORIGINAL_SERVER"))
/* 239 */           break;  return CookiePolicy.ACCEPT_ORIGINAL_SERVER; }
/*     */     
/* 241 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static boolean validateMCF_HOME() {
/* 253 */     File home = new File(env.MCF_HOME());
/* 254 */     return home.isDirectory();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static MCError initError(String msg, String... binds) {
/* 267 */     return new MCError(String.valueOf(ERR_HEADER) + msg, binds);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static MCError initError(Throwable ex) {
/* 279 */     return new MCError(ex, String.valueOf(ERR_HEADER) + ex.getMessage(), new String[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static MCError initError(Throwable ex, String msg, String... binds) {
/* 295 */     return new MCError(ex, String.valueOf(ERR_HEADER) + msg, binds);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final void cleanupDir(MCReadableResource resource, String... dirs) {
/* 322 */     if (dirs == null) {
/*     */       return;
/*     */     }
/*     */     
/* 326 */     if (resource == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 331 */     MCTimestamp ts = (MCTimestamp)MCResource.getBeginPeriod(
/* 332 */         (MCCalendarDate)MCTimestamp.now(), resource, "cleanup.period");
/* 333 */     if (ts == null)
/*     */       return; 
/*     */     byte b;
/*     */     int i;
/*     */     String[] arrayOfString;
/* 338 */     for (i = (arrayOfString = dirs).length, b = 0; b < i; ) { String sdir = arrayOfString[b];
/* 339 */       if (sdir != null && sdir.length() > 0) {
/*     */ 
/*     */ 
/*     */         
/* 343 */         File fdir = new File(sdir);
/* 344 */         File[] ffiles = fdir.listFiles();
/* 345 */         cleanupFile((MCCalendarDate<?>)ts, ffiles);
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void cleanupFile(MCCalendarDate<?> date, File... files) {
/* 365 */     if (date == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 370 */     if (files == null || files.length == 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 375 */     long limit = date.toDate().getTime(); byte b; int i; File[] arrayOfFile;
/* 376 */     for (i = (arrayOfFile = files).length, b = 0; b < i; ) { File file = arrayOfFile[b];
/* 377 */       if (file.isFile()) {
/* 378 */         long mod = file.lastModified();
/* 379 */         if (mod < limit) {
/* 380 */           file.delete();
/*     */         
/*     */         }
/*     */       }
/* 384 */       else if (file.isDirectory()) {
/* 385 */         File[] subfiles = file.listFiles();
/* 386 */         cleanupFile(date, subfiles);
/* 387 */         subfiles = file.listFiles();
/* 388 */         if (subfiles.length == 0) {
/* 389 */           file.delete();
/*     */         }
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final void loggingVersion() {
/* 408 */     if (catalog.completed()) {
/* 409 */       MCLog.write(Core_Msg_FW_A.FCBEC0052, new Object[] {
/* 410 */             catalog.systemid(), 
/* 411 */             catalog.name(), 
/* 412 */             catalog.version(), 
/* 413 */             catalog.build(), 
/* 414 */             catalog.vendor()
/*     */           });
/*     */     }
/*     */ 
/*     */     
/* 419 */     MCProduct.Product[] products = MCSys.product.producs(); byte b; int i; MCProduct.Product[] arrayOfProduct1;
/* 420 */     for (i = (arrayOfProduct1 = products).length, b = 0; b < i; ) { MCProduct.Product product = arrayOfProduct1[b];
/* 421 */       MCLog.follow(Core_Msg_FW_A.FCBEC0053, new Object[] {
/* 422 */             product.module(), 
/* 423 */             product.name(), 
/* 424 */             product.version(), 
/* 425 */             product.build(), 
/* 426 */             product.vendor()
/*     */           });
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final MCMessageList getVersionMessages(MCCatalog mcc, MCProduct mcp) {
/* 447 */     MCMessageList list = new MCMessageList();
/*     */     
/* 449 */     if (mcc != null && mcc.completed()) {
/* 450 */       list.add(new MCMessage(Core_Msg_FW_A.FCBEC0052, new Object[] {
/* 451 */               mcc.systemid(), 
/* 452 */               mcc.name(), 
/* 453 */               mcc.version(), 
/* 454 */               mcc.build(), 
/* 455 */               mcc.vendor()
/*     */             }));
/*     */     }
/*     */ 
/*     */     
/* 460 */     if (mcp != null) {
/* 461 */       MCProduct.Product[] products = mcp.producs(); byte b; int i; MCProduct.Product[] arrayOfProduct1;
/* 462 */       for (i = (arrayOfProduct1 = products).length, b = 0; b < i; ) { MCProduct.Product product = arrayOfProduct1[b];
/* 463 */         list.add(new MCMessage(Core_Msg_FW_A.FCBEC0053, new Object[] {
/* 464 */                 product.module(), 
/* 465 */                 product.name(), 
/* 466 */                 product.version(), 
/* 467 */                 product.build(), 
/* 468 */                 product.vendor() }));
/*     */         b++; }
/*     */     
/*     */     } 
/* 472 */     return list;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\sys\MCSys.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */