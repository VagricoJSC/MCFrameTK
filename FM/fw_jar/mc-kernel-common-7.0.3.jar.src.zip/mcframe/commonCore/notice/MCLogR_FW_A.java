/*      */ package mcframe.commonCore.notice;
/*      */ 
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import mcframe.commonCore.container.MCConstRow;
/*      */ import mcframe.commonCore.container.MCExtMap;
/*      */ import mcframe.commonCore.container.MCRow;
/*      */ import mcframe.commonCore.lang.MCNumber;
/*      */ import mcframe.commonCore.lang.MCTimestamp;
/*      */ import mcframe.commonCore.meta.MCMeta;
/*      */ import mcframe.commonCore.meta.M_META;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ abstract class MCLogR_FW_A
/*      */   extends MCConstRow
/*      */ {
/*      */   public static final String $total_no = "total_no";
/*      */   public static final String $file_path = "file_path";
/*      */   public static final String $log_no = "log_no";
/*      */   public static final String $log_ts = "log_ts";
/*      */   public static final String $elapsed_time = "elapsed_time";
/*      */   public static final String $exec_time = "exec_time";
/*      */   public static final String $req_no = "req_no";
/*      */   public static final String $thread_no = "thread_no";
/*      */   public static final String $co_cd = "co_cd";
/*      */   public static final String $operation_id = "operation_id";
/*      */   public static final String $msg_lvl = "msg_lvl";
/*      */   public static final String $msg_id = "msg_id";
/*      */   public static final String $class_nm = "class_nm";
/*      */   public static final String $method_nm = "method_nm";
/*      */   public static final String $method_line = "method_line";
/*      */   public static final String $msg_txt = "msg_txt";
/*      */   public static final String $button_id = "button_id";
/*      */   public static final String $log_layer = "log_layer";
/*      */   public static final String $analysis = "analysis";
/*      */   public static final String $sql_id = "sql_id";
/*  132 */   public static final MCMeta total_no_META = createCommonMeta("total_no", M_META.INT);
/*  133 */   public static final MCMeta file_path_META = createCommonMeta("file_path", M_META.PATH);
/*  134 */   public static final MCMeta log_no_META = createCommonMeta("log_no", M_META.INT);
/*  135 */   public static final MCMeta log_ts_META = createCommonMeta("log_ts", M_META.TS);
/*  136 */   public static final MCMeta elapsed_time_META = createCommonMeta("elapsed_time", M_META.NUM);
/*  137 */   public static final MCMeta exec_time_META = createCommonMeta("exec_time", M_META.NUM);
/*  138 */   public static final MCMeta req_no_META = createCommonMeta("req_no", M_META.SRV_REQ_NO);
/*  139 */   public static final MCMeta thread_no_META = createCommonMeta("thread_no", M_META.THREAD_NO);
/*  140 */   public static final MCMeta co_cd_META = createCommonMeta("co_cd", M_META.CO_CD);
/*  141 */   public static final MCMeta operation_id_META = createCommonMeta("operation_id", M_META.OPERATION_ID);
/*  142 */   public static final MCMeta msg_lvl_META = createCommonMeta("msg_lvl", M_META.MSG_LVL);
/*  143 */   public static final MCMeta msg_id_META = createCommonMeta("msg_id", M_META.MSG_ID);
/*  144 */   public static final MCMeta class_nm_META = createCommonMeta("class_nm", M_META.CLASS_NM);
/*  145 */   public static final MCMeta method_nm_META = createCommonMeta("method_nm", M_META.METHOD_NM);
/*  146 */   public static final MCMeta method_line_META = createCommonMeta("method_line", M_META.INT);
/*  147 */   public static final MCMeta msg_txt_META = createCommonMeta("msg_txt", M_META.MSG);
/*  148 */   public static final MCMeta button_id_META = createCommonMeta("button_id", M_META.BUTTON_NAME);
/*  149 */   public static final MCMeta log_layer_META = createCommonMeta("log_layer", M_META.INT);
/*  150 */   public static final MCMeta analysis_META = createCommonMeta("analysis", M_META.INT);
/*  151 */   public static final MCMeta sql_id_META = createCommonMeta("sql_id", M_META.RES_VAL);
/*      */   
/*  153 */   protected static final MCRow.ConstMetaList<MCLogR> constMetas = new MCRow.ConstMetaList(
/*  154 */       MCConstRow.constMetas, 
/*  155 */       new MCMeta[] { 
/*  156 */         total_no_META, 
/*  157 */         file_path_META, 
/*  158 */         log_no_META, 
/*  159 */         log_ts_META, 
/*  160 */         elapsed_time_META, 
/*  161 */         exec_time_META, 
/*  162 */         req_no_META, 
/*  163 */         thread_no_META, 
/*  164 */         co_cd_META, 
/*  165 */         operation_id_META, 
/*  166 */         msg_lvl_META, 
/*  167 */         msg_id_META, 
/*  168 */         class_nm_META, 
/*  169 */         method_nm_META, 
/*  170 */         method_line_META, 
/*  171 */         msg_txt_META, 
/*  172 */         button_id_META, 
/*  173 */         log_layer_META, 
/*  174 */         analysis_META, 
/*  175 */         sql_id_META
/*      */       },
/*  177 */       new String[][] { {}, {} });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  189 */   protected static final MCExtMap EXTMAP = new MCExtMap(
/*  190 */       null, new MCExtMap.Entry[0]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] colnames() {
/*  202 */     return constMetas.toNameArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static MCMeta[] colmetas() {
/*  214 */     return constMetas.toMetaArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  220 */   private static final int offset = constMetas.offset();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map<String, String> getExtMap(String aGroup) {
/*  226 */     if (aGroup == null) return null; 
/*  227 */     return (Map<String, String>)EXTMAP.get(aGroup);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> getKeys(String aGroup) {
/*  234 */     if (aGroup == null) return null; 
/*  235 */     return EXTMAP.getKeyList(aGroup);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<String> getExtGroups() {
/*  242 */     Set<String> ret = EXTMAP.keySet();
/*  243 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MCLogR_FW_A(MCRow.ConstMetaList<? extends MCLogR> metas) {
/*  250 */     super(metas);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCLogR clone() {
/*  257 */     return (MCLogR)super.clone();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCLogR createInstance() {
/*  264 */     return (MCLogR)super.createInstance();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCLogR getValues(String... names) {
/*  271 */     return (MCLogR)super.getValues(names);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void fireValueChanged(String column, Comparable<?> newvalue, Comparable<?> oldvalue) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber total_no() {
/*  288 */     return getConstNumber(offset + 0, "total_no");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void total_no(MCNumber value) {
/*  297 */     setConstNumber(offset + 0, "total_no", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void total_no(int value) {
/*  306 */     setConstNumber(offset + 0, "total_no", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void total_no(long value) {
/*  315 */     setConstNumber(offset + 0, "total_no", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void total_no(float value) {
/*  324 */     setConstNumber(offset + 0, "total_no", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void total_no(double value) {
/*  333 */     setConstNumber(offset + 0, "total_no", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String file_path() {
/*  343 */     return getConstString(offset + 1, "file_path");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void file_path(String value) {
/*  352 */     setConstString(offset + 1, "file_path", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber log_no() {
/*  361 */     return getConstNumber(offset + 2, "log_no");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void log_no(MCNumber value) {
/*  369 */     setConstNumber(offset + 2, "log_no", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void log_no(int value) {
/*  377 */     setConstNumber(offset + 2, "log_no", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void log_no(long value) {
/*  385 */     setConstNumber(offset + 2, "log_no", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void log_no(float value) {
/*  393 */     setConstNumber(offset + 2, "log_no", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void log_no(double value) {
/*  401 */     setConstNumber(offset + 2, "log_no", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCTimestamp log_ts() {
/*  410 */     return getConstTimestamp(offset + 3, "log_ts");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void log_ts(MCTimestamp value) {
/*  418 */     setConstTimestamp(offset + 3, "log_ts", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber elapsed_time() {
/*  427 */     return getConstNumber(offset + 4, "elapsed_time");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void elapsed_time(MCNumber value) {
/*  435 */     setConstNumber(offset + 4, "elapsed_time", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void elapsed_time(int value) {
/*  443 */     setConstNumber(offset + 4, "elapsed_time", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void elapsed_time(long value) {
/*  451 */     setConstNumber(offset + 4, "elapsed_time", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void elapsed_time(float value) {
/*  459 */     setConstNumber(offset + 4, "elapsed_time", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void elapsed_time(double value) {
/*  467 */     setConstNumber(offset + 4, "elapsed_time", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber exec_time() {
/*  476 */     return getConstNumber(offset + 5, "exec_time");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void exec_time(MCNumber value) {
/*  484 */     setConstNumber(offset + 5, "exec_time", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void exec_time(int value) {
/*  492 */     setConstNumber(offset + 5, "exec_time", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void exec_time(long value) {
/*  500 */     setConstNumber(offset + 5, "exec_time", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void exec_time(float value) {
/*  508 */     setConstNumber(offset + 5, "exec_time", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void exec_time(double value) {
/*  516 */     setConstNumber(offset + 5, "exec_time", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String req_no() {
/*  525 */     return getConstString(offset + 6, "req_no");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void req_no(String value) {
/*  533 */     setConstString(offset + 6, "req_no", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String thread_no() {
/*  542 */     return getConstString(offset + 7, "thread_no");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void thread_no(String value) {
/*  550 */     setConstString(offset + 7, "thread_no", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String co_cd() {
/*  559 */     return getConstString(offset + 8, "co_cd");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void co_cd(String value) {
/*  567 */     setConstString(offset + 8, "co_cd", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String operation_id() {
/*  576 */     return getConstString(offset + 9, "operation_id");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void operation_id(String value) {
/*  584 */     setConstString(offset + 9, "operation_id", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String msg_lvl() {
/*  593 */     return getConstString(offset + 10, "msg_lvl");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void msg_lvl(String value) {
/*  601 */     setConstString(offset + 10, "msg_lvl", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String msg_id() {
/*  610 */     return getConstString(offset + 11, "msg_id");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void msg_id(String value) {
/*  618 */     setConstString(offset + 11, "msg_id", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String class_nm() {
/*  627 */     return getConstString(offset + 12, "class_nm");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void class_nm(String value) {
/*  635 */     setConstString(offset + 12, "class_nm", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String method_nm() {
/*  644 */     return getConstString(offset + 13, "method_nm");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void method_nm(String value) {
/*  652 */     setConstString(offset + 13, "method_nm", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber method_line() {
/*  661 */     return getConstNumber(offset + 14, "method_line");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void method_line(MCNumber value) {
/*  669 */     setConstNumber(offset + 14, "method_line", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void method_line(int value) {
/*  677 */     setConstNumber(offset + 14, "method_line", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void method_line(long value) {
/*  685 */     setConstNumber(offset + 14, "method_line", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void method_line(float value) {
/*  693 */     setConstNumber(offset + 14, "method_line", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void method_line(double value) {
/*  701 */     setConstNumber(offset + 14, "method_line", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String msg_txt() {
/*  710 */     return getConstString(offset + 15, "msg_txt");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void msg_txt(String value) {
/*  718 */     setConstString(offset + 15, "msg_txt", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String button_id() {
/*  727 */     return getConstString(offset + 16, "button_id");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void button_id(String value) {
/*  735 */     setConstString(offset + 16, "button_id", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber log_layer() {
/*  744 */     return getConstNumber(offset + 17, "log_layer");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void log_layer(MCNumber value) {
/*  752 */     setConstNumber(offset + 17, "log_layer", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void log_layer(int value) {
/*  760 */     setConstNumber(offset + 17, "log_layer", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void log_layer(long value) {
/*  768 */     setConstNumber(offset + 17, "log_layer", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void log_layer(float value) {
/*  776 */     setConstNumber(offset + 17, "log_layer", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void log_layer(double value) {
/*  784 */     setConstNumber(offset + 17, "log_layer", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber analysis() {
/*  793 */     return getConstNumber(offset + 18, "analysis");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void analysis(MCNumber value) {
/*  801 */     setConstNumber(offset + 18, "analysis", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void analysis(int value) {
/*  809 */     setConstNumber(offset + 18, "analysis", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void analysis(long value) {
/*  817 */     setConstNumber(offset + 18, "analysis", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void analysis(float value) {
/*  825 */     setConstNumber(offset + 18, "analysis", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void analysis(double value) {
/*  833 */     setConstNumber(offset + 18, "analysis", value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String sql_id() {
/*  842 */     return getConstString(offset + 19, "sql_id");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void sql_id(String value) {
/*  850 */     setConstString(offset + 19, "sql_id", value);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getString(String name) {
/*  855 */     if ("file_path".equalsIgnoreCase(name)) {
/*  856 */       return file_path();
/*      */     }
/*  858 */     if ("req_no".equalsIgnoreCase(name)) {
/*  859 */       return req_no();
/*      */     }
/*  861 */     if ("thread_no".equalsIgnoreCase(name)) {
/*  862 */       return thread_no();
/*      */     }
/*  864 */     if ("co_cd".equalsIgnoreCase(name)) {
/*  865 */       return co_cd();
/*      */     }
/*  867 */     if ("operation_id".equalsIgnoreCase(name)) {
/*  868 */       return operation_id();
/*      */     }
/*  870 */     if ("msg_lvl".equalsIgnoreCase(name)) {
/*  871 */       return msg_lvl();
/*      */     }
/*  873 */     if ("msg_id".equalsIgnoreCase(name)) {
/*  874 */       return msg_id();
/*      */     }
/*  876 */     if ("class_nm".equalsIgnoreCase(name)) {
/*  877 */       return class_nm();
/*      */     }
/*  879 */     if ("method_nm".equalsIgnoreCase(name)) {
/*  880 */       return method_nm();
/*      */     }
/*  882 */     if ("msg_txt".equalsIgnoreCase(name)) {
/*  883 */       return msg_txt();
/*      */     }
/*  885 */     if ("button_id".equalsIgnoreCase(name)) {
/*  886 */       return button_id();
/*      */     }
/*  888 */     if ("sql_id".equalsIgnoreCase(name)) {
/*  889 */       return sql_id();
/*      */     }
/*  891 */     return super.getString(name);
/*      */   }
/*      */   public MCNumber getNumber(String name) {
/*  894 */     if ("total_no".equalsIgnoreCase(name)) {
/*  895 */       return total_no();
/*      */     }
/*  897 */     if ("log_no".equalsIgnoreCase(name)) {
/*  898 */       return log_no();
/*      */     }
/*  900 */     if ("elapsed_time".equalsIgnoreCase(name)) {
/*  901 */       return elapsed_time();
/*      */     }
/*  903 */     if ("exec_time".equalsIgnoreCase(name)) {
/*  904 */       return exec_time();
/*      */     }
/*  906 */     if ("method_line".equalsIgnoreCase(name)) {
/*  907 */       return method_line();
/*      */     }
/*  909 */     if ("log_layer".equalsIgnoreCase(name)) {
/*  910 */       return log_layer();
/*      */     }
/*  912 */     if ("analysis".equalsIgnoreCase(name)) {
/*  913 */       return analysis();
/*      */     }
/*  915 */     return super.getNumber(name);
/*      */   }
/*      */   public MCTimestamp getTimestamp(String name) {
/*  918 */     if ("log_ts".equalsIgnoreCase(name)) {
/*  919 */       return log_ts();
/*      */     }
/*  921 */     return super.getTimestamp(name);
/*      */   }
/*      */   
/*      */   public String getStringNE(String name) {
/*  925 */     if ("file_path".equalsIgnoreCase(name)) {
/*  926 */       return file_path();
/*      */     }
/*  928 */     if ("req_no".equalsIgnoreCase(name)) {
/*  929 */       return req_no();
/*      */     }
/*  931 */     if ("thread_no".equalsIgnoreCase(name)) {
/*  932 */       return thread_no();
/*      */     }
/*  934 */     if ("co_cd".equalsIgnoreCase(name)) {
/*  935 */       return co_cd();
/*      */     }
/*  937 */     if ("operation_id".equalsIgnoreCase(name)) {
/*  938 */       return operation_id();
/*      */     }
/*  940 */     if ("msg_lvl".equalsIgnoreCase(name)) {
/*  941 */       return msg_lvl();
/*      */     }
/*  943 */     if ("msg_id".equalsIgnoreCase(name)) {
/*  944 */       return msg_id();
/*      */     }
/*  946 */     if ("class_nm".equalsIgnoreCase(name)) {
/*  947 */       return class_nm();
/*      */     }
/*  949 */     if ("method_nm".equalsIgnoreCase(name)) {
/*  950 */       return method_nm();
/*      */     }
/*  952 */     if ("msg_txt".equalsIgnoreCase(name)) {
/*  953 */       return msg_txt();
/*      */     }
/*  955 */     if ("button_id".equalsIgnoreCase(name)) {
/*  956 */       return button_id();
/*      */     }
/*  958 */     if ("sql_id".equalsIgnoreCase(name)) {
/*  959 */       return sql_id();
/*      */     }
/*  961 */     return super.getStringNE(name);
/*      */   }
/*      */   public MCNumber getNumberNE(String name) {
/*  964 */     if ("total_no".equalsIgnoreCase(name)) {
/*  965 */       return total_no();
/*      */     }
/*  967 */     if ("log_no".equalsIgnoreCase(name)) {
/*  968 */       return log_no();
/*      */     }
/*  970 */     if ("elapsed_time".equalsIgnoreCase(name)) {
/*  971 */       return elapsed_time();
/*      */     }
/*  973 */     if ("exec_time".equalsIgnoreCase(name)) {
/*  974 */       return exec_time();
/*      */     }
/*  976 */     if ("method_line".equalsIgnoreCase(name)) {
/*  977 */       return method_line();
/*      */     }
/*  979 */     if ("log_layer".equalsIgnoreCase(name)) {
/*  980 */       return log_layer();
/*      */     }
/*  982 */     if ("analysis".equalsIgnoreCase(name)) {
/*  983 */       return analysis();
/*      */     }
/*  985 */     return super.getNumberNE(name);
/*      */   }
/*      */   public MCTimestamp getTimestampNE(String name) {
/*  988 */     if ("log_ts".equalsIgnoreCase(name)) {
/*  989 */       return log_ts();
/*      */     }
/*  991 */     return super.getTimestampNE(name);
/*      */   }
/*      */   
/*      */   public void setString(String name, String value) {
/*  995 */     if ("file_path".equalsIgnoreCase(name)) {
/*  996 */       file_path(value);
/*      */       return;
/*      */     } 
/*  999 */     if ("req_no".equalsIgnoreCase(name)) {
/* 1000 */       req_no(value);
/*      */       return;
/*      */     } 
/* 1003 */     if ("thread_no".equalsIgnoreCase(name)) {
/* 1004 */       thread_no(value);
/*      */       return;
/*      */     } 
/* 1007 */     if ("co_cd".equalsIgnoreCase(name)) {
/* 1008 */       co_cd(value);
/*      */       return;
/*      */     } 
/* 1011 */     if ("operation_id".equalsIgnoreCase(name)) {
/* 1012 */       operation_id(value);
/*      */       return;
/*      */     } 
/* 1015 */     if ("msg_lvl".equalsIgnoreCase(name)) {
/* 1016 */       msg_lvl(value);
/*      */       return;
/*      */     } 
/* 1019 */     if ("msg_id".equalsIgnoreCase(name)) {
/* 1020 */       msg_id(value);
/*      */       return;
/*      */     } 
/* 1023 */     if ("class_nm".equalsIgnoreCase(name)) {
/* 1024 */       class_nm(value);
/*      */       return;
/*      */     } 
/* 1027 */     if ("method_nm".equalsIgnoreCase(name)) {
/* 1028 */       method_nm(value);
/*      */       return;
/*      */     } 
/* 1031 */     if ("msg_txt".equalsIgnoreCase(name)) {
/* 1032 */       msg_txt(value);
/*      */       return;
/*      */     } 
/* 1035 */     if ("button_id".equalsIgnoreCase(name)) {
/* 1036 */       button_id(value);
/*      */       return;
/*      */     } 
/* 1039 */     if ("sql_id".equalsIgnoreCase(name)) {
/* 1040 */       sql_id(value);
/*      */       return;
/*      */     } 
/* 1043 */     super.setString(name, value);
/*      */   }
/*      */   public void setNumber(String name, MCNumber value) {
/* 1046 */     if ("total_no".equalsIgnoreCase(name)) {
/* 1047 */       total_no(value);
/*      */       return;
/*      */     } 
/* 1050 */     if ("log_no".equalsIgnoreCase(name)) {
/* 1051 */       log_no(value);
/*      */       return;
/*      */     } 
/* 1054 */     if ("elapsed_time".equalsIgnoreCase(name)) {
/* 1055 */       elapsed_time(value);
/*      */       return;
/*      */     } 
/* 1058 */     if ("exec_time".equalsIgnoreCase(name)) {
/* 1059 */       exec_time(value);
/*      */       return;
/*      */     } 
/* 1062 */     if ("method_line".equalsIgnoreCase(name)) {
/* 1063 */       method_line(value);
/*      */       return;
/*      */     } 
/* 1066 */     if ("log_layer".equalsIgnoreCase(name)) {
/* 1067 */       log_layer(value);
/*      */       return;
/*      */     } 
/* 1070 */     if ("analysis".equalsIgnoreCase(name)) {
/* 1071 */       analysis(value);
/*      */       return;
/*      */     } 
/* 1074 */     super.setNumber(name, value);
/*      */   }
/*      */   public void setNumber(String name, int value) {
/* 1077 */     if ("total_no".equalsIgnoreCase(name)) {
/* 1078 */       total_no(value);
/*      */       return;
/*      */     } 
/* 1081 */     if ("log_no".equalsIgnoreCase(name)) {
/* 1082 */       log_no(value);
/*      */       return;
/*      */     } 
/* 1085 */     if ("elapsed_time".equalsIgnoreCase(name)) {
/* 1086 */       elapsed_time(value);
/*      */       return;
/*      */     } 
/* 1089 */     if ("exec_time".equalsIgnoreCase(name)) {
/* 1090 */       exec_time(value);
/*      */       return;
/*      */     } 
/* 1093 */     if ("method_line".equalsIgnoreCase(name)) {
/* 1094 */       method_line(value);
/*      */       return;
/*      */     } 
/* 1097 */     if ("log_layer".equalsIgnoreCase(name)) {
/* 1098 */       log_layer(value);
/*      */       return;
/*      */     } 
/* 1101 */     if ("analysis".equalsIgnoreCase(name)) {
/* 1102 */       analysis(value);
/*      */       return;
/*      */     } 
/* 1105 */     super.setNumber(name, value);
/*      */   }
/*      */   public void setNumber(String name, long value) {
/* 1108 */     if ("total_no".equalsIgnoreCase(name)) {
/* 1109 */       total_no(value);
/*      */       return;
/*      */     } 
/* 1112 */     if ("log_no".equalsIgnoreCase(name)) {
/* 1113 */       log_no(value);
/*      */       return;
/*      */     } 
/* 1116 */     if ("elapsed_time".equalsIgnoreCase(name)) {
/* 1117 */       elapsed_time(value);
/*      */       return;
/*      */     } 
/* 1120 */     if ("exec_time".equalsIgnoreCase(name)) {
/* 1121 */       exec_time(value);
/*      */       return;
/*      */     } 
/* 1124 */     if ("method_line".equalsIgnoreCase(name)) {
/* 1125 */       method_line(value);
/*      */       return;
/*      */     } 
/* 1128 */     if ("log_layer".equalsIgnoreCase(name)) {
/* 1129 */       log_layer(value);
/*      */       return;
/*      */     } 
/* 1132 */     if ("analysis".equalsIgnoreCase(name)) {
/* 1133 */       analysis(value);
/*      */       return;
/*      */     } 
/* 1136 */     super.setNumber(name, value);
/*      */   }
/*      */   public void setNumber(String name, float value) {
/* 1139 */     if ("total_no".equalsIgnoreCase(name)) {
/* 1140 */       total_no(value);
/*      */       return;
/*      */     } 
/* 1143 */     if ("log_no".equalsIgnoreCase(name)) {
/* 1144 */       log_no(value);
/*      */       return;
/*      */     } 
/* 1147 */     if ("elapsed_time".equalsIgnoreCase(name)) {
/* 1148 */       elapsed_time(value);
/*      */       return;
/*      */     } 
/* 1151 */     if ("exec_time".equalsIgnoreCase(name)) {
/* 1152 */       exec_time(value);
/*      */       return;
/*      */     } 
/* 1155 */     if ("method_line".equalsIgnoreCase(name)) {
/* 1156 */       method_line(value);
/*      */       return;
/*      */     } 
/* 1159 */     if ("log_layer".equalsIgnoreCase(name)) {
/* 1160 */       log_layer(value);
/*      */       return;
/*      */     } 
/* 1163 */     if ("analysis".equalsIgnoreCase(name)) {
/* 1164 */       analysis(value);
/*      */       return;
/*      */     } 
/* 1167 */     super.setNumber(name, value);
/*      */   }
/*      */   public void setNumber(String name, double value) {
/* 1170 */     if ("total_no".equalsIgnoreCase(name)) {
/* 1171 */       total_no(value);
/*      */       return;
/*      */     } 
/* 1174 */     if ("log_no".equalsIgnoreCase(name)) {
/* 1175 */       log_no(value);
/*      */       return;
/*      */     } 
/* 1178 */     if ("elapsed_time".equalsIgnoreCase(name)) {
/* 1179 */       elapsed_time(value);
/*      */       return;
/*      */     } 
/* 1182 */     if ("exec_time".equalsIgnoreCase(name)) {
/* 1183 */       exec_time(value);
/*      */       return;
/*      */     } 
/* 1186 */     if ("method_line".equalsIgnoreCase(name)) {
/* 1187 */       method_line(value);
/*      */       return;
/*      */     } 
/* 1190 */     if ("log_layer".equalsIgnoreCase(name)) {
/* 1191 */       log_layer(value);
/*      */       return;
/*      */     } 
/* 1194 */     if ("analysis".equalsIgnoreCase(name)) {
/* 1195 */       analysis(value);
/*      */       return;
/*      */     } 
/* 1198 */     super.setNumber(name, value);
/*      */   }
/*      */   public void setTimestamp(String name, MCTimestamp value) {
/* 1201 */     if ("log_ts".equalsIgnoreCase(name)) {
/* 1202 */       log_ts(value);
/*      */       return;
/*      */     } 
/* 1205 */     super.setTimestamp(name, value);
/*      */   }
/*      */   
/*      */   public void setStringNE(String name, String value) {
/* 1209 */     if ("file_path".equalsIgnoreCase(name)) {
/* 1210 */       file_path(value);
/*      */       return;
/*      */     } 
/* 1213 */     if ("req_no".equalsIgnoreCase(name)) {
/* 1214 */       req_no(value);
/*      */       return;
/*      */     } 
/* 1217 */     if ("thread_no".equalsIgnoreCase(name)) {
/* 1218 */       thread_no(value);
/*      */       return;
/*      */     } 
/* 1221 */     if ("co_cd".equalsIgnoreCase(name)) {
/* 1222 */       co_cd(value);
/*      */       return;
/*      */     } 
/* 1225 */     if ("operation_id".equalsIgnoreCase(name)) {
/* 1226 */       operation_id(value);
/*      */       return;
/*      */     } 
/* 1229 */     if ("msg_lvl".equalsIgnoreCase(name)) {
/* 1230 */       msg_lvl(value);
/*      */       return;
/*      */     } 
/* 1233 */     if ("msg_id".equalsIgnoreCase(name)) {
/* 1234 */       msg_id(value);
/*      */       return;
/*      */     } 
/* 1237 */     if ("class_nm".equalsIgnoreCase(name)) {
/* 1238 */       class_nm(value);
/*      */       return;
/*      */     } 
/* 1241 */     if ("method_nm".equalsIgnoreCase(name)) {
/* 1242 */       method_nm(value);
/*      */       return;
/*      */     } 
/* 1245 */     if ("msg_txt".equalsIgnoreCase(name)) {
/* 1246 */       msg_txt(value);
/*      */       return;
/*      */     } 
/* 1249 */     if ("button_id".equalsIgnoreCase(name)) {
/* 1250 */       button_id(value);
/*      */       return;
/*      */     } 
/* 1253 */     if ("sql_id".equalsIgnoreCase(name)) {
/* 1254 */       sql_id(value);
/*      */       return;
/*      */     } 
/* 1257 */     super.setStringNE(name, value);
/*      */   }
/*      */   public void setNumberNE(String name, MCNumber value) {
/* 1260 */     if ("total_no".equalsIgnoreCase(name)) {
/* 1261 */       total_no(value);
/*      */       return;
/*      */     } 
/* 1264 */     if ("log_no".equalsIgnoreCase(name)) {
/* 1265 */       log_no(value);
/*      */       return;
/*      */     } 
/* 1268 */     if ("elapsed_time".equalsIgnoreCase(name)) {
/* 1269 */       elapsed_time(value);
/*      */       return;
/*      */     } 
/* 1272 */     if ("exec_time".equalsIgnoreCase(name)) {
/* 1273 */       exec_time(value);
/*      */       return;
/*      */     } 
/* 1276 */     if ("method_line".equalsIgnoreCase(name)) {
/* 1277 */       method_line(value);
/*      */       return;
/*      */     } 
/* 1280 */     if ("log_layer".equalsIgnoreCase(name)) {
/* 1281 */       log_layer(value);
/*      */       return;
/*      */     } 
/* 1284 */     if ("analysis".equalsIgnoreCase(name)) {
/* 1285 */       analysis(value);
/*      */       return;
/*      */     } 
/* 1288 */     super.setNumberNE(name, value);
/*      */   }
/*      */   public void setNumberNE(String name, int value) {
/* 1291 */     if ("total_no".equalsIgnoreCase(name)) {
/* 1292 */       total_no(value);
/*      */       return;
/*      */     } 
/* 1295 */     if ("log_no".equalsIgnoreCase(name)) {
/* 1296 */       log_no(value);
/*      */       return;
/*      */     } 
/* 1299 */     if ("elapsed_time".equalsIgnoreCase(name)) {
/* 1300 */       elapsed_time(value);
/*      */       return;
/*      */     } 
/* 1303 */     if ("exec_time".equalsIgnoreCase(name)) {
/* 1304 */       exec_time(value);
/*      */       return;
/*      */     } 
/* 1307 */     if ("method_line".equalsIgnoreCase(name)) {
/* 1308 */       method_line(value);
/*      */       return;
/*      */     } 
/* 1311 */     if ("log_layer".equalsIgnoreCase(name)) {
/* 1312 */       log_layer(value);
/*      */       return;
/*      */     } 
/* 1315 */     if ("analysis".equalsIgnoreCase(name)) {
/* 1316 */       analysis(value);
/*      */       return;
/*      */     } 
/* 1319 */     super.setNumberNE(name, value);
/*      */   }
/*      */   public void setNumberNE(String name, long value) {
/* 1322 */     if ("total_no".equalsIgnoreCase(name)) {
/* 1323 */       total_no(value);
/*      */       return;
/*      */     } 
/* 1326 */     if ("log_no".equalsIgnoreCase(name)) {
/* 1327 */       log_no(value);
/*      */       return;
/*      */     } 
/* 1330 */     if ("elapsed_time".equalsIgnoreCase(name)) {
/* 1331 */       elapsed_time(value);
/*      */       return;
/*      */     } 
/* 1334 */     if ("exec_time".equalsIgnoreCase(name)) {
/* 1335 */       exec_time(value);
/*      */       return;
/*      */     } 
/* 1338 */     if ("method_line".equalsIgnoreCase(name)) {
/* 1339 */       method_line(value);
/*      */       return;
/*      */     } 
/* 1342 */     if ("log_layer".equalsIgnoreCase(name)) {
/* 1343 */       log_layer(value);
/*      */       return;
/*      */     } 
/* 1346 */     if ("analysis".equalsIgnoreCase(name)) {
/* 1347 */       analysis(value);
/*      */       return;
/*      */     } 
/* 1350 */     super.setNumberNE(name, value);
/*      */   }
/*      */   public void setNumberNE(String name, float value) {
/* 1353 */     if ("total_no".equalsIgnoreCase(name)) {
/* 1354 */       total_no(value);
/*      */       return;
/*      */     } 
/* 1357 */     if ("log_no".equalsIgnoreCase(name)) {
/* 1358 */       log_no(value);
/*      */       return;
/*      */     } 
/* 1361 */     if ("elapsed_time".equalsIgnoreCase(name)) {
/* 1362 */       elapsed_time(value);
/*      */       return;
/*      */     } 
/* 1365 */     if ("exec_time".equalsIgnoreCase(name)) {
/* 1366 */       exec_time(value);
/*      */       return;
/*      */     } 
/* 1369 */     if ("method_line".equalsIgnoreCase(name)) {
/* 1370 */       method_line(value);
/*      */       return;
/*      */     } 
/* 1373 */     if ("log_layer".equalsIgnoreCase(name)) {
/* 1374 */       log_layer(value);
/*      */       return;
/*      */     } 
/* 1377 */     if ("analysis".equalsIgnoreCase(name)) {
/* 1378 */       analysis(value);
/*      */       return;
/*      */     } 
/* 1381 */     super.setNumberNE(name, value);
/*      */   }
/*      */   public void setNumberNE(String name, double value) {
/* 1384 */     if ("total_no".equalsIgnoreCase(name)) {
/* 1385 */       total_no(value);
/*      */       return;
/*      */     } 
/* 1388 */     if ("log_no".equalsIgnoreCase(name)) {
/* 1389 */       log_no(value);
/*      */       return;
/*      */     } 
/* 1392 */     if ("elapsed_time".equalsIgnoreCase(name)) {
/* 1393 */       elapsed_time(value);
/*      */       return;
/*      */     } 
/* 1396 */     if ("exec_time".equalsIgnoreCase(name)) {
/* 1397 */       exec_time(value);
/*      */       return;
/*      */     } 
/* 1400 */     if ("method_line".equalsIgnoreCase(name)) {
/* 1401 */       method_line(value);
/*      */       return;
/*      */     } 
/* 1404 */     if ("log_layer".equalsIgnoreCase(name)) {
/* 1405 */       log_layer(value);
/*      */       return;
/*      */     } 
/* 1408 */     if ("analysis".equalsIgnoreCase(name)) {
/* 1409 */       analysis(value);
/*      */       return;
/*      */     } 
/* 1412 */     super.setNumberNE(name, value);
/*      */   }
/*      */   public void setTimestampNE(String name, MCTimestamp value) {
/* 1415 */     if ("log_ts".equalsIgnoreCase(name)) {
/* 1416 */       log_ts(value);
/*      */       return;
/*      */     } 
/* 1419 */     super.setTimestampNE(name, value);
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\notice\MCLogR_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */