/*     */ package mcframe.commonCore.notice;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCMessageList
/*     */   extends ArrayList<MCMessage>
/*     */ {
/*     */   public MCMessageList subList(MCMessageLevel... levels) {
/*  27 */     MCMessageList list = new MCMessageList();
/*  28 */     if (levels == null) {
/*  29 */       return list;
/*     */     }
/*  31 */     int levellen = levels.length;
/*  32 */     int listlen = size();
/*  33 */     for (int i = 0; i < listlen; i++) {
/*  34 */       MCMessage msg = get(i);
/*  35 */       MCMessageLevel lv = msg.getLevel();
/*  36 */       for (int j = 0; j < levellen; j++) {
/*  37 */         if (levels[j] == lv) {
/*  38 */           list.add(msg);
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/*  43 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean containsLevel(MCMessageLevel level) {
/*  55 */     int listlen = size();
/*  56 */     for (int i = 0; i < listlen; i++) {
/*  57 */       MCMessage msg = get(i);
/*  58 */       MCMessageLevel lv = msg.getLevel();
/*  59 */       if (level == lv) {
/*  60 */         return true;
/*     */       }
/*     */     } 
/*  63 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCMessage set(int index, MCMessage element) {
/*  71 */     if (element == null) {
/*  72 */       return null;
/*     */     }
/*  74 */     return super.set(index, element);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean add(MCMessage e) {
/*  80 */     if (e == null) {
/*  81 */       return false;
/*     */     }
/*  83 */     return super.add(e);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(int index, MCMessage element) {
/*  89 */     if (element == null) {
/*     */       return;
/*     */     }
/*  92 */     super.add(index, element);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean addAll(Collection<? extends MCMessage> c) {
/*  98 */     if (c == null)
/*     */     {
/* 100 */       return false;
/*     */     }
/* 102 */     return super.addAll(c);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean addAll(int index, Collection<? extends MCMessage> c) {
/* 108 */     if (c == null)
/*     */     {
/* 110 */       return false;
/*     */     }
/* 112 */     return super.addAll(index, c);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\notice\MCMessageList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */