/*     */ package mcframe.commonCore.notice;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import mcframe.commonCore.lang.MCDate;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.sys.MCSys;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MCError
/*     */   extends Error
/*     */ {
/*     */   private static final String _dumpbase = "mcfdump_{1}.dat";
/*  41 */   private String _dumpfile = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCError(String msg, String... binds) {
/*  53 */     super(MCStringUtil.bind(msg, (Object[])binds));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCError(Throwable cause) {
/*  64 */     super(cause);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCError(Throwable cause, String msg, String... binds) {
/*  77 */     super(MCStringUtil.bind(msg, (Object[])binds), cause);
/*     */   }
/*     */   
/*     */   public String getMessage() {
/*  81 */     StringBuilder sb = new StringBuilder(super.getMessage());
/*  82 */     if (this._dumpfile != null) {
/*  83 */       String LINE_SEP = MCSys.env.getVMEnv("line.separator", "\n");
/*  84 */       sb.append(LINE_SEP);
/*  85 */       sb.append(LINE_SEP);
/*  86 */       sb.append("Dump File: ");
/*  87 */       sb.append(this._dumpfile);
/*  88 */       sb.append(LINE_SEP);
/*     */     } 
/*  90 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String dump() {
/* 112 */     String[] dirs = {
/* 113 */         MCSys.env.MCF_HOME(), 
/* 114 */         System.getProperty("user.dir"), 
/* 115 */         System.getProperty("java.io.tmpdir")
/*     */       };
/* 117 */     String filename = MCStringUtil.bind("mcfdump_{1}.dat", new Object[] {
/* 118 */           (new MCDate()).toString("yyyyMMddHHmmssSSS") });
/* 119 */     this._dumpfile = null; byte b; int i; String[] arrayOfString1;
/* 120 */     for (i = (arrayOfString1 = dirs).length, b = 0; b < i; ) { String dirname = arrayOfString1[b];
/* 121 */       if (dirname != null) {
/*     */ 
/*     */         
/* 124 */         File dir = new File(dirname);
/* 125 */         if (dir.isDirectory()) {
/*     */ 
/*     */           
/* 128 */           File file = new File(dir, filename); try {
/* 129 */             Exception exception2, exception1 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           }
/* 140 */           catch (FileNotFoundException fileNotFoundException) {}
/*     */         } 
/*     */       } 
/*     */       b++; }
/*     */     
/* 145 */     printStackTrace(System.err);
/* 146 */     return this._dumpfile;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\notice\MCError.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */