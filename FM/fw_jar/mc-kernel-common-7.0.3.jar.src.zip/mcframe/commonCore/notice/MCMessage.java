/*     */ package mcframe.commonCore.notice;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.List;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.resource.MCConst;
/*     */ import mcframe.commonCore.resource.MCMessageConst;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCMessage
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 386825317894438551L;
/*     */   private final String _id;
/*     */   private final MCMessageLevel _lv;
/*     */   private MCStringUtil.IndexBindSource _bind;
/*  84 */   private transient MCRow _row = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  92 */   private transient String _colname = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  99 */   private String _wrapmsg = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCMessage(String id, Object... binds) {
/* 113 */     this((MCRow)null, (String)null, id, binds);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCMessage(MCRow causerow, String causecol, String id, Object... binds) {
/* 130 */     this._id = id;
/* 131 */     this._lv = MCConst.message.getLevel(this._id);
/* 132 */     this._bind = createBindList(binds);
/* 133 */     this._row = causerow;
/* 134 */     this._colname = causecol;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCMessage(String id, List<Object> bindlist) {
/* 150 */     this(id, (bindlist == null) ? null : bindlist.toArray());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCMessage(MCRow causerow, String causecol, String id, List<Object> bindlist) {
/* 170 */     this(causerow, causecol, id, (bindlist == null) ? null : bindlist.toArray());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCStringUtil.IndexBindSource createBindList(Object... binds) {
/* 182 */     return new MCStringUtil.IndexBindSource(binds);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getID() {
/* 194 */     return this._id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCMessageLevel getLevel() {
/* 207 */     return this._lv;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getBind(int index) {
/* 220 */     return this._bind.get(index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String[] getBindArray() {
/* 233 */     return this._bind.toArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int addBind(Object... binds) {
/* 250 */     this._wrapmsg = null;
/*     */     
/* 252 */     int top = -1;
/* 253 */     if (binds != null) {
/* 254 */       int len = binds.length;
/* 255 */       if (len > 0) {
/* 256 */         top = this._bind.size();
/* 257 */         for (int i = 0; i < len; i++) {
/* 258 */           this._bind.add(binds[i]);
/*     */         }
/*     */       } 
/*     */     } 
/* 262 */     return top;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String setBind(int index, Object bind) {
/* 286 */     this._wrapmsg = null;
/*     */     
/* 288 */     String old = this._bind.get(index);
/* 289 */     this._bind.set(index, bind);
/* 290 */     return old;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setBind(Object... binds) {
/* 310 */     this._wrapmsg = null;
/*     */     
/* 312 */     this._bind = createBindList(binds);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCMessage setCauseRow(MCRow row, String col) {
/* 326 */     this._row = row;
/* 327 */     this._colname = col;
/* 328 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCRow getCauseRow() {
/* 342 */     return this._row;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getCauseColumn() {
/* 358 */     return this._colname;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void wrapMessage(String message) {
/* 380 */     this._wrapmsg = message;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString() {
/* 407 */     return toString(MCConst.message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String toString(MCMessageConst msgconst) {
/* 437 */     if (this._wrapmsg != null) {
/* 438 */       return this._wrapmsg;
/*     */     }
/*     */     
/* 441 */     if (msgconst == null) {
/* 442 */       msgconst = MCConst.message;
/*     */     }
/* 444 */     String text = msgconst.getMessage(this._id);
/* 445 */     if (text != null) {
/* 446 */       this._bind.nullstr(msgconst.getNullString());
/* 447 */       text = MCStringUtil.bind(text, (MCStringUtil.BindSource)this._bind);
/*     */     } else {
/* 449 */       text = String.valueOf(this._id) + getBindString();
/*     */     } 
/* 451 */     return text;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final String getBindString() {
/* 470 */     StringBuilder sb = new StringBuilder();
/* 471 */     String[] array = this._bind.toArray(); byte b; int i; String[] arrayOfString1;
/* 472 */     for (i = (arrayOfString1 = array).length, b = 0; b < i; ) { String bind = arrayOfString1[b];
/* 473 */       if (sb.length() > 0) {
/* 474 */         sb.append(',');
/*     */       }
/* 476 */       sb.append(bind); b++; }
/*     */     
/* 478 */     sb.insert(0, " (Bind)");
/* 479 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\notice\MCMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */