/*     */ package mcframe.commonCore.notice;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.Writer;
/*     */ import mcframe.commonCore.resource.MCConfig;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class MCLogHandler
/*     */ {
/*     */   static final String RES_LOG_ROOT = "log";
/*     */   protected final Type _type;
/*     */   
/*     */   enum Type
/*     */   {
/*  48 */     ADMIN
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       String lowerName()
/*     */       {
/*  56 */         return "admin";
/*     */       }
/*     */     },
/*  59 */     DEBUG
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       String lowerName()
/*     */       {
/*  67 */         return "debug";
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     final String getResourceKey(String key) {
/*  94 */       if (key == null) {
/*  95 */         key = "";
/*     */       }
/*  97 */       return MCConfig.createKey(new String[] { "log", lowerName(), key });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     abstract String lowerName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final MCLogHandler create(Type type, String user) {
/* 113 */     return new MCLogFileHandler(type, user);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 135 */   protected Writer _writer = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCLogHandler(Type type) {
/* 145 */     this._type = type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract void publish(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract void write(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract void follow(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void rotate() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void close() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handlerError(Object log) {
/* 212 */     handlerError(null, log);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handlerError(Throwable ex) {
/* 225 */     handlerError(ex, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handlerError(Throwable ex, Object log) {
/* 243 */     String id = null;
/* 244 */     MCMessageLevel level = null;
/* 245 */     String text = null;
/* 246 */     if (log == null) {
/* 247 */       if (ex == null) {
/*     */         return;
/*     */       }
/* 250 */       text = "Log Handle Error...";
/*     */     } else {
/*     */       
/* 253 */       if (log instanceof MCMessage) {
/* 254 */         MCMessage msg = (MCMessage)log;
/* 255 */         id = msg.getID();
/* 256 */         level = msg.getLevel();
/*     */       } 
/* 258 */       text = log.toString();
/*     */     } 
/*     */     
/* 261 */     boolean enable = (this._type == Type.ADMIN) ? MCLogger.FW_ENABLE_CHECKER
/* 262 */       .isAdminEnabled(level) : MCLogger.FW_ENABLE_CHECKER.isDebugEnabled(level);
/* 263 */     if (enable) {
/* 264 */       StringBuilder sb = MCLogger.createLogBuffer(level, id, 1);
/* 265 */       sb.append(text);
/* 266 */       sb.append(MCLogger.LINE_SEP);
/* 267 */       if (ex != null) {
/* 268 */         sb.append(MCLog.stackTrace(ex));
/*     */       }
/* 270 */       Writer errwriter = (this._writer != null) ? this._writer : new OutputStreamWriter(
/* 271 */           System.err);
/*     */       try {
/* 273 */         errwriter.write(sb.toString());
/* 274 */         errwriter.flush();
/*     */       }
/* 276 */       catch (IOException iOException) {
/* 277 */         System.err.println(sb.toString());
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\notice\MCLogHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */