/*      */ package mcframe.commonCore.notice;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintWriter;
/*      */ import java.io.StringWriter;
/*      */ import java.io.Writer;
/*      */ import java.nio.file.Files;
/*      */ import mcframe.commonCore.lang.MCStringUtil;
/*      */ import mcframe.commonCore.resource.MCConfig;
/*      */ import mcframe.commonCore.resource.MCConst;
/*      */ import mcframe.commonCore.sys.MCSys;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class MCLog
/*      */ {
/*      */   static {
/*  160 */     String NOW_KEY = "org.apache.commons.logging.Log";
/*  161 */     String OLD_KEY = "org.apache.commons.logging.log";
/*  162 */     if (System.getProperty(NOW_KEY) == null && 
/*  163 */       System.getProperty(OLD_KEY) == null)
/*  164 */       System.setProperty(NOW_KEY, 
/*  165 */           "mcframe.commonCore.notice.MCLogger"); 
/*      */   }
/*  167 */   private static Log _fwlog = LogFactory.getLog("framework");
/*  168 */   private static Log _aplog = LogFactory.getLog("apprication");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final boolean NO_HEADER = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final boolean ON_HEADER = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final char FW_PREFIX = 'F';
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String DEVLOG_ID = "develop";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  208 */   private static final boolean DEVLOG = MCConfig.common.getBoolean("log.devlog", false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  217 */   private static final MCMessageLevel STACKTRACE_WRITE_LEVEL = MCMessageLevel.valueOf(
/*  218 */       MCConfig.common.getString(
/*  219 */         "log.stacktracewritelevel", 
/*      */         
/*  221 */         MCMessageLevel.TRACE.toString()));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String stackTrace(Throwable t) {
/*      */     String trace;
/*  235 */     if (t != null) {
/*  236 */       StringWriter sw = new StringWriter();
/*  237 */       PrintWriter pw = new PrintWriter(sw);
/*  238 */       t.printStackTrace(pw);
/*  239 */       trace = sw.toString();
/*      */     } else {
/*      */       
/*  242 */       trace = "";
/*      */     } 
/*  244 */     return trace;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean isEnabled(String id) {
/*  261 */     MCMessageLevel level = MCConst.message.getLevel(id);
/*  262 */     return isEnabled(id, level);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean isEnabled(MCMessage msg) {
/*  278 */     if (msg == null) {
/*  279 */       return false;
/*      */     }
/*      */     
/*  282 */     return isEnabled(msg.getID(), msg.getLevel());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final boolean isEnabled(String id, MCMessageLevel level) {
/*  297 */     if (level == null) {
/*  298 */       return true;
/*      */     }
/*  300 */     Log logger = getLogger(id);
/*  301 */     return level.isLogEnabled(logger);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void close(String userid) {
/*  318 */     if (_fwlog instanceof MCLogger) {
/*  319 */       MCLogger.close(userid);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void rotate(String userid) {
/*  332 */     if (_fwlog instanceof MCLogger) {
/*  333 */       MCLogger.rotate(userid);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void write(String msgid, Object... values) {
/*  350 */     write(false, msgid, values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void write(MCMessage msg) {
/*  364 */     write(false, msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void write(MCMessageList msglist) {
/*  381 */     if (msglist == null) {
/*      */       return;
/*      */     }
/*  384 */     int size = msglist.size();
/*  385 */     for (int i = 0; i < size; i++) {
/*  386 */       MCMessage msg = msglist.get(i);
/*  387 */       write(false, msg);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void write(Throwable ex) {
/*  409 */     write(false, ex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void follow(String msgid, Object... values) {
/*  424 */     write(true, msgid, values);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void follow(MCMessage msg) {
/*  438 */     write(true, msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void follow(MCMessageList msglist) {
/*  455 */     if (msglist == null) {
/*      */       return;
/*      */     }
/*  458 */     int size = msglist.size();
/*  459 */     for (int i = 0; i < size; i++) {
/*  460 */       MCMessage msg = msglist.get(i);
/*  461 */       write(true, msg);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final FollowWriter followWriter(String msgid) {
/*  490 */     if (!(_fwlog instanceof MCLogger))
/*      */     {
/*  492 */       return new FollowWriter(
/*  493 */           MCLogger.dummyHandler, MCLogger.dummyHandler);
/*      */     }
/*      */     
/*  496 */     MCLogger logger = isFrameworkMessage(msgid) ? 
/*  497 */       (MCLogger)_fwlog : (MCLogger)_aplog;
/*  498 */     MCMessage msg = new MCMessage(msgid, new Object[0]);
/*  499 */     return logger.followWriter(msg.getLevel());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class FollowWriter
/*      */   {
/*      */     private final MCLogHandler admin;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final MCLogHandler debug;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     FollowWriter(MCLogHandler admin, MCLogHandler debug) {
/*  530 */       this.admin = admin;
/*  531 */       this.debug = debug;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void write(String text) {
/*  545 */       this.admin.follow(text);
/*  546 */       this.debug.follow(text);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void startDelay(String msgid, Object... values) {
/*  570 */     if (msgid == null) {
/*  571 */       startDelay(null);
/*      */     } else {
/*      */       
/*  574 */       startDelay(new MCMessage(msgid, values));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void startDelay(MCMessage msg) {
/*  599 */     cancelDelay();
/*      */     
/*  601 */     if (msg == null || !(_fwlog instanceof MCLogger)) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  606 */     MCLogger logger = isFrameworkMessage(msg.getID()) ? 
/*  607 */       (MCLogger)_fwlog : (MCLogger)_aplog;
/*  608 */     DelayWriter delay = logger.delayWriter(msg);
/*  609 */     _delays.set(delay);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void followDelay(String text) {
/*  624 */     DelayWriter delay = _delays.get();
/*  625 */     if (delay == null || !delay.isActive()) {
/*      */       return;
/*      */     }
/*  628 */     delay.write(text);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void writeDelay() {
/*  641 */     DelayWriter delay = _delays.get();
/*  642 */     if (delay == null || !delay.isValid()) {
/*      */       return;
/*      */     }
/*  645 */     delay.close();
/*      */     
/*  647 */     MCMessage header = delay.getHeader();
/*  648 */     MCLogger logger = isFrameworkMessage(header.getID()) ? 
/*  649 */       (MCLogger)_fwlog : (MCLogger)_aplog;
/*  650 */     logger.delay(delay);
/*      */     
/*  652 */     delay.delete();
/*  653 */     _delays.remove();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void cancelDelay() {
/*  667 */     DelayWriter delay = _delays.get();
/*  668 */     if (delay != null) {
/*  669 */       delay.close();
/*  670 */       delay.delete();
/*  671 */       _delays.remove();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  730 */   private static final ThreadLocal<DelayWriter> _delays = new ThreadLocal<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static class DelayWriter
/*      */   {
/*  751 */     private File _file = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  757 */     private Writer _writer = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  763 */     private MCMessage _header = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     DelayWriter(MCMessage msg) {
/*  779 */       this._header = msg;
/*  780 */       if (this._header != null) {
/*  781 */         this._file = createFile();
/*  782 */         if (this._file != null) {
/*  783 */           this._writer = createWriter(this._file);
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private File createFile() {
/*  802 */       String file = MCStringUtil.join("_", new String[] {
/*  803 */             String.valueOf(Thread.currentThread().getId()), 
/*  804 */             MCSys.request.serverRequestNo(), 
/*  805 */             String.valueOf(MCSys.user.ID()) + ".dly" });
/*  806 */       String dir = MCLogFileHandler.getLogDir();
/*  807 */       return new File(dir, file);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Writer createWriter(File file) {
/*      */       try {
/*  822 */         return MCLogFileHandler.createWriter(file, false);
/*      */       }
/*  824 */       catch (Exception exception) {
/*      */ 
/*      */         
/*  827 */         return null;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void delete() {
/*  839 */       if (!isValid()) {
/*      */         return;
/*      */       }
/*      */       
/*      */       try {
/*  844 */         Files.delete(this._file.toPath());
/*      */       }
/*  846 */       catch (IOException e) {
/*  847 */         MCLog.write(e);
/*      */       } 
/*  849 */       this._file = null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void close() {
/*  861 */       if (!isActive()) {
/*      */         return;
/*      */       }
/*      */       
/*      */       try {
/*  866 */         this._writer.close();
/*      */       }
/*  868 */       catch (IOException e) {
/*  869 */         MCLog.write(e);
/*      */       } 
/*  871 */       this._writer = null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void write(String text) {
/*  884 */       if (!isActive()) {
/*      */         return;
/*      */       }
/*      */       
/*      */       try {
/*  889 */         this._writer.write(text);
/*      */       }
/*  891 */       catch (IOException e) {
/*  892 */         MCLog.write(e);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean isActive() {
/*  903 */       return (this._writer != null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean isValid() {
/*  916 */       return (this._file != null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     MCMessage getHeader() {
/*  926 */       return this._header;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     File getFile() {
/*  936 */       return this._file;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     DelayWriter() {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final void write(boolean follow, String msgid, Object... values) {
/*  953 */     if (msgid == null) {
/*      */       return;
/*      */     }
/*  956 */     Log logger = analyzeMessage(follow, msgid, values);
/*  957 */     if (logger != null) {
/*  958 */       writeMessage(logger, follow, new MCMessage(msgid, values), null);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final void write(boolean follow, MCMessage msg) {
/*  972 */     if (msg == null) {
/*      */       return;
/*      */     }
/*  975 */     msg = analyzeMessage(msg);
/*  976 */     Log logger = getEnableLogger(msg);
/*  977 */     if (logger != null) {
/*  978 */       writeMessage(logger, follow, msg, null);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final void write(boolean follow, Throwable ex) {
/* 1000 */     if (ex == null) {
/*      */       return;
/*      */     }
/* 1003 */     MCMessage msg = null;
/* 1004 */     if (ex instanceof MCException) {
/* 1005 */       MCException mcex = (MCException)ex;
/* 1006 */       msg = analyzeMessage(mcex.getMCMessage());
/*      */     }
/*      */     else {
/*      */       
/* 1010 */       msg = analyzeMessage(MCException.createSystemExceptionMessage(ex));
/*      */     } 
/* 1012 */     Log logger = getEnableLogger(msg);
/* 1013 */     if (logger != null) {
/* 1014 */       writeMessage(logger, follow, msg, ex);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final MCMessage analyzeMessage(MCMessage msg) {
/* 1033 */     String id = msg.getID();
/* 1034 */     if (!MCConst.message.containsID(id)) {
/*      */ 
/*      */       
/* 1037 */       msg = createAnalyzeMessageNotFound(msg);
/* 1038 */       Log logger = getEnableLogger(msg);
/* 1039 */       if (logger != null) {
/* 1040 */         MCMessageLevel level = getAnalyzeMessageErrorLevel(msg);
/* 1041 */         writeLog(logger, false, 
/* 1042 */             msg.getID(), level, msg.toString(), null);
/*      */       } 
/* 1044 */       return null;
/*      */     } 
/*      */     
/* 1047 */     if (msg.getLevel() == null) {
/*      */ 
/*      */       
/* 1050 */       msg = createAnalyzeMessageInvalidLevel(msg);
/* 1051 */       Log logger = getEnableLogger(msg);
/* 1052 */       if (logger != null) {
/* 1053 */         MCMessageLevel level = getAnalyzeMessageErrorLevel(msg);
/* 1054 */         writeLog(logger, false, 
/* 1055 */             msg.getID(), level, msg.toString(), null);
/*      */       } 
/* 1057 */       return null;
/*      */     } 
/* 1059 */     return msg;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final Log analyzeMessage(boolean follow, String id, Object... binds) {
/* 1081 */     if (!MCConst.message.containsID(id)) {
/*      */ 
/*      */       
/* 1084 */       MCMessage msg = createAnalyzeMessageNotFound(
/* 1085 */           new MCMessage(id, binds));
/* 1086 */       Log logger = getEnableLogger(msg);
/* 1087 */       if (logger != null) {
/* 1088 */         MCMessageLevel level = getAnalyzeMessageErrorLevel(msg);
/* 1089 */         writeLog(logger, follow, 
/* 1090 */             msg.getID(), level, msg.toString(), null);
/*      */       } 
/* 1092 */       return null;
/*      */     } 
/* 1094 */     MCMessageLevel lv = MCConst.message.getLevel(id);
/* 1095 */     if (lv == null) {
/*      */ 
/*      */       
/* 1098 */       MCMessage msg = createAnalyzeMessageInvalidLevel(
/* 1099 */           new MCMessage(id, binds));
/* 1100 */       Log logger = getEnableLogger(msg);
/* 1101 */       if (logger != null) {
/* 1102 */         MCMessageLevel level = getAnalyzeMessageErrorLevel(msg);
/* 1103 */         writeLog(logger, follow, 
/* 1104 */             msg.getID(), level, msg.toString(), null);
/*      */       } 
/* 1106 */       return null;
/*      */     } 
/* 1108 */     return getEnableLogger(id, lv);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static MCMessage createAnalyzeMessageNotFound(MCMessage msg) {
/* 1121 */     return new MCMessage(Core_Msg_FW_A.FCBJC0001, new Object[] { msg });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static MCMessage createAnalyzeMessageInvalidLevel(MCMessage msg) {
/* 1133 */     return new MCMessage(Core_Msg_FW_A.FCBJC0002, new Object[] { msg.getID(), msg });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static MCMessageLevel getAnalyzeMessageErrorLevel(MCMessage msg) {
/* 1145 */     MCMessageLevel level = msg.getLevel();
/* 1146 */     return (level != null) ? level : MCMessageLevel.WARN;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final void writeMessage(Log logger, boolean follow, MCMessage msg, Throwable t) {
/* 1173 */     writeLog(logger, follow, 
/* 1174 */         msg.getID(), msg.getLevel(), msg.toString(), t);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void developDebug(String msg) {
/* 1206 */     writeDevelopLog(MCMessageLevel.DEBUG, msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void developDebug(Throwable t) {
/* 1235 */     StringWriter sw = new StringWriter();
/* 1236 */     PrintWriter pw = new PrintWriter(sw);
/* 1237 */     t.printStackTrace(pw);
/* 1238 */     pw.flush();
/* 1239 */     String msg = sw.toString();
/* 1240 */     developDebug(msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void developTrace(String msg) {
/* 1271 */     writeDevelopLog(MCMessageLevel.TRACE, msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final void writeDevelopLog(MCMessageLevel level, String msg) {
/* 1283 */     _writeDevelopLog(level, msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final void _writeDevelopLog(MCMessageLevel level, String msg) {
/* 1299 */     if (!DEVLOG) {
/*      */       return;
/*      */     }
/* 1302 */     String id = "develop";
/* 1303 */     Log logger = getEnableLogger(id, level);
/* 1304 */     if (logger != null) {
/* 1305 */       writeLog(logger, false, id, level, msg, null);
/* 1306 */       System.out.println(msg);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final Log getEnableLogger(MCMessage msg) {
/* 1323 */     if (msg == null) {
/* 1324 */       return null;
/*      */     }
/* 1326 */     String id = msg.getID();
/* 1327 */     MCMessageLevel level = msg.getLevel();
/* 1328 */     return getEnableLogger(id, level);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final Log getEnableLogger(String id, MCMessageLevel level) {
/* 1345 */     if (level == null) {
/* 1346 */       level = MCMessageLevel.FATAL;
/*      */     }
/*      */     
/* 1349 */     Log logger = getLogger(id);
/* 1350 */     if (!level.isLogEnabled(logger)) {
/* 1351 */       logger = null;
/*      */     }
/* 1353 */     return logger;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final void writeLog(Log logger, boolean follow, String id, MCMessageLevel level, String msg, Throwable t) {
/* 1379 */     MCVerifiedMessage msgcon = 
/* 1380 */       new MCVerifiedMessage(id, level, msg, follow);
/*      */ 
/*      */     
/* 1383 */     if (t == null) {
/*      */       
/* 1385 */       level.log(logger, msgcon);
/*      */ 
/*      */     
/*      */     }
/* 1389 */     else if (level.compareTo(STACKTRACE_WRITE_LEVEL) >= 0) {
/*      */       
/* 1391 */       level.log(logger, msgcon, t);
/*      */     }
/*      */     else {
/*      */       
/* 1395 */       level.log(logger, msgcon);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final Log getLogger(String id) {
/* 1414 */     return isFrameworkMessage(id) ? _fwlog : _aplog;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean isFrameworkMessage(String id) {
/* 1428 */     return (id != null && id.length() > 0 && id.charAt(0) == 'F');
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\notice\MCLog.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */