/*      */ package mcframe.commonCore.notice;
/*      */ 
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.io.OutputStreamWriter;
/*      */ import java.io.Writer;
/*      */ import java.nio.charset.Charset;
/*      */ import java.nio.file.Files;
/*      */ import java.nio.file.Paths;
/*      */ import java.nio.file.attribute.FileTime;
/*      */ import java.util.Date;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import mcframe.commonCore.lang.MCCalendarDate;
/*      */ import mcframe.commonCore.lang.MCDate;
/*      */ import mcframe.commonCore.lang.MCDateFieldType;
/*      */ import mcframe.commonCore.lang.MCStringUtil;
/*      */ import mcframe.commonCore.resource.MCConfig;
/*      */ import mcframe.commonCore.sys.MCSys;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class MCLogFileHandler
/*      */   extends MCLogHandler
/*      */ {
/*      */   static final String RES_LOG_FILE = "file";
/*   50 */   private static final String RES_LOG_DIR = MCConfig.createKey(new String[] { "log", "dir" });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   57 */   private static final String RES_LOG_ENCODE = MCConfig.createKey(new String[] { "log", 
/*   58 */         "encode" });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String RES_ROTATION = "rotation";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String RES_BACKUP = "backup";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String RES_INIT_ROTATION = "init_rotation";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int DEFAULT_BACKUP = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String BACKUP_SEP = ".";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String DEFAULT_LOG_DIR = "{MCF_HOME}/log";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private enum SIZE
/*      */   {
/*  114 */     B
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       long bytesize(long size)
/*      */       {
/*  122 */         return size;
/*      */       }
/*      */     },
/*  125 */     KB
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       long bytesize(long size)
/*      */       {
/*  133 */         return size * 1024L;
/*      */       }
/*      */     },
/*  136 */     MB
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       long bytesize(long size)
/*      */       {
/*  144 */         return size * 1024L * 1024L;
/*      */       }
/*      */     },
/*  147 */     GB
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       long bytesize(long size)
/*      */       {
/*  155 */         return size * 1024L * 1024L * 1024L;
/*      */       }
/*      */     };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private static final long RADIX = 1024L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     abstract long bytesize(long param1Long);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private enum DATE
/*      */   {
/*  187 */     Y
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     },
/*  194 */     M
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     },
/*  201 */     D
/*      */     {
/*      */     
/*      */     };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  215 */   private static final Pattern ROTATE_PATTERN = Pattern.compile("^([0-9]+)(.*)$", 
/*  216 */       32);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int ROTATE_INTERVAL_IDX = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int ROTATE_UNIT_IDX = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final File _file;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final Rotater _rotater;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final Writer createWriter(File file, boolean append) {
/*  245 */     FileOutputStream os = null;
/*      */     try {
/*  247 */       os = new FileOutputStream(file, append);
/*      */     }
/*  249 */     catch (Exception ex) {
/*  250 */       throw new MCException(ex, Core_Msg_FW_A.FCBJC0008, new Object[] { file.getAbsolutePath() });
/*      */     } 
/*  252 */     Charset cs = getCharset(file);
/*  253 */     return createWriter(os, cs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final Writer createWriter(OutputStream output, Charset cs) {
/*  271 */     if (output == null) {
/*  272 */       return null;
/*      */     }
/*  274 */     return (cs != null) ? 
/*  275 */       new OutputStreamWriter(output, cs) : 
/*  276 */       new OutputStreamWriter(output);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Charset getCharset(File file) {
/*  290 */     String encode = MCConfig.common.getString(RES_LOG_ENCODE);
/*  291 */     if (encode != null) {
/*      */       try {
/*  293 */         return Charset.forName(encode);
/*      */       }
/*  295 */       catch (Exception ex) {
/*      */ 
/*      */         
/*  298 */         throw new MCException(ex, Core_Msg_FW_A.FCBJC0007, new Object[] { encode, file.getAbsolutePath() });
/*      */       } 
/*      */     }
/*  301 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static String getLogDir() {
/*  313 */     String dirname = MCConfig.common.getString(RES_LOG_DIR, "{MCF_HOME}/log");
/*  314 */     return MCStringUtil.bind(dirname, MCConfig.common.bindsrc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  336 */   private Charset charset = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   MCLogFileHandler(MCLogHandler.Type type, String user) {
/*  350 */     super(type);
/*      */ 
/*      */     
/*  353 */     this._file = getLogFile(this._type, user);
/*  354 */     if (this._file == null) {
/*      */ 
/*      */       
/*  357 */       this._rotater = null;
/*  358 */       this._writer = null;
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  363 */     this._rotater = getRotater(user);
/*      */ 
/*      */     
/*  366 */     this.charset = getCharset();
/*      */ 
/*      */     
/*  369 */     init(this._type, this._rotater);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void finalize() {
/*  384 */     close();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Charset getCharset() {
/*      */     try {
/*  397 */       return getCharset(this._file);
/*      */     }
/*  399 */     catch (Exception ex) {
/*  400 */       if (ex instanceof MCException) {
/*  401 */         MCException mcex = (MCException)ex;
/*  402 */         handlerError(mcex.getCause(), mcex.getMCMessage());
/*      */       } else {
/*      */         
/*  405 */         handlerError(ex);
/*      */       } 
/*      */       
/*  408 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final File getLogFile(MCLogHandler.Type type, String user) {
/*  424 */     String filename = MCConfig.common.getString(type.getResourceKey("file"));
/*  425 */     if (filename == null)
/*      */     {
/*      */       
/*  428 */       return null;
/*      */     }
/*      */     
/*  431 */     filename = MCStringUtil.bind(filename, MCConfig.common.bindsrc);
/*      */ 
/*      */     
/*  434 */     String dirname = getLogDir();
/*  435 */     File dir = new File(dirname);
/*  436 */     if (!dir.exists()) {
/*  437 */       dir.mkdir();
/*      */     }
/*      */     
/*  440 */     return new File(dir, filename);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final Rotater getRotater(String user) {
/*  454 */     Map<String, List<Pattern>> group_map = MCConfig.common.getLogGroupMap();
/*  455 */     String group = MCConfig.common.getUserLogGroup(user, group_map);
/*      */ 
/*      */     
/*  458 */     String backupkey = this._type.getResourceKey("backup");
/*  459 */     if (group != null) {
/*  460 */       String k = MCConfig.createKey(new String[] { group, backupkey });
/*  461 */       if (MCConfig.common.containsKey(k)) {
/*  462 */         backupkey = k;
/*      */       }
/*      */     } 
/*  465 */     int backup = 0;
/*      */     try {
/*  467 */       String value = MCConfig.common.getString(backupkey);
/*  468 */       if (!MCStringUtil.isNull(value)) {
/*  469 */         backup = MCConfig.common.getInteger(backupkey);
/*      */       }
/*      */     }
/*  472 */     catch (MCException mCException) {
/*      */       
/*  474 */       MCMessage msg = new MCMessage(Core_Msg_FW_A.FCBJC0006, new Object[] { this._type.name(), 
/*  475 */             this._file.getAbsolutePath() });
/*      */       
/*  477 */       throw new MCException(msg);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  482 */     String rotationkey = this._type.getResourceKey("rotation");
/*  483 */     if (group != null) {
/*  484 */       String k = MCConfig.createKey(new String[] { group, rotationkey });
/*  485 */       if (MCConfig.common.containsKey(k)) {
/*  486 */         rotationkey = k;
/*      */       }
/*      */     } 
/*  489 */     String rotation = MCConfig.common.getString(rotationkey);
/*      */     
/*  491 */     return getRotater(rotation, backup);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final Rotater getRotater(String rotation, int backup) {
/*  508 */     if (MCStringUtil.isNull(rotation)) {
/*      */       
/*  510 */       MCMessage msg = new MCMessage(Core_Msg_FW_A.FCBJC0004, new Object[] { this._type.name(), 
/*  511 */             this._file.getAbsolutePath() });
/*  512 */       handlerError(msg);
/*      */       
/*  514 */       return new NoRotater();
/*      */     } 
/*      */     
/*  517 */     Rotater rotater = null;
/*      */     
/*  519 */     int pos = rotation.indexOf(',');
/*  520 */     if (pos == -1) {
/*  521 */       Matcher m = ROTATE_PATTERN.matcher(rotation);
/*  522 */       if (m.matches()) {
/*  523 */         int interval = Integer.parseInt(m.group(1));
/*  524 */         String unit = m.group(2);
/*  525 */         unit = unit.toUpperCase();
/*      */         
/*      */         try {
/*  528 */           SIZE size = (unit.length() == 0) ? SIZE.B : SIZE.valueOf(unit);
/*  529 */           rotater = getSizeRotater(interval, size, backup);
/*      */         }
/*  531 */         catch (Exception exception) {
/*      */ 
/*      */           
/*      */           try {
/*  535 */             DATE date = DATE.valueOf(unit);
/*  536 */             rotater = getDateRotater(interval, date, backup);
/*      */           }
/*  538 */           catch (Exception exception1) {}
/*      */         }
/*      */       
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/*  545 */       String date_rotation = rotation.substring(0, pos);
/*  546 */       String size_rotation = rotation.substring(pos + 1);
/*  547 */       int date_interval = -1;
/*  548 */       int size_interval = -1;
/*  549 */       DATE date = null;
/*  550 */       SIZE size = null;
/*  551 */       Matcher date_m = ROTATE_PATTERN.matcher(date_rotation);
/*  552 */       if (date_m.matches()) {
/*  553 */         int interval = Integer.parseInt(date_m.group(1));
/*  554 */         String unit = date_m.group(2);
/*  555 */         unit = unit.toUpperCase();
/*      */         try {
/*  557 */           date = (unit.length() == 0) ? DATE.D : DATE.valueOf(unit);
/*  558 */           date_interval = interval;
/*      */         }
/*  560 */         catch (Exception exception) {}
/*      */       } 
/*      */ 
/*      */       
/*  564 */       Matcher size_m = ROTATE_PATTERN.matcher(size_rotation);
/*  565 */       if (size_m.matches()) {
/*  566 */         int interval = Integer.parseInt(size_m.group(1));
/*  567 */         String unit = size_m.group(2);
/*  568 */         unit = unit.toUpperCase();
/*      */         try {
/*  570 */           size = (unit.length() == 0) ? SIZE.B : SIZE.valueOf(unit);
/*  571 */           size_interval = interval;
/*      */         }
/*  573 */         catch (Exception exception) {}
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  578 */       if (date != null && size != null) {
/*  579 */         rotater = getDateSizeRotater(date_interval, size_interval, date, size, 
/*  580 */             backup);
/*      */       }
/*      */     } 
/*      */     
/*  584 */     if (rotater == null) {
/*      */       
/*  586 */       MCMessage msg = new MCMessage(Core_Msg_FW_A.FCBJC0005, new Object[] { this._type.name(), rotation, 
/*  587 */             this._file.getAbsolutePath() });
/*      */       
/*  589 */       throw new MCException(msg);
/*      */     } 
/*      */     
/*  592 */     return rotater;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final Rotater getSizeRotater(int interval, SIZE size, int backup) {
/*  606 */     if (size == null) {
/*  607 */       size = SIZE.B;
/*      */     }
/*  609 */     long bytelen = size.bytesize(interval);
/*  610 */     return new SizeRotater(bytelen, backup);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final Rotater getDateRotater(int interval, DATE unit, int backup) {
/*  624 */     return new DateRotater(interval, unit, backup);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final Rotater getDateSizeRotater(int date_interval, int size_interval, DATE unit, SIZE size, int backup) {
/*  641 */     if (size == null) {
/*  642 */       size = SIZE.B;
/*      */     }
/*  644 */     long bytelen = size.bytesize(size_interval);
/*  645 */     return new DateSizeRotater(date_interval, unit, bytelen, backup);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void init(MCLogHandler.Type type, Rotater rotater) {
/*  658 */     String k = type.getResourceKey("init_rotation");
/*      */     
/*  660 */     boolean rotation = !(!MCConfig.common.getBoolean(k, true) && !rotater.needRotation());
/*  661 */     if (rotation) {
/*  662 */       MCMessage errmsg = this._rotater.backup();
/*  663 */       handlerError(errmsg);
/*      */     } 
/*  665 */     boolean exists = this._rotater.getCurrentFile().exists();
/*  666 */     open(exists);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean open(boolean append) {
/*  681 */     if (this._writer == null) {
/*      */       
/*  683 */       OutputStream output = this._rotater.createOutputStream(append);
/*      */       
/*  685 */       if (output != null)
/*      */       {
/*  687 */         this._writer = createWriter(output, this.charset);
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  693 */     return (this._writer != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void close() {
/*  708 */     if (this._writer != null) {
/*      */       try {
/*  710 */         this._writer.flush();
/*  711 */         this._writer.close();
/*  712 */         this._writer = null;
/*      */       }
/*  714 */       catch (IOException ex) {
/*  715 */         MCMessage msg = new MCMessage(Core_Msg_FW_A.FCBJC0015, new Object[] { this._file.getAbsoluteFile() });
/*  716 */         handlerError(ex, msg);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void rotate() {
/*  729 */     if (this._rotater != null)
/*      */     {
/*  731 */       synchronized (this) {
/*  732 */         this._rotater.forced();
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void publish(String log) {
/*  759 */     if (this._file == null) {
/*      */       return;
/*      */     }
/*      */     
/*  763 */     if (this._rotater != null) {
/*  764 */       this._rotater.rotation();
/*      */     }
/*      */     
/*  767 */     write(log);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void write(String log) {
/*  774 */     if (this._file == null) {
/*      */       return;
/*      */     }
/*      */     
/*  778 */     if (this._writer != null) {
/*      */       try {
/*  780 */         this._writer.write(log);
/*  781 */         this._writer.flush();
/*      */       }
/*  783 */       catch (IOException ex) {
/*  784 */         MCMessage msg = new MCMessage(Core_Msg_FW_A.FCBJC0014, new Object[] { this._file.getAbsoluteFile(), log });
/*  785 */         handlerError(ex, msg);
/*      */       } 
/*      */     } else {
/*      */       
/*  789 */       MCMessage msg = new MCMessage(Core_Msg_FW_A.FCBJC0014, new Object[] { this._file.getAbsoluteFile(), log });
/*  790 */       handlerError(msg);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final void follow(String log) {
/*  797 */     synchronized (this) {
/*  798 */       write(log);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final MCDate getFileCreationDate(File file) {
/*  811 */     if (file.exists()) {
/*      */       try {
/*  813 */         FileTime ft = 
/*  814 */           (FileTime)Files.getAttribute(Paths.get(file.getAbsolutePath(), new String[0]), "creationTime", new java.nio.file.LinkOption[0]);
/*      */         
/*  816 */         return 
/*  817 */           MCDate.valueOf(new Date(ft.toMillis() + MCSys.env.getMCSysTimeDiff()))
/*  818 */           .startTimeOfDay();
/*      */       }
/*  820 */       catch (IOException iOException) {
/*  821 */         return null;
/*      */       } 
/*      */     }
/*  824 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private enum RotaterType
/*      */   {
/*  840 */     SIZE,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  848 */     DATE,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  856 */     DATE_SIZE,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  864 */     NONE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private abstract class Rotater
/*      */   {
/*      */     final File[] _log_files;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Rotater(int maxbak) {
/*  890 */       maxbak = (maxbak < 0) ? 0 : maxbak;
/*  891 */       this._log_files = new File[maxbak + 1];
/*  892 */       updateBackupFiles();
/*      */     }
/*      */     
/*      */     void updateBackupFiles() {
/*  896 */       this._log_files[0] = MCLogFileHandler.this._file;
/*  897 */       File[] backup = MCLogFileHandler.this.getBackupLogFiles(this._log_files.length - 1);
/*  898 */       for (int i = 0; i < backup.length; i++) {
/*  899 */         this._log_files[i + 1] = backup[i];
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     MCMessage backup() {
/*  911 */       MCMessage errmsg = null;
/*      */       
/*  913 */       int last = this._log_files.length - 1;
/*  914 */       File delete_file = this._log_files[last];
/*  915 */       if (delete_file != null && delete_file.exists() && 
/*  916 */         !delete_file.delete())
/*      */       {
/*  918 */         errmsg = new MCMessage(Core_Msg_FW_A.FCBJC0009, new Object[] { delete_file.getAbsolutePath() });
/*      */       }
/*      */       
/*  921 */       if (errmsg == null) {
/*  922 */         for (int i = last - 1; i >= 0; i--) {
/*  923 */           File f = this._log_files[i];
/*  924 */           if (f != null && f.exists() && 
/*  925 */             !MCLogFileHandler.this.backupLogCountUp(f, this)) {
/*  926 */             errmsg = new MCMessage(Core_Msg_FW_A.FCBJC0010, new Object[] { f.getAbsolutePath() });
/*      */             
/*      */             break;
/*      */           } 
/*      */         } 
/*      */       }
/*  932 */       updateBackupFiles();
/*  933 */       return errmsg;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     abstract boolean needRotation();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     abstract MCLogFileHandler.RotaterType type();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     File getCurrentFile() {
/*  964 */       return MCLogFileHandler.this._file;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void forced() {
/*  976 */       MCLogFileHandler.this.close();
/*  977 */       MCMessage errmsg = backup();
/*      */       
/*  979 */       MCLogFileHandler.this.open((errmsg != null));
/*  980 */       MCLogFileHandler.this.handlerError(errmsg);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void rotation() {
/*  992 */       if (needRotation())
/*      */       {
/*      */         
/*  995 */         synchronized (MCLogFileHandler.this) {
/*  996 */           forced();
/*      */         } 
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     OutputStream createOutputStream(boolean append) {
/* 1013 */       File file = getCurrentFile();
/* 1014 */       FileOutputStream fo = null;
/*      */       try {
/* 1016 */         fo = new FileOutputStream(file, append);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1022 */         if (!append) {
/* 1023 */           FileTime last_modify = 
/* 1024 */             Files.getLastModifiedTime(Paths.get(file.getAbsolutePath(), new String[0]), new java.nio.file.LinkOption[0]);
/* 1025 */           Files.setAttribute(Paths.get(file.getAbsolutePath(), new String[0]), "creationTime", 
/* 1026 */               last_modify, new java.nio.file.LinkOption[0]);
/*      */         }
/*      */       
/* 1029 */       } catch (Exception ex) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1038 */         MCMessage msg = new MCMessage(Core_Msg_FW_A.FCBJC0008, new Object[] { file.getAbsolutePath() });
/* 1039 */         MCLogFileHandler.this.handlerError(ex, msg);
/*      */       } 
/* 1041 */       return fo;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private class SizeRotater
/*      */     extends Rotater
/*      */   {
/*      */     private long _size;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final long _max;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     SizeRotater(long maxsize, int maxbak) {
/* 1077 */       super(maxbak);
/*      */       
/* 1079 */       this._size = MCLogFileHandler.this._file.length();
/* 1080 */       this._max = maxsize;
/*      */     }
/*      */ 
/*      */     
/*      */     boolean needRotation() {
/* 1085 */       return (this._size >= this._max);
/*      */     }
/*      */ 
/*      */     
/*      */     MCLogFileHandler.RotaterType type() {
/* 1090 */       return MCLogFileHandler.RotaterType.SIZE;
/*      */     }
/*      */ 
/*      */     
/*      */     OutputStream createOutputStream(boolean append) {
/* 1095 */       this._size = (append ? (int)MCLogFileHandler.this._file.length() : 0L);
/* 1096 */       OutputStream os = super.createOutputStream(append);
/*      */       
/* 1098 */       return (os != null) ? new CountingOutputStream(os) : null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private class CountingOutputStream
/*      */       extends BufferedOutputStream
/*      */     {
/*      */       CountingOutputStream(OutputStream out) {
/* 1118 */         super(out);
/*      */       }
/*      */ 
/*      */       
/*      */       public synchronized void write(int b) throws IOException {
/* 1123 */         super.write(b);
/* 1124 */         MCLogFileHandler.SizeRotater.this._size = MCLogFileHandler.SizeRotater.this._size + 1L;
/*      */       }
/*      */ 
/*      */       
/*      */       public void write(byte[] buff) throws IOException {
/* 1129 */         super.write(buff);
/* 1130 */         MCLogFileHandler.SizeRotater.this._size = MCLogFileHandler.SizeRotater.this._size + buff.length;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       public synchronized void write(byte[] buff, int off, int len) throws IOException {
/* 1136 */         super.write(buff, off, len);
/* 1137 */         MCLogFileHandler.SizeRotater.this._size = MCLogFileHandler.SizeRotater.this._size + len;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private class DateRotater
/*      */     extends Rotater
/*      */   {
/*      */     private final int _interval;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final MCDateFieldType _field;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private MCDate _creation_date;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private MCDate _rotation_date;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     DateRotater(int interval, MCLogFileHandler.DATE unit, int maxbak) {
/* 1190 */       super(maxbak);
/*      */ 
/*      */       
/* 1193 */       this._interval = interval;
/* 1194 */       switch (unit) {
/*      */         case Y:
/* 1196 */           this._field = MCDateFieldType.YEAR;
/*      */           break;
/*      */         case M:
/* 1199 */           this._field = MCDateFieldType.MONTH;
/*      */           break;
/*      */         case null:
/* 1202 */           this._field = MCDateFieldType.DAY;
/*      */           break;
/*      */         default:
/* 1205 */           this._field = null;
/*      */           break;
/*      */       } 
/*      */       
/* 1209 */       setRotationDate();
/*      */     }
/*      */ 
/*      */     
/*      */     boolean needRotation() {
/* 1214 */       if (this._rotation_date != null) {
/* 1215 */         MCDate today = MCDate.systoday();
/*      */         
/* 1217 */         return (today.compareToLeft((MCCalendarDate)this._rotation_date, MCDateFieldType.DAY) >= 0);
/*      */       } 
/* 1219 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     MCLogFileHandler.RotaterType type() {
/* 1224 */       return MCLogFileHandler.RotaterType.DATE;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     OutputStream createOutputStream(boolean append) {
/* 1231 */       OutputStream result = super.createOutputStream(append);
/* 1232 */       setRotationDate();
/* 1233 */       return result;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void setRotationDate() {
/* 1244 */       this._creation_date = MCLogFileHandler.this.getFileCreationDate(getCurrentFile());
/* 1245 */       if (this._creation_date != null) {
/* 1246 */         switch (this._field) {
/*      */           case YEAR:
/* 1248 */             this._rotation_date = (MCDate)this._creation_date.addYear(this._interval);
/*      */             return;
/*      */           case MONTH:
/* 1251 */             this._rotation_date = (MCDate)this._creation_date.addMonth(this._interval);
/*      */             return;
/*      */           case null:
/* 1254 */             this._rotation_date = (MCDate)this._creation_date.addDay(this._interval);
/*      */             return;
/*      */         } 
/* 1257 */         this._rotation_date = null;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private class DateSizeRotater
/*      */     extends DateRotater
/*      */   {
/*      */     private long _size;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final long _max;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     DateSizeRotater(int interval, MCLogFileHandler.DATE unit, long maxsize, int maxbak) {
/* 1302 */       super(interval, unit, maxbak);
/*      */       
/* 1304 */       this._size = MCLogFileHandler.this._file.length();
/* 1305 */       this._max = maxsize;
/*      */     }
/*      */ 
/*      */     
/*      */     boolean needRotation() {
/* 1310 */       return !(!super.needRotation() && this._size < this._max);
/*      */     }
/*      */ 
/*      */     
/*      */     MCLogFileHandler.RotaterType type() {
/* 1315 */       return MCLogFileHandler.RotaterType.DATE_SIZE;
/*      */     }
/*      */ 
/*      */     
/*      */     OutputStream createOutputStream(boolean append) {
/* 1320 */       this._size = (append ? (int)MCLogFileHandler.this._file.length() : 0L);
/* 1321 */       OutputStream os = super.createOutputStream(append);
/*      */       
/* 1323 */       return (os != null) ? new CountingOutputStream(os) : null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private class CountingOutputStream
/*      */       extends BufferedOutputStream
/*      */     {
/*      */       CountingOutputStream(OutputStream out) {
/* 1344 */         super(out);
/*      */       }
/*      */ 
/*      */       
/*      */       public synchronized void write(int b) throws IOException {
/* 1349 */         super.write(b);
/* 1350 */         MCLogFileHandler.DateSizeRotater.this._size = MCLogFileHandler.DateSizeRotater.this._size + 1L;
/*      */       }
/*      */ 
/*      */       
/*      */       public void write(byte[] buff) throws IOException {
/* 1355 */         super.write(buff);
/* 1356 */         MCLogFileHandler.DateSizeRotater.this._size = MCLogFileHandler.DateSizeRotater.this._size + buff.length;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*      */       public synchronized void write(byte[] buff, int off, int len) throws IOException {
/* 1362 */         super.write(buff, off, len);
/* 1363 */         MCLogFileHandler.DateSizeRotater.this._size = MCLogFileHandler.DateSizeRotater.this._size + len;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final File[] getBackupLogFiles(int maxbak) {
/* 1377 */     File[] result = new File[maxbak];
/*      */     
/* 1379 */     String name = this._file.getAbsolutePath();
/* 1380 */     String prefix = "";
/* 1381 */     String suffix = "";
/* 1382 */     int extpos = name.lastIndexOf('.');
/* 1383 */     if (extpos >= 0) {
/* 1384 */       suffix = name.substring(extpos);
/* 1385 */       prefix = name.substring(0, extpos);
/*      */       
/* 1387 */       File dir = this._file.getParentFile();
/* 1388 */       File[] logs = dir.listFiles();
/* 1389 */       for (int i = 0; i < maxbak; i++) {
/* 1390 */         result[i] = getBackupLogFile(logs, prefix, suffix, i + 1);
/*      */       }
/*      */     } 
/* 1393 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final File getBackupLogFile(File[] logs, String prefix, String suffix, int bak) {
/* 1409 */     prefix = String.valueOf(prefix) + "." + bak; byte b; int i; File[] arrayOfFile;
/* 1410 */     for (i = (arrayOfFile = logs).length, b = 0; b < i; ) { File f = arrayOfFile[b];
/* 1411 */       String name = f.getAbsolutePath();
/*      */       
/* 1413 */       if (MCStringUtil.same(name, String.valueOf(prefix) + suffix)) {
/* 1414 */         return f;
/*      */       }
/*      */       
/* 1417 */       if (name.startsWith(String.valueOf(prefix) + ".") && name.endsWith(suffix)) {
/* 1418 */         int begin = prefix.length() + ".".length();
/* 1419 */         int end = name.length() - suffix.length();
/* 1420 */         String date_str = name.substring(begin, end);
/* 1421 */         if (!MCStringUtil.isNull(date_str) && 
/* 1422 */           date_str.matches("[0-9]{4}-[0-9]{2}-[0-9]{2}"))
/* 1423 */           return f; 
/*      */       } 
/*      */       b++; }
/*      */     
/* 1427 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean backupLogCountUp(File file, Rotater rotater) {
/* 1442 */     String name = this._file.getAbsolutePath();
/* 1443 */     String prefix = "";
/* 1444 */     String suffix = "";
/* 1445 */     int extpos = name.lastIndexOf('.');
/* 1446 */     if (extpos >= 0) {
/* 1447 */       suffix = name.substring(extpos);
/* 1448 */       prefix = name.substring(0, extpos);
/*      */     } 
/*      */     
/* 1451 */     String n = file.getAbsolutePath();
/* 1452 */     if (n.startsWith(prefix) && n.endsWith(suffix)) {
/* 1453 */       int begin = prefix.length() + 1;
/* 1454 */       int end = n.length() - suffix.length();
/* 1455 */       if (begin > end) {
/* 1456 */         MCDate mCDate; switch (rotater.type()) {
/*      */           case null:
/*      */           case DATE_SIZE:
/* 1459 */             mCDate = getFileCreationDate(file);
/* 1460 */             if (mCDate == null) {
/* 1461 */               mCDate = MCDate.today();
/*      */             }
/* 1463 */             return file.renameTo(new File(String.valueOf(prefix) + "." + '\001' + "." + 
/* 1464 */                   mCDate.toString("yyyy-MM-dd") + suffix));
/*      */         } 
/* 1466 */         return file.renameTo(new File(String.valueOf(prefix) + "." + '\001' + suffix));
/*      */       } 
/*      */       
/* 1469 */       String count_str = n.substring(begin, end);
/* 1470 */       int sep = count_str.indexOf(".");
/* 1471 */       if (sep == -1) {
/* 1472 */         int i = Integer.parseInt(count_str);
/* 1473 */         i++;
/* 1474 */         return file.renameTo(new File(String.valueOf(prefix) + "." + i + suffix));
/*      */       } 
/*      */       
/* 1477 */       String date = count_str.substring(sep);
/* 1478 */       count_str = count_str.substring(0, sep);
/* 1479 */       int count = Integer.parseInt(count_str);
/* 1480 */       count++;
/* 1481 */       return file
/* 1482 */         .renameTo(new File(String.valueOf(prefix) + "." + count + date + suffix));
/*      */     } 
/*      */     
/* 1485 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private class NoRotater
/*      */     extends Rotater
/*      */   {
/*      */     NoRotater() {
/* 1497 */       super(0);
/*      */     }
/*      */ 
/*      */     
/*      */     MCMessage backup() {
/* 1502 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     boolean needRotation() {
/* 1507 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     MCLogFileHandler.RotaterType type() {
/* 1512 */       return MCLogFileHandler.RotaterType.NONE;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\notice\MCLogFileHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */