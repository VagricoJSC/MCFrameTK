/*     */ package mcframe.commonCore.notice;
/*     */ 
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCServerException
/*     */   extends MCException
/*     */ {
/*     */   public MCServerException(Throwable cause) {
/*  25 */     this(cause, (MCMessage)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCServerException(String msgid, Object... values) {
/*  37 */     super(msgid, values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCServerException(MCRow causerow, String causecol, String msgid, Object... values) {
/*  52 */     super(causerow, causecol, msgid, values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCServerException(Throwable cause, String msgid, Object... values) {
/*  67 */     super(cause, msgid, values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCServerException(Throwable cause, MCRow causerow, String causecol, String msgid, Object... values) {
/*  85 */     super(cause, causerow, causecol, msgid, values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCServerException(MCMessage msg) {
/*  96 */     super(msg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCServerException(Throwable cause, MCMessage msg) {
/* 110 */     super(cause, msg);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\notice\MCServerException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */