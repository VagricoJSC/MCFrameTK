/*     */ package mcframe.commonCore.notice;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCCalendarDate;
/*     */ import mcframe.commonCore.lang.MCTimestamp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MCLogConditionR_FW
/*     */   extends MCLogConditionR_FW_A
/*     */ {
/*     */   Pattern pMsgId;
/*     */   Pattern pAnMsgId;
/*     */   Pattern pMsgLvl;
/*     */   Pattern pReqNo;
/*     */   
/*     */   protected MCLogConditionR_FW(MCRow.ConstMetaList<? extends MCLogConditionR> metas) {
/*  24 */     super(metas);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 137 */     this.pMsgId = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 165 */     this.pAnMsgId = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 194 */     this.pMsgLvl = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 223 */     this.pReqNo = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 254 */     this.pThreadNo = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 285 */     this.pCoCd = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 313 */     this.pClsNm = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 341 */     this.pMetNm = null;
/*     */   }
/*     */ 
/*     */   
/*     */   Pattern pThreadNo;
/*     */   
/*     */   Pattern pCoCd;
/*     */   
/*     */   Pattern pClsNm;
/*     */   Pattern pMetNm;
/*     */   
/*     */   boolean matchMethodNm(MCLogR r) {
/* 353 */     if (method_nm() == null) {
/* 354 */       return true;
/*     */     }
/* 356 */     if (r.method_nm() == null) {
/* 357 */       return false;
/*     */     }
/* 359 */     if (this.pMetNm == null) {
/* 360 */       this.pMetNm = Pattern.compile(method_nm());
/*     */     }
/* 362 */     Matcher matcher = this.pMetNm.matcher(r.method_nm());
/* 363 */     if (matcher.find()) {
/* 364 */       return true;
/*     */     }
/* 366 */     return false;
/*     */   }
/*     */   
/*     */   public boolean matchCond(MCLogR r) {
/*     */     if (log_ts_from() != null && log_ts_from().gt((MCCalendarDate)r.log_ts(), new mcframe.commonCore.lang.MCDateFieldType[0]))
/*     */       return false; 
/*     */     if (log_ts_to() != null && log_ts_to().lt((MCCalendarDate)r.log_ts(), new mcframe.commonCore.lang.MCDateFieldType[0]))
/*     */       return false; 
/*     */     if (!matchMsgId(r))
/*     */       return false; 
/*     */     if (!matchMsgLvl(r))
/*     */       return false; 
/*     */     if (!matchReqNo(r))
/*     */       return false; 
/*     */     if (!matchThreadNo(r))
/*     */       return false; 
/*     */     if (!matchCoCd(r))
/*     */       return false; 
/*     */     if (!matchClassNm(r))
/*     */       return false; 
/*     */     if (!matchMethodNm(r))
/*     */       return false; 
/*     */     return true;
/*     */   }
/*     */   
/*     */   boolean matchMsgId(MCLogR r) {
/*     */     if (msg_id() == null)
/*     */       return matchAnMsgId(r); 
/*     */     if (r.msg_id() == null)
/*     */       return false; 
/*     */     if (this.pMsgId == null)
/*     */       this.pMsgId = Pattern.compile(msg_id()); 
/*     */     Matcher matcher = this.pMsgId.matcher(r.msg_id());
/*     */     if (matcher.find())
/*     */       return true; 
/*     */     return false;
/*     */   }
/*     */   
/*     */   boolean matchAnMsgId(MCLogR r) {
/*     */     if (an_msg_id() == null)
/*     */       return true; 
/*     */     if (r.msg_id() == null)
/*     */       return false; 
/*     */     if (this.pAnMsgId == null)
/*     */       this.pAnMsgId = Pattern.compile(an_msg_id()); 
/*     */     Matcher matcher = this.pAnMsgId.matcher(r.msg_id());
/*     */     if (matcher.find())
/*     */       return false; 
/*     */     return true;
/*     */   }
/*     */   
/*     */   boolean matchMsgLvl(MCLogR r) {
/*     */     if (msg_lvl() == null)
/*     */       return true; 
/*     */     if (r.msg_lvl() == null)
/*     */       return false; 
/*     */     if (this.pMsgLvl == null)
/*     */       this.pMsgLvl = Pattern.compile(msg_lvl()); 
/*     */     Matcher matcher = this.pMsgLvl.matcher(r.msg_lvl());
/*     */     if (matcher.find())
/*     */       return true; 
/*     */     return false;
/*     */   }
/*     */   
/*     */   boolean matchReqNo(MCLogR r) {
/*     */     if (req_no() == null)
/*     */       return true; 
/*     */     if (r.req_no() == null)
/*     */       return false; 
/*     */     if (this.pReqNo == null)
/*     */       this.pReqNo = Pattern.compile(req_no()); 
/*     */     Matcher matcher = this.pReqNo.matcher(r.req_no());
/*     */     if (matcher.find())
/*     */       return true; 
/*     */     return false;
/*     */   }
/*     */   
/*     */   boolean matchThreadNo(MCLogR r) {
/*     */     if (thread_no() == null)
/*     */       return true; 
/*     */     if (r.thread_no() == null)
/*     */       return false; 
/*     */     if (this.pThreadNo == null)
/*     */       this.pThreadNo = Pattern.compile(thread_no()); 
/*     */     Matcher matcher = this.pThreadNo.matcher(r.thread_no());
/*     */     if (matcher.find())
/*     */       return true; 
/*     */     return false;
/*     */   }
/*     */   
/*     */   boolean matchCoCd(MCLogR r) {
/*     */     if (co_cd() == null)
/*     */       return true; 
/*     */     if (r.co_cd() == null)
/*     */       return false; 
/*     */     if (this.pCoCd == null)
/*     */       this.pCoCd = Pattern.compile(co_cd()); 
/*     */     Matcher matcher = this.pCoCd.matcher(r.co_cd());
/*     */     if (matcher.find())
/*     */       return true; 
/*     */     return false;
/*     */   }
/*     */   
/*     */   boolean matchClassNm(MCLogR r) {
/*     */     if (class_nm() == null)
/*     */       return true; 
/*     */     if (r.class_nm() == null)
/*     */       return false; 
/*     */     if (this.pClsNm == null)
/*     */       this.pClsNm = Pattern.compile(class_nm()); 
/*     */     Matcher matcher = this.pClsNm.matcher(r.class_nm());
/*     */     if (matcher.find())
/*     */       return true; 
/*     */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\notice\MCLogConditionR_FW.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */