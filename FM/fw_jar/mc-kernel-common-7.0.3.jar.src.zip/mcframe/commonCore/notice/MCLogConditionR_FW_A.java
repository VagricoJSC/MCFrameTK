/*     */ package mcframe.commonCore.notice;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.commonCore.container.MCConstRow;
/*     */ import mcframe.commonCore.container.MCExtMap;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCTimestamp;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ import mcframe.commonCore.meta.M_META;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class MCLogConditionR_FW_A
/*     */   extends MCConstRow
/*     */ {
/*     */   public static final String $log_ts_from = "log_ts_from";
/*     */   public static final String $log_ts_to = "log_ts_to";
/*     */   public static final String $req_no = "req_no";
/*     */   public static final String $thread_no = "thread_no";
/*     */   public static final String $co_cd = "co_cd";
/*     */   public static final String $msg_lvl = "msg_lvl";
/*     */   public static final String $msg_id = "msg_id";
/*     */   public static final String $an_msg_id = "an_msg_id";
/*     */   public static final String $class_nm = "class_nm";
/*     */   public static final String $method_nm = "method_nm";
/*     */   public static final String $operation_id = "operation_id";
/*     */   public static final String $button_id = "button_id";
/*  90 */   public static final MCMeta log_ts_from_META = createCommonMeta("log_ts_from", M_META.TS);
/*  91 */   public static final MCMeta log_ts_to_META = createCommonMeta("log_ts_to", M_META.TS);
/*  92 */   public static final MCMeta req_no_META = createCommonMeta("req_no", M_META.SRV_REQ_NO);
/*  93 */   public static final MCMeta thread_no_META = createCommonMeta("thread_no", M_META.THREAD_NO);
/*  94 */   public static final MCMeta co_cd_META = createCommonMeta("co_cd", M_META.CO_CD);
/*  95 */   public static final MCMeta msg_lvl_META = createCommonMeta("msg_lvl", M_META.MSG_LVL);
/*  96 */   public static final MCMeta msg_id_META = createCommonMeta("msg_id", M_META.MSG_ID);
/*  97 */   public static final MCMeta an_msg_id_META = createCommonMeta("an_msg_id", M_META.MSG_ID);
/*  98 */   public static final MCMeta class_nm_META = createCommonMeta("class_nm", M_META.CLASS_NM);
/*  99 */   public static final MCMeta method_nm_META = createCommonMeta("method_nm", M_META.METHOD_NM);
/* 100 */   public static final MCMeta operation_id_META = createCommonMeta("operation_id", M_META.OPERATION_ID);
/* 101 */   public static final MCMeta button_id_META = createCommonMeta("button_id", M_META.BUTTON_NAME);
/*     */   
/* 103 */   protected static final MCRow.ConstMetaList<MCLogConditionR> constMetas = new MCRow.ConstMetaList(
/* 104 */       MCConstRow.constMetas, 
/* 105 */       new MCMeta[] { 
/* 106 */         log_ts_from_META, 
/* 107 */         log_ts_to_META, 
/* 108 */         req_no_META, 
/* 109 */         thread_no_META, 
/* 110 */         co_cd_META, 
/* 111 */         msg_lvl_META, 
/* 112 */         msg_id_META, 
/* 113 */         an_msg_id_META, 
/* 114 */         class_nm_META, 
/* 115 */         method_nm_META, 
/* 116 */         operation_id_META, 
/* 117 */         button_id_META
/*     */       },
/* 119 */       new String[][] { {}, {} });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 131 */   protected static final MCExtMap EXTMAP = new MCExtMap(
/* 132 */       null, new MCExtMap.Entry[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] colnames() {
/* 144 */     return constMetas.toNameArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMeta[] colmetas() {
/* 156 */     return constMetas.toMetaArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 162 */   private static final int offset = constMetas.offset();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getExtMap(String aGroup) {
/* 168 */     if (aGroup == null) return null; 
/* 169 */     return (Map<String, String>)EXTMAP.get(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getKeys(String aGroup) {
/* 176 */     if (aGroup == null) return null; 
/* 177 */     return EXTMAP.getKeyList(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExtGroups() {
/* 184 */     Set<String> ret = EXTMAP.keySet();
/* 185 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCLogConditionR_FW_A(MCRow.ConstMetaList<? extends MCLogConditionR> metas) {
/* 192 */     super(metas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCLogConditionR clone() {
/* 199 */     return (MCLogConditionR)super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCLogConditionR createInstance() {
/* 206 */     return (MCLogConditionR)super.createInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCLogConditionR getValues(String... names) {
/* 213 */     return (MCLogConditionR)super.getValues(names);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireValueChanged(String column, Comparable<?> newvalue, Comparable<?> oldvalue) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCTimestamp log_ts_from() {
/* 229 */     return getConstTimestamp(offset + 0, "log_ts_from");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void log_ts_from(MCTimestamp value) {
/* 237 */     setConstTimestamp(offset + 0, "log_ts_from", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCTimestamp log_ts_to() {
/* 246 */     return getConstTimestamp(offset + 1, "log_ts_to");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void log_ts_to(MCTimestamp value) {
/* 254 */     setConstTimestamp(offset + 1, "log_ts_to", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String req_no() {
/* 263 */     return getConstString(offset + 2, "req_no");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void req_no(String value) {
/* 271 */     setConstString(offset + 2, "req_no", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String thread_no() {
/* 280 */     return getConstString(offset + 3, "thread_no");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void thread_no(String value) {
/* 288 */     setConstString(offset + 3, "thread_no", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String co_cd() {
/* 297 */     return getConstString(offset + 4, "co_cd");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void co_cd(String value) {
/* 305 */     setConstString(offset + 4, "co_cd", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String msg_lvl() {
/* 314 */     return getConstString(offset + 5, "msg_lvl");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void msg_lvl(String value) {
/* 322 */     setConstString(offset + 5, "msg_lvl", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String msg_id() {
/* 331 */     return getConstString(offset + 6, "msg_id");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void msg_id(String value) {
/* 339 */     setConstString(offset + 6, "msg_id", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String an_msg_id() {
/* 348 */     return getConstString(offset + 7, "an_msg_id");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void an_msg_id(String value) {
/* 356 */     setConstString(offset + 7, "an_msg_id", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String class_nm() {
/* 365 */     return getConstString(offset + 8, "class_nm");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void class_nm(String value) {
/* 373 */     setConstString(offset + 8, "class_nm", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String method_nm() {
/* 382 */     return getConstString(offset + 9, "method_nm");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void method_nm(String value) {
/* 390 */     setConstString(offset + 9, "method_nm", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String operation_id() {
/* 399 */     return getConstString(offset + 10, "operation_id");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void operation_id(String value) {
/* 407 */     setConstString(offset + 10, "operation_id", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String button_id() {
/* 416 */     return getConstString(offset + 11, "button_id");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void button_id(String value) {
/* 424 */     setConstString(offset + 11, "button_id", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString(String name) {
/* 429 */     if ("req_no".equalsIgnoreCase(name)) {
/* 430 */       return req_no();
/*     */     }
/* 432 */     if ("thread_no".equalsIgnoreCase(name)) {
/* 433 */       return thread_no();
/*     */     }
/* 435 */     if ("co_cd".equalsIgnoreCase(name)) {
/* 436 */       return co_cd();
/*     */     }
/* 438 */     if ("msg_lvl".equalsIgnoreCase(name)) {
/* 439 */       return msg_lvl();
/*     */     }
/* 441 */     if ("msg_id".equalsIgnoreCase(name)) {
/* 442 */       return msg_id();
/*     */     }
/* 444 */     if ("an_msg_id".equalsIgnoreCase(name)) {
/* 445 */       return an_msg_id();
/*     */     }
/* 447 */     if ("class_nm".equalsIgnoreCase(name)) {
/* 448 */       return class_nm();
/*     */     }
/* 450 */     if ("method_nm".equalsIgnoreCase(name)) {
/* 451 */       return method_nm();
/*     */     }
/* 453 */     if ("operation_id".equalsIgnoreCase(name)) {
/* 454 */       return operation_id();
/*     */     }
/* 456 */     if ("button_id".equalsIgnoreCase(name)) {
/* 457 */       return button_id();
/*     */     }
/* 459 */     return super.getString(name);
/*     */   }
/*     */   public MCTimestamp getTimestamp(String name) {
/* 462 */     if ("log_ts_from".equalsIgnoreCase(name)) {
/* 463 */       return log_ts_from();
/*     */     }
/* 465 */     if ("log_ts_to".equalsIgnoreCase(name)) {
/* 466 */       return log_ts_to();
/*     */     }
/* 468 */     return super.getTimestamp(name);
/*     */   }
/*     */   
/*     */   public String getStringNE(String name) {
/* 472 */     if ("req_no".equalsIgnoreCase(name)) {
/* 473 */       return req_no();
/*     */     }
/* 475 */     if ("thread_no".equalsIgnoreCase(name)) {
/* 476 */       return thread_no();
/*     */     }
/* 478 */     if ("co_cd".equalsIgnoreCase(name)) {
/* 479 */       return co_cd();
/*     */     }
/* 481 */     if ("msg_lvl".equalsIgnoreCase(name)) {
/* 482 */       return msg_lvl();
/*     */     }
/* 484 */     if ("msg_id".equalsIgnoreCase(name)) {
/* 485 */       return msg_id();
/*     */     }
/* 487 */     if ("an_msg_id".equalsIgnoreCase(name)) {
/* 488 */       return an_msg_id();
/*     */     }
/* 490 */     if ("class_nm".equalsIgnoreCase(name)) {
/* 491 */       return class_nm();
/*     */     }
/* 493 */     if ("method_nm".equalsIgnoreCase(name)) {
/* 494 */       return method_nm();
/*     */     }
/* 496 */     if ("operation_id".equalsIgnoreCase(name)) {
/* 497 */       return operation_id();
/*     */     }
/* 499 */     if ("button_id".equalsIgnoreCase(name)) {
/* 500 */       return button_id();
/*     */     }
/* 502 */     return super.getStringNE(name);
/*     */   }
/*     */   public MCTimestamp getTimestampNE(String name) {
/* 505 */     if ("log_ts_from".equalsIgnoreCase(name)) {
/* 506 */       return log_ts_from();
/*     */     }
/* 508 */     if ("log_ts_to".equalsIgnoreCase(name)) {
/* 509 */       return log_ts_to();
/*     */     }
/* 511 */     return super.getTimestampNE(name);
/*     */   }
/*     */   
/*     */   public void setString(String name, String value) {
/* 515 */     if ("req_no".equalsIgnoreCase(name)) {
/* 516 */       req_no(value);
/*     */       return;
/*     */     } 
/* 519 */     if ("thread_no".equalsIgnoreCase(name)) {
/* 520 */       thread_no(value);
/*     */       return;
/*     */     } 
/* 523 */     if ("co_cd".equalsIgnoreCase(name)) {
/* 524 */       co_cd(value);
/*     */       return;
/*     */     } 
/* 527 */     if ("msg_lvl".equalsIgnoreCase(name)) {
/* 528 */       msg_lvl(value);
/*     */       return;
/*     */     } 
/* 531 */     if ("msg_id".equalsIgnoreCase(name)) {
/* 532 */       msg_id(value);
/*     */       return;
/*     */     } 
/* 535 */     if ("an_msg_id".equalsIgnoreCase(name)) {
/* 536 */       an_msg_id(value);
/*     */       return;
/*     */     } 
/* 539 */     if ("class_nm".equalsIgnoreCase(name)) {
/* 540 */       class_nm(value);
/*     */       return;
/*     */     } 
/* 543 */     if ("method_nm".equalsIgnoreCase(name)) {
/* 544 */       method_nm(value);
/*     */       return;
/*     */     } 
/* 547 */     if ("operation_id".equalsIgnoreCase(name)) {
/* 548 */       operation_id(value);
/*     */       return;
/*     */     } 
/* 551 */     if ("button_id".equalsIgnoreCase(name)) {
/* 552 */       button_id(value);
/*     */       return;
/*     */     } 
/* 555 */     super.setString(name, value);
/*     */   }
/*     */   public void setTimestamp(String name, MCTimestamp value) {
/* 558 */     if ("log_ts_from".equalsIgnoreCase(name)) {
/* 559 */       log_ts_from(value);
/*     */       return;
/*     */     } 
/* 562 */     if ("log_ts_to".equalsIgnoreCase(name)) {
/* 563 */       log_ts_to(value);
/*     */       return;
/*     */     } 
/* 566 */     super.setTimestamp(name, value);
/*     */   }
/*     */   
/*     */   public void setStringNE(String name, String value) {
/* 570 */     if ("req_no".equalsIgnoreCase(name)) {
/* 571 */       req_no(value);
/*     */       return;
/*     */     } 
/* 574 */     if ("thread_no".equalsIgnoreCase(name)) {
/* 575 */       thread_no(value);
/*     */       return;
/*     */     } 
/* 578 */     if ("co_cd".equalsIgnoreCase(name)) {
/* 579 */       co_cd(value);
/*     */       return;
/*     */     } 
/* 582 */     if ("msg_lvl".equalsIgnoreCase(name)) {
/* 583 */       msg_lvl(value);
/*     */       return;
/*     */     } 
/* 586 */     if ("msg_id".equalsIgnoreCase(name)) {
/* 587 */       msg_id(value);
/*     */       return;
/*     */     } 
/* 590 */     if ("an_msg_id".equalsIgnoreCase(name)) {
/* 591 */       an_msg_id(value);
/*     */       return;
/*     */     } 
/* 594 */     if ("class_nm".equalsIgnoreCase(name)) {
/* 595 */       class_nm(value);
/*     */       return;
/*     */     } 
/* 598 */     if ("method_nm".equalsIgnoreCase(name)) {
/* 599 */       method_nm(value);
/*     */       return;
/*     */     } 
/* 602 */     if ("operation_id".equalsIgnoreCase(name)) {
/* 603 */       operation_id(value);
/*     */       return;
/*     */     } 
/* 606 */     if ("button_id".equalsIgnoreCase(name)) {
/* 607 */       button_id(value);
/*     */       return;
/*     */     } 
/* 610 */     super.setStringNE(name, value);
/*     */   }
/*     */   public void setTimestampNE(String name, MCTimestamp value) {
/* 613 */     if ("log_ts_from".equalsIgnoreCase(name)) {
/* 614 */       log_ts_from(value);
/*     */       return;
/*     */     } 
/* 617 */     if ("log_ts_to".equalsIgnoreCase(name)) {
/* 618 */       log_ts_to(value);
/*     */       return;
/*     */     } 
/* 621 */     super.setTimestampNE(name, value);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\notice\MCLogConditionR_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */