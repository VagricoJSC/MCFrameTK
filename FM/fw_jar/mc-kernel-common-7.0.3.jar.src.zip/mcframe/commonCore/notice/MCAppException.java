/*     */ package mcframe.commonCore.notice;
/*     */ 
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCAppException
/*     */   extends MCException
/*     */ {
/*     */   public MCAppException(Throwable cause) {
/*  25 */     this(cause, (MCMessage)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCAppException(String msgid, Object... values) {
/*  37 */     super(msgid, values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCAppException(MCRow causerow, String causecol, String msgid, Object... values) {
/*  52 */     super(causerow, causecol, msgid, values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCAppException(Throwable cause, String msgid, Object... values) {
/*  67 */     super(cause, msgid, values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCAppException(Throwable cause, MCRow causerow, String causecol, String msgid, Object... values) {
/*  85 */     super(cause, causerow, causecol, msgid, values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCAppException(MCMessage msg) {
/*  96 */     super(msg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCAppException(Throwable cause, MCMessage msg) {
/* 110 */     super(cause, msg);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\notice\MCAppException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */