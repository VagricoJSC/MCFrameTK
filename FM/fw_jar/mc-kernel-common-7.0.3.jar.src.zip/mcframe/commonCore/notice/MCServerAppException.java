/*     */ package mcframe.commonCore.notice;
/*     */ 
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCServerAppException
/*     */   extends MCAppException
/*     */ {
/*     */   public MCServerAppException(Throwable cause) {
/*  24 */     this(cause, (MCMessage)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCServerAppException(String msgid, Object... values) {
/*  36 */     super(msgid, values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCServerAppException(MCRow causerow, String causecol, String msgid, Object... values) {
/*  51 */     super(causerow, causecol, msgid, values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCServerAppException(Throwable cause, String msgid, Object... values) {
/*  66 */     super(cause, msgid, values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCServerAppException(Throwable cause, MCRow causerow, String causecol, String msgid, Object... values) {
/*  84 */     super(cause, causerow, causecol, msgid, values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCServerAppException(MCMessage msg) {
/*  95 */     super(msg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCServerAppException(Throwable cause, MCMessage msg) {
/* 109 */     super(cause, msg);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\notice\MCServerAppException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */