/*     */ package mcframe.commonCore.notice;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCException
/*     */   extends RuntimeException
/*     */ {
/*     */   private final MCMessage _msg;
/*     */   
/*     */   public static MCException getInvocationTargetMCException(InvocationTargetException e) {
/*  45 */     return getInvocationTargetMCException(e, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCException getInvocationTargetMCException(InvocationTargetException e, String wrapid, Object... binds) {
/*  71 */     return getInvocationTargetMCException(e, new MCMessage(wrapid, binds));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCException getInvocationTargetMCException(InvocationTargetException e, MCMessage wrap) {
/*  95 */     Throwable t = e.getTargetException();
/*  96 */     if (t instanceof Error) {
/*  97 */       throw (Error)t;
/*     */     }
/*  99 */     return (t instanceof MCException) ? 
/*     */       
/* 101 */       (MCException)t : 
/*     */       
/* 103 */       new MCException(e, wrap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final MCMessage createSystemExceptionMessage(Throwable ex) {
/* 115 */     return new MCMessage(Core_Msg_FW_A.FCBJC0028, new Object[] { ex });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 131 */   private MCMessageList _msglist = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCException() {
/* 143 */     this._msg = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCException(Throwable cause) {
/* 157 */     this(cause, (MCMessage)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCException(String msgid, Object... values) {
/* 169 */     this(null, msgid, values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCException(MCRow causerow, String causecol, String msgid, Object... values) {
/* 184 */     this(null, causerow, causecol, msgid, values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCException(Throwable cause, String msgid, Object... values) {
/* 199 */     this(cause, null, null, msgid, values);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCException(Throwable cause, MCRow causerow, String causecol, String msgid, Object... values) {
/* 217 */     super(msgid, cause);
/* 218 */     this._msg = (msgid != null) ? 
/* 219 */       new MCMessage(causerow, causecol, msgid, values) : 
/* 220 */       getWrapedMessage(cause);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCException(MCMessage msg) {
/* 231 */     this((Throwable)null, msg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCException(Throwable cause, MCMessage msg) {
/* 245 */     super((msg != null) ? msg.getID() : null, cause);
/* 246 */     this._msg = (msg != null) ? msg : getWrapedMessage(cause);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCMessage getWrapedMessage(Throwable cause) {
/* 258 */     return (cause != null) ? 
/*     */       
/* 260 */       createSystemExceptionMessage(cause) : 
/*     */       
/* 262 */       new MCMessage(Core_Msg_FW_A.FCBJC0029, new Object[0]);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessage() {
/* 267 */     return "(" + this._msg.getID() + ") " + this._msg.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCMessage getMCMessage() {
/* 280 */     return this._msg;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getID() {
/* 291 */     return this._msg.getID();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCMessageLevel getLevel() {
/* 302 */     return this._msg.getLevel();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getBind(int index) {
/* 315 */     return this._msg.getBind(index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String[] getBindArray() {
/* 328 */     return this._msg.getBindArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCException addBind(Object... values) {
/* 340 */     this._msg.addBind(values);
/* 341 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCException setBind(int index, Object values) {
/* 357 */     this._msg.setBind(index, values);
/* 358 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setBind(Object... binds) {
/* 374 */     this._msg.setBind(binds);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCRow getCauseRow() {
/* 389 */     return this._msg.getCauseRow();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getCauseColumn() {
/* 405 */     return this._msg.getCauseColumn();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCException setCauseRow(MCRow row, String col) {
/* 418 */     this._msg.setCauseRow(row, col);
/* 419 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCMessageList getCauseMessageList() {
/* 433 */     if (this._msglist == null) {
/* 434 */       this._msglist = new MCMessageList();
/*     */     }
/* 436 */     return (MCMessageList)this._msglist.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setCauseMessageList(MCMessageList list) {
/* 452 */     if (this._msglist == null) {
/* 453 */       this._msglist = new MCMessageList();
/*     */     }
/* 455 */     this._msglist.clear();
/* 456 */     if (list != null) {
/* 457 */       this._msglist.addAll(list);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void addCauseMessageList(MCMessageList list) {
/* 474 */     if (this._msglist == null) {
/* 475 */       this._msglist = new MCMessageList();
/*     */     }
/* 477 */     if (list != null) {
/* 478 */       this._msglist.addAll(list);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void addCauseMessage(MCMessage msg) {
/* 495 */     if (this._msglist == null) {
/* 496 */       this._msglist = new MCMessageList();
/*     */     }
/* 498 */     if (msg != null) {
/* 499 */       this._msglist.add(msg);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 525 */     return super.toString();
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\notice\MCException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */