/*      */ package mcframe.commonCore.notice;
/*      */ 
/*      */ import java.io.BufferedReader;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FilenameFilter;
/*      */ import java.io.InputStreamReader;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Comparator;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import mcframe.commonCore.container.MCList;
/*      */ import mcframe.commonCore.container.MCRow;
/*      */ import mcframe.commonCore.lang.MCCalendarDate;
/*      */ import mcframe.commonCore.lang.MCNumber;
/*      */ import mcframe.commonCore.lang.MCTimestamp;
/*      */ import mcframe.commonCore.resource.MCConfig;
/*      */ import mcframe.commonCore.resource.MCConst;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MCLogReader
/*      */ {
/*      */   private static final char BIND_START = '{';
/*      */   private static final char BIND_END = '}';
/*   47 */   String _format = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   52 */   long _total = 1L;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   57 */   long _limit = 100000L;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   62 */   MCLogConditionR _cond = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean _rderr = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   77 */   int _isOpeS = -1;
/*      */   
/*   79 */   int _nowOpe = -1;
/*      */   
/*   81 */   List<String> opeLs = new ArrayList<>();
/*      */   
/*   83 */   List<String> opes = new ArrayList<>();
/*      */   
/*   85 */   Pattern pOpeS = Pattern.compile(bindCut(MCConst.message.getMessage(Core_Msg_FW_A.FCBGC0304), this.opes, 
/*   86 */         new HashMap<>()));
/*      */   
/*   88 */   List<String> opee = new ArrayList<>();
/*      */   
/*   90 */   Pattern pOpeE = Pattern.compile(bindCut(MCConst.message.getMessage(Core_Msg_FW_A.FCBGC0305), this.opee, 
/*   91 */         new HashMap<>()));
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   96 */   int _isBtnS = -1;
/*      */   
/*   98 */   int _nowBtn = -1;
/*      */   
/*  100 */   List<String> btnLs = new ArrayList<>();
/*      */   
/*  102 */   List<String> btns = new ArrayList<>();
/*      */   
/*  104 */   Pattern pBtnS = Pattern.compile(bindCut(MCConst.message.getMessage(Core_Msg_FW_A.FCBAC0223), this.btns, 
/*  105 */         new HashMap<>()));
/*      */   
/*  107 */   List<String> btne = new ArrayList<>();
/*      */   
/*  109 */   Pattern pBtnE = Pattern.compile(bindCut(MCConst.message.getMessage(Core_Msg_FW_A.FCBAC0224), this.btne, 
/*  110 */         new HashMap<>()));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static MCList<MCLogR> readLog(String fp, MCTimestamp from, MCTimestamp to, String opeId, String reqNo, String[] lvl, String[] mid, String[] an_mid, String clsNm, String mtNm) {
/*  134 */     return readLog(fp, from, to, opeId, reqNo, null, lvl, mid, an_mid, clsNm, mtNm);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static MCList<MCLogR> readLog(String fp, MCTimestamp from, MCTimestamp to, String opeId, String reqNo, String threadNo, String[] lvl, String[] mid, String[] an_mid, String clsNm, String mtNm) {
/*  161 */     MCLogReader rd = new MCLogReader();
/*  162 */     rd.setFrom(from);
/*  163 */     rd.setTo(to);
/*  164 */     rd.setReqNo(reqNo);
/*  165 */     rd.setThreadNo(threadNo);
/*  166 */     rd.setMsgLvl(lvl);
/*  167 */     rd.setMsgId(mid);
/*  168 */     rd.setAnMsgId(an_mid);
/*  169 */     rd.setClassNm(clsNm);
/*  170 */     rd.setMethodNm(mtNm);
/*  171 */     rd.setOperationId(opeId);
/*      */     
/*  173 */     return rd.readLog(fp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFrom(MCTimestamp ts) {
/*  185 */     getCndRow().log_ts_from(ts);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTo(MCTimestamp ts) {
/*  196 */     getCndRow().log_ts_to(ts);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setReqNo(String no) {
/*  208 */     getCndRow().req_no(no);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setThreadNo(String no) {
/*  220 */     getCndRow().thread_no(no);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCoCd(String cd) {
/*  232 */     getCndRow().co_cd(cd);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMsgLvl(String... lvl) {
/*  244 */     getCndRow().msg_lvl(appendCond(lvl));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMsgId(String... id) {
/*  256 */     getCndRow().msg_id(appendCond(id));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAnMsgId(String... id) {
/*  268 */     getCndRow().an_msg_id(appendCond(id));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClassNm(String cls) {
/*  280 */     getCndRow().class_nm(cls);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMethodNm(String method) {
/*  292 */     getCndRow().method_nm(method);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOperationId(String ope) {
/*  313 */     getCndRow().operation_id(ope);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setButtunId(String btn) {
/*  334 */     getCndRow().button_id(btn);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLimit(long lmt) {
/*  346 */     this._limit = lmt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   MCLogConditionR getCndRow() {
/*  357 */     if (this._cond == null) {
/*  358 */       this._cond = MCLogConditionR.create();
/*      */     }
/*  360 */     return this._cond;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String appendCond(String[] s) {
/*  372 */     if (s == null || s.length == 0) {
/*  373 */       return null;
/*      */     }
/*  375 */     StringBuilder sb = new StringBuilder();
/*  376 */     for (int i = 0; i < s.length; i++) {
/*  377 */       if (i > 0) {
/*  378 */         sb.append("|");
/*      */       }
/*  380 */       sb.append(s[i]);
/*      */     } 
/*  382 */     return (sb.length() > 0) ? sb.toString() : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCList<MCLogR> readLog(String... files) {
/*  397 */     return readLog(false, files);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCList<MCLogR> readLog(boolean sort, String... files) {
/*  412 */     clear();
/*  413 */     if (files == null || files.length == 0) {
/*  414 */       throw new MCException(Core_Msg_FW_A.FCBJC0073, new Object[0]);
/*      */     }
/*      */     
/*  417 */     File[] ls = new File[files.length];
/*  418 */     for (int i = 0; i < files.length; i++) {
/*  419 */       ls[i] = createLogFile(files[i]);
/*      */     }
/*      */     
/*  422 */     if (sort)
/*      */     {
/*  424 */       Arrays.sort(ls, new FileComparator());
/*      */     }
/*      */     
/*  427 */     return readLog(ls);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private File createLogFile(String path) {
/*  439 */     File f = new File(path);
/*  440 */     if (!f.exists()) {
/*  441 */       throw new MCException(Core_Msg_FW_A.FCBJC0069, new Object[] { path });
/*      */     }
/*  443 */     if (!f.isFile()) {
/*  444 */       throw new MCException(Core_Msg_FW_A.FCBJC0079, new Object[] { path });
/*      */     }
/*  446 */     return f;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCList<MCLogR> readLogForDir(String dir, String user, String type) {
/*      */     MCLogHandler.Type t;
/*  463 */     clear();
/*  464 */     if (dir == null) {
/*  465 */       throw new MCException(Core_Msg_FW_A.FCBJC0074, new Object[0]);
/*      */     }
/*      */     
/*  468 */     File d = new File(dir);
/*  469 */     if (!d.exists() || !d.isDirectory()) {
/*  470 */       throw new MCException(Core_Msg_FW_A.FCBJC0072, new Object[] { dir });
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  475 */     if (type != null && type.equalsIgnoreCase("admin")) {
/*  476 */       t = MCLogHandler.Type.ADMIN;
/*      */     } else {
/*      */       
/*  479 */       t = MCLogHandler.Type.DEBUG;
/*      */     } 
/*      */     
/*  482 */     File[] ls = d.listFiles(new LogFilter(user, t));
/*  483 */     if (ls.length == 0) {
/*  484 */       throw new MCException(Core_Msg_FW_A.FCBJC0075, new Object[] { dir, user });
/*      */     }
/*      */     
/*  487 */     Arrays.sort(ls, new FileComparator());
/*      */     
/*  489 */     return readLog(ls);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MCList<MCLogR> readLog(File... files) {
/*  501 */     MCList<MCLogR> l = MCList.create(MCLogR.class);
/*      */ 
/*      */     
/*  504 */     List<MCList<MCLogR>> a = new ArrayList<>(); byte b; int i; File[] arrayOfFile;
/*  505 */     for (i = (arrayOfFile = files).length, b = 0; b < i; ) { File f = arrayOfFile[b];
/*  506 */       MCList<MCLogR> t = _readLog(f, this._cond);
/*  507 */       if (t.size() != 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  512 */         t.sort(new String[] { "log_ts", "log_no" });
/*  513 */         MCTimestamp st = ((MCLogR)t.get(0)).log_ts();
/*  514 */         int idx = -1;
/*  515 */         for (int j = 0; j < a.size(); j++) {
/*  516 */           if (st.lt((MCCalendarDate)((MCLogR)((MCList)a.get(j)).get(0)).log_ts(), new mcframe.commonCore.lang.MCDateFieldType[0])) {
/*  517 */             idx = j;
/*      */             break;
/*      */           } 
/*      */         } 
/*  521 */         if (idx == -1) {
/*  522 */           idx = a.size();
/*      */         }
/*  524 */         a.add(idx, t);
/*      */       }  b++; }
/*  526 */      for (MCList<MCLogR> e : a) {
/*  527 */       l.addAll((Collection)e);
/*      */     }
/*      */     
/*  530 */     doSetTortal(l);
/*      */     
/*  532 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   class FileComparator
/*      */     implements Comparator<File>
/*      */   {
/*      */     public int compare(File o1, File o2) {
/*  558 */       long l1 = o1.lastModified();
/*  559 */       long l2 = o2.lastModified();
/*  560 */       return (int)(l1 - l2);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public class LogFilter
/*      */     implements FilenameFilter
/*      */   {
/*  573 */     String _user = null;
/*      */     
/*  575 */     MCLogHandler.Type _type = null;
/*      */     
/*  577 */     Pattern _pattern = null;
/*      */     
/*  579 */     int _userIdx = 0;
/*      */     
/*  581 */     int _gpc = 0;
/*      */     
/*  583 */     private Pattern _date_pattern = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public LogFilter(String user, MCLogHandler.Type type) {
/*  595 */       this._user = user;
/*  596 */       this._type = type;
/*      */       
/*  598 */       String filename = MCConfig.common.getSourceString(MCConfig.createKey(new String[] { "log", 
/*  599 */               this._type.lowerName(), "file" }));
/*      */       
/*  601 */       if (filename == null) {
/*  602 */         throw new MCException(Core_Msg_FW_A.FCBJC0076, new Object[0]);
/*      */       }
/*  604 */       if (this._user != null && filename.indexOf("{USER}") < 0) {
/*  605 */         throw new MCException(Core_Msg_FW_A.FCBJC0077, new Object[0]);
/*      */       }
/*  607 */       List<String> bn = new ArrayList<>();
/*  608 */       HashMap<String, String> bmap = new HashMap<>();
/*  609 */       if (this._user != null) {
/*  610 */         bmap.put("USER", String.valueOf(this._user) + ")([\\.0-9]*");
/*      */       } else {
/*      */         
/*  613 */         bmap.put("USER", ")([\\.0-9]*");
/*      */       } 
/*  615 */       String temp = MCLogReader.bindCut(filename, bn, bmap);
/*      */       
/*  617 */       this._pattern = Pattern.compile(temp);
/*  618 */       this._userIdx = bn.indexOf("USER") + 1;
/*  619 */       this._gpc = bn.size() + 1;
/*      */       
/*  621 */       String prefix = "";
/*  622 */       String suffix = "";
/*  623 */       int extpos = temp.lastIndexOf('.');
/*  624 */       if (extpos >= 0) {
/*  625 */         suffix = temp.substring(extpos);
/*  626 */         prefix = temp.substring(0, extpos);
/*      */       } 
/*  628 */       String date_filename = String.valueOf(prefix) + "." + "[0-9]{4}-[0-9]{2}-[0-9]{2}" + suffix;
/*  629 */       this._date_pattern = Pattern.compile(date_filename);
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean accept(File dir, String name) {
/*  634 */       Matcher m = this._pattern.matcher(name);
/*  635 */       if (m.find()) {
/*  636 */         int cnt = m.groupCount();
/*  637 */         if (this._user != null) {
/*  638 */           if (cnt == this._gpc) {
/*  639 */             String u = m.group(this._userIdx);
/*  640 */             return (u != null && u.equals(this._user));
/*      */           }
/*      */         
/*      */         }
/*  644 */         else if (cnt == this._gpc - 1) {
/*  645 */           return true;
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  650 */       m = this._date_pattern.matcher(name);
/*  651 */       if (m.find()) {
/*  652 */         int cnt = m.groupCount();
/*  653 */         if (this._user != null) {
/*  654 */           if (cnt == this._gpc) {
/*  655 */             String u = m.group(this._userIdx);
/*  656 */             return (u != null && u.equals(this._user));
/*      */           }
/*      */         
/*      */         }
/*  660 */         else if (cnt == this._gpc - 1) {
/*  661 */           return true;
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  666 */       return false;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCList<MCLogR> readLog(String fp) {
/*  681 */     clear();
/*  682 */     if (fp == null) {
/*  683 */       throw new MCException(Core_Msg_FW_A.FCBJC0074, new Object[0]);
/*      */     }
/*      */     
/*  686 */     File f = createLogFile(fp);
/*      */     
/*  688 */     return readLog(new File[] { f });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clear() {
/*  698 */     this._isOpeS = -1;
/*  699 */     this._nowOpe = -1;
/*  700 */     this.opeLs.clear();
/*  701 */     this._total = 1L;
/*  702 */     this._rderr = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   MCList<MCLogR> _readLog(File lf, MCLogConditionR cond) {
/*  715 */     String fp = lf.getPath();
/*  716 */     MCList<MCLogR> rtn = MCList.create(MCLogR.class);
/*      */     
/*  718 */     List<String> heads = new ArrayList<>();
/*  719 */     String fm = bindCut(getLogHeadformat(), heads, new HashMap<>());
/*  720 */     if (fm == null) {
/*  721 */       return rtn;
/*      */     }
/*  723 */     fm = "^" + fm;
/*  724 */     Pattern pattern = Pattern.compile(fm);
/*      */     
/*  726 */     String format = MCConfig.common.getString("log.dateformat", 
/*  727 */         "yyyyMMddHHmmssSSS");
/*      */     
/*  729 */     FileInputStream fs = null;
/*  730 */     InputStreamReader sr = null;
/*  731 */     BufferedReader br = null;
/*  732 */     MCLogR r = null;
/*  733 */     StringBuilder msg = new StringBuilder();
/*      */     try {
/*  735 */       fs = new FileInputStream(fp);
/*  736 */       sr = new InputStreamReader(fs, "utf-8");
/*  737 */       br = new BufferedReader(sr);
/*  738 */       String line = null;
/*  739 */       long rno = 1L;
/*  740 */       while ((line = br.readLine()) != null) {
/*      */         
/*      */         try {
/*  743 */           Matcher matcher = pattern.matcher(line);
/*  744 */           if (matcher.find()) {
/*  745 */             if (r != null) {
/*  746 */               r.msg_txt(msg.toString());
/*  747 */               opeOpen(r);
/*  748 */               btnOpen(r);
/*      */               
/*  750 */               if (isEq(cond, r)) {
/*  751 */                 rtn.add((MCRow)r);
/*  752 */                 this._total++;
/*  753 */                 if (this._limit < this._total) {
/*  754 */                   throw new MCException(Core_Msg_FW_A.FCBJC0071, new Object[] { fp });
/*      */                 }
/*      */               } 
/*  757 */               btnClose(cond, r);
/*  758 */               opeClose(cond, r);
/*      */               
/*  760 */               msg.delete(0, msg.length());
/*      */             } 
/*  762 */             r = MCLogR.create();
/*  763 */             r.log_no(rno);
/*  764 */             r.file_path(fp);
/*      */             
/*  766 */             for (int i = 0; i < heads.size(); i++) {
/*  767 */               String col = heads.get(i);
/*  768 */               String v = null;
/*  769 */               if (matcher.groupCount() > i) {
/*  770 */                 v = matcher.group(i + 1);
/*      */               }
/*      */               
/*  773 */               if (col.equalsIgnoreCase("DATE")) {
/*  774 */                 r.log_ts(MCTimestamp.valueOf(v, format));
/*      */               }
/*  776 */               else if (col.equalsIgnoreCase("MSGID")) {
/*  777 */                 r.msg_id(v);
/*      */               }
/*  779 */               else if (col.equalsIgnoreCase("LEVEL")) {
/*  780 */                 r.msg_lvl(v);
/*      */               }
/*  782 */               else if (col.equalsIgnoreCase("REQNO")) {
/*  783 */                 r.req_no(v);
/*      */               
/*      */               }
/*  786 */               else if (col.equalsIgnoreCase("THREAD")) {
/*  787 */                 r.thread_no(v);
/*      */               }
/*  789 */               else if (col.equalsIgnoreCase("COCD")) {
/*  790 */                 r.co_cd(v);
/*      */               }
/*  792 */               else if (col.equalsIgnoreCase("CLASS")) {
/*  793 */                 r.class_nm(v);
/*      */               }
/*  795 */               else if (col.equalsIgnoreCase("METHOD")) {
/*  796 */                 r.method_nm(v);
/*      */               }
/*  798 */               else if (col.equalsIgnoreCase("LINE")) {
/*  799 */                 r.method_line(MCNumber.valueOf(v));
/*      */               }
/*      */             
/*      */             }
/*      */           
/*  804 */           } else if (r != null) {
/*  805 */             if (msg.length() > 0) {
/*  806 */               msg.append("\n");
/*      */             }
/*  808 */             msg.append(line);
/*      */           }
/*      */         
/*      */         }
/*  812 */         catch (Exception ex) {
/*  813 */           if (ex instanceof MCException && 
/*  814 */             Core_Msg_FW_A.FCBJC0071.toString().equals(((MCException)ex).getID())) {
/*  815 */             throw (MCException)ex;
/*      */           }
/*      */           
/*  818 */           MCLog.write(new MCMessage(Core_Msg_FW_A.FCBJC0080, new Object[] { Long.valueOf(rno), ex.toString() }));
/*  819 */           this._rderr = true;
/*      */           
/*  821 */           r = null;
/*      */           continue;
/*      */         } finally {
/*  824 */           rno++;
/*      */         } 
/*      */       } 
/*      */       
/*  828 */       if (r != null) {
/*  829 */         r.msg_txt(msg.toString());
/*  830 */         opeOpen(r);
/*  831 */         btnOpen(r);
/*  832 */         if (isEq(cond, r)) {
/*  833 */           rtn.add((MCRow)r);
/*      */         }
/*  835 */         btnClose(cond, r);
/*  836 */         opeClose(cond, r);
/*      */       }
/*      */     
/*  839 */     } catch (Exception ex) {
/*  840 */       if (ex instanceof MCException && 
/*  841 */         Core_Msg_FW_A.FCBJC0071.toString().equals(((MCException)ex).getID())) {
/*  842 */         throw (MCException)ex;
/*      */       }
/*  844 */       throw new MCException(ex, Core_Msg_FW_A.FCBJC0070, new Object[] { fp });
/*      */     } finally {
/*      */       
/*      */       try {
/*  848 */         br.close();
/*  849 */         sr.close();
/*  850 */         fs.close();
/*      */       }
/*  852 */       catch (Exception exception) {}
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  857 */     return rtn;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void opeOpen(MCLogR r) {
/*  868 */     if (Core_Msg_FW_A.FCBGC0304.equals(r.msg_id())) {
/*  869 */       Matcher matcher = this.pOpeS.matcher(r.msg_txt());
/*  870 */       if (matcher.find()) {
/*  871 */         this._nowOpe++;
/*  872 */         String opeid = String.valueOf(matcher.group(1)) + "." + matcher.group(2) + "." + 
/*  873 */           matcher.group(3);
/*  874 */         this.opeLs.add(this._nowOpe, opeid);
/*      */       } 
/*      */     } 
/*  877 */     if (this._nowOpe >= 0) {
/*  878 */       r.operation_id(this.opeLs.get(this._nowOpe));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void btnOpen(MCLogR r) {
/*  890 */     if (Core_Msg_FW_A.FCBAC0223.equals(r.msg_id())) {
/*  891 */       Matcher matcher = this.pBtnS.matcher(r.msg_txt());
/*  892 */       if (matcher.find()) {
/*      */         
/*  894 */         this._nowBtn++;
/*  895 */         String btnid = String.valueOf(matcher.group(1)) + "." + matcher.group(2) + "." + 
/*  896 */           matcher.group(4);
/*  897 */         this.btnLs.add(this._nowBtn, btnid);
/*      */       } 
/*      */     } 
/*  900 */     if (this._nowBtn >= 0) {
/*  901 */       r.button_id(this.btnLs.get(this._nowBtn));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isEq(MCLogConditionR cond, MCLogR r) {
/*  915 */     if (cond != null) {
/*  916 */       if (cond.operation_id() != null) {
/*  917 */         if (Core_Msg_FW_A.FCBGC0304.equals(r.msg_id()) && r.operation_id() != null && 
/*  918 */           cond.operation_id().equals(r.operation_id())) {
/*  919 */           this._isOpeS++;
/*      */         }
/*  921 */         if (this._isOpeS < 0) {
/*  922 */           return false;
/*      */         }
/*      */       }
/*  925 */       else if (cond.button_id() != null) {
/*  926 */         if (Core_Msg_FW_A.FCBAC0223.equals(r.msg_id()) && r.button_id() != null && 
/*  927 */           cond.button_id().equals(r.button_id())) {
/*  928 */           this._isBtnS++;
/*      */         }
/*  930 */         if (this._isBtnS < 0) {
/*  931 */           return false;
/*      */         }
/*      */       } 
/*  934 */       return cond.matchCond(r);
/*      */     } 
/*  936 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void opeClose(MCLogConditionR cond, MCLogR r) {
/*  949 */     if (Core_Msg_FW_A.FCBGC0305.equals(r.msg_id())) {
/*  950 */       Matcher matcher = this.pOpeE.matcher(r.msg_txt());
/*  951 */       String opeid = null;
/*  952 */       if (matcher.find()) {
/*  953 */         opeid = String.valueOf(matcher.group(1)) + "." + matcher.group(2) + "." + 
/*  954 */           matcher.group(3);
/*      */         
/*  956 */         if (this._nowOpe >= 0 && this.opeLs.get(this._nowOpe) != null && (
/*  957 */           (String)this.opeLs.get(this._nowOpe)).equals(opeid)) {
/*  958 */           this.opeLs.remove(this._nowOpe);
/*  959 */           this._nowOpe--;
/*      */         } 
/*      */       } 
/*  962 */       if (cond != null && 
/*  963 */         cond.operation_id() != null && cond.operation_id().equals(opeid) && 
/*  964 */         this._isOpeS >= 0) {
/*  965 */         this._isOpeS--;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void btnClose(MCLogConditionR cond, MCLogR r) {
/*  982 */     if (Core_Msg_FW_A.FCBAC0224.equals(r.msg_id())) {
/*  983 */       Matcher matcher = this.pBtnE.matcher(r.msg_txt());
/*  984 */       String btnid = null;
/*  985 */       if (matcher.find()) {
/*  986 */         btnid = String.valueOf(matcher.group(1)) + "." + matcher.group(2) + "." + 
/*  987 */           matcher.group(4);
/*      */         
/*  989 */         if (this._nowBtn >= 0 && this.btnLs.get(this._nowBtn) != null && (
/*  990 */           (String)this.btnLs.get(this._nowBtn)).equals(btnid)) {
/*  991 */           this._nowBtn--;
/*      */         }
/*      */       } 
/*  994 */       if (cond != null && 
/*  995 */         cond.button_id() != null && cond.button_id().equals(btnid) && 
/*  996 */         this._isBtnS >= 0) {
/*  997 */         this._isBtnS--;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getLogHeadformat() {
/* 1012 */     if (this._format == null) {
/* 1013 */       this._format = MCConfig.common.getSourceString(MCLogger.RES_HEADER);
/*      */     }
/* 1015 */     return this._format;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLogHeadformat(String f) {
/* 1026 */     this._format = f;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static String bindCut(String format, List<String> bindsrc, Map<String, String> bmap) {
/* 1043 */     if (format == null || format.length() == 0) {
/* 1044 */       return format;
/*      */     }
/*      */     
/* 1047 */     StringBuilder sb = new StringBuilder();
/* 1048 */     StringBuilder bindsb = new StringBuilder();
/*      */     
/* 1050 */     char[] chars = format.toCharArray();
/* 1051 */     int len = chars.length;
/* 1052 */     boolean into = false;
/* 1053 */     for (int i = 0; i < len; i++) {
/* 1054 */       char c = chars[i];
/* 1055 */       if (into) {
/* 1056 */         if (c == '}')
/*      */         {
/* 1058 */           String key = bindsb.toString();
/* 1059 */           bindsrc.add(key);
/*      */           
/* 1061 */           sb.append("(");
/*      */           
/* 1063 */           if (bindsb.length() > 0) {
/* 1064 */             String bkey = bindsb.toString();
/* 1065 */             if (bmap.containsKey(bkey)) {
/* 1066 */               sb.append(bmap.get(bkey));
/*      */             } else {
/*      */               
/* 1069 */               sb.append(".*");
/*      */             } 
/*      */           } 
/* 1072 */           sb.append(")");
/*      */           
/* 1074 */           bindsb.delete(0, bindsb.length());
/* 1075 */           into = false;
/*      */         
/*      */         }
/*      */         else
/*      */         {
/* 1080 */           bindsb.append(c);
/*      */         }
/*      */       
/*      */       } else {
/*      */         
/* 1085 */         if (c == '{') {
/* 1086 */           if (i < len - 1 && chars[i + 1] == '{') {
/*      */ 
/*      */             
/* 1089 */             i++;
/*      */           }
/*      */           else {
/*      */             
/* 1093 */             into = true;
/*      */             
/*      */             i++;
/*      */           } 
/*      */         }
/* 1098 */         if (c == '\\' && 
/* 1099 */           i < len - 1 && chars[i + 1] == 'n')
/* 1100 */         { i++;
/* 1101 */           if (i + 1 != len)
/*      */           {
/* 1103 */             sb.append("\\n");
/*      */ 
/*      */           
/*      */           }
/*      */            }
/*      */         
/* 1109 */         else if (c == '\r' && 
/* 1110 */           i < len - 1 && chars[i + 1] == '\n')
/* 1111 */         { sb.append("\\n");
/* 1112 */           i++; }
/*      */         
/*      */         else
/*      */         
/* 1116 */         { sb.append(setEscape(c)); } 
/*      */       } 
/* 1118 */     }  if (bindsb.length() > 0) {
/* 1119 */       sb.append('{');
/* 1120 */       sb.append(bindsb);
/*      */     } 
/* 1122 */     return (sb.length() > 0) ? sb.toString() : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static String setEscepeString(String str) {
/* 1135 */     if (str == null || str.length() == 0) {
/* 1136 */       return null;
/*      */     }
/* 1138 */     char[] chars = str.toCharArray();
/* 1139 */     int len = chars.length;
/* 1140 */     StringBuilder sb = new StringBuilder();
/*      */     
/* 1142 */     for (int i = 0; i < len; i++) {
/* 1143 */       sb.append(setEscape(chars[i]));
/*      */     }
/* 1145 */     return sb.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static String setEscape(char h) {
/* 1157 */     if (h == '[' || h == ']' || h == '.' || h == '(' || h == ')' || h == '^' || 
/* 1158 */       h == '$' || h == '\\') {
/* 1159 */       return "\\" + String.valueOf(h);
/*      */     }
/* 1161 */     if (h == '|') {
/* 1162 */       return "[" + String.valueOf(h) + "]";
/*      */     }
/* 1164 */     return String.valueOf(h);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void doSetTortal(MCList<MCLogR> ls) {
/* 1175 */     long l = 1L;
/* 1176 */     MCTimestamp fts = null;
/* 1177 */     for (MCLogR r : ls) {
/* 1178 */       if (fts == null) {
/* 1179 */         fts = r.log_ts();
/*      */       }
/* 1181 */       r.total_no(l);
/* 1182 */       if (r.log_ts() != null) {
/* 1183 */         r.elapsed_time(r.log_ts().diffMilliSecond((MCCalendarDate)fts));
/*      */       }
/* 1185 */       l++;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isReadErr() {
/* 1198 */     return this._rderr;
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\notice\MCLogReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */