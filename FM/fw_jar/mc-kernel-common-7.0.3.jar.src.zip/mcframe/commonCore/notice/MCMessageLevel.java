/*     */ package mcframe.commonCore.notice;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import mcframe.commonCore.resource.MCConst;
/*     */ import org.apache.commons.logging.Log;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum MCMessageLevel
/*     */ {
/*  22 */   TRACE
/*     */   {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean isLogEnabled(Log log)
/*     */     {
/*  37 */       return log.isTraceEnabled();
/*     */     }
/*     */     
/*     */     void log(Log log, MCVerifiedMessage msgcon) {
/*  41 */       log.trace(msgcon);
/*     */     }
/*     */     
/*     */     void log(Log log, MCVerifiedMessage msgcon, Throwable t) {
/*  45 */       log.trace(msgcon, t);
/*     */     }
/*     */   },
/*     */   
/*  49 */   DEBUG
/*     */   {
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean isLogEnabled(Log log)
/*     */     {
/*  57 */       return log.isDebugEnabled();
/*     */     }
/*     */     
/*     */     void log(Log log, MCVerifiedMessage msgcon) {
/*  61 */       log.debug(msgcon);
/*     */     }
/*     */     
/*     */     void log(Log log, MCVerifiedMessage msgcon, Throwable t) {
/*  65 */       log.debug(msgcon, t);
/*     */     }
/*     */   },
/*     */   
/*  69 */   INFO
/*     */   {
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean isLogEnabled(Log log)
/*     */     {
/*  77 */       return log.isInfoEnabled();
/*     */     }
/*     */     
/*     */     void log(Log log, MCVerifiedMessage msgcon) {
/*  81 */       log.info(msgcon);
/*     */     }
/*     */     
/*     */     void log(Log log, MCVerifiedMessage msgcon, Throwable t) {
/*  85 */       log.info(msgcon, t);
/*     */     }
/*     */   },
/*     */   
/*  89 */   WARN
/*     */   {
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean isLogEnabled(Log log)
/*     */     {
/*  97 */       return log.isWarnEnabled();
/*     */     }
/*     */     
/*     */     void log(Log log, MCVerifiedMessage msgcon) {
/* 101 */       log.warn(msgcon);
/*     */     }
/*     */     
/*     */     void log(Log log, MCVerifiedMessage msgcon, Throwable t) {
/* 105 */       log.warn(msgcon, t);
/*     */     }
/*     */   },
/*     */   
/* 109 */   PROBLEM
/*     */   {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean isLogEnabled(Log log)
/*     */     {
/* 118 */       return log.isErrorEnabled();
/*     */     }
/*     */     
/*     */     void log(Log log, MCVerifiedMessage msgcon) {
/* 122 */       log.error(msgcon);
/*     */     }
/*     */     
/*     */     void log(Log log, MCVerifiedMessage msgcon, Throwable t) {
/* 126 */       log.error(msgcon, t);
/*     */     }
/*     */   },
/*     */   
/* 130 */   ERROR
/*     */   {
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean isLogEnabled(Log log)
/*     */     {
/* 138 */       return log.isFatalEnabled();
/*     */     }
/*     */     
/*     */     void log(Log log, MCVerifiedMessage msgcon) {
/* 142 */       log.fatal(msgcon);
/*     */     }
/*     */     
/*     */     void log(Log log, MCVerifiedMessage msgcon, Throwable t) {
/* 146 */       log.fatal(msgcon, t);
/*     */     }
/*     */   },
/*     */   
/* 150 */   FATAL
/*     */   {
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean isLogEnabled(Log log)
/*     */     {
/* 158 */       return log.isFatalEnabled();
/*     */     }
/*     */     
/*     */     void log(Log log, MCVerifiedMessage msgcon) {
/* 162 */       log.fatal(msgcon);
/*     */     }
/*     */     
/*     */     void log(Log log, MCVerifiedMessage msgcon, Throwable t) {
/* 166 */       log.fatal(msgcon, t);
/*     */     }
/*     */   };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static MCMessageLevel[] _wraps;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 201 */     _wraps = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean checkWrappedErrorLevel(MCMessageLevel lv) {
/* 213 */     if (lv == null) {
/* 214 */       return true;
/*     */     }
/* 216 */     if (_wraps == null) {
/* 217 */       String[] vals = MCConst.message.getWrappedErrorLevelArray();
/* 218 */       ArrayList<MCMessageLevel> list = new ArrayList<>(vals.length); byte b1; int j; String[] arrayOfString1;
/* 219 */       for (j = (arrayOfString1 = vals).length, b1 = 0; b1 < j; ) { String val = arrayOfString1[b1];
/* 220 */         if (val != null && val.length() > 0) {
/*     */           try {
/* 222 */             MCMessageLevel wrap = valueOf(val.charAt(0));
/* 223 */             list.add(wrap);
/* 224 */           } catch (MCException mCException) {}
/*     */         }
/*     */         
/*     */         b1++; }
/*     */       
/* 229 */       _wraps = list.<MCMessageLevel>toArray(new MCMessageLevel[list.size()]);
/*     */     }  byte b; int i; MCMessageLevel[] arrayOfMCMessageLevel;
/* 231 */     for (i = (arrayOfMCMessageLevel = _wraps).length, b = 0; b < i; ) { MCMessageLevel wrap = arrayOfMCMessageLevel[b];
/* 232 */       if (wrap == lv)
/* 233 */         return true; 
/*     */       b++; }
/*     */     
/* 236 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char getOmission() {
/* 248 */     return toString().charAt(0);
/*     */   }
/*     */   
/*     */   abstract boolean isLogEnabled(Log paramLog);
/*     */   
/*     */   abstract void log(Log paramLog, MCVerifiedMessage paramMCVerifiedMessage);
/*     */   
/*     */   abstract void log(Log paramLog, MCVerifiedMessage paramMCVerifiedMessage, Throwable paramThrowable);
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\notice\MCMessageLevel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */