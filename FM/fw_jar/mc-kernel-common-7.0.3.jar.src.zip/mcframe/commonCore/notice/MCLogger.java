/*      */ package mcframe.commonCore.notice;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.Serializable;
/*      */ import java.nio.charset.Charset;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.HashMap;
/*      */ import java.util.Map;
/*      */ import java.util.regex.Pattern;
/*      */ import mcframe.commonCore.lang.MCStringUtil;
/*      */ import mcframe.commonCore.lang.MCTimestamp;
/*      */ import mcframe.commonCore.resource.MCConfig;
/*      */ import mcframe.commonCore.sys.MCSys;
/*      */ import org.apache.commons.logging.Log;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class MCLogger
/*      */   implements Log, Serializable
/*      */ {
/*      */   private static final String RES_LOG_ROOT = "log";
/*      */   private static final String RES_LOG_LEVEL = "level";
/*      */   private static final String RES_LOG_FWLEVEL = "fwlevel";
/*   78 */   private static final String RES_STACKTRACE_LEVEL = MCConfig.createKey(new String[] { "log", 
/*   79 */         "stacktracelevel" });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   86 */   private static final String RES_DEVLOG = MCConfig.createKey(new String[] { "log", "devlog" });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   93 */   static final String RES_HEADER = MCConfig.createKey(new String[] { "log", "header" });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final String CATEGORY_FW = "framework";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final String CATEGORY_AP = "apprication";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final String ID_NONE = "(non id)";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final String LEVEL_NONE = "(non lv)";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final String USER_NONE = "(no login)";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final String LINE_NONE = "?";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final String REQNO_NONE = "-";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final String THREADNO_NONE = "-";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final String COCD_NONE = "-";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  168 */   static final String LINE_SEP = MCSys.env.getVMEnv("line.separator", "\n");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  175 */   private static final MCMessageLevel DEFAULT_LEVEL_ADMIN = MCMessageLevel.INFO;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  182 */   private static final MCMessageLevel DEFAULT_LEVEL_DEBUG = MCMessageLevel.DEBUG;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String LEVEL_APP = "APP";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int OFFSET = 9;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int NON_ID_OFFSET = 4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String DEFAULT_STACKTRACE_MSG = "Stack Trace...";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  222 */   private static final MCMessageLevel DEFAULT_STACKTRACE_LEVEL = MCMessageLevel.DEBUG;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  234 */   private static final String CAUSE_ERR_HEADER = "(cause) {1}" + LINE_SEP + "{2}" + 
/*  235 */     LINE_SEP;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  242 */   private static final String CAUSE_MSG_HEADER = "(with)" + LINE_SEP;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  249 */   private static final Map<String, MCLogHandler[]> _userHandlerMap = (Map)new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int _HANDLE_SIZE = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int _HANDLE_ADMIN = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int _HANDLE_DEBUG = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final void close(String userid) {
/*  280 */     synchronized (_userHandlerMap) {
/*  281 */       MCLogHandler[] handlers = _userHandlerMap.remove(userid);
/*  282 */       if (handlers != null) {
/*  283 */         byte b; int i; MCLogHandler[] arrayOfMCLogHandler; for (i = (arrayOfMCLogHandler = handlers).length, b = 0; b < i; ) { MCLogHandler h = arrayOfMCLogHandler[b];
/*  284 */           if (h != null) {
/*  285 */             h.close();
/*      */           }
/*      */           b++; }
/*      */       
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final void rotate(String userid) {
/*  300 */     synchronized (_userHandlerMap) {
/*  301 */       MCLogHandler[] handlers = _userHandlerMap.get(userid);
/*  302 */       if (handlers != null) {
/*  303 */         byte b; int i; MCLogHandler[] arrayOfMCLogHandler; for (i = (arrayOfMCLogHandler = handlers).length, b = 0; b < i; ) { MCLogHandler h = arrayOfMCLogHandler[b];
/*  304 */           if (h != null) {
/*  305 */             h.rotate();
/*      */           }
/*      */           b++; }
/*      */       
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final StringBuilder createLogBuffer(MCMessageLevel level, String id) {
/*  325 */     return createLogBuffer(level, id, (id != null) ? 9 : 4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final StringBuilder createLogBuffer(MCMessageLevel level, String id, int offset) {
/*  355 */     MCStringUtil.CustomBindSource bindsrc = new MCStringUtil.CustomBindSource(MCConfig.common.bindsrc);
/*      */     
/*  357 */     String format = getHeaderFormat();
/*      */     
/*  359 */     bindsrc.put("DATE", getHeaderTimestamp());
/*  360 */     bindsrc.put("MSGID", getIDForHeader(id));
/*  361 */     bindsrc.put("LEVEL", getLevelForHeader(level));
/*  362 */     bindsrc.put("REQNO", getRequestNoForHeader());
/*  363 */     bindsrc.put("THREAD", getThreadNoForHeader());
/*  364 */     bindsrc.put("COCD", getCoCdForHeader());
/*      */     
/*  366 */     if (_headerSrcTrace) {
/*      */       
/*  368 */       Throwable t = new Throwable();
/*  369 */       StackTraceElement[] st = t.getStackTrace();
/*  370 */       if (st.length > offset) {
/*  371 */         StackTraceElement source = st[offset];
/*  372 */         int line = source.getLineNumber();
/*  373 */         String clname = source.getClassName();
/*  374 */         bindsrc.put("CLASS", clname.substring(clname.lastIndexOf('.') + 1));
/*  375 */         bindsrc.put("METHOD", source.getMethodName());
/*  376 */         bindsrc.put("LINE", (line >= 0) ? String.valueOf(line) : "?");
/*      */       } 
/*      */     } 
/*  379 */     String bufstr = MCStringUtil.bind(format, (MCStringUtil.BindSource)bindsrc);
/*  380 */     return new StringBuilder(bufstr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final StringBuilder createFollowBuffer() {
/*  391 */     return new StringBuilder(1024);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  399 */   private static String _headerFormat = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean _headerSrcTrace = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  413 */   private static final Object _headerFormatLock = new Object();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String getHeaderFormat() {
/*  427 */     if (_headerFormat == null) {
/*  428 */       synchronized (_headerFormatLock) {
/*      */         
/*  430 */         if (_headerFormat == null) {
/*  431 */           String format = MCConfig.common.getSourceString(RES_HEADER);
/*  432 */           if (format == null) {
/*  433 */             _headerFormat = "";
/*      */           
/*      */           }
/*      */           else {
/*      */ 
/*      */             
/*  439 */             Pattern REGEXP_NEWLINE = Pattern.compile("\\\\n");
/*  440 */             _headerFormat = REGEXP_NEWLINE.matcher(format)
/*  441 */               .replaceAll(LINE_SEP);
/*  442 */             _headerSrcTrace = !(_headerFormat.indexOf("{CLASS}") == -1 && 
/*  443 */               _headerFormat.indexOf("{METHOD}") == -1 && 
/*  444 */               _headerFormat.indexOf("{LINE}") == -1);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     }
/*  449 */     return _headerFormat;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  457 */   private static long _time_last = 0L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  464 */   private static String _time_str = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String getHeaderTimestamp() {
/*  475 */     long systime = System.currentTimeMillis();
/*  476 */     if (systime != _time_last) {
/*      */       
/*  478 */       _time_last = systime;
/*  479 */       SimpleDateFormat dformat = getDateFormat();
/*  480 */       _time_str = MCTimestamp.sysnow().toString(dformat);
/*      */     } 
/*  482 */     return _time_str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  490 */   private static SimpleDateFormat _dateFormat = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final SimpleDateFormat getDateFormat() {
/*  504 */     if (_dateFormat == null) {
/*  505 */       String format = MCConfig.common.getString("log.dateformat", 
/*  506 */           "yyyyMMddHHmmssSSS");
/*  507 */       SimpleDateFormat sdf = new SimpleDateFormat(format);
/*  508 */       sdf.setLenient(false);
/*  509 */       _dateFormat = sdf;
/*      */     } 
/*  511 */     return _dateFormat;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final String getIDForHeader(String id) {
/*  526 */     return (id != null) ? id : "(non id)";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final String getLevelForHeader(MCMessageLevel level) {
/*  538 */     return (level != null) ? String.valueOf(level.getOmission()) : "(non lv)";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final String getRequestNoForHeader() {
/*  549 */     String no = MCSys.request.serverRequestNo();
/*  550 */     return (no != null) ? no : "-";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final String getThreadNoForHeader() {
/*  562 */     String no = MCSys.request.serverThreadNo();
/*  563 */     return (no != null) ? no : "-";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final String getCoCdForHeader() {
/*  574 */     String no = (MCSys.request.cooperateCd() != null) ? MCSys.request.cooperateCd() : 
/*  575 */       MCSys.user.coCD();
/*  576 */     return (no != null) ? no : "-";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  584 */   static final EnableChecker FW_ENABLE_CHECKER = new FrameworkChecker(null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  591 */   static final EnableChecker AP_ENABLE_CHECKER = new ApplicationChecker(null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final EnableChecker _checker;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCLogger(String name) {
/*  608 */     this._checker = "framework".equals(name) ? FW_ENABLE_CHECKER : AP_ENABLE_CHECKER;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void trace(Object message, Throwable t) {
/*  614 */     MCVerifiedMessage msgcon = verify(message, MCMessageLevel.TRACE);
/*  615 */     message(msgcon, t);
/*  616 */     throwable(t, msgcon.id());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void trace(Object message) {
/*  622 */     MCVerifiedMessage msgcon = verify(message, MCMessageLevel.TRACE);
/*  623 */     message(msgcon, null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void debug(Object message, Throwable t) {
/*  629 */     MCVerifiedMessage msgcon = verify(message, MCMessageLevel.DEBUG);
/*  630 */     message(msgcon, t);
/*  631 */     throwable(t, msgcon.id());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void debug(Object message) {
/*  637 */     MCVerifiedMessage msgcon = verify(message, MCMessageLevel.DEBUG);
/*  638 */     message(msgcon, null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void info(Object message, Throwable t) {
/*  644 */     MCVerifiedMessage msgcon = verify(message, MCMessageLevel.INFO);
/*  645 */     message(msgcon, t);
/*  646 */     throwable(t, msgcon.id());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void info(Object message) {
/*  652 */     MCVerifiedMessage msgcon = verify(message, MCMessageLevel.INFO);
/*  653 */     message(msgcon, null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void warn(Object message, Throwable t) {
/*  659 */     MCVerifiedMessage msgcon = verify(message, MCMessageLevel.WARN);
/*  660 */     message(msgcon, t);
/*  661 */     throwable(t, msgcon.id());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void warn(Object message) {
/*  667 */     MCVerifiedMessage msgcon = verify(message, MCMessageLevel.WARN);
/*  668 */     message(msgcon, null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void error(Object message, Throwable t) {
/*  674 */     MCVerifiedMessage msgcon = verify(message, MCMessageLevel.ERROR);
/*  675 */     message(msgcon, t);
/*  676 */     throwable(t, msgcon.id());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void error(Object message) {
/*  682 */     MCVerifiedMessage msgcon = verify(message, MCMessageLevel.ERROR);
/*  683 */     message(msgcon, null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void fatal(Object message, Throwable t) {
/*  689 */     MCVerifiedMessage msgcon = verify(message, MCMessageLevel.FATAL);
/*  690 */     message(msgcon, t);
/*  691 */     throwable(t, msgcon.id());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void fatal(Object message) {
/*  697 */     MCVerifiedMessage msgcon = verify(message, MCMessageLevel.FATAL);
/*  698 */     message(msgcon, null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isTraceEnabled() {
/*  704 */     return !(!this._checker.isAdminEnabled(MCMessageLevel.TRACE) && 
/*  705 */       !this._checker.isDebugEnabled(MCMessageLevel.TRACE));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isDebugEnabled() {
/*  711 */     return !(!this._checker.isAdminEnabled(MCMessageLevel.DEBUG) && 
/*  712 */       !this._checker.isDebugEnabled(MCMessageLevel.DEBUG));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isInfoEnabled() {
/*  718 */     return !(!this._checker.isAdminEnabled(MCMessageLevel.INFO) && 
/*  719 */       !this._checker.isDebugEnabled(MCMessageLevel.INFO));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isWarnEnabled() {
/*  725 */     return !(!this._checker.isAdminEnabled(MCMessageLevel.WARN) && 
/*  726 */       !this._checker.isDebugEnabled(MCMessageLevel.WARN));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isErrorEnabled() {
/*  734 */     return !(!this._checker.isAdminEnabled(MCMessageLevel.PROBLEM) && 
/*  735 */       !this._checker.isDebugEnabled(MCMessageLevel.PROBLEM));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isFatalEnabled() {
/*  743 */     return !(!this._checker.isAdminEnabled(MCMessageLevel.ERROR) && 
/*  744 */       !this._checker.isDebugEnabled(MCMessageLevel.ERROR) && 
/*  745 */       !this._checker.isAdminEnabled(MCMessageLevel.FATAL) && 
/*  746 */       !this._checker.isDebugEnabled(MCMessageLevel.FATAL));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MCVerifiedMessage verify(Object message, MCMessageLevel def) {
/*  769 */     return (message instanceof MCVerifiedMessage) ? (MCVerifiedMessage)message : 
/*  770 */       new MCVerifiedMessage(null, def, message.toString(), false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void message(MCVerifiedMessage msg, Throwable t) {
/*  787 */     MCMessageLevel level = msg.level();
/*  788 */     boolean admin = this._checker.isAdminEnabled(level);
/*  789 */     boolean debug = this._checker.isDebugEnabled(level);
/*  790 */     if (admin || debug) {
/*  791 */       StringBuilder sb = msg.follow() ? 
/*  792 */         createFollowBuffer() : 
/*  793 */         createLogBuffer(level, msg.id());
/*  794 */       sb.append(msg.message());
/*  795 */       sb.append(LINE_SEP);
/*      */       
/*  797 */       setCause(t, sb);
/*      */       
/*  799 */       write(sb, admin, debug);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setCause(Throwable t, StringBuilder buf) {
/*  812 */     setCauseMessage(t, buf);
/*  813 */     setCauseThrowable(t, buf);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private StringBuilder setCauseMessage(Throwable t, StringBuilder buf) {
/*  828 */     if (t == null || buf == null) {
/*  829 */       return buf;
/*      */     }
/*  831 */     if (!(t instanceof MCException)) {
/*  832 */       return buf;
/*      */     }
/*  834 */     MCException mcex = (MCException)t;
/*  835 */     MCMessageList ml = mcex.getCauseMessageList();
/*  836 */     int mlsize = ml.size();
/*  837 */     if (mlsize <= 0) {
/*  838 */       return buf;
/*      */     }
/*      */     
/*  841 */     buf.append(CAUSE_MSG_HEADER);
/*  842 */     for (int i = 0; i < mlsize; i++) {
/*  843 */       MCMessage msg = ml.get(i);
/*  844 */       buf.append(createCauseHeader(msg));
/*  845 */       buf.append(LINE_SEP);
/*  846 */       buf.append(msg.toString());
/*  847 */       buf.append(LINE_SEP);
/*      */     } 
/*  849 */     return buf;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private StringBuilder setCauseThrowable(Throwable t, StringBuilder buf) {
/*  862 */     if (t == null || buf == null) {
/*  863 */       return buf;
/*      */     }
/*  865 */     Throwable cause = t.getCause();
/*  866 */     if (cause == null) {
/*  867 */       return buf;
/*      */     }
/*      */     
/*  870 */     String info = null;
/*  871 */     String body = null;
/*  872 */     if (cause instanceof MCException) {
/*  873 */       MCException mcex = (MCException)cause;
/*  874 */       MCMessage msg = mcex.getMCMessage();
/*  875 */       info = createCauseHeader(msg);
/*  876 */       body = msg.toString();
/*      */     } else {
/*      */       
/*  879 */       info = cause.getClass().getName();
/*  880 */       body = cause.getMessage();
/*      */     } 
/*  882 */     String causestr = MCStringUtil.bind(CAUSE_ERR_HEADER, new Object[] { info, body });
/*  883 */     buf.append(causestr);
/*      */     
/*  885 */     setCause(cause, buf);
/*  886 */     return buf;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String createCauseHeader(MCMessage msg) {
/*  898 */     return "-- [" + getLevelForHeader(msg.getLevel()) + "]" + "[" + 
/*  899 */       getIDForHeader(msg.getID()) + "]";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void throwable(Throwable t, String id) {
/*  915 */     if (t == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  920 */     boolean developEnable = MCConfig.common.getBoolean(RES_DEVLOG, false);
/*  921 */     if (developEnable) {
/*  922 */       t.printStackTrace();
/*      */     }
/*      */ 
/*      */     
/*  926 */     MCMessageLevel level = null;
/*  927 */     String lvstr = MCConfig.common.getString(RES_STACKTRACE_LEVEL);
/*  928 */     if (lvstr != null) {
/*      */       try {
/*  930 */         level = MCMessageLevel.valueOf(lvstr);
/*      */       }
/*  932 */       catch (Exception exception) {}
/*      */     }
/*      */ 
/*      */     
/*  936 */     if (level == null) {
/*      */       
/*  938 */       MCMessage msg = new MCMessage(Core_Msg_FW_A.FCBJC0013, new Object[] { DEFAULT_STACKTRACE_LEVEL.name(), id });
/*  939 */       message(new MCVerifiedMessage(msg.getID(), msg, false), null);
/*  940 */       level = DEFAULT_STACKTRACE_LEVEL;
/*      */     } 
/*      */ 
/*      */     
/*  944 */     boolean admin = this._checker.isAdminEnabled(level);
/*  945 */     boolean debug = this._checker.isDebugEnabled(level);
/*  946 */     if (admin || debug) {
/*  947 */       StringBuilder sb = createLogBuffer(level, id);
/*  948 */       sb.append("Stack Trace...");
/*  949 */       sb.append(LINE_SEP);
/*  950 */       sb.append(MCLog.stackTrace(t));
/*  951 */       sb.append(LINE_SEP);
/*  952 */       write(sb, admin, debug);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void write(Object msg, boolean admin, boolean debug) {
/*  969 */     String userid = MCSys.user.ID();
/*      */     
/*  971 */     MCLogHandler[] handlers = null;
/*  972 */     synchronized (_userHandlerMap) {
/*  973 */       handlers = _userHandlerMap.get(userid);
/*  974 */       if (handlers == null) {
/*      */         
/*  976 */         handlers = new MCLogHandler[2];
/*  977 */         _userHandlerMap.put(userid, handlers);
/*      */       } 
/*      */     } 
/*  980 */     synchronized (handlers) {
/*  981 */       String text = null;
/*  982 */       if (admin) {
/*  983 */         if (handlers[0] == null)
/*      */         {
/*  985 */           handlers[0] = MCLogHandler.create(MCLogHandler.Type.ADMIN, 
/*  986 */               userid);
/*      */         }
/*  988 */         text = msg.toString();
/*  989 */         handlers[0].publish(text);
/*      */       } 
/*  991 */       if (debug) {
/*  992 */         if (handlers[1] == null)
/*      */         {
/*  994 */           handlers[1] = MCLogHandler.create(MCLogHandler.Type.DEBUG, 
/*  995 */               userid);
/*      */         }
/*  997 */         text = (text == null) ? msg.toString() : text;
/*  998 */         handlers[1].publish(text);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1009 */   static MCLogHandler dummyHandler = new MCLogHandler(null)
/*      */     {
/*      */       void publish(String log) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       void write(String log) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       void follow(String log) {}
/*      */     };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   MCLog.FollowWriter followWriter(MCMessageLevel level) {
/* 1035 */     boolean admin = this._checker.isAdminEnabled(level);
/* 1036 */     boolean debug = this._checker.isDebugEnabled(level);
/* 1037 */     if (!admin && !debug)
/*      */     {
/* 1039 */       return new MCLog.FollowWriter(dummyHandler, dummyHandler);
/*      */     }
/*      */     
/* 1042 */     String userid = MCSys.user.ID();
/*      */     
/* 1044 */     MCLogHandler[] handlers = null;
/* 1045 */     synchronized (_userHandlerMap) {
/* 1046 */       handlers = _userHandlerMap.get(userid);
/* 1047 */       if (handlers == null)
/*      */       {
/*      */         
/* 1050 */         return new MCLog.FollowWriter(dummyHandler, dummyHandler);
/*      */       }
/*      */     } 
/* 1053 */     synchronized (handlers) {
/* 1054 */       MCLogHandler adminH = (admin && handlers[0] != null) ? 
/* 1055 */         handlers[0] : dummyHandler;
/* 1056 */       MCLogHandler debugH = (debug && handlers[1] != null) ? 
/* 1057 */         handlers[1] : dummyHandler;
/* 1058 */       return new MCLog.FollowWriter(adminH, debugH);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   MCLog.DelayWriter delayWriter(MCMessage msg) {
/* 1072 */     MCMessageLevel level = msg.getLevel();
/* 1073 */     boolean admin = this._checker.isAdminEnabled(level);
/* 1074 */     boolean debug = this._checker.isDebugEnabled(level);
/* 1075 */     return (admin || debug) ? 
/* 1076 */       new MCLog.DelayWriter(msg) : 
/*      */       
/* 1078 */       new MCLog.DelayWriter();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void delay(MCLog.DelayWriter delay) {
/* 1090 */     if (!delay.isValid()) {
/*      */       return;
/*      */     }
/*      */     
/* 1094 */     MCMessage msg = delay.getHeader();
/* 1095 */     MCMessageLevel level = msg.getLevel();
/* 1096 */     boolean admin = this._checker.isAdminEnabled(level);
/* 1097 */     boolean debug = this._checker.isDebugEnabled(level);
/* 1098 */     if (!admin && !debug) {
/*      */       return;
/*      */     }
/* 1101 */     StringBuilder logBuffer = createLogBuffer(level, msg.getID());
/* 1102 */     logBuffer.append(msg.toString());
/* 1103 */     logBuffer.append(LINE_SEP);
/*      */     
/* 1105 */     String userid = MCSys.user.ID();
/*      */     
/* 1107 */     MCLogHandler[] handlers = null;
/* 1108 */     synchronized (_userHandlerMap) {
/* 1109 */       handlers = _userHandlerMap.get(userid);
/* 1110 */       if (handlers == null) {
/*      */         
/* 1112 */         handlers = new MCLogHandler[2];
/* 1113 */         _userHandlerMap.put(userid, handlers);
/*      */       } 
/*      */     } 
/* 1116 */     synchronized (handlers) {
/* 1117 */       String text = null;
/* 1118 */       MCLogHandler[] delayhandlers = { dummyHandler, dummyHandler };
/* 1119 */       if (admin) {
/* 1120 */         if (handlers[0] == null)
/*      */         {
/* 1122 */           handlers[0] = MCLogHandler.create(MCLogHandler.Type.ADMIN, 
/* 1123 */               userid);
/*      */         }
/* 1125 */         text = logBuffer.toString();
/* 1126 */         handlers[0].publish(text);
/* 1127 */         delayhandlers[0] = handlers[0];
/*      */       } 
/* 1129 */       if (debug) {
/* 1130 */         if (handlers[1] == null)
/*      */         {
/* 1132 */           handlers[1] = MCLogHandler.create(MCLogHandler.Type.DEBUG, 
/* 1133 */               userid);
/*      */         }
/* 1135 */         text = (text == null) ? logBuffer.toString() : text;
/* 1136 */         handlers[1].publish(text);
/* 1137 */         delayhandlers[1] = handlers[1];
/*      */       } 
/* 1139 */       joinDelay(delay.getFile(), delayhandlers);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void joinDelay(File file, MCLogHandler... handlers) {
/* 1153 */     boolean cancel = true; byte b; int i; MCLogHandler[] arrayOfMCLogHandler;
/* 1154 */     for (i = (arrayOfMCLogHandler = handlers).length, b = 0; b < i; ) { MCLogHandler handler = arrayOfMCLogHandler[b];
/* 1155 */       if (handler != dummyHandler) {
/* 1156 */         cancel = false; break;
/*      */       } 
/*      */       b++; }
/*      */     
/* 1160 */     if (cancel) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 1165 */     Charset cs = MCLogFileHandler.getCharset(file);
/* 1166 */     if (cs == null)
/* 1167 */       cs = Charset.defaultCharset(); 
/*      */     try {
/* 1169 */       Exception exception2, exception1 = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 1176 */     catch (IOException e) {
/* 1177 */       byte b1; int j; MCLogHandler[] arrayOfMCLogHandler1; for (j = (arrayOfMCLogHandler1 = handlers).length, b1 = 0; b1 < j; ) { MCLogHandler handler = arrayOfMCLogHandler1[b1];
/* 1178 */         handler.handlerError(e);
/*      */         b1++; }
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static abstract class EnableChecker
/*      */   {
/*      */     abstract boolean isAdminEnabled(MCMessageLevel param1MCMessageLevel);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     abstract boolean isDebugEnabled(MCMessageLevel param1MCMessageLevel);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected final MCMessageLevel getAdminLimitLevel(String key) {
/* 1230 */       String limitkey = MCLogHandler.Type.ADMIN.getResourceKey(key);
/* 1231 */       return getLimitLevel(limitkey, MCLogger.DEFAULT_LEVEL_ADMIN);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected final MCMessageLevel getDebugLimitLevel(String key) {
/* 1254 */       String limitkey = MCLogHandler.Type.DEBUG.getResourceKey(key);
/* 1255 */       MCMessageLevel limit = getLimitLevel(limitkey, MCLogger.DEFAULT_LEVEL_DEBUG);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1261 */       return limit;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final MCMessageLevel getLimitLevel(String key, MCMessageLevel def) {
/*      */       MCMessageLevel level;
/* 1282 */       String limitstr = MCConfig.common.getString(key);
/* 1283 */       if (limitstr == null)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1295 */         return null;
/*      */       }
/*      */ 
/*      */       
/*      */       try {
/* 1300 */         level = MCMessageLevel.valueOf(limitstr);
/*      */       }
/* 1302 */       catch (Exception exception) {
/* 1303 */         level = def;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1316 */       return level;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected final boolean checkEnabled(MCMessageLevel level, MCMessageLevel limit) {
/* 1334 */       if (limit == null) {
/* 1335 */         return false;
/*      */       }
/* 1337 */       if (level == null) {
/* 1338 */         return true;
/*      */       }
/* 1340 */       return (level.compareTo(limit) >= 0);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static class FrameworkChecker
/*      */     extends EnableChecker
/*      */   {
/*      */     private MCMessageLevel _adminlv;
/*      */ 
/*      */     
/*      */     private MCMessageLevel _debuglv;
/*      */ 
/*      */ 
/*      */     
/*      */     private FrameworkChecker() {
/* 1357 */       this._adminlv = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1364 */       this._debuglv = null;
/*      */     }
/*      */ 
/*      */     
/*      */     public final boolean isAdminEnabled(MCMessageLevel level) {
/* 1369 */       if (this._adminlv == null) {
/* 1370 */         String lvkey = getLimitLevelKey(MCLogHandler.Type.ADMIN);
/* 1371 */         this._adminlv = getAdminLimitLevel(lvkey);
/*      */       } 
/* 1373 */       return checkEnabled(level, this._adminlv);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public final boolean isDebugEnabled(MCMessageLevel level) {
/* 1379 */       if (this._debuglv == null) {
/* 1380 */         String lvkey = getLimitLevelKey(MCLogHandler.Type.DEBUG);
/* 1381 */         this._debuglv = getDebugLimitLevel(lvkey);
/*      */       } 
/* 1383 */       return checkEnabled(level, this._debuglv);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final String getLimitLevelKey(MCLogHandler.Type type) {
/* 1398 */       String fwkey = type.getResourceKey("fwlevel");
/*      */       
/* 1400 */       String fwval = MCConfig.common.getString(fwkey);
/* 1401 */       String key = (fwval != null && fwval.equals("APP")) ? "level" : 
/* 1402 */         "fwlevel";
/* 1403 */       return key;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static class ApplicationChecker
/*      */     extends EnableChecker
/*      */   {
/*      */     private MCMessageLevel _adminlv;
/*      */ 
/*      */     
/*      */     private MCMessageLevel _debuglv;
/*      */ 
/*      */ 
/*      */     
/*      */     private ApplicationChecker() {
/* 1420 */       this._adminlv = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1427 */       this._debuglv = null;
/*      */     }
/*      */ 
/*      */     
/*      */     public final boolean isAdminEnabled(MCMessageLevel level) {
/* 1432 */       if (this._adminlv == null) {
/* 1433 */         this._adminlv = getAdminLimitLevel("level");
/*      */       }
/* 1435 */       return checkEnabled(level, this._adminlv);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public final boolean isDebugEnabled(MCMessageLevel level) {
/* 1441 */       if (this._debuglv == null) {
/* 1442 */         this._debuglv = getDebugLimitLevel("level");
/*      */       }
/* 1444 */       return checkEnabled(level, this._debuglv);
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\notice\MCLogger.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */