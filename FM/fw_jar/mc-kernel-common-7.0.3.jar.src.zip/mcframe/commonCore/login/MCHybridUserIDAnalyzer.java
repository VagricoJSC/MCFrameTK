/*     */ package mcframe.commonCore.login;
/*     */ 
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.resource.MCConst;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCHybridUserIDAnalyzer
/*     */ {
/*     */   public static final String KEY_ID_PLUGIN = "auth.common.hybrid.userid.analyzer";
/*     */   public static final String KEY_ID_SEPARATOR = "auth.common.hybrid.userid.separator";
/*     */   public static final String KEY_USER_POS = "auth.common.hybrid.userid.userpos";
/*     */   public static final String DEFAULT_ID_SEPARATOR = "@";
/*     */   public static final int DEFAULT_USER_POS = 0;
/*     */   
/*     */   public String generate(String user, String store) {
/*  78 */     if (user == null || store == null) {
/*     */       
/*  80 */       MCException cause = new MCException(Core_Msg_FW_A.FCBHC0132, new Object[] { user, store });
/*  81 */       throw new MCException(cause, Core_Msg_FW_A.FCBHC0127, new Object[0]);
/*     */     } 
/*  83 */     if (MCAuth.isAdminUser(user))
/*     */     {
/*  85 */       return user;
/*     */     }
/*  87 */     if ("default".equals(store))
/*     */     {
/*  89 */       return user;
/*     */     }
/*     */     
/*  92 */     int upos = MCConst.plugin.getInteger("auth.common.hybrid.userid.userpos", 0);
/*  93 */     if (upos < 0) {
/*     */       
/*  95 */       MCException cause = new MCException(Core_Msg_FW_A.FCBHC0128, new Object[] { Integer.valueOf(upos) });
/*  96 */       throw new MCException(cause, Core_Msg_FW_A.FCBHC0127, new Object[0]);
/*     */     } 
/*  98 */     if (upos > 1) {
/*  99 */       upos = 1;
/*     */     }
/*     */     
/* 102 */     String sep = MCConst.plugin.getString("auth.common.hybrid.userid.separator", "@");
/* 103 */     return (upos == 0) ? (String.valueOf(user) + sep + store) : (String.valueOf(store) + sep + user);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] analyze(String userid) {
/* 124 */     if (userid == null) {
/*     */       
/* 126 */       MCException cause = new MCException(Core_Msg_FW_A.FCBHC0131, new Object[] { userid });
/* 127 */       throw new MCException(cause, Core_Msg_FW_A.FCBHC0127, new Object[0]);
/*     */     } 
/* 129 */     if (MCAuth.isAdminUser(userid))
/*     */     {
/* 131 */       return new String[] { userid, "default" };
/*     */     }
/*     */ 
/*     */     
/* 135 */     String sep = MCConst.plugin.getString("auth.common.hybrid.userid.separator", "@");
/* 136 */     int pos = userid.lastIndexOf(sep);
/* 137 */     if (pos < 0)
/*     */     {
/* 139 */       return new String[] { userid, "default" };
/*     */     }
/*     */ 
/*     */     
/* 143 */     int upos = MCConst.plugin.getInteger("auth.common.hybrid.userid.userpos", 0);
/* 144 */     if (upos < 0 || 1 < upos) {
/*     */       
/* 146 */       MCException cause = new MCException(Core_Msg_FW_A.FCBHC0128, new Object[] { Integer.valueOf(upos) });
/* 147 */       throw new MCException(cause, Core_Msg_FW_A.FCBHC0127, new Object[0]);
/*     */     } 
/*     */     
/* 150 */     String[] ids = new String[2];
/* 151 */     int fpos = (upos == 0) ? 0 : 1;
/* 152 */     int lpos = (upos == 0) ? 1 : 0;
/* 153 */     ids[fpos] = userid.substring(0, pos);
/* 154 */     ids[lpos] = userid.substring(pos + 1);
/*     */ 
/*     */     
/* 157 */     if ("default".equals(ids[1])) {
/* 158 */       ids[0] = userid;
/* 159 */       ids[1] = "default";
/*     */     } 
/*     */     
/* 162 */     return ids;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\login\MCHybridUserIDAnalyzer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */