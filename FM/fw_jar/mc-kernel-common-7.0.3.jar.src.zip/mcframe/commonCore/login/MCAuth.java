/*     */ package mcframe.commonCore.login;
/*     */ 
/*     */ import java.util.regex.Pattern;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.commonCore.resource.MCConfig;
/*     */ import mcframe.commonCore.resource.MCConst;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MCAuth
/*     */ {
/*     */   public static final String ARC_CD = "7";
/*  37 */   public static final String MSGID_SESSION_EXIST = Core_Msg_FW_A.FCBHC0001;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  45 */   public static final String MSGID_PW_EXPIRE = Core_Msg_FW_A.FCBHC0007;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   public static final String MSGID_PW_CAUTION = Core_Msg_FW_A.FCBHC0013;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   public static final String MSGID_LIC_LIMIT = Core_Msg_FW_A.FCBHC0058;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   public static final String MSGID_LIC_PERIOD = Core_Msg_FW_A.FCBHC0061;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String PROD_MEDICINE = "750";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String PROD_NXLINK = "770";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String PROD_PLMLINK = "780";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String FNCGRP_LISTENER = "LISTENER";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String STORETYPE_MCFRAME = "MCFRAME";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String STORETYPE_LDAP = "LDAP";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 123 */   private static MCHybridUserIDAnalyzer _hybrid_analyzer = isHybridAuthMode() ? 
/* 124 */     (MCHybridUserIDAnalyzer)MCConst.plugin.create(MCHybridUserIDAnalyzer.class, 
/* 125 */       "auth.common.hybrid.userid.analyzer") : 
/* 126 */     null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String STORE_NONE = "default";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String HYBRID_CLIENT_WINSSO = "WINSSO";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final String LOGINARG_HYBRID_CLIENT = "hybrid_client";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final String AUTH_MCFRAME = "MCFRAME";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final String AUTH_SEMILDAP = "SEMILDAP";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final String AUTH_LDAP = "LDAP";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final String AUTH_WINSSO = "WINSSO";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final String AUTH_HYBRID = "HYBRID";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String AUTH_KEY = "auth";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String EXTAUTH_KEY = "extauth";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 200 */   public static final String EXTAUTH_BASE_KEY = MCConst.createKey(new String[] { "auth", "common", 
/* 201 */         "extauth" });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String SAML_SP_URL_KEY = "sp.url";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String EXTAUTH_MODE = "extmode";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 221 */   private static String _authmode = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 228 */   private static String _extauthmode = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final String OVERLAP_NONE = "none";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final String OVERLAP_CONFIRM = "confirm";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final String OVERLAP_FORCED = "forced";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 257 */   private static String _overlap = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final void setAuthParam() {
/* 266 */     _authmode = MCConfig.common.getString("auth.mode", "MCFRAME");
/* 267 */     _overlap = MCConfig.common.getString("auth.overlap", "none");
/* 268 */     MCLog.write(Core_Msg_FW_A.FCBHC0080, new Object[] { _authmode, _overlap });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final String getAuthMode() {
/* 282 */     if (_authmode == null) {
/* 283 */       setAuthParam();
/*     */     }
/* 285 */     return _authmode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean isDefaultAuthMode() {
/* 296 */     return "MCFRAME".equals(getAuthMode());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean isSemiLDAPAuthMode() {
/* 308 */     return "SEMILDAP".equals(getAuthMode());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean isLDAPAuthMode() {
/* 319 */     return "LDAP".equals(getAuthMode());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean isWindowsSSOMode() {
/* 330 */     return "WINSSO".equals(getAuthMode());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean isHybridAuthMode() {
/* 342 */     return "HYBRID".equals(getAuthMode());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean isCustomMode() {
/* 353 */     if (!isDefaultAuthMode())
/*     */     {
/* 355 */       if (!isSemiLDAPAuthMode() && !isLDAPAuthMode())
/*     */       {
/* 357 */         if (!isWindowsSSOMode())
/*     */         {
/* 359 */           if (!isHybridAuthMode()) {
/*     */             return true;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean useInternalUserList() {
/* 385 */     if (!isDefaultAuthMode() && !isSemiLDAPAuthMode())
/*     */     {
/* 387 */       if (!isHybridAuthMode()) {
/*     */         return false;
/*     */       }
/*     */     }
/*     */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final MCHybridUserIDAnalyzer getHybridUserIDAnalyzer() {
/* 402 */     return _hybrid_analyzer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String[] getHybridStoreArray() {
/* 419 */     if (_hybrid_analyzer == null) {
/* 420 */       return null;
/*     */     }
/*     */     
/* 423 */     String[] stores = MCConfig.common.findPattern("auth.hybrid.store.*");
/* 424 */     for (int i = 0; i < stores.length; i++) {
/* 425 */       String store = stores[i];
/* 426 */       int pos = store.lastIndexOf('.');
/* 427 */       stores[i] = store.substring(pos + 1);
/*     */     } 
/* 429 */     return stores;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String getHybridStoreType(String store) {
/* 444 */     if (_hybrid_analyzer == null) {
/* 445 */       return null;
/*     */     }
/* 447 */     return MCConfig.common.getString(MCConfig.createKey(new String[] { "auth.hybrid.store", store }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String getHybridStoreTypeFor(String userid) {
/* 465 */     if (_hybrid_analyzer == null) {
/* 466 */       return null;
/*     */     }
/* 468 */     if (isAdminUser(userid))
/*     */     {
/* 470 */       return "MCFRAME";
/*     */     }
/* 472 */     String[] ids = _hybrid_analyzer.analyze(userid);
/* 473 */     return MCConfig.common.getString(MCConfig.createKey(new String[] { "auth.hybrid.store", ids[1] }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isHybridInternalUser(String userid) {
/* 489 */     if (isAdminUser(userid))
/*     */     {
/* 491 */       return true;
/*     */     }
/* 493 */     String type = getHybridStoreTypeFor(userid);
/* 494 */     return "MCFRAME".equals(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getAvailableExtAuthMode() {
/* 505 */     return MCConfig.common.getString("auth.external.mode", null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static String getExtAuthMode() {
/* 516 */     return _extauthmode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setExtAuthMode(String mode) {
/* 526 */     _extauthmode = mode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final String getOverlap() {
/* 542 */     if (_overlap == null) {
/* 543 */       setAuthParam();
/*     */     }
/* 545 */     return _overlap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 553 */   private static final Pattern _adminptn = Pattern.compile("admin[1-3]", 
/* 554 */       32);
/*     */   
/*     */   private static final String MODULE = "FC";
/*     */   
/*     */   private static final String LOGIC_AUTH = "FCBHL0010";
/*     */   private static final String OPE_AUTH_LOGIN = "Login";
/*     */   private static final String OPE_AUTH_LOGIN_EX = "LoginEx";
/*     */   private static final String OPE_AUTH_GENE_LOGIN = "GeneralLogin";
/*     */   private static final String OPE_AUTH_GENE_LOGIN_EX = "GeneralLoginEx";
/*     */   private static final String OPE_AUTH_LOGOUT = "Logout";
/*     */   
/*     */   public static final boolean isAdminUser(String id) {
/* 566 */     if (id == null) {
/* 567 */       return false;
/*     */     }
/* 569 */     return _adminptn.matcher(id).matches();
/*     */   }
/*     */   
/*     */   private static final String OPE_AUTH_GENE_LOGOUT = "GeneralLogout";
/*     */   private static final String LOGIC_ACL = "FCBHL0400";
/*     */   private static final String LOGIC_RESOURCE = "FCBJL0100";
/*     */   private static final String SDMODULE = "PC";
/*     */   private static final String SDLOGIC_AUTH = "PCBWL0100";
/*     */   private static final String SDOPE_AUTH_LOGIN = "DoLogin";
/*     */   private static final String SDOPE_AUTH_LOGOUT = "DoLogout";
/*     */   
/*     */   public static final String[] getAdminUsers() {
/* 581 */     return new String[] {
/* 582 */         "admin1", "admin2", "admin3"
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isLoginOperation(MCParam param) {
/* 748 */     return isLoginOperation(param.getModuleId(), param.getLogicId(), 
/* 749 */         param.getOperationId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isLoginOperation(String mid, String lid, String oid) {
/* 765 */     if (MCStringUtil.eq(mid, "FC") && MCStringUtil.eq(lid, "FCBHL0010")) {
/* 766 */       if (!MCStringUtil.eq(oid, "Login"))
/*     */       
/*     */       { 
/* 769 */         if (!MCStringUtil.eq(oid, "LoginEx"))
/*     */         
/* 771 */         { if (MCStringUtil.eq(oid, "GeneralLogin") || 
/* 772 */             MCStringUtil.eq(oid, "GeneralLoginEx"))
/* 773 */             return true;  } else { return true; }  } else { return true; }
/*     */     
/*     */     }
/* 776 */     if (MCStringUtil.eq(mid, "PC") && MCStringUtil.eq(lid, "PCBWL0100") && 
/* 777 */       MCStringUtil.eq(oid, "DoLogin")) {
/* 778 */       return true;
/*     */     }
/* 780 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isLogoutOperation(MCParam param) {
/* 792 */     return isLogoutOperation(param.getModuleId(), param.getLogicId(), 
/* 793 */         param.getOperationId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isLogoutOperation(String mid, String lid, String oid) {
/* 809 */     if (MCStringUtil.eq(mid, "FC") && MCStringUtil.eq(lid, "FCBHL0010")) {
/* 810 */       if (!MCStringUtil.eq(oid, "Logout"))
/*     */       
/* 812 */       { if (MCStringUtil.eq(oid, "GeneralLogout"))
/* 813 */           return true;  } else { return true; }
/*     */     
/*     */     }
/* 816 */     if (MCStringUtil.eq(mid, "PC") && MCStringUtil.eq(lid, "PCBWL0100") && 
/* 817 */       MCStringUtil.eq(oid, "DoLogout")) {
/* 818 */       return true;
/*     */     }
/* 820 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isACLOperation(MCParam param) {
/* 832 */     return isACLOperation(param.getModuleId(), param.getLogicId(), 
/* 833 */         param.getOperationId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isACLOperation(String mid, String lid, String oid) {
/* 847 */     return (MCStringUtil.eq(mid, "FC") && MCStringUtil.eq(lid, "FCBHL0400"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isResourceOperation(MCParam param) {
/* 865 */     return isResourceOperation(param.getModuleId(), param.getLogicId(), 
/* 866 */         param.getOperationId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isResourceOperation(String mid, String lid, String oid) {
/* 880 */     return (MCStringUtil.eq(mid, "FC") && MCStringUtil.eq(lid, "FCBJL0100"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnableModuleSelect(String userid) {
/* 909 */     boolean modselect = MCConfig.common.getBoolean("auth.license.unnamed.modselect", 
/* 910 */         false);
/*     */     
/* 912 */     return (!isAdminUser(userid) && modselect && !isNamed());
/*     */   }
/*     */   
/*     */   public abstract boolean isNamed();
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\login\MCAuth.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */