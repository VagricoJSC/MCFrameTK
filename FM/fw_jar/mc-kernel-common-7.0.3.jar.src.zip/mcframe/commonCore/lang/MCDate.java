/*     */ package mcframe.commonCore.lang;
/*     */ 
/*     */ import java.util.Date;
/*     */ import java.util.GregorianCalendar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MCDate
/*     */   extends MCCalendarDate<MCDate>
/*     */ {
/*     */   public static final String TO_STRING_FORMAT = "yyyyMMddHHmmss";
/*     */   
/*     */   public static final MCDate osnow() {
/*  38 */     return new MCDate(System.currentTimeMillis());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final MCDate ostoday() {
/*  51 */     return new MCDate(roundToday(System.currentTimeMillis()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final MCDate sysnow() {
/*  62 */     return new MCDate(current());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final MCDate systoday() {
/*  75 */     return new MCDate(roundToday(current()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final MCDate now() {
/*  86 */     return new MCDate(currentCo());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final MCDate today() {
/*  99 */     return new MCDate(roundToday(currentCo()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCDate valueOf(MCTimestamp timestamp) {
/* 114 */     return (timestamp != null) ? new MCDate(timestamp._time) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCDate valueOf(Date date) {
/* 131 */     return (date != null) ? new MCDate(date.getTime()) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCDate valueOf(String text, String format) {
/* 154 */     MCDateFormat f = MCDateFormat.create(format);
/* 155 */     return valueOf(text, f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCDate valueOf(String text, MCDateFormat format) {
/* 177 */     Date date = stringToDate(format, text);
/* 178 */     return valueOf(date);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCDate valueOf(int... val) {
/* 199 */     return valueOf(YEAR, val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCDate valueOf(MCDateFieldType field, int... val) {
/* 227 */     if (field == MILLISECOND)
/*     */     {
/* 229 */       return null;
/*     */     }
/* 231 */     int fieldlen = 6;
/* 232 */     long time = longValueOf(field, fieldlen, val);
/* 233 */     return (time != Long.MIN_VALUE) ? new MCDate(time) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCDate() {
/* 255 */     super(currentCo());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCDate(long time) {
/* 268 */     super(time);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final long inittime(long time) {
/* 281 */     return time - time % 1000L;
/*     */   }
/*     */   
/*     */   final MCDate parse(String text, String format) {
/* 285 */     return valueOf(text, format);
/*     */   }
/*     */   
/*     */   final MCDate parse(long time) {
/* 289 */     return new MCDate(time);
/*     */   }
/*     */   
/*     */   final String getToStringFormat() {
/* 293 */     return "yyyyMMddHHmmss";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCDate modTime(MCCalendarDate<?> date) {
/* 303 */     GregorianCalendar othc = createCalendar();
/* 304 */     othc.setTimeInMillis((date != null) ? date._time : 0L);
/* 305 */     GregorianCalendar ownc = calcCalendar();
/* 306 */     ownc.set(HOUR.getField(), othc.get(HOUR.getField()));
/* 307 */     ownc.set(MINUTE.getField(), othc.get(MINUTE.getField()));
/* 308 */     ownc.set(SECOND.getField(), othc.get(SECOND.getField()));
/* 309 */     ownc.set(MILLISECOND.getField(), 0);
/* 310 */     return parse(ownc.getTimeInMillis());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCDate startTimeOfYear() {
/* 324 */     return super.startTimeOfYear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCDate endTimeOfYear() {
/* 337 */     GregorianCalendar c = calcCalendar();
/* 338 */     c.set(MONTH.getField(), 11);
/* 339 */     c.set(DAY.getField(), 31);
/* 340 */     c.set(HOUR.getField(), 23);
/* 341 */     c.set(MINUTE.getField(), 59);
/* 342 */     c.set(SECOND.getField(), 59);
/* 343 */     c.set(MILLISECOND.getField(), 0);
/* 344 */     return parse(c.getTimeInMillis());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCDate startTimeOfMonth() {
/* 357 */     return super.startTimeOfMonth();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCDate endTimeOfMonth() {
/* 370 */     GregorianCalendar c = calcCalendar();
/* 371 */     c.set(DAY.getField(), c.getActualMaximum(DAY.getField()));
/* 372 */     c.set(HOUR.getField(), 23);
/* 373 */     c.set(MINUTE.getField(), 59);
/* 374 */     c.set(SECOND.getField(), 59);
/* 375 */     c.set(MILLISECOND.getField(), 0);
/* 376 */     return parse(c.getTimeInMillis());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCDate startTimeOfDay() {
/* 390 */     return super.startTimeOfDay();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCDate endTimeOfDay() {
/* 404 */     GregorianCalendar c = calcCalendar();
/* 405 */     c.set(HOUR.getField(), 23);
/* 406 */     c.set(MINUTE.getField(), 59);
/* 407 */     c.set(SECOND.getField(), 59);
/* 408 */     c.set(MILLISECOND.getField(), 0);
/* 409 */     return parse(c.getTimeInMillis());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCTimestamp toMCTimestamp() {
/* 426 */     return MCTimestamp.valueOf(this);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\lang\MCDate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */