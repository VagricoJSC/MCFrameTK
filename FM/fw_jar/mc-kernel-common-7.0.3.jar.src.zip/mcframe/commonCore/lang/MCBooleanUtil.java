/*    */ package mcframe.commonCore.lang;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MCBooleanUtil
/*    */ {
/*    */   private static final String BOOLEAN_DB_TRUE = "1";
/*    */   private static final String BOOLEAN_DB_FALSE = "0";
/*    */   
/*    */   public static boolean dbStringToBoolean(String dbstr) {
/* 52 */     return (dbstr != null && dbstr.equals("1"));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String booleanToDBString(boolean boo) {
/* 64 */     return boo ? "1" : "0";
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\lang\MCBooleanUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */