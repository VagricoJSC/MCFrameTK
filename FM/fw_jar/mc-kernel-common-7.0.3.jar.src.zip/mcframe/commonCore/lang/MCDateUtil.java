/*     */ package mcframe.commonCore.lang;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MCDateUtil
/*     */ {
/*     */   public static boolean eq(MCCalendarDate<?> d1, MCCalendarDate<?> d2, MCDateFieldType... fields) {
/*  40 */     return !((d1 != null || d2 != null) && (d1 == null || !d1.eq(d2, fields)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean[] includeDateFieldType(String pattern) {
/*  68 */     if (MCStringUtil.isNull(pattern)) {
/*  69 */       return null;
/*     */     }
/*     */     
/*  72 */     boolean[] a = new boolean[7]; byte b; int i; char[] arrayOfChar;
/*  73 */     for (i = (arrayOfChar = pattern.toCharArray()).length, b = 0; b < i; ) { char c = arrayOfChar[b];
/*  74 */       switch (c) {
/*     */         case 'y':
/*  76 */           a[0] = true;
/*     */           break;
/*     */         case 'M':
/*  79 */           a[1] = true;
/*     */           break;
/*     */         case 'd':
/*  82 */           a[2] = true;
/*     */           break;
/*     */         case 'H':
/*     */         case 'h':
/*  86 */           a[3] = true;
/*     */           break;
/*     */         case 'm':
/*  89 */           a[4] = true;
/*     */           break;
/*     */         case 's':
/*  92 */           a[5] = true;
/*     */           break;
/*     */         case 'S':
/*  95 */           a[6] = true; break;
/*     */       } 
/*     */       b++; }
/*     */     
/*  99 */     return a;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCDateFieldType getDateFieldType(String pattern) {
/* 111 */     boolean[] a = includeDateFieldType(pattern);
/* 112 */     if (a == null) {
/* 113 */       return null;
/*     */     }
/*     */     
/* 116 */     if (a[6])
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 125 */       return MCDateFieldType.MILLISECOND;
/*     */     }
/* 127 */     if (a[5]) {
/* 128 */       return MCDateFieldType.SECOND;
/*     */     }
/* 130 */     if (a[4]) {
/* 131 */       return MCDateFieldType.MINUTE;
/*     */     }
/* 133 */     if (a[3]) {
/* 134 */       return MCDateFieldType.HOUR;
/*     */     }
/* 136 */     if (a[2]) {
/* 137 */       return MCDateFieldType.DAY;
/*     */     }
/* 139 */     if (a[1]) {
/* 140 */       return MCDateFieldType.MONTH;
/*     */     }
/* 142 */     if (a[0]) {
/* 143 */       return MCDateFieldType.YEAR;
/*     */     }
/* 145 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<MCDateFieldType> getDateFieldTypeList(String pattern) {
/* 157 */     boolean[] a = includeDateFieldType(pattern);
/* 158 */     if (a == null) {
/* 159 */       return null;
/*     */     }
/*     */     
/* 162 */     List<MCDateFieldType> l = new ArrayList<>();
/* 163 */     if (a[0]) {
/* 164 */       l.add(MCDateFieldType.YEAR);
/*     */     }
/* 166 */     if (a[1]) {
/* 167 */       l.add(MCDateFieldType.MONTH);
/*     */     }
/* 169 */     if (a[2]) {
/* 170 */       l.add(MCDateFieldType.DAY);
/*     */     }
/* 172 */     if (a[3]) {
/* 173 */       l.add(MCDateFieldType.HOUR);
/*     */     }
/* 175 */     if (a[4]) {
/* 176 */       l.add(MCDateFieldType.MINUTE);
/*     */     }
/* 178 */     if (a[5]) {
/* 179 */       l.add(MCDateFieldType.SECOND);
/*     */     }
/* 181 */     if (a[6]) {
/* 182 */       l.add(MCDateFieldType.MILLISECOND);
/*     */     }
/* 184 */     return l;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCDateFieldType[] getDateFieldTypes(String pattern) {
/* 196 */     List<MCDateFieldType> l = getDateFieldTypeList(pattern);
/* 197 */     if (l == null) {
/* 198 */       return null;
/*     */     }
/* 200 */     return l.<MCDateFieldType>toArray(new MCDateFieldType[l.size()]);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\lang\MCDateUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */