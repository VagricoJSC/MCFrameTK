/*     */ package mcframe.commonCore.lang;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum MCDateFieldType
/*     */ {
/*  13 */   YEAR(
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  18 */     1),
/*     */   
/*  20 */   MONTH(
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  33 */     2),
/*     */   
/*  35 */   DAY(
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  40 */     5),
/*     */   
/*  42 */   HOUR(
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  47 */     11),
/*     */   
/*  49 */   MINUTE(
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  69 */     12),
/*     */   
/*  71 */   SECOND(
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  76 */     13),
/*     */   
/*  78 */   MILLISECOND(
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  83 */     14);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int calField;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final MCDateFieldType[] scaleValues() {
/*  96 */     return new MCDateFieldType[] {
/*  97 */         YEAR, MONTH, DAY, HOUR, MINUTE, SECOND, MILLISECOND
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCDateFieldType(int calendarField) {
/* 115 */     this.calField = calendarField;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getField() {
/* 124 */     return this.calField;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\lang\MCDateFieldType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */