/*     */ package mcframe.commonCore.lang;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCDataMatcher
/*     */ {
/*     */   public static final String EQUAL = "EQUAL";
/*     */   public static final String NOT_EQUAL = "NOT_EQUAL";
/*     */   public static final String LESS_THAN = "LESS_THAN";
/*     */   public static final String LESS_THAN_EQUAL = "LESS_THAN_EQUAL";
/*     */   public static final String GREATER_THAN = "GREATER_THAN";
/*     */   public static final String GREATER_THAN_EQUAL = "GREATER_THAN_EQUAL";
/*     */   public static final String START_WITH = "START_WITH";
/*     */   public static final String NOT_START_WITH = "NOT_START_WITH";
/*     */   public static final String END_WITH = "END_WITH";
/*     */   public static final String NOT_END_WITH = "NOT_END_WITH";
/*     */   public static final String CONTAINS = "CONTAINS";
/*     */   public static final String NOT_CONTAINS = "NOT_CONTAINS";
/*     */   private final MCDataType _type;
/*     */   private final String _operator;
/*     */   private final Comparable<?> _border;
/*     */   
/*     */   public static List<String> getEnableRelativeOperatorList(MCDataType type) {
/* 186 */     List<String> l = new ArrayList<>();
/*     */     
/* 188 */     if (type == null || 
/* 189 */       MCDataType.ROW.equals(type) || 
/* 190 */       MCDataType.BINARY.equals(type)) {
/* 191 */       return l;
/*     */     }
/*     */     
/* 194 */     l.add("EQUAL");
/* 195 */     l.add("NOT_EQUAL");
/*     */     
/* 197 */     if (MCDataType.BOOLEAN.equals(type)) {
/* 198 */       return l;
/*     */     }
/*     */     
/* 201 */     l.add("LESS_THAN");
/* 202 */     l.add("LESS_THAN_EQUAL");
/* 203 */     l.add("GREATER_THAN");
/* 204 */     l.add("GREATER_THAN_EQUAL");
/*     */     
/* 206 */     if (MCDataType.NUMBER.equals(type) || 
/* 207 */       MCDataType.DATE.equals(type) || 
/* 208 */       MCDataType.TIMESTAMP.equals(type)) {
/* 209 */       return l;
/*     */     }
/*     */     
/* 212 */     l.add("START_WITH");
/* 213 */     l.add("NOT_START_WITH");
/* 214 */     l.add("END_WITH");
/* 215 */     l.add("NOT_END_WITH");
/* 216 */     l.add("CONTAINS");
/* 217 */     l.add("NOT_CONTAINS");
/*     */     
/* 219 */     return l;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final MCDataMatcher create(String border, String operator) {
/* 232 */     return new MCDataMatcher(MCDataType.STRING, border, operator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final MCDataMatcher create(MCNumber border, String operator) {
/* 245 */     return new MCDataMatcher(MCDataType.NUMBER, border, operator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final MCDataMatcher create(MCDate border, String operator) {
/* 258 */     return new MCDataMatcher(MCDataType.DATE, border, operator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final MCDataMatcher create(MCTimestamp border, String operator) {
/* 271 */     return new MCDataMatcher(MCDataType.TIMESTAMP, border, operator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final MCDataMatcher create(boolean border, String operator) {
/* 284 */     return new MCDataMatcher(MCDataType.BOOLEAN, Boolean.valueOf(border), operator);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 315 */   private MCDateFieldType[] _date_field = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCDataMatcher(MCDataType type, Comparable<?> border, String operator) {
/* 329 */     this._type = type;
/* 330 */     this._operator = operator;
/* 331 */     this._border = border;
/*     */     
/* 333 */     if (this._border != null && MCDataType.analyze(this._border) != this._type)
/*     */     {
/* 335 */       throw new MCException(Core_Msg_FW_A.FCBFC0030, new Object[] { this._type, this._border.getClass() });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDateFieldType(MCDateFieldType... fields) {
/* 353 */     this._date_field = fields;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDateFieldType(List<MCDateFieldType> list) {
/* 362 */     this._date_field = (list != null) ? list.<MCDateFieldType>toArray(new MCDateFieldType[0]) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean match(Comparable<?> value) {
/* 375 */     value = this._type.cast(value);
/*     */     String str;
/* 377 */     switch ((str = this._operator).hashCode()) { case -2063252949: if (!str.equals("NOT_CONTAINS")) {
/*     */           break;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 401 */         return matchNotContain(value);case -1757146678: if (!str.equals("END_WITH")) break;  return matchEndWith(value);case -1583968932: if (!str.equals("LESS_THAN_EQUAL")) break;  return matchLessThanEqual(value);case -1112834937: if (!str.equals("LESS_THAN")) break;  return matchLessThan(value);case -1058410845: if (!str.equals("START_WITH")) break;  return matchStartWith(value);case -199952465: if (!str.equals("NOT_START_WITH")) break;  return matchNotStartWith(value);case 66219796: if (!str.equals("EQUAL")) break;  return matchEqual(value);case 215180831: if (!str.equals("CONTAINS")) break;  return matchContain(value);case 259386838: if (!str.equals("NOT_END_WITH")) break;  return matchNotEndWith(value);case 360410235: if (!str.equals("GREATER_THAN_EQUAL")) break;  return matchGreaterThanEqual(value);case 972152550: if (!str.equals("GREATER_THAN"))
/*     */           break;  return matchGreaterThan(value);case 1022422664: if (!str.equals("NOT_EQUAL"))
/* 403 */           break;  return matchNotEqual(value); }  return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean matchEqual(Comparable<?> value) {
/* 426 */     switch (this._type) {
/*     */       case STRING:
/* 428 */         return MCStringUtil.eqIgnoreCase(
/* 429 */             (String)value, (String)this._border);
/*     */       case DATE:
/* 431 */         return (this._date_field != null) ? 
/* 432 */           MCDateUtil.eq((MCDate)value, (MCDate)this._border, this._date_field) : 
/* 433 */           MCDateUtil.eq((MCDate)value, (MCDate)this._border, new MCDateFieldType[0]);
/*     */       case TIMESTAMP:
/* 435 */         return (this._date_field != null) ? 
/* 436 */           MCDateUtil.eq((MCTimestamp)value, (MCTimestamp)this._border, this._date_field) : 
/* 437 */           MCDateUtil.eq((MCTimestamp)value, (MCTimestamp)this._border, new MCDateFieldType[0]);
/*     */       case BOOLEAN:
/* 439 */         return ((Boolean)value).equals(this._border);
/*     */       case NUMBER:
/* 441 */         return MCNumberUtil.eq((MCNumber)value, (MCNumber)this._border);
/*     */     } 
/* 443 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean matchNotEqual(Comparable<?> value) {
/* 467 */     switch (this._type) {
/*     */       case STRING:
/*     */       case NUMBER:
/*     */       case DATE:
/*     */       case TIMESTAMP:
/*     */       case BOOLEAN:
/* 473 */         return !matchEqual(value);
/*     */     } 
/* 475 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean matchLessThan(Comparable<?> value) {
/* 499 */     if (value == null || this._border == null) {
/* 500 */       return false;
/*     */     }
/*     */     
/* 503 */     switch (this._type) {
/*     */       case STRING:
/* 505 */         return (((String)value).compareToIgnoreCase((String)this._border) < 0);
/*     */       case DATE:
/* 507 */         return (this._date_field != null) ? (
/* 508 */           (MCDate)value).lt((MCDate)this._border, this._date_field) : (
/* 509 */           (((MCDate)value).compareTo((MCDate)this._border) < 0));
/*     */       case TIMESTAMP:
/* 511 */         return (this._date_field != null) ? (
/* 512 */           (MCTimestamp)value).lt((MCTimestamp)this._border, this._date_field) : (
/* 513 */           (((MCTimestamp)value).compareTo((MCTimestamp)this._border) < 0));
/*     */       case NUMBER:
/* 515 */         return (((MCNumber)value).compareTo((MCNumber)this._border) < 0);
/*     */     } 
/* 517 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean matchLessThanEqual(Comparable<?> value) {
/* 542 */     if (value == null || this._border == null) {
/* 543 */       return false;
/*     */     }
/*     */     
/* 546 */     switch (this._type) {
/*     */       case STRING:
/* 548 */         return (((String)value).compareToIgnoreCase((String)this._border) <= 0);
/*     */       case DATE:
/* 550 */         return (this._date_field != null) ? (
/* 551 */           (MCDate)value).lte((MCDate)this._border, this._date_field) : (
/* 552 */           (((MCDate)value).compareTo((MCDate)this._border) <= 0));
/*     */       case TIMESTAMP:
/* 554 */         return (this._date_field != null) ? (
/* 555 */           (MCTimestamp)value).lte((MCTimestamp)this._border, this._date_field) : (
/* 556 */           (((MCTimestamp)value).compareTo((MCTimestamp)this._border) <= 0));
/*     */       case NUMBER:
/* 558 */         return (((MCNumber)value).compareTo((MCNumber)this._border) <= 0);
/*     */     } 
/* 560 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean matchGreaterThan(Comparable<?> value) {
/* 584 */     if (value == null || this._border == null) {
/* 585 */       return false;
/*     */     }
/*     */     
/* 588 */     switch (this._type) {
/*     */       case STRING:
/*     */       case NUMBER:
/*     */       case DATE:
/*     */       case TIMESTAMP:
/* 593 */         return !matchLessThanEqual(value);
/*     */     } 
/* 595 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean matchGreaterThanEqual(Comparable<?> value) {
/* 620 */     if (value == null || this._border == null) {
/* 621 */       return false;
/*     */     }
/*     */     
/* 624 */     switch (this._type) {
/*     */       case STRING:
/*     */       case NUMBER:
/*     */       case DATE:
/*     */       case TIMESTAMP:
/* 629 */         return !matchLessThan(value);
/*     */     } 
/* 631 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean matchStartWith(Comparable<?> value) {
/* 652 */     if (value == null || this._border == null) {
/* 653 */       return false;
/*     */     }
/*     */     
/* 656 */     switch (this._type) {
/*     */       case STRING:
/* 658 */         return ((String)value).toLowerCase().startsWith((
/* 659 */             (String)this._border).toLowerCase());
/*     */     } 
/* 661 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean matchNotStartWith(Comparable<?> value) {
/* 682 */     if (value == null || this._border == null) {
/* 683 */       return false;
/*     */     }
/*     */     
/* 686 */     switch (this._type) {
/*     */       case STRING:
/* 688 */         return !matchStartWith(value);
/*     */     } 
/* 690 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean matchEndWith(Comparable<?> value) {
/* 711 */     if (value == null || this._border == null) {
/* 712 */       return false;
/*     */     }
/*     */     
/* 715 */     switch (this._type) {
/*     */       case STRING:
/* 717 */         return ((String)value).toLowerCase().endsWith((
/* 718 */             (String)this._border).toLowerCase());
/*     */     } 
/* 720 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean matchNotEndWith(Comparable<?> value) {
/* 741 */     if (value == null || this._border == null) {
/* 742 */       return false;
/*     */     }
/*     */     
/* 745 */     switch (this._type) {
/*     */       case STRING:
/* 747 */         return !matchEndWith(value);
/*     */     } 
/* 749 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean matchContain(Comparable<?> value) {
/*     */     String sv;
/*     */     String sc;
/*     */     Pattern p;
/*     */     Matcher m;
/* 770 */     if (value == null || this._border == null) {
/* 771 */       return false;
/*     */     }
/*     */     
/* 774 */     switch (this._type) {
/*     */       case STRING:
/* 776 */         sv = ((String)value).toLowerCase();
/* 777 */         sc = ((String)this._border).toLowerCase();
/* 778 */         sc = "%" + sc + "%";
/* 779 */         sc = sc.replaceAll("%", "\\\\E.*\\\\Q");
/* 780 */         sc = ".*\\Q" + sc + "\\E" + ".*";
/*     */ 
/*     */         
/* 783 */         p = Pattern.compile(sc, 32);
/* 784 */         m = p.matcher(sv);
/* 785 */         return m.matches();
/*     */     } 
/*     */ 
/*     */     
/* 789 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean matchNotContain(Comparable<?> value) {
/* 810 */     if (value == null || this._border == null) {
/* 811 */       return false;
/*     */     }
/*     */     
/* 814 */     switch (this._type) {
/*     */       case STRING:
/* 816 */         return !matchContain(value);
/*     */     } 
/* 818 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\lang\MCDataMatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */