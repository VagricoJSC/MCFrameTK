/*     */ package mcframe.commonCore.lang;
/*     */ 
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum MCDataType
/*     */ {
/*  16 */   STRING
/*     */   {
/*     */ 
/*     */ 
/*     */     
/*     */     public Class<String> dataClass()
/*     */     {
/*  23 */       return String.class;
/*     */     }
/*     */     public String cast(Comparable<?> val) {
/*  26 */       return (String)super.cast(val);
/*     */     }
/*     */     
/*     */     public void setValueNE(MCRow row, String name, Comparable<?> value) {
/*  30 */       row.setStringNE(name, (String)value);
/*     */     }
/*     */     
/*     */     public Comparable<?> getValueNE(MCRow row, String name) {
/*  34 */       return row.getStringNE(name);
/*     */     }
/*     */     
/*     */     public boolean isDateType() {
/*  38 */       return false;
/*     */     }
/*     */   },
/*     */   
/*  42 */   NUMBER
/*     */   {
/*     */ 
/*     */ 
/*     */     
/*     */     public Class<MCNumber> dataClass()
/*     */     {
/*  49 */       return MCNumber.class;
/*     */     }
/*     */     public MCNumber cast(Comparable<?> val) {
/*  52 */       return (MCNumber)super.cast(val);
/*     */     }
/*     */     
/*     */     public void setValueNE(MCRow row, String name, Comparable<?> value) {
/*  56 */       row.setNumberNE(name, (MCNumber)value);
/*     */     }
/*     */     
/*     */     public Comparable<?> getValueNE(MCRow row, String name) {
/*  60 */       return row.getNumberNE(name);
/*     */     }
/*     */     
/*     */     public boolean isDateType() {
/*  64 */       return false;
/*     */     }
/*     */   },
/*     */   
/*  68 */   DATE
/*     */   {
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Class<MCDate> dataClass()
/*     */     {
/*  76 */       return MCDate.class;
/*     */     }
/*     */     public MCDate cast(Comparable<?> val) {
/*  79 */       return (MCDate)super.cast(val);
/*     */     }
/*     */     
/*     */     public void setValueNE(MCRow row, String name, Comparable<?> value) {
/*  83 */       row.setDateNE(name, (MCDate)value);
/*     */     }
/*     */     
/*     */     public Comparable<?> getValueNE(MCRow row, String name) {
/*  87 */       return row.getDateNE(name);
/*     */     }
/*     */     
/*     */     public boolean isDateType() {
/*  91 */       return true;
/*     */     }
/*     */   },
/*     */   
/*  95 */   TIMESTAMP
/*     */   {
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Class<MCTimestamp> dataClass()
/*     */     {
/* 103 */       return MCTimestamp.class;
/*     */     }
/*     */     public MCTimestamp cast(Comparable<?> val) {
/* 106 */       return (MCTimestamp)super.cast(val);
/*     */     }
/*     */     
/*     */     public void setValueNE(MCRow row, String name, Comparable<?> value) {
/* 110 */       row.setTimestampNE(name, (MCTimestamp)value);
/*     */     }
/*     */     
/*     */     public Comparable<?> getValueNE(MCRow row, String name) {
/* 114 */       return row.getTimestampNE(name);
/*     */     }
/*     */     
/*     */     public boolean isDateType() {
/* 118 */       return true;
/*     */     }
/*     */   },
/*     */   
/* 122 */   BOOLEAN
/*     */   {
/*     */ 
/*     */ 
/*     */     
/*     */     public Class<Boolean> dataClass()
/*     */     {
/* 129 */       return Boolean.class;
/*     */     }
/*     */     public Boolean cast(Comparable<?> val) {
/* 132 */       if (val == null)
/*     */       {
/* 134 */         throw new MCException(Core_Msg_FW_A.FCBFC0021, new Object[0]);
/*     */       }
/* 136 */       return (Boolean)super.cast(val);
/*     */     }
/*     */     
/*     */     public void setValueNE(MCRow row, String name, Comparable<?> value) {
/* 140 */       row.setBooleanNE(name, ((Boolean)value).booleanValue());
/*     */     }
/*     */     
/*     */     public Comparable<?> getValueNE(MCRow row, String name) {
/* 144 */       return Boolean.valueOf(row.getBooleanNE(name));
/*     */     }
/*     */     
/*     */     public boolean isDateType() {
/* 148 */       return false;
/*     */     }
/*     */   },
/*     */   
/* 152 */   BINARY
/*     */   {
/*     */ 
/*     */ 
/*     */     
/*     */     public Class<MCBinary> dataClass()
/*     */     {
/* 159 */       return MCBinary.class;
/*     */     }
/*     */     public MCBinary cast(Comparable<?> val) {
/* 162 */       return (MCBinary)super.cast(val);
/*     */     }
/*     */     
/*     */     public void setValueNE(MCRow row, String name, Comparable<?> value) {
/* 166 */       row.setBinaryNE(name, (MCBinary)value);
/*     */     }
/*     */     
/*     */     public Comparable<?> getValueNE(MCRow row, String name) {
/* 170 */       return row.getBinaryNE(name);
/*     */     }
/*     */     
/*     */     public boolean isDateType() {
/* 174 */       return false;
/*     */     }
/*     */   },
/*     */   
/* 178 */   ROW
/*     */   {
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Class<MCRow> dataClass()
/*     */     {
/* 186 */       return MCRow.class;
/*     */     }
/*     */     
/*     */     public MCRow cast(Comparable<?> val) {
/* 190 */       return (MCRow)super.cast(val);
/*     */     }
/*     */     
/*     */     public void setValueNE(MCRow row, String name, Comparable<?> value) {
/* 194 */       row.setInnerRow(name, (MCRow)value);
/*     */     }
/*     */     
/*     */     public Comparable<?> getValueNE(MCRow row, String name) {
/* 198 */       return (Comparable<?>)row.getInnerRow(name);
/*     */     }
/*     */     
/*     */     public boolean isDateType() {
/* 202 */       return false;
/*     */     }
/*     */   };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Comparable<?> cast(Comparable<?> val) {
/* 269 */     return cast((Class)dataClass(), val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends Comparable<?>> T cast(Class<T> c, Comparable<?> val) {
/*     */     try {
/* 287 */       return c.cast(val);
/* 288 */     } catch (Exception ex) {
/*     */       
/* 290 */       throw new MCException(ex, Core_Msg_FW_A.FCBFC0020, new Object[] {
/* 291 */             val.getClass().getName(), c.getName()
/*     */           });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCDataType analyze(Comparable<?> val) {
/* 305 */     MCDataType type = null;
/* 306 */     if (val instanceof String) {
/* 307 */       type = STRING;
/* 308 */     } else if (val instanceof MCNumber) {
/* 309 */       type = NUMBER;
/* 310 */     } else if (val instanceof MCDate) {
/* 311 */       type = DATE;
/* 312 */     } else if (val instanceof MCTimestamp) {
/* 313 */       type = TIMESTAMP;
/* 314 */     } else if (val instanceof Boolean) {
/* 315 */       type = BOOLEAN;
/* 316 */     } else if (val instanceof MCBinary) {
/* 317 */       type = BINARY;
/* 318 */     } else if (val instanceof MCRow) {
/* 319 */       type = ROW;
/*     */     } 
/* 321 */     return type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCDataType analyze(Class<? extends Comparable<?>> c) {
/* 333 */     MCDataType type = null;
/* 334 */     if (String.class.isAssignableFrom(c)) {
/* 335 */       type = STRING;
/* 336 */     } else if (MCNumber.class.isAssignableFrom(c)) {
/* 337 */       type = NUMBER;
/* 338 */     } else if (MCDate.class.isAssignableFrom(c)) {
/* 339 */       type = DATE;
/* 340 */     } else if (MCTimestamp.class.isAssignableFrom(c)) {
/* 341 */       type = TIMESTAMP;
/* 342 */     } else if (Boolean.class.isAssignableFrom(c)) {
/* 343 */       type = BOOLEAN;
/* 344 */     } else if (MCBinary.class.isAssignableFrom(c)) {
/* 345 */       type = BINARY;
/* 346 */     } else if (MCRow.class.isAssignableFrom(c)) {
/* 347 */       type = ROW;
/*     */     } 
/* 349 */     return type;
/*     */   }
/*     */   
/*     */   public abstract Class<? extends Comparable<?>> dataClass();
/*     */   
/*     */   public abstract void setValueNE(MCRow paramMCRow, String paramString, Comparable<?> paramComparable);
/*     */   
/*     */   public abstract Comparable<?> getValueNE(MCRow paramMCRow, String paramString);
/*     */   
/*     */   public abstract boolean isDateType();
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\lang\MCDataType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */