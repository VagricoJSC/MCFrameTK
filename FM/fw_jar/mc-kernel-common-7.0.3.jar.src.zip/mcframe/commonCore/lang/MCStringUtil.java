/*      */ package mcframe.commonCore.lang;
/*      */ 
/*      */ import java.io.Serializable;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import mcframe.commonCore.container.MCRow;
/*      */ import mcframe.commonCore.resource.MCConst;
/*      */ import mcframe.commonCore.util.MCSimpleList;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class MCStringUtil
/*      */ {
/*   35 */   public static final Pattern TRIM_BOTH = Pattern.compile("^[\\s　]*(.*[^\\s　])[\\s　]*$", 
/*   36 */       32);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   43 */   public static final Pattern TRIM_HEAD = Pattern.compile("^[\\s　]*(.*)", 
/*   44 */       32);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   51 */   public static final Pattern TRIM_TAIL = Pattern.compile("(.*[^\\s　])[\\s　]*$", 
/*   52 */       32);
/*      */ 
/*      */   
/*      */   private static final char BIND_START = '{';
/*      */ 
/*      */   
/*      */   private static final char BIND_END = '}';
/*      */ 
/*      */   
/*      */   public static final String LF_CODE = "\n";
/*      */   
/*      */   public static final String CR_CODE = "\r";
/*      */   
/*      */   public static final String CRLF_CODE = "\r\n";
/*      */ 
/*      */   
/*      */   public static String trim(String value) {
/*   69 */     return trim(TRIM_BOTH, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String trimHead(String value) {
/*   87 */     return trim(TRIM_HEAD, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String trimTail(String value) {
/*  105 */     return trim(TRIM_TAIL, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String trim(Pattern p, String value) {
/*  125 */     if (value != null) {
/*  126 */       Matcher m = p.matcher(value);
/*  127 */       if (m.matches() && m.groupCount() > 0) {
/*  128 */         value = m.group(1);
/*      */       } else {
/*      */         
/*  131 */         value = "";
/*      */       } 
/*      */     } 
/*  134 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class IndexBindSource
/*      */     implements BindSource, Serializable
/*      */   {
/*      */     private static final long serialVersionUID = -8268501798314149045L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  319 */     private Map<String, String> _map = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  326 */     private int _next = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  333 */     private String _nullstr = "(null)";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public IndexBindSource(Object... binds) {
/*      */       byte b;
/*      */       int i;
/*      */       Object[] arrayOfObject;
/*  343 */       for (i = (arrayOfObject = binds).length, b = 0; b < i; ) { Object val = arrayOfObject[b];
/*  344 */         add(val);
/*      */         b++; }
/*      */     
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public IndexBindSource(Collection<?> c) {
/*  356 */       for (Object val : c) {
/*  357 */         add(val);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String[] toArray() {
/*  374 */       int len = this._next - 1;
/*  375 */       String[] a = new String[len];
/*  376 */       if (len > 0) {
/*  377 */         for (int i = len; i > 0; i--) {
/*  378 */           a[i - 1] = this._map.get(String.valueOf(i));
/*      */         }
/*      */       }
/*  381 */       return a;
/*      */     }
/*      */ 
/*      */     
/*      */     public String nullstr() {
/*  386 */       return this._nullstr;
/*      */     }
/*      */ 
/*      */     
/*      */     public void nullstr(String str) {
/*  391 */       this._nullstr = str;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int size() {
/*  406 */       return this._next - 1;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean containsKey(String key) {
/*  420 */       return (this._map != null) ? this._map.containsKey(key) : false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean containsKey(int index) {
/*  432 */       return containsKey(String.valueOf(index));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String get(String key) {
/*  446 */       return (this._map != null) ? this._map.get(key) : null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String get(int index) {
/*  458 */       return get(String.valueOf(index));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String valueToString(Object val) {
/*  475 */       if (val instanceof MCNumber) {
/*  476 */         MCNumber num = (MCNumber)val;
/*  477 */         return num.toSimpleString();
/*      */       } 
/*      */       
/*  480 */       return (val == null) ? null : val.toString();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Map<String, String> mapForPut() {
/*  492 */       if (this._map == null) {
/*  493 */         this._map = new HashMap<>();
/*      */       }
/*  495 */       return this._map;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int add(Object value) {
/*  510 */       int index = this._next++;
/*  511 */       String key = String.valueOf(index);
/*  512 */       mapForPut().put(key, valueToString(value));
/*  513 */       return index;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String set(int index, Object value) {
/*  535 */       if (index <= 0) {
/*  536 */         return null;
/*      */       }
/*  538 */       if (this._next <= index) {
/*  539 */         this._next = index + 1;
/*      */       }
/*  541 */       return mapForPut().put(String.valueOf(index), valueToString(value));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class MCRowBindSource
/*      */     implements BindSource
/*      */   {
/*      */     protected final MCRow _parent;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  566 */     private String _nullstr = "(null)";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MCRowBindSource(MCRow parent) {
/*  576 */       this._parent = (parent != null) ? parent : MCRow.create();
/*      */     }
/*      */ 
/*      */     
/*      */     public String nullstr() {
/*  581 */       return this._nullstr;
/*      */     }
/*      */ 
/*      */     
/*      */     public void nullstr(String str) {
/*  586 */       this._nullstr = str;
/*      */     }
/*      */ 
/*      */     
/*      */     public String get(String key) {
/*  591 */       Object value = this._parent.getValueNE(key);
/*  592 */       return (value != null) ? value.toString() : null;
/*      */     }
/*      */ 
/*      */     
/*      */     public int size() {
/*  597 */       return this._parent.size();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean containsKey(String key) {
/*  602 */       return this._parent.contains(key);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class MapBindSource
/*      */     implements BindSource, Serializable
/*      */   {
/*      */     private static final long serialVersionUID = 8469163229697694319L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected final Map<String, String> _parent;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  634 */     private String _nullstr = "(null)";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MapBindSource(Map<String, String> parent) {
/*  644 */       this._parent = (parent != null) ? parent : new HashMap<>();
/*      */     }
/*      */ 
/*      */     
/*      */     public String nullstr() {
/*  649 */       return this._nullstr;
/*      */     }
/*      */ 
/*      */     
/*      */     public void nullstr(String str) {
/*  654 */       this._nullstr = str;
/*      */     }
/*      */ 
/*      */     
/*      */     public String get(String key) {
/*  659 */       return this._parent.get(key);
/*      */     }
/*      */ 
/*      */     
/*      */     public int size() {
/*  664 */       return this._parent.size();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean containsKey(String key) {
/*  669 */       return this._parent.containsKey(key);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class CustomBindSource
/*      */     implements BindSource
/*      */   {
/*      */     private final MCStringUtil.BindSource _parent;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  692 */     private Map<String, String> _map = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  699 */     private String _nullstr = "(null)";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public CustomBindSource(MCStringUtil.BindSource parent) {
/*  709 */       this._parent = (parent != null) ? parent : new MCStringUtil.MapBindSource(null);
/*      */     }
/*      */ 
/*      */     
/*      */     public String nullstr() {
/*  714 */       return this._nullstr;
/*      */     }
/*      */ 
/*      */     
/*      */     public void nullstr(String str) {
/*  719 */       this._nullstr = str;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void put(String key, String value) {
/*  731 */       if (this._map == null) {
/*  732 */         this._map = new HashMap<>();
/*      */       }
/*  734 */       this._map.put(key, value);
/*      */     }
/*      */ 
/*      */     
/*      */     public String get(String key) {
/*  739 */       if (this._map == null) {
/*  740 */         return this._parent.get(key);
/*      */       }
/*      */       
/*  743 */       return this._map.containsKey(key) ? this._map.get(key) : this._parent.get(key);
/*      */     }
/*      */ 
/*      */     
/*      */     public int size() {
/*  748 */       if (this._map == null) {
/*  749 */         return this._parent.size();
/*      */       }
/*      */       
/*  752 */       return this._map.size() + this._parent.size();
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean containsKey(String key) {
/*  757 */       if (this._map == null) {
/*  758 */         return this._parent.containsKey(key);
/*      */       }
/*      */       
/*  761 */       boolean result = this._map.containsKey(key);
/*  762 */       if (!result) {
/*  763 */         result = this._parent.containsKey(key);
/*      */       }
/*  765 */       return result;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String bind(String format, Object... binds) {
/*  806 */     return bind('{', '}', format, binds);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String bind(char bracket, String format, Object... binds) {
/*  834 */     return bind(bracket, bracket, format, binds);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String bind(char start, char end, String format, Object... binds) {
/*  865 */     IndexBindSource bindsrc = new IndexBindSource(binds);
/*  866 */     return bind(start, end, format, bindsrc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String bind(String format, Map<String, String> bindmap) {
/*  889 */     return bind('{', '}', format, bindmap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String bind(char bracket, String format, Map<String, String> bindmap) {
/*  917 */     return bind(bracket, bracket, format, bindmap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String bind(char start, char end, String format, Map<String, String> bindmap) {
/*  947 */     return bind(start, end, format, new MapBindSource(bindmap));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String bind(String format, MCRow bindmap) {
/*  970 */     return bind('{', '}', format, bindmap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String bind(char bracket, String format, MCRow bindmap) {
/*  997 */     return bind(bracket, bracket, format, bindmap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String bind(char start, char end, String format, MCRow bindmap) {
/* 1027 */     return bind(start, end, format, new MCRowBindSource(bindmap));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String bind(String format, BindSource bindsrc) {
/* 1052 */     return bind('{', '}', format, bindsrc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String bind(char bracket, String format, BindSource bindsrc) {
/* 1082 */     return bind(bracket, bracket, format, bindsrc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String bind(char start, char end, String format, BindSource bindsrc) {
/* 1120 */     if (format == null || format.length() == 0 || bindsrc == null || 
/* 1121 */       bindsrc.size() <= 0) {
/* 1122 */       return format;
/*      */     }
/*      */     
/* 1125 */     StringBuilder sb = new StringBuilder();
/*      */     
/* 1127 */     char[] chars = format.toCharArray();
/* 1128 */     int len = chars.length;
/* 1129 */     boolean into = false;
/* 1130 */     StringBuilder bindsb = new StringBuilder();
/* 1131 */     for (int i = 0; i < len; i++) {
/* 1132 */       char c = chars[i];
/* 1133 */       if (into) {
/* 1134 */         if (c == end)
/*      */         {
/* 1136 */           String key = bindsb.toString();
/* 1137 */           String val = bindsrc.containsKey(key) ? bindsrc.get(key) : (
/* 1138 */             String.valueOf(start) + key + end);
/* 1139 */           if (val == null) {
/* 1140 */             val = bindsrc.nullstr();
/*      */           }
/* 1142 */           if (val != null) {
/* 1143 */             sb.append(val);
/*      */           }
/* 1145 */           bindsb.delete(0, bindsb.length());
/* 1146 */           into = false;
/*      */         }
/*      */         else
/*      */         {
/* 1150 */           bindsb.append(c);
/*      */         }
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1156 */         if (c == start) {
/* 1157 */           if (i < len - 1 && chars[i + 1] == start) {
/*      */ 
/*      */             
/* 1160 */             i++;
/*      */           }
/*      */           else {
/*      */             
/* 1164 */             into = true;
/*      */             
/*      */             i++;
/*      */           } 
/*      */         }
/*      */         
/* 1170 */         sb.append(c);
/*      */       } 
/* 1172 */     }  if (bindsb.length() > 0) {
/* 1173 */       sb.append(start);
/* 1174 */       sb.append(bindsb);
/*      */     } 
/*      */     
/* 1177 */     return (sb.length() > 0) ? sb.toString() : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean eq(String s1, String s2) {
/* 1203 */     return !((s1 != null || s2 != null) && (s1 == null || !s1.equals(s2)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean eqIgnoreCase(String s1, String s2) {
/* 1226 */     return !((s1 != null || s2 != null) && (s1 == null || !s1.equalsIgnoreCase(s2)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean same(String s1, String s2) {
/* 1246 */     return isNull(s1) ? isNull(s2) : s1.equals(s2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean sameIgnoreCase(String s1, String s2) {
/* 1265 */     return isNull(s1) ? isNull(s2) : s1.equalsIgnoreCase(s2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int codePointCount(String s) {
/* 1286 */     return (s != null) ? s.codePointCount(0, (s.toCharArray()).length) : 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String convToMaximum(String s, int max) {
/* 1299 */     if (s == null) {
/* 1300 */       return null;
/*      */     }
/* 1302 */     char[] c = s.toCharArray();
/* 1303 */     if (s.codePointCount(0, c.length) > max) {
/* 1304 */       return String.copyValueOf(c, 0, max);
/*      */     }
/* 1306 */     return s;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String join(String delimiter, String... strings) {
/* 1322 */     return join((String)null, delimiter, strings);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String join(char escape, String delimiter, String... strings) {
/* 1338 */     return join(String.valueOf(escape), delimiter, strings);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String join(String escape, String delimiter, String[] strings) {
/* 1355 */     if (strings == null || strings.length <= 0) {
/* 1356 */       return null;
/*      */     }
/*      */     
/* 1359 */     StringBuilder builder = new StringBuilder();
/* 1360 */     StringBuilder buf = new StringBuilder();
/*      */     
/* 1362 */     if (delimiter == null) {
/* 1363 */       delimiter = "";
/*      */     }
/* 1365 */     boolean esc = !isNull(escape); byte b; int i;
/*      */     String[] arrayOfString;
/* 1367 */     for (i = (arrayOfString = strings).length, b = 0; b < i; ) { String str = arrayOfString[b];
/* 1368 */       builder.append(delimiter);
/* 1369 */       if (str != null)
/*      */       {
/*      */         
/* 1372 */         if (esc) {
/* 1373 */           buf.setLength(0);
/* 1374 */           int orglen = str.length();
/* 1375 */           int begin = 0;
/* 1376 */           int pos = -1;
/* 1377 */           while ((pos = str.indexOf(escape, begin)) >= 0) {
/* 1378 */             buf.append(str.substring(begin, pos));
/* 1379 */             buf.append(escape);
/* 1380 */             buf.append(escape);
/* 1381 */             begin = pos + 1;
/*      */           } 
/* 1383 */           buf.append(str.substring(begin));
/* 1384 */           if (buf.length() != orglen || (
/* 1385 */             delimiter.length() > 0 && buf.indexOf(delimiter) >= 0)) {
/* 1386 */             builder.append(escape);
/* 1387 */             builder.append(buf);
/* 1388 */             builder.append(escape);
/*      */           } else {
/*      */             
/* 1391 */             builder.append(buf);
/*      */           } 
/*      */         } else {
/*      */           
/* 1395 */           builder.append(str);
/*      */         }  }  b++; }
/*      */     
/* 1398 */     return builder.substring(delimiter.length());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String join(String delimiter, char... chars) {
/* 1413 */     if (chars == null || chars.length <= 0) {
/* 1414 */       return null;
/*      */     }
/*      */     
/* 1417 */     if (delimiter == null) {
/* 1418 */       delimiter = "";
/*      */     }
/* 1420 */     StringBuilder builder = new StringBuilder();
/* 1421 */     for (int i = 0; i < chars.length; i++) {
/* 1422 */       if (i != 0) {
/* 1423 */         builder.append(delimiter);
/*      */       }
/* 1425 */       builder.append(chars[i]);
/*      */     } 
/* 1427 */     return builder.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] split(String delimiter, String str) {
/* 1446 */     return split((String)null, delimiter, str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] split(char escape, String delimiter, String str) {
/* 1483 */     return split(String.valueOf(escape), delimiter, str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String[] split(String escape, String delimiter, String str) {
/* 1500 */     if (isNull(str)) {
/* 1501 */       return new String[0];
/*      */     }
/*      */     
/* 1504 */     MCSimpleList<String> result = new MCSimpleList(String.class);
/* 1505 */     StringBuilder buf = new StringBuilder();
/*      */     
/* 1507 */     int del_len = (delimiter != null) ? delimiter.length() : 0;
/* 1508 */     int esc_len = (escape != null) ? escape.length() : 0;
/*      */     
/* 1510 */     boolean esc = false;
/* 1511 */     int begin = 0;
/* 1512 */     int pos = 0;
/*      */     
/* 1514 */     while (pos < str.length()) {
/* 1515 */       if (esc_len != 0 && str.startsWith(escape, pos)) {
/*      */ 
/*      */         
/* 1518 */         esc = true;
/*      */         
/* 1520 */         pos += esc_len;
/* 1521 */         begin = pos;
/*      */       } 
/*      */       
/* 1524 */       while (pos < str.length()) {
/* 1525 */         if (esc) {
/*      */           
/* 1527 */           if (str.startsWith(escape, pos)) {
/*      */ 
/*      */             
/* 1530 */             buf.append(str.substring(begin, pos));
/*      */             
/* 1532 */             pos += esc_len;
/* 1533 */             begin = pos;
/* 1534 */             if (str.startsWith(escape, pos)) {
/*      */ 
/*      */               
/* 1537 */               pos += esc_len;
/*      */               
/*      */               continue;
/*      */             } 
/* 1541 */             esc = false;
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             continue;
/*      */           } 
/* 1548 */         } else if (del_len != 0 && str.startsWith(delimiter, pos)) {
/*      */ 
/*      */           
/* 1551 */           buf.append(str.substring(begin, pos));
/* 1552 */           result.add(buf.toString());
/* 1553 */           buf.setLength(0);
/*      */           
/* 1555 */           pos += del_len;
/* 1556 */           begin = pos;
/*      */           
/*      */           break;
/*      */         } 
/*      */         
/* 1561 */         pos++;
/*      */       } 
/*      */     } 
/*      */     
/* 1565 */     buf.append(str.substring(begin, pos));
/* 1566 */     result.add(buf.toString());
/*      */     
/* 1568 */     return (String[])result.array();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String convertLineFeedCode(String value, String code) {
/* 1603 */     if (value != null && value.length() != 0) {
/* 1604 */       if (code == null) {
/* 1605 */         code = "";
/*      */       }
/*      */ 
/*      */       
/* 1609 */       StringBuilder sb = new StringBuilder();
/* 1610 */       char lf = '\n';
/* 1611 */       char cr = '\r';
/* 1612 */       char[] a = value.toCharArray();
/* 1613 */       for (int i = 0; i < a.length; i++) {
/* 1614 */         char c = a[i];
/* 1615 */         if (c == cr) {
/*      */           
/* 1617 */           if (i != a.length - 1 && a[i + 1] == lf) {
/* 1618 */             sb.append(code);
/* 1619 */             i++;
/*      */           }
/*      */           else {
/*      */             
/* 1623 */             sb.append(code);
/*      */           }
/*      */         
/*      */         }
/* 1627 */         else if (c == lf) {
/* 1628 */           sb.append(code);
/*      */         }
/*      */         else {
/*      */           
/* 1632 */           sb.append(c);
/*      */         } 
/*      */       } 
/* 1635 */       return sb.toString();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1656 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String convertToLF(String value) {
/* 1670 */     return convertLineFeedCode(value, "\n");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String convertToCR(String value) {
/* 1684 */     return convertLineFeedCode(value, "\r");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String convertToCRLF(String value) {
/* 1698 */     return convertLineFeedCode(value, "\r\n");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNull(String string) {
/* 1712 */     return !(string != null && string.length() != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean containsNull(String... strings) {
/* 1725 */     if (strings != null) {
/* 1726 */       int count = strings.length;
/* 1727 */       for (int i = 0; i < count; i++) {
/* 1728 */         if (isNull(strings[i])) {
/* 1729 */           return true;
/*      */         }
/*      */       } 
/* 1732 */       return false;
/*      */     } 
/* 1734 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1742 */   private static char NON_NODE_SEP = Character.MIN_VALUE;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] match(String ptn, String[] tar) {
/* 1763 */     return match(ptn, tar, NON_NODE_SEP);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> match(String ptn, List<String> tar) {
/* 1785 */     return match(ptn, tar, NON_NODE_SEP);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Set<String> match(String ptn, Set<String> tar) {
/* 1807 */     return match(ptn, tar, NON_NODE_SEP);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] match(String ptn, String[] tar, char NODE_SEP) {
/* 1834 */     Pattern regex = crtPtn(ptn, NODE_SEP);
/* 1835 */     List<String> ret = new ArrayList<>(); byte b; int i; String[] arrayOfString;
/* 1836 */     for (i = (arrayOfString = tar).length, b = 0; b < i; ) { String t = arrayOfString[b];
/* 1837 */       Matcher matcher = regex.matcher(t);
/* 1838 */       if (matcher.matches())
/* 1839 */         ret.add(t); 
/*      */       b++; }
/*      */     
/* 1842 */     return ret.<String>toArray(new String[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> match(String ptn, List<String> tar, char NODE_SEP) {
/* 1869 */     Pattern regex = crtPtn(ptn, NODE_SEP);
/* 1870 */     List<String> ret = new ArrayList<>();
/* 1871 */     for (String t : tar) {
/* 1872 */       Matcher matcher = regex.matcher(ptn);
/* 1873 */       if (matcher.matches()) {
/* 1874 */         ret.add(t);
/*      */       }
/*      */     } 
/* 1877 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Set<String> match(String ptn, Set<String> tar, char NODE_SEP) {
/* 1904 */     Pattern regex = crtPtn(ptn, NODE_SEP);
/* 1905 */     Set<String> ret = new HashSet<>();
/* 1906 */     for (String t : tar) {
/* 1907 */       Matcher matcher = regex.matcher(ptn);
/* 1908 */       if (matcher.matches()) {
/* 1909 */         ret.add(t);
/*      */       }
/*      */     } 
/* 1912 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final Pattern crtPtn(String ptn, char NODE_SEP) {
/* 1926 */     String SEPARATOR = (NODE_SEP != NON_NODE_SEP) ? ("[" + NODE_SEP + "]") : "";
/* 1927 */     String QUESTION = (NODE_SEP != NON_NODE_SEP) ? ("[^" + NODE_SEP + "]") : ".";
/* 1928 */     String ASTERISK = String.valueOf(QUESTION) + "*";
/*      */     
/* 1930 */     StringBuilder sb = new StringBuilder();
/* 1931 */     int len = ptn.length();
/* 1932 */     int astlen = 0;
/* 1933 */     int partlen = 0;
/* 1934 */     for (int i = 0; i < len; i++) {
/* 1935 */       char c = ptn.charAt(i);
/* 1936 */       if (c == NODE_SEP) {
/* 1937 */         if (astlen >= 2 && astlen == partlen) {
/*      */           
/* 1939 */           sb.append("(|.+" + SEPARATOR + ")");
/*      */         } else {
/*      */           
/* 1942 */           if (astlen > 0)
/*      */           {
/* 1944 */             sb.append(ASTERISK);
/*      */           }
/* 1946 */           sb.append(SEPARATOR);
/*      */         } 
/* 1948 */         astlen = 0;
/* 1949 */         partlen = 0;
/*      */       
/*      */       }
/* 1952 */       else if (c == '*') {
/* 1953 */         astlen++;
/* 1954 */         partlen++;
/*      */       }
/*      */       else {
/*      */         
/* 1958 */         if (astlen > 0) {
/* 1959 */           sb.append(ASTERISK);
/*      */         }
/* 1961 */         if (c == '?') {
/* 1962 */           sb.append(QUESTION);
/*      */         } else {
/*      */           
/* 1965 */           switch (c) {
/*      */ 
/*      */             
/*      */             case '$':
/*      */             case '(':
/*      */             case ')':
/*      */             case '.':
/*      */             case '[':
/*      */             case '\\':
/*      */             case ']':
/*      */             case '^':
/*      */             case '{':
/*      */             case '|':
/*      */             case '}':
/* 1979 */               sb.append('\\');
/* 1980 */               sb.append(c);
/*      */               break;
/*      */             default:
/* 1983 */               sb.append(c); break;
/*      */           } 
/*      */         } 
/* 1986 */         astlen = 0;
/* 1987 */         partlen++;
/*      */       } 
/*      */     } 
/*      */     
/* 1991 */     if (astlen > 0) {
/* 1992 */       if (astlen >= 2 && astlen == partlen) {
/*      */         
/* 1994 */         sb.append(".+");
/*      */       }
/*      */       else {
/*      */         
/* 1998 */         sb.append(ASTERISK);
/*      */       } 
/*      */     }
/* 2001 */     return Pattern.compile(sb.toString(), 32);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSingleBytes(String str) {
/* 2021 */     if (str != null) {
/*      */ 
/*      */       
/* 2024 */       char[] cs = str.toCharArray(); byte b; int i; char[] arrayOfChar1;
/* 2025 */       for (i = (arrayOfChar1 = cs).length, b = 0; b < i; ) { char c = arrayOfChar1[b];
/* 2026 */         if (c > '')
/* 2027 */           return false; 
/*      */         b++; }
/*      */     
/*      */     } 
/* 2031 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2040 */   static String ARRAY_V_DELIMITER = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getArrayValueDelimiter() {
/* 2051 */     if (ARRAY_V_DELIMITER == null) {
/* 2052 */       ARRAY_V_DELIMITER = MCConst.plugin
/* 2053 */         .getString(MCConst.createKey(new String[] { "ArrayValue", "delimiter" }, ), "^");
/*      */     }
/* 2055 */     return ARRAY_V_DELIMITER;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2064 */   static String ARRAY_V_ESCAPE = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getArrayValueEscape() {
/* 2075 */     if (ARRAY_V_ESCAPE == null) {
/* 2076 */       ARRAY_V_ESCAPE = MCConst.plugin
/* 2077 */         .getString(MCConst.createKey(new String[] { "ArrayValue", "escape" }, ), "\"");
/*      */     }
/* 2079 */     return ARRAY_V_ESCAPE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2085 */   static String ARRAY_V_NOTLIKE_KEYWORD = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getArrayValueNotlikeKeyword() {
/* 2094 */     if (ARRAY_V_NOTLIKE_KEYWORD == null) {
/* 2095 */       ARRAY_V_NOTLIKE_KEYWORD = MCConst.plugin
/* 2096 */         .getString(MCConst.createKey(new String[] { "ArrayValue", "notlike", "keyword" }, ), "-");
/*      */     }
/* 2098 */     return ARRAY_V_NOTLIKE_KEYWORD;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2104 */   static String ARRAY_V_NOTLIKE_ESCAPE = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getArrayValueNotlikeEscape() {
/* 2113 */     if (ARRAY_V_NOTLIKE_ESCAPE == null) {
/* 2114 */       ARRAY_V_NOTLIKE_ESCAPE = MCConst.plugin
/* 2115 */         .getString(MCConst.createKey(new String[] { "ArrayValue", "notlike", "escape" }, ), "\\");
/*      */     }
/* 2117 */     return ARRAY_V_NOTLIKE_ESCAPE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String arrayValueJoin(String... strings) {
/* 2130 */     return join(getArrayValueEscape(), getArrayValueDelimiter(), strings);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] arrayValueSplit(String str) {
/* 2143 */     return split(getArrayValueEscape(), getArrayValueDelimiter(), str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String substringBetween(String str, String tag) {
/* 2156 */     if (str == null || tag == null) {
/* 2157 */       return null;
/*      */     }
/* 2159 */     int start = str.indexOf(tag);
/* 2160 */     if (start != -1) {
/* 2161 */       int end = str.indexOf(tag, start + tag.length());
/* 2162 */       if (end != -1) {
/* 2163 */         return str.substring(start + tag.length(), end);
/*      */       }
/*      */     } 
/* 2166 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean containsIgnoreCase(String str, String searchStr) {
/* 2179 */     if (str == null || searchStr == null) {
/* 2180 */       return false;
/*      */     }
/* 2182 */     int len = searchStr.length();
/* 2183 */     int max = str.length() - len;
/* 2184 */     for (int i = 0; i <= max; i++) {
/* 2185 */       if (str.regionMatches(true, i, searchStr, 0, len)) {
/* 2186 */         return true;
/*      */       }
/*      */     } 
/* 2189 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String rightPad(String str, int size, char padChar) {
/* 2203 */     if (str == null) {
/* 2204 */       return null;
/*      */     }
/* 2206 */     int pads = size - str.length();
/* 2207 */     if (pads <= 0) {
/* 2208 */       return str;
/*      */     }
/* 2210 */     char[] buf = new char[pads];
/* 2211 */     for (int i = 0; i < buf.length; i++) {
/* 2212 */       buf[i] = padChar;
/*      */     }
/* 2214 */     return str.concat(new String(buf));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String nullToBlank(String str) {
/* 2226 */     return (str != null) ? str : "";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String blankToNull(String str) {
/* 2238 */     return isNull(str) ? null : str;
/*      */   }
/*      */   
/*      */   public static interface BindSource {
/*      */     public static final String BIND_NULL = "(null)";
/*      */     
/*      */     String get(String param1String);
/*      */     
/*      */     int size();
/*      */     
/*      */     boolean containsKey(String param1String);
/*      */     
/*      */     String nullstr();
/*      */     
/*      */     void nullstr(String param1String);
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\lang\MCStringUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */