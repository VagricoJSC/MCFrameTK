/*     */ package mcframe.commonCore.lang;
/*     */ 
/*     */ import java.text.DateFormatSymbols;
/*     */ import java.text.NumberFormat;
/*     */ import java.text.ParsePosition;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.GregorianCalendar;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCDateFormat
/*     */   extends SimpleDateFormat
/*     */ {
/*     */   private static final int _ptn_y = 0;
/*     */   private static final int _ptn_M = 1;
/*     */   private static final int _ptn_d = 2;
/*     */   private static final int _ptn_D = 3;
/*     */   private static final int _ptn_w = 4;
/*     */   
/*     */   public static MCDateFormat create(String format) {
/*  99 */     return create(format, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCDateFormat create(String format, Locale locale) {
/* 118 */     if (format == null)
/*     */     {
/* 120 */       throw new MCException(Core_Msg_FW_A.FCBFC0018, new Object[0]);
/*     */     }
/*     */     
/*     */     try {
/* 124 */       MCDateFormat mcdf = new MCDateFormat(format, locale);
/* 125 */       return mcdf;
/* 126 */     } catch (IllegalArgumentException ex) {
/*     */ 
/*     */       
/* 129 */       throw new MCException(ex, Core_Msg_FW_A.FCBFC0026, new Object[] { format });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int getYearCorrectValue(int now_month, int new_month) {
/* 148 */     int diff = now_month - new_month;
/* 149 */     if (diff <= -6)
/*     */     {
/* 151 */       return -1;
/*     */     }
/* 153 */     if (diff >= 7)
/*     */     {
/* 155 */       return 1;
/*     */     }
/*     */     
/* 158 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 168 */   private SimpleDateFormat _parser = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 176 */   private boolean[] _find = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCDateFormat(String format, Locale locale) {
/* 195 */     super(format, (locale == null) ? (locale = Locale.getDefault()) : locale);
/*     */ 
/*     */     
/* 198 */     createParser(format, locale);
/*     */     
/* 200 */     setLenient(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void createParser(String format, Locale locale) {
/* 213 */     boolean[] find = findYearMonthPattern(format);
/* 214 */     String pformat = correctFormat(find, format);
/*     */ 
/*     */     
/* 217 */     SimpleDateFormat p = new SimpleDateFormat(pformat, locale);
/* 218 */     p.setCalendar(getCalendar());
/*     */     
/* 220 */     this._find = find;
/* 221 */     this._parser = p;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean[] findYearMonthPattern(String format) {
/* 238 */     boolean[] find = new boolean[5];
/*     */     
/* 240 */     char[] ca = format.toCharArray();
/* 241 */     int len = ca.length;
/* 242 */     for (int i = 0; i < len; i++) {
/* 243 */       switch (ca[i]) {
/*     */         case 'y':
/* 245 */           find[0] = true;
/*     */           break;
/*     */         case 'M':
/* 248 */           find[1] = true;
/*     */           break;
/*     */         case 'd':
/* 251 */           find[2] = true;
/*     */           break;
/*     */         case 'D':
/* 254 */           find[3] = true;
/*     */           break;
/*     */         case 'w':
/* 257 */           find[4] = true;
/*     */           break;
/*     */       } 
/*     */     } 
/* 261 */     return find;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String correctFormat(boolean[] find, String format) {
/* 283 */     if (!find[0] || !find[1]) {
/*     */ 
/*     */       
/* 286 */       StringBuilder fsb = new StringBuilder(format);
/* 287 */       if (!find[0])
/*     */       {
/* 289 */         fsb.append(" yyyy");
/*     */       }
/* 291 */       if (!find[1])
/*     */       {
/*     */ 
/*     */         
/* 295 */         fsb.append(" MM");
/*     */       }
/* 297 */       format = fsb.toString();
/*     */     } 
/* 299 */     return format;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String correctText(String text, GregorianCalendar now) {
/* 321 */     if (!this._find[0] || !this._find[1]) {
/*     */ 
/*     */       
/* 324 */       StringBuilder tsb = new StringBuilder(text);
/* 325 */       if (!this._find[0]) {
/*     */         
/* 327 */         tsb.append(" ");
/* 328 */         if (!this._find[3] && !this._find[4] && this._find[1]) {
/*     */           
/* 330 */           tsb.append("2000");
/*     */         } else {
/*     */           
/* 333 */           tsb.append(now.get(MCDateFieldType.YEAR.getField()));
/*     */         } 
/*     */       } 
/* 336 */       if (!this._find[1]) {
/*     */ 
/*     */ 
/*     */         
/* 340 */         tsb.append(" ");
/* 341 */         tsb.append(now.get(MCDateFieldType.MONTH.getField()) + 1);
/*     */       } 
/* 343 */       text = tsb.toString();
/*     */     } 
/* 345 */     return text;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Date parse(String text, ParsePosition pos) {
/* 352 */     GregorianCalendar now = MCCalendarDate.createCalendar();
/*     */ 
/*     */     
/* 355 */     String newtext = correctText(text, now);
/*     */ 
/*     */     
/* 358 */     int now_year = now.get(MCDateFieldType.YEAR.getField());
/* 359 */     int now_month = now.get(MCDateFieldType.MONTH.getField());
/*     */ 
/*     */     
/* 362 */     now.add(MCDateFieldType.YEAR.getField(), -50);
/* 363 */     this._parser.set2DigitYearStart(now.getTime());
/*     */ 
/*     */     
/* 366 */     Date date = this._parser.parse(newtext, pos);
/* 367 */     if (date == null) {
/* 368 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 372 */     if (!this._find[0] && !this._find[3] && !this._find[4] && 
/* 373 */       this._find[1]) {
/* 374 */       Calendar cal = this._parser.getCalendar();
/* 375 */       int diff = getYearCorrectValue(
/* 376 */           now_month, 
/* 377 */           cal.get(MCDateFieldType.MONTH.getField()));
/* 378 */       cal.set(MCDateFieldType.YEAR.getField(), now_year + diff);
/* 379 */       date = cal.getTime();
/*     */     } 
/* 381 */     return date;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyPattern(String pattern) {
/* 395 */     if (pattern == null)
/*     */     {
/* 397 */       throw new MCException(Core_Msg_FW_A.FCBFC0018, new Object[0]);
/*     */     }
/*     */     
/*     */     try {
/* 401 */       super.applyPattern(pattern);
/*     */       
/* 403 */       applyPatternForParser();
/* 404 */     } catch (IllegalArgumentException ex) {
/*     */ 
/*     */       
/* 407 */       throw new MCException(ex, Core_Msg_FW_A.FCBFC0026, new Object[] { pattern });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void applyLocalizedPattern(String pattern) {
/* 421 */     if (pattern == null)
/*     */     {
/* 423 */       throw new MCException(Core_Msg_FW_A.FCBFC0018, new Object[0]);
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 428 */       super.applyLocalizedPattern(pattern);
/*     */       
/* 430 */       applyPatternForParser();
/* 431 */     } catch (IllegalArgumentException ex) {
/*     */ 
/*     */       
/* 434 */       throw new MCException(ex, Core_Msg_FW_A.FCBFC0026, new Object[] { pattern });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void applyPatternForParser() {
/* 445 */     String pattern = toPattern();
/* 446 */     boolean[] find = findYearMonthPattern(pattern);
/* 447 */     String ppattern = correctFormat(find, pattern);
/* 448 */     this._parser.applyPattern(ppattern);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void set2DigitYearStart(Date startDate) {
/* 462 */     super.set2DigitYearStart(startDate);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCalendar(Calendar newCalendar) {
/* 467 */     super.setCalendar(newCalendar);
/* 468 */     this._parser.setCalendar(newCalendar);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDateFormatSymbols(DateFormatSymbols newFormatSymbols) {
/* 473 */     super.setDateFormatSymbols(newFormatSymbols);
/* 474 */     this._parser.setDateFormatSymbols(newFormatSymbols);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLenient(boolean lenient) {
/* 479 */     super.setLenient(lenient);
/* 480 */     this._parser.setLenient(lenient);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setNumberFormat(NumberFormat newNumberFormat) {
/* 485 */     super.setNumberFormat(newNumberFormat);
/* 486 */     this._parser.setNumberFormat(newNumberFormat);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTimeZone(TimeZone zone) {
/* 491 */     super.setTimeZone(zone);
/* 492 */     this._parser.setTimeZone(zone);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\lang\MCDateFormat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */