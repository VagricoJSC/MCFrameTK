/*      */ package mcframe.commonCore.lang;
/*      */ 
/*      */ import java.io.Serializable;
/*      */ import java.text.DateFormat;
/*      */ import java.text.ParseException;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.Date;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.Locale;
/*      */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*      */ import mcframe.commonCore.notice.MCException;
/*      */ import mcframe.commonCore.sys.MCSys;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class MCCalendarDate<T extends MCCalendarDate<?>>
/*      */   implements Comparable<MCCalendarDate<?>>, Cloneable, Serializable
/*      */ {
/*  264 */   public static final MCDateFieldType YEAR = MCDateFieldType.YEAR;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  271 */   public static final MCDateFieldType MONTH = MCDateFieldType.MONTH;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  278 */   public static final MCDateFieldType DAY = MCDateFieldType.DAY;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  285 */   public static final MCDateFieldType HOUR = MCDateFieldType.HOUR;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  292 */   public static final MCDateFieldType MINUTE = MCDateFieldType.MINUTE;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  299 */   public static final MCDateFieldType SECOND = MCDateFieldType.SECOND;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  307 */   public static final MCDateFieldType MILLISECOND = MCDateFieldType.MILLISECOND;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int JANUARY = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int JAN = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int FEBRUARY = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int FEB = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int MARCH = 3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int MAR = 3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int APRIL = 4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int APR = 4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int MAY = 5;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int JUNE = 6;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int JUN = 6;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int JULY = 7;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int JUL = 7;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int AUGUST = 8;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int AUG = 8;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int SEPTEMBER = 9;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int SEP = 9;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int OCTOBER = 10;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int OCT = 10;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int NOVEMBER = 11;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int NOV = 11;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int DECEMBER = 12;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int DEC = 12;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int SUNDAY = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int SUN = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int MONDAY = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int MON = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TUESDAY = 3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int TUE = 3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int WEDNESDAY = 4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int WED = 4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int THURSDAY = 5;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int THU = 5;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int FRIDAY = 6;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int FRI = 6;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int SATURDAY = 7;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final int SAT = 7;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final long LONG_NULL = -9223372036854775808L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final long _time;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final long current() {
/*  573 */     return System.currentTimeMillis() + MCSys.env.getMCSysTimeDiff();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final long currentCo() {
/*  584 */     return System.currentTimeMillis() + MCSys.env.getMCCoSysTimeDiff(MCSys.user.coCD());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final long roundToday(long value) {
/*  596 */     GregorianCalendar cal = createCalendar();
/*  597 */     cal.setTimeInMillis(value);
/*  598 */     cal.set(HOUR.getField(), 0);
/*  599 */     cal.set(MINUTE.getField(), 0);
/*  600 */     cal.set(SECOND.getField(), 0);
/*  601 */     cal.set(MILLISECOND.getField(), 0);
/*  602 */     return cal.getTimeInMillis();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final GregorianCalendar createCalendar() {
/*  616 */     GregorianCalendar cal = new GregorianCalendar();
/*  617 */     cal.setLenient(false);
/*      */     
/*  619 */     cal.setTimeInMillis(current());
/*  620 */     return cal;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final GregorianCalendar createDefaultValueCalendar() {
/*  634 */     GregorianCalendar cal = createCalendar();
/*  635 */     cal.set(DAY.getField(), 1);
/*  636 */     cal.set(HOUR.getField(), 0);
/*  637 */     cal.set(MINUTE.getField(), 0);
/*  638 */     cal.set(SECOND.getField(), 0);
/*  639 */     cal.set(MILLISECOND.getField(), 0);
/*  640 */     return cal;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final long longValueOf(MCDateFieldType field, int fieldlen, int... val) {
/*  675 */     if (field == null || val == null || val.length <= 0) {
/*  676 */       return Long.MIN_VALUE;
/*      */     }
/*      */ 
/*      */     
/*  680 */     GregorianCalendar cal = createDefaultValueCalendar();
/*      */ 
/*      */     
/*  683 */     MCDateFieldType[] fs = MCDateFieldType.scaleValues();
/*  684 */     int fpos = 0;
/*  685 */     for (; fs[fpos] != field; fpos++);
/*      */ 
/*      */     
/*  688 */     int vallen = val.length;
/*  689 */     int overflow = fpos + vallen - fieldlen;
/*  690 */     vallen = (overflow > 0) ? (vallen - overflow) : vallen;
/*  691 */     int[] tmp = new int[vallen];
/*  692 */     System.arraycopy(val, 0, tmp, 0, vallen);
/*  693 */     if (fpos == 0 && vallen > 1) {
/*      */       
/*  695 */       tmp[1] = tmp[1] - 1;
/*  696 */     } else if (fpos == 1) {
/*      */       
/*  698 */       tmp[0] = tmp[0] - 1;
/*      */ 
/*      */       
/*  701 */       int diff = MCDateFormat.getYearCorrectValue(
/*  702 */           cal.get(MONTH.getField()), tmp[0]);
/*  703 */       cal.set(YEAR.getField(), cal.get(YEAR.getField()) + diff);
/*      */     } 
/*      */ 
/*      */     
/*  707 */     for (int i = 0; i < vallen; i++) {
/*  708 */       cal.set(fs[fpos + i].getField(), tmp[i]);
/*      */     }
/*      */     try {
/*  711 */       return cal.getTimeInMillis();
/*  712 */     } catch (IllegalArgumentException ex) {
/*      */       
/*  714 */       throw new MCException(ex, Core_Msg_FW_A.FCBFC0011, new Object[] { ex.getMessage() });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final Date stringToDate(MCDateFormat format, String text) {
/*  731 */     if (format == null)
/*      */     {
/*  733 */       throw new MCException(Core_Msg_FW_A.FCBFC0018, new Object[0]);
/*      */     }
/*  735 */     if (text == null) {
/*  736 */       return null;
/*      */     }
/*      */     try {
/*  739 */       return format.parse(text);
/*  740 */     } catch (ParseException ex) {
/*      */ 
/*      */       
/*  743 */       throw new MCException(ex, Core_Msg_FW_A.FCBFC0012, new Object[] {
/*  744 */             text, format.toPattern(), 
/*  745 */             Integer.valueOf(ex.getErrorOffset())
/*      */           });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final SimpleDateFormat createDateFormat(String format) {
/*  765 */     return createDateFormat(format, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final SimpleDateFormat createDateFormat(String format, Locale locale) {
/*  784 */     if (format == null)
/*      */     {
/*  786 */       throw new MCException(Core_Msg_FW_A.FCBFC0018, new Object[0]);
/*      */     }
/*  788 */     if (locale == null)
/*      */     {
/*  790 */       locale = Locale.getDefault();
/*      */     }
/*      */     
/*  793 */     SimpleDateFormat sdf = new SimpleDateFormat(format, locale);
/*  794 */     sdf.setLenient(false);
/*  795 */     return sdf;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  821 */   private GregorianCalendar _owncal = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   MCCalendarDate() {
/*  830 */     this(System.currentTimeMillis());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   MCCalendarDate(long time) {
/*  841 */     this._time = inittime(time);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final GregorianCalendar ownCalendar() {
/*  901 */     if (this._owncal == null) {
/*  902 */       this._owncal = createCalendar();
/*  903 */       this._owncal.setTimeInMillis(this._time);
/*      */     } 
/*  905 */     return this._owncal;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final GregorianCalendar calcCalendar() {
/*  926 */     return (GregorianCalendar)ownCalendar().clone();
/*      */   }
/*      */ 
/*      */   
/*      */   public Object clone() {
/*      */     try {
/*  932 */       MCCalendarDate<?> other = (MCCalendarDate)super.clone();
/*  933 */       other._owncal = (this._owncal == null) ? 
/*  934 */         null : 
/*  935 */         (GregorianCalendar)this._owncal.clone();
/*  936 */       return other;
/*  937 */     } catch (CloneNotSupportedException cloneNotSupportedException) {
/*      */       
/*  939 */       throw new InternalError();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/*  947 */     long ht = this._time;
/*  948 */     return (int)ht ^ (int)(ht >> 32L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int get(MCDateFieldType field) {
/*  975 */     int value = ownCalendar().get(field.getField());
/*  976 */     return (field != MONTH) ? value : ++value;
/*      */   }
/*      */   
/*      */   public boolean isAm() {
/*  980 */     switch (ownCalendar().get(9)) {
/*      */       case 0:
/*  982 */         return true;
/*      */     } 
/*      */     
/*  985 */     return false;
/*      */   }
/*      */   
/*      */   public boolean isPm() {
/*  989 */     switch (ownCalendar().get(9)) {
/*      */       case 1:
/*  991 */         return true;
/*      */     } 
/*      */     
/*  994 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getYear() {
/* 1006 */     return get(YEAR);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMonth() {
/* 1017 */     return get(MONTH);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getDay() {
/* 1028 */     return get(DAY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getHour() {
/* 1039 */     return get(HOUR);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMinute() {
/* 1050 */     return get(MINUTE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getSecond() {
/* 1061 */     return get(SECOND);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMilliSecond() {
/* 1072 */     return get(MILLISECOND);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isLeapYear() {
/* 1084 */     int year = get(YEAR);
/* 1085 */     return ownCalendar().isLeapYear(year);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getDayOfWeek() {
/* 1096 */     return ownCalendar().get(7);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDayNameOfWeek() {
/* 1112 */     return toString("EEEE");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDayNameOfWeek(Locale locale) {
/* 1130 */     return toString("EEEE", locale);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getShortDayNameOfWeek() {
/* 1146 */     return toString("E");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getShortDayNameOfWeek(Locale locale) {
/* 1164 */     return toString("E", locale);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object obj) {
/* 1184 */     return (obj instanceof MCCalendarDate && 
/* 1185 */       this._time == ((MCCalendarDate)obj)._time);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int compareTo(MCCalendarDate<?> c) {
/* 1201 */     if (c == null) {
/* 1202 */       throw new MCException(Core_Msg_FW_A.FCBFC0014, new Object[0]);
/*      */     }
/* 1204 */     return (this._time < c._time) ? -1 : ((this._time == c._time) ? 0 : 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MCDateFieldType[] getFieldArray(MCDateFieldType field, boolean front) {
/* 1221 */     if (field == null)
/*      */     {
/* 1223 */       throw new MCException(Core_Msg_FW_A.FCBFC0013, new Object[0]);
/*      */     }
/*      */     
/* 1226 */     MCDateFieldType[] consts = MCDateFieldType.values();
/* 1227 */     int pos = 0;
/* 1228 */     int len = consts.length;
/* 1229 */     for (; !consts[pos].equals(field) && pos < len; pos++);
/* 1230 */     if (pos >= len)
/*      */     {
/* 1232 */       throw new MCException(Core_Msg_FW_A.FCBFC0015, new Object[] { field });
/*      */     }
/*      */     
/* 1235 */     MCDateFieldType[] fields = null;
/* 1236 */     if (front) {
/* 1237 */       fields = new MCDateFieldType[pos + 1];
/* 1238 */       System.arraycopy(consts, 0, fields, 0, fields.length);
/*      */     } else {
/*      */       
/* 1241 */       fields = new MCDateFieldType[len - pos];
/* 1242 */       System.arraycopy(consts, pos, fields, 0, fields.length);
/*      */     } 
/* 1244 */     return fields;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int compareToField(int value, MCDateFieldType field) {
/* 1262 */     if (field == null)
/*      */     {
/* 1264 */       throw new MCException(Core_Msg_FW_A.FCBFC0013, new Object[0]);
/*      */     }
/*      */     
/* 1267 */     int ownvalue = get(field);
/* 1268 */     int result = 0;
/* 1269 */     if (ownvalue < value) {
/* 1270 */       result = -1;
/* 1271 */     } else if (ownvalue > value) {
/* 1272 */       result = 1;
/*      */     } 
/* 1274 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int compareToField(MCCalendarDate<?> value, MCDateFieldType... fields) {
/* 1297 */     int result = compareTo(value);
/* 1298 */     if (result != 0) {
/* 1299 */       if (fields == null || fields.length <= 0)
/*      */       {
/* 1301 */         throw new MCException(Core_Msg_FW_A.FCBFC0013, new Object[0]);
/*      */       }
/* 1303 */       result = 0;
/* 1304 */       int len = fields.length;
/* 1305 */       for (int i = 0; result == 0 && i < len; i++) {
/* 1306 */         MCDateFieldType field = fields[i];
/* 1307 */         result = compareToField(value.get(field), field);
/*      */       } 
/*      */     } 
/* 1310 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int compareToLeft(MCCalendarDate<?> value, MCDateFieldType field) {
/* 1330 */     MCDateFieldType[] comps = getFieldArray(field, true);
/* 1331 */     return compareToField(value, comps);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int compareToRight(MCCalendarDate<?> value, MCDateFieldType field) {
/* 1351 */     MCDateFieldType[] comps = getFieldArray(field, false);
/* 1352 */     return compareToField(value, comps);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean eq(MCCalendarDate<?> value, MCDateFieldType... fields) {
/* 1371 */     if (value == null) {
/* 1372 */       return false;
/*      */     }
/* 1374 */     if (fields == null || fields.length <= 0) {
/* 1375 */       return equals(value);
/*      */     }
/*      */     
/* 1378 */     boolean result = true;
/* 1379 */     int len = fields.length;
/* 1380 */     for (int i = 0; i < len; i++) {
/* 1381 */       MCDateFieldType field = fields[i];
/* 1382 */       if (get(field) != value.get(field)) {
/* 1383 */         result = false;
/*      */         break;
/*      */       } 
/*      */     } 
/* 1387 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean eq(String text, String format, MCDateFieldType... fields) {
/* 1412 */     MCCalendarDate<?> value = (MCCalendarDate<?>)parse(text, format);
/* 1413 */     return eq(value, fields);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean eqLeft(MCCalendarDate<?> value, MCDateFieldType field) {
/* 1431 */     MCDateFieldType[] comps = null;
/* 1432 */     if (field != null) {
/* 1433 */       comps = getFieldArray(field, true);
/*      */     }
/* 1435 */     return eq(value, comps);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean eqLeft(String text, String format, MCDateFieldType field) {
/* 1459 */     MCCalendarDate<?> value = (MCCalendarDate<?>)parse(text, format);
/* 1460 */     return eqLeft(value, field);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean eqRight(MCCalendarDate<?> value, MCDateFieldType field) {
/* 1478 */     MCDateFieldType[] comps = null;
/* 1479 */     if (field != null) {
/* 1480 */       comps = getFieldArray(field, false);
/*      */     }
/* 1482 */     return eq(value, comps);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean eqRight(String text, String format, MCDateFieldType field) {
/* 1506 */     MCCalendarDate<?> value = (MCCalendarDate<?>)parse(text, format);
/* 1507 */     return eqRight(value, field);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean eqDate(MCCalendarDate<?> value) {
/* 1521 */     return eq(value, new MCDateFieldType[] { YEAR, MONTH, DAY });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean eqDate(String text, String format) {
/* 1538 */     MCCalendarDate<?> value = (MCCalendarDate<?>)parse(text, format);
/* 1539 */     return eqDate(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean eqTime(MCCalendarDate<?> value) {
/* 1553 */     return eq(value, new MCDateFieldType[] { HOUR, MINUTE, SECOND, MILLISECOND });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean eqTime(String text, String format) {
/* 1570 */     MCCalendarDate<?> value = (MCCalendarDate<?>)parse(text, format);
/* 1571 */     return eqTime(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gt(MCCalendarDate<?> value, MCDateFieldType... fields) {
/* 1592 */     if (value == null) {
/* 1593 */       return false;
/*      */     }
/* 1595 */     if (fields == null || fields.length <= 0) {
/* 1596 */       return (compareTo(value) > 0);
/*      */     }
/*      */     
/* 1599 */     boolean result = false;
/* 1600 */     int len = fields.length;
/* 1601 */     for (int i = 0; i < len; i++) {
/* 1602 */       MCDateFieldType field = fields[i];
/* 1603 */       int own = get(field);
/* 1604 */       int val = value.get(field);
/* 1605 */       if (own != val) {
/* 1606 */         result = (own > val);
/*      */         break;
/*      */       } 
/*      */     } 
/* 1610 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gt(String text, String format, MCDateFieldType... fields) {
/* 1637 */     MCCalendarDate<?> value = (MCCalendarDate<?>)parse(text, format);
/* 1638 */     return gt(value, fields);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gtLeft(MCCalendarDate<?> value, MCDateFieldType field) {
/* 1656 */     MCDateFieldType[] comps = null;
/* 1657 */     if (field != null) {
/* 1658 */       comps = getFieldArray(field, true);
/*      */     }
/* 1660 */     return gt(value, comps);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gtLeft(String text, String format, MCDateFieldType field) {
/* 1684 */     MCCalendarDate<?> value = (MCCalendarDate<?>)parse(text, format);
/* 1685 */     return gtLeft(value, field);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gtRight(MCCalendarDate<?> value, MCDateFieldType field) {
/* 1703 */     MCDateFieldType[] comps = null;
/* 1704 */     if (field != null) {
/* 1705 */       comps = getFieldArray(field, false);
/*      */     }
/* 1707 */     return gt(value, comps);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gtRight(String text, String format, MCDateFieldType field) {
/* 1731 */     MCCalendarDate<?> value = (MCCalendarDate<?>)parse(text, format);
/* 1732 */     return gtRight(value, field);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gtDate(MCCalendarDate<?> value) {
/* 1746 */     return gt(value, new MCDateFieldType[] { YEAR, MONTH, DAY });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gtDate(String text, String format) {
/* 1763 */     MCCalendarDate<?> value = (MCCalendarDate<?>)parse(text, format);
/* 1764 */     return gtDate(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gtTime(MCCalendarDate<?> value) {
/* 1778 */     return gt(value, new MCDateFieldType[] { HOUR, MINUTE, SECOND, MILLISECOND });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gtTime(String text, String format) {
/* 1795 */     MCCalendarDate<?> value = (MCCalendarDate<?>)parse(text, format);
/* 1796 */     return gtTime(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gte(MCCalendarDate<?> value, MCDateFieldType... fields) {
/* 1817 */     if (value == null) {
/* 1818 */       return false;
/*      */     }
/* 1820 */     if (fields == null || fields.length <= 0) {
/* 1821 */       return (compareTo(value) >= 0);
/*      */     }
/*      */     
/* 1824 */     boolean result = true;
/* 1825 */     int len = fields.length;
/* 1826 */     for (int i = 0; i < len; i++) {
/* 1827 */       MCDateFieldType field = fields[i];
/* 1828 */       int own = get(field);
/* 1829 */       int val = value.get(field);
/* 1830 */       if (own != val) {
/* 1831 */         result = (own > val);
/*      */         break;
/*      */       } 
/*      */     } 
/* 1835 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gte(String text, String format, MCDateFieldType... fields) {
/* 1862 */     MCCalendarDate<?> value = (MCCalendarDate<?>)parse(text, format);
/* 1863 */     return gte(value, fields);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gteLeft(MCCalendarDate<?> value, MCDateFieldType field) {
/* 1881 */     MCDateFieldType[] comps = null;
/* 1882 */     if (field != null) {
/* 1883 */       comps = getFieldArray(field, true);
/*      */     }
/* 1885 */     return gte(value, comps);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gteLeft(String text, String format, MCDateFieldType field) {
/* 1909 */     MCCalendarDate<?> value = (MCCalendarDate<?>)parse(text, format);
/* 1910 */     return gteLeft(value, field);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gteRight(MCCalendarDate<?> value, MCDateFieldType field) {
/* 1928 */     MCDateFieldType[] comps = null;
/* 1929 */     if (field != null) {
/* 1930 */       comps = getFieldArray(field, false);
/*      */     }
/* 1932 */     return gte(value, comps);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gteRight(String text, String format, MCDateFieldType field) {
/* 1956 */     MCCalendarDate<?> value = (MCCalendarDate<?>)parse(text, format);
/* 1957 */     return gteRight(value, field);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gteDate(MCCalendarDate<?> value) {
/* 1971 */     return gte(value, new MCDateFieldType[] { YEAR, MONTH, DAY });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gteDate(String text, String format) {
/* 1988 */     MCCalendarDate<?> value = (MCCalendarDate<?>)parse(text, format);
/* 1989 */     return gteDate(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gteTime(MCCalendarDate<?> value) {
/* 2001 */     return gte(value, new MCDateFieldType[] { HOUR, MINUTE, SECOND, MILLISECOND });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gteTime(String text, String format) {
/* 2018 */     MCCalendarDate<?> value = (MCCalendarDate<?>)parse(text, format);
/* 2019 */     return gteTime(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lt(MCCalendarDate<?> value, MCDateFieldType... fields) {
/* 2040 */     if (value == null) {
/* 2041 */       return false;
/*      */     }
/* 2043 */     if (fields == null || fields.length <= 0) {
/* 2044 */       return (compareTo(value) < 0);
/*      */     }
/*      */     
/* 2047 */     boolean result = false;
/* 2048 */     int len = fields.length;
/* 2049 */     for (int i = 0; i < len; i++) {
/* 2050 */       MCDateFieldType field = fields[i];
/* 2051 */       int own = get(field);
/* 2052 */       int val = value.get(field);
/* 2053 */       if (own != val) {
/* 2054 */         result = (own < val);
/*      */         break;
/*      */       } 
/*      */     } 
/* 2058 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lt(String text, String format, MCDateFieldType... fields) {
/* 2085 */     MCCalendarDate<?> value = (MCCalendarDate<?>)parse(text, format);
/* 2086 */     return lt(value, fields);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean ltLeft(MCCalendarDate<?> value, MCDateFieldType field) {
/* 2104 */     MCDateFieldType[] comps = null;
/* 2105 */     if (field != null) {
/* 2106 */       comps = getFieldArray(field, true);
/*      */     }
/* 2108 */     return lt(value, comps);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean ltLeft(String text, String format, MCDateFieldType field) {
/* 2132 */     MCCalendarDate<?> value = (MCCalendarDate<?>)parse(text, format);
/* 2133 */     return ltLeft(value, field);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean ltRight(MCCalendarDate<?> value, MCDateFieldType field) {
/* 2151 */     MCDateFieldType[] comps = null;
/* 2152 */     if (field != null) {
/* 2153 */       comps = getFieldArray(field, false);
/*      */     }
/* 2155 */     return lt(value, comps);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean ltRight(String text, String format, MCDateFieldType field) {
/* 2179 */     MCCalendarDate<?> value = (MCCalendarDate<?>)parse(text, format);
/* 2180 */     return ltRight(value, field);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean ltDate(MCCalendarDate<?> value) {
/* 2194 */     return lt(value, new MCDateFieldType[] { YEAR, MONTH, DAY });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean ltDate(String text, String format) {
/* 2211 */     MCCalendarDate<?> value = (MCCalendarDate<?>)parse(text, format);
/* 2212 */     return ltDate(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean ltTime(MCCalendarDate<?> value) {
/* 2226 */     return lt(value, new MCDateFieldType[] { HOUR, MINUTE, SECOND, MILLISECOND });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean ltTime(String text, String format) {
/* 2243 */     MCCalendarDate<?> value = (MCCalendarDate<?>)parse(text, format);
/* 2244 */     return ltTime(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lte(MCCalendarDate<?> value, MCDateFieldType... fields) {
/* 2265 */     if (value == null) {
/* 2266 */       return false;
/*      */     }
/* 2268 */     if (fields == null || fields.length <= 0) {
/* 2269 */       return (compareTo(value) <= 0);
/*      */     }
/*      */     
/* 2272 */     boolean result = true;
/* 2273 */     int len = fields.length;
/* 2274 */     for (int i = 0; i < len; i++) {
/* 2275 */       MCDateFieldType field = fields[i];
/* 2276 */       int own = get(field);
/* 2277 */       int val = value.get(field);
/* 2278 */       if (own != val) {
/* 2279 */         result = (own < val);
/*      */         break;
/*      */       } 
/*      */     } 
/* 2283 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lte(String text, String format, MCDateFieldType... fields) {
/* 2310 */     MCCalendarDate<?> value = (MCCalendarDate<?>)parse(text, format);
/* 2311 */     return lte(value, fields);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lteLeft(MCCalendarDate<?> value, MCDateFieldType field) {
/* 2329 */     MCDateFieldType[] comps = null;
/* 2330 */     if (field != null) {
/* 2331 */       comps = getFieldArray(field, true);
/*      */     }
/* 2333 */     return lte(value, comps);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lteLeft(String text, String format, MCDateFieldType field) {
/* 2357 */     MCCalendarDate<?> value = (MCCalendarDate<?>)parse(text, format);
/* 2358 */     return lteLeft(value, field);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lteRight(MCCalendarDate<?> value, MCDateFieldType field) {
/* 2376 */     MCDateFieldType[] comps = null;
/* 2377 */     if (field != null) {
/* 2378 */       comps = getFieldArray(field, false);
/*      */     }
/* 2380 */     return lte(value, comps);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lteRight(String text, String format, MCDateFieldType field) {
/* 2404 */     MCCalendarDate<?> value = (MCCalendarDate<?>)parse(text, format);
/* 2405 */     return lteRight(value, field);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lteDate(MCCalendarDate<?> value) {
/* 2419 */     return lte(value, new MCDateFieldType[] { YEAR, MONTH, DAY });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lteDate(String text, String format) {
/* 2436 */     MCCalendarDate<?> value = (MCCalendarDate<?>)parse(text, format);
/* 2437 */     return lteDate(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lteTime(MCCalendarDate<?> value) {
/* 2451 */     return lte(value, new MCDateFieldType[] { HOUR, MINUTE, SECOND, MILLISECOND });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lteTime(String text, String format) {
/* 2468 */     MCCalendarDate<?> value = (MCCalendarDate<?>)parse(text, format);
/* 2469 */     return lteTime(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long diffYear(MCCalendarDate<?> date) {
/* 2735 */     if (date == null)
/*      */     {
/* 2737 */       throw new MCException(Core_Msg_FW_A.FCBFC0023, new Object[0]);
/*      */     }
/* 2739 */     return (getYear() - date.getYear());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long diffYear(String text, String format) {
/* 2761 */     MCCalendarDate<?> value = (MCCalendarDate<?>)parse(text, format);
/* 2762 */     return diffYear(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long diffMonth(MCCalendarDate<?> date) {
/* 2781 */     long y = diffYear(date) * 12L;
/* 2782 */     long m = (getMonth() - date.getMonth());
/* 2783 */     return y + m;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long diffMonth(String text, String format) {
/* 2805 */     MCCalendarDate<?> value = (MCCalendarDate<?>)parse(text, format);
/* 2806 */     return diffMonth(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long diffDay(MCCalendarDate<?> date) {
/* 2825 */     return diffHour(date) / 24L;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long diffDay(String text, String format) {
/* 2847 */     MCCalendarDate<?> value = (MCCalendarDate<?>)parse(text, format);
/* 2848 */     return diffDay(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long diffHour(MCCalendarDate<?> date) {
/* 2867 */     return diffMinute(date) / 60L;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long diffHour(String text, String format) {
/* 2889 */     MCCalendarDate<?> value = (MCCalendarDate<?>)parse(text, format);
/* 2890 */     return diffHour(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long diffMinute(MCCalendarDate<?> date) {
/* 2909 */     return diffSecond(date) / 60L;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long diffMinute(String text, String format) {
/* 2931 */     MCCalendarDate<?> value = (MCCalendarDate<?>)parse(text, format);
/* 2932 */     return diffMinute(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long diffSecond(MCCalendarDate<?> date) {
/* 2951 */     return diffMilliSecond(date) / 1000L;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long diffSecond(String text, String format) {
/* 2973 */     MCCalendarDate<?> value = (MCCalendarDate<?>)parse(text, format);
/* 2974 */     return diffSecond(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long diffMilliSecond(MCCalendarDate<?> date) {
/* 2991 */     if (date == null)
/*      */     {
/* 2993 */       throw new MCException(Core_Msg_FW_A.FCBFC0023, new Object[0]);
/*      */     }
/* 2995 */     return this._time - date._time;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long diffMilliSecond(String text, String format) {
/* 3017 */     MCCalendarDate<?> value = (MCCalendarDate<?>)parse(text, format);
/* 3018 */     return diffMilliSecond(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private T add(MCDateFieldType field, int amount) {
/* 3048 */     GregorianCalendar c = calcCalendar();
/* 3049 */     c.add(field.getField(), amount);
/* 3050 */     return parse(c.getTimeInMillis());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T addYear(int amount) {
/* 3066 */     return add(YEAR, amount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T addMonth(int amount) {
/* 3082 */     return add(MONTH, amount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T addDay(int amount) {
/* 3094 */     return add(DAY, amount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T addHour(int amount) {
/* 3106 */     return add(HOUR, amount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T addMinute(int amount) {
/* 3118 */     return add(MINUTE, amount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T addSecond(int amount) {
/* 3130 */     return add(SECOND, amount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   T addMilliSecond(int amount) {
/* 3142 */     return add(MILLISECOND, amount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private T add(MCDateFieldType field, Number amount) {
/* 3169 */     return (amount != null) ? add(field, amount.intValue()) : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T addYear(Number amount) {
/* 3192 */     return add(YEAR, amount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T addMonth(Number amount) {
/* 3215 */     return add(MONTH, amount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T addDay(Number amount) {
/* 3234 */     return add(DAY, amount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T addHour(Number amount) {
/* 3253 */     return add(HOUR, amount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T addMinute(Number amount) {
/* 3272 */     return add(MINUTE, amount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T addSecond(Number amount) {
/* 3291 */     return add(SECOND, amount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   T addMilliSecond(Number amount) {
/* 3306 */     return add(MILLISECOND, amount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private T mod(MCDateFieldType field, int value) {
/*      */     try {
/* 3336 */       GregorianCalendar c = calcCalendar();
/* 3337 */       c.set(field.getField(), value);
/* 3338 */       return parse(c.getTimeInMillis());
/* 3339 */     } catch (Exception ex) {
/*      */       
/* 3341 */       throw new MCException(ex, Core_Msg_FW_A.FCBFC0010, new Object[] {
/* 3342 */             toString(), String.valueOf(value), field
/*      */           });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T modYear(int value) {
/* 3390 */     return addYear(value - getYear());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T modMonth(int value) {
/* 3407 */     if (value < 1 || 12 < value)
/*      */     {
/* 3409 */       throw new MCException(Core_Msg_FW_A.FCBFC0010, new Object[] {
/* 3410 */             toString(), String.valueOf(value), MONTH
/*      */           });
/*      */     }
/* 3413 */     return addMonth(value - getMonth());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T modDay(int value) {
/* 3426 */     return mod(DAY, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T modHour(int value) {
/* 3439 */     return mod(HOUR, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T modMinute(int value) {
/* 3452 */     return mod(MINUTE, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T modSecond(int value) {
/* 3465 */     return mod(SECOND, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   T modMilliSecond(int value) {
/* 3478 */     return mod(MILLISECOND, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private T mod(MCDateFieldType field, Number value) {
/* 3503 */     if (value == null)
/*      */     {
/* 3505 */       throw new MCException(Core_Msg_FW_A.FCBFC0010, new Object[] { toString(), value, field });
/*      */     }
/* 3507 */     return mod(field, value.intValue());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T modYear(Number value) {
/* 3528 */     if (value == null)
/*      */     {
/* 3530 */       throw new MCException(Core_Msg_FW_A.FCBFC0010, new Object[] { toString(), value, YEAR });
/*      */     }
/*      */     
/* 3533 */     return addYear(value.intValue() - getYear());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T modMonth(Number value) {
/* 3554 */     if (value == null)
/*      */     {
/* 3556 */       throw new MCException(Core_Msg_FW_A.FCBFC0010, new Object[] { toString(), value, MONTH });
/*      */     }
/* 3558 */     int intval = value.intValue();
/* 3559 */     if (intval < 1 || 12 < intval)
/*      */     {
/* 3561 */       throw new MCException(Core_Msg_FW_A.FCBFC0010, new Object[] { toString(), value, MONTH });
/*      */     }
/*      */     
/* 3564 */     return addMonth(intval - getMonth());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T modDay(Number value) {
/* 3581 */     return mod(DAY, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T modHour(Number value) {
/* 3598 */     return mod(HOUR, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T modMinute(Number value) {
/* 3615 */     return mod(MINUTE, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T modSecond(Number value) {
/* 3632 */     return mod(SECOND, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   T modMilliSecond(Number value) {
/* 3645 */     return mod(MILLISECOND, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T modDate(MCCalendarDate<?> date) {
/* 3659 */     GregorianCalendar othc = createCalendar();
/* 3660 */     othc.setTimeInMillis((date != null) ? date._time : 0L);
/* 3661 */     GregorianCalendar ownc = calcCalendar();
/* 3662 */     ownc.set(YEAR.getField(), othc.get(YEAR.getField()));
/* 3663 */     ownc.set(MONTH.getField(), othc.get(MONTH.getField()));
/* 3664 */     ownc.set(DAY.getField(), othc.get(DAY.getField()));
/* 3665 */     return parse(ownc.getTimeInMillis());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T modDate(String text, String format) {
/* 3680 */     MCCalendarDate<?> value = (MCCalendarDate<?>)parse(text, format);
/* 3681 */     return modDate(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T modTime(MCCalendarDate<?> date) {
/* 3695 */     GregorianCalendar othc = createCalendar();
/* 3696 */     othc.setTimeInMillis((date != null) ? date._time : 0L);
/* 3697 */     GregorianCalendar ownc = calcCalendar();
/* 3698 */     ownc.set(HOUR.getField(), othc.get(HOUR.getField()));
/* 3699 */     ownc.set(MINUTE.getField(), othc.get(MINUTE.getField()));
/* 3700 */     ownc.set(SECOND.getField(), othc.get(SECOND.getField()));
/* 3701 */     ownc.set(MILLISECOND.getField(), othc.get(MILLISECOND.getField()));
/* 3702 */     return parse(ownc.getTimeInMillis());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T modTime(String text, String format) {
/* 3717 */     MCCalendarDate<?> value = (MCCalendarDate<?>)parse(text, format);
/* 3718 */     return modDate(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T startOfYear() {
/* 3732 */     GregorianCalendar c = calcCalendar();
/* 3733 */     c.set(MONTH.getField(), 0);
/* 3734 */     c.set(DAY.getField(), 1);
/* 3735 */     return parse(c.getTimeInMillis());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T endOfYear() {
/* 3748 */     GregorianCalendar c = calcCalendar();
/* 3749 */     c.set(MONTH.getField(), 11);
/* 3750 */     c.set(DAY.getField(), 31);
/* 3751 */     return parse(c.getTimeInMillis());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T startOfMonth() {
/* 3764 */     GregorianCalendar c = calcCalendar();
/* 3765 */     c.set(DAY.getField(), 1);
/* 3766 */     return parse(c.getTimeInMillis());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T endOfMonth() {
/* 3779 */     GregorianCalendar c = calcCalendar();
/* 3780 */     c.set(DAY.getField(), c.getActualMaximum(DAY.getField()));
/* 3781 */     return parse(c.getTimeInMillis());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T startTimeOfYear() {
/* 3794 */     GregorianCalendar c = calcCalendar();
/* 3795 */     c.set(MONTH.getField(), 0);
/* 3796 */     c.set(DAY.getField(), 1);
/* 3797 */     c.set(HOUR.getField(), 0);
/* 3798 */     c.set(MINUTE.getField(), 0);
/* 3799 */     c.set(SECOND.getField(), 0);
/* 3800 */     c.set(MILLISECOND.getField(), 0);
/* 3801 */     return parse(c.getTimeInMillis());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T endTimeOfYear() {
/* 3814 */     GregorianCalendar c = calcCalendar();
/* 3815 */     c.set(MONTH.getField(), 11);
/* 3816 */     c.set(DAY.getField(), 31);
/* 3817 */     c.set(HOUR.getField(), 23);
/* 3818 */     c.set(MINUTE.getField(), 59);
/* 3819 */     c.set(SECOND.getField(), 59);
/* 3820 */     c.set(MILLISECOND.getField(), 999);
/* 3821 */     return parse(c.getTimeInMillis());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T startTimeOfMonth() {
/* 3834 */     GregorianCalendar c = calcCalendar();
/* 3835 */     c.set(DAY.getField(), 1);
/* 3836 */     c.set(HOUR.getField(), 0);
/* 3837 */     c.set(MINUTE.getField(), 0);
/* 3838 */     c.set(SECOND.getField(), 0);
/* 3839 */     c.set(MILLISECOND.getField(), 0);
/* 3840 */     return parse(c.getTimeInMillis());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T endTimeOfMonth() {
/* 3853 */     GregorianCalendar c = calcCalendar();
/* 3854 */     c.set(DAY.getField(), c.getActualMaximum(DAY.getField()));
/* 3855 */     c.set(HOUR.getField(), 23);
/* 3856 */     c.set(MINUTE.getField(), 59);
/* 3857 */     c.set(SECOND.getField(), 59);
/* 3858 */     c.set(MILLISECOND.getField(), 999);
/* 3859 */     return parse(c.getTimeInMillis());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T startTimeOfDay() {
/* 3873 */     GregorianCalendar c = calcCalendar();
/* 3874 */     c.set(HOUR.getField(), 0);
/* 3875 */     c.set(MINUTE.getField(), 0);
/* 3876 */     c.set(SECOND.getField(), 0);
/* 3877 */     c.set(MILLISECOND.getField(), 0);
/* 3878 */     return parse(c.getTimeInMillis());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T endTimeOfDay() {
/* 3892 */     GregorianCalendar c = calcCalendar();
/* 3893 */     c.set(HOUR.getField(), 23);
/* 3894 */     c.set(MINUTE.getField(), 59);
/* 3895 */     c.set(SECOND.getField(), 59);
/* 3896 */     c.set(MILLISECOND.getField(), 999);
/* 3897 */     return parse(c.getTimeInMillis());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public T trunc(MCDateFieldType field) {
/* 3916 */     GregorianCalendar c = calcCalendar();
/* 3917 */     MCDateFieldType[] fields = MCDateFieldType.values();
/* 3918 */     boolean skip = (field != null); byte b; int i; MCDateFieldType[] arrayOfMCDateFieldType1;
/* 3919 */     for (i = (arrayOfMCDateFieldType1 = fields).length, b = 0; b < i; ) { MCDateFieldType f = arrayOfMCDateFieldType1[b];
/* 3920 */       if (skip) {
/* 3921 */         skip = (f != field);
/*      */       } else {
/*      */         
/* 3924 */         c.set(f.getField(), c.getMinimum(f.getField()));
/*      */       }  b++; }
/*      */     
/* 3927 */     return parse(c.getTimeInMillis());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 3964 */     return toString(getToStringFormat());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString(String format) {
/* 3981 */     SimpleDateFormat f = createDateFormat(format);
/* 3982 */     return toString(f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString(String format, Locale locale) {
/* 4001 */     SimpleDateFormat f = createDateFormat(format, locale);
/* 4002 */     return toString(f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString(DateFormat format) {
/* 4015 */     if (format == null)
/*      */     {
/* 4017 */       throw new MCException(Core_Msg_FW_A.FCBFC0018, new Object[0]);
/*      */     }
/* 4019 */     return format.format(toDate());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date toDate() {
/* 4036 */     return new Date(this._time);
/*      */   }
/*      */   
/*      */   abstract long inittime(long paramLong);
/*      */   
/*      */   abstract T parse(String paramString1, String paramString2);
/*      */   
/*      */   abstract T parse(long paramLong);
/*      */   
/*      */   abstract String getToStringFormat();
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\lang\MCCalendarDate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */