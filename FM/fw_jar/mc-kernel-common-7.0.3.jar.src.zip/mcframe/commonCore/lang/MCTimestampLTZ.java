/*      */ package mcframe.commonCore.lang;
/*      */ import java.util.Calendar;
/*      */ import java.util.Date;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.TimeZone;
/*      */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*      */ import mcframe.commonCore.notice.MCException;
/*      */ 
/*      */ final class MCTimestampLTZ extends Date {
/*      */   public static final int JANUARY = 0;
/*      */   public static final int JAN = 0;
/*      */   public static final int FEBRUARY = 1;
/*      */   public static final int FEB = 1;
/*      */   public static final int MARCH = 2;
/*      */   public static final int MAR = 2;
/*      */   public static final int APRIL = 3;
/*      */   public static final int APR = 3;
/*      */   public static final int MAY = 4;
/*      */   public static final int JUNE = 5;
/*      */   public static final int JUN = 5;
/*      */   public static final int JULY = 6;
/*      */   public static final int JUL = 6;
/*      */   public static final int AUGUST = 7;
/*      */   public static final int AUG = 7;
/*      */   public static final int SEPTEMBER = 8;
/*      */   public static final int SEP = 8;
/*      */   public static final int OCTOBER = 9;
/*      */   public static final int OCT = 9;
/*      */   public static final int NOVEMBER = 10;
/*      */   public static final int NOV = 10;
/*      */   public static final int DECEMBER = 11;
/*      */   public static final int DEC = 11;
/*      */   public static final int SUNDAY = 1;
/*      */   public static final int SUN = 1;
/*      */   public static final int MONDAY = 2;
/*      */   public static final int MON = 2;
/*      */   public static final int TUESDAY = 3;
/*      */   public static final int TUE = 3;
/*      */   public static final int WEDNESDAY = 4;
/*      */   public static final int WED = 4;
/*      */   public static final int THURSDAY = 5;
/*      */   public static final int THU = 5;
/*      */   public static final int FRIDAY = 6;
/*      */   public static final int FRI = 6;
/*      */   public static final int SATURDAY = 7;
/*      */   public static final int SAT = 7;
/*      */   public static final String TO_STRING_FORMAT = "yyyyMMddHHmmssSSS";
/*      */   private GregorianCalendar _calendar;
/*      */   
/*      */   public enum Field {
/*   51 */     YEAR(
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*   56 */       1, 0),
/*      */     
/*   58 */     YEAR_BOTTOM(
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*   63 */       1, 0),
/*      */     
/*   65 */     MONTH(
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*   70 */       2, 1),
/*      */     
/*   72 */     DAY(
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*   77 */       5, 1),
/*      */     
/*   79 */     HOUR24(
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*   84 */       11, 0),
/*      */     
/*   86 */     HOUR12(
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*   91 */       10, 0),
/*      */     
/*   93 */     MINUTE(
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*   98 */       12, 0),
/*      */     
/*  100 */     SECOND(
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  105 */       13, 0),
/*      */     
/*  107 */     MILLISECOND(
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  112 */       14, 0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int calField;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Field(int calendarField, int minimum) {
/*  136 */       this.calField = calendarField;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getField() {
/*  147 */       return this.calField;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static MCTimestampLTZ valueOf(Date date) {
/*  429 */     if (date == null) {
/*  430 */       return null;
/*      */     }
/*  432 */     return new MCTimestampLTZ(date.getTime());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static MCTimestampLTZ valueOf(String text, String format) {
/*  450 */     return valueOf(text, format, TimeZone.getDefault());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static MCTimestampLTZ valueOf(String text, String format, TimeZone tz) {
/*  470 */     if (text == null) {
/*  471 */       return null;
/*      */     }
/*  473 */     if (tz == null)
/*      */     {
/*  475 */       throw new MCException(Core_Msg_FW_A.FCBFC0010, new Object[0]);
/*      */     }
/*  477 */     if (format == null)
/*      */     {
/*  479 */       throw new MCException(Core_Msg_FW_A.FCBFC0011, new Object[] { text });
/*      */     }
/*      */     
/*  482 */     SimpleDateFormat f = new SimpleDateFormat(format);
/*  483 */     f.setLenient(false);
/*  484 */     f.setTimeZone(tz);
/*      */     try {
/*  486 */       Date date = f.parse(text);
/*  487 */       return valueOf(date);
/*  488 */     } catch (ParseException ex) {
/*      */       
/*  490 */       throw new MCException(ex, Core_Msg_FW_A.FCBFC0012, new Object[] {
/*  491 */             text, format, Integer.valueOf(ex.getErrorOffset())
/*      */           });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCTimestampLTZ() {
/*  538 */     this._calendar = null; } public MCTimestampLTZ(long time) { super(time); this._calendar = null; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private GregorianCalendar getInnerCalendar() {
/*  551 */     if (this._calendar == null) {
/*  552 */       this._calendar = new GregorianCalendar();
/*      */     }
/*  554 */     this._calendar.setTime(this);
/*  555 */     return this._calendar;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int get(Field field) {
/*  574 */     if (field == null)
/*      */     {
/*  576 */       throw new MCException(Core_Msg_FW_A.FCBFC0016, new Object[] { field });
/*      */     }
/*  578 */     return getInnerCalendar().get(field.getField());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getYear() {
/*  590 */     return get(Field.YEAR);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMonth() {
/*  602 */     return get(Field.MONTH);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getDay() {
/*  614 */     return get(Field.DAY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getHour() {
/*  625 */     return get(Field.HOUR24);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMinute() {
/*  636 */     return get(Field.MINUTE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getSecond() {
/*  647 */     return get(Field.SECOND);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMilliSecond() {
/*  658 */     return get(Field.MILLISECOND);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isLeapYear() {
/*  699 */     int year = get(Field.YEAR);
/*  700 */     return getInnerCalendar().isLeapYear(year);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Field[] getFieldArray(Field field, boolean front) {
/*  722 */     if (field == null)
/*      */     {
/*  724 */       throw new MCException(Core_Msg_FW_A.FCBFC0013, new Object[0]);
/*      */     }
/*      */     
/*  727 */     Field[] consts = Field.values();
/*  728 */     int pos = 0;
/*  729 */     int len = consts.length;
/*  730 */     for (; !consts[pos].equals(field) && pos < len; pos++);
/*  731 */     if (pos >= len)
/*      */     {
/*  733 */       throw new MCException(Core_Msg_FW_A.FCBFC0015, new Object[] { field });
/*      */     }
/*      */     
/*  736 */     Field[] fields = null;
/*  737 */     if (front) {
/*  738 */       fields = new Field[pos + 1];
/*  739 */       System.arraycopy(consts, 0, fields, 0, fields.length);
/*      */     } else {
/*  741 */       fields = new Field[len - pos];
/*  742 */       System.arraycopy(consts, pos, fields, 0, fields.length);
/*      */     } 
/*  744 */     return fields;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int compareField(int value, Field field) {
/*  762 */     if (field == null)
/*      */     {
/*  764 */       throw new MCException(Core_Msg_FW_A.FCBFC0013, new Object[0]);
/*      */     }
/*      */     
/*  767 */     int ownvalue = get(field);
/*  768 */     int result = 0;
/*  769 */     if (ownvalue < value) {
/*  770 */       result = -1;
/*  771 */     } else if (ownvalue > value) {
/*  772 */       result = 1;
/*      */     } 
/*  774 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int compareField(Date value, Field... fields) {
/*  796 */     if (value == null)
/*      */     {
/*      */       
/*  799 */       throw new MCException(Core_Msg_FW_A.FCBFC0014, new Object[0]);
/*      */     }
/*  801 */     if (fields == null || fields.length <= 0)
/*      */     {
/*  803 */       throw new MCException(Core_Msg_FW_A.FCBFC0013, new Object[0]);
/*      */     }
/*      */     
/*  806 */     Calendar gc = new GregorianCalendar();
/*  807 */     gc.setTime(value);
/*  808 */     int result = 0;
/*  809 */     int len = fields.length;
/*  810 */     for (int i = 0; result == 0 && i < len; i++) {
/*  811 */       Field field = fields[i];
/*  812 */       result = compareField(gc.get(field.getField()), field);
/*      */     } 
/*  814 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int compareLeft(Date value, Field field) {
/*  834 */     Field[] comps = getFieldArray(field, true);
/*  835 */     return compareField(value, comps);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int compareRight(Date value, Field field) {
/*  855 */     Field[] comps = getFieldArray(field, false);
/*  856 */     return compareField(value, comps);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean eq(Date value, Field... fields) {
/*  875 */     if (value == null) {
/*  876 */       return false;
/*      */     }
/*  878 */     if (fields == null || fields.length <= 0) {
/*  879 */       return equals(value);
/*      */     }
/*      */     
/*  882 */     boolean result = true;
/*  883 */     Calendar gc = new GregorianCalendar();
/*  884 */     gc.setTime(value);
/*  885 */     int len = fields.length;
/*  886 */     for (int i = 0; i < len; i++) {
/*  887 */       Field field = fields[i];
/*  888 */       if (get(field) != gc.get(field.getField())) {
/*  889 */         result = false;
/*      */         break;
/*      */       } 
/*      */     } 
/*  893 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean eq(String text, String format, Field... fields) {
/*  918 */     MCTimestampLTZ value = valueOf(text, format);
/*  919 */     return eq(value, fields);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean eq(String text, String format, TimeZone tz, Field... fields) {
/*  941 */     MCTimestampLTZ value = valueOf(text, format, tz);
/*  942 */     return eq(value, fields);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean eqLeft(Date value, Field field) {
/*  960 */     Field[] comps = null;
/*  961 */     if (field != null) {
/*  962 */       comps = getFieldArray(field, true);
/*      */     }
/*  964 */     return eq(value, comps);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean eqLeft(String text, String format, Field field) {
/*  988 */     MCTimestampLTZ value = valueOf(text, format);
/*  989 */     return eqLeft(value, field);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean eqLeft(String text, String format, TimeZone tz, Field field) {
/* 1011 */     MCTimestampLTZ value = valueOf(text, format, tz);
/* 1012 */     return eqLeft(value, field);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean eqRight(Date value, Field field) {
/* 1030 */     Field[] comps = null;
/* 1031 */     if (field != null) {
/* 1032 */       comps = getFieldArray(field, false);
/*      */     }
/* 1034 */     return eq(value, comps);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean eqRight(String text, String format, Field field) {
/* 1058 */     MCTimestampLTZ value = valueOf(text, format);
/* 1059 */     return eqRight(value, field);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean eqRight(String text, String format, TimeZone tz, Field field) {
/* 1081 */     MCTimestampLTZ value = valueOf(text, format, tz);
/* 1082 */     return eqRight(value, field);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean eqDate(Date value) {
/* 1096 */     return eq(value, new Field[] { Field.YEAR, Field.MONTH, Field.DAY });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean eqDate(String text, String format) {
/* 1114 */     MCTimestampLTZ value = valueOf(text, format);
/* 1115 */     return eqDate(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean eqDate(String text, String format, TimeZone tz) {
/* 1134 */     MCTimestampLTZ value = valueOf(text, format, tz);
/* 1135 */     return eqDate(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean eqTime(Date value) {
/* 1149 */     return eq(value, new Field[] { Field.HOUR24, Field.MINUTE, Field.SECOND, 
/* 1150 */           Field.MILLISECOND });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean eqTime(String text, String format) {
/* 1168 */     MCTimestampLTZ value = valueOf(text, format);
/* 1169 */     return eqTime(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean eqTime(String text, String format, TimeZone tz) {
/* 1187 */     MCTimestampLTZ value = valueOf(text, format, tz);
/* 1188 */     return eqTime(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gt(Date value, Field... fields) {
/* 1209 */     if (value == null) {
/* 1210 */       return false;
/*      */     }
/* 1212 */     if (fields == null || fields.length <= 0) {
/* 1213 */       return (compareTo(value) > 0);
/*      */     }
/*      */     
/* 1216 */     boolean result = false;
/* 1217 */     Calendar gc = new GregorianCalendar();
/* 1218 */     gc.setTime(value);
/* 1219 */     int len = fields.length;
/* 1220 */     for (int i = 0; i < len; i++) {
/* 1221 */       Field field = fields[i];
/* 1222 */       int own = get(field);
/* 1223 */       int val = gc.get(field.getField());
/* 1224 */       if (own != val) {
/* 1225 */         result = (own > val);
/*      */         break;
/*      */       } 
/*      */     } 
/* 1229 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gt(String text, String format, Field... fields) {
/* 1256 */     MCTimestampLTZ value = valueOf(text, format);
/* 1257 */     return gt(value, fields);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gt(String text, String format, TimeZone tz, Field... fields) {
/* 1281 */     MCTimestampLTZ value = valueOf(text, format, tz);
/* 1282 */     return gt(value, fields);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gtLeft(Date value, Field field) {
/* 1300 */     Field[] comps = null;
/* 1301 */     if (field != null) {
/* 1302 */       comps = getFieldArray(field, true);
/*      */     }
/* 1304 */     return gt(value, comps);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gtLeft(String text, String format, Field field) {
/* 1328 */     MCTimestampLTZ value = valueOf(text, format);
/* 1329 */     return gtLeft(value, field);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gtLeft(String text, String format, TimeZone tz, Field field) {
/* 1351 */     MCTimestampLTZ value = valueOf(text, format, tz);
/* 1352 */     return gtLeft(value, field);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gtRight(Date value, Field field) {
/* 1370 */     Field[] comps = null;
/* 1371 */     if (field != null) {
/* 1372 */       comps = getFieldArray(field, false);
/*      */     }
/* 1374 */     return gt(value, comps);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gtRight(String text, String format, Field field) {
/* 1398 */     MCTimestampLTZ value = valueOf(text, format);
/* 1399 */     return gtRight(value, field);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gtRight(String text, String format, TimeZone tz, Field field) {
/* 1421 */     MCTimestampLTZ value = valueOf(text, format, tz);
/* 1422 */     return gtRight(value, field);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gtDate(Date value) {
/* 1436 */     return gt(value, new Field[] { Field.YEAR, Field.MONTH, Field.DAY });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gtDate(String text, String format) {
/* 1454 */     MCTimestampLTZ value = valueOf(text, format);
/* 1455 */     return gtDate(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gtDate(String text, String format, TimeZone tz) {
/* 1474 */     MCTimestampLTZ value = valueOf(text, format, tz);
/* 1475 */     return gtDate(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gtTime(Date value) {
/* 1489 */     return gt(value, new Field[] { Field.HOUR24, Field.MINUTE, Field.SECOND, 
/* 1490 */           Field.MILLISECOND });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gtTime(String text, String format) {
/* 1508 */     MCTimestampLTZ value = valueOf(text, format);
/* 1509 */     return gtTime(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gtTime(String text, String format, TimeZone tz) {
/* 1527 */     MCTimestampLTZ value = valueOf(text, format, tz);
/* 1528 */     return gtTime(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gte(Date value, Field... fields) {
/* 1549 */     if (value == null) {
/* 1550 */       return false;
/*      */     }
/* 1552 */     if (fields == null || fields.length <= 0) {
/* 1553 */       return (compareTo(value) >= 0);
/*      */     }
/*      */     
/* 1556 */     boolean result = true;
/* 1557 */     Calendar gc = new GregorianCalendar();
/* 1558 */     gc.setTime(value);
/* 1559 */     int len = fields.length;
/* 1560 */     for (int i = 0; i < len; i++) {
/* 1561 */       Field field = fields[i];
/* 1562 */       int own = get(field);
/* 1563 */       int val = gc.get(field.getField());
/* 1564 */       if (own != val) {
/* 1565 */         result = (own > val);
/*      */         break;
/*      */       } 
/*      */     } 
/* 1569 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gte(String text, String format, Field... fields) {
/* 1596 */     MCTimestampLTZ value = valueOf(text, format);
/* 1597 */     return gte(value, fields);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gte(String text, String format, TimeZone tz, Field... fields) {
/* 1621 */     MCTimestampLTZ value = valueOf(text, format, tz);
/* 1622 */     return gte(value, fields);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gteLeft(Date value, Field field) {
/* 1640 */     Field[] comps = null;
/* 1641 */     if (field != null) {
/* 1642 */       comps = getFieldArray(field, true);
/*      */     }
/* 1644 */     return gte(value, comps);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gteLeft(String text, String format, Field field) {
/* 1668 */     MCTimestampLTZ value = valueOf(text, format);
/* 1669 */     return gteLeft(value, field);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gteLeft(String text, String format, TimeZone tz, Field field) {
/* 1691 */     MCTimestampLTZ value = valueOf(text, format, tz);
/* 1692 */     return gteLeft(value, field);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gteRight(Date value, Field field) {
/* 1710 */     Field[] comps = null;
/* 1711 */     if (field != null) {
/* 1712 */       comps = getFieldArray(field, false);
/*      */     }
/* 1714 */     return gte(value, comps);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gteRight(String text, String format, Field field) {
/* 1738 */     MCTimestampLTZ value = valueOf(text, format);
/* 1739 */     return gteRight(value, field);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gteRight(String text, String format, TimeZone tz, Field field) {
/* 1761 */     MCTimestampLTZ value = valueOf(text, format, tz);
/* 1762 */     return gteRight(value, field);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gteDate(Date value) {
/* 1776 */     return gte(value, new Field[] { Field.YEAR, Field.MONTH, Field.DAY });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gteDate(String text, String format) {
/* 1794 */     MCTimestampLTZ value = valueOf(text, format);
/* 1795 */     return gteDate(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gteDate(String text, String format, TimeZone tz) {
/* 1814 */     MCTimestampLTZ value = valueOf(text, format, tz);
/* 1815 */     return gteDate(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gteTime(Date value) {
/* 1827 */     return gte(value, new Field[] { Field.HOUR24, Field.MINUTE, Field.SECOND, 
/* 1828 */           Field.MILLISECOND });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gteTime(String text, String format) {
/* 1846 */     MCTimestampLTZ value = valueOf(text, format);
/* 1847 */     return gteTime(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gteTime(String text, String format, TimeZone tz) {
/* 1865 */     MCTimestampLTZ value = valueOf(text, format, tz);
/* 1866 */     return gteTime(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lt(Date value, Field... fields) {
/* 1887 */     if (value == null) {
/* 1888 */       return false;
/*      */     }
/* 1890 */     if (fields == null || fields.length <= 0) {
/* 1891 */       return (compareTo(value) < 0);
/*      */     }
/*      */     
/* 1894 */     boolean result = false;
/* 1895 */     Calendar gc = new GregorianCalendar();
/* 1896 */     gc.setTime(value);
/* 1897 */     int len = fields.length;
/* 1898 */     for (int i = 0; i < len; i++) {
/* 1899 */       Field field = fields[i];
/* 1900 */       int own = get(field);
/* 1901 */       int val = gc.get(field.getField());
/* 1902 */       if (own != val) {
/* 1903 */         result = (own < val);
/*      */         break;
/*      */       } 
/*      */     } 
/* 1907 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lt(String text, String format, Field... fields) {
/* 1934 */     MCTimestampLTZ value = valueOf(text, format);
/* 1935 */     return lt(value, fields);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lt(String text, String format, TimeZone tz, Field... fields) {
/* 1959 */     MCTimestampLTZ value = valueOf(text, format, tz);
/* 1960 */     return lt(value, fields);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean ltLeft(Date value, Field field) {
/* 1978 */     Field[] comps = null;
/* 1979 */     if (field != null) {
/* 1980 */       comps = getFieldArray(field, true);
/*      */     }
/* 1982 */     return lt(value, comps);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean ltLeft(String text, String format, Field field) {
/* 2006 */     MCTimestampLTZ value = valueOf(text, format);
/* 2007 */     return ltLeft(value, field);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean ltLeft(String text, String format, TimeZone tz, Field field) {
/* 2029 */     MCTimestampLTZ value = valueOf(text, format, tz);
/* 2030 */     return ltLeft(value, field);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean ltRight(Date value, Field field) {
/* 2048 */     Field[] comps = null;
/* 2049 */     if (field != null) {
/* 2050 */       comps = getFieldArray(field, false);
/*      */     }
/* 2052 */     return lt(value, comps);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean ltRight(String text, String format, Field field) {
/* 2076 */     MCTimestampLTZ value = valueOf(text, format);
/* 2077 */     return ltRight(value, field);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean ltRight(String text, String format, TimeZone tz, Field field) {
/* 2099 */     MCTimestampLTZ value = valueOf(text, format, tz);
/* 2100 */     return ltRight(value, field);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean ltDate(Date value) {
/* 2114 */     return lt(value, new Field[] { Field.YEAR, Field.MONTH, Field.DAY });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean ltDate(String text, String format) {
/* 2132 */     MCTimestampLTZ value = valueOf(text, format);
/* 2133 */     return ltDate(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean ltDate(String text, String format, TimeZone tz) {
/* 2152 */     MCTimestampLTZ value = valueOf(text, format, tz);
/* 2153 */     return ltDate(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean ltTime(Date value) {
/* 2167 */     return lt(value, new Field[] { Field.HOUR24, Field.MINUTE, Field.SECOND, 
/* 2168 */           Field.MILLISECOND });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean ltTime(String text, String format) {
/* 2186 */     MCTimestampLTZ value = valueOf(text, format);
/* 2187 */     return ltTime(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean ltTime(String text, String format, TimeZone tz) {
/* 2205 */     MCTimestampLTZ value = valueOf(text, format, tz);
/* 2206 */     return ltTime(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lte(Date value, Field... fields) {
/* 2227 */     if (value == null) {
/* 2228 */       return false;
/*      */     }
/* 2230 */     if (fields == null || fields.length <= 0) {
/* 2231 */       return (compareTo(value) <= 0);
/*      */     }
/*      */     
/* 2234 */     boolean result = true;
/* 2235 */     Calendar gc = new GregorianCalendar();
/* 2236 */     gc.setTime(value);
/* 2237 */     int len = fields.length;
/* 2238 */     for (int i = 0; i < len; i++) {
/* 2239 */       Field field = fields[i];
/* 2240 */       int own = get(field);
/* 2241 */       int val = gc.get(field.getField());
/* 2242 */       if (own != val) {
/* 2243 */         result = (own < val);
/*      */         break;
/*      */       } 
/*      */     } 
/* 2247 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lte(String text, String format, Field... fields) {
/* 2274 */     MCTimestampLTZ value = valueOf(text, format);
/* 2275 */     return lte(value, fields);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lte(String text, String format, TimeZone tz, Field... fields) {
/* 2299 */     MCTimestampLTZ value = valueOf(text, format, tz);
/* 2300 */     return lte(value, fields);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lteLeft(Date value, Field field) {
/* 2318 */     Field[] comps = null;
/* 2319 */     if (field != null) {
/* 2320 */       comps = getFieldArray(field, true);
/*      */     }
/* 2322 */     return lte(value, comps);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lteLeft(String text, String format, Field field) {
/* 2346 */     MCTimestampLTZ value = valueOf(text, format);
/* 2347 */     return lteLeft(value, field);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lteLeft(String text, String format, TimeZone tz, Field field) {
/* 2369 */     MCTimestampLTZ value = valueOf(text, format, tz);
/* 2370 */     return lteLeft(value, field);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lteRight(Date value, Field field) {
/* 2388 */     Field[] comps = null;
/* 2389 */     if (field != null) {
/* 2390 */       comps = getFieldArray(field, false);
/*      */     }
/* 2392 */     return lte(value, comps);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lteRight(String text, String format, Field field) {
/* 2416 */     MCTimestampLTZ value = valueOf(text, format);
/* 2417 */     return lteRight(value, field);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lteRight(String text, String format, TimeZone tz, Field field) {
/* 2439 */     MCTimestampLTZ value = valueOf(text, format, tz);
/* 2440 */     return lteRight(value, field);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lteDate(Date value) {
/* 2454 */     return lte(value, new Field[] { Field.YEAR, Field.MONTH, Field.DAY });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lteDate(String text, String format) {
/* 2472 */     MCTimestampLTZ value = valueOf(text, format);
/* 2473 */     return lteDate(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lteDate(String text, String format, TimeZone tz) {
/* 2492 */     MCTimestampLTZ value = valueOf(text, format, tz);
/* 2493 */     return lteDate(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lteTime(Date value) {
/* 2507 */     return lte(value, new Field[] { Field.HOUR24, Field.MINUTE, Field.SECOND, 
/* 2508 */           Field.MILLISECOND });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lteTime(String text, String format) {
/* 2526 */     MCTimestampLTZ value = valueOf(text, format);
/* 2527 */     return lteTime(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lteTime(String text, String format, TimeZone tz) {
/* 2545 */     MCTimestampLTZ value = valueOf(text, format, tz);
/* 2546 */     return lteTime(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCTimestampLTZ add(Field field, int amount) {
/* 2940 */     if (field == null)
/*      */     {
/* 2942 */       throw new MCException(Core_Msg_FW_A.FCBFC0016, new Object[] { field });
/*      */     }
/* 2944 */     GregorianCalendar c = getInnerCalendar();
/* 2945 */     c.add(field.getField(), amount);
/* 2946 */     return new MCTimestampLTZ(c.getTimeInMillis());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCTimestampLTZ addYear(int amount) {
/* 2958 */     return add(Field.YEAR, amount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCTimestampLTZ addMonth(int amount) {
/* 2970 */     return add(Field.MONTH, amount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCTimestampLTZ addDay(int amount) {
/* 2982 */     return add(Field.DAY, amount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCTimestampLTZ addHour(int amount) {
/* 2994 */     return add(Field.HOUR24, amount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCTimestampLTZ addMinute(int amount) {
/* 3006 */     return add(Field.MINUTE, amount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCTimestampLTZ addSecond(int amount) {
/* 3018 */     return add(Field.SECOND, amount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCTimestampLTZ addMilliSecond(int amount) {
/* 3030 */     return add(Field.MILLISECOND, amount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCTimestampLTZ mod(Field field, int value) {
/* 3045 */     if (field == null)
/*      */     {
/* 3047 */       throw new MCException(Core_Msg_FW_A.FCBFC0016, new Object[0]);
/*      */     }
/* 3049 */     GregorianCalendar c = getInnerCalendar();
/* 3050 */     c.set(field.getField(), value);
/* 3051 */     return new MCTimestampLTZ(c.getTimeInMillis());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCTimestampLTZ modYear(int value) {
/* 3063 */     return mod(Field.YEAR, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCTimestampLTZ modMonth(int value) {
/* 3075 */     return mod(Field.MONTH, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCTimestampLTZ modDay(int value) {
/* 3087 */     return mod(Field.DAY, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCTimestampLTZ modHour(int value) {
/* 3099 */     return mod(Field.HOUR24, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCTimestampLTZ modMinute(int value) {
/* 3111 */     return mod(Field.MINUTE, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCTimestampLTZ modSecond(int value) {
/* 3123 */     return mod(Field.SECOND, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCTimestampLTZ modMilliSecond(int value) {
/* 3135 */     return mod(Field.MILLISECOND, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCTimestampLTZ endOfMonth() {
/* 3153 */     GregorianCalendar c = getInnerCalendar();
/* 3154 */     c.set(Field.DAY.getField(), c.getActualMaximum(Field.DAY.getField()));
/* 3155 */     c.set(Field.HOUR24.getField(), 23);
/* 3156 */     c.set(Field.MINUTE.getField(), 59);
/* 3157 */     c.set(Field.SECOND.getField(), 59);
/* 3158 */     c.set(Field.MILLISECOND.getField(), 999);
/* 3159 */     return new MCTimestampLTZ(c.getTimeInMillis());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCTimestampLTZ startOfMonth() {
/* 3176 */     GregorianCalendar c = getInnerCalendar();
/* 3177 */     c.set(Field.DAY.getField(), c.getActualMinimum(Field.DAY.getField()));
/* 3178 */     c.set(Field.HOUR24.getField(), 0);
/* 3179 */     c.set(Field.MINUTE.getField(), 0);
/* 3180 */     c.set(Field.SECOND.getField(), 0);
/* 3181 */     c.set(Field.MILLISECOND.getField(), 0);
/* 3182 */     return new MCTimestampLTZ(c.getTimeInMillis());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public GregorianCalendar toCalendar() {
/* 3199 */     GregorianCalendar cal = new GregorianCalendar();
/* 3200 */     cal.setTimeInMillis(getTime());
/* 3201 */     return cal;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 3216 */     return toString("yyyyMMddHHmmssSSS");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString(String format) {
/* 3231 */     return toString(format, TimeZone.getDefault());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString(String format, TimeZone tz) {
/* 3246 */     if (format == null)
/*      */     {
/* 3248 */       throw new MCException(Core_Msg_FW_A.FCBFC0018, new Object[0]);
/*      */     }
/* 3250 */     if (tz == null)
/*      */     {
/* 3252 */       throw new MCException(Core_Msg_FW_A.FCBFC0019, new Object[0]);
/*      */     }
/*      */     
/* 3255 */     SimpleDateFormat f = new SimpleDateFormat(format);
/* 3256 */     f.setTimeZone(tz);
/* 3257 */     f.setLenient(false);
/* 3258 */     return f.format(this);
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\lang\MCTimestampLTZ.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */