/*      */ package mcframe.commonCore.lang;
/*      */ 
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.math.MathContext;
/*      */ import java.math.RoundingMode;
/*      */ import java.text.DecimalFormat;
/*      */ import java.text.DecimalFormatSymbols;
/*      */ import java.text.ParsePosition;
/*      */ import java.util.Arrays;
/*      */ import java.util.Locale;
/*      */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*      */ import mcframe.commonCore.notice.MCException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class MCNumber
/*      */   extends BigDecimal
/*      */ {
/*  197 */   public static final MCNumber ZERO = new MCNumber(BigDecimal.ZERO);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  204 */   public static final MCNumber ONE = new MCNumber(BigDecimal.ONE);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  211 */   public static final MCNumber TEN = new MCNumber(BigDecimal.TEN);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  225 */   public static final RoundingMode MODE_CEILING = RoundingMode.CEILING;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  234 */   public static final RoundingMode MODE_FLOOR = RoundingMode.FLOOR;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  243 */   public static final RoundingMode MODE_DOWN = RoundingMode.DOWN;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  252 */   public static final RoundingMode MODE_UP = RoundingMode.UP;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  262 */   public static final RoundingMode MODE_HALF_DOWN = RoundingMode.HALF_DOWN;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  272 */   public static final RoundingMode MODE_HALF_UP = RoundingMode.HALF_UP;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  282 */   public static final RoundingMode MODE_HALF_EVEN = RoundingMode.HALF_EVEN;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  292 */   public static final RoundingMode MODE_UNNECESSARY = RoundingMode.UNNECESSARY;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static MCNumber valueOf(BigDecimal value) {
/*  310 */     if (value == null) {
/*  311 */       return null;
/*      */     }
/*  313 */     return new MCNumber(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static MCNumber valueOf(BigInteger value) {
/*  325 */     if (value == null) {
/*  326 */       return null;
/*      */     }
/*  328 */     return new MCNumber(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static MCNumber valueOf(String text) {
/*  341 */     if (text == null) {
/*  342 */       return null;
/*      */     }
/*      */     try {
/*  345 */       return new MCNumber(text);
/*  346 */     } catch (Exception ex) {
/*      */       
/*  348 */       throw new MCException(ex, Core_Msg_FW_A.FCBFC0003, new Object[] { text });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static MCNumber valueOf(String text, String format) {
/*  365 */     if (text == null || text.length() == 0) {
/*  366 */       return null;
/*      */     }
/*  368 */     if (format == null) {
/*  369 */       throw new MCException(Core_Msg_FW_A.FCBFC0017, new Object[] { text });
/*      */     }
/*  371 */     DecimalFormat f = new DecimalFormat();
/*  372 */     f.setParseBigDecimal(true);
/*  373 */     f.applyPattern(format);
/*  374 */     ParsePosition pp = new ParsePosition(0);
/*  375 */     MCNumber num = valueOf((BigDecimal)f.parseObject(text, pp));
/*  376 */     if (text.length() != pp.getIndex()) {
/*  377 */       throw new MCException(Core_Msg_FW_A.FCBFC0003, new Object[] { text });
/*      */     }
/*  379 */     return num;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static MCNumber valueOf(String text, DecimalFormat f) {
/*  393 */     if (text == null || text.length() == 0) {
/*  394 */       return null;
/*      */     }
/*  396 */     ParsePosition pp = new ParsePosition(0);
/*      */     
/*  398 */     boolean ibd = f.isParseBigDecimal();
/*  399 */     f.setParseBigDecimal(true);
/*      */     
/*  401 */     MCNumber num = null;
/*      */     try {
/*  403 */       num = valueOf((BigDecimal)f.parseObject(text, pp));
/*      */     } finally {
/*      */       
/*  406 */       f.setParseBigDecimal(ibd);
/*      */     } 
/*      */     
/*  409 */     if (text.length() != pp.getIndex()) {
/*  410 */       throw new MCException(Core_Msg_FW_A.FCBFC0003, new Object[] { text });
/*      */     }
/*  412 */     return num;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isNumeric(String text, DecimalFormat f) {
/*  425 */     ParsePosition pp = new ParsePosition(0);
/*  426 */     valueOf((BigDecimal)f.parseObject(text, pp));
/*  427 */     if (text.length() != pp.getIndex()) {
/*  428 */       return false;
/*      */     }
/*  430 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static MCNumber valueOf(double value) {
/*  448 */     return new MCNumber(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static MCNumber valueOf(float value) {
/*  462 */     return new MCNumber(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static MCNumber valueOf(long value) {
/*  476 */     return new MCNumber(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static MCNumber valueOf(int value) {
/*  490 */     return new MCNumber(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static MCNumber valueOf(long unscaledValue, int scale) {
/*  503 */     return new MCNumber(BigDecimal.valueOf(unscaledValue, scale));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static MCNumber avg(MCNumber... nums) {
/*  522 */     int cnt = 0;
/*  523 */     MCNumber ret = null;
/*  524 */     if (nums != null) {
/*  525 */       byte b; int i; MCNumber[] arrayOfMCNumber; for (i = (arrayOfMCNumber = nums).length, b = 0; b < i; ) { MCNumber num = arrayOfMCNumber[b];
/*  526 */         if (num != null) {
/*  527 */           if (ret == null) {
/*  528 */             ret = ZERO;
/*      */           }
/*  530 */           ret = ret.add(num);
/*  531 */           cnt++;
/*      */         }  b++; }
/*      */     
/*      */     } 
/*  535 */     if (ret != null) {
/*  536 */       ret = ret.divide(cnt);
/*      */     }
/*  538 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static MCNumber max(MCNumber... nums) {
/*  552 */     MCNumber ret = null;
/*  553 */     if (nums != null) {
/*  554 */       byte b; int i; MCNumber[] arrayOfMCNumber; for (i = (arrayOfMCNumber = nums).length, b = 0; b < i; ) { MCNumber num = arrayOfMCNumber[b];
/*  555 */         if (num != null)
/*  556 */           ret = num.gt(ret) ? num : ret; 
/*      */         b++; }
/*      */     
/*      */     } 
/*  560 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static MCNumber min(MCNumber... nums) {
/*  574 */     MCNumber ret = null;
/*  575 */     if (nums != null) {
/*  576 */       byte b; int i; MCNumber[] arrayOfMCNumber; for (i = (arrayOfMCNumber = nums).length, b = 0; b < i; ) { MCNumber num = arrayOfMCNumber[b];
/*  577 */         if (num != null)
/*  578 */           ret = num.lt(ret) ? num : ret; 
/*      */         b++; }
/*      */     
/*      */     } 
/*  582 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static MCNumber sum(MCNumber... nums) {
/*  596 */     MCNumber ret = null;
/*  597 */     if (nums != null) {
/*  598 */       byte b; int i; MCNumber[] arrayOfMCNumber; for (i = (arrayOfMCNumber = nums).length, b = 0; b < i; ) { MCNumber num = arrayOfMCNumber[b];
/*  599 */         if (num != null) {
/*  600 */           if (ret == null) {
/*  601 */             ret = ZERO;
/*      */           }
/*  603 */           ret = ret.add(num);
/*      */         }  b++; }
/*      */     
/*      */     } 
/*  607 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final MathContext createMathContext(int setPrecision) {
/*  628 */     return createMathContext(setPrecision, MODE_HALF_UP);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final MathContext createMathContext(int setPrecision, RoundingMode setRoundingMode) {
/*  643 */     if (setPrecision < 0)
/*      */     {
/*  645 */       throw new MCException(Core_Msg_FW_A.FCBFC0004, new Object[0]);
/*      */     }
/*  647 */     if (setRoundingMode == null)
/*      */     {
/*  649 */       throw new MCException(Core_Msg_FW_A.FCBFC0008, new Object[] { setRoundingMode });
/*      */     }
/*  651 */     return new MathContext(setPrecision, setRoundingMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber(int value) {
/*  666 */     super(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber(long value) {
/*  677 */     super(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber(float value) {
/*  695 */     super(Float.toString(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber(double value) {
/*  713 */     super(Double.toString(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MCNumber(BigDecimal value) {
/*  729 */     super(value.unscaledValue(), value.scale());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MCNumber(BigInteger value) {
/*  744 */     super(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MCNumber(String text) {
/*  760 */     super(text);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString(DecimalFormat format) {
/*  779 */     if (format == null)
/*      */     {
/*  781 */       throw new MCException(Core_Msg_FW_A.FCBFC0001, new Object[0]);
/*      */     }
/*      */     
/*  784 */     return format.format(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString(String format) {
/*  798 */     if (format == null)
/*      */     {
/*  800 */       throw new MCException(Core_Msg_FW_A.FCBFC0001, new Object[0]);
/*      */     }
/*      */     
/*      */     try {
/*  804 */       return toString(new DecimalFormat(format));
/*  805 */     } catch (Exception ex) {
/*      */       
/*  807 */       throw new MCException(ex, Core_Msg_FW_A.FCBFC0002, new Object[] { format });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString(String format, DecimalFormatSymbols fs) {
/*  822 */     if (format == null)
/*      */     {
/*  824 */       throw new MCException(Core_Msg_FW_A.FCBFC0001, new Object[0]);
/*      */     }
/*      */     
/*      */     try {
/*  828 */       if (fs != null) {
/*  829 */         return toString(new DecimalFormat(format, fs));
/*      */       }
/*      */       
/*  832 */       return toString(new DecimalFormat(format));
/*      */     }
/*  834 */     catch (Exception ex) {
/*      */       
/*  836 */       throw new MCException(ex, Core_Msg_FW_A.FCBFC0002, new Object[] { format });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toSimpleString() {
/*  859 */     int scale = scale();
/*  860 */     scale = (scale > 0) ? scale : 1;
/*  861 */     char[] format = new char[3 + scale];
/*  862 */     format[0] = '#';
/*  863 */     format[1] = '0';
/*  864 */     format[2] = '.';
/*  865 */     Arrays.fill(format, 3, format.length, '#');
/*  866 */     return toString(String.valueOf(format), 
/*  867 */         DecimalFormatSymbols.getInstance(Locale.ROOT));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public byte byteValueExact() {
/*      */     try {
/*  874 */       return super.byteValueExact();
/*  875 */     } catch (ArithmeticException ex) {
/*  876 */       throw createStrictConversionException(ex, "byte");
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public short shortValueExact() {
/*      */     try {
/*  883 */       return super.shortValueExact();
/*  884 */     } catch (ArithmeticException ex) {
/*  885 */       throw createStrictConversionException(ex, "short");
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public int intValueExact() {
/*      */     try {
/*  892 */       return super.intValueExact();
/*  893 */     } catch (ArithmeticException ex) {
/*  894 */       throw createStrictConversionException(ex, "int");
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public long longValueExact() {
/*      */     try {
/*  901 */       return super.longValueExact();
/*  902 */     } catch (ArithmeticException ex) {
/*  903 */       throw createStrictConversionException(ex, "long");
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public BigInteger toBigIntegerExact() {
/*      */     try {
/*  910 */       return super.toBigIntegerExact();
/*  911 */     } catch (ArithmeticException ex) {
/*  912 */       throw createStrictConversionException(ex, "BigInteger");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MCException createStrictConversionException(Throwable e, String type) {
/*  931 */     return new MCException(e, Core_Msg_FW_A.FCBFC0029, new Object[] { toSimpleString(), type });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object x) {
/*  981 */     if (!(x instanceof MCNumber)) {
/*  982 */       return false;
/*      */     }
/*  984 */     return super.equals(x);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean eq(BigDecimal val) {
/*  998 */     if (val == null) {
/*  999 */       return false;
/*      */     }
/* 1001 */     return (compareTo(val) == 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean eq(BigInteger val) {
/* 1013 */     MCNumber numval = valueOf(val);
/* 1014 */     return eq(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean eq(int val) {
/* 1026 */     MCNumber numval = valueOf(val);
/* 1027 */     return eq(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean eq(long val) {
/* 1039 */     MCNumber numval = valueOf(val);
/* 1040 */     return eq(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean eq(float val) {
/* 1052 */     MCNumber numval = valueOf(val);
/* 1053 */     return eq(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean eq(double val) {
/* 1065 */     MCNumber numval = valueOf(val);
/* 1066 */     return eq(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean neq(BigDecimal val) {
/* 1081 */     if (val == null) {
/* 1082 */       return false;
/*      */     }
/* 1084 */     return (compareTo(val) != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean neq(BigInteger val) {
/* 1096 */     MCNumber numval = valueOf(val);
/* 1097 */     return neq(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean neq(int val) {
/* 1109 */     MCNumber numval = valueOf(val);
/* 1110 */     return neq(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean neq(long val) {
/* 1122 */     MCNumber numval = valueOf(val);
/* 1123 */     return neq(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean neq(float val) {
/* 1135 */     MCNumber numval = valueOf(val);
/* 1136 */     return neq(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean neq(double val) {
/* 1148 */     MCNumber numval = valueOf(val);
/* 1149 */     return neq(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gt(BigDecimal val) {
/* 1163 */     if (val == null) {
/* 1164 */       return true;
/*      */     }
/* 1166 */     return (compareTo(val) > 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gt(BigInteger val) {
/* 1179 */     MCNumber numval = valueOf(val);
/* 1180 */     return gt(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gt(int val) {
/* 1192 */     MCNumber numval = valueOf(val);
/* 1193 */     return gt(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gt(long val) {
/* 1205 */     MCNumber numval = valueOf(val);
/* 1206 */     return gt(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gt(float val) {
/* 1218 */     MCNumber numval = valueOf(val);
/* 1219 */     return gt(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gt(double val) {
/* 1231 */     MCNumber numval = valueOf(val);
/* 1232 */     return gt(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gte(BigDecimal val) {
/* 1246 */     if (val == null) {
/* 1247 */       return true;
/*      */     }
/* 1249 */     return (compareTo(val) >= 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gte(BigInteger val) {
/* 1262 */     MCNumber numval = valueOf(val);
/* 1263 */     return gte(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gte(int val) {
/* 1275 */     MCNumber numval = valueOf(val);
/* 1276 */     return gte(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gte(long val) {
/* 1288 */     MCNumber numval = valueOf(val);
/* 1289 */     return gte(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gte(float val) {
/* 1301 */     MCNumber numval = valueOf(val);
/* 1302 */     return gte(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gte(double val) {
/* 1314 */     MCNumber numval = valueOf(val);
/* 1315 */     return gte(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lt(BigDecimal val) {
/* 1329 */     if (val == null) {
/* 1330 */       return true;
/*      */     }
/* 1332 */     return (compareTo(val) < 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lt(BigInteger val) {
/* 1345 */     MCNumber numval = valueOf(val);
/* 1346 */     return lt(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lt(int val) {
/* 1358 */     MCNumber numval = valueOf(val);
/* 1359 */     return lt(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lt(long val) {
/* 1371 */     MCNumber numval = valueOf(val);
/* 1372 */     return lt(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lt(float val) {
/* 1384 */     MCNumber numval = valueOf(val);
/* 1385 */     return lt(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lt(double val) {
/* 1397 */     MCNumber numval = valueOf(val);
/* 1398 */     return lt(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lte(BigDecimal val) {
/* 1412 */     if (val == null) {
/* 1413 */       return true;
/*      */     }
/* 1415 */     return (compareTo(val) <= 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lte(BigInteger val) {
/* 1428 */     MCNumber numval = valueOf(val);
/* 1429 */     return lte(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lte(int val) {
/* 1441 */     MCNumber numval = valueOf(val);
/* 1442 */     return lte(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lte(long val) {
/* 1454 */     MCNumber numval = valueOf(val);
/* 1455 */     return lte(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lte(float val) {
/* 1467 */     MCNumber numval = valueOf(val);
/* 1468 */     return lte(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lte(double val) {
/* 1480 */     MCNumber numval = valueOf(val);
/* 1481 */     return lte(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isZero() {
/* 1493 */     return (signum() == 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isPositive() {
/* 1504 */     return (signum() == 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isNegative() {
/* 1515 */     return (signum() == -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber add(BigInteger augend) {
/* 1536 */     MCNumber numval = valueOf(augend);
/* 1537 */     return add(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber add(BigInteger augend, MathContext mc) {
/* 1553 */     MCNumber numval = valueOf(augend);
/* 1554 */     return add(numval, mc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber add(int augend) {
/* 1566 */     MCNumber numval = valueOf(augend);
/* 1567 */     return add(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber add(int augend, MathContext mc) {
/* 1583 */     MCNumber numval = valueOf(augend);
/* 1584 */     return add(numval, mc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber add(long augend) {
/* 1596 */     MCNumber numval = valueOf(augend);
/* 1597 */     return add(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber add(long augend, MathContext mc) {
/* 1613 */     MCNumber numval = valueOf(augend);
/* 1614 */     return add(numval, mc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber add(float augend) {
/* 1626 */     MCNumber numval = valueOf(augend);
/* 1627 */     return add(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber add(float augend, MathContext mc) {
/* 1643 */     MCNumber numval = valueOf(augend);
/* 1644 */     return add(numval, mc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber add(double augend) {
/* 1656 */     MCNumber numval = valueOf(augend);
/* 1657 */     return add(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber add(double augend, MathContext mc) {
/* 1673 */     MCNumber numval = valueOf(augend);
/* 1674 */     return add(numval, mc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber subtract(BigInteger subtrahend) {
/* 1691 */     MCNumber numval = valueOf(subtrahend);
/* 1692 */     return subtract(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber subtract(BigInteger subtrahend, MathContext mc) {
/* 1708 */     MCNumber numval = valueOf(subtrahend);
/* 1709 */     return subtract(numval, mc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber subtract(int subtrahend) {
/* 1721 */     MCNumber numval = valueOf(subtrahend);
/* 1722 */     return subtract(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber subtract(int subtrahend, MathContext mc) {
/* 1738 */     MCNumber numval = valueOf(subtrahend);
/* 1739 */     return subtract(numval, mc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber subtract(long subtrahend) {
/* 1751 */     MCNumber numval = valueOf(subtrahend);
/* 1752 */     return subtract(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber subtract(long subtrahend, MathContext mc) {
/* 1768 */     MCNumber numval = valueOf(subtrahend);
/* 1769 */     return subtract(numval, mc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber subtract(float subtrahend) {
/* 1781 */     MCNumber numval = valueOf(subtrahend);
/* 1782 */     return subtract(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber subtract(float subtrahend, MathContext mc) {
/* 1798 */     MCNumber numval = valueOf(subtrahend);
/* 1799 */     return subtract(numval, mc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber subtract(double subtrahend) {
/* 1811 */     MCNumber numval = valueOf(subtrahend);
/* 1812 */     return subtract(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber subtract(double subtrahend, MathContext mc) {
/* 1828 */     MCNumber numval = valueOf(subtrahend);
/* 1829 */     return subtract(numval, mc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber multiply(BigDecimal multiplicand, RoundingMode roundingMode) {
/* 1851 */     return multiply(multiplicand, scale(), roundingMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber multiply(BigDecimal multiplicand, int scale, RoundingMode roundingMode) {
/* 1869 */     MCNumber numval = valueOf(multiplicand);
/* 1870 */     numval = multiply(numval);
/* 1871 */     return numval.setScale(scale, roundingMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber multiply(BigInteger multiplicand) {
/* 1883 */     MCNumber numval = valueOf(multiplicand);
/* 1884 */     return multiply(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber multiply(BigInteger multiplicand, RoundingMode roundingMode) {
/* 1901 */     MCNumber numval = valueOf(multiplicand);
/* 1902 */     return multiply(numval, roundingMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber multiply(BigInteger multiplicand, int scale, RoundingMode roundingMode) {
/* 1920 */     MCNumber numval = valueOf(multiplicand);
/* 1921 */     return multiply(numval, scale, roundingMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber multiply(BigInteger multiplicand, MathContext mc) {
/* 1937 */     MCNumber numval = valueOf(multiplicand);
/* 1938 */     return multiply(numval, mc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber multiply(int multiplicand) {
/* 1950 */     MCNumber numval = valueOf(multiplicand);
/* 1951 */     return multiply(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber multiply(int multiplicand, RoundingMode roundingMode) {
/* 1968 */     MCNumber numval = valueOf(multiplicand);
/* 1969 */     return multiply(numval, roundingMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber multiply(int multiplicand, int scale, RoundingMode roundingMode) {
/* 1987 */     MCNumber numval = valueOf(multiplicand);
/* 1988 */     return multiply(numval, scale, roundingMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber multiply(int multiplicand, MathContext mc) {
/* 2004 */     MCNumber numval = valueOf(multiplicand);
/* 2005 */     return multiply(numval, mc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber multiply(long multiplicand) {
/* 2017 */     MCNumber numval = valueOf(multiplicand);
/* 2018 */     return multiply(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber multiply(long multiplicand, RoundingMode roundingMode) {
/* 2035 */     MCNumber numval = valueOf(multiplicand);
/* 2036 */     return multiply(numval, roundingMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber multiply(long multiplicand, int scale, RoundingMode roundingMode) {
/* 2054 */     MCNumber numval = valueOf(multiplicand);
/* 2055 */     return multiply(numval, scale, roundingMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber multiply(long multiplicand, MathContext mc) {
/* 2071 */     MCNumber numval = valueOf(multiplicand);
/* 2072 */     return multiply(numval, mc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber multiply(float multiplicand) {
/* 2084 */     MCNumber numval = valueOf(multiplicand);
/* 2085 */     return multiply(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber multiply(float multiplicand, RoundingMode roundingMode) {
/* 2102 */     MCNumber numval = valueOf(multiplicand);
/* 2103 */     return multiply(numval, roundingMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber multiply(float multiplicand, int scale, RoundingMode roundingMode) {
/* 2121 */     MCNumber numval = valueOf(multiplicand);
/* 2122 */     return multiply(numval, scale, roundingMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber multiply(float multiplicand, MathContext mc) {
/* 2138 */     MCNumber numval = valueOf(multiplicand);
/* 2139 */     return multiply(numval, mc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber multiply(double multiplicand) {
/* 2151 */     MCNumber numval = valueOf(multiplicand);
/* 2152 */     return multiply(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber multiply(double multiplicand, RoundingMode roundingMode) {
/* 2169 */     MCNumber numval = valueOf(multiplicand);
/* 2170 */     return multiply(numval, roundingMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber multiply(double multiplicand, int scale, RoundingMode roundingMode) {
/* 2188 */     MCNumber numval = valueOf(multiplicand);
/* 2189 */     return multiply(numval, scale, roundingMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber multiply(double multiplicand, MathContext mc) {
/* 2205 */     MCNumber numval = valueOf(multiplicand);
/* 2206 */     return multiply(numval, mc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divide(BigInteger divisor) {
/* 2225 */     MCNumber numval = valueOf(divisor);
/* 2226 */     return divide(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divide(BigInteger divisor, int roundingMode) {
/* 2245 */     MCNumber numval = valueOf(divisor);
/* 2246 */     return divide(numval, roundingMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divide(BigInteger divisor, int scale, int roundingMode) {
/* 2266 */     MCNumber numval = valueOf(divisor);
/* 2267 */     return divide(numval, scale, roundingMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divide(BigInteger divisor, RoundingMode roundingMode) {
/* 2285 */     MCNumber numval = valueOf(divisor);
/* 2286 */     return divide(numval, roundingMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divide(BigInteger divisor, int scale, RoundingMode roundingMode) {
/* 2305 */     MCNumber numval = valueOf(divisor);
/* 2306 */     return divide(numval, scale, roundingMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divide(BigInteger divisor, MathContext mc) {
/* 2327 */     MCNumber numval = valueOf(divisor);
/* 2328 */     return divide(numval, mc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber[] divideAndRemainder(BigInteger divisor) {
/* 2344 */     MCNumber numval = valueOf(divisor);
/* 2345 */     return divideAndRemainder(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber[] divideAndRemainder(BigInteger divisor, MathContext mc) {
/* 2368 */     MCNumber numval = valueOf(divisor);
/* 2369 */     return divideAndRemainder(numval, mc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divideToIntegralValue(BigInteger divisor) {
/* 2382 */     MCNumber numval = valueOf(divisor);
/* 2383 */     return divideToIntegralValue(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divideToIntegralValue(BigInteger divisor, MathContext mc) {
/* 2402 */     MCNumber numval = valueOf(divisor);
/* 2403 */     return divideToIntegralValue(numval, mc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divide(int divisor) {
/* 2417 */     MCNumber numval = valueOf(divisor);
/* 2418 */     return divide(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divide(int divisor, int roundingMode) {
/* 2437 */     MCNumber numval = valueOf(divisor);
/* 2438 */     return divide(numval, roundingMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divide(int divisor, int scale, int roundingMode) {
/* 2458 */     MCNumber numval = valueOf(divisor);
/* 2459 */     return divide(numval, roundingMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divide(int divisor, RoundingMode roundingMode) {
/* 2477 */     MCNumber numval = valueOf(divisor);
/* 2478 */     return divide(numval, roundingMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divide(int divisor, int scale, RoundingMode roundingMode) {
/* 2497 */     MCNumber numval = valueOf(divisor);
/* 2498 */     return divide(numval, scale, roundingMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divide(int divisor, MathContext mc) {
/* 2519 */     MCNumber numval = valueOf(divisor);
/* 2520 */     return divide(numval, mc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber[] divideAndRemainder(int divisor) {
/* 2536 */     MCNumber numval = valueOf(divisor);
/* 2537 */     return divideAndRemainder(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber[] divideAndRemainder(int divisor, MathContext mc) {
/* 2560 */     MCNumber numval = valueOf(divisor);
/* 2561 */     return divideAndRemainder(numval, mc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divideToIntegralValue(int divisor) {
/* 2574 */     MCNumber numval = valueOf(divisor);
/* 2575 */     return divideToIntegralValue(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divideToIntegralValue(int divisor, MathContext mc) {
/* 2594 */     MCNumber numval = valueOf(divisor);
/* 2595 */     return divideToIntegralValue(numval, mc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divide(long divisor) {
/* 2609 */     MCNumber numval = valueOf(divisor);
/* 2610 */     return divide(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divide(long divisor, int roundingMode) {
/* 2629 */     MCNumber numval = valueOf(divisor);
/* 2630 */     return divide(numval, roundingMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divide(long divisor, int scale, int roundingMode) {
/* 2650 */     MCNumber numval = valueOf(divisor);
/* 2651 */     return divide(numval, roundingMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divide(long divisor, RoundingMode roundingMode) {
/* 2669 */     MCNumber numval = valueOf(divisor);
/* 2670 */     return divide(numval, roundingMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divide(long divisor, int scale, RoundingMode roundingMode) {
/* 2689 */     MCNumber numval = valueOf(divisor);
/* 2690 */     return divide(numval, scale, roundingMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divide(long divisor, MathContext mc) {
/* 2711 */     MCNumber numval = valueOf(divisor);
/* 2712 */     return divide(numval, mc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber[] divideAndRemainder(long divisor) {
/* 2728 */     MCNumber numval = valueOf(divisor);
/* 2729 */     return divideAndRemainder(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber[] divideAndRemainder(long divisor, MathContext mc) {
/* 2752 */     MCNumber numval = valueOf(divisor);
/* 2753 */     return divideAndRemainder(numval, mc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divideToIntegralValue(long divisor) {
/* 2766 */     MCNumber numval = valueOf(divisor);
/* 2767 */     return divideToIntegralValue(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divideToIntegralValue(long divisor, MathContext mc) {
/* 2786 */     MCNumber numval = valueOf(divisor);
/* 2787 */     return divideToIntegralValue(numval, mc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divide(float divisor) {
/* 2801 */     MCNumber numval = valueOf(divisor);
/* 2802 */     return divide(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divide(float divisor, int roundingMode) {
/* 2821 */     MCNumber numval = valueOf(divisor);
/* 2822 */     return divide(numval, roundingMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divide(float divisor, int scale, int roundingMode) {
/* 2842 */     MCNumber numval = valueOf(divisor);
/* 2843 */     return divide(numval, roundingMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divide(float divisor, RoundingMode roundingMode) {
/* 2861 */     MCNumber numval = valueOf(divisor);
/* 2862 */     return divide(numval, roundingMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divide(float divisor, int scale, RoundingMode roundingMode) {
/* 2881 */     MCNumber numval = valueOf(divisor);
/* 2882 */     return divide(numval, scale, roundingMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divide(float divisor, MathContext mc) {
/* 2903 */     MCNumber numval = valueOf(divisor);
/* 2904 */     return divide(numval, mc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber[] divideAndRemainder(float divisor) {
/* 2920 */     MCNumber numval = valueOf(divisor);
/* 2921 */     return divideAndRemainder(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber[] divideAndRemainder(float divisor, MathContext mc) {
/* 2944 */     MCNumber numval = valueOf(divisor);
/* 2945 */     return divideAndRemainder(numval, mc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divideToIntegralValue(float divisor) {
/* 2958 */     MCNumber numval = valueOf(divisor);
/* 2959 */     return divideToIntegralValue(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divideToIntegralValue(float divisor, MathContext mc) {
/* 2978 */     MCNumber numval = valueOf(divisor);
/* 2979 */     return divideToIntegralValue(numval, mc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divide(double divisor) {
/* 2993 */     MCNumber numval = valueOf(divisor);
/* 2994 */     return divide(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divide(double divisor, int roundingMode) {
/* 3013 */     MCNumber numval = valueOf(divisor);
/* 3014 */     return divide(numval, roundingMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divide(double divisor, int scale, int roundingMode) {
/* 3034 */     MCNumber numval = valueOf(divisor);
/* 3035 */     return divide(numval, roundingMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divide(double divisor, RoundingMode roundingMode) {
/* 3053 */     MCNumber numval = valueOf(divisor);
/* 3054 */     return divide(numval, roundingMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divide(double divisor, int scale, RoundingMode roundingMode) {
/* 3073 */     MCNumber numval = valueOf(divisor);
/* 3074 */     return divide(numval, scale, roundingMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divide(double divisor, MathContext mc) {
/* 3095 */     MCNumber numval = valueOf(divisor);
/* 3096 */     return divide(numval, mc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber[] divideAndRemainder(double divisor) {
/* 3112 */     MCNumber numval = valueOf(divisor);
/* 3113 */     return divideAndRemainder(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber[] divideAndRemainder(double divisor, MathContext mc) {
/* 3136 */     MCNumber numval = valueOf(divisor);
/* 3137 */     return divideAndRemainder(numval, mc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divideToIntegralValue(double divisor) {
/* 3150 */     MCNumber numval = valueOf(divisor);
/* 3151 */     return divideToIntegralValue(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divideToIntegralValue(double divisor, MathContext mc) {
/* 3170 */     MCNumber numval = valueOf(divisor);
/* 3171 */     return divideToIntegralValue(numval, mc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber remainder(BigInteger divisor) {
/* 3189 */     MCNumber numval = valueOf(divisor);
/* 3190 */     return remainder(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber remainder(BigInteger divisor, MathContext mc) {
/* 3210 */     MCNumber numval = valueOf(divisor);
/* 3211 */     return remainder(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber remainder(int divisor) {
/* 3224 */     MCNumber numval = valueOf(divisor);
/* 3225 */     return remainder(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber remainder(int divisor, MathContext mc) {
/* 3245 */     MCNumber numval = valueOf(divisor);
/* 3246 */     return remainder(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber remainder(long divisor) {
/* 3259 */     MCNumber numval = valueOf(divisor);
/* 3260 */     return remainder(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber remainder(long divisor, MathContext mc) {
/* 3280 */     MCNumber numval = valueOf(divisor);
/* 3281 */     return remainder(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber remainder(float divisor) {
/* 3294 */     MCNumber numval = valueOf(divisor);
/* 3295 */     return remainder(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber remainder(float divisor, MathContext mc) {
/* 3315 */     MCNumber numval = valueOf(divisor);
/* 3316 */     return remainder(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber remainder(double divisor) {
/* 3329 */     MCNumber numval = valueOf(divisor);
/* 3330 */     return remainder(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber remainder(double divisor, MathContext mc) {
/* 3350 */     MCNumber numval = valueOf(divisor);
/* 3351 */     return remainder(numval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber abs() {
/* 3409 */     return new MCNumber(super.abs());
/*      */   }
/*      */   
/*      */   public MCNumber abs(MathContext mc) {
/*      */     try {
/* 3414 */       return (mc != null) ? 
/* 3415 */         new MCNumber(super.abs(mc)) : 
/* 3416 */         abs();
/* 3417 */     } catch (ArithmeticException ex) {
/*      */       
/* 3419 */       throw new MCException(ex, Core_Msg_FW_A.FCBFC0005, new Object[0]);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber add(BigDecimal augend) {
/* 3433 */     if (augend == null) {
/* 3434 */       return null;
/*      */     }
/* 3436 */     return new MCNumber(super.add(augend));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber add(BigDecimal augend, MathContext mc) {
/* 3453 */     if (augend == null) {
/* 3454 */       return null;
/*      */     }
/*      */     try {
/* 3457 */       return (mc != null) ? 
/* 3458 */         new MCNumber(super.add(augend, mc)) : 
/* 3459 */         add(augend);
/* 3460 */     } catch (ArithmeticException ex) {
/*      */       
/* 3462 */       throw new MCException(ex, Core_Msg_FW_A.FCBFC0005, new Object[0]);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divide(BigDecimal divisor) {
/* 3478 */     if (divisor == null) {
/* 3479 */       return null;
/*      */     }
/*      */     try {
/* 3482 */       return new MCNumber(super.divide(divisor));
/* 3483 */     } catch (ArithmeticException ex) {
/* 3484 */       if (divisor.signum() == 0)
/*      */       {
/* 3486 */         throw new MCException(ex, Core_Msg_FW_A.FCBFC0007, new Object[0]);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3492 */       throw new MCException(ex, Core_Msg_FW_A.FCBFC0006, new Object[0]);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divide(BigDecimal divisor, int roundingMode) {
/* 3514 */     return divide(divisor, scale(), roundingMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divide(BigDecimal divisor, int scale, int roundingMode) {
/* 3535 */     if (divisor == null) {
/* 3536 */       return null;
/*      */     }
/*      */     try {
/* 3539 */       return new MCNumber(super.divide(divisor, scale, roundingMode));
/* 3540 */     } catch (ArithmeticException ex) {
/* 3541 */       if (divisor.signum() == 0)
/*      */       {
/* 3543 */         throw new MCException(ex, Core_Msg_FW_A.FCBFC0007, new Object[0]);
/*      */       }
/*      */       
/* 3546 */       throw new MCException(ex, Core_Msg_FW_A.FCBFC0005, new Object[0]);
/*      */     }
/* 3548 */     catch (IllegalArgumentException ex) {
/*      */       
/* 3550 */       throw new MCException(ex, Core_Msg_FW_A.FCBFC0008, new Object[] { String.valueOf(roundingMode) });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divide(BigDecimal divisor, RoundingMode roundingMode) {
/* 3570 */     return divide(divisor, scale(), roundingMode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divide(BigDecimal divisor, int scale, RoundingMode roundingMode) {
/* 3590 */     if (divisor == null) {
/* 3591 */       return null;
/*      */     }
/*      */     try {
/* 3594 */       return (roundingMode != null) ? 
/* 3595 */         new MCNumber(super.divide(divisor, scale, roundingMode)) : 
/* 3596 */         setScale(scale);
/* 3597 */     } catch (ArithmeticException ex) {
/* 3598 */       if (divisor.signum() == 0)
/*      */       {
/* 3600 */         throw new MCException(ex, Core_Msg_FW_A.FCBFC0007, new Object[0]);
/*      */       }
/*      */       
/* 3603 */       throw new MCException(ex, Core_Msg_FW_A.FCBFC0005, new Object[0]);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divide(BigDecimal divisor, MathContext mc) {
/* 3627 */     if (divisor == null) {
/* 3628 */       return null;
/*      */     }
/*      */     try {
/* 3631 */       return (mc != null) ? 
/* 3632 */         new MCNumber(super.divide(divisor, mc)) : 
/* 3633 */         divide(divisor);
/* 3634 */     } catch (ArithmeticException ex) {
/* 3635 */       if (divisor.signum() == 0)
/*      */       {
/* 3637 */         throw new MCException(ex, Core_Msg_FW_A.FCBFC0007, new Object[0]);
/*      */       }
/*      */       
/* 3640 */       throw new MCException(ex, Core_Msg_FW_A.FCBFC0005, new Object[0]);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber[] divideAndRemainder(BigDecimal divisor) {
/* 3659 */     MCNumber[] result = new MCNumber[2];
/* 3660 */     result[0] = divideToIntegralValue(divisor);
/* 3661 */     result[1] = subtract(result[0].multiply(divisor));
/* 3662 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber[] divideAndRemainder(BigDecimal divisor, MathContext mc) {
/* 3691 */     if (mc == null || mc.getPrecision() == 0) {
/* 3692 */       return divideAndRemainder(divisor);
/*      */     }
/*      */     
/* 3695 */     MCNumber[] result = new MCNumber[2];
/* 3696 */     result[0] = divideToIntegralValue(divisor, mc);
/* 3697 */     result[1] = subtract(result[0].multiply(divisor));
/* 3698 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divideToIntegralValue(BigDecimal divisor) {
/* 3712 */     if (divisor == null) {
/* 3713 */       return null;
/*      */     }
/*      */     try {
/* 3716 */       return new MCNumber(super.divideToIntegralValue(divisor));
/* 3717 */     } catch (ArithmeticException ex) {
/*      */       
/* 3719 */       throw new MCException(ex, Core_Msg_FW_A.FCBFC0007, new Object[0]);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber divideToIntegralValue(BigDecimal divisor, MathContext mc) {
/* 3745 */     if (divisor == null) {
/* 3746 */       return null;
/*      */     }
/*      */     try {
/* 3749 */       return (mc != null) ? 
/* 3750 */         new MCNumber(super.divideToIntegralValue(divisor, mc)) : 
/* 3751 */         divideToIntegralValue(divisor);
/* 3752 */     } catch (ArithmeticException ex) {
/* 3753 */       if (divisor.signum() == 0)
/*      */       {
/* 3755 */         throw new MCException(ex, Core_Msg_FW_A.FCBFC0007, new Object[0]);
/*      */       }
/*      */       
/* 3758 */       throw new MCException(ex, Core_Msg_FW_A.FCBFC0005, new Object[0]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public MCNumber max(BigDecimal val) {
/* 3764 */     if (val == null) {
/* 3765 */       return this;
/*      */     }
/* 3767 */     return new MCNumber(super.max(val));
/*      */   }
/*      */   
/*      */   public MCNumber min(BigDecimal val) {
/* 3771 */     if (val == null) {
/* 3772 */       return this;
/*      */     }
/* 3774 */     return new MCNumber(super.min(val));
/*      */   }
/*      */   
/*      */   public MCNumber movePointLeft(int n) {
/*      */     try {
/* 3779 */       return new MCNumber(super.movePointLeft(n));
/* 3780 */     } catch (ArithmeticException ex) {
/*      */       
/* 3782 */       throw new MCException(ex, Core_Msg_FW_A.FCBFC0009, new Object[] { String.valueOf(n) });
/*      */     } 
/*      */   }
/*      */   
/*      */   public MCNumber movePointRight(int n) {
/*      */     try {
/* 3788 */       return new MCNumber(super.movePointRight(n));
/* 3789 */     } catch (ArithmeticException ex) {
/*      */       
/* 3791 */       throw new MCException(ex, Core_Msg_FW_A.FCBFC0009, new Object[] { String.valueOf(n) });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber multiply(BigDecimal multiplicand) {
/* 3805 */     if (multiplicand == null) {
/* 3806 */       return null;
/*      */     }
/* 3808 */     return new MCNumber(super.multiply(multiplicand));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber multiply(BigDecimal multiplicand, MathContext mc) {
/* 3825 */     if (multiplicand == null) {
/* 3826 */       return null;
/*      */     }
/*      */     try {
/* 3829 */       return (mc != null) ? 
/* 3830 */         new MCNumber(super.multiply(multiplicand, mc)) : 
/* 3831 */         multiply(multiplicand);
/* 3832 */     } catch (ArithmeticException ex) {
/*      */       
/* 3834 */       throw new MCException(ex, Core_Msg_FW_A.FCBFC0005, new Object[0]);
/*      */     } 
/*      */   }
/*      */   
/*      */   public MCNumber negate() {
/* 3839 */     return new MCNumber(super.negate());
/*      */   }
/*      */   
/*      */   public MCNumber negate(MathContext mc) {
/*      */     try {
/* 3844 */       return (mc != null) ? 
/* 3845 */         new MCNumber(super.negate(mc)) : 
/* 3846 */         negate();
/* 3847 */     } catch (ArithmeticException ex) {
/*      */       
/* 3849 */       throw new MCException(ex, Core_Msg_FW_A.FCBFC0005, new Object[0]);
/*      */     } 
/*      */   }
/*      */   
/*      */   public MCNumber plus() {
/* 3854 */     return new MCNumber(super.plus());
/*      */   }
/*      */   
/*      */   public MCNumber plus(MathContext mc) {
/*      */     try {
/* 3859 */       return (mc != null) ? 
/* 3860 */         new MCNumber(super.plus(mc)) : 
/* 3861 */         plus();
/* 3862 */     } catch (ArithmeticException ex) {
/*      */       
/* 3864 */       throw new MCException(ex, Core_Msg_FW_A.FCBFC0005, new Object[0]);
/*      */     } 
/*      */   }
/*      */   
/*      */   public MCNumber pow(int n) {
/*      */     try {
/* 3870 */       return new MCNumber(super.pow(n));
/* 3871 */     } catch (ArithmeticException ex) {
/*      */       
/* 3873 */       throw new MCException(ex, Core_Msg_FW_A.FCBFC0022, new Object[] { String.valueOf(n) });
/*      */     } 
/*      */   }
/*      */   
/*      */   public MCNumber pow(int n, MathContext mc) {
/*      */     try {
/* 3879 */       return (mc == null) ? 
/* 3880 */         pow(n) : 
/* 3881 */         new MCNumber(super.pow(n, mc));
/* 3882 */     } catch (ArithmeticException ex) {
/*      */       
/* 3884 */       throw new MCException(ex, Core_Msg_FW_A.FCBFC0005, new Object[0]);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber remainder(BigDecimal divisor) {
/* 3899 */     if (divisor == null) {
/* 3900 */       return null;
/*      */     }
/*      */     try {
/* 3903 */       return new MCNumber(super.remainder(divisor));
/* 3904 */     } catch (ArithmeticException ex) {
/*      */       
/* 3906 */       throw new MCException(ex, Core_Msg_FW_A.FCBFC0007, new Object[0]);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber remainder(BigDecimal divisor, MathContext mc) {
/* 3928 */     if (divisor == null) {
/* 3929 */       return null;
/*      */     }
/*      */     try {
/* 3932 */       return (mc != null) ? 
/* 3933 */         new MCNumber(super.remainder(divisor, mc)) : 
/* 3934 */         remainder(divisor);
/* 3935 */     } catch (ArithmeticException ex) {
/* 3936 */       if (divisor.equals(ZERO))
/*      */       {
/* 3938 */         throw new MCException(ex, Core_Msg_FW_A.FCBFC0007, new Object[0]);
/*      */       }
/*      */       
/* 3941 */       throw new MCException(ex, Core_Msg_FW_A.FCBFC0005, new Object[0]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public MCNumber round(MathContext mc) {
/*      */     try {
/* 3948 */       return new MCNumber(super.round(mc));
/* 3949 */     } catch (ArithmeticException ex) {
/*      */       
/* 3951 */       throw new MCException(ex, Core_Msg_FW_A.FCBFC0005, new Object[0]);
/*      */     } 
/*      */   }
/*      */   
/*      */   public MCNumber scaleByPowerOfTen(int n) {
/* 3956 */     return new MCNumber(super.scaleByPowerOfTen(n));
/*      */   }
/*      */   
/*      */   public MCNumber setScale(int newScale) {
/*      */     try {
/* 3961 */       return new MCNumber(super.setScale(newScale));
/* 3962 */     } catch (ArithmeticException ex) {
/*      */       
/* 3964 */       throw new MCException(ex, Core_Msg_FW_A.FCBFC0005, new Object[0]);
/*      */     } 
/*      */   }
/*      */   
/*      */   public MCNumber setScale(int newScale, int roundingMode) {
/*      */     try {
/* 3970 */       return new MCNumber(super.setScale(newScale, roundingMode));
/* 3971 */     } catch (ArithmeticException ex) {
/*      */       
/* 3973 */       throw new MCException(ex, Core_Msg_FW_A.FCBFC0005, new Object[0]);
/* 3974 */     } catch (IllegalArgumentException ex) {
/*      */       
/* 3976 */       throw new MCException(ex, Core_Msg_FW_A.FCBFC0008, new Object[] { String.valueOf(roundingMode) });
/*      */     } 
/*      */   }
/*      */   
/*      */   public MCNumber setScale(int newScale, RoundingMode roundingMode) {
/*      */     try {
/* 3982 */       return (roundingMode != null) ? 
/* 3983 */         new MCNumber(super.setScale(newScale, roundingMode)) : 
/* 3984 */         setScale(newScale);
/* 3985 */     } catch (ArithmeticException ex) {
/*      */       
/* 3987 */       throw new MCException(ex, Core_Msg_FW_A.FCBFC0005, new Object[0]);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public MCNumber stripTrailingZeros() {
/* 3993 */     if (compareTo(ZERO) == 0) {
/* 3994 */       return ZERO;
/*      */     }
/* 3996 */     return new MCNumber(super.stripTrailingZeros());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber subtract(BigDecimal subtrahend) {
/* 4011 */     if (subtrahend == null) {
/* 4012 */       return null;
/*      */     }
/* 4014 */     return new MCNumber(super.subtract(subtrahend));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber subtract(BigDecimal subtrahend, MathContext mc) {
/* 4031 */     if (subtrahend == null) {
/* 4032 */       return null;
/*      */     }
/*      */     try {
/* 4035 */       return (mc != null) ? 
/* 4036 */         new MCNumber(super.subtract(subtrahend, mc)) : 
/* 4037 */         subtract(subtrahend);
/* 4038 */     } catch (ArithmeticException ex) {
/*      */       
/* 4040 */       throw new MCException(ex, Core_Msg_FW_A.FCBFC0005, new Object[0]);
/*      */     } 
/*      */   }
/*      */   
/*      */   public MCNumber ulp() {
/* 4045 */     return new MCNumber(super.ulp());
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\lang\MCNumber.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */