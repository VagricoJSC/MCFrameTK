/*     */ package mcframe.commonCore.lang;
/*     */ 
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MCTimestamp
/*     */   extends MCCalendarDate<MCTimestamp>
/*     */ {
/*     */   public static final String TO_STRING_FORMAT = "yyyyMMddHHmmssSSS";
/*     */   
/*     */   public static final MCTimestamp osnow() {
/*  32 */     return new MCTimestamp(System.currentTimeMillis());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final MCTimestamp ostoday() {
/*  45 */     return new MCTimestamp(roundToday(System.currentTimeMillis()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final MCTimestamp sysnow() {
/*  56 */     return new MCTimestamp(current());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final MCTimestamp systoday() {
/*  69 */     return new MCTimestamp(roundToday(current()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final MCTimestamp now() {
/*  80 */     return new MCTimestamp(currentCo());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final MCTimestamp today() {
/*  93 */     return new MCTimestamp(roundToday(currentCo()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCTimestamp valueOf(MCDate date) {
/* 105 */     return (date != null) ? new MCTimestamp(date._time) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCTimestamp valueOf(Date date) {
/* 117 */     return (date != null) ? new MCTimestamp(date.getTime()) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCTimestamp valueOf(String text, String format) {
/* 137 */     MCDateFormat f = MCDateFormat.create(format);
/* 138 */     return valueOf(text, f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCTimestamp valueOf(String text, MCDateFormat format) {
/* 157 */     Date date = stringToDate(format, text);
/* 158 */     return valueOf(date);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCTimestamp valueOf(int... val) {
/* 179 */     return valueOf(YEAR, val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCTimestamp valueOf(MCDateFieldType field, int... val) {
/* 202 */     int fieldlen = 7;
/* 203 */     long time = longValueOf(field, fieldlen, val);
/* 204 */     return (time != Long.MIN_VALUE) ? new MCTimestamp(time) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCTimestamp() {
/* 223 */     super(currentCo());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCTimestamp(long time) {
/* 234 */     super(time);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final long inittime(long time) {
/* 246 */     return time;
/*     */   }
/*     */   
/*     */   final MCTimestamp parse(String text, String format) {
/* 250 */     return valueOf(text, format);
/*     */   }
/*     */   
/*     */   final MCTimestamp parse(long time) {
/* 254 */     return new MCTimestamp(time);
/*     */   }
/*     */   
/*     */   final String getToStringFormat() {
/* 258 */     return "yyyyMMddHHmmssSSS";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCTimestamp addMilliSecond(int amount) {
/* 268 */     return super.addMilliSecond(amount);
/*     */   }
/*     */   
/*     */   public MCTimestamp modMilliSecond(int value) {
/* 272 */     return super.modMilliSecond(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCTimestamp addMilliSecond(Number amount) {
/* 277 */     return super.addMilliSecond(amount);
/*     */   }
/*     */   
/*     */   public MCTimestamp modMilliSecond(Number value) {
/* 281 */     return super.modMilliSecond(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCDate toMCDate() {
/* 298 */     return MCDate.valueOf(this);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\lang\MCTimestamp.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */