/*     */ package mcframe.commonCore.lang;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.net.URL;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MCBinary
/*     */   implements Comparable<MCBinary>, Cloneable
/*     */ {
/*     */   public static final long BLANK_DB = -9223372036854775808L;
/*  45 */   public static final File BLANK_FILE = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   public static final String BLANK_REMOTE = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final char DPTEXT_SEP = '#';
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final char DPTEXT_REMOTE = '#';
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final char DPTEXT_LOCAL = '@';
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String createDPText(String reqno, int seqno) {
/*  92 */     return String.valueOf(reqno) + '#' + seqno;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCBinary valueOf(long dbp) {
/* 107 */     return new MCBinary(dbp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCBinary valueOf(File file) {
/* 124 */     if (file == null) {
/* 125 */       return null;
/*     */     }
/* 127 */     return new MCBinary(file);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCBinary valueOf(String remote) {
/* 143 */     if (remote == null) {
/* 144 */       return null;
/*     */     }
/* 146 */     return new MCBinary(remote);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 158 */   private File _file_p = BLANK_FILE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 166 */   private String _remote_p = BLANK_REMOTE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean _file_remote = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 181 */   private long _db_p = Long.MIN_VALUE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 189 */   private URL _db_url = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCBinary(long dbp) {
/* 201 */     if (dbp < 0L)
/*     */     {
/* 203 */       throw new MCException(Core_Msg_FW_A.FCBFC0024, new Object[] { String.valueOf(dbp) });
/*     */     }
/* 205 */     this._db_p = dbp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCBinary(File file) {
/* 225 */     this._file_p = file;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCBinary(String remote) {
/* 239 */     this._remote_p = remote;
/* 240 */     this._file_remote = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 245 */     return isDBFile() ? (
/*     */       
/* 247 */       31 * (int)((
/* 248 */       (int)(this._db_p >>> 32L) * 31) + (this._db_p & 0xFFFFFFFFL))) : (
/*     */       
/* 250 */       isDBFile() ? (
/*     */ 
/*     */       
/* 253 */       (this._remote_p == null) ? 0 : this._remote_p.hashCode()) : (
/*     */       
/* 255 */       (this._file_p == null) ? 0 : this._file_p.hashCode()));
/*     */   }
/*     */ 
/*     */   
/*     */   public Object clone() {
/*     */     try {
/* 261 */       MCBinary other = (MCBinary)super.clone();
/* 262 */       other._file_p = this._file_p;
/*     */       
/* 264 */       other._remote_p = this._remote_p;
/* 265 */       return other;
/* 266 */     } catch (CloneNotSupportedException cloneNotSupportedException) {
/*     */       
/* 268 */       throw new InternalError();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   URL dblinkURL() {
/* 282 */     return this._db_url;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void dblinkURL(URL url) {
/* 293 */     this._db_url = url;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDBFile() {
/* 306 */     return (this._db_p != Long.MIN_VALUE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRemoteFile() {
/* 318 */     return this._file_remote;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLocalFile() {
/* 330 */     return (!isDBFile() && !isRemoteFile());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File toFile() {
/* 348 */     return this._file_p;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toRemotePath() {
/* 362 */     return this._remote_p;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long toDBPointer() {
/* 373 */     return this._db_p;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 387 */     return isDBFile() ? 
/* 388 */       String.valueOf(this._db_p) : (
/*     */       
/* 390 */       isRemoteFile() ? 
/* 391 */       this._remote_p : 
/* 392 */       this._file_p.getAbsolutePath());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(MCBinary o) {
/* 421 */     if (o == null) {
/* 422 */       throw new MCException(Core_Msg_FW_A.FCBFC0027, new Object[0]);
/*     */     }
/*     */     
/* 425 */     if (this._db_p != Long.MIN_VALUE)
/*     */     {
/* 427 */       return (this._db_p < o._db_p) ? -1 : ((this._db_p > o._db_p) ? 1 : 0);
/*     */     }
/*     */ 
/*     */     
/* 431 */     if (o._db_p != Long.MIN_VALUE) {
/* 432 */       return -1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 438 */     if (this._file_remote && o._file_remote) {
/* 439 */       return this._remote_p.compareTo(o._remote_p);
/*     */     }
/*     */     
/* 442 */     if (!this._file_remote && !o._file_remote) {
/* 443 */       return this._file_p.compareTo(o._file_p);
/*     */     }
/*     */     
/* 446 */     return this._file_remote ? -1 : 1;
/*     */   }
/*     */   
/*     */   public boolean equals(Object x) {
/* 450 */     if (!(x instanceof MCBinary)) {
/* 451 */       return false;
/*     */     }
/* 453 */     MCBinary b = (MCBinary)x;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 463 */     if (this._db_p != Long.MIN_VALUE)
/*     */     {
/* 465 */       return (this._db_p == b._db_p);
/*     */     }
/* 467 */     if (b._db_p != Long.MIN_VALUE)
/*     */     {
/* 469 */       return false;
/*     */     }
/* 471 */     if (this._file_remote != b._file_remote)
/*     */     {
/* 473 */       return false;
/*     */     }
/*     */     
/* 476 */     return this._file_remote ? (
/*     */ 
/*     */       
/* 479 */       (this._remote_p != null) ? 
/* 480 */       this._remote_p.equals(b._remote_p) : (
/* 481 */       (b._remote_p == null))) : (
/*     */       
/* 483 */       (this._file_p != null) ? 
/* 484 */       this._file_p.equals(b._file_p) : (
/* 485 */       (b._file_p == null)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void dblink(long pointer) {
/* 510 */     this._db_p = pointer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void remote(boolean remote) {
/* 528 */     this._file_remote = remote;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\lang\MCBinary.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */