/*    */ package mcframe.commonCore.param;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum MCFaultType
/*    */ {
/* 11 */   FRAMEWORK_ERROR_TYPE { public String toDP() { return "0"; } },
/* 12 */   APP_ERROR_TYPE { public String toDP() { return "1"; }
/*    */      }
/*    */   ;
/*    */   
/*    */   public abstract String toDP();
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\param\MCFaultType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */