/*     */ package mcframe.commonCore.param;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.file.Files;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.notice.Core_Msg;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.resource.MCConfig;
/*     */ import mcframe.commonCore.sys.MCSys;
/*     */ import mcframe.commonCore.util.MCFileUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCParamFileUtil
/*     */ {
/*     */   public static final String PARAM_FILE_ENCODE = "UTF-8";
/*     */   private static final String UP_PARAM_FILE = "param_{USER}_{REQNO}_up.txt";
/*     */   private static final String DOWN_PARAM_FILE = "param_{USER}_{REQNO}_down.txt";
/*     */   private static final String PARAM_FILE_DIR = "{USERHOME}/param";
/*     */   
/*     */   public static File getUpParamFile() {
/*  57 */     return new File(getParamFileDir(), getUpParamFileName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getUpParamFileName() {
/*  68 */     return MCStringUtil.bind("param_{USER}_{REQNO}_up.txt", (MCStringUtil.BindSource)getCustomBindSource());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static File getDownParamFile() {
/*  79 */     return new File(getParamFileDir(), getDownParamFileName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getDownParamFileName() {
/*  90 */     return MCStringUtil.bind("param_{USER}_{REQNO}_down.txt", (MCStringUtil.BindSource)getCustomBindSource());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static MCStringUtil.CustomBindSource getCustomBindSource() {
/* 101 */     MCStringUtil.CustomBindSource bindsrc = new MCStringUtil.CustomBindSource(MCConfig.common.bindsrc);
/* 102 */     bindsrc.put("REQNO", MCSys.request.serverRequestNo());
/* 103 */     return bindsrc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getParamFileDir() {
/* 114 */     return MCStringUtil.bind("{USERHOME}/param", MCConfig.common.bindsrc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static File getScrContainerFile(MCParam param, int seq) {
/* 130 */     File f = new File(getParamFileDir(), 
/* 131 */         getScrContainerName(param, seq));
/* 132 */     MCFileUtil.mkDir(f.getParentFile());
/*     */     
/*     */     try {
/* 135 */       Files.deleteIfExists(f.toPath());
/*     */     }
/* 137 */     catch (IOException iOException) {
/*     */       
/* 139 */       MCLog.write(Core_Msg.FCBGC0064, new Object[] { f.getParentFile(), f.getName() });
/*     */     } 
/* 141 */     return f;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getScrContainerName(MCParam param, int seq) {
/* 155 */     return String.valueOf(param.getModuleId()) + "_" + param.getLogicId() + "_" + 
/* 156 */       param.getOperationId() + "_" + String.format("%02d", new Object[] { Integer.valueOf(seq) }) + "_scr.csv";
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\param\MCParamFileUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */