/*     */ package mcframe.commonCore.param;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import mcframe.commonCore.container.MCContainer;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCContainerParam
/*     */ {
/*  27 */   private List<MCContainer> up = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  37 */   private List<MCContainer> down = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<MCContainer> up() {
/*  48 */     return this.up;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<MCContainer> down() {
/*  59 */     return this.down;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void up(List<MCContainer> list) {
/*  70 */     this.up = list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void down(List<MCContainer> list) {
/*  81 */     this.down = list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCContainer getUpBlock(int i) {
/*  94 */     return this.up.get(i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCContainer getDownBlock(int i) {
/* 106 */     return this.down.get(i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addUpBlock(MCContainer cont) {
/* 118 */     this.up.add(cont);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addDownBlock(MCContainer cont) {
/* 130 */     this.down.add(cont);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void copy(MCContainerParam p) {
/* 143 */     this.up.clear();
/* 144 */     this.down.clear();
/*     */     
/* 146 */     List<MCContainer> upList = p.up();
/* 147 */     List<MCContainer> downList = p.down();
/*     */     
/* 149 */     for (MCContainer cont : upList) {
/* 150 */       if (cont instanceof MCRow) {
/* 151 */         this.up.add(((MCRow)cont).clone()); continue;
/*     */       } 
/* 153 */       this.up.add(((MCList)cont).clone());
/*     */     } 
/*     */ 
/*     */     
/* 157 */     for (MCContainer cont : downList) {
/* 158 */       if (cont instanceof MCRow) {
/* 159 */         this.down.add(((MCRow)cont).clone()); continue;
/*     */       } 
/* 161 */       this.down.add(((MCList)cont).clone());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\param\MCContainerParam.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */