/*     */ package mcframe.commonCore.param;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCDownloadStreamParam
/*     */ {
/*  22 */   private final List<MCDownloadStream> _list = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/*  44 */     return this._list.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCDownloadStream[] toArray() {
/*  57 */     return this._list.<MCDownloadStream>toArray(new MCDownloadStream[this._list.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/*  69 */     closeAll();
/*  70 */     this._list.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void closeAll() {
/*  80 */     for (int i = 0, len = this._list.size(); i < len; i++) {
/*  81 */       MCDownloadStream in = this._list.get(i);
/*  82 */       if (in != null) {
/*     */         try {
/*  84 */           in.close();
/*  85 */         } catch (IOException iOException) {}
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAll(MCDownloadStreamParam dlsp) {
/* 100 */     if (dlsp == null) {
/*     */       return;
/*     */     }
/* 103 */     this._list.addAll(dlsp._list);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int add(MCDownloadStream is) {
/* 115 */     this._list.add(is);
/* 116 */     return this._list.size() - 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCDownloadStream get(int index) {
/*     */     try {
/* 129 */       return this._list.get(index);
/* 130 */     } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
/*     */       
/* 132 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\param\MCDownloadStreamParam.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */