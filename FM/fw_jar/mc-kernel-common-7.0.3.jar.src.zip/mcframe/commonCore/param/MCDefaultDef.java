/*    */ package mcframe.commonCore.param;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCDefaultDef
/*    */   extends MCDef
/*    */ {
/* 21 */   private static MCDefaultContainerDef defaultDef = new MCDefaultContainerDef();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MCContainerDef getCustomDef(String id) {
/* 34 */     return defaultDef;
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\param\MCDefaultDef.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */