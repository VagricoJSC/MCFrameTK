/*     */ package mcframe.commonCore.param;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import mcframe.commonCore.lang.MCBinary;
/*     */ import mcframe.commonCore.resource.MCConfig;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCUploadFileParam
/*     */ {
/*  29 */   private final Map<String, MCUploadStream> _resmap = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  39 */   private final Map<String, String> _reqmap = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   private String _respath = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int responseSize() {
/*  69 */     return this._resmap.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int requestSize() {
/*  80 */     return this._reqmap.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/*  91 */     this._resmap.clear();
/*  92 */     this._reqmap.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAll(MCUploadFileParam ulfp) {
/* 103 */     if (ulfp == null) {
/*     */       return;
/*     */     }
/* 106 */     this._resmap.putAll(ulfp._resmap);
/* 107 */     this._reqmap.putAll(ulfp._reqmap);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[][] toRequestArrays() {
/* 124 */     int size = this._reqmap.size();
/* 125 */     String[][] arrays = new String[2][];
/* 126 */     arrays[0] = new String[size];
/* 127 */     arrays[1] = new String[size];
/* 128 */     int i = 0;
/* 129 */     for (Map.Entry<String, String> entry : this._reqmap.entrySet()) {
/* 130 */       arrays[0][i] = entry.getValue();
/* 131 */       arrays[1][i++] = entry.getKey();
/*     */     } 
/* 133 */     return arrays;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String addRequest(File file, String reqno) {
/* 149 */     String path = (file != null) ? file.getAbsolutePath() : null;
/* 150 */     String id = this._reqmap.get(path);
/* 151 */     if (id == null) {
/* 152 */       id = MCBinary.createDPText(reqno, this._reqmap.size());
/* 153 */       this._reqmap.put(path, id);
/*     */     } 
/* 155 */     return id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRequest(File file) {
/* 167 */     String path = (file != null) ? file.getAbsolutePath() : null;
/* 168 */     return this._reqmap.get(path);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[][] toResponseArrays() {
/* 185 */     int size = this._resmap.size();
/* 186 */     String[][] arrays = new String[2][];
/* 187 */     arrays[0] = new String[size];
/* 188 */     arrays[1] = new String[size];
/* 189 */     int i = 0;
/* 190 */     for (Map.Entry<String, MCUploadStream> entry : this._resmap.entrySet()) {
/* 191 */       arrays[0][i] = entry.getKey();
/* 192 */       arrays[1][i++] = ((MCUploadStream)entry.getValue()).getSource();
/*     */     } 
/* 194 */     return arrays;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean addResponse(String id, MCUploadStream us) {
/* 210 */     MCUploadStream value = this._resmap.get(id);
/* 211 */     if (value == null) {
/* 212 */       this._resmap.put(id, us);
/* 213 */       return true;
/*     */     } 
/* 215 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean addResponseFile(String id, File src) {
/* 231 */     MCUploadStream value = this._resmap.get(id);
/* 232 */     if (value == null) {
/* 233 */       this._resmap.put(id, new MCUploadStream(id, src));
/* 234 */       return true;
/*     */     } 
/* 236 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCUploadStream getResponse(String id) {
/* 248 */     return this._resmap.get(id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File getResponseFile(String id) {
/* 265 */     MCUploadStream us = this._resmap.get(id);
/* 266 */     return (us != null) ? us.toFile(this._respath) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResponseFilePath(String path) {
/* 277 */     this._respath = path;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 288 */     StringBuilder sb = new StringBuilder();
/* 289 */     int uplen = responseSize();
/* 290 */     String[][] ups = toResponseArrays();
/* 291 */     for (int i = 0; i < uplen; i++) {
/* 292 */       sb.append(ups[0][i]);
/* 293 */       sb.append(" (");
/* 294 */       sb.append(ups[1][i]);
/* 295 */       sb.append(')');
/* 296 */       sb.append(MCConfig.LINE_SEP);
/*     */     } 
/* 298 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\param\MCUploadFileParam.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */