/*    */ package mcframe.commonCore.param;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MCBaseDef
/*    */   extends MCDef
/*    */ {
/*    */   protected MCContainerDef getCustomDef(String id) {
/* 23 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\param\MCBaseDef.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */