/*    */ package mcframe.commonCore.param;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCDefaultContainerDef
/*    */   extends MCContainerDef
/*    */ {
/* 19 */   public static final MCContainerDef.MCItemDefList itemList = new MCContainerDef.MCItemDefList(null, new MCItemDef[0]);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected MCContainerDef.MCItemDefList itemList() {
/* 38 */     return itemList;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MCItemDef[] transItems() {
/* 49 */     return (itemList()).metas;
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\param\MCDefaultContainerDef.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */