/*     */ package mcframe.commonCore.param;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCGeneralContainerDef
/*     */   extends MCContainerDef
/*     */ {
/*     */   private final MCContainerDef.MCItemDefList _itemList;
/*  31 */   private MCBlockDef _block = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  38 */   private MCContainerDef _parent = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String _moduleId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String _logicId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String _operationId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCGeneralContainerDef(MCItemDef[] own) {
/*  69 */     this(MCContainerDef.itemList, own);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCGeneralContainerDef(String moduleId, String logicId, String operationId, MCItemDef[] own) {
/*  84 */     this(MCContainerDef.itemList, own);
/*  85 */     this._moduleId = moduleId;
/*  86 */     this._logicId = logicId;
/*  87 */     this._operationId = operationId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCGeneralContainerDef(MCItemDef[] own, MCBlockDef blk) {
/*  99 */     this(MCContainerDef.itemList, own, blk);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCGeneralContainerDef(String moduleId, String logicId, String operationId, MCItemDef[] own, MCBlockDef blk) {
/* 115 */     this(MCContainerDef.itemList, own, blk);
/* 116 */     this._moduleId = moduleId;
/* 117 */     this._logicId = logicId;
/* 118 */     this._operationId = operationId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCGeneralContainerDef(String moduleId, String logicId, String operationId, MCContainerDef parent, MCItemDef[] own) {
/* 136 */     this(parent.itemList(), own);
/* 137 */     this._parent = parent;
/* 138 */     this._moduleId = moduleId;
/* 139 */     this._logicId = logicId;
/* 140 */     this._operationId = operationId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCGeneralContainerDef(MCContainerDef parent, MCItemDef[] own) {
/* 154 */     this(parent.itemList(), own);
/* 155 */     this._parent = parent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCGeneralContainerDef(MCContainerDef parent, MCItemDef[] own, MCBlockDef blk) {
/* 170 */     this(parent.itemList(), own, blk);
/* 171 */     this._parent = parent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCGeneralContainerDef(String moduleId, String logicId, String operationId, MCContainerDef parent, MCItemDef[] own, MCBlockDef blk) {
/* 190 */     this(parent.itemList(), own, blk);
/* 191 */     this._parent = parent;
/* 192 */     this._moduleId = moduleId;
/* 193 */     this._logicId = logicId;
/* 194 */     this._operationId = operationId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCGeneralContainerDef(MCContainerDef.MCItemDefList parent, MCItemDef[] own) {
/* 206 */     this(parent, own, (MCBlockDef)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCGeneralContainerDef(MCContainerDef.MCItemDefList parent, MCItemDef[] own, MCBlockDef blk) {
/* 219 */     this._itemList = new MCContainerDef.MCItemDefList(parent, own);
/* 220 */     this._block = blk;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCContainerDef.MCItemDefList itemList() {
/* 225 */     return this._itemList;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCBlockDef block() {
/* 230 */     return this._block;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCContainerDef parent() {
/* 235 */     return this._parent;
/*     */   }
/*     */ 
/*     */   
/*     */   public String moduleId() {
/* 240 */     return this._moduleId;
/*     */   }
/*     */ 
/*     */   
/*     */   public String logicId() {
/* 245 */     return this._logicId;
/*     */   }
/*     */ 
/*     */   
/*     */   public String operationId() {
/* 250 */     return this._operationId;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\param\MCGeneralContainerDef.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */