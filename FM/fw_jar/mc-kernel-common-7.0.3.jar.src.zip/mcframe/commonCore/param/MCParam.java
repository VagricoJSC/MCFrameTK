/*      */ package mcframe.commonCore.param;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.TimeZone;
/*      */ import mcframe.commonCore.container.MCContainer;
/*      */ import mcframe.commonCore.lang.MCNumber;
/*      */ import mcframe.commonCore.lang.MCTimestamp;
/*      */ import mcframe.commonCore.resource.MCConfig;
/*      */ import mcframe.commonCore.sys.MCClientOperation;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MCParam
/*      */   implements Cloneable
/*      */ {
/*   35 */   private String id = null;
/*      */   
/*      */   public static final String DP_VERSION_1_01 = "1.01";
/*      */   
/*      */   public static final String DP_VERSION_1_02 = "1.02";
/*      */   
/*      */   public static final String DP_VERSION = "1.02";
/*      */   
/*      */   private final MCContainerParam containerParam;
/*      */   
/*      */   private final MCExceptionParam exceptionParam;
/*      */   
/*      */   private final MCMessageParam messageParam;
/*      */   
/*      */   private final MCDownloadStreamParam downloadStreamParam;
/*      */   
/*      */   private final MCUploadFileParam uploadFileParam;
/*      */   
/*      */   private final MCPagingParam pagingParam;
/*      */   
/*      */   private String dpVersion;
/*      */   
/*      */   private String moduleId;
/*      */   
/*      */   private String logicId;
/*      */   
/*      */   private String operationId;
/*      */   
/*      */   private String version;
/*      */   
/*      */   private MCDef def;
/*      */   
/*      */   private MCTimestamp createdTime;
/*      */   
/*      */   private String serverId;
/*      */   
/*      */   private String serverRequestNo;
/*      */   private String clientId;
/*      */   private String clientRequestNo;
/*      */   private boolean _ope_async;
/*      */   private Locale clientLocale;
/*      */   private TimeZone clientTimeZone;
/*      */   private String userId;
/*      */   private String userName;
/*      */   private String loginSequence;
/*      */   private String reqSrcId;
/*      */   private MCTimestamp requestTime;
/*      */   private MCTimestamp commitTime;
/*      */   private MCTimestamp coSysTimestamp;
/*      */   private MCNumber limitDLSize;
/*      */   private MCNumber limitULSize;
/*      */   private Map<String, String> args;
/*      */   private String rOperationTyp;
/*      */   private String rActionId;
/*      */   private String rLabel;
/*      */   private String systemId;
/*      */   private String appVersion;
/*      */   private String appBuild;
/*      */   private String identifier;
/*      */   private String dlVersion;
/*      */   private String dlBuild;
/*      */   private List<MCContainerEntry> upEntries;
/*      */   
/*      */   public MCParam(String moduleId, String logicId, String operationId, String version) {
/*   99 */     this();
/*  100 */     setModuleId(moduleId);
/*  101 */     setLogicId(logicId);
/*  102 */     setOperationId(operationId);
/*  103 */     setVersion(version);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCParam(MCOperationInfo info) {
/*  117 */     this(info.moduleId, info.logicId, info.operationId, info.version);
/*  118 */     this.id = info.id;
/*  119 */     setDef(info.def);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCContainerParam getContainerParam() {
/*  187 */     return this.containerParam;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCExceptionParam getExceptionParam() {
/*  198 */     return this.exceptionParam;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCMessageParam getMessageParam() {
/*  209 */     return this.messageParam;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCDownloadStreamParam getDownloadStreamParam() {
/*  220 */     return this.downloadStreamParam;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCUploadFileParam getUploadFileParam() {
/*  231 */     return this.uploadFileParam;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCPagingParam getPagingParam() {
/*  245 */     return this.pagingParam;
/*      */   }
/*      */   public String getDPVersion() { return this.dpVersion; }
/*      */   public void setDPVersion(String dpVersion) { this.dpVersion = dpVersion; }
/*      */   public String getModuleId() { return this.moduleId; }
/*      */   public void setModuleId(String moduleId) { this.moduleId = moduleId; }
/*      */   public String getLogicId() { return this.logicId; }
/*      */   public void setLogicId(String logicId) { this.logicId = logicId; }
/*      */   public String getOperationId() { return this.operationId; }
/*      */   public void setOperationId(String operationId) { this.operationId = operationId; }
/*      */   public String getVersion() { return this.version; }
/*      */   public void setVersion(String version) { this.version = version; }
/*      */   public MCDef getDef() { return this.def; }
/*      */   public void setDef(MCDef def) { if (def != null) this.def = def;  }
/*      */   public MCTimestamp getCreatedTime() { return this.createdTime; }
/*  260 */   public void setCreatedTime(MCTimestamp createdTime) { this.createdTime = createdTime; } public String getServerId() { return this.serverId; } public void setServerId(String serverId) { this.serverId = serverId; } public String getServerRequestNo() { return this.serverRequestNo; } public void setServerRequestNo(String serverRequestNo) { this.serverRequestNo = serverRequestNo; } public String getClientId() { return this.clientId; } public void setClientId(String clientId) { this.clientId = clientId; } public String getClientRequestNo() { return this.clientRequestNo; } public void setClientRequestNo(String clientRequestNo) { this.clientRequestNo = clientRequestNo; } public void setOperationAsync(boolean async) { this._ope_async = async; } public boolean isOperationAsync() { return this._ope_async; } public Locale getClientLocale() { return this.clientLocale; } public void setClientLocale(Locale clientLocale) { this.clientLocale = clientLocale; } public MCParam() { this.dpVersion = MCConfig.common.getString("net.param.mcdp.dpversion", "1.02");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  501 */     this._ope_async = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1016 */     this.args = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1126 */     this.rLabel = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1255 */     this.identifier = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1284 */     this.dlVersion = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1313 */     this.dlBuild = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1369 */     this
/* 1370 */       .upEntries = new ArrayList<>(); this.containerParam = new MCContainerParam(); this.exceptionParam = new MCExceptionParam(); this.messageParam = new MCMessageParam(); this.downloadStreamParam = new MCDownloadStreamParam(); this.uploadFileParam = new MCUploadFileParam(); this.pagingParam = new MCPagingParam(); this.def = new MCDefaultDef();
/*      */     this.args = new HashMap<>(); }
/*      */   public TimeZone getClientTimeZone() { return this.clientTimeZone; }
/*      */   public void setClientTimeZone(TimeZone clientTimeZone) { this.clientTimeZone = clientTimeZone; }
/*      */   public String getUserId() { return this.userId; }
/*      */   public void setUserId(String userId) { this.userId = userId; }
/*      */   public String getUserName() { return this.userName; }
/*      */   public void setUserName(String userName) { this.userName = userName; }
/*      */   public String getLoginSequence() { return this.loginSequence; }
/* 1379 */   public void setLoginSequence(String loginSequence) { this.loginSequence = loginSequence; } public List<MCContainerEntry> entries() { return this.upEntries; } public String getReqSrcId() { return this.reqSrcId; } public void setReqSrcId(String reqSrcId) { this.reqSrcId = reqSrcId; }
/*      */   public MCTimestamp getRequestTime() { return this.requestTime; }
/*      */   public void setRequestTime(MCTimestamp requestTime) { this.requestTime = requestTime; }
/*      */   public MCTimestamp getCommitTime() { return this.commitTime; }
/*      */   public void setCommitTime(MCTimestamp commitTime) { this.commitTime = commitTime; }
/*      */   public MCTimestamp getCoSysTimestamp() { return this.coSysTimestamp; }
/*      */   public void setCoSysTimestamp(MCTimestamp coSysTimestamp) { this.coSysTimestamp = coSysTimestamp; }
/*      */   public MCNumber getLimitDLSize() { return this.limitDLSize; }
/*      */   public void setLimitDLSize(MCNumber limitDLSize) { this.limitDLSize = limitDLSize; }
/*      */   public MCNumber getLimitULSize() { return this.limitULSize; }
/*      */   public void setLimitULSize(MCNumber limitULSize) { this.limitULSize = limitULSize; }
/*      */   public Map<String, String> getArgs() { return this.args; }
/*      */   public void setOperationHis(MCClientOperation ope) { if (ope != null) { setActionIdHis(ope.getActionID()); setActionLabelHis(ope.getLabel()); setOperationTypeHis(ope.getOperationCD()); } else { setActionIdHis(null); setActionLabelHis(null); setOperationTypeHis(null); }  }
/*      */   public String getOperationTypeHis() { return this.rOperationTyp; }
/*      */   public void setOperationTypeHis(String r_operationTyp) { this.rOperationTyp = r_operationTyp; }
/*      */   public String getActionIdHis() { return this.rActionId; }
/* 1395 */   public MCParam clone() { MCParam p = new MCParam();
/* 1396 */     p.copy(this);
/* 1397 */     return p; } public void setActionIdHis(String rActionId) { this.rActionId = rActionId; } public String getActionLabelHis() { return this.rLabel; } public void setActionLabelHis(String rLabel) { this.rLabel = rLabel; } public String getSystemId() { return this.systemId; }
/*      */   public void setSystemId(String systemId) { this.systemId = systemId; }
/*      */   public String getApplicationVersion() { return this.appVersion; }
/*      */   public void setApplicationVersion(String appVersion) { this.appVersion = appVersion; }
/*      */   public String getApplicationBuild() { return this.appBuild; }
/*      */   public void setApplicationBuild(String appBuild) { this.appBuild = appBuild; }
/*      */   public String getIdentifier() { return this.identifier; }
/*      */   public void setIdentifier(String identifier) { this.identifier = identifier; }
/*      */   public String getDlVersion() { return this.dlVersion; }
/*      */   public void setDlVersion(String dlVersion) { this.dlVersion = dlVersion; }
/*      */   public String getDlBuild() { return this.dlBuild; }
/*      */   public void setDlBuild(String dlBuild) { this.dlBuild = dlBuild; }
/*      */   public void addUpBlock(MCContainer cont) { this.containerParam.addUpBlock(cont); }
/*      */   public void addDownBlock(MCContainer cont) { this.containerParam.addDownBlock(cont); }
/* 1411 */   public void copy(MCParam p) { this.containerParam.up().clear();
/* 1412 */     this.containerParam.up().addAll(p.containerParam.up());
/* 1413 */     this.containerParam.down().clear();
/* 1414 */     this.containerParam.down().addAll(p.containerParam.down());
/*      */     
/* 1416 */     MCExceptionRowParam thiserp = this.exceptionParam.getExceptionRowParam();
/* 1417 */     MCExceptionRowParam erp = p.exceptionParam.getExceptionRowParam();
/* 1418 */     thiserp.setBlkNo(erp.getBlkNo());
/* 1419 */     thiserp.setBlkRowIdx(erp.getBlkRowIdx());
/* 1420 */     thiserp.setCompMsg(erp.getCompMsg());
/* 1421 */     thiserp.setEx(erp.getEx());
/* 1422 */     thiserp.setId(erp.getId());
/* 1423 */     thiserp.setLevel(erp.getLevel());
/*      */     
/* 1425 */     thiserp.setClmIdx(erp.getClmIdx());
/* 1426 */     thiserp.setType(erp.getType());
/* 1427 */     thiserp.getBind().clear();
/* 1428 */     thiserp.getBind().addAll(erp.getBind());
/*      */     
/* 1430 */     this.exceptionParam.getMessageRowParamList().clear();
/* 1431 */     this.exceptionParam.getMessageRowParamList().addAll(
/* 1432 */         p.exceptionParam.getMessageRowParamList());
/*      */     
/* 1434 */     this.messageParam.getMessageRowParamList().clear();
/* 1435 */     this.messageParam.getMessageRowParamList().addAll(
/* 1436 */         p.messageParam.getMessageRowParamList());
/*      */     
/* 1438 */     this.downloadStreamParam.clear();
/* 1439 */     this.downloadStreamParam.addAll(p.downloadStreamParam);
/*      */     
/* 1441 */     this.uploadFileParam.clear();
/* 1442 */     this.uploadFileParam.addAll(p.uploadFileParam);
/*      */     
/* 1444 */     this.pagingParam.getPagingRowParamList().clear();
/* 1445 */     this.pagingParam.getPagingRowParamList().addAll(
/* 1446 */         p.pagingParam.getPagingRowParamList());
/* 1447 */     this.pagingParam.getPagingSortParamList().clear();
/* 1448 */     this.pagingParam.getPagingSortParamList().addAll(
/* 1449 */         p.pagingParam.getPagingSortParamList());
/*      */ 
/*      */     
/* 1452 */     this.dpVersion = p.dpVersion;
/*      */     
/* 1454 */     this.moduleId = p.moduleId;
/* 1455 */     this.logicId = p.logicId;
/* 1456 */     this.operationId = p.operationId;
/* 1457 */     this.version = p.version;
/*      */     
/* 1459 */     this.clientId = p.clientId;
/* 1460 */     this.clientLocale = p.clientLocale;
/* 1461 */     this.reqSrcId = p.reqSrcId;
/* 1462 */     this.rActionId = p.rActionId;
/* 1463 */     this.rLabel = p.rLabel;
/* 1464 */     this.rOperationTyp = p.rOperationTyp;
/* 1465 */     this.clientRequestNo = p.clientRequestNo;
/* 1466 */     this.clientTimeZone = p.clientTimeZone;
/* 1467 */     this.commitTime = p.commitTime;
/* 1468 */     this.createdTime = p.createdTime;
/* 1469 */     this.def = p.def;
/* 1470 */     this.limitDLSize = p.limitDLSize;
/* 1471 */     this.loginSequence = p.loginSequence;
/* 1472 */     this.requestTime = p.requestTime;
/* 1473 */     this.serverId = p.serverId;
/* 1474 */     this.userId = p.userId;
/*      */     
/* 1476 */     this.systemId = p.systemId;
/* 1477 */     this.appVersion = p.appVersion;
/* 1478 */     this.appBuild = p.appBuild;
/* 1479 */     this.args.clear();
/* 1480 */     this.args.putAll(p.args);
/*      */ 
/*      */     
/* 1483 */     this.identifier = p.identifier;
/* 1484 */     this.dlVersion = p.dlVersion;
/* 1485 */     this.dlBuild = p.dlBuild; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String id() {
/* 1496 */     return this.id;
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\param\MCParam.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */