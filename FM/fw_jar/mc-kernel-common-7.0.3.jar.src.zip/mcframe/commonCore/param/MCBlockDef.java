/*    */ package mcframe.commonCore.param;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MCBlockDef
/*    */ {
/*    */   public String id;
/*    */   
/*    */   public static MCBlockDef create(String anId) {
/* 30 */     MCBlockDef ret = new MCBlockDef();
/* 31 */     ret.id = anId;
/* 32 */     return ret;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String toParamString() {
/* 43 */     return this.id;
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\param\MCBlockDef.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */