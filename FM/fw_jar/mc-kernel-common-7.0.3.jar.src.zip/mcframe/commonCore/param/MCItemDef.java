/*     */ package mcframe.commonCore.param;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MCItemDef
/*     */ {
/*  23 */   public static final MCItemDef IGNORE_ITEM = new MCItemDef();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String id;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean required = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCContainerDef refDef;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String idInParam;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCItemDef create(String anId) {
/*  71 */     MCItemDef ret = new MCItemDef();
/*  72 */     ret.id = anId;
/*  73 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCItemDef create(String anId, String anIdInParam) {
/*  86 */     MCItemDef ret = create(anId);
/*  87 */     ret.idInParam = anIdInParam;
/*  88 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCItemDef create(String anId, boolean aRequired) {
/* 101 */     MCItemDef ret = create(anId);
/* 102 */     ret.required = aRequired;
/* 103 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCItemDef create(String anId, boolean aRequired, String anIdInParam) {
/* 117 */     MCItemDef ret = create(anId, aRequired);
/* 118 */     ret.idInParam = anIdInParam;
/* 119 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCItemDef create(String anId, MCContainerDef aRefDef) {
/* 132 */     MCItemDef ret = new MCItemDef();
/* 133 */     ret.id = anId;
/* 134 */     ret.refDef = aRefDef;
/* 135 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCItemDef create(String anId, MCContainerDef aRefDef, String anIdInParam) {
/* 149 */     MCItemDef ret = create(anId, aRefDef);
/* 150 */     ret.refDef = aRefDef;
/* 151 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCItemDef IGNORE_ITEM(String anIdInParam) {
/* 161 */     MCItemDef ret = new MCItemDef();
/* 162 */     ret.idInParam = anIdInParam;
/* 163 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isIgnore() {
/* 172 */     return (this.id == null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInnerRow() {
/* 183 */     return (this.refDef != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toParamString() {
/* 194 */     return this.id;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\param\MCItemDef.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */