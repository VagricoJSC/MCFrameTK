/*     */ package mcframe.commonCore.param;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.File;
/*     */ import java.io.InputStream;
/*     */ import java.util.Date;
/*     */ import mcframe.commonCore.lang.MCTimestamp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCDownloadStream
/*     */   extends BufferedInputStream
/*     */ {
/*  31 */   private String _name = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  38 */   private MCTimestamp _lastmod = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  45 */   private long _size = -1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   private File _file = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCDownloadStream(InputStream in, String name, MCTimestamp lastmod) {
/*  67 */     super(in);
/*  68 */     this._name = name;
/*  69 */     this._lastmod = lastmod;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCDownloadStream(InputStream in, String name, MCTimestamp lastmod, long fsize) {
/*  84 */     this(in, name, lastmod);
/*  85 */     this._size = fsize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCDownloadStream(InputStream in, String name, long lastmod) {
/*  98 */     this(in, name, MCTimestamp.valueOf(new Date(lastmod)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCDownloadStream(InputStream in, String name, long lastmod, long fsize) {
/* 113 */     this(in, name, MCTimestamp.valueOf(new Date(lastmod)), fsize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCDownloadStream(InputStream in, int bsize, String name, MCTimestamp lastmod) {
/* 128 */     super(in, bsize);
/* 129 */     this._name = name;
/* 130 */     this._lastmod = lastmod;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCDownloadStream(InputStream in, int bsize, String name, MCTimestamp lastmod, long fsize) {
/* 146 */     this(in, bsize, name, lastmod);
/* 147 */     this._size = fsize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCDownloadStream(InputStream in, int bsize, String name, long lastmod) {
/* 162 */     this(in, bsize, name, MCTimestamp.valueOf(new Date(lastmod)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCDownloadStream(InputStream in, int bsize, String name, long lastmod, long fsize) {
/* 178 */     this(in, bsize, name, MCTimestamp.valueOf(new Date(lastmod)), fsize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCDownloadStream(InputStream in, File file) {
/* 198 */     this(in, (file != null) ? file.getName() : null, (file != null) ? MCTimestamp.valueOf(new Date(file.lastModified())) : null, (file != null) ? file.length() : -1L);
/* 199 */     this._file = file;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCDownloadStream(InputStream in, int bsize, File file) {
/* 220 */     this(in, bsize, (file != null) ? file.getName() : null, (file != null) ? MCTimestamp.valueOf(new Date(file.lastModified())) : null, (file != null) ? file.length() : -1L);
/* 221 */     this._file = file;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 233 */     return this._name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String name) {
/* 244 */     this._name = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long size() {
/* 255 */     return this._size;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCTimestamp getLastModify() {
/* 266 */     return this._lastmod;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File getFile() {
/* 280 */     return this._file;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\param\MCDownloadStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */