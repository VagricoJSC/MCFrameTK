/*     */ package mcframe.commonCore.param;
/*     */ 
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Writer;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCDPWriter
/*     */ {
/*     */   private static final int MOD_UTF8_SIZE = 21845;
/*     */   private final PrintWriter pw;
/*     */   private final DataOutputStream os;
/*     */   private final boolean dump;
/*     */   private boolean _dly_active = false;
/*  68 */   private Writer dw = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  75 */   private String mid = "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   private String lid = "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   private String oid = "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean saveStatus;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String dumpId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private StringBuilder _buffer_string_builder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean _header;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Writer createDummyWriter() {
/* 167 */     return new Writer()
/*     */       {
/*     */         public void write(String str, int off, int len) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public void write(char[] s, int off, int len) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public void close() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public void flush() {}
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOperationID(String mid, String lid, String oid) {
/* 198 */     this.mid = mid;
/* 199 */     this.lid = lid;
/* 200 */     this.oid = oid;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void closeDump() {
/* 210 */     if (this.dw != null) {
/*     */       try {
/* 212 */         this.dw.close();
/*     */       }
/* 214 */       catch (IOException e) {
/* 215 */         MCLog.write(e);
/*     */       } 
/*     */     }
/* 218 */     this.dw = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/* 228 */     closeDump();
/*     */     
/* 230 */     if (this.pw != null) {
/* 231 */       this.pw.close();
/*     */     }
/* 233 */     if (this.os != null) {
/*     */       try {
/* 235 */         this.os.close();
/*     */       }
/* 237 */       catch (IOException e) {
/*     */         
/* 239 */         MCLog.write(e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flushDump() {
/* 251 */     if (this.dw != null) {
/*     */       try {
/* 253 */         this.dw.flush();
/*     */       }
/* 255 */       catch (IOException e) {
/* 256 */         MCLog.write(e);
/*     */       } 
/*     */     }
/*     */     
/* 260 */     if (this._dly_active) {
/* 261 */       MCLog.writeDelay();
/* 262 */       this._dly_active = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() {
/* 273 */     flushDump();
/*     */     
/* 275 */     if (this.pw != null) {
/* 276 */       this.pw.flush();
/*     */     }
/* 278 */     if (this.os != null) {
/*     */       try {
/* 280 */         this.os.flush();
/*     */       }
/* 282 */       catch (IOException e) {
/*     */         
/* 284 */         MCLog.write(e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(String str) {
/* 298 */     if (isBuffer()) {
/* 299 */       this._buffer_string_builder.append(str);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 304 */     if (this.dump) {
/*     */ 
/*     */       
/* 307 */       if (!this._dly_active) {
/* 308 */         MCLog.startDelay(getDumpId(), new Object[] { this.mid, this.lid, this.oid, "" });
/* 309 */         this._dly_active = true;
/*     */       } 
/* 311 */       MCLog.followDelay(str);
/*     */     } 
/* 313 */     if (this.saveStatus)
/*     */     {
/* 315 */       writeDownParamFile(str);
/*     */     }
/*     */ 
/*     */     
/* 319 */     if (this.pw != null) {
/* 320 */       this.pw.write(str);
/*     */     }
/* 322 */     if (this.os != null) {
/*     */       
/*     */       try {
/*     */         
/* 326 */         int len = str.length();
/* 327 */         for (int pos = 0; pos < len; pos += 21845) {
/* 328 */           int last = pos + 21845;
/* 329 */           if (last > len) {
/* 330 */             last = len;
/*     */           }
/* 332 */           String part = str.substring(pos, last);
/* 333 */           this.os.writeUTF(part);
/*     */         }
/*     */       
/* 336 */       } catch (IOException e) {
/*     */         
/* 338 */         e.printStackTrace();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSaveStatus(boolean save) {
/* 351 */     this.saveStatus = save;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getDumpId() {
/* 362 */     return MCStringUtil.isNull(this.dumpId) ? Core_Msg_FW_A.FCBGC0235 : this.dumpId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDumpId(String id) {
/* 373 */     this.dumpId = id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeDownParamFile(String str) {
/*     */     try {
/* 384 */       if (this.dw == null) {
/* 385 */         File dir = new File(MCParamFileUtil.getParamFileDir());
/* 386 */         if (!dir.exists()) {
/* 387 */           dir.mkdir();
/*     */         }
/* 389 */         this.dw = new OutputStreamWriter(
/* 390 */             new FileOutputStream(MCParamFileUtil.getDownParamFile()), 
/* 391 */             "UTF-8");
/*     */       } 
/* 393 */       this.dw.write(str);
/*     */     
/*     */     }
/* 396 */     catch (IOException e) {
/* 397 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCDPWriter(Writer writer, boolean dump)
/*     */   {
/* 407 */     this._buffer_string_builder = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 458 */     this._header = false; if (writer == null) writer = createDummyWriter();  this.pw = (writer instanceof PrintWriter) ? (PrintWriter)writer : new PrintWriter(writer); this.os = null; this.dump = dump; } public MCDPWriter(OutputStream os, boolean dump) { this._buffer_string_builder = null; this._header = false;
/*     */     if (os == null) {
/*     */       this.pw = new PrintWriter(createDummyWriter());
/*     */       this.os = null;
/*     */     } else {
/*     */       this.pw = null;
/*     */       this.os = new DataOutputStream2(os);
/*     */     } 
/*     */     this.dump = dump; }
/*     */   
/*     */   public void setWriteHeader(boolean write) {
/* 469 */     this._header = write;
/*     */   }
/*     */   public void setBuffer(boolean buffer) {
/*     */     if (buffer == isBuffer())
/*     */       return; 
/*     */     if (buffer) {
/*     */       this._buffer_string_builder = new StringBuilder();
/*     */     } else {
/*     */       String s = this._buffer_string_builder.toString();
/*     */       this._buffer_string_builder = null;
/*     */       write(s);
/*     */     } 
/*     */   }
/*     */   public boolean isBuffer() {
/*     */     return (this._buffer_string_builder != null);
/*     */   }
/*     */   public boolean isWriteHeader() {
/* 486 */     return this._header;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   class DataOutputStream2
/*     */     extends DataOutputStream
/*     */   {
/*     */     DataOutputStream2(OutputStream os) {
/* 509 */       super(os);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public synchronized void write(byte[] b, int off, int len) throws IOException {
/* 516 */       super.write(b, off + 2, len - 2);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\param\MCDPWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */