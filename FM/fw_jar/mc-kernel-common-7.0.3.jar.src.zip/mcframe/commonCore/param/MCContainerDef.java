/*     */ package mcframe.commonCore.param;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MCContainerDef
/*     */ {
/*  14 */   protected static final MCItemDefList itemList = new MCItemDefList(null, 
/*  15 */       new MCItemDef[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract MCItemDefList itemList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCItemDef[] transItems() {
/*  34 */     return (itemList()).metas;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class MCItemDefList
/*     */   {
/*     */     protected final MCItemDef[] metas;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MCItemDefList(MCItemDefList parents, MCItemDef[] thismetas) {
/*  66 */       List<MCItemDef> l_metas = new ArrayList<>();
/*  67 */       if (parents != null)
/*     */       {
/*     */ 
/*     */         
/*  71 */         for (int j = 0; j < parents.metas.length; j++) {
/*  72 */           l_metas.add(parents.metas[j]);
/*     */         }
/*     */       }
/*     */       
/*  76 */       for (int i = 0; i < thismetas.length; i++) {
/*     */ 
/*     */         
/*  79 */         if (thismetas[i].isInnerRow()) {
/*  80 */           List<MCItemDef> aList = MCContainerDef._expandItemDef(thismetas[i], 
/*  81 */               new ArrayList<>(), (thismetas[i]).id, 
/*  82 */               (thismetas[i]).idInParam);
/*  83 */           for (MCItemDef inMeta : aList) {
/*  84 */             l_metas = MCContainerDef.replaceAdd(inMeta, l_metas);
/*     */           }
/*     */         } else {
/*     */           
/*  88 */           l_metas = MCContainerDef.replaceAdd(thismetas[i], l_metas);
/*     */         } 
/*     */       } 
/*     */       
/*  92 */       this.metas = new MCItemDef[l_metas.size()];
/*  93 */       l_metas.toArray(this.metas);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static List<MCItemDef> _expandItemDef(MCItemDef anItem, List<MCItemDef> aList, String baseId, String baseIdInParam) {
/* 108 */     if (anItem.isInnerRow()) {
/* 109 */       MCItemDef[] inMetas = (anItem.refDef.itemList()).metas; byte b; int i; MCItemDef[] arrayOfMCItemDef1;
/* 110 */       for (i = (arrayOfMCItemDef1 = inMetas).length, b = 0; b < i; ) { MCItemDef inMeta = arrayOfMCItemDef1[b];
/* 111 */         String newId = String.valueOf(baseId) + "." + inMeta.id;
/* 112 */         String newIinP = null;
/* 113 */         if (baseIdInParam != null && inMeta.idInParam != null) {
/* 114 */           newIinP = String.valueOf(baseIdInParam) + "." + inMeta.idInParam;
/*     */         }
/* 116 */         aList = _expandItemDef(inMeta, aList, newId, newIinP);
/*     */         b++; }
/*     */     
/*     */     } else {
/* 120 */       boolean req = anItem.required;
/* 121 */       aList.add(MCItemDef.create(baseId, req, baseIdInParam));
/*     */     } 
/* 123 */     return aList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static List<MCItemDef> replaceAdd(MCItemDef anItem, List<MCItemDef> l_metas) {
/* 137 */     if (anItem == null) return l_metas; 
/* 138 */     if (anItem.idInParam == null) {
/*     */ 
/*     */       
/* 141 */       l_metas.add(anItem);
/* 142 */       return l_metas;
/*     */     } 
/* 144 */     boolean find = false;
/* 145 */     for (int i = 0; i < l_metas.size(); i++) {
/* 146 */       MCItemDef cand = l_metas.get(i);
/* 147 */       if (anItem.idInParam.equals(cand.idInParam)) {
/* 148 */         find = true;
/* 149 */         l_metas.remove(i);
/* 150 */         l_metas.add(i, anItem);
/*     */         break;
/*     */       } 
/*     */     } 
/* 154 */     if (!find) l_metas.add(anItem); 
/* 155 */     return l_metas;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCBlockDef block() {
/* 163 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCContainerDef parent() {
/* 171 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String moduleId() {
/* 179 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String logicId() {
/* 187 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String operationId() {
/* 195 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\param\MCContainerDef.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */