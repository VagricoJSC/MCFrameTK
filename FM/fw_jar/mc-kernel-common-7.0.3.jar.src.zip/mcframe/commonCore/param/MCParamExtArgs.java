package mcframe.commonCore.param;

public final class MCParamExtArgs {
  public static final String BATCH_CD1 = "args.batch_cd1";
  
  public static final String BATCH_CD2 = "args.batch_cd2";
  
  public static final String BATCH_CD3 = "args.batch_cd3";
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\param\MCParamExtArgs.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */