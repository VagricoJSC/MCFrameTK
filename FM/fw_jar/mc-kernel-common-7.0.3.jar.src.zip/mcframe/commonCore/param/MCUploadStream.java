/*     */ package mcframe.commonCore.param;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.util.MCFileUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MCUploadStream
/*     */   extends ByteArrayOutputStream
/*     */ {
/*  32 */   private String _id = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  40 */   private String _src = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  47 */   private File _file = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean _close = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCUploadStream(String id, String srcname) {
/*  68 */     this._id = id;
/*     */ 
/*     */     
/*  71 */     this._src = srcname.replace('\\', '/');
/*  72 */     this._file = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCUploadStream(String id, File src) {
/*  89 */     this._id = id;
/*  90 */     this._src = (src != null) ? src.getAbsolutePath() : null;
/*  91 */     this._file = (src != null) ? src : null;
/*  92 */     close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getID() {
/* 104 */     return this._id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSource() {
/* 115 */     return this._src;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String createFileName() {
/* 132 */     String name = null;
/* 133 */     if (this._file == null) {
/*     */ 
/*     */       
/* 136 */       if (this._src == null) {
/*     */         
/* 138 */         name = this._id;
/*     */       } else {
/*     */         
/* 141 */         File src = new File(this._src);
/* 142 */         name = src.getName();
/*     */       } 
/*     */     } else {
/*     */       
/* 146 */       name = this._file.getName();
/*     */     } 
/* 148 */     return name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized File toFile(String path) {
/* 175 */     if (this._file != null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 185 */       return this._file;
/*     */     }
/* 187 */     if (this._close)
/*     */     {
/* 189 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 194 */     File dir = new File(path, this._id);
/* 195 */     MCFileUtil.mkDir(dir);
/* 196 */     String name = createFileName();
/* 197 */     File file = new File(dir, name);
/*     */ 
/*     */ 
/*     */     
/* 201 */     MCLog.write(Core_Msg_FW_A.FCBGC0106, new Object[] { file.getAbsolutePath() }); try {
/* 202 */       Exception exception2, exception1 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 209 */     catch (FileNotFoundException fileNotFoundException) {
/*     */       
/* 211 */       throw new MCException(Core_Msg_FW_A.FCBGC0087, new Object[] { file.getAbsolutePath() });
/*     */     }
/* 213 */     catch (IOException iOException) {
/*     */       
/* 215 */       throw new MCException(Core_Msg_FW_A.FCBGC0090, new Object[] { file.getAbsolutePath() });
/*     */     } 
/*     */ 
/*     */     
/* 219 */     this._file = file;
/* 220 */     close();
/*     */     
/* 222 */     return this._file;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void close() {
/* 238 */     this._close = true;
/* 239 */     this.buf = null;
/* 240 */     this.count = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void cutoff(int len) {
/* 256 */     if (this.count <= 0 || len < 0) {
/*     */       return;
/*     */     }
/* 259 */     this.count -= len;
/* 260 */     if (this.count < 0) {
/* 261 */       this.count = 0;
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized void write(int b) {
/* 266 */     if (this._close) {
/*     */       return;
/*     */     }
/* 269 */     super.write(b);
/*     */   }
/*     */   
/*     */   public synchronized void write(byte[] b, int off, int len) {
/* 273 */     if (this._close) {
/*     */       return;
/*     */     }
/* 276 */     super.write(b, off, len);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\param\MCUploadStream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */