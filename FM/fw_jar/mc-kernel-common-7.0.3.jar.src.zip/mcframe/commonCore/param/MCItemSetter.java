package mcframe.commonCore.param;

import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.lang.MCDataType;

public interface MCItemSetter {
  MCDataType type();
  
  void setValue(MCRow paramMCRow, String paramString1, String paramString2);
  
  void addColumnMCLL(MCRow paramMCRow, String paramString1, String paramString2);
  
  String toDPText(MCRow paramMCRow, String paramString);
  
  String toDPTextNE(MCRow paramMCRow, String paramString);
  
  void setValueJSON(MCRow paramMCRow, String paramString1, String paramString2);
  
  String toJSONText(MCRow paramMCRow, String paramString);
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\param\MCItemSetter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */