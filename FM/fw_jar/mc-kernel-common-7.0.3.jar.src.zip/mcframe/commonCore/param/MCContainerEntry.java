/*     */ package mcframe.commonCore.param;
/*     */ 
/*     */ import mcframe.commonCore.container.MCContainer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCContainerEntry
/*     */ {
/*     */   public static final String MSG_CP_NO_POINTER_TXT = "";
/*     */   private String id;
/*     */   private MCContainer container;
/*     */   private String type;
/*     */   private String path;
/*     */   private String pointer;
/*     */   private int blkNo;
/*  81 */   private int blkRowIdx = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   private MCItemDef[] itemdefs = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   private MCItemSetter[] setters = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCContainerEntry(String id, MCContainer con, String type, int blkNo, MCItemDef[] itemdefs, MCItemSetter[] setters) {
/* 116 */     this.id = id;
/* 117 */     this.container = con;
/* 118 */     this.type = type;
/* 119 */     this.pointer = "";
/* 120 */     this.blkNo = blkNo;
/* 121 */     this.itemdefs = itemdefs;
/* 122 */     this.setters = setters;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCContainerEntry(String id, MCContainer con, String type, String path, String pointer, int blkNo, int blkRowIdx, MCItemDef[] itemdefs, MCItemSetter[] setters) {
/* 149 */     this(id, con, type, blkNo, itemdefs, setters);
/* 150 */     this.blkRowIdx = blkRowIdx;
/* 151 */     this.path = path;
/* 152 */     this.pointer = pointer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCContainerEntry() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(String id, MCContainer con, String type, int blkNo, MCItemDef[] itemdefs, MCItemSetter[] setters) {
/* 184 */     this.id = id;
/* 185 */     this.container = con;
/* 186 */     this.type = type;
/* 187 */     this.pointer = "";
/* 188 */     this.blkNo = blkNo;
/* 189 */     this.itemdefs = itemdefs;
/* 190 */     this.setters = setters;
/* 191 */     this.blkRowIdx = -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(String id, MCContainer con, String type, String path, String pointer, int blkNo, int blkRowIdx, MCItemDef[] itemdefs, MCItemSetter[] setters) {
/* 218 */     init(id, con, type, blkNo, itemdefs, setters);
/* 219 */     this.blkRowIdx = blkRowIdx;
/* 220 */     this.path = path;
/* 221 */     this.pointer = pointer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String id() {
/* 233 */     return this.id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String type() {
/* 244 */     return this.type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String pointer() {
/* 255 */     return this.pointer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCContainer container() {
/* 266 */     return this.container;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String path() {
/* 277 */     return this.path;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int blkNo() {
/* 288 */     return this.blkNo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int blkRowIdx() {
/* 299 */     return this.blkRowIdx;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rollBlkRowIdx() {
/* 309 */     this.blkRowIdx++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCItemDef[] itemDefs() {
/* 320 */     return this.itemdefs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCItemSetter[] setters() {
/* 331 */     return this.setters;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\param\MCContainerEntry.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */