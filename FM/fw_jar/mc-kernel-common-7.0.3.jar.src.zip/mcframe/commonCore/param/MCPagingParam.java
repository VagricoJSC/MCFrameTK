/*    */ package mcframe.commonCore.param;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import mcframe.commonCore.lang.MCNumber;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCPagingParam
/*    */ {
/* 42 */   private final List<MCPagingRowParam> paging = new ArrayList<>();
/* 43 */   private final List<MCPagingSortParam> sort = new ArrayList<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isEnabled() {
/* 54 */     return (this.paging.size() > 0);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isFirst() {
/* 65 */     if (!isEnabled()) {
/* 66 */       return false;
/*    */     }
/*    */     
/* 69 */     return MCNumber.valueOf(-1).eq((BigDecimal)((MCPagingRowParam)this.paging.get(0)).getTotalSize());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<MCPagingRowParam> getPagingRowParamList() {
/* 80 */     return this.paging;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<MCPagingSortParam> getPagingSortParamList() {
/* 91 */     return this.sort;
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\param\MCPagingParam.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */