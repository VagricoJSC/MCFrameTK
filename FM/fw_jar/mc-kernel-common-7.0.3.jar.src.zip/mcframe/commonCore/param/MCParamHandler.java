package mcframe.commonCore.param;

public interface MCParamHandler {
  void handle(MCParam paramMCParam);
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\param\MCParamHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */