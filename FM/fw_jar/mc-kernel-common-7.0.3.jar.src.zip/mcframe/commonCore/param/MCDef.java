/*     */ package mcframe.commonCore.param;
/*     */ 
/*     */ import java.util.Map;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MCDef
/*     */ {
/*  24 */   private static MCDefaultContainerDef defaultDef = new MCDefaultContainerDef();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract MCContainerDef getCustomDef(String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCContainerDef getDef(String id) {
/*  48 */     MCContainerDef def = getCustomDef(id);
/*  49 */     if (def == null) {
/*  50 */       throw new MCException(Core_Msg_FW_A.FCBGC0018, new Object[] { id });
/*     */     }
/*  52 */     return def;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCContainerDef getDefNE(String id) {
/*  63 */     MCContainerDef def = getCustomDef(id);
/*  64 */     return def;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toDefId(MCParam param, boolean isUp, int block) {
/*  83 */     if (param == null) {
/*  84 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  89 */     if (param.id() != null) {
/*  90 */       return toDefId(param.id(), isUp, block);
/*     */     }
/*     */     
/*  93 */     return toDefId(param.getModuleId(), 
/*  94 */         param.getLogicId(), 
/*  95 */         param.getOperationId(), 
/*  96 */         isUp, 
/*  97 */         block);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toDefId(String moduleId, String logicId, String operationId, boolean isUp, int block) {
/* 119 */     if (moduleId == null || logicId == null || operationId == null) {
/* 120 */       return null;
/*     */     }
/*     */     
/* 123 */     String aSuffix = String.valueOf(moduleId) + 
/* 124 */       "." + 
/* 125 */       logicId + 
/* 126 */       "." + 
/* 127 */       operationId;
/*     */     
/* 129 */     return toDefId(aSuffix, isUp, block);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String toDefId(String suffix, boolean isUp, int block) {
/* 146 */     if (suffix == null) {
/* 147 */       return null;
/*     */     }
/*     */     
/* 150 */     if (isUp) {
/* 151 */       return String.valueOf(suffix) + 
/* 152 */         "." + 
/* 153 */         "UP" + 
/* 154 */         "." + 
/* 155 */         "BLOCK" + String.valueOf(block);
/*     */     }
/* 157 */     return String.valueOf(suffix) + 
/* 158 */       "." + 
/* 159 */       "DOWN" + 
/* 160 */       "." + 
/* 161 */       "BLOCK" + String.valueOf(block);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCItemDef[] convToCltDef(Map<String, MCItemDef> clt, MCItemDef[] common) {
/* 176 */     MCItemDef[] ret = new MCItemDef[common.length];
/* 177 */     for (int i = 0; i < common.length; i++) {
/* 178 */       MCItemDef itm = clt.get((common[i]).id);
/* 179 */       if (itm == null) {
/* 180 */         ret[i] = MCItemDef.IGNORE_ITEM;
/*     */       } else {
/*     */         
/* 183 */         ret[i] = itm;
/*     */       } 
/*     */     } 
/* 186 */     return ret;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\param\MCDef.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */