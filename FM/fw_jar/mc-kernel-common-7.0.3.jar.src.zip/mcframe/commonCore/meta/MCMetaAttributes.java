/*    */ package mcframe.commonCore.meta;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import mcframe.commonCore.lang.MCDate;
/*    */ import mcframe.commonCore.lang.MCNumber;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MCMetaAttributes
/*    */ {
/*    */   private final Map<String, Object> attrs;
/*    */   
/*    */   public MCMetaAttributes() {
/* 21 */     this.attrs = new HashMap<>();
/*    */   }
/*    */   public MCMetaAttributes(Map<String, Object> attrs) {
/* 24 */     this.attrs = new HashMap<>(attrs);
/*    */   }
/*    */   
/*    */   public String getString(String key) {
/* 28 */     return (String)this.attrs.get(key);
/*    */   }
/*    */   
/*    */   public boolean getBoolean(String key) {
/* 32 */     return ((Boolean)this.attrs.get(key)).booleanValue();
/*    */   }
/*    */   
/*    */   public MCNumber getNumber(String key) {
/* 36 */     return (MCNumber)this.attrs.get(key);
/*    */   }
/*    */   
/*    */   public MCDate getDate(String key) {
/* 40 */     return (MCDate)this.attrs.get(key);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\meta\MCMetaAttributes.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */