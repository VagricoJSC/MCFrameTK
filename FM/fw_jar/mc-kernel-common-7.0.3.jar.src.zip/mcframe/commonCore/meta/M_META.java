package mcframe.commonCore.meta;

import mcframe.commonCore.annotation.EI;

@EI
public class M_META extends M_META_FW_A {}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\meta\M_META.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */