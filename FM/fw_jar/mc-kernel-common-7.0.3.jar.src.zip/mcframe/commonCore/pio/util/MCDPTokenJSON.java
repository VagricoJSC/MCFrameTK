/*     */ package mcframe.commonCore.pio.util;
/*     */ 
/*     */ import com.fasterxml.jackson.core.JsonParseException;
/*     */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*     */ import com.fasterxml.jackson.databind.JsonMappingException;
/*     */ import com.fasterxml.jackson.databind.JsonNode;
/*     */ import com.fasterxml.jackson.databind.ObjectMapper;
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.util.MCCollectionUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCDPTokenJSON
/*     */   extends MCDPToken
/*     */ {
/*     */   private static final String KEY = "key";
/*     */   private static final String VAL = "val";
/*     */   private static final String BLK_DISPATCH = "dispatch";
/*     */   private static final String HDR_UPPARAM = "upHeaderParam";
/*     */   private static final String ERR_WSMSG = "wsMessage";
/*     */   private static final String ERR_CAUSEMSG = "causeWsMessageArray";
/*     */   private static final String PRE_UP = "up";
/*     */   private static final String PRE_DOWN = "down";
/*     */   private static final String PRE_ERR = "err";
/* 104 */   private JsonNode _root = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 111 */   private String _position = "";
/* 112 */   private int _rowposition = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean _up;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean _err;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCDPTokenJSON(String json) {
/*     */     try {
/* 140 */       this._root = parse(json);
/* 141 */       this._err = this._root.has("err");
/* 142 */       this._up = this._root.has("up");
/* 143 */       if (!this._up && 
/* 144 */         !this._err && !this._root.has("down"))
/*     */       {
/* 146 */         throw new MCException(Core_Msg_FW_A.FCBGC0288, new Object[] { "header not_found" });
/*     */       }
/*     */       
/* 149 */       if (this._up && this._err)
/*     */       {
/* 151 */         throw new MCException(Core_Msg_FW_A.FCBGC0282, new Object[0]);
/*     */       }
/*     */     }
/* 154 */     catch (MCException e) {
/*     */       
/* 156 */       throw new MCException(e, Core_Msg_FW_A.FCBGC0016, new Object[] { e.getID(), e.getMCMessage() });
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public MCDPFormat getFormat() {
/* 162 */     return MCDPFormat.JSON;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUp() {
/* 173 */     return this._up;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isErr() {
/* 184 */     return this._err;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getPrefix() {
/* 195 */     return this._up ? "up" : (this._err ? "err" : "down");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JsonNode parse(String json) {
/* 208 */     long start = System.currentTimeMillis();
/*     */ 
/*     */     
/* 211 */     ObjectMapper mapper = new ObjectMapper();
/*     */     
/* 213 */     mapper.enable(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS);
/*     */     
/*     */     try {
/* 216 */       return (JsonNode)mapper.readValue(json, JsonNode.class);
/*     */     }
/* 218 */     catch (JsonParseException e) {
/* 219 */       throw new MCException(e, Core_Msg_FW_A.FCBGC0089, new Object[0]);
/*     */     }
/* 221 */     catch (JsonMappingException e) {
/* 222 */       throw new MCException(e, Core_Msg_FW_A.FCBGC0089, new Object[0]);
/*     */     }
/* 224 */     catch (IOException e) {
/* 225 */       throw new MCException(e, Core_Msg_FW_A.FCBGC0089, new Object[0]);
/*     */     } finally {
/*     */       
/* 228 */       String TRC_ID = Core_Msg_FW_A.FCBGC0294;
/* 229 */       long end = System.currentTimeMillis();
/* 230 */       if (MCLog.isEnabled(TRC_ID)) {
/* 231 */         MCLog.write(TRC_ID, new Object[] { String.valueOf(end - start) });
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] toArray(JsonNode node, int size) {
/* 248 */     if (node == null || !node.isArray()) {
/*     */       
/* 250 */       this._position = "(not_array) " + this._position;
/* 251 */       return null;
/*     */     } 
/* 253 */     if (node.size() != size) {
/*     */       
/* 255 */       this._position = "(invalid_menber_count(" + size + "/" + node.size() + ")) " + this._position;
/* 256 */       return null;
/*     */     } 
/* 258 */     String[] array = new String[size];
/* 259 */     for (int i = 0; i < size; i++) {
/*     */       
/* 261 */       JsonNode item = node.get(i);
/* 262 */       array[i] = item.isNull() ? null : item.asText();
/*     */       
/* 264 */       if (array[i] != null && array[i].length() == 0) {
/* 265 */         array[i] = null;
/*     */       }
/*     */     } 
/* 268 */     return array;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] getKeys(JsonNode node) {
/* 280 */     this._position = String.valueOf(this._position) + " key";
/* 281 */     this._rowposition = -1;
/*     */     
/* 283 */     JsonNode keys = node.get("key");
/* 284 */     if (keys == null)
/*     */     {
/* 286 */       return new String[0];
/*     */     }
/* 288 */     if (!keys.isArray()) {
/*     */       
/* 290 */       this._position = "(not_array) " + this._position;
/* 291 */       return null;
/*     */     } 
/* 293 */     int size = keys.size();
/* 294 */     return toArray(keys, size);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[][] getVals(JsonNode node, int size) {
/* 309 */     this._position = String.valueOf(this._position) + " val";
/* 310 */     this._rowposition = -1;
/*     */     
/* 312 */     JsonNode vals = node.get("val");
/* 313 */     if (vals == null)
/*     */     {
/* 315 */       return new String[0][];
/*     */     }
/* 317 */     if (!vals.isArray()) {
/*     */       
/* 319 */       this._position = "(not_array) " + this._position;
/* 320 */       return null;
/*     */     } 
/* 322 */     String[][] valsArray = null;
/* 323 */     JsonNode topval = vals.get(0);
/* 324 */     if (topval != null && !topval.isArray()) {
/*     */       
/* 326 */       this._rowposition = 0;
/* 327 */       valsArray = new String[1][];
/* 328 */       valsArray[0] = toArray(vals, size);
/*     */     }
/*     */     else {
/*     */       
/* 332 */       int len = vals.size();
/* 333 */       valsArray = new String[len][];
/* 334 */       for (int i = 0; i < len; i++) {
/* 335 */         this._rowposition = i;
/* 336 */         JsonNode child = vals.get(i);
/* 337 */         valsArray[i] = toArray(child, size);
/*     */       } 
/*     */     } 
/* 340 */     return valsArray;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, Integer> createKeyMap(JsonNode node) {
/* 352 */     String[] keys = getKeys(node);
/* 353 */     Map<String, Integer> map = new HashMap<>(keys.length);
/* 354 */     for (int i = 0; i < keys.length; i++) {
/* 355 */       map.put(keys[i], Integer.valueOf(i));
/*     */     }
/* 357 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Integer> getKeyMap(int index) {
/* 373 */     String block = String.valueOf(getPrefix()) + index;
/* 374 */     this._position = block;
/* 375 */     this._rowposition = -1;
/*     */     
/* 377 */     if (this._err) {
/*     */       
/* 379 */       this._position = "(error_param) " + this._position;
/* 380 */       return null;
/*     */     } 
/*     */     
/* 383 */     JsonNode cont = this._root.get(block);
/* 384 */     if (cont == null) {
/*     */       
/* 386 */       this._position = "(not_found) " + this._position;
/* 387 */       return null;
/*     */     } 
/*     */     
/* 390 */     return createKeyMap(cont);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[][] getValues(Map<String, Integer> keymap, int index) {
/* 406 */     String block = String.valueOf(getPrefix()) + index;
/* 407 */     this._position = block;
/* 408 */     this._rowposition = -1;
/*     */     
/* 410 */     if (this._err) {
/*     */       
/* 412 */       this._position = "(error_param) " + this._position;
/* 413 */       return null;
/*     */     } 
/* 415 */     JsonNode cont = this._root.get(block);
/* 416 */     if (cont == null) {
/*     */       
/* 418 */       this._position = "(not_found) " + this._position;
/* 419 */       return null;
/*     */     } 
/* 421 */     if (keymap == null) {
/*     */       
/* 423 */       this._position = "(null_key) " + this._position;
/* 424 */       return null;
/*     */     } 
/*     */     
/* 427 */     return getVals(cont, keymap.size());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Integer> getHeaderKeyMap(String child) {
/* 443 */     this._position = "header " + child;
/* 444 */     this._rowposition = -1;
/*     */     
/* 446 */     JsonNode block = this._root.get(getPrefix());
/* 447 */     JsonNode header = block.get(child);
/* 448 */     if (header == null) {
/*     */       
/* 450 */       this._position = "(not_found) " + this._position;
/* 451 */       return null;
/*     */     } 
/*     */     
/* 454 */     return createKeyMap(header);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[][] getHeaderValues(String child, Map<String, Integer> keymap) {
/* 468 */     this._position = "header";
/* 469 */     this._rowposition = -1;
/*     */     
/* 471 */     JsonNode block = this._root.get(getPrefix());
/* 472 */     JsonNode header = block.get(child);
/* 473 */     if (header == null) {
/*     */       
/* 475 */       this._position = "(not_found) " + this._position;
/* 476 */       return null;
/*     */     } 
/*     */     
/* 479 */     if (keymap == null) {
/*     */       
/* 481 */       this._position = "(null_key) " + this._position;
/* 482 */       return null;
/*     */     } 
/*     */     
/* 485 */     String[][] vals = getVals(header, keymap.size());
/*     */     
/* 487 */     if (child.equals("upHeaderParam")) {
/*     */       
/* 489 */       JsonNode dispatch = this._root.get("dispatch");
/* 490 */       if (dispatch != null) {
/* 491 */         int pos = keymap.size();
/* 492 */         vals[0] = Arrays.<String>copyOf(vals[0], pos + dispatch.size());
/* 493 */         Iterator<String> ite = dispatch.fieldNames();
/* 494 */         while (ite.hasNext()) {
/* 495 */           String field = ite.next();
/* 496 */           keymap.put(field, Integer.valueOf(pos));
/* 497 */           vals[0][pos++] = dispatch.get(field).textValue();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 502 */     return vals;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Integer> getMessageKeyMap(String child, String grandchild) {
/* 519 */     this._position = "header " + child;
/* 520 */     this._rowposition = -1;
/*     */     
/* 522 */     JsonNode block = this._root.get(getPrefix());
/* 523 */     JsonNode message = block.get(child);
/* 524 */     if (message == null) {
/*     */       
/* 526 */       this._position = "(not_found) " + this._position;
/* 527 */       return null;
/*     */     } 
/*     */     
/* 530 */     this._position = String.valueOf(this._position) + " " + grandchild;
/* 531 */     JsonNode marray = message.get(grandchild);
/* 532 */     if (marray == null) {
/*     */       
/* 534 */       this._position = "(not_found) " + this._position;
/* 535 */       return null;
/*     */     } 
/*     */     
/* 538 */     return createKeyMap(marray);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[][] getMessageValues(String child, String grandchild, Map<String, Integer> keymap) {
/* 553 */     this._position = "header";
/* 554 */     this._rowposition = -1;
/*     */     
/* 556 */     JsonNode block = this._root.get(getPrefix());
/* 557 */     JsonNode message = block.get(child);
/* 558 */     if (message == null) {
/*     */       
/* 560 */       this._position = "(not_found) " + this._position;
/* 561 */       return null;
/*     */     } 
/*     */     
/* 564 */     this._position = String.valueOf(this._position) + " " + grandchild;
/* 565 */     JsonNode marray = message.get(grandchild);
/* 566 */     if (marray == null) {
/*     */       
/* 568 */       this._position = "(not_found) " + this._position;
/* 569 */       return null;
/*     */     } 
/*     */     
/* 572 */     if (keymap == null) {
/*     */       
/* 574 */       this._position = "(null_key) " + this._position;
/* 575 */       return null;
/*     */     } 
/*     */     
/* 578 */     return getVals(marray, keymap.size());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Integer> getErrorKeyMap() {
/* 590 */     this._position = "err";
/* 591 */     this._rowposition = -1;
/*     */     
/* 593 */     JsonNode err = this._root.get("err");
/* 594 */     if (err == null) {
/*     */       
/* 596 */       this._position = "(not_found) " + this._position;
/* 597 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 601 */     JsonNode message = err.get("wsMessage");
/* 602 */     if (message == null) {
/*     */       
/* 604 */       this._position = "(wsMessage not_found) " + this._position;
/* 605 */       return null;
/*     */     } 
/*     */     
/* 608 */     return createKeyMap(message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[][] getErrorValues(Map<String, Integer> keymap) {
/* 623 */     this._position = "err";
/* 624 */     this._rowposition = -1;
/*     */     
/* 626 */     JsonNode err = this._root.get("err");
/* 627 */     if (err == null) {
/*     */       
/* 629 */       this._position = "(not_found) " + this._position;
/* 630 */       return null;
/*     */     } 
/*     */     
/* 633 */     if (keymap == null) {
/*     */       
/* 635 */       this._position = "(null_key) " + this._position;
/* 636 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 640 */     JsonNode message = err.get("wsMessage");
/* 641 */     if (message == null) {
/*     */       
/* 643 */       this._position = "(wsMessage not_found) " + this._position;
/* 644 */       return null;
/*     */     } 
/*     */     
/* 647 */     String[][] msgvals = getVals(message, keymap.size());
/* 648 */     if (msgvals.length > 1) {
/*     */       
/* 650 */       this._position = "(multi_errline) " + this._position;
/* 651 */       return null;
/*     */     } 
/*     */ 
/*     */     
/* 655 */     JsonNode cause = err.get("causeWsMessageArray");
/* 656 */     if (cause != null) {
/* 657 */       String[][] cauvals = getVals(cause, keymap.size());
/* 658 */       msgvals = (String[][])MCCollectionUtil.concat((Object[][])new String[][][] { msgvals, cauvals });
/*     */     } 
/*     */     
/* 661 */     return msgvals;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, Integer> getPagingKeyMap(String child, String grandchild) {
/* 678 */     this._position = "header " + child;
/* 679 */     this._rowposition = -1;
/*     */     
/* 681 */     JsonNode block = this._root.get(getPrefix());
/* 682 */     JsonNode paging = block.get(child);
/* 683 */     if (paging == null) {
/*     */       
/* 685 */       this._position = "(not_found) " + this._position;
/* 686 */       return null;
/*     */     } 
/*     */     
/* 689 */     this._position = String.valueOf(this._position) + " " + grandchild;
/* 690 */     JsonNode parray = paging.get(grandchild);
/* 691 */     if (parray == null) {
/*     */       
/* 693 */       this._position = "(not_found) " + this._position;
/* 694 */       return null;
/*     */     } 
/*     */     
/* 697 */     return createKeyMap(parray);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[][] getPagingValues(String child, String grandchild, Map<String, Integer> keymap) {
/* 712 */     this._position = "header";
/* 713 */     this._rowposition = -1;
/*     */     
/* 715 */     JsonNode block = this._root.get(getPrefix());
/* 716 */     JsonNode paging = block.get(child);
/* 717 */     if (paging == null) {
/*     */       
/* 719 */       this._position = "(not_found) " + this._position;
/* 720 */       return null;
/*     */     } 
/*     */     
/* 723 */     this._position = String.valueOf(this._position) + " " + grandchild;
/* 724 */     JsonNode parray = paging.get(grandchild);
/* 725 */     if (parray == null) {
/*     */       
/* 727 */       this._position = "(not_found) " + this._position;
/* 728 */       return null;
/*     */     } 
/*     */     
/* 731 */     if (keymap == null) {
/*     */       
/* 733 */       this._position = "(null_key) " + this._position;
/* 734 */       return null;
/*     */     } 
/*     */     
/* 737 */     return getVals(parray, keymap.size());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String position() {
/* 750 */     return (this._rowposition < 0) ? this._position : (String.valueOf(this._position) + this._rowposition);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\pi\\util\MCDPTokenJSON.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */