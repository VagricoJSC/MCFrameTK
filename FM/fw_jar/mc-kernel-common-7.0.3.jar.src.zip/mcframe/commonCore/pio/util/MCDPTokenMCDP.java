/*     */ package mcframe.commonCore.pio.util;
/*     */ 
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCDPTokenMCDP
/*     */   extends MCDPToken
/*     */ {
/*     */   public static final String LINE_END = "LineEnd...";
/*     */   private final char[] chars;
/*     */   private final int charlen;
/*     */   private int nextpos;
/*     */   private int line;
/*     */   private int col;
/*     */   private final CharBuf _charbuf;
/*     */   
/*     */   public MCDPFormat getFormat() {
/*  22 */     return MCDPFormat.MCDP;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class CharBuf
/*     */   {
/*     */     private char[] _buf;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  44 */     private int _len = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     CharBuf(int len) {
/*  53 */       this._buf = new char[len];
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void add(char ch) {
/*  63 */       int buflen = this._buf.length;
/*  64 */       if (buflen <= this._len) {
/*  65 */         char[] newbuf = new char[buflen * 2];
/*  66 */         System.arraycopy(this._buf, 0, newbuf, 0, buflen);
/*  67 */         this._buf = newbuf;
/*     */       } 
/*  69 */       this._buf[this._len++] = ch;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void clear() {
/*  78 */       this._len = 0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 101 */       return (this._len != 0) ? new String(this._buf, 0, this._len) : null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCDPTokenMCDP(String mcdp) {
/* 166 */     this.chars = (mcdp == null) ? new char[0] : mcdp.toCharArray();
/* 167 */     this.charlen = this.chars.length;
/* 168 */     this.nextpos = 0;
/* 169 */     this.line = 0;
/* 170 */     this.col = 0;
/* 171 */     this._charbuf = new CharBuf(1024);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/* 182 */     return (this.nextpos < this.charlen);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean nextTokenIsTag() {
/* 193 */     return (this.nextpos < this.charlen && this.chars[this.nextpos] == '<');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean nextTokenIsLnEnd() {
/* 204 */     return (this.nextpos < this.charlen && this.chars[this.nextpos] == '\n');
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean nextTokenIsComment() {
/* 216 */     if (this.nextpos < this.charlen - 3) {
/* 217 */       return (this.chars[this.nextpos] == '<' && 
/* 218 */         this.chars[this.nextpos + 1] == '#' && 
/* 219 */         this.chars[this.nextpos + 2] == '>');
/*     */     }
/*     */     
/* 222 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int line() {
/* 233 */     return this.line;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int column() {
/* 244 */     return this.col;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String position() {
/* 256 */     return "Line:" + (this.line + 1) + " Column:" + this.col;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String nextToken() {
/* 273 */     this._charbuf.clear();
/* 274 */     while (this.nextpos < this.charlen) {
/* 275 */       char ch = this.chars[this.nextpos++];
/*     */ 
/*     */       
/* 278 */       if (ch == '`') {
/* 279 */         if (this.nextpos >= this.charlen) {
/*     */           break;
/*     */         }
/*     */ 
/*     */         
/* 284 */         ch = this.chars[this.nextpos++];
/* 285 */         switch (ch) {
/*     */           
/*     */           case 'n':
/* 288 */             this._charbuf.add('\n');
/*     */             continue;
/*     */ 
/*     */           
/*     */           case 'r':
/* 293 */             this._charbuf.add('\r');
/*     */             continue;
/*     */         } 
/*     */         
/* 297 */         this._charbuf.add(ch);
/*     */ 
/*     */         
/*     */         continue;
/*     */       } 
/*     */ 
/*     */       
/* 304 */       if (ch == '\n') {
/*     */         
/* 306 */         this.line++;
/* 307 */         this.col = 0;
/* 308 */         return "LineEnd...";
/*     */       } 
/*     */ 
/*     */       
/* 312 */       if (ch == ';') {
/* 313 */         this.col++;
/* 314 */         return this._charbuf.toString();
/*     */       } 
/*     */ 
/*     */       
/* 318 */       this._charbuf.add(ch);
/*     */     } 
/*     */     
/* 321 */     throw new MCException(Core_Msg_FW_A.FCBGC0089, new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void nextTokenNE() {
/*     */     try {
/* 333 */       nextToken();
/*     */     }
/* 335 */     catch (MCException mCException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toStringNext() {
/* 348 */     return new String(this.chars, this.nextpos, this.charlen - this.nextpos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void nextLine() {
/* 363 */     while (this.nextpos < this.charlen) {
/* 364 */       char ch = this.chars[this.nextpos++];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 379 */       if (ch == '\n') {
/* 380 */         this.line++;
/* 381 */         this.col = 0;
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean skipCommentLine() {
/* 399 */     boolean skip = nextTokenIsComment();
/* 400 */     while (nextTokenIsComment()) {
/* 401 */       nextLine();
/*     */     }
/* 403 */     return skip;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\pi\\util\MCDPTokenMCDP.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */