/*    */ package mcframe.commonCore.pio.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum MCDPParseType
/*    */ {
/* 10 */   NOMAL,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 16 */   LISTLOGIC;
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\pi\\util\MCDPParseType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */