/*    */ package mcframe.commonCore.pio.util;
/*    */ 
/*    */ import mcframe.commonCore.param.MCParam;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCParseTypeUtil
/*    */ {
/*    */   public static MCDPParseType getParseType(MCParam param) {
/* 20 */     MCDPParseType pt = MCDPParseType.NOMAL;
/* 21 */     if (isListLogic2(param)) {
/* 22 */       pt = MCDPParseType.LISTLOGIC;
/*    */     }
/* 24 */     return pt;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static boolean isListLogic2(MCParam p) {
/* 33 */     return ("FC".equals(p.getModuleId()) && 
/* 34 */       "FCBAL1000".equals(p.getLogicId()) && (
/* 35 */       "Srch03".equals(p.getOperationId()) || "Srch04".equals(p
/* 36 */         .getOperationId())));
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\pi\\util\MCParseTypeUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */