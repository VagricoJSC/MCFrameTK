/*    */ package mcframe.commonCore.pio.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class MCDPToken
/*    */ {
/*    */   public static MCDPToken create(String text) {
/* 28 */     if (text.charAt(0) == '{')
/*    */     {
/* 30 */       return new MCDPTokenJSON(text);
/*    */     }
/*    */     
/* 33 */     return new MCDPTokenMCDP(text);
/*    */   }
/*    */   
/*    */   public abstract MCDPFormat getFormat();
/*    */   
/*    */   public abstract String position();
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\pi\\util\MCDPToken.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */