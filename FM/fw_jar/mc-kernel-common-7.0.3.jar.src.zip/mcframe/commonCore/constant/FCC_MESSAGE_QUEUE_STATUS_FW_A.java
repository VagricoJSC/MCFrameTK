/*     */ package mcframe.commonCore.constant;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.notice.MCAppException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class FCC_MESSAGE_QUEUE_STATUS_FW_A
/*     */   extends MCRootConst
/*     */ {
/*     */   public static final String moduleID = "FC";
/*     */   public static final String typeID = "MESSAGE_QUEUE_STATUS";
/*  32 */   protected MCRow constR = MCRow.create();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static FCC_MESSAGE_QUEUE_STATUS[] array;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String $VALUE = "message_queue_status";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String $NAME = "message_queue_status_nm";
/*     */ 
/*     */ 
/*     */   
/*  51 */   public static final FCC_MESSAGE_QUEUE_STATUS WAIT_FOR_EXECUTION = create("1", "WAIT_FOR_EXECUTION");
/*     */ 
/*     */ 
/*     */   
/*  55 */   public static final FCC_MESSAGE_QUEUE_STATUS WAIT_FOR_REPLAY = create("2", "WAIT_FOR_REPLAY");
/*     */ 
/*     */ 
/*     */   
/*  59 */   public static final FCC_MESSAGE_QUEUE_STATUS RUNNING = create("3", "RUNNING");
/*     */ 
/*     */ 
/*     */   
/*  63 */   public static final FCC_MESSAGE_QUEUE_STATUS NORMAL_END = create("4", "NORMAL_END");
/*     */ 
/*     */ 
/*     */   
/*  67 */   public static final FCC_MESSAGE_QUEUE_STATUS ABNORMAL_END = create("5", "ABNORMAL_END");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static FCC_MESSAGE_QUEUE_STATUS create() {
/*  73 */     return new FCC_MESSAGE_QUEUE_STATUS();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FCC_MESSAGE_QUEUE_STATUS get(String value) {
/*  84 */     FCC_MESSAGE_QUEUE_STATUS type = FCC_MESSAGE_QUEUE_STATUS.getNE(value);
/*  85 */     if (type == null) {
/*  86 */       throw FCC_MESSAGE_QUEUE_STATUS.invalidValue(value);
/*     */     }
/*  88 */     return type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FCC_MESSAGE_QUEUE_STATUS getNE(String value) {
/*     */     byte b;
/*     */     int i;
/*     */     FCC_MESSAGE_QUEUE_STATUS[] arrayOfFCC_MESSAGE_QUEUE_STATUS;
/*  99 */     for (i = (arrayOfFCC_MESSAGE_QUEUE_STATUS = FCC_MESSAGE_QUEUE_STATUS.array()).length, b = 0; b < i; ) { FCC_MESSAGE_QUEUE_STATUS me = arrayOfFCC_MESSAGE_QUEUE_STATUS[b];
/* 100 */       if (isSame(me.value(), value))
/* 101 */         return me; 
/*     */       b++; }
/*     */     
/* 104 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static FCC_MESSAGE_QUEUE_STATUS create(String value, String xmlKey) {
/* 111 */     FCC_MESSAGE_QUEUE_STATUS me = FCC_MESSAGE_QUEUE_STATUS.create();
/* 112 */     me.xmlKey = xmlKey;
/* 113 */     me.constR.addStringColumn("message_queue_status", value);
/* 114 */     return me;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String moduleID() {
/* 122 */     return "FC";
/*     */   }
/*     */ 
/*     */   
/*     */   protected String typeID() {
/* 127 */     return "MESSAGE_QUEUE_STATUS";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String value() {
/* 140 */     return this.constR.getString("message_queue_status");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean contains(String value) {
/* 149 */     FCC_MESSAGE_QUEUE_STATUS me = FCC_MESSAGE_QUEUE_STATUS.getNE(value);
/* 150 */     if (me != null) {
/* 151 */       return true;
/*     */     }
/*     */     
/* 154 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void containsEx(String value) {
/* 163 */     FCC_MESSAGE_QUEUE_STATUS me = FCC_MESSAGE_QUEUE_STATUS.getNE(value);
/* 164 */     if (me == null) {
/* 165 */       throw FCC_MESSAGE_QUEUE_STATUS.invalidValue(value);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void containsEx(String value, String msgid, Object... binds) {
/* 176 */     FCC_MESSAGE_QUEUE_STATUS me = FCC_MESSAGE_QUEUE_STATUS.getNE(value);
/* 177 */     if (me == null) {
/* 178 */       if (binds == null) {
/* 179 */         throw new MCAppException(msgid, new Object[] { value });
/*     */       }
/* 181 */       throw new MCAppException(msgid, binds);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 191 */     return createStringPath(new Object[] { value(), name() });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FCC_MESSAGE_QUEUE_STATUS[] array() {
/* 199 */     if (array == null) {
/* 200 */       array = new FCC_MESSAGE_QUEUE_STATUS[] {
/* 201 */           FCC_MESSAGE_QUEUE_STATUS.WAIT_FOR_EXECUTION, FCC_MESSAGE_QUEUE_STATUS.WAIT_FOR_REPLAY, FCC_MESSAGE_QUEUE_STATUS.RUNNING, FCC_MESSAGE_QUEUE_STATUS.NORMAL_END, FCC_MESSAGE_QUEUE_STATUS.ABNORMAL_END
/*     */         };
/*     */     }
/* 204 */     return array;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCList<MCRow> list() {
/* 212 */     MCList<MCRow> list = MCList.create(MCRow.class); byte b; int i; FCC_MESSAGE_QUEUE_STATUS[] arrayOfFCC_MESSAGE_QUEUE_STATUS;
/* 213 */     for (i = (arrayOfFCC_MESSAGE_QUEUE_STATUS = FCC_MESSAGE_QUEUE_STATUS.array()).length, b = 0; b < i; ) { FCC_MESSAGE_QUEUE_STATUS me = arrayOfFCC_MESSAGE_QUEUE_STATUS[b];
/* 214 */       MCRow r = MCRow.create();
/* 215 */       r.addStringColumn("message_queue_status", me.value());
/* 216 */       r.addStringColumn("message_queue_status_nm", me.name());
/* 217 */       list.add(r); b++; }
/*     */     
/* 219 */     return list;
/*     */   }
/*     */ 
/*     */   
/*     */   protected static String value(String key) {
/*     */     byte b;
/*     */     int i;
/*     */     FCC_MESSAGE_QUEUE_STATUS[] arrayOfFCC_MESSAGE_QUEUE_STATUS;
/* 227 */     for (i = (arrayOfFCC_MESSAGE_QUEUE_STATUS = FCC_MESSAGE_QUEUE_STATUS.array()).length, b = 0; b < i; ) { FCC_MESSAGE_QUEUE_STATUS me = arrayOfFCC_MESSAGE_QUEUE_STATUS[b];
/* 228 */       if (me.key().equals(key))
/* 229 */         return me.value(); 
/*     */       b++; }
/*     */     
/* 232 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static List<String> getKeys() {
/* 240 */     List<String> keys = new ArrayList<>(); byte b; int i; FCC_MESSAGE_QUEUE_STATUS[] arrayOfFCC_MESSAGE_QUEUE_STATUS;
/* 241 */     for (i = (arrayOfFCC_MESSAGE_QUEUE_STATUS = FCC_MESSAGE_QUEUE_STATUS.array()).length, b = 0; b < i; ) { FCC_MESSAGE_QUEUE_STATUS me = arrayOfFCC_MESSAGE_QUEUE_STATUS[b];
/* 242 */       keys.add(me.key()); b++; }
/*     */     
/* 244 */     return keys;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCList<MCRow> subList(MCRow row) {
/* 253 */     Map<String, Boolean> kl = new HashMap<>(); byte b; int i; String[] arrayOfString;
/* 254 */     for (i = (arrayOfString = row.getColumnPathArray()).length, b = 0; b < i; ) { String s = arrayOfString[b];
/* 255 */       if (FCC_MESSAGE_QUEUE_STATUS.getKeys().contains(s))
/* 256 */         kl.put(s, Boolean.valueOf(row.getBoolean(s))); 
/*     */       b++; }
/*     */     
/* 259 */     MCList<MCRow> list = MCList.create(MCRow.class);
/* 260 */     for (Map.Entry<String, Boolean> e : kl.entrySet()) {
/* 261 */       if (((Boolean)e.getValue()).booleanValue()) {
/* 262 */         FCC_MESSAGE_QUEUE_STATUS me = FCC_MESSAGE_QUEUE_STATUS.get(FCC_MESSAGE_QUEUE_STATUS.value(e.getKey()));
/* 263 */         MCRow r = list.createRow();
/* 264 */         r.addStringColumn("message_queue_status", me.value());
/* 265 */         r.addStringColumn("message_queue_status_nm", me.name());
/* 266 */         list.add(r);
/*     */       } 
/*     */     } 
/* 269 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCList<MCRow> list(MCRow row) {
/* 279 */     MCList<MCRow> list = FCC_MESSAGE_QUEUE_STATUS.subList(row);
/* 280 */     if (list.isEmpty()) {
/* 281 */       list = FCC_MESSAGE_QUEUE_STATUS.list();
/*     */     }
/* 283 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCList<MCRow> subList(String[] cols, Comparable[] vals) {
/* 294 */     MCList<MCRow> list = MCList.create(MCRow.class); byte b; int i; FCC_MESSAGE_QUEUE_STATUS[] arrayOfFCC_MESSAGE_QUEUE_STATUS;
/* 295 */     for (i = (arrayOfFCC_MESSAGE_QUEUE_STATUS = FCC_MESSAGE_QUEUE_STATUS.array()).length, b = 0; b < i; ) { FCC_MESSAGE_QUEUE_STATUS me = arrayOfFCC_MESSAGE_QUEUE_STATUS[b];
/* 296 */       if (FCC_MESSAGE_QUEUE_STATUS.isSameVals(me, cols, (Comparable<?>[])vals)) {
/* 297 */         MCRow r = MCRow.create();
/* 298 */         r.addStringColumn("message_queue_status", me.value());
/* 299 */         r.addStringColumn("message_queue_status_nm", me.name());
/* 300 */         list.add(r);
/*     */       }  b++; }
/*     */     
/* 303 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCList<MCRow> subList(Map<String, Comparable<?>> colValMap) {
/*     */     MCList<MCRow> list;
/* 314 */     if (colValMap != null && colValMap.size() > 0) {
/* 315 */       int s = colValMap.size();
/* 316 */       String[] cols = new String[s];
/* 317 */       Comparable[] vals = new Comparable[s];
/* 318 */       int i = 0;
/* 319 */       for (Map.Entry<String, Comparable<?>> e : colValMap.entrySet()) {
/* 320 */         cols[i] = e.getKey();
/* 321 */         vals[i] = e.getValue();
/* 322 */         i = 1;
/*     */       } 
/* 324 */       list = FCC_MESSAGE_QUEUE_STATUS.subList(cols, (Comparable<?>[])vals);
/*     */     } else {
/*     */       
/* 327 */       list = MCList.create(MCRow.class);
/*     */     } 
/* 329 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCList<MCRow> exptSubList(String col, Comparable[] vals) {
/* 340 */     MCList<MCRow> list = MCList.create(MCRow.class);
/* 341 */     String[] cols = { col };
/* 342 */     Comparable[] val = new Comparable[1]; byte b; int i; FCC_MESSAGE_QUEUE_STATUS[] arrayOfFCC_MESSAGE_QUEUE_STATUS;
/* 343 */     for (i = (arrayOfFCC_MESSAGE_QUEUE_STATUS = FCC_MESSAGE_QUEUE_STATUS.array()).length, b = 0; b < i; ) { FCC_MESSAGE_QUEUE_STATUS me = arrayOfFCC_MESSAGE_QUEUE_STATUS[b];
/* 344 */       boolean f = true; byte b1; int j; Comparable[] arrayOfComparable;
/* 345 */       for (j = (arrayOfComparable = vals).length, b1 = 0; b1 < j; ) { Comparable<?> v = arrayOfComparable[b1];
/* 346 */         val[0] = v;
/* 347 */         if (FCC_MESSAGE_QUEUE_STATUS.isSameVals(me, cols, (Comparable<?>[])val)) {
/* 348 */           f = false; break;
/*     */         } 
/*     */         b1++; }
/*     */       
/* 352 */       if (f) {
/* 353 */         MCRow r = MCRow.create();
/* 354 */         r.addStringColumn("message_queue_status", me.value());
/* 355 */         r.addStringColumn("message_queue_status_nm", me.name());
/* 356 */         list.add(r);
/*     */       }  b++; }
/*     */     
/* 359 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static boolean isSameVals(FCC_MESSAGE_QUEUE_STATUS me, String[] cols, Comparable[] vals) {
/*     */     int i;
/* 372 */     if (cols.length <= vals.length) { i = cols.length; }
/* 373 */     else { i = vals.length; }
/* 374 */      boolean f = true;
/* 375 */     for (int j = 0; j < i; j++) {
/* 376 */       String col = cols[j];
/* 377 */       Comparable<?> val = vals[j];
/* 378 */       if (!me.constR.contains(col)) throw new MCAppException("FCBBC0068", new Object[] { "FCC_MESSAGE_QUEUE_STATUS", col }); 
/* 379 */       Comparable<?> rVal = me.constR.getValue(col);
/* 380 */       if (!isSame(rVal, val)) {
/* 381 */         f = false;
/*     */         break;
/*     */       } 
/*     */     } 
/* 385 */     return f;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isSame(FCC_MESSAGE_QUEUE_STATUS type) {
/* 395 */     return (this == type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isWAIT_FOR_EXECUTION(String value) {
/* 407 */     FCC_MESSAGE_QUEUE_STATUS type = FCC_MESSAGE_QUEUE_STATUS.getNE(value);
/* 408 */     return FCC_MESSAGE_QUEUE_STATUS.WAIT_FOR_EXECUTION.isSame(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isWAIT_FOR_EXECUTION(FCC_MESSAGE_QUEUE_STATUS type) {
/* 417 */     return FCC_MESSAGE_QUEUE_STATUS.WAIT_FOR_EXECUTION.isSame(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isWAIT_FOR_REPLAY(String value) {
/* 426 */     FCC_MESSAGE_QUEUE_STATUS type = FCC_MESSAGE_QUEUE_STATUS.getNE(value);
/* 427 */     return FCC_MESSAGE_QUEUE_STATUS.WAIT_FOR_REPLAY.isSame(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isWAIT_FOR_REPLAY(FCC_MESSAGE_QUEUE_STATUS type) {
/* 436 */     return FCC_MESSAGE_QUEUE_STATUS.WAIT_FOR_REPLAY.isSame(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isRUNNING(String value) {
/* 445 */     FCC_MESSAGE_QUEUE_STATUS type = FCC_MESSAGE_QUEUE_STATUS.getNE(value);
/* 446 */     return FCC_MESSAGE_QUEUE_STATUS.RUNNING.isSame(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isRUNNING(FCC_MESSAGE_QUEUE_STATUS type) {
/* 455 */     return FCC_MESSAGE_QUEUE_STATUS.RUNNING.isSame(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isNORMAL_END(String value) {
/* 464 */     FCC_MESSAGE_QUEUE_STATUS type = FCC_MESSAGE_QUEUE_STATUS.getNE(value);
/* 465 */     return FCC_MESSAGE_QUEUE_STATUS.NORMAL_END.isSame(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isNORMAL_END(FCC_MESSAGE_QUEUE_STATUS type) {
/* 474 */     return FCC_MESSAGE_QUEUE_STATUS.NORMAL_END.isSame(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isABNORMAL_END(String value) {
/* 483 */     FCC_MESSAGE_QUEUE_STATUS type = FCC_MESSAGE_QUEUE_STATUS.getNE(value);
/* 484 */     return FCC_MESSAGE_QUEUE_STATUS.ABNORMAL_END.isSame(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isABNORMAL_END(FCC_MESSAGE_QUEUE_STATUS type) {
/* 493 */     return FCC_MESSAGE_QUEUE_STATUS.ABNORMAL_END.isSame(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getGrpName() {
/* 500 */     return getGrpName("FC", "MESSAGE_QUEUE_STATUS");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getGrpName(Locale lcl) {
/* 508 */     return getGrpName(lcl, "FC", "MESSAGE_QUEUE_STATUS");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getGrpRmrks() {
/* 515 */     return getGrpRmrks("FC", "MESSAGE_QUEUE_STATUS");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getGrpRmrks(Locale lcl) {
/* 523 */     return getGrpRmrks(lcl, "FC", "MESSAGE_QUEUE_STATUS");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <E extends MCRow> void putName(MCList<E> list, String valueColumn, String nameColumn) {
/* 540 */     for (MCRow r : list) {
/* 541 */       FCC_MESSAGE_QUEUE_STATUS.putName(r, valueColumn, nameColumn);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <E extends MCRow> void putName(E row, String valueColumn, String nameColumn) {
/* 559 */     String value = row.getString(valueColumn);
/* 560 */     FCC_MESSAGE_QUEUE_STATUS type = FCC_MESSAGE_QUEUE_STATUS.get(value);
/* 561 */     row.setString(nameColumn, type.name());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <E extends MCRow> void putNameNE(MCList<E> list, String valueColumn, String nameColumn) {
/* 578 */     for (MCRow r : list) {
/* 579 */       FCC_MESSAGE_QUEUE_STATUS.putNameNE(r, valueColumn, nameColumn);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <E extends MCRow> void putNameNE(E row, String valueColumn, String nameColumn) {
/* 598 */     String value = row.getString(valueColumn);
/* 599 */     FCC_MESSAGE_QUEUE_STATUS type = FCC_MESSAGE_QUEUE_STATUS.getNE(value);
/* 600 */     if (type != null) {
/* 601 */       row.setString(nameColumn, type.name());
/*     */     } else {
/*     */       
/* 604 */       row.setString(nameColumn, null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <E extends MCRow> void putName(MCList<E> list, String valueColumn, String nameColumn, Locale lcl) {
/* 618 */     for (MCRow r : list) {
/* 619 */       FCC_MESSAGE_QUEUE_STATUS.putName(r, valueColumn, nameColumn, lcl);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <E extends MCRow> void putName(E row, String valueColumn, String nameColumn, Locale lcl) {
/* 633 */     String value = row.getString(valueColumn);
/* 634 */     FCC_MESSAGE_QUEUE_STATUS type = FCC_MESSAGE_QUEUE_STATUS.get(value);
/* 635 */     row.setString(nameColumn, type.name(lcl));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <E extends MCRow> void putNameNE(MCList<E> list, String valueColumn, String nameColumn, Locale lcl) {
/* 649 */     for (MCRow r : list) {
/* 650 */       FCC_MESSAGE_QUEUE_STATUS.putNameNE(r, valueColumn, nameColumn, lcl);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <E extends MCRow> void putNameNE(E row, String valueColumn, String nameColumn, Locale lcl) {
/* 665 */     String value = row.getString(valueColumn);
/* 666 */     FCC_MESSAGE_QUEUE_STATUS type = FCC_MESSAGE_QUEUE_STATUS.getNE(value);
/* 667 */     if (type != null) {
/* 668 */       row.setString(nameColumn, type.name(lcl));
/*     */     } else {
/*     */       
/* 671 */       row.setString(nameColumn, null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <E extends MCRow> void putName(MCList<E> list, String valueColumn, String nameColumn, String rmrksColumn) {
/* 690 */     for (MCRow r : list) {
/* 691 */       FCC_MESSAGE_QUEUE_STATUS.putName(r, valueColumn, nameColumn, rmrksColumn);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <E extends MCRow> void putName(E row, String valueColumn, String nameColumn, String rmrksColumn) {
/* 710 */     String value = row.getString(valueColumn);
/* 711 */     FCC_MESSAGE_QUEUE_STATUS type = FCC_MESSAGE_QUEUE_STATUS.get(value);
/* 712 */     row.setString(nameColumn, type.name());
/* 713 */     row.setString(rmrksColumn, type.rmrks());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <E extends MCRow> void putNameNE(MCList<E> list, String valueColumn, String nameColumn, String rmrksColumn) {
/* 731 */     for (MCRow r : list) {
/* 732 */       FCC_MESSAGE_QUEUE_STATUS.putNameNE(r, valueColumn, nameColumn, rmrksColumn);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <E extends MCRow> void putNameNE(E row, String valueColumn, String nameColumn, String rmrksColumn) {
/* 752 */     String value = row.getString(valueColumn);
/* 753 */     FCC_MESSAGE_QUEUE_STATUS type = FCC_MESSAGE_QUEUE_STATUS.getNE(value);
/* 754 */     if (type != null) {
/* 755 */       row.setString(nameColumn, type.name());
/* 756 */       row.setString(rmrksColumn, type.rmrks());
/*     */     } else {
/*     */       
/* 759 */       row.setString(nameColumn, null);
/* 760 */       row.setString(rmrksColumn, null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <E extends MCRow> void putName(MCList<E> list, String valueColumn, String nameColumn, String rmrksColumn, Locale lcl) {
/* 775 */     for (MCRow r : list) {
/* 776 */       FCC_MESSAGE_QUEUE_STATUS.putName(r, valueColumn, nameColumn, rmrksColumn, lcl);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <E extends MCRow> void putName(E row, String valueColumn, String nameColumn, String rmrksColumn, Locale lcl) {
/* 791 */     String value = row.getString(valueColumn);
/* 792 */     FCC_MESSAGE_QUEUE_STATUS type = FCC_MESSAGE_QUEUE_STATUS.get(value);
/* 793 */     row.setString(nameColumn, type.name(lcl));
/* 794 */     row.setString(rmrksColumn, type.rmrks(lcl));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <E extends MCRow> void putNameNE(MCList<E> list, String valueColumn, String nameColumn, String rmrksColumn, Locale lcl) {
/* 809 */     for (MCRow r : list) {
/* 810 */       FCC_MESSAGE_QUEUE_STATUS.putNameNE(r, valueColumn, nameColumn, rmrksColumn, lcl);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <E extends MCRow> void putNameNE(E row, String valueColumn, String nameColumn, String rmrksColumn, Locale lcl) {
/* 826 */     String value = row.getString(valueColumn);
/* 827 */     FCC_MESSAGE_QUEUE_STATUS type = FCC_MESSAGE_QUEUE_STATUS.getNE(value);
/* 828 */     if (type != null) {
/* 829 */       row.setString(nameColumn, type.name(lcl));
/* 830 */       row.setString(rmrksColumn, type.rmrks(lcl));
/*     */     } else {
/*     */       
/* 833 */       row.setString(nameColumn, null);
/* 834 */       row.setString(rmrksColumn, null);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\constant\FCC_MESSAGE_QUEUE_STATUS_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */