package mcframe.commonCore.constant;

import mcframe.commonCore.annotation.EI;

@EI
public class FCC_MESSAGE_QUEUE_STATUS extends FCC_MESSAGE_QUEUE_STATUS_FW {}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\constant\FCC_MESSAGE_QUEUE_STATUS.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */