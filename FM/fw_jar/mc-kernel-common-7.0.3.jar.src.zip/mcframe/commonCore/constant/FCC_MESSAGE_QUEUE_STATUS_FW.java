package mcframe.commonCore.constant;

abstract class FCC_MESSAGE_QUEUE_STATUS_FW extends FCC_MESSAGE_QUEUE_STATUS_FW_A {}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\constant\FCC_MESSAGE_QUEUE_STATUS_FW.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */