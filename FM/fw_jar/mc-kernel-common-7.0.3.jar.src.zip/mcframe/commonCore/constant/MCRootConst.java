/*     */ package mcframe.commonCore.constant;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.util.Locale;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.resource.MCConst;
/*     */ import mcframe.commonCore.resource.MCLabelConst;
/*     */ import mcframe.commonCore.resource.MCLocaleConst;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MCRootConst
/*     */ {
/*     */   private static final String constID = "CONST";
/*     */   private static final String LABEL_KEY = "label";
/*     */   private static final String RMRKS_KEY = "rmrks";
/*     */   private static final String KEYS_KEY = "keys";
/*     */   protected String xmlKey;
/*     */   private static final String DELIMITER = ",";
/*     */   
/*     */   protected abstract String moduleID();
/*     */   
/*     */   protected final String constID() {
/*  62 */     return "CONST";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract String typeID();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String key() {
/*  82 */     return this.xmlKey;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String name() {
/*  99 */     String key = MCConst.createKey(new String[] { moduleID(), constID(), typeID(), "keys", key(), 
/* 100 */           "label" });
/* 101 */     return MCConst.label.getLabel(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String name(Locale lcl) {
/* 116 */     MCLabelConst labelConst = MCLocaleConst.label(lcl);
/* 117 */     String key = MCConst.createKey(new String[] { moduleID(), constID(), typeID(), "keys", key(), 
/* 118 */           "label" });
/* 119 */     return labelConst.getLabel(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String rmrks() {
/* 136 */     String key = MCConst.createKey(new String[] { moduleID(), constID(), typeID(), "keys", key(), 
/* 137 */           "rmrks" });
/* 138 */     return MCConst.label.getLabel(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String rmrks(Locale lcl) {
/* 153 */     MCLabelConst labelConst = MCLocaleConst.label(lcl);
/* 154 */     String key = MCConst.createKey(new String[] { moduleID(), constID(), typeID(), "keys", key(), 
/* 155 */           "rmrks" });
/* 156 */     return labelConst.getLabel(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static MCException invalidValue(Object value) {
/* 168 */     return new MCException(Core_Msg_FW_A.FCBJC0066, new Object[] { value });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static String createStringPath(Object... objs) {
/* 187 */     if (objs == null) {
/* 188 */       return null;
/*     */     }
/* 190 */     StringBuilder sb = new StringBuilder();
/* 191 */     for (int i = 0; i < objs.length; i++) {
/* 192 */       if (i != 0) {
/* 193 */         sb.append(",");
/*     */       }
/* 195 */       if (objs[i] != null) {
/* 196 */         sb.append(objs[i]);
/*     */       }
/*     */     } 
/* 199 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static String getGrpName(String moduleID, String typeID) {
/* 216 */     String key = MCConst.createKey(new String[] { moduleID, "CONST", typeID, "label" });
/* 217 */     return MCConst.label.getLabel(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static String getGrpName(Locale lcl, String moduleID, String typeID) {
/* 231 */     MCLabelConst labelConst = MCLocaleConst.label(lcl);
/* 232 */     String key = MCConst.createKey(new String[] { moduleID, "CONST", typeID, "label" });
/* 233 */     return labelConst.getLabel(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static String getGrpRmrks(String moduleID, String typeID) {
/* 250 */     String key = MCConst.createKey(new String[] { moduleID, "CONST", typeID, "rmrks" });
/* 251 */     return MCConst.label.getLabel(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static String getGrpRmrks(Locale lcl, String moduleID, String typeID) {
/* 265 */     MCLabelConst labelConst = MCLocaleConst.label(lcl);
/* 266 */     String key = MCConst.createKey(new String[] { moduleID, "CONST", typeID, "rmrks" });
/* 267 */     return labelConst.getLabel(key);
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public boolean equals(Object obj) {
/* 273 */     return super.equals(obj);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static <E extends Comparable<?>> boolean isSame(E val1, E val2) {
/* 292 */     E a = null;
/* 293 */     E b = null;
/* 294 */     if (val1 != null) {
/* 295 */       a = val1;
/* 296 */       b = val2;
/*     */     }
/* 298 */     else if (val2 != null) {
/* 299 */       a = val2;
/* 300 */       b = val1;
/*     */     }
/*     */     else {
/*     */       
/* 304 */       return true;
/*     */     } 
/*     */     
/* 307 */     if (a instanceof MCNumber && b instanceof MCNumber) {
/* 308 */       return ((MCNumber)a).eq((BigDecimal)b);
/*     */     }
/* 310 */     return a.equals(b);
/*     */   }
/*     */   
/*     */   public abstract Comparable<?> value();
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\constant\MCRootConst.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */