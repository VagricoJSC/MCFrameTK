package mcframe.commonCore.event;

import java.util.EventListener;
import java.util.Locale;

public interface MCReportLabelListener extends EventListener {
  String doNGEvent(String paramString1, String paramString2, Locale paramLocale);
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\event\MCReportLabelListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */