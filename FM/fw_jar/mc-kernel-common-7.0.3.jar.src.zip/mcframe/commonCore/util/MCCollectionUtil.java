/*     */ package mcframe.commonCore.util;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCCollectionUtil
/*     */ {
/*     */   public static <E> void reverse(Object[] array) {
/*  34 */     if (array != null) {
/*  35 */       int count = array.length;
/*  36 */       int index = count - 1;
/*  37 */       for (int i = 0; i < count; i++) {
/*  38 */         int back = index - i;
/*  39 */         if (back <= i) {
/*     */           return;
/*     */         }
/*  42 */         E obj = (E)array[i];
/*  43 */         array[i] = array[back];
/*  44 */         array[back] = obj;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> boolean contains(T value, Object... target) {
/*  70 */     if (target == null) return false; 
/*  71 */     if (value == null) {
/*  72 */       byte b; int i; Object[] arrayOfObject; for (i = (arrayOfObject = target).length, b = 0; b < i; ) { Object t = arrayOfObject[b];
/*  73 */         if (t == null) return true;  b++; }
/*     */     
/*     */     } else {
/*     */       byte b; int i; Object[] arrayOfObject;
/*  77 */       for (i = (arrayOfObject = target).length, b = 0; b < i; ) { Object t = arrayOfObject[b];
/*  78 */         if (value.equals(t)) return true;  b++; }
/*     */     
/*     */     } 
/*  81 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T[] subArray(Object[] array, int startIdx, int endIdx, Class<T> clazz) {
/* 100 */     List<T> ls = Arrays.asList((T[])array);
/* 101 */     ls = ls.subList(startIdx, endIdx);
/* 102 */     return ls.toArray((T[])Array.newInstance(clazz, 0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T[] remove(Object[] src, Object[] dest, Object... removeValues) {
/* 127 */     List<T> ans = new ArrayList<>();
/* 128 */     if (src == null) {
/* 129 */       return null;
/*     */     }
/* 131 */     for (int i = 0; i < src.length; i++) {
/* 132 */       if (!contains(src[i], removeValues)) {
/* 133 */         ans.add((T)src[i]);
/*     */       }
/*     */     } 
/* 136 */     return ans.toArray((T[])dest);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T[] concat(Object[]... args) {
/* 157 */     if (args == null || args.length == 0 || args[0] == null) {
/* 158 */       return null;
/*     */     }
/*     */     
/* 161 */     int len = 0; byte b1; int i; Object[][] arrayOfObject1;
/* 162 */     for (i = (arrayOfObject1 = args).length, b1 = 0; b1 < i; ) { Object[] arg = arrayOfObject1[b1];
/* 163 */       len += (arg != null) ? arg.length : 0;
/*     */       b1++; }
/*     */     
/* 166 */     Class<?> type = args.getClass().getComponentType().getComponentType();
/* 167 */     Object[] temp = (Object[])Array.newInstance(type, len);
/* 168 */     int pos = 0; byte b2; int j; Object[][] arrayOfObject2;
/* 169 */     for (j = (arrayOfObject2 = args).length, b2 = 0; b2 < j; ) { Object[] arg = arrayOfObject2[b2];
/* 170 */       if (arg != null) {
/* 171 */         int arglen = arg.length;
/* 172 */         System.arraycopy(arg, 0, temp, pos, arglen);
/* 173 */         pos += arglen;
/*     */       }  b2++; }
/*     */     
/* 176 */     return (T[])temp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @SafeVarargs
/*     */   public static <T> T[] toArray(Object... items) {
/* 189 */     return (T[])items;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean contains(List<?> list, Object element) {
/* 209 */     if (list != null) {
/* 210 */       Object[] array = list.toArray(); byte b; int i; Object[] arrayOfObject1;
/* 211 */       for (i = (arrayOfObject1 = array).length, b = 0; b < i; ) { Object o = arrayOfObject1[b];
/* 212 */         if (o == element)
/* 213 */           return true; 
/*     */         b++; }
/*     */     
/*     */     } 
/* 217 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isEmpty(Object obj) {
/* 236 */     if (obj == null) {
/* 237 */       return true;
/*     */     }
/* 239 */     if (obj instanceof Collection) {
/* 240 */       return ((Collection)obj).isEmpty();
/*     */     }
/* 242 */     if (obj instanceof Map) {
/* 243 */       return ((Map)obj).isEmpty();
/*     */     }
/* 245 */     if (obj.getClass().isArray()) {
/* 246 */       return (Array.getLength(obj) == 0);
/*     */     }
/* 248 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isNotEmpty(Object obj) {
/* 261 */     return !isEmpty(obj);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCor\\util\MCCollectionUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */