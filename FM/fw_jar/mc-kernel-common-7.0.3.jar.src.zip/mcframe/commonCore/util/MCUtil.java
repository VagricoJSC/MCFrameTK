/*     */ package mcframe.commonCore.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.StringReader;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.lang.reflect.Array;
/*     */ import java.net.URLEncoder;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import mcframe.commonCore.notice.Core_Msg;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.resource.MCConfig;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MCUtil
/*     */ {
/*     */   public static final String STARTUP_KEY_OPEN = "open_id";
/*     */   public static final String OPEN_PARAM_MID = "$param_mid$";
/*     */   public static final String OPEN_PARAM_SID = "$param_sid$";
/*     */   public static final String OPEN_INIT_PARAM = "$init_param$";
/*     */   
/*     */   public static boolean equals(Object o1, Object o2) {
/*  52 */     return !((o1 != null || o2 != null) && (o1 == null || !o1.equals(o2)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T> T requireNonNull(T obj, String argID) {
/*  68 */     if (obj == null || (
/*  69 */       obj.getClass().isArray() && Array.getLength(obj) < 0)) {
/*  70 */       StackTraceElement[] e = Thread.currentThread().getStackTrace();
/*  71 */       throw new MCException(Core_Msg.FCUCC0019, new Object[] {
/*  72 */             String.valueOf(e[2].getClassName()) + "." + e[2].getMethodName(), argID });
/*     */     } 
/*  74 */     return obj;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean classInitException(Throwable e) {
/*     */     byte b;
/*     */     int i;
/*     */     StackTraceElement[] arrayOfStackTraceElement;
/*  90 */     for (i = (arrayOfStackTraceElement = e.getStackTrace()).length, b = 0; b < i; ) { StackTraceElement ste = arrayOfStackTraceElement[b];
/*  91 */       if ("<clinit>".equals(ste.getMethodName()))
/*  92 */         return true; 
/*     */       b++; }
/*     */     
/*  95 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String createOpenParam(String mid, String sid, Map<String, String> params, List<String> args) {
/* 172 */     StringBuilder buf = new StringBuilder();
/* 173 */     if (mid == null || sid == null) {
/* 174 */       return buf.toString();
/*     */     }
/* 176 */     buf.append(mid);
/* 177 */     buf.append(".");
/* 178 */     buf.append(sid);
/*     */ 
/*     */     
/* 181 */     if ((params == null || params.size() <= 0) && (args == null || args.size() <= 0)) {
/* 182 */       return buf.toString();
/*     */     }
/* 184 */     buf.append("?");
/*     */ 
/*     */     
/* 187 */     for (Map.Entry<String, String> entry : params.entrySet()) {
/* 188 */       String val = entry.getValue();
/* 189 */       if (val == null) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 195 */       val = escapeOpenValue(val);
/*     */       
/* 197 */       String key = entry.getKey();
/* 198 */       buf.append(key);
/* 199 */       buf.append("=");
/* 200 */       buf.append(val);
/* 201 */       buf.append(";");
/*     */     } 
/*     */ 
/*     */     
/* 205 */     if (args != null && args.size() > 0) {
/* 206 */       String val = createOpenInitParam(args);
/* 207 */       if (val != null) {
/* 208 */         buf.append("$init_param$");
/* 209 */         buf.append("=");
/* 210 */         buf.append(val);
/* 211 */         buf.append(";");
/*     */       } 
/*     */     } 
/*     */     
/* 215 */     return buf.substring(0, buf.length() - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String createOpenInitParam(List<String> args) {
/* 242 */     if (args == null || args.size() <= 0) {
/* 243 */       return null;
/*     */     }
/* 245 */     StringBuilder buf = new StringBuilder();
/* 246 */     for (String arg : args) {
/* 247 */       if (arg == null) {
/* 248 */         arg = "";
/*     */       }
/* 250 */       arg = escapeOpenValue(arg);
/* 251 */       buf.append(arg);
/* 252 */       buf.append(",");
/*     */     } 
/* 254 */     return buf.substring(0, buf.length() - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String escapeOpenValue(String val) {
/* 275 */     if (val.indexOf(';') >= 0 || val.indexOf(',') >= 0 || val.indexOf('"') >= 0) {
/*     */       
/* 277 */       val = val.replaceAll("\"", "\"\"");
/* 278 */       val = "\"" + val + "\"";
/*     */     } 
/* 280 */     return val;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void analyzeOpenParam(String openparam, Map<String, String> params, List<String> args) {
/* 306 */     if (params != null) {
/* 307 */       params.clear();
/*     */     }
/* 309 */     if (args != null) {
/* 310 */       args.clear();
/*     */     }
/*     */     
/* 313 */     if (openparam == null) {
/*     */       return;
/*     */     }
/*     */     
/* 317 */     Map<String, String> _params = new HashMap<>();
/* 318 */     List<String> _args = new ArrayList<>();
/*     */     
/* 320 */     String col = null;
/* 321 */     String val = null;
/*     */ 
/*     */     
/* 324 */     boolean init = false;
/*     */     
/* 326 */     StringBuilder buf = new StringBuilder();
/* 327 */     char sep = '.';
/* 328 */     StringReader sr = new StringReader(openparam);
/*     */     try {
/* 330 */       for (int ch = -1; (ch = sr.read()) > -1; ) {
/* 331 */         char c = (char)ch;
/* 332 */         if (c == sep) {
/* 333 */           switch (c) {
/*     */             
/*     */             case '.':
/* 336 */               val = (buf.length() > 0) ? buf.toString() : null;
/* 337 */               _params.put("$param_mid$", val);
/* 338 */               buf.delete(0, buf.length());
/* 339 */               sep = '?';
/*     */               continue;
/*     */             
/*     */             case '?':
/* 343 */               val = (buf.length() > 0) ? buf.toString() : null;
/* 344 */               _params.put("$param_sid$", val);
/* 345 */               buf.delete(0, buf.length());
/* 346 */               sep = '=';
/*     */               continue;
/*     */             
/*     */             case '=':
/* 350 */               col = (buf.length() > 0) ? buf.toString() : null;
/* 351 */               buf.delete(0, buf.length());
/* 352 */               sep = ';';
/* 353 */               init = "$init_param$".equals(col);
/*     */               continue;
/*     */ 
/*     */             
/*     */             case '"':
/* 358 */               if ((ch = sr.read()) <= -1) {
/*     */                 continue;
/*     */               }
/*     */               
/* 362 */               c = (char)ch;
/*     */               
/* 364 */               if (init && c == ',') {
/*     */                 
/* 366 */                 val = (buf.length() > 0) ? buf.toString() : null;
/* 367 */                 _args.add(val);
/* 368 */                 buf.delete(0, buf.length());
/*     */                 
/*     */                 continue;
/*     */               } 
/* 372 */               if (c != ';') {
/*     */ 
/*     */                 
/* 375 */                 buf.append(c);
/*     */                 continue;
/*     */               } 
/*     */ 
/*     */ 
/*     */             
/*     */             case ';':
/* 382 */               if (init) {
/*     */                 
/* 384 */                 val = (buf.length() > 0) ? buf.toString() : null;
/* 385 */                 _args.add(val);
/*     */               }
/* 387 */               else if (!_params.containsKey(col)) {
/* 388 */                 val = (buf.length() > 0) ? buf.toString() : null;
/* 389 */                 _params.put(col, val);
/*     */               } 
/* 391 */               buf.delete(0, buf.length());
/* 392 */               sep = '=';
/* 393 */               init = false;
/*     */               continue;
/*     */           } 
/*     */           continue;
/*     */         } 
/* 398 */         if (sep == ';' && c == '"' && buf.length() <= 0) {
/*     */           
/* 400 */           sep = '"'; continue;
/*     */         } 
/* 402 */         if (init && sep == ';' && c == ',') {
/*     */           
/* 404 */           val = (buf.length() > 0) ? buf.toString() : null;
/* 405 */           _args.add(val);
/* 406 */           buf.delete(0, buf.length());
/*     */           continue;
/*     */         } 
/* 409 */         buf.append(c);
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 414 */     catch (IOException e) {
/*     */       
/* 416 */       e.printStackTrace();
/*     */     } 
/*     */ 
/*     */     
/* 420 */     switch (sep) {
/*     */       
/*     */       case '.':
/* 423 */         val = (buf.length() > 0) ? buf.toString() : null;
/* 424 */         _params.put("$param_mid$", val);
/*     */         break;
/*     */       
/*     */       case '?':
/* 428 */         val = (buf.length() > 0) ? buf.toString() : null;
/* 429 */         _params.put("$param_sid$", val);
/*     */         break;
/*     */       
/*     */       case '=':
/* 433 */         col = (buf.length() > 0) ? buf.toString() : null;
/*     */         break;
/*     */ 
/*     */       
/*     */       case '"':
/*     */       case ';':
/* 439 */         if (init) {
/*     */           
/* 441 */           val = (buf.length() > 0) ? buf.toString() : null;
/* 442 */           _args.add(val); break;
/*     */         } 
/* 444 */         if (!params.containsKey(col)) {
/* 445 */           val = (buf.length() > 0) ? buf.toString() : null;
/* 446 */           _params.put(col, val);
/*     */         } 
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 452 */     if (params != null) {
/* 453 */       params.putAll(_params);
/*     */     }
/* 455 */     if (args != null) {
/* 456 */       args.addAll(_args);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void analyzeOpenInitParam(String initparam, List<String> args) {
/* 474 */     if (args != null) {
/* 475 */       args.clear();
/*     */     }
/*     */     
/* 478 */     if (initparam == null) {
/*     */       return;
/*     */     }
/*     */     
/* 482 */     List<String> _args = new ArrayList<>();
/* 483 */     String val = null;
/*     */     
/* 485 */     StringBuilder buf = new StringBuilder();
/* 486 */     char sep = ',';
/* 487 */     StringReader sr = new StringReader(initparam);
/*     */     try {
/* 489 */       for (int ch = -1; (ch = sr.read()) > -1; ) {
/* 490 */         char c = (char)ch;
/* 491 */         if (c == sep) {
/* 492 */           switch (c) {
/*     */ 
/*     */             
/*     */             case '"':
/* 496 */               if ((ch = sr.read()) <= -1) {
/*     */                 continue;
/*     */               }
/*     */               
/* 500 */               c = (char)ch;
/*     */               
/* 502 */               if (c != ',') {
/*     */ 
/*     */                 
/* 505 */                 buf.append(c);
/*     */                 continue;
/*     */               } 
/*     */ 
/*     */ 
/*     */             
/*     */             case ',':
/* 512 */               val = (buf.length() > 0) ? buf.toString() : null;
/* 513 */               _args.add(val);
/* 514 */               buf.delete(0, buf.length());
/*     */               continue;
/*     */           } 
/*     */           continue;
/*     */         } 
/* 519 */         if (sep == ',' && c == '"' && buf.length() <= 0) {
/*     */           
/* 521 */           sep = '"';
/*     */           continue;
/*     */         } 
/* 524 */         buf.append(c);
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 529 */     catch (IOException e) {
/*     */       
/* 531 */       e.printStackTrace();
/*     */     } 
/*     */ 
/*     */     
/* 535 */     val = (buf.length() > 0) ? buf.toString() : null;
/* 536 */     _args.add(val);
/*     */ 
/*     */     
/* 539 */     if (args != null) {
/* 540 */       args.addAll(_args);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String openURL(String mid, String sid, Map<String, String> params) {
/* 559 */     return openURL(mid, sid, params, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String openURL(String mid, String sid, Map<String, String> params, List<String> args) {
/* 585 */     String port = openURLPort();
/* 586 */     if (port == null) {
/* 587 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 591 */     String param = createOpenParam(mid, sid, params, args);
/* 592 */     String enc = openURLParamEncode();
/*     */     try {
/* 594 */       param = URLEncoder.encode(param, enc);
/*     */     }
/* 596 */     catch (UnsupportedEncodingException e) {
/*     */       
/* 598 */       throw new MCException(e);
/*     */     } 
/*     */     
/* 601 */     return "http://localhost:" + port + "/mcframe?" + "open_id" + "=" + param;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String openURLPort() {
/* 614 */     return MCConfig.common.getString("contact.openurl.port");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String openURLParamEncode() {
/* 625 */     return MCConfig.common.getString("contact.openurl.encode", "UTF-8");
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCor\\util\MCUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */