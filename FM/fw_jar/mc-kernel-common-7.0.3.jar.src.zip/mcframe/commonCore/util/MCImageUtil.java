/*     */ package mcframe.commonCore.util;
/*     */ 
/*     */ import java.awt.AlphaComposite;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Image;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.awt.image.AreaAveragingScaleFilter;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.FilteredImageSource;
/*     */ import java.awt.image.ImageFilter;
/*     */ import java.awt.image.ImageObserver;
/*     */ import java.awt.image.ImageProducer;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.util.Iterator;
/*     */ import javax.imageio.ImageIO;
/*     */ import javax.imageio.ImageReader;
/*     */ import javax.imageio.stream.ImageInputStream;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCImageUtil
/*     */ {
/*     */   public static Dimension imageSize(File file) {
/*     */     try {
/*  46 */       BufferedImage img = ImageIO.read(file);
/*  47 */       return new Dimension(img.getWidth(), img.getHeight());
/*     */     }
/*  49 */     catch (Exception e) {
/*  50 */       throw new MCException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String imageFormat(File file) {
/*  74 */     String format = null;
/*     */     try {
/*  76 */       ImageInputStream iis = ImageIO.createImageInputStream(new FileInputStream(file));
/*  77 */       Iterator<ImageReader> readers = ImageIO.getImageReaders(iis);
/*  78 */       while (readers.hasNext()) {
/*  79 */         ImageReader reader = readers.next();
/*  80 */         if (format == null) {
/*  81 */           format = reader.getFormatName().toLowerCase();
/*     */         }
/*  83 */         reader.dispose();
/*     */       }
/*     */     
/*  86 */     } catch (Exception e) {
/*  87 */       throw new MCException(e);
/*     */     } 
/*  89 */     return format;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void scaleImage(File in, File out, double scale) {
/* 110 */     String format = imageFormat(in);
/* 111 */     scaleImage(in, out, scale, format);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void scaleImage(File in, File out, double scale, String format) {
/*     */     try {
/* 133 */       BufferedImage org = ImageIO.read(in);
/* 134 */       int newW = (int)(org.getWidth() * scale);
/* 135 */       int newH = (int)(org.getHeight() * scale);
/* 136 */       scaleImage(org, out, newW, newH, format);
/*     */     }
/* 138 */     catch (Exception e) {
/* 139 */       throw (e instanceof MCException) ? (MCException)e : new MCException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void scaleImage(File in, File out, int newW, int newH) {
/* 159 */     String format = imageFormat(in);
/* 160 */     scaleImage(in, out, newW, newH, format);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void scaleImage(File in, File out, int newW, int newH, String format) {
/*     */     try {
/* 180 */       scaleImage(ImageIO.read(in), out, newW, newH, format);
/*     */     }
/* 182 */     catch (Exception e) {
/* 183 */       throw (e instanceof MCException) ? (MCException)e : new MCException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void scaleImage(BufferedImage img, File out, int newW, int newH, String format) {
/* 205 */     MCFileUtil.mkDir(out.getAbsoluteFile().getParentFile());
/*     */     
/*     */     try {
/* 208 */       ImageFilter filter = new AreaAveragingScaleFilter(newW, newH);
/* 209 */       ImageProducer p = new FilteredImageSource(img.getSource(), filter);
/* 210 */       Image dstImage = Toolkit.getDefaultToolkit().createImage(p);
/* 211 */       BufferedImage dst = new BufferedImage(
/* 212 */           dstImage.getWidth(null), dstImage.getHeight(null), 2);
/* 213 */       Graphics2D g = dst.createGraphics();
/*     */ 
/*     */       
/* 216 */       g.setComposite(AlphaComposite.getInstance(1, 0.0F));
/* 217 */       Rectangle2D.Double rect = new Rectangle2D.Double(
/* 218 */           0.0D, 0.0D, dst.getHeight(), dst.getHeight());
/* 219 */       g.fill(rect);
/* 220 */       g.setPaintMode();
/*     */ 
/*     */       
/* 223 */       g.setRenderingHint(
/* 224 */           RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/*     */       
/* 226 */       g.drawImage(dstImage, 0, 0, (ImageObserver)null);
/* 227 */       g.dispose();
/*     */ 
/*     */ 
/*     */       
/* 231 */       ImageIO.write(dst, format, out);
/*     */     }
/* 233 */     catch (Exception e) {
/* 234 */       throw new MCException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void fitImage(File in, File out, int frameW, int frameH) {
/* 259 */     String format = imageFormat(in);
/* 260 */     scaleImage(in, out, frameW, frameH, format);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void fitImage(File in, File out, int frameW, int frameH, String format) {
/*     */     try {
/* 285 */       fitImage(ImageIO.read(in), out, frameW, frameH, format);
/*     */     }
/* 287 */     catch (Exception e) {
/* 288 */       throw (e instanceof MCException) ? (MCException)e : new MCException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void fitImage(BufferedImage img, File out, int frameW, int frameH, String format) {
/* 315 */     MCFileUtil.mkDir(out.getAbsoluteFile().getParentFile());
/*     */     
/*     */     try {
/* 318 */       int orgW = img.getWidth(null);
/* 319 */       int orgH = img.getHeight(null);
/* 320 */       double scaleW = frameW / orgW;
/* 321 */       double scaleH = frameH / orgH;
/* 322 */       double scale = Math.min(scaleW, scaleH);
/* 323 */       int newW = (int)(orgW * scale);
/* 324 */       int newH = (int)(orgH * scale);
/* 325 */       boolean hc = (scale == scaleW);
/* 326 */       int x = hc ? 0 : ((frameW - newW) / 2);
/* 327 */       int y = hc ? ((frameH - newH) / 2) : 0;
/*     */       
/* 329 */       ImageFilter filter = new AreaAveragingScaleFilter(newW, newH);
/* 330 */       ImageProducer p = new FilteredImageSource(img.getSource(), filter);
/* 331 */       Image dstImage = Toolkit.getDefaultToolkit().createImage(p);
/*     */       
/* 333 */       BufferedImage dst = new BufferedImage(frameW, frameH, 2);
/* 334 */       Graphics2D g = dst.createGraphics();
/*     */ 
/*     */       
/* 337 */       g.setComposite(AlphaComposite.getInstance(1, 0.0F));
/* 338 */       Rectangle2D.Double rect = new Rectangle2D.Double(
/* 339 */           0.0D, 0.0D, dst.getHeight(), dst.getHeight());
/* 340 */       g.fill(rect);
/* 341 */       g.setPaintMode();
/*     */ 
/*     */       
/* 344 */       g.setRenderingHint(
/* 345 */           RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/*     */       
/* 347 */       g.drawImage(dstImage, x, y, (ImageObserver)null);
/* 348 */       g.dispose();
/*     */ 
/*     */ 
/*     */       
/* 352 */       ImageIO.write(dst, format, out);
/*     */     }
/* 354 */     catch (Exception e) {
/* 355 */       throw new MCException(e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCor\\util\MCImageUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */