/*     */ package mcframe.commonCore.util;
/*     */ 
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.BiFunction;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Function;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MCFunctionIFUtil
/*     */ {
/*     */   public static <T> Consumer<T> exConsumer(ExConsumer<T> func) {
/*  43 */     return t -> {
/*     */         
/*     */         try {
/*     */           paramExConsumer.accept(t);
/*  47 */         } catch (MCException e) {
/*     */           
/*     */           throw e;
/*  50 */         } catch (RuntimeException e) {
/*     */           
/*     */           throw e;
/*  53 */         } catch (Exception e) {
/*     */           throw new MCException(e);
/*     */         } 
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T, U> BiConsumer<T, U> exConsumer(ExBiConsumer<T, U> func) {
/*  84 */     return (t, u) -> {
/*     */         
/*     */         try {
/*     */           paramExBiConsumer.accept(t, u);
/*  88 */         } catch (MCException e) {
/*     */           
/*     */           throw e;
/*  91 */         } catch (RuntimeException e) {
/*     */           
/*     */           throw e;
/*  94 */         } catch (Exception e) {
/*     */           throw new MCException(e);
/*     */         } 
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T, R> Function<T, R> exFunction(ExFunction<T, R> func) {
/* 125 */     return t -> {
/*     */         
/*     */         try {
/*     */           return paramExFunction.apply(t);
/* 129 */         } catch (MCException e) {
/*     */           
/*     */           throw e;
/* 132 */         } catch (RuntimeException e) {
/*     */           
/*     */           throw e;
/* 135 */         } catch (Exception e) {
/*     */           throw new MCException(e);
/*     */         } 
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T, U, R> BiFunction<T, U, R> exFunction(ExBiFunction<T, U, R> func) {
/* 165 */     return (t, u) -> {
/*     */         
/*     */         try {
/*     */           return paramExBiFunction.apply(t, u);
/* 169 */         } catch (MCException e) {
/*     */           
/*     */           throw e;
/* 172 */         } catch (RuntimeException e) {
/*     */           
/*     */           throw e;
/* 175 */         } catch (Exception e) {
/*     */           throw new MCException(e);
/*     */         } 
/*     */       };
/*     */   }
/*     */   
/*     */   @FunctionalInterface
/*     */   public static interface ExBiConsumer<T, U> {
/*     */     void accept(T param1T, U param1U) throws Exception;
/*     */   }
/*     */   
/*     */   @FunctionalInterface
/*     */   public static interface ExBiFunction<T, U, R> {
/*     */     R apply(T param1T, U param1U) throws Exception;
/*     */   }
/*     */   
/*     */   @FunctionalInterface
/*     */   public static interface ExConsumer<T> {
/*     */     void accept(T param1T) throws Exception;
/*     */   }
/*     */   
/*     */   @FunctionalInterface
/*     */   public static interface ExFunction<T, R> {
/*     */     R apply(T param1T) throws Exception;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCor\\util\MCFunctionIFUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */