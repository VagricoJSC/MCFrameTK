/*     */ package mcframe.commonCore.util;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.resource.MCConst;
/*     */ import mcframe.commonCore.resource.MCListLogicConst;
/*     */ import mcframe.commonCore.sys.MCFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCListLogicUtil
/*     */ {
/*  22 */   protected static Map<String, Class<?>> _cachedClassL = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] getOutColumns(String listLogicId) {
/*  36 */     Class<?> common = getColsClass(listLogicId);
/*  37 */     if (common != null) {
/*  38 */       Method outAll = getOutAllMethod(common);
/*     */       
/*     */       try {
/*  41 */         if (outAll != null) {
/*  42 */           Object o = outAll.invoke(null, new Object[0]);
/*  43 */           return (String[])o;
/*     */         }
/*     */       
/*     */       }
/*  47 */       catch (IllegalAccessException|IllegalArgumentException|java.lang.reflect.InvocationTargetException e) {
/*  48 */         throw new MCException(e);
/*     */       } 
/*     */     } 
/*  51 */     return new String[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class<?> getColsClass(String listLogicId) {
/*  62 */     if (_cachedClassL.containsKey(listLogicId)) {
/*  63 */       return _cachedClassL.get(listLogicId);
/*     */     }
/*  65 */     String[] s = MCConst.ll.getCommonCols(listLogicId);
/*  66 */     if (s != null) {
/*  67 */       String common = s[0];
/*  68 */       String cols = s[1];
/*  69 */       return getColsClass(MCFactory.getClass(Object.class, common), cols);
/*     */     } 
/*  71 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Class<?> getColsClass(Class<?> common, String colsNm) {
/*  85 */     while (common != null) {
/*     */       try {
/*  87 */         return Class.forName(String.valueOf(common.getName()) + "$" + colsNm);
/*     */       }
/*  89 */       catch (ClassNotFoundException classNotFoundException) {
/*  90 */         common = common.getSuperclass();
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  99 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Method getOutAllMethod(Class<?> cols) {
/* 111 */     while (cols != null) {
/* 112 */       byte b; int i; Method[] arrayOfMethod; for (i = (arrayOfMethod = cols.getDeclaredMethods()).length, b = 0; b < i; ) { Method m = arrayOfMethod[b];
/* 113 */         if (m.getName().equals("outAll"))
/* 114 */           return m; 
/*     */         b++; }
/*     */       
/* 117 */       cols = cols.getSuperclass();
/*     */     } 
/* 119 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void initCachedClassL(MCListLogicConst.ListLogicEnv env) {
/* 132 */     if (!MCConst.ll.isCacheEnable()) {
/*     */       return;
/*     */     }
/* 135 */     List<String> listLogicIds = MCConst.ll.getCacheClassId(env);
/* 136 */     for (String id : listLogicIds) {
/* 137 */       Class<?> clazz = getColsClass(id);
/* 138 */       if (clazz != null) {
/* 139 */         _cachedClassL.put(id, clazz);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static int getCacheSize() {
/* 152 */     return _cachedClassL.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static boolean isCached(String id) {
/* 164 */     return _cachedClassL.containsKey(id);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCor\\util\MCListLogicUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */