/*      */ package mcframe.commonCore.util;
/*      */ 
/*      */ import com.fasterxml.jackson.core.JsonGenerator;
/*      */ import com.fasterxml.jackson.core.JsonProcessingException;
/*      */ import com.fasterxml.jackson.core.type.TypeReference;
/*      */ import com.fasterxml.jackson.databind.DeserializationFeature;
/*      */ import com.fasterxml.jackson.databind.JsonNode;
/*      */ import com.fasterxml.jackson.databind.JsonSerializer;
/*      */ import com.fasterxml.jackson.databind.Module;
/*      */ import com.fasterxml.jackson.databind.ObjectMapper;
/*      */ import com.fasterxml.jackson.databind.SerializerProvider;
/*      */ import com.fasterxml.jackson.databind.module.SimpleModule;
/*      */ import com.fasterxml.jackson.databind.ser.std.StdSerializer;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.net.URLEncoder;
/*      */ import java.security.MessageDigest;
/*      */ import java.security.NoSuchAlgorithmException;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import mcframe.commonCore.container.MCList;
/*      */ import mcframe.commonCore.container.MCRow;
/*      */ import mcframe.commonCore.lang.MCCalendarDate;
/*      */ import mcframe.commonCore.lang.MCDate;
/*      */ import mcframe.commonCore.lang.MCNumber;
/*      */ import mcframe.commonCore.lang.MCTimestamp;
/*      */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*      */ import mcframe.commonCore.notice.MCException;
/*      */ import mcframe.commonCore.sys.MCSys;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MCDataConvUtil
/*      */ {
/*      */   protected static final char basepad = '=';
/*   62 */   protected static final char[] base64map = new char[] { 
/*   63 */       'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 
/*   64 */       'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 
/*   65 */       'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 
/*   66 */       't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', 
/*   67 */       '8', '9', '+', '/' };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String encodeBase64(byte[] dec) {
/*   99 */     return encodeBase64(dec, 0, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String encodeBase64(InputStream dec) {
/*  114 */     return encodeBase64(dec, 0, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String encodeBase64(byte[] dec, int len) {
/*  135 */     return encodeBase64(dec, len, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String encodeBase64(InputStream dec, int len) {
/*  151 */     return encodeBase64(dec, len, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String encodeBase64(byte[] dec, boolean padding) {
/*  172 */     return encodeBase64(dec, 0, padding);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String encodeBase64(InputStream dec, boolean padding) {
/*  188 */     return encodeBase64(dec, 0, padding);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String encodeBase64(byte[] dec, int len, boolean padding) {
/*  212 */     return encodeBase64(new ByteArrayInputStream(dec), len, padding);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String encodeBase64(InputStream dec, int len, boolean padding) {
/*  230 */     String enc = encodeByMap(dec, base64map, len, "\r\n", new char[0]);
/*  231 */     if (padding) {
/*  232 */       int enclen = enc.length();
/*  233 */       if (len > 0 && enclen > len) {
/*      */         
/*  235 */         int retlen = enclen / (len + 2);
/*  236 */         enclen -= retlen * 2;
/*      */       } 
/*  238 */       int padlen = enclen % 4;
/*  239 */       if (padlen > 0) {
/*  240 */         StringBuilder sb = new StringBuilder(enclen + padlen);
/*  241 */         sb.append(enc);
/*  242 */         for (int i = padlen; i < 4; i++) {
/*  243 */           sb.append('=');
/*      */         }
/*  245 */         enc = sb.toString();
/*      */       } 
/*      */     } 
/*  248 */     return enc;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] decodeBase64(String enc) {
/*  268 */     return decodeBase64(enc, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] decodeBase64(String enc, boolean padding) {
/*  289 */     if (enc == null) {
/*  290 */       return null;
/*      */     }
/*      */     
/*  293 */     int slen = enc.length();
/*  294 */     int blen = slen / 4 * 3;
/*  295 */     blen += (slen % 4 > 0) ? 3 : 0; try {
/*  296 */       Exception exception1 = null, exception2 = null; 
/*      */       try {  }
/*      */       finally
/*  299 */       { exception2 = null; if (exception1 == null) { exception1 = exception2; } else if (exception1 != exception2) { exception1.addSuppressed(exception2); }  } 
/*  300 */     } catch (IOException e) {
/*      */       
/*  302 */       throw new MCException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void decodeBase64(OutputStream os, String enc, boolean padding) {
/*  404 */     if (enc == null) {
/*      */       return;
/*      */     }
/*      */     
/*  408 */     int slen = enc.length();
/*  409 */     byte[] bb = new byte[3];
/*  410 */     int padlen = 0;
/*      */     
/*  412 */     int buf = 0;
/*  413 */     int cnt = 0;
/*      */     try {
/*  415 */       for (int i = 0; i < slen; i++) {
/*  416 */         char c = enc.charAt(i);
/*  417 */         int idx = 0;
/*  418 */         if (c == '=') {
/*  419 */           if (!padding) {
/*      */             continue;
/*      */           }
/*      */           
/*  423 */           padlen++;
/*      */         } else {
/*      */           
/*  426 */           if (padlen > 0)
/*      */           {
/*  428 */             throw new MCException(Core_Msg_FW_A.FCBEC0022, new Object[] { enc });
/*      */           }
/*  430 */           if ('A' <= c && c <= 'Z')
/*  431 */           { idx = c - 65; }
/*      */           
/*  433 */           else if ('a' <= c && c <= 'z')
/*  434 */           { idx = c - 97 + 26; }
/*      */           
/*  436 */           else if ('0' <= c && c <= '9')
/*  437 */           { idx = c - 48 + 52; }
/*      */           
/*  439 */           else if (c == '+')
/*  440 */           { idx = 62; }
/*      */           
/*  442 */           else if (c == '/')
/*  443 */           { idx = 63; } else { continue; } 
/*  444 */         }  buf <<= 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  452 */           6;
/*  453 */         buf |= idx;
/*  454 */         if (cnt % 4 == 3) {
/*      */           
/*  456 */           bb[0] = (byte)(buf >> 16 & 0xFF);
/*  457 */           bb[1] = (byte)(buf >> 8 & 0xFF);
/*  458 */           bb[2] = (byte)(buf & 0xFF);
/*  459 */           os.write(bb, 0, bb.length - padlen);
/*  460 */           buf = 0;
/*      */         } 
/*      */         
/*  463 */         cnt++;
/*      */         continue;
/*      */       } 
/*  466 */       if (cnt % 4 > 0) {
/*  467 */         if (padding)
/*      */         {
/*  469 */           throw new MCException(Core_Msg_FW_A.FCBEC0023, new Object[] { enc });
/*      */         }
/*      */ 
/*      */         
/*  473 */         while (cnt % 4 != 0) {
/*  474 */           buf <<= 6;
/*  475 */           padlen++;
/*  476 */           cnt++;
/*      */         } 
/*      */         
/*  479 */         bb[0] = (byte)(buf >> 16 & 0xFF);
/*  480 */         bb[1] = (byte)(buf >> 8 & 0xFF);
/*  481 */         bb[2] = (byte)(buf & 0xFF);
/*  482 */         os.write(bb, 0, bb.length - padlen);
/*  483 */         buf = 0;
/*      */       }
/*      */     
/*      */     }
/*  487 */     catch (IOException e) {
/*      */       
/*  489 */       throw new MCException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] digest(String algorithm, byte[] data) {
/*      */     MessageDigest md;
/*      */     try {
/*  566 */       md = MessageDigest.getInstance(algorithm);
/*      */     }
/*  568 */     catch (NoSuchAlgorithmException ex) {
/*      */       
/*  570 */       throw new MCException(ex, Core_Msg_FW_A.FCBEC0020, new Object[] { algorithm });
/*      */     } 
/*  572 */     md.update(data);
/*  573 */     return md.digest();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] digest(String algorithm, File file) {
/*      */     try {
/*  588 */       MessageDigest md = MessageDigest.getInstance(algorithm);
/*  589 */       Exception exception1 = null, exception2 = null;
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/*      */       
/*      */       } finally {
/*  596 */         exception2 = null; if (exception1 == null) { exception1 = exception2; } else if (exception1 != exception2) { exception1.addSuppressed(exception2);
/*      */ 
/*      */           
/*      */            }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*  610 */     catch (Exception ex) {
/*      */       
/*  612 */       throw new MCException(ex, Core_Msg_FW_A.FCBEC0021, new Object[] { file.getAbsolutePath() });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  625 */   private static char[] _hexs = new char[] { 
/*  626 */       '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String hexString(byte[] data) {
/*  643 */     if (data == null) {
/*  644 */       return null;
/*      */     }
/*      */     
/*  647 */     int l = data.length;
/*  648 */     char[] str = new char[l << 1];
/*      */     
/*  650 */     for (int i = 0, j = 0; i < l; i++) {
/*  651 */       str[j++] = _hexs[(0xF0 & data[i]) >>> 4];
/*  652 */       str[j++] = _hexs[0xF & data[i]];
/*      */     } 
/*  654 */     return String.valueOf(str);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] hexByteArray(String str) {
/*  671 */     if (str == null) {
/*  672 */       return null;
/*      */     }
/*  674 */     if (str.length() % 2 > 0)
/*      */     {
/*  676 */       throw new MCException(Core_Msg_FW_A.FCBEC0045, new Object[] { str });
/*      */     }
/*      */ 
/*      */     
/*  680 */     char[] chars = str.toCharArray();
/*  681 */     int clen = chars.length;
/*  682 */     int blen = clen / 2;
/*  683 */     int bpos = 0;
/*  684 */     int radix = 16;
/*  685 */     byte[] bytes = new byte[blen];
/*  686 */     for (int i = 0; i < clen; ) {
/*  687 */       int bint = 0;
/*  688 */       for (int p = 0; p < 2; p++) {
/*  689 */         bint *= radix;
/*  690 */         char ch = chars[i++];
/*  691 */         int val = Character.digit(ch, radix);
/*  692 */         if (val < 0)
/*      */         {
/*  694 */           throw new MCException(Core_Msg_FW_A.FCBEC0046, new Object[] { str });
/*      */         }
/*  696 */         bint -= val;
/*      */       } 
/*  698 */       bytes[bpos++] = (byte)-bint;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  705 */     return bytes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static String encodeByMap(byte[] bin, char[] map) {
/*  721 */     return encodeByMap(bin, map, 0, (String)null, new char[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static String encodeByMap(byte[] bin, char[] map, int splitlen, String spliter, char... adjusts) {
/*  765 */     if (bin == null)
/*  766 */       return null; 
/*      */     try {
/*  768 */       Exception exception1 = null, exception2 = null; 
/*      */       try {  }
/*      */       finally
/*  771 */       { exception2 = null; if (exception1 == null) { exception1 = exception2; } else if (exception1 != exception2) { exception1.addSuppressed(exception2); }  } 
/*  772 */     } catch (IOException e) {
/*      */       
/*  774 */       throw new MCException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static String encodeByMap(InputStream is, char[] map, int splitlen, String spliter, char... adjusts) {
/*  875 */     if (is == null || map == null || map.length == 0) {
/*  876 */       return null;
/*      */     }
/*      */ 
/*      */     
/*  880 */     boolean split = (splitlen > 0 && spliter != null);
/*      */     
/*  882 */     int bytelen = 8;
/*  883 */     int bit = 0;
/*  884 */     for (int m = map.length; bit < bytelen && m >>> bit > 1; bit++);
/*      */ 
/*      */     
/*  887 */     int mask = (2 << bit - 1) - 1;
/*  888 */     int shiftlen = bytelen - bit;
/*  889 */     StringBuilder enc = new StringBuilder(1024);
/*      */     
/*  891 */     int shift = 0;
/*  892 */     int len = 0;
/*  893 */     int buf = 0;
/*  894 */     int bin = 0;
/*      */     try {
/*  896 */       while ((bin = is.read()) > -1) {
/*  897 */         shift += shiftlen;
/*  898 */         buf <<= bytelen;
/*  899 */         buf += bin;
/*  900 */         enc.append(map[buf >>> shift & mask]);
/*  901 */         len++;
/*  902 */         if (split && len % splitlen == 0)
/*      */         {
/*  904 */           enc.append(spliter);
/*      */         }
/*      */         
/*  907 */         if (shift >= bit)
/*      */         {
/*  909 */           shift -= bit;
/*  910 */           enc.append(map[buf >>> shift & mask]);
/*  911 */           len++;
/*  912 */           if (split && len % splitlen == 0)
/*      */           {
/*  914 */             enc.append(spliter);
/*      */           }
/*      */         }
/*      */       
/*      */       } 
/*  919 */     } catch (IOException e) {
/*      */       
/*  921 */       throw new MCException(e);
/*      */     } 
/*      */     
/*  924 */     if (shift > 0) {
/*      */       
/*  926 */       shift = bit - shift;
/*  927 */       enc.append(map[buf << shift & mask]);
/*  928 */       len++;
/*      */     
/*      */     }
/*  931 */     else if (split) {
/*      */       
/*  933 */       int splen = spliter.length();
/*  934 */       int newlen = enc.length() - splen;
/*  935 */       if (newlen >= 0)
/*      */       {
/*  937 */         if (enc.indexOf(spliter, newlen) >= 0) {
/*  938 */           enc.setLength(newlen);
/*      */         }
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  945 */     if (split) {
/*  946 */       len %= splitlen;
/*  947 */       if (len > 0 && adjusts != null && adjusts.length > 0) {
/*  948 */         int last = splitlen - len;
/*  949 */         int alen = adjusts.length;
/*  950 */         int loop = last / alen + 1;
/*  951 */         for (int i = 0; i < loop; i++) {
/*  952 */           for (int j = 0; last > 0 && j < alen; j++) {
/*  953 */             enc.append(adjusts[j]);
/*  954 */             last--;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  960 */     return enc.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class JSON
/*      */   {
/*      */     private ObjectMapper _OM;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public enum NumberFormatType
/*      */     {
/*  985 */       S_NUMBER
/*      */       {
/*      */         
/*      */         String toString(MCNumber b)
/*      */         {
/*  990 */           return b.toString();
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         StdSerializer<MCNumber> createSerializer() {
/*  996 */           return null;
/*      */         }
/*      */       },
/*      */       
/* 1000 */       S_PLAIN
/*      */       {
/*      */         String toString(MCNumber b)
/*      */         {
/* 1004 */           return (b != null) ? b.toPlainString() : null;
/*      */         }
/*      */ 
/*      */         
/*      */         StdSerializer<MCNumber> createSerializer() {
/* 1009 */           return new NumberToStringSerializer(this);
/*      */         }
/*      */       },
/*      */       
/* 1013 */       S_SIMPLE
/*      */       {
/*      */         String toString(MCNumber b)
/*      */         {
/* 1017 */           return (b != null) ? b.toSimpleString() : null;
/*      */         }
/*      */ 
/*      */         
/*      */         StdSerializer<MCNumber> createSerializer() {
/* 1022 */           return new NumberToStringSerializer(this);
/*      */         }
/*      */       },
/*      */       
/* 1026 */       S_ENGINEERING
/*      */       {
/*      */         String toString(MCNumber b)
/*      */         {
/* 1030 */           return (b != null) ? b.toEngineeringString() : null;
/*      */         }
/*      */ 
/*      */         
/*      */         StdSerializer<MCNumber> createSerializer() {
/* 1035 */           return new NumberToStringSerializer(this);
/*      */         }
/*      */       },
/* 1038 */       S_SCIENTIFIC
/*      */       {
/*      */         String toString(MCNumber b)
/*      */         {
/* 1042 */           return (b != null) ? b.toString() : null;
/*      */         }
/*      */ 
/*      */         
/*      */         StdSerializer<MCNumber> createSerializer() {
/* 1047 */           return new NumberToStringSerializer(this);
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */       
/*      */       abstract String toString(MCNumber param2MCNumber);
/*      */ 
/*      */       
/*      */       abstract StdSerializer<MCNumber> createSerializer();
/*      */ 
/*      */       
/*      */       private class NumberToStringSerializer
/*      */         extends StdSerializer<MCNumber>
/*      */       {
/*      */         MCDataConvUtil.JSON.NumberFormatType _strtyp;
/*      */ 
/*      */         
/*      */         private NumberToStringSerializer(Class<MCNumber> t) {
/* 1066 */           super(t);
/*      */         }
/*      */         
/*      */         NumberToStringSerializer(MCDataConvUtil.JSON.NumberFormatType s) {
/* 1070 */           this(MCNumber.class);
/* 1071 */           this._strtyp = s;
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         public void serialize(MCNumber value, JsonGenerator jgen, SerializerProvider provider) throws IOException {
/* 1077 */           jgen.writeObject(this._strtyp.toString(value));
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private class CalSerializer<T extends MCCalendarDate<T>>
/*      */       extends JsonSerializer<T>
/*      */     {
/* 1091 */       private String _fmt = "yyyy-MM-dd'T'HH:mm:ss.SSSZ";
/*      */       
/* 1093 */       private Locale _lcl = MCSys.user.locale();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       CalSerializer(String f) {
/* 1099 */         this._fmt = f;
/*      */       }
/*      */       
/*      */       CalSerializer(String f, Locale l) {
/* 1103 */         this._fmt = f;
/* 1104 */         this._lcl = l;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       public void serialize(T value, JsonGenerator jgen, SerializerProvider provider) throws IOException, JsonProcessingException {
/* 1111 */         String s = null;
/* 1112 */         if (value != null) {
/* 1113 */           SimpleDateFormat f = new SimpleDateFormat(this._fmt, this._lcl);
/* 1114 */           s = value.toString(f);
/*      */         } 
/* 1116 */         jgen.writeString(s);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       CalSerializer() {}
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1129 */     private StdSerializer<MCNumber> _num2str = NumberFormatType.S_SIMPLE
/* 1130 */       .createSerializer();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1135 */     private CalSerializer<MCDate> _dt2str = new CalSerializer<>();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1140 */     private CalSerializer<MCTimestamp> _ts2str = new CalSerializer<>();
/*      */     
/* 1142 */     private List<DeserializationFeature> _deserializer = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private JSON() {
/* 1155 */       this._deserializer.add(DeserializationFeature.USE_BIG_INTEGER_FOR_INTS);
/* 1156 */       this._deserializer.add(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static final JSON create() {
/* 1168 */       return new JSON();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final JSON setNumberFormat(NumberFormatType type) {
/* 1180 */       this._OM = null;
/* 1181 */       this._num2str = (type == null) ? null : type.createSerializer();
/* 1182 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final JSON setDateFormat(String fmt, Locale lcl) {
/* 1195 */       this._OM = null;
/* 1196 */       this._dt2str = new CalSerializer<>(fmt, lcl);
/* 1197 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final JSON setDateFormat(String fmt) {
/* 1210 */       this._OM = null;
/* 1211 */       this._dt2str = new CalSerializer<>(fmt);
/* 1212 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final JSON setTimestampFormat(String fmt, Locale lcl) {
/* 1225 */       this._OM = null;
/* 1226 */       this._ts2str = new CalSerializer<>(fmt, lcl);
/* 1227 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final JSON setTimestampFormat(String fmt) {
/* 1240 */       this._OM = null;
/* 1241 */       this._ts2str = new CalSerializer<>(fmt);
/* 1242 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public final void setDeserializer(List<DeserializationFeature> deserializer) {
/* 1252 */       this._OM = null;
/* 1253 */       this._deserializer = deserializer;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private ObjectMapper createObjectMapper() {
/* 1263 */       ObjectMapper om = new ObjectMapper();
/*      */       
/* 1265 */       SimpleModule mod = new SimpleModule();
/* 1266 */       if (this._num2str != null) {
/* 1267 */         mod.addSerializer(MCNumber.class, (JsonSerializer)this._num2str);
/*      */       }
/* 1269 */       mod.addSerializer(MCDate.class, this._dt2str);
/* 1270 */       mod.addSerializer(MCTimestamp.class, this._ts2str);
/* 1271 */       om.registerModule((Module)mod);
/*      */ 
/*      */       
/* 1274 */       for (DeserializationFeature e : this._deserializer) {
/* 1275 */         om.enable(e);
/*      */       }
/*      */       
/* 1278 */       return om;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String toJson_Impl(Object o) {
/* 1289 */       if (this._OM == null) {
/* 1290 */         this._OM = createObjectMapper();
/*      */       }
/*      */       try {
/* 1293 */         return this._OM.writeValueAsString(o);
/*      */       }
/* 1295 */       catch (JsonProcessingException e) {
/* 1296 */         throw new MCException(e);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String toJson(Map<String, Object> o) {
/* 1309 */       return toJson_Impl(o);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String toJson(Map[] o) {
/* 1321 */       return toJson_Impl(o);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Map<String, Object> toMap(String json) {
/* 1334 */       if (json == null) {
/* 1335 */         return null;
/*      */       }
/* 1337 */       if (this._OM == null) {
/* 1338 */         this._OM = createObjectMapper();
/*      */       }
/*      */       try {
/* 1341 */         return (Map<String, Object>)this._OM.readValue(json, 
/* 1342 */             new TypeReference<LinkedHashMap<String, Object>>()
/*      */             {
/*      */             
/*      */             });
/* 1346 */       } catch (Exception e) {
/* 1347 */         throw new MCException(e);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public List<Map<String, Object>> toArray(String json) {
/* 1361 */       if (json == null) {
/* 1362 */         return null;
/*      */       }
/* 1364 */       if (this._OM == null) {
/* 1365 */         this._OM = createObjectMapper();
/*      */       }
/*      */       try {
/* 1368 */         List<LinkedHashMap<String, Object>> ret = (List<LinkedHashMap<String, Object>>)this._OM.readValue(json, 
/* 1369 */             new TypeReference<List<LinkedHashMap<String, Object>>>() {  }
/*      */           );
/* 1371 */         return (List)ret;
/*      */       }
/* 1373 */       catch (Exception e) {
/* 1374 */         throw new MCException(e);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Map<String, String> toMapString(String json) {
/* 1389 */       if (json == null) {
/* 1390 */         return null;
/*      */       }
/* 1392 */       if (this._OM == null) {
/* 1393 */         this._OM = createObjectMapper();
/*      */       }
/*      */       try {
/* 1396 */         return (Map<String, String>)this._OM.readValue(json, 
/* 1397 */             new TypeReference<LinkedHashMap<String, String>>()
/*      */             {
/*      */             
/*      */             });
/* 1401 */       } catch (Exception e) {
/* 1402 */         throw new MCException(e);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public List<Map<String, String>> toArrayString(String json) {
/* 1417 */       if (json == null) {
/* 1418 */         return null;
/*      */       }
/* 1420 */       if (this._OM == null) {
/* 1421 */         this._OM = createObjectMapper();
/*      */       }
/*      */       try {
/* 1424 */         List<LinkedHashMap<String, String>> ret = (List<LinkedHashMap<String, String>>)this._OM.readValue(json, 
/* 1425 */             new TypeReference<List<LinkedHashMap<String, String>>>() {  }
/*      */           );
/* 1427 */         return (List)ret;
/*      */       }
/* 1429 */       catch (Exception e) {
/* 1430 */         throw new MCException(e);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Deprecated
/*      */     public JsonNode toJsonNode(String json) {
/* 1468 */       if (json == null) {
/* 1469 */         return null;
/*      */       }
/* 1471 */       if (this._OM == null) {
/* 1472 */         this._OM = createObjectMapper();
/*      */       }
/*      */       try {
/* 1475 */         return this._OM.readTree(json);
/*      */       }
/* 1477 */       catch (Exception e) {
/* 1478 */         throw new MCException(e);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     @Deprecated
/*      */     public JsonNode toJsonNode(File jsonFile) {
/* 1493 */       if (jsonFile == null) {
/* 1494 */         return null;
/*      */       }
/* 1496 */       if (this._OM == null) {
/* 1497 */         this._OM = createObjectMapper();
/*      */       }
/*      */       try {
/* 1500 */         return this._OM.readTree(jsonFile);
/*      */       }
/* 1502 */       catch (Exception e) {
/* 1503 */         throw new MCException(e, Core_Msg_FW_A.FCUCC0021, new Object[] { jsonFile.getAbsolutePath() });
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static boolean isArray(String json) {
/* 1517 */       return (json != null) ? json.startsWith("[") : false;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class QUERY_STRING
/*      */   {
/*      */     public static final String AMPERSAND = "&";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static final String EQUAL = "=";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public static final QUERY_STRING create() {
/* 1571 */       return new QUERY_STRING();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String toQueryString_Impl(Map<String, String> request) {
/* 1583 */       boolean notFirst = false;
/* 1584 */       StringBuilder sb = new StringBuilder();
/*      */       
/* 1586 */       for (Map.Entry<String, String> entry : request.entrySet()) {
/*      */         
/* 1588 */         if (notFirst) {
/* 1589 */           sb.append("&");
/*      */         }
/* 1591 */         notFirst = true;
/*      */ 
/*      */         
/*      */         try {
/* 1595 */           sb.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
/* 1596 */           sb.append("=");
/*      */ 
/*      */           
/* 1599 */           sb.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
/*      */         }
/* 1601 */         catch (UnsupportedEncodingException e) {
/* 1602 */           throw new MCException(e);
/*      */         } 
/*      */       } 
/* 1605 */       return sb.toString();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String toQueryString(Map<String, String> o) {
/* 1617 */       return toQueryString_Impl(o);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map<String, Object> toMap(MCRow r) {
/* 1632 */     return toMap(r, (List<String>)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map<String, Object> toMap(MCRow r, List<String> items) {
/* 1651 */     String[] ca = r.getColumnPathArray();
/* 1652 */     LinkedHashMap<String, Object> m = new LinkedHashMap<>(ca.length);
/* 1653 */     if (items == null) {
/* 1654 */       byte b; int i; String[] arrayOfString; for (i = (arrayOfString = ca).length, b = 0; b < i; ) { String c = arrayOfString[b];
/* 1655 */         m.put(c, r.getValue(c));
/*      */         b++; }
/*      */     
/*      */     } else {
/* 1659 */       for (String c : items) {
/* 1660 */         m.put(c, r.getValue(c));
/*      */       }
/*      */     } 
/* 1663 */     m.put("row_status", r.getStatus().toString());
/* 1664 */     return m;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map<String, Object>[] toMap(MCList<?> l) {
/* 1678 */     return toMap(l, (List<String>)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map<String, Object>[] toMap(MCList<?> l, List<String> items) {
/* 1697 */     String[] ca = l.getColumnPathArray();
/*      */     
/* 1699 */     LinkedHashMap[] ma = new LinkedHashMap[l.size()];
/* 1700 */     for (int i = 0; i < l.size(); i++) {
/* 1701 */       LinkedHashMap<String, Object> m = new LinkedHashMap<>(ca.length);
/* 1702 */       if (items == null) {
/* 1703 */         byte b; int j; String[] arrayOfString; for (j = (arrayOfString = ca).length, b = 0; b < j; ) { String c = arrayOfString[b];
/*      */           
/* 1705 */           m.put(c, l.getValue(i, c));
/*      */           b++; }
/*      */       
/*      */       } else {
/* 1709 */         for (String c : items)
/*      */         {
/* 1711 */           m.put(c, l.getValue(i, c));
/*      */         }
/*      */       } 
/* 1714 */       m.put("row_status", l.get(i).getStatus().toString());
/* 1715 */       ma[i] = m;
/*      */     } 
/* 1717 */     return (Map<String, Object>[])ma;
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCor\\util\MCDataConvUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */