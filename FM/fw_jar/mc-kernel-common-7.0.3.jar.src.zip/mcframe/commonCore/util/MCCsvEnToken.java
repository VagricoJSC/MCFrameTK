/*     */ package mcframe.commonCore.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCCsvEnToken
/*     */ {
/*     */   private static final char DQ = '"';
/*     */   private static final char CM = ',';
/*     */   private static final char NN = '\n';
/*     */   private static final char RR = '\r';
/*  37 */   private char _delimiter = ',';
/*     */ 
/*     */ 
/*     */   
/*     */   private Reader csvReader;
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] nTokens;
/*     */ 
/*     */   
/*     */   public static final int NORMAL_STATUS = 0;
/*     */ 
/*     */   
/*  51 */   private int csvErrorCd = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean inDQ = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean _unicode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean _head;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCCsvEnToken(String targetString) {
/* 109 */     this._unicode = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 117 */     this._head = true; this.csvReader = new StringReader(targetString); } public MCCsvEnToken(Reader targetReader) { this._unicode = false; this._head = true; this.csvReader = targetReader; } public MCCsvEnToken(Reader targetReader, boolean unicode) { this._unicode = false; this._head = true;
/*     */     this.csvReader = targetReader;
/*     */     this._unicode = unicode; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDelimiter(char delimiter) {
/* 129 */     this._delimiter = delimiter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDoubleQuotation() {
/* 140 */     return this.inDQ;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDoubleQuotation(boolean DQ) {
/* 151 */     this.inDQ = DQ;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasMoreTokens() {
/* 163 */     if (this.nTokens != null) {
/* 164 */       return true;
/*     */     }
/* 166 */     if (this.csvErrorCd != 0) {
/* 167 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 171 */     boolean innerDQ = false;
/*     */ 
/*     */     
/* 174 */     List<String> tokens = new ArrayList<>();
/*     */ 
/*     */     
/* 177 */     StringBuilder tempBuff = new StringBuilder();
/*     */ 
/*     */ 
/*     */     
/*     */     while (true) {
/*     */       int tempInt;
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 187 */         if ((tempInt = this.csvReader.read()) == -1) {
/* 188 */           throw new IOException();
/*     */         }
/*     */       }
/* 191 */       catch (IOException iOException) {
/*     */         
/* 193 */         if (!innerDQ) {
/* 194 */           if (tempBuff.toString().trim().length() > 0) {
/* 195 */             tokens.add(tempBuff.toString());
/*     */           }
/*     */           else {
/*     */             
/* 199 */             tokens.add(null);
/*     */           } 
/*     */         }
/* 202 */         if (tokens.size() == 1 && (tokens.get(0) == null || ((String)tokens.get(0)).length() == 0)) {
/* 203 */           return false;
/*     */         }
/* 205 */         this.nTokens = toStringArray(tokens);
/* 206 */         return true;
/*     */       } 
/* 208 */       char temp = (char)tempInt;
/*     */       
/* 210 */       if (this._head) {
/* 211 */         this._head = false;
/*     */         
/* 213 */         if (this._unicode && (tempInt == 65279 || tempInt == 65534)) {
/*     */           continue;
/*     */         }
/*     */       } 
/* 217 */       if (innerDQ) {
/* 218 */         if (this.inDQ && temp == '"') {
/*     */ 
/*     */           
/*     */           try {
/*     */ 
/*     */             
/* 224 */             if ((tempInt = this.csvReader.read()) == -1) {
/* 225 */               throw new IOException();
/*     */             }
/*     */           }
/* 228 */           catch (IOException iOException) {
/*     */             
/* 230 */             tokens.add(tempBuff.toString());
/* 231 */             if (tokens.size() == 1 && ((String)tokens.get(0)).length() == 0) {
/* 232 */               return false;
/*     */             }
/* 234 */             this.nTokens = toStringArray(tokens);
/* 235 */             return true;
/*     */           } 
/* 237 */           temp = (char)tempInt;
/*     */           
/* 239 */           if (temp == '"') {
/*     */             
/* 241 */             tempBuff.append(temp);
/*     */             continue;
/*     */           } 
/* 244 */           if (temp == this._delimiter) {
/*     */ 
/*     */             
/* 247 */             innerDQ = false;
/*     */             
/* 249 */             tokens.add(tempBuff.toString());
/* 250 */             tempBuff = new StringBuilder();
/*     */             
/*     */             continue;
/*     */           } 
/* 254 */           if (temp == '\n' || temp == '\r') {
/*     */ 
/*     */             
/*     */             try {
/* 258 */               if (temp == '\r') {
/* 259 */                 this.csvReader.skip(1L);
/*     */               }
/*     */             }
/* 262 */             catch (IOException iOException) {}
/*     */ 
/*     */ 
/*     */             
/* 266 */             tokens.add(tempBuff.toString());
/* 267 */             tempBuff = new StringBuilder();
/* 268 */             this.nTokens = toStringArray(tokens);
/* 269 */             return true;
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 274 */           innerDQ = false;
/* 275 */           tempBuff.append(temp);
/*     */ 
/*     */ 
/*     */           
/*     */           continue;
/*     */         } 
/*     */ 
/*     */         
/* 283 */         tempBuff.append(temp);
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 288 */       if (this.inDQ && temp == '"') {
/*     */         
/* 290 */         if (tempBuff.length() == 0) {
/*     */           
/* 292 */           innerDQ = true;
/*     */           
/*     */           continue;
/*     */         } 
/* 296 */         tempBuff.append(temp);
/*     */         
/*     */         continue;
/*     */       } 
/* 300 */       if (temp == this._delimiter) {
/*     */ 
/*     */         
/* 303 */         if (tempBuff.toString().trim().length() > 0) {
/* 304 */           tokens.add(tempBuff.toString());
/*     */         }
/*     */         else {
/*     */           
/* 308 */           tokens.add(null);
/*     */         } 
/*     */         
/* 311 */         tempBuff = new StringBuilder();
/*     */         continue;
/*     */       } 
/* 314 */       if (temp == '\n' || temp == '\r') {
/*     */ 
/*     */         
/*     */         try {
/* 318 */           if (temp == '\r') {
/* 319 */             this.csvReader.skip(1L);
/*     */           }
/*     */         }
/* 322 */         catch (IOException iOException) {}
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 327 */         if (tempBuff.toString().trim().length() > 0) {
/* 328 */           tokens.add(tempBuff.toString());
/*     */         }
/*     */         else {
/*     */           
/* 332 */           tokens.add(null);
/*     */         } 
/*     */         
/* 335 */         tempBuff = new StringBuilder();
/* 336 */         this.nTokens = toStringArray(tokens);
/* 337 */         return true;
/*     */       } 
/*     */ 
/*     */       
/* 341 */       tempBuff.append(temp);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] nextLineTokens() {
/* 359 */     if (this.nTokens != null) {
/* 360 */       String[] ret = this.nTokens;
/* 361 */       this.nTokens = null;
/* 362 */       return ret;
/*     */     } 
/*     */     
/* 365 */     if (!hasMoreTokens()) {
/* 366 */       return null;
/*     */     }
/* 368 */     return nextLineTokens();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String[] toStringArray(List<String> strVector) {
/* 381 */     Object[] o = strVector.toArray();
/* 382 */     String[] ret = new String[o.length];
/* 383 */     for (int i = 0; i < o.length; i++) {
/* 384 */       ret[i] = (String)o[i];
/*     */     }
/* 386 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void finalize() {
/*     */     try {
/* 399 */       if (this.csvReader != null) {
/* 400 */         this.csvReader.close();
/*     */       }
/*     */     }
/* 403 */     catch (IOException iOException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasError() {
/* 415 */     return (this.csvErrorCd != 0);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCor\\util\MCCsvEnToken.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */