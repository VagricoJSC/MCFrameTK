/*     */ package mcframe.commonCore.util;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.net.URL;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.file.Files;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MCFileUtil
/*     */ {
/*     */   public static final URL URIToURL(String uri) {
/*  45 */     if (uri == null) {
/*  46 */       return null;
/*     */     }
/*     */     try {
/*  49 */       URI uriobj = new URI(uri);
/*  50 */       return uriobj.toURL();
/*  51 */     } catch (Exception ex) {
/*     */       
/*  53 */       throw new MCException(ex, Core_Msg_FW_A.FCUCC0005, new Object[] { uri });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final URL fileToURL(File file) {
/*  67 */     if (file == null) {
/*  68 */       return null;
/*     */     }
/*     */     try {
/*  71 */       return file.toURI().toURL();
/*  72 */     } catch (MalformedURLException ex) {
/*     */       
/*  74 */       throw new MCException(ex, Core_Msg_FW_A.FCUCC0007, new Object[] { file });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static File URLToFile(URL url) {
/*  88 */     if (url == null) {
/*  89 */       return null;
/*     */     }
/*     */     try {
/*  92 */       return new File(url.toURI());
/*  93 */     } catch (Exception ex) {
/*     */       
/*  95 */       throw new MCException(ex, Core_Msg_FW_A.FCUCC0006, new Object[] { url });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void copy(File from, File to) {
/* 121 */     if (from == null || to == null) {
/*     */       return;
/*     */     }
/* 124 */     if (to.equals(from)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 130 */     File toDir = to.getParentFile();
/* 131 */     mkDir(toDir);
/*     */     try {
/* 133 */       Exception exception2, exception1 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 148 */     catch (FileNotFoundException ex) {
/*     */       
/* 150 */       throw new MCException(ex, Core_Msg_FW_A.FCUCC0008, new Object[] { from.getAbsoluteFile() });
/*     */     }
/* 152 */     catch (IOException ex) {
/*     */       
/* 154 */       throw new MCException(ex, Core_Msg_FW_A.FCUCC0010, new Object[] {
/* 155 */             from.getAbsoluteFile(), to.getAbsoluteFile()
/*     */           });
/*     */     } 
/*     */     
/* 159 */     to.setLastModified(from.lastModified());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void copyDir(File from, File to) {
/* 387 */     if (!from.isDirectory())
/*     */     {
/* 389 */       throw new MCException(Core_Msg_FW_A.FCUCC0016, new Object[] { from.getAbsoluteFile() });
/*     */     }
/* 391 */     if (!to.isDirectory()) {
/*     */ 
/*     */       
/* 394 */       if (to.isFile())
/*     */       {
/* 396 */         throw new MCException(Core_Msg_FW_A.FCUCC0017, new Object[] { to.getAbsoluteFile() });
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 401 */       mkDir(to);
/*     */     } 
/*     */ 
/*     */     
/* 405 */     mkDir(to); byte b; int i;
/*     */     File[] arrayOfFile;
/* 407 */     for (i = (arrayOfFile = from.listFiles()).length, b = 0; b < i; ) { File member = arrayOfFile[b];
/* 408 */       String name = member.getName();
/* 409 */       if (!name.equals(".") && !name.equals("..")) {
/*     */ 
/*     */         
/* 412 */         File target = new File(to, name);
/*     */         
/* 414 */         if (member.isDirectory()) {
/* 415 */           copyDir(member, target);
/*     */         }
/*     */         else {
/*     */           
/* 419 */           copy(member, target);
/*     */         } 
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void rmDir(File dir) {
/* 439 */     if (dir == null || !dir.isDirectory()) {
/*     */       return;
/*     */     }
/* 442 */     File[] members = dir.listFiles(); byte b; int i; File[] arrayOfFile1;
/* 443 */     for (i = (arrayOfFile1 = members).length, b = 0; b < i; ) { File member = arrayOfFile1[b];
/* 444 */       if (member.isFile()) {
/*     */         try {
/* 446 */           Files.deleteIfExists(member.toPath());
/*     */         }
/* 448 */         catch (Throwable e) {
/*     */           
/* 450 */           throw new MCException(e, Core_Msg_FW_A.FCUCC0018, new Object[] { dir.getAbsolutePath() });
/*     */         } 
/*     */       } else {
/*     */         
/* 454 */         rmDir(member);
/*     */       }  b++; }
/*     */     
/*     */     try {
/* 458 */       Files.deleteIfExists(dir.toPath());
/*     */     }
/* 460 */     catch (Throwable e) {
/*     */       
/* 462 */       throw new MCException(e, Core_Msg_FW_A.FCUCC0018, new Object[] { dir.getAbsolutePath() });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean mkDir(File dir) {
/* 479 */     if (dir == null) {
/* 480 */       return false;
/*     */     }
/*     */     
/* 483 */     if (!dir.exists()) {
/* 484 */       mkDirImpl(dir);
/* 485 */       return true;
/*     */     } 
/* 487 */     if (dir.isFile())
/*     */     {
/* 489 */       throw new MCException(Core_Msg_FW_A.FCUCC0011, new Object[] { dir.getAbsolutePath() });
/*     */     }
/* 491 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void mkDirImpl(File dir) {
/* 506 */     File p = dir.getParentFile();
/* 507 */     if (p != null && !p.exists()) {
/* 508 */       mkDirImpl(p);
/*     */     }
/* 510 */     if (!dir.mkdir())
/*     */     {
/* 512 */       throw new MCException(Core_Msg_FW_A.FCUCC0011, new Object[] { dir.getAbsolutePath() });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static char[] readText(File file) {
/* 537 */     return readText(file, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static char[] readText(File file, String charset) {
/* 559 */     if (file == null) {
/* 560 */       return null;
/*     */     }
/*     */     
/* 563 */     StringBuilder sb = new StringBuilder();
/* 564 */     readText(sb, file, charset);
/* 565 */     char[] buf = new char[sb.length()];
/* 566 */     sb.getChars(0, buf.length, buf, 0);
/* 567 */     return buf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void readText(Appendable buf, File file) {
/* 591 */     readText(buf, file, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void readText(Appendable buf, File file, String charset) {
/* 618 */     if (buf == null) {
/*     */       return;
/*     */     }
/* 621 */     if (file == null) {
/*     */       return;
/*     */     }
/* 624 */     if (charset == null) {
/* 625 */       charset = Charset.defaultCharset().name();
/*     */     }
/*     */     try {
/* 628 */       Exception exception2, exception1 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 638 */     catch (FileNotFoundException e) {
/*     */ 
/*     */       
/* 641 */       throw new MCException(e, Core_Msg_FW_A.FCUCC0013, new Object[] { file.getAbsolutePath() });
/*     */     }
/* 643 */     catch (UnsupportedEncodingException e) {
/*     */ 
/*     */       
/* 646 */       throw new MCException(e, Core_Msg_FW_A.FCUCC0012, new Object[] { file.getAbsolutePath() });
/*     */     }
/* 648 */     catch (IOException e) {
/*     */ 
/*     */ 
/*     */       
/* 652 */       throw new MCException(e, Core_Msg_FW_A.FCUCC0014, new Object[] { file.getAbsolutePath() });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writeText(CharSequence text, File file) {
/* 687 */     writeText(text, file, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writeText(CharSequence text, File file, String charset) {
/* 713 */     char[] ca = (text != null) ? text.toString().toCharArray() : null;
/* 714 */     writeText(ca, file, charset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writeText(char[] text, File file) {
/* 737 */     writeText(text, file, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void writeText(char[] text, File file, String charset) {
/* 763 */     if (text == null) {
/*     */       return;
/*     */     }
/* 766 */     if (file == null) {
/*     */       return;
/*     */     }
/* 769 */     if (charset == null) {
/* 770 */       charset = Charset.defaultCharset().name();
/*     */     }
/*     */ 
/*     */     
/* 774 */     mkDir(file.getParentFile());
/*     */     try {
/* 776 */       Exception exception2, exception1 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 784 */     catch (FileNotFoundException e) {
/*     */ 
/*     */       
/* 787 */       throw new MCException(e, Core_Msg_FW_A.FCUCC0013, new Object[] { file.getAbsolutePath() });
/*     */     }
/* 789 */     catch (UnsupportedEncodingException e) {
/*     */ 
/*     */       
/* 792 */       throw new MCException(e, Core_Msg_FW_A.FCUCC0012, new Object[] { file.getAbsolutePath() });
/*     */     }
/* 794 */     catch (IOException e) {
/*     */ 
/*     */ 
/*     */       
/* 798 */       throw new MCException(e, Core_Msg_FW_A.FCUCC0015, new Object[] { file.getAbsolutePath() });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getExtension(String file) {
/* 810 */     if (MCStringUtil.isNull(file)) {
/* 811 */       return null;
/*     */     }
/* 813 */     int point = file.lastIndexOf('.');
/* 814 */     if (point != -1) {
/* 815 */       return file.substring(point + 1);
/*     */     }
/* 817 */     return file;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCor\\util\MCFileUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */