/*     */ package mcframe.commonCore.util;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MCSimpleList<E>
/*     */ {
/*     */   private final Class<E> type;
/*  65 */   private E[] list = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCSimpleList(Class<E> type) {
/*  75 */     this.type = type;
/*  76 */     this.list = create(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private E[] create(int size) {
/*  89 */     return (E[])Array.newInstance(this.type, size);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(E element) {
/* 100 */     int length = this.list.length;
/* 101 */     Object[] result = (Object[])create(length + 1);
/* 102 */     System.arraycopy(this.list, 0, result, 0, length);
/* 103 */     result[length] = element;
/* 104 */     this.list = (E[])result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAll(Object[] elements) {
/* 115 */     int length = this.list.length;
/* 116 */     int count = elements.length;
/* 117 */     Object[] result = (Object[])create(length + count);
/* 118 */     System.arraycopy(this.list, 0, result, 0, length);
/* 119 */     System.arraycopy(elements, 0, result, length, count);
/* 120 */     this.list = (E[])result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(E element) {
/* 131 */     for (int i = this.list.length - 1; i >= 0; i--) {
/* 132 */       if (this.list[i].equals(element)) {
/* 133 */         Object[] result = (Object[])create(this.list.length - 1);
/* 134 */         System.arraycopy(this.list, 0, result, 0, i);
/* 135 */         int length = result.length;
/* 136 */         if (i < length) {
/* 137 */           System.arraycopy(this.list, i + 1, result, i, length - i);
/*     */         }
/* 139 */         this.list = (E[])result;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void set(E element) {
/* 153 */     removeAll();
/* 154 */     add(element);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeAll() {
/* 164 */     this.list = create(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public E[] array() {
/* 177 */     return this.list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 188 */     return this.list.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(E element) {
/* 200 */     if (element != null) {
/* 201 */       Object[] list = (Object[])array();
/* 202 */       int length = size();
/* 203 */       if (length != 0) {
/* 204 */         for (int i = 0; i < length; i++) {
/* 205 */           if (element.equals(list[i])) {
/* 206 */             return true;
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/* 211 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCor\\util\MCSimpleList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */