/*     */ package mcframe.commonCore.resource;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import mcframe.commonCore.annotation.AutoGenResource;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.resource.ctrl.MCGroupResource;
/*     */ import mcframe.commonCore.resource.ctrl.MCReadableResource;
/*     */ import mcframe.commonCore.resource.ctrl.MCResource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @AutoGenResource
/*     */ public class MCACTypeConst
/*     */   extends MCReadableResource
/*     */   implements MCPackageResource
/*     */ {
/*     */   public static final String FILE_BASE = "MCACType";
/*  42 */   protected static final MCGroupResource.Type TYPE = MCGroupResource.Type.CONST;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String _entrytag = "type";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCACTypeConst() {
/*  59 */     super(TYPE, "MCACType");
/*     */   }
/*     */ 
/*     */   
/*     */   public final String loadPackageInit(Locale locale, String... pkgs) {
/*  64 */     return loadPackageInit(MCResource.getProjectPath(), locale, pkgs);
/*     */   }
/*     */ 
/*     */   
/*     */   public final String loadPackageInit(String[] pjpath, Locale locale, String... pkgs) {
/*  69 */     return super.loadPackageInit(pjpath, locale, pkgs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getType(String... id) {
/*  87 */     String joinid = MCResource.createKey(id);
/*  88 */     joinid = MCResource.createKey(new String[] { joinid, "type" });
/*  89 */     return getString(joinid);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean containsType(String type) {
/* 102 */     if (!MCStringUtil.isNull(type)) {
/* 103 */       return containsKey(MCResource.createKey(new String[] { type, "type" }));
/*     */     }
/* 105 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String[] findTypeKeys(String... id) {
/* 122 */     String joinid = MCResource.createKey(id);
/* 123 */     joinid = MCResource.createKey(new String[] { joinid, "type" });
/* 124 */     String[] ret = findKeys(joinid);
/* 125 */     for (int i = 0; i < ret.length; i++) {
/* 126 */       int end = ret[i].length() - "type".length() - 1;
/* 127 */       ret[i] = ret[i].substring(0, end);
/*     */     } 
/* 129 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String findTypeHierarchy(String... id) {
/* 142 */     if (id == null || id.length == 0) {
/* 143 */       return null;
/*     */     }
/* 145 */     id[id.length - 1] = MCResource.createKey(new String[] { id[id.length - 1], "type" });
/* 146 */     String ret = findHierarchy(id);
/* 147 */     if (!MCStringUtil.isNull(ret)) {
/* 148 */       int end = ret.length() - "type".length() - 1;
/* 149 */       ret = ret.substring(0, end);
/*     */     } 
/* 151 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getBoolean(String key, boolean def) {
/* 156 */     return super.getBoolean(key, def);
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getStringArray(String key) {
/* 161 */     return super.getStringArray(key);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\MCACTypeConst.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */