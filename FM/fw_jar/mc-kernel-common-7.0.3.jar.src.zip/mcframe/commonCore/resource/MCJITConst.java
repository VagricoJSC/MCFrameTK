/*     */ package mcframe.commonCore.resource;
/*     */ 
/*     */ import java.util.ConcurrentModificationException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.resource.ctrl.MCGroupResource;
/*     */ import mcframe.commonCore.resource.ctrl.MCReadableResource;
/*     */ import mcframe.commonCore.resource.ctrl.MCResource;
/*     */ import mcframe.commonCore.sys.MCSys;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class MCJITConst
/*     */   extends MCResource
/*     */ {
/*     */   final class ModLocaleKey
/*     */   {
/*     */     final String _mod;
/*     */     final Locale _lcl;
/*     */     
/*     */     ModLocaleKey(String m, Locale l) {
/*  38 */       this._mod = Objects.<String>requireNonNull(m, "m must not be null");
/*  39 */       this._lcl = Objects.<Locale>requireNonNull(l, "l must not be null");
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/*  44 */       return Objects.hash(new Object[] { this._mod, this._lcl });
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/*  49 */       if (obj instanceof ModLocaleKey) {
/*  50 */         ModLocaleKey ml = (ModLocaleKey)obj;
/*  51 */         return (Objects.equals(this._mod, ml._mod) && Objects.equals(this._lcl, ml._lcl));
/*     */       } 
/*  53 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/*  58 */       return String.valueOf(this._mod) + ":" + this._lcl.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract class JITLabelConst
/*     */     extends MCReadableResource
/*     */   {
/*     */     private static final String BLANK = "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     JITLabelConst(String modid, Locale l, String filebase) {
/*  87 */       super(MCGroupResource.Type.CONST, filebase);
/*  88 */       MCResource.tracelog(true, "loading ModuleId:" + modid, loadInitExceptVMOS(
/*  89 */             MCSys.env.MCF_HOME(), MCResource.getProjectPath(), new String[] {
/*  90 */               modid, "FC"
/*  91 */             }, l));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     JITLabelConst(String filebase) {
/* 103 */       super(MCGroupResource.Type.CONST, filebase);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     String getSourceStringBlank(String key) {
/* 128 */       return getSourceString(key, "");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 138 */   Map<ModLocaleKey, JITLabelConst> _modToLbl = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 145 */   private Object _LOCK_OBJECT = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   JITLabelConst get(String mod, Locale l) {
/* 155 */     ModLocaleKey ml = new ModLocaleKey(mod, l);
/* 156 */     JITLabelConst lbl = null;
/*     */     
/* 158 */     synchronized (this._LOCK_OBJECT) {
/*     */       try {
/* 160 */         lbl = this._modToLbl.get(ml);
/* 161 */         if (lbl == null) {
/* 162 */           lbl = createConst(mod, l);
/* 163 */           this._modToLbl.put(ml, lbl);
/*     */         }
/*     */       
/* 166 */       } catch (ConcurrentModificationException ex) {
/* 167 */         MCLog.write(ex);
/*     */       } 
/*     */     } 
/* 170 */     return lbl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getSourceString(String key, String mod, Locale locale) {
/* 182 */     if (MCStringUtil.isNull(key) || key.length() < 1) {
/* 183 */       return null;
/*     */     }
/* 185 */     JITLabelConst lbl = get(mod, locale);
/* 186 */     if (lbl == null) {
/* 187 */       return null;
/*     */     }
/* 189 */     String rtn = lbl.getSourceStringBlank(key);
/* 190 */     if (rtn != null) {
/* 191 */       return rtn;
/*     */     }
/* 193 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String[] findPattern(String pattern, String mod, Locale locale) {
/* 208 */     JITLabelConst lbl = get(mod, locale);
/* 209 */     if (lbl == null) {
/* 210 */       return new String[0];
/*     */     }
/* 212 */     return lbl.findPattern(pattern);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract JITLabelConst createConst(String paramString, Locale paramLocale);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void loadAll(final Locale l) {
/* 233 */     (new Thread()
/*     */       {
/*     */         public void run() {
/* 236 */           String[] ms = MCJITConst.getModulePath(); byte b; int i; String[] arrayOfString1;
/* 237 */           for (i = (arrayOfString1 = ms).length, b = 0; b < i; ) { String m = arrayOfString1[b];
/* 238 */             MCJITConst.this.get(m, l);
/*     */             b++; }
/*     */            }
/* 241 */       }).start();
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\MCJITConst.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */