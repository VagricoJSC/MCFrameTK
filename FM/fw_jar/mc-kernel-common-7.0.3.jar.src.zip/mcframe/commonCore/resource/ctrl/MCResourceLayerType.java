/*    */ package mcframe.commonCore.resource.ctrl;
/*    */ 
/*    */ public enum MCResourceLayerType
/*    */ {
/*  5 */   USER,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 14 */   EXT,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 23 */   SYS,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 32 */   BARCODE;
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\ctrl\MCResourceLayerType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */