/*     */ package mcframe.commonCore.resource.ctrl;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import mcframe.commonCore.resource.MCConfig;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MCResourceIOBase
/*     */ {
/*     */   protected static final String TRACE_HEADER_PREFIX = "***** ";
/*     */   protected static final String TRACE_TARGET_PREFIX = "Target Resource ";
/*  45 */   protected static final String _format = MCConfig.common.getString("resource.format", "xml");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   protected static final boolean _tracelog = (MCConfig.common.getString("log.resource.trace") != null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   protected final StringBuilder _trace = new StringBuilder(50);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void traceTargetResource(String resource) {
/*  83 */     if (_tracelog) {
/*  84 */       this._trace.append("Target Resource ");
/*  85 */       this._trace.append(resource);
/*  86 */       this._trace.append(MCResource.LINE_SEP);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final long traceFoundResource(String resource, long s, long e) {
/* 108 */     if (_tracelog) {
/* 109 */       this._trace.append("  >>>>> Found!");
/* 110 */       traceTime(s, e);
/* 111 */       this._trace.append(MCResource.LINE_SEP);
/*     */     } else {
/*     */       
/* 114 */       this._trace.append("  ");
/* 115 */       this._trace.append(resource);
/*     */       
/* 117 */       e = s;
/*     */     } 
/* 119 */     return e;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void traceReadResource(String resource, boolean ok, long s, long e) {
/* 134 */     if (_tracelog) {
/* 135 */       this._trace.append("  >>>>> Read ");
/* 136 */       this._trace.append(ok ? "Success!" : "Error!");
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 147 */     traceTime(s, e);
/* 148 */     this._trace.append(MCResource.LINE_SEP);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void traceSavedResource(String resource) {
/* 159 */     if (_tracelog) {
/* 160 */       this._trace.append("  >>>>> Saved!");
/* 161 */       this._trace.append(MCResource.LINE_SEP);
/*     */     } else {
/*     */       
/* 164 */       this._trace.append("  ");
/* 165 */       this._trace.append(resource);
/* 166 */       this._trace.append(MCResource.LINE_SEP);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void traceReadErrorResource(String resource, long s, long e) {
/* 181 */     this._trace.append("Resource Read Error!! ");
/* 182 */     this._trace.append(resource);
/* 183 */     traceTime(s, e);
/* 184 */     this._trace.append(MCResource.LINE_SEP);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void traceWriteErrorResource(String resource) {
/* 195 */     this._trace.append("Resource Write Error!! ");
/* 196 */     this._trace.append(resource);
/* 197 */     this._trace.append(MCResource.LINE_SEP);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void traceNotFoundResource(String resource, long s, long e) {
/* 211 */     if (_tracelog) {
/* 212 */       this._trace.append("  >>>>> Not Found!");
/* 213 */       traceTime(s, e);
/* 214 */       this._trace.append(MCResource.LINE_SEP);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void traceTime(long s, long e) {
/* 227 */     this._trace.append(" ( ");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 233 */     long time = e - s;
/* 234 */     this._trace.append(time);
/*     */     
/* 236 */     this._trace.append(" )");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void traceAlreadySearchedPackage(String pkg) {
/* 247 */     this._trace.append("Already Searched - Package : ");
/* 248 */     this._trace.append(pkg);
/* 249 */     this._trace.append(MCResource.LINE_SEP);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTrace(String base, Locale locale) {
/* 264 */     String trace = this._trace.toString();
/* 265 */     StringBuilder sb = new StringBuilder(trace.length() + 50);
/* 266 */     sb.append("***** ");
/* 267 */     sb.append(base);
/* 268 */     if (locale != null) {
/* 269 */       sb.append(" locale:" + locale);
/*     */     }
/* 271 */     sb.append(MCResource.LINE_SEP);
/* 272 */     sb.append(trace);
/* 273 */     return sb.toString();
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\ctrl\MCResourceIOBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */