/*     */ package mcframe.commonCore.resource.ctrl;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.Set;
/*     */ import java.util.Stack;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.resource.MCConfig;
/*     */ import mcframe.commonCore.sys.MCPackage;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.Locator;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.SAXParseException;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MCResourceBundleXMLHandler
/*     */   extends DefaultHandler
/*     */ {
/*  39 */   static final char[] LINE_SEP = MCResource.LINE_SEP.toCharArray();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final String ATTR_SKIP = "skip";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   class NodeBuf
/*     */   {
/*     */     final String key;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  68 */     StringBuilder value = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean parent = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     NodeBuf(String key) {
/*  86 */       this.key = key;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   final Stack<NodeBuf> _stack = new Stack<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCResourceBundle _bundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final MCResourceBundle.Source _type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final String _file;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final String _srcinfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final MCFileResourceReader _reader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final String[] _namespace;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 145 */   Locator _locator = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean _trim;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCResourceBundleXMLHandler(MCResourceBundle resource, MCResourceBundle.Source type, String file, MCFileResourceReader reader, String... namespace) {
/* 168 */     this._bundle = resource;
/* 169 */     this._type = type;
/* 170 */     this._file = file;
/* 171 */     this._srcinfo = MCResourceBundle.getSourceString(file, type);
/* 172 */     this._reader = reader;
/* 173 */     this._namespace = (namespace != null) ? namespace : new String[0];
/*     */ 
/*     */     
/* 176 */     boolean t = false;
/* 177 */     if (this._file != null) {
/* 178 */       String v = MCConfig.common.getString("resource.trim_xml");
/* 179 */       t = (v != null && this._file.matches(v));
/*     */     } 
/* 181 */     this._trim = t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setDocumentLocator(Locator locator) {
/* 188 */     this._locator = locator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startElement(String namespaceURI, String localName, String qName, Attributes attributes) {
/* 199 */     if (!isTargetNamespace(namespaceURI)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 204 */     NodeBuf node = null;
/* 205 */     if (attributes.getValue("skip") == null)
/*     */     {
/* 207 */       node = startNode(qName, attributes);
/*     */     }
/* 209 */     this._stack.push(node);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final NodeBuf startNode(String qName, Attributes attributes) {
/* 221 */     NodeBuf node = null;
/* 222 */     if (this._stack.isEmpty()) {
/*     */       
/* 224 */       node = new NodeBuf(null);
/*     */     } else {
/*     */       
/* 227 */       NodeBuf parent = this._stack.peek();
/* 228 */       if (parent != null) {
/*     */         
/* 230 */         parent.parent = true;
/* 231 */         String key = (parent.key != null) ? 
/* 232 */           MCResource.createKey(new String[] { parent.key, qName
/* 233 */             }) : qName;
/* 234 */         node = new NodeBuf(key);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 244 */     return node;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void endElement(String namespaceURI, String localName, String qName) {
/* 250 */     if (!isTargetNamespace(namespaceURI)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 255 */     NodeBuf node = this._stack.pop();
/* 256 */     if (node == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 261 */     String key = node.key;
/* 262 */     if (key == null) {
/*     */       return;
/*     */     }
/*     */     
/* 266 */     if (this._bundle.containsKey(key)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 272 */     String value = MCResourceItem.BLANK_VALUE;
/* 273 */     if (node.value != null) {
/* 274 */       value = MCResource.trimValue(node.value.toString());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 279 */     if (node.parent && value == null) {
/*     */       return;
/*     */     }
/*     */     
/* 283 */     if (qName.equals("include")) {
/*     */ 
/*     */ 
/*     */       
/* 287 */       include(this._stack.peek(), value);
/*     */     }
/*     */     else {
/*     */       
/* 291 */       this._bundle.set(key, value, this._srcinfo);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void characters(char[] ch, int offset, int length) {
/* 298 */     if (this._trim && MCResource.trimValue(
/* 299 */         String.valueOf(ch, offset, length)) == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 304 */     NodeBuf node = this._stack.peek();
/* 305 */     if (node == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 310 */     if (node.value == null) {
/* 311 */       node.value = new StringBuilder();
/*     */     }
/*     */ 
/*     */     
/* 315 */     int last = offset;
/* 316 */     for (int i = 0, pos = offset; i < length; i++, pos++) {
/* 317 */       if (ch[pos] == '\n') {
/*     */ 
/*     */         
/* 320 */         if (last < pos) {
/* 321 */           node.value.append(ch, last, pos - last);
/*     */         }
/*     */ 
/*     */         
/* 325 */         node.value.append(LINE_SEP);
/* 326 */         last = pos + 1;
/*     */       } 
/*     */     } 
/* 329 */     int end = offset + length;
/* 330 */     if (last < end) {
/* 331 */       node.value.append(ch, last, end - last);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isTargetNamespace(String namespaceURI) {
/* 345 */     if (namespaceURI == null) {
/* 346 */       return true;
/*     */     }
/* 348 */     int len = this._namespace.length;
/* 349 */     for (int i = 0; i < len; i++) {
/* 350 */       if (this._namespace[i] != null && 
/* 351 */         this._namespace[i].equals(namespaceURI)) {
/* 352 */         return true;
/*     */       }
/*     */     } 
/*     */     
/* 356 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void fatalError(SAXParseException spe) throws SAXException {
/* 367 */     errorReport(spe);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final void error(SAXParseException spe) {
/* 373 */     errorReport(spe);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final void warning(SAXParseException spe) {
/* 379 */     errorReport(spe);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void errorReport(SAXParseException spe) {
/* 391 */     throw new MCException(Core_Msg_FW_A.FCBJC0020, new Object[] {
/* 392 */           spe.getMessage(), 
/* 393 */           this._srcinfo, 
/* 394 */           Integer.valueOf(this._locator.getLineNumber()), 
/* 395 */           Integer.valueOf(this._locator.getColumnNumber())
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void include(NodeBuf parent, String name) {
/*     */     File f;
/*     */     String c;
/* 416 */     MCResourceBundle resource = new MCResourceBundle();
/* 417 */     name = this._reader.createFileName(name);
/* 418 */     switch (this._type) {
/*     */       case FILEPATH:
/* 420 */         f = new File((new File(this._file)).getParent(), name);
/*     */ 
/*     */         
/* 423 */         if (!this._reader.readFromFilePath(resource, f))
/*     */         {
/* 425 */           throw new MCException(Core_Msg_FW_A.FCBJC0041, new Object[] { f.getAbsolutePath() });
/*     */         }
/*     */         break;
/*     */       case CLASSPATH:
/* 429 */         c = this._file.substring(0, this._file.lastIndexOf('/'));
/* 430 */         c = MCPackage.createPackagePath(new String[] { c, name });
/*     */ 
/*     */         
/* 433 */         if (!this._reader.readFromClassPath(resource, c))
/*     */         {
/* 435 */           throw new MCException(Core_Msg_FW_A.FCBJC0041, new Object[] { c });
/*     */         }
/*     */         break;
/*     */ 
/*     */       
/*     */       default:
/*     */         return;
/*     */     } 
/*     */     
/* 444 */     synchronized (resource) {
/* 445 */       Set<String> keyset = resource.keySet();
/* 446 */       for (String key : keyset) {
/* 447 */         MCResourceItem item = resource.get(key);
/* 448 */         key = MCResource.createKey(new String[] { parent.key, key });
/* 449 */         if (!this._bundle.containsKey(key))
/* 450 */           this._bundle.set(key, item); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\ctrl\MCResourceBundleXMLHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */