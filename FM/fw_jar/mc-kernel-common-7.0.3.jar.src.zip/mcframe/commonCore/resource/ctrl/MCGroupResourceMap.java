/*     */ package mcframe.commonCore.resource.ctrl;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCGroupResourceMap
/*     */ {
/*  72 */   private final MCGroupResource.Type _type = MCGroupResource.Type.CONST;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String _filebase;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Map<String, MCGroupResource> _resmap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   private MCResourceBundleMap basemap = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 103 */   private MCResourceBundleMap initmap = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 111 */   private MCResourceBundleMap pkgmap = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 118 */   private MCResourceBundleMap usermap = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCGroupResourceMap(String filebase) {
/* 129 */     this(filebase, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCGroupResourceMap(String filebase, Map<String, MCGroupResource> resmap) {
/* 141 */     this._filebase = filebase;
/* 142 */     this._resmap = (resmap != null) ? 
/* 143 */       new HashMap<>(resmap) : 
/* 144 */       new HashMap<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFileBase() {
/* 156 */     return this._filebase;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void put(String key, MCGroupResource res) {
/* 170 */     this._resmap.put(key, res);
/*     */ 
/*     */ 
/*     */     
/* 174 */     this.pkgmap = null;
/* 175 */     this.basemap = null;
/* 176 */     this.initmap = null;
/* 177 */     this.usermap = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void resetBundleMap() {
/* 192 */     this.pkgmap = null;
/* 193 */     this.basemap = null;
/* 194 */     this.initmap = null;
/* 195 */     this.usermap = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean isLoadedBaseBundleMap() {
/* 207 */     return (this.basemap != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCResourceBundleMap getBaseBundleMap() {
/* 219 */     if (this.basemap == null) {
/* 220 */       MCResourceBundleMap map = new MCResourceBundleMap();
/* 221 */       for (Map.Entry<String, MCGroupResource> entry : this._resmap.entrySet()) {
/* 222 */         map.put(entry.getKey(), ((MCGroupResource)entry.getValue()).getBaseBundle());
/*     */       }
/* 224 */       this.basemap = map;
/*     */     } 
/* 226 */     return this.basemap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCResourceBundleMap getInitBundleMap() {
/* 237 */     if (this.initmap == null) {
/* 238 */       MCResourceBundleMap map = new MCResourceBundleMap();
/* 239 */       for (Map.Entry<String, MCGroupResource> entry : this._resmap.entrySet()) {
/* 240 */         map.put(entry.getKey(), ((MCGroupResource)entry.getValue()).getInitBundle());
/*     */       }
/* 242 */       this.initmap = map;
/*     */     } 
/* 244 */     return this.initmap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCResourceBundleMap getPackageBundleMap() {
/* 256 */     if (this.pkgmap == null) {
/* 257 */       MCResourceBundleMap map = new MCResourceBundleMap();
/* 258 */       for (Map.Entry<String, MCGroupResource> entry : this._resmap.entrySet()) {
/* 259 */         map.put(entry.getKey(), ((MCGroupResource)entry.getValue()).getPackageBundle());
/*     */       }
/* 261 */       this.pkgmap = map;
/*     */     } 
/* 263 */     return this.pkgmap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCResourceBundleMap getUserBundleMap() {
/* 274 */     if (this.usermap == null) {
/* 275 */       MCResourceBundleMap map = new MCResourceBundleMap();
/* 276 */       for (Map.Entry<String, MCGroupResource> entry : this._resmap.entrySet()) {
/* 277 */         map.put(entry.getKey(), ((MCGroupResource)entry.getValue()).getUserBundle());
/*     */       }
/* 279 */       this.usermap = map;
/*     */     } 
/* 281 */     return this.usermap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void clearInitSearchedPackage() {
/* 306 */     MCResourceBundleMap map = getPackageBundleMap();
/* 307 */     map.clearSearchedPackage();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String loadInit(String homedir, String[] pjpath, String[] mdpath, Locale locale) {
/* 327 */     for (MCGroupResource res : this._resmap.values())
/*     */     {
/* 329 */       res.loadVMOS();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 335 */     MCResourceBundleMap pkg = getPackageBundleMap();
/* 336 */     pkg.clear();
/*     */ 
/*     */     
/* 339 */     MCInitResourceLoader loader = getInitLoader(false, homedir, pjpath, mdpath);
/*     */     
/* 341 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 343 */     if (!isLoadedBaseBundleMap()) {
/* 344 */       MCResourceBundleMap base = getBaseBundleMap();
/* 345 */       sb.append(loader.loadInit(base, getFileBase(), null));
/*     */     } 
/*     */ 
/*     */     
/* 349 */     if (locale != null) {
/*     */       
/* 351 */       MCResourceBundleMap map = getInitBundleMap();
/* 352 */       map.clear();
/*     */       
/* 354 */       sb.append(loader.loadInit(map, getFileBase(), locale));
/*     */     } 
/* 356 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String loadPackageInit(String[] pjpath, Locale locale, String... pkgs) {
/* 376 */     MCResourceBundleMap map = getPackageBundleMap();
/*     */     
/* 378 */     MCInitResourceLoader loader = getInitLoader(null, pjpath, null);
/* 379 */     return loader.loadInitPackage(map, getFileBase(), locale, pkgs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCInitResourceLoader getInitLoader(String homedir, String[] pjpath, String[] mdpath) {
/* 398 */     return getFileResourceLoader(true, homedir, pjpath, mdpath);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCInitResourceLoader getInitLoader(boolean baselocale, String homedir, String[] pjpath, String[] mdpath) {
/* 419 */     return getFileResourceLoader(baselocale, homedir, pjpath, mdpath);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCFileResourceLoader getFileResourceLoader(boolean baselocale, String homedir, String[] pjpath, String[] mdpath) {
/* 438 */     return new MCFileResourceLoader(
/* 439 */         getFileResourceSequencer(baselocale, pjpath), 
/* 440 */         homedir, 
/* 441 */         this._type.getBaseDir(), 
/* 442 */         this._type.isReadCommonUser(), 
/* 443 */         this._type.isReadModulePath() ? mdpath : null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCFileResourceSequencer getFileResourceSequencer(boolean baselocale, String[] pjpath) {
/* 461 */     return new MCFileResourceSequencer(
/* 462 */         true, 
/* 463 */         baselocale, 
/* 464 */         pjpath);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\ctrl\MCGroupResourceMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */