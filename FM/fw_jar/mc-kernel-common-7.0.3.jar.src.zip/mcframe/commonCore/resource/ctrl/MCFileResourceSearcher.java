/*     */ package mcframe.commonCore.resource.ctrl;
/*     */ 
/*     */ import java.io.File;
/*     */ import mcframe.commonCore.resource.MCConfig;
/*     */ import mcframe.commonCore.sys.MCEnv;
/*     */ import mcframe.commonCore.sys.MCPackage;
/*     */ import mcframe.commonCore.sys.MCSys;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MCFileResourceSearcher
/*     */ {
/*  36 */   private static final boolean _initdir = MCConfig.common.getBoolean("resource.init.directory", true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   private static final boolean _initcp = MCConfig.common.getBoolean("resource.init.classpath", false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String _rootdir;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String _pkgdir;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String[] _modpath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ResourcePath _rp_com;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ResourcePath[] _rp_mod;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCFileResourceSearcher(String root, String pkg, String... modules) {
/* 191 */     this._rp_com = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 357 */     this._rp_mod = null;
/*     */     this._rootdir = (root != null) ? root : MCSys.env.MCF_HOME();
/*     */     this._pkgdir = (pkg != null) ? pkg : "";
/*     */     this._modpath = modules;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isReadInitFromDir() {
/*     */     return _initdir;
/*     */   }
/*     */   
/*     */   private ResourcePath[] getModuleResourcePath() {
/* 369 */     if (this._rp_mod == null) {
/* 370 */       if (this._modpath == null || this._modpath.length == 0)
/*     */       {
/* 372 */         return null;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 377 */       int len = this._modpath.length;
/* 378 */       this._rp_mod = new ResourcePath[len];
/* 379 */       for (int i = 0; i < len; i++) {
/* 380 */         this._rp_mod[i] = new ResourcePath(this._rootdir, this._pkgdir, this._modpath[i]);
/*     */       }
/*     */     } 
/* 383 */     return this._rp_mod;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isReadInitFromPackage() {
/*     */     return _initcp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean readFromDir(MCReadableResourceBundle resource, MCFileResourceReader reader, File dir, String filename) {
/* 403 */     return reader.readFromFilePath(resource, new File(dir, filename));
/*     */   }
/*     */   boolean readInit(MCReadableResourceBundle resource, MCFileResourceReader reader, String filename) { boolean ret = false; ret = readInitForModule(resource, reader, filename); if (readInitForCommon(resource, reader, filename))
/*     */       ret = true;  return ret; }
/*     */   private boolean readInitForCommon(MCReadableResourceBundle resource, MCFileResourceReader reader, String filename) { boolean ret = false; if (this._rp_com == null)
/*     */       this._rp_com = new ResourcePath(this._rootdir, this._pkgdir, null);  ResourcePath rp = this._rp_com; if (isReadInitFromDir() && rp.dir != null)
/*     */       ret = readFromDir(resource, reader, rp.dir, filename);  if (isReadInitFromPackage() && !ret)
/*     */       ret = readFromPackage(resource, reader, rp.pkg, filename); 
/*     */     return ret; } private boolean readInitForModule(MCReadableResourceBundle resource, MCFileResourceReader reader, String filename) { boolean ret = false;
/*     */     ResourcePath[] rp = getModuleResourcePath();
/*     */     if (rp != null) {
/*     */       int len = rp.length;
/*     */       for (int i = 0; i < len; i++) {
/*     */         if (isReadInitFromDir() && (rp[i]).dir != null && readFromDir(resource, reader, (rp[i]).dir, filename)) {
/*     */           ret = true;
/*     */         } else if (isReadInitFromPackage() && readFromPackage(resource, reader, (rp[i]).pkg, filename)) {
/*     */           ret = true;
/*     */         } 
/*     */       } 
/*     */     } 
/* 423 */     return ret; } boolean readFromJar(MCReadableResourceBundle resource, MCFileResourceReader reader, File jar, String filename) { return reader.readFromJar(resource, jar, filename); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class ResourcePath
/*     */   {
/*     */     final File dir;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     final String pkg;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     ResourcePath(String basedir, String basepkg, String modid) {
/*     */       this(basedir, basepkg, modid, false);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     ResourcePath(String basedir, String basepkg, String modid, boolean force) {
/*     */       this.pkg = MCPackage.createPackagePath(new String[] { basepkg, modid });
/*     */       this.dir = MCFileResourceUtil.getDir(force, new String[] { basedir, this.pkg });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean readFromPaths(MCReadableResourceBundle resource, MCFileResourceReader reader, File[] paths, String filename) {
/* 477 */     boolean find = false;
/* 478 */     String[] mods = (this._modpath == null || this._modpath.length == 0) ? 
/*     */       
/* 480 */       new String[1] : 
/*     */       
/* 482 */       this._modpath; byte b; int i; String[] arrayOfString1;
/* 483 */     for (i = (arrayOfString1 = mods).length, b = 0; b < i; ) { String mod = arrayOfString1[b]; byte b1; int j; File[] arrayOfFile;
/* 484 */       for (j = (arrayOfFile = paths).length, b1 = 0; b1 < j; ) { File path = arrayOfFile[b1];
/* 485 */         if (path != null) {
/*     */ 
/*     */           
/* 488 */           ResourcePath rp = new ResourcePath(
/* 489 */               path.getAbsolutePath(), this._pkgdir, mod);
/* 490 */           if (path.isFile()) {
/*     */             
/* 492 */             String pkg = MCPackage.createPackagePath(new String[] { rp.pkg, filename });
/* 493 */             if (readFromJar(resource, reader, path, pkg)) {
/* 494 */               find = true;
/*     */ 
/*     */               
/*     */               break;
/*     */             } 
/* 499 */           } else if (readFromDir(resource, reader, rp.dir, filename)) {
/* 500 */             find = true; break;
/*     */           } 
/*     */         }  b1++; }
/*     */       
/*     */       b++; }
/*     */     
/* 506 */     return find;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean readFromPackage(MCReadableResourceBundle resource, MCFileResourceReader reader, String pkg, String filename) {
/* 528 */     String pkgpath = MCPackage.createPackagePath(new String[] { pkg, filename });
/* 529 */     return reader.readFromClassPath(resource, pkgpath);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean readUser(MCResourceBundle resource, MCFileResourceReader reader, String filename, String userid) {
/* 577 */     boolean ret = false;
/*     */ 
/*     */     
/* 580 */     String userhome = MCEnv.createUserHomePath(this._rootdir, userid);
/* 581 */     ResourcePath rp = new ResourcePath(userhome, this._pkgdir, null, true);
/* 582 */     if (rp.dir != null) {
/* 583 */       ret = readFromDir(resource, reader, rp.dir, filename);
/*     */     }
/*     */     
/* 586 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean readPath(MCResourceBundle resource, MCFileResourceReader reader, String filename) {
/* 615 */     boolean ret = false;
/*     */     
/* 617 */     ResourcePath rp = new ResourcePath(this._rootdir, this._pkgdir, null);
/* 618 */     if (rp.dir != null)
/*     */     {
/* 620 */       ret = readFromDir(resource, reader, rp.dir, filename);
/*     */     }
/*     */ 
/*     */     
/* 624 */     if (!ret) {
/* 625 */       ret = readFromPackage(resource, reader, rp.pkg, filename);
/*     */     }
/*     */     
/* 628 */     return ret;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\ctrl\MCFileResourceSearcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */