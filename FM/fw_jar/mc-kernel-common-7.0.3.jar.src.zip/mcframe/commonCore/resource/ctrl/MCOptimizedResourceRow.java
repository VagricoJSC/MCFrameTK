package mcframe.commonCore.resource.ctrl;

public interface MCOptimizedResourceRow extends MCResourceRow {
  String name_key();
  
  void name_key(String paramString);
  
  String getOptimizedResourceKey();
  
  String getOptimizedResourceName();
  
  void setOptimizedMark(String paramString1, String paramString2);
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\ctrl\MCOptimizedResourceRow.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */