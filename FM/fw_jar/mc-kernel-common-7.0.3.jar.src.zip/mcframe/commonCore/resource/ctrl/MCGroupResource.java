/*      */ package mcframe.commonCore.resource.ctrl;
/*      */ 
/*      */ import java.util.Arrays;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*      */ import mcframe.commonCore.notice.MCException;
/*      */ import mcframe.commonCore.resource.MCDumpResource;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class MCGroupResource
/*      */   implements MCDumpResource
/*      */ {
/*      */   protected static final String NULLVAL_STR = "(null)";
/*      */   
/*      */   protected enum Type
/*      */   {
/*   46 */     CONFIG
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       String getBaseDir()
/*      */       {
/*   54 */         return "conf";
/*      */       }
/*      */ 
/*      */       
/*      */       boolean isReadCommonUser() {
/*   59 */         return true;
/*      */       }
/*      */ 
/*      */       
/*      */       boolean isReadModulePath() {
/*   64 */         return true;
/*      */       }
/*      */     },
/*   67 */     CONST
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       String getBaseDir()
/*      */       {
/*   75 */         return "const";
/*      */       }
/*      */ 
/*      */       
/*      */       boolean isReadCommonUser() {
/*   80 */         return false;
/*      */       }
/*      */ 
/*      */       
/*      */       boolean isReadModulePath() {
/*   85 */         return true;
/*      */       }
/*      */     };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     abstract String getBaseDir();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     abstract boolean isReadCommonUser();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     abstract boolean isReadModulePath();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String getFileExtension() {
/*  135 */     return MCFileResourceReader.createReader().getFileExtension();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  152 */   private MCResourceBundle[] _layer = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  160 */   private final int LAYER_OSVM = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  167 */   private final int LAYER_USER = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  175 */   private final int LAYER_EXT = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  183 */   private final int LAYER_SYS = 3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  190 */   private final int LAYER_INIT = 4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  197 */   private final int LAYER_BASE = 5;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  204 */   private final int LAYER_PKG = 6;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  211 */   private final int LAYER_BARCODE = 7;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final Type _type;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final String _filebase;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _writable = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  240 */   protected Locale _locale = null; public static final String SYSTEM_USER_ID = "?ALL";
/*      */   public static final String BARCODE_USER_ID = "?ALL";
/*      */   public static final String EXT_ATTR_USER_ID = "?EXT";
/*      */   public static final String PGM_ID_SYSTEM = "ALL";
/*      */   public static final String SCREEN_RESOURCE_KEY_PREFIX = "_0_SCR_";
/*      */   public static final String BARCODE_RESOURCE_KEY = "barcode";
/*      */   private static final String CONV_EQ = "=";
/*      */   private static final String CONV_NULL = "";
/*      */   private static final String CONV_SRC_HEAD = "    (source) ";
/*      */   
/*      */   MCGroupResource(Type type, String filebase) {
/*  251 */     this._type = type;
/*  252 */     this._filebase = filebase;
/*      */     
/*  254 */     resetBundle();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void loadVMOS() {
/*  271 */     if (this._layer[0] != null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  276 */     MCResourceBundle resource = new MCResourceBundle();
/*      */     
/*  278 */     String keyhead = String.valueOf(this._filebase) + "#";
/*  279 */     int keyhead_len = keyhead.length();
/*      */     
/*  281 */     String[] srcpaths = {
/*  282 */         "JavaVM Parameters", 
/*  283 */         "OS Environment"
/*      */       };
/*  285 */     MCResourceBundle.Source[] srctypes = {
/*  286 */         MCResourceBundle.Source.VMENV, 
/*  287 */         MCResourceBundle.Source.OSENV
/*      */       };
/*      */     
/*  290 */     Set[] keysets = {
/*  291 */         System.getProperties().entrySet(), 
/*  292 */         System.getenv().entrySet()
/*      */       };
/*      */ 
/*      */     
/*  296 */     for (int i = 0; i < 2; i++) {
/*  297 */       int cnt = 0;
/*  298 */       String srcinfo = MCResourceBundle.getSourceString(srcpaths[i], srctypes[i]);
/*  299 */       Set<?> keyset = keysets[i];
/*  300 */       Iterator<?> ite = keyset.iterator();
/*  301 */       while (ite.hasNext()) {
/*  302 */         Map.Entry<?, ?> entry = (Map.Entry<?, ?>)ite.next();
/*  303 */         String key = entry.getKey().toString();
/*  304 */         if (key != null && key.startsWith(keyhead)) {
/*  305 */           key = key.substring(keyhead_len);
/*  306 */           MCResourceItem item = resource.get(key);
/*  307 */           if (item == null) {
/*  308 */             String val = (String)entry.getValue();
/*      */ 
/*      */             
/*  311 */             val = MCResource.trimValue(val);
/*  312 */             resource.set(key, val, srcinfo);
/*  313 */             cnt++;
/*      */           } 
/*      */         } 
/*      */       } 
/*  317 */       if (cnt > 0) {
/*  318 */         resource.addSource(srcpaths[i], srctypes[i]);
/*      */       }
/*      */     } 
/*      */     
/*  322 */     this._layer[0] = (resource.size() > 0) ? resource : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String loadInit(String homedir, String[] pjpath, String[] mdpath, Locale locale) {
/*  361 */     this._locale = locale;
/*      */ 
/*      */     
/*  364 */     loadVMOS();
/*      */ 
/*      */     
/*  367 */     return "";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String loadUser(String homedir, Locale locale) {
/*  407 */     this._locale = locale;
/*      */ 
/*      */     
/*  410 */     return "";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String saveUser(String homedir, Locale locale) {
/*  441 */     return "";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final Type getType() {
/*  452 */     return this._type;
/*      */   }
/*      */ 
/*      */   
/*      */   public final String getFileBase() {
/*  457 */     return this._filebase;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void setWritable(boolean writable) {
/*  470 */     this._writable = writable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean isWritable() {
/*  481 */     return this._writable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void resetBundle() {
/*  492 */     MCResourceBundle osvm = (this._layer != null) ? this._layer[0] : null;
/*      */     
/*  494 */     this._layer = new MCResourceBundle[] {
/*  495 */         osvm
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isLoadedBaseBundle() {
/*  508 */     return (this._layer[5] != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MCResourceBundle getBundle(int type) {
/*  521 */     if (this._layer[type] == null) {
/*  522 */       this._layer[type] = new MCResourceBundle();
/*      */     }
/*  524 */     return this._layer[type];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   MCResourceBundle getBundle(MCResourceLayerType type) {
/*  536 */     switch (type) {
/*      */       case USER:
/*  538 */         return getBundle(1);
/*      */       case EXT:
/*  540 */         return getBundle(2);
/*      */       case SYS:
/*  542 */         return getBundle(3);
/*      */       case null:
/*  544 */         return getBundle(7);
/*      */     } 
/*  546 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final MCResourceBundle getBaseBundle() {
/*  559 */     return getBundle(5);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final MCResourceBundle getInitBundle() {
/*  571 */     return getBundle(4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final MCResourceBundle getPackageBundle() {
/*  583 */     return getBundle(6);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final MCResourceBundle getUserBundle() {
/*  595 */     return getBundle(1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final MCResourceBundle getExtBundle() {
/*  606 */     return getBundle(2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final MCResourceBundle getSysBundle() {
/*  617 */     return getBundle(3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final MCResourceBundle getBarcodeBundle() {
/*  627 */     return getBundle(7);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void addInitBundle(MCGroupResource resource) {
/*  640 */     if (resource == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  645 */     int len = this._layer.length;
/*  646 */     MCResourceBundle[] l = new MCResourceBundle[len + 2];
/*  647 */     System.arraycopy(this._layer, 0, l, 0, len);
/*  648 */     l[len++] = resource.getInitBundle();
/*  649 */     l[len++] = resource.getBaseBundle();
/*  650 */     this._layer = l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void removeSearchedPackage(String pkg) {
/*  662 */     pkg = (pkg != null) ? pkg.replace('.', '/') : null;
/*      */     
/*  664 */     getPackageBundle().removeSearchedPackage(pkg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void clearInitSearchedPackage() {
/*  675 */     getPackageBundle().clearSearchedPackage();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean isUpdate() {
/*  687 */     return getUserBundle().isUpdate();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Set<String> keySet() {
/*  751 */     Set<String> set = new LinkedHashSet<>(); byte b; int i;
/*      */     MCResourceBundle[] arrayOfMCResourceBundle;
/*  753 */     for (i = (arrayOfMCResourceBundle = this._layer).length, b = 0; b < i; ) { MCResourceBundle res = arrayOfMCResourceBundle[b];
/*  754 */       if (res != null)
/*      */       {
/*  756 */         synchronized (res) {
/*  757 */           Set<String> kset = res.keySet();
/*  758 */           set.addAll(kset);
/*      */         } 
/*      */       }
/*      */       b++; }
/*      */     
/*  763 */     return set;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean containsKey(String key) {
/*  775 */     return containsKey(key, this._layer); } private boolean containsKey(String key, MCResourceBundle... resources) {
/*      */     byte b;
/*      */     int i;
/*      */     MCResourceBundle[] arrayOfMCResourceBundle;
/*  779 */     for (i = (arrayOfMCResourceBundle = resources).length, b = 0; b < i; ) { MCResourceBundle res = arrayOfMCResourceBundle[b];
/*  780 */       if (res != null && 
/*  781 */         res.containsKey(key)) {
/*  782 */         return true;
/*      */       }
/*      */       b++; }
/*      */     
/*  786 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean containsKey(MCResourceLayerType type, String key) {
/*  791 */     return containsKey(key, new MCResourceBundle[] { getBundle(type) });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String findHierarchy(String... args) {
/*  840 */     String find = null;
/*  841 */     if (args != null && args.length > 0) {
/*  842 */       int len = args.length;
/*  843 */       String base = args[len - 1];
/*  844 */       String[] items = new String[len];
/*  845 */       System.arraycopy(args, 0, items, 0, len);
/*  846 */       for (int i = len - 1; i > -1; i--) {
/*  847 */         items[i] = base;
/*  848 */         String key = MCResource.createKey(items);
/*  849 */         if (containsKey(key)) {
/*  850 */           find = key;
/*      */           break;
/*      */         } 
/*  853 */         items[i] = null;
/*      */       } 
/*      */     } 
/*  856 */     return find;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String[] findKeys(String pattern) {
/*  917 */     int max = 0; byte b1; int i; MCResourceBundle[] arrayOfMCResourceBundle1;
/*  918 */     for (i = (arrayOfMCResourceBundle1 = this._layer).length, b1 = 0; b1 < i; ) { MCResourceBundle res = arrayOfMCResourceBundle1[b1];
/*  919 */       if (res != null)
/*  920 */         max += res.size(); 
/*      */       b1++; }
/*      */     
/*  923 */     Set<String> finds = new LinkedHashSet<>(max);
/*      */     
/*  925 */     Pattern regex = toSearchRegEx(pattern); byte b2; int j; MCResourceBundle[] arrayOfMCResourceBundle2;
/*  926 */     for (j = (arrayOfMCResourceBundle2 = this._layer).length, b2 = 0; b2 < j; ) { MCResourceBundle res = arrayOfMCResourceBundle2[b2];
/*  927 */       if (res != null)
/*      */       {
/*  929 */         synchronized (res) {
/*  930 */           Set<String> keys = res.keySet();
/*  931 */           for (String key : keys) {
/*  932 */             Matcher matcher = regex.matcher(key);
/*  933 */             if (matcher.matches()) {
/*  934 */               finds.add(matcher.group(1));
/*      */             }
/*      */           } 
/*      */         } 
/*      */       }
/*      */       b2++; }
/*      */     
/*  941 */     return finds.<String>toArray(new String[finds.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String[] findPattern(String pattern) {
/* 1002 */     return findPattern(pattern, this._layer);
/*      */   }
/*      */   
/*      */   private String[] findPattern(String pattern, MCResourceBundle... resources) {
/* 1006 */     int max = 0; byte b1; int i; MCResourceBundle[] arrayOfMCResourceBundle1;
/* 1007 */     for (i = (arrayOfMCResourceBundle1 = resources).length, b1 = 0; b1 < i; ) { MCResourceBundle res = arrayOfMCResourceBundle1[b1];
/* 1008 */       if (res != null)
/* 1009 */         max += res.size(); 
/*      */       b1++; }
/*      */     
/* 1012 */     Set<String> finds = new LinkedHashSet<>(max);
/*      */     
/* 1014 */     Pattern regex = toSearchRegEx(pattern); byte b2; int j; MCResourceBundle[] arrayOfMCResourceBundle2;
/* 1015 */     for (j = (arrayOfMCResourceBundle2 = resources).length, b2 = 0; b2 < j; ) { MCResourceBundle res = arrayOfMCResourceBundle2[b2];
/* 1016 */       if (res != null)
/*      */       {
/* 1018 */         synchronized (res) {
/* 1019 */           Set<String> keys = res.keySet();
/* 1020 */           for (String key : keys) {
/* 1021 */             Matcher matcher = regex.matcher(key);
/* 1022 */             if (matcher.lookingAt()) {
/* 1023 */               finds.add(matcher.group(1));
/*      */             }
/*      */           } 
/*      */         } 
/*      */       }
/*      */       b2++; }
/*      */     
/* 1030 */     return finds.<String>toArray(new String[finds.size()]);
/*      */   }
/*      */   
/*      */   protected String[] findPattern(MCResourceLayerType type, String pattern) {
/* 1034 */     return findPattern(pattern, new MCResourceBundle[] { getBundle(type) });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final Pattern toSearchRegEx(String pattern) {
/* 1054 */     StringBuilder sb = new StringBuilder();
/* 1055 */     int len = pattern.length();
/* 1056 */     int astlen = 0;
/* 1057 */     int partlen = 0;
/* 1058 */     sb.append('(');
/* 1059 */     for (int i = 0; i < len; i++) {
/* 1060 */       char c = pattern.charAt(i);
/* 1061 */       switch (c) {
/*      */         case '.':
/* 1063 */           if (astlen >= 2 && astlen == partlen) {
/*      */             
/* 1065 */             sb.append("(|.+[.])");
/*      */           } else {
/*      */             
/* 1068 */             if (astlen > 0)
/*      */             {
/* 1070 */               sb.append("[^.]*");
/*      */             }
/* 1072 */             sb.append("[.]");
/*      */           } 
/* 1074 */           astlen = 0;
/* 1075 */           partlen = 0;
/*      */           break;
/*      */         case '*':
/* 1078 */           astlen++;
/* 1079 */           partlen++;
/*      */           break;
/*      */         default:
/* 1082 */           if (astlen > 0) {
/* 1083 */             sb.append("[^.]*");
/*      */           }
/* 1085 */           if (c == '?') {
/* 1086 */             sb.append("[^.]");
/*      */           } else {
/*      */             
/* 1089 */             sb.append(c);
/*      */           } 
/* 1091 */           astlen = 0;
/* 1092 */           partlen++;
/*      */           break;
/*      */       } 
/*      */     } 
/* 1096 */     if (astlen > 0) {
/* 1097 */       if (astlen >= 2 && astlen == partlen)
/*      */       {
/* 1099 */         sb.append(".+");
/*      */       }
/*      */       else
/*      */       {
/* 1103 */         sb.append("[^.]*");
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/* 1108 */       sb.append(")([.]|$");
/*      */     } 
/* 1110 */     sb.append(')');
/* 1111 */     return Pattern.compile(sb.toString(), 32);
/*      */   }
/*      */   
/*      */   protected boolean isSearchedProgram(MCResourceLayerType type, String pgmid) {
/* 1115 */     MCResourceBundle o = getBundle(type);
/* 1116 */     return (o != null) ? o.isSearchedProgram(pgmid) : false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getSourceString(String key) {
/* 1140 */     return getSourceString(key, (String)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getSourceString(String key, String blank) {
/* 1166 */     return getSourceString(key, blank, this._layer);
/*      */   }
/*      */   
/*      */   protected String getSourceString(MCResourceLayerType type, String key) {
/* 1170 */     return getSourceString(key, null, new MCResourceBundle[] { getBundle(type) });
/*      */   }
/*      */ 
/*      */   
/*      */   private String getSourceString(String key, String blank, MCResourceBundle... resources) {
/* 1175 */     MCResourceItem item = null; byte b; int i; MCResourceBundle[] arrayOfMCResourceBundle;
/* 1176 */     for (i = (arrayOfMCResourceBundle = resources).length, b = 0; b < i; ) { MCResourceBundle res = arrayOfMCResourceBundle[b];
/* 1177 */       if (res != null) {
/* 1178 */         item = res.get(key);
/* 1179 */         if (item != null) {
/* 1180 */           String val = item.getValue();
/*      */ 
/*      */           
/* 1183 */           val = MCResource.decrypt(val);
/* 1184 */           return (val != null) ? val : blank;
/*      */         } 
/*      */       }  b++; }
/*      */     
/* 1188 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final String setUserItem(String key, String value) {
/* 1208 */     return setItem(MCResourceLayerType.USER, key, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final String setItem(MCResourceLayerType type, String key, String value) {
/* 1227 */     if (key == null)
/*      */     {
/* 1229 */       throw new MCException(Core_Msg_FW_A.FCBJC0052, new Object[] { getFileBase(), key, value });
/*      */     }
/*      */     
/* 1232 */     checkItem(type, key, value);
/*      */ 
/*      */     
/* 1235 */     MCResourceItem item = getBundle(type).put(key, value);
/* 1236 */     return (item != null) ? item.getValue() : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void checkItem(MCResourceLayerType type, String key, String value) {
/* 1250 */     if (!isWritable()) {
/* 1251 */       throw new MCException(Core_Msg_FW_A.FCBJC0027, new Object[] { getFileBase(), key, value });
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void removeUserItem(String key) {
/* 1265 */     removeItem(MCResourceLayerType.USER, key);
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void removeItem(MCResourceLayerType type, String key) {
/* 1270 */     getBundle(type).remove(key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Map<String, String> toMap(boolean source) {
/* 1307 */     Map<String, String> map = new LinkedHashMap<>(); byte b; int i;
/*      */     MCResourceBundle[] arrayOfMCResourceBundle;
/* 1309 */     for (i = (arrayOfMCResourceBundle = this._layer).length, b = 0; b < i; ) { MCResourceBundle res = arrayOfMCResourceBundle[b];
/* 1310 */       if (res != null)
/*      */       {
/* 1312 */         synchronized (res) {
/* 1313 */           Set<Map.Entry<String, MCResourceItem>> eset = res.entrySet();
/* 1314 */           for (Map.Entry<String, MCResourceItem> e : eset) {
/* 1315 */             String key = e.getKey();
/* 1316 */             MCResourceItem item = e.getValue();
/* 1317 */             String value = item.getValue();
/* 1318 */             String src = source ? item.getSourceString() : null;
/* 1319 */             if (!map.containsKey(key)) {
/* 1320 */               if (value == null) {
/* 1321 */                 value = "";
/*      */               }
/* 1323 */               if (src != null) {
/* 1324 */                 value = String.valueOf(value) + MCResource.LINE_SEP + "    (source) " + src;
/*      */               }
/* 1326 */               map.put(key, value);
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       }
/*      */       b++; }
/*      */     
/* 1333 */     return map;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Map<String, String> toSourceMap() {
/* 1344 */     Map<String, String> map = new LinkedHashMap<>(); byte b; int i;
/*      */     MCResourceBundle[] arrayOfMCResourceBundle;
/* 1346 */     for (i = (arrayOfMCResourceBundle = this._layer).length, b = 0; b < i; ) { MCResourceBundle res = arrayOfMCResourceBundle[b];
/* 1347 */       if (res != null)
/*      */       {
/* 1349 */         synchronized (res) {
/* 1350 */           Set<Map.Entry<String, MCResourceItem>> eset = res.entrySet();
/* 1351 */           for (Map.Entry<String, MCResourceItem> e : eset) {
/* 1352 */             String key = e.getKey();
/* 1353 */             MCResourceItem item = e.getValue();
/* 1354 */             String src = item.getSourceString();
/* 1355 */             if (!map.containsKey(key)) {
/* 1356 */               map.put(key, src);
/*      */             }
/*      */           } 
/*      */         } 
/*      */       }
/*      */       b++; }
/*      */     
/* 1363 */     return map;
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1368 */     return toString(false);
/*      */   }
/*      */ 
/*      */   
/*      */   public String toString(boolean source) {
/* 1373 */     StringBuilder sb = new StringBuilder();
/*      */     
/* 1375 */     sb.append(getFileBase());
/* 1376 */     sb.append(MCResource.LINE_SEP);
/*      */     
/* 1378 */     Map<String, String> map = toMap(source);
/* 1379 */     String[] key = (String[])map.keySet().toArray((Object[])new String[0]);
/* 1380 */     Arrays.sort((Object[])key);
/* 1381 */     for (int i = 0; i < key.length; i++) {
/* 1382 */       sb.append(key[i]);
/* 1383 */       sb.append("=");
/* 1384 */       String val = map.get(key[i]);
/* 1385 */       sb.append((val != null) ? val : "");
/* 1386 */       sb.append(MCResource.LINE_SEP);
/*      */     } 
/* 1388 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   public final String[] getLoadSourceArray() {
/* 1393 */     String[] path = null; byte b; int i; MCResourceBundle[] arrayOfMCResourceBundle;
/* 1394 */     for (i = (arrayOfMCResourceBundle = this._layer).length, b = 0; b < i; ) { MCResourceBundle res = arrayOfMCResourceBundle[b];
/* 1395 */       if (res != null) {
/* 1396 */         String[] rpath = res.getPathArray();
/* 1397 */         if (path == null) {
/* 1398 */           path = rpath;
/*      */         } else {
/*      */           
/* 1401 */           int rpathlen = rpath.length;
/* 1402 */           int pathlen = path.length;
/* 1403 */           String[] newpath = new String[rpathlen + pathlen];
/* 1404 */           System.arraycopy(path, 0, newpath, 0, pathlen);
/* 1405 */           System.arraycopy(rpath, 0, newpath, pathlen, rpathlen);
/* 1406 */           path = newpath;
/*      */         } 
/*      */       }  b++; }
/*      */     
/* 1410 */     return path;
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\ctrl\MCGroupResource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */