/*     */ package mcframe.commonCore.resource.ctrl;
/*     */ 
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintWriter;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MCXMLResourceWriter
/*     */   extends MCFileResourceWriter
/*     */ {
/*     */   private static final String EXT = ".xml";
/*     */   private static final String TAG_ROOT = "mcframe";
/*     */   private static final String FORM_HEADER = "<?xml version=\"1.0\" encoding=\"%s\"?>";
/*     */   private static final String FORM_OPEN = "<%s>";
/*     */   private static final String FORM_CLOSE = "</%s>";
/*     */   private static final String INDENT = "\t";
/*  77 */   private char[] ENTITY = new char[] { '<', '>', '&', '"', '\'' };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getFileExtension() {
/*  92 */     return ".xml";
/*     */   }
/*     */   
/*     */   final void write(OutputStream os, String cs, MCResourceBundle resource, String srcinfo) {
/*     */     Charset charset;
/*  97 */     if (os == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 102 */     if (cs == null) {
/* 103 */       cs = "UTF-8";
/*     */     }
/*     */     try {
/* 106 */       charset = Charset.forName(cs);
/* 107 */     } catch (Exception ex) {
/*     */       
/* 109 */       throw new MCException(ex, Core_Msg_FW_A.FCBJC0037, new Object[] { cs });
/*     */     } 
/*     */ 
/*     */     
/* 113 */     List<String> stack = new ArrayList<>();
/*     */ 
/*     */     
/* 116 */     PrintWriter pw = createWriter(os, charset);
/* 117 */     pw.println();
/*     */ 
/*     */     
/* 120 */     if (resource != null) {
/*     */       
/* 122 */       String[] keys = null;
/* 123 */       synchronized (resource) {
/* 124 */         keys = resource.keySet().<String>toArray(new String[resource.size()]);
/*     */       } 
/* 126 */       Arrays.sort((Object[])keys); byte b; int i; String[] arrayOfString1;
/* 127 */       for (i = (arrayOfString1 = keys).length, b = 0; b < i; ) { String key = arrayOfString1[b];
/* 128 */         String[] kitem = MCResource.splitKey(key);
/*     */ 
/*     */         
/* 131 */         int kpos = matchIndex(kitem, stack, pw);
/*     */ 
/*     */         
/* 134 */         createLayerTag(kitem, kpos, stack, pw);
/*     */ 
/*     */         
/* 137 */         MCResourceItem ri = resource.get(key);
/* 138 */         String val = ri.getValue();
/* 139 */         if (val != null) {
/* 140 */           addValue(pw, val);
/*     */         }
/*     */         
/*     */         b++; }
/*     */     
/*     */     } 
/* 146 */     int smax = stack.size() - 1;
/* 147 */     for (int pos = smax; pos >= 0; pos--) {
/* 148 */       closeLayerTag(pos, smax, stack, pw);
/*     */     }
/*     */ 
/*     */     
/* 152 */     pw.println();
/* 153 */     closeWriter(pw);
/* 154 */     if (pw.checkError())
/*     */     {
/* 156 */       throw new MCException(Core_Msg_FW_A.FCBJC0054, new Object[] { srcinfo });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int matchIndex(String[] items, List<String> stack, PrintWriter pw) {
/* 175 */     int smax = stack.size() - 1;
/* 176 */     int imax = items.length - 1;
/*     */     
/* 178 */     int pos = 0;
/* 179 */     for (; pos <= smax && pos <= imax; pos++) {
/*     */       
/* 181 */       String s = stack.get(pos);
/* 182 */       String k = items[pos];
/* 183 */       if (!k.equals(s)) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */     
/* 188 */     pos--;
/* 189 */     for (int i = smax; i > pos; i--)
/*     */     {
/* 191 */       closeLayerTag(i, smax, stack, pw);
/*     */     }
/*     */     
/* 194 */     return pos;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void createLayerTag(String[] items, int pos, List<String> stack, PrintWriter pw) {
/* 212 */     int len = items.length;
/* 213 */     for (; ++pos < len; pos++) {
/* 214 */       String k = items[pos];
/*     */       
/* 216 */       pw.println();
/* 217 */       createTag(pw, k, pos);
/* 218 */       stack.add(k);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void closeLayerTag(int pos, int max, List<String> stack, PrintWriter pw) {
/* 234 */     int indent = 0;
/* 235 */     if (pos < max) {
/* 236 */       indent = pos;
/* 237 */       pw.println();
/*     */     } 
/* 239 */     String tag = stack.remove(pos);
/* 240 */     closeTag(pw, tag, indent);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final PrintWriter createWriter(OutputStream os, Charset cs) {
/* 256 */     PrintWriter pw = new PrintWriter(new OutputStreamWriter(os, cs), true);
/* 257 */     pw.format("<?xml version=\"1.0\" encoding=\"%s\"?>", new Object[] { cs.name() });
/* 258 */     pw.println();
/* 259 */     createTag(pw, "mcframe", 0);
/* 260 */     pw.println();
/* 261 */     return pw;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void closeWriter(PrintWriter pw) {
/* 274 */     pw.println();
/* 275 */     closeTag(pw, "mcframe", 0);
/* 276 */     pw.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final PrintWriter createTag(PrintWriter pw, String tag, int indent) {
/* 296 */     for (int i = 0; i < indent; i++) {
/* 297 */       pw.print("\t");
/*     */     }
/* 299 */     pw.format("<%s>", new Object[] { tag });
/* 300 */     return pw;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final PrintWriter closeTag(PrintWriter pw, String tag, int indent) {
/* 320 */     for (int i = 0; i < indent; i++) {
/* 321 */       pw.print("\t");
/*     */     }
/* 323 */     pw.format("</%s>", new Object[] { tag });
/* 324 */     return pw;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final PrintWriter addValue(PrintWriter pw, String val) {
/* 340 */     boolean cdata = false;
/* 341 */     if (val != null) {
/* 342 */       char[] carray = val.toCharArray(); byte b; int i; char[] arrayOfChar1;
/* 343 */       for (i = (arrayOfChar1 = carray).length, b = 0; b < i; ) { char c = arrayOfChar1[b]; byte b1; int j; char[] arrayOfChar;
/* 344 */         for (j = (arrayOfChar = this.ENTITY).length, b1 = 0; b1 < j; ) { char E = arrayOfChar[b1];
/* 345 */           if (c == E) {
/* 346 */             cdata = true; break;
/*     */           } 
/*     */           b1++; }
/*     */         
/*     */         b++; }
/*     */     
/*     */     } 
/* 353 */     if (cdata) {
/* 354 */       pw.print("<![CDATA[");
/* 355 */       pw.print(val);
/* 356 */       pw.print("]]>");
/*     */     } else {
/*     */       
/* 359 */       pw.print(val);
/*     */     } 
/* 361 */     return pw;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\ctrl\MCXMLResourceWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */