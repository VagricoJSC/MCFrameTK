/*    */ package mcframe.commonCore.resource.ctrl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class MCFileResourceIOBase
/*    */   extends MCResourceIOBase
/*    */ {
/*    */   public final String createFileName(String basename) {
/* 22 */     return String.valueOf(basename) + getFileExtension();
/*    */   }
/*    */   
/*    */   public abstract String getFileExtension();
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\ctrl\MCFileResourceIOBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */