/*     */ package mcframe.commonCore.resource.ctrl;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.Set;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.sys.MCPackage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MCResourceBundleINIHandler
/*     */   implements MCINIHandler
/*     */ {
/*     */   MCResourceBundle _bundle;
/*     */   final MCResourceBundle.Source _type;
/*     */   final String _file;
/*     */   final String _srcinfo;
/*     */   final MCFileResourceReader _reader;
/*  67 */   String _section = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCResourceBundleINIHandler(MCResourceBundle bundle, MCResourceBundle.Source type, String file, MCFileResourceReader reader) {
/*  82 */     this._bundle = bundle;
/*  83 */     this._type = type;
/*  84 */     this._file = file;
/*  85 */     this._srcinfo = MCResourceBundle.getSourceString(file, type);
/*  86 */     this._reader = reader;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void comment(String comment) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void section(String section) {
/*  96 */     this._section = section;
/*     */   }
/*     */ 
/*     */   
/*     */   public void entry(String key, String value) {
/* 101 */     if (this._section != null) {
/* 102 */       key = MCResource.createKey(new String[] { this._section, key });
/*     */     }
/*     */     
/* 105 */     int include = key.lastIndexOf(".include");
/* 106 */     if (include >= 0) {
/*     */ 
/*     */ 
/*     */       
/* 110 */       String prefix = key.substring(0, include);
/* 111 */       include(prefix, value);
/*     */ 
/*     */     
/*     */     }
/* 115 */     else if (!this._bundle.containsKey(key)) {
/*     */       
/* 117 */       this._bundle.set(key, value, this._srcinfo);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void include(String prefix, String name) {
/*     */     File f;
/*     */     String c;
/* 138 */     MCResourceBundle resource = new MCResourceBundle();
/* 139 */     name = this._reader.createFileName(name);
/* 140 */     switch (this._type) {
/*     */       case FILEPATH:
/* 142 */         f = new File((new File(this._file)).getParent(), name);
/*     */ 
/*     */         
/* 145 */         if (!this._reader.readFromFilePath(resource, f))
/*     */         {
/* 147 */           throw new MCException(Core_Msg_FW_A.FCBJC0041, new Object[] { f.getAbsolutePath() });
/*     */         }
/*     */         break;
/*     */       case CLASSPATH:
/* 151 */         c = this._file.substring(0, this._file.lastIndexOf('/'));
/* 152 */         c = MCPackage.createPackagePath(new String[] { c, name });
/*     */ 
/*     */         
/* 155 */         if (!this._reader.readFromClassPath(resource, c))
/*     */         {
/* 157 */           throw new MCException(Core_Msg_FW_A.FCBJC0041, new Object[] { c });
/*     */         }
/*     */         break;
/*     */ 
/*     */       
/*     */       default:
/*     */         return;
/*     */     } 
/*     */     
/* 166 */     synchronized (resource) {
/* 167 */       Set<String> keyset = resource.keySet();
/* 168 */       for (String key : keyset) {
/* 169 */         MCResourceItem item = resource.get(key);
/* 170 */         key = MCResource.createKey(new String[] { prefix, key });
/* 171 */         if (!this._bundle.containsKey(key))
/* 172 */           this._bundle.set(key, item); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\ctrl\MCResourceBundleINIHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */