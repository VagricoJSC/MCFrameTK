/*     */ package mcframe.commonCore.resource.ctrl;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class MCFileResourceReader
/*     */   extends MCFileResourceIOBase
/*     */ {
/*     */   public static final MCFileResourceReader createReader() {
/*  47 */     return _format.equals("xml") ? 
/*  48 */       new MCXMLResourceReader() : new MCINIResourceReader();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract boolean read(MCReadableResourceBundle paramMCReadableResourceBundle, InputStream paramInputStream, MCResourceBundle.Source paramSource, String paramString);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean readFromFilePath(MCReadableResourceBundle resource, File file) {
/*  88 */     String filepath = file.getAbsolutePath();
/*  89 */     MCResourceBundle.Source srctype = MCResourceBundle.Source.FILEPATH;
/*  90 */     String logresource = MCResourceBundle.getSourceString(filepath, srctype);
/*     */ 
/*     */     
/*  93 */     traceTargetResource(logresource);
/*  94 */     long stime = System.currentTimeMillis();
/*  95 */     long etime = stime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 111 */     if (!file.isFile()) {
/*     */       
/* 113 */       etime = System.currentTimeMillis();
/* 114 */       traceNotFoundResource(logresource, stime, etime);
/* 115 */       return false;
/*     */     }  try {
/* 117 */       Exception exception1 = null, exception2 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {  }
/*     */       finally
/* 132 */       { exception2 = null; if (exception1 == null) { exception1 = exception2; } else if (exception1 != exception2) { exception1.addSuppressed(exception2); }  } 
/* 133 */     } catch (FileNotFoundException fileNotFoundException) {
/*     */       
/* 135 */       etime = System.currentTimeMillis();
/* 136 */       traceNotFoundResource(logresource, stime, etime);
/* 137 */       return false;
/*     */     }
/* 139 */     catch (IOException ex) {
/*     */       
/* 141 */       etime = System.currentTimeMillis();
/* 142 */       traceReadErrorResource(logresource, stime, etime);
/* 143 */       throw new MCException(ex);
/*     */     }
/* 145 */     catch (MCException ex) {
/*     */       
/* 147 */       etime = System.currentTimeMillis();
/* 148 */       traceReadErrorResource(logresource, stime, etime);
/* 149 */       throw ex;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean readFromClassPath(MCReadableResourceBundle resource, String file) {
/* 172 */     MCResourceBundle.Source srctype = MCResourceBundle.Source.CLASSPATH;
/* 173 */     String logresource = MCResourceBundle.getSourceString(file, srctype);
/*     */ 
/*     */     
/* 176 */     traceTargetResource(logresource);
/* 177 */     long stime = System.currentTimeMillis();
/* 178 */     long etime = stime;
/*     */ 
/*     */     
/* 181 */     ClassLoader cl = Thread.currentThread().getContextClassLoader();
/* 182 */     InputStream is = cl.getResourceAsStream(file);
/* 183 */     if (is == null) {
/*     */       
/* 185 */       etime = System.currentTimeMillis();
/* 186 */       traceNotFoundResource(logresource, stime, etime);
/* 187 */       return false;
/*     */     } 
/*     */     
/*     */     try {
/* 191 */       etime = System.currentTimeMillis();
/* 192 */       boolean ret = read(resource, is, srctype, file);
/* 193 */       if (ret)
/*     */       {
/* 195 */         resource.addSource(file, srctype);
/*     */       }
/*     */       
/* 198 */       stime = traceFoundResource(logresource, stime, etime);
/* 199 */       etime = System.currentTimeMillis();
/* 200 */       traceReadResource(logresource, ret, stime, etime);
/* 201 */       return ret;
/*     */     }
/* 203 */     catch (MCException ex) {
/*     */       
/* 205 */       etime = System.currentTimeMillis();
/* 206 */       traceReadErrorResource(logresource, stime, etime);
/* 207 */       throw ex;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean readFromJar(MCReadableResourceBundle resource, File jar, String file) {
/* 231 */     String filepath = String.valueOf(jar.getAbsolutePath()) + "!/" + file;
/* 232 */     MCResourceBundle.Source srctype = MCResourceBundle.Source.JARFILE;
/* 233 */     String logresource = MCResourceBundle.getSourceString(filepath, srctype);
/*     */ 
/*     */     
/* 236 */     traceTargetResource(logresource);
/* 237 */     long stime = System.currentTimeMillis();
/* 238 */     long etime = stime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 253 */       Exception exception1 = null, exception2 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {  }
/*     */       finally
/* 285 */       { exception2 = null; if (exception1 == null) { exception1 = exception2; } else if (exception1 != exception2) { exception1.addSuppressed(exception2); }  } 
/* 286 */     } catch (IOException iOException) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 291 */       return false;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\ctrl\MCFileResourceReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */