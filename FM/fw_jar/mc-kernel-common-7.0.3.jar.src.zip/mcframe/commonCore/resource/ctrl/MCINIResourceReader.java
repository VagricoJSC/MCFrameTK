/*     */ package mcframe.commonCore.resource.ctrl;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MCINIResourceReader
/*     */   extends MCFileResourceReader
/*     */ {
/*     */   private static final String EXT = ".ini";
/*     */   static final String MULTI_START = ">>>>>";
/*     */   static final String MULTI_END = "<<<<<";
/*     */   
/*     */   public final String getFileExtension() {
/*  90 */     return ".ini";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean read(MCReadableResourceBundle resource, InputStream is, MCResourceBundle.Source type, String file) {
/*  97 */     if (resource == null || is == null) {
/*  98 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 102 */     BufferedReader br = null;
/*     */     
/*     */     try {
/* 105 */       br = new BufferedReader(new InputStreamReader(is, "UTF-8"));
/*     */     }
/* 107 */     catch (UnsupportedEncodingException unsupportedEncodingException) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 112 */     analyze(resource, br, type, file);
/*     */ 
/*     */     
/*     */     try {
/* 116 */       br.close();
/*     */     }
/* 118 */     catch (IOException iOException) {}
/*     */ 
/*     */ 
/*     */     
/* 122 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void analyze(MCReadableResourceBundle rs, BufferedReader br, MCResourceBundle.Source type, String file) {
/* 139 */     MCINIHandler handler = rs.createINIHandler(type, file, this);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 148 */     String srcinfo = MCResourceBundle.getSourceString(file, type);
/* 149 */     String line = null;
/*     */     try {
/* 151 */       while ((line = br.readLine()) != null) {
/* 152 */         if (line.length() > 0) {
/* 153 */           int end; char head = line.charAt(0);
/* 154 */           switch (head) {
/*     */             case '#':
/* 156 */               handler.comment(line);
/*     */               continue;
/*     */             case '[':
/* 159 */               end = line.indexOf(']');
/* 160 */               if (end > -1) {
/* 161 */                 handleSection(handler, line, 1, end);
/*     */                 continue;
/*     */               } 
/*     */               break;
/*     */           } 
/* 166 */           handleEntry(handler, line, br);
/*     */         }
/*     */       
/*     */       }
/*     */     
/* 171 */     } catch (IOException ex) {
/*     */       
/* 173 */       throw new MCException(ex, Core_Msg_FW_A.FCBJC0018, new Object[] { srcinfo });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void handleSection(MCINIHandler handler, String text, int start, int end) {
/* 192 */     String section = text.substring(start, end);
/* 193 */     section = MCResource.trimValue(section);
/* 194 */     handler.section(section);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void handleEntry(MCINIHandler handler, String line, BufferedReader br) throws IOException {
/* 212 */     String key = line;
/* 213 */     String val = MCResourceItem.BLANK_VALUE;
/* 214 */     int eq = line.indexOf('=');
/* 215 */     if (eq > -1) {
/* 216 */       key = line.substring(0, eq++);
/* 217 */       if (eq < line.length()) {
/* 218 */         val = line.substring(eq);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 223 */     key = MCResource.trimKey(key);
/*     */ 
/*     */     
/* 226 */     val = MCResource.trimValue(val);
/* 227 */     if (val != null && val.equals(">>>>>"))
/*     */     {
/* 229 */       val = multiLineValue(br);
/*     */     }
/*     */     
/* 232 */     handler.entry(key, val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String multiLineValue(BufferedReader br) throws IOException {
/* 248 */     StringBuilder sb = new StringBuilder();
/* 249 */     String line = null;
/* 250 */     while ((line = br.readLine()) != null) {
/*     */       
/* 252 */       line = MCResource.trimValue(line);
/* 253 */       if (line.equals("<<<<<")) {
/*     */         break;
/*     */       }
/* 256 */       sb.append(line);
/* 257 */       sb.append(MCResource.LINE_SEP);
/*     */     } 
/* 259 */     return (sb.length() > 0) ? sb.toString() : null;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\ctrl\MCINIResourceReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */