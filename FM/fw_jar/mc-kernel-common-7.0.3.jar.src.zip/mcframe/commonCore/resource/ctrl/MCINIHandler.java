package mcframe.commonCore.resource.ctrl;

interface MCINIHandler {
  void comment(String paramString);
  
  void section(String paramString);
  
  void entry(String paramString1, String paramString2);
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\ctrl\MCINIHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */