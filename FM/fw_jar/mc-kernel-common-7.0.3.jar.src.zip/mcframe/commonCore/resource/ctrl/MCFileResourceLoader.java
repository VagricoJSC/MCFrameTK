/*     */ package mcframe.commonCore.resource.ctrl;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MCFileResourceLoader
/*     */   implements MCInitResourceLoader, MCUserResourceLoader, MCPathResourceLoader
/*     */ {
/*     */   private final MCFileResourceSequencer _sequencer;
/*     */   private final MCFileResourceSearcher _searcher;
/*     */   private final boolean _commonuser;
/*     */   
/*     */   MCFileResourceLoader(MCFileResourceSequencer seq, String root, String pkg, boolean commonuser, String... modpath) {
/*  83 */     this(seq, new MCFileResourceSearcher(root, pkg, modpath), commonuser);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCFileResourceLoader(MCFileResourceSequencer seq, MCFileResourceSearcher sch, boolean commonuser) {
/*  99 */     this._sequencer = seq;
/* 100 */     this._searcher = sch;
/* 101 */     this._commonuser = commonuser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCFileResourceSequencer sequencer() {
/* 116 */     return this._sequencer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String loadInit(MCReadableResourceBundle inires, String base, Locale locale) {
/* 124 */     if (inires == null) {
/* 125 */       return "";
/*     */     }
/*     */     
/* 128 */     MCFileResourceReader reader = MCFileResourceReader.createReader();
/*     */     try {
/* 130 */       boolean ret = false;
/* 131 */       String[] seq = this._sequencer.initSequence(reader, base, locale); byte b; int i; String[] arrayOfString1;
/* 132 */       for (i = (arrayOfString1 = seq).length, b = 0; b < i; ) { String filename = arrayOfString1[b];
/* 133 */         ret = this._searcher.readInit(inires, reader, filename);
/*     */         b++; }
/*     */       
/* 136 */       if (!ret && (this._sequencer.conatainsBase() || locale == null))
/*     */       {
/*     */ 
/*     */         
/* 140 */         throw new MCException(Core_Msg_FW_A.FCBJC0021, new Object[] { base });
/*     */       }
/*     */     }
/* 143 */     catch (Exception ex) {
/*     */       
/* 145 */       throw new MCException(ex, Core_Msg_FW_A.FCBJC0024, new Object[] {
/* 146 */             base, reader.getTrace(base, locale) });
/*     */     } 
/* 148 */     return reader.getTrace(base, locale);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String loadInitPackage(MCReadableResourceBundle inires, String base, Locale locale, String... pkgs) {
/* 155 */     if (inires == null || pkgs == null) {
/* 156 */       return "";
/*     */     }
/*     */     
/* 159 */     MCFileResourceReader reader = MCFileResourceReader.createReader();
/* 160 */     String[] seq = this._sequencer.initSequence(reader, base, locale); try {
/*     */       byte b; int i; String[] arrayOfString;
/* 162 */       for (i = (arrayOfString = pkgs).length, b = 0; b < i; ) { String pkg = arrayOfString[b];
/* 163 */         String pkgpath = (pkg != null) ? pkg.replace('.', '/') : null;
/* 164 */         if (!inires.isSearchedPackage(pkgpath)) {
/*     */ 
/*     */           
/* 167 */           synchronized (MCLoadResourceLocker.getPackageLocker(pkg)) {
/* 168 */             if (!inires.isSearchedPackage(pkgpath)) {
/*     */               byte b1; int j; String[] arrayOfString1;
/* 170 */               for (j = (arrayOfString1 = seq).length, b1 = 0; b1 < j; ) { String filename = arrayOfString1[b1];
/* 171 */                 this._searcher.readFromPackage(inires, reader, pkgpath, filename);
/*     */                 
/*     */                 b1++; }
/*     */ 
/*     */               
/* 176 */               inires.addSearchedPackage(pkgpath);
/*     */             }
/*     */             else {
/*     */               
/* 180 */               reader.traceAlreadySearchedPackage(pkgpath);
/*     */             } 
/*     */             
/* 183 */             MCLoadResourceLocker.removePackageLocker(pkg);
/*     */           
/*     */           }
/*     */ 
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 191 */           reader.traceAlreadySearchedPackage(pkg);
/*     */         } 
/*     */         b++; }
/*     */     
/* 195 */     } catch (Exception ex) {
/*     */       
/* 197 */       throw new MCException(ex, Core_Msg_FW_A.FCBJC0024, new Object[] {
/* 198 */             base, reader.getTrace(base, locale) });
/*     */     } 
/* 200 */     return reader.getTrace(base, locale);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String loadInitPath(MCReadableResourceBundle inires, String base, Locale locale, String... paths) {
/* 211 */     if (inires == null || paths == null || paths.length <= 0) {
/* 212 */       return "";
/*     */     }
/*     */ 
/*     */     
/* 216 */     int pathlen = paths.length;
/* 217 */     List<File> pathlist = new ArrayList<>(pathlen); byte b; int i; String[] arrayOfString1;
/* 218 */     for (i = (arrayOfString1 = paths).length, b = 0; b < i; ) { String path = arrayOfString1[b];
/* 219 */       File file = new File(path);
/* 220 */       pathlist.add(file.exists() ? file : null); b++; }
/*     */     
/* 222 */     File[] pathfiles = pathlist.<File>toArray(new File[pathlist.size()]);
/*     */ 
/*     */     
/* 225 */     MCFileResourceReader reader = MCFileResourceReader.createReader();
/* 226 */     String[] seq = this._sequencer.initSequence(reader, base, locale); try {
/*     */       byte b1; int j; String[] arrayOfString;
/* 228 */       for (j = (arrayOfString = seq).length, b1 = 0; b1 < j; ) { String filename = arrayOfString[b1];
/* 229 */         this._searcher.readFromPaths(inires, reader, pathfiles, filename);
/*     */         b1++; }
/*     */     
/* 232 */     } catch (Exception ex) {
/*     */       
/* 234 */       throw new MCException(ex, Core_Msg_FW_A.FCBJC0024, new Object[] {
/* 235 */             base, reader.getTrace(base, locale) });
/*     */     } 
/* 237 */     return reader.getTrace(base, locale);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String loadUser(MCResourceBundle usrres, String base, Locale locale, String userid) {
/* 244 */     if (usrres == null) {
/* 245 */       return "";
/*     */     }
/*     */     
/* 248 */     MCFileResourceReader reader = MCFileResourceReader.createReader();
/*     */ 
/*     */     
/*     */     try {
/* 252 */       String[] seq = this._sequencer.userSequence(reader, base, null);
/*     */ 
/*     */       
/* 255 */       if (userid != null) {
/* 256 */         byte b; int i; String[] arrayOfString; for (i = (arrayOfString = seq).length, b = 0; b < i; ) { String filename = arrayOfString[b];
/* 257 */           this._searcher.readUser(usrres, reader, filename, userid);
/*     */           b++; }
/*     */       
/*     */       } 
/* 261 */       if (this._commonuser) {
/* 262 */         byte b; int i; String[] arrayOfString; for (i = (arrayOfString = seq).length, b = 0; b < i; ) { String filename = arrayOfString[b];
/* 263 */           this._searcher.readUser(usrres, reader, filename, null);
/*     */           b++; }
/*     */       
/*     */       } 
/* 267 */     } catch (Exception ex) {
/*     */       
/* 269 */       throw new MCException(ex, Core_Msg_FW_A.FCBJC0024, new Object[] {
/* 270 */             base, reader.getTrace(base, locale) });
/*     */     } 
/* 272 */     return reader.getTrace(base, locale);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String loadPath(MCResourceBundle pthres, String base) {
/* 278 */     if (pthres == null) {
/* 279 */       return null;
/*     */     }
/*     */     
/* 282 */     MCFileResourceReader reader = MCFileResourceReader.createReader();
/* 283 */     String[] seq = this._sequencer.userSequence(reader, base, null); try {
/*     */       byte b; int i; String[] arrayOfString;
/* 285 */       for (i = (arrayOfString = seq).length, b = 0; b < i; ) { String filename = arrayOfString[b];
/* 286 */         this._searcher.readPath(pthres, reader, filename);
/*     */         b++; }
/*     */     
/* 289 */     } catch (Exception ex) {
/*     */       
/* 291 */       throw new MCException(ex, Core_Msg_FW_A.FCBJC0024, new Object[] {
/* 292 */             base, reader.getTrace(base, null) });
/*     */     } 
/* 294 */     return reader.getTrace(base, null);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\ctrl\MCFileResourceLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */