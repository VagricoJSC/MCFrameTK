/*     */ package mcframe.commonCore.resource.ctrl;
/*     */ 
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.notice.MCMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MCGeneralReadableResource
/*     */   extends MCReadableResource
/*     */ {
/*     */   protected MCGeneralReadableResource(MCGroupResource.Type type, String filebase) {
/*  29 */     super(type, filebase);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSourceString(String key) {
/*  38 */     return super.getSourceString(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString(String key) {
/*  43 */     return super.getString(key);
/*     */   }
/*     */   
/*     */   public String getString(String key, String def) {
/*  47 */     return super.getString(key, def);
/*     */   }
/*     */   
/*     */   public String getString(String key, String def, MCMessage msg) {
/*  51 */     return super.getString(key, def, msg);
/*     */   }
/*     */ 
/*     */   
/*     */   public char getCharacter(String key) {
/*  56 */     return super.getCharacter(key);
/*     */   }
/*     */   
/*     */   public char getCharacter(String key, char def) {
/*  60 */     return super.getCharacter(key, def);
/*     */   }
/*     */   
/*     */   public char getCharacter(String key, char def, MCMessage msg) {
/*  64 */     return super.getCharacter(key, def, msg);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCNumber getNumber(String key) {
/*  69 */     return super.getNumber(key);
/*     */   }
/*     */   
/*     */   public MCNumber getNumber(String key, MCNumber def) {
/*  73 */     return super.getNumber(key, def);
/*     */   }
/*     */   
/*     */   public MCNumber getNumber(String key, MCNumber def, MCMessage msg) {
/*  77 */     return super.getNumber(key, def, msg);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getInteger(String key) {
/*  82 */     return super.getInteger(key);
/*     */   }
/*     */   
/*     */   public int getInteger(String key, int def) {
/*  86 */     return super.getInteger(key, def);
/*     */   }
/*     */   
/*     */   public int getInteger(String key, int def, MCMessage msg) {
/*  90 */     return super.getInteger(key, def, msg);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getBoolean(String key) {
/*  95 */     return super.getBoolean(key);
/*     */   }
/*     */   
/*     */   public boolean getBoolean(String key, boolean def) {
/*  99 */     return super.getBoolean(key, def);
/*     */   }
/*     */   
/*     */   public boolean getBoolean(String key, boolean def, MCMessage msg) {
/* 103 */     return super.getBoolean(key, def, msg);
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getStringArray(String key) {
/* 108 */     return super.getStringArray(key);
/*     */   }
/*     */   
/*     */   public String[] getStringArray(String key, String[] def) {
/* 112 */     return super.getStringArray(key, def);
/*     */   }
/*     */   
/*     */   public String[] getStringArray(String key, String[] def, MCMessage msg) {
/* 116 */     return super.getStringArray(key, def, msg);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\ctrl\MCGeneralReadableResource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */