/*     */ package mcframe.commonCore.resource.ctrl;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.util.Locale;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.meta.M_META;
/*     */ import mcframe.commonCore.sys.MCSys;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MCWritableResource
/*     */   extends MCReadableResource
/*     */ {
/*     */   protected MCWritableResource(MCGroupResource.Type type, String filebase) {
/*  37 */     super(type, filebase);
/*  38 */     setWritable(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String loadUser(String homedir, Locale locale) {
/*  45 */     super.loadUser(homedir, locale);
/*     */     
/*  47 */     MCResourceBundle user = getUserBundle();
/*  48 */     user.clear();
/*  49 */     MCUserResourceLoader loader = getUserLoader(homedir);
/*     */     
/*  51 */     return loadUser(loader, user, locale);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String loadUser(MCUserResourceLoader loader, MCResourceBundle bundle, Locale locale) {
/*  66 */     StringBuilder sb = new StringBuilder();
/*  67 */     long s = System.currentTimeMillis();
/*  68 */     sb.append(loader.loadUser(bundle, getFileBase(), locale, MCSys.user.ID()));
/*  69 */     long e = System.currentTimeMillis();
/*  70 */     long t = e - s;
/*  71 */     sb.append("(load total : " + t + ")\n");
/*  72 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String saveUser(String homedir, Locale locale) {
/*  78 */     super.saveUser(homedir, locale);
/*     */     
/*  80 */     MCResourceBundle user = getUserBundle();
/*  81 */     MCUserResourceSaver saver = getUserSaver(homedir);
/*  82 */     return saver.saveUser(user, getFileBase(), locale, MCSys.user.ID());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCUserResourceLoader getUserLoader(String homedir) {
/* 101 */     return getFileResourceLoader(homedir, (String[])null, (String[])null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCUserResourceSaver getUserSaver(String homedir) {
/* 118 */     return getFileResourceSaver(homedir);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCFileResourceSaver getFileResourceSaver(String homedir) {
/* 130 */     MCGroupResource.Type type = getType();
/* 131 */     return new MCFileResourceSaver(
/* 132 */         (homedir != null) ? homedir : MCSys.env.MCF_HOME(), 
/* 133 */         type.getBaseDir());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void remove(String key) {
/* 152 */     removeUserItem(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void remove(String... keys) {
/* 164 */     if (keys == null)
/*     */       return;  byte b; int i;
/*     */     String[] arrayOfString;
/* 167 */     for (i = (arrayOfString = keys).length, b = 0; b < i; ) { String k = arrayOfString[b];
/* 168 */       remove(k);
/*     */       b++; }
/*     */   
/*     */   }
/*     */   protected void remove(MCResourceLayerType type, String key) {
/* 173 */     removeItem(type, key);
/*     */   }
/*     */   
/*     */   protected void remove(MCResourceLayerType type, String... keys) {
/* 177 */     if (keys != null) {
/* 178 */       byte b; int i; String[] arrayOfString; for (i = (arrayOfString = keys).length, b = 0; b < i; ) { String k = arrayOfString[b];
/* 179 */         remove(type, k);
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setString(String key, String value) {
/* 202 */     setUserItem(key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setString(MCResourceLayerType type, String key, String value) {
/* 225 */     setItem(type, key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setCharacter(String key, char value) {
/* 241 */     setString(key, Character.toString(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setNumber(String key, MCNumber value) {
/* 257 */     String str = null;
/* 258 */     if (value != null) {
/* 259 */       str = value.toPlainString();
/*     */     }
/* 261 */     setString(key, str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setInteger(String key, int value) {
/* 277 */     setString(key, Integer.toString(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setBoolean(String key, boolean value) {
/* 293 */     setString(key, Boolean.toString(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setStringArray(String key, String[] value) {
/* 314 */     setString(key, MCStringUtil.join('"', ",", value));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setStringArray(MCResourceLayerType type, String key, String[] value) {
/* 320 */     setString(type, key, MCStringUtil.join('"', ",", value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setStringArrayKeyRotation(String pgmId, String key, String[] value) {
/* 346 */     int x = M_META.RES_VAL.length() - 2;
/* 347 */     int c = 0;
/* 348 */     String v = MCStringUtil.join('"', ",", value);
/*     */     while (true) {
/* 350 */       String k = String.valueOf(key) + "_" + String.valueOf(c++);
/* 351 */       if (MCStringUtil.isNull(v) || v.length() <= x) {
/* 352 */         String str = "_" + v + "_";
/* 353 */         setString(k, str);
/*     */         
/*     */         break;
/*     */       } 
/* 357 */       String s = "_" + v.substring(0, x) + "_";
/* 358 */       setString(k, s);
/*     */       
/* 360 */       v = v.substring(x);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setColor(String key, Color value) {
/* 380 */     (new String[3])[0] = 
/* 381 */       String.valueOf(value.getRed()); (new String[3])[1] = 
/* 382 */       String.valueOf(value.getGreen()); (new String[3])[2] = 
/* 383 */       String.valueOf(value.getBlue());
/*     */     
/* 385 */     String[] s = (value != null) ? new String[3] : null;
/* 386 */     setStringArray(key, s);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\ctrl\MCWritableResource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */