/*      */ package mcframe.commonCore.resource.ctrl;
/*      */ 
/*      */ import java.awt.Color;
/*      */ import java.awt.Font;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.IOException;
/*      */ import java.io.StringReader;
/*      */ import java.lang.annotation.Annotation;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import mcframe.commonCore.annotation.AutoGenResource;
/*      */ import mcframe.commonCore.annotation.LocaleResource;
/*      */ import mcframe.commonCore.crypt.MCCrypt;
/*      */ import mcframe.commonCore.lang.MCCalendarDate;
/*      */ import mcframe.commonCore.lang.MCDate;
/*      */ import mcframe.commonCore.lang.MCDateFieldType;
/*      */ import mcframe.commonCore.lang.MCStringUtil;
/*      */ import mcframe.commonCore.lang.MCTimestamp;
/*      */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*      */ import mcframe.commonCore.notice.MCException;
/*      */ import mcframe.commonCore.notice.MCLog;
/*      */ import mcframe.commonCore.resource.MCDumpResource;
/*      */ import mcframe.commonCore.resource.MCPackageResource;
/*      */ import mcframe.commonCore.sys.MCFactory;
/*      */ import mcframe.commonCore.sys.MCSys;
/*      */ import mcframe.commonCore.util.MCDataConvUtil;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class MCResource
/*      */ {
/*  185 */   private static final MCProjectPath pjpath = new MCProjectPath();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  194 */   private static final MCModulePath mdpath = new MCModulePath();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final char NODE_SEP = '.';
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String createKey(String... parts) {
/*  220 */     if (parts == null) {
/*  221 */       return null;
/*      */     }
/*      */     
/*  224 */     StringBuilder sb = new StringBuilder(100);
/*  225 */     int len = parts.length;
/*  226 */     if (len > 0) {
/*  227 */       for (int i = 0; i < len; i++) {
/*  228 */         if (parts[i] != null) {
/*  229 */           sb.append('.');
/*  230 */           sb.append(parts[i]);
/*      */         } 
/*      */       } 
/*      */     }
/*  234 */     return (sb.length() > 0) ? sb.substring(1) : "";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  243 */   private static final Pattern KEY_SPLIT_PATTERN = Pattern.compile("[.]");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String[] splitKey(String key) {
/*  254 */     return splitKey(key, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String[] splitKey(String key, int limit) {
/*  275 */     if (key == null) {
/*  276 */       return null;
/*      */     }
/*  278 */     return KEY_SPLIT_PATTERN.split(key, limit);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean validateKey(String key) {
/*  302 */     if (key == null || key.length() <= 0) {
/*  303 */       return false;
/*      */     }
/*  305 */     if (key.charAt(key.length() - 1) == '.')
/*      */     {
/*  307 */       return false;
/*      */     }
/*  309 */     Pattern p = Pattern.compile("^[A-Za-z_][A-Za-z0-9_-]*");
/*  310 */     String[] keys = splitKey(key); byte b; int i; String[] arrayOfString1;
/*  311 */     for (i = (arrayOfString1 = keys).length, b = 0; b < i; ) { String k = arrayOfString1[b];
/*  312 */       if (!p.matcher(k).matches())
/*  313 */         return false; 
/*      */       b++; }
/*      */     
/*  316 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MCCalendarDate<T>> T getEndPeriod(T cd, MCReadableResource resource, String key) {
/*  353 */     return getPeriod(cd, false, resource, key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MCCalendarDate<T>> T getBeginPeriod(T cd, MCReadableResource resource, String key) {
/*  386 */     return getPeriod(cd, true, resource, key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static <T extends MCCalendarDate<T>> T getPeriod(T cd, boolean begin, MCReadableResource resource, String key) {
/*      */     MCCalendarDate mCCalendarDate;
/*  412 */     if (cd == null)
/*      */     {
/*  414 */       return null;
/*      */     }
/*      */     
/*  417 */     String[] info = splitPeriodInfo(resource, key);
/*  418 */     if (info == null)
/*      */     {
/*  420 */       return null;
/*      */     }
/*      */     
/*  423 */     int i = Integer.parseInt(info[0]) * (begin ? -1 : 1);
/*  424 */     char c = info[1].charAt(0);
/*  425 */     switch (c) {
/*      */       case 'y':
/*  427 */         mCCalendarDate = cd.addYear(i);
/*      */         break;
/*      */       case 'M':
/*  430 */         mCCalendarDate = mCCalendarDate.addMonth(i);
/*      */         break;
/*      */       case 'd':
/*  433 */         mCCalendarDate = mCCalendarDate.addDay(i);
/*      */         break;
/*      */       case 'H':
/*      */       case 'h':
/*  437 */         mCCalendarDate = mCCalendarDate.addHour(i);
/*      */         break;
/*      */       case 'm':
/*  440 */         mCCalendarDate = mCCalendarDate.addMinute(i);
/*      */         break;
/*      */       case 's':
/*  443 */         mCCalendarDate = mCCalendarDate.addSecond(i);
/*      */         break;
/*      */       case 'S':
/*  446 */         mCCalendarDate = (mCCalendarDate instanceof MCTimestamp) ? 
/*      */           
/*  448 */           (MCCalendarDate)((MCTimestamp)mCCalendarDate).addMilliSecond(i) : (
/*      */           
/*  450 */           (i > 0) ? mCCalendarDate.addSecond(1) : mCCalendarDate);
/*      */         break;
/*      */     } 
/*  453 */     return (T)mCCalendarDate;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  463 */   private static final Pattern PERIOD_INFO_PATTERN = Pattern.compile("(^[0-9]+)([yMdHmsS]$)", 32);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String VALUE_DELIMITER = ",";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String[] splitPeriodInfo(MCReadableResource resource, String key) {
/*  480 */     if (resource == null || key == null)
/*      */     {
/*  482 */       return null;
/*      */     }
/*  484 */     String period = resource.getString(key);
/*  485 */     if (period == null)
/*      */     {
/*  487 */       return null;
/*      */     }
/*      */     
/*  490 */     Matcher m = PERIOD_INFO_PATTERN.matcher(period);
/*      */     
/*  492 */     if (!m.matches() || m.groupCount() != 2)
/*      */     {
/*  494 */       throw new MCException(Core_Msg_FW_A.FCBJC0035, new Object[] { resource.getFileBase(), key, period });
/*      */     }
/*  496 */     return new String[] {
/*  497 */         m.group(1), m.group(2)
/*      */       };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final <T extends MCCalendarDate<T>> boolean passedPeriod(T cd, MCReadableResource resource, String key) {
/*  534 */     return passedPeriod(null, cd, resource, key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final <T extends MCCalendarDate<T>> boolean passedPeriod(T now, T cd, MCReadableResource resource, String key) {
/*  557 */     return passedPeriod(now, cd, MCDateFieldType.MILLISECOND, resource, key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final <T extends MCCalendarDate<T>> boolean passedDatePeriod(T cd, MCReadableResource resource, String key) {
/*  585 */     return passedDatePeriod(null, cd, resource, key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final <T extends MCCalendarDate<T>> boolean passedDatePeriod(T now, T cd, MCReadableResource resource, String key) {
/*  608 */     return passedPeriod(now, cd, MCDateFieldType.DAY, resource, key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final <T extends MCCalendarDate<T>> boolean passedPeriod(T now, T cd, MCDateFieldType field, MCReadableResource resource, String key) {
/*  643 */     if (cd == null)
/*      */     {
/*  645 */       return false;
/*      */     }
/*      */ 
/*      */     
/*  649 */     boolean type_date = true;
/*  650 */     if (cd instanceof MCDate) {
/*  651 */       type_date = true;
/*      */     }
/*  653 */     else if (cd instanceof MCTimestamp) {
/*  654 */       type_date = false;
/*      */     }
/*      */     else {
/*      */       
/*  658 */       return false;
/*      */     } 
/*      */     
/*  661 */     if (now == null)
/*      */     {
/*  663 */       now = type_date ? (T)MCDate.sysnow() : (T)MCTimestamp.sysnow();
/*      */     }
/*      */ 
/*      */     
/*  667 */     T limit = getBeginPeriod(now, resource, key);
/*      */ 
/*      */     
/*  670 */     return (limit != null) ? limit.gtLeft((MCCalendarDate)cd, field) : false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final Font createFont(String value) {
/*  701 */     if (MCStringUtil.isNull(value)) {
/*  702 */       return null;
/*      */     }
/*      */     try {
/*  705 */       String v = value;
/*  706 */       int i = v.indexOf(",");
/*  707 */       if (i > -1) {
/*  708 */         String name = v.substring(0, i);
/*  709 */         v = v.substring(i + 1);
/*  710 */         i = v.indexOf(",");
/*  711 */         if (i > -1) {
/*  712 */           int style = (
/*  713 */             (Integer)MCFactory.getFieldValue(Font.class, int.class, v.substring(0, i)))
/*  714 */             .intValue();
/*  715 */           int size = Integer.parseInt(v.substring(i + 1));
/*  716 */           return new Font(name, style, size);
/*      */         }
/*      */       
/*      */       } 
/*  720 */     } catch (MCException e) {
/*  721 */       throw new MCException(e, Core_Msg_FW_A.FCBJC0060, new Object[] { value });
/*      */     }
/*  723 */     catch (NumberFormatException e) {
/*  724 */       throw new MCException(e, Core_Msg_FW_A.FCBJC0060, new Object[] { value });
/*      */     } 
/*  726 */     throw new MCException(Core_Msg_FW_A.FCBJC0060, new Object[] { value });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final Color createColor(String value) {
/*  749 */     if (MCStringUtil.isNull(value)) {
/*  750 */       return null;
/*      */     }
/*  752 */     Integer[] rgb = new Integer[4];
/*  753 */     String[] rgbs = value.split(",");
/*  754 */     if (rgbs.length != 3 && rgbs.length != 4) {
/*  755 */       throw new MCException(Core_Msg_FW_A.FCBJC0061, new Object[] { value });
/*      */     }
/*  757 */     for (int idx = 0; idx < rgbs.length; idx++) {
/*  758 */       String p = rgbs[idx];
/*      */       try {
/*  760 */         int e = Integer.parseInt(p);
/*  761 */         if (e >= 0 && 255 >= e) {
/*  762 */           rgb[idx] = Integer.valueOf(e);
/*      */         } else {
/*      */           
/*  765 */           throw new MCException(Core_Msg_FW_A.FCBJC0061, new Object[] { value });
/*      */         }
/*      */       
/*  768 */       } catch (NumberFormatException e) {
/*  769 */         throw new MCException(e, Core_Msg_FW_A.FCBJC0061, new Object[] { value });
/*      */       } 
/*      */     } 
/*  772 */     if (rgb[3] == null) {
/*  773 */       return new Color(rgb[0].intValue(), rgb[1].intValue(), rgb[2].intValue());
/*      */     }
/*      */     
/*  776 */     return new Color(rgb[0].intValue(), rgb[1].intValue(), rgb[2].intValue(), rgb[3].intValue());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  787 */   private static final Pattern BYTE_VALUE_PATTERN = Pattern.compile(
/*  788 */       "^([0-9]+)(B|KB|MB|GB|TB)$", 34);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long getByteValue(MCReadableResource resource, String key) {
/*  810 */     if (resource == null || key == null)
/*      */     {
/*  812 */       return -1L;
/*      */     }
/*  814 */     String str = resource.getString(key);
/*  815 */     if (str == null)
/*      */     {
/*  817 */       return -1L;
/*      */     }
/*      */     
/*  820 */     Matcher m = BYTE_VALUE_PATTERN.matcher(str);
/*  821 */     if (!m.matches())
/*      */     {
/*  823 */       return -1L;
/*      */     }
/*      */     
/*  826 */     long limit = Long.parseLong(m.group(1));
/*  827 */     String unit = m.group(2);
/*  828 */     unit = unit.toUpperCase();
/*  829 */     int radix = 1024;
/*  830 */     if (unit.equals("B")) {
/*  831 */       return limit;
/*      */     }
/*  833 */     if (unit.equals("KB")) {
/*  834 */       return limit * radix;
/*      */     }
/*  836 */     if (unit.equals("MB")) {
/*  837 */       return limit * (radix * radix);
/*      */     }
/*  839 */     if (unit.equals("GB")) {
/*  840 */       return limit * (radix * radix * radix);
/*      */     }
/*  842 */     if (unit.equals("TB")) {
/*  843 */       return limit * (radix * radix * radix * radix);
/*      */     }
/*      */ 
/*      */     
/*  847 */     return -1L;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  856 */   private static final Pattern TRIM_KEY = Pattern.compile("^[\\s]*(.*)", 
/*  857 */       32);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  865 */   private static final Pattern TRIM_VALUE = Pattern.compile("^\\s*(.*[^\\s])\\s*$", 
/*  866 */       32);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final String LOCALE_SEP = "_";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String OS_LOCALE = "system";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static String trimKey(String key) {
/*  885 */     return trim(TRIM_KEY, key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static String trimValue(String value) {
/*  905 */     return trim(TRIM_VALUE, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String trim(Pattern pattern, String text) {
/*  922 */     String newtext = MCStringUtil.trim(pattern, text);
/*  923 */     return (newtext != null && newtext.length() > 0) ? newtext : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String createFileName(String base, String pj, Locale locale) {
/*  946 */     return createFileName(base, pj, locale, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String createFileName(String base, String pj, Locale locale, boolean auto) {
/*  969 */     return String.valueOf(MCFileResourceUtil.createFileName(base, pj, locale, auto)) + 
/*  970 */       fileExtension();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String fileExtension() {
/*  983 */     return MCFileResourceReader.createReader().getFileExtension();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final Locale convLocale(String ls) {
/* 1012 */     Locale l = null;
/* 1013 */     if (ls != null)
/* 1014 */     { if (ls.equals("system")) {
/* 1015 */         return Locale.getDefault();
/*      */       }
/* 1017 */       String[] lp = ls.split("_", 3);
/* 1018 */       switch (lp.length)
/*      */       { case 0:
/* 1020 */           l = Locale.getDefault();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1037 */           return l;case 1: l = new Locale(lp[0]); return l;case 2: l = new Locale(lp[0], lp[1]); return l; }  l = new Locale(lp[0], lp[1], lp[2]); } else { l = Locale.getDefault(); }  return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String convLocaleString(String cd) {
/* 1052 */     return (cd != null && cd.equals("system")) ? Locale.getDefault().toString() : cd;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String[] getProjectPath() {
/* 1069 */     return pjpath.toArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String[] getModulePath() {
/* 1082 */     return mdpath.toArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final String loadPath() {
/* 1099 */     String homedir = getDefaultHome();
/* 1100 */     StringBuilder trace = createTraceBuffer();
/* 1101 */     trace.append(pjpath.load(homedir));
/* 1102 */     trace.append(mdpath.load(homedir));
/* 1103 */     return trace.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String getDefaultHome() {
/* 1116 */     return MCSys.env.MCF_HOME();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final void loaddumpPathResource() {
/* 1128 */     loaddump(
/* 1129 */         new MCPathResource[] { pjpath, mdpath });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static abstract class ResourceLoadThread
/*      */     extends Thread
/*      */   {
/* 1144 */     protected StringBuilder trace = MCResource.createTraceBuffer();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1151 */     protected long time = -1L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1158 */     protected Locale locale = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1165 */     protected MCGroupResource resource = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1172 */     protected MCException mce = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected ResourceLoadThread(Locale locale, MCGroupResource resource) {
/* 1183 */       super("ResourceLoad-" + resource.getFileBase());
/* 1184 */       this.locale = locale;
/* 1185 */       this.resource = resource;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public abstract void load();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void run() {
/* 1198 */       long start = System.currentTimeMillis();
/*      */       try {
/* 1200 */         load();
/*      */       }
/* 1202 */       catch (MCException e) {
/* 1203 */         this.mce = e;
/*      */       }
/* 1205 */       catch (Throwable e) {
/* 1206 */         this.mce = new MCException(e);
/*      */       } 
/* 1208 */       long end = System.currentTimeMillis();
/* 1209 */       this.time = end - start;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void loadJoin() {
/*      */       try {
/* 1222 */         join();
/*      */       }
/* 1224 */       catch (InterruptedException e) {
/*      */         
/* 1226 */         throw new MCException(e, Core_Msg_FW_A.FCBJC0024, new Object[] { this.resource.getFileBase() });
/*      */       } 
/* 1228 */       if (this.mce != null) {
/* 1229 */         throw this.mce;
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String trace() {
/* 1241 */       return this.trace.toString();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public long time() {
/* 1252 */       return this.time;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MCGroupResource resource() {
/* 1263 */       return this.resource;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final String loadInit(Locale locale, MCGroupResource... resources) {
/* 1289 */     StringBuilder trace = createTraceBuffer();
/* 1290 */     if (resources != null) {
/* 1291 */       ResourceLoadThread[] threads = new ResourceLoadThread[resources.length];
/* 1292 */       int cnt = 0; byte b; int i; MCGroupResource[] arrayOfMCGroupResource;
/* 1293 */       for (i = (arrayOfMCGroupResource = resources).length, b = 0; b < i; ) { MCGroupResource resource = arrayOfMCGroupResource[b];
/* 1294 */         if (resource != null) {
/* 1295 */           threads[cnt] = new LoadInitThread(locale, resource);
/* 1296 */           threads[cnt].start();
/*      */         } else {
/*      */           
/* 1299 */           threads[cnt] = null;
/*      */         } 
/* 1301 */         cnt++; b++; }
/*      */        ResourceLoadThread[] arrayOfResourceLoadThread1;
/* 1303 */       for (i = (arrayOfResourceLoadThread1 = threads).length, b = 0; b < i; ) { ResourceLoadThread thread = arrayOfResourceLoadThread1[b];
/* 1304 */         if (thread != null) {
/* 1305 */           thread.loadJoin();
/* 1306 */           trace.append(thread.trace());
/*      */         }  b++; }
/*      */     
/*      */     } 
/* 1310 */     return trace.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class LoadInitThread
/*      */     extends ResourceLoadThread
/*      */   {
/*      */     LoadInitThread(Locale locale, MCGroupResource resource) {
/* 1329 */       super(locale, resource);
/*      */     }
/*      */ 
/*      */     
/*      */     public void load() {
/* 1334 */       this.resource.clearInitSearchedPackage();
/*      */ 
/*      */       
/* 1337 */       this.trace.append(this.resource.loadInit(MCResource.getDefaultHome(), MCResource.getProjectPath(), 
/* 1338 */             MCResource.getModulePath(), MCResource.isLocaleSupport(this.resource) ? this.locale : null));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final String loadInit(Locale locale, Class<?> cl, MCPackageResource... resources) {
/* 1366 */     String pkg = (cl != null) ? cl.getPackage().getName() : null;
/* 1367 */     return loadInit(locale, pkg, resources);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final String loadInit(Locale locale, String pkg, MCPackageResource... resources) {
/* 1394 */     return loadInit(locale, new String[] {
/* 1395 */           pkg
/* 1396 */         }, resources);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final String loadInit(Locale locale, String[] pkgs, MCPackageResource... resources) {
/* 1426 */     StringBuilder trace = createTraceBuffer();
/* 1427 */     if (resources != null) {
/* 1428 */       ResourceLoadThread[] threads = new ResourceLoadThread[resources.length];
/* 1429 */       int cnt = 0; byte b; int i; MCPackageResource[] arrayOfMCPackageResource;
/* 1430 */       for (i = (arrayOfMCPackageResource = resources).length, b = 0; b < i; ) { MCPackageResource resource = arrayOfMCPackageResource[b];
/* 1431 */         if (resource != null) {
/* 1432 */           threads[cnt] = new LoadPackageInitThread(locale, pkgs, resource);
/* 1433 */           threads[cnt].start();
/*      */         } else {
/*      */           
/* 1436 */           threads[cnt] = null;
/*      */         } 
/* 1438 */         cnt++; b++; }
/*      */        ResourceLoadThread[] arrayOfResourceLoadThread1;
/* 1440 */       for (i = (arrayOfResourceLoadThread1 = threads).length, b = 0; b < i; ) { ResourceLoadThread thread = arrayOfResourceLoadThread1[b];
/* 1441 */         if (thread != null) {
/* 1442 */           thread.loadJoin();
/* 1443 */           trace.append(thread.trace());
/*      */         }  b++; }
/*      */     
/*      */     } 
/* 1447 */     return trace.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class LoadPackageInitThread
/*      */     extends ResourceLoadThread
/*      */   {
/* 1462 */     private String[] pkgs = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     LoadPackageInitThread(Locale locale, String[] pkgs, MCPackageResource resource) {
/* 1474 */       super(locale, (MCGroupResource)resource);
/* 1475 */       this.pkgs = Arrays.<String>copyOf(pkgs, pkgs.length);
/*      */     }
/*      */ 
/*      */     
/*      */     public void load() {
/* 1480 */       MCPackageResource pkgres = (MCPackageResource)this.resource;
/* 1481 */       this.trace.append(pkgres.loadPackageInit(MCResource.getProjectPath(), 
/* 1482 */             MCResource.isLocaleSupport(pkgres) ? this.locale : null, this.pkgs));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final String loadInit(Locale locale, Class<?> cl, MCGroupResourceMap resources) {
/* 1509 */     String pkg = (cl != null) ? cl.getPackage().getName() : null;
/* 1510 */     return loadInit(locale, pkg, resources);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final String loadInit(Locale locale, String pkg, MCGroupResourceMap resources) {
/* 1536 */     return loadInit(locale, new String[] {
/* 1537 */           pkg
/* 1538 */         }, resources);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final String loadInit(Locale locale, String[] pkgs, MCGroupResourceMap resources) {
/* 1565 */     StringBuilder trace = createTraceBuffer();
/*      */     
/* 1567 */     if (resources != null) {
/* 1568 */       trace.append(resources.loadPackageInit(getProjectPath(), locale, 
/* 1569 */             pkgs));
/*      */     }
/* 1571 */     return trace.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final String loadInit(Locale locale, MCGroupResourceMap resources) {
/* 1615 */     if (resources != null) {
/* 1616 */       resources.clearInitSearchedPackage();
/*      */     }
/* 1618 */     return "";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final String loadUser(Locale locale, MCGroupResource... resources) {
/* 1639 */     StringBuilder trace = createTraceBuffer();
/* 1640 */     if (resources != null) {
/* 1641 */       byte b; int i; MCGroupResource[] arrayOfMCGroupResource; for (i = (arrayOfMCGroupResource = resources).length, b = 0; b < i; ) { MCGroupResource resource = arrayOfMCGroupResource[b];
/* 1642 */         if (resource != null)
/*      */         {
/*      */           
/* 1645 */           trace.append(resource.loadUser(getDefaultHome(), 
/* 1646 */                 isLocaleSupport(resource) ? locale : null)); } 
/*      */         b++; }
/*      */     
/*      */     } 
/* 1650 */     return trace.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final boolean isLocaleSupport(Object resource) {
/* 1720 */     return isAnnotationResource(resource, (Class)LocaleResource.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final boolean isAutoGenSupport(Object resource) {
/* 1732 */     return isAnnotationResource(resource, (Class)AutoGenResource.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final boolean isAnnotationResource(Object resource, Class<? extends Annotation> annotation) {
/* 1747 */     return (resource instanceof MCGroupResource) ? 
/* 1748 */       resource.getClass().isAnnotationPresent(annotation) : false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final String saveUser(Locale locale, MCGroupResource... resources) {
/* 1770 */     StringBuilder trace = createTraceBuffer();
/* 1771 */     if (resources != null) {
/* 1772 */       byte b; int i; MCGroupResource[] arrayOfMCGroupResource; for (i = (arrayOfMCGroupResource = resources).length, b = 0; b < i; ) { MCGroupResource resource = arrayOfMCGroupResource[b];
/* 1773 */         if (resource != null && resource.isUpdate())
/*      */         {
/*      */           
/* 1776 */           trace.append(resource.saveUser(getDefaultHome(), 
/* 1777 */                 isLocaleSupport(resource) ? locale : null)); } 
/*      */         b++; }
/*      */     
/*      */     } 
/* 1781 */     return trace.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final MCPackageResource[] getPackageResource(MCGroupResource... resources) {
/* 1796 */     List<MCPackageResource> list = new ArrayList<>();
/* 1797 */     if (resources != null) {
/* 1798 */       byte b; int i; MCGroupResource[] arrayOfMCGroupResource; for (i = (arrayOfMCGroupResource = resources).length, b = 0; b < i; ) { MCGroupResource resource = arrayOfMCGroupResource[b];
/* 1799 */         if (resource != null && resource instanceof MCPackageResource)
/* 1800 */           list.add((MCPackageResource)resource); 
/*      */         b++; }
/*      */     
/*      */     } 
/* 1804 */     return list.<MCPackageResource>toArray(new MCPackageResource[list.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static MCGroupResourceMap createGroupMap(String name) {
/* 1816 */     return new MCGroupResourceMap(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static boolean checkLoadIntegration(MCGroupResourceMap map, StringBuilder sb) {
/* 1832 */     BufferedReader br = new BufferedReader(new StringReader(sb.toString()));
/*      */     try {
/* 1834 */       String line = null;
/* 1835 */       while ((line = br.readLine()) != null && br.ready()) {
/* 1836 */         if (line.startsWith("***** ")) {
/*      */           continue;
/*      */         }
/*      */         
/* 1840 */         if (MCResourceIOBase._tracelog && 
/* 1841 */           line.startsWith("Target Resource ")) {
/*      */           continue;
/*      */         }
/*      */ 
/*      */         
/* 1846 */         return true;
/*      */       } 
/*      */       
/* 1849 */       MCLog.write(Core_Msg_FW_A.FCBJC0067, new Object[] { map.getFileBase() });
/* 1850 */       return false;
/*      */     }
/* 1852 */     catch (IOException e) {
/*      */       
/* 1854 */       throw new MCException(e, Core_Msg_FW_A.FCBJC0024, new Object[] { map.getFileBase() });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static void removeSearchedPackage(String pkg, MCPackageResource... resources) {
/*      */     byte b;
/*      */     int i;
/*      */     MCPackageResource[] arrayOfMCPackageResource;
/* 1869 */     for (i = (arrayOfMCPackageResource = resources).length, b = 0; b < i; ) { MCPackageResource resource = arrayOfMCPackageResource[b];
/* 1870 */       if (resource != null && resource instanceof MCGroupResource) {
/* 1871 */         ((MCGroupResource)resource).removeSearchedPackage(pkg);
/*      */       }
/*      */       b++; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static void removeSearchedPackage(Class<?> cl, MCPackageResource... resources) {
/* 1887 */     String pkg = (cl != null) ? cl.getPackage().getName() : null;
/* 1888 */     removeSearchedPackage(pkg, resources);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static void resetBundle(MCGroupResource... resources) {
/*      */     byte b;
/*      */     int i;
/*      */     MCGroupResource[] arrayOfMCGroupResource;
/* 1900 */     for (i = (arrayOfMCGroupResource = resources).length, b = 0; b < i; ) { MCGroupResource resource = arrayOfMCGroupResource[b];
/* 1901 */       resource.resetBundle();
/*      */       b++; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static void resetBundle(MCGroupResourceMap resources) {
/* 1914 */     resources.resetBundleMap();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final StringBuilder createTraceBuffer() {
/* 1929 */     return new StringBuilder(1024);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1937 */   public static final String LINE_SEP = MCSys.env.getVMEnv("line.separator", "\n");
/*      */ 
/*      */   
/*      */   protected static final String TRACE_USER = "User Settings";
/*      */ 
/*      */   
/*      */   protected static final String TRACE_LOCALE = "New Locale";
/*      */ 
/*      */   
/*      */   protected static final String TRACE_PACKAGE = "Package Local";
/*      */ 
/*      */   
/*      */   private static final String dllfix = "#@#";
/*      */ 
/*      */   
/*      */   protected static final <T extends MCDumpResource> void loaddump(MCDumpResource... rs) {
/* 1953 */     if (rs == null)
/*      */       return;  byte b; int i;
/*      */     MCDumpResource[] arrayOfMCDumpResource;
/* 1956 */     for (i = (arrayOfMCDumpResource = rs).length, b = 0; b < i; ) { MCDumpResource r = arrayOfMCDumpResource[b];
/* 1957 */       loaddump(r);
/*      */       b++; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void storedump(MCDumpResource rs, String... srcs) {
/* 1971 */     StringBuilder srcssb = new StringBuilder();
/* 1972 */     if (srcs != null) {
/* 1973 */       byte b; int i; String[] arrayOfString; for (i = (arrayOfString = srcs).length, b = 0; b < i; ) { String src = arrayOfString[b];
/* 1974 */         srcssb.append(src);
/* 1975 */         srcssb.append(LINE_SEP); b++; }
/*      */     
/*      */     } 
/* 1978 */     MCLog.write(Core_Msg_FW_A.FCBJC0038, new Object[] { rs.getFileBase(), srcssb.toString() });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void loaddump(MCDumpResource rs) {
/* 1990 */     StringBuilder srcssb = new StringBuilder();
/* 1991 */     String[] srcs = rs.getLoadSourceArray();
/* 1992 */     if (srcs != null) {
/* 1993 */       byte b; int i; String[] arrayOfString; for (i = (arrayOfString = srcs).length, b = 0; b < i; ) { String src = arrayOfString[b];
/* 1994 */         srcssb.append(src);
/* 1995 */         srcssb.append(LINE_SEP); b++; }
/*      */     
/*      */     } 
/* 1998 */     MCLog.write(Core_Msg_FW_A.FCBJC0016, new Object[] { rs.getFileBase(), srcssb.toString() });
/*      */ 
/*      */     
/* 2001 */     if (MCLog.isEnabled(Core_Msg_FW_A.FCBJC0030)) {
/* 2002 */       MCLog.write(Core_Msg_FW_A.FCBJC0030, new Object[] { rs.toString(true) });
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void tracelog(boolean load, String caption, String trace) {
/* 2044 */     String msgid = load ? Core_Msg_FW_A.FCBJC0039 : Core_Msg_FW_A.FCBJC0040;
/* 2045 */     MCLog.write(msgid, new Object[] { caption, trace });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void tracelogPackageCaption(boolean load, Class<?> cl, String trace) {
/* 2064 */     String pkg = (cl != null) ? cl.getPackage().getName() : "(null)";
/* 2065 */     tracelogPackageCaption(load, pkg, trace);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void tracelogPackageCaption(boolean load, String pkg, String trace) {
/* 2083 */     String caption = "Package Local - " + ((pkg != null) ? pkg : "(null)");
/* 2084 */     tracelog(load, caption, trace);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void tracelogLocaleCaption(boolean load, Locale l, String trace) {
/* 2101 */     String caption = "New Locale - " + ((l != null) ? (String)l : "(null)");
/* 2102 */     tracelog(load, caption, trace);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final void tracelogUserCaption(boolean load, String id, String trace) {
/* 2119 */     String caption = "User Settings - " + ((id != null) ? id : "(null)");
/* 2120 */     tracelog(load, caption, trace);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final <T extends MCReadableResource> T createTemp(Class<T> res, String[] pjpath, String[] mdpath, Locale locale, String... paths) {
/* 2188 */     if (res == null) {
/* 2189 */       return null;
/*      */     }
/* 2191 */     T obj = create(res);
/*      */     
/* 2193 */     String trace = obj.loadTemp(pjpath, mdpath, locale, paths);
/* 2194 */     tracelog(true, "Create Temp", trace.toString());
/* 2195 */     return obj;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final <T extends MCReadableResource> T createTemp(Class<T> res, String[] pjpath, String pkg, Locale locale, String... paths) {
/* 2234 */     if (res == null) {
/* 2235 */       return null;
/*      */     }
/* 2237 */     T obj = create(res);
/*      */     
/* 2239 */     String trace = obj.loadTemp(pjpath, pkg, locale, paths);
/* 2240 */     tracelog(true, "Create Temp - " + pkg, trace.toString());
/* 2241 */     return obj;
/*      */   }
/*      */   
/*      */   private static final <T extends MCReadableResource> T create(Class<T> res) {
/* 2245 */     if (res.isMemberClass()) {
/*      */       
/* 2247 */       Class<?> dc = res.getDeclaringClass();
/* 2248 */       Class[] types = {
/* 2249 */           dc
/*      */         };
/* 2251 */       Object[] args = {
/* 2252 */           MCFactory.create(dc, null, null)
/*      */         };
/* 2254 */       return (T)MCFactory.create(res, types, args);
/*      */     } 
/*      */     
/* 2257 */     return (T)MCFactory.create(res, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String[] createTempProjectPath(String dir) {
/* 2284 */     return createTempPath(new MCProjectPath(), dir);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String[] createTempModulePath(String dir) {
/* 2310 */     return createTempPath(new MCModulePath(), dir);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String[] createTempPath(MCPathResource path, String dir) {
/* 2336 */     path.load(dir);
/* 2337 */     return path.toArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String encrypt(String val) {
/* 2358 */     return commonCrypt(val) ? benc(val) : jenc(val);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static String decrypt(String val) {
/* 2376 */     return commonCrypt(val) ? bdec(val) : jdec(val);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean commonCrypt(String val) {
/* 2391 */     return (val != null && val.startsWith("#@#"));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2432 */   private static MCCrypt crypt = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String fix = "#$#";
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static MCCrypt getCrypt() throws Exception {
/* 2443 */     if (crypt == null) {
/* 2444 */       crypt = MCCrypt.createCrypt();
/*      */     }
/* 2446 */     return crypt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2461 */   private static int fixlen = "#$#".length();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2468 */   private static int saltlen = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2475 */   private static int keylen = fixlen * 2 + saltlen;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2482 */   private static int halfkeylen = keylen / 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String jenc(String val) {
/* 2493 */     val = (val == null) ? "" : val;
/* 2494 */     String salt = createSalt();
/* 2495 */     String key = "#$#" + salt + "#$#";
/* 2496 */     String dec = String.valueOf(val) + salt;
/* 2497 */     String enc = null;
/*      */     try {
/* 2499 */       enc = getCrypt().encrypt(key, dec);
/*      */     }
/* 2501 */     catch (Exception e) {
/*      */ 
/*      */       
/* 2504 */       throw new MCException(e, Core_Msg_FW_A.FCBDC0001, new Object[] { val });
/*      */     } 
/* 2506 */     return String.valueOf(key.substring(0, halfkeylen)) + enc + 
/* 2507 */       key.substring(key.length() - halfkeylen);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String jdec(String val) {
/* 2519 */     if (!isJavaEncVal(val)) {
/* 2520 */       return val;
/*      */     }
/*      */ 
/*      */     
/* 2524 */     int len = val.length();
/* 2525 */     String key = String.valueOf(val.substring(0, halfkeylen)) + val.substring(len - halfkeylen);
/* 2526 */     String enc = val.substring(halfkeylen, len - halfkeylen);
/* 2527 */     String dec = null;
/*      */     try {
/* 2529 */       dec = getCrypt().decrypt(key, enc);
/*      */     }
/* 2531 */     catch (Exception exception) {
/*      */ 
/*      */       
/* 2534 */       return val;
/*      */     } 
/* 2536 */     if (dec == null || dec.length() < saltlen)
/*      */     {
/* 2538 */       return val;
/*      */     }
/* 2540 */     String salt = key.substring(fixlen, fixlen + saltlen);
/* 2541 */     if (!dec.endsWith(salt))
/*      */     {
/* 2543 */       return val;
/*      */     }
/* 2545 */     dec = dec.substring(0, dec.length() - saltlen);
/* 2546 */     return (dec.length() == 0) ? null : dec;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String createSalt() {
/* 2557 */     long l = System.currentTimeMillis() % 256L;
/* 2558 */     byte b = (byte)(int)l;
/* 2559 */     return MCDataConvUtil.hexString(new byte[] {
/* 2560 */           b
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean isJavaEncVal(String val) {
/* 2577 */     if (val == null)
/*      */     {
/* 2579 */       return false;
/*      */     }
/* 2581 */     if (val.length() < keylen)
/*      */     {
/* 2583 */       return false;
/*      */     }
/* 2585 */     if (!val.startsWith("#$#") || !val.endsWith("#$#"))
/*      */     {
/* 2587 */       return false;
/*      */     }
/* 2589 */     return true;
/*      */   }
/*      */   
/*      */   private static native String benc(String paramString);
/*      */   
/*      */   private static native String bdec(String paramString);
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\ctrl\MCResource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */