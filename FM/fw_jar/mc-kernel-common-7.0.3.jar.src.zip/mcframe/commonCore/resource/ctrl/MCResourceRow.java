package mcframe.commonCore.resource.ctrl;

public interface MCResourceRow {
  String UserID();
  
  void UserID(String paramString);
  
  String Locale();
  
  void Locale(String paramString);
  
  String Name();
  
  void Name(String paramString);
  
  String Key();
  
  void Key(String paramString);
  
  String Value();
  
  void Value(String paramString);
  
  String CoCD();
  
  void CoCD(String paramString);
  
  String ExtAttr1();
  
  void ExtAttr1(String paramString);
  
  String ExtAttr2();
  
  void ExtAttr2(String paramString);
  
  String ExtAttr3();
  
  void ExtAttr3(String paramString);
  
  String PgmID();
  
  void PgmID(String paramString);
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\ctrl\MCResourceRow.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */