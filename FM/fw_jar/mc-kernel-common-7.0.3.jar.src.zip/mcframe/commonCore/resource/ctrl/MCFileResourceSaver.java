/*     */ package mcframe.commonCore.resource.ctrl;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.Locale;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.sys.MCEnv;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MCFileResourceSaver
/*     */   implements MCUserResourceSaver
/*     */ {
/*     */   private final String _rootdir;
/*     */   private final String _pkgdir;
/*     */   
/*     */   MCFileResourceSaver(String root, String pkg) {
/*  53 */     this._rootdir = root;
/*  54 */     this._pkgdir = pkg;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String saveUser(MCResourceBundle usrres, String base, Locale locale, String userid) {
/*  60 */     if (usrres == null) {
/*  61 */       return "";
/*     */     }
/*     */     
/*  64 */     MCFileResourceWriter writer = MCFileResourceWriter.createWriter();
/*     */ 
/*     */ 
/*     */     
/*  68 */     String filename = MCFileResourceUtil.createLocaleFileName(base, null);
/*  69 */     filename = writer.createFileName(filename);
/*     */ 
/*     */     
/*     */     try {
/*  73 */       String userhome = MCEnv.createUserHomePath(this._rootdir, userid);
/*  74 */       File dir = MCFileResourceUtil.getDir(true, new String[] { userhome, this._pkgdir });
/*  75 */       if (dir != null) {
/*  76 */         writeToDir(usrres, writer, dir, filename);
/*     */       } else {
/*     */         
/*  79 */         File d = (this._pkgdir != null) ? 
/*  80 */           new File(userhome, this._pkgdir) : new File(userhome);
/*  81 */         throw new MCException(Core_Msg_FW_A.FCBJC0055, new Object[] { base, d.getAbsolutePath() });
/*     */       } 
/*     */       
/*  84 */       usrres.commit((new File(dir, filename)).getAbsolutePath(), 
/*  85 */           MCResourceBundle.Source.FILEPATH);
/*  86 */     } catch (Exception ex) {
/*     */       
/*  88 */       throw new MCException(ex, Core_Msg_FW_A.FCBJC0036, new Object[] {
/*  89 */             base, writer.getTrace(base, locale) });
/*     */     } 
/*  91 */     return writer.getTrace(base, locale);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String saveUserRoot(MCResourceBundle usrres, String base, Locale locale) {
/* 114 */     if (usrres == null) {
/* 115 */       return "";
/*     */     }
/*     */     
/* 118 */     MCFileResourceWriter writer = MCFileResourceWriter.createWriter();
/*     */     
/* 120 */     String filename = MCFileResourceUtil.createLocaleFileName(base, locale);
/* 121 */     filename = writer.createFileName(filename);
/*     */     
/*     */     try {
/* 124 */       File dir = MCFileResourceUtil.getDir(true, new String[] { this._rootdir, this._pkgdir });
/* 125 */       if (dir != null) {
/* 126 */         writeToDir(usrres, writer, dir, filename);
/*     */       } else {
/*     */         
/* 129 */         File d = (this._pkgdir != null) ? 
/* 130 */           new File(this._rootdir, this._pkgdir) : new File(this._rootdir);
/* 131 */         throw new MCException(Core_Msg_FW_A.FCBJC0055, new Object[] { base, d.getAbsolutePath() });
/*     */       } 
/*     */       
/* 134 */       usrres.commit((new File(dir, filename)).getAbsolutePath(), 
/* 135 */           MCResourceBundle.Source.FILEPATH);
/* 136 */     } catch (Exception ex) {
/*     */       
/* 138 */       throw new MCException(ex, Core_Msg_FW_A.FCBJC0036, new Object[] {
/* 139 */             base, writer.getTrace(base, locale) });
/*     */     } 
/* 141 */     return writer.getTrace(base, locale);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeToDir(MCResourceBundle resource, MCFileResourceWriter writer, File dir, String filename) {
/* 160 */     writer.writeToFilePath(resource, new File(dir, filename));
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\ctrl\MCFileResourceSaver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */