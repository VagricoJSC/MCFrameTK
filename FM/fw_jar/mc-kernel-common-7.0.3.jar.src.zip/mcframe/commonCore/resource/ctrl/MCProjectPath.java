/*    */ package mcframe.commonCore.resource.ctrl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCProjectPath
/*    */   extends MCPathResource
/*    */ {
/*    */   public static final String FILE_BASE = "ProjectPath";
/*    */   static final String FW_PATH = "";
/*    */   
/*    */   MCProjectPath() {
/* 47 */     super("ProjectPath");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String load(String homedir) {
/* 55 */     String trace = super.load(homedir);
/*    */ 
/*    */     
/* 58 */     int len = this.path.length;
/* 59 */     String[] array = new String[len + 1];
/* 60 */     System.arraycopy(this.path, 0, array, 0, len);
/* 61 */     array[len] = "";
/* 62 */     this.path = array;
/*    */     
/* 64 */     return trace;
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\ctrl\MCProjectPath.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */