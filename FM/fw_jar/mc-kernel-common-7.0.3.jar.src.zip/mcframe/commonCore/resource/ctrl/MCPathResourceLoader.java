package mcframe.commonCore.resource.ctrl;

interface MCPathResourceLoader {
  String loadPath(MCResourceBundle paramMCResourceBundle, String paramString);
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\ctrl\MCPathResourceLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */