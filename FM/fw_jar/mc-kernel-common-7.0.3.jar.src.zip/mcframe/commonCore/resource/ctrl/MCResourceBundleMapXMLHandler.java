/*     */ package mcframe.commonCore.resource.ctrl;
/*     */ 
/*     */ import org.xml.sax.Attributes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MCResourceBundleMapXMLHandler
/*     */   extends MCResourceBundleXMLHandler
/*     */ {
/*     */   MCResourceBundleMap _bundleMap;
/*     */   String _pkgpath;
/*     */   
/*     */   MCResourceBundleMapXMLHandler(MCResourceBundleMap resource, MCResourceBundle.Source type, String file, MCFileResourceReader reader, String... namespace) {
/*  48 */     super(null, type, file, reader, namespace);
/*  49 */     this._bundleMap = resource;
/*     */ 
/*     */     
/*  52 */     this._pkgpath = null;
/*  53 */     if (type == MCResourceBundle.Source.CLASSPATH) {
/*  54 */       int d = file.lastIndexOf('/');
/*  55 */       this._pkgpath = (d != -1) ? file.substring(0, d) : null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startElement(String namespaceURI, String localName, String qName, Attributes attributes) {
/*  63 */     if (!isTargetNamespace(namespaceURI)) {
/*     */       return;
/*     */     }
/*     */     
/*  67 */     namespaceURI = null;
/*     */     
/*  69 */     if (this._bundle == null)
/*     */     {
/*  71 */       if (this._stack.size() == 1) {
/*     */         
/*  73 */         this._bundle = this._bundleMap.get(qName);
/*  74 */         if (this._bundle == null) {
/*     */           
/*  76 */           this._stack.add(null);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         }
/*  82 */         else if (this._pkgpath != null && this._bundle.isSearchedPackage(this._pkgpath)) {
/*     */           
/*  84 */           this._stack.add(null);
/*  85 */           this._bundle = null;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 100 */     super.startElement(namespaceURI, localName, qName, attributes);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void endElement(String namespaceURI, String localName, String qName) {
/* 106 */     if (!isTargetNamespace(namespaceURI)) {
/*     */       return;
/*     */     }
/*     */     
/* 110 */     namespaceURI = null;
/*     */     
/* 112 */     if (this._stack.size() == 1)
/*     */     {
/* 114 */       if (this._bundle != null) {
/*     */         
/* 116 */         this._bundle = null;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 128 */     super.endElement(namespaceURI, localName, qName);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\ctrl\MCResourceBundleMapXMLHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */