/*     */ package mcframe.commonCore.resource.ctrl;
/*     */ 
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Arrays;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MCINIResourceWriter
/*     */   extends MCFileResourceWriter
/*     */ {
/*     */   private static final String EXT = ".ini";
/*     */   
/*     */   public final String getFileExtension() {
/*  45 */     return ".ini";
/*     */   }
/*     */   
/*     */   final void write(OutputStream os, String cs, MCResourceBundle resource, String srcinfo) {
/*     */     Charset charset;
/*  50 */     if (os == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  55 */     if (cs == null) {
/*  56 */       cs = "UTF-8";
/*     */     }
/*     */     try {
/*  59 */       charset = Charset.forName(cs);
/*  60 */     } catch (Exception ex) {
/*     */       
/*  62 */       throw new MCException(ex, Core_Msg_FW_A.FCBJC0037, new Object[] { cs });
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  67 */     BufferedWriter bw = new BufferedWriter(
/*  68 */         new OutputStreamWriter(os, charset));
/*     */ 
/*     */     
/*     */     try {
/*  72 */       if (resource != null) {
/*     */         
/*  74 */         String[] keys = null;
/*  75 */         synchronized (resource) {
/*  76 */           keys = resource.keySet().<String>toArray(new String[resource.size()]);
/*     */         } 
/*  78 */         Arrays.sort((Object[])keys); try {
/*     */           byte b; int i; String[] arrayOfString;
/*  80 */           for (i = (arrayOfString = keys).length, b = 0; b < i; ) { String key = arrayOfString[b];
/*     */             
/*  82 */             bw.write(key);
/*  83 */             bw.write(61);
/*     */             
/*  85 */             MCResourceItem ri = resource.get(key);
/*  86 */             String val = ri.getValue();
/*  87 */             if (val != null) {
/*  88 */               bw.write(val);
/*     */             }
/*     */             
/*  91 */             bw.newLine(); b++; }
/*     */         
/*  93 */         } catch (IOException iOException) {
/*     */           
/*  95 */           throw new MCException(Core_Msg_FW_A.FCBJC0054, new Object[] { srcinfo });
/*     */         } 
/*     */       } 
/*     */     } finally {
/*     */       
/*     */       try {
/* 101 */         bw.close();
/* 102 */       } catch (IOException iOException) {}
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\ctrl\MCINIResourceWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */