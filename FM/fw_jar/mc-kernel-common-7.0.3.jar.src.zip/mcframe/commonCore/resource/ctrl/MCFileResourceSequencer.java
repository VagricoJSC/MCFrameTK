/*     */ package mcframe.commonCore.resource.ctrl;
/*     */ 
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MCFileResourceSequencer
/*     */ {
/*     */   private final String[] _pjpath;
/*     */   private final boolean _baselocale;
/*     */   
/*     */   MCFileResourceSequencer(String... pjs) {
/*  49 */     this(false, true, pjs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCFileResourceSequencer(boolean auto, String... pjs) {
/*  69 */     this(auto, true, pjs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCFileResourceSequencer(boolean auto, boolean baselocale, String... pjs) {
/*  89 */     (new String[1])[0] = ""; pjs = (pjs != null && pjs.length > 0) ? pjs : new String[1];
/*  90 */     int len = pjs.length;
/*     */     
/*  92 */     if (!auto) {
/*     */       
/*  94 */       this._pjpath = new String[len];
/*  95 */       System.arraycopy(pjs, 0, this._pjpath, 0, len);
/*     */     }
/*     */     else {
/*     */       
/*  99 */       len *= 2;
/* 100 */       String[] pjs_a = new String[len];
/* 101 */       StringBuilder sb = new StringBuilder();
/* 102 */       int pos = 0; byte b; int i; String[] arrayOfString1;
/* 103 */       for (i = (arrayOfString1 = pjs).length, b = 0; b < i; ) { String pj = arrayOfString1[b];
/* 104 */         pjs_a[pos++] = pj;
/* 105 */         if (pj.length() > 0) {
/* 106 */           sb.setLength(0);
/* 107 */           sb.append(pj);
/* 108 */           sb.append("_A");
/* 109 */           pjs_a[pos++] = sb.toString();
/*     */         }  b++; }
/*     */       
/* 112 */       if (pos < len) {
/* 113 */         this._pjpath = new String[pos];
/* 114 */         System.arraycopy(pjs_a, 0, this._pjpath, 0, pos);
/*     */       } else {
/*     */         
/* 117 */         this._pjpath = pjs_a;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 122 */     this._baselocale = baselocale;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] getLocalePath(Locale locale) {
/* 155 */     if (locale == null)
/*     */     {
/* 157 */       return new String[] { "" };
/*     */     }
/*     */     
/* 160 */     String l = locale.getLanguage();
/* 161 */     String c = locale.getCountry();
/* 162 */     String v = locale.getVariant();
/* 163 */     int llen = (l.length() != 0) ? 1 : 0;
/* 164 */     int clen = (c.length() != 0) ? 1 : 0;
/* 165 */     int vlen = (v.length() != 0) ? 1 : 0;
/* 166 */     if (llen + clen == 0)
/*     */     {
/* 168 */       return new String[] { "" };
/*     */     }
/*     */ 
/*     */     
/* 172 */     int loclen = llen + clen + vlen + (this._baselocale ? 1 : 0);
/* 173 */     String[] locpath = new String[loclen];
/* 174 */     if (this._baselocale) {
/* 175 */       locpath[--loclen] = "";
/*     */     }
/*     */     
/* 178 */     StringBuilder sb = new StringBuilder("_");
/* 179 */     sb.append(l);
/* 180 */     if (llen != 0) {
/* 181 */       locpath[--loclen] = sb.toString();
/*     */     }
/*     */     
/* 184 */     sb.append("_");
/* 185 */     sb.append(c);
/* 186 */     if (clen != 0) {
/* 187 */       locpath[--loclen] = sb.toString();
/*     */     }
/*     */     
/* 190 */     if (vlen != 0) {
/*     */       
/* 192 */       sb.append("_");
/* 193 */       sb.append(v);
/* 194 */       locpath[--loclen] = sb.toString();
/*     */     } 
/* 196 */     return locpath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean conatainsBase() {
/* 209 */     return this._baselocale;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String[] initSequence(MCFileResourceReader reader, String base, Locale locale) {
/* 230 */     if (base == null) {
/* 231 */       return new String[0];
/*     */     }
/*     */     
/* 234 */     String[] locpath = getLocalePath(locale);
/* 235 */     int loclen = locpath.length;
/* 236 */     int pjlen = this._pjpath.length;
/* 237 */     String[] seq = new String[loclen * pjlen];
/*     */ 
/*     */     
/* 240 */     for (int cnt = 0, l = 0; l < loclen; l++) {
/* 241 */       for (int p = 0; p < pjlen; p++, cnt++) {
/* 242 */         String namePj = MCFileResourceUtil.createProjectFileName(
/* 243 */             base, this._pjpath[p]);
/* 244 */         seq[cnt] = reader.createFileName(String.valueOf(namePj) + locpath[l]);
/*     */       } 
/*     */     } 
/*     */     
/* 248 */     return seq;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String[] userSequence(MCFileResourceReader reader, String base, Locale locale) {
/* 270 */     if (base == null) {
/* 271 */       return new String[0];
/*     */     }
/*     */     
/* 274 */     if (locale != null) {
/* 275 */       base = MCFileResourceUtil.createLocaleFileName(base, locale);
/*     */     }
/* 277 */     base = reader.createFileName(base);
/* 278 */     return new String[] { base };
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\ctrl\MCFileResourceSequencer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */