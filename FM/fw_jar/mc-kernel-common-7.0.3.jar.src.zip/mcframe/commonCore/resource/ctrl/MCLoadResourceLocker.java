/*    */ package mcframe.commonCore.resource.ctrl;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MCLoadResourceLocker
/*    */ {
/* 31 */   private static final Map<String, Object> _pkgMap = new HashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static Object getPackageLocker(String pkg) {
/* 47 */     synchronized (_pkgMap) {
/* 48 */       Object p = _pkgMap.get(pkg);
/* 49 */       if (p == null) {
/* 50 */         p = new Object();
/* 51 */         _pkgMap.put(pkg, p);
/*    */       } 
/* 53 */       return p;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static void removePackageLocker(String pkg) {
/* 73 */     synchronized (_pkgMap) {
/* 74 */       _pkgMap.remove(pkg);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\ctrl\MCLoadResourceLocker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */