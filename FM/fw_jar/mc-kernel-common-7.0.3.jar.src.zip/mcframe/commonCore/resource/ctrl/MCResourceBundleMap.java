/*     */ package mcframe.commonCore.resource.ctrl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCResourceBundleMap
/*     */   implements MCReadableResourceBundle
/*     */ {
/*  34 */   private final Map<String, MCResourceBundle> _resmap = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  45 */   private final List<String> _srclist = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSearchedPackage(String pkg) {
/*  62 */     Iterator<MCResourceBundle> ite = this._resmap.values().iterator();
/*  63 */     while (ite.hasNext()) {
/*  64 */       if (!((MCResourceBundle)ite.next()).isSearchedPackage(pkg)) {
/*  65 */         return false;
/*     */       }
/*     */     } 
/*  68 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addSearchedPackage(String pkg) {
/*  75 */     Iterator<MCResourceBundle> ite = this._resmap.values().iterator();
/*  76 */     while (ite.hasNext()) {
/*  77 */       ((MCResourceBundle)ite.next()).addSearchedPackage(pkg);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void addSource(String srcpath, MCResourceBundle.Source srctype) {
/*  83 */     this._srclist.add(srcpath);
/*  84 */     for (MCResourceBundle bundle : this._resmap.values()) {
/*  85 */       bundle.addSource(srcpath, srctype);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultHandler createXMLHandler(MCResourceBundle.Source type, String file, MCFileResourceReader reader, String... namespace) {
/*  93 */     return new MCResourceBundleMapXMLHandler(
/*  94 */         this, type, file, reader, namespace);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCINIHandler createINIHandler(MCResourceBundle.Source type, String file, MCFileResourceReader reader) {
/* 101 */     return new MCResourceBundleMapINIHandler(this, type, file, reader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void clearSearchedPackage() {
/* 116 */     Iterator<MCResourceBundle> ite = this._resmap.values().iterator();
/* 117 */     while (ite.hasNext()) {
/* 118 */       ((MCResourceBundle)ite.next()).clearSearchedPackage();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void clear() {
/* 131 */     for (MCResourceBundle bundle : this._resmap.values()) {
/* 132 */       bundle.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void put(String key, MCResourceBundle res) {
/* 147 */     this._resmap.put(key, res);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCResourceBundle get(String key) {
/* 159 */     return this._resmap.get(key);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\ctrl\MCResourceBundleMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */