/*     */ package mcframe.commonCore.resource.ctrl;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import mcframe.commonCore.resource.MCConst;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCCustomResource
/*     */   extends MCGeneralWritableResource
/*     */ {
/*     */   private static final String TRACE_CUSTOM = "Custom Resource";
/*  48 */   private String _caption = "Custom Resource";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCCustomResource(String filebase) {
/*  63 */     super(MCGroupResource.Type.CONFIG, filebase);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCCustomResource(MCGroupResource.Type type, String filebase) {
/*  78 */     super(type, filebase);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCFileResourceSearcher createSearcher(String root, String pkg, String... modpath) {
/*  94 */     return new MCFileResourceSearcher(root, pkg, modpath)
/*     */       {
/*     */         protected boolean isReadInitFromDir() {
/*  97 */           return true;
/*     */         }
/*     */         
/*     */         protected boolean isReadInitFromPackage() {
/* 101 */           return true;
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String loadInit(String root, String pkg, Locale locale) {
/* 131 */     String[] pjpath = MCResource.getProjectPath();
/* 132 */     MCFileResourceLoader loader = new MCFileResourceLoader(
/*     */         
/* 134 */         new MCFileResourceSequencer(false, pjpath), 
/* 135 */         createSearcher(root, pkg, MCResource.getModulePath()), 
/* 136 */         false);
/*     */     
/* 138 */     MCResourceBundle init = getInitBundle();
/* 139 */     init.clear();
/* 140 */     String trace = loader.loadInit(init, getFileBase(), locale);
/* 141 */     traceLog(true, trace);
/* 142 */     return trace;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String loadUser(String path, String pj, Locale locale) {
/* 169 */     if (path == null) {
/* 170 */       path = ".";
/*     */     }
/* 172 */     String filename = MCFileResourceUtil.createProjectFileName(
/* 173 */         getFileBase(), pj);
/* 174 */     MCFileResourceLoader loader = 
/*     */       
/* 176 */       new MCFileResourceLoader(
/* 177 */         new MCFileResourceSequencer(new String[0]), 
/*     */ 
/*     */ 
/*     */         
/* 181 */         createSearcher(path, (String)null, new String[] { null
/* 182 */           }), false);
/*     */     
/* 184 */     MCResourceBundle user = getUserBundle();
/* 185 */     user.clear();
/*     */     
/* 187 */     String trace = loader.loadInitPath(user, filename, locale, new String[] { path });
/* 188 */     traceLog(true, trace);
/* 189 */     return trace;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String loadResource(MCResourceBundle resource, String path, Locale locale) {
/* 209 */     if (resource == null) {
/* 210 */       return null;
/*     */     }
/*     */     
/* 213 */     if (path == null) {
/* 214 */       path = ".";
/*     */     }
/*     */     
/* 217 */     MCFileResourceLoader l = new MCFileResourceLoader(
/* 218 */         new MCFileResourceSequencer(new String[0]), 
/*     */ 
/*     */ 
/*     */         
/* 222 */         createSearcher(path, (String)null, new String[] { null
/* 223 */           }), false);
/*     */ 
/*     */     
/* 226 */     resource.clear();
/*     */     
/* 228 */     String n = MCFileResourceUtil.createProjectFileName(
/* 229 */         getFileBase(), null);
/*     */     
/* 231 */     String trace = l.loadInitPath(resource, n, locale, new String[] { path });
/* 232 */     traceLog(true, trace);
/* 233 */     return trace;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String saveUser(String path, String pj, Locale locale) {
/* 264 */     MCFileResourceSaver saver = new MCFileResourceSaver(path, null);
/* 265 */     String filename = MCFileResourceUtil.createProjectFileName(
/* 266 */         getFileBase(), pj);
/* 267 */     String trace = saver.saveUserRoot(getUserBundle(), filename, locale);
/* 268 */     traceLog(false, trace);
/* 269 */     return trace;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String saveResource(MCResourceBundle resource, String path, Locale locale) {
/* 287 */     MCFileResourceSaver s = new MCFileResourceSaver(path, null);
/* 288 */     String n = MCFileResourceUtil.createProjectFileName(getFileBase(), null);
/* 289 */     String trace = s.saveUserRoot(resource, n, locale);
/* 290 */     traceLog(false, trace);
/* 291 */     return trace;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String loadInitBundle(String root, String pkg, Locale locale) {
/* 319 */     String[] pjpath = MCResource.getProjectPath();
/* 320 */     MCFileResourceLoader loader = new MCFileResourceLoader(
/*     */         
/* 322 */         new MCFileResourceSequencer(false, pjpath), 
/* 323 */         createSearcher(root, pkg, MCResource.getModulePath()), 
/* 324 */         false);
/*     */ 
/*     */     
/* 327 */     MCGroupResourceMap map = new MCGroupResourceMap(
/* 328 */         MCConst.getBundleFileBase());
/* 329 */     map.put(getFileBase(), this);
/* 330 */     MCResourceBundleMap initmap = map.getInitBundleMap();
/* 331 */     initmap.clear();
/* 332 */     String trace = loader.loadInit(initmap, map.getFileBase(), locale);
/* 333 */     traceLog(true, trace);
/* 334 */     return trace;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String loadUserBundle(String path, String pj, Locale locale) {
/* 360 */     if (path == null) {
/* 361 */       path = ".";
/*     */     }
/* 363 */     MCFileResourceLoader loader = 
/* 364 */       new MCFileResourceLoader(
/* 365 */         new MCFileResourceSequencer(new String[0]), 
/*     */ 
/*     */ 
/*     */         
/* 369 */         createSearcher(path, (String)null, new String[] { null
/* 370 */           }), false);
/*     */ 
/*     */     
/* 373 */     MCGroupResourceMap map = new MCGroupResourceMap(
/* 374 */         MCConst.getBundleFileBase());
/* 375 */     map.put(getFileBase(), this);
/* 376 */     MCResourceBundleMap usermap = map.getUserBundleMap();
/* 377 */     usermap.clear();
/* 378 */     String filename = MCFileResourceUtil.createProjectFileName(
/* 379 */         map.getFileBase(), pj);
/* 380 */     String trace = loader.loadInitPath(usermap, filename, locale, new String[] { path });
/* 381 */     traceLog(true, trace);
/* 382 */     return trace;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTraceLogCaption(String caption) {
/* 395 */     this._caption = (caption != null) ? caption : "Custom Resource";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void traceLog(boolean load, String trace) {
/* 411 */     MCResource.tracelog(load, this._caption, trace);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\ctrl\MCCustomResource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */