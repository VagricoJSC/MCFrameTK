package mcframe.commonCore.resource.ctrl;

import java.util.Locale;

public interface MCInitResourceLoader {
  String loadInit(MCReadableResourceBundle paramMCReadableResourceBundle, String paramString, Locale paramLocale);
  
  String loadInitPackage(MCReadableResourceBundle paramMCReadableResourceBundle, String paramString, Locale paramLocale, String... paramVarArgs);
  
  String loadInitPath(MCReadableResourceBundle paramMCReadableResourceBundle, String paramString, Locale paramLocale, String... paramVarArgs);
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\ctrl\MCInitResourceLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */