/*    */ package mcframe.commonCore.resource.ctrl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCModulePath
/*    */   extends MCPathResource
/*    */ {
/*    */   public static final String FILE_BASE = "ModulePath";
/*    */   
/*    */   MCModulePath() {
/* 33 */     super("ModulePath");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String load(String homedir) {
/* 41 */     return super.load(homedir);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\ctrl\MCModulePath.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */