/*     */ package mcframe.commonCore.resource.ctrl;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import javax.xml.parsers.FactoryConfigurationError;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.parsers.SAXParser;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MCXMLResourceReader
/*     */   extends MCFileResourceReader
/*     */ {
/*     */   private static final String EXT = ".xml";
/*     */   private static final String NAMESPACE_NONE = "";
/*     */   private final String[] _namespace;
/*     */   
/*     */   MCXMLResourceReader() {
/*  64 */     this(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCXMLResourceReader(String... namespace) {
/*  77 */     (new String[1])[0] = ""; this._namespace = (namespace != null) ? namespace : new String[1];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getFileExtension() {
/*  83 */     return ".xml";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean read(MCReadableResourceBundle resource, InputStream is, MCResourceBundle.Source type, String file) {
/*  90 */     if (resource == null || is == null) {
/*  91 */       return false;
/*     */     }
/*     */ 
/*     */     
/*  95 */     DefaultHandler handler = resource.createXMLHandler(
/*  96 */         type, file, this, this._namespace);
/*     */     
/*  98 */     SAXParser sax = getSAXParser();
/*     */     try {
/* 100 */       sax.parse(is, handler);
/*     */     }
/* 102 */     catch (IOException ex) {
/*     */ 
/*     */       
/* 105 */       String srcinfo = MCResourceBundle.getSourceString(file, type);
/* 106 */       throw new MCException(ex, Core_Msg_FW_A.FCBJC0018, new Object[] { srcinfo });
/*     */     }
/* 108 */     catch (SAXException ex) {
/*     */ 
/*     */       
/* 111 */       String srcinfo = MCResourceBundle.getSourceString(file, type);
/* 112 */       throw new MCException(ex, Core_Msg_FW_A.FCBJC0019, new Object[] { srcinfo });
/*     */     } 
/* 114 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final SAXParser getSAXParser() {
/* 127 */     SAXParser sax = null;
/* 128 */     SAXParserFactory spf = getSAXParserFactory();
/*     */     try {
/* 130 */       spf.setValidating(false);
/* 131 */       spf.setNamespaceAware(true);
/* 132 */       sax = spf.newSAXParser();
/*     */     }
/* 134 */     catch (ParserConfigurationException ex) {
/*     */ 
/*     */       
/* 137 */       throw new MCException(ex, Core_Msg_FW_A.FCBJC0017, new Object[0]);
/*     */     }
/* 139 */     catch (SAXException ex) {
/*     */ 
/*     */       
/* 142 */       throw new MCException(ex, Core_Msg_FW_A.FCBJC0017, new Object[0]);
/*     */     } 
/* 144 */     return sax;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 154 */   private static SAXParserFactory _spf = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final SAXParserFactory getSAXParserFactory() {
/*     */     try {
/* 166 */       if (_spf == null) {
/* 167 */         _spf = SAXParserFactory.newInstance();
/* 168 */         _spf.setValidating(false);
/* 169 */         _spf.setNamespaceAware(false);
/*     */       }
/*     */     
/* 172 */     } catch (FactoryConfigurationError ex) {
/*     */ 
/*     */       
/* 175 */       throw new MCException(ex, Core_Msg_FW_A.FCBJC0017, new Object[0]);
/*     */     } 
/* 177 */     return _spf;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\ctrl\MCXMLResourceReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */