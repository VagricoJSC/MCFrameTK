package mcframe.commonCore.resource.ctrl;

import org.xml.sax.helpers.DefaultHandler;

interface MCReadableResourceBundle {
  boolean isSearchedPackage(String paramString);
  
  void addSearchedPackage(String paramString);
  
  void addSource(String paramString, MCResourceBundle.Source paramSource);
  
  DefaultHandler createXMLHandler(MCResourceBundle.Source paramSource, String paramString, MCFileResourceReader paramMCFileResourceReader, String... paramVarArgs);
  
  MCINIHandler createINIHandler(MCResourceBundle.Source paramSource, String paramString, MCFileResourceReader paramMCFileResourceReader);
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\ctrl\MCReadableResourceBundle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */