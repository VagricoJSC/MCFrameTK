/*     */ package mcframe.commonCore.resource.ctrl;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.StringReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.resource.MCDumpResource;
/*     */ import mcframe.commonCore.sys.MCSys;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class MCPathResource
/*     */   implements MCDumpResource
/*     */ {
/*     */   private static final String WORK = "work";
/*     */   private static final String ENTRY = "entry";
/*     */   private static final String DEFAULT = "default";
/*     */   private static final String COMMENT = "#";
/*     */   private final String _base;
/*  73 */   private String _src = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   protected String[] path = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCPathResource(String base) {
/*  91 */     this._base = base;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String load(String homedir) {
/* 116 */     this._src = null;
/* 117 */     this.path = null;
/* 118 */     if (homedir == null)
/*     */     {
/* 120 */       homedir = MCSys.env.MCF_HOME();
/*     */     }
/*     */     
/* 123 */     MCFileResourceLoader loader = new MCFileResourceLoader(
/* 124 */         new MCFileResourceSequencer(new String[0]), 
/* 125 */         homedir, 
/* 126 */         "conf", 
/* 127 */         false, new String[0]);
/*     */     
/* 129 */     MCResourceBundle bundle = new MCResourceBundle();
/*     */     
/* 131 */     String trace = load(loader, bundle);
/* 132 */     if (bundle.pathSize() <= 0)
/*     */     {
/*     */       
/* 135 */       throw new MCException(Core_Msg_FW_A.FCBJC0022, new Object[] { trace });
/*     */     }
/*     */ 
/*     */     
/* 139 */     this._src = bundle.getPathArray()[0];
/*     */ 
/*     */     
/* 142 */     List<String> list = new ArrayList<>();
/* 143 */     String[] tag = { "work", "entry", "default" };
/* 144 */     for (int i = 0; i < tag.length; i++) {
/* 145 */       MCResourceItem item = bundle.get(tag[i]);
/* 146 */       analyzePath(item, list);
/*     */     } 
/* 148 */     this.path = list.<String>toArray(new String[list.size()]);
/*     */     
/* 150 */     return trace;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String load(MCFileResourceLoader loader, MCResourceBundle bundle) {
/* 163 */     long s = System.currentTimeMillis();
/* 164 */     String trace = loader.loadPath(bundle, this._base);
/* 165 */     long e = System.currentTimeMillis();
/* 166 */     long t = e - s;
/* 167 */     return String.valueOf(trace) + "(load total : " + t + ")\n";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void analyzePath(MCResourceItem item, List<String> list) {
/* 181 */     if (item == null || list == null) {
/*     */       return;
/*     */     }
/*     */     
/* 185 */     String path = item.getValue();
/* 186 */     if (path != MCResourceItem.BLANK_VALUE) {
/* 187 */       BufferedReader br = new BufferedReader(new StringReader(path));
/*     */       while (true) {
/*     */         try {
/* 190 */           String line = br.readLine();
/* 191 */           if (line == null) {
/*     */             break;
/*     */           }
/* 194 */           String pathitem = MCStringUtil.trim(line);
/* 195 */           if (pathitem.length() > 0 && 
/* 196 */             !pathitem.startsWith("#")) {
/* 197 */             list.add(pathitem);
/*     */           }
/* 199 */         } catch (IOException iOException) {}
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getLoadSourceArray() {
/* 209 */     return new String[] { this._src };
/*     */   }
/*     */ 
/*     */   
/*     */   public String getFileBase() {
/* 214 */     return this._base;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString(boolean source) {
/* 219 */     return toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 224 */     StringBuilder sb = new StringBuilder();
/* 225 */     String[] pstrs = toArray();
/* 226 */     if (pstrs != null) {
/* 227 */       sb.append(getFileBase());
/* 228 */       sb.append(MCResource.LINE_SEP); byte b; int i; String[] arrayOfString;
/* 229 */       for (i = (arrayOfString = pstrs).length, b = 0; b < i; ) { String pstr = arrayOfString[b];
/* 230 */         sb.append(pstr);
/* 231 */         sb.append(MCResource.LINE_SEP); b++; }
/*     */     
/*     */     } 
/* 234 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] toArray() {
/* 245 */     if (this.path == null) {
/* 246 */       return null;
/*     */     }
/* 248 */     String[] array = new String[this.path.length];
/* 249 */     System.arraycopy(this.path, 0, array, 0, this.path.length);
/* 250 */     return array;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\ctrl\MCPathResource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */