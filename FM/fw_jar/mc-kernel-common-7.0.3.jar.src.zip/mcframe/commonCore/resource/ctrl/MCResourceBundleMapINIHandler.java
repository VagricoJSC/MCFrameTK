/*    */ package mcframe.commonCore.resource.ctrl;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MCResourceBundleMapINIHandler
/*    */   extends MCResourceBundleINIHandler
/*    */ {
/*    */   MCResourceBundleMap _bundlemap;
/*    */   
/*    */   MCResourceBundleMapINIHandler(MCResourceBundleMap bundle, MCResourceBundle.Source type, String file, MCFileResourceReader reader) {
/* 35 */     super(null, type, file, reader);
/* 36 */     this._bundlemap = bundle;
/*    */   }
/*    */ 
/*    */   
/*    */   public void section(String section) {
/* 41 */     this._bundle = this._bundlemap.get(section);
/* 42 */     this._section = section;
/*    */   }
/*    */ 
/*    */   
/*    */   public void entry(String key, String value) {
/* 47 */     if (this._bundle == null) {
/*    */       return;
/*    */     }
/*    */     
/* 51 */     super.entry(key, value);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\ctrl\MCResourceBundleMapINIHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */