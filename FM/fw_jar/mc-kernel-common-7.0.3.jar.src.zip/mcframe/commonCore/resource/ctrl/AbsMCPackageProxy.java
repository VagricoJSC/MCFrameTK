/*    */ package mcframe.commonCore.resource.ctrl;
/*    */ 
/*    */ public abstract class AbsMCPackageProxy
/*    */ {
/*    */   protected MCResourceBundle getUserBundle(MCGroupResource resource) {
/*  6 */     return resource.getUserBundle();
/*    */   }
/*    */   
/*    */   protected MCResourceBundle getExtBundle(MCGroupResource resource) {
/* 10 */     return resource.getExtBundle();
/*    */   }
/*    */   
/*    */   protected MCResourceBundle getSysBundle(MCGroupResource resource) {
/* 14 */     return resource.getSysBundle();
/*    */   }
/*    */   
/*    */   protected MCResourceBundle getBarcodeBundle(MCGroupResource resource) {
/* 18 */     return resource.getBarcodeBundle();
/*    */   }
/*    */ 
/*    */   
/*    */   protected MCResourceBundle getBundle(MCGroupResource resource, MCResourceLayerType type) {
/* 23 */     return resource.getBundle(type);
/*    */   }
/*    */   
/*    */   protected void clear(MCResourceBundle resource) {
/* 27 */     resource.clear();
/*    */   }
/*    */   
/*    */   protected void clear(MCResourceBundle resource, String pgmid) {
/* 31 */     resource.clear(pgmid);
/*    */   }
/*    */   
/*    */   protected void addSearchedProgram(MCResourceBundle resource, String pgmid) {
/* 35 */     resource.addSearchedProgram(pgmid);
/*    */   }
/*    */   
/*    */   protected void removeSearchedProgram(MCResourceBundle resource, String pgmid) {
/* 39 */     resource.removeSearchedProgram(pgmid);
/*    */   }
/*    */   
/*    */   protected void clearSearchedProgram(MCResourceBundle resource) {
/* 43 */     resource.clearSearchedProgram();
/*    */   }
/*    */   
/*    */   protected MCResourceBundle create() {
/* 47 */     return new MCResourceBundle();
/*    */   }
/*    */   
/*    */   protected boolean isLocaleSupport(MCGroupResource resource) {
/* 51 */     return MCResource.isLocaleSupport(resource);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\ctrl\AbsMCPackageProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */