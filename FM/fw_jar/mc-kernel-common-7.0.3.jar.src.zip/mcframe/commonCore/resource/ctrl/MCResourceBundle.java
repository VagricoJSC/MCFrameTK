/*     */ package mcframe.commonCore.resource.ctrl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.resource.MCConst;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MCResourceBundle
/*     */   implements MCReadableResourceBundle
/*     */ {
/*     */   public enum Source
/*     */   {
/*  33 */     JARFILE
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       String getSourceHeader()
/*     */       {
/*  42 */         return "<jarfile>";
/*     */       }
/*     */     },
/*  45 */     FILEPATH
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       String getSourceHeader()
/*     */       {
/*  53 */         return "<filesystem>";
/*     */       }
/*     */     },
/*  56 */     CLASSPATH
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       String getSourceHeader()
/*     */       {
/*  64 */         return "<classpath>";
/*     */       }
/*     */     },
/*  67 */     CLASSFILE
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       String getSourceHeader()
/*     */       {
/*  77 */         return "<classfile>";
/*     */       }
/*     */     },
/*  80 */     DATABASE
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       String getSourceHeader()
/*     */       {
/*  88 */         return "<database>";
/*     */       }
/*     */     },
/*  91 */     VMENV
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       String getSourceHeader()
/*     */       {
/*  99 */         return "<javavm parameter>";
/*     */       }
/*     */     },
/* 102 */     OSENV
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       String getSourceHeader()
/*     */       {
/* 110 */         return "<os environment>";
/*     */       }
/*     */     },
/* 113 */     NONE
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       String getSourceHeader()
/*     */       {
/* 121 */         return "<none>";
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     abstract String getSourceHeader();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class SrcEntry
/*     */   {
/*     */     final String path;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private SrcEntry(String path, MCResourceBundle.Source type) {
/* 159 */       this.path = path;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String getSourceString(String srcpath, Source srctype) {
/* 173 */     srctype = (srctype != null) ? srctype : Source.NONE;
/* 174 */     srcpath = (srcpath != null) ? srcpath : "";
/* 175 */     return String.valueOf(srctype.getSourceHeader()) + " " + srcpath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 183 */   private final Map<String, MCResourceItem> _itemmap = new LinkedHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 192 */   private final List<SrcEntry> _srclist = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 199 */   private final Set<String> _pkgset = new LinkedHashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 207 */   private final Set<String> _pgmset = new LinkedHashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 214 */   private String[] _h_key = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 221 */   private MCResourceItem[] _h_val = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 228 */   private MCRow.Status[] _h_act = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 235 */   private int _h_len = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 242 */   private int _update = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void clear() {
/* 262 */     synchronized (this) {
/* 263 */       for (int i = 0; i < this._h_len; i++) {
/* 264 */         this._h_key[i] = null;
/* 265 */         this._h_val[i] = null;
/* 266 */         this._h_act[i] = null;
/*     */       } 
/* 268 */       this._itemmap.clear();
/* 269 */       this._srclist.clear();
/* 270 */       this._update = 0;
/*     */       
/* 272 */       clearSearchedProgram();
/*     */     } 
/*     */   }
/*     */   
/*     */   void clear(String pgmid) {
/* 277 */     synchronized (this) {
/*     */       
/* 279 */       List<String> kl = new ArrayList<>();
/* 280 */       List<MCResourceItem> vl = new ArrayList<>();
/* 281 */       List<MCRow.Status> sl = new ArrayList<>();
/*     */       int i;
/* 283 */       for (i = 0; i < this._h_len; i++) {
/* 284 */         String k = this._h_key[i];
/* 285 */         if (k == null) {
/*     */           continue;
/*     */         }
/*     */         
/* 289 */         if (k.startsWith("_0_SCR_")) {
/* 290 */           String[] ka = MCConst.splitKey(k);
/* 291 */           if (ka.length >= 3 && pgmid.equals(MCConst.createKey(new String[] { ka[1], ka[2] }))) {
/*     */             continue;
/*     */           }
/*     */         } 
/*     */         
/* 296 */         kl.add(k);
/* 297 */         vl.add(this._h_val[i]);
/* 298 */         sl.add(this._h_act[i]);
/*     */         continue;
/*     */       } 
/* 301 */       for (i = 0; i < this._h_len; i++) {
/* 302 */         this._h_key[i] = null;
/* 303 */         this._h_val[i] = null;
/* 304 */         this._h_act[i] = null;
/*     */       } 
/* 306 */       this._update = 0;
/*     */       
/* 308 */       for (i = 0; i < kl.size(); i++) {
/* 309 */         history(kl.get(i), vl.get(i), sl.get(i));
/*     */       }
/*     */ 
/*     */       
/* 313 */       List<String> dl = new ArrayList<>();
/* 314 */       for (String k : this._itemmap.keySet()) {
/* 315 */         if (k.startsWith("_0_SCR_")) {
/* 316 */           String[] ka = MCConst.splitKey(k);
/* 317 */           if (ka.length >= 3 && pgmid.equals(MCConst.createKey(new String[] { ka[1], ka[2] }))) {
/* 318 */             dl.add(k);
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/* 323 */       for (String k : dl) {
/* 324 */         this._itemmap.remove(k);
/*     */       }
/*     */       
/* 327 */       removeSearchedProgram(pgmid);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void copy(MCResourceBundle from) {
/* 342 */     synchronized (this) {
/* 343 */       for (int i = 0; i < from._h_len; i++) {
/* 344 */         this._h_key[i] = from._h_key[i];
/* 345 */         this._h_val[i] = from._h_val[i];
/* 346 */         this._h_act[i] = from._h_act[i];
/*     */       } 
/* 348 */       this._itemmap.putAll(from._itemmap);
/* 349 */       this._srclist.addAll(from._srclist);
/* 350 */       this._update = from._update;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String commit(String srcpath, Source srctype) {
/* 366 */     String src = getSourceString(srcpath, srctype);
/* 367 */     for (int i = 0; i < this._h_len; i++) {
/* 368 */       if (i < this._update)
/*     */       {
/* 370 */         this._h_val[i].setSourceString(src);
/*     */       }
/* 372 */       this._h_key[i] = null;
/* 373 */       this._h_val[i] = null;
/* 374 */       this._h_act[i] = null;
/*     */     } 
/* 376 */     this._update = 0;
/* 377 */     return src;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isUpdate() {
/* 388 */     return (this._update > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void history(String key, MCResourceItem item, MCRow.Status act) {
/* 401 */     int base = 10;
/* 402 */     if (this._update >= this._h_len) {
/* 403 */       if (this._h_len <= 0) {
/* 404 */         this._h_key = new String[base];
/* 405 */         this._h_val = new MCResourceItem[base];
/* 406 */         this._h_act = new MCRow.Status[base];
/* 407 */         this._h_len = base;
/*     */       } else {
/*     */         
/* 410 */         int n_len = this._h_len + base;
/* 411 */         String[] n_key = new String[n_len];
/* 412 */         MCResourceItem[] n_val = new MCResourceItem[n_len];
/* 413 */         MCRow.Status[] n_act = new MCRow.Status[n_len];
/* 414 */         System.arraycopy(this._h_key, 0, n_key, 0, this._h_len);
/* 415 */         System.arraycopy(this._h_val, 0, n_val, 0, this._h_len);
/* 416 */         System.arraycopy(this._h_act, 0, n_act, 0, this._h_len);
/* 417 */         this._h_key = n_key;
/* 418 */         this._h_val = n_val;
/* 419 */         this._h_act = n_act;
/* 420 */         this._h_len = n_len;
/*     */       } 
/*     */     }
/* 423 */     this._h_key[this._update] = key;
/* 424 */     this._h_val[this._update] = item;
/* 425 */     this._h_act[this._update] = act;
/* 426 */     this._update++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends MCRow & MCResourceRow> void addHistoryList(MCList<T> list, String base, String userid, String cocd, String extattr1, String extattr2, String extattr3, Locale locale) {
/* 447 */     for (int i = 0; i < this._update; i++) {
/* 448 */       MCRow mCRow = list.createRow();
/* 449 */       ((MCResourceRow)mCRow).UserID(userid);
/* 450 */       ((MCResourceRow)mCRow).CoCD(cocd);
/* 451 */       ((MCResourceRow)mCRow).ExtAttr1(extattr1);
/* 452 */       ((MCResourceRow)mCRow).ExtAttr2(extattr2);
/* 453 */       ((MCResourceRow)mCRow).ExtAttr3(extattr3);
/* 454 */       ((MCResourceRow)mCRow).Locale((locale != null) ? locale.toString() : null);
/* 455 */       ((MCResourceRow)mCRow).Name(base);
/* 456 */       ((MCResourceRow)mCRow).Key(this._h_key[i]);
/* 457 */       ((MCResourceRow)mCRow).Value(this._h_val[i].getValue());
/* 458 */       mCRow.setStatus(this._h_act[i]);
/* 459 */       list.add(mCRow);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends MCRow & MCResourceRow> void setList(MCList<T> list) {
/* 472 */     if (list == null) {
/*     */       return;
/*     */     }
/* 475 */     String srcinfo = getSourceString(null, Source.DATABASE);
/* 476 */     int len = list.size();
/* 477 */     for (int i = 0; i < len; i++) {
/* 478 */       MCRow mCRow = list.get(i);
/* 479 */       String key = ((MCResourceRow)mCRow).Key();
/* 480 */       if (key != null) {
/* 481 */         set(key, ((MCResourceRow)mCRow).Value(), srcinfo);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCResourceItem remove(String key) {
/* 496 */     synchronized (this) {
/* 497 */       MCResourceItem item = this._itemmap.remove(key);
/* 498 */       if (item != null) {
/* 499 */         history(key, item, MCRow.Status.DELETE);
/*     */       }
/* 501 */       return item;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCResourceItem put(String key, String val) {
/* 521 */     MCResourceItem item = new MCResourceItem();
/* 522 */     item.setValue(val, getSourceString(null, Source.NONE));
/* 523 */     MCResourceItem old = set(key, item);
/* 524 */     history(key, item, (old != null) ? MCRow.Status.MODIFY : MCRow.Status.CREATE);
/* 525 */     return old;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCResourceItem set(String key, MCResourceItem value) {
/* 544 */     synchronized (this) {
/* 545 */       return this._itemmap.put(key, value);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCResourceItem set(String key, String val, String srcinfo) {
/* 567 */     MCResourceItem item = new MCResourceItem();
/* 568 */     item.setValue(val, srcinfo);
/* 569 */     return set(key, item);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCResourceItem set(String key, String val, String srcpath, Source srctype) {
/* 591 */     return set(key, val, getSourceString(srcpath, srctype));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCResourceItem get(String key) {
/* 603 */     return this._itemmap.get(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int size() {
/* 615 */     synchronized (this) {
/* 616 */       return this._itemmap.size();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean containsKey(String key) {
/* 630 */     synchronized (this) {
/* 631 */       return this._itemmap.containsKey(key);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Set<String> keySet() {
/* 643 */     return this._itemmap.keySet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Set<Map.Entry<String, MCResourceItem>> entrySet() {
/* 654 */     return this._itemmap.entrySet();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DefaultHandler createXMLHandler(Source type, String file, MCFileResourceReader reader, String... namespace) {
/* 661 */     return new MCResourceBundleXMLHandler(this, type, file, reader, namespace);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCINIHandler createINIHandler(Source type, String file, MCFileResourceReader reader) {
/* 668 */     return new MCResourceBundleINIHandler(this, type, file, reader);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isSearchedPackage(String pkg) {
/* 674 */     return this._pkgset.contains(pkg);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final void addSearchedPackage(String pkg) {
/* 680 */     this._pkgset.add(pkg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void removeSearchedPackage(String pkg) {
/* 692 */     this._pkgset.remove(pkg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void clearSearchedPackage() {
/* 702 */     this._pkgset.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isSearchedProgram(String pgmid) {
/* 714 */     return this._pgmset.contains(pgmid);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void addSearchedProgram(String pgmid) {
/* 725 */     this._pgmset.add(pgmid);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void removeSearchedProgram(String pgmid) {
/* 736 */     this._pgmset.remove(pgmid);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void clearSearchedProgram() {
/* 746 */     this._pgmset.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void addSource(String srcpath, Source srctype) {
/* 772 */     this._srclist.add(new SrcEntry(srcpath, srctype, null));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void setSource(String srcpath, Source srctype) {
/* 789 */     this._srclist.clear();
/* 790 */     this._srclist.add(new SrcEntry(srcpath, srctype, null));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final String[] getPathArray() {
/* 804 */     int len = this._srclist.size();
/* 805 */     String[] a = new String[len];
/* 806 */     int newlen = len;
/* 807 */     for (int i = 0; i < len; i++) {
/* 808 */       SrcEntry src = this._srclist.get(i);
/* 809 */       if (src.path != null) {
/* 810 */         a[i] = src.path;
/*     */       } else {
/*     */         
/* 813 */         newlen--;
/*     */       } 
/*     */     } 
/* 816 */     if (newlen != len) {
/* 817 */       String[] b = new String[newlen];
/* 818 */       System.arraycopy(a, 0, b, 0, newlen);
/* 819 */       a = b;
/*     */     } 
/* 821 */     return a;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final int pathSize() {
/* 832 */     return this._srclist.size();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 837 */     StringBuilder sb = new StringBuilder();
/*     */     
/* 839 */     synchronized (this) {
/* 840 */       Set<Map.Entry<String, MCResourceItem>> set = this._itemmap.entrySet();
/* 841 */       for (Map.Entry<String, MCResourceItem> entry : set) {
/* 842 */         sb.append(entry.getKey());
/* 843 */         sb.append('=');
/* 844 */         sb.append(((MCResourceItem)entry.getValue()).toString());
/* 845 */         sb.append(MCResource.LINE_SEP);
/*     */       } 
/*     */     } 
/* 848 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> toMap() {
/* 859 */     Map<String, String> map = new LinkedHashMap<>(this._itemmap.size());
/*     */     
/* 861 */     synchronized (this) {
/* 862 */       Set<Map.Entry<String, MCResourceItem>> set = this._itemmap.entrySet();
/* 863 */       for (Map.Entry<String, MCResourceItem> entry : set) {
/* 864 */         map.put(entry.getKey(), ((MCResourceItem)entry.getValue()).getValue());
/*     */       }
/*     */     } 
/* 867 */     return map;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\ctrl\MCResourceBundle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */