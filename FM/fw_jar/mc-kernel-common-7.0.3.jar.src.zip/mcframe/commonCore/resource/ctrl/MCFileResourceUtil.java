/*     */ package mcframe.commonCore.resource.ctrl;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MCFileResourceUtil
/*     */ {
/*     */   static final String PJ_SEP = "@";
/*     */   
/*     */   static final String createProjectFileName(String base, String pj) {
/*  45 */     if (base == null) {
/*  46 */       return null;
/*     */     }
/*  48 */     StringBuilder sb = new StringBuilder(base);
/*  49 */     if (pj != null && pj.length() > 0) {
/*  50 */       sb.append("@");
/*  51 */       sb.append(pj);
/*     */     } 
/*  53 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final String createLocaleFileName(String base, Locale locale) {
/*  76 */     if (base == null) {
/*  77 */       return null;
/*     */     }
/*  79 */     StringBuilder sb = new StringBuilder(base);
/*  80 */     if (locale != null) {
/*  81 */       sb.append("_");
/*  82 */       sb.append(locale.toString());
/*     */     } 
/*  84 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final String createFileName(String base, String pj, Locale locale, boolean auto) {
/* 113 */     if (base == null) {
/* 114 */       return null;
/*     */     }
/* 116 */     StringBuilder sb = new StringBuilder(base);
/* 117 */     if (pj != null && pj.length() > 0) {
/* 118 */       sb.append("@");
/* 119 */       sb.append(pj);
/*     */     } 
/* 121 */     if (auto) {
/* 122 */       sb.append("_A");
/*     */     }
/* 124 */     if (locale != null) {
/* 125 */       sb.append("_");
/* 126 */       sb.append(locale.toString());
/*     */     } 
/* 128 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final File getDir(boolean force, String... paths) {
/* 155 */     File dir = null; byte b; int i; String[] arrayOfString;
/* 156 */     for (i = (arrayOfString = paths).length, b = 0; b < i; ) { String path = arrayOfString[b];
/* 157 */       if (path != null) {
/* 158 */         dir = new File(dir, path);
/*     */       }
/*     */       
/*     */       b++; }
/*     */     
/* 163 */     if (dir == null) {
/* 164 */       return null;
/*     */     }
/* 166 */     if (force && !dir.exists()) {
/* 167 */       dir.mkdirs();
/*     */     }
/* 169 */     if (!dir.isDirectory()) {
/* 170 */       return null;
/*     */     }
/* 172 */     return dir;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\ctrl\MCFileResourceUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */