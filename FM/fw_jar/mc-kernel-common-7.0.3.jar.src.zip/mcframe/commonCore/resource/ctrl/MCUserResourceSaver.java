package mcframe.commonCore.resource.ctrl;

import java.util.Locale;

public interface MCUserResourceSaver {
  String saveUser(MCResourceBundle paramMCResourceBundle, String paramString1, Locale paramLocale, String paramString2);
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\ctrl\MCUserResourceSaver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */