/*    */ package mcframe.commonCore.resource.ctrl;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.OutputStream;
/*    */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*    */ import mcframe.commonCore.notice.MCException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class MCFileResourceWriter
/*    */   extends MCFileResourceIOBase
/*    */ {
/*    */   protected static final String DEFAULT_CHARSET = "UTF-8";
/*    */   
/*    */   public static final MCFileResourceWriter createWriter() {
/* 38 */     return new MCXMLResourceWriter();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   abstract void write(OutputStream paramOutputStream, String paramString1, MCResourceBundle paramMCResourceBundle, String paramString2);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final void writeToFilePath(MCResourceBundle resource, File file) {
/* 73 */     String filepath = file.getAbsolutePath();
/* 74 */     MCResourceBundle.Source srctype = MCResourceBundle.Source.FILEPATH;
/* 75 */     String logresource = MCResourceBundle.getSourceString(filepath, srctype);
/*    */ 
/*    */     
/* 78 */     traceTargetResource(logresource);
/*    */     
/* 80 */     OutputStream os = null;
/*    */     try {
/* 82 */       os = new FileOutputStream(file);
/* 83 */     } catch (FileNotFoundException ex) {
/*    */       
/* 85 */       traceWriteErrorResource(logresource);
/* 86 */       throw new MCException(ex, Core_Msg_FW_A.FCBJC0053, new Object[] { filepath });
/*    */     } 
/*    */     
/*    */     try {
/* 90 */       write(os, "UTF-8", resource, logresource);
/*    */       
/* 92 */       resource.setSource(filepath, srctype);
/* 93 */       traceSavedResource(logresource);
/* 94 */     } catch (MCException ex) {
/*    */       
/* 96 */       traceWriteErrorResource(logresource);
/* 97 */       throw ex;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\ctrl\MCFileResourceWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */