/*      */ package mcframe.commonCore.resource.ctrl;
/*      */ 
/*      */ import java.awt.Color;
/*      */ import java.net.InetAddress;
/*      */ import java.net.UnknownHostException;
/*      */ import java.util.Locale;
/*      */ import mcframe.commonCore.lang.MCNumber;
/*      */ import mcframe.commonCore.lang.MCStringUtil;
/*      */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*      */ import mcframe.commonCore.notice.MCException;
/*      */ import mcframe.commonCore.notice.MCLog;
/*      */ import mcframe.commonCore.notice.MCMessage;
/*      */ import mcframe.commonCore.resource.MCConst;
/*      */ import mcframe.commonCore.sys.MCSys;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class MCReadableResource
/*      */   extends MCGroupResource
/*      */ {
/*      */   public static final String ARRAY_DELIMITER = ",";
/*      */   public static final char ARRAY_ESCAPE = '"';
/*      */   public final MCStringUtil.BindSource bindsrc;
/*      */   
/*      */   static final class BindSource
/*      */     implements MCStringUtil.BindSource
/*      */   {
/*      */     private final MCReadableResource _resource;
/*      */     
/*      */     enum ReserveBind
/*      */     {
/*   62 */       MCF_HOME
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         String value()
/*      */         {
/*   69 */           return MCSys.env.MCF_HOME();
/*      */         }
/*      */       },
/*      */       
/*   73 */       USERHOME
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         String value()
/*      */         {
/*   80 */           return MCSys.env.USERHOME();
/*      */         }
/*      */       },
/*      */       
/*   84 */       USER
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         String value()
/*      */         {
/*  107 */           String user = MCSys.user.ID();
/*  108 */           return (user != null) ? user : "";
/*      */         }
/*      */       },
/*      */       
/*  112 */       LOGINSEQ
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*      */         String value()
/*      */         {
/*  119 */           String seq = MCSys.user.loginSequence();
/*  120 */           return (seq != null) ? seq : "(no sequence)";
/*      */         }
/*      */       },
/*      */       
/*  124 */       PORT
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         String value()
/*      */         {
/*  133 */           Integer p = MCSys.env._getClientPortNO();
/*  134 */           return (p != null) ? String.valueOf(p) : "";
/*      */         }
/*      */       },
/*      */       
/*  138 */       HOST
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         String value()
/*      */         {
/*  147 */           String host = null;
/*      */           try {
/*  149 */             host = InetAddress.getLocalHost().getHostName();
/*      */           }
/*  151 */           catch (UnknownHostException unknownHostException) {
/*  152 */             host = System.getenv("COMPUTERNAME");
/*  153 */             if (host == null) {
/*  154 */               host = System.getenv("HOSTNAME");
/*      */             }
/*      */           } 
/*  157 */           if (host == null) {
/*  158 */             host = "MCF-SERVER";
/*      */           }
/*  160 */           return host;
/*      */         }
/*      */       };
/*      */ 
/*      */       
/*  165 */       static final ReserveBind[] consts = values();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       static {
/*      */       
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       abstract String value();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     BindSource(MCReadableResource resource) {
/*  194 */       this._resource = resource;
/*      */     }
/*      */     
/*      */     public String nullstr() {
/*  198 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void nullstr(String str) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String get(String key) {
/*  214 */       int len = ReserveBind.consts.length;
/*  215 */       for (int i = 0; i < len; i++) {
/*  216 */         ReserveBind rb = ReserveBind.consts[i];
/*  217 */         if (rb.name().equals(key)) {
/*  218 */           return rb.value();
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/*  223 */       return this._resource.getString(key);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int size() {
/*  240 */       return ReserveBind.consts.length;
/*      */     }
/*      */     
/*      */     public boolean containsKey(String key) {
/*  244 */       int len = ReserveBind.consts.length;
/*  245 */       for (int i = 0; i < len; i++) {
/*  246 */         if (ReserveBind.consts[i].name().equals(key)) {
/*  247 */           return true;
/*      */         }
/*      */       } 
/*  250 */       return this._resource.containsKey(key);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MCReadableResource(MCGroupResource.Type type, String filebase) {
/*  274 */     super(type, filebase);
/*  275 */     setWritable(false);
/*  276 */     this.bindsrc = new BindSource(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String loadInit(String homedir, String[] pjpath, String[] mdpath, Locale locale) {
/*  285 */     super.loadInit(homedir, pjpath, mdpath, locale);
/*      */     
/*  287 */     return loadInitExceptVMOS(homedir, pjpath, mdpath, locale);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String loadInitExceptVMOS(String homedir, String[] pjpath, String[] mdpath, Locale locale) {
/*  308 */     MCResourceBundle pkg = getPackageBundle();
/*  309 */     pkg.clear();
/*      */ 
/*      */     
/*  312 */     MCInitResourceLoader loader = getInitLoader(false, homedir, pjpath, mdpath);
/*      */     
/*  314 */     StringBuilder sb = new StringBuilder();
/*      */     
/*  316 */     if (!isLoadedBaseBundle()) {
/*  317 */       MCResourceBundle base = getBaseBundle();
/*      */       
/*  319 */       loadInit(loader, base, (Locale)null, sb);
/*      */     } 
/*      */ 
/*      */     
/*  323 */     if (locale != null) {
/*      */       
/*  325 */       MCResourceBundle init = getInitBundle();
/*  326 */       init.clear();
/*      */ 
/*      */       
/*  329 */       loadInit(loader, init, locale, sb);
/*      */     } 
/*  331 */     return sb.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void loadInit(MCInitResourceLoader loader, MCResourceBundle bundle, Locale locale, StringBuilder trace) {
/*  346 */     long s = System.currentTimeMillis();
/*  347 */     trace.append(loader.loadInit(bundle, getFileBase(), locale));
/*  348 */     long e = System.currentTimeMillis();
/*  349 */     long t = e - s;
/*  350 */     trace.append("(load total : " + t + ")\n");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String loadPackageInit(String[] pjpath, Locale locale, String... pkgs) {
/*  371 */     MCResourceBundle init = getPackageBundle();
/*  372 */     MCInitResourceLoader loader = getInitLoader((String)null, pjpath, (String[])null);
/*  373 */     return loader.loadInitPackage(init, getFileBase(), locale, pkgs);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MCInitResourceLoader getInitLoader(String homedir, String[] pjpath, String[] mdpath) {
/*  397 */     return getFileResourceLoader(true, homedir, pjpath, mdpath);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MCInitResourceLoader getInitLoader(boolean baselocale, String homedir, String[] pjpath, String[] mdpath) {
/*  421 */     return getFileResourceLoader(baselocale, homedir, pjpath, mdpath);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   MCFileResourceLoader getFileResourceLoader(String homedir, String[] pjpath, String[] mdpath) {
/*  446 */     return getFileResourceLoader(true, homedir, pjpath, mdpath);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   MCFileResourceLoader getFileResourceLoader(boolean baselocale, String homedir, String[] pjpath, String[] mdpath) {
/*  470 */     MCGroupResource.Type type = getType();
/*  471 */     return new MCFileResourceLoader(
/*  472 */         getFileResourceSequencer(baselocale, pjpath), 
/*  473 */         homedir, 
/*  474 */         type.getBaseDir(), 
/*  475 */         type.isReadCommonUser(), 
/*  476 */         type.isReadModulePath() ? mdpath : null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   MCFileResourceSequencer getFileResourceSequencer(String[] pjpath) {
/*  495 */     return getFileResourceSequencer(true, pjpath);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   MCFileResourceSequencer getFileResourceSequencer(boolean baselocale, String[] pjpath) {
/*  513 */     return new MCFileResourceSequencer(
/*  514 */         MCResource.isAutoGenSupport(this), 
/*  515 */         baselocale, 
/*  516 */         pjpath);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getString(String key) {
/*  536 */     return getString(key, (String)null, (MCMessage)null);
/*      */   }
/*      */   
/*      */   protected String getString(MCResourceLayerType type, String key) {
/*  540 */     boolean defval = false;
/*  541 */     String value = getSourceString(type, key);
/*  542 */     if (value != null) {
/*      */       try {
/*  544 */         value = MCStringUtil.bind(value, this.bindsrc);
/*      */       }
/*  546 */       catch (StackOverflowError err) {
/*      */         
/*  548 */         throw new MCException(err, Core_Msg_FW_A.FCBJC0056, new Object[] { getFileBase(), key });
/*      */       } 
/*      */     } else {
/*      */       
/*  552 */       value = null;
/*  553 */       defval = true;
/*      */     } 
/*  555 */     tracelog(key, value, defval);
/*  556 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getString(String key, String def) {
/*  573 */     return getString(key, def, (MCMessage)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getString(String key, String def, MCMessage msg) {
/*  596 */     return _getString(key, def, (String)null, msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getStringNoTrim(String key) {
/*  615 */     return getStringNoTrim(key, (String)null, (MCMessage)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getStringNoTrim(String key, String def) {
/*  637 */     return getStringNoTrim(key, def, (MCMessage)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getStringNoTrim(String key, String def, MCMessage msg) {
/*  665 */     return _getString(key, def, "@", msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String _getString(String key, String def, String remove, MCMessage msg) {
/*  693 */     boolean defval = false;
/*  694 */     String value = getSourceString(key);
/*  695 */     if (value != null) {
/*      */       try {
/*  697 */         value = MCStringUtil.bind(value, this.bindsrc);
/*      */       }
/*  699 */       catch (StackOverflowError err) {
/*      */         
/*  701 */         throw new MCException(err, Core_Msg_FW_A.FCBJC0056, new Object[] { getFileBase(), key });
/*      */       } 
/*      */       
/*  704 */       if (remove != null) {
/*  705 */         int vl = value.length();
/*  706 */         int rl = remove.length();
/*  707 */         if (vl >= rl * 2 && 
/*  708 */           value.startsWith(remove) && value.endsWith(remove)) {
/*  709 */           value = value.substring(rl, vl - rl);
/*      */         }
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/*  715 */       if (msg != null) {
/*  716 */         MCLog.write(msg);
/*      */       }
/*  718 */       value = def;
/*  719 */       defval = true;
/*      */     } 
/*  721 */     tracelog(key, value, defval);
/*  722 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected char getCharacter(String key) {
/*  740 */     return getCharacter(key, (Character)null, (MCMessage)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected char getCharacter(String key, char def) {
/*  760 */     return getCharacter(key, def, (MCMessage)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected char getCharacter(String key, char def, MCMessage msg) {
/*  785 */     return getCharacter(key, Character.valueOf(def), (MCMessage)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private char getCharacter(String key, Character def, MCMessage msg) {
/*      */     char value;
/*  812 */     boolean defval = false;
/*      */     
/*  814 */     String str = getString(key);
/*  815 */     if (str == null) {
/*  816 */       if (msg != null) {
/*  817 */         MCLog.write(msg);
/*      */       }
/*  819 */       if (def == null)
/*      */       {
/*  821 */         throw new MCException(Core_Msg_FW_A.FCBJC0050, new Object[] {
/*  822 */               getFileBase(), key, "(null)"
/*      */             }); } 
/*  824 */       value = def.charValue();
/*  825 */       defval = true;
/*      */     }
/*  827 */     else if (str.length() != 1) {
/*  828 */       if (msg != null) {
/*  829 */         MCLog.write(msg);
/*      */       }
/*  831 */       if (def == null)
/*      */       {
/*  833 */         throw new MCException(Core_Msg_FW_A.FCBJC0050, new Object[] { getFileBase(), key, str });
/*      */       }
/*  835 */       value = def.charValue();
/*  836 */       defval = true;
/*      */     } else {
/*      */       
/*  839 */       value = str.charAt(0);
/*      */     } 
/*  841 */     tracelog(key, Character.valueOf(value), defval);
/*  842 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MCNumber getNumber(String key) {
/*  858 */     return getNumber(key, (MCNumber)null, (MCMessage)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MCNumber getNumber(String key, MCNumber def) {
/*  876 */     return getNumber(key, def, (MCMessage)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MCNumber getNumber(String key, MCNumber def, MCMessage msg) {
/*  899 */     boolean defval = false;
/*  900 */     MCNumber value = null;
/*  901 */     String str = getString(key);
/*      */     try {
/*  903 */       value = MCNumber.valueOf(str);
/*      */     }
/*  905 */     catch (MCException ex) {
/*      */       
/*  907 */       throw new MCException(ex, Core_Msg_FW_A.FCBJC0025, new Object[] { getFileBase(), key, str });
/*      */     } 
/*  909 */     if (value == null) {
/*  910 */       if (msg != null) {
/*  911 */         MCLog.write(msg);
/*      */       }
/*  913 */       value = def;
/*  914 */       defval = true;
/*      */     } 
/*  916 */     tracelog(key, value, defval);
/*  917 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getInteger(String key) {
/*  933 */     return getInteger(key, (Integer)null, (MCMessage)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getInteger(String key, int def) {
/*  951 */     return getInteger(key, def, (MCMessage)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getInteger(String key, int def, MCMessage msg) {
/*  974 */     return getInteger(key, Integer.valueOf(def), msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int getInteger(String key, Integer def, MCMessage msg) {
/*      */     Integer value;
/* 1000 */     boolean defval = false;
/*      */     
/* 1002 */     String str = getString(key);
/* 1003 */     if (str == null) {
/* 1004 */       if (msg != null) {
/* 1005 */         MCLog.write(msg);
/*      */       }
/* 1007 */       if (def == null)
/*      */       {
/* 1009 */         throw new MCException(Core_Msg_FW_A.FCBJC0026, new Object[] {
/* 1010 */               getFileBase(), key, "(null)"
/*      */             }); } 
/* 1012 */       value = def;
/* 1013 */       defval = true;
/*      */     } else {
/*      */       
/*      */       try {
/* 1017 */         value = Integer.valueOf(str);
/*      */       }
/* 1019 */       catch (Exception ex) {
/*      */         
/* 1021 */         throw new MCException(ex, Core_Msg_FW_A.FCBJC0026, new Object[] { getFileBase(), key, str });
/*      */       } 
/*      */     } 
/* 1024 */     tracelog(key, value, defval);
/* 1025 */     return value.intValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean getBoolean(String key) {
/* 1042 */     return getBoolean(key, (Boolean)null, (MCMessage)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean getBoolean(String key, boolean def) {
/* 1061 */     return getBoolean(key, def, (MCMessage)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean getBoolean(String key, boolean def, MCMessage msg) {
/* 1085 */     return getBoolean(key, Boolean.valueOf(def), msg);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean getBoolean(String key, Boolean def, MCMessage msg) {
/*      */     Boolean value;
/* 1110 */     boolean defval = false;
/*      */     
/* 1112 */     String str = getString(key);
/* 1113 */     if (str == null && def != null) {
/* 1114 */       if (msg != null) {
/* 1115 */         MCLog.write(msg);
/*      */       }
/* 1117 */       value = def;
/* 1118 */       defval = true;
/*      */     } else {
/*      */       
/* 1121 */       value = Boolean.valueOf(str);
/*      */     } 
/* 1123 */     tracelog(key, value, defval);
/* 1124 */     return value.booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Color getColor(String key) {
/* 1150 */     return getColor(key, (Color)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Color getColor(String key, Color def) {
/* 1177 */     String value = getString(key);
/*      */     try {
/* 1179 */       Color result = MCResource.createColor(value);
/* 1180 */       return (result != null) ? result : def;
/*      */     }
/* 1182 */     catch (MCException e) {
/* 1183 */       throw new MCException(e, Core_Msg_FW_A.FCBJC0032, new Object[] { key, value });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String[] getStringArray(String key) {
/* 1202 */     return getStringArray(key, (String[])null, (MCMessage)null);
/*      */   }
/*      */   
/*      */   protected String[] getStringArray(MCResourceLayerType type, String key) {
/* 1206 */     String s = getString(type, key);
/* 1207 */     if (s == null) {
/* 1208 */       return null;
/*      */     }
/*      */ 
/*      */     
/* 1212 */     String[] a = MCStringUtil.split('"', ",", s);
/* 1213 */     int len = a.length;
/* 1214 */     for (int i = 0; i < len; i++) {
/* 1215 */       a[i] = MCStringUtil.trim(a[i]);
/*      */     }
/* 1217 */     return a;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String[] getStringArray(String key, String[] def) {
/* 1238 */     return getStringArray(key, def, (MCMessage)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String[] getStringArray(String key, String[] def, MCMessage msg) {
/* 1264 */     return _getStringArray(key, def, msg, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String[] getSourceStringArray(String key) {
/* 1279 */     return getSourceStringArray(key, (String[])null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String[] getSourceStringArray(String key, String[] def) {
/* 1296 */     return _getStringArray(key, def, (MCMessage)null, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String[] _getStringArray(String key, String[] def, MCMessage msg, boolean isSrc) {
/* 1325 */     String[] value = null;
/* 1326 */     String str = null;
/* 1327 */     if (isSrc) {
/* 1328 */       str = getSourceString(key);
/*      */     } else {
/*      */       
/* 1331 */       str = getString(key);
/*      */     } 
/* 1333 */     if (str == null) {
/* 1334 */       if (msg != null) {
/* 1335 */         MCLog.write(msg);
/*      */       }
/* 1337 */       value = def;
/*      */     }
/*      */     else {
/*      */       
/* 1341 */       value = MCStringUtil.split('"', ",", str);
/* 1342 */       int len = value.length;
/* 1343 */       for (int i = 0; i < len; i++) {
/* 1344 */         value[i] = MCStringUtil.trim(value[i]);
/*      */       }
/*      */     } 
/* 1347 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String[] getStringArrayKeyRotation(String pgmId, String key) {
/* 1374 */     StringBuilder sb = new StringBuilder();
/*      */     
/* 1376 */     int c = 0;
/*      */     while (true) {
/* 1378 */       String k = String.valueOf(key) + "_" + String.valueOf(c++);
/* 1379 */       if (!containsKey(k)) {
/*      */         break;
/*      */       }
/*      */       
/* 1383 */       String s = getString(k);
/* 1384 */       s = s.substring(1, s.length() - 1);
/* 1385 */       sb.append(s);
/*      */     } 
/*      */ 
/*      */     
/* 1389 */     return MCStringUtil.split(
/* 1390 */         '"', ",", sb.toString());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void tracelog(String key, Object value, boolean defval) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String loadTemp(String[] pjpath, String[] mdpath, Locale locale, String... paths) {
/* 1475 */     if (paths == null || paths.length <= 0) {
/* 1476 */       return "";
/*      */     }
/*      */ 
/*      */     
/* 1480 */     StringBuilder sb = new StringBuilder();
/* 1481 */     MCInitResourceLoader loader = getTempLoader(pjpath, mdpath, 
/* 1482 */         getType().getBaseDir());
/* 1483 */     MCResourceBundle usr = getUserBundle();
/* 1484 */     sb.append(loader.loadInitPath(usr, getFileBase(), locale, paths));
/* 1485 */     return sb.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String loadTemp(String[] pjpath, String pkg, Locale locale, String... paths) {
/* 1521 */     if (paths == null || paths.length <= 0) {
/* 1522 */       return "";
/*      */     }
/*      */     
/* 1525 */     StringBuilder sb = new StringBuilder();
/* 1526 */     MCInitResourceLoader loader = getTempLoader(pjpath, (String[])null, pkg);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1550 */     MCGroupResourceMap gmap = createTempMap();
/* 1551 */     MCResourceBundleMap umap = gmap.getUserBundleMap();
/* 1552 */     String base = gmap.getFileBase(); byte b; int i; String[] arrayOfString;
/* 1553 */     for (i = (arrayOfString = paths).length, b = 0; b < i; ) { String path = arrayOfString[b];
/* 1554 */       sb.append(loader.loadInitPath(umap, base, locale, new String[] { path }));
/*      */       b++; }
/*      */     
/* 1557 */     if (!MCConst.checkLoadIntegration(gmap, sb)) {
/*      */       
/* 1559 */       MCResourceBundle usr = getUserBundle();
/* 1560 */       base = getFileBase(); String[] arrayOfString1;
/* 1561 */       for (int j = (arrayOfString1 = paths).length; i < j; ) { String path = arrayOfString1[i];
/* 1562 */         sb.append(loader.loadInitPath(usr, base, locale, new String[] { path })); i++; }
/*      */     
/*      */     } 
/* 1565 */     return sb.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MCGroupResourceMap createTempMap() {
/* 1576 */     String base = MCConst.getBundleFileBase();
/* 1577 */     MCGroupResourceMap map = MCConst.createGroupMap(base);
/* 1578 */     map.put(getFileBase(), this);
/* 1579 */     return map;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MCInitResourceLoader getTempLoader(String[] pjpath, String[] mdpath, String basepkg) {
/* 1594 */     return new MCFileResourceLoader(
/*      */         
/* 1596 */         getFileResourceSequencer(pjpath), 
/*      */         
/* 1598 */         null, 
/*      */         
/* 1600 */         basepkg, 
/*      */         
/* 1602 */         false, 
/*      */         
/* 1604 */         mdpath);
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\ctrl\MCReadableResource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */