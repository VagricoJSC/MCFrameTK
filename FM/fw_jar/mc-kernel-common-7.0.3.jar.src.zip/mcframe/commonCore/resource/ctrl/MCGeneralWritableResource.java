/*     */ package mcframe.commonCore.resource.ctrl;
/*     */ 
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.notice.MCMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MCGeneralWritableResource
/*     */   extends MCWritableResource
/*     */ {
/*     */   protected MCGeneralWritableResource(MCGroupResource.Type type, String filebase) {
/*  28 */     super(type, filebase);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSourceString(String key) {
/*  37 */     return super.getSourceString(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString(String key) {
/*  42 */     return super.getString(key);
/*     */   }
/*     */   
/*     */   public String getString(String key, String def) {
/*  46 */     return super.getString(key, def);
/*     */   }
/*     */   
/*     */   public String getString(String key, String def, MCMessage msg) {
/*  50 */     return super.getString(key, def, msg);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getStringNoTrim(String key) {
/*  55 */     return super.getStringNoTrim(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getStringNoTrim(String key, String def) {
/*  60 */     return super.getStringNoTrim(key, def);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getStringNoTrim(String key, String def, MCMessage msg) {
/*  65 */     return super.getStringNoTrim(key, def, msg);
/*     */   }
/*     */   
/*     */   public char getCharacter(String key) {
/*  69 */     return super.getCharacter(key);
/*     */   }
/*     */   
/*     */   public char getCharacter(String key, char def) {
/*  73 */     return super.getCharacter(key, def);
/*     */   }
/*     */   
/*     */   public char getCharacter(String key, char def, MCMessage msg) {
/*  77 */     return super.getCharacter(key, def, msg);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCNumber getNumber(String key) {
/*  82 */     return super.getNumber(key);
/*     */   }
/*     */   
/*     */   public MCNumber getNumber(String key, MCNumber def) {
/*  86 */     return super.getNumber(key, def);
/*     */   }
/*     */   
/*     */   public MCNumber getNumber(String key, MCNumber def, MCMessage msg) {
/*  90 */     return super.getNumber(key, def, msg);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getInteger(String key) {
/*  95 */     return super.getInteger(key);
/*     */   }
/*     */   
/*     */   public int getInteger(String key, int def) {
/*  99 */     return super.getInteger(key, def);
/*     */   }
/*     */   
/*     */   public int getInteger(String key, int def, MCMessage msg) {
/* 103 */     return super.getInteger(key, def, msg);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getBoolean(String key) {
/* 108 */     return super.getBoolean(key);
/*     */   }
/*     */   
/*     */   public boolean getBoolean(String key, boolean def) {
/* 112 */     return super.getBoolean(key, def);
/*     */   }
/*     */   
/*     */   public boolean getBoolean(String key, boolean def, MCMessage msg) {
/* 116 */     return super.getBoolean(key, def, msg);
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getStringArray(String key) {
/* 121 */     return super.getStringArray(key);
/*     */   }
/*     */   
/*     */   public String[] getStringArray(String key, String[] def) {
/* 125 */     return super.getStringArray(key, def);
/*     */   }
/*     */   
/*     */   public String[] getStringArray(String key, String[] def, MCMessage msg) {
/* 129 */     return super.getStringArray(key, def, msg);
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getSourceStringArray(String key) {
/* 134 */     return super.getSourceStringArray(key);
/*     */   }
/*     */   
/*     */   public String[] getSourceStringArray(String key, String[] def) {
/* 138 */     return super.getSourceStringArray(key, def);
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getStringArrayKeyRotation(String pgmId, String key) {
/* 143 */     return super.getStringArrayKeyRotation(pgmId, key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setString(String key, String value) {
/* 151 */     super.setString(key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCharacter(String key, char value) {
/* 156 */     super.setCharacter(key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setNumber(String key, MCNumber value) {
/* 161 */     super.setNumber(key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setInteger(String key, int value) {
/* 166 */     super.setInteger(key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBoolean(String key, boolean value) {
/* 171 */     super.setBoolean(key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setStringArray(String key, String[] value) {
/* 176 */     super.setStringArray(key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStringArrayKeyRotation(String pgmId, String key, String[] value) {
/* 182 */     super.setStringArrayKeyRotation(pgmId, key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(String key) {
/* 190 */     super.remove(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public void remove(String... keys) {
/* 195 */     super.remove(keys);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\ctrl\MCGeneralWritableResource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */