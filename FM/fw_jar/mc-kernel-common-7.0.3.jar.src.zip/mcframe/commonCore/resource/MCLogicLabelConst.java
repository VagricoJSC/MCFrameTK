/*     */ package mcframe.commonCore.resource;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import mcframe.commonCore.annotation.AutoGenResource;
/*     */ import mcframe.commonCore.annotation.LocaleResource;
/*     */ import mcframe.commonCore.event.MCLogicLabelListener;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.sys.MCFactory;
/*     */ import mcframe.commonCore.sys.MCSys;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MCLogicLabelConst
/*     */   extends MCJITConst
/*     */ {
/*     */   public static final String FILE_BASE = "MCLogicLabel";
/*  55 */   private Map<Locale, List<MCLogicLabelListener>> _labellistenerMap = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @AutoGenResource
/*     */   @LocaleResource
/*     */   public final class LgcLConst
/*     */     extends MCJITConst.JITLabelConst
/*     */   {
/*     */     LgcLConst(String modid, Locale l) {
/*  76 */       super(modid, l, "MCLogicLabel");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     LgcLConst() {
/*  88 */       super("MCLogicLabel");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public final String getLabel(String key) {
/* 108 */       return getSourceStringBlank(key);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   MCJITConst.JITLabelConst createConst(String mod, Locale l) {
/* 114 */     return new LgcLConst(mod, l);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getLabel(String mod, String lgc, String ope) {
/* 140 */     return getLabel(mod, lgc, ope, MCSys.user.locale());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getLabel(String mod, String lgc, String ope, Locale locale) {
/* 162 */     if (MCStringUtil.isNull(mod) || mod.length() < 1 || 
/* 163 */       MCStringUtil.isNull(lgc) || lgc.length() < 1) {
/* 164 */       return null;
/*     */     }
/* 166 */     String key = MCConst.createKey(new String[] { mod, lgc, ope, "label" });
/* 167 */     String lab = get(mod, locale).getSourceStringBlank(key);
/*     */ 
/*     */ 
/*     */     
/* 171 */     List<MCLogicLabelListener> _labellistener = null;
/* 172 */     if (locale != null) {
/* 173 */       _labellistener = this._labellistenerMap.get(locale);
/*     */     }
/* 175 */     if (locale != null && _labellistener == null) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 180 */       _labellistener = new ArrayList<>();
/* 181 */       this._labellistenerMap.put(locale, _labellistener);
/*     */       
/* 183 */       _labellistener = createLabelListener(locale);
/* 184 */       this._labellistenerMap.put(locale, _labellistener);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 189 */     if (_labellistener != null) {
/*     */       try {
/* 191 */         for (MCLogicLabelListener l : _labellistener) {
/* 192 */           lab = l.doNGEvent(key, lab);
/*     */         }
/* 194 */       } catch (Throwable e) {
/* 195 */         String lStr = (locale == null) ? null : locale.toString();
/* 196 */         MCLog.write((Throwable)new MCException(Core_Msg_FW_A.FCBHC0113, new Object[] { key, lab, lStr, e.getMessage() }));
/*     */       } 
/*     */     }
/*     */     
/* 200 */     return lab;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<MCLogicLabelListener> createLabelListener(Locale locale) {
/* 211 */     List<MCLogicLabelListener> listeners = new ArrayList<>();
/*     */     
/* 213 */     String entrykey = "logiclabel";
/*     */     
/* 215 */     if (!MCConst.plugin.isLoadedBaseBundle()) {
/* 216 */       return null;
/*     */     }
/*     */     
/* 219 */     String[] keys = MCConst.plugin.getOrderKeys(entrykey); byte b; int i; String[] arrayOfString1;
/* 220 */     for (i = (arrayOfString1 = keys).length, b = 0; b < i; ) { String key = arrayOfString1[b];
/* 221 */       if (!MCConst.plugin.containsKey(key)) {
/*     */         
/* 223 */         MCLog.write((Throwable)new MCException(Core_Msg_FW_A.FCBHC0103, new Object[] { key, null }));
/*     */       } else {
/*     */         
/* 226 */         String name = MCConst.plugin.getName(key);
/* 227 */         if (name != null)
/*     */           
/*     */           try {
/*     */ 
/*     */             
/* 232 */             Class[] c = { Locale.class };
/* 233 */             Object[] o = { locale };
/* 234 */             MCLogicLabelListener listener = (MCLogicLabelListener)MCFactory.create(
/* 235 */                 MCLogicLabelListener.class, name, c, o);
/* 236 */             listeners.add(listener);
/* 237 */           } catch (Exception ex) {
/*     */             
/* 239 */             MCLog.write((Throwable)new MCException(ex, Core_Msg_FW_A.FCBHC0103, new Object[] { key, name }));
/*     */           }  
/*     */       }  b++; }
/*     */     
/* 243 */     return listeners;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\MCLogicLabelConst.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */