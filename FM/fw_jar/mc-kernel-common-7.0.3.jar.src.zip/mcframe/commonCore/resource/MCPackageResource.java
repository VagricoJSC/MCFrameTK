package mcframe.commonCore.resource;

import java.util.Locale;

public interface MCPackageResource extends MCDumpResource {
  String loadPackageInit(Locale paramLocale, String... paramVarArgs);
  
  String loadPackageInit(String[] paramArrayOfString1, Locale paramLocale, String... paramVarArgs1);
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\MCPackageResource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */