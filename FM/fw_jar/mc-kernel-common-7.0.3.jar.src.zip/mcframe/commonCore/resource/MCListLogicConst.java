/*     */ package mcframe.commonCore.resource;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Collectors;
/*     */ import java.util.stream.Stream;
/*     */ import mcframe.commonCore.annotation.AutoGenResource;
/*     */ import mcframe.commonCore.resource.ctrl.MCGroupResource;
/*     */ import mcframe.commonCore.resource.ctrl.MCReadableResource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @AutoGenResource
/*     */ public final class MCListLogicConst
/*     */   extends MCReadableResource
/*     */ {
/*     */   public static final String FILE_BASE = "MCListLogic";
/*  40 */   protected static final MCGroupResource.Type TYPE = MCGroupResource.Type.CONST;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String KEY_PATH = "path";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String KEY_SERVER_METHOD = "server";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String KEY_CLIENT_METHOD = "client";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String _method_delim = "#";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String KEY_COLS = "common";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCListLogicConst() {
/*  84 */     super(TYPE, "MCListLogic");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String getServerMethodPath(String listLogicId) {
/*  96 */     String key = MCConst.createKey(new String[] { listLogicId, "path", "server" });
/*  97 */     return getString(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getServerClass(String listLogicId) {
/* 108 */     String s = getServerMethodPath(listLogicId);
/* 109 */     if (s != null) {
/* 110 */       return s.split("#")[0];
/*     */     }
/* 112 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getServerMethod(String listLogicId) {
/* 123 */     String s = getServerMethodPath(listLogicId);
/* 124 */     if (s != null) {
/* 125 */       return s.split("#")[1];
/*     */     }
/* 127 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String getClientMethodPath(String listLogicId) {
/* 139 */     String key = MCConst.createKey(new String[] { listLogicId, "path", "client" });
/* 140 */     return getString(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getClientClass(String listLogicId) {
/* 151 */     String s = getClientMethodPath(listLogicId);
/* 152 */     if (s != null) {
/* 153 */       return s.split("#")[0];
/*     */     }
/* 155 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getClientMethod(String listLogicId) {
/* 166 */     String s = getClientMethodPath(listLogicId);
/* 167 */     if (s != null) {
/* 168 */       return s.split("#")[1];
/*     */     }
/* 170 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String getCommonColsPath(String listLogicId) {
/* 183 */     String key = MCConst.createKey(new String[] { listLogicId, "path", "common" });
/* 184 */     return getString(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String[] getCommonCols(String listLogicId) {
/* 196 */     String s = getCommonColsPath(listLogicId);
/* 197 */     if (s != null) {
/* 198 */       String[] s_i = s.split("\\$");
/* 199 */       String common = s_i[0];
/* 200 */       String cols = s_i[1];
/* 201 */       return new String[] {
/* 202 */           common, cols
/*     */         };
/*     */     } 
/* 205 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isCacheEnable() {
/* 216 */     return getBoolean(MCConst.createKey(new String[] { "cache", "enable" }, ), true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final List<String> getCacheClassId(ListLogicEnv env) {
/* 227 */     List<String> result = new ArrayList<>();
/* 228 */     Set<String> exclude = env.getExcludeCacheIds();
/* 229 */     Stream.<String>of(env.getCachePtn()).forEach(ptn -> paramList.addAll(Arrays.asList(findPattern(ptn))));
/*     */ 
/*     */     
/* 232 */     return (List<String>)result.stream()
/* 233 */       .filter(id -> !paramSet.contains(id))
/* 234 */       .collect(Collectors.toList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final String[] getServerCachePtn() {
/* 245 */     return getStringArray(MCConst.createKey(new String[] { "cache", "server", "ptn" }, ), new String[] {
/* 246 */           "*.????L????.*"
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final String[] getClientCachePtn() {
/* 258 */     return getStringArray(MCConst.createKey(new String[] { "cache", "client", "ptn" }, ), new String[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final Set<String> getServerExcludeCacheIds() {
/* 270 */     String[] ids = getStringArray(MCConst.createKey(new String[] { "cache", "server", "exclude" }, ), new String[0]);
/* 271 */     Set<String> result = new HashSet<>();
/* 272 */     Collections.addAll(result, ids);
/* 273 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final Set<String> getClientExcludeCacheIds() {
/* 284 */     String[] ids = getStringArray(MCConst.createKey(new String[] { "cache", "client", "exclude" }, ), new String[0]);
/* 285 */     Set<String> result = new HashSet<>();
/* 286 */     Collections.addAll(result, ids);
/* 287 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum ListLogicEnv
/*     */   {
/* 298 */     SERVER
/*     */     {
/*     */       public String[] getCachePtn() {
/* 301 */         return MCConst.ll.getServerCachePtn();
/*     */       }
/*     */ 
/*     */       
/*     */       public Set<String> getExcludeCacheIds() {
/* 306 */         return MCConst.ll.getServerExcludeCacheIds();
/*     */       }
/*     */     },
/* 309 */     CLIENT
/*     */     {
/*     */       public String[] getCachePtn() {
/* 312 */         return MCConst.ll.getClientCachePtn();
/*     */       }
/*     */       
/*     */       public Set<String> getExcludeCacheIds() {
/* 316 */         return MCConst.ll.getClientExcludeCacheIds();
/*     */       }
/*     */     };
/*     */     
/*     */     public abstract String[] getCachePtn();
/*     */     
/*     */     public abstract Set<String> getExcludeCacheIds();
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\MCListLogicConst.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */