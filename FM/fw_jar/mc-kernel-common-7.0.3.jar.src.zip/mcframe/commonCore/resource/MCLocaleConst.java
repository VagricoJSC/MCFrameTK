/*     */ package mcframe.commonCore.resource;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import mcframe.commonCore.resource.ctrl.MCGroupResource;
/*     */ import mcframe.commonCore.resource.ctrl.MCResource;
/*     */ import mcframe.commonCore.sys.MCFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MCLocaleConst<E extends MCGroupResource>
/*     */   extends MCResource
/*     */ {
/*  31 */   private static final MCLocaleConst<MCMessageConst> _message = new MCLocaleConst(
/*  32 */       (Class)MCMessageConst.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final MCMessageConst message(Locale l) {
/*  43 */     return _message.get(l);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   private static final MCLocaleConst<MCLabelConst> _label = new MCLocaleConst(
/*  52 */       (Class)MCLabelConst.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final MCLabelConst label(Locale l) {
/*  63 */     return _label.get(l);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final MCLabelConst label(Locale l, Class... cls) {
/*  84 */     return _label.get(l, cls);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final MCLabelConst label(Locale l, String... pkgs) {
/* 105 */     return _label.get(l, pkgs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 113 */   private static final MCLocaleConst<MCReportLabelConst> _reportLabel = new MCLocaleConst(
/* 114 */       (Class)MCReportLabelConst.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final MCReportLabelConst reportLabel(Locale l) {
/* 125 */     return _reportLabel.get(l);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final MCReportLabelConst reportLabel(Locale l, Class... cls) {
/* 146 */     return _reportLabel.get(l, cls);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final MCReportLabelConst reportLabel(Locale l, String... pkgs) {
/* 167 */     return _reportLabel.get(l, pkgs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 175 */   private static final MCLocaleConst<MCFormatConst> _format = new MCLocaleConst(
/* 176 */       (Class)MCFormatConst.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final MCFormatConst format(Locale l) {
/* 187 */     return _format.get(l);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean _init = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Class<E> _constclass;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void loadInit() {
/* 208 */     if (!_init) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 220 */       String[] ls = MCConfig.common.getEntryLocaleArray();
/*     */       
/* 222 */       loadInitSeparate(ls);
/* 223 */       _init = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final void loadInitSeparate(String... ls) {
/* 272 */     _message.init(ls);
/* 273 */     _label.init(ls);
/* 274 */     _reportLabel.init(ls);
/* 275 */     _format.init(ls);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 316 */   private Map<String, E> _constmap = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCLocaleConst(Class<E> constclass) {
/* 325 */     this._constclass = constclass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private E createLocaleInstance(String l) {
/* 339 */     return (E)MCFactory.create(this._constclass, this._constclass.getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init(String[] ls) {
/* 358 */     this._constmap.clear(); byte b; int i; String[] arrayOfString;
/* 359 */     for (i = (arrayOfString = ls).length, b = 0; b < i; ) { String l = arrayOfString[b];
/* 360 */       this._constmap.put(l, null);
/*     */       b++; }
/*     */     
/* 363 */     this._constmap.put(null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String loadLocaleConst(String l) {
/* 399 */     Locale locale = null;
/* 400 */     if (l != null)
/* 401 */     { E lconst; String ret, items[] = l.split("_", 3);
/* 402 */       switch (items.length)
/*     */       { case 1:
/* 404 */           locale = new Locale(items[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 417 */           lconst = createLocaleInstance(l);
/* 418 */           ret = loadInit(locale, new MCGroupResource[] { (MCGroupResource)lconst });
/*     */           
/* 420 */           this._constmap.put(l, lconst);
/* 421 */           return ret;case 2: locale = new Locale((String)lconst[0], (String)lconst[1]); lconst = createLocaleInstance(l); ret = loadInit(locale, new MCGroupResource[] { (MCGroupResource)lconst }); this._constmap.put(l, lconst); return ret;case 3: locale = new Locale((String)lconst[0], (String)lconst[1], (String)lconst[2]); lconst = createLocaleInstance(l); ret = loadInit(locale, new MCGroupResource[] { (MCGroupResource)lconst }); this._constmap.put(l, lconst); return ret; }  return ""; }  E e = createLocaleInstance(l); String str = loadInit(locale, new MCGroupResource[] { (MCGroupResource)e }); this._constmap.put(l, e); return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final E get(Locale locale) {
/* 467 */     String key = null;
/* 468 */     if (locale != null) {
/* 469 */       StringBuilder temp = new StringBuilder();
/* 470 */       String l = locale.getLanguage();
/* 471 */       String c = locale.getCountry();
/* 472 */       String v = locale.getVariant();
/* 473 */       if (l.length() > 0) {
/* 474 */         temp.append(l);
/* 475 */         if (this._constmap.containsKey(temp.toString())) {
/* 476 */           key = temp.toString();
/*     */         }
/*     */       } 
/* 479 */       temp.append("_");
/* 480 */       if (c.length() > 0) {
/* 481 */         temp.append(c);
/* 482 */         if (this._constmap.containsKey(temp.toString())) {
/* 483 */           key = temp.toString();
/*     */         }
/*     */       } 
/* 486 */       temp.append("_");
/* 487 */       if (v.length() > 0) {
/* 488 */         temp.append(v);
/* 489 */         if (this._constmap.containsKey(temp.toString())) {
/* 490 */           key = temp.toString();
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 495 */     MCGroupResource mCGroupResource = (MCGroupResource)this._constmap.get(key);
/* 496 */     if (mCGroupResource == null)
/*     */     {
/* 498 */       synchronized (this._constmap) {
/* 499 */         mCGroupResource = (MCGroupResource)this._constmap.get(key);
/* 500 */         if (mCGroupResource == null) {
/*     */           
/* 502 */           StringBuilder trace = new StringBuilder();
/* 503 */           trace.append(loadLocaleConst(key));
/* 504 */           MCResource.tracelog(true, key, trace.toString());
/* 505 */           mCGroupResource = (MCGroupResource)this._constmap.get(key);
/*     */         } 
/*     */       } 
/*     */     }
/* 509 */     return (E)mCGroupResource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final E get(Locale locale, Class... cls) {
/* 530 */     E con = get(locale); byte b; int i; Class[] arrayOfClass;
/* 531 */     for (i = (arrayOfClass = cls).length, b = 0; b < i; ) { Class<?> cl = arrayOfClass[b];
/* 532 */       MCConst.loadPackageInit(locale, cl, new MCPackageResource[] { (MCPackageResource)con }); b++; }
/*     */     
/* 534 */     return con;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final E get(Locale locale, String... pkgs) {
/* 555 */     E con = get(locale); byte b; int i; String[] arrayOfString;
/* 556 */     for (i = (arrayOfString = pkgs).length, b = 0; b < i; ) { String pkg = arrayOfString[b];
/* 557 */       MCConst.loadPackageInit(locale, pkg, new MCPackageResource[] { (MCPackageResource)con }); b++; }
/*     */     
/* 559 */     return con;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\MCLocaleConst.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */