/*     */ package mcframe.commonCore.resource;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.resource.ctrl.MCGroupResource;
/*     */ import mcframe.commonCore.resource.ctrl.MCGroupResourceMap;
/*     */ import mcframe.commonCore.resource.ctrl.MCResource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCConst
/*     */   extends MCResource
/*     */ {
/* 182 */   public static final MCMessageConst message = new MCMessageConst();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 189 */   public static final MCPluginConst plugin = new MCPluginConst();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 196 */   public static final MCACTypeConst actype = new MCACTypeConst();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 203 */   public static final MCLabelConst label = new MCLabelConst();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 211 */   public static final MCFormatConst format = new MCFormatConst();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 218 */   public static final MCReportConst report = new MCReportConst();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 225 */   public static final MCReportLabelConst repotlbl = new MCReportLabelConst();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 233 */   public static final MCDBLabelConst dblbl = new MCDBLabelConst();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 241 */   public static final MCLogicLabelConst lgclbl = new MCLogicLabelConst();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 248 */   public static final MCListLogicConst ll = new MCListLogicConst();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 255 */   static final MCGroupResource[] group = new MCGroupResource[] {
/* 256 */       (MCGroupResource)message, (MCGroupResource)plugin, (MCGroupResource)actype, (MCGroupResource)label, (MCGroupResource)format, (MCGroupResource)report, (MCGroupResource)repotlbl, (MCGroupResource)ll
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 267 */   static final MCPackageResource[] pkg = getPackageResource(group);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String FILE_BASE = "MCConst";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String BASE_DIR = "const";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static MCGroupResourceMap createGroupMap(boolean common, MCGroupResource... adds) {
/* 283 */     MCGroupResourceMap map = new MCGroupResourceMap("MCConst");
/* 284 */     if (common) {
/* 285 */       byte b1; int j; MCGroupResource[] arrayOfMCGroupResource1; for (j = (arrayOfMCGroupResource1 = group).length, b1 = 0; b1 < j; ) { MCGroupResource gr = arrayOfMCGroupResource1[b1];
/* 286 */         map.put(gr.getFileBase(), gr); b1++; }
/*     */     
/*     */     }  byte b; int i; MCGroupResource[] arrayOfMCGroupResource;
/* 289 */     for (i = (arrayOfMCGroupResource = adds).length, b = 0; b < i; ) { MCGroupResource gr = arrayOfMCGroupResource[b];
/* 290 */       map.put(gr.getFileBase(), gr); b++; }
/*     */     
/* 292 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static MCGroupResourceMap createGroupMap(boolean common, MCPackageResource... adds) {
/* 309 */     MCGroupResourceMap map = new MCGroupResourceMap("MCConst");
/* 310 */     if (common) {
/* 311 */       byte b1; int j; MCPackageResource[] arrayOfMCPackageResource1; for (j = (arrayOfMCPackageResource1 = pkg).length, b1 = 0; b1 < j; ) { MCPackageResource gr = arrayOfMCPackageResource1[b1];
/* 312 */         map.put(gr.getFileBase(), (MCGroupResource)gr); b1++; }
/*     */     
/*     */     }  byte b; int i; MCPackageResource[] arrayOfMCPackageResource;
/* 315 */     for (i = (arrayOfMCPackageResource = adds).length, b = 0; b < i; ) { MCPackageResource gr = arrayOfMCPackageResource[b];
/* 316 */       map.put(gr.getFileBase(), (MCGroupResource)gr); b++; }
/*     */     
/* 318 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getBundleFileBase() {
/* 350 */     return "MCConst";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void loaddump() {
/* 367 */     loaddump((MCDumpResource[])group);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void resetAllBundle() {
/* 378 */     resetBundle(group);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final String loadInit(Locale locale) {
/* 395 */     return loadInit(locale, group);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final String loadInit(Locale locale, Class<?> cl) {
/* 416 */     return loadInit(locale, cl, pkg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final String loadInit(Locale locale, String... pkgs) {
/* 437 */     return loadInit(locale, pkgs, pkg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String loadPackageInit(Locale locale, Class<?> cl, MCPackageResource... ress) {
/* 452 */     MCGroupResourceMap rmap = createGroupMap(false, ress);
/* 453 */     return loadPackageInit(false, locale, cl, rmap, ress);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String loadPackageInit(Locale locale, String pkg, MCPackageResource... ress) {
/* 468 */     MCGroupResourceMap rmap = createGroupMap(false, ress);
/* 469 */     return loadPackageInit(false, locale, pkg, rmap, ress);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final String loadPackageInitWithCommon(Locale locale, Class<?> cl, MCGroupResourceMap rmap, MCPackageResource[] pkg) {
/* 508 */     return loadPackageInit(true, locale, cl, rmap, pkg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final String loadPackageInitWithCommon(Locale locale, String pkgpath, MCGroupResourceMap rmap, MCPackageResource[] pkg) {
/* 548 */     return loadPackageInit(true, locale, pkgpath, rmap, pkg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String loadPackageInit(boolean common, Locale locale, Class<?> cl, MCGroupResourceMap rmap, MCPackageResource[] pkg) {
/* 566 */     StringBuilder sb = createTraceBuffer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 572 */     if (!loadInitIntegration(locale, cl, sb, rmap))
/*     */     {
/* 574 */       if (MCConfig.common.getBoolean("resource.division.package", false)) {
/*     */         
/* 576 */         MCLog.write(Core_Msg_FW_A.FCBJC0068, new Object[] { cl.getPackage().getName() });
/*     */ 
/*     */         
/* 579 */         if (common) {
/* 580 */           removeSearchedPackage(cl, MCConst.pkg);
/*     */         }
/* 582 */         removeSearchedPackage(cl, pkg);
/* 583 */         loadInitDivision(common, locale, cl, sb, pkg);
/*     */       } 
/*     */     }
/*     */     
/* 587 */     String trace = sb.toString();
/* 588 */     tracelogPackageCaption(true, cl, trace);
/* 589 */     return trace;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String loadPackageInit(boolean common, Locale locale, String pkgpath, MCGroupResourceMap rmap, MCPackageResource[] pkg) {
/* 607 */     StringBuilder sb = createTraceBuffer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 613 */     if (!loadInitIntegration(locale, pkgpath, sb, rmap))
/*     */     {
/* 615 */       if (MCConfig.common.getBoolean("resource.division.package", false)) {
/*     */         
/* 617 */         MCLog.write(Core_Msg_FW_A.FCBJC0068, new Object[] { pkgpath });
/*     */ 
/*     */         
/* 620 */         if (common) {
/* 621 */           removeSearchedPackage(pkgpath, MCConst.pkg);
/*     */         }
/* 623 */         removeSearchedPackage(pkgpath, pkg);
/* 624 */         loadInitDivision(common, locale, pkgpath, sb, pkg);
/*     */       } 
/*     */     }
/*     */     
/* 628 */     String trace = sb.toString();
/* 629 */     tracelogPackageCaption(true, pkgpath, trace);
/* 630 */     return trace;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final boolean loadInitIntegration(Locale locale, Class<?> cl, StringBuilder sb, MCGroupResourceMap rmap) {
/* 650 */     sb.append(loadInit(locale, cl, rmap));
/* 651 */     return checkLoadIntegration(rmap, sb);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final boolean loadInitIntegration(Locale locale, String pkgpath, StringBuilder sb, MCGroupResourceMap rmap) {
/* 671 */     sb.append(loadInit(locale, pkgpath, rmap));
/* 672 */     return checkLoadIntegration(rmap, sb);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final void loadInitDivision(boolean common, Locale locale, Class<?> cl, StringBuilder sb, MCPackageResource[] pkg) {
/* 692 */     if (common)
/*     */     {
/* 694 */       sb.append(loadInit(locale, cl));
/*     */     }
/*     */     
/* 697 */     sb.append(loadInit(locale, cl, pkg));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final void loadInitDivision(boolean common, Locale locale, String pkgpath, StringBuilder sb, MCPackageResource[] pkg) {
/* 717 */     if (common)
/*     */     {
/* 719 */       sb.append(loadInit(locale, new String[] {
/* 720 */               pkgpath
/*     */             }));
/*     */     }
/*     */     
/* 724 */     sb.append(loadInit(locale, pkgpath, pkg));
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\MCConst.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */