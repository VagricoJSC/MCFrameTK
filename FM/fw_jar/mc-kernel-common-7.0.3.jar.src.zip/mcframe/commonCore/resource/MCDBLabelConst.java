/*     */ package mcframe.commonCore.resource;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import mcframe.commonCore.annotation.AutoGenResource;
/*     */ import mcframe.commonCore.annotation.LocaleResource;
/*     */ import mcframe.commonCore.event.MCDBLabelListener;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.sys.MCFactory;
/*     */ import mcframe.commonCore.sys.MCSys;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MCDBLabelConst
/*     */   extends MCJITConst
/*     */ {
/*     */   public static final String FILE_BASE = "MCDBLabel";
/*  58 */   private Map<Locale, List<MCDBLabelListener>> _labellistenerMap = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @AutoGenResource
/*     */   @LocaleResource
/*     */   public final class DBLConst
/*     */     extends MCJITConst.JITLabelConst
/*     */   {
/*     */     DBLConst(String modid, Locale l) {
/*  79 */       super(modid, l, "MCDBLabel");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     DBLConst() {
/*  91 */       super("MCDBLabel");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public final String getLabel(String key) {
/* 111 */       return getSourceStringBlank(key);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   MCJITConst.JITLabelConst createConst(String mod, Locale l) {
/* 117 */     return new DBLConst(mod, l);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getLabel(String tblName, String colName) {
/* 141 */     return getLabel(tblName, colName, MCSys.user.locale());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getLabel(String tblName, String colName, Locale locale) {
/* 162 */     if (MCStringUtil.isNull(tblName) || tblName.length() < 1) {
/* 163 */       return null;
/*     */     }
/*     */     
/* 166 */     String[] mods = MCConst.getModulePath();
/*     */ 
/*     */     
/* 169 */     Arrays.sort(mods, new Comparator<String>()
/*     */         {
/*     */           public int compare(String o1, String o2) {
/* 172 */             int rtn = o2.length() - o1.length();
/* 173 */             if (rtn == 0) {
/* 174 */               rtn = o1.compareTo(o2);
/*     */             }
/* 176 */             return rtn;
/*     */           }
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 183 */     String[] reMods = new String[mods.length];
/* 184 */     int ri = 0; byte b;
/*     */     int i;
/*     */     String[] arrayOfString1;
/* 187 */     for (i = (arrayOfString1 = mods).length, b = 0; b < i; ) { String mod = arrayOfString1[b];
/* 188 */       if (tblName.startsWith(mod)) {
/* 189 */         String key = MCConst.createKey(new String[] { mod, tblName, colName, "label" });
/* 190 */         String rtn = get(mod, locale).getSourceStringBlank(key);
/* 191 */         if (rtn != null) {
/* 192 */           rtn = _doNGEvent(key, rtn, locale);
/* 193 */           return rtn;
/*     */         } 
/*     */       } else {
/*     */         
/* 197 */         reMods[ri++] = mod;
/*     */       } 
/*     */       b++; }
/*     */     
/* 201 */     for (i = (arrayOfString1 = reMods).length, b = 0; b < i; ) { String mod = arrayOfString1[b];
/* 202 */       if (mod == null) {
/*     */         break;
/*     */       }
/* 205 */       MCJITConst.JITLabelConst lbl = get(mod, locale);
/* 206 */       String key = MCConst.createKey(new String[] { mod, tblName, colName, "label" });
/* 207 */       String rtn = lbl.getSourceStringBlank(key);
/* 208 */       if (rtn != null) {
/* 209 */         rtn = _doNGEvent(key, rtn, locale);
/* 210 */         return rtn;
/*     */       }  b++; }
/*     */     
/* 213 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String _doNGEvent(String key, String lab, Locale locale) {
/* 219 */     List<MCDBLabelListener> _labellistener = null;
/* 220 */     if (locale != null) {
/* 221 */       _labellistener = this._labellistenerMap.get(locale);
/*     */     }
/* 223 */     if (locale != null && _labellistener == null) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 228 */       _labellistener = new ArrayList<>();
/* 229 */       this._labellistenerMap.put(locale, _labellistener);
/*     */       
/* 231 */       _labellistener = createLabelListener(locale);
/* 232 */       this._labellistenerMap.put(locale, _labellistener);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 237 */     if (_labellistener != null) {
/*     */       try {
/* 239 */         for (MCDBLabelListener l : _labellistener) {
/* 240 */           lab = l.doNGEvent(key, lab);
/*     */         }
/*     */       }
/* 243 */       catch (Throwable e) {
/* 244 */         String lStr = (locale == null) ? null : locale.toString();
/* 245 */         MCLog.write((Throwable)new MCException(Core_Msg_FW_A.FCBHC0112, new Object[] { key, lab, lStr, e.getMessage() }));
/*     */       } 
/*     */     }
/*     */     
/* 249 */     return lab;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<MCDBLabelListener> createLabelListener(Locale locale) {
/* 260 */     List<MCDBLabelListener> listeners = new ArrayList<>();
/*     */     
/* 262 */     String entrykey = "dblabel";
/*     */     
/* 264 */     if (!MCConst.plugin.isLoadedBaseBundle()) {
/* 265 */       return null;
/*     */     }
/*     */     
/* 268 */     String[] keys = MCConst.plugin.getOrderKeys(entrykey); byte b; int i; String[] arrayOfString1;
/* 269 */     for (i = (arrayOfString1 = keys).length, b = 0; b < i; ) { String key = arrayOfString1[b];
/* 270 */       if (!MCConst.plugin.containsKey(key)) {
/*     */         
/* 272 */         MCLog.write((Throwable)new MCException(Core_Msg_FW_A.FCBHC0102, new Object[] { key, null }));
/*     */       } else {
/*     */         
/* 275 */         String name = MCConst.plugin.getName(key);
/* 276 */         if (name != null)
/*     */           
/*     */           try {
/*     */ 
/*     */             
/* 281 */             Class[] c = {
/* 282 */                 Locale.class
/*     */               };
/* 284 */             Object[] o = {
/* 285 */                 locale
/*     */               };
/* 287 */             MCDBLabelListener listener = (MCDBLabelListener)MCFactory.create(MCDBLabelListener.class, 
/* 288 */                 name, c, o);
/* 289 */             listeners.add(listener);
/*     */           }
/* 291 */           catch (Exception ex) {
/*     */             
/* 293 */             MCLog.write((Throwable)new MCException(ex, Core_Msg_FW_A.FCBHC0102, new Object[] { key, name }));
/*     */           }  
/*     */       }  b++; }
/*     */     
/* 297 */     return listeners;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\MCDBLabelConst.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */