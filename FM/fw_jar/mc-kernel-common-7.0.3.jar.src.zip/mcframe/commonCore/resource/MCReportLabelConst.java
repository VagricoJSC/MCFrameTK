/*     */ package mcframe.commonCore.resource;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import mcframe.commonCore.annotation.AutoGenResource;
/*     */ import mcframe.commonCore.annotation.LocaleResource;
/*     */ import mcframe.commonCore.event.MCReportLabelListener;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.resource.ctrl.MCGroupResource;
/*     */ import mcframe.commonCore.resource.ctrl.MCReadableResource;
/*     */ import mcframe.commonCore.resource.ctrl.MCResource;
/*     */ import mcframe.commonCore.sys.MCFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @AutoGenResource
/*     */ @LocaleResource
/*     */ public final class MCReportLabelConst
/*     */   extends MCReadableResource
/*     */   implements MCPackageResource
/*     */ {
/*     */   public static final String FILE_BASE = "MCReportLabel";
/*  46 */   protected static final MCGroupResource.Type TYPE = MCGroupResource.Type.CONST;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String BLANK = "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<MCReportLabelListener> _labellistener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCReportLabelConst() {
/*  75 */     super(TYPE, "MCReportLabel");
/*     */   }
/*     */ 
/*     */   
/*     */   public final String loadPackageInit(Locale locale, String... pkgs) {
/*  80 */     return loadPackageInit(MCResource.getProjectPath(), locale, pkgs);
/*     */   }
/*     */ 
/*     */   
/*     */   public final String loadPackageInit(String[] pjpath, Locale locale, String... pkgs) {
/*  85 */     return super.loadPackageInit(pjpath, locale, pkgs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getLabel(String key) {
/* 104 */     String lab = getSourceString(key, "");
/*     */     
/* 106 */     if (!MCConst.repotlbl.isLoadedBaseBundle()) {
/* 107 */       return lab;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 112 */     if (this._labellistener == null) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 117 */       this._labellistener = new ArrayList<>();
/*     */       
/* 119 */       this._labellistener = createLabelListener();
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 124 */     if (this._labellistener != null) {
/*     */       try {
/* 126 */         for (MCReportLabelListener l : this._labellistener) {
/* 127 */           lab = l.doNGEvent(key, lab, this._locale);
/*     */         }
/* 129 */       } catch (Throwable e) {
/* 130 */         String lStr = (this._locale == null) ? null : this._locale.toString();
/* 131 */         MCLog.write((Throwable)new MCException(Core_Msg_FW_A.FCBHC0114, new Object[] { key, lab, lStr, e.getMessage() }));
/*     */       } 
/*     */     }
/*     */     
/* 135 */     return lab;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<MCReportLabelListener> createLabelListener() {
/* 146 */     List<MCReportLabelListener> listeners = new ArrayList<>();
/*     */     
/* 148 */     String entrykey = "reportlabel";
/*     */     
/* 150 */     if (!MCConst.plugin.isLoadedBaseBundle()) {
/* 151 */       return null;
/*     */     }
/*     */     
/* 154 */     String[] keys = MCConst.plugin.getOrderKeys(entrykey); byte b; int i; String[] arrayOfString1;
/* 155 */     for (i = (arrayOfString1 = keys).length, b = 0; b < i; ) { String key = arrayOfString1[b];
/* 156 */       if (!MCConst.plugin.containsKey(key)) {
/*     */         
/* 158 */         MCLog.write((Throwable)new MCException(Core_Msg_FW_A.FCBHC0104, new Object[] { key, null }));
/*     */       } else {
/*     */         
/* 161 */         String name = MCConst.plugin.getName(key);
/* 162 */         if (name != null)
/*     */           
/*     */           try {
/*     */ 
/*     */             
/* 167 */             MCReportLabelListener listener = (MCReportLabelListener)MCFactory.create(
/* 168 */                 MCReportLabelListener.class, name);
/* 169 */             listeners.add(listener);
/* 170 */           } catch (Exception ex) {
/*     */             
/* 172 */             MCLog.write((Throwable)new MCException(ex, Core_Msg_FW_A.FCBHC0104, new Object[] { key, name }));
/*     */           }  
/*     */       }  b++; }
/*     */     
/* 176 */     return listeners;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSourceString(String key) {
/* 196 */     return super.getSourceString(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getString(String key) {
/* 201 */     return super.getString(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean getBoolean(String key, boolean def) {
/* 206 */     return super.getBoolean(key, def);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\MCReportLabelConst.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */