/*     */ package mcframe.commonCore.resource;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import mcframe.commonCore.annotation.LocaleResource;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.resource.ctrl.MCGroupResource;
/*     */ import mcframe.commonCore.resource.ctrl.MCReadableResource;
/*     */ import mcframe.commonCore.util.MCCollectionUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @LocaleResource
/*     */ public class MCFormatConst
/*     */   extends MCReadableResource
/*     */ {
/*     */   public static final String FILE_BASE = "MCFormat";
/*  41 */   protected static final MCGroupResource.Type TYPE = MCGroupResource.Type.CONST;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String DATE = "date";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String NUMBER = "number";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String NOFORMAT = "NOFORMAT";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   private static final Character[] ENABLE_INPUT_CHAR = new Character[] {
/*  74 */       Character.valueOf('y'), Character.valueOf('M'), Character.valueOf('d'), Character.valueOf('H'), Character.valueOf('h'), Character.valueOf('m'), Character.valueOf('s'), Character.valueOf('S')
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   private static final Character[] ENABLE_OUTPUT_CHAR = new Character[] { 
/*  84 */       Character.valueOf('y'), Character.valueOf('M'), Character.valueOf('d'), Character.valueOf('H'), Character.valueOf('h'), Character.valueOf('m'), Character.valueOf('s'), Character.valueOf('S'), 
/*  85 */       Character.valueOf('G'), Character.valueOf('w'), Character.valueOf('W'), Character.valueOf('D'), Character.valueOf('F'), Character.valueOf('E'), Character.valueOf('K'), Character.valueOf('k'), Character.valueOf('h'), Character.valueOf('Z'), Character.valueOf('z') };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  94 */   private static final Character[] ENABLE_OUTPUT_2CHAR = new Character[] {
/*  95 */       Character.valueOf('a')
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCFormatConst() {
/* 105 */     super(TYPE, "MCFormat");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDateOutputPattern(String id) {
/* 118 */     return getOutputPattern("date", id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDateOutputBase(String id) {
/* 131 */     return !MCStringUtil.isNull(id) ? 
/* 132 */       getString(MCConst.createKey(new String[] { "date", id, "output.base" })) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDateOutputBlank(String id) {
/* 146 */     if (MCStringUtil.isNull(id)) {
/* 147 */       return null;
/*     */     }
/*     */     
/* 150 */     String k = MCConst.createKey(new String[] { "date", id, "output.blank" });
/* 151 */     if (containsKey(k)) {
/* 152 */       return getString(k);
/*     */     }
/*     */     
/* 155 */     String p = getDateOutputPattern(id);
/* 156 */     if (MCStringUtil.isNull(p)) {
/* 157 */       return null;
/*     */     }
/*     */     
/* 160 */     StringBuilder sb = new StringBuilder(); byte b; int i; char[] arrayOfChar;
/* 161 */     for (i = (arrayOfChar = p.toCharArray()).length, b = 0; b < i; ) { char c = arrayOfChar[b];
/* 162 */       if (MCCollectionUtil.contains(Character.valueOf(c), (Object[])ENABLE_INPUT_CHAR)) {
/* 163 */         sb.append("_");
/*     */       }
/* 165 */       else if (MCCollectionUtil.contains(Character.valueOf(c), (Object[])ENABLE_OUTPUT_CHAR)) {
/* 166 */         sb.append(" ");
/*     */       }
/* 168 */       else if (MCCollectionUtil.contains(Character.valueOf(c), (Object[])ENABLE_OUTPUT_2CHAR)) {
/* 169 */         sb.append("__");
/*     */       } else {
/*     */         
/* 172 */         sb.append(c);
/*     */       }  b++; }
/*     */     
/* 175 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDateInputPattern(String id) {
/* 192 */     if (MCStringUtil.isNull(id)) {
/* 193 */       return null;
/*     */     }
/*     */     
/* 196 */     String k = MCConst.createKey(new String[] { "date", id, "input.pattern" });
/* 197 */     if (containsKey(k)) {
/* 198 */       return getString(k);
/*     */     }
/*     */     
/* 201 */     String p = getDateOutputPattern(id);
/* 202 */     if (MCStringUtil.isNull(p)) {
/* 203 */       return null;
/*     */     }
/*     */     
/* 206 */     StringBuilder sb = new StringBuilder(); byte b; int i; char[] arrayOfChar;
/* 207 */     for (i = (arrayOfChar = p.toCharArray()).length, b = 0; b < i; ) { char c = arrayOfChar[b];
/* 208 */       if (MCCollectionUtil.contains(Character.valueOf(c), (Object[])ENABLE_INPUT_CHAR))
/* 209 */         sb.append(c); 
/*     */       b++; }
/*     */     
/* 212 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDateInputBase(String id) {
/* 227 */     return !MCStringUtil.isNull(id) ? 
/* 228 */       getString(MCConst.createKey(new String[] { "date", id, "input.base" })) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNumberOutputPattern(String id) {
/* 241 */     return getOutputPattern("number", id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNumberInputPattern(String id) {
/* 254 */     return getInputPattern("number", id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getOutputPattern(String type, String id) {
/* 275 */     return !MCStringUtil.isNull(id) ? 
/* 276 */       getString(MCConst.createKey(new String[] { type, id, "output.pattern" })) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getInputPattern(String type, String id) {
/* 297 */     return !MCStringUtil.isNull(id) ? 
/* 298 */       getString(MCConst.createKey(new String[] { type, id, "input.pattern" })) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getNumberPositiveForeground(String id) {
/* 312 */     return getColor(MCConst.createKey(new String[] { "number", id, "positive.fg" }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getNumberNegativeForeground(String id) {
/* 327 */     return getColor(MCConst.createKey(new String[] { "number", id, "negative.fg" }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCZeroType getNumberZeroType(String id) {
/* 339 */     String value = getString(MCConst.createKey(new String[] { "number", id, "zero" }));
/* 340 */     if (!MCStringUtil.isNull(value)) {
/* 341 */       MCZeroType[] types = MCZeroType.values(); byte b; int i; MCZeroType[] arrayOfMCZeroType1;
/* 342 */       for (i = (arrayOfMCZeroType1 = types).length, b = 0; b < i; ) { MCZeroType type = arrayOfMCZeroType1[b];
/* 343 */         if (type.toString().equals(value))
/* 344 */           return type; 
/*     */         b++; }
/*     */     
/*     */     } 
/* 348 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Character getNumberDecimalSeparator(String id) {
/* 360 */     String s = getString(MCConst.createKey(new String[] { "number", id, "decimalsep" }));
/* 361 */     if (s != null && s.length() >= 1) {
/* 362 */       return Character.valueOf(s.charAt(0));
/*     */     }
/* 364 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Character getNumberGroupingSeparator(String id) {
/* 376 */     String s = getString(MCConst.createKey(new String[] { "number", id, "groupingsep" }));
/* 377 */     if (s != null && s.length() >= 1) {
/* 378 */       return Character.valueOf(s.charAt(0));
/*     */     }
/* 380 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum MCZeroType
/*     */   {
/* 391 */     CUT,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 400 */     PADDING,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 409 */     NONE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getString(String key, String def) {
/* 421 */     return super.getString(key, def);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\MCFormatConst.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */