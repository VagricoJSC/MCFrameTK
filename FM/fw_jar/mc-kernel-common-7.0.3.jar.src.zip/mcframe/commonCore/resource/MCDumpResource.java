package mcframe.commonCore.resource;

public interface MCDumpResource {
  String getFileBase();
  
  String[] getLoadSourceArray();
  
  String toString(boolean paramBoolean);
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\MCDumpResource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */