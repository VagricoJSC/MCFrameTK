/*     */ package mcframe.commonCore.resource;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.resource.ctrl.MCGroupResource;
/*     */ import mcframe.commonCore.resource.ctrl.MCReadableResource;
/*     */ import mcframe.commonCore.resource.ctrl.MCResource;
/*     */ import mcframe.commonCore.sys.MCFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MCPluginConst
/*     */   extends MCReadableResource
/*     */ {
/*     */   public static final String FILE_BASE = "MCPlugin";
/*  36 */   protected static final MCGroupResource.Type TYPE = MCGroupResource.Type.CONST;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String KEY_ORDER = "order";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCPluginConst() {
/*  53 */     super(TYPE, "MCPlugin");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getName(String key) {
/*  66 */     return getString(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String[] getOrderNames(String key) {
/*  86 */     String[] okeys = getOrderKeys(key);
/*  87 */     int len = okeys.length;
/*  88 */     int cnt = 0;
/*  89 */     String[] names = new String[len]; byte b; int i; String[] arrayOfString1;
/*  90 */     for (i = (arrayOfString1 = okeys).length, b = 0; b < i; ) { String okey = arrayOfString1[b];
/*  91 */       if (containsKey(okey))
/*     */       {
/*  93 */         throw new MCException(Core_Msg_FW_A.FCBJC0059, new Object[] { "MCPlugin", okey });
/*     */       }
/*  95 */       String name = getName(okey);
/*  96 */       if (name != null)
/*     */       {
/*  98 */         names[cnt++] = name; } 
/*     */       b++; }
/*     */     
/* 101 */     if (cnt < len) {
/* 102 */       String[] temp = new String[cnt];
/* 103 */       System.arraycopy(names, 0, temp, 0, cnt);
/* 104 */       names = temp;
/*     */     } 
/* 106 */     return names;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String[] getOrderKeys(String key) {
/* 136 */     String[] order = getOrder(key);
/* 137 */     if (order == null) {
/*     */       
/* 139 */       String pattern = MCResource.createKey(new String[] { key, "*" });
/* 140 */       order = findKeys(pattern);
/* 141 */       Arrays.sort((Object[])order);
/*     */       
/* 143 */       String orderkey = MCResource.createKey(new String[] { key, "order" });
/* 144 */       int len = order.length;
/* 145 */       int cnt = 0;
/* 146 */       String[] temp = new String[len]; byte b; int i; String[] arrayOfString1;
/* 147 */       for (i = (arrayOfString1 = order).length, b = 0; b < i; ) { String o = arrayOfString1[b];
/* 148 */         if (!o.equals(orderkey))
/* 149 */           temp[cnt++] = o; 
/*     */         b++; }
/*     */       
/* 152 */       if (cnt < len) {
/* 153 */         order = new String[cnt];
/* 154 */         System.arraycopy(temp, 0, order, 0, cnt);
/*     */       } else {
/* 156 */         order = temp;
/*     */       } 
/*     */     } else {
/*     */       
/* 160 */       int len = order.length;
/* 161 */       for (int i = 0; i < len; i++) {
/* 162 */         order[i] = MCResource.createKey(new String[] { key, order[i] });
/*     */       } 
/*     */     } 
/* 165 */     return order;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String[] getOrder(String key) {
/* 181 */     String[] order = null;
/* 182 */     String okey = MCResource.createKey(new String[] { key, "order" });
/* 183 */     String val = getString(okey);
/* 184 */     if (val != null)
/*     */     {
/* 186 */       order = val.split(",");
/*     */     }
/* 188 */     return order;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final <T> Class<? extends T> getClass(Class<T> proto, String key) {
/* 206 */     String name = getName(key);
/* 207 */     return (name != null) ? MCFactory.getClass(proto, name) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final <T> T create(Class<T> proto, String key) {
/* 225 */     String name = getName(key);
/* 226 */     return (name != null) ? (T)MCFactory.create(proto, name) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final <T> T createEx(Class<T> proto, String key) {
/* 245 */     String name = getName(key);
/* 246 */     if (name == null) {
/* 247 */       throw new MCException(Core_Msg_FW_A.FCBJC0058, new Object[] { getFileBase(), key });
/*     */     }
/* 249 */     return (T)MCFactory.create(proto, name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getString(String key, String def) {
/* 266 */     return super.getString(key, def);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String[] getStringArray(String key, String[] def) {
/* 287 */     return getStringArray(key, def, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getInteger(String key, int def) {
/* 305 */     return super.getInteger(key, def);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean getBoolean(String key, boolean def) {
/* 324 */     return super.getBoolean(key, def);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\MCPluginConst.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */