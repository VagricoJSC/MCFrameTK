/*     */ package mcframe.commonCore.resource;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import mcframe.commonCore.annotation.AutoGenResource;
/*     */ import mcframe.commonCore.annotation.LocaleResource;
/*     */ import mcframe.commonCore.event.MCMessageListener;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.notice.MCMessage;
/*     */ import mcframe.commonCore.notice.MCMessageLevel;
/*     */ import mcframe.commonCore.resource.ctrl.MCGroupResource;
/*     */ import mcframe.commonCore.resource.ctrl.MCReadableResource;
/*     */ import mcframe.commonCore.resource.ctrl.MCResource;
/*     */ import mcframe.commonCore.sys.MCFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @AutoGenResource
/*     */ @LocaleResource
/*     */ public class MCMessageConst
/*     */   extends MCReadableResource
/*     */ {
/*     */   private List<MCMessageListener> _messagelistener;
/*     */   public static final String FILE_BASE = "MCMessage";
/*  52 */   protected static final MCGroupResource.Type TYPE = MCGroupResource.Type.CONST;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String KEY_MESSAGE = "msg";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String KEY_LEVEL = "lv";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCMessageConst() {
/*  77 */     super(TYPE, "MCMessage");
/*     */   }
/*     */   
/*     */   private List<MCMessageListener> createMessageListener() {
/*  81 */     List<MCMessageListener> listeners = new ArrayList<>();
/*     */     
/*  83 */     String entrykey = "message";
/*     */     
/*  85 */     if (!MCConst.plugin.isLoadedBaseBundle()) {
/*  86 */       return null;
/*     */     }
/*     */     
/*  89 */     String[] keys = MCConst.plugin.getOrderKeys(entrykey); byte b; int i; String[] arrayOfString1;
/*  90 */     for (i = (arrayOfString1 = keys).length, b = 0; b < i; ) { String key = arrayOfString1[b];
/*  91 */       if (!MCConst.plugin.containsKey(key)) {
/*     */         
/*  93 */         MCLog.write((Throwable)new MCException(Core_Msg_FW_A.FCBHC0101, new Object[] { key, null }));
/*     */       } else {
/*     */         
/*  96 */         String name = MCConst.plugin.getName(key);
/*  97 */         if (name != null)
/*     */           
/*     */           try {
/*     */ 
/*     */             
/* 102 */             MCMessageListener listener = (MCMessageListener)MCFactory.create(
/* 103 */                 MCMessageListener.class, name);
/* 104 */             listeners.add(listener);
/* 105 */           } catch (Exception exception) {
/*     */             
/* 107 */             MCLog.write((Throwable)new MCException(Core_Msg_FW_A.FCBHC0101, new Object[] { key, null }));
/*     */           }  
/*     */       }  b++; }
/*     */     
/* 111 */     return listeners;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getMessage(String id) {
/* 127 */     String key = MCResource.createKey(new String[] { id, "msg" });
/* 128 */     String mes = super.getSourceString(key);
/*     */     
/* 130 */     if (!MCConst.message.isLoadedBaseBundle()) {
/* 131 */       return mes;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 136 */     if (this._messagelistener == null) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 141 */       this._messagelistener = new ArrayList<>();
/*     */       
/* 143 */       this._messagelistener = createMessageListener();
/*     */     } 
/* 145 */     if (this._messagelistener != null) {
/*     */       try {
/* 147 */         for (MCMessageListener l : this._messagelistener) {
/* 148 */           mes = l.doNGEvent(id, mes, this._locale);
/*     */         }
/* 150 */       } catch (Throwable e) {
/* 151 */         String lStr = (this._locale == null) ? null : this._locale.toString();
/* 152 */         MCLog.write((Throwable)new MCException(Core_Msg_FW_A.FCBHC0111, new Object[] { key, mes, lStr, e.getMessage() }));
/*     */       } 
/*     */     }
/*     */     
/* 156 */     return mes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCMessageLevel getLevel(String id) {
/* 170 */     MCMessageLevel level = null;
/*     */     
/* 172 */     String key = MCResource.createKey(new String[] { id, "lv" });
/* 173 */     String lvstr = getString(key);
/* 174 */     if (lvstr != null && lvstr.length() == 1) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 180 */       char lvch = lvstr.charAt(0);
/*     */       try {
/* 182 */         level = MCMessageLevel.valueOf(lvch);
/*     */       }
/* 184 */       catch (Exception exception) {}
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 190 */     return level;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCMessage getMCMessage(String id) {
/* 203 */     String msg = getMessage(id);
/* 204 */     return (msg != null) ? new MCMessage(id, new Object[0]) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean containsID(String id) {
/* 218 */     String key = MCResource.createKey(new String[] { id, "msg" });
/* 219 */     return containsKey(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getNullString() {
/* 232 */     String nullstr = getString("bind.null");
/* 233 */     return (nullstr != null) ? nullstr : "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getWrappedErrorLevelArray() {
/* 245 */     return getStringArray("wrap.err.lv", new String[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSourceString(String key) {
/* 265 */     return super.getSourceString(key);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\MCMessageConst.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */