/*     */ package mcframe.commonCore.resource;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.regex.Pattern;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.resource.ctrl.MCGeneralWritableResource;
/*     */ import mcframe.commonCore.resource.ctrl.MCGroupResource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MCCoreConfig
/*     */   extends MCGeneralWritableResource
/*     */   implements MCCoreConfigResource
/*     */ {
/*     */   public static final String FILE_BASE = "MCConfig";
/*  55 */   protected static final MCGroupResource.Type TYPE = MCGroupResource.Type.CONFIG;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCCoreConfig() {
/*  64 */     super(TYPE, "MCConfig");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void loadVMOS() {
/*  71 */     super.loadVMOS();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCList<MCRow> getUserLocaleList(String cdcol, String namecol) {
/* 137 */     String[] keys = getUserLocaleKeyArray();
/* 138 */     return keys2LocaleList(cdcol, namecol, keys);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String[] getUserLocaleArray() {
/* 167 */     String[] keys = getUserLocaleKeyArray();
/* 168 */     return key2LocaleString(keys);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] getUserLocaleKeyArray() {
/* 181 */     Set<String> keyset = new LinkedHashSet<>();
/* 182 */     String[] cds = MCConfig.common.getStringArray("locale.list");
/* 183 */     if (cds != null) {
/* 184 */       byte b; int i; String[] arrayOfString; for (i = (arrayOfString = cds).length, b = 0; b < i; ) { String cd = arrayOfString[b];
/* 185 */         String key = MCConfig.createKey(new String[] { "locale.entry", cd });
/* 186 */         if (MCConfig.common.getString(key) != null) {
/*     */           
/* 188 */           keyset.add(key);
/*     */         }
/*     */         else {
/*     */           
/* 192 */           MCLog.write(Core_Msg_FW_A.FCBHC0086, new Object[] { key2LocaleString(key) });
/*     */         }  b++; }
/*     */     
/*     */     } 
/* 196 */     return keyset.<String>toArray(new String[keyset.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCList<MCRow> getEntryLocaleList(String cdcol, String namecol) {
/* 261 */     String[] keys = getEntryLocaleKeyArray();
/* 262 */     return keys2LocaleList(cdcol, namecol, keys);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String[] getEntryLocaleArray() {
/* 290 */     String[] keys = getEntryLocaleKeyArray();
/* 291 */     return key2LocaleString(keys);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] getEntryLocaleKeyArray() {
/* 302 */     String[] keys = MCConfig.common.findKeys("locale.entry.*");
/* 303 */     String[] valids = new String[keys.length];
/* 304 */     int validlen = 0; byte b; int i; String[] arrayOfString1;
/* 305 */     for (i = (arrayOfString1 = keys).length, b = 0; b < i; ) { String key = arrayOfString1[b];
/* 306 */       if (MCConfig.common.getString(key) != null)
/*     */       {
/* 308 */         valids[validlen++] = key;
/*     */       }
/*     */       
/*     */       b++; }
/*     */ 
/*     */     
/* 314 */     if (keys.length != validlen) {
/* 315 */       String[] temp = new String[validlen];
/* 316 */       System.arraycopy(valids, 0, temp, 0, validlen);
/* 317 */       valids = temp;
/*     */     } 
/* 319 */     return valids;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCList<MCRow> keys2LocaleList(String cdcol, String namecol, String... keys) {
/* 335 */     cdcol = (cdcol != null) ? cdcol : "lcl_cd";
/* 336 */     namecol = (namecol != null) ? namecol : "lcl_nm";
/*     */     
/* 338 */     Set<String> cdset = new LinkedHashSet<>();
/* 339 */     MCList<MCRow> list = MCList.create(MCRow.class); byte b; int i;
/*     */     String[] arrayOfString;
/* 341 */     for (i = (arrayOfString = keys).length, b = 0; b < i; ) { String key = arrayOfString[b];
/* 342 */       String cd = key2LocaleString(key);
/* 343 */       if (cdset.add(cd)) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 348 */         String name = MCConfig.common.getString(key);
/* 349 */         if (name.equals("@")) {
/* 350 */           Locale locale = MCConfig.convLocale(cd);
/* 351 */           name = locale.getDisplayName(locale);
/*     */         } 
/* 353 */         MCRow w = MCRow.create();
/* 354 */         w.setStringNE(cdcol, cd);
/* 355 */         w.setStringNE(namecol, name);
/* 356 */         list.add(w);
/*     */       }  b++; }
/*     */     
/* 359 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] key2LocaleString(String[] keys) {
/* 373 */     Set<String> cdset = new LinkedHashSet<>(); byte b; int i; String[] arrayOfString;
/* 374 */     for (i = (arrayOfString = keys).length, b = 0; b < i; ) { String key = arrayOfString[b];
/* 375 */       String cd = key2LocaleString(key);
/* 376 */       cdset.add(cd); b++; }
/*     */     
/* 378 */     return cdset.<String>toArray(new String[cdset.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String key2LocaleString(String key) {
/* 390 */     String[] items = MCConfig.splitKey(key);
/* 391 */     return MCConfig.convLocaleString(items[items.length - 1]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, List<Pattern>> getLogGroupMap() {
/* 402 */     Map<String, List<Pattern>> group_map = new LinkedHashMap<>();
/* 403 */     String[] groups = getStringArray("log_setting_list");
/* 404 */     if (groups != null && groups.length > 0) {
/* 405 */       byte b; int i; String[] arrayOfString; for (i = (arrayOfString = groups).length, b = 0; b < i; ) { String g = arrayOfString[b];
/* 406 */         String[] targets = getStringArray(MCConfig.createKey(new String[] { g, "target" }));
/* 407 */         if (targets != null && targets.length > 0) {
/* 408 */           byte b1; int j; String[] arrayOfString1; for (j = (arrayOfString1 = targets).length, b1 = 0; b1 < j; ) { String target = arrayOfString1[b1];
/* 409 */             if (!MCStringUtil.isNull(target)) {
/* 410 */               StringBuilder sb = new StringBuilder();
/* 411 */               sb.append("^"); byte b2; int k; char[] arrayOfChar;
/* 412 */               for (k = (arrayOfChar = target.toCharArray()).length, b2 = 0; b2 < k; ) { char c = arrayOfChar[b2];
/* 413 */                 switch (c) {
/*     */                   case '.':
/* 415 */                     sb.append("[.]");
/*     */                     break;
/*     */                   case '*':
/* 418 */                     sb.append('.');
/* 419 */                     sb.append('*');
/*     */                     break;
/*     */                   default:
/* 422 */                     sb.append(c); break;
/*     */                 } 
/*     */                 b2++; }
/*     */               
/* 426 */               sb.append("$");
/*     */               
/* 428 */               if (!group_map.containsKey(g)) {
/* 429 */                 List<Pattern> l = new ArrayList<>();
/* 430 */                 group_map.put(g, l);
/*     */               } 
/* 432 */               ((List<Pattern>)group_map.get(g)).add(Pattern.compile(sb.toString()));
/*     */             }  b1++; }
/*     */         
/*     */         }  b++; }
/*     */     
/*     */     } 
/* 438 */     return group_map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUserLogGroup(String user, Map<String, List<Pattern>> map) {
/* 452 */     if (MCStringUtil.isNull(user) || map == null) {
/* 453 */       return null;
/*     */     }
/*     */     
/* 456 */     for (Map.Entry<String, List<Pattern>> e : map.entrySet()) {
/* 457 */       List<Pattern> l = e.getValue();
/* 458 */       for (Pattern p : l) {
/* 459 */         if (p.matcher(user).matches()) {
/* 460 */           return e.getKey();
/*     */         }
/*     */       } 
/*     */     } 
/* 464 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\MCCoreConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */