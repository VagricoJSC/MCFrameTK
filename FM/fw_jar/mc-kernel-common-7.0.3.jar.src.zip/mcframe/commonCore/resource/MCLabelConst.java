/*     */ package mcframe.commonCore.resource;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import mcframe.commonCore.annotation.AutoGenResource;
/*     */ import mcframe.commonCore.annotation.LocaleResource;
/*     */ import mcframe.commonCore.event.MCLabelListener;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.resource.ctrl.MCGroupResource;
/*     */ import mcframe.commonCore.resource.ctrl.MCReadableResource;
/*     */ import mcframe.commonCore.resource.ctrl.MCResource;
/*     */ import mcframe.commonCore.sys.MCFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @AutoGenResource
/*     */ @LocaleResource
/*     */ public final class MCLabelConst
/*     */   extends MCReadableResource
/*     */   implements MCPackageResource
/*     */ {
/*     */   public static final String FILE_BASE = "MCLabel";
/*  46 */   protected static final MCGroupResource.Type TYPE = MCGroupResource.Type.CONST;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String BLANK = "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<MCLabelListener> _labellistener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCLabelConst() {
/*  76 */     super(TYPE, "MCLabel");
/*     */   }
/*     */ 
/*     */   
/*     */   public final String loadPackageInit(Locale locale, String... pkgs) {
/*  81 */     return loadPackageInit(MCResource.getProjectPath(), locale, pkgs);
/*     */   }
/*     */ 
/*     */   
/*     */   public final String loadPackageInit(String[] pjpath, Locale locale, String... pkgs) {
/*  86 */     return super.loadPackageInit(pjpath, locale, pkgs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getLabel(String key) {
/* 106 */     String lab = getSourceString(key, "");
/*     */     
/* 108 */     if (!MCConst.label.isLoadedBaseBundle()) {
/* 109 */       return lab;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 114 */     if (this._labellistener == null) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 119 */       this._labellistener = new ArrayList<>();
/*     */       
/* 121 */       this._labellistener = createLabelListener();
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 126 */     if (this._labellistener != null) {
/*     */       try {
/* 128 */         for (MCLabelListener l : this._labellistener) {
/* 129 */           lab = l.doNGEvent(key, lab, this._locale);
/*     */         }
/*     */       }
/* 132 */       catch (Throwable e) {
/* 133 */         String lStr = (this._locale == null) ? null : this._locale.toString();
/* 134 */         MCLog.write((Throwable)new MCException(Core_Msg_FW_A.FCBHC0110, new Object[] { key, lab, lStr, e.getMessage() }));
/*     */       } 
/*     */     }
/*     */     
/* 138 */     return lab;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<MCLabelListener> createLabelListener() {
/* 149 */     List<MCLabelListener> listeners = new ArrayList<>();
/*     */     
/* 151 */     String entrykey = "label";
/*     */     
/* 153 */     if (!MCConst.plugin.isLoadedBaseBundle()) {
/* 154 */       return null;
/*     */     }
/*     */     
/* 157 */     String[] keys = MCConst.plugin.getOrderKeys(entrykey); byte b; int i; String[] arrayOfString1;
/* 158 */     for (i = (arrayOfString1 = keys).length, b = 0; b < i; ) { String key = arrayOfString1[b];
/* 159 */       if (!MCConst.plugin.containsKey(key)) {
/*     */         
/* 161 */         MCLog.write((Throwable)new MCException(Core_Msg_FW_A.FCBHC0100, new Object[] { key, null }));
/*     */       } else {
/*     */         
/* 164 */         String name = MCConst.plugin.getName(key);
/* 165 */         if (name != null)
/*     */           
/*     */           try {
/*     */ 
/*     */             
/* 170 */             MCLabelListener listener = (MCLabelListener)MCFactory.create(MCLabelListener.class, name);
/* 171 */             listeners.add(listener);
/*     */           }
/* 173 */           catch (Exception ex) {
/*     */             
/* 175 */             MCLog.write((Throwable)new MCException(ex, Core_Msg_FW_A.FCBHC0100, new Object[] { key, name }));
/*     */           }  
/*     */       }  b++; }
/*     */     
/* 179 */     return listeners;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSourceString(String key) {
/* 200 */     return super.getSourceString(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getLogicLabel(String mod, String lgc, String ope, String blk, String colName) {
/* 218 */     if (MCStringUtil.isNull(mod) || MCStringUtil.isNull(lgc) || 
/* 219 */       MCStringUtil.isNull(ope) || MCStringUtil.isNull(blk) || 
/* 220 */       MCStringUtil.isNull(colName)) {
/* 221 */       return null;
/*     */     }
/* 223 */     String key = MCConst.createKey(new String[] { mod, lgc, ope, blk, colName, "label" });
/* 224 */     return getLabel(key);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\MCLabelConst.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */