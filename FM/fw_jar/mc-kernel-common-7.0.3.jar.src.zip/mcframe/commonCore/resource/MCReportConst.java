/*     */ package mcframe.commonCore.resource;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import mcframe.commonCore.annotation.AutoGenResource;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.resource.ctrl.MCGroupResource;
/*     */ import mcframe.commonCore.resource.ctrl.MCReadableResource;
/*     */ import mcframe.commonCore.resource.ctrl.MCResource;
/*     */ import mcframe.commonCore.sys.MCFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @AutoGenResource
/*     */ public final class MCReportConst
/*     */   extends MCReadableResource
/*     */ {
/*     */   public static final String FILE_BASE = "MCReport";
/*  38 */   protected static final MCGroupResource.Type TYPE = MCGroupResource.Type.CONST;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String KEY_CLASS = "class";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String KEY_CLASSID = "classid";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String KEY_PARENT = "parent";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCReportConst() {
/*  68 */     super(TYPE, "MCReport");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getClassID(String moduleid, String reportkey) {
/*  84 */     String key = MCConst.createKey(new String[] { moduleid, reportkey, "classid" });
/*  85 */     return super.getString(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getClassName(String moduleid, String reportkey) {
/*  98 */     String key = MCConst.createKey(new String[] { moduleid, reportkey, "class" });
/*  99 */     return super.getString(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final <T> Class<? extends T> getClass(String moduleid, String reportkey, Class<T> parent) {
/* 118 */     Class<? extends T> clazz = null;
/*     */     
/* 120 */     String classname = getClassName(moduleid, reportkey);
/* 121 */     if (classname == null) {
/* 122 */       return null;
/*     */     }
/* 124 */     clazz = MCFactory.getClass(parent, classname);
/*     */     
/* 126 */     return clazz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final <T> T getInstance(String moduleid, String reportkey, Class<T> parent) {
/* 147 */     Class<? extends T> clazz = getClass(moduleid, reportkey, parent);
/* 148 */     return (T)MCFactory.create(clazz, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String[] getIDArray() {
/* 165 */     return findPattern("*.*");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCList<MCRow> getIDList(String col) {
/* 185 */     String[] ids = getIDArray();
/* 186 */     int size = ids.length;
/* 187 */     MCList<MCRow> list = MCList.create(MCRow.class, size);
/* 188 */     col = (col != null) ? col : "id";
/* 189 */     list.addStringColumn(col);
/* 190 */     for (int i = 0; i < size; i++) {
/* 191 */       MCRow row = list.createRow();
/* 192 */       row.setString(col, ids[i]);
/* 193 */       list.add(row);
/*     */     } 
/* 195 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCList<MCRow> getIDList(String modulecol, String reportcol) {
/* 216 */     String[] ids = getIDArray();
/* 217 */     int size = ids.length;
/* 218 */     MCList<MCRow> list = MCList.create(MCRow.class, size);
/* 219 */     modulecol = (modulecol != null) ? modulecol : "mid";
/* 220 */     reportcol = (reportcol != null) ? reportcol : "sid";
/* 221 */     list.addStringColumn(modulecol);
/* 222 */     list.addStringColumn(reportcol);
/* 223 */     for (int i = 0; i < size; i++) {
/* 224 */       MCRow row = list.createRow();
/* 225 */       int split = ids[i].indexOf('.');
/* 226 */       row.setString(modulecol, ids[i].substring(0, split));
/* 227 */       row.setString(reportcol, ids[i].substring(split + 1));
/* 228 */       list.add(row);
/*     */     } 
/* 230 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getParentID(String moduleid, String reportkey) {
/* 243 */     String key = MCConst.createKey(new String[] { moduleid, reportkey, "parent" });
/* 244 */     return getString(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String[] getParentIDChainArray(String moduleid, String reportkey) {
/* 269 */     List<String> chain = new ArrayList<>();
/*     */     
/* 271 */     String[] ids = {
/* 272 */         moduleid, reportkey
/*     */       };
/* 274 */     String parent = null;
/* 275 */     while ((parent = getParentID(ids[0], ids[1])) != null) {
/* 276 */       chain.add(parent);
/* 277 */       ids = MCResource.splitKey(parent, 2);
/* 278 */       if (ids.length < 2) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 284 */     return chain.<String>toArray(new String[chain.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   public final String getString(String key) {
/* 289 */     return super.getString(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getInteger(String key) {
/* 294 */     return super.getInteger(key);
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getInteger(String key, int def) {
/* 299 */     return super.getInteger(key, def);
/*     */   }
/*     */ 
/*     */   
/*     */   public final boolean getBoolean(String key, boolean def) {
/* 304 */     return super.getBoolean(key, def);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\MCReportConst.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */