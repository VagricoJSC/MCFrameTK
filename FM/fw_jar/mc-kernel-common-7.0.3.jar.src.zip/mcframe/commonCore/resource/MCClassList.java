/*     */ package mcframe.commonCore.resource;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.sys.MCFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MCClassList<E>
/*     */ {
/*     */   public static final Map<String, MCClassList<?>[]> createEntryMap(String name, String layer) {
/*  59 */     Map<String, MCClassList<?>[]> entrymap = 
/*  60 */       (Map)new HashMap<>();
/*     */ 
/*     */ 
/*     */     
/*  64 */     String[] pjs = MCConst.getProjectPath();
/*     */ 
/*     */     
/*  67 */     int pjslen = (pjs != null) ? pjs.length : 0;
/*     */ 
/*     */     
/*  70 */     String[] mds = MCConst.getModulePath();
/*     */ 
/*     */     
/*  73 */     int mdslen = (mds != null) ? mds.length : 0;
/*     */     
/*  75 */     StringBuilder buf = new StringBuilder();
/*  76 */     buf.append("mcframe.");
/*  77 */     buf.append(layer);
/*  78 */     int layerlen = buf.length();
/*  79 */     for (int m = 0; m < mdslen; m++) {
/*  80 */       buf.setLength(layerlen);
/*  81 */       String md = mds[m];
/*  82 */       buf.append(md);
/*  83 */       buf.append('.');
/*  84 */       buf.append(name);
/*  85 */       int namelen = buf.length();
/*  86 */       MCClassList[] lista = new MCClassList[pjslen];
/*  87 */       entrymap.put(md, lista);
/*  88 */       for (int p = 0; p < pjslen; p++) {
/*  89 */         buf.setLength(namelen);
/*  90 */         String pj = pjs[p];
/*  91 */         if (pj.length() > 0) {
/*  92 */           buf.append('_');
/*  93 */           buf.append(pj);
/*     */         } 
/*  95 */         String listname = buf.toString();
/*     */         try {
/*  97 */           MCClassList<?> list = (MCClassList)MCFactory.create(
/*  98 */               MCClassList.class, listname);
/*  99 */           lista[p] = list;
/* 100 */         } catch (MCException mCException) {}
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 106 */     return entrymap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Class<?> getClass(Map<String, MCClassList<?>[]> map, String moduleid, String targetid) {
/* 121 */     MCClassList[] lista = (MCClassList[])map.get(moduleid);
/* 122 */     if (lista == null) {
/* 123 */       return null;
/*     */     }
/*     */     
/* 126 */     Class<?> c = null;
/* 127 */     int len = lista.length;
/* 128 */     for (int i = 0; i < len && c == null; i++) {
/* 129 */       MCClassList<?> list = lista[i];
/* 130 */       if (list != null) {
/* 131 */         c = list.getClass(targetid);
/*     */       }
/*     */     } 
/* 134 */     return c;
/*     */   }
/*     */   
/*     */   public abstract Class<? extends E> getClass(String paramString);
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\MCClassList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */