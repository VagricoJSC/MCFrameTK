package mcframe.commonCore.resource;

import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.notice.MCMessage;

public interface MCCoreConfigResource {
  String getSourceString(String paramString);
  
  String getString(String paramString);
  
  String getString(String paramString1, String paramString2);
  
  String getString(String paramString1, String paramString2, MCMessage paramMCMessage);
  
  char getCharacter(String paramString);
  
  char getCharacter(String paramString, char paramChar);
  
  char getCharacter(String paramString, char paramChar, MCMessage paramMCMessage);
  
  MCNumber getNumber(String paramString);
  
  MCNumber getNumber(String paramString, MCNumber paramMCNumber);
  
  MCNumber getNumber(String paramString, MCNumber paramMCNumber, MCMessage paramMCMessage);
  
  int getInteger(String paramString);
  
  int getInteger(String paramString, int paramInt);
  
  int getInteger(String paramString, int paramInt, MCMessage paramMCMessage);
  
  boolean getBoolean(String paramString);
  
  boolean getBoolean(String paramString, boolean paramBoolean);
  
  boolean getBoolean(String paramString, boolean paramBoolean, MCMessage paramMCMessage);
  
  String[] getStringArray(String paramString);
  
  String[] getStringArray(String paramString, String[] paramArrayOfString);
  
  String[] getStringArray(String paramString, String[] paramArrayOfString, MCMessage paramMCMessage);
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\MCCoreConfigResource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */