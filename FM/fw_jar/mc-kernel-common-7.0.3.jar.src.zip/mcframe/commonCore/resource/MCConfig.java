/*     */ package mcframe.commonCore.resource;
/*     */ 
/*     */ import mcframe.commonCore.resource.ctrl.MCGroupResource;
/*     */ import mcframe.commonCore.resource.ctrl.MCResource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCConfig
/*     */   extends MCResource
/*     */ {
/*  74 */   public static final MCCoreConfig common = new MCCoreConfig();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   static final MCGroupResource[] group = new MCGroupResource[] {
/*  82 */       (MCGroupResource)common
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String BASE_DIR = "conf";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void loaddump() {
/* 103 */     loaddumpPathResource();
/* 104 */     loaddump((MCDumpResource[])group);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean _initialized = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean isInitialized() {
/* 122 */     return _initialized;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static String init() {
/* 149 */     String trace = null;
/*     */ 
/*     */     
/* 152 */     StringBuilder sb = createTraceBuffer();
/*     */ 
/*     */     
/* 155 */     resetBundle(group);
/*     */ 
/*     */ 
/*     */     
/* 159 */     common.loadVMOS();
/*     */ 
/*     */     
/* 162 */     sb.append(loadPath());
/*     */ 
/*     */     
/* 165 */     sb.append(loadInit(null, group));
/*     */     
/* 167 */     trace = sb.toString();
/* 168 */     _initialized = true;
/*     */ 
/*     */     
/* 171 */     return (trace != null) ? trace : "";
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\resource\MCConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */