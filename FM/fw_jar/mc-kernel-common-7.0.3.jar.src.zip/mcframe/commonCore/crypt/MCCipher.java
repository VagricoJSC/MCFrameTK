/*     */ package mcframe.commonCore.crypt;
/*     */ 
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.spec.SecretKeySpec;
/*     */ import mcframe.commonCore.util.MCDataConvUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCCipher
/*     */   extends MCCrypt
/*     */ {
/*  27 */   private final String algorithm = "Blowfish";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  34 */   private final String encode = "UTF-8";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String encrypt(String key, String dec) throws Exception {
/*  50 */     byte[] decbyte = dec.getBytes("UTF-8");
/*  51 */     byte[] encbyte = doFinal(1, key, decbyte);
/*  52 */     return MCDataConvUtil.encodeBase64(encbyte, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String decrypt(String key, String enc) throws Exception {
/*  73 */     byte[] encbyte = MCDataConvUtil.decodeBase64(enc, false);
/*  74 */     byte[] decbyte = doFinal(2, key, encbyte);
/*  75 */     return new String(decbyte, "UTF-8");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] doFinal(int mode, String key, byte[] data) throws Exception {
/*  97 */     SecretKeySpec sksSpec = new SecretKeySpec(key.getBytes("UTF-8"), 
/*  98 */         "Blowfish");
/*  99 */     Cipher cipher = Cipher.getInstance("Blowfish");
/* 100 */     cipher.init(mode, sksSpec);
/* 101 */     return cipher.doFinal(data);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\crypt\MCCipher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */