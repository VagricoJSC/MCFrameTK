/*    */ package mcframe.commonCore.crypt;
/*    */ 
/*    */ import mcframe.commonCore.resource.MCConst;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class MCCrypt
/*    */ {
/*    */   public static MCCrypt createCrypt() throws Exception {
/* 68 */     String cn = MCConst.plugin.getString(
/* 69 */         MCConst.createKey(new String[] { "crypt", "class"
/* 70 */           }, ), "mcframe.commonCore.crypt.MCCipher");
/* 71 */     Class<?> c = Class.forName(cn);
/* 72 */     Class<? extends MCCrypt> cc = c.asSubclass(MCCrypt.class);
/* 73 */     return cc.newInstance();
/*    */   }
/*    */   
/*    */   public abstract String encrypt(String paramString1, String paramString2) throws Exception;
/*    */   
/*    */   public abstract String decrypt(String paramString1, String paramString2) throws Exception;
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\crypt\MCCrypt.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */