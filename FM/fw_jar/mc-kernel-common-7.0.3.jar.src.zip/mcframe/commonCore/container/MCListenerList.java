/*     */ package mcframe.commonCore.container;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.EventListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MCListenerList<E extends EventListener>
/*     */   implements Serializable
/*     */ {
/*     */   private final Class<E> _type;
/*     */   private E[] _listenerArray;
/*     */   
/*     */   MCListenerList(Class<E> listenerType) {
/*  43 */     this(listenerType, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCListenerList(Class<E> listenerType, E listener) {
/*  55 */     this._type = listenerType;
/*  56 */     if (listener != null) {
/*  57 */       this._listenerArray = createArray(1);
/*  58 */       this._listenerArray[0] = listener;
/*     */     } else {
/*  60 */       this._listenerArray = createArray(0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private E[] createArray(int size) {
/*  74 */     return (E[])Array.newInstance(this._type, size);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/*  87 */     return this._listenerArray.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public E[] getListeners() {
/* 100 */     return this._listenerArray;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addListener(EventListener... listener) {
/* 134 */     if (listener == null) {
/*     */       return;
/*     */     }
/* 137 */     int len = listener.length;
/* 138 */     if (len == 0) {
/*     */       return;
/*     */     }
/* 141 */     int pos = this._listenerArray.length;
/* 142 */     EventListener[] tmp = (EventListener[])createArray(pos + len);
/* 143 */     System.arraycopy(this._listenerArray, 0, tmp, 0, pos);
/* 144 */     System.arraycopy(listener, 0, tmp, pos, len);
/* 145 */     this._listenerArray = (E[])tmp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeListener(E listener) {
/* 162 */     if (listener == null) {
/*     */       return;
/*     */     }
/* 165 */     int index = this._listenerArray.length - 1;
/*     */     
/* 167 */     for (; index >= 0 && this._listenerArray[index] != listener; index--);
/* 168 */     if (index >= 0) {
/* 169 */       int tmplen = this._listenerArray.length - 1;
/* 170 */       EventListener[] tmp = (EventListener[])createArray(tmplen);
/* 171 */       System.arraycopy(this._listenerArray, 0, tmp, 0, index);
/* 172 */       if (index < tmplen) {
/* 173 */         System.arraycopy(this._listenerArray, index + 1, tmp, index, 
/* 174 */             tmplen - index);
/*     */       }
/* 176 */       this._listenerArray = (E[])tmp;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public E[] removeAllListener() {
/* 191 */     E[] arrayOfE = this._listenerArray;
/* 192 */     this._listenerArray = createArray(0);
/* 193 */     return arrayOfE;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\MCListenerList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */