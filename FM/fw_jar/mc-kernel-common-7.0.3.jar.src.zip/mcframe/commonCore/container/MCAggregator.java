/*     */ package mcframe.commonCore.container;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCAggregator
/*     */ {
/*     */   private final String[] _grpkeys;
/*     */   private final MCGroupByPolicy _policy;
/*     */   
/*     */   private static class GroupKey
/*     */   {
/*     */     private final Comparable<?>[] _vals;
/*     */     private final int _hash;
/*     */     
/*     */     GroupKey(Comparable[] vals) {
/*  57 */       this._vals = (Comparable<?>[])vals;
/*  58 */       int hash = 0; byte b; int i; Comparable[] arrayOfComparable;
/*  59 */       for (i = (arrayOfComparable = vals).length, b = 0; b < i; ) { Comparable<?> val = arrayOfComparable[b];
/*  60 */         hash += (val != null) ? val.hashCode() : 0; b++; }
/*     */       
/*  62 */       this._hash = hash;
/*     */     }
/*     */     
/*     */     public int hashCode() {
/*  66 */       return this._hash;
/*     */     }
/*     */     
/*     */     public boolean equals(Object obj) {
/*  70 */       if (this == obj) {
/*  71 */         return true;
/*     */       }
/*  73 */       if (obj instanceof GroupKey) {
/*  74 */         GroupKey another = (GroupKey)obj;
/*  75 */         return Arrays.equals((Object[])this._vals, (Object[])another._vals);
/*     */       } 
/*  77 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  99 */   private final Map<GroupKey, MCAggregate<MCRow>[]> _agMap = (Map)new LinkedHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCAggregator(MCGroupByPolicy policy) {
/* 115 */     this._policy = policy.clone();
/* 116 */     this._grpkeys = this._policy.groupArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sumUp(MCRow row) {
/* 130 */     Comparable[] vals = new Comparable[this._grpkeys.length];
/* 131 */     for (int i = 0; i < vals.length; i++) {
/* 132 */       vals[i] = row.getValueNE(this._grpkeys[i]);
/*     */     }
/* 134 */     GroupKey grpkey = new GroupKey((Comparable<?>[])vals);
/* 135 */     MCAggregate[] ags = (MCAggregate[])this._agMap.get(grpkey);
/* 136 */     if (ags == null) {
/* 137 */       ags = this._policy.aggregateArray();
/* 138 */       this._agMap.put(grpkey, ags);
/*     */     }  byte b; int j; MCAggregate[] arrayOfMCAggregate1;
/* 140 */     for (j = (arrayOfMCAggregate1 = ags).length, b = 0; b < j; ) { MCAggregate<MCRow> ag = arrayOfMCAggregate1[b];
/* 141 */       ag.add(row);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setResult(MCList<? extends MCRow> list) {
/* 167 */     list.clear();
/* 168 */     this._agMap.entrySet().forEach(entry -> {
/*     */           MCRow row = paramMCList.add();
/*     */           Comparable[] vals = (Comparable[])(entry.getKey())._vals;
/*     */           for (int i = 0; i < this._grpkeys.length; i++)
/*     */             row.setValueNE(this._grpkeys[i], vals[i]); 
/*     */           MCAggregate[] ags = (MCAggregate[])entry.getValue();
/*     */           MCAggregate.setToRow(row, (MCAggregate<MCRow>[])ags);
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\MCAggregator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */