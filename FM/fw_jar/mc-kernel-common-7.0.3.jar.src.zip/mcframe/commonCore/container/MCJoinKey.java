/*    */ package mcframe.commonCore.container;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*    */ import mcframe.commonCore.notice.MCException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCJoinKey<L extends MCList<? extends MCRow>>
/*    */   implements Serializable
/*    */ {
/* 31 */   private String _deadClass = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private boolean _alive = true;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   MCJoinKey(L ds) {
/* 51 */     this._deadClass = ds.msgBindClassName();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isAlive() {
/* 65 */     return this._alive;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void dead() {
/* 75 */     this._alive = false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   void checkAlive() {
/* 86 */     if (!isAlive())
/*    */     {
/* 88 */       throw new MCException(Core_Msg_FW_A.FCBBC0057, new Object[] { this._deadClass });
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\MCJoinKey.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */