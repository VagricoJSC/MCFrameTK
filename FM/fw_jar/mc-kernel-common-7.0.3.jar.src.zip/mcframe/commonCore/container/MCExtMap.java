/*    */ package mcframe.commonCore.container;
/*    */ 
/*    */ import java.util.AbstractMap;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCExtMap
/*    */   extends HashMap<String, MCExtList>
/*    */ {
/*    */   public MCExtMap() {}
/*    */   
/*    */   public MCExtMap(MCExtMap parent, Entry... entries) {
/* 36 */     if (parent != null)
/* 37 */       putAll(parent);  byte b; int i;
/*    */     Entry[] arrayOfEntry;
/* 39 */     for (i = (arrayOfEntry = entries).length, b = 0; b < i; ) { Entry ent = arrayOfEntry[b];
/* 40 */       MCExtList existValue = get(ent.getKey());
/* 41 */       if (existValue == null) {
/* 42 */         put(ent.getKey(), ent.getValue());
/*    */       } else {
/* 44 */         for (String mName : ent.getValue().getKeyList()) {
/* 45 */           existValue.put(mName, ent.getValue().get(mName));
/*    */         }
/*    */       } 
/*    */       b++; }
/*    */   
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<String> getKeyList(String aGroup) {
/* 60 */     if (aGroup == null) return null; 
/* 61 */     MCExtList aList = get(aGroup);
/* 62 */     if (aList == null) return null; 
/* 63 */     return aList.getKeyList();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static class Entry
/*    */     extends AbstractMap.SimpleEntry<String, MCExtList>
/*    */   {
/*    */     public Entry(String aKey, MCExtList aValue) {
/* 80 */       super(aKey, aValue);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\MCExtMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */