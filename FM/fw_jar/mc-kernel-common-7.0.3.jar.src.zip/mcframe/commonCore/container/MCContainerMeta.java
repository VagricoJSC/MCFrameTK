/*     */ package mcframe.commonCore.container;
/*     */ 
/*     */ import mcframe.commonCore.lang.MCDBType;
/*     */ import mcframe.commonCore.lang.MCDataType;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCContainerMeta
/*     */   extends MCMeta
/*     */ {
/*     */   private final Class<? extends MCRow> _cont;
/*     */   
/*     */   static final MCContainerMeta stringMeta(String name, int length) {
/*  33 */     return new MCContainerMeta(
/*  34 */         name, 
/*  35 */         MCDataType.STRING, 
/*  36 */         length, 
/*  37 */         0, 
/*  38 */         false, 
/*  39 */         MCDBType.STRING);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final MCContainerMeta stringMeta(String name) {
/*  53 */     return stringMeta(name, -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final MCContainerMeta numberMeta(String name, int length, int scale, boolean minus) {
/*  71 */     return new MCContainerMeta(
/*  72 */         name, 
/*  73 */         MCDataType.NUMBER, 
/*  74 */         length, 
/*  75 */         scale, 
/*  76 */         minus, 
/*  77 */         MCDBType.NUMBER);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final MCContainerMeta numberMeta(String name) {
/*  91 */     return numberMeta(name, -1, -1, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final MCContainerMeta dateMeta(String name) {
/* 105 */     return new MCContainerMeta(
/* 106 */         name, 
/* 107 */         MCDataType.DATE, 
/* 108 */         0, 
/* 109 */         0, 
/* 110 */         false, 
/* 111 */         MCDBType.DATE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final MCContainerMeta timestampMeta(String name) {
/* 125 */     return new MCContainerMeta(
/* 126 */         name, 
/* 127 */         MCDataType.TIMESTAMP, 
/* 128 */         0, 
/* 129 */         0, 
/* 130 */         false, 
/* 131 */         MCDBType.TIMESTAMP);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final MCContainerMeta booleanMeta(String name) {
/* 146 */     return new MCContainerMeta(
/* 147 */         name, 
/* 148 */         MCDataType.BOOLEAN, 
/* 149 */         1, 
/* 150 */         0, 
/* 151 */         false, 
/* 152 */         MCDBType.BOOLEAN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final MCContainerMeta binaryMeta(String name) {
/* 166 */     return new MCContainerMeta(
/* 167 */         name, 
/* 168 */         MCDataType.BINARY, 
/* 169 */         0, 
/* 170 */         0, 
/* 171 */         false, 
/* 172 */         MCDBType.BINARY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final MCContainerMeta rowMeta(String name, Class<? extends MCConstRow> container) {
/* 190 */     return new MCContainerMeta(name, (Class)container);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final MCContainerMeta cryptStringMeta(String name, int length) {
/* 205 */     return new MCContainerMeta(
/* 206 */         name, 
/* 207 */         MCDataType.STRING, 
/* 208 */         length, 
/* 209 */         0, 
/* 210 */         false, 
/* 211 */         MCDBType.STRING, 
/*     */         
/* 213 */         true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final MCContainerMeta cryptStringMeta(String name) {
/* 227 */     return cryptStringMeta(name, -1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final MCContainerMeta cloneMeta(String name, MCMeta meta) {
/* 284 */     if (meta.type() == MCDataType.ROW) {
/* 285 */       throw new MCException(Core_Msg_FW_A.FCBBC0002, new Object[] { name });
/*     */     }
/* 287 */     return new MCContainerMeta(name, meta);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final MCContainerMeta cloneMeta(String name, MCMeta meta, Class<? extends MCConstRow> container) {
/* 309 */     if (meta.type() != MCDataType.ROW) {
/* 310 */       throw new MCException(Core_Msg_FW_A.FCBBC0001, new Object[] { name, meta.type() });
/*     */     }
/* 312 */     return new MCContainerMeta(name, meta, (Class)container);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCContainerMeta(String name, MCDataType type, int length, int scale, boolean minus, MCDBType dbtype) {
/* 354 */     this(name, type, length, scale, minus, dbtype, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCContainerMeta(String name, MCDataType type, int length, int scale, boolean minus, MCDBType dbtype, boolean crypt) {
/* 388 */     this("", name, type, length, scale, minus, dbtype, crypt, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCContainerMeta(String name, Class<? extends MCRow> container) {
/* 413 */     this("", name, MCDataType.ROW, 0, 0, false, null, false, container);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCContainerMeta(String name, MCMeta meta) {
/* 440 */     this(meta.ID(), name, meta.type(), meta.length(), meta.scale(), meta.minusEnable(), meta.dbType(), meta.crypt(), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCContainerMeta(String name, MCMeta meta, Class<? extends MCRow> container) {
/* 470 */     this(meta.ID(), name, meta.type(), meta.length(), meta.scale(), meta.minusEnable(), meta.dbType(), meta.crypt(), container);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCContainerMeta(String id, String name, MCDataType type, int length, int scale, boolean minus, MCDBType dbtype, boolean crypt, Class<? extends MCRow> container) {
/* 499 */     super(id, name, type, length, scale, minus, dbtype, crypt);
/* 500 */     if (name == null || type == null)
/*     */     {
/* 502 */       throw new MCException(Core_Msg_FW_A.FCBBC0001, new Object[] { name, type });
/*     */     }
/* 504 */     if (type == MCDataType.ROW && container == null)
/*     */     {
/* 506 */       throw new MCException(Core_Msg_FW_A.FCBBC0002, new Object[] { name });
/*     */     }
/* 508 */     this._cont = container;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Class<? extends MCRow> innerRowClass() {
/* 519 */     return this._cont;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCRow castInnerRow(Comparable<?> r) {
/* 533 */     return castInnerRow((Class)this._cont, r);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final <T extends MCRow> T castInnerRow(Class<T> c, Comparable<?> r) {
/*     */     try {
/* 550 */       if (!this._cont.equals(c))
/*     */       {
/* 552 */         throw new MCException(Core_Msg_FW_A.FCBBC0023, new Object[] {
/* 553 */               this._cont.getClass().getName(), 
/* 554 */               c.getClass().getName()
/*     */             }); } 
/* 556 */       return c.cast(r);
/* 557 */     } catch (Exception ex) {
/* 558 */       if (this._cont == null)
/*     */       {
/* 560 */         throw new MCException(ex, Core_Msg_FW_A.FCBFC0020, new Object[] {
/* 561 */               r.getClass().getName(), type()
/*     */             });
/*     */       }
/* 564 */       throw new MCException(ex, Core_Msg_FW_A.FCBBC0023, new Object[] {
/* 565 */             this._cont.getClass().getName(), 
/* 566 */             r.getClass().getName()
/*     */           });
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\MCContainerMeta.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */