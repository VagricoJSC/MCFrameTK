/*    */ package mcframe.commonCore.container;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class MCConstList<E extends MCConstRow>
/*    */   extends MCList<E>
/*    */ {
/*    */   protected MCConstList(Class<E> rowc) {
/* 22 */     super(rowc);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected MCConstList(Class<E> rowc, int initCapacity) {
/* 34 */     super(rowc, initCapacity);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\MCConstList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */