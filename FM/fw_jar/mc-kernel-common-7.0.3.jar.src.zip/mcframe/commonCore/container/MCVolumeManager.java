/*      */ package mcframe.commonCore.container;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import mcframe.commonCore.lang.MCNumber;
/*      */ import mcframe.commonCore.lang.MCStringUtil;
/*      */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*      */ import mcframe.commonCore.notice.MCError;
/*      */ import mcframe.commonCore.notice.MCException;
/*      */ import mcframe.commonCore.notice.MCLog;
/*      */ import mcframe.commonCore.param.MCParam;
/*      */ import mcframe.commonCore.resource.MCConfig;
/*      */ import mcframe.commonCore.resource.MCCoreConfigResource;
/*      */ import mcframe.commonCore.resource.ctrl.MCGroupResource;
/*      */ import mcframe.commonCore.util.MCUtil;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MCVolumeManager
/*      */ {
/*      */   public static class ThreadVolumeManager
/*      */   {
/*   48 */     private long _ope = -1L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   56 */     private long _max = -1L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   64 */     private long _vol = -1L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   72 */     private double _mem = MCVolumeManager.NO_LIMIT_INT;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private ThreadVolumeManager(MCVolumeManager.VolumeConfig[] vc) {
/*   83 */       this._ope = getLongValue((vc[1]).volume, MCVolumeManager._opevol);
/*   84 */       this._max = getLongValue((vc[0]).limit, MCVolumeManager._opelimit);
/*   85 */       this._mem = getDoubleValue((vc[2]).memory, MCVolumeManager._opememory);
/*   86 */       this._vol = 0L;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private long getLongValue(MCNumber num, long def) {
/*  101 */       return (num != null) ? num.longValue() : def;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private double getDoubleValue(MCNumber num, double def) {
/*  116 */       return (num != null) ? num.doubleValue() : def;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void consume() {
/*  129 */       if (!MCVolumeManager.checkLimit(this._max, this._vol++)) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  134 */         MCException ex = new MCException(Core_Msg_FW_A.FCBGC0099, new Object[] { String.valueOf(this._max) });
/*  135 */         if (!MCUtil.classInitException((Throwable)ex)) {
/*  136 */           throw new MCError(ex);
/*      */         }
/*      */       } 
/*      */       
/*  140 */       if (!MCVolumeManager.checkMemory(this._mem)) {
/*      */ 
/*      */         
/*  143 */         MCException ex = new MCException(Core_Msg_FW_A.FCBGC0102, new Object[0]);
/*  144 */         if (!MCUtil.classInitException((Throwable)ex)) {
/*  145 */           throw new MCError(ex, String.valueOf(this._mem), new String[0]);
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private long count() {
/*  158 */       return this._vol;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private long maxcount() {
/*  169 */       return this._max;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private long operation() {
/*  180 */       return this._ope;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private double memory() {
/*  191 */       return this._mem;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  201 */   private static final ThreadLocal<ThreadVolumeManager> _threadMgr = new ThreadLocal<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static ThreadVolumeManager getThreadVolumeManager() {
/*  215 */     return _threadMgr.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public static void setThreadVolumeManager(ThreadVolumeManager mgr) {
/*  228 */     _threadMgr.set(mgr);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class VolumeConfig
/*      */   {
/*      */     final String id;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     final String pattern;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     final MCNumber volume;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     final MCNumber limit;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     final MCNumber memory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     VolumeConfig(String id, String p, MCNumber v, MCNumber l, MCNumber m) {
/*  293 */       this.id = id;
/*  294 */       this.pattern = p;
/*  295 */       this.volume = v;
/*  296 */       this.limit = l;
/*  297 */       this.memory = m;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  307 */   private static final Map<String, VolumeConfig[]> _cache = (Map)new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int _cache_limit = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int _cache_volume = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int _cache_memory = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static VolumeConfig[] _configs;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static VolumeConfig _defaultconfig;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String res_prefix = "process.max";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final long NO_LIMIT = -1L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void createVolumeConfigs() {
/*  357 */     String[] keys = null;
/*      */     
/*  359 */     String strOrder = getResourceString(getResourceKey(new String[] { "order" }, ), null);
/*      */     
/*  361 */     if (strOrder != null) {
/*  362 */       String[] strOrderArr = strOrder.split(",");
/*  363 */       Set<String> orderSet = new LinkedHashSet<>(strOrderArr.length); byte b; int j; String[] arrayOfString1;
/*  364 */       for (j = (arrayOfString1 = strOrderArr).length, b = 0; b < j; ) { String id = arrayOfString1[b];
/*  365 */         orderSet.add(getResourceKey(new String[] { "items", id.trim() })); b++; }
/*      */       
/*  367 */       keys = orderSet.<String>toArray(new String[orderSet.size()]);
/*  368 */       _order = true;
/*      */     } else {
/*      */       
/*  371 */       keys = ((MCGroupResource)_config)
/*  372 */         .findPattern(getResourceKey(new String[] { "items.*" }));
/*      */     } 
/*      */ 
/*      */     
/*  376 */     int size = keys.length;
/*  377 */     List<VolumeConfig> list = new ArrayList<>();
/*  378 */     for (int i = 0; i < size; i++) {
/*  379 */       String pkey = MCConfig.createKey(new String[] { keys[i], "ptn" });
/*  380 */       String p = getResourceString(pkey, null);
/*  381 */       if (!MCStringUtil.isNull(p)) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  386 */         String vkey = MCConfig.createKey(new String[] { keys[i], "vol" });
/*  387 */         String lkey = MCConfig.createKey(new String[] { keys[i], "limit" });
/*  388 */         String mkey = MCConfig.createKey(new String[] { keys[i], "memory" });
/*  389 */         MCNumber v = getResourceNumber(vkey, null);
/*  390 */         MCNumber l = getResourceNumber(lkey, null);
/*  391 */         MCNumber m = getResourceNumber(mkey, null);
/*  392 */         list.add(new VolumeConfig(keys[i], p, v, l, m));
/*      */       } 
/*  394 */     }  _configs = list.<VolumeConfig>toArray(new VolumeConfig[list.size()]);
/*      */     
/*  396 */     _defaultconfig = new VolumeConfig("default", null, null, null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static VolumeConfig[] selectVolumeConfig(MCParam p) {
/*  409 */     String id = MCStringUtil.join(".", new String[] { p.getModuleId(), p.getLogicId(), 
/*  410 */           p.getOperationId() });
/*  411 */     VolumeConfig[] result = _cache.get(id);
/*  412 */     if (result == null) {
/*  413 */       result = new VolumeConfig[] {
/*  414 */           _defaultconfig, _defaultconfig, _defaultconfig
/*      */         };
/*  416 */       String[] ids = {
/*  417 */           id }; byte b; int i;
/*      */       VolumeConfig[] arrayOfVolumeConfig;
/*  419 */       for (i = (arrayOfVolumeConfig = _configs).length, b = 0; b < i; ) { VolumeConfig vc = arrayOfVolumeConfig[b];
/*  420 */         String[] results = MCStringUtil.match(vc.pattern, ids, '.');
/*  421 */         if (results.length > 0) {
/*      */           
/*  423 */           if (updateSelectResult((result[0]).limit, vc.limit))
/*      */           {
/*  425 */             result[0] = vc;
/*      */           }
/*  427 */           if (updateSelectResult((result[1]).volume, vc.volume))
/*      */           {
/*  429 */             result[1] = vc;
/*      */           }
/*  431 */           if (updateSelectResult((result[2]).memory, vc.memory))
/*      */           {
/*  433 */             result[2] = vc; } 
/*      */         } 
/*      */         b++; }
/*      */       
/*  437 */       _cache.put(id, result);
/*      */     } 
/*  439 */     if (isNoLimitRowlimiter(p)) {
/*  440 */       VolumeConfig[] _result = {
/*  441 */           new VolumeConfig((result[0]).id, 
/*  442 */             (result[0]).pattern, (result[0]).volume, 
/*  443 */             MCNumber.valueOf(-1L), (result[0]).memory), 
/*  444 */           result[1], result[2]
/*      */         };
/*  446 */       return _result;
/*      */     } 
/*  448 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean isNoLimitRowlimiter(MCParam p) {
/*  460 */     if (_exceptheaderkey.length == 0)
/*  461 */       return false;  byte b; int i;
/*      */     String[] arrayOfString;
/*  463 */     for (i = (arrayOfString = _exceptheaderkey).length, b = 0; b < i; ) { String key = arrayOfString[b];
/*  464 */       if (!p.getArgs().containsKey(key))
/*  465 */         return false; 
/*      */       b++; }
/*      */     
/*  468 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean updateSelectResult(MCNumber org, MCNumber sel) {
/*  485 */     if (sel == null)
/*      */     {
/*  487 */       return false;
/*      */     }
/*  489 */     if (org == null)
/*      */     {
/*  491 */       return true;
/*      */     }
/*      */     
/*  494 */     if (_order) {
/*  495 */       return false;
/*      */     }
/*      */     
/*  498 */     long org_l = org.longValue();
/*  499 */     long sel_l = sel.longValue();
/*  500 */     if (org_l == -1L && sel_l != -1L)
/*      */     {
/*  502 */       return true;
/*      */     }
/*      */     
/*  505 */     return (sel_l < org_l);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  530 */   private static final int NO_LIMIT_INT = (new Long(-1L)).intValue();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  538 */   private static long _retry = 0L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  546 */   private static long _interval = 0L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  554 */   private static long _sysvol = -1L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  562 */   private static long _syslimit = -1L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  570 */   private static long _opevol = -1L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  578 */   private static long _opelimit = -1L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  586 */   private static double _sysmemory = NO_LIMIT_INT;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  594 */   private static String[] _exceptheaderkey = new String[0];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean _gc = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  610 */   private static double _opememory = NO_LIMIT_INT;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  618 */   private static long _volcount = -1L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  626 */   private static long _opecount = -1L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  634 */   private static MCCoreConfigResource _config = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  642 */   private static long _intervalGC = -1L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  650 */   private static long _lastGC = -1L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean _order = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean checkLimit(long limit, long val) {
/*  674 */     if (isNoLimit(limit)) {
/*  675 */       return true;
/*      */     }
/*  677 */     return (val <= limit);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean checkMemory(double memory) {
/*  690 */     if (isNoLimit(memory)) {
/*  691 */       return true;
/*      */     }
/*  693 */     Runtime rt = Runtime.getRuntime();
/*  694 */     double used = (rt.totalMemory() - rt.freeMemory()) + 0.0D;
/*  695 */     return (used / rt.maxMemory() * 100.0D < memory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean isNoLimit(double val) {
/*  710 */     return (val <= -1.0D);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static MCNumber getResourceNumber(String key, MCNumber def) {
/*  725 */     MCNumber num = _config.getNumber(key);
/*  726 */     return (num != null) ? num : def;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static long getResourceLong(String key, long def) {
/*  741 */     MCNumber num = _config.getNumber(key);
/*  742 */     return (num != null) ? num.longValue() : def;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static double getResourceDouble(String key, double def) {
/*  757 */     MCNumber num = _config.getNumber(key);
/*  758 */     return (num != null) ? num.doubleValue() : def;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean getResourceBoolean(String key, boolean def) {
/*  773 */     return _config.getBoolean(key, def);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String getResourceString(String key, String def) {
/*  788 */     return _config.getString(key, def);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String[] getResourceStringArray(String key, String[] def) {
/*  803 */     return _config.getStringArray(key, def);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String getResourceKey(String... parts) {
/*  818 */     return "process.max." + MCConfig.createKey(parts);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void sysinit() {
/*      */     try {
/*  829 */       _retry = getResourceLong(getResourceKey(new String[] { "retry" }, ), 0L);
/*  830 */       _interval = getResourceLong(getResourceKey(new String[] { "interval" }, ), 0L);
/*  831 */       _intervalGC = getResourceLong(getResourceKey(new String[] { "gcinterval" }, ), 0L);
/*      */     }
/*  833 */     catch (MCException e) {
/*      */       
/*  835 */       MCLog.write(Core_Msg_FW_A.FCBGC0317, new Object[] { e.getMCMessage().toString() });
/*      */     } 
/*      */     
/*  838 */     MCLog.write(Core_Msg_FW_A.FCBGC0311, new Object[] { String.valueOf(_retry), String.valueOf(_interval) });
/*      */ 
/*      */     
/*  841 */     _sysvol = getResourceLong(getResourceKey(new String[] { "sysvol" }, ), -1L);
/*  842 */     _syslimit = getResourceLong(getResourceKey(new String[] { "syslimit" }, ), -1L);
/*  843 */     _sysmemory = getResourceDouble(getResourceKey(new String[] { "sysmemory" }, ), NO_LIMIT_INT);
/*  844 */     _gc = getResourceBoolean(getResourceKey(new String[] { "gc" }, ), false);
/*      */     
/*  846 */     _opevol = getResourceLong(getResourceKey(new String[] { "opevol" }, ), 0L);
/*  847 */     _opelimit = getResourceLong(getResourceKey(new String[] { "opelimit" }, ), -1L);
/*  848 */     _opememory = getResourceDouble(getResourceKey(new String[] { "opememory" }, ), NO_LIMIT_INT);
/*      */ 
/*      */     
/*  851 */     _volcount = 0L;
/*  852 */     _opecount = 0L;
/*      */ 
/*      */     
/*  855 */     _exceptheaderkey = getResourceStringArray(getResourceKey(new String[] { "exceptheaderkey" }, ), new String[0]);
/*      */ 
/*      */     
/*  858 */     createVolumeConfigs();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void initialize(MCCoreConfigResource config) {
/*  876 */     synchronized (_threadMgr) {
/*  877 */       if (config != null) {
/*  878 */         _config = config;
/*      */         
/*  880 */         sysinit();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isInitialized() {
/*  893 */     return (_config != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void beginOperation(MCParam param) {
/*  909 */     long start = System.currentTimeMillis();
/*  910 */     synchronized (_threadMgr) {
/*  911 */       if (!isInitialized()) {
/*      */         return;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  917 */       VolumeConfig[] vc = selectVolumeConfig(param);
/*  918 */       ThreadVolumeManager mgr = new ThreadVolumeManager(vc, null);
/*  919 */       _threadMgr.set(mgr);
/*      */       
/*  921 */       MCLog.write(Core_Msg_FW_A.FCBGC0101, new Object[] { (vc[0]).id, String.valueOf(ThreadVolumeManager.access$1(mgr)), 
/*  922 */             (vc[1]).id, String.valueOf(ThreadVolumeManager.access$2(mgr)), 
/*  923 */             (vc[2]).id, String.valueOf(ThreadVolumeManager.access$3(mgr)) });
/*      */ 
/*      */ 
/*      */       
/*  927 */       long vol = mgr.operation();
/*  928 */       int retrycnt = 0;
/*      */       while (true) {
/*  930 */         long newcount = _opecount + vol;
/*  931 */         if (checkLimit(_sysvol, newcount) && checkMemory(_sysmemory)) {
/*  932 */           _opecount = newcount;
/*      */           break;
/*      */         } 
/*  935 */         if (retrycnt >= _retry) {
/*      */           
/*  937 */           _threadMgr.remove();
/*  938 */           throw new MCException(Core_Msg_FW_A.FCBGC0060, new Object[] { String.valueOf(passedTime(start)), 
/*  939 */                 String.valueOf(retrycnt) });
/*      */         } 
/*  941 */         retrycnt++;
/*      */ 
/*      */         
/*      */         try {
/*  945 */           Thread.sleep(_interval);
/*      */         }
/*  947 */         catch (Exception e) {
/*      */           
/*  949 */           _threadMgr.remove();
/*  950 */           MCLog.write(Core_Msg_FW_A.FCBGC0314, new Object[0]);
/*  951 */           throw new MCException(e, Core_Msg_FW_A.FCBGC0059, new Object[0]);
/*      */         } 
/*  953 */         MCLog.write(Core_Msg_FW_A.FCBGC0312, new Object[] { String.valueOf(passedTime(start)), 
/*  954 */               String.valueOf(retrycnt), String.valueOf(_retry) });
/*      */       } 
/*      */ 
/*      */       
/*  958 */       MCLog.write(Core_Msg_FW_A.FCBGC0313, new Object[] { String.valueOf(passedTime(start)), 
/*  959 */             String.valueOf(retrycnt) });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static long passedTime(long start) {
/*  976 */     long end = System.currentTimeMillis();
/*  977 */     return end - start;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long endOperation() {
/*  988 */     long count = 0L;
/*      */     
/*  990 */     ThreadVolumeManager mgr = _threadMgr.get();
/*  991 */     if (mgr != null) {
/*      */       
/*  993 */       _threadMgr.remove();
/*      */ 
/*      */       
/*  996 */       count = mgr.count();
/*  997 */       _volcount -= count;
/*      */ 
/*      */       
/* 1000 */       _opecount -= mgr.operation();
/*      */     } 
/*      */     
/* 1003 */     return count;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void consumeVolume() {
/* 1017 */     ThreadVolumeManager mgr = _threadMgr.get();
/* 1018 */     if (mgr != null) {
/*      */       
/* 1020 */       long newcount = _volcount + 1L;
/* 1021 */       if (!checkLimit(_syslimit, newcount)) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1026 */         MCException ex = new MCException(Core_Msg_FW_A.FCBGC0098, new Object[] { String.valueOf(_syslimit) });
/* 1027 */         if (!MCUtil.classInitException((Throwable)ex)) {
/* 1028 */           throw new MCError(ex);
/*      */         }
/*      */       } 
/* 1031 */       if (!checkMemory(_sysmemory)) {
/*      */ 
/*      */         
/* 1034 */         MCException ex = new MCException(Core_Msg_FW_A.FCBGC0103, new Object[0]);
/* 1035 */         if (!MCUtil.classInitException((Throwable)ex)) {
/* 1036 */           throw new MCError(ex);
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 1041 */       mgr.consume();
/*      */       
/* 1043 */       _volcount = newcount;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isVolumeManageMessage(String id) {
/* 1057 */     return !(!MCStringUtil.eq(id, Core_Msg_FW_A.FCBGC0098) && !MCStringUtil.eq(id, Core_Msg_FW_A.FCBGC0099) && 
/* 1058 */       !isMemoryLimitMessage(id));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isMemoryLimitMessage(String id) {
/* 1071 */     return !(!MCStringUtil.eq(id, Core_Msg_FW_A.FCBGC0103) && !MCStringUtil.eq(id, Core_Msg_FW_A.FCBGC0102));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean isMemoryLimitException(Throwable t) {
/* 1084 */     if (t != null) {
/* 1085 */       if (t instanceof MCError) {
/* 1086 */         MCError error = (MCError)t;
/* 1087 */         if (error.getCause() != null) {
/* 1088 */           t = error.getCause();
/*      */         }
/*      */       } 
/* 1091 */       if (t instanceof MCException) {
/* 1092 */         return isMemoryLimitMessage(((MCException)t).getID());
/*      */       }
/*      */     } 
/* 1095 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static synchronized void doGC(Throwable t) {
/* 1107 */     if (_gc && isMemoryLimitException(t)) {
/* 1108 */       long elapse = System.currentTimeMillis() - _lastGC;
/* 1109 */       if (elapse >= _intervalGC) {
/*      */         
/* 1111 */         long time = System.currentTimeMillis();
/* 1112 */         System.gc();
/* 1113 */         MCLog.write(Core_Msg_FW_A.FCBGC0108, new Object[] { Long.valueOf(System.currentTimeMillis() - time) });
/* 1114 */         _lastGC = System.currentTimeMillis();
/*      */       } else {
/*      */         
/* 1117 */         MCLog.write(Core_Msg_FW_A.FCBGC0109, new Object[] { Long.valueOf(elapse) });
/*      */       } 
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\MCVolumeManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */