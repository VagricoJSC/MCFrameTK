/*     */ package mcframe.commonCore.container;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import mcframe.commonCore.lang.MCDataType;
/*     */ import mcframe.commonCore.lang.MCDate;
/*     */ import mcframe.commonCore.lang.MCDateFormat;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.lang.MCTimestamp;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.util.MCCollectionUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MCStringValueSetter
/*     */ {
/*     */   private MCDateFormat _dateFormat;
/*     */   private MCDateFormat _timestampFormat;
/*     */   
/*     */   public MCStringValueSetter() {
/*  53 */     this._dateFormat = MCDateFormat.create("yyyyMMddHHmmss");
/*  54 */     this._timestampFormat = MCDateFormat.create("yyyyMMddHHmmssSSS");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCStringValueSetter(String dateFormat, String timestampFormat) {
/*  66 */     dateFormat = (dateFormat != null) ? dateFormat : "yyyyMMddHHmmss";
/*  67 */     timestampFormat = (timestampFormat != null) ? timestampFormat : "yyyyMMddHHmmssSSS";
/*  68 */     this._dateFormat = MCDateFormat.create(dateFormat);
/*  69 */     this._timestampFormat = MCDateFormat.create(timestampFormat);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCStringValueSetter setDateFormat(String dateFormat) {
/*  85 */     if (dateFormat != null) {
/*  86 */       this._dateFormat = MCDateFormat.create(dateFormat);
/*     */     }
/*  88 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCStringValueSetter setTimestampFormat(String timestampFormat) {
/* 104 */     if (timestampFormat != null) {
/* 105 */       this._timestampFormat = MCDateFormat.create(timestampFormat);
/*     */     }
/* 107 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRowValue(MCRow row, String name, String value) {
/* 124 */     if (row == null || MCStringUtil.isNull(name) || MCStringUtil.isNull(value) || !row.contains(name)) {
/*     */       return;
/*     */     }
/* 127 */     MCDataType type = row.getMeta(name).type();
/*     */     
/* 129 */     Comparable<?> val = createValue(type, value);
/* 130 */     if (val == null) {
/* 131 */       MCLog.write(Core_Msg_FW_A.FCBGC0268, new Object[] { name, type.name(), value });
/*     */       
/*     */       return;
/*     */     } 
/* 135 */     row.setValue(name, type, val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRowValues(MCRow row, List<String> names, Map<String, String> values) {
/* 154 */     if (row == null || MCCollectionUtil.isEmpty(names) || MCCollectionUtil.isEmpty(values)) {
/*     */       return;
/*     */     }
/* 157 */     int colIdx = 0;
/* 158 */     for (String name : names) {
/*     */       
/* 160 */       setRowValue(row, name, values.get(name));
/* 161 */       row.setParamColIndex(name, colIdx++);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setListValues(MCList<MCRow> list, List<String> names, List<Map<String, String>> values) {
/* 184 */     if (list == null || MCCollectionUtil.isEmpty(names) || MCCollectionUtil.isEmpty(values)) {
/*     */       return;
/*     */     }
/*     */     
/* 188 */     int size = values.size();
/* 189 */     for (int idx = 0; idx < size; idx++) {
/*     */       
/* 191 */       MCRow row = list.createRow();
/* 192 */       row.setParamRowIndex(idx);
/* 193 */       list.add(row);
/* 194 */       Map<String, String> valMap = values.get(idx);
/*     */       
/* 196 */       for (String n : names) {
/* 197 */         if (!row.contains(n) || MCStringUtil.isNull(valMap.get(n))) {
/*     */           continue;
/*     */         }
/*     */         
/* 201 */         Comparable<?> val = createValue(row.getMeta(n).type(), valMap.get(n));
/* 202 */         if (val != null)
/*     */         {
/* 204 */           list.setValue(idx, n, val);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRowStatus(MCRow row, String status) {
/* 221 */     MCRow.Status st = MCRow.Status.NONE;
/* 222 */     if (status != null) {
/* 223 */       st = MCRow.Status.valueOf(status);
/*     */     }
/* 225 */     row.setStatus(st);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRowRefTime(MCRow row, String refTime) {
/* 240 */     if (refTime != null) {
/* 241 */       row.setRefTime(MCTimestamp.valueOf(refTime, this._timestampFormat));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Comparable<?> createValue(MCDataType type, String value) {
/* 258 */     switch (type) {
/*     */       case STRING:
/* 260 */         return value;
/*     */       case DATE:
/* 262 */         return (Comparable<?>)MCDate.valueOf(value, this._dateFormat);
/*     */       case TIMESTAMP:
/* 264 */         return (Comparable<?>)MCTimestamp.valueOf(value, this._timestampFormat);
/*     */       case NUMBER:
/* 266 */         return (Comparable<?>)MCNumber.valueOf(value);
/*     */       case BOOLEAN:
/* 268 */         return Boolean.valueOf("true".equals(value));
/*     */     } 
/* 270 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\MCStringValueSetter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */