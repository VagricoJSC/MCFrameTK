/*     */ package mcframe.commonCore.container;
/*     */ 
/*     */ import java.math.RoundingMode;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCGroupByPolicy
/*     */   implements Cloneable
/*     */ {
/*     */   enum Type
/*     */   {
/*  42 */     AVG
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       <E extends MCRow> MCAggregate<E> createAggregate(String name, String result, MCRowMatcher<E> matcher)
/*     */       {
/*  52 */         return new MCAggregate.AVG<>(name, null, result, matcher);
/*     */       }
/*     */     },
/*     */     
/*  56 */     COUNT
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       <E extends MCRow> MCAggregate<E> createAggregate(String name, String result, MCRowMatcher<E> matcher)
/*     */       {
/*  66 */         return new MCAggregate.COUNT<>(name, null, result, matcher);
/*     */       }
/*     */     },
/*     */     
/*  70 */     MIN
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       <E extends MCRow> MCAggregate<E> createAggregate(String name, String result, MCRowMatcher<E> matcher)
/*     */       {
/*  80 */         return new MCAggregate.MIN<>(name, null, result, matcher);
/*     */       }
/*     */     },
/*     */     
/*  84 */     MAX
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       <E extends MCRow> MCAggregate<E> createAggregate(String name, String result, MCRowMatcher<E> matcher)
/*     */       {
/*  94 */         return new MCAggregate.MAX<>(name, null, result, matcher);
/*     */       }
/*     */     },
/*     */     
/*  98 */     SUM
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       <E extends MCRow> MCAggregate<E> createAggregate(String name, String result, MCRowMatcher<E> matcher)
/*     */       {
/* 108 */         return new MCAggregate.SUM<>(name, null, result, matcher);
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     abstract <E extends MCRow> MCAggregate<E> createAggregate(String param1String1, String param1String2, MCRowMatcher<E> param1MCRowMatcher);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 138 */   private final Set<String> _groupSet = new HashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 148 */   private final Map<String, MCAggregate<?>> _entryMap = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCGroupByPolicy(String... names) {
/* 159 */     if (names != null) {
/* 160 */       byte b; int i; String[] arrayOfString; for (i = (arrayOfString = names).length, b = 0; b < i; ) { String name = arrayOfString[b];
/* 161 */         if (name != null) {
/* 162 */           this._groupSet.add(name);
/*     */         }
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addKey(String... names) {
/* 191 */     if (names != null) {
/* 192 */       byte b; int i; String[] arrayOfString; for (i = (arrayOfString = names).length, b = 0; b < i; ) { String name = arrayOfString[b];
/* 193 */         if (name != null) {
/* 194 */           this._groupSet.add(name);
/*     */         }
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCGroupByPolicy clone() {
/* 230 */     MCGroupByPolicy gbp = new MCGroupByPolicy(new String[0]);
/* 231 */     gbp._groupSet.addAll(this._groupSet);
/* 232 */     gbp._entryMap.putAll(this._entryMap);
/* 233 */     return gbp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void avg(String... names) {
/* 257 */     aggregate(Type.AVG, names);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void avg(String name, RoundingMode mode) {
/* 280 */     avg(name, name, null, mode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void avg(String name, int scale, RoundingMode mode) {
/* 300 */     avg(name, name, null, scale, mode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void avg(String name, String result, MCRowMatcher<?> matcher) {
/* 326 */     aggregate(Type.AVG, name, result, matcher);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void avg(String name, String result, MCRowMatcher<?> matcher, RoundingMode mode) {
/* 352 */     MCAggregate<?> a = aggregate(Type.AVG, name, result, matcher);
/* 353 */     if (a != null) {
/* 354 */       Map<String, Object> option = new HashMap<>();
/* 355 */       option.put("mode", mode);
/* 356 */       a.setOption(option);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void avg(String name, String result, MCRowMatcher<?> matcher, int scale, RoundingMode mode) {
/* 380 */     MCAggregate<?> a = aggregate(Type.AVG, name, result, matcher);
/* 381 */     if (a != null) {
/* 382 */       Map<String, Object> option = new HashMap<>();
/* 383 */       option.put("scale", Integer.valueOf(scale));
/* 384 */       option.put("mode", mode);
/* 385 */       a.setOption(option);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void count(String name, String result) {
/* 404 */     aggregate(Type.COUNT, name, result, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void count(String result) {
/* 420 */     if (result == null) {
/*     */       return;
/*     */     }
/* 423 */     aggregate(Type.COUNT, "*", result, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void count(String name, String result, MCRowMatcher<?> matcher) {
/* 445 */     aggregate(Type.COUNT, name, result, matcher);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void count(String result, MCRowMatcher<?> matcher) {
/* 465 */     if (result == null) {
/*     */       return;
/*     */     }
/* 468 */     aggregate(Type.COUNT, "*", result, matcher);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void min(String... names) {
/* 484 */     aggregate(Type.MIN, names);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void min(String name, String result, MCRowMatcher<?> matcher) {
/* 503 */     aggregate(Type.MIN, name, result, matcher);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void max(String... names) {
/* 519 */     aggregate(Type.MAX, names);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void max(String name, String result, MCRowMatcher<?> matcher) {
/* 538 */     aggregate(Type.MAX, name, result, matcher);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void sum(String... names) {
/* 554 */     aggregate(Type.SUM, names);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void sum(String name, String result, MCRowMatcher<?> matcher) {
/* 573 */     aggregate(Type.SUM, name, result, matcher);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void aggregate(Type type, String... names) {
/* 591 */     if (names != null) {
/* 592 */       byte b; int i; String[] arrayOfString; for (i = (arrayOfString = names).length, b = 0; b < i; ) { String name = arrayOfString[b];
/* 593 */         aggregate(type, name, name, null);
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final MCAggregate<?> aggregate(Type type, String name, String result, MCRowMatcher<?> matcher) {
/* 619 */     if (type == null) {
/* 620 */       return null;
/*     */     }
/* 622 */     if (name != null) {
/* 623 */       if (this._groupSet.contains(name))
/*     */       {
/* 625 */         throw new MCException(Core_Msg_FW_A.FCBBC0047, new Object[] { name });
/*     */       }
/* 627 */       if (this._groupSet.contains(result))
/*     */       {
/* 629 */         throw new MCException(Core_Msg_FW_A.FCBBC0047, new Object[] { result });
/*     */       }
/*     */       
/* 632 */       MCAggregate<?> a = type.createAggregate(name, result, matcher);
/* 633 */       this._entryMap.put(result, a);
/* 634 */       return a;
/*     */     } 
/* 636 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String[] groupArray() {
/* 649 */     return this._groupSet.<String>toArray(new String[this._groupSet.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String[] resultArray() {
/* 660 */     String[] result = new String[this._entryMap.size()];
/* 661 */     int cnt = 0;
/* 662 */     for (MCAggregate<?> ag : this._entryMap.values()) {
/* 663 */       result[cnt++] = ag.result();
/*     */     }
/* 665 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final <E extends MCRow> MCAggregate<E>[] aggregateArray() {
/* 680 */     MCAggregate[] agArray = new MCAggregate[this._entryMap.size()];
/* 681 */     agArray = (MCAggregate[])this._entryMap.values().toArray((Object[])agArray);
/* 682 */     for (int i = 0; i < agArray.length; i++) {
/* 683 */       agArray[i] = agArray[i].createInstance();
/*     */     }
/* 685 */     return (MCAggregate<E>[])agArray;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\MCGroupByPolicy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */