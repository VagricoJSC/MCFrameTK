/*     */ package mcframe.commonCore.container;
/*     */ 
/*     */ import java.util.List;
/*     */ import mcframe.commonCore.lang.MCDataType;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MCRowSortPolicyComparator<E extends MCRow>
/*     */   extends MCRowComparator<E>
/*     */ {
/*     */   public int compare(E row1, E row2) {
/*  51 */     int comp = compareRowNull(row1, row2);
/*  52 */     if (comp == Integer.MAX_VALUE) {
/*  53 */       comp = compareRowEmpty(row1, row2);
/*  54 */       if (comp == 0 && 
/*  55 */         this._policy != null) {
/*  56 */         for (int i = 0; i < this._policy.size(); i++) {
/*  57 */           String name = this._policy.name(i);
/*     */           try {
/*  59 */             Comparable<?> d1 = row1.getValue(name);
/*  60 */             Comparable<?> d2 = row2.getValue(name);
/*  61 */             comp = compareCol(name, d1, d2, i);
/*     */           }
/*  63 */           catch (MCException ex) {
/*     */             
/*  65 */             throw new MCException(ex, Core_Msg_FW_A.FCBBC0044, new Object[] { row1.msgBindClassName(), 
/*  66 */                   row2.msgBindClassName(), name });
/*     */           } 
/*  68 */           if (comp != 0) {
/*     */             break;
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/*  75 */     return comp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  83 */   protected MCSortPolicy _policy = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  98 */   private int[][] _sortFactor = null;
/*     */   
/* 100 */   private static final int[] SORT_FACTOR_ASC = new int[] {
/* 101 */       1, 1, 1, 1
/*     */     };
/*     */   
/* 104 */   private static final int[] SORT_FACTOR_DESC = new int[] {
/* 105 */       1, 1, -1, -1
/*     */     };
/*     */   
/* 108 */   private static final int[] SORT_FACTOR_ASC_NULL_AHEAD = new int[] {
/* 109 */       -1, -1, 1, -1
/*     */     };
/*     */   
/* 112 */   private static final int[] SORT_FACTOR_DESC_NULL_AHEAD = new int[] {
/* 113 */       -1, -1, -1, -1
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCRowSortPolicyComparator(List<String> keyList) {
/* 128 */     this((keyList != null) ? keyList.<String>toArray(new String[keyList.size()]) : null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCRowSortPolicyComparator(String... keys) {
/* 144 */     super(keys);
/* 145 */     setKeys(keys);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCRowSortPolicyComparator(MCSortPolicy policy) {
/* 159 */     super(policy.nameArray());
/* 160 */     setSortPolicy(policy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setKeys(String[] keys) {
/* 171 */     if (keys != null) {
/* 172 */       MCSortPolicy policy = new MCSortPolicy(); byte b; int i; String[] arrayOfString;
/* 173 */       for (i = (arrayOfString = keys).length, b = 0; b < i; ) { String name = arrayOfString[b];
/* 174 */         policy.add(MCList.SortType.ASC, name); b++; }
/*     */       
/* 176 */       setSortPolicy(policy);
/*     */     } else {
/*     */       
/* 179 */       this._policy = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setSortPolicy(MCSortPolicy policy) {
/* 192 */     if (policy != null) {
/* 193 */       this._policy = policy.clone();
/* 194 */       this._sortFactor = new int[this._policy.size()][4];
/* 195 */       for (int i = 0; i < this._policy.size(); i++) {
/* 196 */         switch (this._policy.type(i)) {
/*     */           case null:
/* 198 */             this._sortFactor[i] = SORT_FACTOR_ASC;
/*     */             break;
/*     */           case DESC:
/* 201 */             this._sortFactor[i] = SORT_FACTOR_DESC;
/*     */             break;
/*     */           case ASC_NULL_AHEAD:
/* 204 */             this._sortFactor[i] = SORT_FACTOR_ASC_NULL_AHEAD;
/*     */             break;
/*     */           case DESC_NULL_AHEAD:
/* 207 */             this._sortFactor[i] = SORT_FACTOR_DESC_NULL_AHEAD;
/*     */             break;
/*     */         } 
/*     */       } 
/* 211 */       super.setKeys(this._policy.nameArray());
/*     */     } else {
/*     */       
/* 214 */       this._policy = null;
/* 215 */       this._sortFactor = null;
/* 216 */       super.setKeys(null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int compareRowNull(E row1, E row2) {
/* 235 */     int result = compareNull(row1, row2);
/* 236 */     if (result != Integer.MAX_VALUE && 
/* 237 */       this._policy != null) {
/* 238 */       result *= this._sortFactor[0][0];
/*     */     }
/*     */     
/* 241 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int compareRowEmpty(E row1, E row2) {
/* 260 */     boolean emp1 = row1.isEmpty();
/* 261 */     boolean emp2 = row2.isEmpty();
/* 262 */     int result = (emp1 == emp2) ? 0 : (emp1 ? 1 : -1);
/* 263 */     if (result != 0 && 
/* 264 */       this._policy != null) {
/* 265 */       result *= this._sortFactor[0][1];
/*     */     }
/*     */     
/* 268 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareCol(String name, Comparable<?> col1, Comparable<?> col2, int index) {
/* 288 */     int comp = compareColNull(name, col1, col2, index);
/* 289 */     if (comp == Integer.MAX_VALUE) {
/*     */       try {
/* 291 */         comp = col1.compareTo(col2);
/* 292 */         if (this._policy != null) {
/* 293 */           comp *= this._sortFactor[index][2];
/*     */         }
/*     */       }
/* 296 */       catch (ClassCastException classCastException) {
/*     */         
/* 298 */         String nonSupportType = "Non-Support Type";
/* 299 */         MCDataType type1 = MCDataType.analyze(col1);
/* 300 */         String tname1 = (type1 != null) ? type1.toString() : nonSupportType;
/* 301 */         MCDataType type2 = MCDataType.analyze(col2);
/* 302 */         String tname2 = (type2 != null) ? type2.toString() : nonSupportType;
/* 303 */         throw new MCException(Core_Msg_FW_A.FCBBC0045, new Object[] { name, tname1, tname2 });
/*     */       } 
/*     */     }
/* 306 */     return comp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int compareColNull(String name, Comparable<?> col1, Comparable<?> col2, int index) {
/* 328 */     int result = compareNull(col1, col2);
/* 329 */     if (result != Integer.MAX_VALUE && 
/* 330 */       this._policy != null) {
/* 331 */       result *= this._sortFactor[index][3];
/*     */     }
/*     */     
/* 334 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\MCRowSortPolicyComparator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */