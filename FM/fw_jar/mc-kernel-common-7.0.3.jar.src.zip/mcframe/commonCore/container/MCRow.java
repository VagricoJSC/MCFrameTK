/*      */ package mcframe.commonCore.container;
/*      */ 
/*      */ import java.io.Serializable;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.regex.Pattern;
/*      */ import mcframe.commonCore.lang.MCBinary;
/*      */ import mcframe.commonCore.lang.MCDataType;
/*      */ import mcframe.commonCore.lang.MCDate;
/*      */ import mcframe.commonCore.lang.MCNumber;
/*      */ import mcframe.commonCore.lang.MCStringUtil;
/*      */ import mcframe.commonCore.lang.MCTimestamp;
/*      */ import mcframe.commonCore.meta.MCMeta;
/*      */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*      */ import mcframe.commonCore.notice.MCError;
/*      */ import mcframe.commonCore.notice.MCException;
/*      */ import mcframe.commonCore.notice.MCLog;
/*      */ import mcframe.commonCore.notice.MCMessage;
/*      */ import mcframe.commonCore.notice.MCMessageLevel;
/*      */ import mcframe.commonCore.notice.MCMessageList;
/*      */ import mcframe.commonCore.resource.MCConfig;
/*      */ import mcframe.commonCore.sys.MCFactory;
/*      */ import mcframe.commonCore.util.MCUtil;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MCRow
/*      */   implements MCContainer, Comparable<MCRow>, Cloneable, Serializable
/*      */ {
/*      */   private static final String COLUMN_PATH_SEP = ".";
/*      */   
/*      */   public static final String createColumnPath(String... cols) {
/*  250 */     if (cols == null) {
/*  251 */       return null;
/*      */     }
/*  253 */     StringBuilder sb = new StringBuilder();
/*  254 */     for (int i = 0; i < cols.length; i++) {
/*  255 */       if (cols[i] != null) {
/*  256 */         if (sb.length() > 0) {
/*  257 */           sb.append(".");
/*      */         }
/*  259 */         sb.append(cols[i]);
/*      */       } 
/*      */     } 
/*  262 */     return sb.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  271 */   private static final Pattern PATH_SPLIT_PATTERN = Pattern.compile("[.]");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final Comparable<?>[] _const_datas;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String[] splitColumnPath(String path) {
/*  282 */     if (path == null) {
/*  283 */       return null;
/*      */     }
/*  285 */     return PATH_SPLIT_PATTERN.split(path);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final <T extends MCRow> void copyvalue(T dest, T src) {
/*  317 */     copy(dest, src, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final <T extends MCRow> void copyall(T dest, T src) {
/*  355 */     copy(dest, src, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final <T extends MCRow> void copy(T dest, T src, boolean attr) {
/*  389 */     if (src == null || dest == null)
/*      */     {
/*  391 */       throw new MCException(Core_Msg_FW_A.FCBBC0009, new Object[0]);
/*      */     }
/*  393 */     if (src.getClass() != dest.getClass())
/*      */     {
/*  395 */       throw new MCException(Core_Msg_FW_A.FCBBC0010, new Object[] { src.msgBindClassName(), 
/*  396 */             dest.msgBindClassName() });
/*      */     }
/*      */ 
/*      */     
/*  400 */     if (src == dest) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  405 */     int constpos = 0;
/*  406 */     int constlen = MCConstColumnList.size((MCRow)src);
/*  407 */     for (int i = 0; i < constlen; i++) {
/*  408 */       MCMeta meta = MCConstColumnList.meta((MCRow)src, i);
/*  409 */       if (meta.type() == MCDataType.ROW) {
/*  410 */         MCConstColumnList.setRange((MCRow)dest, constpos, constpos, i - constpos, 
/*  411 */             ((MCRow)src)._const_datas);
/*  412 */         if (attr && ((MCRow)src)._const_paramColIndex != null) {
/*  413 */           MCConstColumnList.setParamColIndex((MCRow)dest, constpos, constpos, 
/*  414 */               i - constpos, ((MCRow)src)._const_paramColIndex);
/*      */         }
/*  416 */         copy((MCRow)MCConstColumnList.get((MCRow)dest, i), 
/*  417 */             (MCRow)MCConstColumnList.get((MCRow)src, i), attr);
/*  418 */         constpos = i + 1;
/*      */       } 
/*      */     } 
/*  421 */     if (constpos < constlen) {
/*  422 */       MCConstColumnList.setRange((MCRow)dest, constpos, constpos, constlen - constpos, 
/*  423 */           ((MCRow)src)._const_datas);
/*  424 */       if (attr && ((MCRow)src)._const_paramColIndex != null) {
/*  425 */         MCConstColumnList.setParamColIndex((MCRow)dest, constpos, constpos, 
/*  426 */             constlen - constpos, ((MCRow)src)._const_paramColIndex);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  431 */     MCTempColumnList dtl = dest.tmpColList();
/*  432 */     MCTempColumnList stl = src.tmpColList();
/*  433 */     if (dtl != null) {
/*  434 */       dtl.removeAll();
/*      */     }
/*  436 */     if (!isEmpty(stl)) {
/*  437 */       dest.createTmpColList().addAll(stl);
/*      */       
/*  439 */       dtl = dest.tmpColList();
/*      */       
/*  441 */       int temppos = 0;
/*  442 */       int templen = stl.size();
/*  443 */       for (int j = 0; j < templen; j++) {
/*  444 */         MCMeta meta = stl.meta(j);
/*  445 */         if (meta.type() == MCDataType.ROW) {
/*      */           
/*  447 */           dtl.setRange(temppos, stl, temppos, j - temppos);
/*  448 */           if (attr) {
/*  449 */             dtl.setParamColIndex(temppos, stl, temppos, j - temppos);
/*      */           }
/*  451 */           copy((MCRow)dtl.get(j), (MCRow)stl.get(j), attr);
/*  452 */           temppos = j + 1;
/*      */         } 
/*      */       } 
/*  455 */       if (temppos < templen) {
/*  456 */         dtl.setRange(temppos, stl, temppos, templen - temppos);
/*  457 */         if (attr) {
/*  458 */           dtl.setParamColIndex(temppos, stl, temppos, templen - temppos);
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  466 */     if (attr) {
/*  467 */       dest.setAttributes((MCRow)src);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final void copyByName(MCRow dest, MCRow src) {
/*  495 */     if (dest == null || src == null) {
/*      */       return;
/*      */     }
/*  498 */     dest.setByName(src);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static MCRow create() {
/*  507 */     return new MCRow(new ConstMetaList<>());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MCRow> MCRow createByName(T proto) {
/*  518 */     MCRow row = create();
/*  519 */     copyByName(row, (MCRow)proto);
/*  520 */     return row;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static <T extends MCRow> T class2row(Class<T> rowc) {
/*      */     try {
/*  535 */       Object obj = MCFactory.invokeStatic(rowc, "create", null, null);
/*  536 */       return rowc.cast(obj);
/*      */     }
/*  538 */     catch (Exception t) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  543 */       throwUnnecessaryWrapExceptionForCreate(t);
/*  544 */       throw new MCException(t, Core_Msg_FW_A.FCBBC0004, new Object[] { rowc.getName() });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void throwUnnecessaryWrapExceptionForCreate(Exception e) {
/*  556 */     if (e instanceof MCException) {
/*  557 */       MCException mce = (MCException)e;
/*  558 */       if (!MCMessageLevel.checkWrappedErrorLevel(mce.getLevel()))
/*      */       {
/*  560 */         throw mce;
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private static boolean containsAlias(ConstMetaList<? extends MCRow> l, String n) {
/*  566 */     return (l.indexOfAlias(n) >= 0);
/*      */   }
/*      */   
/*      */   static int indexOfAlias(ConstMetaList<? extends MCRow> l, String n) {
/*  570 */     return l.indexOfAlias(n);
/*      */   }
/*      */   
/*      */   private static MCContainerMeta aliasMeta(MCRow o, String n) {
/*  574 */     return o._list.aliasMeta(o, n);
/*      */   }
/*      */   
/*      */   private static boolean isEmpty(MCColumnList l) {
/*  578 */     return !(l != null && l.size() != 0);
/*      */   }
/*      */   
/*      */   private static int indexOf(MCColumnList l, String n) {
/*  582 */     return (l != null) ? l.indexOf(n) : -1;
/*      */   }
/*      */   
/*      */   private static MCContainerMeta meta(MCColumnList l, String n) {
/*  586 */     return (l != null) ? l.meta(n) : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final class ConstMetaList<T extends MCRow>
/*      */     implements Serializable
/*      */   {
/*      */     private final MCContainerMeta[] metas;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final int offset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final String[] _name;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final String[] _path;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     final int size;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     ConstMetaList() {
/*  643 */       this(null, null, null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ConstMetaList(ConstMetaList<? super T> parents, MCMeta[] metas) {
/*  661 */       this(parents, metas, null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ConstMetaList(ConstMetaList<? super T> parents, MCMeta[] metas, String[][] alias) {
/*  693 */       int plen = (parents != null) ? parents.size : 0;
/*  694 */       int mlen = (metas != null) ? metas.length : 0;
/*  695 */       int size = plen + mlen;
/*  696 */       this.metas = new MCContainerMeta[size];
/*  697 */       if (parents != null) {
/*  698 */         System.arraycopy(parents.metas, 0, this.metas, 0, plen);
/*      */       }
/*  700 */       for (int i = 0, pos = plen; i < mlen; i++) {
/*  701 */         if (metas[i] != null) {
/*  702 */           this.metas[pos++] = (MCContainerMeta)metas[i];
/*      */         } else {
/*      */           
/*  705 */           size--;
/*      */         } 
/*      */       } 
/*  708 */       this.size = size;
/*  709 */       this.offset = plen;
/*      */ 
/*      */       
/*  712 */       int palen = (parents != null) ? parents._name.length : 0;
/*  713 */       int alen = (alias != null) ? (alias[0]).length : 0;
/*  714 */       int asize = palen + alen;
/*  715 */       this._name = new String[asize];
/*  716 */       this._path = new String[asize];
/*  717 */       if (parents != null) {
/*  718 */         System.arraycopy(parents._name, 0, this._name, 0, palen);
/*  719 */         System.arraycopy(parents._path, 0, this._path, 0, palen);
/*      */       } 
/*  721 */       for (int j = 0, k = palen; j < alen; j++) {
/*  722 */         if (alias[0][j] != null && alias[1][j] != null) {
/*  723 */           this._name[k] = alias[0][j];
/*  724 */           this._path[k] = alias[1][j];
/*  725 */           k++;
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int offset() {
/*  738 */       return this.offset;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String[] toNameArray() {
/*  752 */       String[] s = new String[this.size];
/*  753 */       for (int i = 0; i < this.size; i++) {
/*  754 */         s[i] = this.metas[i].name();
/*      */       }
/*  756 */       return s;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MCMeta[] toMetaArray() {
/*  770 */       return (MCMeta[])toContainerMetaArray();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     MCContainerMeta[] toContainerMetaArray() {
/*  784 */       MCContainerMeta[] m = new MCContainerMeta[this.size];
/*  785 */       System.arraycopy(this.metas, 0, m, 0, this.size);
/*  786 */       return m;
/*      */     }
/*      */     
/*      */     MCContainerMeta[] getContainerMetaArray() {
/*  790 */       return this.metas;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String[][] toAliasArray() {
/*  801 */       int len = this._name.length;
/*  802 */       String[][] a = {
/*  803 */           new String[len], new String[len]
/*      */         };
/*  805 */       if (len > 0) {
/*  806 */         System.arraycopy(this._name, 0, a[0], 0, len);
/*  807 */         System.arraycopy(this._path, 0, a[1], 0, len);
/*      */       } 
/*  809 */       return a;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Object[] analyzeAlias(MCRow o, int index) {
/*      */       try {
/*  827 */         o.getClass(); MCRow.ColumnPath cp = new MCRow.ColumnPath(this._path[index]);
/*  828 */         MCContainerMeta m = cp.getConstMeta();
/*  829 */         if (m == null) {
/*  830 */           throw new MCException(Core_Msg_FW_A.FCBBC0077, new Object[] { o.msgBindClassName(), this._name[index], 
/*  831 */                 this._path[index] });
/*      */         }
/*  833 */         return new Object[] {
/*  834 */             MCRow.ColumnPath.access$0(cp), m
/*      */           };
/*      */       }
/*  837 */       catch (IndexOutOfBoundsException ex) {
/*      */         
/*  839 */         throw new MCException(ex, Core_Msg_FW_A.FCBBC0076, new Object[] { o.msgBindClassName(), 
/*  840 */               String.valueOf(this._name.length), String.valueOf(index) });
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private MCRow.ColumnPath getColumnPath(MCRow o, int index) {
/*      */       try {
/*  855 */         o.getClass(); MCRow.ColumnPath cp = new MCRow.ColumnPath(this._path[index]);
/*  856 */         MCContainerMeta m = cp.getConstMeta();
/*  857 */         if (m == null) {
/*  858 */           throw new MCException(Core_Msg_FW_A.FCBBC0077, new Object[] { o.msgBindClassName(), this._name[index], 
/*  859 */                 this._path[index] });
/*      */         }
/*  861 */         return cp;
/*      */       }
/*  863 */       catch (IndexOutOfBoundsException ex) {
/*      */         
/*  865 */         throw new MCException(ex, Core_Msg_FW_A.FCBBC0076, new Object[] { o.msgBindClassName(), 
/*  866 */               String.valueOf(this._name.length), String.valueOf(index) });
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     int indexOfAlias(String alias) {
/*  879 */       if (alias != null) {
/*  880 */         for (int i = 0; i < this._name.length; i++) {
/*      */           
/*  882 */           if (alias.equalsIgnoreCase(this._name[i])) {
/*  883 */             return i;
/*      */           }
/*      */         } 
/*      */       }
/*  887 */       return -1;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     MCRow aliasRow(MCRow o, int index) {
/*  903 */       Object[] a = analyzeAlias(o, index);
/*  904 */       return (MCRow)a[0];
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     MCContainerMeta aliasMeta(MCRow o, String alias) {
/*  919 */       int index = indexOfAlias(alias);
/*  920 */       if (index < 0) {
/*  921 */         return null;
/*      */       }
/*  923 */       return aliasMeta(o, index);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     MCContainerMeta aliasMeta(MCRow o, int index) {
/*  939 */       Object[] a = analyzeAlias(o, index);
/*  940 */       return (MCContainerMeta)a[1];
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     String aliasPath(MCRow o, String alias) {
/*  955 */       int index = indexOfAlias(alias);
/*  956 */       if (index < 0) {
/*  957 */         return null;
/*      */       }
/*  959 */       return aliasPath(o, index);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     String aliasPath(MCRow o, int index) {
/*  975 */       analyzeAlias(o, index);
/*  976 */       return this._path[index];
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     String[] toAliasNameArray() {
/*  987 */       String[] a = new String[this._name.length];
/*  988 */       System.arraycopy(this._name, 0, a, 0, this._name.length);
/*  989 */       return a;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1009 */   private MCRow _parent = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1018 */   private String _parentCol = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final ConstMetaList<? extends MCRow> _list;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int[] _const_paramColIndex;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MCTempColumnList _tmpcols;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MCRow(ConstMetaList<? extends MCRow> cols) {
/*      */     try {
/* 1050 */       if (cols == null)
/*      */       {
/* 1052 */         throw new MCException(Core_Msg_FW_A.FCBBC0005, new Object[] { msgBindClassName() });
/*      */       }
/* 1054 */       this._list = cols;
/* 1055 */       this._const_datas = (Comparable<?>[])new Comparable[MCConstColumnList.size(this)];
/* 1056 */       MCConstColumnList.rowinit(this);
/*      */     }
/* 1058 */     catch (MCException ex) {
/*      */       
/* 1060 */       throw new MCException(ex, Core_Msg_FW_A.FCBBC0004, new Object[] { msgBindClassName() });
/*      */     } 
/*      */ 
/*      */     
/* 1064 */     if (MCContainerSignalManager.isInterrupted()) {
/* 1065 */       MCException e = new MCException(
/* 1066 */           MCContainerSignalManager.getInterruptedMessage4GUI());
/* 1067 */       if (!MCUtil.classInitException((Throwable)e)) {
/* 1068 */         MCLog.write(MCContainerSignalManager.getInterruptedMessage());
/* 1069 */         throw new MCError(e);
/*      */       } 
/*      */       
/* 1072 */       MCContainerSignalManager.resume();
/*      */     } 
/*      */ 
/*      */     
/* 1076 */     if (Thread.interrupted()) {
/* 1077 */       MCException e = new MCException(new InterruptedException());
/* 1078 */       if (!MCUtil.classInitException((Throwable)e)) {
/* 1079 */         throw new MCError(e);
/*      */       }
/*      */       
/* 1082 */       Thread.currentThread().interrupt();
/*      */     } 
/*      */ 
/*      */     
/* 1086 */     MCVolumeManager.consumeVolume();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void init() {
/*      */     try {
/* 1113 */       int len = MCConstColumnList.size(this);
/* 1114 */       for (int i = 0; i < len; i++) {
/* 1115 */         MCConstColumnList.init(this, i, this._const_datas);
/*      */       }
/*      */ 
/*      */       
/* 1119 */       removeTempColumn();
/*      */ 
/*      */       
/* 1122 */       initAttributes();
/*      */     
/*      */     }
/* 1125 */     catch (MCException ex) {
/*      */       
/* 1127 */       throw new MCException(ex, Core_Msg_FW_A.FCBBC0006, new Object[] { msgBindClassName() });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final MCTempColumnList tmpColList() {
/* 1139 */     return this._tmpcols;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MCRow createInnerRow(MCMeta meta) {
/* 1159 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setParentRow(MCRow parent, String parentcol) {
/* 1171 */     this._parent = parent;
/* 1172 */     this._parentCol = parentcol;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final MCRow getParentRow() {
/* 1183 */     return this._parent;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getParentRowColumn() {
/* 1194 */     return this._parentCol;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getParentRowColumnPath() {
/* 1205 */     MCRow r = getParentRow();
/* 1206 */     if (r == null) {
/* 1207 */       return null;
/*      */     }
/* 1209 */     return r.getRootRowColumnPath(getParentRowColumn());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final MCRow getRootRow() {
/* 1224 */     MCRow current = this;
/* 1225 */     MCRow parent = current.getParentRow();
/* 1226 */     if (parent != null) {
/* 1227 */       current = parent.getRootRow();
/*      */     }
/* 1229 */     return current;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getRootRowColumnPath() {
/* 1243 */     String rcol = getParentRowColumn();
/* 1244 */     MCRow parent = getParentRow();
/* 1245 */     if (parent != null) {
/* 1246 */       String pcol = parent.getRootRowColumnPath();
/* 1247 */       rcol = createColumnPath(new String[] { pcol, rcol });
/*      */     } 
/* 1249 */     return rcol;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getRootRowColumnPath(String name) {
/* 1270 */     if (!contains(name)) {
/* 1271 */       return null;
/*      */     }
/* 1273 */     String rcol = getRootRowColumnPath();
/* 1274 */     rcol = createColumnPath(new String[] { rcol, name });
/* 1275 */     return rcol;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String[] getRootRowColumnPathArray() {
/* 1298 */     String rcol = getRootRowColumnPath();
/* 1299 */     List<String> list = getColumnPathList(rcol, true);
/* 1300 */     return list.<String>toArray(new String[list.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final MCTempColumnList createTmpColList() {
/* 1315 */     return (this._tmpcols != null) ? this._tmpcols : (this._tmpcols = new MCTempColumnList(this));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void addListPrototypeTempColumns(MCRow listPrototype) {
/* 1327 */     if (!isEmpty(listPrototype._tmpcols)) {
/* 1328 */       createTmpColList().addAllForce(listPrototype._tmpcols);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void addTempColumns(MCRow src) {
/* 1343 */     if (!isEmpty(src._tmpcols)) {
/* 1344 */       createTmpColList().addAll(src._tmpcols);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final int addTempColumn(String name, MCDataType type) {
/* 1367 */     int index = -1;
/* 1368 */     if (MCConstColumnList.indexOf(this, name) < 0 && !containsAlias(this._list, name)) {
/*      */       
/* 1370 */       if (type == MCDataType.ROW)
/*      */       {
/* 1372 */         throw new MCException(Core_Msg_FW_A.FCBBC0056, new Object[] { msgBindClassName(), name });
/*      */       }
/*      */       
/* 1375 */       MCContainerMeta m = createTempMeta(name, type);
/* 1376 */       index = createTmpColList().add(m);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1381 */     if (index >= 0) {
/*      */       
/* 1383 */       MCLog.write(Core_Msg_FW_A.FCBBC0007, new Object[] { msgBindClassName(), name, type });
/*      */     }
/*      */     else {
/*      */       
/* 1387 */       MCLog.write(Core_Msg_FW_A.FCBBC0008, new Object[] { msgBindClassName(), name, type });
/*      */     } 
/* 1389 */     return index;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final MCContainerMeta createTempMeta(String name, MCDataType type) {
/* 1404 */     switch (type) {
/*      */ 
/*      */       
/*      */       case STRING:
/* 1408 */         return MCContainerMeta.stringMeta(name, -1);
/*      */ 
/*      */       
/*      */       case NUMBER:
/* 1412 */         return MCContainerMeta.numberMeta(name, -1, 
/* 1413 */             -1, true);
/*      */       case DATE:
/* 1415 */         return MCContainerMeta.dateMeta(name);
/*      */       case TIMESTAMP:
/* 1417 */         return MCContainerMeta.timestampMeta(name);
/*      */       case BOOLEAN:
/* 1419 */         return MCContainerMeta.booleanMeta(name);
/*      */       case null:
/* 1421 */         return MCContainerMeta.binaryMeta(name);
/*      */       
/*      */       case ROW:
/* 1424 */         return MCContainerMeta.rowMeta(name, (Class<? extends MCConstRow>)null);
/*      */     } 
/*      */     
/* 1427 */     throw new MCException(Core_Msg_FW_A.FCBBC0001, new Object[] { name, type });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void removeTempColumn() {
/* 1437 */     if (this._tmpcols != null) {
/* 1438 */       this._tmpcols.removeAll();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addStringColumn(String name) {
/* 1455 */     addValueColumn(name, MCDataType.STRING);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addStringColumn(String name, String value) {
/* 1473 */     addValueColumn(name, MCDataType.STRING, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addNumberColumn(String name) {
/* 1489 */     addValueColumn(name, MCDataType.NUMBER);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addNumberColumn(String name, MCNumber value) {
/* 1507 */     addValueColumn(name, MCDataType.NUMBER, (Comparable<?>)value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addDateColumn(String name) {
/* 1523 */     addValueColumn(name, MCDataType.DATE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addDateColumn(String name, MCDate value) {
/* 1541 */     addValueColumn(name, MCDataType.DATE, (Comparable<?>)value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addTimestampColumn(String name) {
/* 1557 */     addValueColumn(name, MCDataType.TIMESTAMP);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addTimestampColumn(String name, MCTimestamp value) {
/* 1575 */     addValueColumn(name, MCDataType.TIMESTAMP, (Comparable<?>)value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addBooleanColumn(String name) {
/* 1591 */     addValueColumn(name, MCDataType.BOOLEAN);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addBooleanColumn(String name, boolean value) {
/* 1609 */     addValueColumn(name, MCDataType.BOOLEAN, Boolean.valueOf(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addBinaryColumn(String name) {
/* 1625 */     addValueColumn(name, MCDataType.BINARY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addBinaryColumn(String name, MCBinary value) {
/* 1643 */     addValueColumn(name, MCDataType.BINARY, (Comparable<?>)value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void addValueColumn(String name, MCDataType type) {
/* 1672 */     ColumnPath cp = new ColumnPath(name);
/* 1673 */     cp.row.addValueColumnImpl(cp.name, type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void addValueColumn(String name, MCDataType type, Comparable<?> value) {
/* 1705 */     ColumnPath cp = new ColumnPath(name);
/* 1706 */     int index = cp.row.addValueColumnImpl(cp.name, type);
/* 1707 */     cp.row.createTmpColList().setchkval(index, cp.name, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int addValueColumnImpl(String name, MCDataType type) {
/* 1734 */     int index = addTempColumn(name, type);
/* 1735 */     if (index < 0)
/*      */     {
/* 1737 */       index = validateTempColumn(name, type);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1742 */     return index;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final int validateTempColumn(String name, MCDataType type) {
/* 1757 */     int index = (this._tmpcols != null) ? this._tmpcols.indexOf(name) : -1;
/* 1758 */     if (index < 0) {
/* 1759 */       if (MCConstColumnList.indexOf(this, name) >= 0 || 
/* 1760 */         containsAlias(this._list, name))
/*      */       {
/* 1762 */         throw new MCException(Core_Msg_FW_A.FCBBC0053, new Object[] { msgBindClassName(), name, type });
/*      */       }
/*      */     } else {
/*      */       
/* 1766 */       MCMeta meta = this._tmpcols.meta(index);
/* 1767 */       if (meta.type() != type)
/*      */       {
/* 1769 */         throw new MCException(Core_Msg_FW_A.FCBBC0054, new Object[] { msgBindClassName(), name, type });
/*      */       }
/*      */     } 
/* 1772 */     return index;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final String msgBindClassName() {
/* 1787 */     return getClass().getName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCRow createInstance() {
/* 1802 */     return (MCRow)class2row(getClass());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final MCDataType getDataType(String name) {
/* 1817 */     MCDataType type = null;
/* 1818 */     MCMeta meta = getMeta(name);
/* 1819 */     if (meta != null) {
/* 1820 */       type = meta.type();
/*      */     }
/* 1822 */     return type;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isEmpty() {
/* 1845 */     boolean e = true;
/*      */ 
/*      */     
/* 1848 */     e = MCConstColumnList.isEmpty(this);
/*      */ 
/*      */     
/* 1851 */     if (e && this._tmpcols != null) {
/* 1852 */       e = this._tmpcols.isEmpty();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1869 */     return e;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isEmpty(String... names) {
/* 1886 */     if (names == null)
/*      */     {
/* 1888 */       throw new MCException(Core_Msg_FW_A.FCBBC0052, new Object[] { msgBindClassName(), "(null)" });
/*      */     }
/*      */     
/* 1891 */     boolean empty = true;
/*      */     
/* 1893 */     int len = names.length;
/* 1894 */     for (int i = 0; empty && i < len; i++) {
/* 1895 */       ColumnPath cp = new ColumnPath(names[i]);
/* 1896 */       MCMeta meta = cp.getMeta();
/* 1897 */       if (meta != null) {
/* 1898 */         empty = cp.row.isEmptyColumn(meta);
/*      */       }
/*      */       else {
/*      */         
/* 1902 */         throw new MCException(Core_Msg_FW_A.FCBBC0052, new Object[] { msgBindClassName(), names[i] });
/*      */       } 
/*      */     } 
/*      */     
/* 1906 */     return empty;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean isEmptyColumn(MCMeta meta) {
/* 1918 */     boolean empty = true;
/* 1919 */     if (meta.type() == MCDataType.ROW) {
/* 1920 */       MCRow inner = getInnerRow(meta.name());
/* 1921 */       empty = inner.isEmpty();
/*      */     }
/* 1923 */     else if (meta.type() == MCDataType.BOOLEAN) {
/* 1924 */       empty = !getBoolean(meta.name());
/*      */     } else {
/*      */       
/* 1927 */       empty = (getValue(meta.name()) == null);
/*      */     } 
/* 1929 */     return empty;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void clear() {
/* 1950 */     int l = MCConstColumnList.size(this); int i;
/* 1951 */     for (i = 0; i < l; i++) {
/* 1952 */       MCConstColumnList.clear(this, i);
/*      */     }
/*      */     
/* 1955 */     if (this._tmpcols != null) {
/* 1956 */       l = this._tmpcols.size();
/* 1957 */       for (i = 0; i < l; i++) {
/* 1958 */         this._tmpcols.clear(i);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void clear(String... names) {
/* 1985 */     if (names == null || names.length <= 0)
/*      */       return;  byte b;
/*      */     int i;
/*      */     String[] arrayOfString;
/* 1989 */     for (i = (arrayOfString = names).length, b = 0; b < i; ) { String name = arrayOfString[b];
/*      */       
/* 1991 */       int index = MCConstColumnList.indexOf(this, name);
/* 1992 */       if (index > -1) {
/* 1993 */         MCConstColumnList.clear(this, index);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1998 */         index = indexOfAlias(this._list, name);
/* 1999 */         if (index > -1) {
/* 2000 */           ColumnPath cp = this._list.getColumnPath(this, index);
/* 2001 */           MCRow row = cp.row;
/* 2002 */           MCContainerMeta meta = cp.getConstMeta();
/* 2003 */           MCConstColumnList.clear(row, MCConstColumnList.indexOf(row, meta));
/*      */         
/*      */         }
/*      */         else {
/*      */           
/* 2008 */           index = indexOf(this._tmpcols, name);
/* 2009 */           if (index > -1) {
/* 2010 */             this._tmpcols.clear(index);
/*      */           
/*      */           }
/*      */           else {
/*      */             
/* 2015 */             ColumnPath cp = new ColumnPath(name);
/* 2016 */             if (cp.row != this) {
/* 2017 */               cp.row.clear(new String[] { ColumnPath.access$1(cp) });
/*      */             
/*      */             }
/*      */             else {
/*      */               
/* 2022 */               throw throw_ColumnNotFound(name);
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       b++; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void clearAll() {
/* 2044 */     clear();
/* 2045 */     getRootRow().initAttributes();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean equals(Object obj) {
/* 2069 */     if (!(obj instanceof MCRow)) {
/* 2070 */       return false;
/*      */     }
/*      */     
/* 2073 */     MCRow row = (MCRow)obj;
/*      */     
/* 2075 */     if (row.getClass() != getClass()) {
/* 2076 */       return false;
/*      */     }
/*      */     
/* 2079 */     if (row == this) {
/* 2080 */       return true;
/*      */     }
/*      */     
/* 2083 */     for (int i = 0; i < MCConstColumnList.size(this); i++) {
/* 2084 */       Comparable<?> ownval = MCConstColumnList.get(this, 
/* 2085 */           MCConstColumnList.meta(this, i));
/* 2086 */       Comparable<?> rowval = MCConstColumnList.get(row, 
/* 2087 */           MCConstColumnList.meta(row, i));
/* 2088 */       if ((ownval == null) ? (rowval != null) : !ownval.equals(rowval)) {
/* 2089 */         return false;
/*      */       }
/*      */     } 
/* 2092 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean equalColumns(MCRow row, String... names) {
/*      */     String[] ownnames, rownames;
/* 2124 */     if (row == null) {
/* 2125 */       return false;
/*      */     }
/*      */     
/* 2128 */     if (row.getClass() != getClass()) {
/* 2129 */       return false;
/*      */     }
/*      */     
/* 2132 */     if (row == this) {
/* 2133 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2138 */     if (names == null || names.length == 0) {
/* 2139 */       ownnames = getConstColumnPathArray();
/* 2140 */       rownames = row.getConstColumnPathArray();
/*      */     } else {
/*      */       
/* 2143 */       ownnames = names;
/* 2144 */       rownames = names;
/*      */     } 
/*      */     
/* 2147 */     ColumnPath owncp = new ColumnPath();
/* 2148 */     ColumnPath rowcp = new ColumnPath();
/* 2149 */     int collen = ownnames.length;
/* 2150 */     for (int i = 0; i < collen; i++) {
/* 2151 */       owncp.init(this, ownnames[i]);
/* 2152 */       rowcp.init(row, rownames[i]);
/* 2153 */       MCContainerMeta ownmeta = owncp.getConstMeta();
/* 2154 */       MCContainerMeta rowmeta = rowcp.getConstMeta();
/*      */ 
/*      */       
/* 2157 */       if (ownmeta == null || rowmeta == null)
/*      */       {
/* 2159 */         throw new MCException(Core_Msg_FW_A.FCBBC0024, new Object[] { msgBindClassName(), names[i] });
/*      */       }
/* 2161 */       if (ownmeta != rowmeta) {
/* 2162 */         return false;
/*      */       }
/*      */       
/* 2165 */       Comparable<?> ownval = MCConstColumnList.get(owncp.row, ownmeta);
/* 2166 */       Comparable<?> rowval = MCConstColumnList.get(rowcp.row, rowmeta);
/* 2167 */       if ((ownval == null) ? (rowval != null) : !ownval.equals(rowval)) {
/* 2168 */         return false;
/*      */       }
/*      */     } 
/* 2171 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int compareTo(MCRow row) {
/* 2203 */     if (row == null) {
/* 2204 */       return -1;
/*      */     }
/* 2206 */     if (row == this) {
/* 2207 */       return 0;
/*      */     }
/* 2209 */     if (!getClass().isAssignableFrom(row.getClass()))
/*      */     {
/* 2211 */       throw new MCException(Core_Msg_FW_A.FCBBC0011, new Object[] { msgBindClassName(), row.msgBindClassName() });
/*      */     }
/*      */     
/* 2214 */     int comp = 0;
/* 2215 */     String[] names = getNameArray();
/* 2216 */     int nameslen = names.length;
/* 2217 */     for (int i = 0; i < nameslen && comp == 0; i++) {
/* 2218 */       comp = compareValueNE(names[i], row, names[i]);
/*      */     }
/* 2220 */     return comp;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int compareValue(String owncol, MCRow row, String rowcol) {
/* 2247 */     if (row == null)
/*      */     {
/* 2249 */       throw new MCException(Core_Msg_FW_A.FCBBC0067, new Object[0]);
/*      */     }
/* 2251 */     Comparable<?> ownval = getValue(owncol);
/* 2252 */     Comparable<?> rowval = row.getValue(rowcol);
/* 2253 */     return compareRowValue(this, owncol, ownval, row, rowcol, rowval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int compareValueNE(String owncol, MCRow row, String rowcol) {
/* 2279 */     if (row == null) {
/* 2280 */       return -1;
/*      */     }
/*      */ 
/*      */     
/* 2284 */     Comparable<?> ownval = getValueNE(owncol);
/* 2285 */     Comparable<?> rowval = row.getValueNE(rowcol);
/* 2286 */     return compareRowValue(this, owncol, ownval, row, rowcol, rowval);
/*      */   }
/*      */ 
/*      */   
/*      */   int compareValueNE(String owncol, ColumnDefinition owndef, MCRow row, String rowcol, ColumnDefinition rowdef) {
/* 2291 */     if (row == null) {
/* 2292 */       return -1;
/*      */     }
/*      */ 
/*      */     
/* 2296 */     Comparable<?> ownval = getValueNE(owndef, owncol, this);
/* 2297 */     Comparable<?> rowval = getValueNE(rowdef, rowcol, row);
/* 2298 */     return compareRowValue(this, owncol, ownval, row, rowcol, rowval);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int compareRowValue(MCRow row1, String col1, Comparable<Comparable> val1, MCRow row2, String col2, Comparable val2) {
/* 2326 */     if (val1 == null) {
/* 2327 */       return (val2 == null) ? 0 : 1;
/*      */     }
/* 2329 */     if (val2 == null) {
/* 2330 */       return -1;
/*      */     }
/*      */     
/*      */     try {
/* 2334 */       return val1.compareTo(val2);
/*      */     }
/* 2336 */     catch (ClassCastException classCastException) {
/*      */       
/* 2338 */       String col1row = (row1 != null) ? row1.msgBindClassName() : null;
/* 2339 */       MCDataType col1type = (row1 != null && col1 != null) ? 
/* 2340 */         row1.getMeta(col1).type() : null;
/* 2341 */       String col2row = (row2 != null) ? row2.msgBindClassName() : null;
/* 2342 */       MCDataType col2type = (row2 != null && col2 != null) ? 
/* 2343 */         row2.getMeta(col2).type() : null;
/* 2344 */       throw new MCException(Core_Msg_FW_A.FCBBC0012, new Object[] { col1row, col1, col1type, col2row, col2, 
/* 2345 */             col2type });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int hashCode() {
/* 2363 */     int hashCode = super.hashCode();
/* 2364 */     int len = MCConstColumnList.size(this);
/* 2365 */     for (int i = 0; i < len; i++) {
/* 2366 */       Comparable<?> val = MCConstColumnList.get(this, i);
/* 2367 */       hashCode = 31 * hashCode + ((val == null) ? 0 : val.hashCode());
/*      */     } 
/* 2369 */     return hashCode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCRow clone() {
/* 2390 */     MCRow row = createInstance();
/* 2391 */     copyall(row, this);
/* 2392 */     return row;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCMessageList validate(String... names) {
/* 2426 */     return validate(this, null, this, names);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final MCMessageList validate(MCRow baserow, String ppath, MCRow prow, String... names) {
/* 2462 */     if (names == null || names.length <= 0) {
/* 2463 */       names = prow.getNameArray();
/*      */     }
/*      */     
/* 2466 */     String basename = baserow.msgBindClassName();
/* 2467 */     MCMessageList list = new MCMessageList(); byte b; int i; String[] arrayOfString;
/* 2468 */     for (i = (arrayOfString = names).length, b = 0; b < i; ) { String name = arrayOfString[b];
/* 2469 */       String cpath = (ppath != null) ? 
/* 2470 */         createColumnPath(new String[] { ppath, name }) : name;
/*      */       
/* 2472 */       MCMeta meta = prow.getMeta(name);
/* 2473 */       if (meta == null) {
/* 2474 */         MCMessage msg = new MCMessage(baserow, cpath, Core_Msg_FW_A.FCBBC0062, new Object[] { basename, cpath });
/* 2475 */         list.add(msg);
/*      */       }
/* 2477 */       else if (meta.type() != MCDataType.ROW) {
/* 2478 */         MCMessage msg = validateValue(baserow, cpath, prow, meta);
/* 2479 */         if (msg != null) {
/* 2480 */           list.add(msg);
/*      */         }
/*      */       }
/*      */       else {
/*      */         
/* 2485 */         MCRow row = prow.getInnerRow(name);
/* 2486 */         MCMessageList temp = validate(baserow, cpath, row, new String[0]);
/* 2487 */         if (temp.size() > 0)
/* 2488 */           list.addAll((Collection)temp); 
/*      */       } 
/*      */       b++; }
/*      */     
/* 2492 */     return list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MCMessage validateValue(MCRow baserow, String cpath, MCRow row, MCMeta meta) {
/*      */     String str;
/*      */     MCNumber num;
/* 2522 */     if (row == null || meta == null) {
/* 2523 */       return null;
/*      */     }
/*      */     
/* 2526 */     int length = meta.length();
/* 2527 */     if (length == -1)
/*      */     {
/* 2529 */       return null;
/*      */     }
/* 2531 */     switch (meta.type()) {
/*      */       case STRING:
/* 2533 */         str = getString(cpath);
/* 2534 */         if (str != null) {
/*      */           
/* 2536 */           if (str.length() > length) {
/* 2537 */             String basename = baserow.msgBindClassName();
/* 2538 */             return new MCMessage(baserow, cpath, Core_Msg_FW_A.FCBBC0063, new Object[] { basename, cpath, 
/* 2539 */                   Integer.valueOf(length), str });
/*      */           } 
/*      */           
/* 2542 */           if (meta.crypt() && !MCStringUtil.isSingleBytes(str)) {
/* 2543 */             String basename = baserow.msgBindClassName();
/* 2544 */             return new MCMessage(baserow, cpath, Core_Msg_FW_A.FCBBC0078, new Object[] { basename, cpath });
/*      */           } 
/*      */         } 
/*      */         break;
/*      */       
/*      */       case NUMBER:
/* 2550 */         num = getNumber(cpath);
/* 2551 */         if (num != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2556 */           int scale = meta.scale();
/* 2557 */           length -= scale;
/* 2558 */           int numscale = num.scale();
/* 2559 */           int numlength = num.precision() - numscale;
/* 2560 */           if (numlength > length || numscale > scale) {
/* 2561 */             String basename = baserow.msgBindClassName();
/* 2562 */             return new MCMessage(baserow, cpath, Core_Msg_FW_A.FCBBC0064, new Object[] { basename, cpath, 
/* 2563 */                   Integer.valueOf(length), Integer.valueOf(meta.scale()), 
/* 2564 */                   num });
/*      */           } 
/*      */           
/* 2567 */           if (!meta.minusEnable() && num.isNegative()) {
/* 2568 */             String basename = baserow.msgBindClassName();
/* 2569 */             return new MCMessage(baserow, cpath, Core_Msg_FW_A.FCBBC0065, new Object[] { basename, cpath, 
/* 2570 */                   num });
/*      */           } 
/*      */         } 
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2578 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Comparable<?>[] toArray(String... names) {
/* 2597 */     if (names == null || names.length == 0) {
/* 2598 */       names = getNameArray();
/*      */     }
/* 2600 */     Comparable[] vals = new Comparable[names.length];
/* 2601 */     for (int i = 0; i < names.length; i++) {
/* 2602 */       MCMeta meta = getMeta(names[i]);
/* 2603 */       if (meta == null)
/*      */       {
/* 2605 */         throw throw_ColumnNotFound(names[i]);
/*      */       }
/* 2607 */       vals[i] = getValue(names[i]);
/*      */     } 
/* 2609 */     return (Comparable<?>[])vals;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 2657 */     if (MCConfig.common.getBoolean("log.devlog", false)) {
/* 2658 */       StringBuilder sb = new StringBuilder();
/* 2659 */       MCMeta[] a = getConstMetaArray();
/* 2660 */       for (int i = 0; i < constSize(); i++) {
/* 2661 */         sb.append(" [");
/* 2662 */         sb.append(i);
/* 2663 */         sb.append(" (");
/* 2664 */         sb.append(a[i].type().toString().charAt(0));
/* 2665 */         sb.append(") ");
/* 2666 */         sb.append(a[i].name());
/* 2667 */         sb.append("] ");
/*      */         
/* 2669 */         if (MCDataType.ROW.equals(a[i].type())) {
/* 2670 */           sb.append((this._const_datas[i] != null) ? (
/* 2671 */               (MCRow)this._const_datas[i]).toRowString() : "");
/*      */         } else {
/*      */           
/* 2674 */           sb.append((this._const_datas[i] != null) ? this._const_datas[i] : "");
/*      */         } 
/*      */         
/* 2677 */         sb.append("\n");
/*      */       } 
/*      */       
/* 2680 */       if (sb.length() > 0) {
/* 2681 */         sb.append("\n");
/*      */       }
/* 2683 */       if (this._tmpcols != null) {
/* 2684 */         sb.append(this._tmpcols.toString()).append("\n");
/*      */       }
/*      */       
/* 2687 */       sb.append(" [status] ").append(getStatus()).append("\n");
/* 2688 */       sb.append(" [gui_visible] ").append(isGUIVisible()).append("\n");
/* 2689 */       sb.append(" [gui_create] ").append(isGUICreated()).append("\n");
/* 2690 */       sb.append(" [gui_modify] ").append(isGUIModified()).append("\n");
/* 2691 */       sb.append(" [gui_delete] ").append(isGUIDeleted());
/* 2692 */       return sb.toString();
/*      */     } 
/*      */     
/* 2695 */     return toRowString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toRowString() {
/* 2710 */     StringBuilder sb = new StringBuilder(); byte b; int i; String[] arrayOfString;
/* 2711 */     for (i = (arrayOfString = getNameArray()).length, b = 0; b < i; ) { String s, n = arrayOfString[b];
/* 2712 */       sb.append(",");
/*      */       
/* 2714 */       Comparable<?> v = getValue(n);
/* 2715 */       if (MCDataType.ROW.equals(getDataType(n))) {
/* 2716 */         s = ((MCRow)v).toRowString();
/*      */       } else {
/*      */         
/* 2719 */         s = (v != null) ? v.toString() : "";
/*      */       } 
/* 2721 */       sb.append(s); b++; }
/*      */     
/* 2723 */     return (sb.length() > 0) ? sb.substring(1) : "";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void fireValueChanged(String column, Comparable<?> newvalue, Comparable<?> oldvalue) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void fireStatusChanged(Status newstatus, Status oldstatus) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initAttributes() {
/* 2778 */     if (this._ri == null) {
/*      */       return;
/*      */     }
/*      */     
/* 2782 */     if (this != getRootRow()) {
/* 2783 */       this._ri = null;
/*      */       
/*      */       return;
/*      */     } 
/* 2787 */     Status o = this._ri.status();
/*      */     
/* 2789 */     this._ri.status(Status.NONE);
/* 2790 */     this._ri.guicreate(false);
/* 2791 */     this._ri.guimodify(false);
/* 2792 */     this._ri.guidelete(false);
/* 2793 */     this._ri._reftime = null;
/* 2794 */     this._ri._param_index = -1;
/* 2795 */     this._ri._param_rowindex = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2801 */     fireStatusChanged(this._ri.status(), o);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAttributes(MCRow row) {
/* 2821 */     if (row == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 2826 */     MCRow ownroot = getRootRow();
/* 2827 */     MCRow rowroot = row.getRootRow();
/*      */     
/* 2829 */     RootRowInfo oi = ownroot.ri();
/* 2830 */     RootRowInfo ri = rowroot.ri();
/* 2831 */     oi._param_index = ri._param_index;
/* 2832 */     oi._param_rowindex = ri._param_rowindex;
/* 2833 */     oi._reftime = ri._reftime;
/* 2834 */     oi._gui_index = ri._gui_index;
/* 2835 */     oi.guivisible(ri.guivisible());
/* 2836 */     oi.guicreate(ri.guicreate());
/* 2837 */     oi.guimodify(ri.guimodify());
/* 2838 */     oi.guidelete(ri.guidelete());
/*      */     
/* 2840 */     setRootStatusWithEvent(ownroot, ri.status());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setColAttributes(String name, MCRow row) {
/* 2856 */     setColAttributes(name, row, name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setColAttributes(String name, MCRow row, String src_name) {
/* 2872 */     if (MCStringUtil.isNull(name) || row == null || MCStringUtil.isNull(src_name)) {
/*      */       return;
/*      */     }
/*      */     
/* 2876 */     setParamColIndexNE(name, row.getParamColIndexNE(src_name));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum Status
/*      */   {
/* 2895 */     NONE,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2901 */     GUICREATE,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2912 */     CREATE,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2918 */     MODIFY,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2924 */     DELETE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2938 */   public static final Status NONE = Status.NONE;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2946 */   public static final Status GUICREATE = Status.GUICREATE;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2954 */   public static final Status CREATE = Status.CREATE;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2962 */   public static final Status MODIFY = Status.MODIFY;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2970 */   public static final Status DELETE = Status.DELETE;
/*      */ 
/*      */   
/*      */   RootRowInfo _ri;
/*      */ 
/*      */   
/*      */   private PointerBundle _pb;
/*      */ 
/*      */   
/*      */   public final boolean isStatusCreate() {
/* 2980 */     return isStatus(Status.CREATE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isStatusModify() {
/* 2991 */     return isStatus(Status.MODIFY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isStatusDelete() {
/* 3002 */     return isStatus(Status.DELETE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isStatusGUICreate() {
/* 3019 */     return (isStatus(Status.NONE) && isGUICreated());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isStatusNone() {
/* 3031 */     return isStatus(Status.NONE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean isStatus(Status status) {
/* 3043 */     MCRow root = getRootRow();
/* 3044 */     return (root.ri().status() == status);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Status getStatus() {
/* 3055 */     MCRow root = getRootRow();
/* 3056 */     return root.ri().status();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStatus(Status status) {
/* 3070 */     status = (status == null) ? NONE : status;
/*      */     
/* 3072 */     MCRow root = getRootRow();
/* 3073 */     RootRowInfo ri = root.ri();
/* 3074 */     switch (status) {
/*      */       case null:
/* 3076 */         ri.guicreate(true);
/* 3077 */         ri.guimodify(true);
/* 3078 */         ri.guidelete(false);
/*      */         break;
/*      */       case MODIFY:
/* 3081 */         ri.guicreate(false);
/* 3082 */         ri.guimodify(true);
/* 3083 */         ri.guidelete(false);
/*      */         break;
/*      */       case DELETE:
/* 3086 */         ri.guidelete(true);
/*      */         break;
/*      */       case GUICREATE:
/* 3089 */         ri.guicreate(true);
/* 3090 */         ri.guimodify(false);
/* 3091 */         ri.guidelete(false);
/* 3092 */         status = NONE;
/*      */         break;
/*      */       
/*      */       default:
/* 3096 */         ri.guicreate(false);
/* 3097 */         ri.guimodify(false);
/* 3098 */         ri.guidelete(false);
/*      */         break;
/*      */     } 
/* 3101 */     setRootStatusWithEvent(root, status);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setRootStatusWithEvent(MCRow root, Status status) {
/* 3113 */     if (status == null) {
/* 3114 */       status = Status.NONE;
/*      */     }
/*      */     
/* 3117 */     Status old = root.ri().status();
/* 3118 */     root.ri().status(status);
/* 3119 */     root.fireStatusChanged(status, old);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private RootRowInfo ri() {
/* 3141 */     return (this._ri != null) ? this._ri : (this._ri = new RootRowInfo(null));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final class RootRowInfo
/*      */     implements Serializable
/*      */   {
/*      */     private byte _info;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void set(int i, boolean f) {
/* 3168 */       int m = 1 << i;
/* 3169 */       String a = Integer.toBinaryString(f ? (this._info | m) : (this._info & (m ^ 0xFFFFFFFF)));
/* 3170 */       this._info = Byte.parseByte(a, 2);
/*      */     }
/*      */     
/*      */     private boolean get(int i) {
/* 3174 */       int m = 1 << i;
/* 3175 */       return ((this._info & m) != 0);
/*      */     }
/*      */ 
/*      */     
/*      */     private void guivisible(boolean f) {
/* 3180 */       set(0, !f);
/*      */     }
/*      */ 
/*      */     
/*      */     private boolean guivisible() {
/* 3185 */       return !get(0);
/*      */     }
/*      */     
/*      */     private void guicreate(boolean f) {
/* 3189 */       set(1, f);
/*      */     }
/*      */     
/*      */     private boolean guicreate() {
/* 3193 */       return get(1);
/*      */     }
/*      */     
/*      */     private void guimodify(boolean f) {
/* 3197 */       set(2, f);
/*      */     }
/*      */     
/*      */     private boolean guimodify() {
/* 3201 */       return get(2);
/*      */     }
/*      */     
/*      */     private void guidelete(boolean f) {
/* 3205 */       set(3, f);
/*      */     }
/*      */     
/*      */     private boolean guidelete() {
/* 3209 */       return get(3);
/*      */     }
/*      */     
/*      */     private void status(MCRow.Status s) {
/* 3213 */       switch ((s != null) ? s : MCRow.NONE) {
/*      */         case GUICREATE:
/* 3215 */           set(4, true);
/* 3216 */           set(5, false);
/* 3217 */           set(6, false);
/*      */           return;
/*      */         case null:
/* 3220 */           set(4, false);
/* 3221 */           set(5, true);
/* 3222 */           set(6, false);
/*      */           return;
/*      */         case MODIFY:
/* 3225 */           set(4, true);
/* 3226 */           set(5, true);
/* 3227 */           set(6, false);
/*      */           return;
/*      */         case DELETE:
/* 3230 */           set(4, false);
/* 3231 */           set(5, false);
/* 3232 */           set(6, true);
/*      */           return;
/*      */       } 
/*      */       
/* 3236 */       set(4, false);
/* 3237 */       set(5, false);
/* 3238 */       set(6, false);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private MCRow.Status status() {
/* 3244 */       if (get(6)) {
/* 3245 */         return MCRow.DELETE;
/*      */       }
/* 3247 */       boolean v4 = get(4);
/* 3248 */       boolean v5 = get(5);
/* 3249 */       if (v4) {
/* 3250 */         return v5 ? MCRow.MODIFY : MCRow.GUICREATE;
/*      */       }
/* 3252 */       return v5 ? MCRow.CREATE : MCRow.NONE;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3263 */     private int _gui_index = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3271 */     private int _param_index = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3279 */     private int _param_rowindex = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3287 */     private MCTimestamp _reftime = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private RootRowInfo() {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private PointerBundle pb() {
/* 3308 */     return (this._pb != null) ? this._pb : (this._pb = new PointerBundle(null));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final class PointerBundle
/*      */     implements Serializable
/*      */   {
/* 3325 */     private Map<MCJoinKey<?>, MCList<?>> _joins = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3332 */     private Object _relation_key_own = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3339 */     private Object _relation_key = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private PointerBundle() {}
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean isGUICreated() {
/* 3350 */     return getRootRow().ri().guicreate();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean isGUIModified() {
/* 3361 */     return getRootRow().ri().guimodify();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean isGUIDeleted() {
/* 3372 */     return getRootRow().ri().guidelete();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void setGUICreated(boolean on) {
/* 3383 */     MCRow root = getRootRow();
/* 3384 */     root.ri().guicreate(on);
/* 3385 */     root.setStatusByGUIFlug();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void setGUIModified(boolean on) {
/* 3396 */     MCRow root = getRootRow();
/* 3397 */     root.ri().guimodify(on);
/* 3398 */     root.setStatusByGUIFlug();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void setGUIDeleted(boolean on) {
/* 3409 */     MCRow root = getRootRow();
/* 3410 */     root.ri().guidelete(on);
/* 3411 */     root.setStatusByGUIFlug();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void setGUINone() {
/* 3421 */     MCRow root = getRootRow();
/* 3422 */     RootRowInfo ri = root.ri();
/*      */     
/* 3424 */     ri.guicreate(false);
/* 3425 */     ri.guimodify(false);
/* 3426 */     ri.guidelete(false);
/* 3427 */     root.setStatusByGUIFlug();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void setStatusByGUIFlug() {
/* 3471 */     MCRow root = getRootRow();
/* 3472 */     RootRowInfo ri = root.ri();
/* 3473 */     Status status = Status.NONE;
/* 3474 */     if (ri.guidelete()) {
/* 3475 */       status = Status.DELETE;
/*      */     
/*      */     }
/* 3478 */     else if (ri.guimodify()) {
/* 3479 */       if (ri.guicreate()) {
/* 3480 */         status = Status.CREATE;
/*      */       } else {
/*      */         
/* 3483 */         status = Status.MODIFY;
/*      */       } 
/*      */     } 
/*      */     
/* 3487 */     setRootStatusWithEvent(root, status);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getGUIIndex() {
/* 3506 */     MCRow root = getRootRow();
/* 3507 */     return (root.ri())._gui_index;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int setGUIIndex(int index) {
/* 3519 */     MCRow root = getRootRow();
/* 3520 */     int oldindex = (root.ri())._gui_index;
/* 3521 */     (root.ri())._gui_index = index;
/* 3522 */     return oldindex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setGUIVisible(boolean visible) {
/* 3534 */     MCRow root = getRootRow();
/* 3535 */     root.ri().guivisible(visible);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isGUIVisible() {
/* 3546 */     MCRow root = getRootRow();
/* 3547 */     return root.ri().guivisible();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getParamIndex() {
/* 3568 */     MCRow root = getRootRow();
/* 3569 */     return (root.ri())._param_index;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int setParamIndex(int index) {
/* 3582 */     MCRow root = getRootRow();
/* 3583 */     int oldindex = (root.ri())._param_index;
/* 3584 */     (root.ri())._param_index = index;
/* 3585 */     return oldindex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getParamRowIndex() {
/* 3596 */     MCRow root = getRootRow();
/* 3597 */     return (root.ri())._param_rowindex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int setParamRowIndex(int index) {
/* 3609 */     MCRow root = getRootRow();
/* 3610 */     int oldindex = (root.ri())._param_rowindex;
/* 3611 */     (root.ri())._param_rowindex = index;
/* 3612 */     return oldindex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getParamColIndexNE(String name) {
/* 3626 */     return getParamColIndex(name, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getParamColIndex(String name) {
/* 3638 */     return getParamColIndex(name, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int getParamColIndex(String name, boolean ne) {
/*      */     int index;
/* 3653 */     if ((index = MCConstColumnList.indexOf(this, name)) > -1) {
/* 3654 */       return getConstParamColIndex(index, name, 
/* 3655 */           MCConstColumnList.meta(this, index).type());
/*      */     }
/*      */     
/* 3658 */     ColumnPath cp = new ColumnPath(name);
/* 3659 */     if (cp.row != this) {
/* 3660 */       return cp.row.getParamColIndex(cp.name);
/*      */     }
/*      */     
/* 3663 */     if ((index = indexOfAlias(this._list, name)) > -1) {
/* 3664 */       ColumnPath cp2 = this._list.getColumnPath(this, index);
/* 3665 */       MCRow row = cp2.row;
/* 3666 */       MCContainerMeta meta = cp2.getConstMeta();
/* 3667 */       index = MCConstColumnList.indexOf(row, meta);
/* 3668 */       return row.getConstParamColIndex(index, meta.name(), meta.type());
/*      */     } 
/*      */     
/* 3671 */     if ((index = indexOf(this._tmpcols, name)) > -1) {
/* 3672 */       return getTempParamColIndex(index, name);
/*      */     }
/*      */     
/* 3675 */     if (ne) {
/* 3676 */       return -1;
/*      */     }
/*      */ 
/*      */     
/* 3680 */     throw throw_ColumnNotFound(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int getConstParamColIndex(int i, String n, MCDataType t) {
/* 3698 */     return MCConstColumnList.paramColIndex(this, i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int getTempParamColIndex(int index, String name) {
/* 3711 */     return createTmpColList().paramColIndex(index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int setParamColIndexNE(String name, int pi) {
/* 3726 */     return setParamColIndex(name, pi, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int setParamColIndex(String name, int pi) {
/* 3739 */     return setParamColIndex(name, pi, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int setParamColIndex(String name, int pi, boolean ne) {
/*      */     int index;
/* 3755 */     if ((index = MCConstColumnList.indexOf(this, name)) > -1) {
/* 3756 */       return setConstParamColIndex(index, name, 
/* 3757 */           MCConstColumnList.meta(this, index).type(), pi);
/*      */     }
/*      */     
/* 3760 */     ColumnPath cp = new ColumnPath(name);
/* 3761 */     if (cp.row != this) {
/* 3762 */       return cp.row.setParamColIndex(cp.name, pi);
/*      */     }
/*      */     
/* 3765 */     if ((index = indexOfAlias(this._list, name)) > -1) {
/* 3766 */       ColumnPath cp2 = this._list.getColumnPath(this, index);
/* 3767 */       MCRow row = cp2.row;
/* 3768 */       MCContainerMeta meta = cp2.getConstMeta();
/* 3769 */       index = MCConstColumnList.indexOf(row, meta);
/* 3770 */       return row.setConstParamColIndex(index, meta.name(), meta.type(), pi);
/*      */     } 
/*      */     
/* 3773 */     if ((index = indexOf(this._tmpcols, name)) > -1) {
/* 3774 */       return setTempParamColIndex(index, name, pi);
/*      */     }
/*      */     
/* 3777 */     if (ne) {
/* 3778 */       return -1;
/*      */     }
/*      */ 
/*      */     
/* 3782 */     throw throw_ColumnNotFound(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int setConstParamColIndex(int i, String n, MCDataType t, int pi) {
/* 3801 */     return MCConstColumnList.setParamColIndex(this, i, t, pi);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int setTempParamColIndex(int index, String name, int pi) {
/* 3815 */     return createTmpColList().setParamColIndex(index, pi);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final MCTimestamp getRefTime() {
/* 3836 */     MCRow root = getRootRow();
/* 3837 */     return (root.ri())._reftime;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final MCTimestamp setRefTime(MCTimestamp time) {
/* 3850 */     MCRow root = getRootRow();
/* 3851 */     MCTimestamp oldtime = (root.ri())._reftime;
/* 3852 */     (root.ri())._reftime = time;
/* 3853 */     return oldtime;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final Object getRelationKey() {
/* 3872 */     if ((pb())._relation_key_own == null) {
/* 3873 */       (pb())._relation_key_own = new Object();
/*      */     }
/* 3875 */     return (pb())._relation_key_own;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void relateContainer(MCRow row) {
/* 3886 */     if (row == null) {
/* 3887 */       if (this._pb != null) {
/* 3888 */         this._pb._relation_key = null;
/*      */       }
/*      */     } else {
/*      */       
/* 3892 */       (pb())._relation_key = row.getRelationKey();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean isRelationContainer(MCRow row) {
/* 3905 */     if (row == null || this._pb == null || this._pb._relation_key == null) {
/* 3906 */       return false;
/*      */     }
/* 3908 */     return (this._pb._relation_key == row.getRelationKey());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getConstColIndex(String name) {
/* 3924 */     int index = MCConstColumnList.indexOf(this, name);
/* 3925 */     if (index > -1) {
/* 3926 */       return index;
/*      */     }
/*      */ 
/*      */     
/* 3930 */     index = indexOfAlias(this._list, name);
/* 3931 */     if (index > -1) {
/* 3932 */       ColumnPath cp = this._list.getColumnPath(this, index);
/* 3933 */       MCRow row = cp.row;
/* 3934 */       if (row == this) {
/* 3935 */         MCContainerMeta meta = cp.getConstMeta();
/* 3936 */         return MCConstColumnList.indexOf(row, meta);
/*      */       } 
/*      */     } 
/*      */     
/* 3940 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setConstString(int index, String name, String value) {
/* 3972 */     MCConstColumnList.set(this, index, name, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setConstNumber(int index, String name, MCNumber value) {
/* 4004 */     MCConstColumnList.set(this, index, name, (Comparable<?>)value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setConstNumber(int index, String name, int value) {
/* 4020 */     MCConstColumnList.set(this, index, name, (Comparable<?>)MCNumber.valueOf(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setConstNumber(int index, String name, long value) {
/* 4036 */     MCConstColumnList.set(this, index, name, (Comparable<?>)MCNumber.valueOf(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setConstNumber(int index, String name, float value) {
/* 4052 */     MCConstColumnList.set(this, index, name, (Comparable<?>)MCNumber.valueOf(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setConstNumber(int index, String name, double value) {
/* 4068 */     MCConstColumnList.set(this, index, name, (Comparable<?>)MCNumber.valueOf(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setConstDate(int index, String name, MCDate value) {
/* 4100 */     MCConstColumnList.set(this, index, name, (Comparable<?>)value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setConstTimestamp(int index, String name, MCTimestamp value) {
/* 4132 */     MCConstColumnList.set(this, index, name, (Comparable<?>)value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setConstBoolean(int index, String name, boolean value) {
/* 4164 */     MCConstColumnList.set(this, index, name, Boolean.valueOf(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setConstBinary(int index, String name, MCBinary value) {
/* 4196 */     MCConstColumnList.set(this, index, name, (Comparable<?>)value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private class ColumnPath
/*      */   {
/* 4227 */     private String name = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4234 */     private MCRow row = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     ColumnPath(String path) {
/* 4256 */       this(MCRow.this, path);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     ColumnPath(MCRow row, String path) {
/* 4272 */       init(row, path);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     final void init(MCRow row, String path) {
/* 4288 */       if (row == null)
/*      */       {
/* 4290 */         throw new MCException(Core_Msg_FW_A.FCBBC0072, new Object[0]);
/*      */       }
/* 4292 */       if (path == null)
/*      */       {
/* 4294 */         throw new MCException(Core_Msg_FW_A.FCBBC0073, new Object[0]);
/*      */       }
/*      */       
/* 4297 */       MCRow target = row;
/* 4298 */       ColumnPath a_cp = null;
/* 4299 */       int str = 0;
/* 4300 */       int end = 0;
/* 4301 */       while ((end = path.indexOf(".", str)) > -1) {
/* 4302 */         String part = path.substring(str, end);
/*      */ 
/*      */         
/* 4305 */         if ((a_cp = analyzeAlias(target, part)) != null) {
/* 4306 */           target = a_cp.row;
/* 4307 */           part = a_cp.name;
/*      */         } 
/*      */         
/*      */         try {
/* 4311 */           target = target.getInnerRow(part);
/*      */         }
/* 4313 */         catch (Exception ex) {
/* 4314 */           throw new MCException(ex, Core_Msg_FW_A.FCBBC0051, new Object[] { this.this$0.msgBindClassName(), 
/* 4315 */                 path, part });
/*      */         } 
/* 4317 */         str = end + 1;
/*      */       } 
/* 4319 */       String name = path.substring(str);
/*      */ 
/*      */       
/* 4322 */       if ((a_cp = analyzeAlias(target, name)) != null) {
/* 4323 */         target = a_cp.row;
/* 4324 */         name = a_cp.name;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 4329 */       this.name = name;
/* 4330 */       this.row = target;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private ColumnPath analyzeAlias(MCRow target, String name) {
/* 4343 */       ColumnPath cp = null;
/* 4344 */       int idx = MCRow.indexOfAlias(target._list, name);
/* 4345 */       if (idx > -1)
/*      */       {
/* 4347 */         cp = target._list.getColumnPath(target, idx);
/*      */       }
/* 4349 */       return cp;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     final MCContainerMeta getConstMeta() {
/* 4361 */       return (this.row != null) ? MCConstColumnList.meta(this.row, this.name) : null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     final MCContainerMeta getTempMeta() {
/* 4373 */       return (this.row != null && this.row._tmpcols != null) ? this.row._tmpcols.meta(this.name) : null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     final MCContainerMeta getMeta() {
/* 4384 */       MCContainerMeta meta = getConstMeta();
/* 4385 */       return (meta != null) ? meta : getTempMeta();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     ColumnPath() {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final MCMeta[] getConstMetaArray() {
/* 4399 */     return (MCMeta[])MCConstColumnList.metas(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final MCMeta[] getTempMetaArray() {
/* 4412 */     return (this._tmpcols != null) ? (MCMeta[])this._tmpcols.getMetaArray() : new MCMeta[0];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final MCMeta[] getMetaArray() {
/* 4427 */     MCMeta[] c = getConstMetaArray();
/* 4428 */     MCMeta[] t = getTempMetaArray();
/* 4429 */     MCMeta[] all = new MCMeta[c.length + t.length];
/* 4430 */     System.arraycopy(c, 0, all, 0, c.length);
/* 4431 */     System.arraycopy(t, 0, all, c.length, t.length);
/* 4432 */     return all;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String[] getConstNameArray() {
/* 4445 */     return MCConstColumnList.getNameArray(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String[] getTempNameArray() {
/* 4458 */     return (this._tmpcols != null) ? this._tmpcols.getNameArray() : new String[0];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String[] getNameArray() {
/* 4473 */     String[] c = getConstNameArray();
/* 4474 */     String[] t = getTempNameArray();
/* 4475 */     String[] all = new String[c.length + t.length];
/* 4476 */     System.arraycopy(c, 0, all, 0, c.length);
/* 4477 */     System.arraycopy(t, 0, all, c.length, t.length);
/* 4478 */     return all;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getRealColumnPath(String name) {
/*      */     ColumnPath cp;
/* 4498 */     if (name == null) {
/* 4499 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 4505 */       cp = new ColumnPath(name);
/*      */     }
/* 4507 */     catch (MCException mCException) {
/*      */       
/* 4509 */       return null;
/*      */     } 
/* 4511 */     if (cp.row.getMeta(cp.name) == null)
/*      */     {
/* 4513 */       return null;
/*      */     }
/*      */ 
/*      */     
/* 4517 */     String rcol = cp.row.getRootRowColumnPath();
/* 4518 */     String path = createColumnPath(new String[] { rcol, ColumnPath.access$1(cp) });
/*      */ 
/*      */     
/* 4521 */     String rowpath = getParentRowColumnPath();
/* 4522 */     if (rowpath != null) {
/* 4523 */       path = path.replace(String.valueOf(rowpath) + ".", "");
/*      */     }
/*      */     
/* 4526 */     return path;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String[] getConstColumnPathArray() {
/* 4544 */     List<String> list = getColumnPathList(null, false);
/* 4545 */     return list.<String>toArray(new String[list.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String[] getColumnPathArray() {
/* 4566 */     List<String> list = getColumnPathList(null, true);
/* 4567 */     return list.<String>toArray(new String[list.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final List<String> getColumnPathList(String pp, boolean addtemp) {
/* 4584 */     List<String> pl = new ArrayList<>();
/*      */     
/* 4586 */     int l = MCConstColumnList.size(this); int i;
/* 4587 */     for (i = 0; i < l; i++) {
/* 4588 */       MCContainerMeta m = MCConstColumnList.meta(this, i);
/* 4589 */       String n = m.name();
/* 4590 */       if (m.type() == MCDataType.ROW) {
/* 4591 */         String ip = (pp != null) ? createColumnPath(new String[] { pp, n }) : n;
/* 4592 */         MCRow io = (MCRow)MCConstColumnList.get(this, i);
/* 4593 */         pl.addAll(io.getColumnPathList(ip, addtemp));
/*      */       } else {
/*      */         
/* 4596 */         pl.add((pp != null) ? createColumnPath(new String[] { pp, n }) : n);
/*      */       } 
/*      */     } 
/*      */     
/* 4600 */     if (addtemp && this._tmpcols != null) {
/* 4601 */       l = this._tmpcols.size();
/* 4602 */       for (i = 0; i < l; i++) {
/* 4603 */         MCContainerMeta m = this._tmpcols.meta(i);
/* 4604 */         String n = m.name();
/* 4605 */         if (m.type() == MCDataType.ROW) {
/* 4606 */           String ip = (pp != null) ? createColumnPath(new String[] { pp, n }) : n;
/* 4607 */           MCRow io = (MCRow)this._tmpcols.get(i);
/* 4608 */           pl.addAll(io.getColumnPathList(ip, addtemp));
/*      */         } else {
/*      */           
/* 4611 */           pl.add((pp != null) ? createColumnPath(new String[] { pp, n }) : n);
/*      */         } 
/*      */       } 
/*      */     } 
/* 4615 */     return pl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String[] getAliasArray() {
/* 4628 */     return this._list.toAliasNameArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String[] getAlias(String name) {
/* 4650 */     if (name == null) {
/* 4651 */       return new String[0];
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4657 */     List<String> list = new ArrayList<>();
/*      */ 
/*      */     
/* 4660 */     String real = getRealColumnPath(name);
/* 4661 */     if (real != null) {
/*      */       
/* 4663 */       String[] aliases = this._list._name; byte b; int i; String[] arrayOfString1;
/* 4664 */       for (i = (arrayOfString1 = aliases).length, b = 0; b < i; ) { String alias = arrayOfString1[b];
/* 4665 */         String path = getRealColumnPath(alias);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4670 */         if (path != null && path.equalsIgnoreCase(real))
/* 4671 */           list.add(alias); 
/*      */         b++; }
/*      */     
/*      */     } 
/* 4675 */     return list.<String>toArray(new String[list.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final MCMeta getConstMeta(String name) {
/* 4691 */     if (name == null) {
/* 4692 */       return null;
/*      */     }
/*      */     
/*      */     try {
/*      */       MCMeta m;
/* 4697 */       if ((m = MCConstColumnList.meta(this, name)) != null) {
/* 4698 */         return m;
/*      */       }
/*      */       
/* 4701 */       if ((m = aliasMeta(this, name)) != null) {
/* 4702 */         return m;
/*      */       }
/*      */       
/* 4705 */       ColumnPath cp = new ColumnPath(name);
/* 4706 */       if (cp.row != this) {
/* 4707 */         m = cp.getConstMeta();
/*      */       }
/* 4709 */       return m;
/*      */     }
/* 4711 */     catch (MCException mCException) {
/*      */       
/* 4713 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final MCMeta getTempMeta(String name) {
/* 4730 */     if (name == null) {
/* 4731 */       return null;
/*      */     }
/*      */     try {
/* 4734 */       MCMeta m = null;
/*      */       
/* 4736 */       if ((m = meta(this._tmpcols, name)) != null) {
/* 4737 */         return m;
/*      */       }
/*      */       
/* 4740 */       ColumnPath cp = new ColumnPath(name);
/* 4741 */       if (cp.row != this) {
/* 4742 */         m = cp.getTempMeta();
/*      */       }
/* 4744 */       return m;
/*      */     }
/* 4746 */     catch (MCException mCException) {
/*      */       
/* 4748 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final MCMeta getMeta(String name) {
/* 4764 */     if (name == null) {
/* 4765 */       return null;
/*      */     }
/*      */     try {
/* 4768 */       MCMeta m = null;
/*      */       
/* 4770 */       if ((m = MCConstColumnList.meta(this, name)) != null) {
/* 4771 */         return m;
/*      */       }
/*      */       
/* 4774 */       if ((m = aliasMeta(this, name)) != null) {
/* 4775 */         return m;
/*      */       }
/*      */       
/* 4778 */       if ((m = meta(this._tmpcols, name)) != null) {
/* 4779 */         return m;
/*      */       }
/*      */       
/* 4782 */       ColumnPath cp = new ColumnPath(name);
/* 4783 */       if (cp.row != this) {
/* 4784 */         m = cp.getMeta();
/*      */       }
/* 4786 */       return m;
/*      */     }
/* 4788 */     catch (MCException mCException) {
/*      */       
/* 4790 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean containsConst(String name) {
/* 4803 */     return (getConstMeta(name) != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean containsTemp(String name) {
/* 4815 */     return (getTempMeta(name) != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean contains(String name) {
/* 4829 */     return (getMeta(name) != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int constSize() {
/* 4840 */     return MCConstColumnList.size(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int tempSize() {
/* 4851 */     return (this._tmpcols != null) ? this._tmpcols.size() : 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int size() {
/* 4864 */     return constSize() + tempSize();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4880 */   private static final Comparable<?> _NOT_FOUND_COL = "not found";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final Comparable<?> getValue(String name, MCDataType type) {
/* 4902 */     Comparable<?> implval = getValueImpl(name, type);
/* 4903 */     if (implval != _NOT_FOUND_COL) {
/* 4904 */       return implval;
/*      */     }
/*      */ 
/*      */     
/* 4908 */     ColumnPath cp = new ColumnPath(name);
/* 4909 */     if (cp.row != this) {
/* 4910 */       return cp.row.getValue(cp.name, type);
/*      */     }
/*      */ 
/*      */     
/* 4914 */     throw throw_ColumnNotFound(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final Comparable<?> getValueNE(String name, MCDataType type) {
/* 4940 */     Comparable<?> implval = getValueImpl(name, type);
/* 4941 */     if (implval != _NOT_FOUND_COL) {
/* 4942 */       return implval;
/*      */     }
/*      */ 
/*      */     
/* 4946 */     ColumnPath cp = new ColumnPath(name);
/* 4947 */     if (cp.row != this) {
/* 4948 */       return cp.row.getValueNE(cp.name, type);
/*      */     }
/*      */ 
/*      */     
/* 4952 */     Comparable<?> val = (type != MCDataType.BOOLEAN) ? MCColumnList.INIT_COLUMN_VAL : 
/* 4953 */       MCColumnList.INIT_BOOLEAN_VAL;
/* 4954 */     return type.cast(val);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Comparable<?> getValueImpl(String name, MCDataType type) {
/*      */     int index;
/* 4977 */     if ((index = MCConstColumnList.indexOf(this, name)) > -1) {
/* 4978 */       return getConstValue(index, name, type);
/*      */     }
/*      */     
/* 4981 */     if ((index = indexOfAlias(this._list, name)) > -1) {
/* 4982 */       ColumnPath cp = this._list.getColumnPath(this, index);
/* 4983 */       MCRow row = cp.row;
/* 4984 */       MCContainerMeta meta = cp.getConstMeta();
/* 4985 */       index = MCConstColumnList.indexOf(row, meta);
/* 4986 */       return row.getConstValue(index, name, type);
/*      */     } 
/*      */     
/* 4989 */     if ((index = indexOf(this._tmpcols, name)) > -1) {
/* 4990 */       return getTempValue(index, name, type);
/*      */     }
/* 4992 */     return _NOT_FOUND_COL;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final Comparable<?> getConstValue(int i, String n, MCDataType y) {
/*      */     try {
/* 5010 */       return MCConstColumnList.getchkval(this, i, y);
/*      */     }
/* 5012 */     catch (MCException ex) {
/*      */       
/* 5014 */       throw new MCException(ex, Core_Msg_FW_A.FCBBC0019, new Object[] { msgBindClassName(), n });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final Comparable<?> getTempValue(int index, String name, MCDataType type) {
/*      */     try {
/* 5033 */       return (this._tmpcols != null) ? this._tmpcols.getchkval(index, type) : null;
/*      */     }
/* 5035 */     catch (MCException ex) {
/*      */       
/* 5037 */       throw new MCException(ex, Core_Msg_FW_A.FCBBC0020, new Object[] { msgBindClassName(), name });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void setValue(String name, MCDataType type, Comparable<?> val) {
/* 5065 */     if (setValueImpl(name, type, val)) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 5070 */     ColumnPath cp = new ColumnPath(name);
/* 5071 */     if (cp.row != this) {
/* 5072 */       cp.row.setValue(cp.name, type, val);
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 5077 */     throw throw_ColumnNotFound(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void setValueNE(String name, MCDataType type, Comparable<?> val) {
/* 5105 */     if (setValueImpl(name, type, val)) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 5110 */     ColumnPath cp = new ColumnPath(name);
/* 5111 */     if (cp.row != this) {
/* 5112 */       cp.row.setValueNE(cp.name, type, val);
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 5117 */     addValueColumn(name, type, val);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean setValueImpl(String name, MCDataType type, Comparable<?> val) {
/*      */     int index;
/* 5144 */     if ((index = MCConstColumnList.indexOf(this, name)) > -1) {
/* 5145 */       setConstValue(index, name, type, val);
/* 5146 */       return true;
/*      */     } 
/*      */     
/* 5149 */     if ((index = indexOfAlias(this._list, name)) > -1) {
/* 5150 */       ColumnPath cp = this._list.getColumnPath(this, index);
/* 5151 */       MCRow row = cp.row;
/* 5152 */       MCContainerMeta meta = cp.getConstMeta();
/* 5153 */       index = MCConstColumnList.indexOf(row, meta);
/*      */       
/* 5155 */       row.setConstValue(index, meta.name(), type, val);
/* 5156 */       return true;
/*      */     } 
/*      */     
/* 5159 */     if ((index = indexOf(this._tmpcols, name)) > -1) {
/* 5160 */       setTempValue(index, name, type, val);
/* 5161 */       return true;
/*      */     } 
/*      */     
/* 5164 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void setConstValue(int i, String n, MCDataType y, Comparable<?> v) {
/* 5186 */     MCConstColumnList.setchkval(this, i, n, y, v);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void setTempValue(int index, String name, MCDataType type, Comparable<?> val) {
/* 5207 */     createTmpColList().setchkval(index, name, type, val);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final MCException throw_ColumnNotFound(String name) {
/* 5219 */     return new MCException(Core_Msg_FW_A.FCBBC0068, new Object[] { msgBindClassName(), name });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Comparable<?> getValue(String name) {
/* 5245 */     Comparable<?> implval = getValueImpl(name);
/* 5246 */     if (implval != _NOT_FOUND_COL) {
/* 5247 */       return implval;
/*      */     }
/*      */ 
/*      */     
/* 5251 */     ColumnPath cp = new ColumnPath(name);
/* 5252 */     if (cp.row != this) {
/* 5253 */       return cp.row.getValue(cp.name);
/*      */     }
/*      */ 
/*      */     
/* 5257 */     throw throw_ColumnNotFound(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Comparable<?> getValueNE(String name) {
/* 5282 */     Comparable<?> implval = getValueImpl(name);
/* 5283 */     if (implval != _NOT_FOUND_COL) {
/* 5284 */       return implval;
/*      */     }
/*      */ 
/*      */     
/* 5288 */     ColumnPath cp = new ColumnPath(name);
/* 5289 */     if (cp.row != this) {
/* 5290 */       return cp.row.getValueNE(cp.name);
/*      */     }
/*      */ 
/*      */     
/* 5294 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Comparable<?> getValueImpl(String name) {
/*      */     int index;
/* 5316 */     if ((index = MCConstColumnList.indexOf(this, name)) > -1) {
/* 5317 */       return getConstValue(index, name, MCConstColumnList.meta(this, index).type());
/*      */     }
/*      */ 
/*      */     
/* 5321 */     if ((index = indexOfAlias(this._list, name)) > -1) {
/* 5322 */       ColumnPath cp = this._list.getColumnPath(this, index);
/* 5323 */       MCRow row = cp.row;
/* 5324 */       MCContainerMeta meta = cp.getConstMeta();
/* 5325 */       MCDataType type = meta.type();
/* 5326 */       index = MCConstColumnList.indexOf(row, meta);
/* 5327 */       return row.getConstValue(index, name, type);
/*      */     } 
/*      */ 
/*      */     
/* 5331 */     if ((index = indexOf(this._tmpcols, name)) > -1) {
/* 5332 */       return getTempValue(index, name, this._tmpcols.meta(index).type());
/*      */     }
/*      */     
/* 5335 */     return _NOT_FOUND_COL;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   Comparable<?> getTempValue(String name) {
/*      */     int index;
/* 5342 */     if ((index = indexOf(this._tmpcols, name)) > -1) {
/* 5343 */       return getTempValue(index, name, this._tmpcols.meta(index).type());
/*      */     }
/*      */ 
/*      */     
/* 5347 */     ColumnPath cp = new ColumnPath(name);
/* 5348 */     if (cp.row != this) {
/* 5349 */       return cp.row.getTempValue(cp.name);
/*      */     }
/*      */ 
/*      */     
/* 5353 */     throw throw_ColumnNotFound(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setValue(String name, Comparable<?> val) {
/* 5379 */     if (setValueImpl(name, val)) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 5384 */     ColumnPath cp = new ColumnPath(name);
/* 5385 */     if (cp.row != this) {
/* 5386 */       cp.row.setValue(cp.name, val);
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 5391 */     throw throw_ColumnNotFound(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setValueNE(String name, Comparable<?> val) {
/* 5422 */     if (setValueImpl(name, val)) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 5427 */     ColumnPath cp = new ColumnPath(name);
/* 5428 */     if (cp.row != this) {
/* 5429 */       cp.row.setValueNE(cp.name, val);
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 5434 */     if (val != null) {
/* 5435 */       MCDataType type = MCDataType.analyze(val);
/* 5436 */       if (type == null)
/*      */       {
/* 5438 */         throw new MCException(Core_Msg_FW_A.FCBBC0066, new Object[] { msgBindClassName(), name, 
/* 5439 */               val.getClass().getName() });
/*      */       }
/* 5441 */       addValueColumn(name, type, val);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean setValueImpl(String name, Comparable<?> val) {
/*      */     int index;
/* 5468 */     if ((index = MCConstColumnList.indexOf(this, name)) > -1) {
/* 5469 */       setConstValue(index, name, MCConstColumnList.meta(this, index).type(), val);
/* 5470 */       return true;
/*      */     } 
/*      */     
/* 5473 */     if ((index = indexOfAlias(this._list, name)) > -1) {
/* 5474 */       ColumnPath cp = this._list.getColumnPath(this, index);
/* 5475 */       MCRow row = cp.row;
/* 5476 */       MCContainerMeta meta = cp.getConstMeta();
/* 5477 */       MCDataType type = meta.type();
/* 5478 */       index = MCConstColumnList.indexOf(row, meta);
/*      */       
/* 5480 */       row.setConstValue(index, meta.name(), type, val);
/* 5481 */       return true;
/*      */     } 
/*      */     
/* 5484 */     if ((index = indexOf(this._tmpcols, name)) > -1) {
/* 5485 */       setTempValue(index, name, this._tmpcols.meta(index).type(), val);
/* 5486 */       return true;
/*      */     } 
/*      */     
/* 5489 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(String name) {
/* 5512 */     return (String)getValue(name, MCDataType.STRING);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getStringNE(String name) {
/* 5532 */     return (String)getValueNE(name, MCDataType.STRING);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setString(String name, String value) {
/* 5551 */     setValue(name, MCDataType.STRING, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStringNE(String name, String value) {
/* 5571 */     setValueNE(name, MCDataType.STRING, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber getNumber(String name) {
/* 5590 */     return (MCNumber)getValue(name, MCDataType.NUMBER);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber getNumberNE(String name) {
/* 5610 */     return (MCNumber)getValueNE(name, MCDataType.NUMBER);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNumber(String name, MCNumber value) {
/* 5635 */     setValue(name, MCDataType.NUMBER, (Comparable<?>)value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNumber(String name, int value) {
/* 5654 */     setValue(name, MCDataType.NUMBER, (Comparable<?>)MCNumber.valueOf(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNumber(String name, long value) {
/* 5673 */     setNumber(name, MCNumber.valueOf(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNumber(String name, float value) {
/* 5692 */     setNumber(name, MCNumber.valueOf(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNumber(String name, double value) {
/* 5711 */     setNumber(name, MCNumber.valueOf(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNumberNE(String name, MCNumber value) {
/* 5731 */     setValueNE(name, MCDataType.NUMBER, (Comparable<?>)value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNumberNE(String name, int value) {
/* 5751 */     setNumberNE(name, MCNumber.valueOf(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNumberNE(String name, long value) {
/* 5771 */     setNumberNE(name, MCNumber.valueOf(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNumberNE(String name, float value) {
/* 5791 */     setNumberNE(name, MCNumber.valueOf(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNumberNE(String name, double value) {
/* 5811 */     setNumberNE(name, MCNumber.valueOf(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCDate getDate(String name) {
/* 5830 */     return (MCDate)getValue(name, MCDataType.DATE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCDate getDateNE(String name) {
/* 5850 */     return (MCDate)getValueNE(name, MCDataType.DATE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDate(String name, MCDate value) {
/* 5869 */     setValue(name, MCDataType.DATE, (Comparable<?>)value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDateNE(String name, MCDate value) {
/* 5889 */     setValueNE(name, MCDataType.DATE, (Comparable<?>)value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCTimestamp getTimestamp(String name) {
/* 5908 */     return (MCTimestamp)getValue(name, MCDataType.TIMESTAMP);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCTimestamp getTimestampNE(String name) {
/* 5928 */     return (MCTimestamp)getValueNE(name, MCDataType.TIMESTAMP);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestamp(String name, MCTimestamp value) {
/* 5947 */     setValue(name, MCDataType.TIMESTAMP, (Comparable<?>)value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestampNE(String name, MCTimestamp value) {
/* 5967 */     setValueNE(name, MCDataType.TIMESTAMP, (Comparable<?>)value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBoolean(String name) {
/* 5986 */     return ((Boolean)getValue(name, MCDataType.BOOLEAN)).booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBooleanNE(String name) {
/* 6006 */     return ((Boolean)getValueNE(name, MCDataType.BOOLEAN)).booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBoolean(String name, boolean value) {
/* 6025 */     setValue(name, MCDataType.BOOLEAN, Boolean.valueOf(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBooleanNE(String name, boolean value) {
/* 6045 */     setValueNE(name, MCDataType.BOOLEAN, Boolean.valueOf(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCBinary getBinary(String name) {
/* 6064 */     return (MCBinary)getValue(name, MCDataType.BINARY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCBinary getBinaryNE(String name) {
/* 6084 */     return (MCBinary)getValueNE(name, MCDataType.BINARY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinary(String name, MCBinary value) {
/* 6103 */     setValue(name, MCDataType.BINARY, (Comparable<?>)value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryNE(String name, MCBinary value) {
/* 6123 */     setValueNE(name, MCDataType.BINARY, (Comparable<?>)value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCRow getInnerRow(String name) {
/* 6144 */     return (MCRow)getValue(name, MCDataType.ROW);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T extends MCRow> T getInnerRow(String name, Class<T> rowc) {
/* 6168 */     return (T)MCDataType.cast(rowc, getValue(name, MCDataType.ROW));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInnerRow(String name, MCRow value) {
/* 6196 */     setValue(name, MCDataType.ROW, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private enum ColumnType
/*      */   {
/* 6212 */     CONST_ROW, TEMP_ROW, NON;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final class ColumnDefinition
/*      */   {
/*      */     private final String name;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final MCContainerMeta meta;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final MCContainerMeta minedmeta;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final MCRow.ColumnType type;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final boolean isOwnColumn;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final ColumnDefinition innerRowDefinition;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final int index;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private ColumnDefinition(String name, MCContainerMeta meta, MCRow.ColumnType type, int index) {
/* 6265 */       this.name = name;
/* 6266 */       this.meta = meta;
/* 6267 */       this.type = type;
/* 6268 */       this.isOwnColumn = true;
/* 6269 */       this.innerRowDefinition = null;
/* 6270 */       this.minedmeta = meta;
/* 6271 */       this.index = index;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private ColumnDefinition(String name, ColumnDefinition innerRowDefinition) {
/* 6278 */       this.name = name;
/* 6279 */       this.meta = null;
/* 6280 */       this.type = null;
/* 6281 */       this.isOwnColumn = false;
/* 6282 */       this.innerRowDefinition = innerRowDefinition;
/*      */       
/* 6284 */       this.minedmeta = getMinedMeta(innerRowDefinition);
/* 6285 */       this.index = -1;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isNoDefine() {
/* 6294 */       return (this.type == MCRow.ColumnType.NON);
/*      */     }
/*      */     
/*      */     public MCMeta getMeta() {
/* 6298 */       return this.meta;
/*      */     }
/*      */ 
/*      */     
/*      */     private static final MCContainerMeta getMinedMeta(ColumnDefinition cd) {
/* 6303 */       ColumnDefinition c = cd;
/*      */       
/* 6305 */       while (c != null) {
/* 6306 */         if (c.isNoDefine()) {
/* 6307 */           return null;
/*      */         }
/* 6309 */         if (c.isOwnColumn() && c.type == MCRow.ColumnType.CONST_ROW) {
/* 6310 */           return c.meta;
/*      */         }
/* 6312 */         if (c.isOwnColumn() && c.type == MCRow.ColumnType.TEMP_ROW) {
/* 6313 */           return c.meta;
/*      */         }
/* 6315 */         c = c.innerRowDefinition;
/*      */       } 
/*      */       
/* 6318 */       return null;
/*      */     }
/*      */     
/*      */     MCMeta getMinedMeta() {
/* 6322 */       return this.minedmeta;
/*      */     }
/*      */     
/*      */     public String getName() {
/* 6326 */       return this.name;
/*      */     }
/*      */     
/*      */     public boolean isOwnColumn() {
/* 6330 */       return this.isOwnColumn;
/*      */     }
/*      */     
/*      */     public ColumnDefinition getInnerRowDefinition() {
/* 6334 */       return this.innerRowDefinition;
/*      */     }
/*      */ 
/*      */     
/*      */     public String toString() {
/* 6339 */       String metaName = (this.meta != null) ? this.meta.name() : "meta is null";
/* 6340 */       return String.valueOf(this.name) + "," + metaName + "," + this.type + "," + this.isOwnColumn + "," + this.index;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ColumnDefinition getColumnDefinition(String name) {
/* 6351 */     MCContainerMeta meta = null;
/* 6352 */     ColumnDefinition result = null;
/*      */     int index;
/* 6354 */     if ((index = MCConstColumnList.indexOf(this, name)) > -1) {
/*      */       
/* 6356 */       meta = MCConstColumnList.meta(this, index);
/* 6357 */       result = new ColumnDefinition(name, meta, ColumnType.CONST_ROW, index, null);
/*      */     }
/* 6359 */     else if ((index = indexOf(this._tmpcols, name)) > -1) {
/*      */       
/* 6361 */       meta = createTmpColList().meta(index);
/* 6362 */       result = new ColumnDefinition(name, meta, ColumnType.TEMP_ROW, index, null);
/*      */     } else {
/*      */       
/* 6365 */       ColumnPath cp = new ColumnPath(name);
/*      */       
/* 6367 */       if (cp.row == this) {
/*      */         
/* 6369 */         result = createNonColumnDefinition(name);
/*      */       }
/*      */       else {
/*      */         
/* 6373 */         result = new ColumnDefinition(name, cp.row.getColumnDefinition(cp.name), null);
/*      */       } 
/*      */     } 
/*      */     
/* 6377 */     return result;
/*      */   }
/*      */   
/*      */   ColumnDefinition getColumnDefinitionNE(String name) {
/* 6381 */     if (containsConst(name)) {
/* 6382 */       return getColumnDefinition(name);
/*      */     }
/* 6384 */     return createNonColumnDefinition(name);
/*      */   }
/*      */   
/*      */   ColumnDefinition createNonColumnDefinition(String name) {
/* 6388 */     return new ColumnDefinition(name, null, ColumnType.NON, -1, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ColumnDefinition getColumnDefinition(ColumnDefinition before) {
/* 6398 */     MCContainerMeta meta = null;
/* 6399 */     ColumnDefinition result = null;
/*      */     
/* 6401 */     if (before.type != ColumnType.NON) {
/* 6402 */       return before;
/*      */     }
/*      */     
/* 6405 */     if (before.isOwnColumn) {
/* 6406 */       int index; if ((index = indexOf(this._tmpcols, before.name)) > -1) {
/*      */         
/* 6408 */         meta = createTmpColList().meta(index);
/* 6409 */         result = new ColumnDefinition(before.name, meta, ColumnType.TEMP_ROW, 
/* 6410 */             index, null);
/*      */       } else {
/*      */         
/* 6413 */         result = before;
/*      */       } 
/*      */     } else {
/*      */       
/* 6417 */       ColumnPath cp = new ColumnPath(before.name);
/* 6418 */       result = new ColumnDefinition(before.name, 
/* 6419 */           cp.row.getColumnDefinition(before), null);
/*      */     } 
/*      */     
/* 6422 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Comparable<?> getValueNE(ColumnDefinition columnDefinition) {
/* 6431 */     if (columnDefinition.isNoDefine()) {
/* 6432 */       return null;
/*      */     }
/* 6434 */     if (columnDefinition.isOwnColumn && 
/* 6435 */       columnDefinition.type == ColumnType.CONST_ROW) {
/* 6436 */       return getConstValue(columnDefinition.index, columnDefinition.getName(), 
/* 6437 */           columnDefinition.getMeta().type());
/*      */     }
/* 6439 */     if (isTmpColumn(columnDefinition)) {
/* 6440 */       return getTempValue(columnDefinition.index, columnDefinition.getName(), 
/* 6441 */           columnDefinition.getMeta().type());
/*      */     }
/*      */     
/* 6444 */     ColumnPath cp = new ColumnPath(columnDefinition.name);
/* 6445 */     return cp.row.getValueNE(columnDefinition.innerRowDefinition);
/*      */   }
/*      */ 
/*      */   
/*      */   static Comparable<?> getValueNE(ColumnDefinition cd, String name, MCRow row) {
/* 6450 */     if (cd == null) {
/* 6451 */       return row.getValueNE(name);
/*      */     }
/* 6453 */     if (!cd.isNoDefine()) {
/* 6454 */       return row.getValueNE(cd);
/*      */     }
/*      */     
/* 6457 */     return row.getValueNE(name);
/*      */   }
/*      */ 
/*      */   
/*      */   static Comparable<?> getValue(ColumnDefinition cd, String name, MCRow row) {
/* 6462 */     if (cd == null) {
/* 6463 */       return row.getValue(name);
/*      */     }
/* 6465 */     if (!cd.isNoDefine()) {
/* 6466 */       return row.getValueNE(cd);
/*      */     }
/*      */     
/* 6469 */     return row.getValue(name);
/*      */   }
/*      */ 
/*      */   
/*      */   static MCMeta getMeta(ColumnDefinition cd, String name, MCRow row) {
/* 6474 */     if (cd == null) {
/* 6475 */       return row.getMeta(name);
/*      */     }
/* 6477 */     if (!cd.isNoDefine()) {
/* 6478 */       return cd.getMinedMeta();
/*      */     }
/*      */     
/* 6481 */     return row.getMeta(name);
/*      */   }
/*      */ 
/*      */   
/*      */   static boolean isTmpColumn(ColumnDefinition columnDefinition) {
/* 6486 */     if (columnDefinition == null || columnDefinition.isNoDefine()) {
/* 6487 */       return false;
/*      */     }
/* 6489 */     if (columnDefinition.isOwnColumn) {
/* 6490 */       return (columnDefinition.type == ColumnType.TEMP_ROW);
/*      */     }
/*      */     
/* 6493 */     return isTmpColumn(columnDefinition.getInnerRowDefinition());
/*      */   }
/*      */ 
/*      */   
/*      */   static boolean isTempOrNoDefineColumn(ColumnDefinition columnDefinition) {
/* 6498 */     if (columnDefinition == null || columnDefinition.isNoDefine()) {
/* 6499 */       return true;
/*      */     }
/* 6501 */     if (columnDefinition.isOwnColumn) {
/* 6502 */       return (columnDefinition.type == ColumnType.TEMP_ROW);
/*      */     }
/*      */     
/* 6505 */     return isTempOrNoDefineColumn(columnDefinition.getInnerRowDefinition());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Comparable<?> getValue(ColumnDefinition columnDefinition) {
/* 6515 */     if (columnDefinition.isNoDefine()) {
/* 6516 */       throw throw_ColumnNotFound(columnDefinition.name);
/*      */     }
/* 6518 */     return getValueNE(columnDefinition);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setValue(ColumnDefinition columnDefinition, Comparable<?> value, MCDataType _type) {
/* 6529 */     if (columnDefinition.isOwnColumn) {
/* 6530 */       if (columnDefinition.type == ColumnType.CONST_ROW) {
/* 6531 */         MCConstColumnList.setchkval(this, columnDefinition.index, 
/* 6532 */             columnDefinition.name, columnDefinition.meta.type(), value);
/*      */       }
/* 6534 */       else if (columnDefinition.type == ColumnType.TEMP_ROW) {
/* 6535 */         createTmpColList().setchkval(columnDefinition.index, 
/* 6536 */             columnDefinition.name, columnDefinition.meta.type(), value);
/*      */       }
/*      */       else {
/*      */         
/* 6540 */         MCDataType type = null;
/* 6541 */         if (value != null) {
/* 6542 */           type = MCDataType.analyze(value);
/*      */         } else {
/*      */           
/* 6545 */           type = _type;
/*      */         } 
/*      */         
/* 6548 */         if (value != null && type == null)
/*      */         {
/* 6550 */           throw new MCException(Core_Msg_FW_A.FCBBC0066, new Object[] { msgBindClassName(), 
/* 6551 */                 ColumnDefinition.access$4(columnDefinition), value.getClass().getName() });
/*      */         }
/*      */         
/* 6554 */         if (type != null) {
/* 6555 */           int index = (this._tmpcols != null) ? this._tmpcols.indexOf(columnDefinition.name) : 
/* 6556 */             -1;
/* 6557 */           if (index < 0) {
/* 6558 */             MCContainerMeta m = createTempMeta(columnDefinition.name, type);
/* 6559 */             index = createTmpColList().add(m);
/*      */           } 
/* 6561 */           createTmpColList().setchkval(index, columnDefinition.name, value);
/*      */         } 
/*      */       } 
/*      */     } else {
/*      */       
/* 6566 */       ColumnPath cp = new ColumnPath(columnDefinition.name);
/* 6567 */       cp.row.setValue(columnDefinition.innerRowDefinition, value, _type);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final class MCColumnValue
/*      */   {
/*      */     private final String _name;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final MCContainerMeta _meta;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final Comparable<?> _value;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private MCColumnValue(String name, MCContainerMeta meta, Comparable<?> value) {
/* 6598 */       this._name = name;
/* 6599 */       this._meta = meta;
/* 6600 */       this._value = value;
/*      */     }
/*      */     
/*      */     public String getName() {
/* 6604 */       return this._name;
/*      */     }
/*      */     
/*      */     public MCMeta getMeta() {
/* 6608 */       return this._meta;
/*      */     }
/*      */     
/*      */     public Comparable<?> getValue() {
/* 6612 */       return this._value;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   MCColumnValue getColumnValueNE(String name) {
/* 6635 */     MCColumnValue implval = getColumnValueImpl(name);
/* 6636 */     if (implval != null) {
/* 6637 */       return implval;
/*      */     }
/*      */ 
/*      */     
/* 6641 */     ColumnPath cp = new ColumnPath(name);
/* 6642 */     if (cp.row != this) {
/* 6643 */       return cp.row.getColumnValueImpl(cp.name);
/*      */     }
/*      */ 
/*      */     
/* 6647 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private MCColumnValue getColumnValueImpl(String name) {
/*      */     int index;
/* 6653 */     if ((index = MCConstColumnList.indexOf(this, name)) > -1) {
/* 6654 */       MCContainerMeta meta = MCConstColumnList.meta(this, index);
/* 6655 */       Comparable<?> value = getConstValue(index, name, meta.type());
/* 6656 */       return new MCColumnValue(name, meta, value, null);
/*      */     } 
/*      */ 
/*      */     
/* 6660 */     if ((index = indexOfAlias(this._list, name)) > -1) {
/* 6661 */       ColumnPath cp = this._list.getColumnPath(this, index);
/* 6662 */       MCRow row = cp.row;
/* 6663 */       MCContainerMeta meta = cp.getConstMeta();
/* 6664 */       MCDataType type = meta.type();
/* 6665 */       index = MCConstColumnList.indexOf(row, meta);
/* 6666 */       Comparable<?> value = row.getConstValue(index, name, type);
/* 6667 */       return new MCColumnValue(name, meta, value, null);
/*      */     } 
/*      */ 
/*      */     
/* 6671 */     if ((index = indexOf(this._tmpcols, name)) > -1) {
/* 6672 */       MCContainerMeta meta = this._tmpcols.meta(index);
/* 6673 */       Comparable<?> value = getTempValue(index, name, meta.type());
/* 6674 */       return new MCColumnValue(name, meta, value, null);
/*      */     } 
/*      */     
/* 6677 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final <L extends MCList<?>> void setJoin(MCJoinKey<L> key, L ds) {
/* 6695 */     if (key != null) {
/* 6696 */       key.checkAlive();
/* 6697 */       if ((pb())._joins == null) {
/* 6698 */         (pb())._joins = (Map)new HashMap<>();
/*      */       }
/* 6700 */       (pb())._joins.put(key, ds);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <L extends MCList<?>> L getJoined(MCJoinKey<L> key) {
/* 6718 */     if (key == null)
/*      */     {
/* 6720 */       throw new MCException(Core_Msg_FW_A.FCBBC0058, new Object[] { msgBindClassName() });
/*      */     }
/*      */     
/* 6723 */     key.checkAlive();
/* 6724 */     if (this._pb == null || this._pb._joins == null)
/*      */     {
/* 6726 */       throw new MCException(Core_Msg_FW_A.FCBBC0059, new Object[] { msgBindClassName() });
/*      */     }
/*      */     
/* 6729 */     MCList mCList = (MCList)this._pb._joins.get(key);
/* 6730 */     if (mCList == null)
/*      */     {
/* 6732 */       throw new MCException(Core_Msg_FW_A.FCBBC0059, new Object[] { msgBindClassName() });
/*      */     }
/* 6734 */     return (L)mCList;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R extends MCRow, L extends MCList<R>> R getJoinedRow(MCJoinKey<L> key) {
/* 6751 */     R row = null;
/* 6752 */     L joined = (L)getJoined(key);
/* 6753 */     if (joined.size() > 0) {
/* 6754 */       row = joined.get(0);
/*      */     }
/* 6756 */     return row;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final <R extends MCRow, L extends MCList<R>> Object getValue(MCJoinKey<L> key, String name) {
/* 6779 */     Object<?> val = null;
/* 6780 */     R row = getJoinedRow(key);
/* 6781 */     if (row != null) {
/* 6782 */       val = (Object<?>)row.getValue(name);
/*      */     }
/*      */     else {
/*      */       
/* 6786 */       throw_getJoinAny_JoinedRowNotFound(key);
/*      */     } 
/* 6788 */     return val;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final <R extends MCRow, L extends MCList<R>> Object getValueNE(MCJoinKey<L> key, String name) {
/* 6815 */     Object<?> val = null;
/* 6816 */     R row = getJoinedRow(key);
/* 6817 */     if (row != null) {
/* 6818 */       val = (Object<?>)row.getValueNE(name);
/*      */     }
/* 6820 */     return val;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R extends MCRow, L extends MCList<R>> String getString(MCJoinKey<L> key, String name) {
/* 6846 */     String value = null;
/* 6847 */     R row = getJoinedRow(key);
/* 6848 */     if (row != null) {
/* 6849 */       value = row.getString(name);
/*      */     }
/*      */     else {
/*      */       
/* 6853 */       throw_getJoinAny_JoinedRowNotFound(key);
/*      */     } 
/* 6855 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R extends MCRow, L extends MCList<R>> String getStringNE(MCJoinKey<L> key, String name) {
/* 6884 */     String value = null;
/* 6885 */     R row = getJoinedRow(key);
/* 6886 */     if (row != null) {
/* 6887 */       value = row.getStringNE(name);
/*      */     }
/* 6889 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R extends MCRow, L extends MCList<R>> MCNumber getNumber(MCJoinKey<L> key, String name) {
/* 6915 */     MCNumber value = null;
/* 6916 */     R row = getJoinedRow(key);
/* 6917 */     if (row != null) {
/* 6918 */       value = row.getNumber(name);
/*      */     }
/*      */     else {
/*      */       
/* 6922 */       throw_getJoinAny_JoinedRowNotFound(key);
/*      */     } 
/* 6924 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R extends MCRow, L extends MCList<R>> MCNumber getNumberNE(MCJoinKey<L> key, String name) {
/* 6953 */     MCNumber value = null;
/* 6954 */     R row = getJoinedRow(key);
/* 6955 */     if (row != null) {
/* 6956 */       value = row.getNumberNE(name);
/*      */     }
/* 6958 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R extends MCRow, L extends MCList<R>> MCDate getDate(MCJoinKey<L> key, String name) {
/* 6984 */     MCDate value = null;
/* 6985 */     R row = getJoinedRow(key);
/* 6986 */     if (row != null) {
/* 6987 */       value = row.getDate(name);
/*      */     }
/*      */     else {
/*      */       
/* 6991 */       throw_getJoinAny_JoinedRowNotFound(key);
/*      */     } 
/* 6993 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R extends MCRow, L extends MCList<R>> MCDate getDateNE(MCJoinKey<L> key, String name) {
/* 7022 */     MCDate value = null;
/* 7023 */     R row = getJoinedRow(key);
/* 7024 */     if (row != null) {
/* 7025 */       value = row.getDateNE(name);
/*      */     }
/* 7027 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R extends MCRow, L extends MCList<R>> MCTimestamp getTimestamp(MCJoinKey<L> key, String name) {
/* 7053 */     MCTimestamp value = null;
/* 7054 */     R row = getJoinedRow(key);
/* 7055 */     if (row != null) {
/* 7056 */       value = row.getTimestamp(name);
/*      */     }
/*      */     else {
/*      */       
/* 7060 */       throw_getJoinAny_JoinedRowNotFound(key);
/*      */     } 
/* 7062 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R extends MCRow, L extends MCList<R>> MCTimestamp getTimestampNE(MCJoinKey<L> key, String name) {
/* 7091 */     MCTimestamp value = null;
/* 7092 */     R row = getJoinedRow(key);
/* 7093 */     if (row != null) {
/* 7094 */       value = row.getTimestampNE(name);
/*      */     }
/* 7096 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R extends MCRow, L extends MCList<R>> boolean getBoolean(MCJoinKey<L> key, String name) {
/* 7122 */     R row = getJoinedRow(key);
/* 7123 */     if (row == null)
/*      */     {
/* 7125 */       throw_getJoinAny_JoinedRowNotFound(key);
/*      */     }
/* 7127 */     return row.getBoolean(name);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R extends MCRow, L extends MCList<R>> boolean getBooleanNE(MCJoinKey<L> key, String name) {
/* 7156 */     MCRow row = getJoinedRow(key);
/* 7157 */     if (row != null) {
/* 7158 */       return row.getBooleanNE(name);
/*      */     }
/* 7160 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R extends MCRow, L extends MCList<R>> MCBinary getBinary(MCJoinKey<L> key, String name) {
/* 7186 */     MCBinary value = null;
/* 7187 */     R row = getJoinedRow(key);
/* 7188 */     if (row != null) {
/* 7189 */       value = row.getBinary(name);
/*      */     }
/*      */     else {
/*      */       
/* 7193 */       throw_getJoinAny_JoinedRowNotFound(key);
/*      */     } 
/* 7195 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R extends MCRow, L extends MCList<R>> MCBinary getBinaryNE(MCJoinKey<L> key, String name) {
/* 7224 */     MCBinary value = null;
/* 7225 */     R row = getJoinedRow(key);
/* 7226 */     if (row != null) {
/* 7227 */       value = row.getBinaryNE(name);
/*      */     }
/* 7229 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void throw_getJoinAny_JoinedRowNotFound(MCJoinKey<?> key) {
/* 7241 */     throw new MCException(Core_Msg_FW_A.FCBBC0060, new Object[] { msgBindClassName() });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCRow getValues(String... names) {
/* 7268 */     MCRow row = createInstance();
/* 7269 */     if (names != null) {
/* 7270 */       for (int i = 0; i < names.length; i++) {
/* 7271 */         MCMeta meta = getMeta(names[i]);
/* 7272 */         if (meta == null)
/*      */         {
/* 7274 */           throw throw_ColumnNotFound(names[i]);
/*      */         }
/* 7276 */         Comparable<?> value = getValue(names[i]);
/* 7277 */         row.setValueNE(names[i], meta.type(), value);
/*      */       } 
/*      */     }
/* 7280 */     return row;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private class CopyMapper
/*      */     extends MCByNameRowMapper
/*      */   {
/*      */     CopyMapper(MCRow srcrow, int mapsize) {
/* 7300 */       super(srcrow, MCRow.this, mapsize);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     final void copy() {
/* 7310 */       int size = this.mappings.size();
/* 7311 */       for (int i = 0; i < size; i++) {
/* 7312 */         MCByNameRowMapper.Mapping mapping = this.mappings.get(i);
/* 7313 */         Comparable<?> value = this.srcrow.getValue(mapping.srcname);
/* 7314 */         this.destrow.setValue(mapping.destname, mapping.type, value);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setValues(String[] dest, MCRow row, String[] src) {
/* 7352 */     if (src == null || dest == null)
/*      */     {
/* 7354 */       throw new MCException(Core_Msg_FW_A.FCBBC0026, new Object[0]);
/*      */     }
/* 7356 */     if (src.length != dest.length)
/*      */     {
/* 7358 */       throw new MCException(Core_Msg_FW_A.FCBBC0027, new Object[] { String.valueOf(src.length), 
/* 7359 */             String.valueOf(dest.length) });
/*      */     }
/*      */     
/* 7362 */     CopyMapper mapper = new CopyMapper(row, src.length);
/* 7363 */     for (int i = 0; i < src.length; i++) {
/* 7364 */       mapper.entry(src[i], dest[i]);
/*      */     }
/* 7366 */     mapper.copy();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setValues(Map<String, String> map, MCRow row) {
/* 7406 */     if (map == null)
/*      */     {
/* 7408 */       throw new MCException(Core_Msg_FW_A.FCBBC0029, new Object[0]);
/*      */     }
/*      */     
/* 7411 */     CopyMapper mapper = new CopyMapper(row, map.size());
/* 7412 */     Iterator<Map.Entry<String, String>> entryIte = map.entrySet().iterator();
/* 7413 */     while (entryIte.hasNext()) {
/* 7414 */       Map.Entry<String, String> entry = entryIte.next();
/* 7415 */       String srcname = entry.getValue();
/* 7416 */       String destname = entry.getKey();
/* 7417 */       mapper.entry(srcname, destname);
/*      */     } 
/* 7419 */     mapper.copy();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setValuesNE(String[] dest, MCRow row, String[] src) {
/* 7459 */     if (src == null || dest == null)
/*      */     {
/* 7461 */       throw new MCException(Core_Msg_FW_A.FCBBC0026, new Object[0]);
/*      */     }
/* 7463 */     if (src.length != dest.length)
/*      */     {
/* 7465 */       throw new MCException(Core_Msg_FW_A.FCBBC0027, new Object[] { String.valueOf(src.length), 
/* 7466 */             String.valueOf(dest.length) });
/*      */     }
/*      */     
/* 7469 */     CopyMapper mapper = new CopyMapper(row, src.length);
/* 7470 */     for (int i = 0; i < src.length; i++) {
/* 7471 */       mapper.entryNE(src[i], dest[i], true);
/*      */     }
/* 7473 */     mapper.copy();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setValuesNE(Map<String, String> map, MCRow row) {
/* 7518 */     if (map == null)
/*      */     {
/* 7520 */       throw new MCException(Core_Msg_FW_A.FCBBC0029, new Object[0]);
/*      */     }
/*      */     
/* 7523 */     CopyMapper mapper = new CopyMapper(row, map.size());
/* 7524 */     Iterator<Map.Entry<String, String>> entryIte = map.entrySet().iterator();
/* 7525 */     while (entryIte.hasNext()) {
/* 7526 */       Map.Entry<String, String> entry = entryIte.next();
/* 7527 */       String srcname = entry.getValue();
/* 7528 */       String destname = entry.getKey();
/* 7529 */       mapper.entryNE(srcname, destname, true);
/*      */     } 
/* 7531 */     mapper.copy();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void throw_setValues_InvalidDataType(String destname, MCDataType desttype, MCRow src, String srcname, MCDataType srctype) {
/* 7549 */     throw new MCException(Core_Msg_FW_A.FCBBC0028, new Object[] { msgBindClassName(), destname, desttype, 
/* 7550 */           src.msgBindClassName(), srcname, srctype });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setValuesByName(MCRow row) {
/* 7581 */     setValuesByName(row, getColumnPathArray());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setValuesByName(MCRow row, String... names) {
/* 7621 */     if (names == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 7633 */     CopyMapper mapper = new CopyMapper(row, names.length); byte b; int i; String[] arrayOfString;
/* 7634 */     for (i = (arrayOfString = names).length, b = 0; b < i; ) { String name = arrayOfString[b];
/*      */       try {
/* 7636 */         mapper.entry(name, name);
/*      */       }
/* 7638 */       catch (MCException ex) {
/* 7639 */         if (ex.getID().equals(Core_Msg_FW_A.FCBBC0020)) {
/* 7640 */           throw ex;
/*      */         }
/*      */       } 
/*      */       b++; }
/*      */     
/* 7645 */     mapper.copy();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAttributesByName(MCRow row) {
/* 7671 */     setAttributesByName(row, getColumnPathArray());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAttributesByName(MCRow row, String... names) {
/* 7702 */     if (names == null)
/*      */       return;  byte b;
/*      */     int i;
/*      */     String[] arrayOfString;
/* 7706 */     for (i = (arrayOfString = names).length, b = 0; b < i; ) { String name = arrayOfString[b];
/* 7707 */       if (row.contains(name)) {
/* 7708 */         row.setColAttributes(name, row);
/*      */       }
/*      */       b++; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setByName(MCRow row) {
/* 7738 */     setValuesByName(row);
/* 7739 */     setAttributes(row);
/* 7740 */     setAttributesByName(row);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCRow subColumns(String... cols) {
/* 7767 */     MCRow row = create(); byte b; int i; String[] arrayOfString;
/* 7768 */     for (i = (arrayOfString = cols).length, b = 0; b < i; ) { String col = arrayOfString[b];
/* 7769 */       MCMeta meta = getMeta(col);
/* 7770 */       if (meta == null)
/*      */       {
/* 7772 */         throw throw_ColumnNotFound(col);
/*      */       }
/* 7774 */       row.setValueNE(col, meta.type(), getValue(col)); b++; }
/*      */     
/* 7776 */     return row;
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\MCRow.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */