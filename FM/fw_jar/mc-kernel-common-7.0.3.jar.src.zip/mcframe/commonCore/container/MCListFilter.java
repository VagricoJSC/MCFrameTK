/*    */ package mcframe.commonCore.container;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MCListFilter
/*    */ {
/*    */   <E extends MCRow> MCList<E> subList(MCList<E> list, MCRowFilterList<MCRowFilter> filter) {
/* 45 */     if (list == null) {
/* 46 */       return null;
/*    */     }
/*    */     
/* 49 */     MCList<E> l = list.createInstance();
/* 50 */     if (list.size() == 0) {
/* 51 */       return l;
/*    */     }
/*    */ 
/*    */     
/* 55 */     if (!filter.isEnabled()) {
/* 56 */       l.addAll(list);
/* 57 */       return l;
/*    */     } 
/*    */ 
/*    */     
/* 61 */     for (MCRow mCRow : list) {
/* 62 */       if (filter.match(mCRow)) {
/* 63 */         l.add((E)mCRow);
/*    */       }
/*    */     } 
/*    */     
/* 67 */     return l;
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\MCListFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */