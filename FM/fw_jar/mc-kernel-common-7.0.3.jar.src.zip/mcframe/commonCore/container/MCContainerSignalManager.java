/*     */ package mcframe.commonCore.container;
/*     */ 
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCContainerSignalManager
/*     */ {
/*  22 */   private static MCContainerSignalHandler _handler = new DefaultContainerSignalHandler();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setHandler(MCContainerSignalHandler handler) {
/*  36 */     _handler = handler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isInterrupted() {
/*  48 */     return _handler.isInterrupted();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void resume() {
/*  59 */     _handler.resume();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMessage getInterruptedMessage() {
/*  71 */     return _handler.getInterruptedMessage();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMessage getInterruptedMessage4GUI() {
/*  83 */     return _handler.getInterruptedMessage4GUI();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isInterruptedMessage(String id) {
/*  94 */     return MCStringUtil.eq(id, getInterruptedMessage4GUI().getID());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class DefaultContainerSignalHandler
/*     */     implements MCContainerSignalHandler
/*     */   {
/*     */     public boolean isInterrupted() {
/* 112 */       return false;
/*     */     }
/*     */ 
/*     */     
/*     */     public MCMessage getInterruptedMessage() {
/* 117 */       return new MCMessage(Core_Msg_FW_A.FCBGC0151, new Object[0]);
/*     */     }
/*     */ 
/*     */     
/*     */     public MCMessage getInterruptedMessage4GUI() {
/* 122 */       return new MCMessage(Core_Msg_FW_A.FCBGC0151, new Object[0]);
/*     */     }
/*     */     
/*     */     public void resume() {}
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\MCContainerSignalManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */