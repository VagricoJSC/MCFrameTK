/*     */ package mcframe.commonCore.container;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import mcframe.commonCore.lang.MCDate;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCRowFilterList<E extends MCRowFilter>
/*     */   extends ArrayList<E>
/*     */   implements MCRowMatcher<MCRow>, Cloneable
/*     */ {
/*     */   public static boolean match(List<MCRowFilter> filters, MCRow row) {
/*  40 */     return match(filters, row, (MCList<?>)null, (MCDate)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean match(List<MCRowFilter> filters, MCRow row, MCList<?> aggregation, MCDate codate) {
/*  59 */     MCRowFilterList<MCRowFilter> s = new MCRowFilterList<>(filters);
/*  60 */     s.setCoDate(codate);
/*  61 */     s.setAggregateList((MCList)aggregation);
/*  62 */     return s.match(row);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   private transient List<List<List<List<MCRowFilter>>>> _cache = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   private transient int _cacheModCount = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   private MCDate _codate = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  94 */   private MCList<? extends MCRow> _aggregation = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCRowFilterList(List<E> list) {
/* 115 */     super(list);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCRowFilterList<E> clone() {
/* 120 */     MCRowFilterList<E> l = new MCRowFilterList();
/*     */     
/* 122 */     for (MCRowFilter mCRowFilter : this) {
/* 123 */       l.add((E)mCRowFilter.clone());
/*     */     }
/*     */     
/* 126 */     l._codate = this._codate;
/* 127 */     l._aggregation = this._aggregation;
/*     */     
/* 129 */     return l;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public E set(int index, E element) {
/* 135 */     clearCache();
/* 136 */     return super.set(index, element);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCoDate(MCDate date) {
/* 150 */     this._codate = date;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAggregateList(MCList<? extends MCRow> list) {
/* 161 */     this._aggregation = list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<List<List<List<MCRowFilter>>>> analyzeFilterList() {
/* 173 */     if (this._cacheModCount != this.modCount)
/*     */     {
/* 175 */       clearCache();
/*     */     }
/* 177 */     if (this._cache != null)
/*     */     {
/* 179 */       return this._cache;
/*     */     }
/*     */ 
/*     */     
/* 183 */     List<List<MCRowFilter>> cl = new ArrayList<>();
/* 184 */     List<MCRowFilter> c = null;
/* 185 */     String cn = null;
/* 186 */     for (MCRowFilter f : this) {
/* 187 */       if (!validate(f)) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 193 */       String n = f.getColumnName();
/* 194 */       if (!MCStringUtil.eq(cn, n) || c == null) {
/* 195 */         c = new ArrayList<>();
/* 196 */         cl.add(c);
/*     */       } 
/* 198 */       c.add(f);
/* 199 */       cn = n;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 204 */     List<List<List<MCRowFilter>>> ocl = new ArrayList<>();
/* 205 */     for (List<MCRowFilter> cf : cl) {
/* 206 */       List<List<MCRowFilter>> ol = new ArrayList<>();
/* 207 */       List<MCRowFilter> o = null;
/* 208 */       for (MCRowFilter f : cf) {
/* 209 */         String t = f.getLogicOperator();
/* 210 */         if ("OR".equals(t) || o == null) {
/* 211 */           o = new ArrayList<>();
/* 212 */           ol.add(o);
/*     */         } 
/* 214 */         o.add(f);
/*     */       } 
/* 216 */       ocl.add(ol);
/*     */     } 
/*     */ 
/*     */     
/* 220 */     List<List<List<List<MCRowFilter>>>> gl = new ArrayList<>();
/* 221 */     List<List<List<MCRowFilter>>> gf = null;
/* 222 */     for (List<List<MCRowFilter>> ocf : ocl) {
/* 223 */       MCRowFilter f = ((List<MCRowFilter>)ocf.get(0)).get(0);
/* 224 */       if ("OR".equals(f.getLogicOperator()) || gf == null) {
/* 225 */         gf = new ArrayList<>();
/* 226 */         gl.add(gf);
/*     */       } 
/* 228 */       gf.add(ocf);
/*     */     } 
/*     */ 
/*     */     
/* 232 */     this._cache = gl;
/* 233 */     this._cacheModCount = this.modCount;
/*     */     
/* 235 */     return gl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean match(MCRow row) {
/* 252 */     List<List<List<List<MCRowFilter>>>> fl = analyzeFilterList();
/* 253 */     for (List<List<List<MCRowFilter>>> ands : fl) {
/*     */       
/* 255 */       if (matchGroupsAND(row, ands)) {
/* 256 */         return true;
/*     */       }
/*     */     } 
/* 259 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private <T extends MCRow> boolean matchGroupsAND(T row, List<List<List<MCRowFilter>>> ands) {
/* 273 */     for (List<List<MCRowFilter>> ors : ands) {
/* 274 */       if (!matchColumnsOR(row, ors)) {
/* 275 */         return false;
/*     */       }
/*     */     } 
/* 278 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private <T extends MCRow> boolean matchColumnsOR(T row, List<List<MCRowFilter>> ors) {
/* 295 */     for (List<MCRowFilter> ands : ors) {
/* 296 */       if (matchColumnsAND(row, ands)) {
/* 297 */         return true;
/*     */       }
/*     */     } 
/* 300 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private <T extends MCRow> boolean matchColumnsAND(T row, List<MCRowFilter> fs) {
/* 316 */     for (MCRowFilter f : fs) {
/*     */       
/* 318 */       f.setCoDate(this._codate);
/* 319 */       f.setAggregateList(this._aggregation);
/*     */       
/* 321 */       if (!f.match((MCRow)row)) {
/* 322 */         return false;
/*     */       }
/*     */     } 
/* 325 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean validate(MCRowFilter filter) {
/* 337 */     return 
/*     */       
/* 339 */       !(filter == null || 
/* 340 */       filter.isDisable() || 
/* 341 */       MCStringUtil.isNull(filter.getColumnName()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void clearCache() {
/* 352 */     this._cache = null;
/* 353 */     this._cacheModCount = -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled() {
/* 364 */     for (MCRowFilter f : this) {
/* 365 */       if (validate(f)) {
/* 366 */         return true;
/*     */       }
/*     */     } 
/* 369 */     return false;
/*     */   }
/*     */   
/*     */   public MCRowFilterList() {}
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\MCRowFilterList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */