package mcframe.commonCore.container;

import java.util.EventListener;

public interface MCListListener extends EventListener {
  void rowAdded(MCListEvent paramMCListEvent);
  
  void rowRemoved(MCListEvent paramMCListEvent);
  
  void rowRemoved(MCListEvent[] paramArrayOfMCListEvent);
  
  void rowSet(MCListEvent paramMCListEvent);
  
  void listSorted(MCListEvent paramMCListEvent);
  
  void listCleared(MCListEvent paramMCListEvent);
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\MCListListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */