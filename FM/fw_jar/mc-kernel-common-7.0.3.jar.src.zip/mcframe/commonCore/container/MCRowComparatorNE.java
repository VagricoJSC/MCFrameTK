/*    */ package mcframe.commonCore.container;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCRowComparatorNE<T extends MCRow>
/*    */   extends MCRowComparator<T>
/*    */ {
/*    */   protected MCRowComparatorNE(List<String> keyList) {
/* 28 */     super(keyList);
/*    */   }
/*    */   MCRowComparatorNE(String[] keys, MCRow.ColumnDefinition[] keycdefs) {
/* 31 */     super(keys, keycdefs);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected MCRowComparatorNE(String... keys) {
/* 46 */     super(keys);
/*    */   }
/*    */ 
/*    */   
/*    */   Comparable<?> getValue(T row, String name, MCRow.ColumnDefinition cd) {
/* 51 */     return MCRow.getValueNE(cd, name, (MCRow)row);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\MCRowComparatorNE.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */