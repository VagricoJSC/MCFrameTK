/*     */ package mcframe.commonCore.container;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MCTempColumnList
/*     */   extends MCColumnList
/*     */   implements Serializable
/*     */ {
/*     */   final MCRow _row;
/*     */   MCContainerMeta[] _metas;
/*     */   Comparable<?>[] _datas;
/*     */   int[] _paramColIndex;
/*  49 */   private int _size = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCTempColumnList(MCRow row) {
/*  59 */     this._row = row;
/*  60 */     this._metas = new MCContainerMeta[0];
/*  61 */     this._size = this._metas.length;
/*  62 */     this._datas = (Comparable<?>[])new Comparable[this._size];
/*  63 */     this._paramColIndex = new int[this._size];
/*     */   }
/*     */ 
/*     */   
/*     */   MCRow row() {
/*  68 */     return this._row;
/*     */   }
/*     */ 
/*     */   
/*     */   MCContainerMeta[] metas() {
/*  73 */     return this._metas;
/*     */   }
/*     */ 
/*     */   
/*     */   Comparable<?>[] datas() {
/*  78 */     return this._datas;
/*     */   }
/*     */ 
/*     */   
/*     */   int[] paramColIndex() {
/*  83 */     return this._paramColIndex;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean isConst() {
/*  88 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   int size() {
/*  93 */     return this._size;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void ensure(int minCapacity) {
/* 106 */     int oldCapacity = this._metas.length;
/* 107 */     if (minCapacity > oldCapacity) {
/* 108 */       MCContainerMeta[] _oldmetas = this._metas;
/* 109 */       Comparable<?>[] arrayOfComparable = this._datas;
/* 110 */       int[] _oldpi = this._paramColIndex;
/*     */       
/* 112 */       int newCapacity = oldCapacity * 3 / 2 + 1;
/* 113 */       if (newCapacity < minCapacity) {
/* 114 */         newCapacity = minCapacity;
/*     */       }
/* 116 */       this._metas = new MCContainerMeta[newCapacity];
/* 117 */       System.arraycopy(_oldmetas, 0, this._metas, 0, this._size);
/*     */       
/* 119 */       this._datas = (Comparable<?>[])new Comparable[newCapacity];
/* 120 */       System.arraycopy(arrayOfComparable, 0, this._datas, 0, this._size);
/*     */       
/* 122 */       this._paramColIndex = new int[newCapacity];
/* 123 */       System.arraycopy(_oldpi, 0, this._paramColIndex, 0, this._size);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int add(MCContainerMeta meta) {
/* 142 */     return addAll(new MCContainerMeta[] { meta });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int addAll(MCTempColumnList metalist) {
/* 160 */     return (metalist != null) ? addAll(metalist._metas) : -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int addAll(MCContainerMeta... metas) {
/* 181 */     int oldlen = this._size;
/* 182 */     int newlen = this._size + metas.length;
/* 183 */     ensure(newlen); byte b; int i; MCContainerMeta[] arrayOfMCContainerMeta;
/* 184 */     for (i = (arrayOfMCContainerMeta = metas).length, b = 0; b < i; ) { MCContainerMeta meta = arrayOfMCContainerMeta[b];
/* 185 */       if (meta != null && indexOf(meta.name()) < 0) {
/* 186 */         this._metas[this._size] = meta;
/* 187 */         this._size++;
/* 188 */         init(this._size - 1);
/*     */       }  b++; }
/*     */     
/* 191 */     return (oldlen != this._size) ? oldlen : -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int addAllForce(MCTempColumnList metalist) {
/* 207 */     if (metalist == null || metalist.size() == 0) {
/* 208 */       return -1;
/*     */     }
/* 210 */     int oldlen = this._size;
/* 211 */     int newlen = this._size + metalist._size;
/* 212 */     ensure(newlen);
/* 213 */     System.arraycopy(metalist._metas, 0, this._metas, this._size, metalist._size);
/* 214 */     this._size = newlen;
/* 215 */     for (int i = oldlen; i < newlen; i++) {
/* 216 */       init(i);
/*     */     }
/* 218 */     return (oldlen != this._size) ? oldlen : -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void removeAll() {
/* 228 */     this._metas = new MCContainerMeta[0];
/* 229 */     this._datas = (Comparable<?>[])new Comparable[0];
/* 230 */     this._paramColIndex = new int[0];
/* 231 */     this._size = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isEmpty() {
/* 237 */     return super.isEmpty();
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\MCTempColumnList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */