/*      */ package mcframe.commonCore.container;
/*      */ 
/*      */ import java.io.Serializable;
/*      */ import java.lang.reflect.Array;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.RoundingMode;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Comparator;
/*      */ import java.util.HashMap;
/*      */ import java.util.IdentityHashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.ListIterator;
/*      */ import java.util.Map;
/*      */ import mcframe.commonCore.lang.MCBinary;
/*      */ import mcframe.commonCore.lang.MCCalendarDate;
/*      */ import mcframe.commonCore.lang.MCDataType;
/*      */ import mcframe.commonCore.lang.MCDate;
/*      */ import mcframe.commonCore.lang.MCNumber;
/*      */ import mcframe.commonCore.lang.MCStringUtil;
/*      */ import mcframe.commonCore.lang.MCTimestamp;
/*      */ import mcframe.commonCore.meta.MCMeta;
/*      */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*      */ import mcframe.commonCore.notice.MCException;
/*      */ import mcframe.commonCore.notice.MCMessageList;
/*      */ import mcframe.commonCore.sys.MCFactory;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MCList<E extends MCRow>
/*      */   implements MCContainer, List<E>, Cloneable, Serializable
/*      */ {
/*      */   class ConstColAttr
/*      */   {
/*   46 */     private Map<String, MCRow.ColumnDefinition> _col2Attr = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     MCRow.ColumnDefinition get(String col) {
/*   55 */       MCRow.ColumnDefinition o = null;
/*   56 */       if (this._col2Attr == null) {
/*   57 */         this._col2Attr = new HashMap<>();
/*      */       } else {
/*      */         
/*   60 */         o = this._col2Attr.get(col);
/*      */       } 
/*   62 */       if (o == null) {
/*   63 */         if (MCStringUtil.isNull(col)) {
/*   64 */           o = MCList.this._protorow.createNonColumnDefinition(col);
/*      */         } else {
/*      */           
/*   67 */           o = MCList.this._protorow.getColumnDefinitionNE(col);
/*   68 */           if (MCRow.isTempOrNoDefineColumn(o)) {
/*   69 */             o = MCList.this._protorow.createNonColumnDefinition(col);
/*      */           }
/*      */         } 
/*   72 */         this._col2Attr.put(col, o);
/*      */       } 
/*   74 */       return o;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   82 */   private transient ConstColAttr _colAttr = new ConstColAttr();
/*      */   
/*      */   private final E _protorow;
/*      */   
/*      */   private final MCRowList<E> _rows;
/*      */   
/*      */   private MCListenerList<MCListListener> _listenerList;
/*      */   
/*      */   private int _param_index;
/*      */   
/*      */   private Map<MCIndexKey, MCIndex<E>> _indexMap;
/*      */   private List<MCJoinKey<?>> _joinkeyList;
/*      */   
/*      */   public static final String createColumnPath(String... cols) {
/*   96 */     return MCRow.createColumnPath(cols);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String[] splitColumnPath(String path) {
/*  110 */     return MCRow.splitColumnPath(path);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static final void copyByName(MCList<? extends MCRow> dest, MCList<? extends MCRow> src) {
/*  131 */     if (dest == null || src == null) {
/*      */       return;
/*      */     }
/*  134 */     dest.addAllByName(src);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MCRow> MCList<T> create(Class<T> rowc) {
/*  148 */     if (rowc == null)
/*      */     {
/*  150 */       throw new MCException(Core_Msg_FW_A.FCBBC0061, new Object[] { MCList.class.getName() });
/*      */     }
/*  152 */     return new MCList<>(rowc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MCRow> MCList<T> create(Class<T> rowc, int initCapacity) {
/*  167 */     if (rowc == null)
/*      */     {
/*  169 */       throw new MCException(Core_Msg_FW_A.FCBBC0061, new Object[] { MCList.class.getName() });
/*      */     }
/*  171 */     return new MCList<>(rowc, initCapacity);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MCRow> MCList<T> create(T row) {
/*  188 */     Class<T> c = (row != null) ? (Class)row.getClass() : null;
/*  189 */     return create(c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MCRow> MCList<T> create(T row, int initCapacity) {
/*  207 */     Class<T> c = (row != null) ? (Class)row.getClass() : null;
/*  208 */     return create(c, initCapacity);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MCRow> MCList<T> createByName(Class<T> rowc, MCList<? extends MCRow> proto) {
/*  224 */     MCList<T> ds = create(rowc);
/*  225 */     copyByName(ds, proto);
/*  226 */     return ds;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends MCRow> MCList<T> createByName(T row, MCList<? extends MCRow> proto) {
/*  244 */     MCList<T> ds = create(row);
/*  245 */     copyByName(ds, proto);
/*  246 */     return ds;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MCList(Class<E> rowc) {
/*  274 */     this(MCRow.class2row(rowc));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MCList(E row) {
/*  288 */     this(row, 10);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MCList(Class<E> rowc, int initCapacity) {
/*  303 */     this(MCRow.class2row(rowc), initCapacity);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void init() {
/*  359 */     clear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final MCRowList<E> rowlist() {
/*  372 */     return this._rows;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addStringColumn(String name) {
/*  400 */     addValueColumn(name, MCDataType.STRING);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addStringColumn(String name, String value) {
/*  420 */     addValueColumn(name, MCDataType.STRING, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addNumberColumn(String name) {
/*  444 */     addValueColumn(name, MCDataType.NUMBER);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addNumberColumn(String name, MCNumber value) {
/*  464 */     addValueColumn(name, MCDataType.NUMBER, (Comparable<?>)value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addDateColumn(String name) {
/*  488 */     addValueColumn(name, MCDataType.DATE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addDateColumn(String name, MCDate value) {
/*  508 */     addValueColumn(name, MCDataType.DATE, (Comparable<?>)value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addTimestampColumn(String name) {
/*  532 */     addValueColumn(name, MCDataType.TIMESTAMP);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addTimestampColumn(String name, MCTimestamp value) {
/*  552 */     addValueColumn(name, MCDataType.TIMESTAMP, (Comparable<?>)value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addBooleanColumn(String name) {
/*  576 */     addValueColumn(name, MCDataType.BOOLEAN);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addBooleanColumn(String name, boolean value) {
/*  596 */     addValueColumn(name, MCDataType.BOOLEAN, Boolean.valueOf(value));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addBinaryColumn(String name) {
/*  620 */     addValueColumn(name, MCDataType.BINARY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addBinaryColumn(String name, MCBinary value) {
/*  640 */     addValueColumn(name, MCDataType.BINARY, (Comparable<?>)value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void addValueColumn(String name, MCDataType type) {
/*  663 */     addValueColumnImpl(name, type);
/*      */ 
/*      */     
/*  666 */     int size = size();
/*  667 */     for (int i = 0; i < size; i++) {
/*  668 */       E row = this._rows.get(i);
/*  669 */       row.addValueColumn(name, type);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void addValueColumn(String name, MCDataType type, Comparable<?> value) {
/*  697 */     addValueColumnImpl(name, type);
/*      */ 
/*      */     
/*  700 */     int size = size();
/*  701 */     for (int i = 0; i < size; i++) {
/*  702 */       E row = this._rows.get(i);
/*  703 */       row.addValueColumn(name, type, value);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void addValueColumnImpl(String name, MCDataType type) {
/*  732 */     int size = size();
/*      */ 
/*      */ 
/*      */     
/*  736 */     validateTempColumn((MCRow)this._protorow, name, type);
/*      */     
/*  738 */     for (int i = 0; i < size; i++) {
/*  739 */       validateTempColumn((MCRow)this._rows.get(i), name, type);
/*      */     }
/*      */ 
/*      */     
/*  743 */     this._protorow.addTempColumn(name, type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int validateTempColumn(MCRow row, String name, MCDataType type) {
/*      */     try {
/*  761 */       return row.validateTempColumn(name, type);
/*      */     }
/*  763 */     catch (MCException ex) {
/*  764 */       throw new MCException(ex, Core_Msg_FW_A.FCBBC0055, new Object[] { msgBindClassName(), name, type });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final String msgBindClassName() {
/*  781 */     return getClass().getName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCList<E> createInstance() {
/*      */     try {
/*  797 */       Class<? extends MCRow> rc = (Class)this._protorow.getClass();
/*  798 */       Class<? extends MCList> lc = (Class)getClass();
/*  799 */       return (MCList<E>)MCFactory.create(lc, new Class[] {
/*  800 */             rc.getClass()
/*  801 */           }, new Object[] {
/*  802 */             rc
/*      */           });
/*      */     }
/*  805 */     catch (Exception t) {
/*  806 */       throw new MCException(t, Core_Msg_FW_A.FCBBC0032, new Object[] { msgBindClassName() });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public E createRow() {
/*      */     try {
/*  822 */       MCRow mCRow = this._protorow.createInstance();
/*      */       
/*  824 */       mCRow.addListPrototypeTempColumns((MCRow)this._protorow);
/*  825 */       return (E)mCRow;
/*      */     }
/*  827 */     catch (MCException ex) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  832 */       MCRow.throwUnnecessaryWrapExceptionForCreate((Exception)ex);
/*      */       
/*  834 */       throw new MCException(ex, Core_Msg_FW_A.FCBBC0031, new Object[] { msgBindClassName(), 
/*  835 */             this._protorow.msgBindClassName() });
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void ensureCapacity(int minCapacity) {
/*  849 */     this._rows.ensureCapacity(minCapacity);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCList<E> clone() {
/*  877 */     MCList<E> newL = createInstance();
/*      */ 
/*      */     
/*  880 */     int size = size();
/*  881 */     newL._rows.ensureCapacity(size);
/*  882 */     for (int i = 0; i < size; i++) {
/*  883 */       newL.add((E)this._rows.get(i).clone());
/*      */     }
/*      */ 
/*      */     
/*  887 */     newL._protorow.addTempColumns((MCRow)this._protorow);
/*      */     
/*  889 */     return newL;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCList<E> shallowClone() {
/*  915 */     MCList<E> newL = createInstance();
/*      */ 
/*      */     
/*  918 */     int size = size();
/*  919 */     newL._rows.ensureCapacity(size);
/*  920 */     System.arraycopy(this._rows._rows, 0, newL._rows._rows, 0, size);
/*  921 */     newL._rows._size = size;
/*      */ 
/*      */     
/*  924 */     newL._protorow.addTempColumns((MCRow)this._protorow);
/*      */     
/*  926 */     return newL;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void clear(String... names) {
/*  948 */     int size = size();
/*  949 */     for (int i = 0; i < size; i++) {
/*  950 */       this._rows.get(i).clear(names);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public E[] remove(int fromIndex, int toIndex) {
/*  965 */     return this._rows.remove(fromIndex, toIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int hashCode() {
/*  981 */     int hashCode = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  987 */     int size = size();
/*  988 */     for (int i = 0; i < size; i++) {
/*  989 */       E row = this._rows.get(i);
/*  990 */       hashCode = 31 * hashCode + ((row == null) ? 0 : row.hashCode());
/*      */     } 
/*  992 */     return hashCode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 1006 */     StringBuilder sb = new StringBuilder();
/* 1007 */     int size = size();
/* 1008 */     for (int i = 0; i < size; i++) {
/* 1009 */       sb.append(String.valueOf(this._rows.get(i).toRowString()) + "\n");
/*      */     }
/*      */     
/* 1012 */     return sb.toString();
/*      */   } public final void addListListener(MCListListener... listener) { if (this._listenerList == null) this._listenerList = new MCListenerList<>(MCListListener.class);  this._listenerList.addListener(listener); } public final void removeListListener(MCListListener listener) { if (this._listenerList == null) return;  this._listenerList.removeListener(listener); }
/*      */   public final MCListListener[] removeAllListListener() { if (this._listenerList == null) return new MCListListener[0];  return this._listenerList.removeAllListener(); }
/*      */   final void fireRowAdded(E addrow, int index) { if (this._listenerList == null)
/*      */       return;  int len = this._listenerList.size(); if (len > 0) { MCListEvent event = new MCListEvent(this, MCListEvent.Type.ADD, (MCRow)addrow, null, index, 1); MCListListener[] listeners = this._listenerList.getListeners(); for (int i = 0; i < len; i++)
/*      */         listeners[i].rowAdded(event);  }  }
/*      */   final void fireRowRemoved(MCRow[] delrows, int index, int count) { if (this._listenerList == null)
/*      */       return;  int len = this._listenerList.size(); if (len > 0) { MCListEvent event = new MCListEvent(this, MCListEvent.Type.REMOVE, null, delrows, index, count); MCListListener[] listeners = this._listenerList.getListeners(); for (int i = 0; i < len; i++)
/*      */         listeners[i].rowRemoved(event);  }  }
/*      */   final void fireRowRemoved(MCListEvent[] events) { if (this._listenerList == null)
/*      */       return;  int len = this._listenerList.size(); if (len > 0) { MCListListener[] listeners = this._listenerList.getListeners(); for (int i = 0; i < len; i++)
/*      */         listeners[i].rowRemoved(events);  }  }
/*      */   final void fireRowSet(E newrow, E oldrow, int index) { if (this._listenerList == null)
/*      */       return;  int len = this._listenerList.size(); if (len > 0) { MCListEvent event = new MCListEvent(this, MCListEvent.Type.SET, (MCRow)newrow, (MCRow)oldrow, index, 1); MCListListener[] listeners = this._listenerList.getListeners(); for (int i = 0; i < len; i++)
/*      */         listeners[i].rowSet(event);  }  }
/*      */   final void fireRowAddedAll(E toprow, int topindex, int count) { if (this._listenerList == null)
/*      */       return;  int len = this._listenerList.size(); if (len > 0) { MCListEvent event = new MCListEvent(this, MCListEvent.Type.ADDALL, (MCRow)toprow, null, topindex, count); MCListListener[] listeners = this._listenerList.getListeners(); for (int i = 0; i < len; i++)
/*      */         listeners[i].rowAdded(event);  }  }
/*      */   final void fireListSorted(int from, int count) { if (this._listenerList == null)
/*      */       return;  int len = this._listenerList.size(); if (len > 0) { MCListEvent event = new MCListEvent(this, MCListEvent.Type.SORT, null, null, from, count); MCListListener[] listeners = this._listenerList.getListeners(); for (int i = 0; i < len; i++)
/*      */         listeners[i].listSorted(event);  }  }
/*      */   final void fireListCleared(MCRow[] delrows, int count) { if (this._listenerList == null)
/*      */       return;  int len = this._listenerList.size(); if (len > 0) { MCListEvent event = new MCListEvent(this, MCListEvent.Type.CLEAR, null, delrows, 0, count); MCListListener[] listeners = this._listenerList.getListeners(); for (int i = 0; i < len; i++)
/*      */         listeners[i].listCleared(event);  }  }
/*      */   public final MCDataType getDataType(String name) { MCRow.ColumnDefinition m = getConstColumnDefinition(name); if (m.isNoDefine())
/*      */       return this._protorow.getDataType(name);  return m.getMinedMeta().type(); }
/*      */   public final String[] getNameArray() { return this._protorow.getNameArray(); }
/*      */   public final MCMeta getMeta(String name) { MCRow.ColumnDefinition m = getConstColumnDefinition(name); if (m.isNoDefine())
/*      */       return this._protorow.getMeta(name);  return m.getMinedMeta(); }
/*      */   public final MCMeta[] getMetaArray() { return this._protorow.getMetaArray(); }
/*      */   public final String[] getColumnPathArray() { return this._protorow.getColumnPathArray(); }
/*      */   private <T extends Comparable<?>> List<T> createColValueList(String name, Class<T> c, int size) { MCContainerMeta meta = (MCContainerMeta)getMeta(name); if (meta == null)
/*      */       throw this._protorow.throw_ColumnNotFound(name);  List<T> l = null; MCDataType type = meta.type(); if (type == MCDataType.ROW) { if (c != null && !c.isAssignableFrom(type.dataClass()))
/*      */         throw new MCException(Core_Msg_FW_A.FCBBC0074, new Object[] { c.getName(), type.dataClass().getName() });  MCList<? extends MCRow> ml = create(meta.innerRowClass()); ml.ensureCapacity(size); MCList<? extends MCRow> mCList1 = ml; } else { l = new ArrayList<>(size); }  return l; }
/* 1046 */   public MCMessageList validate(String... names) { MCMessageList list = new MCMessageList();
/* 1047 */     int size = size();
/* 1048 */     for (int i = 0; i < size; i++) {
/* 1049 */       MCMessageList rlist = get(i).validate(names);
/* 1050 */       list.addAll((Collection)rlist);
/*      */     } 
/* 1052 */     return list; }
/*      */   public Comparable<?> getValue(int index, String name) { return getValue(get(index), name); }
/*      */   Comparable<?> getValue(E row, String name) { MCRow.ColumnDefinition m = getConstColumnDefinition(name); return MCRow.getValue(m, name, (MCRow)row); }
/*      */   public Comparable<?> getValueNE(int index, String name) { MCRow.ColumnDefinition m = getConstColumnDefinition(name); if (m.isNoDefine()) return get(index).getValueNE(name);  return get(index).getValueNE(m); }
/*      */   public void setValue(int index, String name, Comparable<?> value) { MCRow.ColumnDefinition m = getConstColumnDefinition(name); if (m.isNoDefine()) { get(index).setValue(name, value); } else { get(index).setValue(m, value, m.getMinedMeta().type()); }  }
/*      */   public void setValueNE(int index, String name, Comparable<?> value) { get(index).setValueNE(name, value); }
/*      */   public List<Comparable<?>> getValue(String name) { return getValue(name, (Class<Comparable<?>>)null); }
/*      */   public List<Comparable<?>> getValueNE(String name) { return getValueNE(name, (Class<Comparable<?>>)null); }
/*      */   public <T extends Comparable<?>> List<T> getValue(String name, Class<T> c) { int size = size(); List<T> l = createColValueList(name, c, size); MCRow.ColumnDefinition cd = getConstColumnDefinition(name); if (c != null) { for (int i = 0; i < size; i++) { Comparable<?> val = MCRow.getValue(cd, name, (MCRow)get(i)); l.add((T)MCDataType.cast(c, val)); }  } else { for (int i = 0; i < size; i++) { Comparable<?> val = MCRow.getValue(cd, name, (MCRow)get(i)); l.add((T)val); }  }  return l; }
/*      */   public <T extends Comparable<?>> List<T> getValueNE(String name, Class<T> c) { int size = size(); List<T> l = createColValueList(name, c, size); if (c != null) { for (int i = 0; i < size; i++) { Comparable<?> val = getValueNE(i, name); l.add((T)MCDataType.cast(c, val)); }  } else { for (int i = 0; i < size; i++) { Comparable<?> val = getValueNE(i, name); l.add((T)val); }  }  return l; }
/*      */   public void setValue(String name, Comparable<?> value) { int size = size(); MCRow.ColumnDefinition m = getConstColumnDefinition(name); if (m.isNoDefine()) { for (int i = 0; i < size; i++) get(i).setValue(name, value);  } else { for (int i = 0; i < size; i++) get(i).setValue(m, value, m.getMinedMeta().type());  }  }
/*      */   public void setValueNE(String name, Comparable<?> value) { int size = size(); MCRow.ColumnDefinition m = getConstColumnDefinition(name); if (m.isNoDefine()) { for (int i = 0; i < size; i++) get(i).setValueNE(name, value);  } else { for (int i = 0; i < size; i++) get(i).setValue(m, value, m.getMinedMeta().type());  }  }
/*      */   public <R extends MCRow> void setColumnValue(String name, MCList<R> srclist, String srcname) { if (srclist == null || srcname == null || name == null) return;  int ownlen = size(); int srclen = srclist.size(); if (srclen > 0) { R srcrow = srclist.get(0); MCDataType type = srcrow.getDataType(srcname); if (type == null) srcrow.throw_ColumnNotFound(srcname);  for (int i = 0; i < ownlen; i++) { E ownrow = get(i); Comparable<?> val = (i < srclen) ? srclist.get(i).getValueNE(srcname) : null; ownrow.setValue(name, type, val); }  }  }
/*      */   public void setColumnValue(String name, String srcname) { setColumnValue(name, this, srcname); }
/*      */   public <R extends MCRow> void setColumnValueNE(String name, MCList<R> srclist, String srcname) { if (srclist == null || srcname == null || name == null) return;  int ownlen = size(); int srclen = srclist.size(); if (srclen > 0) { R srcrow = srclist.get(0); MCDataType type = srcrow.getDataType(srcname); if (type == null) srcrow.throw_ColumnNotFound(srcname);  for (int i = 0; i < ownlen; i++) { E ownrow = get(i); Comparable<?> val = (i < srclen) ? srclist.get(i).getValueNE(srcname) : null; ownrow.setValueNE(name, type, val); }  }  }
/*      */   public void setColumnValueNE(String name, String srcname) { setColumnValueNE(name, this, srcname); }
/*      */   MCRow.ColumnDefinition getColumnDefinition(MCRow.ColumnDefinition before) { return this._protorow.getColumnDefinition(before); }
/*      */   MCRow.ColumnDefinition getConstColumnDefinition(String s) { return this._colAttr.get(s); }
/* 1070 */   public String getString(int index, String name) { E row = get(index); return row.getString(name); } public String getStringNE(int index, String name) { E row = get(index); return row.getStringNE(name); } public void setString(int index, String name, String value) { E row = get(index); row.setString(name, value); } public void setStringNE(int index, String name, String value) { E row = get(index); row.setStringNE(name, value); } public MCNumber getNumber(int index, String name) { E row = get(index); return row.getNumber(name); } public MCNumber getNumberNE(int index, String name) { E row = get(index); return row.getNumberNE(name); } public void setNumber(int index, String name, MCNumber value) { E row = get(index); row.setNumber(name, value); } public void setNumber(int index, String name, int value) { setNumber(index, name, MCNumber.valueOf(value)); } public void setNumber(int index, String name, long value) { setNumber(index, name, MCNumber.valueOf(value)); } public void setNumber(int index, String name, float value) { setNumber(index, name, MCNumber.valueOf(value)); } public void setNumber(int index, String name, double value) { setNumber(index, name, MCNumber.valueOf(value)); } public void setNumberNE(int index, String name, MCNumber value) { E row = get(index); row.setNumberNE(name, value); } public void setNumberNE(int index, String name, int value) { setNumberNE(index, name, MCNumber.valueOf(value)); } public void setNumberNE(int index, String name, long value) { setNumberNE(index, name, MCNumber.valueOf(value)); } public void setNumberNE(int index, String name, float value) { setNumberNE(index, name, MCNumber.valueOf(value)); } protected MCList(E row, int initCapacity) { this._listenerList = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3720 */     this._param_index = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4175 */     this._indexMap = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4362 */     this._joinkeyList = null; try { try { this._protorow = (E)row.createInstance(); } catch (MCException ex) { MCRow.throwUnnecessaryWrapExceptionForCreate((Exception)ex); throw new MCException(ex, Core_Msg_FW_A.FCBBC0031, new Object[] { msgBindClassName(), row.getClass().getName() }); }  this._rows = new MCRowList<>(this, (Class)row.getClass(), initCapacity); init(); } catch (MCException ex) { MCRow.throwUnnecessaryWrapExceptionForCreate((Exception)ex); throw new MCException(ex, Core_Msg_FW_A.FCBBC0032, new Object[] { msgBindClassName() }); }  }
/*      */   public void setNumberNE(int index, String name, double value) { setNumberNE(index, name, MCNumber.valueOf(value)); }
/*      */   public MCDate getDate(int index, String name) { E row = get(index); return row.getDate(name); }
/*      */   public MCDate getDateNE(int index, String name) { E row = get(index); return row.getDateNE(name); }
/*      */   public void setDate(int index, String name, MCDate value) { E row = get(index); row.setDate(name, value); }
/*      */   public void setDateNE(int index, String name, MCDate value) { E row = get(index); row.setDateNE(name, value); }
/*      */   public MCTimestamp getTimestamp(int index, String name) { E row = get(index); return row.getTimestamp(name); }
/*      */   public MCTimestamp getTimestampNE(int index, String name) { E row = get(index); return row.getTimestampNE(name); }
/*      */   public void setTimestamp(int index, String name, MCTimestamp value) { E row = get(index); row.setTimestamp(name, value); }
/*      */   public void setTimestampNE(int index, String name, MCTimestamp value) { E row = get(index); row.setTimestampNE(name, value); }
/* 4372 */   public boolean getBoolean(int index, String name) { E row = get(index); return row.getBoolean(name); } public boolean getBooleanNE(int index, String name) { E row = get(index); return row.getBooleanNE(name); } public void setBoolean(int index, String name, boolean value) { E row = get(index); row.setBoolean(name, value); } public void setBooleanNE(int index, String name, boolean value) { E row = get(index); row.setBooleanNE(name, value); } public MCBinary getBinary(int index, String name) { E row = get(index); return row.getBinary(name); } public MCBinary getBinaryNE(int index, String name) { E row = get(index); return row.getBinaryNE(name); } List<MCJoinKey<?>> getJoinKeyList() { if (this._joinkeyList == null) {
/* 4373 */       this._joinkeyList = new ArrayList<>();
/*      */     }
/* 4375 */     return this._joinkeyList; } public void setBinary(int index, String name, MCBinary value) { E row = get(index); row.setBinary(name, value); } public void setBinaryNE(int index, String name, MCBinary value) { E row = get(index); row.setBinaryNE(name, value); } public MCRow getInnerRow(int index, String name) { E row = get(index); return row.getInnerRow(name); } public <T extends MCRow> T getInnerRow(int index, String name, Class<T> rowc) { E row = get(index); return row.getInnerRow(name, rowc); } public void setInnerRow(int index, String name, MCRow row) { E parentrow = get(index); parentrow.setInnerRow(name, row); } public List<String> getString(String name) { return getValue(name, String.class); } public List<String> getStringNE(String name) { return getValueNE(name, String.class); } public void setString(String name, String value) { int size = size(); for (int i = 0; i < size; i++) setString(i, name, value);  } public void setStringNE(String name, String value) { int size = size(); for (int i = 0; i < size; i++) setStringNE(i, name, value);  } public List<MCNumber> getNumber(String name) { return getValue(name, MCNumber.class); } public List<MCNumber> getNumberNE(String name) { return getValueNE(name, MCNumber.class); } public void setNumber(String name, MCNumber value) { int size = size(); for (int i = 0; i < size; i++) setNumber(i, name, value);  } public void setNumber(String name, int value) { setNumber(name, MCNumber.valueOf(value)); } public void setNumber(String name, long value) { setNumber(name, MCNumber.valueOf(value)); } public void setNumber(String name, float value) { setNumber(name, MCNumber.valueOf(value)); } public void setNumber(String name, double value) { setNumber(name, MCNumber.valueOf(value)); } public void setNumberNE(String name, MCNumber value) { int size = size(); for (int i = 0; i < size; i++) setNumberNE(i, name, value);  } public void setNumberNE(String name, int value) { setNumberNE(name, MCNumber.valueOf(value)); } public void setNumberNE(String name, long value) { setNumberNE(name, MCNumber.valueOf(value)); } public void setNumberNE(String name, float value) { setNumberNE(name, MCNumber.valueOf(value)); } public void setNumberNE(String name, double value) { setNumberNE(name, MCNumber.valueOf(value)); } public List<MCDate> getDate(String name) { return getValue(name, MCDate.class); } public List<MCDate> getDateNE(String name) { return getValueNE(name, MCDate.class); }
/*      */   public void setDate(String name, MCDate value) { int size = size(); for (int i = 0; i < size; i++) setDate(i, name, value);  }
/*      */   public void setDateNE(String name, MCDate value) { int size = size(); for (int i = 0; i < size; i++) setDateNE(i, name, value);  }
/*      */   public List<MCTimestamp> getTimestamp(String name) { return getValue(name, MCTimestamp.class); }
/*      */   public List<MCTimestamp> getTimestampNE(String name) { return getValueNE(name, MCTimestamp.class); }
/*      */   public void setTimestamp(String name, MCTimestamp value) { int size = size(); for (int i = 0; i < size; i++) setTimestamp(i, name, value);  }
/*      */   public void setTimestampNE(String name, MCTimestamp value) { int size = size(); for (int i = 0; i < size; i++) setTimestampNE(i, name, value);  }
/*      */   public List<Boolean> getBoolean(String name) { return getValue(name, Boolean.class); }
/*      */   public List<Boolean> getBooleanNE(String name) { return getValueNE(name, Boolean.class); }
/*      */   public void setBoolean(String name, boolean value) { int size = size(); for (int i = 0; i < size; i++) setBoolean(i, name, value);  }
/* 4385 */   void removeAllJoinKey() { if (this._joinkeyList == null) {
/*      */       return;
/*      */     }
/* 4388 */     int size = this._joinkeyList.size();
/* 4389 */     if (size <= 0) {
/*      */       return;
/*      */     }
/* 4392 */     for (int i = 0; i < size; i++) {
/* 4393 */       MCJoinKey<?> joinkey = this._joinkeyList.get(i);
/* 4394 */       joinkey.dead();
/*      */     } 
/* 4396 */     this._joinkeyList.clear(); } public void setBooleanNE(String name, boolean value) { int size = size(); for (int i = 0; i < size; i++)
/*      */       setBooleanNE(i, name, value);  }
/*      */   public List<MCBinary> getBinary(String name) { return getValue(name, MCBinary.class); }
/*      */   public List<MCBinary> getBinaryNE(String name) { return getValueNE(name, MCBinary.class); }
/*      */   public void setBinary(String name, MCBinary value) { int size = size(); for (int i = 0; i < size; i++)
/*      */       setBinary(i, name, value);  }
/*      */   public void setBinaryNE(String name, MCBinary value) { int size = size(); for (int i = 0; i < size; i++)
/*      */       setBinaryNE(i, name, value);  }
/*      */   public void setAttributes(MCRow row) { int size = size(); for (int i = 0; i < size; i++)
/*      */       this._rows.get(i).setAttributes(row);  }
/*      */   public final boolean isStatusCreate() { return isStatus(MCRow.CREATE); }
/*      */   public final boolean isStatusModify() { return isStatus(MCRow.MODIFY); }
/*      */   public final boolean isStatusDelete() { return isStatus(MCRow.DELETE); }
/*      */   public final boolean isStatusNone() { return isStatus(MCRow.NONE); }
/*      */   final boolean isStatus(MCRow.Status status) { int size = size(); for (int i = 0; i < size; i++) { if (!this._rows.get(i).isStatus(status))
/*      */         return false;  }  return true; }
/*      */   public final void setStatus(MCRow.Status status) { int size = size(); for (int i = 0; i < size; i++)
/*      */       this._rows.get(i).setStatus(status);  }
/*      */   public final int getParamIndex() { return this._param_index; }
/*      */   public final int setParamIndex(int index) { int oldindex = this._param_index; this._param_index = index; return oldindex; }
/*      */   public final MCTimestamp getRefTime() { MCTimestamp reftime = null; int size = size(); for (int i = 0; i < size; i++) { MCTimestamp rowtime = get(i).getRefTime(); if (rowtime != null)
/*      */         if (reftime == null) { reftime = rowtime; } else { reftime = (reftime.compareTo((MCCalendarDate)rowtime) > 0) ? rowtime : reftime; }
/*      */           }
/*      */      return reftime; }
/*      */   public final MCTimestamp setRefTime(MCTimestamp time) { MCTimestamp oldtime = null; int size = size(); for (int i = 0; i < size; i++) { MCTimestamp rowtime = get(i).setRefTime(time); if (rowtime != null)
/*      */         if (oldtime == null) { oldtime = rowtime; }
/*      */         else { oldtime = (oldtime.compareTo((MCCalendarDate)rowtime) > 0) ? rowtime : oldtime; }
/*      */           }
/*      */      return oldtime; }
/* 4425 */   public <R extends MCRow, L extends MCList<R>> MCJoinKey<L> join(String owncol, L target, String col) { return join(new String[] {
/* 4426 */           owncol
/* 4427 */         }, target, new String[] {
/* 4428 */           col }); } public final void relateContainer(MCList<?> list) { if (list == null) return;  int size = size(); int othsize = list.size(); size = (size < othsize) ? size : othsize; for (int i = 0; i < size; i++) { MCRow ownrow = (MCRow)get(i); MCRow othrow = (MCRow)list.get(i); ownrow.relateContainer(othrow); }  } public enum SortType {
/*      */     ASC {
/*      */       public <T extends MCRow> MCRowComparator<T> getComparator(String... keys) { return new MCRowComparator.ASC<>(keys); } public <T extends MCRow> MCRowComparator<T> getComparator(List<String> keyList) { return new MCRowComparator.ASC<>(keyList); }
/*      */       <T extends MCRow> MCRowComparator<T> getComparator(String[] keys, MCRow.ColumnDefinition[] cds) { return new MCRowComparator.ASC<>(keys, cds); } }, ASC_NULL_AHEAD {
/*      */       public <T extends MCRow> MCRowComparator<T> getComparator(String... keys) { return new MCRowComparator.ASC_NULL_AHEAD<>(keys); }
/*      */       public <T extends MCRow> MCRowComparator<T> getComparator(List<String> keyList) { return new MCRowComparator.ASC_NULL_AHEAD<>(keyList); }
/*      */       <T extends MCRow> MCRowComparator<T> getComparator(String[] keys, MCRow.ColumnDefinition[] cds) { return new MCRowComparator.ASC_NULL_AHEAD<>(keys, cds); } }, DESC {
/*      */       public <T extends MCRow> MCRowComparator<T> getComparator(String... keys) { return new MCRowComparator.DESC<>(keys); }
/*      */       public <T extends MCRow> MCRowComparator<T> getComparator(List<String> keyList) { return new MCRowComparator.DESC<>(keyList); }
/*      */       <T extends MCRow> MCRowComparator<T> getComparator(String[] keys, MCRow.ColumnDefinition[] cds) { return new MCRowComparator.DESC<>(keys, cds); } }, DESC_NULL_AHEAD {
/*      */       public <T extends MCRow> MCRowComparator<T> getComparator(String... keys) { return new MCRowComparator.DESC_NULL_AHEAD<>(keys); }
/*      */       public <T extends MCRow> MCRowComparator<T> getComparator(List<String> keyList) { return new MCRowComparator.DESC_NULL_AHEAD<>(keyList); }
/*      */       <T extends MCRow> MCRowComparator<T> getComparator(String[] keys, MCRow.ColumnDefinition[] cds) { return new MCRowComparator.DESC_NULL_AHEAD<>(keys, cds); } };
/*      */     public abstract <T extends MCRow> MCRowComparator<T> getComparator(String... param1VarArgs);
/*      */     abstract <T extends MCRow> MCRowComparator<T> getComparator(String[] param1ArrayOfString, MCRow.ColumnDefinition[] param1ArrayOfColumnDefinition);
/*      */     public abstract <T extends MCRow> MCRowComparator<T> getComparator(List<String> param1List); }
/*      */   public void sort(String... names) { sort(SortType.ASC, names); }
/*      */   public void sort(List<String> nameList) { sort(SortType.ASC, nameList); }
/*      */   public void sort(SortType type, String... names) { if (type == null) throw new MCException(Core_Msg_FW_A.FCBBC0046, new Object[0]);  if (names == null || names.length <= 0) names = getColumnPathArray();  MCRowComparator<E> c = type.getComparator(names, getConstColumnDefinition(names)); sort(c); }
/*      */   public void sort(SortType type, List<String> nameList) { if (nameList == null || nameList.size() <= 0) { sort(type, new String[0]); } else { MCRowComparator<E> c = type.getComparator(nameList); sort(c); }  }
/*      */   public void sort(Comparator<? super E> comp) { this._rows.sort(0, size(), (Comparator<? super E>[])new Comparator[] { comp }); }
/*      */   public void sort(MCSortPolicy policy) { if (policy == null) return;  MCRowComparator<E> comps = new MCRowSortPolicyComparator<>(policy); this._rows.sort(0, size(), (Comparator<? super E>[])new Comparator[] { comps }); }
/*      */   public E get(MCIndexKey idxkey, int index) { this._rows.checkIndex(index); MCIndex<E> idx = getIndex(idxkey); return idx.get(index); }
/*      */   public Iterator<E> iterator(MCIndexKey idxkey) { MCIndex<E> idx = getIndex(idxkey); return idx.iterator(); }
/*      */   final MCIndex<E> getIndex(MCIndexKey idxkey) { MCIndex<E> idx = (this._indexMap != null) ? this._indexMap.get(idxkey) : null; if (idx == null) { MCException mcex; if (idxkey != null) { mcex = new MCException(Core_Msg_FW_A.FCBBC0042, new Object[0]); } else { mcex = new MCException(Core_Msg_FW_A.FCBBC0043, new Object[0]); }  throw mcex; }  return idx; }
/*      */   void removeAllIndex() { if (this._indexMap == null || this._indexMap.size() <= 0) return;  this._indexMap.clear(); }
/*      */   public void removeIndex(MCIndexKey idxkey) { if (this._indexMap != null) this._indexMap.remove(idxkey);  }
/*      */   public MCIndexKey createIndex(String... keys) { if (keys == null) keys = new String[0];  MCRowComparator<E> comp = new MCRowComparator.ASC<>(keys, getConstColumnDefinition(keys)); return createIndex(comp); }
/*      */   public MCIndexKey createIndex(MCRowComparator<E> comparator) { if (comparator == null) throw new MCException(Core_Msg_FW_A.FCBBC0040, new Object[0]);  MCIndex<E> index = new MCBinaryTreeIndex<>(comparator, this); MCIndexKey indexKey = index.getIndexKey(); if (this._indexMap == null) this._indexMap = new HashMap<>();  this._indexMap.put(indexKey, index); return indexKey; }
/*      */   public boolean containsIndex(MCIndexKey idxkey) { if (this._indexMap == null) return false;  return this._indexMap.containsKey(idxkey); }
/* 4458 */   public <R extends MCRow, L extends MCList<R>> MCJoinKey<L> join(String[] owncols, L target, String[] cols) { MCIndexKey idxkey = target.createIndex(cols);
/* 4459 */     MCJoinKey<L> joinkey = join(owncols, target, idxkey);
/* 4460 */     target.removeIndex(idxkey);
/* 4461 */     return joinkey; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R extends MCRow, L extends MCList<R>> MCJoinKey<L> join(String owncol, L target, MCIndexKey idxkey) {
/* 4490 */     return join(new String[] {
/* 4491 */           owncol
/* 4492 */         }, target, idxkey);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <R extends MCRow, L extends MCList<R>> MCJoinKey<L> join(String[] owncols, L target, MCIndexKey idxkey) {
/* 4522 */     Map<String, L> joinMap = new HashMap<>();
/*      */     
/* 4524 */     MCIndex<R> idx = target.getIndex(idxkey);
/* 4525 */     MCJoinKey<L> joinkey = (MCJoinKey)new MCJoinKey<>((MCList<? extends MCRow>)target);
/* 4526 */     getJoinKeyList().add(joinkey);
/* 4527 */     target.getJoinKeyList().add(joinkey);
/*      */     
/* 4529 */     int len = size();
/* 4530 */     for (int i = 0; i < len; i++) {
/* 4531 */       MCList<R> mCList; E row = get(i);
/*      */       
/* 4533 */       if (owncols == null) {
/* 4534 */         L joinds = target;
/*      */       } else {
/*      */         
/* 4537 */         Comparable[] vals = (Comparable[])getJoinValues(row, owncols);
/* 4538 */         String valskey = concatValues((Comparable<?>[])vals);
/* 4539 */         mCList = (MCList)joinMap.get(valskey);
/* 4540 */         if (mCList == null) {
/* 4541 */           mCList = target.subList(idx, (Comparable<?>[])vals);
/* 4542 */           joinMap.put(valskey, (L)mCList);
/*      */         } 
/*      */       } 
/* 4545 */       row.setJoin(joinkey, mCList);
/*      */     } 
/*      */     
/* 4548 */     return joinkey;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final Comparable<?>[] getJoinValues(E row, String[] names) {
/* 4563 */     Comparable[] vals = new Comparable[names.length];
/* 4564 */     for (int i = 0; i < vals.length; i++) {
/* 4565 */       vals[i] = row.getValue(names[i]);
/*      */     }
/* 4567 */     return (Comparable<?>[])vals;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final String concatValues(Comparable... values) {
/* 4586 */     StringBuilder sb = new StringBuilder();
/* 4587 */     for (int i = 0; i < values.length; i++) {
/* 4588 */       sb.append(values[i]);
/*      */ 
/*      */       
/* 4591 */       sb.append('￿');
/*      */     } 
/* 4593 */     return sb.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCList<E>[] groupList(String... names) {
/* 4612 */     List<MCList<E>> groups = new ArrayList<>();
/* 4613 */     MCRowComparator<E> rowcomp = new MCRowComparator.ASC<>(names, 
/* 4614 */         getConstColumnDefinition(names));
/* 4615 */     MCIndexKey idxkey = createIndex(rowcomp);
/* 4616 */     MCIndex<E> idx = getIndex(idxkey);
/* 4617 */     MCList<E> current = null;
/* 4618 */     E base = null;
/*      */     
/* 4620 */     for (MCRow mCRow : idx) {
/* 4621 */       if (rowcomp.compare(base, (E)mCRow) != 0) {
/* 4622 */         current = createSubListInstance();
/* 4623 */         groups.add(current);
/* 4624 */         MCRow mCRow1 = mCRow;
/*      */       } 
/* 4626 */       current.add((E)mCRow);
/*      */     } 
/* 4628 */     removeIndex(idxkey);
/* 4629 */     MCList[] glist = (MCList[])Array.newInstance(getClass(), groups.size());
/* 4630 */     return groups.<MCList<E>>toArray((MCList<E>[])glist);
/*      */   }
/*      */   
/*      */   private MCRow.ColumnDefinition[] getConstColumnDefinition(String[] cols) {
/* 4634 */     if (cols == null) {
/* 4635 */       return null;
/*      */     }
/* 4637 */     MCRow.ColumnDefinition[] cds = new MCRow.ColumnDefinition[cols.length];
/* 4638 */     for (int i = 0; i < cols.length; i++) {
/* 4639 */       cds[i] = getConstColumnDefinition(cols[i]);
/*      */     }
/* 4641 */     return cds;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCList<E> groupBy(String... names) {
/* 4713 */     MCGroupByPolicy gbPolicy = new MCGroupByPolicy(names);
/* 4714 */     return groupBy(gbPolicy);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCList<E> groupBy(MCGroupByPolicy policy) {
/* 4812 */     return groupByImpl(policy, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCList<E> groupByNE(String... names) {
/* 4883 */     MCGroupByPolicy gbPolicy = new MCGroupByPolicy(names);
/* 4884 */     return groupByNE(gbPolicy);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCList<E> groupByNE(MCGroupByPolicy policy) {
/* 4981 */     return groupByImpl(policy, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MCList<E> groupByImpl(MCGroupByPolicy policy, boolean isStrict) {
/* 5080 */     if (policy == null) {
/* 5081 */       return createSubListInstance();
/*      */     }
/*      */     
/* 5084 */     String[] names = policy.groupArray();
/*      */     
/* 5086 */     MCRowComparator<E> rowcomp = new MCRowComparator<>(names, 
/* 5087 */         getConstColumnDefinition(names));
/* 5088 */     MCIndexKey idxkey = createIndex(rowcomp);
/* 5089 */     MCIndex<E> idx = getIndex(idxkey);
/*      */     
/* 5091 */     MCAggregate[] agarray = (MCAggregate[])policy.aggregateArray();
/* 5092 */     MCList<E> ds = createSubListInstance();
/* 5093 */     E current = null;
/* 5094 */     for (MCRow mCRow : idx) {
/* 5095 */       if (rowcomp.compare(current, (E)mCRow) != 0) {
/* 5096 */         if (current != null) {
/* 5097 */           MCAggregate.setToRow(current, (MCAggregate<E>[])agarray);
/* 5098 */           agarray = policy.aggregateArray();
/*      */         } 
/* 5100 */         current = createRow();
/*      */         
/* 5102 */         current.clear();
/* 5103 */         if (isStrict) {
/* 5104 */           current.setValues(names, mCRow, names);
/*      */         } else {
/*      */           
/* 5107 */           current.setValuesNE(names, mCRow, names);
/*      */         } 
/* 5109 */         ds.add(current);
/*      */       } 
/* 5111 */       for (int i = agarray.length - 1; i >= 0; i--) {
/* 5112 */         agarray[i].add(mCRow);
/*      */       }
/*      */     } 
/* 5115 */     if (current != null) {
/* 5116 */       MCAggregate.setToRow(current, (MCAggregate<E>[])agarray);
/*      */     }
/*      */     
/* 5119 */     removeIndex(idxkey);
/* 5120 */     return ds;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCList<E> distinctNE(String... names) {
/* 5139 */     if (size() == 0) {
/* 5140 */       return this;
/*      */     }
/* 5142 */     MCRow.ColumnDefinition[] cds = getConstColumnDefinition(names);
/* 5143 */     MCRowComparator<E> rowcomp = new MCRowComparatorNE<>(names, cds);
/* 5144 */     MCList<E> ds = createSubListInstance();
/*      */     
/* 5146 */     MCList<E> l = shallowClone();
/* 5147 */     l.sort(rowcomp);
/* 5148 */     E current = l.get(0);
/* 5149 */     ds.add(current);
/* 5150 */     for (int i = 1; i < l.size(); i++) {
/* 5151 */       if (!compareColumn((MCRow)current, (MCRow)l.get(i), names, cds)) {
/* 5152 */         current = l.get(i);
/* 5153 */         ds.add(l.get(i));
/*      */       } 
/*      */     } 
/*      */     
/* 5157 */     return ds;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean compareColumn(MCRow r1, MCRow r2, String[] names, MCRow.ColumnDefinition[] cds) {
/* 5162 */     for (int i = 0; i < names.length; i++) {
/* 5163 */       String name = names[i];
/* 5164 */       MCRow.ColumnDefinition cd = cds[i];
/*      */       
/* 5166 */       if (r1.compareValueNE(name, cd, r2, name, cd) != 0) {
/* 5167 */         return false;
/*      */       }
/*      */     } 
/* 5170 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber avg(String name) {
/* 5198 */     MCAggregate.AVG<E> avg = new MCAggregate.AVG<>(name, 
/* 5199 */         getConstColumnDefinition(name), name, null);
/* 5200 */     for (int i = size() - 1; i >= 0; i--) {
/* 5201 */       avg.add(this._rows.get(i));
/*      */     }
/* 5203 */     return avg.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber avg(String name, RoundingMode mode) {
/* 5226 */     MCAggregate.AVG<E> avg = new MCAggregate.AVG<>(name, 
/* 5227 */         getConstColumnDefinition(name), name, null);
/* 5228 */     Map<String, Object> option = new HashMap<>();
/* 5229 */     option.put("mode", mode);
/* 5230 */     avg.setOption(option);
/* 5231 */     for (int i = size() - 1; i >= 0; i--) {
/* 5232 */       avg.add(this._rows.get(i));
/*      */     }
/* 5234 */     return avg.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber avg(String name, int scale, RoundingMode mode) {
/* 5254 */     MCAggregate.AVG<E> avg = new MCAggregate.AVG<>(name, 
/* 5255 */         getConstColumnDefinition(name), name, null);
/* 5256 */     Map<String, Object> option = new HashMap<>();
/* 5257 */     option.put("scale", Integer.valueOf(scale));
/* 5258 */     option.put("mode", mode);
/* 5259 */     avg.setOption(option);
/* 5260 */     for (int i = size() - 1; i >= 0; i--) {
/* 5261 */       avg.add(this._rows.get(i));
/*      */     }
/* 5263 */     return avg.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int count(String name) {
/* 5278 */     MCAggregate.COUNT<E> count = new MCAggregate.COUNT<>(name, 
/* 5279 */         getConstColumnDefinition(name), name, null);
/* 5280 */     for (int i = size() - 1; i >= 0; i--) {
/* 5281 */       count.add(this._rows.get(i));
/*      */     }
/* 5283 */     return count.intValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Comparable<?> min(String name) {
/* 5300 */     MCAggregate.MIN<E> min = new MCAggregate.MIN<>(name, 
/* 5301 */         getConstColumnDefinition(name), name, null);
/* 5302 */     for (int i = size() - 1; i >= 0; i--) {
/* 5303 */       min.add(this._rows.get(i));
/*      */     }
/* 5305 */     return min.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Comparable<?> max(String name) {
/* 5322 */     MCAggregate.MAX<E> max = new MCAggregate.MAX<>(name, 
/* 5323 */         getConstColumnDefinition(name), name, null);
/* 5324 */     for (int i = size() - 1; i >= 0; i--) {
/* 5325 */       max.add(this._rows.get(i));
/*      */     }
/* 5327 */     return max.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber sum(String name) {
/* 5344 */     MCAggregate.SUM<E> sum = new MCAggregate.SUM<>(name, 
/* 5345 */         getConstColumnDefinition(name), name, null);
/* 5346 */     for (int i = size() - 1; i >= 0; i--) {
/* 5347 */       sum.add(this._rows.get(i));
/*      */     }
/* 5349 */     return sum.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <L extends MCList<?>> MCNumber avg(MCJoinKey<L> joinKey, String name) {
/* 5371 */     return avg(joinKey, name, MCNumber.MODE_DOWN);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <L extends MCList<?>> MCNumber avg(MCJoinKey<L> joinKey, String name, RoundingMode mode) {
/* 5390 */     int scale = -1;
/* 5391 */     int validcnt = 0;
/* 5392 */     MCNumber average = null;
/* 5393 */     for (int i = size() - 1; i >= 0; i--) {
/* 5394 */       L ds = this._rows.get(i).getJoined(joinKey);
/* 5395 */       MCNumber val = ds.sum(name);
/* 5396 */       if (val != null && average == null) {
/* 5397 */         average = MCNumber.ZERO;
/*      */       }
/* 5399 */       average = average.add((BigDecimal)val);
/* 5400 */       validcnt += ds.count(name);
/* 5401 */       MCMeta meta = ds.getMeta(name);
/* 5402 */       scale = Math.max((meta == null) ? average.scale() : meta.scale(), scale);
/*      */     } 
/* 5404 */     if (average != null) {
/* 5405 */       average = average.divide((BigDecimal)new MCNumber(validcnt), scale, mode);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5418 */     return average;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <L extends MCList<?>> MCNumber avg(MCJoinKey<L> joinKey, String name, int scale, RoundingMode mode) {
/* 5438 */     int validcnt = 0;
/* 5439 */     MCNumber average = null;
/* 5440 */     for (int i = size() - 1; i >= 0; i--) {
/* 5441 */       L ds = this._rows.get(i).getJoined(joinKey);
/* 5442 */       MCNumber val = ds.sum(name);
/* 5443 */       if (val != null && average == null) {
/* 5444 */         average = MCNumber.ZERO;
/*      */       }
/* 5446 */       average = average.add((BigDecimal)val);
/* 5447 */       validcnt += ds.count(name);
/*      */     } 
/* 5449 */     if (average != null) {
/* 5450 */       average = average.divide((BigDecimal)new MCNumber(validcnt), scale, mode);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5463 */     return average;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <L extends MCList<?>> int count(MCJoinKey<L> joinKey, String name) {
/* 5477 */     int cnt = 0;
/* 5478 */     for (int i = size() - 1; i >= 0; i--) {
/* 5479 */       L ds = this._rows.get(i).getJoined(joinKey);
/* 5480 */       cnt += ds.count(name);
/*      */     } 
/* 5482 */     return cnt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <L extends MCList<? extends MCRow>> Comparable min(MCJoinKey<L> joinKey, String name) {
/* 5500 */     Comparable<?> minval = null;
/* 5501 */     for (int i = size() - 1; i >= 0; i--) {
/* 5502 */       L ds = (L)this._rows.get(i).getJoined(joinKey);
/* 5503 */       Comparable<?> val = ds.min(name);
/* 5504 */       if (val != null) {
/* 5505 */         if (minval == null) {
/* 5506 */           minval = val;
/*      */         } else {
/*      */           
/* 5509 */           minval = (val.compareTo(minval) < 0) ? val : minval;
/*      */         } 
/*      */       }
/*      */     } 
/* 5513 */     return minval;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <L extends MCList<? extends MCRow>> Comparable max(MCJoinKey<L> joinKey, String name) {
/* 5532 */     Comparable<?> maxval = null;
/* 5533 */     for (int i = size() - 1; i >= 0; i--) {
/* 5534 */       L ds = (L)this._rows.get(i).getJoined(joinKey);
/* 5535 */       Comparable<?> val = ds.max(name);
/* 5536 */       if (val != null) {
/* 5537 */         if (maxval == null) {
/* 5538 */           maxval = val;
/*      */         } else {
/*      */           
/* 5541 */           maxval = (val.compareTo(maxval) > 0) ? val : maxval;
/*      */         } 
/*      */       }
/*      */     } 
/* 5545 */     return maxval;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   MCList<E> createSubListInstance() {
/* 5595 */     MCList<E> ds = createInstance();
/* 5596 */     ds._protorow.addTempColumns((MCRow)this._protorow);
/* 5597 */     return ds;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCList<E> statusChangedList() {
/* 5610 */     MCList<E> ds = createSubListInstance();
/* 5611 */     int size = size();
/* 5612 */     for (int i = 0; i < size; i++) {
/* 5613 */       E row = this._rows.get(i);
/* 5614 */       if (row.getStatus() != MCRow.Status.NONE) {
/* 5615 */         ds.add(row);
/*      */       }
/*      */     } 
/* 5618 */     return ds;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCList<E> subList(MCRow.Status... status) {
/* 5635 */     if (status == null) {
/* 5636 */       status = new MCRow.Status[] {
/* 5637 */           MCRow.Status.NONE
/*      */         };
/*      */     }
/* 5640 */     MCList<E> ds = createSubListInstance();
/* 5641 */     int size = size();
/* 5642 */     for (int i = 0; i < size; i++) {
/* 5643 */       E row = this._rows.get(i);
/* 5644 */       for (int j = 0; j < status.length; j++) {
/* 5645 */         if (row.getStatus() == status[j]) {
/* 5646 */           ds.add(row);
/*      */         }
/*      */       } 
/*      */     } 
/* 5650 */     return ds;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCList<E> subList(String key, Comparable<?> val) {
/* 5668 */     return subList(new String[] {
/* 5669 */           key
/* 5670 */         }, (Comparable<?>[])new Comparable[] {
/* 5671 */           val
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCList<E> subList(String[] keys, Comparable[] vals) {
/* 5700 */     MCList<E> ds = createSubListInstance();
/*      */     
/* 5702 */     if (keys == null || vals == null)
/*      */     {
/* 5704 */       return ds;
/*      */     }
/* 5706 */     int keylen = keys.length;
/* 5707 */     int vallen = vals.length;
/* 5708 */     if (keylen <= 0 || vallen <= 0)
/*      */     {
/* 5710 */       return ds;
/*      */     }
/* 5712 */     int collen = (keylen > vallen) ? vallen : keylen;
/*      */     
/* 5714 */     MCRowComparator<E> comp = new MCRowComparator<>(keys);
/* 5715 */     MCRow.ColumnDefinition[] keycds = getConstColumnDefinition(keys);
/* 5716 */     int size = size();
/* 5717 */     for (int i = 0; i < size; i++) {
/* 5718 */       E row = get(i);
/* 5719 */       int match = 0;
/* 5720 */       for (int k = 0; k < collen && match == 0; k++) {
/* 5721 */         Comparable<?> data = MCRow.getValue(keycds[k], keys[k], (MCRow)get(i));
/* 5722 */         match = comp.compareCol(keys[k], data, vals[k]);
/*      */       } 
/* 5724 */       if (match == 0) {
/* 5725 */         ds.add(row);
/*      */       }
/*      */     } 
/* 5728 */     return ds;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCList<E> subList(MCIndexKey idxkey, Comparable... vals) {
/* 5759 */     MCIndex<E> idx = getIndex(idxkey);
/* 5760 */     return subList(idx, (Comparable<?>[])vals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final MCList<E> subList(MCIndex<E> idx, Comparable... vals) {
/* 5788 */     return (idx != null) ? idx.select((Comparable<?>[])vals) : createSubListInstance();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCList<E> subList(MCRowMatcher<E> matcher) {
/* 5804 */     MCList<E> sub = createSubListInstance();
/*      */     
/* 5806 */     if (matcher == null) {
/* 5807 */       return sub;
/*      */     }
/*      */     
/* 5810 */     int size = size();
/* 5811 */     for (int i = 0; i < size; i++) {
/* 5812 */       E row = this._rows.get(i);
/* 5813 */       if (matcher.match(row)) {
/* 5814 */         sub.add(row);
/*      */       }
/*      */     } 
/* 5817 */     return sub;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCList<E> subList(MCRowMatcher<E> matcher, MCIndexKey serial) {
/* 5845 */     MCList<E> sub = createSubListInstance();
/*      */     
/* 5847 */     if (matcher == null) {
/* 5848 */       return sub;
/*      */     }
/* 5850 */     if (serial == null)
/*      */     {
/* 5852 */       serial = createIndex(new String[0]);
/*      */     }
/*      */     
/* 5855 */     MCIndex<E> idx = getIndex(serial);
/* 5856 */     int size = size();
/* 5857 */     int pos = 0;
/* 5858 */     for (; pos < size; pos++) {
/* 5859 */       E row = idx.get(pos);
/* 5860 */       if (matcher.match(row)) {
/* 5861 */         sub.add(row);
/* 5862 */         pos++;
/*      */         break;
/*      */       } 
/*      */     } 
/* 5866 */     for (; pos < size; pos++) {
/* 5867 */       E row = idx.get(pos);
/* 5868 */       if (!matcher.match(row)) {
/*      */         break;
/*      */       }
/* 5871 */       sub.add(row);
/*      */     } 
/* 5873 */     return sub;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCList<E> subList(String[] cols, MCRow valrow) {
/* 5908 */     return subList(cols, valrow, cols);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCList<E> subList(String[] owncols, MCRow valrow, String[] valcols) {
/* 5953 */     MCList<E> list = createSubListInstance();
/*      */     
/* 5955 */     if (valrow == null)
/*      */     {
/* 5957 */       return list;
/*      */     }
/* 5959 */     if (valcols == null || owncols == null)
/*      */     {
/* 5961 */       return list;
/*      */     }
/* 5963 */     int ownlen = owncols.length;
/* 5964 */     int vallen = valcols.length;
/* 5965 */     if (ownlen <= 0 || vallen <= 0)
/*      */     {
/* 5967 */       return list;
/*      */     }
/*      */ 
/*      */     
/* 5971 */     Comparable[] vals = new Comparable[vallen];
/* 5972 */     for (int i = 0; i < vallen; i++) {
/* 5973 */       vals[i] = valrow.getValue(valcols[i]);
/*      */     }
/* 5975 */     return subList(owncols, (Comparable<?>[])vals);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public E getFirst(String key, Comparable<?> val) {
/* 5989 */     return getFirst(new String[] {
/* 5990 */           key
/* 5991 */         }, (Comparable<?>[])new Comparable[] {
/* 5992 */           val
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public E getFirst(String[] keys, Comparable[] vals) {
/* 6017 */     if (keys == null || vals == null)
/*      */     {
/* 6019 */       return null;
/*      */     }
/* 6021 */     int keylen = keys.length;
/* 6022 */     int vallen = vals.length;
/* 6023 */     if (keylen <= 0 || vallen <= 0)
/*      */     {
/* 6025 */       return null;
/*      */     }
/* 6027 */     int collen = (keylen > vallen) ? vallen : keylen;
/*      */     
/* 6029 */     MCRowComparator<E> comp = new MCRowComparator<>(keys);
/* 6030 */     MCRow.ColumnDefinition[] keycds = getConstColumnDefinition(keys);
/* 6031 */     int size = size();
/* 6032 */     for (int i = 0; i < size; i++) {
/* 6033 */       E row = get(i);
/* 6034 */       int match = 0;
/* 6035 */       for (int k = 0; k < collen && match == 0; k++) {
/* 6036 */         Comparable<?> data = MCRow.getValue(keycds[k], keys[k], (MCRow)get(i));
/* 6037 */         match = comp.compareCol(keys[k], data, vals[k]);
/*      */       } 
/* 6039 */       if (match == 0) {
/* 6040 */         return row;
/*      */       }
/*      */     } 
/* 6043 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public E getFirst(MCIndexKey idxkey, Comparable... vals) {
/* 6064 */     MCIndex<E> idx = getIndex(idxkey);
/* 6065 */     MCList<E> list = idx.select((Comparable<?>[])vals);
/* 6066 */     return (list.size() > 0) ? list.get(0) : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean addAllByName(Collection<? extends MCRow> c) {
/* 6095 */     return addAllByName(size(), c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean addAllByName(int index, Collection<? extends MCRow> c) {
/* 6132 */     MCRow[] other = null;
/* 6133 */     int len = 0;
/* 6134 */     if (c != null) {
/* 6135 */       MCRow[] org = c.<MCRow>toArray(new MCRow[c.size()]);
/* 6136 */       int orglen = org.length;
/* 6137 */       other = (MCRow[])this._rows.createRowArray(orglen);
/* 6138 */       for (int i = 0; i < orglen; i++) {
/* 6139 */         if (org[i] != null) {
/* 6140 */           E row = createRow();
/* 6141 */           row.setByName(org[i]);
/* 6142 */           other[len++] = (MCRow)row;
/*      */         } 
/*      */       } 
/*      */     } 
/* 6146 */     return this._rows.addArray(index, (E[])other, len);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void merge(Collection<? extends E> c, String... keys) {
/* 6167 */     if (keys != null && keys.length > 0) {
/* 6168 */       MCRow[] others = c.<MCRow>toArray((MCRow[])this._rows.createRowArray(c.size()));
/* 6169 */       MCRow[] adds = (MCRow[])this._rows.createRowArray(c.size());
/* 6170 */       int addslen = 0;
/* 6171 */       MCIndexKey idxkey = createIndex(keys);
/* 6172 */       Comparable[] values = new Comparable[keys.length];
/* 6173 */       MCRow.ColumnDefinition[] keycds = getConstColumnDefinition(keys); byte b; int i; MCRow[] arrayOfMCRow1;
/* 6174 */       for (i = (arrayOfMCRow1 = others).length, b = 0; b < i; ) { MCRow mCRow = arrayOfMCRow1[b];
/* 6175 */         int len = keys.length;
/* 6176 */         for (int j = 0; j < len; j++) {
/* 6177 */           values[j] = MCRow.getValue(keycds[j], keys[j], mCRow);
/*      */         }
/* 6179 */         if (!contains(idxkey, (Comparable<?>[])values)) {
/*      */           
/* 6181 */           adds[addslen] = mCRow;
/* 6182 */           addslen++;
/*      */         }  b++; }
/*      */       
/* 6185 */       removeIndex(idxkey);
/* 6186 */       this._rows.addArray(size(), (E[])adds, addslen);
/*      */     } else {
/*      */       
/* 6189 */       addAll(c);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAll(Collection<? extends E> c) {
/* 6204 */     clear();
/* 6205 */     addAll(c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean contains(MCIndexKey idxkey, Comparable... vals) {
/* 6226 */     MCIndex<E> idx = getIndex(idxkey);
/*      */     
/* 6228 */     MCList<E> ds = idx.select((Comparable<?>[])vals);
/* 6229 */     return (ds.size() > 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCList<MCRow> subColumns(String... cols) {
/* 6260 */     int size = size();
/* 6261 */     MCList<MCRow> list = create(MCRow.class, size);
/*      */ 
/*      */     
/* 6264 */     int len = (cols != null) ? cols.length : 0; int i;
/* 6265 */     for (i = 0; i < len; i++) {
/* 6266 */       MCMeta meta = getMeta(cols[i]);
/* 6267 */       if (meta == null) {
/* 6268 */         throw this._protorow.throw_ColumnNotFound(cols[i]);
/*      */       }
/* 6270 */       list.addValueColumn(meta.name(), meta.type());
/*      */     } 
/*      */     
/* 6273 */     for (i = 0; i < size; i++) {
/* 6274 */       E own = get(i);
/* 6275 */       MCRow row = own.subColumns(cols);
/* 6276 */       list.add(row);
/*      */     } 
/*      */     
/* 6279 */     return list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCList<MCRow> innerRowList(String col) {
/* 6308 */     return innerRowList(col, MCRow.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T extends MCRow> MCList<T> innerRowList(String col, Class<T> rowc) {
/* 6324 */     MCContainerMeta meta = (MCContainerMeta)this._protorow.getConstMeta(col);
/* 6325 */     if (meta == null || meta.type() != MCDataType.ROW)
/*      */     {
/* 6327 */       throw new MCException(Core_Msg_FW_A.FCBBC0071, new Object[] { msgBindClassName(), col });
/*      */     }
/* 6329 */     if (rowc != null && !rowc.isAssignableFrom(meta.innerRowClass()))
/*      */     {
/* 6331 */       throw new MCException(Core_Msg_FW_A.FCBBC0074, new Object[] { rowc.getName(), 
/* 6332 */             meta.innerRowClass().getName() });
/*      */     }
/*      */     
/* 6335 */     MCList<T> list = create(rowc);
/* 6336 */     int size = size();
/* 6337 */     for (int i = 0; i < size; i++) {
/* 6338 */       T row = this._rows.get(i).getInnerRow(col, rowc);
/* 6339 */       list.add(row);
/*      */     } 
/* 6341 */     return list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public E add() {
/* 6352 */     E row = createRow();
/* 6353 */     add(row);
/* 6354 */     return row;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean add(E row) {
/* 6373 */     add(size(), row);
/* 6374 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void add(int index, E row) {
/* 6390 */     this._rows.add(index, row);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean addAll(Collection<? extends E> c) {
/* 6406 */     return addAll(size(), c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean addAll(int index, Collection<? extends E> c) {
/* 6423 */     if (c == null) {
/* 6424 */       return false;
/*      */     }
/* 6426 */     int len = c.size();
/* 6427 */     if (len == 0) {
/* 6428 */       return false;
/*      */     }
/*      */     
/* 6431 */     MCRow[] other = c.<MCRow>toArray((MCRow[])this._rows.createRowArray(len));
/* 6432 */     return this._rows.addArray(index, (E[])other, len);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clear() {
/* 6443 */     this._rows.clear();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean contains(Object o) {
/* 6456 */     return (indexOf(o) >= 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean containsAll(Collection<?> c) {
/* 6470 */     Iterator<?> iterator = c.iterator();
/* 6471 */     while (iterator.hasNext()) {
/* 6472 */       if (!contains(iterator.next())) {
/* 6473 */         return false;
/*      */       }
/*      */     } 
/* 6476 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object obj) {
/* 6498 */     if (obj == null) {
/* 6499 */       return false;
/*      */     }
/* 6501 */     if (getClass() != obj.getClass()) {
/* 6502 */       return false;
/*      */     }
/* 6504 */     MCList<?> other = (MCList)obj;
/* 6505 */     int size = size();
/* 6506 */     if (size != other.size()) {
/* 6507 */       return false;
/*      */     }
/*      */     
/* 6510 */     MCMeta[] ownmetas = getMetaArray();
/* 6511 */     MCMeta[] othermetas = other.getMetaArray();
/* 6512 */     if (ownmetas.length != othermetas.length) {
/* 6513 */       return false;
/*      */     }
/*      */     
/* 6516 */     for (int i = 0; i < size; i++) {
/* 6517 */       if (!get(i).equals(other.get(i))) {
/* 6518 */         return false;
/*      */       }
/*      */     } 
/*      */     
/* 6522 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public E get(int index) {
/* 6536 */     return this._rows.get(index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int indexOf(Object o) {
/* 6552 */     int size = size();
/* 6553 */     if (o != null) {
/* 6554 */       for (int i = 0; i < size; i++) {
/* 6555 */         if (o == this._rows.get(i)) {
/* 6556 */           return i;
/*      */         }
/*      */       } 
/*      */     }
/* 6560 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEmpty() {
/* 6572 */     return (size() == 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Iterator<E> iterator() {
/* 6584 */     return new DIterator(null, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int lastIndexOf(Object o) {
/* 6598 */     if (o != null) {
/* 6599 */       for (int i = size() - 1; i >= 0; i--) {
/* 6600 */         if (o == this._rows.get(i)) {
/* 6601 */           return i;
/*      */         }
/*      */       } 
/*      */     }
/* 6605 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ListIterator<E> listIterator() {
/* 6617 */     return new DListIterator();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ListIterator<E> listIterator(int index) {
/* 6631 */     this._rows.checkIndex(index);
/* 6632 */     return new DListIterator(index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public E remove(int index) {
/* 6646 */     return this._rows.remove(index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean remove(Object o) {
/* 6659 */     if (o != null) {
/* 6660 */       int size = size();
/* 6661 */       for (int index = 0; index < size; index++) {
/* 6662 */         if (o == this._rows.get(index)) {
/* 6663 */           remove(index);
/* 6664 */           return true;
/*      */         } 
/*      */       } 
/*      */     } 
/* 6668 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean removeAll(Collection<?> c) {
/* 6682 */     return thinOut(c, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean retainAll(Collection<?> c) {
/* 6697 */     return thinOut(c, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean thinOut(final Collection<?> cl, boolean keep) {
/* 6729 */     ContainChecker c = (cl instanceof MCList) ? new ContainChecker(cl)
/*      */       {
/*      */         Map<MCRow, Object> map;
/*      */         
/*      */         public boolean contains(Object o) {
/* 6734 */           return this.map.containsKey(o);
/*      */         }
/* 6736 */       } : new ContainChecker()
/*      */       {
/*      */         public boolean contains(Object o) {
/* 6739 */           return cl.contains(o);
/*      */         }
/*      */       };
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6746 */     List<MCListEvent> el = new ArrayList<>();
/*      */     
/* 6748 */     boolean modified = false;
/* 6749 */     int size = this._rows.size();
/* 6750 */     int to = 0;
/*      */     
/* 6752 */     for (int i = size - 1; i >= 0; i--) {
/* 6753 */       if (c.contains(this._rows.get(i)) != keep) {
/* 6754 */         to = i--;
/* 6755 */         while (i >= 0 && c.contains(this._rows.get(i)) != keep) {
/* 6756 */           i--;
/*      */         }
/* 6758 */         MCListEvent event = removeBlock(i + 1, to + 1);
/* 6759 */         el.add(event);
/* 6760 */         size -= to - i;
/* 6761 */         modified = true;
/*      */       } 
/*      */     } 
/*      */     
/* 6765 */     if (modified)
/*      */     {
/* 6767 */       fireRowRemoved(el.<MCListEvent>toArray(new MCListEvent[el.size()]));
/*      */     }
/*      */     
/* 6770 */     return modified;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Map<MCRow, Object> getContainsMap(MCList<?> l) {
/* 6782 */     int size = l.size();
/* 6783 */     Map<MCRow, Object> map = new IdentityHashMap<>(size);
/* 6784 */     for (int i = 0; i < size; i++) {
/* 6785 */       map.put((MCRow)l.get(i), null);
/*      */     }
/* 6787 */     return map;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MCListEvent removeBlock(int from, int to) {
/* 6807 */     MCRow[] delrows = (MCRow[])this._rows.removeNoEvent(from, to);
/* 6808 */     return new MCListEvent(this, MCListEvent.Type.REMOVE, null, delrows, from, 
/* 6809 */         delrows.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public E set(int index, E element) {
/* 6824 */     return this._rows.set(index, element);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int size() {
/* 6836 */     return this._rows.size();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCList<E> subList(int fromIndex, int toIndex) {
/* 6856 */     MCList<E> ds = createSubListInstance();
/* 6857 */     int len = toIndex - fromIndex;
/* 6858 */     ds._rows.addArray(0, this._rows.getArray(fromIndex, toIndex), len);
/* 6859 */     return ds;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public E[] toArray() {
/* 6871 */     return this._rows.toArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public <T> T[] toArray(Object[] a) {
/* 6886 */     return this._rows.toArray((T[])a);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private class DIterator
/*      */     implements Iterator<E>
/*      */   {
/* 6906 */     protected final int _initial = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6913 */     int _cursor = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6920 */     int _lastcursor = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6927 */     int _ownmodcnt = MCList.this._rows.modcnt();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean hasNext() {
/* 6939 */       return (this._cursor != MCList.this.size());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public E next() {
/* 6954 */       checkModify();
/* 6955 */       E row = MCList.this.get(this._cursor);
/*      */       
/* 6957 */       this._lastcursor = this._cursor;
/* 6958 */       this._cursor++;
/* 6959 */       return row;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void remove() {
/* 6973 */       if (this._lastcursor == -1)
/*      */       {
/* 6975 */         throw new MCException(Core_Msg_FW_A.FCBBC0036, new Object[0]);
/*      */       }
/* 6977 */       checkModify();
/* 6978 */       MCList.this.remove(this._lastcursor);
/* 6979 */       if (this._lastcursor < this._cursor) {
/* 6980 */         this._cursor--;
/*      */       }
/* 6982 */       this._lastcursor = -1;
/* 6983 */       this._ownmodcnt = MCList.this._rows.modcnt();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void checkModify() {
/* 6995 */       if (this._ownmodcnt != MCList.this._rows.modcnt())
/*      */       {
/* 6997 */         throw new MCException(Core_Msg_FW_A.FCBBC0035, new Object[0]);
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private DIterator() {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private class DListIterator
/*      */     extends DIterator
/*      */     implements ListIterator<E>
/*      */   {
/*      */     public void add(E o) {
/* 7065 */       checkModify();
/* 7066 */       MCList.this.add(this._cursor, o);
/* 7067 */       this._cursor++;
/* 7068 */       this._lastcursor = -1;
/* 7069 */       this._ownmodcnt = MCList.this._rows.modcnt();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean hasPrevious() {
/* 7082 */       return (this._cursor != 0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int nextIndex() {
/* 7095 */       return this._cursor;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public E previous() {
/* 7110 */       checkModify();
/* 7111 */       int precursor = this._cursor - 1;
/* 7112 */       E row = MCList.this.get(precursor);
/*      */       
/* 7114 */       this._cursor = precursor;
/* 7115 */       this._lastcursor = this._cursor;
/* 7116 */       return row;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int previousIndex() {
/* 7129 */       return this._cursor - 1;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void set(E o) {
/* 7147 */       if (this._lastcursor == -1)
/*      */       {
/* 7149 */         throw new MCException(Core_Msg_FW_A.FCBBC0037, new Object[0]);
/*      */       }
/* 7151 */       checkModify();
/* 7152 */       MCList.this.set(this._lastcursor, o);
/* 7153 */       this._ownmodcnt = MCList.this._rows.modcnt();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     DListIterator() {
/* 7162 */       super(null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     DListIterator(int index) {
/* 7172 */       super(null);
/* 7173 */       this._cursor = index;
/*      */     }
/*      */   }
/*      */   
/*      */   private static interface ContainChecker {
/*      */     boolean contains(Object param1Object);
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\MCList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */