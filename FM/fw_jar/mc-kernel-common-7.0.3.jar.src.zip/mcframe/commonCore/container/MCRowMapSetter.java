package mcframe.commonCore.container;

public interface MCRowMapSetter {
  Comparable<?> getValue(MCRow paramMCRow);
  
  void setValue(MCRow paramMCRow, Comparable<?> paramComparable);
  
  int getParamColIndex(MCRow paramMCRow);
  
  void setParamColIndex(MCRow paramMCRow, int paramInt);
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\MCRowMapSetter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */