/*    */ package mcframe.commonCore.container;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCExtList
/*    */   extends LinkedHashMap<String, String>
/*    */ {
/*    */   public MCExtList() {}
/*    */   
/*    */   public MCExtList(String[][] keyValues) {
/* 34 */     if (keyValues == null)
/*    */       return;  byte b; int i;
/*    */     String[][] arrayOfString;
/* 37 */     for (i = (arrayOfString = keyValues).length, b = 0; b < i; ) { String[] kv = arrayOfString[b];
/* 38 */       if (kv.length >= 2) {
/* 39 */         put(kv[0], kv[1]);
/*    */       }
/*    */       b++; }
/*    */   
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<String> getKeyList() {
/* 52 */     return new ArrayList<>(keySet());
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\MCExtList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */