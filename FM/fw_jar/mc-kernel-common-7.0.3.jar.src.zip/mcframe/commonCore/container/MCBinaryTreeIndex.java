/*     */ package mcframe.commonCore.container;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MCBinaryTreeIndex<E extends MCRow>
/*     */   extends MCIndex<E>
/*     */ {
/*     */   private final MCRowComparator<E> _rowcomp;
/*     */   private final E[] _nodes;
/*     */   private final MCBinaryTreeIndexKey _idxkey;
/*     */   
/*     */   MCBinaryTreeIndex(MCRowComparator<E> comparator, MCList<E> ds) {
/*  58 */     super(ds);
/*  59 */     this._rowcomp = comparator;
/*  60 */     this._nodes = createIndex(comparator, ds);
/*  61 */     this._idxkey = new MCBinaryTreeIndexKey(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final E[] createIndex(MCRowComparator<E> comp, MCList<E> ds) {
/*  79 */     MCRow[] pointer = (MCRow[])ds.toArray();
/*  80 */     Arrays.sort(pointer, 0, pointer.length, comp);
/*  81 */     return (E[])pointer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void checkIndex(int index) {
/*  96 */     if (index < 0 || this._nodes.length <= index)
/*     */     {
/*  98 */       throw new MCException(Core_Msg_FW_A.FCBBC0033, new Object[] {
/*  99 */             getClass().getName(), 
/* 100 */             String.valueOf(this._nodes.length), 
/* 101 */             String.valueOf(index)
/*     */           });
/*     */     }
/*     */   }
/*     */   
/*     */   public final MCIndexKey getIndexKey() {
/* 107 */     return this._idxkey;
/*     */   }
/*     */   
/*     */   public final E get(int index) {
/* 111 */     checkIndex(index);
/*     */     
/* 113 */     return this._nodes[index];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Iterator<E> iterator() {
/* 126 */     return new IndexIterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCList<E> select(Comparable... vals) {
/* 136 */     if (vals == null) {
/* 137 */       return createSelectList(0);
/*     */     }
/* 139 */     String[] keys = this._idxkey._keys;
/* 140 */     MCRow.ColumnDefinition[] keycds = this._idxkey._keycds;
/* 141 */     return select(keys, keycds, (Comparable<?>[])vals, 0, this._nodes.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final MCList<E> select(String[] keys, MCRow.ColumnDefinition[] keycds, Comparable[] vals, int i, int j) {
/* 160 */     MCList<E> result = null;
/*     */     
/* 162 */     if (i == j) {
/* 163 */       result = createSelectList(0);
/*     */     } else {
/* 165 */       int x = (i + j) / 2;
/* 166 */       int comp = compare(this._nodes[x], keys, keycds, (Comparable<?>[])vals);
/* 167 */       if (comp > 0) {
/* 168 */         if (x != j) {
/* 169 */           result = select(keys, keycds, (Comparable<?>[])vals, i, x);
/*     */         } else {
/* 171 */           result = createSelectList(0);
/*     */         } 
/* 173 */       } else if (comp < 0) {
/* 174 */         if (x != i) {
/* 175 */           result = select(keys, keycds, (Comparable<?>[])vals, x, j);
/*     */         } else {
/* 177 */           result = createSelectList(0);
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 182 */         int min = x;
/* 183 */         while (min > 0 && compare(this._nodes[min - 1], keys, keycds, (Comparable<?>[])vals) == 0) {
/* 184 */           min--;
/*     */         }
/* 186 */         int last = this._nodes.length - 1;
/* 187 */         int max = x;
/* 188 */         while (max < last && compare(this._nodes[max + 1], keys, keycds, (Comparable<?>[])vals) == 0) {
/* 189 */           max++;
/*     */         }
/* 191 */         result = createSelectList(max - min + 1);
/* 192 */         while (min <= max) {
/* 193 */           result.add(this._nodes[min]);
/* 194 */           min++;
/*     */         } 
/*     */       } 
/*     */     } 
/* 198 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int compare(E row, String[] keys, MCRow.ColumnDefinition[] keycds, Comparable[] vals) {
/* 219 */     int comp = 0;
/* 220 */     int cols = (keys.length <= vals.length) ? keys.length : vals.length;
/* 221 */     if (keycds != null && keycds.length > 0) {
/* 222 */       for (int k = 0; k < cols && comp == 0; k++) {
/* 223 */         MCRow.ColumnDefinition keycd = (keycds.length > k) ? keycds[k] : null;
/* 224 */         Comparable<?> data = MCRow.getValue(keycd, keys[k], (MCRow)row);
/* 225 */         comp = this._rowcomp.compareCol(keys[k], data, vals[k]);
/*     */       } 
/*     */     } else {
/*     */       
/* 229 */       for (int k = 0; k < cols && comp == 0; k++) {
/* 230 */         Comparable<?> data = row.getValue(keys[k]);
/* 231 */         comp = this._rowcomp.compareCol(keys[k], data, vals[k]);
/*     */       } 
/*     */     } 
/* 234 */     return comp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class MCBinaryTreeIndexKey
/*     */     implements MCIndexKey
/*     */   {
/*     */     private final String[] _keys;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final MCRow.ColumnDefinition[] _keycds;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private MCBinaryTreeIndexKey() {
/* 268 */       this._keys = MCBinaryTreeIndex.this._rowcomp.getKeys();
/* 269 */       this._keycds = MCBinaryTreeIndex.this._rowcomp._keycdefs;
/*     */     }
/*     */     
/*     */     public final String[] getKeys() {
/* 273 */       return this._keys;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class IndexIterator
/*     */     implements Iterator<E>
/*     */   {
/* 297 */     protected final int _initial = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 304 */     int _cursor = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 311 */     int _lastcursor = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean hasNext() {
/* 322 */       return (this._cursor != MCBinaryTreeIndex.this._nodes.length);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public E next() {
/* 333 */       E row = MCBinaryTreeIndex.this.get(this._cursor);
/*     */       
/* 335 */       this._lastcursor = this._cursor;
/* 336 */       this._cursor++;
/* 337 */       return row;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void remove() {
/* 350 */       throw new MCException(Core_Msg_FW_A.FCBBC0039, new Object[0]);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\MCBinaryTreeIndex.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */