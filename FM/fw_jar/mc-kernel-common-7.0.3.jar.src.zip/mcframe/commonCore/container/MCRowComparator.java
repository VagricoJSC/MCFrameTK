/*     */ package mcframe.commonCore.container;
/*     */ 
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import mcframe.commonCore.lang.MCDataType;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCRowComparator<T extends MCRow>
/*     */   implements Comparator<T>
/*     */ {
/*     */   protected static final int NOT_NULL = 2147483647;
/*     */   protected static final int SMALL = -1;
/*     */   protected static final int EQUAL = 0;
/*     */   protected static final int LARGE = 1;
/*     */   
/*     */   public int compare(T row1, T row2) {
/* 132 */     int comp = compareRowNull(row1, row2);
/* 133 */     if (comp == Integer.MAX_VALUE) {
/*     */       
/* 135 */       comp = compareRowEmpty(row1, row2);
/* 136 */       if (comp == 0 && 
/* 137 */         this._keys != null) {
/* 138 */         for (int i = 0; i < this._keys.length; i++) {
/* 139 */           String name = this._keys[i];
/* 140 */           MCRow.ColumnDefinition cd = null;
/* 141 */           if (this._keycdefs != null && this._keycdefs.length > i) {
/* 142 */             cd = this._keycdefs[i];
/*     */           }
/*     */           try {
/* 145 */             Comparable<?> d1 = getValue(row1, name, cd);
/* 146 */             Comparable<?> d2 = getValue(row2, name, cd);
/* 147 */             comp = compareCol(name, d1, d2);
/*     */           }
/* 149 */           catch (MCException ex) {
/*     */             
/* 151 */             throw new MCException(ex, Core_Msg_FW_A.FCBBC0044, new Object[] {
/* 152 */                   row1.msgBindClassName(), 
/* 153 */                   row2.msgBindClassName(), 
/* 154 */                   name });
/*     */           } 
/* 156 */           if (comp != 0) {
/*     */             break;
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 163 */     return comp;
/*     */   }
/*     */ 
/*     */   
/*     */   Comparable<?> getValue(T row, String name, MCRow.ColumnDefinition cd) {
/* 168 */     return MCRow.getValue(cd, name, (MCRow)row);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 206 */   protected String[] _keys = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final MCRow.ColumnDefinition[] _keycdefs;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCRowComparator(List<String> keyList) {
/* 231 */     this((keyList != null) ? keyList.<String>toArray(new String[keyList.size()]) : null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCRowComparator(String... keys) {
/* 247 */     setKeys(keys);
/* 248 */     this._keycdefs = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCRowComparator(String[] keys, MCRow.ColumnDefinition[] keycdefs) {
/* 267 */     setKeys(keys);
/* 268 */     this._keycdefs = keycdefs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setKeys(String[] keys) {
/* 279 */     if (keys != null) {
/* 280 */       this._keys = new String[keys.length];
/* 281 */       System.arraycopy(keys, 0, this._keys, 0, keys.length);
/*     */     } else {
/*     */       
/* 284 */       this._keys = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getKeys() {
/* 296 */     String[] keys = null;
/* 297 */     if (this._keys != null) {
/* 298 */       keys = new String[this._keys.length];
/* 299 */       System.arraycopy(this._keys, 0, keys, 0, this._keys.length);
/*     */     } 
/* 301 */     return keys;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareCol(String name, Comparable<?> col1, Comparable<?> col2) {
/* 318 */     int comp = compareColNull(name, col1, col2);
/* 319 */     if (comp == Integer.MAX_VALUE) {
/*     */       try {
/* 321 */         comp = col1.compareTo(col2);
/*     */       }
/* 323 */       catch (ClassCastException classCastException) {
/*     */         
/* 325 */         String nonSupportType = "Non-Support Type";
/* 326 */         MCDataType type1 = MCDataType.analyze(col1);
/* 327 */         String tname1 = (type1 != null) ? 
/* 328 */           type1.toString() : nonSupportType;
/* 329 */         MCDataType type2 = MCDataType.analyze(col2);
/* 330 */         String tname2 = (type2 != null) ? 
/* 331 */           type2.toString() : nonSupportType;
/* 332 */         throw new MCException(Core_Msg_FW_A.FCBBC0045, new Object[] { name, tname1, tname2 });
/*     */       } 
/*     */     }
/* 335 */     return comp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int compareRowEmpty(T row1, T row2) {
/* 352 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int compareRowNull(T row1, T row2) {
/* 372 */     return compareNull(row1, row2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int compareColNull(String name, Comparable<?> col1, Comparable<?> col2) {
/* 393 */     return compareNull(col1, col2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int compareNull(Object obj1, Object obj2) {
/* 412 */     if (obj1 == null) {
/* 413 */       if (obj2 != null) {
/* 414 */         return 1;
/*     */       }
/*     */     } else {
/*     */       
/* 418 */       if (obj2 == null) {
/* 419 */         return -1;
/*     */       }
/* 421 */       return Integer.MAX_VALUE;
/*     */     } 
/* 423 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ASC<E extends MCRow>
/*     */     extends MCRowComparator<E>
/*     */   {
/*     */     public ASC(List<String> keyList) {
/* 470 */       super(keyList);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ASC(String... keys) {
/* 484 */       super(keys);
/*     */     }
/*     */     
/*     */     ASC(String[] keys, MCRow.ColumnDefinition[] keycdefs) {
/* 488 */       super(keys, keycdefs);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected int compareRowEmpty(E row1, E row2) {
/* 506 */       if (row1 == null || row2 == null) {
/* 507 */         return compareRowNull(row1, row2);
/*     */       }
/*     */       
/* 510 */       boolean emp1 = row1.isEmpty();
/* 511 */       boolean emp2 = row2.isEmpty();
/* 512 */       return (emp1 == emp2) ? 0 : (emp1 ? 1 : -1);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class DESC<E extends MCRow>
/*     */     extends ASC<E>
/*     */   {
/*     */     public DESC(List<String> keyList) {
/* 555 */       super(keyList);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DESC(String... keys) {
/* 569 */       super(keys);
/*     */     }
/*     */     
/*     */     DESC(String[] keys, MCRow.ColumnDefinition[] keycdefs) {
/* 573 */       super(keys, keycdefs);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int compareCol(String name, Comparable col1, Comparable col2) {
/* 580 */       return super.compareCol(name, col1, col2) * -1;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected int compareColNull(String name, Comparable<?> o1, Comparable<?> o2) {
/* 586 */       int ret = super.compareColNull(name, o1, o2);
/* 587 */       if (ret != Integer.MAX_VALUE) {
/* 588 */         ret *= -1;
/*     */       }
/* 590 */       return ret;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class ASC_NULL_AHEAD<E extends MCRow>
/*     */     extends ASC<E>
/*     */   {
/*     */     public ASC_NULL_AHEAD(List<String> keyList) {
/* 633 */       super(keyList);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ASC_NULL_AHEAD(String... keys) {
/* 647 */       super(keys);
/*     */     }
/*     */     
/*     */     ASC_NULL_AHEAD(String[] keys, MCRow.ColumnDefinition[] keycdefs) {
/* 651 */       super(keys, keycdefs);
/*     */     }
/*     */     
/*     */     protected int compareRowNull(E row1, E row2) {
/* 655 */       int ret = super.compareRowNull(row1, row2);
/* 656 */       if (ret != Integer.MAX_VALUE) {
/* 657 */         ret *= -1;
/*     */       }
/* 659 */       return ret;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected int compareColNull(String name, Comparable<?> o1, Comparable<?> o2) {
/* 665 */       int ret = super.compareColNull(name, o1, o2);
/* 666 */       if (ret != Integer.MAX_VALUE) {
/* 667 */         ret *= -1;
/*     */       }
/* 669 */       return ret;
/*     */     }
/*     */ 
/*     */     
/*     */     protected int compareRowEmpty(E row1, E row2) {
/* 674 */       return super.compareRowEmpty(row1, row2) * -1;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class DESC_NULL_AHEAD<E extends MCRow>
/*     */     extends ASC<E>
/*     */   {
/*     */     public DESC_NULL_AHEAD(List<String> keyList) {
/* 717 */       super(keyList);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DESC_NULL_AHEAD(String... keys) {
/* 731 */       super(keys);
/*     */     }
/*     */     DESC_NULL_AHEAD(String[] keys, MCRow.ColumnDefinition[] keycdefs) {
/* 734 */       super(keys, keycdefs);
/*     */     }
/*     */     
/*     */     public int compare(E row1, E row2) {
/* 738 */       return super.compare(row1, row2) * -1;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\MCRowComparator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */