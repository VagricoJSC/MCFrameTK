/*     */ package mcframe.commonCore.container;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.RoundingMode;
/*     */ import java.util.Map;
/*     */ import mcframe.commonCore.lang.MCDataType;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class MCAggregate<E extends MCRow>
/*     */ {
/*     */   protected final String _name;
/*     */   protected final MCRow.ColumnDefinition _namecd;
/*     */   protected final String _result;
/*     */   protected final MCRowMatcher<E> _matcher;
/*     */   
/*     */   static final class AVG<E extends MCRow>
/*     */     extends MCAggregate<E>
/*     */   {
/*     */     private int _cnt;
/*     */     private MCNumber _total;
/*     */     private RoundingMode _mode;
/*     */     private Integer _scale;
/*     */     private MCMeta _meta;
/*     */     
/*     */     AVG(String name, MCRow.ColumnDefinition namecd, String result, MCRowMatcher<E> matcher) {
/* 112 */       super(name, namecd, result, "AVG", matcher);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void init() {
/* 117 */       this._cnt = 0;
/* 118 */       this._total = null;
/*     */ 
/*     */       
/* 121 */       this._mode = MCNumber.MODE_DOWN;
/* 122 */       this._scale = null;
/*     */     }
/*     */ 
/*     */     
/*     */     protected AVG<E> createInstance() {
/* 127 */       AVG<E> a = new AVG(this._name, this._namecd, this._result, this._matcher);
/*     */ 
/*     */       
/* 130 */       a._mode = this._mode;
/* 131 */       a._scale = this._scale;
/*     */       
/* 133 */       return a;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void setOption(Map<String, Object> option) {
/* 138 */       if (option == null) {
/*     */         return;
/*     */       }
/*     */       
/* 142 */       Integer scale = (Integer)getOptionValue(option, "scale", Integer.class);
/* 143 */       if (scale != null) {
/* 144 */         this._scale = scale;
/*     */       }
/*     */       
/* 147 */       this._mode = (RoundingMode)getOptionValue(option, "mode", RoundingMode.class);
/* 148 */       if (scale != null) {
/* 149 */         this._scale = scale;
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void add(E row) {
/* 172 */       if (!this._matcher.match(row)) {
/*     */         return;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 179 */       if (this._meta == null) {
/* 180 */         this._meta = MCRow.getMeta(this._namecd, this._name, (MCRow)row);
/* 181 */         if (this._meta != null && this._meta.type() != MCDataType.NUMBER)
/*     */         {
/* 183 */           throw new MCException(Core_Msg_FW_A.FCBBC0050, new Object[] { this._meta.name(), this._meta.type() });
/*     */         }
/*     */       } 
/*     */       try {
/* 187 */         MCNumber val = (MCNumber)MCRow.getValue(this._namecd, this._name, (MCRow)row);
/* 188 */         if (val != null) {
/* 189 */           if (this._total == null) {
/* 190 */             this._total = MCNumber.ZERO;
/*     */           }
/* 192 */           this._total = this._total.add((BigDecimal)val);
/* 193 */           this._cnt++;
/*     */         }
/*     */       
/* 196 */       } catch (MCException ex) {
/*     */ 
/*     */         
/* 199 */         throw ex;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected MCNumber get() {
/* 217 */       if (this._total == null) {
/* 218 */         return null;
/*     */       }
/*     */ 
/*     */       
/* 222 */       int scale = this._meta.scale();
/* 223 */       if (this._scale != null) {
/* 224 */         scale = this._scale.intValue();
/*     */ 
/*     */       
/*     */       }
/* 228 */       else if (scale == -1) {
/* 229 */         scale = this._total.scale();
/*     */       } 
/*     */ 
/*     */       
/* 233 */       MCNumber newval = this._total.setScale(scale + 1, MCNumber.MODE_DOWN);
/* 234 */       newval = newval.divide((BigDecimal)new MCNumber(this._cnt), MCNumber.MODE_DOWN);
/*     */       
/* 236 */       return newval.setScale(scale, this._mode);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void setTo(E row) {
/* 257 */       if (row != null)
/*     */       {
/* 259 */         row.setNumberNE(this._result, get());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class COUNT<E extends MCRow>
/*     */     extends MCAggregate<E>
/*     */   {
/*     */     static final String ALL = "*";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private int _cnt;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     COUNT(String name, MCRow.ColumnDefinition namecd, String result, MCRowMatcher<E> matcher) {
/* 300 */       super(name, namecd, result, "COUNT", matcher);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void init() {
/* 305 */       this._cnt = 0;
/*     */     }
/*     */ 
/*     */     
/*     */     protected COUNT<E> createInstance() {
/* 310 */       COUNT<E> a = new COUNT(this._name, this._namecd, this._result, this._matcher);
/*     */ 
/*     */       
/* 313 */       return a;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void add(E row) {
/* 331 */       if (!this._matcher.match(row)) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 336 */       if (this._name == "*") {
/*     */         
/* 338 */         this._cnt++;
/*     */         
/*     */         return;
/*     */       } 
/*     */       try {
/* 343 */         Comparable<?> val = MCRow.getValue(this._namecd, this._name, (MCRow)row);
/* 344 */         if (val != null) {
/* 345 */           this._cnt++;
/*     */         }
/*     */       }
/* 348 */       catch (MCException ex) {
/*     */         
/* 350 */         throw ex;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected MCNumber get() {
/* 366 */       return new MCNumber(this._cnt);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected int intValue() {
/* 380 */       return this._cnt;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void setTo(E row) {
/* 401 */       if (row != null)
/*     */       {
/* 403 */         row.setNumberNE(this._result, get());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class MIN<E extends MCRow>
/*     */     extends MCAggregate<E>
/*     */   {
/*     */     private Comparable<?> _min;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     MIN(String name, MCRow.ColumnDefinition namecd, String result, MCRowMatcher<E> matcher) {
/* 438 */       super(name, namecd, result, "MIN", matcher);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void init() {
/* 443 */       this._min = null;
/*     */     }
/*     */ 
/*     */     
/*     */     protected MIN<E> createInstance() {
/* 448 */       MIN<E> a = new MIN(this._name, this._namecd, this._result, this._matcher);
/*     */ 
/*     */       
/* 451 */       return a;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void add(E row) {
/* 470 */       if (!this._matcher.match(row)) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/*     */       try {
/* 476 */         Comparable<?> val = MCRow.getValue(this._namecd, this._name, (MCRow)row);
/* 477 */         if (val != null) {
/* 478 */           if (this._min == null) {
/* 479 */             this._min = val;
/* 480 */           } else if (val.compareTo(this._min) < 0) {
/* 481 */             this._min = val;
/*     */           }
/*     */         
/*     */         }
/* 485 */       } catch (MCException ex) {
/*     */         
/* 487 */         throw ex;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected Comparable<?> get() {
/* 503 */       return this._min;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void setTo(E row) {
/* 524 */       if (row != null)
/*     */       {
/* 526 */         row.setValueNE(this._result, get());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class MAX<E extends MCRow>
/*     */     extends MCAggregate<E>
/*     */   {
/*     */     private Comparable<?> _max;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     MAX(String name, MCRow.ColumnDefinition namecd, String result, MCRowMatcher<E> matcher) {
/* 561 */       super(name, namecd, result, "MAX", matcher);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void init() {
/* 566 */       this._max = null;
/*     */     }
/*     */ 
/*     */     
/*     */     protected MAX<E> createInstance() {
/* 571 */       MAX<E> a = new MAX(this._name, this._namecd, this._result, this._matcher);
/*     */ 
/*     */       
/* 574 */       return a;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void add(E row) {
/* 593 */       if (!this._matcher.match(row)) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/*     */       try {
/* 599 */         Comparable<?> val = MCRow.getValue(this._namecd, this._name, (MCRow)row);
/* 600 */         if (val != null) {
/* 601 */           if (this._max == null) {
/* 602 */             this._max = val;
/* 603 */           } else if (val.compareTo(this._max) > 0) {
/* 604 */             this._max = val;
/*     */           }
/*     */         
/*     */         }
/* 608 */       } catch (MCException ex) {
/*     */         
/* 610 */         throw ex;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected Comparable<?> get() {
/* 626 */       return this._max;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void setTo(E row) {
/* 647 */       if (row != null)
/*     */       {
/* 649 */         row.setValueNE(this._result, get());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final class SUM<E extends MCRow>
/*     */     extends MCAggregate<E>
/*     */   {
/*     */     private MCNumber _total;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     SUM(String name, MCRow.ColumnDefinition namecd, String result, MCRowMatcher<E> matcher) {
/* 683 */       super(name, namecd, result, "SUM", matcher);
/*     */     }
/*     */ 
/*     */     
/*     */     public void init() {
/* 688 */       this._total = null;
/*     */     }
/*     */ 
/*     */     
/*     */     protected SUM<E> createInstance() {
/* 693 */       SUM<E> a = new SUM(this._name, this._namecd, this._result, this._matcher);
/*     */ 
/*     */       
/* 696 */       return a;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void add(E row) {
/* 715 */       if (!this._matcher.match(row)) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/*     */       try {
/* 721 */         MCNumber val = (MCNumber)MCRow.getValue(this._namecd, this._name, (MCRow)row);
/* 722 */         if (val != null) {
/* 723 */           if (this._total == null) {
/* 724 */             this._total = MCNumber.ZERO;
/*     */           }
/* 726 */           this._total = this._total.add((BigDecimal)val);
/*     */         }
/*     */       
/*     */       }
/* 730 */       catch (RuntimeException ex) {
/* 731 */         MCException mCException; if (ex instanceof ClassCastException) {
/* 732 */           MCMeta meta = MCRow.getMeta(this._namecd, this._name, (MCRow)row);
/* 733 */           if (meta != null && meta.type() != MCDataType.NUMBER)
/*     */           {
/* 735 */             mCException = new MCException(ex, Core_Msg_FW_A.FCBBC0049, new Object[] {
/* 736 */                   meta.name(), meta.type()
/*     */                 });
/*     */           }
/*     */         } 
/*     */         
/* 741 */         throw mCException;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MCNumber get() {
/* 758 */       return this._total;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void setTo(E row) {
/* 779 */       if (row != null)
/*     */       {
/* 781 */         row.setNumberNE(this._result, get());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final <T extends MCRow> void setToRow(T row, MCAggregate... ag) {
/* 806 */     if (row != null) {
/* 807 */       for (int i = ag.length - 1; i >= 0; i--) {
/* 808 */         ag[i].setTo(row);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCAggregate(String name, MCRow.ColumnDefinition namecd, String result, String type, MCRowMatcher<E> matcher) {
/* 864 */     if (name == null)
/*     */     {
/* 866 */       throw new MCException(Core_Msg_FW_A.FCBBC0048, new Object[] { type });
/*     */     }
/* 868 */     this._name = name;
/* 869 */     this._namecd = namecd;
/* 870 */     this._result = (result != null) ? result : name;
/* 871 */     this._matcher = (matcher != null) ? matcher : new MCRowMatcher<E>()
/*     */       {
/*     */         public boolean match(E row)
/*     */         {
/* 875 */           return true;
/*     */         }
/*     */       };
/* 878 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setOption(Map<String, Object> option) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected <T> T getOptionValue(Map<String, Object> option, String key, Class<T> c) {
/* 907 */     Object val = option.get(key);
/*     */     try {
/* 909 */       return c.cast(val);
/*     */     }
/* 911 */     catch (ClassCastException classCastException) {
/*     */       
/* 913 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String name() {
/* 925 */     return this._name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String result() {
/* 937 */     return this._result;
/*     */   }
/*     */   
/*     */   protected abstract void init();
/*     */   
/*     */   protected abstract MCAggregate<E> createInstance();
/*     */   
/*     */   protected abstract void add(E paramE);
/*     */   
/*     */   protected abstract Comparable<?> get();
/*     */   
/*     */   protected abstract void setTo(E paramE);
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\MCAggregate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */