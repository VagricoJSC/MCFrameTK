/*     */ package mcframe.commonCore.container;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import mcframe.commonCore.lang.MCDataType;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class MCByNameRowMapper
/*     */ {
/*     */   final MCRow srcrow;
/*     */   final MCRow destrow;
/*     */   final List<Mapping> mappings;
/*     */   
/*     */   class Mapping
/*     */   {
/*     */     final MCDataType type;
/*     */     final String srcname;
/*     */     final String destname;
/*     */     
/*     */     Mapping(MCDataType type, String srcname, String destname) {
/*  60 */       this.type = type;
/*  61 */       this.srcname = srcname;
/*  62 */       this.destname = destname;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCByNameRowMapper(MCRow srcrow, MCRow destrow, int mapsize) {
/* 100 */     if (srcrow == null)
/*     */     {
/* 102 */       throw new MCException(Core_Msg_FW_A.FCBBC0025, new Object[0]);
/*     */     }
/* 104 */     if (destrow == null)
/*     */     {
/* 106 */       throw new MCException(Core_Msg_FW_A.FCBBC0030, new Object[0]);
/*     */     }
/* 108 */     this.srcrow = srcrow;
/* 109 */     this.destrow = destrow;
/* 110 */     this.mappings = (mapsize < 0) ? 
/* 111 */       new ArrayList<>() : 
/* 112 */       new ArrayList<>(mapsize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void entry(String srcname, String destname) {
/* 135 */     MCMeta srcmeta = this.srcrow.getMeta(srcname);
/* 136 */     if (srcmeta == null)
/*     */     {
/* 138 */       throw this.srcrow.throw_ColumnNotFound(srcname);
/*     */     }
/* 140 */     MCMeta destmeta = this.destrow.getMeta(destname);
/* 141 */     if (destmeta == null)
/*     */     {
/* 143 */       throw this.destrow.throw_ColumnNotFound(destname);
/*     */     }
/* 145 */     if (srcmeta.type() != destmeta.type())
/*     */     {
/* 147 */       this.destrow.throw_setValues_InvalidDataType(
/* 148 */           destmeta.name(), destmeta.type(), 
/* 149 */           this.srcrow, srcmeta.name(), srcmeta.type());
/*     */     }
/*     */     
/* 152 */     Mapping mapping = new Mapping(srcmeta.type(), srcname, destname);
/* 153 */     this.mappings.add(mapping);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void entryNE(String srcname, String destname, boolean addtemp) {
/* 191 */     MCMeta srcmeta = this.srcrow.getMeta(srcname);
/* 192 */     if (srcmeta == null)
/*     */     {
/* 194 */       throw this.srcrow.throw_ColumnNotFound(srcname);
/*     */     }
/* 196 */     MCMeta destmeta = this.destrow.getMeta(destname);
/* 197 */     if (destmeta != null) {
/* 198 */       if (srcmeta.type() != destmeta.type())
/*     */       {
/* 200 */         this.destrow.throw_setValues_InvalidDataType(
/* 201 */             destmeta.name(), destmeta.type(), 
/* 202 */             this.srcrow, srcmeta.name(), srcmeta.type());
/*     */       
/*     */       }
/*     */     }
/* 206 */     else if (addtemp) {
/* 207 */       this.destrow.addValueColumn(destname, srcmeta.type());
/*     */     } else {
/*     */       
/* 210 */       destname = null;
/*     */     } 
/*     */ 
/*     */     
/* 214 */     Mapping mapping = new Mapping(srcmeta.type(), srcname, destname);
/* 215 */     this.mappings.add(mapping);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\MCByNameRowMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */