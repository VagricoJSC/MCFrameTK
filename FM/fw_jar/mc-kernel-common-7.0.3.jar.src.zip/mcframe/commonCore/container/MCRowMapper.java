/*     */ package mcframe.commonCore.container;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import mcframe.commonCore.lang.MCDataType;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MCRowMapper<D extends MCRow, S extends MCRow>
/*     */ {
/*  35 */   private Map<String, String> pathMap = null;
/*     */ 
/*     */ 
/*     */   
/*     */   private MCRowMapSetter[] setter;
/*     */ 
/*     */ 
/*     */   
/*     */   private MCRowMapSetter[] getter;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCRowMapper() {
/*  49 */     setupColumnPathMap();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setupColumnPathMap() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addColumnPathMap(String destCol, String srcCol) {
/*  82 */     if (MCStringUtil.isNull(destCol) || MCStringUtil.isNull(srcCol)) {
/*  83 */       throw new MCException(Core_Msg_FW_A.FCBAC0439, new Object[0]);
/*     */     }
/*  85 */     getColumnPathMap().put(destCol, srcCol);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, String> getColumnPathMap() {
/*  96 */     if (this.pathMap == null) {
/*  97 */       this.pathMap = new HashMap<>();
/*     */     }
/*  99 */     return this.pathMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setupIndex(D dest, S src) {
/* 112 */     if (this.pathMap != null) {
/* 113 */       int size = this.pathMap.size();
/* 114 */       this.setter = new MCRowMapSetter[size];
/* 115 */       this.getter = new MCRowMapSetter[size];
/* 116 */       int i = 0;
/* 117 */       for (Map.Entry<String, String> entry : this.pathMap.entrySet()) {
/* 118 */         this.setter[i] = createSetter((MCRow)dest, entry.getKey());
/* 119 */         this.getter[i] = createSetter((MCRow)src, entry.getValue());
/* 120 */         i++;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCRowMapSetter createSetter(MCRow r, String k) {
/* 135 */     int index = MCConstColumnList.indexOf(r, k);
/* 136 */     if (index != -1) {
/* 137 */       return new MCConstRowMapSetter(k, MCConstColumnList.meta(r, index).type(), 
/* 138 */           index);
/*     */     }
/* 140 */     index = MCRow.indexOfAlias(r._list, k);
/* 141 */     if (index != -1) {
/* 142 */       return createSetter(r, r._list.aliasPath(r, index));
/*     */     }
/* 144 */     String[] sp = MCRow.splitColumnPath(k);
/* 145 */     if (sp.length > 1) {
/* 146 */       index = MCConstColumnList.indexOf(r, sp[0]);
/* 147 */       if (index != -1) {
/* 148 */         String newPath = 
/* 149 */           MCRow.createColumnPath(Arrays.<String>copyOfRange(sp, 1, sp.length));
/* 150 */         return new MCInnerRowMapSetter(index, 
/* 151 */             createSetter((MCRow)MCConstColumnList.get(r, index), newPath));
/*     */       } 
/* 153 */       index = MCRow.indexOfAlias(r._list, sp[0]);
/* 154 */       if (index != -1) {
/* 155 */         sp[0] = r._list.aliasPath(r, index);
/* 156 */         return createSetter(r, MCRow.createColumnPath(sp));
/*     */       } 
/*     */     } 
/* 159 */     return new MCTempRowMapSetter(k);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void copy(D dest, S src) {
/* 182 */     if (dest == null || src == null) {
/*     */       return;
/*     */     }
/* 185 */     _valueCopy(dest, src);
/* 186 */     _rowAttributesCopy(dest, src);
/* 187 */     dest.setAttributes((MCRow)src);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void copyValue(D dest, S src) {
/* 204 */     if (dest == null || src == null) {
/*     */       return;
/*     */     }
/* 207 */     _valueCopy(dest, src);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <F extends MCList<S>> void join(D dest, MCJoinKey<F> key) {
/* 233 */     if (dest == null || key == null) {
/*     */       return;
/*     */     }
/* 236 */     F srclist = dest.getJoined(key);
/* 237 */     if (srclist.size() > 0) {
/* 238 */       _valueCopy(dest, srclist.get(0));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _rowAttributesCopy(D dest, S src) {
/* 251 */     if (this.setter != null) {
/* 252 */       for (int i = 0; i < this.setter.length; i++) {
/* 253 */         this.setter[i].setParamColIndex((MCRow)dest, this.getter[i].getParamColIndex((MCRow)src));
/*     */       }
/*     */     }
/* 256 */     rowAttributesCopy(dest, src);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void rowAttributesCopy(D dest, S src) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _valueCopy(D dest, S src) {
/* 279 */     if (this.setter == null) {
/* 280 */       setupIndex(dest, src);
/*     */     }
/* 282 */     if (this.setter != null) {
/* 283 */       for (int i = 0; i < this.setter.length; i++) {
/* 284 */         this.setter[i].setValue((MCRow)dest, this.getter[i].getValue((MCRow)src));
/*     */       }
/*     */     }
/* 287 */     valueCopy(dest, src);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void valueCopy(D dest, S src) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class MCTempRowMapSetter
/*     */     implements MCRowMapSetter
/*     */   {
/*     */     private final String colName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     MCTempRowMapSetter(String colName) {
/* 326 */       this.colName = colName;
/*     */     }
/*     */ 
/*     */     
/*     */     public Comparable<?> getValue(MCRow r) {
/* 331 */       return r.getValueNE(this.colName);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setValue(MCRow r, Comparable<?> v) {
/* 336 */       r.setValueNE(this.colName, v);
/*     */     }
/*     */ 
/*     */     
/*     */     public int getParamColIndex(MCRow r) {
/* 341 */       return r.getParamColIndexNE(this.colName);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setParamColIndex(MCRow r, int i) {
/* 346 */       r.setParamColIndexNE(this.colName, i);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class MCConstRowMapSetter
/*     */     implements MCRowMapSetter
/*     */   {
/*     */     private final String name;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final MCDataType type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final int index;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MCConstRowMapSetter(String name, MCDataType type, int index) {
/* 385 */       this.name = name;
/* 386 */       this.type = type;
/* 387 */       this.index = index;
/*     */     }
/*     */ 
/*     */     
/*     */     public Comparable<?> getValue(MCRow r) {
/* 392 */       return MCConstColumnList.get(r, this.index);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setValue(MCRow r, Comparable<?> v) {
/* 397 */       if (this.type == MCDataType.ROW && r instanceof MCConstRow && v instanceof MCRow) {
/* 398 */         ((MCConstRow)r).setConstInnerRow(this.index, this.name, (MCRow)v);
/*     */       } else {
/*     */         
/* 401 */         MCConstColumnList.set(r, this.index, this.name, v);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public int getParamColIndex(MCRow r) {
/* 407 */       return MCConstColumnList.paramColIndex(r, this.index);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setParamColIndex(MCRow r, int i) {
/* 412 */       MCConstColumnList.setParamColIndex(r, this.index, this.type, i);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class MCInnerRowMapSetter
/*     */     implements MCRowMapSetter
/*     */   {
/*     */     private final int index;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final MCRowMapSetter setter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MCInnerRowMapSetter(int index, MCRowMapSetter setter) {
/* 445 */       this.index = index;
/* 446 */       this.setter = setter;
/*     */     }
/*     */ 
/*     */     
/*     */     public Comparable<?> getValue(MCRow r) {
/* 451 */       MCRow inner = (MCRow)MCConstColumnList.get(r, this.index);
/* 452 */       return this.setter.getValue(inner);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setValue(MCRow r, Comparable<?> v) {
/* 457 */       MCRow inner = (MCRow)MCConstColumnList.get(r, this.index);
/* 458 */       this.setter.setValue(inner, v);
/*     */     }
/*     */ 
/*     */     
/*     */     public int getParamColIndex(MCRow r) {
/* 463 */       MCRow inner = (MCRow)MCConstColumnList.get(r, this.index);
/* 464 */       return this.setter.getParamColIndex(inner);
/*     */     }
/*     */ 
/*     */     
/*     */     public void setParamColIndex(MCRow r, int i) {
/* 469 */       MCRow inner = (MCRow)MCConstColumnList.get(r, this.index);
/* 470 */       this.setter.setParamColIndex(inner, i);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\MCRowMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */