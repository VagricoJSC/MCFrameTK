/*     */ package mcframe.commonCore.container;
/*     */ 
/*     */ import mcframe.commonCore.lang.MCBinary;
/*     */ import mcframe.commonCore.lang.MCDataType;
/*     */ import mcframe.commonCore.lang.MCDate;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.lang.MCTimestamp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbsMCPackageProxy
/*     */ {
/*     */   protected Comparable<?> getValue(MCRow row, String name) {
/*  39 */     return row.getValue(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Comparable<?> setValue(MCRow row, String name, Comparable<?> value, MCDataType type) {
/*  52 */     row.setValue(name, type, value);
/*  53 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setParamIndex(MCList<?> ds, int index) {
/*  65 */     ds.setParamIndex(index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setParamIndex(MCRow row, int index) {
/*  75 */     row.setParamIndex(index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setParamRowIndex(MCRow row, int index) {
/*  85 */     row.setParamRowIndex(index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isGUICreated(MCRow row) {
/*  97 */     return row.isGUICreated();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isGUIModified(MCRow row) {
/* 107 */     return row.isGUIModified();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isGUIDeleted(MCRow row) {
/* 117 */     return row.isGUIDeleted();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setGUICreated(MCRow row, boolean on) {
/* 127 */     row.setGUICreated(on);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setGUIModified(MCRow row, boolean on) {
/* 137 */     row.setGUIModified(on);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setGUIDeleted(MCRow row, boolean on) {
/* 147 */     row.setGUIDeleted(on);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setGUIVisible(MCRow row, boolean visible) {
/* 159 */     row.setGUIVisible(visible);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCRow.ColumnDefinition getColumnDefinition(MCRow row, String name) {
/* 167 */     return row.getColumnDefinition(name);
/*     */   }
/*     */   
/*     */   protected MCRow.ColumnDefinition getColumnDefinition(MCRow row, MCRow.ColumnDefinition before) {
/* 171 */     return row.getColumnDefinition(before);
/*     */   }
/*     */   
/*     */   protected void setValue(MCRow row, MCRow.ColumnDefinition columnDefinition, Comparable<?> value, MCDataType type) {
/* 175 */     row.setValue(columnDefinition, value, type);
/*     */   }
/*     */   
/*     */   protected MCRow.ColumnDefinition getColumnDefinition(MCList<?> list, MCRow.ColumnDefinition before) {
/* 179 */     return list.getColumnDefinition(before);
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCRow.MCColumnValue getColumnValueNE(MCRow row, String name) {
/* 184 */     return row.getColumnValueNE(name);
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getConstColIndex(MCRow row, String name) {
/* 189 */     return row.getConstColIndex(name);
/*     */   }
/*     */   
/*     */   protected void setConstString(MCRow row, int index, String name, String value) {
/* 193 */     row.setConstString(index, name, value);
/*     */   }
/*     */   
/*     */   protected void setConstNumber(MCRow row, int index, String name, MCNumber value) {
/* 197 */     row.setConstNumber(index, name, value);
/*     */   }
/*     */   
/*     */   protected void setConstNumber(MCRow row, int index, String name, int value) {
/* 201 */     row.setConstNumber(index, name, value);
/*     */   }
/*     */   
/*     */   protected void setConstNumber(MCRow row, int index, String name, long value) {
/* 205 */     row.setConstNumber(index, name, value);
/*     */   }
/*     */   
/*     */   protected void setConstNumber(MCRow row, int index, String name, float value) {
/* 209 */     row.setConstNumber(index, name, value);
/*     */   }
/*     */   
/*     */   protected void setConstNumber(MCRow row, int index, String name, double value) {
/* 213 */     row.setConstNumber(index, name, value);
/*     */   }
/*     */   
/*     */   protected void setConstDate(MCRow row, int index, String name, MCDate value) {
/* 217 */     row.setConstDate(index, name, value);
/*     */   }
/*     */   
/*     */   protected void setConstTimestamp(MCRow row, int index, String name, MCTimestamp value) {
/* 221 */     row.setConstTimestamp(index, name, value);
/*     */   }
/*     */   
/*     */   protected void setConstBoolean(MCRow row, int index, String name, boolean value) {
/* 225 */     row.setConstBoolean(index, name, value);
/*     */   }
/*     */   
/*     */   protected void setConstBinary(MCRow row, int index, String name, MCBinary value) {
/* 229 */     row.setConstBinary(index, name, value);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\AbsMCPackageProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */