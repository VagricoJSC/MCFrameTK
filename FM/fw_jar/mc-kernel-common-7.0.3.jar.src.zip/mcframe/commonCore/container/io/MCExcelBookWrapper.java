/*     */ package mcframe.commonCore.container.io;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import org.apache.poi.ss.usermodel.Workbook;
/*     */ import org.apache.poi.xssf.usermodel.XSSFWorkbook;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCExcelBookWrapper
/*     */   implements AutoCloseable
/*     */ {
/*     */   private final String _fileName;
/*     */   private final Workbook _workbook;
/*     */   private final MCContainerIOConfig _config;
/*     */   
/*     */   enum IOMode
/*     */   {
/*  56 */     READ,
/*  57 */     WRITE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCExcelBookWrapper(String fileName, MCContainerIOConfig config) {
/*  71 */     this(fileName, config, IOMode.READ);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCExcelBookWrapper(String fileName, MCContainerIOConfig config, IOMode mode) {
/*  85 */     this._fileName = fileName;
/*  86 */     this._config = config;
/*     */     
/*  88 */     if (mode == IOMode.READ) {
/*  89 */       File file = new File(this._fileName); try {
/*  90 */         Exception exception2, exception1 = null;
/*     */ 
/*     */       
/*     */       }
/*  94 */       catch (Exception e) {
/*  95 */         throw new MCException(e, Core_Msg_FW_A.FCBLC0006, new Object[] { this._fileName });
/*     */       } 
/*     */     } else {
/*     */       
/*  99 */       this._workbook = (Workbook)new XSSFWorkbook();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCExcelSheetReader getActiveSheetReader() {
/* 112 */     return new MCExcelSheetReader(
/* 113 */         this._workbook.getSheetAt(this._workbook.getActiveSheetIndex()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCExcelSheetReader getSheetReaderAt(int index) {
/* 126 */     if (this._workbook.isSheetHidden(index)) {
/* 127 */       return null;
/*     */     }
/* 129 */     return new MCExcelSheetReader(this._workbook.getSheetAt(index));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getNumberOfSheets() {
/* 140 */     return this._workbook.getNumberOfSheets();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCExcelSheetWriter getSheetWriter(String name) {
/* 153 */     if (this._workbook.getSheet(name) == null) {
/* 154 */       this._workbook.createSheet(name);
/*     */     }
/* 156 */     return new MCExcelSheetWriter(this._workbook.getSheet(name));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeBook() {
/* 165 */     File file = new File(this._fileName); try {
/* 166 */       Exception exception2, exception1 = null;
/*     */     
/*     */     }
/* 169 */     catch (Exception e) {
/* 170 */       int idx = file.getName().lastIndexOf(".");
/* 171 */       String extension = (idx == -1) ? 
/* 172 */         "" : 
/* 173 */         file.getName().substring(idx);
/* 174 */       throw new MCException(e, Core_Msg_FW_A.FCBLC2006, new Object[] { this._fileName, extension });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSheetNameAt(int index) {
/* 188 */     return (index >= 0 || index < this._workbook.getNumberOfSheets()) ? 
/* 189 */       this._workbook.getSheetName(index) : 
/* 190 */       null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/*     */     try {
/* 202 */       this._workbook.close();
/*     */     }
/* 204 */     catch (IOException iOException) {}
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\io\MCExcelBookWrapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */