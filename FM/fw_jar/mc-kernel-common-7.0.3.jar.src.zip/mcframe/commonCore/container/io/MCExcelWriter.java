/*    */ package mcframe.commonCore.container.io;
/*    */ 
/*    */ import mcframe.commonCore.container.MCList;
/*    */ import mcframe.commonCore.notice.MCMessageList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCExcelWriter
/*    */ {
/*    */   public <T extends mcframe.commonCore.container.MCRow> MCExcelWriter(MCList<T> container, String fileName) {}
/*    */   
/*    */   public MCMessageList write() {
/* 23 */     MCMessageList result = new MCMessageList();
/*    */     
/* 25 */     return result;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MCMessageList write(MCContainerIOConfig config) {
/* 34 */     MCMessageList result = new MCMessageList();
/*    */     
/* 36 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\io\MCExcelWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */