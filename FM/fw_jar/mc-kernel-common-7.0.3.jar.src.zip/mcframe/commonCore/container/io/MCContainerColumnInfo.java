/*     */ package mcframe.commonCore.container.io;
/*     */ 
/*     */ import java.io.File;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCBinary;
/*     */ import mcframe.commonCore.lang.MCDataType;
/*     */ import mcframe.commonCore.lang.MCDate;
/*     */ import mcframe.commonCore.lang.MCDateUtil;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.lang.MCTimestamp;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.resource.MCConst;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCContainerColumnInfo
/*     */ {
/*     */   private final String _column;
/*     */   private final MCDataType _type;
/*     */   private final String _format;
/*     */   private final String _adjustedFormat;
/*     */   private final MCContainerIOConfig _config;
/*     */   private static final String NULL_TEXT = "";
/*  84 */   private static String FORMAT_YMDHMSS = MCConst.format
/*  85 */     .getDateOutputPattern("YMDHMSS");
/*     */   
/*  87 */   private static String FORMAT_Y2MDHMSS = MCConst.format
/*  88 */     .getDateOutputPattern("Y2MDHMSS");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCContainerColumnInfo(String column, MCDataType type, String format, MCContainerIOConfig config) {
/* 103 */     this._column = column;
/* 104 */     this._type = type;
/* 105 */     this._format = format;
/* 106 */     this._config = config;
/* 107 */     this._adjustedFormat = adjustFormat(format);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCDataType getType() {
/* 117 */     return this._type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFormat() {
/* 127 */     return this._format;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getColumn() {
/* 137 */     return this._column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void map(MCRow row, String value) {
/* 147 */     switch (this._type) {
/*     */       case DATE:
/* 149 */         if (isPoiExcelRead()) {
/* 150 */           MCDate dateValue = getFormattedDateValue(value);
/* 151 */           this._type.setValueNE(row, this._column, (Comparable)dateValue);
/*     */         } else {
/*     */           
/* 154 */           MCDate dataValue = (value == null || value.equals("")) ? null : 
/* 155 */             MCDate.valueOf(value, this._format);
/* 156 */           this._type.setValueNE(row, this._column, (Comparable)dataValue);
/*     */         } 
/*     */       
/*     */       case TIMESTAMP:
/* 160 */         if (isPoiExcelRead()) {
/* 161 */           MCTimestamp tsValue = getFormattedTsValue(value);
/* 162 */           this._type.setValueNE(row, this._column, (Comparable)tsValue);
/*     */         } else {
/*     */           
/* 165 */           MCTimestamp tsValue = (value == null || value.equals("")) ? null : 
/* 166 */             MCTimestamp.valueOf(value, this._format);
/* 167 */           this._type.setValueNE(row, this._column, (Comparable)tsValue);
/*     */         } 
/*     */       
/*     */       case NUMBER:
/* 171 */         if (value == null || value.equals("")) {
/* 172 */           this._type.setValueNE(row, this._column, null);
/*     */         } else {
/*     */           MCNumber num;
/* 175 */           value = value.trim();
/*     */           
/* 177 */           if (MCStringUtil.isNull(this._format)) {
/* 178 */             num = MCNumber.valueOf(value);
/*     */           } else {
/*     */             
/* 181 */             num = MCNumber.valueOf(value, this._format);
/*     */           } 
/* 183 */           this._type.setValueNE(row, this._column, (Comparable)num);
/*     */         } 
/*     */       case BOOLEAN:
/* 186 */         this._type.setValueNE(row, this._column, Boolean.valueOf(makeBooleanValue(value)));
/*     */       
/*     */       case null:
/* 189 */         this._type.setValueNE(row, this._column, (Comparable)textToBinary(value));
/*     */       
/*     */       case ROW:
/*     */         return;
/*     */     } 
/*     */     
/* 195 */     this._type.setValueNE(row, this._column, value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isPoiExcelRead() {
/* 201 */     return (this._config.getFileType() == MCContainerIOConfig.FileType.EXCEL_POI);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String adjustFormat(String format) {
/* 219 */     return (format.equals(FORMAT_YMDHMSS) || format.equals(FORMAT_Y2MDHMSS)) ? this._format : 
/* 220 */       "yyyyMMddHHmmssSSS";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCDate getFormattedDateValue(String value) {
/* 230 */     MCDate dateValue = null;
/*     */ 
/*     */     
/*     */     try {
/* 234 */       dateValue = _getFormattedDateValue(value, this._adjustedFormat);
/*     */     }
/* 236 */     catch (MCException e) {
/* 237 */       if (e.getID().equals(Core_Msg_FW_A.FCBFC0012)) {
/* 238 */         dateValue = _getFormattedDateValue(value, this._format);
/*     */       }
/*     */     } 
/* 241 */     return (dateValue != null) ? (MCDate)dateValue.trunc(MCDateUtil.getDateFieldType(this._format)) : 
/* 242 */       dateValue;
/*     */   }
/*     */   
/*     */   MCDate _getFormattedDateValue(String value, String format) {
/* 246 */     return (value == null || value.equals("")) ? null : MCDate.valueOf(value, format);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCTimestamp getFormattedTsValue(String value) {
/* 256 */     MCTimestamp tsValue = null;
/*     */ 
/*     */     
/*     */     try {
/* 260 */       tsValue = _getFormattedTsValue(value, this._adjustedFormat);
/*     */     }
/* 262 */     catch (MCException e) {
/* 263 */       if (e.getID().equals(Core_Msg_FW_A.FCBFC0012)) {
/* 264 */         tsValue = _getFormattedTsValue(value, this._format);
/*     */       }
/*     */     } 
/* 267 */     return (tsValue != null) ? (MCTimestamp)tsValue.trunc(MCDateUtil.getDateFieldType(this._format)) : 
/* 268 */       tsValue;
/*     */   }
/*     */   
/*     */   MCTimestamp _getFormattedTsValue(String value, String format) {
/* 272 */     return (value == null || value.equals("")) ? null : 
/* 273 */       MCTimestamp.valueOf(value, format);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String get(MCRow row) {
/*     */     MCDate dateValue;
/*     */     MCTimestamp tsValue;
/*     */     MCNumber num;
/*     */     boolean boolValue;
/* 285 */     if (row == null) {
/* 286 */       return "";
/*     */     }
/*     */     
/* 289 */     String result = "";
/* 290 */     switch (this._type) {
/*     */       case DATE:
/* 292 */         dateValue = (MCDate)this._type.getValueNE(row, this._column);
/* 293 */         result = (dateValue != null) ? dateValue.toString(this._format) : "";
/*     */       
/*     */       case TIMESTAMP:
/* 296 */         tsValue = (MCTimestamp)this._type.getValueNE(row, this._column);
/* 297 */         result = (tsValue != null) ? tsValue.toString(this._format) : "";
/*     */       
/*     */       case NUMBER:
/* 300 */         num = (MCNumber)this._type.getValueNE(row, this._column);
/* 301 */         if (num == null) {
/* 302 */           result = "";
/*     */         }
/* 304 */         else if (MCStringUtil.isNull(this._format)) {
/* 305 */           result = num.toPlainString();
/*     */         } else {
/*     */           
/* 308 */           result = num.toString(this._format);
/*     */         } 
/*     */       
/*     */       case BOOLEAN:
/* 312 */         boolValue = ((Boolean)this._type.getValueNE(row, this._column)).booleanValue();
/* 313 */         result = makeStringValue(boolValue);
/*     */       
/*     */       case null:
/* 316 */         if (this._config.isWriterWriteBinary()) {
/* 317 */           MCBinary bin = (MCBinary)this._type.getValueNE(row, this._column);
/* 318 */           result = binaryToText(bin);
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case ROW:
/* 328 */         return result;
/*     */     } 
/*     */     result = (String)this._type.getValueNE(row, this._column);
/*     */   } private boolean makeBooleanValue(String value) {
/* 332 */     return this._config.getReaderBooleanType().makeBooleanValue(value);
/*     */   }
/*     */   
/*     */   private String makeStringValue(boolean value) {
/* 336 */     return this._config.getReaderBooleanType().makeStringValue(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String binaryToText(MCBinary binary) {
/* 349 */     if (binary == null) {
/* 350 */       return "";
/*     */     }
/*     */ 
/*     */     
/* 354 */     if (binary.isDBFile()) {
/* 355 */       return String.valueOf(binary.toDBPointer());
/*     */     }
/*     */ 
/*     */     
/* 359 */     if (binary.isRemoteFile())
/*     */     {
/* 361 */       return String.valueOf('#') + binary.toRemotePath();
/*     */     }
/*     */     
/* 364 */     File file = binary.toFile();
/* 365 */     return String.valueOf('@') + file.getAbsolutePath();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static MCBinary textToBinary(String text) {
/*     */     try {
/* 381 */       if (text == null || text.equals("")) {
/* 382 */         return null;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 387 */       if (text.charAt(0) == '@') {
/* 388 */         File f = new File(text.substring(1));
/* 389 */         return MCBinary.valueOf(f);
/*     */       } 
/*     */       
/* 392 */       int pos = text.indexOf('#');
/*     */ 
/*     */ 
/*     */       
/* 396 */       if (pos < 0) {
/* 397 */         return MCBinary.valueOf(Long.parseLong(text));
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 402 */       if (pos == 0) {
/* 403 */         return MCBinary.valueOf(text.substring(1));
/*     */       }
/*     */ 
/*     */       
/* 407 */       return null;
/*     */     
/*     */     }
/* 410 */     catch (MCException e) {
/* 411 */       throw new MCException(e, Core_Msg_FW_A.FCBGC0011, new Object[] { MCBinary.class.getName(), text });
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\io\MCContainerColumnInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */