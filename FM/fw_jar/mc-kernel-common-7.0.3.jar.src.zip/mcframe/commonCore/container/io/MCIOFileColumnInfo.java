/*    */ package mcframe.commonCore.container.io;
/*    */ 
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*    */ import mcframe.commonCore.notice.MCException;
/*    */ 
/*    */ 
/*    */ 
/*    */ class MCIOFileColumnInfo
/*    */ {
/* 13 */   private final Map<String, Integer> colInfo = new LinkedHashMap<>(); MCIOFileColumnInfo(String[] targetColumns, String[] ioFileColumns) { byte b;
/*    */     int i;
/*    */     String[] arrayOfString;
/* 16 */     for (i = (arrayOfString = targetColumns).length, b = 0; b < i; ) { String target = arrayOfString[b];
/* 17 */       boolean flg = false;
/* 18 */       for (int j = 0; j < ioFileColumns.length; j++) {
/* 19 */         if (target.equals(ioFileColumns[j])) {
/* 20 */           this.colInfo.put(target, Integer.valueOf(j));
/* 21 */           flg = true;
/*    */           
/*    */           break;
/*    */         } 
/*    */       } 
/* 26 */       if (!flg)
/* 27 */         throw new MCException(Core_Msg_FW_A.FCBLC3002, new Object[] { target }); 
/*    */       b++; }
/*    */      }
/*    */ 
/*    */   
/*    */   MCIOFileColumnInfo(String[] targetColumns) {
/* 33 */     for (int i = 0; i < targetColumns.length; i++) {
/* 34 */       this.colInfo.put(targetColumns[i], Integer.valueOf(i));
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   Set<String> getColumnList() {
/* 40 */     return this.colInfo.keySet();
/*    */   }
/*    */   
/*    */   int getColumnIndexOnFile(String columnName) {
/* 44 */     return ((Integer)this.colInfo.get(columnName)).intValue();
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 49 */     StringBuilder sb = new StringBuilder();
/* 50 */     for (String key : this.colInfo.keySet()) {
/* 51 */       sb.append(key).append("::").append(this.colInfo.get(key)).append("\n");
/*    */     }
/* 53 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\io\MCIOFileColumnInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */