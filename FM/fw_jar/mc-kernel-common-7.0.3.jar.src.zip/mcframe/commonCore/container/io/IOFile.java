package mcframe.commonCore.container.io;

import java.util.Iterator;

public interface IOFile extends AutoCloseable, Iterator<String[]>, Iterable<String[]> {
  String[] getNextLine();
  
  int getLineNumber();
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\io\IOFile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */