/*     */ package mcframe.commonCore.container.io;
/*     */ 
/*     */ import java.io.File;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.notice.MCMessageList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCCsvReader<R extends MCRow>
/*     */ {
/*     */   private final MCList<R> _container;
/*     */   private final String _fileName;
/*  45 */   private MCContainerColumnMapper<R> _mapper = new DefaultContainerColumnMapper<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IfContainerAdjuster<R> _containerAdjuster;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IfColumnFormatEditor _formatEditor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCCsvReader(MCList<R> container, String fileName) {
/*  72 */     this._container = container;
/*  73 */     this._fileName = fileName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCCsvReader(MCList<R> container, File file) {
/*  85 */     this(container, file.getAbsolutePath());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContainerColumnMapper(MCContainerColumnMapper<R> mapper) {
/*  96 */     if (mapper != null) {
/*  97 */       this._mapper = mapper;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected MCContainerColumnMapper<R> _getContainerColumnMapper() {
/* 112 */     return this._mapper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContainerAdjuster(IfContainerAdjuster<R> containerAdjuster) {
/* 124 */     if (containerAdjuster != null) {
/* 125 */       this._containerAdjuster = containerAdjuster;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected IfContainerAdjuster<R> _getContainerAdjuster() {
/* 140 */     return this._containerAdjuster;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setColumnFormatEditor(IfColumnFormatEditor editor) {
/* 151 */     if (editor != null) {
/* 152 */       this._formatEditor = editor;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCMessageList read() {
/* 164 */     return read(new MCContainerIOConfig(), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCMessageList read(String[] columns) {
/* 177 */     return read(new MCContainerIOConfig(), columns);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCMessageList read(MCContainerIOConfig config) {
/* 189 */     return read(config, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCMessageList read(MCContainerIOConfig config, String[] columns) {
/* 203 */     MCMessageList result = new MCMessageList();
/* 204 */     this._container.clear();
/*     */     try {
/* 206 */       Exception exception2, exception1 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 223 */     catch (MCException e) {
/* 224 */       MCLog.write((Throwable)e);
/* 225 */       result.add(e.getMCMessage());
/*     */     } 
/* 227 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCIOFileColumnInfo resolveColumns(String[] argColumns, MCCsvFile csv, MCContainerIOConfig config) {
/*     */     MCIOFileColumnInfo result;
/* 238 */     String[] csvCols = skipColumnLine(csv, config);
/*     */     
/* 240 */     boolean isArgEffective = (argColumns != null && argColumns.length != 0);
/* 241 */     boolean isCsvEffective = (csvCols != null && csvCols.length != 0);
/*     */ 
/*     */     
/* 244 */     if (isArgEffective && isCsvEffective) {
/* 245 */       result = new MCIOFileColumnInfo(argColumns, csvCols);
/*     */     }
/* 247 */     else if (isArgEffective) {
/* 248 */       result = new MCIOFileColumnInfo(argColumns);
/*     */     }
/* 250 */     else if (isCsvEffective) {
/* 251 */       result = new MCIOFileColumnInfo(csvCols);
/*     */     } else {
/*     */       
/* 254 */       throw new MCException(Core_Msg_FW_A.FCBLC3001, new Object[0]);
/*     */     } 
/* 256 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] skipColumnLine(MCCsvFile csv, MCContainerIOConfig config) {
/* 266 */     if (!config.isReaderNameOut()) {
/* 267 */       return null;
/*     */     }
/* 269 */     return csv.getNextLine();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] skipTitleList(MCCsvFile csv, MCContainerIOConfig config) {
/* 279 */     if (!config.isReaderTitleOut()) {
/* 280 */       return null;
/*     */     }
/* 282 */     return csv.getNextLine();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCList<R> getContainer() {
/* 293 */     return this._container;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\io\MCCsvReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */