/*     */ package mcframe.commonCore.container.io;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.EnumSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCContainerIOConfig
/*     */ {
/*     */   private Encode writerEncode;
/*     */   private Delimiter writerDelimiter;
/*     */   private boolean writerDq;
/*     */   private boolean writerDisplay;
/*     */   private boolean writerAdjustwidth;
/*     */   private int writerAdjustwidthrow;
/*     */   private boolean writerCutnewline;
/*     */   private boolean writerNameOut;
/*     */   private boolean writerTitleOut;
/*     */   private TitleType writerTitleType;
/*     */   private BooleanType writerBooleanType;
/*     */   private NumType writerNumType;
/*     */   private boolean writerWriteBinary;
/*     */   private Encode readerEncode;
/*     */   private Delimiter readerDelimiter;
/*     */   private boolean readerDq;
/*     */   private boolean readerNameOut;
/*     */   private boolean readerTitleOut;
/*     */   private BooleanType readerBooleanType;
/*     */   private int readerBreakCnt;
/*     */   private int readerMax;
/*     */   private boolean readerCellValue;
/*     */   private FileType readerFileType;
/*     */   
/*     */   public MCContainerIOConfig() {
/* 231 */     this.writerEncode = Encode.UTF8;
/* 232 */     this.writerDelimiter = Delimiter.COMMA;
/* 233 */     this.writerDq = true;
/* 234 */     this.writerDisplay = false;
/* 235 */     this.writerAdjustwidth = true;
/* 236 */     this.writerAdjustwidthrow = -1;
/* 237 */     this.writerCutnewline = false;
/* 238 */     this.writerNameOut = true;
/* 239 */     this.writerTitleOut = true;
/* 240 */     this.writerTitleType = TitleType.MESSAGE;
/* 241 */     this.writerBooleanType = BooleanType.ZERO_ONE;
/* 242 */     this.writerNumType = NumType.STANDARD;
/* 243 */     this.writerWriteBinary = false;
/*     */ 
/*     */     
/* 246 */     this.readerEncode = this.writerEncode;
/* 247 */     this.readerDelimiter = this.writerDelimiter;
/* 248 */     this.readerDq = true;
/* 249 */     this.readerNameOut = this.writerNameOut;
/* 250 */     this.readerTitleOut = this.writerTitleOut;
/* 251 */     this.readerBooleanType = this.writerBooleanType;
/* 252 */     this.readerBreakCnt = -1;
/* 253 */     this.readerMax = -1;
/* 254 */     this.readerCellValue = false;
/* 255 */     this.readerFileType = FileType.CSV;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Encode getWriterEncode() {
/* 262 */     return this.writerEncode;
/*     */   }
/*     */   
/*     */   public void setWriterEncode(Encode writerEncode) {
/* 266 */     this.writerEncode = writerEncode;
/*     */   }
/*     */   
/*     */   public Delimiter getWriterDelimiter() {
/* 270 */     return this.writerDelimiter;
/*     */   }
/*     */   
/*     */   public void setWriterDelimiter(Delimiter writerDelimiter) {
/* 274 */     this.writerDelimiter = writerDelimiter;
/*     */   }
/*     */   
/*     */   public boolean isWriterDq() {
/* 278 */     return this.writerDq;
/*     */   }
/*     */   
/*     */   public void setWriterDq(boolean writerDq) {
/* 282 */     this.writerDq = writerDq;
/*     */   }
/*     */   
/*     */   public boolean isWriterDisplay() {
/* 286 */     return this.writerDisplay;
/*     */   }
/*     */   
/*     */   public void setWriterDisplay(boolean writerDisplay) {
/* 290 */     this.writerDisplay = writerDisplay;
/*     */   }
/*     */   
/*     */   public boolean isWriterAdjustwidth() {
/* 294 */     return this.writerAdjustwidth;
/*     */   }
/*     */   
/*     */   public void setWriterAdjustwidth(boolean writerAdjustwidth) {
/* 298 */     this.writerAdjustwidth = writerAdjustwidth;
/*     */   }
/*     */   
/*     */   public int getWriterAdjustwidthrow() {
/* 302 */     return this.writerAdjustwidthrow;
/*     */   }
/*     */   
/*     */   public void setWriterAdjustwidthrow(int writerAdjustwidthrow) {
/* 306 */     this.writerAdjustwidthrow = writerAdjustwidthrow;
/*     */   }
/*     */   
/*     */   public boolean isWriterCutnewline() {
/* 310 */     return this.writerCutnewline;
/*     */   }
/*     */   
/*     */   public void setWriterCutnewline(boolean writerCutnewline) {
/* 314 */     this.writerCutnewline = writerCutnewline;
/*     */   }
/*     */   
/*     */   public boolean isWriterNameOut() {
/* 318 */     return this.writerNameOut;
/*     */   }
/*     */   
/*     */   public void setWriterNameOut(boolean writerNameOut) {
/* 322 */     this.writerNameOut = writerNameOut;
/*     */   }
/*     */   
/*     */   public boolean isWriterTitleOut() {
/* 326 */     return this.writerTitleOut;
/*     */   }
/*     */   
/*     */   public void setWriterTitleOut(boolean writerTitleOut) {
/* 330 */     this.writerTitleOut = writerTitleOut;
/*     */   }
/*     */   
/*     */   public TitleType getWriterTitleType() {
/* 334 */     return this.writerTitleType;
/*     */   }
/*     */   
/*     */   boolean isWriterWriteBinary() {
/* 338 */     return this.writerWriteBinary;
/*     */   }
/*     */   
/*     */   public void setWriterTitleType(TitleType writerTitleType) {
/* 342 */     this.writerTitleType = writerTitleType;
/*     */   }
/*     */   
/*     */   public BooleanType getWriterBooleanType() {
/* 346 */     return this.writerBooleanType;
/*     */   }
/*     */   
/*     */   public void setWriterBooleanType(BooleanType writerBooleanType) {
/* 350 */     this.writerBooleanType = writerBooleanType;
/*     */   }
/*     */   
/*     */   FileType getFileType() {
/* 354 */     return this.readerFileType;
/*     */   }
/*     */   
/*     */   void setFileType(FileType readerFileType) {
/* 358 */     this.readerFileType = readerFileType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setWriterWriteBinary(boolean b) {
/* 371 */     this.writerWriteBinary = b;
/*     */   }
/*     */   
/*     */   public NumType getWriterNumType() {
/* 375 */     return this.writerNumType;
/*     */   }
/*     */   
/*     */   public void setWriterNumType(NumType writerNumType) {
/* 379 */     this.writerNumType = writerNumType;
/*     */   }
/*     */   
/*     */   public Encode getReaderEncode() {
/* 383 */     return this.readerEncode;
/*     */   }
/*     */   
/*     */   public void setReaderEncode(Encode readerEncode) {
/* 387 */     this.readerEncode = readerEncode;
/*     */   }
/*     */   
/*     */   public Delimiter getReaderDelimiter() {
/* 391 */     return this.readerDelimiter;
/*     */   }
/*     */   
/*     */   public void setReaderDelimiter(Delimiter readerDelimiter) {
/* 395 */     this.readerDelimiter = readerDelimiter;
/*     */   }
/*     */   
/*     */   public boolean isReaderDq() {
/* 399 */     return this.readerDq;
/*     */   }
/*     */   
/*     */   public void setReaderDq(boolean readerDq) {
/* 403 */     this.readerDq = readerDq;
/*     */   }
/*     */   
/*     */   public boolean isReaderNameOut() {
/* 407 */     return this.readerNameOut;
/*     */   }
/*     */   
/*     */   public void setReaderNameOut(boolean readerNameOut) {
/* 411 */     this.readerNameOut = readerNameOut;
/*     */   }
/*     */   
/*     */   public boolean isReaderTitleOut() {
/* 415 */     return this.readerTitleOut;
/*     */   }
/*     */   
/*     */   public void setReaderTitleOut(boolean readerTitleOut) {
/* 419 */     this.readerTitleOut = readerTitleOut;
/*     */   }
/*     */   
/*     */   public BooleanType getReaderBooleanType() {
/* 423 */     return this.readerBooleanType;
/*     */   }
/*     */   
/*     */   public void setReaderBooleanType(BooleanType readerBooleanType) {
/* 427 */     this.readerBooleanType = readerBooleanType;
/*     */   }
/*     */   
/*     */   public int getReaderBreakCnt() {
/* 431 */     return this.readerBreakCnt;
/*     */   }
/*     */   
/*     */   public void setReaderBreakCnt(int readerBreakCnt) {
/* 435 */     this.readerBreakCnt = readerBreakCnt;
/*     */   }
/*     */   
/*     */   public int getReaderMax() {
/* 439 */     return this.readerMax;
/*     */   }
/*     */   
/*     */   public void setReaderMax(int readerMax) {
/* 443 */     this.readerMax = readerMax;
/*     */   }
/*     */   
/*     */   public boolean isReaderCellValue() {
/* 447 */     return this.readerCellValue;
/*     */   }
/*     */   
/*     */   public void setReaderCellValue(boolean readerCellValue) {
/* 451 */     this.readerCellValue = readerCellValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Encode
/*     */   {
/* 465 */     UTF8
/*     */     {
/*     */       public Charset getCharset() {
/* 468 */         return StandardCharsets.UTF_8;
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean isSuitable(String str) {
/* 473 */         boolean ret = (str != null && (
/* 474 */           str.toUpperCase().equals("UTF-8") || 
/* 475 */           str.toUpperCase().equals("UTF8") || str.toUpperCase()
/* 476 */           .equals("UTF_8")));
/* 477 */         return ret;
/*     */       }
/*     */     },
/* 480 */     UTF16LE
/*     */     {
/*     */       public Charset getCharset() {
/* 483 */         return StandardCharsets.UTF_16LE;
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean isSuitable(String str) {
/* 488 */         boolean ret = (str != null && (
/* 489 */           str.toUpperCase().equals("UTF-16LE") || 
/* 490 */           str.toUpperCase().equals("UTF16LE") || str
/* 491 */           .toUpperCase().equals("UTF_16LE")));
/* 492 */         return ret;
/*     */       }
/*     */     },
/* 495 */     MS932
/*     */     {
/*     */       public Charset getCharset() {
/* 498 */         return Charset.forName("MS932");
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean isSuitable(String str) {
/* 503 */         boolean ret = (str != null && str.toUpperCase().equals("MS932"));
/* 504 */         return ret;
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Encode getEncode(String encodeStr, Encode defaultEncode) {
/* 539 */       Encode result = defaultEncode;
/* 540 */       for (Encode encode : EnumSet.<Encode>allOf(Encode.class)) {
/* 541 */         if (encode.isSuitable(encodeStr)) {
/* 542 */           result = encode;
/*     */           break;
/*     */         } 
/*     */       } 
/* 546 */       return result;
/*     */     }
/*     */ 
/*     */     
/*     */     public abstract Charset getCharset();
/*     */ 
/*     */     
/*     */     public abstract boolean isSuitable(String param1String);
/*     */   }
/*     */   
/*     */   public enum Delimiter
/*     */   {
/* 558 */     COMMA {
/*     */       public String toString() {
/* 560 */         return ",";
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean isSuitable(String str) {
/* 565 */         boolean ret = (str != null && str.toUpperCase().equals("COMMA"));
/* 566 */         return ret;
/*     */       }
/*     */ 
/*     */       
/*     */       public char toChar() {
/* 571 */         return ',';
/*     */       }
/*     */     },
/* 574 */     TAB {
/*     */       public String toString() {
/* 576 */         return "\t";
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean isSuitable(String str) {
/* 581 */         boolean ret = (str != null && str.toUpperCase().equals("TAB"));
/* 582 */         return ret;
/*     */       }
/*     */ 
/*     */       
/*     */       public char toChar() {
/* 587 */         return '\t';
/*     */       }
/*     */     },
/* 590 */     SPACE {
/*     */       public String toString() {
/* 592 */         return " ";
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean isSuitable(String str) {
/* 597 */         boolean ret = (str != null && str.toUpperCase().equals("SPACE"));
/* 598 */         return ret;
/*     */       }
/*     */ 
/*     */       
/*     */       public char toChar() {
/* 603 */         return ' ';
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Delimiter getDelimiter(String delimiterStr, Delimiter defaultDelimiter) {
/* 630 */       Delimiter result = defaultDelimiter;
/* 631 */       for (Delimiter delimiter : EnumSet.<Delimiter>allOf(Delimiter.class)) {
/* 632 */         if (delimiter.isSuitable(delimiterStr)) {
/* 633 */           result = delimiter;
/*     */           break;
/*     */         } 
/*     */       } 
/* 637 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public abstract boolean isSuitable(String param1String);
/*     */ 
/*     */     
/*     */     public abstract char toChar();
/*     */   }
/*     */ 
/*     */   
/*     */   public enum TitleType
/*     */   {
/* 651 */     MESSAGE
/*     */     {
/*     */       public boolean isSuitable(String str) {
/* 654 */         boolean ret = (str != null && str.toUpperCase().equals("MESSAGE"));
/* 655 */         return ret;
/*     */       }
/*     */     },
/* 658 */     LABEL
/*     */     {
/*     */       public boolean isSuitable(String str) {
/* 661 */         boolean ret = (str != null && str.toUpperCase().equals("LABEL"));
/* 662 */         return ret;
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static TitleType getTitleType(String titleTypeStr, TitleType defaultTitleType) {
/* 688 */       TitleType result = defaultTitleType;
/* 689 */       for (TitleType titleType : EnumSet.<TitleType>allOf(TitleType.class)) {
/* 690 */         if (titleType.isSuitable(titleTypeStr)) {
/* 691 */           result = titleType;
/*     */           break;
/*     */         } 
/*     */       } 
/* 695 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public abstract boolean isSuitable(String param1String);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public enum BooleanType
/*     */   {
/* 707 */     ZERO_ONE
/*     */     {
/*     */       public boolean isSuitable(int val) {
/* 710 */         return (val == 1);
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean makeBooleanValue(String value) {
/* 715 */         boolean result = false;
/* 716 */         if (value != null && value.equals("1")) {
/* 717 */           result = true;
/*     */         }
/* 719 */         return result;
/*     */       }
/*     */ 
/*     */       
/*     */       public String makeStringValue(boolean value) {
/* 724 */         return value ? "1" : "0";
/*     */       }
/*     */     },
/* 727 */     TRUE_FALSE
/*     */     {
/*     */       public boolean isSuitable(int val) {
/* 730 */         return (val == 2);
/*     */       }
/*     */       
/*     */       public boolean makeBooleanValue(String value) {
/* 734 */         boolean result = false;
/* 735 */         if (value != null && value.toUpperCase().equals("TRUE")) {
/* 736 */           result = true;
/*     */         }
/* 738 */         return result;
/*     */       }
/*     */       
/*     */       public String makeStringValue(boolean value) {
/* 742 */         return value ? "TRUE" : "FALSE";
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static BooleanType getBooleanType(int booleanTypeVal, BooleanType defaultBooleanType) {
/* 767 */       BooleanType result = defaultBooleanType;
/* 768 */       for (BooleanType booleanType : EnumSet.<BooleanType>allOf(BooleanType.class)) {
/* 769 */         if (booleanType.isSuitable(booleanTypeVal)) {
/* 770 */           result = booleanType;
/*     */           break;
/*     */         } 
/*     */       } 
/* 774 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public abstract boolean isSuitable(int param1Int);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public abstract boolean makeBooleanValue(String param1String);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public abstract String makeStringValue(boolean param1Boolean);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public enum NumType
/*     */   {
/* 806 */     STANDARD
/*     */     {
/*     */       public boolean isSuitable(int val) {
/* 809 */         return (val == 0);
/*     */       }
/*     */     },
/* 812 */     NUMBER
/*     */     {
/*     */       public boolean isSuitable(int val) {
/* 815 */         return (val == 1);
/*     */       }
/*     */     },
/* 818 */     USER_FORMAT
/*     */     {
/*     */       public boolean isSuitable(int val) {
/* 821 */         return (val == 2);
/*     */       }
/*     */     },
/* 824 */     STRING
/*     */     {
/*     */       public boolean isSuitable(int val) {
/* 827 */         return (val == 3);
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static NumType getNumType(int numTypeVal, NumType defaultNumType) {
/* 852 */       NumType result = defaultNumType;
/* 853 */       for (NumType numType : EnumSet.<NumType>allOf(NumType.class)) {
/* 854 */         if (numType.isSuitable(numTypeVal)) {
/* 855 */           result = numType;
/*     */           break;
/*     */         } 
/*     */       } 
/* 859 */       return result;
/*     */     }
/*     */     
/*     */     public abstract boolean isSuitable(int param1Int);
/*     */   }
/*     */   
/*     */   enum FileType
/*     */   {
/* 867 */     CSV,
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 872 */     EXCEL_POI;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\io\MCContainerIOConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */