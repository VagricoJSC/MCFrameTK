/*    */ package mcframe.commonCore.container.io;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCCellDateFormatSet
/*    */ {
/* 18 */   private Map<String, String> _formatMap = new HashMap<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MCCellDateFormatSet() {
/* 25 */     this._formatMap.put("[$-411]yyyy/mm/dd (aaa)", "yyyy/MM/dd (EEE)");
/* 26 */     this._formatMap.put("[$-411]yy/mm/dd (aaa)", "yy/MM/dd (EEE)");
/* 27 */     this._formatMap.put("[$-409]aaa mm-dd-yyyy", "EEE MM-dd-yyyy");
/* 28 */     this._formatMap.put("[$-409]aaa mm-dd-yy", "EEE MM-dd-yy");
/*    */     
/* 30 */     this._formatMap.put("yyyy/mm/dd (aaa)", "yyyy/MM/dd (EEE)");
/* 31 */     this._formatMap.put("yy/mm/dd (aaa)", "yy/MM/dd (EEE)");
/* 32 */     this._formatMap.put("yyyy/mm/dd hh:mm:ss.ss", "yyyy/MM/dd hh:mm:ss.SSS");
/* 33 */     this._formatMap.put("yyyy/mm/dd hh:mm:ss", "yyyy/MM/dd hh:mm:ss");
/* 34 */     this._formatMap.put("yyyy/mm/dd hh:mm", "yyyy/MM/dd hh:mm");
/* 35 */     this._formatMap.put("yyyy/mm/dd", "yyyy/MM/dd");
/* 36 */     this._formatMap.put("yyyy/mm", "yyyy/MM");
/* 37 */     this._formatMap.put("mm/dd", "MM/dd");
/* 38 */     this._formatMap.put("hh:mm", "hh:mm");
/* 39 */     this._formatMap.put("yy/mm/dd hh:mm:ss.ss", "yy/MM/dd hh:mm:ss.SSS");
/* 40 */     this._formatMap.put("yy/mm/dd hh:mm:ss", "yy/MM/dd hh:mm:ss");
/* 41 */     this._formatMap.put("yy/mm/dd hh:m", "yy/MM/dd hh:m");
/* 42 */     this._formatMap.put("yy/mm/dd", "yy/MM/dd");
/* 43 */     this._formatMap.put("yy/mm", "yy/MM");
/* 44 */     this._formatMap.put("yyyy", "yyyy");
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean contains(String format) {
/* 49 */     String adjusted = format.replace("\\", "");
/* 50 */     return this._formatMap.containsKey(adjusted);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\io\MCCellDateFormatSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */