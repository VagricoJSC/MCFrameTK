/*    */ package mcframe.commonCore.container.io;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.apache.poi.openxml4j.opc.OPCPackage;
/*    */ import org.apache.poi.xssf.eventusermodel.ReadOnlySharedStringsTable;
/*    */ import org.xml.sax.Attributes;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MCReadOnlySharedStringsTable
/*    */   extends ReadOnlySharedStringsTable
/*    */ {
/*    */   private boolean isPhonetic;
/* 24 */   private static String RPH_TAG = "rPh";
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MCReadOnlySharedStringsTable(OPCPackage pkg) throws IOException, SAXException {
/* 32 */     super(pkg, false);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void startElement(String uri, String localName, String name, Attributes attributes) throws SAXException {
/* 38 */     super.startElement(uri, localName, name, attributes);
/*    */     
/* 40 */     if (RPH_TAG.equals(name)) {
/* 41 */       this.isPhonetic = true;
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void endElement(String uri, String localName, String name) throws SAXException {
/* 48 */     this.isPhonetic = false;
/* 49 */     super.endElement(uri, localName, name);
/*    */   }
/*    */ 
/*    */   
/*    */   public void characters(char[] ch, int start, int length) throws SAXException {
/* 54 */     if (!this.isPhonetic)
/* 55 */       super.characters(ch, start, length); 
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\io\MCReadOnlySharedStringsTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */