/*     */ package mcframe.commonCore.container.io;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.xml.parsers.FactoryConfigurationError;
/*     */ import javax.xml.parsers.SAXParser;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.notice.MCMessageList;
/*     */ import mcframe.commonCore.resource.MCConst;
/*     */ import org.apache.poi.openxml4j.exceptions.InvalidOperationException;
/*     */ import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.XMLReader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCExcelReader<R extends MCRow>
/*     */ {
/*     */   private final MCList<R> _container;
/*     */   private final String _fileName;
/*  63 */   private MCContainerColumnMapper<R> _mapper = new DefaultContainerColumnMapper<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IfContainerAdjuster<R> _ContainerAdjuster;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IfColumnFormatEditor _formatEditor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<String[]> _list;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCExcelReader(MCList<R> container, String fileName) {
/*  99 */     this._container = container;
/* 100 */     this._fileName = fileName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCExcelReader(MCList<R> container, File file) {
/* 112 */     this(container, file.getAbsolutePath());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContainerColumnMapper(MCContainerColumnMapper<R> mapper) {
/* 123 */     if (mapper != null) {
/* 124 */       this._mapper = mapper;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected MCContainerColumnMapper<R> _getContainerColumnMapper() {
/* 139 */     return this._mapper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContainerAdjuster(IfContainerAdjuster<R> containerAdjuster) {
/* 151 */     if (containerAdjuster != null) {
/* 152 */       this._ContainerAdjuster = containerAdjuster;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected IfContainerAdjuster<R> _getContainerAdjuster() {
/* 167 */     return this._ContainerAdjuster;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setColumnFormatEditor(IfColumnFormatEditor editor) {
/* 178 */     if (editor != null) {
/* 179 */       this._formatEditor = editor;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCMessageList read() {
/* 191 */     return read(new MCContainerIOConfig(), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCMessageList read(String[] columns) {
/* 204 */     return read(new MCContainerIOConfig(), columns);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCMessageList read(MCContainerIOConfig config) {
/* 216 */     return read(config, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCMessageList read(MCContainerIOConfig config, String[] columns) {
/* 230 */     if (MCConst.plugin.getBoolean("excelreader.event", true)) {
/* 231 */       return read(config, columns, true);
/*     */     }
/* 233 */     return read(config, columns, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCMessageList read(MCContainerIOConfig config, String[] columns, boolean event) {
/* 252 */     config.setFileType(MCContainerIOConfig.FileType.EXCEL_POI);
/*     */     
/* 254 */     if (event) {
/* 255 */       return readByEvent(config, columns);
/*     */     }
/* 257 */     return readByUser(config, columns);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCMessageList readByUser(MCContainerIOConfig config, String[] columns) {
/* 271 */     MCMessageList result = new MCMessageList();
/* 272 */     this._container.clear();
/*     */     try {
/* 274 */       Exception exception2, exception1 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 295 */     catch (MCException e) {
/* 296 */       MCLog.write((Throwable)e);
/* 297 */       result.add(e.getMCMessage());
/*     */     }
/* 299 */     catch (Exception e) {
/* 300 */       MCException mce = new MCException(e, Core_Msg_FW_A.FCBLC3008, new Object[] { this._fileName });
/* 301 */       MCLog.write((Throwable)mce);
/* 302 */       result.add(mce.getMCMessage());
/*     */     } 
/* 304 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCMessageList readByEvent(MCContainerIOConfig config, String[] columns) {
/* 319 */     MCMessageList result = new MCMessageList();
/* 320 */     this._container.clear();
/* 321 */     this._list = (List)new ArrayList<>();
/*     */ 
/*     */     
/*     */     try {
/* 325 */       parseXSSFSheets();
/*     */       
/* 327 */       MCExcelSheetEventReader reader = new MCExcelSheetEventReader(this._list);
/*     */ 
/*     */       
/* 330 */       MCIOFileColumnInfo targetColumns = resolveColumns(columns, reader, config);
/* 331 */       skipTitleList(reader, config);
/* 332 */       this._mapper.init(targetColumns, (R)this._container.createRow(), config);
/*     */       
/* 334 */       for (String[] line : reader) {
/* 335 */         MCRow mCRow = this._container.createRow();
/* 336 */         this._mapper.map2Container(line, (R)mCRow, reader.getLineNumber());
/* 337 */         if (this._ContainerAdjuster != null) {
/* 338 */           mCRow = (MCRow)this._ContainerAdjuster.adjustBeforeList((R)mCRow);
/*     */         }
/* 340 */         if (mCRow != null) {
/* 341 */           this._container.add(mCRow);
/*     */         }
/*     */       }
/*     */     
/* 345 */     } catch (MCException e) {
/* 346 */       MCLog.write((Throwable)e);
/* 347 */       result.add(e.getMCMessage());
/*     */     }
/* 349 */     catch (Exception e) {
/* 350 */       MCException mce = new MCException(e, Core_Msg_FW_A.FCBLC3008, new Object[] { this._fileName });
/* 351 */       MCLog.write((Throwable)mce);
/* 352 */       result.add(mce.getMCMessage());
/*     */     } 
/* 354 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseXSSFSheets() {
/*     */     try {
/* 368 */       Exception exception2, exception1 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 396 */     catch (InvalidOperationException|org.apache.poi.UnsupportedFileFormatException e) {
/*     */ 
/*     */       
/* 399 */       throw new MCException(e, Core_Msg_FW_A.FCBLC0006, new Object[] { this._fileName });
/*     */     }
/* 401 */     catch (OpenXML4JException|java.io.IOException e) {
/* 402 */       throw new MCException(e, Core_Msg_FW_A.FCBLC0008, new Object[0]);
/*     */     }
/* 404 */     catch (SAXException e) {
/* 405 */       throw new MCException(e, Core_Msg_FW_A.FCBLC0009, new Object[0]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private XMLReader getXMLReader() {
/* 420 */     XMLReader sheetParser = null;
/*     */     try {
/* 422 */       SAXParserFactory spf = SAXParserFactory.newInstance();
/*     */ 
/*     */ 
/*     */       
/* 426 */       spf.setNamespaceAware(true);
/* 427 */       SAXParser p = spf.newSAXParser();
/* 428 */       sheetParser = p.getXMLReader();
/*     */     }
/* 430 */     catch (SAXException|javax.xml.parsers.ParserConfigurationException e) {
/*     */       
/* 432 */       throw new MCException(e, Core_Msg_FW_A.FCBLC0007, new Object[0]);
/*     */     }
/* 434 */     catch (FactoryConfigurationError e) {
/*     */       
/* 436 */       throw new MCException(e, Core_Msg_FW_A.FCBLC0007, new Object[0]);
/*     */     } 
/* 438 */     return sheetParser;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ExcelRowContentCallback createExcelRowContentCallback() {
/* 450 */     return new ExcelRowContentCallback()
/*     */       {
/*     */         
/*     */         public void processRow(int rowNum, Map<String, String> map)
/*     */         {
/* 455 */           String[] data = (String[])map.values().toArray((Object[])new String[0]);
/* 456 */           MCExcelReader.this._list.add(data);
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCIOFileColumnInfo resolveColumns(String[] argColumns, MCExcelSheetReader reader, MCContainerIOConfig config) {
/*     */     MCIOFileColumnInfo result;
/* 469 */     String[] excelCols = skipColumnLine(reader, config);
/*     */     
/* 471 */     boolean isArgEffective = (argColumns != null && argColumns.length != 0);
/* 472 */     boolean isExcelEffective = (excelCols != null && excelCols.length != 0);
/*     */ 
/*     */     
/* 475 */     if (isArgEffective && isExcelEffective) {
/* 476 */       result = new MCIOFileColumnInfo(argColumns, excelCols);
/*     */     }
/* 478 */     else if (isArgEffective) {
/* 479 */       result = new MCIOFileColumnInfo(argColumns);
/*     */     }
/* 481 */     else if (isExcelEffective) {
/* 482 */       result = new MCIOFileColumnInfo(excelCols);
/*     */     } else {
/*     */       
/* 485 */       throw new MCException(Core_Msg_FW_A.FCBLC3001, new Object[0]);
/*     */     } 
/* 487 */     return result;
/*     */   }
/*     */   
/*     */   private MCIOFileColumnInfo resolveColumns(String[] argColumns, MCExcelSheetEventReader reader, MCContainerIOConfig config) {
/*     */     MCIOFileColumnInfo result;
/* 492 */     String[] excelCols = skipColumnLine(reader, config);
/*     */     
/* 494 */     boolean isArgEffective = (argColumns != null && argColumns.length != 0);
/* 495 */     boolean isExcelEffective = (excelCols != null && excelCols.length != 0);
/*     */ 
/*     */     
/* 498 */     if (isArgEffective && isExcelEffective) {
/* 499 */       result = new MCIOFileColumnInfo(argColumns, excelCols);
/*     */     }
/* 501 */     else if (isArgEffective) {
/* 502 */       result = new MCIOFileColumnInfo(argColumns);
/*     */     }
/* 504 */     else if (isExcelEffective) {
/* 505 */       result = new MCIOFileColumnInfo(excelCols);
/*     */     } else {
/*     */       
/* 508 */       throw new MCException(Core_Msg_FW_A.FCBLC3001, new Object[0]);
/*     */     } 
/* 510 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] skipColumnLine(MCExcelSheetReader reader, MCContainerIOConfig config) {
/* 521 */     if (!config.isReaderNameOut()) {
/* 522 */       return null;
/*     */     }
/* 524 */     return reader.getNextLine();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] skipColumnLine(MCExcelSheetEventReader reader, MCContainerIOConfig config) {
/* 535 */     if (!config.isReaderNameOut()) {
/* 536 */       return null;
/*     */     }
/* 538 */     return reader.getNextLine();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] skipTitleList(MCExcelSheetReader reader, MCContainerIOConfig config) {
/* 549 */     if (!config.isReaderTitleOut()) {
/* 550 */       return null;
/*     */     }
/* 552 */     return reader.getNextLine();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] skipTitleList(MCExcelSheetEventReader reader, MCContainerIOConfig config) {
/* 563 */     if (!config.isReaderTitleOut()) {
/* 564 */       return null;
/*     */     }
/* 566 */     return reader.getNextLine();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCList<R> getContainer() {
/* 577 */     return this._container;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\io\MCExcelReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */