/*     */ package mcframe.commonCore.container.io;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Path;
/*     */ import java.nio.file.Paths;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import mcframe.commonCore.lang.MCDataType;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.util.MCCsvEnToken;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCCsvFile
/*     */   implements IOFile
/*     */ {
/*     */   private final BufferedReader _csv;
/*     */   MCCsvEnToken _tokenizer;
/*     */   private final MCContainerIOConfig _config;
/*  57 */   private int _lineNumber = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCCsvFile(String fileName, MCContainerIOConfig config) {
/*  68 */     this._config = config;
/*     */     
/*  70 */     Path path = Paths.get(fileName, new String[0]);
/*  71 */     if (!Files.exists(path, new java.nio.file.LinkOption[0])) {
/*  72 */       throw new MCException(Core_Msg_FW_A.FCBLC0001, new Object[] { fileName });
/*     */     }
/*     */     try {
/*  75 */       this._csv = Files.newBufferedReader(path, this._config.getReaderEncode().getCharset());
/*  76 */       char delimiter = this._config.getReaderDelimiter().toChar();
/*  77 */       this._tokenizer = new MCCsvEnToken(this._csv);
/*  78 */       this._tokenizer.setDelimiter(delimiter);
/*     */     }
/*  80 */     catch (IOException e) {
/*  81 */       throw new MCException(e, Core_Msg_FW_A.FCBLC0006, new Object[] { fileName });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/*     */     try {
/*  91 */       this._csv.close();
/*  92 */       this._tokenizer = null;
/*     */     }
/*  94 */     catch (IOException iOException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<String[]> iterator() {
/* 102 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/* 107 */     boolean result = this._tokenizer.hasMoreTokens();
/* 108 */     if (result) {
/* 109 */       this._lineNumber++;
/*     */     }
/* 111 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] next() {
/* 116 */     String[] result = this._tokenizer.nextLineTokens();
/* 117 */     if (result == null) {
/* 118 */       return new String[0];
/*     */     }
/* 120 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getNextLine() {
/* 125 */     if (!hasNext()) {
/* 126 */       return new String[0];
/*     */     }
/* 128 */     return next();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLineNumber() {
/* 140 */     return this._lineNumber;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String makeHeaderData(String[] src, MCContainerIOConfig config) {
/* 153 */     StringBuilder result = new StringBuilder();
/* 154 */     for (int i = 0; i < src.length; i++) {
/* 155 */       result.append("\"").append(src[i]).append("\"");
/* 156 */       if (i != src.length - 1) {
/* 157 */         result.append(config.getWriterDelimiter().toString());
/*     */       }
/*     */     } 
/* 160 */     return result.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String makeLineData(String[] src, List<MCDataType> types, MCContainerIOConfig config) {
/* 176 */     StringBuilder result = new StringBuilder();
/* 177 */     for (int i = 0; i < src.length; i++) {
/* 178 */       appendColumnData(src[i], types.get(i), result, config, (i == 0));
/*     */     }
/* 180 */     return result.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private static void appendColumnData(String src, MCDataType type, StringBuilder dist, MCContainerIOConfig config, boolean isFirst) {
/* 185 */     if (!isFirst) {
/* 186 */       dist.append(config.getWriterDelimiter().toString());
/*     */     }
/*     */     
/* 189 */     if (type == MCDataType.STRING && config.isWriterDq()) {
/* 190 */       if (src != null) {
/*     */         
/* 192 */         src = src.replaceAll("\"", "\"\"");
/* 193 */         dist.append("\"").append(src).append("\"");
/*     */       } 
/*     */     } else {
/*     */       
/* 197 */       dist.append(src);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\io\MCCsvFile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */