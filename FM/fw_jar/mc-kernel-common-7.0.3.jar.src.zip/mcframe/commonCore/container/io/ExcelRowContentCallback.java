package mcframe.commonCore.container.io;

import java.util.Map;

public interface ExcelRowContentCallback {
  void processRow(int paramInt, Map<String, String> paramMap);
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\io\ExcelRowContentCallback.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */