/*     */ package mcframe.commonCore.container.io;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCExcelSheetEventReader
/*     */   implements Iterator<String[]>, Iterable<String[]>
/*     */ {
/*     */   private final List<String[]> _list;
/*     */   private MCContainerColumnMapper<?> _mapper;
/*     */   private String[] _currentLine;
/*  46 */   private int _lineNumber = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int _lastLineNumber;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCExcelSheetEventReader(List<String[]> list) {
/*  64 */     this._list = list;
/*  65 */     this._lastLineNumber = this._list.size() - 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addOnColumnMapper(MCContainerColumnMapper<?> mapper) {
/*  76 */     this._mapper = mapper;
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<String[]> iterator() {
/*  81 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/*  86 */     if (this._lineNumber > this._lastLineNumber) {
/*  87 */       return false;
/*     */     }
/*     */     
/*  90 */     this._currentLine = this._list.get(this._lineNumber++);
/*  91 */     if (isEmptyRow(this._currentLine) && this._lineNumber - 1 == this._lastLineNumber) {
/*  92 */       return false;
/*     */     }
/*  94 */     return true;
/*     */   }
/*     */   
/*     */   private boolean isEmptyRow(String[] row) {
/*  98 */     if (row == null || row.length == 0) {
/*  99 */       return true;
/*     */     }
/* 101 */     boolean result = true; byte b; int i; String[] arrayOfString;
/* 102 */     for (i = (arrayOfString = row).length, b = 0; b < i; ) { String cell = arrayOfString[b];
/* 103 */       if (cell != null && !cell.equals("")) {
/* 104 */         result = false; break;
/*     */       } 
/*     */       b++; }
/*     */     
/* 108 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] next() {
/* 117 */     return this._currentLine;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getNextLine() {
/* 127 */     if (!hasNext()) {
/* 128 */       return new String[0];
/*     */     }
/* 130 */     return next();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLineNumber() {
/* 141 */     return this._lineNumber;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\io\MCExcelSheetEventReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */