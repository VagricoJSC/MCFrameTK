/*     */ package mcframe.commonCore.container.io;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCDataType;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.notice.MCMessageList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultContainerColumnMapper<R extends MCRow>
/*     */   implements MCContainerColumnMapper<R>
/*     */ {
/*  34 */   private final Map<String, MCContainerColumnInfo> _columnInfo = new LinkedHashMap<>();
/*     */   private MCContainerIOConfig _config;
/*     */   private MCIOFileColumnInfo _columns;
/*     */   
/*     */   protected MCContainerIOConfig getConfig() {
/*  39 */     return this._config;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(MCIOFileColumnInfo columns, R protRow, MCContainerIOConfig config) {
/*  55 */     this._config = config;
/*  56 */     this._columnInfo.clear();
/*  57 */     this._columns = columns;
/*  58 */     for (String column : columns.getColumnList()) {
/*  59 */       MCMeta meta = protRow.getMeta(column);
/*  60 */       if (meta == null) {
/*  61 */         this._columnInfo.put(column, makeTempColumnInfo(column, config));
/*     */         continue;
/*     */       } 
/*  64 */       this._columnInfo.put(column, makeConstColumnInfo(column, meta, config));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<MCDataType> getColumnTypeList() {
/*  78 */     List<MCDataType> result = new ArrayList<>();
/*  79 */     Exception exception1 = null, exception2 = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getColumnList() {
/*  93 */     return (String[])this._columnInfo.keySet().toArray((Object[])new String[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getColumnTitle() {
/* 106 */     return (String[])this._columnInfo.keySet().toArray((Object[])new String[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCContainerColumnInfo makeConstColumnInfo(String column, MCMeta meta, MCContainerIOConfig config) {
/* 122 */     switch (meta.type())
/*     */     { case DATE:
/* 124 */         ret = new MCContainerColumnInfo(column, MCDataType.DATE, 
/* 125 */             "yyyyMMddHHmmss", config);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 135 */         return ret;case TIMESTAMP: ret = new MCContainerColumnInfo(column, MCDataType.TIMESTAMP, "yyyyMMddHHmmssSSS", config); return ret; }  MCContainerColumnInfo ret = new MCContainerColumnInfo(column, meta.type(), "", config); return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCContainerColumnInfo makeTempColumnInfo(String column, MCContainerIOConfig config) {
/* 149 */     return new MCContainerColumnInfo(column, MCDataType.STRING, "", config);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void map2Container(String[] data, R row, int lineNum) {
/* 164 */     for (String column : this._columnInfo.keySet()) {
/* 165 */       String value = null;
/*     */       try {
/* 167 */         MCContainerColumnInfo info = this._columnInfo.get(column);
/* 168 */         value = getColumnData(data, this._columns.getColumnIndexOnFile(column));
/* 169 */         info.map((MCRow)row, value);
/*     */       }
/* 171 */       catch (Throwable t) {
/* 172 */         if (t instanceof MCException) {
/* 173 */           MCException e = (MCException)t;
/* 174 */           if (e.getID().equals(Core_Msg_FW_A.FCBFC0012) || e.getID().equals(Core_Msg_FW_A.FCBFC0003)) {
/*     */             
/* 176 */             e.setCauseRow((MCRow)row, column);
/* 177 */             throw new MCException(e, Core_Msg_FW_A.FCBLC3006, new Object[] { Integer.valueOf(lineNum), column, value });
/*     */           } 
/*     */         } 
/* 180 */         throw new MCException(t, Core_Msg_FW_A.FCBLC3003, new Object[] { Integer.valueOf(lineNum), column, value });
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void map2ContainerNE(String[] data, R row, int lineNum, MCMessageList msgList) {
/* 199 */     for (String column : this._columnInfo.keySet()) {
/* 200 */       String value = null;
/*     */       try {
/* 202 */         MCContainerColumnInfo info = this._columnInfo.get(column);
/* 203 */         value = getColumnData(data, this._columns.getColumnIndexOnFile(column));
/* 204 */         info.map((MCRow)row, value);
/*     */       }
/* 206 */       catch (Throwable t) {
/* 207 */         MCException exForMsg = null;
/* 208 */         if (t instanceof MCException) {
/* 209 */           MCException e = (MCException)t;
/* 210 */           if (e.getID().equals(Core_Msg_FW_A.FCBFC0012) || e.getID().equals(Core_Msg_FW_A.FCBFC0003)) {
/*     */             
/* 212 */             e.setCauseRow((MCRow)row, column);
/* 213 */             exForMsg = new MCException((Throwable)e, Core_Msg_FW_A.FCBLC3006, new Object[] { Integer.valueOf(lineNum), column, value });
/*     */           } 
/*     */         } 
/* 216 */         exForMsg = (exForMsg == null) ? 
/* 217 */           new MCException(t, Core_Msg_FW_A.FCBLC3003, new Object[] { Integer.valueOf(lineNum), column, value
/* 218 */             }) : exForMsg;
/* 219 */         MCLog.write((Throwable)exForMsg);
/* 220 */         msgList.add(exForMsg.getMCMessage());
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private String getColumnData(String[] line, int colIndex) {
/* 226 */     if (line == null || line.length <= colIndex) {
/* 227 */       return null;
/*     */     }
/* 229 */     return line[colIndex];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] map2File(R row, int lineNum) {
/* 243 */     int i = 0;
/* 244 */     String[] line = new String[this._columnInfo.keySet().size()];
/* 245 */     for (String column : this._columnInfo.keySet()) {
/* 246 */       String value = null;
/*     */       try {
/* 248 */         MCContainerColumnInfo info = this._columnInfo.get(column);
/* 249 */         value = info.get((MCRow)row);
/* 250 */         line[i++] = value;
/*     */       }
/* 252 */       catch (Throwable t) {
/* 253 */         throw new MCException(t, Core_Msg_FW_A.FCBLC3004, new Object[] { Integer.valueOf(lineNum), column, value });
/*     */       } 
/*     */     } 
/* 256 */     return line;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 268 */     return this._columnInfo.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCContainerColumnInfo getColumnInfo(String columnName) {
/* 281 */     return this._columnInfo.get(columnName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCContainerColumnInfo getColumnInfo(int colIndex) {
/* 295 */     MCContainerColumnInfo result = null;
/* 296 */     int i = 0;
/* 297 */     for (String colName : this._columnInfo.keySet()) {
/* 298 */       if (i == colIndex) {
/* 299 */         result = this._columnInfo.get(colName);
/*     */         break;
/*     */       } 
/* 302 */       i++;
/*     */     } 
/* 304 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\io\DefaultContainerColumnMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */