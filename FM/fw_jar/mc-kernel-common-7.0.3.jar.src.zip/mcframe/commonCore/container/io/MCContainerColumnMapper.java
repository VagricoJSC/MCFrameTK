/*     */ package mcframe.commonCore.container.io;
/*     */ 
/*     */ import java.util.List;
/*     */ import mcframe.commonCore.lang.MCDataType;
/*     */ import mcframe.commonCore.notice.MCMessageList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface MCContainerColumnMapper<R extends mcframe.commonCore.container.MCRow>
/*     */ {
/*     */   void init(MCIOFileColumnInfo paramMCIOFileColumnInfo, R paramR, MCContainerIOConfig paramMCContainerIOConfig);
/*     */   
/*     */   List<MCDataType> getColumnTypeList();
/*     */   
/*     */   String[] getColumnTitle();
/*     */   
/*     */   void map2Container(String[] paramArrayOfString, R paramR, int paramInt);
/*     */   
/*     */   void map2ContainerNE(String[] paramArrayOfString, R paramR, int paramInt, MCMessageList paramMCMessageList);
/*     */   
/*     */   String[] map2File(R paramR, int paramInt);
/*     */   
/*     */   int size();
/*     */   
/*     */   MCContainerColumnInfo getColumnInfo(String paramString);
/*     */   
/*     */   MCContainerColumnInfo getColumnInfo(int paramInt);
/*     */   
/*     */   default boolean isFileOutputColumn(R row, String colName) {
/* 124 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\io\MCContainerColumnMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */