/*    */ package mcframe.commonCore.container.io;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface IfContainerAdjuster<R extends mcframe.commonCore.container.MCRow>
/*    */ {
/*    */   default R adjustBeforeList(R org) {
/* 25 */     return org;
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\io\IfContainerAdjuster.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */