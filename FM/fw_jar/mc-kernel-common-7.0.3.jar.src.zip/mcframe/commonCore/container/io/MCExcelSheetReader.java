/*     */ package mcframe.commonCore.container.io;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import mcframe.commonCore.lang.MCDate;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import org.apache.poi.ss.usermodel.Cell;
/*     */ import org.apache.poi.ss.usermodel.CellType;
/*     */ import org.apache.poi.ss.usermodel.CellValue;
/*     */ import org.apache.poi.ss.usermodel.CreationHelper;
/*     */ import org.apache.poi.ss.usermodel.DateUtil;
/*     */ import org.apache.poi.ss.usermodel.FormulaEvaluator;
/*     */ import org.apache.poi.ss.usermodel.Row;
/*     */ import org.apache.poi.ss.usermodel.Sheet;
/*     */ import org.apache.poi.ss.usermodel.Workbook;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCExcelSheetReader
/*     */   implements Iterator<String[]>, Iterable<String[]>
/*     */ {
/*     */   private final Sheet _sheet;
/*     */   private MCContainerColumnMapper<?> _mapper;
/*     */   private String[] _currentLine;
/*  63 */   private int _lineNumber = 0;
/*     */   
/*  65 */   private MCCellDateFormatSet set = new MCCellDateFormatSet();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCExcelSheetReader(Sheet sheet) {
/*  75 */     this._sheet = sheet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addOnColumnMapper(MCContainerColumnMapper<?> mapper) {
/*  86 */     this._mapper = mapper;
/*     */   }
/*     */ 
/*     */   
/*     */   public Iterator<String[]> iterator() {
/*  91 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/*  96 */     if (this._lineNumber > this._sheet.getLastRowNum()) {
/*  97 */       return false;
/*     */     }
/*     */     
/* 100 */     Row currentLine = this._sheet.getRow(this._lineNumber++);
/* 101 */     this._currentLine = getData(currentLine);
/* 102 */     if (isEmptyRow(this._currentLine) && this._lineNumber - 1 == this._sheet.getLastRowNum()) {
/* 103 */       return false;
/*     */     }
/* 105 */     return true;
/*     */   }
/*     */   
/*     */   private boolean isEmptyRow(String[] row) {
/* 109 */     if (row == null || row.length == 0) {
/* 110 */       return true;
/*     */     }
/* 112 */     boolean result = true; byte b; int i; String[] arrayOfString;
/* 113 */     for (i = (arrayOfString = row).length, b = 0; b < i; ) { String cell = arrayOfString[b];
/* 114 */       if (cell != null && !cell.equals("")) {
/* 115 */         result = false; break;
/*     */       } 
/*     */       b++; }
/*     */     
/* 119 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] next() {
/* 127 */     return this._currentLine;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String[] getData(Row line) {
/* 139 */     if (line == null) {
/* 140 */       return new String[0];
/*     */     }
/* 142 */     List<String> result = new ArrayList<>();
/*     */     
/* 144 */     for (int i = 0; i < line.getLastCellNum(); i++) {
/* 145 */       result.add(getCellValue(line, i));
/*     */     }
/* 147 */     return result.<String>toArray(new String[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getCellValue(Row line, int colNum) {
/*     */     double dValue;
/* 157 */     Cell cell = line.getCell(colNum);
/* 158 */     if (cell == null) {
/* 159 */       return "";
/*     */     }
/*     */     
/* 162 */     switch (cell.getCellType()) {
/*     */       case STRING:
/* 164 */         return cell.getStringCellValue();
/*     */       case NUMERIC:
/* 166 */         dValue = cell.getNumericCellValue();
/* 167 */         if (isCellMCDateFormatted(cell)) {
/* 168 */           Date date = DateUtil.getJavaDate(dValue);
/* 169 */           return getDateString(date, colNum);
/*     */         } 
/* 171 */         return getNumberString(dValue);
/*     */       case BOOLEAN:
/* 173 */         return Boolean.toString(cell.getBooleanCellValue());
/*     */       case FORMULA:
/* 175 */         return getStringFormulaValue(cell, colNum);
/*     */ 
/*     */ 
/*     */       
/*     */       case null:
/* 180 */         return "";
/*     */     } 
/* 182 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getNumberString(double value) {
/* 195 */     return BigDecimal.valueOf(value).stripTrailingZeros().toPlainString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String getDateString(Date date, int colNum) {
/* 201 */     String format = "yyyyMMddHHmmssSSS";
/* 202 */     return MCDate.valueOf(date).toString(format);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isCellMCDateFormatted(Cell cell) {
/* 212 */     return !(!DateUtil.isCellDateFormatted(cell) && 
/* 213 */       !this.set.contains(cell.getCellStyle().getDataFormatString()));
/*     */   }
/*     */   private String getStringFormulaValue(Cell cell, int colNum) {
/*     */     double dValue;
/* 217 */     assert cell.getCellType() == CellType.FORMULA;
/*     */     
/* 219 */     if (cell.getCachedFormulaResultType() == CellType.ERROR) {
/* 220 */       throw new MCException(Core_Msg_FW_A.FCBLC3007, new Object[] { Integer.valueOf(this._lineNumber), Integer.valueOf(colNum), Byte.valueOf(cell.getErrorCellValue()) });
/*     */     }
/*     */     
/* 223 */     Workbook book = this._sheet.getWorkbook();
/* 224 */     CreationHelper helper = book.getCreationHelper();
/* 225 */     FormulaEvaluator evaluator = helper.createFormulaEvaluator();
/* 226 */     CellValue value = evaluator.evaluate(cell);
/* 227 */     switch (value.getCellType()) {
/*     */       case STRING:
/* 229 */         return value.getStringValue();
/*     */       case NUMERIC:
/* 231 */         dValue = cell.getNumericCellValue();
/* 232 */         if (isCellMCDateFormatted(cell)) {
/* 233 */           Date date = DateUtil.getJavaDate(dValue);
/* 234 */           return getDateString(date, colNum);
/*     */         } 
/* 236 */         return getNumberString(value.getNumberValue());
/*     */       case BOOLEAN:
/* 238 */         return Boolean.toString(value.getBooleanValue());
/*     */     } 
/* 240 */     return "";
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getNextLine() {
/* 245 */     if (!hasNext()) {
/* 246 */       return new String[0];
/*     */     }
/* 248 */     return next();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLineNumber() {
/* 259 */     return this._lineNumber;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\io\MCExcelSheetReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */