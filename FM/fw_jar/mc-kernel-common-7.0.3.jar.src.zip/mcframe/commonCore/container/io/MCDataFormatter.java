/*    */ package mcframe.commonCore.container.io;
/*    */ 
/*    */ import java.util.Date;
/*    */ import mcframe.commonCore.lang.MCTimestamp;
/*    */ import org.apache.poi.ss.usermodel.DataFormatter;
/*    */ import org.apache.poi.ss.usermodel.DateUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCDataFormatter
/*    */   extends DataFormatter
/*    */ {
/* 15 */   MCCellDateFormatSet dateformatset = new MCCellDateFormatSet();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String formatRawCellContents(double value, int formatIndex, String formatString, boolean use1904Windowing) {
/* 27 */     if ((DateUtil.isADateFormat(formatIndex, formatString) || 
/* 28 */       this.dateformatset.contains(formatString)) && 
/* 29 */       DateUtil.isValidExcelDate(value)) {
/* 30 */       Date d = DateUtil.getJavaDate(value, use1904Windowing);
/*    */       
/* 32 */       return MCTimestamp.valueOf(d).toString();
/*    */     } 
/*    */     
/* 35 */     return super.formatRawCellContents(value, formatIndex, formatString, 
/* 36 */         use1904Windowing);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\io\MCDataFormatter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */