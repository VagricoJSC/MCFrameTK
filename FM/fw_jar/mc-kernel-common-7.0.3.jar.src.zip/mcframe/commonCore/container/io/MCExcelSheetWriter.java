/*    */ package mcframe.commonCore.container.io;
/*    */ 
/*    */ import org.apache.poi.ss.usermodel.Cell;
/*    */ import org.apache.poi.ss.usermodel.CellStyle;
/*    */ import org.apache.poi.ss.usermodel.CellType;
/*    */ import org.apache.poi.ss.usermodel.DataFormat;
/*    */ import org.apache.poi.ss.usermodel.Row;
/*    */ import org.apache.poi.ss.usermodel.Sheet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCExcelSheetWriter
/*    */ {
/*    */   private final Sheet _sheet;
/*    */   private final DataFormat dataFormat;
/*    */   private final CellStyle stringCellStyle;
/*    */   
/*    */   public MCExcelSheetWriter(Sheet _sheet) {
/* 40 */     this._sheet = _sheet;
/* 41 */     this.dataFormat = _sheet.getWorkbook().createDataFormat();
/* 42 */     this.stringCellStyle = _sheet.getWorkbook().createCellStyle();
/* 43 */     this.stringCellStyle.setDataFormat(this.dataFormat.getFormat("text"));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getLastLineNum() {
/* 53 */     return this._sheet.getLastRowNum();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addStringRow(String[] data, int lineNum) {
/* 66 */     Row row = this._sheet.createRow(lineNum);
/*    */     
/* 68 */     for (int i = 0; i < data.length; i++) {
/* 69 */       Cell cell = row.createCell(i, CellType.STRING);
/* 70 */       cell.setCellValue(data[i]);
/*    */ 
/*    */       
/* 73 */       cell.setCellStyle(this.stringCellStyle);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\io\MCExcelSheetWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */