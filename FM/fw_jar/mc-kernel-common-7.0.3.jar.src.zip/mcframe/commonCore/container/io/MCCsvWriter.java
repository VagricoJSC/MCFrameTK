/*     */ package mcframe.commonCore.container.io;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCDataType;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.notice.MCMessage;
/*     */ import mcframe.commonCore.notice.MCMessageList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCCsvWriter<R extends MCRow>
/*     */ {
/*     */   private final MCList<R> _container;
/*     */   private final String _fileName;
/*  53 */   private MCContainerColumnMapper<R> _mapper = new DefaultContainerColumnMapper<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IfColumnFormatEditor _formatEditor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IfColumnNameEditor _nameEditor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCCsvWriter(MCList<R> container, String fileName) {
/*  79 */     this._container = container;
/*  80 */     this._fileName = fileName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCCsvWriter(MCList<R> container, File file) {
/*  92 */     this(container, file.getAbsolutePath());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setContainerColumnMapper(MCContainerColumnMapper<R> mapper) {
/* 102 */     if (mapper != null) {
/* 103 */       this._mapper = mapper;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setColumnFormatEditor(IfColumnFormatEditor editor) {
/* 116 */     if (editor != null) {
/* 117 */       this._formatEditor = editor;
/*     */     }
/*     */   }
/*     */   
/*     */   public void setColumnNameEditor(IfColumnNameEditor editor) {
/* 122 */     if (editor != null) {
/* 123 */       this._nameEditor = editor;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCMessageList write() {
/* 134 */     return write(new MCContainerIOConfig(), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCMessageList write(String[] columns) {
/* 147 */     return write(new MCContainerIOConfig(), columns);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCMessageList write(MCContainerIOConfig config) {
/* 159 */     return write(config, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCMessageList write(MCContainerIOConfig config, String[] columns) {
/* 173 */     MCMessageList result = new MCMessageList();
/*     */     
/* 175 */     MCIOFileColumnInfo targetColumns = resolveColumns(columns, config);
/* 176 */     this._mapper.init(targetColumns, (R)this._container.createRow(), config);
/* 177 */     List<MCDataType> types = this._mapper.getColumnTypeList();
/*     */     try {
/* 179 */       Exception exception2, exception1 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 200 */     catch (IOException e) {
/* 201 */       MCMessage m = new MCMessage(Core_Msg_FW_A.FCBLC3005, new Object[] { this._fileName });
/* 202 */       MCLog.write((Throwable)new MCException(e, m));
/* 203 */       result.add(m);
/*     */     } 
/*     */     
/* 206 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCIOFileColumnInfo resolveColumns(String[] argColumns, MCContainerIOConfig config) {
/* 220 */     List<String> result = new ArrayList<>();
/* 221 */     MCRow mCRow = this._container.createRow(); byte b; int i; String[] arrayOfString;
/* 222 */     for (i = (arrayOfString = getWriteColumns(argColumns, config)).length, b = 0; b < i; ) { String colName = arrayOfString[b];
/* 223 */       if (this._mapper.isFileOutputColumn((R)mCRow, colName))
/* 224 */         result.add(colName); 
/*     */       b++; }
/*     */     
/* 227 */     return new MCIOFileColumnInfo(result.<String>toArray(new String[result.size()]));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String[] getWriteColumns(String[] argColumns, MCContainerIOConfig config) {
/* 240 */     if (argColumns != null && argColumns.length != 0) {
/* 241 */       return argColumns;
/*     */     }
/* 243 */     return this._container.getColumnPathArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCList<R> getContainer() {
/* 254 */     return this._container;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCContainerColumnMapper<R> getColumnMapper() {
/* 265 */     return this._mapper;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\io\MCCsvWriter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */