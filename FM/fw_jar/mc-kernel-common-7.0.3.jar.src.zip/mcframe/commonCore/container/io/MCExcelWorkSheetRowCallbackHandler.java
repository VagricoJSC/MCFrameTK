/*     */ package mcframe.commonCore.container.io;
/*     */ 
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Optional;
/*     */ import org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler;
/*     */ import org.apache.poi.xssf.usermodel.XSSFComment;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCExcelWorkSheetRowCallbackHandler
/*     */   implements XSSFSheetXMLHandler.SheetContentsHandler
/*     */ {
/*     */   private static final int HEADER_ROW = 0;
/*     */   private ExcelRowContentCallback rowCallback;
/*     */   private LinkedHashMap<String, String> _columnHeaders;
/*  81 */   Optional<LinkedHashMap<String, String>> _columnHeadersOpt = Optional.empty();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private LinkedHashMap<String, String> _currentRowMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int _currentRow;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCExcelWorkSheetRowCallbackHandler(ExcelRowContentCallback rowCallbackHandler) {
/* 109 */     this.rowCallback = rowCallbackHandler;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startRow(int rowNum) {
/* 117 */     this._currentRow = rowNum;
/*     */     
/* 119 */     if (this._currentRow == 0) {
/* 120 */       this._columnHeaders = new LinkedHashMap<>();
/*     */     }
/*     */     else {
/*     */       
/* 124 */       this._columnHeadersOpt.ifPresent(_colHdrs -> {
/*     */             this._currentRowMap = new LinkedHashMap<>();
/*     */             _colHdrs.values().forEach(());
/*     */           });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cell(String cellReference, String formattedValue, XSSFComment comment) {
/* 138 */     if (this._currentRow == 0) {
/* 139 */       this._columnHeaders.put(getColumnReference(cellReference), formattedValue);
/* 140 */       this._columnHeadersOpt = Optional.ofNullable(this._columnHeaders);
/*     */     }
/*     */     else {
/*     */       
/* 144 */       this._columnHeadersOpt.ifPresent(_colHdrs -> {
/*     */             String colHdr = _colHdrs.get(getColumnReference(paramString1));
/*     */             this._currentRowMap.put(colHdr, paramString2);
/*     */           });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void endRow(int rowNum) {
/* 156 */     if (this._currentRow == 0) {
/*     */       
/* 158 */       this.rowCallback.processRow(this._currentRow, this._columnHeaders);
/*     */ 
/*     */     
/*     */     }
/* 162 */     else if (this._columnHeadersOpt.isPresent()) {
/* 163 */       this.rowCallback.processRow(this._currentRow, this._currentRowMap);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void headerFooter(String text, boolean isHeader, String tagName) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getColumnReference(String cellReference) {
/* 190 */     if (cellReference == null || cellReference.equals("")) {
/* 191 */       return "";
/*     */     }
/* 193 */     return cellReference.split("[0-9]*$")[0];
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\io\MCExcelWorkSheetRowCallbackHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */