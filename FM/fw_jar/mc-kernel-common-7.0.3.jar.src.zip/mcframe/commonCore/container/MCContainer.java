package mcframe.commonCore.container;

import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.meta.MCMeta;

public interface MCContainer {
  void clear();
  
  void clear(String... paramVarArgs);
  
  boolean isEmpty();
  
  MCDataType getDataType(String paramString);
  
  String[] getNameArray();
  
  MCMeta getMeta(String paramString);
  
  MCMeta[] getMetaArray();
  
  String[] getColumnPathArray();
  
  void setAttributes(MCRow paramMCRow);
  
  boolean isStatusNone();
  
  void setStatus(MCRow.Status paramStatus);
  
  int getParamIndex();
  
  int setParamIndex(int paramInt);
  
  MCTimestamp getRefTime();
  
  MCTimestamp setRefTime(MCTimestamp paramMCTimestamp);
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\MCContainer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */