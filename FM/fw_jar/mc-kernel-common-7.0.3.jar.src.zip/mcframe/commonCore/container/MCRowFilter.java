/*      */ package mcframe.commonCore.container;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.List;
/*      */ import mcframe.commonCore.expression.MCAggregateFunctions;
/*      */ import mcframe.commonCore.expression.MCExpressionBuilder;
/*      */ import mcframe.commonCore.expression.MCExpressionFunctions;
/*      */ import mcframe.commonCore.lang.MCCalendarDate;
/*      */ import mcframe.commonCore.lang.MCDataMatcher;
/*      */ import mcframe.commonCore.lang.MCDataType;
/*      */ import mcframe.commonCore.lang.MCDate;
/*      */ import mcframe.commonCore.lang.MCDateFieldType;
/*      */ import mcframe.commonCore.lang.MCDateUtil;
/*      */ import mcframe.commonCore.lang.MCNumber;
/*      */ import mcframe.commonCore.lang.MCStringUtil;
/*      */ import mcframe.commonCore.lang.MCTimestamp;
/*      */ import mcframe.commonCore.meta.MCMeta;
/*      */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*      */ import mcframe.commonCore.notice.MCException;
/*      */ import mcframe.commonCore.notice.MCLog;
/*      */ import mcframe.commonCore.notice.MCMessage;
/*      */ import mcframe.commonCore.notice.MCMessageList;
/*      */ import mcframe.commonCore.sys.MCFactory;
/*      */ import mcframe.commonCore.sys.MCSys;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MCRowFilter
/*      */   implements MCRowMatcher<MCRow>, Cloneable
/*      */ {
/*      */   public static final String AND = "AND";
/*      */   public static final String OR = "OR";
/*      */   public static final String EQUAL = "EQUAL";
/*      */   public static final String NOT_EQUAL = "NOT_EQUAL";
/*      */   public static final String LESS_THAN = "LESS_THAN";
/*      */   public static final String LESS_THAN_EQUAL = "LESS_THAN_EQUAL";
/*      */   public static final String GREATER_THAN = "GREATER_THAN";
/*      */   public static final String GREATER_THAN_EQUAL = "GREATER_THAN_EQUAL";
/*      */   public static final String START_WITH = "START_WITH";
/*      */   public static final String NOT_START_WITH = "NOT_START_WITH";
/*      */   public static final String END_WITH = "END_WITH";
/*      */   public static final String NOT_END_WITH = "NOT_END_WITH";
/*      */   public static final String CONTAINS = "CONTAINS";
/*      */   public static final String NOT_CONTAINS = "NOT_CONTAINS";
/*      */   public static final String FIELD_YEAR = "y";
/*      */   public static final String FIELD_MONTH = "M";
/*      */   public static final String FIELD_DAY = "d";
/*      */   public static final String FIELD_HOUR = "H";
/*      */   public static final String FIELD_MINUTE = "m";
/*      */   public static final String FIELD_SECOND = "s";
/*      */   public static final String FIELD_MILLI_SECOND = "S";
/*      */   private static final String DATE_SEP = ";";
/*      */   private static final String DATECOL_CO = "_date_company";
/*      */   private static final String DATECOL_MC = "_date_mcframe";
/*      */   private static final String DATECOL_SYS = "_date_system";
/*      */   
/*      */   public static String getDateSaveValue(String diff_col, String diff_field, MCNumber diff, MCTimestamp date) {
/*  329 */     String diff_s = (diff != null) ? diff.toSimpleString() : null;
/*  330 */     String date_s = (date != null) ? date.toString() : null;
/*  331 */     return MCStringUtil.join(";", new String[] { diff_col, diff_field, diff_s, date_s });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setDateSaveValue(String value, MCRow row, String diff_col, String diff_field, String diff, String date) {
/*  359 */     String[] vals = MCStringUtil.split(";", value);
/*  360 */     if (diff_col != null) {
/*  361 */       row.setStringNE(diff_col, (
/*  362 */           vals.length > 0 && vals[0].length() > 0) ? vals[0] : null);
/*      */     }
/*  364 */     if (diff_field != null) {
/*  365 */       row.setStringNE(diff_field, (
/*  366 */           vals.length > 1 && vals[1].length() > 0) ? vals[1] : null);
/*      */     }
/*  368 */     if (diff != null) {
/*  369 */       row.setNumberNE(diff, (
/*  370 */           vals.length > 2 && vals[2].length() > 0) ? MCNumber.valueOf(vals[2]) : null);
/*      */     }
/*  372 */     if (date != null) {
/*  373 */       row.setTimestampNE(date, (
/*  374 */           vals.length > 3 && vals[3].length() > 0) ? 
/*  375 */           MCTimestamp.valueOf(vals[3], "yyyyMMddHHmmssSSS") : null);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _disable = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  415 */   private String _column_name = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  423 */   private MCDataType _data_type = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  431 */   private Comparable<?> _value = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  439 */   private String _relative = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  447 */   private String _logic = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  456 */   private List<MCDateFieldType> _date_field_type_list = null;
/*      */ 
/*      */ 
/*      */   
/*      */   private MCExpressionBuilder _eb;
/*      */ 
/*      */ 
/*      */   
/*      */   private MCList<MCRow> _agregateList;
/*      */ 
/*      */ 
/*      */   
/*      */   private MCDate _codate;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCRowFilter createInstance() {
/*  474 */     return new MCRowFilter();
/*      */   }
/*      */ 
/*      */   
/*      */   public MCRowFilter clone() {
/*  479 */     MCRowFilter f = createInstance();
/*  480 */     f.copy(this);
/*  481 */     return f;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void copy(MCRowFilter filter) {
/*  494 */     setDisable(filter.isDisable());
/*  495 */     setConditionNoCheck(filter.getColumnName(), filter.getDataType(), 
/*  496 */         filter.getConditionValue(), filter.getRelativeOperator(), 
/*  497 */         filter.getLogicOperator());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCRowFilter() {
/*  506 */     this._eb = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  531 */     this._agregateList = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  552 */     this._codate = null; } public MCExpressionBuilder getExpressionBuilder() {
/*      */     if (this._eb == null) {
/*      */       this._eb = new MCExpressionBuilder(new MCExpressionFunctions[0]);
/*      */       if (this._agregateList != null)
/*      */         this._eb.addFunctions((MCExpressionFunctions)new MCAggregateFunctions(this._agregateList)); 
/*      */     } 
/*      */     return this._eb;
/*      */   } public void setAggregateList(MCList<? extends MCRow> list) {
/*      */     this._agregateList = (MCList)list;
/*      */   } public void setCoDate(MCDate codate) {
/*  562 */     this._codate = codate;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean setCondition(String name, MCDataType type, Comparable<?> value, String relative, String logic) {
/*  585 */     if (!checkCondition(name, type, value, relative, logic)) {
/*  586 */       return false;
/*      */     }
/*  588 */     setConditionNoCheck(name, type, value, relative, logic);
/*  589 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConditionNoCheck(String name, MCDataType type, Comparable<?> value, String relative, String logic) {
/*  605 */     setColumnNameNoCheck(name);
/*  606 */     setDataTypeNoCheck(type);
/*  607 */     setConditionValueNoCheck(value);
/*  608 */     setRelativeOperatorNoCheck(relative);
/*  609 */     setLogicOperatorNoCheck(logic);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setColumnNameNoCheck(String name) {
/*  621 */     this._column_name = name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getColumnName() {
/*  633 */     return this._column_name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDataTypeNoCheck(MCDataType type) {
/*  644 */     this._data_type = type;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCDataType getDataType() {
/*  656 */     return this._data_type;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConditionValueNoCheck(Comparable<?> value) {
/*  667 */     this._value = value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Comparable<?> getConditionValue() {
/*  679 */     return this._value;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRelativeOperatorNoCheck(String relative) {
/*  690 */     this._relative = relative;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getRelativeOperator() {
/*  702 */     return this._relative;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLogicOperatorNoCheck(String logic) {
/*  713 */     this._logic = logic;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getLogicOperator() {
/*  725 */     return this._logic;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDisable(boolean disable) {
/*  738 */     this._disable = disable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isDisable() {
/*  749 */     return this._disable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDateFieldTypeList(List<MCDateFieldType> list) {
/*  760 */     this._date_field_type_list = list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<MCDateFieldType> getDateFieldTypeList() {
/*  771 */     return this._date_field_type_list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCMessageList checkCondition(MCRow condition, String name, String type, String value, String relative, String logic) {
/*  791 */     MCMessageList l = new MCMessageList();
/*  792 */     checkColumnName(l, condition, name);
/*  793 */     MCDataType t = checkDataType(l, condition, type);
/*  794 */     if (t == null) {
/*  795 */       return l;
/*      */     }
/*  797 */     checkConditionValue(l, condition, value, t);
/*  798 */     checkRelativeOperator(l, condition, relative, t);
/*  799 */     checkLogicOperator(l, condition, logic);
/*  800 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean checkCondition(String name, MCDataType type, Comparable<?> value, String relative, String logic) {
/*  819 */     if (!checkColumnName(null, name)) {
/*  820 */       return false;
/*      */     }
/*      */     
/*  823 */     if (!checkDataType(null, type)) {
/*  824 */       return false;
/*      */     }
/*      */     
/*  827 */     if (!checkConditionValue(null, value, type)) {
/*  828 */       return false;
/*      */     }
/*      */     
/*  831 */     if (!checkRelativeOperator(null, relative, type)) {
/*  832 */       return false;
/*      */     }
/*      */     
/*  835 */     if (!checkLogicOperator(null, logic)) {
/*  836 */       return false;
/*      */     }
/*      */     
/*  839 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String checkColumnName(MCMessageList list, MCRow condition, String name) {
/*  862 */     MCMessageList l = new MCMessageList();
/*      */     
/*  864 */     String n = condition.getString(name);
/*  865 */     if (!checkColumnName(l, n)) {
/*  866 */       n = null;
/*      */     }
/*      */     
/*  869 */     if (l.size() > 0) {
/*  870 */       for (MCMessage m : l) {
/*  871 */         m.setCauseRow(condition, name);
/*      */       }
/*  873 */       list.addAll((Collection)l);
/*      */     } 
/*      */     
/*  876 */     return n;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean checkColumnName(MCMessageList list, String name) {
/*  893 */     if (MCStringUtil.isNull(name)) {
/*  894 */       if (list != null) {
/*  895 */         MCMessage m = new MCMessage(Core_Msg_FW_A.FCBAC0361, new Object[0]);
/*  896 */         list.add(m);
/*      */       } 
/*  898 */       return false;
/*      */     } 
/*  900 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MCDataType checkDataType(MCMessageList list, MCRow condition, String type) {
/*  923 */     MCMessageList l = new MCMessageList();
/*  924 */     MCDataType t = null;
/*  925 */     String v = condition.getString(type);
/*  926 */     if (v != null) {
/*  927 */       t = MCDataType.valueOf(v);
/*      */     }
/*      */     
/*  930 */     if (!checkDataType(l, t)) {
/*  931 */       t = null;
/*      */     }
/*      */     
/*  934 */     if (l.size() > 0) {
/*  935 */       for (MCMessage m : l) {
/*  936 */         m.setCauseRow(condition, type);
/*      */       }
/*  938 */       list.addAll((Collection)l);
/*      */     } 
/*      */     
/*  941 */     return t;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean checkDataType(MCMessageList list, MCDataType type) {
/*  958 */     List<MCDataType> l = getEnableDataTypeList();
/*  959 */     if (!l.contains(type)) {
/*  960 */       if (list != null) {
/*  961 */         String a1 = (type != null) ? type.name() : null;
/*  962 */         String[] a = new String[l.size()];
/*  963 */         for (int i = 0; i < l.size(); i++) {
/*  964 */           a[i] = ((MCDataType)l.get(i)).name();
/*      */         }
/*  966 */         String a2 = MCStringUtil.join(",", a);
/*  967 */         MCMessage m = new MCMessage(Core_Msg_FW_A.FCBAC0362, new Object[] { a1, a2 });
/*  968 */         list.add(m);
/*      */       } 
/*  970 */       return false;
/*      */     } 
/*  972 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Comparable<?> checkConditionValue(MCMessageList list, MCRow condition, String value, MCDataType type) {
/*  997 */     MCMessageList l = new MCMessageList();
/*  998 */     Comparable<?> v = condition.getValue(value);
/*  999 */     if (!checkConditionValue(l, v, type)) {
/* 1000 */       v = null;
/*      */     }
/*      */     
/* 1003 */     if (l.size() > 0) {
/* 1004 */       for (MCMessage m : l) {
/* 1005 */         m.setCauseRow(condition, value);
/*      */       }
/* 1007 */       list.addAll((Collection)l);
/*      */     } 
/*      */     
/* 1010 */     return v;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean checkConditionValue(MCMessageList list, Comparable<?> value, MCDataType type) {
/* 1029 */     if (type.isDateType())
/*      */     {
/*      */ 
/*      */ 
/*      */       
/* 1034 */       return true;
/*      */     }
/*      */     
/*      */     try {
/* 1038 */       type.cast(value);
/*      */     }
/* 1040 */     catch (MCException mCException) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1054 */       if (list != null) {
/* 1055 */         list.add(invalidConditionValueMessage(value, type));
/*      */       }
/* 1057 */       return false;
/*      */     } 
/* 1059 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MCMessage invalidConditionValueMessage(Comparable<?> value, MCDataType type) {
/* 1072 */     String a1 = (type != null) ? type.name() : null;
/* 1073 */     Comparable<?> a2 = value;
/* 1074 */     String a3 = (value != null) ? value.getClass().getName() : null;
/* 1075 */     return new MCMessage(Core_Msg_FW_A.FCBAC0363, new Object[] { a1, a2, a3 });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String checkRelativeOperator(MCMessageList list, MCRow condition, String relative, MCDataType type) {
/* 1100 */     MCMessageList l = new MCMessageList();
/* 1101 */     String v = condition.getString(relative);
/* 1102 */     if (!checkRelativeOperator(l, v, type)) {
/* 1103 */       v = null;
/*      */     }
/*      */     
/* 1106 */     if (l.size() > 0) {
/* 1107 */       for (MCMessage m : l) {
/* 1108 */         m.setCauseRow(condition, relative);
/*      */       }
/* 1110 */       list.addAll((Collection)l);
/*      */     } 
/*      */     
/* 1113 */     return v;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean checkRelativeOperator(MCMessageList list, String relative, MCDataType type) {
/* 1132 */     List<String> e = getEnableRelativeOperatorList(type);
/* 1133 */     if (!e.contains(relative)) {
/* 1134 */       if (list != null) {
/* 1135 */         String a1 = (type != null) ? type.name() : null;
/* 1136 */         String a2 = relative;
/* 1137 */         String a3 = MCStringUtil.join(
/* 1138 */             ",", e.<String>toArray(new String[e.size()]));
/* 1139 */         MCMessage m = new MCMessage(Core_Msg_FW_A.FCBAC0364, new Object[] { a1, a2, a3 });
/* 1140 */         list.add(m);
/*      */       } 
/* 1142 */       return false;
/*      */     } 
/* 1144 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String checkLogicOperator(MCMessageList list, MCRow condition, String logic) {
/* 1168 */     MCMessageList l = new MCMessageList();
/* 1169 */     String v = condition.getString(logic);
/* 1170 */     if (!checkLogicOperator(l, v)) {
/* 1171 */       v = null;
/*      */     }
/*      */     
/* 1174 */     if (l.size() > 0) {
/* 1175 */       for (MCMessage m : l) {
/* 1176 */         m.setCauseRow(condition, logic);
/*      */       }
/* 1178 */       list.addAll((Collection)l);
/*      */     } 
/* 1180 */     return v;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean checkLogicOperator(MCMessageList list, String logic) {
/* 1197 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<MCDataType> getEnableDataTypeList() {
/* 1208 */     List<MCDataType> l = new ArrayList<>();
/*      */     
/* 1210 */     l.add(MCDataType.STRING);
/* 1211 */     l.add(MCDataType.NUMBER);
/* 1212 */     l.add(MCDataType.DATE);
/* 1213 */     l.add(MCDataType.TIMESTAMP);
/* 1214 */     l.add(MCDataType.BOOLEAN);
/*      */     
/* 1216 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> getEnableRelativeOperatorList(MCDataType type) {
/* 1229 */     return MCDataMatcher.getEnableRelativeOperatorList(type);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Comparable<?> getRowValue(MCRow row) {
/* 1241 */     String n = getColumnName();
/* 1242 */     if (row.getMeta(n) != null)
/*      */     {
/* 1244 */       return row.getValue(n);
/*      */     }
/*      */     
/* 1247 */     MCExpressionBuilder eb = getExpressionBuilder();
/* 1248 */     return (Comparable<?>)eb.evaluate(getColumnName(), row);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MCDataType getRowDataType(MCRow row) {
/* 1260 */     String n = getColumnName();
/* 1261 */     MCDataType type = row.getDataType(n);
/*      */     
/* 1263 */     return (type != null) ? type : MCDataType.NUMBER;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean match(MCRow row) {
/*      */     MCCalendarDate mCCalendarDate;
/*      */     MCRow dateR;
/*      */     String col;
/*      */     MCTimestamp val;
/* 1281 */     MCDataMatcher matcher = null;
/*      */     
/* 1283 */     Comparable<?> v = getRowValue(row);
/* 1284 */     Comparable<?> c = getConditionValue();
/*      */     
/* 1286 */     String o = getRelativeOperator();
/* 1287 */     List<MCDateFieldType> l = getDateFieldTypeList();
/* 1288 */     MCDataType type = getRowDataType(row);
/*      */ 
/*      */     
/* 1291 */     switch (type) {
/*      */       case STRING:
/* 1293 */         matcher = MCDataMatcher.create((String)c, o);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1389 */         return matcher.match(type.cast(v));case NUMBER: matcher = MCDataMatcher.create((MCNumber)c, o); return matcher.match(type.cast(v));case BOOLEAN: matcher = MCDataMatcher.create(((Boolean)c).booleanValue(), o); return matcher.match(type.cast(v));case DATE: case TIMESTAMP: dateR = MCRow.create(); setDateSaveValue((String)c, dateR, "column", "field", "diff", "date"); col = dateR.getString("column"); val = dateR.getTimestamp("date"); if (col == null) { matcher = (type == MCDataType.DATE) ? MCDataMatcher.create(MCDate.valueOf(val), o) : MCDataMatcher.create(val, o); } else { String field = dateR.getString("field"); MCNumber diff = dateR.getNumber("diff"); MCMeta meta = row.getMeta(col); MCDataType difftype = (meta != null) ? meta.type() : null; MCDate dt = null; String str1; switch ((str1 = col).hashCode()) { case -531883035: if (!str1.equals("_date_mcframe")) break;  dt = MCDate.now(); break;case -467030325: if (!str1.equals("_date_company")) break;  dt = (this._codate != null) ? this._codate : getCoToday(); break;case 729513505: if (!str1.equals("_date_system")) break;  dt = MCDate.sysnow(); break; }  if (type == MCDataType.DATE) { dt = (dt != null) ? dt : ((difftype == MCDataType.DATE) ? row.getDate(col) : MCDate.valueOf(row.getTimestamp(col))); matcher = createDateDiffMatcher(dt, field, diff, o); } else { MCTimestamp ts = (dt != null) ? MCTimestamp.valueOf(dt) : ((difftype == MCDataType.TIMESTAMP) ? row.getTimestamp(col) : MCTimestamp.valueOf(row.getDate(col))); matcher = createTimestampDiffMatcher(ts, field, diff, o); }  MCDateFieldType ft = MCDateUtil.getDateFieldType(field); if (ft != null && v != null) mCCalendarDate = (type == MCDataType.DATE) ? ((MCDate)v).trunc(ft) : ((MCTimestamp)v).trunc(ft);  }  if (matcher == null) return false;  if (l != null) matcher.setDateFieldType(l);  return matcher.match(type.cast((Comparable)mCCalendarDate));
/*      */     } 
/*      */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MCDataMatcher createDateDiffMatcher(MCDate val, String field, MCNumber diff, String ope) {
/* 1405 */     if (val == null || diff == null || field == null)
/*      */     {
/* 1407 */       return null;
/*      */     }
/*      */     String str;
/* 1410 */     switch ((str = field).hashCode()) { case 72: if (!str.equals("H")) {
/*      */           break;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1421 */         val = (MCDate)val.addHour((Number)diff); break;case 77: if (!str.equals("M"))
/*      */           break;  val = (MCDate)val.addMonth((Number)diff); break;case 83: if (!str.equals("S")); break;case 100: if (!str.equals("d"))
/*      */           break;  val = (MCDate)val.addDay((Number)diff); break;case 109: if (!str.equals("m"))
/* 1424 */           break;  val = (MCDate)val.addMinute((Number)diff); break;
/*      */       case 115:
/*      */         if (!str.equals("s"))
/* 1427 */           break;  val = (MCDate)val.addSecond((Number)diff); break;
/*      */       case 121:
/*      */         if (!str.equals("y"))
/*      */           break;  val = (MCDate)val.addYear((Number)diff);
/*      */         break; }
/*      */     
/* 1433 */     MCDateFieldType ft = MCDateUtil.getDateFieldType(field);
/* 1434 */     val = (MCDate)val.trunc(ft);
/* 1435 */     return MCDataMatcher.create(val, ope);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MCDataMatcher createTimestampDiffMatcher(MCTimestamp val, String field, MCNumber diff, String ope) {
/* 1451 */     if (val == null || diff == null || field == null)
/*      */     {
/* 1453 */       return null;
/*      */     }
/*      */     String str;
/* 1456 */     switch ((str = field).hashCode()) { case 72: if (!str.equals("H")) {
/*      */           break;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1467 */         val = (MCTimestamp)val.addHour((Number)diff); break;
/*      */       case 77:
/*      */         if (!str.equals("M"))
/*      */           break; 
/*      */         val = (MCTimestamp)val.addMonth((Number)diff);
/*      */         break;
/*      */       case 83:
/*      */         if (!str.equals("S"))
/*      */           break; 
/* 1476 */         val = val.addMilliSecond((Number)diff); break;case 100: if (!str.equals("d"))
/*      */           break;  val = (MCTimestamp)val.addDay((Number)diff); break;case 109: if (!str.equals("m"))
/*      */           break;  val = (MCTimestamp)val.addMinute((Number)diff); break;case 115: if (!str.equals("s"))
/*      */           break;  val = (MCTimestamp)val.addSecond((Number)diff); break;
/*      */       case 121: if (!str.equals("y"))
/* 1481 */           break;  val = (MCTimestamp)val.addYear((Number)diff); break; }  MCDateFieldType ft = MCDateUtil.getDateFieldType(field);
/* 1482 */     val = (MCTimestamp)val.trunc(ft);
/* 1483 */     return MCDataMatcher.create(val, ope);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MCDate getCoToday() {
/* 1495 */     String srv = MCSys.request.serverId();
/* 1496 */     if (srv == null) {
/*      */       
/* 1498 */       Class<? extends Object> clazz = null;
/*      */       try {
/* 1500 */         clazz = MCFactory.getClass(Object.class, 
/* 1501 */             "mcframe.clientCore.date.MCCoTodayAgent");
/*      */       }
/* 1503 */       catch (MCException e) {
/*      */         
/* 1505 */         MCLog.write((Throwable)e);
/* 1506 */         return null;
/*      */       } 
/* 1508 */       return (MCDate)MCFactory.invokeStatic(clazz, "getCoToday", null, null);
/*      */     } 
/*      */ 
/*      */     
/* 1512 */     Class<? extends Object> c = null;
/*      */     try {
/* 1514 */       c = MCFactory.getClass(Object.class, 
/* 1515 */           "mcframe.serverCore.mcjdbc.FWDBUtil");
/*      */     }
/* 1517 */     catch (MCException e) {
/*      */       
/* 1519 */       MCLog.write((Throwable)e);
/* 1520 */       return null;
/*      */     } 
/* 1522 */     return (MCDate)MCFactory.invokeStatic(c, "coToday", null, null);
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\MCRowFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */