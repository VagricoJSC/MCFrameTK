/*     */ package mcframe.commonCore.container;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.commonCore.lang.MCBinary;
/*     */ import mcframe.commonCore.lang.MCDate;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.lang.MCTimestamp;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MCConstRow
/*     */   extends MCRow
/*     */ {
/*     */   protected static final MCMeta createStringMeta(String name, int length) {
/*  42 */     return MCContainerMeta.stringMeta(name, length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final MCMeta createStringMeta(String name) {
/*  54 */     return MCContainerMeta.stringMeta(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final MCMeta createNumberMeta(String name, int length, int scale, boolean minus) {
/*  70 */     return MCContainerMeta.numberMeta(name, length, scale, minus);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final MCMeta createNumberMeta(String name) {
/*  82 */     return MCContainerMeta.numberMeta(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final MCMeta createDateMeta(String name) {
/*  94 */     return MCContainerMeta.dateMeta(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final MCMeta createTimestampMeta(String name) {
/* 106 */     return MCContainerMeta.timestampMeta(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final MCMeta createBooleanMeta(String name) {
/* 118 */     return MCContainerMeta.booleanMeta(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final MCMeta createBinaryMeta(String name) {
/* 130 */     return MCContainerMeta.binaryMeta(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final MCMeta createInnerRowMeta(String name, Class<? extends MCConstRow> rowclass) {
/* 144 */     return MCContainerMeta.rowMeta(name, rowclass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final MCMeta createCryptStringMeta(String name, int length) {
/* 158 */     return MCContainerMeta.cryptStringMeta(name, length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final MCMeta createCryptStringMeta(String name) {
/* 170 */     return MCContainerMeta.cryptStringMeta(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final MCMeta createCommonMeta(String name, MCMeta meta) {
/* 214 */     return MCContainerMeta.cloneMeta(name, meta);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final MCMeta createCommonMeta(String name, MCMeta meta, Class<? extends MCConstRow> rowclass) {
/* 231 */     return MCContainerMeta.cloneMeta(name, meta, rowclass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 240 */   protected static final MCRow.ConstMetaList<MCRow> constMetas = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCConstRow(MCRow.ConstMetaList<? extends MCRow> metas) {
/* 271 */     super(metas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCConstRow createInnerRow(MCMeta meta) {
/* 291 */     MCConstRow inner = null;
/* 292 */     Class<? extends MCRow> c = null;
/*     */     try {
/* 294 */       MCContainerMeta cmeta = (MCContainerMeta)meta;
/* 295 */       c = cmeta.innerRowClass();
/* 296 */       inner = (MCConstRow)class2row(c);
/* 297 */     } catch (Exception ex) {
/*     */       
/* 299 */       throw new MCException(ex, Core_Msg_FW_A.FCBBC0003, new Object[] {
/* 300 */             msgBindClassName(), 
/* 301 */             meta.name(), 
/* 302 */             (c != null) ? c.getName() : null });
/*     */     } 
/* 304 */     inner.setParentRow(this, meta.name());
/*     */     
/* 306 */     inner._ri = null;
/*     */     
/* 308 */     return inner;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final String getConstString(int index, String name) {
/* 370 */     return (String)MCConstColumnList.get(this, index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setConstString(int index, String name, String value) {
/* 386 */     MCConstColumnList.set(this, index, name, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final MCNumber getConstNumber(int index, String name) {
/* 402 */     return (MCNumber)MCConstColumnList.get(this, index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setConstNumber(int index, String name, MCNumber value) {
/* 418 */     MCConstColumnList.set(this, index, name, (Comparable<?>)value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setConstNumber(int index, String name, int value) {
/* 434 */     MCConstColumnList.set(this, index, name, (Comparable<?>)MCNumber.valueOf(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setConstNumber(int index, String name, long value) {
/* 450 */     MCConstColumnList.set(this, index, name, (Comparable<?>)MCNumber.valueOf(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setConstNumber(int index, String name, float value) {
/* 466 */     MCConstColumnList.set(this, index, name, (Comparable<?>)MCNumber.valueOf(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setConstNumber(int index, String name, double value) {
/* 482 */     MCConstColumnList.set(this, index, name, (Comparable<?>)MCNumber.valueOf(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final MCDate getConstDate(int index, String name) {
/* 498 */     return (MCDate)MCConstColumnList.get(this, index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setConstDate(int index, String name, MCDate value) {
/* 514 */     MCConstColumnList.set(this, index, name, (Comparable<?>)value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final MCTimestamp getConstTimestamp(int index, String name) {
/* 530 */     return (MCTimestamp)MCConstColumnList.get(this, index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setConstTimestamp(int index, String name, MCTimestamp value) {
/* 546 */     MCConstColumnList.set(this, index, name, (Comparable<?>)value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final boolean getConstBoolean(int index, String name) {
/* 562 */     return ((Boolean)MCConstColumnList.get(this, index)).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setConstBoolean(int index, String name, boolean value) {
/* 579 */     MCConstColumnList.set(this, index, name, Boolean.valueOf(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final MCBinary getConstBinary(int index, String name) {
/* 595 */     return (MCBinary)MCConstColumnList.get(this, index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setConstBinary(int index, String name, MCBinary value) {
/* 611 */     MCConstColumnList.set(this, index, name, (Comparable<?>)value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final MCRow getConstInnerRow(int index, String name) {
/* 627 */     return (MCRow)MCConstColumnList.get(this, index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setConstInnerRow(int index, String name, MCRow value) {
/* 643 */     MCRow inner = (MCRow)MCConstColumnList.get(this, index);
/* 644 */     if (value != null) {
/*     */       
/* 646 */       MCRow.copyvalue(inner, value);
/*     */     } else {
/*     */       
/* 649 */       inner.clear();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getKeys(String aGroup) {
/* 662 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExtGroups() {
/* 673 */     Set<String> ret = new HashSet<>();
/* 674 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getExtMap(String aGroup) {
/* 686 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\MCConstRow.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */