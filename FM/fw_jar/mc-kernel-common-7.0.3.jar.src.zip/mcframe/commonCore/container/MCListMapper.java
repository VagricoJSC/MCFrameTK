/*     */ package mcframe.commonCore.container;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MCListMapper<D extends MCRow, S extends MCRow>
/*     */ {
/*     */   private final MCRowMapper<D, S> _rm;
/*     */   
/*     */   public MCListMapper(MCRowMapper<D, S> mapper) {
/*  33 */     this._rm = mapper;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAll(MCList<D> dest, MCList<S> src) {
/*  52 */     if (this._rm == null || dest == null || src == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  58 */     MCList<D> temp = dest.createInstance();
/*  59 */     for (MCRow mCRow : src) {
/*  60 */       D destrow = dest.createRow();
/*  61 */       this._rm.copy(destrow, (S)mCRow);
/*  62 */       temp.add(destrow);
/*     */     } 
/*  64 */     dest.addAll(temp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAllValue(MCList<D> dest, MCList<S> src) {
/*  83 */     if (this._rm == null || dest == null || src == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  89 */     MCList<D> temp = dest.createInstance();
/*  90 */     for (MCRow mCRow : src) {
/*  91 */       D destrow = dest.createRow();
/*  92 */       this._rm.copyValue(destrow, (S)mCRow);
/*  93 */       temp.add(destrow);
/*     */     } 
/*  95 */     dest.addAll(temp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <F extends MCList<S>> void join(MCList<D> dest, MCJoinKey<F> key) {
/* 114 */     if (this._rm == null || dest == null || key == null) {
/*     */       return;
/*     */     }
/* 117 */     for (MCRow mCRow : dest)
/* 118 */       this._rm.join((D)mCRow, key); 
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\MCListMapper.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */