/*     */ package mcframe.commonCore.container;
/*     */ 
/*     */ import mcframe.commonCore.lang.MCDataType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MCConstColumnList
/*     */   extends MCColumnList
/*     */ {
/*  14 */   private static final MCConstColumnList L = new MCConstColumnList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isConst() {
/*  21 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   int size() {
/*  26 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   MCRow row() {
/*  31 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   MCContainerMeta[] metas() {
/*  36 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   Comparable<?>[] datas() {
/*  41 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   int[] paramColIndex() {
/*  46 */     return null;
/*     */   }
/*     */   
/*     */   static void init(MCRow o, int i, Comparable[] ds) {
/*  50 */     L.init(true, o, i, metas(o)[i], (Comparable<?>[])ds);
/*     */   }
/*     */   
/*     */   static void rowinit(MCRow o) {
/*  54 */     o.init();
/*     */   }
/*     */   
/*     */   static int size(MCRow o) {
/*  58 */     return (metas(o)).length;
/*     */   }
/*     */   
/*     */   static MCContainerMeta[] metas(MCRow o) {
/*  62 */     return o._list.getContainerMetaArray();
/*     */   }
/*     */   
/*     */   static MCContainerMeta meta(MCRow o, int i) {
/*  66 */     return L.meta(o, i, size(o), metas(o));
/*     */   }
/*     */   
/*     */   static MCContainerMeta meta(MCRow o, String n) {
/*  70 */     return L.meta(size(o), n, metas(o));
/*     */   }
/*     */   
/*     */   static int paramColIndex(MCRow o, int i) {
/*  74 */     return L.paramColIndex(o, i, size(o), o._const_paramColIndex);
/*     */   }
/*     */   
/*     */   static int paramColIndex(MCRow o, String n) {
/*  78 */     return L.paramColIndex(n, o._const_paramColIndex);
/*     */   }
/*     */   
/*     */   static int indexOf(MCRow o, String n) {
/*  82 */     return L.indexOf(n, size(o), metas(o));
/*     */   }
/*     */   
/*     */   static int indexOf(MCRow o, MCContainerMeta m) {
/*  86 */     return L.indexOf(size(o), m, metas(o));
/*     */   }
/*     */   
/*     */   static void clear(MCRow o, int i) {
/*  90 */     L.clear(false, o, i, meta(o, i), o._const_datas);
/*     */   }
/*     */   
/*     */   static Comparable<?> get(MCRow o, MCContainerMeta m) {
/*  94 */     return L.get(false, o, size(o), m, metas(o), o._const_datas);
/*     */   }
/*     */   
/*     */   static Comparable<?> get(MCRow o, int i) {
/*  98 */     return L.get(false, o, i, o._const_datas);
/*     */   }
/*     */   
/*     */   static void set(MCRow o, int i, String n, Comparable<?> v) {
/* 102 */     L.set(false, o, i, n, v, o._const_datas);
/*     */   }
/*     */   
/*     */   static String[] getNameArray(MCRow o) {
/* 106 */     return L.getNameArray(size(o), metas(o));
/*     */   }
/*     */   
/*     */   static void setRange(MCRow o, int pos, int srcpos, int len, Comparable[] sds) {
/* 110 */     L.setRange(o, pos, srcpos, len, metas(o), o._const_datas, (Comparable<?>[])sds);
/*     */   }
/*     */   
/*     */   static void setParamColIndex(MCRow o, int pos, int srcpos, int len, int[] sds) {
/* 114 */     init(o, len);
/* 115 */     L.setParamColIndex(o, pos, srcpos, len, metas(o), o._const_paramColIndex, sds);
/*     */   }
/*     */   
/*     */   static int setParamColIndex(MCRow o, int i, MCDataType y, int pi) {
/* 119 */     init(o, pi);
/* 120 */     return L.setParamColIndex(i, y, o._const_paramColIndex, pi);
/*     */   }
/*     */   
/*     */   static void init(MCRow o, int pi) {
/* 124 */     if (pi != -1 && o._const_paramColIndex == null) {
/* 125 */       int size = size(o);
/* 126 */       o._const_paramColIndex = new int[size];
/* 127 */       for (int idx = 0; idx < size; idx++) {
/* 128 */         L.init(idx, o._const_paramColIndex);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   static Comparable<?> getchkval(MCRow o, int i, MCDataType y) {
/* 134 */     return L.getchkval(false, o, i, y, o._const_datas);
/*     */   }
/*     */ 
/*     */   
/*     */   static Comparable<?> setchkval(MCRow o, int i, String n, MCDataType y, Comparable<?> v) {
/* 139 */     return L.setchkval(false, o, i, n, y, v, metas(o), o._const_datas);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   Comparable<?> getchkvalimpl(MCRow row, int index, MCDataType type, Comparable<?> val) {
/* 145 */     return (type != MCDataType.ROW) ? super.getchkvalimpl(row, index, type, val) : 
/* 146 */       metas(row)[index].castInnerRow(val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setchkvalimpl(MCRow row, int index, String name, MCDataType type, Comparable<?> val, Comparable<?> last, MCContainerMeta[] metas, Comparable[] datas) {
/* 153 */     if (type != MCDataType.ROW) {
/* 154 */       super.setchkvalimpl(row, index, name, type, val, last, metas, (Comparable<?>[])datas);
/*     */       
/*     */       return;
/*     */     } 
/* 158 */     MCContainerMeta m = metas(row)[index];
/* 159 */     MCRow inner = m.castInnerRow(last);
/* 160 */     if (val != null) {
/* 161 */       MCRow value = m.castInnerRow(val);
/* 162 */       MCRow.copyvalue(inner, value);
/*     */     }
/*     */     else {
/*     */       
/* 166 */       inner.clear();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static boolean isEmpty(MCRow o) {
/* 172 */     return L.isEmpty(true, o, (metas(o)).length, metas(o), o._const_datas);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\MCConstColumnList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */