/*     */ package mcframe.commonCore.container;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MCRowList<E extends MCRow>
/*     */   implements Serializable
/*     */ {
/*     */   final MCList<E> _list;
/*     */   final Class<E> _rowclass;
/*     */   E[] _rows;
/*  50 */   int _size = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   private int _modcnt = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCRowList(MCList<E> list, Class<E> rowclass, int initCapacity) {
/*  69 */     this._list = list;
/*  70 */     this._rowclass = rowclass;
/*  71 */     this._rows = createRowArray(initCapacity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final E[] createRowArray(int size) {
/*  88 */     return (E[])Array.newInstance(this._rowclass, size);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void updateModcnt() {
/*  98 */     this._modcnt++;
/*  99 */     this._list.removeAllIndex();
/* 100 */     this._list.removeAllJoinKey();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void sortModcnt() {
/* 111 */     this._modcnt++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final int modcnt() {
/* 122 */     return this._modcnt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void ensureCapacity(int minCapacity) {
/* 135 */     int oldCapacity = this._rows.length;
/* 136 */     if (minCapacity > oldCapacity) {
/* 137 */       E[] arrayOfE = this._rows;
/* 138 */       int newCapacity = oldCapacity * 3 / 2 + 1;
/* 139 */       if (newCapacity < minCapacity) {
/* 140 */         newCapacity = minCapacity;
/*     */       }
/* 142 */       this._rows = createRowArray(newCapacity);
/* 143 */       System.arraycopy(arrayOfE, 0, this._rows, 0, this._size);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final int size() {
/* 155 */     return this._size;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void checkIndex(int index) {
/* 170 */     if (index < 0 || this._size <= index)
/*     */     {
/* 172 */       throw new MCException(Core_Msg_FW_A.FCBBC0033, new Object[] {
/* 173 */             this._list.msgBindClassName(), 
/* 174 */             String.valueOf(this._size), 
/* 175 */             String.valueOf(index)
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final E get(int index) {
/* 190 */     checkIndex(index);
/* 191 */     return this._rows[index];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final E[] getArray(int from, int to) {
/* 210 */     if (from >= to)
/*     */     {
/* 212 */       throw new MCException(Core_Msg_FW_A.FCBBC0034, new Object[] {
/* 213 */             this._list.msgBindClassName(), 
/* 214 */             String.valueOf(this._size), 
/* 215 */             String.valueOf(from), 
/* 216 */             String.valueOf(to)
/*     */           }); } 
/* 218 */     checkIndex(from);
/* 219 */     checkIndex(to - 1);
/*     */     
/* 221 */     int len = to - from;
/* 222 */     MCRow[] a = (MCRow[])createRowArray(len);
/* 223 */     System.arraycopy(this._rows, from, a, 0, len);
/* 224 */     return (E[])a;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void add(int index, E row) {
/* 239 */     if (row != null) {
/*     */       
/* 241 */       if (this._size != index) {
/* 242 */         checkIndex(index);
/*     */       }
/* 244 */       updateModcnt();
/*     */       
/* 246 */       ensureCapacity(this._size + 1);
/* 247 */       if (this._size != index) {
/* 248 */         System.arraycopy(this._rows, index, this._rows, index + 1, 
/* 249 */             this._size - index);
/*     */       }
/* 251 */       this._rows[index] = row;
/* 252 */       this._size++;
/*     */       
/* 254 */       this._list.fireRowAdded(row, index);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean addArray(int index, MCRow[] other, int otherlen) {
/* 273 */     boolean added = false;
/* 274 */     if (other != null && otherlen > 0) {
/*     */       
/* 276 */       if (this._size != index) {
/* 277 */         checkIndex(index);
/*     */       }
/* 279 */       updateModcnt();
/*     */       
/* 281 */       ensureCapacity(this._size + otherlen);
/*     */       
/* 283 */       int movelen = this._size - index;
/* 284 */       if (movelen > 0) {
/* 285 */         System.arraycopy(this._rows, index, this._rows, index + otherlen, movelen);
/*     */       }
/* 287 */       System.arraycopy(other, 0, this._rows, index, otherlen);
/* 288 */       this._size += otherlen;
/*     */       
/* 290 */       added = (otherlen != 0);
/* 291 */       if (added)
/*     */       {
/* 293 */         this._list.fireRowAddedAll((E)other[0], index, otherlen);
/*     */       }
/*     */     } 
/* 296 */     return added;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   E set(int index, E element) {
/* 310 */     checkIndex(index);
/* 311 */     updateModcnt();
/*     */     
/* 313 */     E oldrow = this._rows[index];
/* 314 */     this._rows[index] = element;
/*     */     
/* 316 */     this._list.fireRowSet(element, oldrow, index);
/* 317 */     return oldrow;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   E remove(int index) {
/* 346 */     return remove(index, index + 1)[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   E[] remove(int from, int to) {
/* 365 */     MCRow[] rems = (MCRow[])removeNoEvent(from, to);
/* 366 */     this._list.fireRowRemoved((E[])rems, from, rems.length);
/* 367 */     return (E[])rems;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   E[] removeNoEvent(int from, int to) {
/* 389 */     MCRow[] rems = (MCRow[])getArray(from, to);
/* 390 */     int count = rems.length;
/*     */     
/* 392 */     updateModcnt();
/*     */     
/* 394 */     int numMoved = this._size - to;
/* 395 */     if (numMoved > 0) {
/* 396 */       System.arraycopy(this._rows, to, this._rows, from, numMoved);
/*     */     }
/* 398 */     int lastsize = this._size;
/* 399 */     this._size -= count;
/* 400 */     for (int i = this._size; i < lastsize; i++) {
/* 401 */       this._rows[i] = null;
/*     */     }
/*     */     
/* 404 */     return (E[])rems;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void clear() {
/* 414 */     updateModcnt();
/*     */ 
/*     */     
/* 417 */     E[] arrayOfE = (this._size != 0) ? getArray(0, this._size) : null;
/* 418 */     int count = this._size;
/* 419 */     for (int i = 0; i < count; i++) {
/* 420 */       this._rows[i] = null;
/*     */     }
/* 422 */     this._size = 0;
/*     */     
/* 424 */     if (count > 0) {
/* 425 */       this._list.fireListCleared(arrayOfE, count);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void sort(int from, int to, Comparator... comps) {
/* 451 */     if (comps == null || comps.length <= 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 456 */     sortModcnt();
/*     */ 
/*     */     
/* 459 */     int size = comps.length;
/* 460 */     for (int i = size - 1; i >= 0; i--) {
/* 461 */       Comparator<? super E> comp = comps[i];
/* 462 */       Arrays.sort(this._rows, from, to, comp);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 479 */     int count = to - from;
/* 480 */     if (count > 0)
/*     */     {
/* 482 */       this._list.fireListSorted(from, count);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final E[] toArray() {
/* 495 */     MCRow[] a = (MCRow[])Array.newInstance(this._rowclass, this._size);
/* 496 */     System.arraycopy(this._rows, 0, a, 0, this._size);
/* 497 */     return (E[])a;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final <T> T[] toArray(Object[] a) {
/* 512 */     if (a.length < this._size)
/*     */     {
/* 514 */       a = (Object[])Array.newInstance(a.getClass().getComponentType(), 
/* 515 */           this._size);
/*     */     }
/* 517 */     System.arraycopy(this._rows, 0, a, 0, this._size);
/* 518 */     if (a.length > this._size) {
/* 519 */       a[this._size] = null;
/*     */     }
/* 521 */     return (T[])a;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\MCRowList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */