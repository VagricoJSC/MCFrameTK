package mcframe.commonCore.container;

public interface MCRowMatcher<T extends MCRow> {
  boolean match(T paramT);
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\MCRowMatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */