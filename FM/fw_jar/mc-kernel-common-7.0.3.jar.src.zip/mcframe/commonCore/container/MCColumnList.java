/*     */ package mcframe.commonCore.container;
/*     */ 
/*     */ import mcframe.commonCore.lang.MCDataType;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class MCColumnList
/*     */ {
/*  37 */   static final Comparable<?> INIT_COLUMN_VAL = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  44 */   static final Boolean INIT_BOOLEAN_VAL = Boolean.FALSE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final int INIT_PARAM_COL_INDEX = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract boolean isConst();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract int size();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract MCRow row();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract MCContainerMeta[] metas();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract Comparable<?>[] datas();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   abstract int[] paramColIndex();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean checkIndex(int i, int s) {
/* 117 */     return (i >= 0 && i < s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean contains(String name) {
/* 129 */     return (indexOf(name) >= 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean contains(MCContainerMeta meta) {
/* 143 */     return (indexOf(meta) >= 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final int indexOf(String name) {
/* 157 */     return indexOf(name, size(), metas());
/*     */   }
/*     */   
/*     */   final int indexOf(String n, int s, MCContainerMeta[] ms) {
/* 161 */     if (n == null) {
/* 162 */       return -1;
/*     */     }
/* 164 */     for (int i = 0; i < s; i++) {
/*     */       
/* 166 */       if (n.equalsIgnoreCase(ms[i].name())) {
/* 167 */         return i;
/*     */       }
/*     */     } 
/* 170 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final int indexOf(MCContainerMeta meta) {
/* 184 */     return indexOf(size(), meta, metas());
/*     */   }
/*     */   
/*     */   final int indexOf(int s, MCContainerMeta m, MCContainerMeta[] ms) {
/* 188 */     if (m == null) {
/* 189 */       return -1;
/*     */     }
/* 191 */     for (int i = 0; i < s; i++) {
/* 192 */       if (m == ms[i]) {
/* 193 */         return i;
/*     */       }
/*     */     } 
/* 196 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final String[] getNameArray() {
/* 207 */     return getNameArray(size(), metas());
/*     */   }
/*     */ 
/*     */   
/*     */   final String[] getNameArray(int s, MCContainerMeta[] ms) {
/* 212 */     String[] a = new String[s];
/* 213 */     for (int i = 0; i < s; i++) {
/* 214 */       a[i] = ms[i].name();
/*     */     }
/* 216 */     return a;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final MCContainerMeta[] getMetaArray() {
/* 227 */     int s = size();
/* 228 */     MCContainerMeta[] metaarray = new MCContainerMeta[s];
/* 229 */     System.arraycopy(metas(), 0, metaarray, 0, s);
/* 230 */     return metaarray;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final MCContainerMeta meta(int index) {
/* 243 */     return meta(row(), index, size(), metas());
/*     */   }
/*     */   
/*     */   final MCContainerMeta meta(MCRow o, int i, int s, MCContainerMeta[] ms) {
/* 247 */     return checkIndex(i, s) ? ms[i] : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final MCContainerMeta meta(String name) {
/* 259 */     return meta(size(), name, metas());
/*     */   }
/*     */   
/*     */   final MCContainerMeta meta(int s, String n, MCContainerMeta[] ms) {
/* 263 */     int p = indexOf(n, s, ms);
/* 264 */     return (p >= 0) ? ms[p] : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final int paramColIndex(int index) {
/* 277 */     return paramColIndex(row(), index, size(), paramColIndex());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final int paramColIndex(MCRow o, int i, int s, int[] pi) {
/* 293 */     return (pi != null && checkIndex(i, s)) ? pi[i] : -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final int paramColIndex(String name) {
/* 305 */     return paramColIndex(name, paramColIndex());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final int paramColIndex(String n, int[] pi) {
/* 318 */     if (pi == null) {
/* 319 */       return -1;
/*     */     }
/* 321 */     int p = indexOf(n);
/* 322 */     return (p >= 0) ? pi[p] : -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int setParamColIndex(int i, int v) {
/* 335 */     return setParamColIndex(i, meta(i).type(), paramColIndex(), v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int setParamColIndex(int i, MCDataType y, int[] pi, int v) {
/* 350 */     if (y == MCDataType.ROW || pi == null) {
/* 351 */       return -1;
/*     */     }
/* 353 */     int oldindex = pi[i];
/* 354 */     pi[i] = v;
/* 355 */     return oldindex;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final Comparable<?> get(MCContainerMeta meta) {
/* 369 */     return get(isConst(), row(), size(), meta, metas(), datas());
/*     */   }
/*     */ 
/*     */   
/*     */   final Comparable<?> get(boolean c, MCRow o, int s, MCContainerMeta m, MCContainerMeta[] ms, Comparable[] ds) {
/* 374 */     int p = indexOf(s, m, ms);
/* 375 */     return get(c, o, p, (Comparable<?>[])ds);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Comparable<?> get(int index) {
/* 392 */     return get(isConst(), row(), index, datas());
/*     */   }
/*     */   
/*     */   Comparable<?> get(boolean c, MCRow o, int i, Comparable[] ds) {
/*     */     try {
/* 397 */       return ds[i];
/*     */     }
/* 399 */     catch (IndexOutOfBoundsException ex) {
/*     */       
/* 401 */       throw new MCException(ex, c ? Core_Msg_FW_A.FCBBC0015 : Core_Msg_FW_A.FCBBC0017, new Object[] { o.msgBindClassName(), 
/* 402 */             String.valueOf(ds.length), String.valueOf(i) });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Comparable<?> getchkval(int index, MCDataType type) {
/* 422 */     return getchkval(isConst(), row(), index, type, datas());
/*     */   }
/*     */ 
/*     */   
/*     */   Comparable<?> getchkval(boolean c, MCRow o, int i, MCDataType y, Comparable[] ds) {
/* 427 */     Comparable<?> v = get(c, o, i, (Comparable<?>[])ds);
/* 428 */     return getchkvalimpl(o, i, y, v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Comparable<?> getchkvalimpl(MCRow row, int index, MCDataType type, Comparable<?> val) {
/* 447 */     return type.cast(val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Comparable<?> set(int index, String name, Comparable<?> value) {
/* 470 */     return set(isConst(), row(), index, name, value, datas());
/*     */   }
/*     */ 
/*     */   
/*     */   Comparable<?> set(boolean c, MCRow o, int i, String n, Comparable<?> v, Comparable[] ds) {
/* 475 */     Comparable<?> ov = null;
/*     */     try {
/* 477 */       ov = ds[i];
/* 478 */       ds[i] = v;
/*     */     }
/* 480 */     catch (IndexOutOfBoundsException ex) {
/*     */ 
/*     */ 
/*     */       
/* 484 */       MCException e = new MCException(ex, c ? Core_Msg_FW_A.FCBBC0016 : Core_Msg_FW_A.FCBBC0018, new Object[] {
/* 485 */             o.msgBindClassName(), String.valueOf(ds.length), String.valueOf(i)
/*     */           });
/* 487 */       throw new MCException(e, c ? Core_Msg_FW_A.FCBBC0021 : Core_Msg_FW_A.FCBBC0022, new Object[] { o.msgBindClassName(), n });
/*     */     } 
/*     */ 
/*     */     
/* 491 */     o.fireValueChanged(n, v, ov);
/* 492 */     return ov;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Comparable<?> setchkval(int index, String name, Comparable<?> val) {
/* 518 */     Comparable<?> last = null;
/*     */     try {
/* 520 */       last = get(index);
/* 521 */       MCDataType type = metas()[index].type();
/* 522 */       setchkvalimpl(row(), index, name, type, val, last, metas(), datas());
/*     */     }
/* 524 */     catch (Exception ex) {
/* 525 */       throw new MCException(ex, isConst() ? Core_Msg_FW_A.FCBBC0021 : Core_Msg_FW_A.FCBBC0022, new Object[] {
/* 526 */             row().msgBindClassName(), name
/*     */           });
/*     */     } 
/*     */     
/* 530 */     row().fireValueChanged(name, val, last);
/* 531 */     return last;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Comparable<?> setchkval(int index, String name, MCDataType type, Comparable<?> val) {
/* 555 */     return setchkval(isConst(), row(), index, name, type, val, metas(), datas());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Comparable<?> setchkval(boolean c, MCRow o, int i, String n, MCDataType y, Comparable<?> v, MCContainerMeta[] ms, Comparable[] ds) {
/*     */     Comparable<?> ov;
/*     */     try {
/* 564 */       ov = get(c, o, i, (Comparable<?>[])ds);
/* 565 */       setchkvalimpl(o, i, n, y, v, ov, ms, (Comparable<?>[])ds);
/*     */     }
/* 567 */     catch (Exception ex) {
/* 568 */       throw new MCException(ex, c ? Core_Msg_FW_A.FCBBC0021 : Core_Msg_FW_A.FCBBC0022, new Object[] { o.msgBindClassName(), n });
/*     */     } 
/*     */     
/* 571 */     o.fireValueChanged(n, v, ov);
/* 572 */     return ov;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setchkvalimpl(MCRow row, int index, String name, MCDataType type, Comparable<?> val, Comparable<?> last, MCContainerMeta[] metas, Comparable[] datas) {
/* 596 */     setchkvalimpl(index, type, metas[index], val, (Comparable<?>[])datas);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void setchkvalimpl(int i, MCDataType y, MCContainerMeta m, Comparable<?> v, Comparable[] ds) {
/* 602 */     if (m.type() != y) {
/* 603 */       throw new MCException(Core_Msg_FW_A.FCBFC0020, new Object[] { y.name(), m.type().name() });
/*     */     }
/* 605 */     ds[i] = y.cast(v);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setRange(int pos, MCColumnList src, int srcpos, int len) {
/* 631 */     setRange(row(), pos, srcpos, len, metas(), datas(), src.datas());
/*     */   }
/*     */ 
/*     */   
/*     */   void setRange(MCRow o, int pos, int srcpos, int len, MCContainerMeta[] ms, Comparable[] dds, Comparable[] sds) {
/*     */     try {
/* 637 */       Comparable[] lastdatas = new Comparable[len];
/* 638 */       System.arraycopy(dds, pos, lastdatas, 0, len);
/* 639 */       System.arraycopy(sds, srcpos, dds, pos, len);
/* 640 */       for (int i = 0; i < len; i++) {
/* 641 */         afterSetRange(o, pos, i, ms, (Comparable<?>[])dds, (Comparable<?>[])lastdatas);
/*     */       }
/*     */     }
/* 644 */     catch (Exception ex) {
/*     */       
/* 646 */       throw new MCException(ex, Core_Msg_FW_A.FCBBC0070, new Object[] { o.msgBindClassName() });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void afterSetRange(MCRow o, int pos, int cnt, MCContainerMeta[] ms, Comparable[] ds, Comparable[] lds) {
/* 670 */     o.fireValueChanged(ms[pos + cnt].name(), ds[pos + cnt], lds[cnt]);
/*     */   }
/*     */   
/*     */   void setParamColIndex(int pos, MCColumnList src, int srcpos, int len) {
/* 674 */     setParamColIndex(row(), pos, srcpos, len, metas(), paramColIndex(), 
/* 675 */         src.paramColIndex());
/*     */   }
/*     */ 
/*     */   
/*     */   void setParamColIndex(MCRow o, int pos, int srcpos, int len, MCContainerMeta[] ms, int[] dds, int[] sds) {
/*     */     try {
/* 681 */       int[] lastdatas = new int[len];
/* 682 */       System.arraycopy(dds, pos, lastdatas, 0, len);
/* 683 */       System.arraycopy(sds, srcpos, dds, pos, len);
/*     */     }
/* 685 */     catch (Exception ex) {
/*     */       
/* 687 */       throw new MCException(ex, Core_Msg_FW_A.FCBBC0070, new Object[] { o.msgBindClassName() });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void init(String name) {
/* 706 */     int index = indexOf(name);
/* 707 */     init(index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void init(int index) {
/* 724 */     init(isConst(), row(), index, meta(index), datas());
/*     */   }
/*     */   
/*     */   void init(boolean c, MCRow o, int i, MCContainerMeta m, Comparable[] ds) {
/* 728 */     if (m == null)
/*     */     {
/* 730 */       throw new MCException(c ? Core_Msg_FW_A.FCBBC0016 : Core_Msg_FW_A.FCBBC0018, new Object[] { o.msgBindClassName(), 
/* 731 */             String.valueOf(ds.length), String.valueOf(i) });
/*     */     }
/* 733 */     MCDataType y = m.type();
/* 734 */     if (y == MCDataType.ROW) {
/* 735 */       MCRow io = (MCRow)ds[i];
/* 736 */       if (io == null) {
/* 737 */         io = o.createInnerRow(m);
/* 738 */         ds[i] = io;
/*     */       } else {
/*     */         
/* 741 */         io.init();
/*     */       } 
/*     */     } else {
/*     */       
/* 745 */       Comparable<?> ov = ds[i];
/* 746 */       ds[i] = (y == MCDataType.BOOLEAN) ? INIT_BOOLEAN_VAL : INIT_COLUMN_VAL;
/* 747 */       o.fireValueChanged(m.name(), ds[i], ov);
/*     */     } 
/*     */   }
/*     */   
/*     */   void init(int i, int[] pi) {
/* 752 */     pi[i] = -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void clear(String name) {
/* 768 */     int pos = indexOf(name);
/* 769 */     clear(pos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void clear(int index) {
/* 785 */     clear(isConst(), row(), index, meta(index), datas());
/*     */   }
/*     */   
/*     */   void clear(boolean c, MCRow o, int i, MCContainerMeta m, Comparable[] ds) {
/* 789 */     if (m == null)
/*     */     {
/* 791 */       throw new MCException(c ? Core_Msg_FW_A.FCBBC0016 : Core_Msg_FW_A.FCBBC0018, new Object[] { o.msgBindClassName(), 
/* 792 */             String.valueOf(ds.length), String.valueOf(i) });
/*     */     }
/* 794 */     if (m.type() == MCDataType.ROW) {
/* 795 */       MCRow io = (MCRow)ds[i];
/* 796 */       if (io == null) {
/* 797 */         io = o.createInnerRow(m);
/* 798 */         ds[i] = io;
/*     */       } 
/* 800 */       io.clear();
/*     */     } else {
/*     */       
/* 803 */       Comparable<?> ov = ds[i];
/* 804 */       ds[i] = (m.type() == MCDataType.BOOLEAN) ? INIT_BOOLEAN_VAL : INIT_COLUMN_VAL;
/* 805 */       o.fireValueChanged(m.name(), ds[i], ov);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 822 */     StringBuilder sb = new StringBuilder();
/* 823 */     MCContainerMeta[] a = metas();
/* 824 */     for (int i = 0; i < size(); i++) {
/* 825 */       sb.append(" [");
/* 826 */       sb.append(i);
/* 827 */       sb.append(" (");
/* 828 */       sb.append(a[i].type().toString().charAt(0));
/* 829 */       sb.append(") ");
/* 830 */       sb.append(a[i].name());
/* 831 */       sb.append("] ");
/* 832 */       sb.append((datas()[i] != null) ? datas()[i] : "");
/* 833 */       sb.append("\n");
/*     */     } 
/* 835 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isEmpty() {
/* 854 */     return isEmpty(isConst(), row(), size(), metas(), datas());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isEmpty(boolean c, MCRow o, int size, MCContainerMeta[] ms, Comparable[] ds) {
/* 860 */     boolean result = true;
/* 861 */     for (int i = 0; i < size && result; i++) {
/* 862 */       Comparable<?> v = get(c, o, i, (Comparable<?>[])ds);
/* 863 */       if (ms[i].type() == MCDataType.ROW) {
/* 864 */         result = ((MCRow)v).isEmpty();
/*     */       }
/* 866 */       else if (ms[i].type() != MCDataType.BOOLEAN) {
/* 867 */         result = (v == INIT_COLUMN_VAL);
/*     */       } else {
/*     */         
/* 870 */         result = (v == INIT_BOOLEAN_VAL);
/*     */       } 
/*     */     } 
/* 873 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\MCColumnList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */