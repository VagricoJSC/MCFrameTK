/*     */ package mcframe.commonCore.container;
/*     */ 
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCSortPolicy
/*     */   implements Cloneable
/*     */ {
/*     */   private static final int _amount = 10;
/*  36 */   private MCList.SortType[] _types = new MCList.SortType[10];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  44 */   private String[] _names = new String[10];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   private int _size = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCSortPolicy(MCList.SortType type, String name) {
/*  74 */     this();
/*  75 */     add(type, name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void ensureCapacity() {
/*  85 */     int buflen = this._types.length;
/*  86 */     if (this._size == buflen) {
/*  87 */       buflen += 10;
/*  88 */       MCList.SortType[] typeNew = new MCList.SortType[buflen];
/*  89 */       System.arraycopy(this._types, 0, typeNew, 0, this._size);
/*  90 */       this._types = typeNew;
/*  91 */       String[] nameNew = new String[buflen];
/*  92 */       System.arraycopy(this._names, 0, nameNew, 0, this._size);
/*  93 */       this._names = nameNew;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkIndex(int index) {
/* 106 */     if (index < 0 && this._size <= index)
/*     */     {
/* 108 */       throw new MCException(Core_Msg_FW_A.FCBBC0075, new Object[] {
/* 109 */             String.valueOf(this._size), String.valueOf(index)
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(MCList.SortType type, String name) {
/* 125 */     if (type == null) {
/*     */       return;
/*     */     }
/*     */     
/* 129 */     ensureCapacity();
/* 130 */     this._types[this._size] = type;
/* 131 */     this._names[this._size] = name;
/* 132 */     this._size++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void set(int index, MCList.SortType type, String name) {
/* 149 */     checkIndex(index);
/*     */     
/* 151 */     this._types[index] = type;
/* 152 */     this._names[index] = name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(int index, MCList.SortType type, String name) {
/* 166 */     checkIndex(index);
/*     */     
/* 168 */     int len = this._size - index - 1;
/* 169 */     System.arraycopy(this._types, index + 1, this._types, index, len);
/* 170 */     System.arraycopy(this._names, index + 1, this._names, index, len);
/* 171 */     this._size--;
/* 172 */     this._types[this._size] = null;
/* 173 */     this._names[this._size] = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCList.SortType type(int index) {
/* 186 */     checkIndex(index);
/*     */     
/* 188 */     return this._types[index];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String name(int index) {
/* 201 */     checkIndex(index);
/*     */     
/* 203 */     return this._names[index];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCList.SortType[] typeArray() {
/* 217 */     MCList.SortType[] a = new MCList.SortType[this._size];
/* 218 */     System.arraycopy(this._types, 0, a, 0, this._size);
/* 219 */     return a;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] nameArray() {
/* 233 */     String[] a = new String[this._size];
/* 234 */     System.arraycopy(this._names, 0, a, 0, this._size);
/* 235 */     return a;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCSortPolicy clone() {
/* 240 */     MCSortPolicy p = new MCSortPolicy();
/* 241 */     int len = this._types.length;
/* 242 */     p._types = new MCList.SortType[len];
/* 243 */     p._names = new String[len];
/* 244 */     System.arraycopy(this._types, 0, p._types, 0, len);
/* 245 */     System.arraycopy(this._names, 0, p._names, 0, len);
/* 246 */     p._size = this._size;
/* 247 */     return p;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int size() {
/* 258 */     return this._size;
/*     */   }
/*     */   
/*     */   public MCSortPolicy() {}
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\MCSortPolicy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */