package mcframe.commonCore.container;

import mcframe.commonCore.notice.MCMessage;

public interface MCContainerSignalHandler {
  boolean isInterrupted();
  
  void resume();
  
  MCMessage getInterruptedMessage();
  
  MCMessage getInterruptedMessage4GUI();
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\container\MCContainerSignalHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */