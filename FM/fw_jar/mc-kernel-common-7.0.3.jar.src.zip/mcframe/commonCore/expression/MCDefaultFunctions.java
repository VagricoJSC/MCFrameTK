/*    */ package mcframe.commonCore.expression;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ import mcframe.commonCore.expression.exp4j.ArgContainer;
/*    */ import mcframe.commonCore.expression.exp4j.ExpressionBuilder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MCDefaultFunctions
/*    */   implements MCExpressionFunctions
/*    */ {
/* 34 */   public final MCFunction nvl = nvlFunction();
/* 35 */   public final MCFunction coalesce = coalesceFunction();
/*    */ 
/*    */ 
/*    */   
/*    */   public void setTo(ExpressionBuilder eb) {
/* 40 */     eb.function(this.nvl);
/*    */   }
/*    */ 
/*    */   
/*    */   public MCFunction[] toArray() {
/* 45 */     return new MCFunction[] {
/* 46 */         this.nvl
/*    */       };
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected MCFunction nvlFunction() {
/* 56 */     return new MCFunction("_nvl", 2, true) { public ArgContainer apply(ArgContainer... args) { byte b;
/*    */           int i;
/*    */           ArgContainer[] arrayOfArgContainer;
/* 59 */           for (i = (arrayOfArgContainer = args).length, b = 0; b < i; ) { ArgContainer arg = arrayOfArgContainer[b];
/* 60 */             BigDecimal val = arg.getValue();
/* 61 */             if (val != null)
/* 62 */               return arg; 
/*    */             b++; }
/*    */           
/* 65 */           return null; }
/*    */          }
/*    */       ;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected MCFunction coalesceFunction() {
/* 75 */     return new MCFunction("_coalesce", 2) { public ArgContainer apply(ArgContainer... args) { byte b;
/*    */           int i;
/*    */           ArgContainer[] arrayOfArgContainer;
/* 78 */           for (i = (arrayOfArgContainer = args).length, b = 0; b < i; ) { ArgContainer arg = arrayOfArgContainer[b];
/* 79 */             BigDecimal val = arg.getValue();
/* 80 */             if (val != null)
/* 81 */               return arg; 
/*    */             b++; }
/*    */           
/* 84 */           return null; }
/*    */          }
/*    */       ;
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\expression\MCDefaultFunctions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */