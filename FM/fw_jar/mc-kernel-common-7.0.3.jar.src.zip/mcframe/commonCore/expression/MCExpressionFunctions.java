package mcframe.commonCore.expression;

import mcframe.commonCore.expression.exp4j.ExpressionBuilder;

public interface MCExpressionFunctions {
  void setTo(ExpressionBuilder paramExpressionBuilder);
  
  MCFunction[] toArray();
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\expression\MCExpressionFunctions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */