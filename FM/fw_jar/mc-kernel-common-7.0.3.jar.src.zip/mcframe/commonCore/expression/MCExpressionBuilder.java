/*     */ package mcframe.commonCore.expression;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.RoundingMode;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import mcframe.commonCore.container.MCContainer;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.expression.exp4j.ArgContainer;
/*     */ import mcframe.commonCore.expression.exp4j.Expression;
/*     */ import mcframe.commonCore.expression.exp4j.ExpressionBuilder;
/*     */ import mcframe.commonCore.expression.exp4j.function.Function;
/*     */ import mcframe.commonCore.expression.exp4j.operator.Operator;
/*     */ import mcframe.commonCore.expression.exp4j.tokenizer.Token;
/*     */ import mcframe.commonCore.expression.exp4j.tokenizer.VariableToken;
/*     */ import mcframe.commonCore.lang.MCDataType;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCExpressionBuilder
/*     */ {
/*  43 */   private MCNumber _resultNull = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   private final Set<Function> _funcSet = new HashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  57 */   private final List<MCExpressionFunctions> _efList = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   private RoundingMode _roundMode = RoundingMode.HALF_UP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   private MCNumber _scale = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCExpressionBuilder(MCExpressionFunctions... efs) {
/*  84 */     addFunctions(new MCDefaultFunctions()); byte b; int i; MCExpressionFunctions[] arrayOfMCExpressionFunctions;
/*  85 */     for (i = (arrayOfMCExpressionFunctions = efs).length, b = 0; b < i; ) { MCExpressionFunctions ef = arrayOfMCExpressionFunctions[b];
/*  86 */       addFunctions(ef);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addFunctions(MCExpressionFunctions ef) {
/*  99 */     MCFunction[] arrayOfMCFunction1 = ef.toArray();
/* 100 */     Set<Function> tempSet = new HashSet<>(this._funcSet); byte b; int i; MCFunction[] arrayOfMCFunction2;
/* 101 */     for (i = (arrayOfMCFunction2 = arrayOfMCFunction1).length, b = 0; b < i; ) { Function func = arrayOfMCFunction2[b];
/* 102 */       if (!tempSet.add(func))
/*     */       {
/* 104 */         throw new MCException(Core_Msg_FW_A.FCBEC0061, new Object[] { func.getName() }); } 
/*     */       b++; }
/*     */     
/* 107 */     this._funcSet.addAll(tempSet);
/* 108 */     this._efList.add(ef);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDivideRoundMode(RoundingMode mode) {
/* 121 */     if (mode != null) {
/* 122 */       this._roundMode = mode;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDivideScale(int scale) {
/* 134 */     this._scale = MCNumber.valueOf(scale);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Expression createExpression(String formula, Set<String> varSet) {
/* 148 */     if (formula == null || formula.length() <= 0)
/*     */     {
/* 150 */       return null;
/*     */     }
/*     */     try {
/* 153 */       ExpressionBuilder core = new ExpressionBuilder(formula);
/*     */       
/* 155 */       this._funcSet.forEach(f -> paramExpressionBuilder.function(f));
/*     */ 
/*     */ 
/*     */       
/* 159 */       Operator divide = new Operator("/", 2, true, 1000)
/*     */         {
/*     */           public ArgContainer apply(ArgContainer... args)
/*     */           {
/* 163 */             if (MCExpressionBuilder.this._scale != null) {  } else {  }  return 
/*     */ 
/*     */               
/* 166 */               new ArgContainer(args[0].getValue().divide(
/* 167 */                   args[1].getValue(), MCExpressionBuilder.this._roundMode));
/*     */           }
/*     */         };
/*     */       
/* 171 */       core.operator(divide);
/*     */       
/* 173 */       core.variables(varSet);
/* 174 */       return core.build();
/*     */     }
/* 176 */     catch (Exception e) {
/*     */       
/* 178 */       throw new MCException(e, Core_Msg_FW_A.FCBEC0059, new Object[] { formula });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean substitute(Expression exp, Set<String> varSet, MCRow row) {
/* 193 */     boolean nonNull = true;
/* 194 */     for (String v : varSet) {
/*     */       
/* 196 */       MCNumber val = row.getNumber(v);
/* 197 */       if (val == null) {
/* 198 */         nonNull = false;
/*     */       }
/* 200 */       exp.setVariable(v, (BigDecimal)val);
/*     */     } 
/* 202 */     return nonNull;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Set<String> getAvailableColSet(MCContainer cont) {
/* 217 */     Set<String> varSet = new HashSet<>(); byte b; int i; String[] arrayOfString;
/* 218 */     for (i = (arrayOfString = cont.getColumnPathArray()).length, b = 0; b < i; ) { String n = arrayOfString[b];
/*     */       
/* 220 */       MCMeta c = cont.getMeta(n);
/* 221 */       if (c.type() == MCDataType.NUMBER)
/* 222 */         varSet.add(n); 
/*     */       b++; }
/*     */     
/* 225 */     return varSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCNumber evaluate(String formula, MCRow row) {
/* 244 */     Set<String> varSet = getAvailableColSet((MCContainer)row);
/* 245 */     return evaluate(formula, row, varSet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCNumber evaluate(String formula, MCRow row, Set<String> varSet) {
/* 264 */     Expression exp = createExpression(formula, varSet);
/* 265 */     if (exp == null)
/*     */     {
/* 267 */       return this._resultNull;
/*     */     }
/*     */ 
/*     */     
/* 271 */     substitute(exp, varSet, row);
/*     */     
/*     */     try {
/* 274 */       return MCNumber.valueOf(exp.evaluate());
/*     */     }
/* 276 */     catch (Exception e) {
/*     */       
/* 278 */       throw new MCException(e, Core_Msg_FW_A.FCBEC0060, new Object[] { formula });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void evaluate(String formula, String resultColumn, MCList<? extends MCRow> list) {
/* 303 */     Set<String> varSet = getAvailableColSet((MCContainer)list);
/* 304 */     evaluate(formula, resultColumn, list, varSet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void evaluate(String formula, String resultColumn, MCList<? extends MCRow> list, Set<String> varSet) {
/* 332 */     Expression exp = createExpression(formula, varSet);
/* 333 */     if (exp == null) {
/*     */       
/* 335 */       list.setNumberNE(resultColumn, this._resultNull);
/*     */       
/*     */       return;
/*     */     } 
/* 339 */     for (int i = 0; i < list.size(); i++) {
/* 340 */       MCRow row = list.get(i);
/*     */ 
/*     */       
/* 343 */       substitute(exp, varSet, row);
/*     */       
/*     */       try {
/* 346 */         MCNumber result = MCNumber.valueOf(exp.evaluate());
/* 347 */         row.setNumberNE(resultColumn, result);
/*     */       }
/* 349 */       catch (Exception e) {
/* 350 */         throw new MCException(e, Core_Msg_FW_A.FCBEC0060, new Object[] { String.valueOf(formula) + " (row no." + i + ")" });
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String convertVariables(String formula, List<String> fromList, List<String> toList) {
/* 375 */     Set<String> fromSet = new HashSet<>(fromList);
/* 376 */     return convertVariables(formula, fromSet, fromList, toList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String convertVariables(String formula, Set<String> fromSet, List<String> fromList, List<String> toList) {
/* 397 */     Expression exp = createExpression(formula, fromSet);
/* 398 */     if (exp == null) {
/* 399 */       return formula;
/*     */     }
/*     */     
/* 402 */     List<VariableToken> vList = new ArrayList<>(); byte b; int i; Token[] arrayOfToken;
/* 403 */     for (i = (arrayOfToken = exp.getTokens()).length, b = 0; b < i; ) { Token t = arrayOfToken[b];
/* 404 */       if (t instanceof VariableToken) {
/* 405 */         vList.add((VariableToken)t);
/*     */       }
/*     */       
/*     */       b++; }
/*     */     
/* 410 */     Collections.sort(vList, new VariableTokenComparator());
/*     */     
/* 412 */     String result = new String(formula);
/*     */     
/* 414 */     for (Token t : vList) {
/* 415 */       String str = formula.substring(t.offset, t.offset + t.length);
/* 416 */       String str1 = result.substring(0, t.offset);
/* 417 */       String str2 = result.substring(t.offset + t.length, result.length());
/*     */       
/* 419 */       int idx = 0;
/* 420 */       for (String s : fromList) {
/* 421 */         if (s.equals(str)) {
/*     */           break;
/*     */         }
/* 424 */         idx++;
/*     */       } 
/* 426 */       if (idx < toList.size()) {
/* 427 */         result = String.valueOf(str1) + (String)toList.get(idx) + str2;
/*     */       }
/*     */     } 
/* 430 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getVariableList(String formula, MCContainer cont) {
/* 444 */     Set<String> varSet = getAvailableColSet(cont);
/* 445 */     return getVariableList(formula, varSet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getVariableList(String formula, Set<String> varSet) {
/* 459 */     List<String> list = new ArrayList<>();
/*     */     
/* 461 */     Expression exp = createExpression(formula, varSet);
/* 462 */     if (exp == null) {
/* 463 */       return list;
/*     */     }
/*     */     
/* 466 */     List<VariableToken> vList = new ArrayList<>(); byte b; int i; Token[] arrayOfToken;
/* 467 */     for (i = (arrayOfToken = exp.getTokens()).length, b = 0; b < i; ) { Token t = arrayOfToken[b];
/* 468 */       if (t instanceof VariableToken) {
/* 469 */         vList.add((VariableToken)t);
/*     */       }
/*     */       
/*     */       b++; }
/*     */     
/* 474 */     Collections.sort(vList, new VariableTokenComparator());
/*     */     
/* 476 */     for (Token t : vList) {
/* 477 */       String id = formula.substring(t.offset, t.offset + t.length);
/* 478 */       list.add(id);
/*     */     } 
/* 480 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected class VariableTokenComparator
/*     */     implements Comparator<VariableToken>
/*     */   {
/*     */     public int compare(VariableToken a, VariableToken b) {
/* 491 */       if (a.offset < b.offset) {
/* 492 */         return 1;
/*     */       }
/* 494 */       if (a.offset == b.offset) {
/* 495 */         return 0;
/*     */       }
/*     */       
/* 498 */       return -1;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\expression\MCExpressionBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */