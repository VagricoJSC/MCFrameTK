/*     */ package mcframe.commonCore.expression;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.expression.exp4j.ArgContainer;
/*     */ import mcframe.commonCore.expression.exp4j.ExpressionBuilder;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCAggregateFunctions
/*     */   implements MCExpressionFunctions
/*     */ {
/*     */   private final MCList<?> mclist;
/*     */   public final MCFunction sum;
/*     */   public final MCFunction avg;
/*     */   public final MCFunction max;
/*     */   public final MCFunction min;
/*     */   public final MCFunction count;
/*     */   
/*     */   public MCAggregateFunctions(MCList<?> mclist) {
/*  54 */     this.mclist = (mclist != null) ? mclist.shallowClone() : null;
/*     */ 
/*     */     
/*  57 */     this.sum = sumFunction();
/*  58 */     this.avg = avgFunction();
/*  59 */     this.max = maxFunction();
/*  60 */     this.min = minFunction();
/*  61 */     this.count = countFunction();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTo(ExpressionBuilder eb) {
/*  66 */     eb.function(this.sum);
/*  67 */     eb.function(this.avg);
/*  68 */     eb.function(this.max);
/*  69 */     eb.function(this.min);
/*  70 */     eb.function(this.count);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCFunction[] toArray() {
/*  75 */     return new MCFunction[] { this.sum, this.avg, this.max, this.min, this.count };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCFunction sumFunction() {
/*  85 */     return new MCFunction("_sum", 1)
/*     */       {
/*     */         public ArgContainer apply(ArgContainer... args) {
/*  88 */           MCNumber num = MCAggregateFunctions.this.mclist.sum(args[0].getName());
/*  89 */           return (num != null) ? new ArgContainer((BigDecimal)num) : null;
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCFunction avgFunction() {
/* 100 */     return new MCFunction("_avg", 1)
/*     */       {
/*     */         public ArgContainer apply(ArgContainer... args) {
/* 103 */           MCNumber num = MCAggregateFunctions.this.mclist.avg(args[0].getName());
/* 104 */           return (num != null) ? new ArgContainer((BigDecimal)num) : null;
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCFunction maxFunction() {
/* 115 */     return new MCFunction("_max", 1) {
/*     */         public ArgContainer apply(ArgContainer... args) {
/* 117 */           MCNumber num = (MCNumber)MCAggregateFunctions.this.mclist.max(args[0].getName());
/* 118 */           return (num != null) ? new ArgContainer((BigDecimal)num) : null;
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCFunction minFunction() {
/* 129 */     return new MCFunction("_min", 1)
/*     */       {
/*     */         public ArgContainer apply(ArgContainer... args) {
/* 132 */           MCNumber num = (MCNumber)MCAggregateFunctions.this.mclist.min(args[0].getName());
/* 133 */           return (num != null) ? new ArgContainer((BigDecimal)num) : null;
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCFunction countFunction() {
/* 144 */     return new MCFunction("_count", 1)
/*     */       {
/*     */         public ArgContainer apply(ArgContainer... args) {
/* 147 */           MCNumber num = MCNumber.valueOf(MCAggregateFunctions.this.mclist.count(args[0].getName()));
/* 148 */           return new ArgContainer((BigDecimal)num);
/*     */         }
/*     */       };
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\expression\MCAggregateFunctions.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */