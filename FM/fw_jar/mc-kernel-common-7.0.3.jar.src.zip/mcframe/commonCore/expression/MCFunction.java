/*    */ package mcframe.commonCore.expression;
/*    */ 
/*    */ import mcframe.commonCore.expression.exp4j.function.Function;
/*    */ 
/*    */ public abstract class MCFunction
/*    */   extends Function
/*    */ {
/*    */   public MCFunction(String name, int numArguments, boolean nullable) {
/*  9 */     super(name, numArguments, nullable);
/*    */   }
/*    */   
/*    */   public MCFunction(String name, int numArguments) {
/* 13 */     super(name, numArguments);
/*    */   }
/*    */   
/*    */   public MCFunction(String name) {
/* 17 */     super(name);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 24 */     return getName().hashCode();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object obj) {
/* 29 */     if (this == obj) {
/* 30 */       return true;
/*    */     }
/* 32 */     if (!(obj instanceof Function)) {
/* 33 */       return false;
/*    */     }
/* 35 */     Function f = (Function)obj;
/* 36 */     return (getName().equals(f.getName()) && getNumArguments() == f.getNumArguments());
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\expression\MCFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */