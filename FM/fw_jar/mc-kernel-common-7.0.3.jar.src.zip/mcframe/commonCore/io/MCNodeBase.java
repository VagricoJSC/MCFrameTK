/*    */ package mcframe.commonCore.io;
/*    */ 
/*    */ import java.text.DecimalFormat;
/*    */ import java.util.regex.Pattern;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class MCNodeBase
/*    */   implements MCNode
/*    */ {
/*    */   protected MCNode _root;
/*    */   protected String _key;
/*    */   protected String _file;
/*    */   protected String _separator;
/*    */   
/*    */   public MCNodeBase() {
/* 22 */     this._root = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 31 */     this._key = null;
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 36 */     this._file = null;
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 41 */     this._separator = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 63 */     decimalFormat.setParseBigDecimal(true);
/* 64 */     decimalFormat.setMaximumFractionDigits(2147483647);
/*    */   }
/*    */ 
/*    */   
/*    */   protected static final MCNode[] EMPTY_NODE_ARRAY = new MCNode[0];
/*    */   protected static final Integer DEF_INT = Integer.valueOf(0);
/* 70 */   protected static final Pattern intPattern = Pattern.compile("^-?[0-9]+$");
/*    */   
/*    */   protected static final Boolean DEF_BOOL = Boolean.FALSE;
/*    */   
/*    */   protected static final DecimalFormat decimalFormat = new DecimalFormat();
/* 75 */   protected static final Pattern boolPattern = Pattern.compile("^true$|^false$");
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\io\MCNodeBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */