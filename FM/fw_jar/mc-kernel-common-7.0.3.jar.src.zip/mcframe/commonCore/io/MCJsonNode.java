/*      */ package mcframe.commonCore.io;
/*      */ 
/*      */ import com.fasterxml.jackson.databind.JsonNode;
/*      */ import com.fasterxml.jackson.databind.node.JsonNodeType;
/*      */ import java.util.Arrays;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.regex.Matcher;
/*      */ import java.util.regex.Pattern;
/*      */ import java.util.stream.StreamSupport;
/*      */ import mcframe.commonCore.lang.MCNumber;
/*      */ import mcframe.commonCore.lang.MCStringUtil;
/*      */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*      */ import mcframe.commonCore.notice.MCException;
/*      */ import mcframe.commonCore.util.MCDataConvUtil;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MCJsonNode
/*      */   extends MCNodeBase
/*      */ {
/*   42 */   private MCDataConvUtil.JSON _json = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   48 */   private JsonNode _node = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   55 */   private Map<String, MCNode> _cacheNode = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   62 */   private Map<String, MCNode[]> _cacheArray = (Map)new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   69 */   private Set<Map.Entry<String, MCNode>> _cacheChild = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   MCJsonNode(JsonNode node, String key) {
/*   79 */     this._node = node;
/*   80 */     this._key = key;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   MCJsonNode(JsonNode node, MCDataConvUtil.JSON json, String separator, String file) {
/*   92 */     this._root = this;
/*   93 */     this._node = node;
/*   94 */     this._json = json;
/*   95 */     this._key = null;
/*   96 */     this._separator = separator;
/*   97 */     this._file = file;
/*      */   }
/*      */ 
/*      */   
/*      */   public MCNode getRootNode() {
/*  102 */     return this._root;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNode getNode(String... keys) {
/*  113 */     if (!this._node.isObject()) {
/*  114 */       return null;
/*      */     }
/*      */     
/*  117 */     String key = createKey(keys);
/*  118 */     String cacheKey = getCacheKey(key);
/*  119 */     if (this._cacheNode.containsKey(cacheKey)) {
/*  120 */       return this._cacheNode.get(cacheKey);
/*      */     }
/*      */     
/*  123 */     JsonNode node = _getNode(new String[] { key });
/*  124 */     if (node == null) {
/*      */       
/*  126 */       this._cacheNode.put(cacheKey, null);
/*  127 */       return null;
/*      */     } 
/*      */ 
/*      */     
/*  131 */     MCNode mcNode = createChildNode(node, cacheKey);
/*      */     
/*  133 */     this._cacheNode.put(cacheKey, mcNode);
/*  134 */     return mcNode;
/*      */   }
/*      */ 
/*      */   
/*      */   public MCNode getNode(int index) {
/*  139 */     if (!isArray()) {
/*  140 */       return null;
/*      */     }
/*  142 */     String cacheKey = getCacheKey(String.valueOf(index));
/*  143 */     if (index < 0 || size() <= index) {
/*  144 */       throw new MCException(Core_Msg_FW_A.FCUCC0028, new Object[] { cacheKey, Integer.valueOf(size()), Integer.valueOf(index) });
/*      */     }
/*      */     
/*  147 */     if (this._cacheNode.containsKey(cacheKey)) {
/*  148 */       return this._cacheNode.get(cacheKey);
/*      */     }
/*      */     
/*  151 */     MCNode mcNode = createChildNode(this._node.get(index), cacheKey);
/*  152 */     this._cacheNode.put(cacheKey, mcNode);
/*  153 */     return mcNode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNode[] getNodeArray(String... keys) {
/*  163 */     if (!this._node.isObject()) {
/*  164 */       return null;
/*      */     }
/*      */ 
/*      */     
/*  168 */     String key = createKey(keys);
/*  169 */     String cacheKey = getCacheKey(key);
/*  170 */     if (this._cacheArray.containsKey(cacheKey)) {
/*  171 */       return this._cacheArray.get(cacheKey);
/*      */     }
/*      */ 
/*      */     
/*  175 */     JsonNode node = searchNode(key);
/*      */     
/*  177 */     if (node == null || (
/*  178 */       node.isArray() && (
/*  179 */       node.isEmpty() || (
/*  180 */       node.size() == 1 && !node.get(0).isValueNode() && node.get(0).isEmpty())))) {
/*      */       
/*  182 */       this._cacheArray.put(cacheKey, null);
/*  183 */       return null;
/*      */     } 
/*      */ 
/*      */     
/*  187 */     if (!isArrayNode(node)) {
/*  188 */       throw new MCException(Core_Msg_FW_A.FCUCC0027, new Object[] { cacheKey });
/*      */     }
/*      */     
/*  191 */     MCNode[] mcNodes = new MCNode[node.size()];
/*  192 */     String nodeKey = String.valueOf(cacheKey) + this._separator;
/*  193 */     for (int i = 0; i < node.size(); i++)
/*      */     {
/*  195 */       mcNodes[i] = createChildNode(node.get(i), String.valueOf(nodeKey) + i);
/*      */     }
/*      */     
/*  198 */     this._cacheArray.put(cacheKey, mcNodes);
/*  199 */     return mcNodes;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean containsKey(String... keys) {
/*  204 */     return (findNode(keys) != null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Iterator<String> getChildNodeKeys() {
/*  215 */     if (!this._node.isObject())
/*      */     {
/*  217 */       return null;
/*      */     }
/*      */     
/*  220 */     Iterator<String> names = this._node.fieldNames();
/*      */ 
/*      */     
/*  223 */     return names.hasNext() ? names : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Iterator<Map.Entry<String, MCNode>> getChildNodes() {
/*  234 */     if (!this._node.isObject())
/*      */     {
/*  236 */       return null;
/*      */     }
/*      */     
/*  239 */     if (this._cacheChild != null) {
/*  240 */       return this._cacheChild.iterator();
/*      */     }
/*      */     
/*  243 */     Iterator<Map.Entry<String, JsonNode>> nodes = this._node.fields();
/*  244 */     if (!nodes.hasNext())
/*      */     {
/*  246 */       return null;
/*      */     }
/*      */     
/*  249 */     Map<String, MCNode> mcNodes = new LinkedHashMap<>();
/*  250 */     while (nodes.hasNext()) {
/*  251 */       Map.Entry<String, JsonNode> entry = nodes.next();
/*  252 */       String cacheKey = getCacheKey(entry.getKey());
/*  253 */       mcNodes.put(entry.getKey(), createChildNode(entry.getValue(), cacheKey));
/*      */     } 
/*      */     
/*  256 */     Set<Map.Entry<String, MCNode>> childNodes = mcNodes.entrySet();
/*  257 */     this._cacheChild = childNodes;
/*  258 */     return childNodes.iterator();
/*      */   }
/*      */ 
/*      */   
/*      */   public String getNodeKey() {
/*  263 */     return this._key;
/*      */   }
/*      */ 
/*      */   
/*      */   public int size() {
/*  268 */     if (isArray()) {
/*  269 */       return this._node.size();
/*      */     }
/*  271 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getString() {
/*  276 */     return getString((String)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getString(String def) {
/*  281 */     return getString(def, true);
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] getStringArray() {
/*  286 */     return getStringArray((String[])null);
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] getStringArray(String[] def) {
/*  291 */     return getStringArray(def, true);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getNodeString(String... keys) {
/*  296 */     return getNodeString((String)null, keys);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getNodeString(String def, String... keys) {
/*  301 */     return getNodeString(def, true, keys);
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] getNodeStringArray(String... keys) {
/*  306 */     return getNodeStringArray((String[])null, keys);
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] getNodeStringArray(String[] def, String... keys) {
/*  311 */     return getNodeStringArray(def, true, keys);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getStringNoTrim() {
/*  316 */     return getStringNoTrim((String)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getStringNoTrim(String def) {
/*  321 */     return getString(def, false);
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] getStringArrayNoTrim() {
/*  326 */     return getStringArrayNoTrim((String[])null);
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] getStringArrayNoTrim(String[] def) {
/*  331 */     return getStringArray(def, false);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getNodeStringNoTrim(String... keys) {
/*  336 */     return getNodeStringNoTrim((String)null, keys);
/*      */   }
/*      */ 
/*      */   
/*      */   public String getNodeStringNoTrim(String def, String... keys) {
/*  341 */     return getNodeString(def, false, keys);
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] getNodeStringArrayNoTrim(String... keys) {
/*  346 */     return getNodeStringArrayNoTrim((String[])null, keys);
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] getNodeStringArrayNoTrim(String[] def, String... keys) {
/*  351 */     return getNodeStringArray(def, false, keys);
/*      */   }
/*      */ 
/*      */   
/*      */   public MCNumber getNumber() {
/*  356 */     return getNumber((MCNumber)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public MCNumber getNumber(MCNumber def) {
/*  361 */     Node node = new NumberNode(this._node, this._key);
/*  362 */     return (MCNumber)getValue(node, def);
/*      */   }
/*      */ 
/*      */   
/*      */   public MCNumber[] getNumberArray() {
/*  367 */     return getNumberArray((MCNumber[])null);
/*      */   }
/*      */ 
/*      */   
/*      */   public MCNumber[] getNumberArray(MCNumber[] def) {
/*  372 */     Node valueNode = new NumberNode(this._node, this._key);
/*  373 */     return (MCNumber[])getValueArray(valueNode, (Object[])def);
/*      */   }
/*      */ 
/*      */   
/*      */   public MCNumber getNodeNumber(String... keys) {
/*  378 */     return getNodeNumber((MCNumber)null, keys);
/*      */   }
/*      */ 
/*      */   
/*      */   public MCNumber getNodeNumber(MCNumber def, String... keys) {
/*  383 */     if (!this._node.isObject()) {
/*  384 */       return def;
/*      */     }
/*  386 */     JsonNode node = _getNode(keys);
/*  387 */     if (node == null) {
/*  388 */       return def;
/*      */     }
/*  390 */     Node valueNode = new NumberNode(node, getCacheKey(createKey(keys)));
/*  391 */     return (MCNumber)getValue(valueNode, def);
/*      */   }
/*      */ 
/*      */   
/*      */   public MCNumber[] getNodeNumberArray(String... keys) {
/*  396 */     return getNodeNumberArray((MCNumber[])null, keys);
/*      */   }
/*      */ 
/*      */   
/*      */   public MCNumber[] getNodeNumberArray(MCNumber[] def, String... keys) {
/*  401 */     if (!this._node.isObject()) {
/*  402 */       return def;
/*      */     }
/*  404 */     JsonNode node = _getNode(keys);
/*  405 */     if (node == null) {
/*  406 */       return def;
/*      */     }
/*  408 */     Node valueNode = new NumberNode(node, getCacheKey(createKey(keys)));
/*  409 */     return (MCNumber[])getValueArray(valueNode, (Object[])def);
/*      */   }
/*      */ 
/*      */   
/*      */   public int getInteger() {
/*  414 */     return _getInteger((Integer)null);
/*      */   }
/*      */ 
/*      */   
/*      */   public int getInteger(int def) {
/*  419 */     return _getInteger(Integer.valueOf(def));
/*      */   }
/*      */ 
/*      */   
/*      */   public int[] getIntegerArray() {
/*  424 */     return getIntegerArray((int[])null);
/*      */   }
/*      */ 
/*      */   
/*      */   public int[] getIntegerArray(int[] def) {
/*  429 */     IntegerNode valueNode = new IntegerNode(this._node, this._key);
/*  430 */     return getIntegerValueArray(valueNode, def);
/*      */   }
/*      */ 
/*      */   
/*      */   public int getNodeInteger(String... keys) {
/*  435 */     return getNodeInteger(DEF_INT.intValue(), keys);
/*      */   }
/*      */ 
/*      */   
/*      */   public int getNodeInteger(int def, String... keys) {
/*  440 */     if (!this._node.isObject()) {
/*  441 */       return def;
/*      */     }
/*  443 */     JsonNode node = _getNode(keys);
/*  444 */     if (node == null) {
/*  445 */       return def;
/*      */     }
/*  447 */     Node valueNode = new IntegerNode(node, getCacheKey(createKey(keys)), Integer.valueOf(def));
/*  448 */     return ((Integer)getValue(valueNode, Integer.valueOf(def))).intValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public int[] getNodeIntegerArray(String... keys) {
/*  453 */     return getNodeIntegerArray((int[])null, keys);
/*      */   }
/*      */ 
/*      */   
/*      */   public int[] getNodeIntegerArray(int[] def, String... keys) {
/*  458 */     if (!this._node.isObject()) {
/*  459 */       return def;
/*      */     }
/*  461 */     JsonNode node = _getNode(keys);
/*  462 */     if (node == null) {
/*  463 */       return def;
/*      */     }
/*  465 */     IntegerNode valueNode = new IntegerNode(node, getCacheKey(createKey(keys)));
/*  466 */     return getIntegerValueArray(valueNode, def);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean getBoolean() {
/*  471 */     return getBoolean(DEF_BOOL.booleanValue());
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean getBoolean(boolean def) {
/*  476 */     Node valueNode = new BooleanNode(this._node, this._key);
/*  477 */     return ((Boolean)getValue(valueNode, Boolean.valueOf(def))).booleanValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean[] getBooleanArray() {
/*  482 */     return getBooleanArray((boolean[])null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean[] getBooleanArray(boolean[] def) {
/*  487 */     BooleanNode valueNode = new BooleanNode(this._node, this._key);
/*  488 */     return getBooleanValueArray(valueNode, def);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean getNodeBoolean(String... keys) {
/*  493 */     return getNodeBoolean(DEF_BOOL.booleanValue(), keys);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean getNodeBoolean(boolean def, String... keys) {
/*  498 */     if (!this._node.isObject()) {
/*  499 */       return def;
/*      */     }
/*  501 */     JsonNode node = _getNode(keys);
/*  502 */     if (node == null) {
/*  503 */       return def;
/*      */     }
/*  505 */     BooleanNode valueNode = new BooleanNode(node, getCacheKey(createKey(keys)));
/*  506 */     return ((Boolean)getValue(valueNode, Boolean.valueOf(def))).booleanValue();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean[] getNodeBooleanArray(String... keys) {
/*  511 */     return getNodeBooleanArray((boolean[])null, keys);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean[] getNodeBooleanArray(boolean[] def, String... keys) {
/*  516 */     if (!this._node.isObject()) {
/*  517 */       return def;
/*      */     }
/*  519 */     JsonNode node = _getNode(keys);
/*  520 */     if (node == null) {
/*  521 */       return def;
/*      */     }
/*  523 */     BooleanNode valueNode = new BooleanNode(node, getCacheKey(createKey(keys)));
/*  524 */     return getBooleanValueArray(valueNode, def);
/*      */   }
/*      */ 
/*      */   
/*      */   public MCDocumentType getDocumentType() {
/*  529 */     return MCDocumentType.JSON;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getSeparator() {
/*  534 */     return this._separator;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isString() {
/*  539 */     return isString((String[])null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isString(String... keys) {
/*  544 */     MCNodeType type = getValueMCNodeType(MCNodeType.STRING, keys);
/*  545 */     return (type == MCNodeType.STRING);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isStringArray() {
/*  550 */     return isStringArray((String[])null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isStringArray(String... keys) {
/*  555 */     MCNodeType type = getArrayMCNodeType(MCNodeType.STRING_ARRAY, keys);
/*  556 */     return (type == MCNodeType.STRING_ARRAY);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isNumber() {
/*  561 */     return isNumber((String[])null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isNumber(String... keys) {
/*  566 */     MCNodeType type = getValueMCNodeType(MCNodeType.NUMBER, keys);
/*  567 */     if (type == MCNodeType.INTEGER)
/*      */     {
/*  569 */       type = MCNodeType.NUMBER;
/*      */     }
/*  571 */     return (type == MCNodeType.NUMBER);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isNumberArray() {
/*  576 */     return isNumberArray((String[])null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isNumberArray(String... keys) {
/*  581 */     MCNodeType type = getArrayMCNodeType(MCNodeType.NUMBER_ARRAY, keys);
/*  582 */     if (type == MCNodeType.INTEGER_ARRAY)
/*      */     {
/*  584 */       type = MCNodeType.NUMBER_ARRAY;
/*      */     }
/*  586 */     return (type == MCNodeType.NUMBER_ARRAY);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isInteger() {
/*  591 */     return isInteger((String[])null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isInteger(String... keys) {
/*  596 */     MCNodeType type = getValueMCNodeType(MCNodeType.INTEGER, keys);
/*  597 */     return (type == MCNodeType.INTEGER);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isIntegerArray() {
/*  602 */     return isIntegerArray((String[])null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isIntegerArray(String... keys) {
/*  607 */     MCNodeType type = getArrayMCNodeType(MCNodeType.INTEGER_ARRAY, keys);
/*  608 */     return (type == MCNodeType.INTEGER_ARRAY);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isBoolean() {
/*  613 */     return isBoolean((String[])null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isBoolean(String... keys) {
/*  618 */     MCNodeType type = getValueMCNodeType(MCNodeType.BOOLEAN, keys);
/*  619 */     return (type == MCNodeType.BOOLEAN);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isBooleanArray() {
/*  624 */     return isBooleanArray((String[])null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isBooleanArray(String... keys) {
/*  629 */     MCNodeType type = getArrayMCNodeType(MCNodeType.BOOLEAN_ARRAY, keys);
/*  630 */     return (type == MCNodeType.BOOLEAN_ARRAY);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isObject() {
/*  635 */     return isObject((String[])null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isObject(String... keys) {
/*  640 */     MCNodeType type = getValueMCNodeType(MCNodeType.OBJECT, keys);
/*  641 */     return (type == MCNodeType.OBJECT);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isArray() {
/*  646 */     return isArray((String[])null);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isArray(String... keys) {
/*  651 */     MCNodeType type = getArrayMCNodeType(MCNodeType.ARRAY, keys);
/*  652 */     return (type == MCNodeType.ARRAY);
/*      */   }
/*      */ 
/*      */   
/*      */   public MCNodeType getNodeType() {
/*  657 */     return getMCNodeType(this._node);
/*      */   }
/*      */ 
/*      */   
/*      */   public MCNodeType getNodeType(String... keys) {
/*  662 */     return getMCNodeType(findNode(keys));
/*      */   }
/*      */ 
/*      */   
/*      */   public Map<String, Object> toMap() {
/*  667 */     return this._json.toMap(this._node.toString());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MCJsonNode createChildNode(JsonNode jsonNode, String key) {
/*  681 */     MCJsonNode node = new MCJsonNode(jsonNode, key);
/*  682 */     node._root = this._root;
/*  683 */     node._json = this._json;
/*  684 */     node._separator = this._separator;
/*  685 */     node._file = this._file;
/*  686 */     return node;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private JsonNode searchNode(String key) {
/*  700 */     if (MCStringUtil.isNull(key) || 
/*  701 */       key.startsWith(this._separator)) {
/*  702 */       return null;
/*      */     }
/*      */     
/*  705 */     String[] keys = key.split(Pattern.quote(this._separator));
/*  706 */     JsonNode node = this._node;
/*  707 */     for (int i = 0; i < keys.length; i++) {
/*  708 */       node = node.get(keys[i]);
/*      */       
/*  710 */       if (node == null) {
/*  711 */         return null;
/*      */       }
/*      */       
/*  714 */       if (node.isArray() && i != keys.length - 1) {
/*  715 */         throw new MCException(Core_Msg_FW_A.FCUCC0026, new Object[] { key });
/*      */       }
/*      */     } 
/*      */     
/*  719 */     return node;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String createKey(String... keys) {
/*  733 */     return createKey(this._separator, keys);
/*      */   }
/*      */   
/*      */   private String createKey(String sep, String... keys) {
/*  737 */     if (keys == null || keys.length == 0) {
/*  738 */       return null;
/*      */     }
/*      */     
/*  741 */     if (keys.length == 1) {
/*  742 */       return keys[0];
/*      */     }
/*      */     
/*  745 */     StringBuilder sb = new StringBuilder(1000);
/*  746 */     boolean first = true;
/*  747 */     for (int i = 0; i < keys.length; i++) {
/*  748 */       if (!MCStringUtil.isNull(keys[i])) {
/*  749 */         if (first) {
/*  750 */           first = false;
/*      */         } else {
/*      */           
/*  753 */           sb.append(sep);
/*      */         } 
/*  755 */         sb.append(keys[i]);
/*      */       } 
/*      */     } 
/*      */     
/*  759 */     return (sb.length() > 0) ? sb.toString() : "";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getCacheKey(String key) {
/*  772 */     if (MCStringUtil.isNull(key)) {
/*  773 */       return null;
/*      */     }
/*  775 */     return (this._key == null) ? key : (String.valueOf(this._key) + this._separator + key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private JsonNode _getNode(String... keys) {
/*  790 */     String key = createKey(keys);
/*  791 */     JsonNode node = searchNode(key);
/*      */ 
/*      */     
/*  794 */     if (node == null || (node.isArray() && node.isEmpty())) {
/*  795 */       return null;
/*      */     }
/*      */     
/*  798 */     if (!isValueNode(node)) {
/*  799 */       String cacheKey = getCacheKey(key);
/*  800 */       throw new MCException(Core_Msg_FW_A.FCUCC0027, new Object[] { cacheKey });
/*      */     } 
/*  802 */     return node;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isValueNode(JsonNode node) {
/*  814 */     MCNodeType type = getMCNodeType(node);
/*  815 */     if (type == MCNodeType.ARRAY || 
/*  816 */       type == MCNodeType.NONE) {
/*  817 */       return false;
/*      */     }
/*  819 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isArrayNode(JsonNode node) {
/*  831 */     MCNodeType type = getMCNodeType(node);
/*  832 */     if (type == MCNodeType.NULL || 
/*  833 */       type == MCNodeType.EMPTY_ARRAY || 
/*  834 */       type == MCNodeType.NULL_ARRAY || 
/*  835 */       type == MCNodeType.ARRAY) {
/*  836 */       return true;
/*      */     }
/*  838 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Object getValue(Node node, Object def) {
/*  851 */     if (!node.isValue()) {
/*  852 */       node.error();
/*      */     }
/*  854 */     return node.isNull() ? def : node.value();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Object[] getValueArray(Node node, Object[] def) {
/*  867 */     if (!node.isValueArray()) {
/*  868 */       node.error();
/*      */     }
/*  870 */     if (node.isEmpty()) {
/*  871 */       return def;
/*      */     }
/*  873 */     return node.valueArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int[] getIntegerValueArray(IntegerNode node, int[] def) {
/*  886 */     if (!node.isValueArray()) {
/*  887 */       node.error();
/*      */     }
/*  889 */     if (node.isEmpty()) {
/*  890 */       return def;
/*      */     }
/*  892 */     return node.integerValueArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean[] getBooleanValueArray(BooleanNode node, boolean[] def) {
/*  905 */     if (!node.isValueArray()) {
/*  906 */       node.error();
/*      */     }
/*  908 */     if (node.isEmpty()) {
/*  909 */       return def;
/*      */     }
/*  911 */     return node.booleanValueArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private JsonNode findNode(String... keys) {
/*  923 */     if (!this._node.isObject()) {
/*  924 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  929 */     String key = createKey(this._separator, keys);
/*  930 */     key = key.replaceAll(Pattern.quote(this._separator), String.valueOf('/'));
/*      */     
/*  932 */     String jsonKey = String.valueOf('/') + key;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  937 */     JsonNode node = this._node.at(jsonKey);
/*  938 */     if (node == null || node.isMissingNode()) {
/*  939 */       return null;
/*      */     }
/*  941 */     return node;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getString(String def, boolean isTrim) {
/*  948 */     Node valueNode = new StringNode(this._node, isTrim, this._key);
/*  949 */     return (String)getValue(valueNode, def);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String[] getStringArray(String[] def, boolean isTrim) {
/*  956 */     Node valueNode = new StringNode(this._node, isTrim, this._key);
/*  957 */     return (String[])getValueArray(valueNode, (Object[])def);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getNodeString(String def, boolean isTrim, String... keys) {
/*  964 */     if (!this._node.isObject()) {
/*  965 */       return def;
/*      */     }
/*  967 */     JsonNode node = _getNode(keys);
/*  968 */     if (node == null) {
/*  969 */       return def;
/*      */     }
/*  971 */     Node valueNode = new StringNode(node, isTrim, getCacheKey(createKey(keys)));
/*  972 */     return (String)getValue(valueNode, def);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String[] getNodeStringArray(String[] def, boolean isTrim, String... keys) {
/*  979 */     if (!this._node.isObject()) {
/*  980 */       return def;
/*      */     }
/*  982 */     JsonNode node = _getNode(keys);
/*  983 */     if (node == null) {
/*  984 */       return def;
/*      */     }
/*  986 */     Node valueNode = new StringNode(node, isTrim, getCacheKey(createKey(keys)));
/*  987 */     return (String[])getValueArray(valueNode, (Object[])def);
/*      */   }
/*      */   
/*      */   private int _getInteger(Integer def) {
/*  991 */     Node valueNode = new IntegerNode(this._node, this._key, def);
/*  992 */     return ((Integer)getValue(valueNode, def)).intValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MCNodeType getValueMCNodeType(MCNodeType def, String... keys) {
/* 1007 */     JsonNode node = this._node;
/* 1008 */     if (keys != null) {
/* 1009 */       node = findNode(keys);
/* 1010 */       if (node == null) {
/* 1011 */         return MCNodeType.NONE;
/*      */       }
/*      */     } 
/*      */     
/* 1015 */     MCNodeType type = getMCNodeType(node);
/* 1016 */     if (type == MCNodeType.NULL) {
/*      */       
/* 1018 */       if (def == MCNodeType.INTEGER) {
/* 1019 */         return MCNodeType.NONE;
/*      */       }
/* 1021 */       return def;
/*      */     } 
/* 1023 */     return type;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MCNodeType getArrayMCNodeType(MCNodeType def, String... keys) {
/* 1038 */     JsonNode node = this._node;
/* 1039 */     if (keys != null) {
/* 1040 */       node = findNode(keys);
/* 1041 */       if (node == null) {
/* 1042 */         return MCNodeType.NONE;
/*      */       }
/*      */     } 
/*      */     
/* 1046 */     MCNodeType type = getMCNodeType(node);
/* 1047 */     if (type == MCNodeType.NULL || type == MCNodeType.NULL_ARRAY) {
/*      */       
/* 1049 */       if (def == MCNodeType.INTEGER_ARRAY) {
/* 1050 */         return MCNodeType.NONE;
/*      */       }
/* 1052 */       return def;
/*      */     } 
/*      */     
/* 1055 */     if (type == MCNodeType.EMPTY_ARRAY) {
/* 1056 */       return def;
/*      */     }
/*      */     
/* 1059 */     return type;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MCNodeType getMCNodeType(JsonNode node) {
/* 1072 */     if (node == null) {
/* 1073 */       return MCNodeType.NONE;
/*      */     }
/*      */     
/* 1076 */     MCNodeType mctype = MCNodeType.NONE;
/* 1077 */     switch (node.getNodeType()) {
/*      */       case BOOLEAN:
/* 1079 */         mctype = MCNodeType.BOOLEAN;
/*      */         break;
/*      */       case NULL:
/* 1082 */         mctype = MCNodeType.NULL;
/*      */         break;
/*      */       case NUMBER:
/* 1085 */         if (isInt(node)) {
/* 1086 */           mctype = MCNodeType.INTEGER;
/*      */           break;
/*      */         } 
/* 1089 */         mctype = MCNodeType.NUMBER;
/*      */         break;
/*      */       
/*      */       case OBJECT:
/* 1093 */         mctype = MCNodeType.OBJECT;
/*      */         break;
/*      */       case STRING:
/* 1096 */         mctype = MCNodeType.STRING;
/*      */         break;
/*      */       
/*      */       case null:
/* 1100 */         mctype = getMCArrayNodeType(node);
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1107 */     return mctype;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MCNodeType getMCArrayNodeType(JsonNode arrayNode) {
/* 1138 */     if (!arrayNode.isArray()) {
/* 1139 */       return MCNodeType.NONE;
/*      */     }
/* 1141 */     if (arrayNode.isEmpty()) {
/* 1142 */       return MCNodeType.EMPTY_ARRAY;
/*      */     }
/*      */     
/* 1145 */     JsonNodeType jType = null;
/* 1146 */     boolean existOther = false;
/* 1147 */     boolean existNull = false;
/* 1148 */     boolean isInteger = false;
/*      */ 
/*      */     
/* 1151 */     for (JsonNode node : arrayNode) {
/* 1152 */       JsonNodeType nodeType = node.getNodeType();
/* 1153 */       if (nodeType == JsonNodeType.NULL) {
/*      */         
/* 1155 */         existNull = true;
/*      */         
/*      */         continue;
/*      */       } 
/* 1159 */       if (jType != null && 
/* 1160 */         jType != nodeType) {
/* 1161 */         existOther = true;
/*      */         
/*      */         break;
/*      */       } 
/* 1165 */       if (nodeType == JsonNodeType.NUMBER) {
/* 1166 */         if ((jType == null && isInt(node)) || (
/* 1167 */           isInteger && isInt(node))) {
/*      */           
/* 1169 */           isInteger = true;
/*      */         }
/*      */         else {
/*      */           
/* 1173 */           isInteger = false;
/*      */         } 
/*      */       }
/* 1176 */       jType = nodeType;
/*      */     } 
/*      */     
/* 1179 */     if (existOther) {
/* 1180 */       return MCNodeType.NONE;
/*      */     }
/*      */     
/* 1183 */     if (jType == null) {
/* 1184 */       return MCNodeType.NULL_ARRAY;
/*      */     }
/*      */ 
/*      */     
/* 1188 */     MCNodeType arraytype = MCNodeType.NONE;
/* 1189 */     switch (jType) {
/*      */       case BOOLEAN:
/* 1191 */         arraytype = MCNodeType.BOOLEAN_ARRAY;
/*      */         break;
/*      */       case NUMBER:
/* 1194 */         if (isInteger && !existNull) {
/*      */           
/* 1196 */           arraytype = MCNodeType.INTEGER_ARRAY;
/*      */           break;
/*      */         } 
/* 1199 */         arraytype = MCNodeType.NUMBER_ARRAY;
/*      */         break;
/*      */       
/*      */       case STRING:
/* 1203 */         arraytype = MCNodeType.STRING_ARRAY;
/*      */         break;
/*      */       case null:
/*      */       case OBJECT:
/* 1207 */         arraytype = MCNodeType.ARRAY;
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1217 */     return arraytype;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isInt(JsonNode node) {
/* 1223 */     return (node.isIntegralNumber() && node.canConvertToInt());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private abstract class Node
/*      */   {
/* 1230 */     protected JsonNode _valueNode = null;
/*      */     
/* 1232 */     protected String _nodeKey = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected boolean isEmpty() {
/* 1238 */       if (node().isNull() || (
/* 1239 */         node().isArray() && node().isEmpty())) {
/* 1240 */         return true;
/*      */       }
/* 1242 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected boolean isNull() {
/* 1249 */       return node().isNull();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected String text() {
/* 1257 */       if (this._valueNode.isContainerNode()) {
/* 1258 */         MCNodeType type = MCJsonNode.this.getMCNodeType(this._valueNode);
/* 1259 */         return type.toString();
/*      */       } 
/* 1261 */       return this._valueNode.asText();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Node() {}
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     abstract Object value();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     abstract Object[] valueArray();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     abstract boolean isValue();
/*      */ 
/*      */ 
/*      */     
/*      */     abstract boolean isValueArray();
/*      */ 
/*      */ 
/*      */     
/*      */     abstract void error();
/*      */ 
/*      */ 
/*      */     
/*      */     abstract JsonNode node();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private class StringNode
/*      */     extends Node
/*      */   {
/*      */     private boolean _trim = true;
/*      */ 
/*      */ 
/*      */     
/*      */     StringNode(JsonNode node, boolean isTrim, String nodeKey) {
/* 1307 */       super(null);
/* 1308 */       this._valueNode = node;
/* 1309 */       this._trim = isTrim;
/* 1310 */       this._nodeKey = nodeKey;
/*      */     }
/*      */ 
/*      */     
/*      */     String value() {
/* 1315 */       String v = this._valueNode.textValue();
/* 1316 */       return this._trim ? v.trim() : v;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     String[] valueArray() {
/*      */       String[] value;
/* 1323 */       if (this._valueNode.isArray()) {
/* 1324 */         value = (String[])StreamSupport.stream(this._valueNode.spliterator(), false)
/* 1325 */           .filter(e -> isValue(e))
/* 1326 */           .map(e -> e.textValue())
/* 1327 */           .toArray(param1Int -> new String[param1Int]);
/*      */ 
/*      */         
/* 1330 */         if (this._valueNode.size() != value.length) {
/* 1331 */           error();
/*      */         
/*      */         }
/*      */       }
/*      */       else {
/*      */         
/* 1337 */         value = MCStringUtil.split(",", this._valueNode.textValue());
/*      */       } 
/* 1339 */       if (this._trim) {
/* 1340 */         for (int i = 0; i < value.length; i++) {
/* 1341 */           value[i] = MCStringUtil.trim(value[i]);
/*      */         }
/*      */       }
/* 1344 */       return value;
/*      */     }
/*      */     
/*      */     private boolean isValue(JsonNode node) {
/* 1348 */       if (node.isTextual() || node.isNull()) {
/* 1349 */         return true;
/*      */       }
/* 1351 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     boolean isValue() {
/* 1356 */       return isValue(this._valueNode);
/*      */     }
/*      */ 
/*      */     
/*      */     boolean isValueArray() {
/* 1361 */       if (this._valueNode.isTextual() || 
/* 1362 */         this._valueNode.isNull() || 
/* 1363 */         this._valueNode.isArray()) {
/* 1364 */         return true;
/*      */       }
/* 1366 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     void error() {
/* 1371 */       throw new MCException(Core_Msg_FW_A.FCUCC0022, new Object[] { this.this$0._file, this._nodeKey, text() });
/*      */     }
/*      */ 
/*      */     
/*      */     JsonNode node() {
/* 1376 */       return this._valueNode;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   final class NumberNode
/*      */     extends Node
/*      */   {
/*      */     NumberNode(JsonNode node, String nodeKey) {
/* 1385 */       super(null);
/* 1386 */       this._valueNode = node;
/* 1387 */       this._nodeKey = nodeKey;
/*      */     }
/*      */ 
/*      */     
/*      */     MCNumber value() {
/* 1392 */       Number num = this._valueNode.numberValue();
/* 1393 */       return MCNumber.valueOf(num.toString());
/*      */     }
/*      */ 
/*      */     
/*      */     MCNumber[] valueArray() {
/*      */       MCNumber[] value;
/* 1399 */       if (this._valueNode.isArray()) {
/* 1400 */         value = (MCNumber[])StreamSupport.stream(this._valueNode.spliterator(), false)
/* 1401 */           .filter(e -> isValue(e))
/* 1402 */           .map(e -> {
/*      */               Number n = e.numberValue(); return (n == null) ? null : MCNumber.valueOf(n.toString());
/* 1404 */             }).toArray(param1Int -> new MCNumber[param1Int]);
/*      */ 
/*      */         
/* 1407 */         if (this._valueNode.size() != value.length) {
/* 1408 */           error();
/*      */         
/*      */         }
/*      */       }
/*      */       else {
/*      */         
/* 1414 */         String[] s = MCStringUtil.split(",", this._valueNode.textValue());
/* 1415 */         value = (MCNumber[])Arrays.<String>stream(s)
/* 1416 */           .filter(e -> MCNumber.isNumeric(e, MCJsonNode.decimalFormat))
/* 1417 */           .map(e -> {
/*      */               String t = MCStringUtil.trim(e);
/*      */ 
/*      */               
/*      */               return MCStringUtil.isNull(e) ? null : MCNumber.valueOf(t);
/* 1422 */             }).toArray(param1Int -> new MCNumber[param1Int]);
/*      */ 
/*      */         
/* 1425 */         if (s.length != value.length) {
/* 1426 */           error();
/*      */         }
/*      */       } 
/* 1429 */       return value;
/*      */     }
/*      */     private boolean isValue(JsonNode node) {
/* 1432 */       if (node.isNumber() || node.isNull()) {
/* 1433 */         return true;
/*      */       }
/* 1435 */       return false;
/*      */     }
/*      */     
/*      */     boolean isValue() {
/* 1439 */       return isValue(this._valueNode);
/*      */     }
/*      */     
/*      */     boolean isValueArray() {
/* 1443 */       if (this._valueNode.isNull() || 
/* 1444 */         this._valueNode.isArray() || 
/* 1445 */         this._valueNode.isTextual())
/*      */       {
/* 1447 */         return true;
/*      */       }
/* 1449 */       return false;
/*      */     }
/*      */     
/*      */     void error() {
/* 1453 */       throw new MCException(Core_Msg_FW_A.FCUCC0023, new Object[] { this.this$0._file, this._nodeKey, text() });
/*      */     }
/*      */     
/*      */     JsonNode node() {
/* 1457 */       return this._valueNode;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private class IntegerNode
/*      */     extends Node
/*      */   {
/* 1470 */     private Integer _def = null;
/*      */ 
/*      */ 
/*      */     
/*      */     IntegerNode(JsonNode node, String nodeKey, Integer def) {
/* 1475 */       super(null);
/* 1476 */       this._valueNode = node;
/* 1477 */       this._nodeKey = nodeKey;
/* 1478 */       this._def = def;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     IntegerNode(JsonNode node, String nodeKey) {
/* 1484 */       super(null);
/* 1485 */       this._valueNode = node;
/* 1486 */       this._nodeKey = nodeKey;
/*      */     }
/*      */ 
/*      */     
/*      */     Integer value() {
/* 1491 */       return Integer.valueOf(this._valueNode.intValue());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     Integer[] valueArray() {
/* 1497 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     int[] integerValueArray() {
/*      */       int[] value;
/* 1503 */       if (this._valueNode.isArray()) {
/* 1504 */         value = StreamSupport.stream(this._valueNode.spliterator(), false)
/* 1505 */           .filter(e -> isValue(e))
/* 1506 */           .mapToInt(e -> e.intValue())
/* 1507 */           .toArray();
/*      */ 
/*      */         
/* 1510 */         if (this._valueNode.size() != value.length) {
/* 1511 */           error();
/*      */         
/*      */         }
/*      */       }
/*      */       else {
/*      */         
/* 1517 */         String[] s = MCStringUtil.split(",", this._valueNode.textValue());
/* 1518 */         value = Arrays.<String>stream(s)
/* 1519 */           .filter(e -> {
/*      */               Matcher m = MCJsonNode.intPattern.matcher(e); return m.find();
/* 1521 */             }).mapToInt(e -> {
/*      */               String t = MCStringUtil.trim(e); return Integer.valueOf(t).intValue();
/* 1523 */             }).toArray();
/*      */ 
/*      */         
/* 1526 */         if (s.length != value.length) {
/* 1527 */           error();
/*      */         }
/*      */       } 
/* 1530 */       return value;
/*      */     }
/*      */ 
/*      */     
/*      */     private boolean isValue(JsonNode node) {
/* 1535 */       if (MCJsonNode.this.isInt(node) || (node.isNull() && this._def != null)) {
/* 1536 */         return true;
/*      */       }
/* 1538 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     boolean isValue() {
/* 1543 */       return isValue(this._valueNode);
/*      */     }
/*      */ 
/*      */     
/*      */     boolean isValueArray() {
/* 1548 */       if (this._valueNode.isNull() || 
/* 1549 */         this._valueNode.isArray() || 
/* 1550 */         this._valueNode.isTextual())
/*      */       {
/* 1552 */         return true;
/*      */       }
/* 1554 */       return false;
/*      */     }
/*      */     
/*      */     void error() {
/* 1558 */       throw new MCException(Core_Msg_FW_A.FCUCC0024, new Object[] { this.this$0._file, this._nodeKey, text() });
/*      */     }
/*      */     
/*      */     public JsonNode node() {
/* 1562 */       return this._valueNode;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private class BooleanNode
/*      */     extends Node
/*      */   {
/*      */     BooleanNode(JsonNode node, String nodeKey) {
/* 1571 */       super(null);
/* 1572 */       this._valueNode = node;
/* 1573 */       this._nodeKey = nodeKey;
/*      */     }
/*      */ 
/*      */     
/*      */     Boolean value() {
/* 1578 */       return Boolean.valueOf(this._valueNode.booleanValue());
/*      */     }
/*      */ 
/*      */     
/*      */     Boolean[] valueArray() {
/* 1583 */       return null;
/*      */     }
/*      */     
/*      */     boolean[] booleanValueArray() {
/*      */       Boolean[] value;
/* 1588 */       if (this._valueNode.isArray()) {
/* 1589 */         value = (Boolean[])StreamSupport.stream(this._valueNode.spliterator(), false)
/* 1590 */           .filter(e -> isValue(e))
/* 1591 */           .map(e -> Boolean.valueOf(e.booleanValue()))
/* 1592 */           .toArray(param1Int -> new Boolean[param1Int]);
/*      */ 
/*      */         
/* 1595 */         if (this._valueNode.size() != value.length) {
/* 1596 */           error();
/*      */         
/*      */         }
/*      */       }
/*      */       else {
/*      */         
/* 1602 */         String[] s = MCStringUtil.split(",", this._valueNode.textValue());
/* 1603 */         value = (Boolean[])Arrays.<String>stream(s)
/* 1604 */           .filter(e -> {
/* 1605 */               Matcher m = MCJsonNode.boolPattern.matcher(e); return !(!m.find() && !MCStringUtil.isNull(e));
/* 1606 */             }).map(e -> {
/*      */               String t = MCStringUtil.trim(e);
/*      */ 
/*      */               
/*      */               return MCStringUtil.isNull(e) ? MCJsonNode.DEF_BOOL : Boolean.valueOf(t);
/* 1611 */             }).toArray(param1Int -> new Boolean[param1Int]);
/*      */ 
/*      */         
/* 1614 */         if (s.length != value.length) {
/* 1615 */           error();
/*      */         }
/*      */       } 
/*      */       
/* 1619 */       boolean[] b = new boolean[value.length];
/* 1620 */       for (int i = 0; i < value.length; i++) {
/* 1621 */         b[i] = value[i].booleanValue();
/*      */       }
/* 1623 */       return b;
/*      */     }
/*      */     
/*      */     private boolean isValue(JsonNode node) {
/* 1627 */       if (node.isBoolean() || node.isNull()) {
/* 1628 */         return true;
/*      */       }
/* 1630 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     boolean isValue() {
/* 1635 */       return isValue(this._valueNode);
/*      */     }
/*      */ 
/*      */     
/*      */     boolean isValueArray() {
/* 1640 */       if (this._valueNode.isNull() || 
/* 1641 */         this._valueNode.isArray() || 
/* 1642 */         this._valueNode.isTextual())
/*      */       {
/* 1644 */         return true;
/*      */       }
/* 1646 */       return false;
/*      */     }
/*      */     
/*      */     void error() {
/* 1650 */       throw new MCException(Core_Msg_FW_A.FCUCC0025, new Object[] { this.this$0._file, this._nodeKey, text() });
/*      */     }
/*      */     
/*      */     JsonNode node() {
/* 1654 */       return this._valueNode;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\io\MCJsonNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */