/*    */ package mcframe.commonCore.io;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum MCDocumentType
/*    */ {
/* 12 */   JSON(
/*    */ 
/*    */     
/* 15 */     "json"),
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 20 */   XML("xml");
/*    */   
/*    */   private final String type;
/*    */ 
/*    */   
/*    */   MCDocumentType(String type) {
/* 26 */     this.type = type;
/*    */   }
/*    */   
/*    */   public String getString() {
/* 30 */     return this.type;
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\io\MCDocumentType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */