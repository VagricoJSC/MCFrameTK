/*    */ package mcframe.commonCore.io;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum MCNodeType
/*    */ {
/* 12 */   ARRAY,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 17 */   BOOLEAN,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 22 */   NULL,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 27 */   NUMBER,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 32 */   INTEGER,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 37 */   OBJECT,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 42 */   STRING,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 47 */   BOOLEAN_ARRAY,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 52 */   NUMBER_ARRAY,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 57 */   INTEGER_ARRAY,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 62 */   STRING_ARRAY,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 67 */   EMPTY_ARRAY,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 72 */   NULL_ARRAY,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 77 */   NONE;
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\io\MCNodeType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */