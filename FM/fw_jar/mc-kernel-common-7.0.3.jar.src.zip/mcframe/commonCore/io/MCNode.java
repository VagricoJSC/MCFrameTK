package mcframe.commonCore.io;

import java.util.Iterator;
import java.util.Map;
import mcframe.commonCore.lang.MCNumber;

public interface MCNode {
  MCNode getRootNode();
  
  MCNode getNode(String... paramVarArgs);
  
  MCNode getNode(int paramInt);
  
  MCNode[] getNodeArray(String... paramVarArgs);
  
  boolean containsKey(String... paramVarArgs);
  
  Iterator<String> getChildNodeKeys();
  
  Iterator<Map.Entry<String, MCNode>> getChildNodes();
  
  String getNodeKey();
  
  int size();
  
  String getString();
  
  String getStringNoTrim();
  
  String getString(String paramString);
  
  String getStringNoTrim(String paramString);
  
  String[] getStringArray();
  
  String[] getStringArrayNoTrim();
  
  String[] getStringArray(String[] paramArrayOfString);
  
  String[] getStringArrayNoTrim(String[] paramArrayOfString);
  
  String getNodeString(String... paramVarArgs);
  
  String getNodeStringNoTrim(String... paramVarArgs);
  
  String getNodeString(String paramString, String... paramVarArgs);
  
  String getNodeStringNoTrim(String paramString, String... paramVarArgs);
  
  String[] getNodeStringArray(String... paramVarArgs);
  
  String[] getNodeStringArrayNoTrim(String... paramVarArgs);
  
  String[] getNodeStringArray(String[] paramArrayOfString1, String... paramVarArgs1);
  
  String[] getNodeStringArrayNoTrim(String[] paramArrayOfString1, String... paramVarArgs1);
  
  MCNumber getNumber();
  
  MCNumber getNumber(MCNumber paramMCNumber);
  
  MCNumber[] getNumberArray();
  
  MCNumber[] getNumberArray(MCNumber[] paramArrayOfMCNumber);
  
  MCNumber getNodeNumber(String... paramVarArgs);
  
  MCNumber getNodeNumber(MCNumber paramMCNumber, String... paramVarArgs);
  
  MCNumber[] getNodeNumberArray(String... paramVarArgs);
  
  MCNumber[] getNodeNumberArray(MCNumber[] paramArrayOfMCNumber, String... paramVarArgs);
  
  int getInteger();
  
  int getInteger(int paramInt);
  
  int[] getIntegerArray();
  
  int[] getIntegerArray(int[] paramArrayOfint);
  
  int getNodeInteger(String... paramVarArgs);
  
  int getNodeInteger(int paramInt, String... paramVarArgs);
  
  int[] getNodeIntegerArray(String... paramVarArgs);
  
  int[] getNodeIntegerArray(int[] paramArrayOfint, String... paramVarArgs);
  
  boolean getBoolean();
  
  boolean getBoolean(boolean paramBoolean);
  
  boolean[] getBooleanArray();
  
  boolean[] getBooleanArray(boolean[] paramArrayOfboolean);
  
  boolean getNodeBoolean(String... paramVarArgs);
  
  boolean getNodeBoolean(boolean paramBoolean, String... paramVarArgs);
  
  boolean[] getNodeBooleanArray(String... paramVarArgs);
  
  boolean[] getNodeBooleanArray(boolean[] paramArrayOfboolean, String... paramVarArgs);
  
  MCDocumentType getDocumentType();
  
  String getSeparator();
  
  boolean isString();
  
  boolean isString(String... paramVarArgs);
  
  boolean isStringArray();
  
  boolean isStringArray(String... paramVarArgs);
  
  boolean isNumber();
  
  boolean isNumber(String... paramVarArgs);
  
  boolean isNumberArray();
  
  boolean isNumberArray(String... paramVarArgs);
  
  boolean isInteger();
  
  boolean isInteger(String... paramVarArgs);
  
  boolean isIntegerArray();
  
  boolean isIntegerArray(String... paramVarArgs);
  
  boolean isBoolean();
  
  boolean isBoolean(String... paramVarArgs);
  
  boolean isBooleanArray();
  
  boolean isBooleanArray(String... paramVarArgs);
  
  boolean isObject();
  
  boolean isObject(String... paramVarArgs);
  
  boolean isArray();
  
  boolean isArray(String... paramVarArgs);
  
  MCNodeType getNodeType();
  
  MCNodeType getNodeType(String... paramVarArgs);
  
  Map<String, Object> toMap();
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\io\MCNode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */