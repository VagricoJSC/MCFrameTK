/*    */ package mcframe.commonCore.io;
/*    */ 
/*    */ import com.fasterxml.jackson.databind.JsonNode;
/*    */ import java.io.File;
/*    */ import mcframe.commonCore.lang.MCStringUtil;
/*    */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*    */ import mcframe.commonCore.notice.MCException;
/*    */ import mcframe.commonCore.util.MCDataConvUtil;
/*    */ import mcframe.commonCore.util.MCFileUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCNodeFactory
/*    */ {
/*    */   public static MCNode create(String filePath) {
/* 40 */     return create(filePath, String.valueOf('.'));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static MCNode create(String filePath, String separator) {
/* 57 */     if (MCStringUtil.isNull(filePath)) {
/* 58 */       throw new MCException(Core_Msg_FW_A.FCUCC0013, new Object[] { filePath });
/*    */     }
/* 60 */     File file = new File(filePath);
/* 61 */     if (!file.exists()) {
/* 62 */       throw new MCException(Core_Msg_FW_A.FCUCC0013, new Object[] { file.getAbsolutePath() });
/*    */     }
/*    */     
/* 65 */     MCNode node = null;
/* 66 */     String extension = MCFileUtil.getExtension(filePath);
/*    */     
/* 68 */     if (MCDocumentType.JSON.getString().equalsIgnoreCase(extension)) {
/* 69 */       MCDataConvUtil.JSON json = MCDataConvUtil.JSON.create();
/*    */       
/* 71 */       JsonNode root = json.toJsonNode(file);
/*    */       
/* 73 */       node = new MCJsonNode(root, json, separator, file.getName());
/*    */     
/*    */     }
/*    */     else {
/*    */ 
/*    */       
/* 79 */       throw new MCException(Core_Msg_FW_A.FCUCC0013, new Object[] { file.getAbsolutePath() });
/*    */     } 
/*    */     
/* 82 */     return node;
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\io\MCNodeFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */