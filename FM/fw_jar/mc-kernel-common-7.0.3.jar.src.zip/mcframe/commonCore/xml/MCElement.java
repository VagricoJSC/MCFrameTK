/*     */ package mcframe.commonCore.xml;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.NamedNodeMap;
/*     */ import org.w3c.dom.Node;
/*     */ import org.w3c.dom.NodeList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCElement
/*     */ {
/*  30 */   Element _element = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCElement(Element element) {
/*  43 */     if (element == null) {
/*  44 */       throw new MCException("引数の{1}に、nullが指定されました。", new Object[] { "Element" });
/*     */     }
/*  46 */     if (element.getNodeType() != 1) {
/*  47 */       throw new MCException("引数の{1}に、nullが指定されました。", new Object[] { "Element" });
/*     */     }
/*  49 */     this._element = element;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Element getElement() {
/*  63 */     return this._element;
/*     */   }
/*     */   
/*     */   public MCElement getParent() {
/*  67 */     Node p = this._element.getParentNode();
/*  68 */     if (p.getNodeType() == 1) {
/*  69 */       return new MCElement((Element)p);
/*     */     }
/*  71 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCElement getFirstElement() {
/*  82 */     NodeList nodeList = this._element.getChildNodes();
/*  83 */     int length = nodeList.getLength();
/*  84 */     for (int i = 0; i < length; i++) {
/*  85 */       Node node = nodeList.item(i);
/*  86 */       if (node.getNodeType() == 1) {
/*  87 */         return new MCElement((Element)node);
/*     */       }
/*     */     } 
/*  90 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<MCElement> getElements() {
/* 103 */     NodeList nodeList = this._element.getChildNodes();
/* 104 */     return castElementList(nodeList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<MCElement> castElementList(NodeList nodeList) {
/* 117 */     List<MCElement> list = new ArrayList<>();
/* 118 */     for (int i = 0; i < nodeList.getLength(); i++) {
/* 119 */       Node node = nodeList.item(i);
/* 120 */       if (node.getNodeType() == 1) {
/* 121 */         MCElement el = new MCElement((Element)node);
/* 122 */         list.add(el);
/*     */       } 
/*     */     } 
/* 125 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<MCElement> getElementsByTagName(String name) {
/* 139 */     NodeList nodeList = this._element.getElementsByTagName(name);
/* 140 */     return castElementList(nodeList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTagName() {
/* 152 */     return this._element.getTagName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getValue() {
/* 173 */     StringBuilder sb = new StringBuilder();
/* 174 */     NodeList nodeList = this._element.getChildNodes();
/* 175 */     int length = nodeList.getLength();
/* 176 */     for (int i = 0; i < length; i++) {
/* 177 */       Node node = nodeList.item(i);
/* 178 */       if (node.getNodeType() == 3) {
/* 179 */         String val = node.getNodeValue();
/* 180 */         if (val != null) {
/* 181 */           sb.append(val.trim());
/*     */         }
/*     */       }
/* 184 */       else if (node.getNodeType() == 4) {
/* 185 */         String val = node.getNodeValue();
/* 186 */         if (val != null) {
/* 187 */           sb.append(val);
/*     */         }
/*     */       } 
/*     */     } 
/* 191 */     return (sb.length() > 0) ? sb.toString() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getRealValue() {
/* 209 */     StringBuilder sb = new StringBuilder();
/* 210 */     NodeList nodeList = this._element.getChildNodes();
/* 211 */     int length = nodeList.getLength();
/* 212 */     for (int i = 0; i < length; i++) {
/* 213 */       Node node = nodeList.item(i);
/* 214 */       if (node.getNodeType() == 3 || 
/* 215 */         node.getNodeType() == 4) {
/* 216 */         String val = node.getNodeValue();
/* 217 */         if (val != null) {
/* 218 */           sb.append(val);
/*     */         }
/*     */       } 
/*     */     } 
/* 222 */     return (sb.length() > 0) ? sb.toString() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getValues() {
/* 237 */     List<String> list = new ArrayList<>();
/* 238 */     NodeList nodeList = this._element.getChildNodes();
/* 239 */     int length = nodeList.getLength();
/* 240 */     for (int i = 0; i < length; i++) {
/* 241 */       Node node = nodeList.item(i);
/* 242 */       if (node.getNodeType() == 3 || 
/* 243 */         node.getNodeType() == 4) {
/* 244 */         String val = node.getNodeValue();
/* 245 */         if (val != null) {
/* 246 */           list.add(val);
/*     */         }
/*     */       } 
/*     */     } 
/* 250 */     return list.<String>toArray(new String[list.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addValue(String val) {
/* 264 */     if (val == null) {
/*     */       return;
/*     */     }
/* 267 */     Document doc = this._element.getOwnerDocument();
/* 268 */     Node text = doc.createTextNode(val);
/* 269 */     this._element.appendChild(text);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(String val) {
/* 283 */     removeAllValue();
/* 284 */     addValue(val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addCDATAValue(String val) {
/* 298 */     if (val == null) {
/*     */       return;
/*     */     }
/* 301 */     Document doc = this._element.getOwnerDocument();
/* 302 */     Node text = doc.createCDATASection(val);
/* 303 */     this._element.appendChild(text);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCDATAValue(String val) {
/* 317 */     removeAllValue();
/* 318 */     addCDATAValue(val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void removeAllValue() {
/* 330 */     NodeList nodeList = this._element.getChildNodes();
/* 331 */     int length = nodeList.getLength();
/* 332 */     for (int i = 0; i < length; i++) {
/* 333 */       Node node = nodeList.item(i);
/* 334 */       if (node.getNodeType() == 3 || 
/* 335 */         node.getNodeType() == 4) {
/* 336 */         this._element.removeChild(node);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getAttribute(String name) {
/* 351 */     return this._element.getAttribute(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getAttributeToBoolean(String name) {
/* 365 */     String attr = getAttribute(name);
/* 366 */     return (attr != null && attr.toLowerCase().equals("true"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAttributeToInt(String name) {
/* 381 */     String attr = getAttribute(name);
/* 382 */     return MCAttr.areDigits(attr) ? Integer.parseInt(attr) : 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttribute(String name, String value) {
/* 394 */     this._element.setAttribute(name, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeAttribute(String name) {
/* 406 */     this._element.removeAttribute(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCAttr getAttributeNode(String name) {
/* 419 */     Attr attr = this._element.getAttributeNode(name);
/* 420 */     return new MCAttr(attr, this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<MCAttr> getAttributeNodes() {
/* 432 */     List<MCAttr> list = new ArrayList<>();
/* 433 */     NamedNodeMap map = this._element.getAttributes();
/* 434 */     for (int i = 0; i < map.getLength(); i++) {
/* 435 */       MCAttr attr = new MCAttr((Attr)map.item(i), this);
/* 436 */       list.add(attr);
/*     */     } 
/* 438 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCAttr setAttributeNode(MCAttr newAttr) {
/* 453 */     Attr attr = newAttr.getAttr();
/* 454 */     attr = this._element.setAttributeNode(attr);
/* 455 */     if (attr != null) {
/* 456 */       return new MCAttr(attr, this);
/*     */     }
/* 458 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasAttribute(String name) {
/* 471 */     return this._element.hasAttribute(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNullAttribute(String name) {
/* 486 */     if (hasAttribute(name)) {
/* 487 */       String temp = getAttribute(name);
/* 488 */       return !(temp != null && temp.trim().length() > 0);
/*     */     } 
/* 490 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addComment(String text) {
/* 504 */     if (text == null) {
/*     */       return;
/*     */     }
/* 507 */     Document doc = this._element.getOwnerDocument();
/* 508 */     Node comment = doc.createComment(text);
/* 509 */     this._element.appendChild(comment);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCElement replaceChild(MCElement newChild, MCElement oldChild) {
/* 525 */     Document doc = this._element.getOwnerDocument();
/* 526 */     Node newNode = newChild.getElement();
/* 527 */     newNode = doc.importNode(newNode, true);
/*     */ 
/*     */     
/* 530 */     Node oldNode = oldChild.getElement();
/* 531 */     this._element.replaceChild(newNode, oldNode);
/* 532 */     newChild._element = (Element)newNode;
/* 533 */     return oldChild;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCElement insertBefore(MCElement newChild, MCElement refChild) {
/* 549 */     Document doc = this._element.getOwnerDocument();
/* 550 */     Node newNode = newChild.getElement();
/* 551 */     newNode = doc.importNode(newNode, true);
/*     */ 
/*     */     
/* 554 */     if (refChild != null) {
/* 555 */       Node refNode = refChild.getElement();
/* 556 */       this._element.insertBefore(newNode, refNode);
/*     */     } else {
/* 558 */       this._element.insertBefore(newNode, null);
/*     */     } 
/* 560 */     newChild._element = (Element)newNode;
/* 561 */     return newChild;
/*     */   }
/*     */   
/*     */   public MCElement appendChild(MCElement newChild) {
/* 565 */     Document doc = this._element.getOwnerDocument();
/* 566 */     Node newNode = newChild.getElement();
/* 567 */     newNode = doc.importNode(newNode, true);
/*     */     
/* 569 */     this._element.appendChild(newNode);
/*     */     
/* 571 */     newChild._element = (Element)newNode;
/* 572 */     return newChild;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCElement removeChild(MCElement oldChild) {
/* 586 */     Node delNode = this._element.removeChild(oldChild._element);
/* 587 */     if (delNode != null) return oldChild; 
/* 588 */     return null;
/*     */   }
/*     */   
/*     */   public MCXMLDocument getOwnerDocument() {
/* 592 */     Document doc = this._element.getOwnerDocument();
/* 593 */     if (doc != null) {
/* 594 */       return new MCXMLDocument(doc);
/*     */     }
/* 596 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 611 */     return this._element.toString();
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\xml\MCElement.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */