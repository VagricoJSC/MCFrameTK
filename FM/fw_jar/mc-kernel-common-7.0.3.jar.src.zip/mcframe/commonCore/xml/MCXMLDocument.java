/*     */ package mcframe.commonCore.xml;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.transform.Transformer;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import org.w3c.dom.DOMImplementation;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.DocumentType;
/*     */ import org.w3c.dom.Text;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCXMLDocument
/*     */ {
/*  47 */   protected Document _document = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final String KEY_ENCODING = "encoding";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final String KEY_VERSION = "version";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final String CHAR_SET = "UTF-8";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean _editReturn = true;
/*     */ 
/*     */ 
/*     */   
/*  71 */   private int _editIndent = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCXMLDocument(Document document) {
/*  83 */     this._document = document;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Document getDocument() {
/*  95 */     return this._document;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCXMLDocument createParseDocument(String xmlPath) {
/* 109 */     MCXMLDocument doc = new MCXMLDocument(null);
/* 110 */     InputStream ips = doc.getClass().getResourceAsStream("/" + xmlPath);
/* 111 */     if (ips == null)
/*     */     {
/* 113 */       throw new MCException(Core_Msg_FW_A.FCUCC0001, new Object[] { xmlPath });
/*     */     }
/*     */ 
/*     */     
/* 117 */     doc = createParseDocument(ips, xmlPath);
/* 118 */     return doc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCXMLDocument createParseDocument(File xml) {
/*     */     try {
/* 132 */       FileInputStream inp = new FileInputStream(xml);
/* 133 */       return createParseDocument(inp, xml.getPath());
/* 134 */     } catch (IOException ioe) {
/* 135 */       throw new MCException(ioe, Core_Msg_FW_A.FCUCC0002, new Object[] { xml.getPath() });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCXMLDocument createParseDocument(InputStream xml, String path) {
/* 150 */     MCXMLDocument rtn = null;
/*     */     try {
/* 152 */       InputSource xmlInput = new InputSource(xml);
/*     */       
/* 154 */       DocumentBuilderFactory dbfactory = 
/* 155 */         DocumentBuilderFactory.newInstance();
/* 156 */       DocumentBuilder builder = dbfactory.newDocumentBuilder();
/* 157 */       Document document = builder.parse(xmlInput);
/* 158 */       rtn = new MCXMLDocument(document);
/*     */     }
/* 160 */     catch (ParserConfigurationException ex) {
/*     */       
/* 162 */       throw new MCException(ex, Core_Msg_FW_A.FCUCC0002, new Object[] { path });
/* 163 */     } catch (SAXException ex) {
/*     */       
/* 165 */       throw new MCException(ex, Core_Msg_FW_A.FCUCC0002, new Object[] { path });
/* 166 */     } catch (IOException ex) {
/*     */       
/* 168 */       throw new MCException(ex, Core_Msg_FW_A.FCUCC0002, new Object[] { path });
/* 169 */     } catch (IllegalArgumentException ex) {
/*     */       
/* 171 */       throw new MCException(ex, Core_Msg_FW_A.FCUCC0002, new Object[] { path });
/*     */     } finally {
/* 173 */       if (rtn != null) {
/* 174 */         rtn.setEditReturn(true);
/*     */       }
/*     */     } 
/* 177 */     return rtn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCXMLDocument createNewDocument(String namespaceURI, String qualifiedName, DocumentType doctype) {
/* 199 */     MCXMLDocument _document = null;
/*     */     try {
/* 201 */       DocumentBuilderFactory dbfactory = 
/* 202 */         DocumentBuilderFactory.newInstance();
/* 203 */       DocumentBuilder builder = dbfactory.newDocumentBuilder();
/* 204 */       DOMImplementation domImpl = builder.getDOMImplementation();
/* 205 */       Document document = domImpl.createDocument(namespaceURI, 
/* 206 */           qualifiedName, doctype);
/*     */       
/* 208 */       _document = new MCXMLDocument(document);
/* 209 */     } catch (ParserConfigurationException ex) {
/*     */       
/* 211 */       throw new MCException(ex, Core_Msg_FW_A.FCUCC0003, new Object[] { qualifiedName });
/* 212 */     } catch (IllegalArgumentException ex) {
/*     */       
/* 214 */       throw new MCException(ex, Core_Msg_FW_A.FCUCC0003, new Object[] { qualifiedName });
/*     */     } 
/* 216 */     return _document;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void _save(OutputStream opStream, String anEnc) {
/*     */     try {
/* 233 */       TransformerFactory transFactory = TransformerFactory.newInstance();
/* 234 */       Transformer transformer = transFactory.newTransformer();
/*     */ 
/*     */ 
/*     */       
/* 238 */       String var = transformer.getOutputProperty("version");
/* 239 */       Properties aProp = new Properties();
/* 240 */       aProp.put("version", var);
/* 241 */       if (anEnc != null) aProp.put("encoding", anEnc); 
/* 242 */       transformer.setOutputProperties(aProp);
/*     */ 
/*     */       
/* 245 */       if (this._editReturn || this._editIndent >= 0) {
/* 246 */         editFormat();
/*     */       }
/*     */       
/* 249 */       DOMSource source = new DOMSource(this._document);
/* 250 */       StreamResult result = new StreamResult(opStream);
/* 251 */       transformer.transform(source, result);
/*     */     
/*     */     }
/* 254 */     catch (TransformerException ex) {
/* 255 */       throw new MCException(ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public File save(File file) {
/*     */     try {
/* 271 */       FileOutputStream os = new FileOutputStream(file);
/* 272 */       _save(os, null);
/* 273 */       os.close();
/*     */     }
/* 275 */     catch (IOException ex) {
/* 276 */       throw new MCException(ex);
/*     */     } 
/* 278 */     return file;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCElement getDocumentMCElement() {
/* 289 */     return new MCElement(this._document.getDocumentElement());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCElement createElement(String tagName) {
/* 300 */     MCElement rtn = new MCElement(this._document.createElement(tagName));
/* 301 */     return rtn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Text createTextNode(String data) {
/* 313 */     return this._document.createTextNode(data);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEditReturn(boolean boo) {
/* 326 */     this._editReturn = boo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEditIndent(int indent) {
/* 343 */     this._editIndent = indent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void editFormat() {
/* 354 */     MCElement root = getDocumentMCElement();
/*     */ 
/*     */     
/* 357 */     List<MCElement> list = root.getElements();
/* 358 */     for (int i = 0; i < list.size(); i++) {
/* 359 */       MCElement child = list.get(i);
/*     */       
/* 361 */       if (this._editReturn) {
/* 362 */         Text tx = createTextNode("\n");
/* 363 */         root.getElement().insertBefore(tx, child.getElement());
/*     */       } 
/*     */       
/* 366 */       if (this._editIndent >= 0) {
/* 367 */         for (int j = 0; j < this._editIndent; j++) {
/* 368 */           Text tx = createTextNode("\t");
/* 369 */           root.getElement().insertBefore(tx, child.getElement());
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 374 */       editFormat(child, this._editIndent + 1, this._editReturn);
/*     */     } 
/*     */ 
/*     */     
/* 378 */     if (this._editReturn) {
/* 379 */       Text tx = createTextNode("\n");
/* 380 */       root.getElement().insertBefore(tx, null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void editFormat(MCElement el, int indent, boolean editReturn) {
/* 395 */     List<MCElement> list = el.getElements();
/* 396 */     if (list == null || list.size() <= 0)
/* 397 */       return;  for (int i = 0; i < list.size(); i++) {
/* 398 */       MCElement child = list.get(i);
/*     */       
/* 400 */       if (editReturn) {
/* 401 */         Text tx = createTextNode("\n");
/* 402 */         el.getElement().insertBefore(tx, child.getElement());
/*     */       } 
/*     */       
/* 405 */       if (indent >= 0) {
/* 406 */         for (int j = 0; j < indent; j++) {
/* 407 */           Text tx = createTextNode("\t");
/* 408 */           el.getElement().insertBefore(tx, child.getElement());
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 413 */       editFormat(child, indent + 1, editReturn);
/*     */     } 
/*     */     
/* 416 */     if (editReturn) {
/* 417 */       Text tx = createTextNode("\n");
/* 418 */       el.getElement().insertBefore(tx, null);
/*     */     } 
/*     */     
/* 421 */     if (indent > 0)
/* 422 */       for (int j = 0; j < indent - 1; j++) {
/* 423 */         Text tx = createTextNode("\t");
/* 424 */         el.getElement().insertBefore(tx, null);
/*     */       }  
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\xml\MCXMLDocument.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */