/*     */ package mcframe.commonCore.xml;
/*     */ 
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import org.w3c.dom.Attr;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCAttr
/*     */ {
/*  16 */   private Attr _attr = null;
/*  17 */   private MCElement _owner = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCAttr(Attr attr, MCElement owner) {
/*  29 */     if (attr == null) {
/*  30 */       throw new MCException("引数の{1}に、nullが指定されました。", new Object[] { "Attr" });
/*     */     }
/*  32 */     if (attr.getNodeType() != 2) {
/*  33 */       throw new MCException("引数の{1}に、nullが指定されました。", new Object[] { "Attr" });
/*     */     }
/*  35 */     this._attr = attr;
/*  36 */     this._owner = owner;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Attr getAttr() {
/*  46 */     return this._attr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/*  58 */     return this._attr.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getSpecified() {
/*  71 */     return this._attr.getSpecified();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getValue() {
/*  83 */     return this._attr.getValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getAttributeToBoolean() {
/*  96 */     String value = this._attr.getValue();
/*  97 */     return (value != null && value.toLowerCase().equals("true"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAttributeToInt() {
/* 110 */     String value = this._attr.getValue();
/* 111 */     return areDigits(value) ? Integer.parseInt(value) : 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean areDigits(String s) {
/* 124 */     if (s == null || s.equals("")) return false;
/*     */     
/* 126 */     for (int i = 0; i < s.length(); i++) {
/* 127 */       char c = s.charAt(i);
/* 128 */       if (!Character.isDigit(c) || 
/* 129 */         Character.UnicodeBlock.of(c) != 
/* 130 */         Character.UnicodeBlock.BASIC_LATIN) {
/* 131 */         return false;
/*     */       }
/*     */     } 
/* 134 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(String value) {
/* 144 */     this._attr.setValue(value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCElement getOwnerElement() {
/* 157 */     return this._owner;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-kernel-common-7.0.3.jar!\mcframe\commonCore\xml\MCAttr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */