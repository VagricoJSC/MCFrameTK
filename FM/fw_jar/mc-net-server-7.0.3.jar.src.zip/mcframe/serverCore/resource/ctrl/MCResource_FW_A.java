/*      */ package mcframe.serverCore.resource.ctrl;
/*      */ 
/*      */ import mcframe.commonCore.container.MCContainer;
/*      */ import mcframe.commonCore.param.MCOperationInfo;
/*      */ import mcframe.commonCore.param.MCParam;
/*      */ import mcframe.serverCore.logic.MCLogic;
/*      */ import mcframe.serverCore.logic.MCLogicBase;
/*      */ import mcframe.serverCore.logic.MCLogicUtil;
/*      */ import mcframe.serverCore.logic.MCOperation;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class MCResource_FW_A
/*      */   extends MCLogicBase
/*      */ {
/*      */   public static final String MODULE_ID = "FC";
/*      */   public static final String SUBMODULE_ID = "FCBJ";
/*      */   public static final String LOGIC_ID = "FCBJL0100";
/*      */   protected MCResource_FW.Upd01 aUpd01;
/*      */   protected MCResource_FW.Del01 aDel01;
/*      */   protected MCResource_FW.Srch01 aSrch01;
/*      */   protected MCResource_FW.Srch02 aSrch02;
/*      */   protected MCResource_FW.Srch03 aSrch03;
/*      */   protected MCResource_FW.Imp01 aImp01;
/*      */   protected MCResource_FW.Exp01 aExp01;
/*      */   
/*      */   public String getModuleID() {
/*   42 */     return "FC";
/*      */   } public String getSubmoduleID() {
/*   44 */     return "FCBJ";
/*      */   } public String getLogicID() {
/*   46 */     return "FCBJL0100";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initUpd01() {
/*   53 */     this.info = PDef.FC_FCBJL0100_Upd01_INFO;
/*   54 */     ((MCResource)this).getClass(); this.aUpd01 = new MCResource_FW.Upd01((MCResource)this);
/*      */   }
/*      */   
/*      */   public static MCResource_FW.Upd01 crtUpd01() {
/*   58 */     MCResource lgc = new MCResource();
/*   59 */     lgc.initUpd01();
/*   60 */     return lgc.aUpd01;
/*      */   }
/*      */   
/*      */   protected void paramUpd01(MCParam p) {
/*   64 */     if (this.aUpd01 == null) {
/*      */       return;
/*      */     }
/*   67 */     p.setDef(this.info.def);
/*   68 */     p.addUpBlock((MCContainer)this.aUpd01.up0());
/*      */   }
/*      */   
/*      */   protected void doUpd01() {
/*   72 */     this.aUpd01.call();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResourceR createResourceR() {
/*   81 */     return ResourceR.create();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResourceL<ResourceR> createResourceL() {
/*   90 */     return ResourceL.createFC_FCBJL0100_Resource(ResourceR.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResourceR createUpd01_DtlR() {
/*   99 */     return ResourceR.create();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResourceL<ResourceR> createUpd01_DtlL() {
/*  108 */     return ResourceL.createFC_FCBJL0100_Resource(ResourceR.class);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void initDel01() {
/*  113 */     this.info = PDef.FC_FCBJL0100_Del01_INFO;
/*  114 */     ((MCResource)this).getClass(); this.aDel01 = new MCResource_FW.Del01((MCResource)this);
/*      */   }
/*      */   
/*      */   public static MCResource_FW.Del01 crtDel01() {
/*  118 */     MCResource lgc = new MCResource();
/*  119 */     lgc.initDel01();
/*  120 */     return lgc.aDel01;
/*      */   }
/*      */   
/*      */   protected void paramDel01(MCParam p) {
/*  124 */     if (this.aDel01 == null) {
/*      */       return;
/*      */     }
/*  127 */     p.setDef(this.info.def);
/*  128 */     p.addUpBlock((MCContainer)this.aDel01.up0());
/*      */   }
/*      */   
/*      */   protected void doDel01() {
/*  132 */     this.aDel01.call();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResourceR createDel01_HdrR() {
/*  141 */     return ResourceR.create();
/*      */   }
/*      */ 
/*      */   
/*      */   protected void initSrch01() {
/*  146 */     this.info = PDef.FC_FCBJL0100_Srch01_INFO;
/*  147 */     ((MCResource)this).getClass(); this.aSrch01 = new MCResource_FW.Srch01((MCResource)this);
/*      */   }
/*      */   
/*      */   public static MCResource_FW.Srch01 crtSrch01() {
/*  151 */     MCResource lgc = new MCResource();
/*  152 */     lgc.initSrch01();
/*  153 */     return lgc.aSrch01;
/*      */   }
/*      */   
/*      */   protected void paramSrch01(MCParam p) {
/*  157 */     if (this.aSrch01 == null) {
/*      */       return;
/*      */     }
/*  160 */     p.setDef(this.info.def);
/*  161 */     p.addUpBlock((MCContainer)this.aSrch01.up0());
/*  162 */     p.addDownBlock((MCContainer)this.aSrch01.down0());
/*      */   }
/*      */   
/*      */   protected void doSrch01() {
/*  166 */     this.aSrch01.call();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResourceR createSrch01_CndR() {
/*  175 */     return ResourceR.create();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResourceR createSrch01_RsltR() {
/*  184 */     return ResourceR.create();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResourceL<ResourceR> createSrch01_RsltL() {
/*  193 */     return ResourceL.createFC_FCBJL0100_Resource(ResourceR.class);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void initSrch02() {
/*  198 */     this.info = PDef.FC_FCBJL0100_Srch02_INFO;
/*  199 */     ((MCResource)this).getClass(); this.aSrch02 = new MCResource_FW.Srch02((MCResource)this);
/*      */   }
/*      */   
/*      */   public static MCResource_FW.Srch02 crtSrch02() {
/*  203 */     MCResource lgc = new MCResource();
/*  204 */     lgc.initSrch02();
/*  205 */     return lgc.aSrch02;
/*      */   }
/*      */   
/*      */   protected void paramSrch02(MCParam p) {
/*  209 */     if (this.aSrch02 == null) {
/*      */       return;
/*      */     }
/*  212 */     p.setDef(this.info.def);
/*  213 */     p.addUpBlock((MCContainer)this.aSrch02.up0());
/*  214 */     p.addDownBlock((MCContainer)this.aSrch02.down0());
/*      */   }
/*      */   
/*      */   protected void doSrch02() {
/*  218 */     this.aSrch02.call();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResourceR createSrch02_CndR() {
/*  227 */     return ResourceR.create();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResourceL<ResourceR> createSrch02_CndL() {
/*  236 */     return ResourceL.createFC_FCBJL0100_Resource(ResourceR.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResourceR createSrch02_RsltR() {
/*  245 */     return ResourceR.create();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResourceL<ResourceR> createSrch02_RsltL() {
/*  254 */     return ResourceL.createFC_FCBJL0100_Resource(ResourceR.class);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void initSrch03() {
/*  259 */     this.info = PDef.FC_FCBJL0100_Srch03_INFO;
/*  260 */     ((MCResource)this).getClass(); this.aSrch03 = new MCResource_FW.Srch03((MCResource)this);
/*      */   }
/*      */   
/*      */   public static MCResource_FW.Srch03 crtSrch03() {
/*  264 */     MCResource lgc = new MCResource();
/*  265 */     lgc.initSrch03();
/*  266 */     return lgc.aSrch03;
/*      */   }
/*      */   
/*      */   protected void paramSrch03(MCParam p) {
/*  270 */     if (this.aSrch03 == null) {
/*      */       return;
/*      */     }
/*  273 */     p.setDef(this.info.def);
/*  274 */     p.addUpBlock((MCContainer)this.aSrch03.up0());
/*  275 */     p.addDownBlock((MCContainer)this.aSrch03.down0());
/*      */   }
/*      */   
/*      */   protected void doSrch03() {
/*  279 */     this.aSrch03.call();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResourceR createSrch03_CndR() {
/*  288 */     return ResourceR.create();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResourceL<ResourceR> createSrch03_CndL() {
/*  297 */     return ResourceL.createFC_FCBJL0100_Resource(ResourceR.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResourceR createSrch03_RsltR() {
/*  306 */     return ResourceR.create();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResourceL<ResourceR> createSrch03_RsltL() {
/*  315 */     return ResourceL.createFC_FCBJL0100_Resource(ResourceR.class);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void initImp01() {
/*  320 */     this.info = PDef.FC_FCBJL0100_Imp01_INFO;
/*  321 */     ((MCResource)this).getClass(); this.aImp01 = new MCResource_FW.Imp01((MCResource)this);
/*      */   }
/*      */   
/*      */   public static MCResource_FW.Imp01 crtImp01() {
/*  325 */     MCResource lgc = new MCResource();
/*  326 */     lgc.initImp01();
/*  327 */     return lgc.aImp01;
/*      */   }
/*      */   
/*      */   protected void paramImp01(MCParam p) {
/*  331 */     if (this.aImp01 == null) {
/*      */       return;
/*      */     }
/*  334 */     p.setDef(this.info.def);
/*  335 */     p.addUpBlock((MCContainer)this.aImp01.up0());
/*  336 */     p.addUpBlock((MCContainer)this.aImp01.up1());
/*      */   }
/*      */   
/*      */   protected void doImp01() {
/*  340 */     this.aImp01.call();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResourceR createImp01_UserR() {
/*  349 */     return ResourceR.create();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResourceL<ResourceR> createImp01_UserL() {
/*  358 */     return ResourceL.createFC_FCBJL0100_Resource(ResourceR.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResourceR createImp01_DtlR() {
/*  367 */     return ResourceR.create();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResourceL<ResourceR> createImp01_DtlL() {
/*  376 */     return ResourceL.createFC_FCBJL0100_Resource(ResourceR.class);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void initExp01() {
/*  381 */     this.info = PDef.FC_FCBJL0100_Exp01_INFO;
/*  382 */     ((MCResource)this).getClass(); this.aExp01 = new MCResource_FW.Exp01((MCResource)this);
/*      */   }
/*      */   
/*      */   public static MCResource_FW.Exp01 crtExp01() {
/*  386 */     MCResource lgc = new MCResource();
/*  387 */     lgc.initExp01();
/*  388 */     return lgc.aExp01;
/*      */   }
/*      */   
/*      */   protected void paramExp01(MCParam p) {
/*  392 */     if (this.aExp01 == null) {
/*      */       return;
/*      */     }
/*  395 */     p.setDef(this.info.def);
/*  396 */     p.addUpBlock((MCContainer)this.aExp01.up0());
/*  397 */     p.addDownBlock((MCContainer)this.aExp01.down0());
/*      */   }
/*      */   
/*      */   protected void doExp01() {
/*  401 */     this.aExp01.call();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResourceR createExp01_CndR() {
/*  410 */     return ResourceR.create();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResourceR createExp01_RsltR() {
/*  419 */     return ResourceR.create();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResourceL<ResourceR> createExp01_RsltL() {
/*  428 */     return ResourceL.createFC_FCBJL0100_Resource(ResourceR.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract class Upd01
/*      */     extends MCOperation
/*      */   {
/*      */     public static final String OPERATION_ID = "Upd01";
/*      */ 
/*      */ 
/*      */     
/*      */     private final ResourceL<ResourceR> up0;
/*      */ 
/*      */     
/*      */     private final ResourceL<ResourceR> aResource;
/*      */ 
/*      */ 
/*      */     
/*      */     public String getOperationID() {
/*  449 */       return "Upd01";
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected Upd01() {
/*  462 */       this.up0 = ResourceL.createFC_FCBJL0100_Resource(ResourceR.class);
/*  463 */       this.aResource = ResourceL.createFC_FCBJL0100_Resource(ResourceR.class);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void mapUpContainers(String key) {
/*  477 */       super.mapUpContainers(key);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void mapDownContainers(String key) {
/*  485 */       super.mapDownContainers(key);
/*      */     }
/*      */     
/*      */     public MCContainer up(int i) {
/*  489 */       if (i == 0) return (MCContainer)up0(); 
/*  490 */       return null;
/*      */     }
/*      */     
/*      */     public MCContainer down(int i) {
/*  494 */       return null;
/*      */     }
/*      */     
/*      */     public void exec() {
/*  498 */       clear();
/*  499 */       MCLogicUtil.invoke((MCLogic)MCResource_FW_A.this);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void clear() {}
/*      */ 
/*      */ 
/*      */     
/*      */     public ResourceR createResourceR() {
/*  510 */       return ResourceR.create();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ResourceL<ResourceR> createResourceL() {
/*  519 */       return ResourceL.createFC_FCBJL0100_Resource(ResourceR.class);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ResourceR createUpd01_DtlR() {
/*  528 */       return ResourceR.create();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ResourceL<ResourceR> createUpd01_DtlL() {
/*  537 */       return ResourceL.createFC_FCBJL0100_Resource(ResourceR.class);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ResourceL<ResourceR> up0() {
/*  561 */       return this.up0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ResourceL<ResourceR> Resource() {
/*  572 */       return this.aResource;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public MCOperationInfo getOperationInfo() {
/*  578 */       return MCResource_FW_A.this.info;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract class Del01
/*      */     extends MCOperation
/*      */   {
/*      */     public static final String OPERATION_ID = "Del01";
/*      */ 
/*      */ 
/*      */     
/*      */     private final ResourceR up0;
/*      */ 
/*      */ 
/*      */     
/*      */     public String getOperationID() {
/*  597 */       return "Del01";
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected Del01() {
/*  608 */       this.up0 = ResourceR.create();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void mapUpContainers(String key) {
/*  622 */       super.mapUpContainers(key);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void mapDownContainers(String key) {
/*  630 */       super.mapDownContainers(key);
/*      */     }
/*      */     
/*      */     public MCContainer up(int i) {
/*  634 */       if (i == 0) return (MCContainer)up0(); 
/*  635 */       return null;
/*      */     }
/*      */     
/*      */     public MCContainer down(int i) {
/*  639 */       return null;
/*      */     }
/*      */     
/*      */     public void exec() {
/*  643 */       clear();
/*  644 */       MCLogicUtil.invoke((MCLogic)MCResource_FW_A.this);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void clear() {}
/*      */ 
/*      */ 
/*      */     
/*      */     public ResourceR createDel01_HdrR() {
/*  655 */       return ResourceR.create();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ResourceR up0() {
/*  678 */       return this.up0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MCOperationInfo getOperationInfo() {
/*  686 */       return MCResource_FW_A.this.info;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract class Srch01
/*      */     extends MCOperation
/*      */   {
/*      */     public static final String OPERATION_ID = "Srch01";
/*      */ 
/*      */     
/*      */     private final ResourceR up0;
/*      */ 
/*      */     
/*      */     private final ResourceL<ResourceR> down0;
/*      */ 
/*      */ 
/*      */     
/*      */     public String getOperationID() {
/*  706 */       return "Srch01";
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected Srch01() {
/*  719 */       this.up0 = ResourceR.create();
/*  720 */       this.down0 = ResourceL.createFC_FCBJL0100_Resource(ResourceR.class);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void mapUpContainers(String key) {
/*  734 */       super.mapUpContainers(key);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void mapDownContainers(String key) {
/*  742 */       super.mapDownContainers(key);
/*      */     }
/*      */     
/*      */     public MCContainer up(int i) {
/*  746 */       if (i == 0) return (MCContainer)up0(); 
/*  747 */       return null;
/*      */     }
/*      */     
/*      */     public MCContainer down(int i) {
/*  751 */       if (i == 0) return (MCContainer)down0(); 
/*  752 */       return null;
/*      */     }
/*      */     
/*      */     public void exec() {
/*  756 */       clear();
/*  757 */       MCLogicUtil.invoke((MCLogic)MCResource_FW_A.this);
/*      */     }
/*      */     
/*      */     protected void clear() {
/*  761 */       down0().clear();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ResourceR createSrch01_CndR() {
/*  769 */       return ResourceR.create();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ResourceR createSrch01_RsltR() {
/*  778 */       return ResourceR.create();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ResourceL<ResourceR> createSrch01_RsltL() {
/*  787 */       return ResourceL.createFC_FCBJL0100_Resource(ResourceR.class);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ResourceR up0() {
/*  805 */       return this.up0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ResourceL<ResourceR> down0() {
/*  822 */       return this.down0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MCOperationInfo getOperationInfo() {
/*  829 */       return MCResource_FW_A.this.info;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract class Srch02
/*      */     extends MCOperation
/*      */   {
/*      */     public static final String OPERATION_ID = "Srch02";
/*      */ 
/*      */     
/*      */     private final ResourceL<ResourceR> up0;
/*      */ 
/*      */     
/*      */     private final ResourceL<ResourceR> down0;
/*      */ 
/*      */ 
/*      */     
/*      */     public String getOperationID() {
/*  849 */       return "Srch02";
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected Srch02() {
/*  862 */       this.up0 = ResourceL.createFC_FCBJL0100_Resource(ResourceR.class);
/*  863 */       this.down0 = ResourceL.createFC_FCBJL0100_Resource(ResourceR.class);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void mapUpContainers(String key) {
/*  877 */       super.mapUpContainers(key);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void mapDownContainers(String key) {
/*  885 */       super.mapDownContainers(key);
/*      */     }
/*      */     
/*      */     public MCContainer up(int i) {
/*  889 */       if (i == 0) return (MCContainer)up0(); 
/*  890 */       return null;
/*      */     }
/*      */     
/*      */     public MCContainer down(int i) {
/*  894 */       if (i == 0) return (MCContainer)down0(); 
/*  895 */       return null;
/*      */     }
/*      */     
/*      */     public void exec() {
/*  899 */       clear();
/*  900 */       MCLogicUtil.invoke((MCLogic)MCResource_FW_A.this);
/*      */     }
/*      */     
/*      */     protected void clear() {
/*  904 */       down0().clear();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ResourceR createSrch02_CndR() {
/*  912 */       return ResourceR.create();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ResourceL<ResourceR> createSrch02_CndL() {
/*  921 */       return ResourceL.createFC_FCBJL0100_Resource(ResourceR.class);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ResourceR createSrch02_RsltR() {
/*  930 */       return ResourceR.create();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ResourceL<ResourceR> createSrch02_RsltL() {
/*  939 */       return ResourceL.createFC_FCBJL0100_Resource(ResourceR.class);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ResourceL<ResourceR> up0() {
/*  960 */       return this.up0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ResourceL<ResourceR> down0() {
/*  983 */       return this.down0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MCOperationInfo getOperationInfo() {
/*  990 */       return MCResource_FW_A.this.info;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract class Srch03
/*      */     extends MCOperation
/*      */   {
/*      */     public static final String OPERATION_ID = "Srch03";
/*      */ 
/*      */     
/*      */     private final ResourceL<ResourceR> up0;
/*      */ 
/*      */     
/*      */     private final ResourceL<ResourceR> down0;
/*      */ 
/*      */ 
/*      */     
/*      */     public String getOperationID() {
/* 1010 */       return "Srch03";
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected Srch03() {
/* 1023 */       this.up0 = ResourceL.createFC_FCBJL0100_Resource(ResourceR.class);
/* 1024 */       this.down0 = ResourceL.createFC_FCBJL0100_Resource(ResourceR.class);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void mapUpContainers(String key) {
/* 1038 */       super.mapUpContainers(key);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void mapDownContainers(String key) {
/* 1046 */       super.mapDownContainers(key);
/*      */     }
/*      */     
/*      */     public MCContainer up(int i) {
/* 1050 */       if (i == 0) return (MCContainer)up0(); 
/* 1051 */       return null;
/*      */     }
/*      */     
/*      */     public MCContainer down(int i) {
/* 1055 */       if (i == 0) return (MCContainer)down0(); 
/* 1056 */       return null;
/*      */     }
/*      */     
/*      */     public void exec() {
/* 1060 */       clear();
/* 1061 */       MCLogicUtil.invoke((MCLogic)MCResource_FW_A.this);
/*      */     }
/*      */     
/*      */     protected void clear() {
/* 1065 */       down0().clear();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ResourceR createSrch03_CndR() {
/* 1073 */       return ResourceR.create();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ResourceL<ResourceR> createSrch03_CndL() {
/* 1082 */       return ResourceL.createFC_FCBJL0100_Resource(ResourceR.class);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ResourceR createSrch03_RsltR() {
/* 1091 */       return ResourceR.create();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ResourceL<ResourceR> createSrch03_RsltL() {
/* 1100 */       return ResourceL.createFC_FCBJL0100_Resource(ResourceR.class);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ResourceL<ResourceR> up0() {
/* 1122 */       return this.up0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ResourceL<ResourceR> down0() {
/* 1145 */       return this.down0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MCOperationInfo getOperationInfo() {
/* 1152 */       return MCResource_FW_A.this.info;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract class Imp01
/*      */     extends MCOperation
/*      */   {
/*      */     public static final String OPERATION_ID = "Imp01";
/*      */ 
/*      */     
/*      */     private final ResourceL<ResourceR> up0;
/*      */ 
/*      */     
/*      */     private final ResourceL<ResourceR> up1;
/*      */ 
/*      */ 
/*      */     
/*      */     public String getOperationID() {
/* 1172 */       return "Imp01";
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected Imp01() {
/* 1185 */       this.up0 = ResourceL.createFC_FCBJL0100_Resource(ResourceR.class);
/* 1186 */       this.up1 = ResourceL.createFC_FCBJL0100_Resource(ResourceR.class);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void mapUpContainers(String key) {
/* 1200 */       super.mapUpContainers(key);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void mapDownContainers(String key) {
/* 1208 */       super.mapDownContainers(key);
/*      */     }
/*      */     
/*      */     public MCContainer up(int i) {
/* 1212 */       if (i == 0) return (MCContainer)up0(); 
/* 1213 */       if (i == 1) return (MCContainer)up1(); 
/* 1214 */       return null;
/*      */     }
/*      */     
/*      */     public MCContainer down(int i) {
/* 1218 */       return null;
/*      */     }
/*      */     
/*      */     public void exec() {
/* 1222 */       clear();
/* 1223 */       MCLogicUtil.invoke((MCLogic)MCResource_FW_A.this);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void clear() {}
/*      */ 
/*      */ 
/*      */     
/*      */     public ResourceR createImp01_UserR() {
/* 1234 */       return ResourceR.create();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ResourceL<ResourceR> createImp01_UserL() {
/* 1243 */       return ResourceL.createFC_FCBJL0100_Resource(ResourceR.class);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ResourceR createImp01_DtlR() {
/* 1252 */       return ResourceR.create();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ResourceL<ResourceR> createImp01_DtlL() {
/* 1261 */       return ResourceL.createFC_FCBJL0100_Resource(ResourceR.class);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ResourceL<ResourceR> up0() {
/* 1282 */       return this.up0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ResourceL<ResourceR> up1() {
/* 1298 */       return this.up1;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MCOperationInfo getOperationInfo() {
/* 1306 */       return MCResource_FW_A.this.info;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract class Exp01
/*      */     extends MCOperation
/*      */   {
/*      */     public static final String OPERATION_ID = "Exp01";
/*      */ 
/*      */     
/*      */     private final ResourceR up0;
/*      */ 
/*      */     
/*      */     private final ResourceL<ResourceR> down0;
/*      */ 
/*      */ 
/*      */     
/*      */     public String getOperationID() {
/* 1326 */       return "Exp01";
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected Exp01() {
/* 1339 */       this.up0 = ResourceR.create();
/* 1340 */       this.down0 = ResourceL.createFC_FCBJL0100_Resource(ResourceR.class);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void mapUpContainers(String key) {
/* 1354 */       super.mapUpContainers(key);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void mapDownContainers(String key) {
/* 1362 */       super.mapDownContainers(key);
/*      */     }
/*      */     
/*      */     public MCContainer up(int i) {
/* 1366 */       if (i == 0) return (MCContainer)up0(); 
/* 1367 */       return null;
/*      */     }
/*      */     
/*      */     public MCContainer down(int i) {
/* 1371 */       if (i == 0) return (MCContainer)down0(); 
/* 1372 */       return null;
/*      */     }
/*      */     
/*      */     public void exec() {
/* 1376 */       clear();
/* 1377 */       MCLogicUtil.invoke((MCLogic)MCResource_FW_A.this);
/*      */     }
/*      */     
/*      */     protected void clear() {
/* 1381 */       down0().clear();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ResourceR createExp01_CndR() {
/* 1389 */       return ResourceR.create();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ResourceR createExp01_RsltR() {
/* 1398 */       return ResourceR.create();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ResourceL<ResourceR> createExp01_RsltL() {
/* 1407 */       return ResourceL.createFC_FCBJL0100_Resource(ResourceR.class);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ResourceR up0() {
/* 1428 */       return this.up0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ResourceL<ResourceR> down0() {
/* 1445 */       return this.down0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MCOperationInfo getOperationInfo() {
/* 1452 */       return MCResource_FW_A.this.info;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\resource\ctrl\MCResource_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */