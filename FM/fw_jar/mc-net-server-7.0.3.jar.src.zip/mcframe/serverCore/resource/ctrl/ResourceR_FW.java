/*     */ package mcframe.serverCore.resource.ctrl;
/*     */ public abstract class ResourceR_FW extends ResourceR_FW_A implements MCOptimizedResourceRow { private String optimizedResourceKey; private String optimizedResourceName; public String UserID() {
/*     */     return user_id();
/*     */   } public void UserID(String value) {
/*     */     user_id(value);
/*     */   } public String Locale() {
/*     */     return locale();
/*     */   }
/*     */   public void Locale(String value) {
/*     */     locale(value);
/*     */   }
/*     */   public String Name() {
/*     */     return name();
/*     */   }
/*     */   public void Name(String value) {
/*     */     name(value);
/*     */   }
/*     */   public String Key() {
/*     */     return res_key();
/*     */   }
/*     */   public void Key(String value) {
/*     */     res_key(value);
/*     */   }
/*  24 */   protected ResourceR_FW(MCRow.ConstMetaList<? extends ResourceR> metas) { super(metas);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 127 */     this.optimizedResourceKey = null;
/*     */     
/* 129 */     this.optimizedResourceName = null; }
/*     */   public String Value() { return res_val(); }
/*     */   public void Value(String value) { res_val(value); } public void optimizedResourceInit() { String resourceName;
/* 132 */     if (this.optimizedResourceKey != null && this.optimizedResourceName != null) {
/*     */       return;
/*     */     }
/* 135 */     String key = res_key();
/*     */     
/* 137 */     if (MCStringUtil.isNull(key)) {
/* 138 */       key = name_key();
/* 139 */       String[] keys = MCResource.splitKey(key, 2);
/* 140 */       resourceName = keys[0];
/*     */     } else {
/*     */       
/* 143 */       resourceName = name();
/*     */     } 
/* 145 */     this.optimizedResourceKey = key;
/* 146 */     this.optimizedResourceName = resourceName; } public String CoCD() { return co_cd(); }
/*     */   public void CoCD(String value) { co_cd(value); }
/*     */   public String ExtAttr1() { return ext_attr1(); }
/*     */   public void ExtAttr1(String value) { ext_attr1(value); }
/*     */   public String ExtAttr2() { return ext_attr2(); }
/* 151 */   public String getOptimizedResourceKey() { optimizedResourceInit();
/* 152 */     return this.optimizedResourceKey; } public void ExtAttr2(String value) { ext_attr2(value); }
/*     */   public String ExtAttr3() { return ext_attr3(); }
/*     */   public void ExtAttr3(String value) { ext_attr3(value); }
/*     */   public String PgmID() { return pgm_id(); }
/*     */   public void PgmID(String value) { pgm_id(value); }
/* 157 */   public String getOptimizedResourceName() { optimizedResourceInit();
/* 158 */     return this.optimizedResourceName; }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOptimizedMark(String name, String newKey) {
/* 163 */     if (MCStringUtil.isNull(name)) {
/* 164 */       name_key("$" + newKey);
/*     */     } else {
/*     */       
/* 167 */       name("$" + name);
/* 168 */       res_key(newKey);
/*     */     } 
/*     */   } }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\resource\ctrl\ResourceR_FW.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */