/*     */ package mcframe.serverCore.resource.ctrl;
/*     */ 
/*     */ import java.util.List;
/*     */ import mcframe.commonCore.container.MCConstList;
/*     */ import mcframe.commonCore.container.MCGroupByPolicy;
/*     */ import mcframe.commonCore.container.MCIndexKey;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.container.MCRowMatcher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class ResourceL_FW_A<E extends ResourceR>
/*     */   extends MCConstList<E>
/*     */ {
/*     */   protected ResourceL_FW_A(Class<E> rowc) {
/*  26 */     super(rowc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ResourceL_FW_A(Class<E> rowc, int initCapacity) {
/*  33 */     super(rowc, initCapacity);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceL<E> clone() {
/*  40 */     return (ResourceL<E>)super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceL<E> shallowClone() {
/*  47 */     return (ResourceL<E>)super.shallowClone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceL<E> createInstance() {
/*  54 */     return (ResourceL<E>)super.createInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceL<E> groupBy(String... names) {
/*  61 */     return (ResourceL<E>)super.groupBy(names);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceL<E> groupBy(MCGroupByPolicy policy) {
/*  68 */     return (ResourceL<E>)super.groupBy(policy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceL<E>[] groupList(String... names) {
/*  75 */     return (ResourceL<E>[])super.groupList(names);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceL<E> statusChangedList() {
/*  82 */     return (ResourceL<E>)super.statusChangedList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceL<E> subList(int fromIndex, int toIndex) {
/*  89 */     return (ResourceL<E>)super.subList(fromIndex, toIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceL<E> subList(MCIndexKey idxkey, Comparable... vals) {
/*  96 */     return (ResourceL<E>)super.subList(idxkey, vals);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceL<E> subList(MCRow.Status... status) {
/* 103 */     return (ResourceL<E>)super.subList(status);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceL<E> subList(String key, Comparable val) {
/* 110 */     return (ResourceL<E>)super.subList(key, val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceL<E> subList(String[] keys, Comparable[] vals) {
/* 117 */     return (ResourceL<E>)super.subList(keys, vals);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceL<E> subList(MCRowMatcher<E> matcher) {
/* 124 */     return (ResourceL<E>)super.subList(matcher);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceL<E> subList(MCRowMatcher<E> matcher, MCIndexKey serial) {
/* 131 */     return (ResourceL<E>)super.subList(matcher, serial);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceL<E> subList(String[] cols, MCRow valrow) {
/* 138 */     return (ResourceL<E>)super.subList(cols, valrow);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceL<E> subList(String[] owncols, MCRow valrow, String[] valcols) {
/* 145 */     return (ResourceL<E>)super.subList(owncols, valrow, valcols);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\resource\ctrl\ResourceL_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */