/*     */ package mcframe.serverCore.resource.ctrl;
/*     */ 
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.notice.MCMessage;
/*     */ import mcframe.commonCore.notice.MCMessageList;
/*     */ import mcframe.commonCore.resource.ctrl.MCOptimizedResourceManager;
/*     */ import mcframe.serverCore.dbc.FCM_RESOURCE_R;
/*     */ import mcframe.serverCore.queryapi.IFMCFMSQL;
/*     */ import mcframe.serverCore.queryapi.IFMCSQL;
/*     */ import mcframe.serverCore.queryapi.MCDBContainer;
/*     */ import mcframe.serverCore.queryapi.MCQueryApiBuilder;
/*     */ import mcframe.serverCore.resource.MCConfig;
/*     */ import mcframe.serverCore.resource.MCConst;
/*     */ import mcframe.serverCore.util.MCDBUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MCResource_FW
/*     */   extends MCResource_FW_A
/*     */ {
/*  46 */   private static boolean isOptimizedPersonalResource = MCConfig.server
/*  47 */     .getBoolean("net.personalResource.optimization", true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class Upd01
/*     */     extends MCResource_FW_A.Upd01
/*     */   {
/*     */     protected void call() {
/*  58 */       MCList<FCM_RESOURCE_R> ins = MCList.create(FCM_RESOURCE_R.class);
/*  59 */       MCList<FCM_RESOURCE_R> upd = MCList.create(FCM_RESOURCE_R.class);
/*  60 */       MCList<FCM_RESOURCE_R> del = MCList.create(FCM_RESOURCE_R.class);
/*     */       
/*  62 */       for (ResourceR o : up0()) {
/*  63 */         switch (o.getStatus()) {
/*     */           case null:
/*  65 */             MCResource_FW.this.setPgmId(o);
/*  66 */             ins.add((MCRow)o);
/*     */           
/*     */           case MODIFY:
/*  69 */             MCResource_FW.this.setPgmId(o);
/*  70 */             upd.add((MCRow)o);
/*     */           
/*     */           case DELETE:
/*  73 */             del.add((MCRow)o);
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       } 
/*  80 */       FCM_RESOURCE_R dbc = FCM_RESOURCE_R.create("M");
/*  81 */       if (del.size() > 0) {
/*  82 */         IFMCSQL.MCPredicate where = IFMCSQL.value(0).eq(IFMCSQL.value(0))
/*  83 */           .and(dbc.user_id.eq(IFMCSQL.bind("user_id")))
/*  84 */           .and(getIsNullCndDel((IFMCSQL.MCPermColumn)dbc.co_cd, "co_cd"))
/*  85 */           .and(getIsNullCndDel((IFMCSQL.MCPermColumn)dbc.ext_attr1, "ext_attr1"))
/*  86 */           .and(getIsNullCndDel((IFMCSQL.MCPermColumn)dbc.ext_attr2, "ext_attr2"))
/*  87 */           .and(getIsNullCndDel((IFMCSQL.MCPermColumn)dbc.ext_attr3, "ext_attr3"))
/*  88 */           .and(getIsNullCndDel((IFMCSQL.MCPermColumn)dbc.locale, "locale"))
/*  89 */           .and(dbc.name.eq(IFMCSQL.bind("name")))
/*  90 */           .and(dbc.res_key.eq(IFMCSQL.bind("res_key")));
/*  91 */         MCDBUtil.execDbDelete("FC_MCResource_FW_Upd01_call_1", (MCDBContainer)dbc, where, del);
/*     */       } 
/*  93 */       if (ins.size() > 0) {
/*     */         try {
/*  95 */           MCQueryApiBuilder builder = MCQueryApiBuilder.create((MCDBContainer)dbc);
/*  96 */           MCDBUtil.dbInsert("FC_MCResource_FW_Upd01_call_2", ins, builder);
/*  97 */         } catch (MCException e) {
/*  98 */           if (Core_Msg_FW_A.FCBCC0136.equals(e.getID())) {
/*  99 */             throw new MCException(Core_Msg_FW_A.FCBJC0083, new Object[] { e });
/*     */           }
/*     */         } 
/*     */       }
/* 103 */       if (upd.size() > 0) {
/* 104 */         IFMCSQL.MCPredicate where = IFMCSQL.value(0).eq(IFMCSQL.value(0))
/* 105 */           .and(dbc.user_id.eq(IFMCSQL.bindEx("user_id")))
/* 106 */           .and(getIsNullCndUpd((IFMCSQL.MCPermColumn)dbc.co_cd, "co_cd"))
/* 107 */           .and(getIsNullCndUpd((IFMCSQL.MCPermColumn)dbc.ext_attr1, "ext_attr1"))
/* 108 */           .and(getIsNullCndUpd((IFMCSQL.MCPermColumn)dbc.ext_attr2, "ext_attr2"))
/* 109 */           .and(getIsNullCndUpd((IFMCSQL.MCPermColumn)dbc.ext_attr3, "ext_attr3"))
/* 110 */           .and(getIsNullCndUpd((IFMCSQL.MCPermColumn)dbc.locale, "locale"))
/* 111 */           .and(dbc.name.eq(IFMCSQL.bindEx("name")))
/* 112 */           .and(dbc.res_key.eq(IFMCSQL.bindEx("res_key")));
/* 113 */         MCDBUtil.execDbUpdate("FC_MCResource_FW_Upd01_call_3", (MCDBContainer)dbc, upd, where, new IFMCSQL.MCPermColumn[0]);
/*     */       } 
/*     */     }
/*     */     
/*     */     private IFMCSQL.MCPredicate getIsNullCndDel(IFMCSQL.MCPermColumn name, String bind) {
/* 118 */       return MCQueryApiBuilder.makeIsNull(name)
/* 119 */         .and(IFMCSQL.bind(bind).isNull())
/* 120 */         .or(MCQueryApiBuilder.makeEq(name, (IFMCSQL.MCExpr)IFMCSQL.bind(bind)));
/*     */     }
/*     */     
/*     */     private IFMCSQL.MCPredicate getIsNullCndUpd(IFMCSQL.MCPermColumn name, String bind) {
/* 124 */       return MCQueryApiBuilder.makeIsNull(name)
/* 125 */         .and(IFMCSQL.bindEx(bind).isNull())
/* 126 */         .or(MCQueryApiBuilder.makeEq(name, (IFMCSQL.MCExpr)IFMCSQL.bindEx(bind)));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class Srch01
/*     */     extends MCResource_FW_A.Srch01
/*     */   {
/*     */     protected void call() {
/* 139 */       ResourceR cnd = up0();
/* 140 */       ResourceL<ResourceR> rslt = down0();
/*     */       
/* 142 */       MCQueryApiBuilder builder = MCQueryApiBuilder.create((MCDBContainer)cnd);
/* 143 */       builder.setSelect(new IFMCSQL.MCColumn[] { (IFMCSQL.MCColumn)cnd.res_key, (IFMCSQL.MCColumn)cnd.res_val });
/* 144 */       builder.addWhereWithAnd(cnd.user_id.eq(IFMCSQL.bind("1")), new Comparable[] { cnd.user_id() });
/* 145 */       builder.addWhereWithAnd(MCResource_FW.this.getCnd((IFMCSQL.MCPermColumn)cnd.locale, "1", cnd.locale()), new Comparable[] { cnd.locale() });
/* 146 */       builder.addWhereWithAnd(MCResource_FW.this.getCnd((IFMCSQL.MCPermColumn)cnd.name, "1"), new Comparable[] { cnd.name() });
/* 147 */       builder.addWhereWithAnd(MCResource_FW.this.getCnd((IFMCSQL.MCPermColumn)cnd.pgm_id, "1"), new Comparable[] { "ALL" });
/*     */ 
/*     */       
/* 150 */       if (MCDBUtil.dbSelect("FC_MCResource_FW_Srch01_call", (MCList)rslt, builder) > 0 && MCResource_FW.isOptimizedPersonalResource)
/*     */       {
/* 152 */         MCOptimizedResourceManager.optimizeResourceKey((MCList)rslt);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class Srch02
/*     */     extends MCResource_FW_A.Srch02
/*     */   {
/*     */     protected void call() {
/* 166 */       ResourceL<ResourceR> resourceL1 = up0();
/*     */       
/* 168 */       ResourceL<ResourceR> rslt = down0();
/* 169 */       FCM_RESOURCE_R dbc = FCM_RESOURCE_R.create("M");
/* 170 */       MCQueryApiBuilder builder = MCQueryApiBuilder.create((MCDBContainer)dbc);
/* 171 */       builder.setSelect(new IFMCSQL.MCColumn[] { (IFMCSQL.MCColumn)dbc.user_id, (IFMCSQL.MCColumn)dbc.co_cd, (IFMCSQL.MCColumn)dbc.ext_attr1, (IFMCSQL.MCColumn)dbc.ext_attr2, (IFMCSQL.MCColumn)dbc.ext_attr3, (IFMCSQL.MCColumn)dbc.name, 
/* 172 */             (IFMCSQL.MCColumn)dbc.res_key, (IFMCSQL.MCColumn)dbc.res_val });
/*     */       
/* 174 */       for (int i = 0; i < resourceL1.size(); i++) {
/* 175 */         ResourceR cnd = (ResourceR)resourceL1.get(i);
/* 176 */         Comparable[] values = { cnd.user_id(), cnd.co_cd(), cnd.ext_attr1(), cnd.ext_attr2(), cnd.ext_attr3(), cnd.locale(), "ALL" };
/* 177 */         IFMCSQL.MCPredicate where = dbc.user_id.eq(IFMCSQL.bind("1"))
/* 178 */           .and(MCResource_FW.this.getCnd((IFMCSQL.MCPermColumn)dbc.co_cd, "2", cnd.co_cd()))
/* 179 */           .and(MCResource_FW.this.getCnd((IFMCSQL.MCPermColumn)dbc.ext_attr1, "3", cnd.ext_attr1()))
/* 180 */           .and(MCResource_FW.this.getCnd((IFMCSQL.MCPermColumn)dbc.ext_attr2, "4", cnd.ext_attr2()))
/* 181 */           .and(MCResource_FW.this.getCnd((IFMCSQL.MCPermColumn)dbc.ext_attr3, "5", cnd.ext_attr3()))
/* 182 */           .and(MCResource_FW.this.getCnd((IFMCSQL.MCPermColumn)dbc.locale, "6", cnd.locale()))
/* 183 */           .and(MCResource_FW.this.getCnd((IFMCSQL.MCPermColumn)dbc.pgm_id, "7", "ALL"));
/* 184 */         if (i == 0) {
/* 185 */           builder.addWhereWithAnd(where, values);
/*     */         } else {
/*     */           
/* 188 */           builder.addWhereWithOr(where, values);
/*     */         } 
/*     */ 
/*     */         
/* 192 */         if ("?ALL".equals(cnd.user_id()) && cnd.name() == null) {
/* 193 */           MCResource_FW.this.addNotCnd(builder, (IFMCSQL.MCPermColumn)dbc.name, "MCSystemLocation");
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 198 */       if (MCDBUtil.dbSelect("FC_MCResource_FW_Srch02_call", (MCList)rslt, builder) > 0 && MCResource_FW.isOptimizedPersonalResource)
/*     */       {
/* 200 */         MCOptimizedResourceManager.optimizeResourceKey((MCList)rslt);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class Srch03
/*     */     extends MCResource_FW_A.Srch03
/*     */   {
/*     */     protected void call() {
/* 214 */       ResourceL<ResourceR> resourceL1 = up0();
/*     */       
/* 216 */       ResourceL<ResourceR> rslt = down0();
/* 217 */       FCM_RESOURCE_R dbc = FCM_RESOURCE_R.create("M");
/* 218 */       MCQueryApiBuilder builder = MCQueryApiBuilder.create((MCDBContainer)dbc);
/* 219 */       builder.setSelect(new IFMCSQL.MCColumn[] { (IFMCSQL.MCColumn)dbc.user_id, (IFMCSQL.MCColumn)dbc.co_cd, (IFMCSQL.MCColumn)dbc.ext_attr1, (IFMCSQL.MCColumn)dbc.ext_attr2, (IFMCSQL.MCColumn)dbc.ext_attr3, (IFMCSQL.MCColumn)dbc.name, 
/* 220 */             (IFMCSQL.MCColumn)dbc.res_key, (IFMCSQL.MCColumn)dbc.res_val });
/*     */       
/* 222 */       for (int i = 0; i < resourceL1.size(); i++) {
/* 223 */         ResourceR cnd = (ResourceR)resourceL1.get(i);
/* 224 */         Comparable[] values = { cnd.user_id(), cnd.co_cd(), cnd.ext_attr1(), cnd.ext_attr2(), 
/* 225 */             cnd.ext_attr3(), cnd.locale(), cnd.pgm_id() };
/* 226 */         IFMCSQL.MCPredicate where = dbc.user_id.eq(IFMCSQL.bind("1"))
/* 227 */           .and(MCResource_FW.this.getCnd((IFMCSQL.MCPermColumn)dbc.co_cd, "2", cnd.co_cd()))
/* 228 */           .and(MCResource_FW.this.getCnd((IFMCSQL.MCPermColumn)dbc.ext_attr1, "3", cnd.ext_attr1()))
/* 229 */           .and(MCResource_FW.this.getCnd((IFMCSQL.MCPermColumn)dbc.ext_attr2, "4", cnd.ext_attr2()))
/* 230 */           .and(MCResource_FW.this.getCnd((IFMCSQL.MCPermColumn)dbc.ext_attr3, "5", cnd.ext_attr3()))
/* 231 */           .and(MCResource_FW.this.getCnd((IFMCSQL.MCPermColumn)dbc.locale, "6", cnd.locale())
/* 232 */             .and(MCResource_FW.this.getCnd((IFMCSQL.MCPermColumn)dbc.pgm_id, "7", cnd.pgm_id())));
/*     */         
/* 234 */         if (i == 0) {
/* 235 */           builder.addWhereWithAnd(where, values);
/*     */         } else {
/*     */           
/* 238 */           builder.addWhereWithOr(where, values);
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 243 */       if (MCDBUtil.dbSelect("FC_MCResource_FW_Srch03_call", (MCList)rslt, builder) > 0 && MCResource_FW.isOptimizedPersonalResource)
/*     */       {
/* 245 */         MCOptimizedResourceManager.optimizeResourceKey((MCList)rslt);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class Imp01
/*     */     extends MCResource_FW_A.Imp01
/*     */   {
/*     */     protected void call() {
/* 259 */       ResourceL<ResourceR> hdr = up0();
/* 260 */       ResourceL<ResourceR> dtl = up1();
/*     */ 
/*     */       
/* 263 */       MCOptimizedResourceManager.deOptimizedResourceKey(true, (MCList)dtl);
/*     */ 
/*     */       
/* 266 */       FCM_RESOURCE_R dbc = FCM_RESOURCE_R.create("M");
/* 267 */       IFMCSQL.MCPredicate where = IFMCSQL.value(0).eq(IFMCSQL.value(0))
/* 268 */         .and(dbc.user_id.eq(IFMCSQL.bind("user_id")))
/* 269 */         .and(MCResource_FW.this.getIsNullCnd((IFMCSQL.MCPermColumn)dbc.co_cd, "co_cd"))
/* 270 */         .and(MCResource_FW.this.getIsNullCnd((IFMCSQL.MCPermColumn)dbc.ext_attr1, "ext_attr1"))
/* 271 */         .and(MCResource_FW.this.getIsNullCnd((IFMCSQL.MCPermColumn)dbc.ext_attr2, "ext_attr2"))
/* 272 */         .and(MCResource_FW.this.getIsNullCnd((IFMCSQL.MCPermColumn)dbc.ext_attr3, "ext_attr3"));
/* 273 */       MCDBUtil.execDbDelete("FC_MCResource_FW_Imp01_call_1", (MCDBContainer)dbc, where, (MCList)hdr);
/*     */       
/* 275 */       MCMessageList ml = new MCMessageList();
/* 276 */       for (ResourceR o : dtl) {
/* 277 */         String[] ka = MCConst.splitKey(o.name_key(), 2);
/* 278 */         if (ka.length != 2) {
/*     */           
/* 280 */           ml.add(new MCMessage(Core_Msg_FW_A.FCBJC0063, new Object[] { o.name_key() }));
/*     */           continue;
/*     */         } 
/* 283 */         o.name(ka[0]);
/* 284 */         o.res_key(ka[1]);
/*     */         
/* 286 */         MCResource_FW.this.setPgmId(o);
/*     */       } 
/*     */       
/* 289 */       if (ml.size() > 0) {
/*     */         
/* 291 */         MCException ex = new MCException(Core_Msg_FW_A.FCBJC0062, new Object[0]);
/* 292 */         ex.setCauseMessageList(ml);
/* 293 */         throw ex;
/*     */       } 
/*     */ 
/*     */       
/* 297 */       for (FCM_RESOURCE_R o : hdr) {
/* 298 */         dtl.setString("user_id", o.user_id());
/* 299 */         dtl.setString("co_cd", o.co_cd());
/* 300 */         dtl.setString("ext_attr1", o.ext_attr1());
/* 301 */         dtl.setString("ext_attr2", o.ext_attr2());
/* 302 */         dtl.setString("ext_attr3", o.ext_attr3());
/* 303 */         dtl.setString("locale", o.locale());
/* 304 */         MCQueryApiBuilder builder = MCQueryApiBuilder.create((MCDBContainer)dbc);
/* 305 */         MCDBUtil.dbInsert("FC_MCResource_FW_Imp01_call_2", (MCList)dtl, builder);
/*     */       } 
/*     */ 
/*     */       
/* 309 */       if (MCLog.isEnabled(Core_Msg_FW_A.FCBJC0064)) {
/* 310 */         StringBuilder sb = new StringBuilder();
/* 311 */         for (FCM_RESOURCE_R o : hdr) {
/* 312 */           sb.append("\n");
/* 313 */           sb.append(o.user_id());
/*     */         } 
/* 315 */         MCLog.write(Core_Msg_FW_A.FCBJC0064, new Object[] { sb });
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class Exp01
/*     */     extends MCResource_FW_A.Exp01
/*     */   {
/*     */     protected void call() {
/* 329 */       ResourceR cnd = up0();
/*     */       
/* 331 */       ResourceL<ResourceR> rslt = down0();
/* 332 */       MCQueryApiBuilder builder = MCQueryApiBuilder.create((MCDBContainer)cnd);
/* 333 */       builder.setSelect(new IFMCSQL.MCColumn[] { (IFMCSQL.MCColumn)cnd.name.concat((IFMCFMSQL.MCFMAGStringExpr)IFMCSQL.value(".")).concat((IFMCFMSQL.MCFMAGStringExpr)cnd.res_key).as("name_key") });
/* 334 */       builder.addSelect(new IFMCSQL.MCColumn[] { (IFMCSQL.MCColumn)cnd.res_val });
/*     */       
/* 336 */       builder.addWhereWithAnd(cnd.user_id.eq(IFMCSQL.bind("1")), new Comparable[] { cnd.user_id() });
/* 337 */       builder.addWhereWithAnd(MCResource_FW.this.getCnd((IFMCSQL.MCPermColumn)cnd.co_cd, "1", cnd.co_cd()), new Comparable[] { cnd.co_cd() });
/* 338 */       builder.addWhereWithAnd(MCResource_FW.this.getCnd((IFMCSQL.MCPermColumn)cnd.ext_attr1, "1", cnd.ext_attr1()), new Comparable[] { cnd.ext_attr1() });
/* 339 */       builder.addWhereWithAnd(MCResource_FW.this.getCnd((IFMCSQL.MCPermColumn)cnd.ext_attr2, "1", cnd.ext_attr2()), new Comparable[] { cnd.ext_attr2() });
/* 340 */       builder.addWhereWithAnd(MCResource_FW.this.getCnd((IFMCSQL.MCPermColumn)cnd.ext_attr3, "1", cnd.ext_attr3()), new Comparable[] { cnd.ext_attr3() });
/* 341 */       builder.addWhereWithAnd(MCResource_FW.this.getCnd((IFMCSQL.MCPermColumn)cnd.locale, "1", cnd.locale()), new Comparable[] { cnd.locale() });
/*     */ 
/*     */       
/* 344 */       if (MCDBUtil.dbSelect("FC_MCResource_FW_Exp01_call", (MCList)rslt, builder) > 0 && MCResource_FW.isOptimizedPersonalResource)
/*     */       {
/* 346 */         MCOptimizedResourceManager.optimizeResourceKey((MCList)rslt);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private IFMCSQL.MCPredicate getCnd(IFMCSQL.MCPermColumn name, String bind) {
/* 353 */     return MCQueryApiBuilder.makeEq(name, (IFMCSQL.MCExpr)IFMCSQL.bind(bind));
/*     */   }
/*     */   
/*     */   private IFMCSQL.MCPredicate getCnd(IFMCSQL.MCPermColumn name, String bind, String value) {
/* 357 */     if (value != null) {
/* 358 */       return getCnd(name, bind);
/*     */     }
/*     */     
/* 361 */     return MCQueryApiBuilder.makeIsNull(name);
/*     */   }
/*     */ 
/*     */   
/*     */   private void addNotCnd(MCQueryApiBuilder builder, IFMCSQL.MCPermColumn name, String value) {
/* 366 */     builder.addWhereWithAnd(MCQueryApiBuilder.makeNeq(name, (IFMCSQL.MCExpr)IFMCSQL.bind("1")), new Comparable[] { value });
/*     */   }
/*     */   
/*     */   private IFMCSQL.MCPredicate getIsNullCnd(IFMCSQL.MCPermColumn name, String bind) {
/* 370 */     return MCQueryApiBuilder.makeIsNull(name)
/* 371 */       .and(IFMCSQL.bind(bind).isNull())
/* 372 */       .or(MCQueryApiBuilder.makeEq(name, (IFMCSQL.MCExpr)IFMCSQL.bind(bind)));
/*     */   }
/*     */   
/*     */   protected void setPgmId(ResourceR data) {
/* 376 */     String k = data.res_key();
/* 377 */     String p = "ALL";
/* 378 */     if (k != null && k.startsWith("_0_SCR_")) {
/* 379 */       String[] a = MCConst.splitKey(k, -1);
/* 380 */       if (a.length >= 3) {
/* 381 */         data.pgm_id(MCConst.createKey(new String[] { a[1], a[2] }));
/*     */         return;
/*     */       } 
/*     */     } 
/* 385 */     data.pgm_id(p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class Del01
/*     */     extends MCResource_FW_A.Del01
/*     */   {
/*     */     protected void call() {
/* 395 */       FCM_RESOURCE_R dbc = FCM_RESOURCE_R.create("M");
/* 396 */       IFMCSQL.MCPredicate where = IFMCSQL.value(0).eq(IFMCSQL.value(0))
/* 397 */         .and(dbc.user_id.eq(IFMCSQL.bind("user_id")))
/* 398 */         .and(MCResource_FW.this.getIsNullCnd((IFMCSQL.MCPermColumn)dbc.co_cd, "co_cd"))
/* 399 */         .and(MCResource_FW.this.getIsNullCnd((IFMCSQL.MCPermColumn)dbc.ext_attr1, "ext_attr1"))
/* 400 */         .and(MCResource_FW.this.getIsNullCnd((IFMCSQL.MCPermColumn)dbc.ext_attr2, "ext_attr2"))
/* 401 */         .and(MCResource_FW.this.getIsNullCnd((IFMCSQL.MCPermColumn)dbc.ext_attr3, "ext_attr3"))
/* 402 */         .and(dbc.res_key.like((IFMCFMSQL.MCFMAGStringExpr)IFMCSQL.bind("res_key_prefix")));
/* 403 */       MCDBUtil.execDbDelete("FC_MCResource_FW_Del01_call", (MCDBContainer)dbc, where, (MCRow)up0());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\resource\ctrl\MCResource_FW.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */