/*    */ package mcframe.serverCore.resource.ctrl;
/*    */ 
/*    */ import mcframe.commonCore.container.MCGroupByPolicy;
/*    */ import mcframe.commonCore.container.MCIndexKey;
/*    */ import mcframe.commonCore.container.MCRow;
/*    */ import mcframe.commonCore.container.MCRowMatcher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ResourceL_FW<E extends ResourceR>
/*    */   extends ResourceL_FW_A<E>
/*    */ {
/*    */   protected ResourceL_FW(Class<E> rowc) {
/* 21 */     super(rowc);
/*    */   }
/*    */   
/*    */   protected ResourceL_FW(Class<E> rowc, int initCapacity) {
/* 25 */     super(rowc, initCapacity);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\resource\ctrl\ResourceL_FW.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */