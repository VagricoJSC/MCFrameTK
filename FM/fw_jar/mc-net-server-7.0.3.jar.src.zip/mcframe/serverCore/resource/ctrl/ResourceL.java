/*     */ package mcframe.serverCore.resource.ctrl;
/*     */ 
/*     */ import mcframe.commonCore.annotation.EI;
/*     */ import mcframe.commonCore.container.MCGroupByPolicy;
/*     */ import mcframe.commonCore.container.MCIndexKey;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.container.MCRowMatcher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @EI
/*     */ public class ResourceL<E extends ResourceR>
/*     */   extends ResourceL_FW<E>
/*     */ {
/*     */   public static <T extends ResourceR> ResourceL<T> createFC_FCBJL0100_Resource(Class<T> clazz) {
/* 134 */     ResourceL<T> ls = new ResourceL<>(clazz);
/* 135 */     return ls;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends ResourceR> ResourceL<T> createFC_FCBJL0100_Resource(Class<T> clazz, int initCapacity) {
/* 145 */     ResourceL<T> ls = new ResourceL<>(clazz, initCapacity);
/* 146 */     return ls;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends ResourceR> ResourceL<T> createFC_FCBJL0100_ResourceByName(Class<T> clazz, MCList<? extends MCRow> proto) {
/* 157 */     ResourceL<T> ls = createFC_FCBJL0100_Resource(clazz);
/* 158 */     copyByName((MCList)ls, proto);
/* 159 */     return ls;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ResourceL(Class<E> rowc) {
/* 167 */     super(rowc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ResourceL(Class<E> rowc, int initCapacity) {
/* 174 */     super(rowc, initCapacity);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\resource\ctrl\ResourceL.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */