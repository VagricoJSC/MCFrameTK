/*     */ package mcframe.serverCore.resource.ctrl;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.commonCore.container.MCExtMap;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ import mcframe.serverCore.dbc.FCM_RESOURCE_R;
/*     */ import mcframe.serverCore.queryapi.MCDBContainer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class ResourceR_FW_A
/*     */   extends FCM_RESOURCE_R
/*     */ {
/*     */   public static final String $name_key = "name_key";
/*     */   public static final String $res_key_prefix = "res_key_prefix";
/*  34 */   public static final MCMeta name_key_META = createStringMeta("name_key");
/*  35 */   public static final MCMeta res_key_prefix_META = createStringMeta("res_key_prefix");
/*     */   
/*  37 */   protected static final MCRow.ConstMetaList<ResourceR> constMetas = new MCRow.ConstMetaList(
/*  38 */       FCM_RESOURCE_R.constMetas, 
/*  39 */       new MCMeta[] {
/*  40 */         name_key_META, 
/*  41 */         res_key_prefix_META
/*     */       },
/*  43 */       new String[][] { {}, {} });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   protected static final MCExtMap EXTMAP = new MCExtMap(
/*  56 */       null, new MCExtMap.Entry[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] colnames() {
/*  68 */     return constMetas.toNameArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMeta[] colmetas() {
/*  80 */     return constMetas.toMetaArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  86 */   private static final int offset = constMetas.offset();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getExtMap(String aGroup) {
/*  92 */     if (aGroup == null) return null; 
/*  93 */     return (Map<String, String>)EXTMAP.get(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getKeys(String aGroup) {
/* 100 */     if (aGroup == null) return null; 
/* 101 */     return EXTMAP.getKeyList(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExtGroups() {
/* 108 */     Set<String> ret = EXTMAP.keySet();
/* 109 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ResourceR_FW_A(MCRow.ConstMetaList<? extends ResourceR> metas) {
/* 116 */     super(metas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceR clone() {
/* 123 */     return (ResourceR)super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceR createInstance() {
/* 130 */     return (ResourceR)super.createInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResourceR getValues(String... names) {
/* 137 */     return (ResourceR)super.getValues(names);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireValueChanged(String column, Comparable<?> newvalue, Comparable<?> oldvalue) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String name_key() {
/* 149 */     return getConstString(offset + 0, "name_key");
/*     */   }
/*     */   
/*     */   public void name_key(String value) {
/* 153 */     setConstString(offset + 0, "name_key", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String res_key_prefix() {
/* 158 */     return getConstString(offset + 1, "res_key_prefix");
/*     */   }
/*     */   
/*     */   public void res_key_prefix(String value) {
/* 162 */     setConstString(offset + 1, "res_key_prefix", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString(String name) {
/* 167 */     if ("name_key".equalsIgnoreCase(name)) {
/* 168 */       return name_key();
/*     */     }
/* 170 */     if ("res_key_prefix".equalsIgnoreCase(name)) {
/* 171 */       return res_key_prefix();
/*     */     }
/* 173 */     return super.getString(name);
/*     */   }
/*     */   
/*     */   public String getStringNE(String name) {
/* 177 */     if ("name_key".equalsIgnoreCase(name)) {
/* 178 */       return name_key();
/*     */     }
/* 180 */     if ("res_key_prefix".equalsIgnoreCase(name)) {
/* 181 */       return res_key_prefix();
/*     */     }
/* 183 */     return super.getStringNE(name);
/*     */   }
/*     */   
/*     */   public void setString(String name, String value) {
/* 187 */     if ("name_key".equalsIgnoreCase(name)) {
/* 188 */       name_key(value);
/*     */       return;
/*     */     } 
/* 191 */     if ("res_key_prefix".equalsIgnoreCase(name)) {
/* 192 */       res_key_prefix(value);
/*     */       return;
/*     */     } 
/* 195 */     super.setString(name, value);
/*     */   }
/*     */   
/*     */   public void setStringNE(String name, String value) {
/* 199 */     if ("name_key".equalsIgnoreCase(name)) {
/* 200 */       name_key(value);
/*     */       return;
/*     */     } 
/* 203 */     if ("res_key_prefix".equalsIgnoreCase(name)) {
/* 204 */       res_key_prefix(value);
/*     */       return;
/*     */     } 
/* 207 */     super.setStringNE(name, value);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\resource\ctrl\ResourceR_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */