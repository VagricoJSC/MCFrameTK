/*     */ package mcframe.serverCore.resource.ctrl;
/*     */ 
/*     */ import mcframe.commonCore.param.MCBlockDef;
/*     */ import mcframe.commonCore.param.MCContainerDef;
/*     */ import mcframe.commonCore.param.MCDef;
/*     */ import mcframe.commonCore.param.MCGeneralContainerDef;
/*     */ import mcframe.commonCore.param.MCItemDef;
/*     */ import mcframe.commonCore.param.MCOperationInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PDef_FW_A
/*     */   extends MCDef
/*     */ {
/*     */   public MCContainerDef getCustomDef(String id) {
/*  22 */     if (id == null) {
/*  23 */       return null;
/*     */     }
/*     */     
/*  26 */     if (id.equals("FC.FCBJL0100.Upd01.UP.BLOCK0")) {
/*  27 */       return FC_FCBJL0100_Upd01_UP_BLOCK0();
/*     */     }
/*  29 */     if (id.equals("FC.FCBJL0100.Del01.UP.BLOCK0")) {
/*  30 */       return FC_FCBJL0100_Del01_UP_BLOCK0();
/*     */     }
/*  32 */     if (id.equals("FC.FCBJL0100.Srch01.UP.BLOCK0")) {
/*  33 */       return FC_FCBJL0100_Srch01_UP_BLOCK0();
/*     */     }
/*  35 */     if (id.equals("FC.FCBJL0100.Srch01.DOWN.BLOCK0")) {
/*  36 */       return FC_FCBJL0100_Srch01_DOWN_BLOCK0();
/*     */     }
/*  38 */     if (id.equals("FC.FCBJL0100.Srch02.UP.BLOCK0")) {
/*  39 */       return FC_FCBJL0100_Srch02_UP_BLOCK0();
/*     */     }
/*  41 */     if (id.equals("FC.FCBJL0100.Srch02.DOWN.BLOCK0")) {
/*  42 */       return FC_FCBJL0100_Srch02_DOWN_BLOCK0();
/*     */     }
/*  44 */     if (id.equals("FC.FCBJL0100.Srch03.UP.BLOCK0")) {
/*  45 */       return FC_FCBJL0100_Srch03_UP_BLOCK0();
/*     */     }
/*  47 */     if (id.equals("FC.FCBJL0100.Srch03.DOWN.BLOCK0")) {
/*  48 */       return FC_FCBJL0100_Srch03_DOWN_BLOCK0();
/*     */     }
/*  50 */     if (id.equals("FC.FCBJL0100.Imp01.UP.BLOCK0")) {
/*  51 */       return FC_FCBJL0100_Imp01_UP_BLOCK0();
/*     */     }
/*  53 */     if (id.equals("FC.FCBJL0100.Imp01.UP.BLOCK1")) {
/*  54 */       return FC_FCBJL0100_Imp01_UP_BLOCK1();
/*     */     }
/*  56 */     if (id.equals("FC.FCBJL0100.Exp01.UP.BLOCK0")) {
/*  57 */       return FC_FCBJL0100_Exp01_UP_BLOCK0();
/*     */     }
/*  59 */     if (id.equals("FC.FCBJL0100.Exp01.DOWN.BLOCK0")) {
/*  60 */       return FC_FCBJL0100_Exp01_DOWN_BLOCK0();
/*     */     }
/*     */ 
/*     */     
/*  64 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   static final MCOperationInfo FC_FCBJL0100_Upd01_INFO = new MCOperationInfo("FC", "FCBJL0100", "Upd01", "000000", new PDef());
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBJL0100_Upd01_UP_BLOCK0() {
/*  74 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBJL0100", "Upd01", 
/*  75 */         new MCItemDef[] {
/*  76 */           MCItemDef.create("user_id", true, "user_id"), 
/*  77 */           MCItemDef.create("co_cd", "co_cd"), 
/*  78 */           MCItemDef.create("ext_attr1", "ext_attr1"), 
/*  79 */           MCItemDef.create("ext_attr2", "ext_attr2"), 
/*  80 */           MCItemDef.create("ext_attr3", "ext_attr3"), 
/*  81 */           MCItemDef.create("locale", "locale"), 
/*  82 */           MCItemDef.create("name", true, "name"), 
/*  83 */           MCItemDef.create("res_key", true, "res_key"), 
/*  84 */           MCItemDef.create("res_val", "res_val")
/*     */ 
/*     */         
/*  87 */         }MCBlockDef.create("Upd01_Dtl"));
/*     */   }
/*     */ 
/*     */   
/*  91 */   static final MCOperationInfo FC_FCBJL0100_Del01_INFO = new MCOperationInfo("FC", "FCBJL0100", "Del01", "000000", new PDef());
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBJL0100_Del01_UP_BLOCK0() {
/*  95 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBJL0100", "Del01", 
/*  96 */         new MCItemDef[] {
/*  97 */           MCItemDef.create("user_id", true, "user_id"), 
/*  98 */           MCItemDef.create("co_cd", "co_cd"), 
/*  99 */           MCItemDef.create("ext_attr1", "ext_attr1"), 
/* 100 */           MCItemDef.create("ext_attr2", "ext_attr2"), 
/* 101 */           MCItemDef.create("ext_attr3", "ext_attr3"), 
/* 102 */           MCItemDef.create("locale", "locale"), 
/* 103 */           MCItemDef.create("name", true, "name"), 
/* 104 */           MCItemDef.create("res_key_prefix", true, "res_key_prefix")
/*     */ 
/*     */         
/* 107 */         }MCBlockDef.create("Del01_Hdr"));
/*     */   }
/*     */ 
/*     */   
/* 111 */   static final MCOperationInfo FC_FCBJL0100_Srch01_INFO = new MCOperationInfo("FC", "FCBJL0100", "Srch01", "000000", new PDef());
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBJL0100_Srch01_UP_BLOCK0() {
/* 115 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBJL0100", "Srch01", 
/* 116 */         new MCItemDef[] {
/* 117 */           MCItemDef.create("user_id", true, "user_id"), 
/* 118 */           MCItemDef.create("locale", "locale"), 
/* 119 */           MCItemDef.create("name", true, "name")
/*     */ 
/*     */         
/* 122 */         }MCBlockDef.create("Srch01_Cnd"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBJL0100_Srch01_DOWN_BLOCK0() {
/* 129 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBJL0100", "Srch01", 
/* 130 */         new MCItemDef[] {
/* 131 */           MCItemDef.create("res_key", true, "res_key"), 
/* 132 */           MCItemDef.create("res_val", "res_val")
/*     */ 
/*     */         
/* 135 */         }MCBlockDef.create("Srch01_Rslt"));
/*     */   }
/*     */ 
/*     */   
/* 139 */   static final MCOperationInfo FC_FCBJL0100_Srch02_INFO = new MCOperationInfo("FC", "FCBJL0100", "Srch02", "000000", new PDef());
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBJL0100_Srch02_UP_BLOCK0() {
/* 143 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBJL0100", "Srch02", 
/* 144 */         new MCItemDef[] {
/* 145 */           MCItemDef.create("user_id", true, "user_id"), 
/* 146 */           MCItemDef.create("co_cd", "co_cd"), 
/* 147 */           MCItemDef.create("ext_attr1", "ext_attr1"), 
/* 148 */           MCItemDef.create("ext_attr2", "ext_attr2"), 
/* 149 */           MCItemDef.create("ext_attr3", "ext_attr3"), 
/* 150 */           MCItemDef.create("locale", "locale")
/*     */ 
/*     */         
/* 153 */         }MCBlockDef.create("Srch02_Cnd"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBJL0100_Srch02_DOWN_BLOCK0() {
/* 160 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBJL0100", "Srch02", 
/* 161 */         new MCItemDef[] {
/* 162 */           MCItemDef.create("user_id", true, "user_id"), 
/* 163 */           MCItemDef.create("co_cd", "co_cd"), 
/* 164 */           MCItemDef.create("ext_attr1", "ext_attr1"), 
/* 165 */           MCItemDef.create("ext_attr2", "ext_attr2"), 
/* 166 */           MCItemDef.create("ext_attr3", "ext_attr3"), 
/* 167 */           MCItemDef.create("name", true, "name"), 
/* 168 */           MCItemDef.create("res_key", true, "res_key"), 
/* 169 */           MCItemDef.create("res_val", "res_val")
/*     */ 
/*     */         
/* 172 */         }MCBlockDef.create("Srch02_Rslt"));
/*     */   }
/*     */ 
/*     */   
/* 176 */   static final MCOperationInfo FC_FCBJL0100_Srch03_INFO = new MCOperationInfo("FC", "FCBJL0100", "Srch03", "000000", new PDef());
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBJL0100_Srch03_UP_BLOCK0() {
/* 180 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBJL0100", "Srch03", 
/* 181 */         new MCItemDef[] {
/* 182 */           MCItemDef.create("user_id", true, "user_id"), 
/* 183 */           MCItemDef.create("co_cd", "co_cd"), 
/* 184 */           MCItemDef.create("ext_attr1", "ext_attr1"), 
/* 185 */           MCItemDef.create("ext_attr2", "ext_attr2"), 
/* 186 */           MCItemDef.create("ext_attr3", "ext_attr3"), 
/* 187 */           MCItemDef.create("pgm_id", true, "pgm_id"), 
/* 188 */           MCItemDef.create("locale", "locale")
/*     */ 
/*     */         
/* 191 */         }MCBlockDef.create("Srch03_Cnd"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBJL0100_Srch03_DOWN_BLOCK0() {
/* 198 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBJL0100", "Srch03", 
/* 199 */         new MCItemDef[] {
/* 200 */           MCItemDef.create("user_id", true, "user_id"), 
/* 201 */           MCItemDef.create("co_cd", "co_cd"), 
/* 202 */           MCItemDef.create("ext_attr1", "ext_attr1"), 
/* 203 */           MCItemDef.create("ext_attr2", "ext_attr2"), 
/* 204 */           MCItemDef.create("ext_attr3", "ext_attr3"), 
/* 205 */           MCItemDef.create("name", true, "name"), 
/* 206 */           MCItemDef.create("res_key", true, "res_key"), 
/* 207 */           MCItemDef.create("res_val", "res_val")
/*     */ 
/*     */         
/* 210 */         }MCBlockDef.create("Srch03_Rslt"));
/*     */   }
/*     */ 
/*     */   
/* 214 */   static final MCOperationInfo FC_FCBJL0100_Imp01_INFO = new MCOperationInfo("FC", "FCBJL0100", "Imp01", "000000", new PDef());
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBJL0100_Imp01_UP_BLOCK0() {
/* 218 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBJL0100", "Imp01", 
/* 219 */         new MCItemDef[] {
/* 220 */           MCItemDef.create("user_id", true, "user_id"), 
/* 221 */           MCItemDef.create("co_cd", "co_cd"), 
/* 222 */           MCItemDef.create("ext_attr1", "ext_attr1"), 
/* 223 */           MCItemDef.create("ext_attr2", "ext_attr2"), 
/* 224 */           MCItemDef.create("ext_attr3", "ext_attr3"), 
/* 225 */           MCItemDef.create("locale", "locale")
/*     */ 
/*     */         
/* 228 */         }MCBlockDef.create("Imp01_User"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBJL0100_Imp01_UP_BLOCK1() {
/* 234 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBJL0100", "Imp01", 
/* 235 */         new MCItemDef[] {
/* 236 */           MCItemDef.create("name_key", true, "name_key"), 
/* 237 */           MCItemDef.create("res_val", "res_val")
/*     */ 
/*     */         
/* 240 */         }MCBlockDef.create("Imp01_Dtl"));
/*     */   }
/*     */ 
/*     */   
/* 244 */   static final MCOperationInfo FC_FCBJL0100_Exp01_INFO = new MCOperationInfo("FC", "FCBJL0100", "Exp01", "000000", new PDef());
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBJL0100_Exp01_UP_BLOCK0() {
/* 248 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBJL0100", "Exp01", 
/* 249 */         new MCItemDef[] {
/* 250 */           MCItemDef.create("user_id", true, "user_id"), 
/* 251 */           MCItemDef.create("co_cd", "co_cd"), 
/* 252 */           MCItemDef.create("ext_attr1", "ext_attr1"), 
/* 253 */           MCItemDef.create("ext_attr2", "ext_attr2"), 
/* 254 */           MCItemDef.create("ext_attr3", "ext_attr3"), 
/* 255 */           MCItemDef.create("locale", "locale")
/*     */ 
/*     */         
/* 258 */         }MCBlockDef.create("Exp01_Cnd"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBJL0100_Exp01_DOWN_BLOCK0() {
/* 265 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBJL0100", "Exp01", 
/* 266 */         new MCItemDef[] {
/* 267 */           MCItemDef.create("name_key", true, "name_key"), 
/* 268 */           MCItemDef.create("res_val", "res_val")
/*     */ 
/*     */         
/* 271 */         }MCBlockDef.create("Exp01_Rslt"));
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\resource\ctrl\PDef_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */