package mcframe.serverCore.phase;

import mcframe.commonCore.param.MCParam;

public interface MCLogicBeforeAfter extends MCPhase {
  Throwable destroy(MCParam paramMCParam, Throwable paramThrowable);
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\phase\MCLogicBeforeAfter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */