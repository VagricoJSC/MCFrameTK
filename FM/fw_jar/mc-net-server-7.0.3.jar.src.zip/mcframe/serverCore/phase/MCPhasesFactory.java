/*     */ package mcframe.serverCore.phase;
/*     */ 
/*     */ import mcframe.commonCore.sys.MCFactory;
/*     */ import mcframe.serverCore.requester.MCDispatcherContext;
/*     */ import mcframe.serverCore.resource.MCConst;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCPhasesFactory
/*     */ {
/*     */   public static MCPhase createAuthentication(MCDispatcherContext ctx) {
/*  33 */     if (ctx.getInvokeType().skipAuthentication()) {
/*  34 */       return MCInactivePhase.create();
/*     */     }
/*  36 */     String c = "mcframe.serverCore.login.MCAuthPhase";
/*  37 */     return (MCPhase)MCFactory.create(MCPhase.class, c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCPhase createAuthorization(MCDispatcherContext ctx) {
/*  52 */     if (ctx.getInvokeType().skipAuthorization() || ctx.isListLogic()) {
/*  53 */       return MCInactivePhase.create();
/*     */     }
/*  55 */     return createPhase(ctx, "phase.authorization.class");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCPhase createParaOpeCtrl(MCDispatcherContext ctx) {
/*  70 */     if (ctx.getInvokeType().skipParaOpeCtrl() || ctx.isListLogic()) {
/*  71 */       return MCInactivePhase.create();
/*     */     }
/*  73 */     return createPhase(ctx, "phase.paraOpe.class");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCPhase createMaxOpeCtrl(MCDispatcherContext ctx) {
/*  88 */     if (ctx.getInvokeType().skipMaxOpeCtrl()) {
/*  89 */       return MCInactivePhase.create();
/*     */     }
/*  91 */     return createPhase(ctx, "phase.maxOpe.class");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCPhase createServStsCtrl(MCDispatcherContext ctx) {
/* 106 */     if (ctx.getInvokeType().skipServStsCtrl() || ctx.isListLogic()) {
/* 107 */       return MCInactivePhase.create();
/*     */     }
/* 109 */     return createPhase(ctx, "phase.servSts.class");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static MCPhase createPhase(MCDispatcherContext ctx, String key) {
/* 138 */     MCPhase phase = (MCPhase)MCConst.plugin.create(MCPhase.class, key);
/* 139 */     return (phase != null) ? phase : MCInactivePhase.create();
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\phase\MCPhasesFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */