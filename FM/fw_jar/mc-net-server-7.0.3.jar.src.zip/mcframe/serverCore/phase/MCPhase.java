package mcframe.serverCore.phase;

import mcframe.commonCore.param.MCParam;

public interface MCPhase {
  void invoke(MCParam paramMCParam);
  
  void destroy(MCParam paramMCParam);
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\phase\MCPhase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */