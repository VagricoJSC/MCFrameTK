/*    */ package mcframe.serverCore.phase;
/*    */ 
/*    */ import mcframe.commonCore.param.MCParam;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCInactivePhase
/*    */   implements MCPhase
/*    */ {
/* 14 */   private static final MCInactivePhase _PHASE = new MCInactivePhase();
/*    */   
/*    */   public static MCInactivePhase create() {
/* 17 */     return _PHASE;
/*    */   }
/*    */   
/*    */   public void invoke(MCParam param) {}
/*    */   
/*    */   public void destroy(MCParam param) {}
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\phase\MCInactivePhase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */