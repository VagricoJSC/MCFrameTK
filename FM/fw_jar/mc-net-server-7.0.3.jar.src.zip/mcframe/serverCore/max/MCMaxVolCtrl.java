/*    */ package mcframe.serverCore.max;
/*    */ 
/*    */ import mcframe.commonCore.container.MCVolumeManager;
/*    */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*    */ import mcframe.commonCore.notice.MCLog;
/*    */ import mcframe.commonCore.param.MCParam;
/*    */ import mcframe.commonCore.resource.MCCoreConfigResource;
/*    */ import mcframe.serverCore.phase.MCPhase;
/*    */ import mcframe.serverCore.resource.MCConfig;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCMaxVolCtrl
/*    */   implements MCPhase
/*    */ {
/*    */   public void invoke(MCParam p) {
/* 34 */     if (!MCVolumeManager.isInitialized()) {
/* 35 */       MCVolumeManager.initialize((MCCoreConfigResource)MCConfig.server);
/*    */     }
/* 37 */     MCVolumeManager.beginOperation(p);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void destroy(MCParam p) {
/* 49 */     long row = MCVolumeManager.endOperation();
/*    */     
/* 51 */     MCLog.write(Core_Msg_FW_A.FCBGC0100, new Object[] {
/* 52 */           p.getModuleId(), p.getLogicId(), p.getOperationId(), 
/* 53 */           String.valueOf(row)
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\max\MCMaxVolCtrl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */