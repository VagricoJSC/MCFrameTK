/*    */ package mcframe.serverCore.max;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCMaxOpeConfig
/*    */ {
/*    */   final String ptn;
/*    */   final int qty;
/*    */   
/*    */   MCMaxOpeConfig(String ptn, int qty) {
/* 39 */     this.ptn = ptn;
/* 40 */     this.qty = qty;
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\max\MCMaxOpeConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */