/*    */ package mcframe.serverCore.max;
/*    */ 
/*    */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*    */ import mcframe.commonCore.notice.MCException;
/*    */ import mcframe.commonCore.notice.MCLog;
/*    */ import mcframe.commonCore.param.MCParam;
/*    */ import mcframe.serverCore.phase.MCPhase;
/*    */ import mcframe.serverCore.resource.MCConfig;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCMaxOpeCtrl
/*    */   implements MCPhase
/*    */ {
/* 28 */   protected static final MCMaxQueue queue = MCMaxQueue.createMaxQueue();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void invoke(MCParam p) {
/* 43 */     int retry = 0;
/* 44 */     int interval = 0;
/*    */     try {
/* 46 */       retry = MCConfig.server.getInteger("process.max.retry", 0);
/* 47 */       interval = MCConfig.server.getInteger("process.max.interval", 0);
/* 48 */     } catch (MCException e) {
/*    */       
/* 50 */       MCLog.write(Core_Msg_FW_A.FCBGC0317, new Object[] { e.getMCMessage().toString() });
/*    */     } 
/*    */ 
/*    */     
/* 54 */     MCLog.write(Core_Msg_FW_A.FCBGC0311, new Object[] { String.valueOf(retry), String.valueOf(interval) });
/*    */ 
/*    */     
/* 57 */     MCMaxConfig conf = queue.createMaxConfig(p.getModuleId(), 
/* 58 */         p.getLogicId(), 
/* 59 */         p.getOperationId());
/* 60 */     String req_id = p.getServerRequestNo();
/* 61 */     queue.offer(conf, req_id);
/* 62 */     queue.queue(retry, interval, conf, req_id);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void destroy(MCParam p) {
/* 74 */     MCMaxConfig conf = queue.createMaxConfig(p.getModuleId(), 
/* 75 */         p.getLogicId(), 
/* 76 */         p.getOperationId());
/* 77 */     String req_id = p.getServerRequestNo();
/* 78 */     queue.remove(conf, req_id);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\max\MCMaxOpeCtrl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */