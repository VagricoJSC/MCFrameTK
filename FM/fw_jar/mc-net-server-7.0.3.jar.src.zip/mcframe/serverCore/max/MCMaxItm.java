/*    */ package mcframe.serverCore.max;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCMaxItm
/*    */ {
/*    */   final String reqNo;
/*    */   final MCMaxConfig conf;
/*    */   
/*    */   MCMaxItm(String reqNo, MCMaxConfig conf) {
/* 40 */     this.reqNo = reqNo;
/* 41 */     this.conf = conf;
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\max\MCMaxItm.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */