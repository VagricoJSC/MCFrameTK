/*     */ package mcframe.serverCore.max;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.serverCore.resource.MCConfig;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCMaxQueue
/*     */ {
/*  73 */   private static final MCMaxQueue _obj = new MCMaxQueue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   private Map<String, MCMaxConfig> cache = new HashMap<>();
/*  83 */   private Map<String, LinkedList<MCMaxItm>> opeQueue = new HashMap<>();
/*  84 */   private Bag<String> bag = new Bag<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCMaxOpeConfig[] master;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMaxQueue createMaxQueue() {
/*  95 */     return _obj;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized void offer(MCMaxConfig conf, String req_no) {
/*     */     LinkedList<MCMaxItm> queue;
/* 108 */     MCMaxItm itm = new MCMaxItm(req_no, conf);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 113 */     synchronized (this.opeQueue) {
/* 114 */       if ((queue = this.opeQueue.get(conf.ope_id)) == null) {
/* 115 */         queue = new LinkedList<>();
/* 116 */         this.opeQueue.put(conf.ope_id, queue);
/*     */       } 
/*     */     } 
/*     */     
/* 120 */     synchronized (queue) {
/* 121 */       queue.offer(itm);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void queue(int retry, int interval, MCMaxConfig conf, String req_no) {
/* 140 */     int waitSum = 0;
/* 141 */     int retrySum = 0;
/*     */     try {
/* 143 */       while (!confirm(conf.ope_id, req_no)) {
/* 144 */         Thread.sleep(interval);
/* 145 */         waitSum += interval;
/* 146 */         if (retry <= retrySum)
/*     */         {
/* 148 */           throw new MCException(Core_Msg_FW_A.FCBGC0060, new Object[] { String.valueOf(waitSum), 
/* 149 */                 String.valueOf(retrySum) });
/*     */         }
/* 151 */         retrySum++;
/*     */       }
/*     */     
/* 154 */     } catch (MCException e) {
/* 155 */       throw e;
/*     */     }
/* 157 */     catch (Exception e) {
/*     */       
/* 159 */       MCLog.write(Core_Msg_FW_A.FCBGC0314, new Object[0]);
/* 160 */       throw new MCException(e, Core_Msg_FW_A.FCBGC0059, new Object[0]);
/*     */     } finally {
/*     */       
/* 163 */       removeQueue(conf.ope_id, req_no);
/*     */     } 
/*     */     
/* 166 */     MCLog.write(Core_Msg_FW_A.FCBGC0313, new Object[] { String.valueOf(waitSum), String.valueOf(retrySum) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized void remove(MCMaxConfig conf, String req_no) {
/* 179 */     if (conf.max < 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 184 */     this.bag.remove(conf.ope_id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCMaxConfig createMaxConfig(String moduleId, String logicId, String operationId) {
/* 198 */     return getConf(crtOpeId(moduleId, logicId, operationId));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCMaxConfig getConf(String ope) {
/*     */     MCMaxConfig conf;
/* 212 */     if ((conf = this.cache.get(ope)) == null) {
/* 213 */       conf = new MCMaxConfig(ope);
/* 214 */       readRes(conf);
/* 215 */       this.cache.put(ope, conf);
/*     */     } 
/* 217 */     return conf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean confirm(String ope, String req_no) {
/* 230 */     MCMaxItm head = getHead(ope);
/*     */ 
/*     */     
/* 233 */     if (head.conf.max < 0) {
/* 234 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 238 */     if (!isHead(head, req_no)) {
/* 239 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 243 */     if (isMax(head)) {
/* 244 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 248 */     insOpe(head);
/*     */     
/* 250 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCMaxItm getHead(String ope) {
/* 262 */     LinkedList<MCMaxItm> lst = this.opeQueue.get(ope);
/* 263 */     if (lst.size() == 0) {
/* 264 */       return null;
/*     */     }
/* 266 */     return lst.get(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isHead(MCMaxItm itm, String req_no) {
/* 279 */     if (itm.reqNo.equals(req_no)) {
/* 280 */       return true;
/*     */     }
/* 282 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isMax(MCMaxItm itm) {
/* 295 */     if (itm.conf.max <= this.bag.count(itm.conf.ope_id)) {
/* 296 */       return true;
/*     */     }
/* 298 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void insOpe(MCMaxItm itm) {
/* 309 */     this.bag.add(itm.conf.ope_id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void removeQueue(String ope, String req_no) {
/* 321 */     LinkedList<MCMaxItm> queue = this.opeQueue.get(ope);
/* 322 */     if (queue == null) {
/*     */       return;
/*     */     }
/* 325 */     LinkedList<MCMaxItm> del = new LinkedList<>();
/*     */     
/* 327 */     synchronized (queue) {
/* 328 */       for (MCMaxItm itm : queue) {
/*     */ 
/*     */         
/* 331 */         String c_req_no = itm.reqNo;
/* 332 */         if (c_req_no.equals(req_no)) {
/* 333 */           del.add(itm);
/*     */         }
/*     */       } 
/* 336 */       queue.removeAll(del);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readRes(MCMaxConfig conf) {
/* 349 */     refresh(false); byte b; int i; MCMaxOpeConfig[] arrayOfMCMaxOpeConfig;
/* 350 */     for (i = (arrayOfMCMaxOpeConfig = this.master).length, b = 0; b < i; ) { MCMaxOpeConfig c = arrayOfMCMaxOpeConfig[b];
/* 351 */       if (match(conf.ope_id, c.ptn)) {
/* 352 */         conf.max = c.qty;
/*     */         break;
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String crtOpeId(String moduleId, String logicId, String operationId) {
/* 366 */     return String.valueOf(moduleId) + "." + logicId + "." + operationId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean match(String ope_id, String ptn) {
/* 380 */     String[] tar = MCStringUtil.match(ptn, new String[] {
/* 381 */           ope_id
/* 382 */         }, '.');
/* 383 */     return (tar.length == 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized void refresh(boolean enf) {
/* 395 */     if (this.master == null || enf) {
/* 396 */       this.cache.clear();
/* 397 */       this.bag.clear();
/* 398 */       String[] keys = MCConfig.server.findPattern("process.max.items.*");
/*     */ 
/*     */       
/* 401 */       List<MCMaxOpeConfig> list = new ArrayList<>();
/*     */ 
/*     */       
/* 404 */       for (int i = 0; i < keys.length; i++) {
/* 405 */         String ptnkey = MCConfig.createKey(new String[] { keys[i], "ptn" });
/* 406 */         String ptn = MCConfig.server.getString(ptnkey);
/* 407 */         if (!MCStringUtil.isNull(ptn)) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 412 */           String qtykey = MCConfig.createKey(new String[] { keys[i], "qty" });
/* 413 */           if (MCConfig.server.containsKey(qtykey))
/*     */           
/*     */           { 
/*     */             
/* 417 */             int qty = MCConfig.server.getInteger(qtykey, -1);
/* 418 */             MCMaxOpeConfig c = new MCMaxOpeConfig(ptn, qty);
/* 419 */             list.add(c); } 
/*     */         } 
/* 421 */       }  this.master = list.<MCMaxOpeConfig>toArray(new MCMaxOpeConfig[list.size()]);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\max\MCMaxQueue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */