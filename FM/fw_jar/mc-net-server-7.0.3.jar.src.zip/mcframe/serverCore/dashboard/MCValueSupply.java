/*     */ package mcframe.serverCore.dashboard;
/*     */ 
/*     */ import mcframe.commonCore.dashboard.MCValueSupply;
/*     */ import mcframe.commonCore.lang.MCDate;
/*     */ import mcframe.commonCore.lang.MCTimestamp;
/*     */ import mcframe.serverCore.mcjdbc.FWDBUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface MCValueSupply
/*     */   extends MCValueSupply
/*     */ {
/*     */   MCValueSupply clone();
/*     */   
/*     */   static MCValueSupply create(String col, String name, String type, boolean required, boolean editable) {
/*  40 */     if (type == null)
/*  41 */       return null; 
/*     */     String str;
/*  43 */     switch ((str = type).hashCode()) { case 49: if (!str.equals("1")) {
/*     */           break;
/*     */         }
/*     */         
/*  47 */         return new StringVS(col, name, type, required, editable);
/*     */       case 50:
/*     */         if (!str.equals("2"))
/*  50 */           break;  return new NumberVS(col, name, type, required, editable);
/*     */       
/*     */       case 51:
/*     */         if (!str.equals("3")) {
/*     */           break;
/*     */         }
/*  56 */         return new DateVS(col, name, type, required, editable);
/*     */       case 52:
/*     */         if (!str.equals("4"))
/*  59 */           break;  return new TimestampVS(col, name, type, required, editable);
/*     */       case 53: if (!str.equals("5"))
/*     */           break;  return new BooleanVS(col, name, type, required, editable);
/*     */       case 54: if (!str.equals("6")); break;
/*     */       case 1584: if (!str.equals("1A"))
/*     */           break;  return new StringVS(col, name, type, required, editable);
/*     */       case 1586: if (!str.equals("1C"))
/*  66 */           break;  return new StringVS(col, name, type, required, editable); }  return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class StringVS
/*     */     extends MCValueSupply.StringBase
/*     */     implements MCValueSupply
/*     */   {
/*     */     protected StringVS(String col, String name, String type, boolean required, boolean editable) {
/* 100 */       super(col, name, type, required, editable);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected MCValueSupply.StringBase createInstance(String col, String name, String type, boolean required, boolean editable) {
/* 106 */       return new StringVS(column(), name(), type(), required(), editable());
/*     */     }
/*     */ 
/*     */     
/*     */     public StringVS clone() {
/* 111 */       return (StringVS)cloneImpl();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class NumberVS
/*     */     extends MCValueSupply.NumberBase
/*     */     implements MCValueSupply
/*     */   {
/*     */     protected NumberVS(String col, String name, String type, boolean required, boolean editable) {
/* 135 */       super(col, name, type, required, editable);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected NumberVS createInstance(String col, String name, String type, boolean required, boolean editable) {
/* 141 */       return new NumberVS(column(), name(), type(), required(), editable());
/*     */     }
/*     */ 
/*     */     
/*     */     public NumberVS clone() {
/* 146 */       return (NumberVS)cloneImpl();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class BooleanVS
/*     */     extends MCValueSupply.BooleanBase
/*     */     implements MCValueSupply
/*     */   {
/*     */     protected BooleanVS(String col, String name, String type, boolean required, boolean editable) {
/* 170 */       super(col, name, type, required, editable);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected BooleanVS createInstance(String col, String name, String type, boolean required, boolean editable) {
/* 176 */       return new BooleanVS(column(), name(), type(), required(), editable());
/*     */     }
/*     */ 
/*     */     
/*     */     public BooleanVS clone() {
/* 181 */       return (BooleanVS)cloneImpl();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class DateVS
/*     */     extends MCValueSupply.DateBase
/*     */     implements MCValueSupply
/*     */   {
/*     */     protected DateVS(String col, String name, String type, boolean required, boolean editable) {
/* 205 */       super(col, name, type, required, editable);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected DateVS createInstance(String col, String name, String type, boolean required, boolean editable) {
/* 211 */       return new DateVS(column(), name(), type(), required(), editable());
/*     */     }
/*     */ 
/*     */     
/*     */     public DateVS clone() {
/* 216 */       return (DateVS)cloneImpl();
/*     */     }
/*     */ 
/*     */     
/*     */     protected MCDate getCoToday() {
/* 221 */       return FWDBUtil.coToday();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class TimestampVS
/*     */     extends DateVS
/*     */     implements MCValueSupply
/*     */   {
/*     */     protected TimestampVS(String col, String name, String type, boolean required, boolean editable) {
/* 245 */       super(col, name, type, required, editable);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected TimestampVS createInstance(String col, String name, String type, boolean required, boolean editable) {
/* 251 */       return new TimestampVS(column(), name(), type(), required(), editable());
/*     */     }
/*     */ 
/*     */     
/*     */     public TimestampVS clone() {
/* 256 */       return (TimestampVS)cloneImpl();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void value(Comparable<?> val) {
/* 262 */       super.value((Comparable)MCDate.valueOf((MCTimestamp)val));
/*     */     }
/*     */ 
/*     */     
/*     */     public Comparable<?> value() {
/* 267 */       return (Comparable<?>)MCTimestamp.valueOf((MCDate)super.value());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\dashboard\MCValueSupply.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */