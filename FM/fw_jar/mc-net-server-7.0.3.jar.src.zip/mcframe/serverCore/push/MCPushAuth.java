package mcframe.serverCore.push;

import java.util.List;
import java.util.Map;

public interface MCPushAuth {
  void confirmSession(String paramString1, String paramString2);
  
  boolean isStaffOnly(String paramString);
  
  String getMailAddress(String paramString);
  
  Map<String, MCPushAuthInfo> getPushAuthInfo(List<String> paramList);
  
  String[] getActiveUsers(String paramString);
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\push\MCPushAuth.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */