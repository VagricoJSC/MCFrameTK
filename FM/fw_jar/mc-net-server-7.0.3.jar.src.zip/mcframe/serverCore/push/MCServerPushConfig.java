/*     */ package mcframe.serverCore.push;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import javax.websocket.HandshakeResponse;
/*     */ import javax.websocket.server.HandshakeRequest;
/*     */ import javax.websocket.server.ServerEndpointConfig;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCServerPushConfig
/*     */   extends ServerEndpointConfig.Configurator
/*     */ {
/*     */   public static String getQueryParam(String query, String key) {
/*  35 */     if (query == null) {
/*  36 */       return null;
/*     */     }
/*     */     
/*  39 */     String[] params = query.split("&"); byte b; int i; String[] arrayOfString1;
/*  40 */     for (i = (arrayOfString1 = params).length, b = 0; b < i; ) { String param = arrayOfString1[b];
/*  41 */       String prefix = String.valueOf(key) + "=";
/*  42 */       if (param.startsWith(prefix))
/*  43 */         return param.substring(prefix.length()); 
/*     */       b++; }
/*     */     
/*  46 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void modifyHandshake(ServerEndpointConfig sec, HandshakeRequest request, HandshakeResponse response) {
/*  53 */     Map<String, Object> mcmap = new HashMap<>();
/*     */ 
/*     */     
/*  56 */     HttpSession session = (HttpSession)request.getHttpSession();
/*  57 */     if (session != null) {
/*  58 */       Object object1 = session.getAttribute("_mc_remote_addr");
/*  59 */       if (object1 != null) {
/*  60 */         mcmap.put("_mc_remote_addr", object1);
/*     */       }
/*  62 */       Object object2 = session.getAttribute("_mc_remote_host");
/*  63 */       if (object2 != null) {
/*  64 */         mcmap.put("_mc_remote_host", object2);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  69 */     List<String> xff = (List<String>)request.getHeaders().get("X-Forwarded-For");
/*  70 */     if (xff != null) {
/*  71 */       String str = xff.get(0);
/*  72 */       if (str != null) {
/*  73 */         mcmap.put("_mc_remote_addr", str);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  78 */     String query = request.getQueryString();
/*  79 */     String addr = getQueryParam(query, "addr");
/*  80 */     if (addr != null) {
/*  81 */       mcmap.put("_mc_remote_addr", addr);
/*     */     }
/*  83 */     String host = getQueryParam(query, "host");
/*  84 */     if (host != null) {
/*  85 */       mcmap.put("_mc_remote_host", host);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 102 */     sec.getUserProperties().put(MCServerPushAgent.PROP_REQUEST_INFO, mcmap);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\push\MCServerPushConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */