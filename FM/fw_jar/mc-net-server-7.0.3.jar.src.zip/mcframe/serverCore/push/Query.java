/*    */ package mcframe.serverCore.push;
/*    */ 
/*    */ import mcframe.serverCore.dbc.FCT_PUSHMSG_R;
/*    */ import mcframe.serverCore.dbc.FCT_PUSHMSG_SEND_R;
/*    */ import mcframe.serverCore.queryapi.IFMCFMSQL;
/*    */ import mcframe.serverCore.queryapi.IFMCSQL;
/*    */ 
/*    */ public class Query
/*    */ {
/*    */   public static IFMCSQL.MCMainQuery FCBAL0020_FCT_PUSHMSG_SEND_S01() {
/* 11 */     FCT_PUSHMSG_SEND_R S0T = FCT_PUSHMSG_SEND_R.create("T");
/* 12 */     FCT_PUSHMSG_R S0T1 = FCT_PUSHMSG_R.create("T1");
/*    */     
/* 14 */     return (IFMCSQL.MCMainQuery)((IFMCSQL.MCMainQuery)IFMCSQL.sql("FCBAL0020_FCT_PUSHMSG_SEND_S01")
/* 15 */       .mainQuery()
/* 16 */       .select(new IFMCFMSQL.MCFMEDColumnGroup[] {
/* 17 */           (IFMCFMSQL.MCFMEDColumnGroup)S0T.push_id, 
/* 18 */           (IFMCFMSQL.MCFMEDColumnGroup)S0T.user_id, 
/* 19 */           (IFMCFMSQL.MCFMEDColumnGroup)S0T.send_dt, 
/* 20 */           (IFMCFMSQL.MCFMEDColumnGroup)S0T.recv_dt, 
/* 21 */           (IFMCFMSQL.MCFMEDColumnGroup)S0T1.importance
/*    */         
/* 23 */         }).from(
/* 24 */         (IFMCSQL.MCDerivedView)S0T
/* 25 */         .leftOuterJoin((IFMCSQL.MCSingleView)S0T1).on(S0T.push_id.eq(S0T1.push_id))))
/*    */       
/* 27 */       .where(
/* 28 */         IFMCSQL.value(0).eq(IFMCSQL.value(0))
/* 29 */         .and(S0T.user_id.eq(IFMCSQL.bind("user_id"))));
/*    */   }
/*    */ 
/*    */   
/*    */   public static IFMCSQL.MCMainQuery FCBAL0020_FCT_PUSHMSG_SEND_S02() {
/* 34 */     FCT_PUSHMSG_SEND_R S0T = FCT_PUSHMSG_SEND_R.create("T");
/* 35 */     FCT_PUSHMSG_R S0T1 = FCT_PUSHMSG_R.create("T1");
/* 36 */     return (IFMCSQL.MCMainQuery)((IFMCSQL.MCMainQuery)((IFMCSQL.MCMainQuery)IFMCSQL.sql("FCBAL0020_FCT_PUSHMSG_SEND_S02")
/* 37 */       .mainQuery()
/* 38 */       .select(new IFMCFMSQL.MCFMEDColumnGroup[] {
/* 39 */           (IFMCFMSQL.MCFMEDColumnGroup)IFMCSQL.countAll().as("count"), 
/* 40 */           (IFMCFMSQL.MCFMEDColumnGroup)S0T1.importance
/*    */         
/* 42 */         }).from(
/* 43 */         (IFMCSQL.MCDerivedView)S0T
/* 44 */         .leftOuterJoin((IFMCSQL.MCSingleView)S0T1).on(S0T.push_id.eq(S0T1.push_id))))
/*    */       
/* 46 */       .where(
/* 47 */         IFMCSQL.value(0).eq(IFMCSQL.value(0))
/* 48 */         .and(S0T.recv_dt.isNull())
/* 49 */         .and(S0T.user_id.eq(IFMCSQL.bind("user_id")))))
/*    */       
/* 51 */       .groupBy(new IFMCFMSQL.MCFMEDExpr[] { (IFMCFMSQL.MCFMEDExpr)S0T1.importance });
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\push\Query.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */