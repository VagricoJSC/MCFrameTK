/*      */ package mcframe.serverCore.push;
/*      */ 
/*      */ import com.fasterxml.jackson.core.JsonParseException;
/*      */ import com.fasterxml.jackson.databind.JsonMappingException;
/*      */ import com.fasterxml.jackson.databind.ObjectMapper;
/*      */ import java.io.IOException;
/*      */ import java.io.StringWriter;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import mcframe.commonCore.container.MCContainer;
/*      */ import mcframe.commonCore.container.MCIndexKey;
/*      */ import mcframe.commonCore.container.MCJoinKey;
/*      */ import mcframe.commonCore.container.MCList;
/*      */ import mcframe.commonCore.container.MCRow;
/*      */ import mcframe.commonCore.lang.MCBooleanUtil;
/*      */ import mcframe.commonCore.lang.MCDate;
/*      */ import mcframe.commonCore.lang.MCNumber;
/*      */ import mcframe.commonCore.lang.MCStringUtil;
/*      */ import mcframe.commonCore.mail.MCMailMessage;
/*      */ import mcframe.commonCore.mail.MCMailSender;
/*      */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*      */ import mcframe.commonCore.notice.MCException;
/*      */ import mcframe.commonCore.notice.MCLog;
/*      */ import mcframe.commonCore.notice.MCMessage;
/*      */ import mcframe.commonCore.notice.MCMessageLevel;
/*      */ import mcframe.commonCore.param.MCDPWriter;
/*      */ import mcframe.commonCore.param.MCDef;
/*      */ import mcframe.commonCore.param.MCMessageRowParam;
/*      */ import mcframe.commonCore.param.MCOperationInfo;
/*      */ import mcframe.commonCore.param.MCParam;
/*      */ import mcframe.commonCore.pio.MCDPReaderFactory;
/*      */ import mcframe.commonCore.pio.MCP2TBodyReader;
/*      */ import mcframe.commonCore.pio.MCP2THeaderReader;
/*      */ import mcframe.commonCore.pio.util.MCDPFormat;
/*      */ import mcframe.commonCore.pio.util.MCDPParseType;
/*      */ import mcframe.commonCore.push.MCPushMessage;
/*      */ import mcframe.commonCore.push.MCServerPushManager;
/*      */ import mcframe.commonCore.push.MCServerPushProxy;
/*      */ import mcframe.commonCore.requester.MCClusterServerRole;
/*      */ import mcframe.commonCore.resource.MCLocaleConst;
/*      */ import mcframe.commonCore.resource.MCMessageConst;
/*      */ import mcframe.commonCore.resource.ctrl.MCResource;
/*      */ import mcframe.commonCore.sys.MCFactory;
/*      */ import mcframe.commonCore.util.MCUtil;
/*      */ import mcframe.serverCore.dbc.FCM_PUSHMSG_SETTING_R;
/*      */ import mcframe.serverCore.dbc.FCT_PUSHMSG_R;
/*      */ import mcframe.serverCore.dbc.FCT_PUSHMSG_SCREEN_R;
/*      */ import mcframe.serverCore.dbc.FCT_PUSHMSG_SEND_R;
/*      */ import mcframe.serverCore.logic.MCOperation;
/*      */ import mcframe.serverCore.mcjdbc.CoreSql;
/*      */ import mcframe.serverCore.mcjdbc.MCDBTransaction;
/*      */ import mcframe.serverCore.mcjdbc.MCTransactionManager;
/*      */ import mcframe.serverCore.notice.MCMessagePool;
/*      */ import mcframe.serverCore.push.ctrl.Broadcast2_NoticeR;
/*      */ import mcframe.serverCore.push.ctrl.Broadcast2_UserR;
/*      */ import mcframe.serverCore.push.ctrl.MCServerPush;
/*      */ import mcframe.serverCore.push.ctrl.MCServerPush_FW;
/*      */ import mcframe.serverCore.push.ctrl.NoticeR;
/*      */ import mcframe.serverCore.push.ctrl.PDef;
/*      */ import mcframe.serverCore.push.ctrl.ScreenR;
/*      */ import mcframe.serverCore.push.ctrl.UserR;
/*      */ import mcframe.serverCore.queryapi.IFMCFMSQL;
/*      */ import mcframe.serverCore.queryapi.IFMCSQL;
/*      */ import mcframe.serverCore.queryapi.MCDBContainer;
/*      */ import mcframe.serverCore.queryapi.MCQueryApiBuilder;
/*      */ import mcframe.serverCore.requester.MCBroadcastCaller;
/*      */ import mcframe.serverCore.requester.MCClusterCaller;
/*      */ import mcframe.serverCore.resource.MCConfig;
/*      */ import mcframe.serverCore.sys.MCSys;
/*      */ import mcframe.serverCore.util.MCDBUtil;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MCServerPushManager
/*      */   extends MCServerPushManager
/*      */ {
/*      */   public static class UserSession
/*      */   {
/*      */     public String userid;
/*      */     public String loginseq;
/*      */     public String locale;
/*      */     public String host;
/*      */     public String ip;
/*      */   }
/*  105 */   private static MCServerPushManager _mgr = new MCServerPushManager();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static MCServerPushManager getManager() {
/*  115 */     return _mgr;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getDefaultPushLevel() {
/*  126 */     return String.valueOf(MCMessageLevel.INFO.getOmission());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static MCNumber getDefaultHistoryCount() {
/*  137 */     return MCConfig.server.getNumber("push.message.history");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getDefaultHistoryCountString() {
/*  148 */     MCNumber cnt = getDefaultHistoryCount();
/*  149 */     return (cnt != null) ? cnt.toSimpleString() : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  160 */   private Map<String, UserSession> _userMap = new ConcurrentHashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  167 */   private MCPushAuth _pushAuth = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _enable = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MCServerPushManager() {
/*  191 */     super(MCSys.env.is3Tier() ? new MCServerPushAgent.MCServerPushProxyImpl() : null);
/*      */     
/*  193 */     this._pushAuth = (MCPushAuth)MCFactory.create(MCPushAuth.class, 
/*  194 */         "mcframe.serverCore.login.MCPushAuthImpl");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setEnabled(boolean enable) {
/*  210 */     this._enable = enable;
/*  211 */     if (!this._enable) {
/*  212 */       disable();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEnabled() {
/*  224 */     return this._enable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String recvMessage(String session, String clientid, String message) {
/*      */     Map<String, Object> map;
/*      */     UserSession user;
/*  241 */     ObjectMapper mapper = new ObjectMapper();
/*      */     
/*      */     try {
/*  244 */       map = (Map<String, Object>)mapper.readValue(message, Map.class);
/*      */     }
/*  246 */     catch (JsonParseException e) {
/*  247 */       throw new MCException(e, Core_Msg_FW_A.FCBGC0089, new Object[0]);
/*      */     }
/*  249 */     catch (JsonMappingException e) {
/*  250 */       throw new MCException(e, Core_Msg_FW_A.FCBGC0089, new Object[0]);
/*      */     }
/*  252 */     catch (IOException e) {
/*  253 */       throw new MCException(e, Core_Msg_FW_A.FCBGC0089, new Object[0]);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  258 */     String method = (String)map.get("method");
/*  259 */     if (method == null)
/*      */     {
/*  261 */       throw new MCException(Core_Msg_FW_A.FCBGC0419, new Object[] { method }); } 
/*      */     String str1;
/*  263 */     switch ((str1 = method).hashCode()) { case 2020776: if (!str1.equals("AUTH"))
/*      */           break; 
/*  265 */         user = new UserSession();
/*  266 */         user.userid = (String)map.get("userid");
/*  267 */         user.loginseq = (String)map.get("loginseq");
/*  268 */         user.locale = (String)map.get("locale");
/*  269 */         setUserSession(session, user);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  275 */         return method; }
/*      */     
/*      */     throw new MCException(Core_Msg_FW_A.FCBGC0419, new Object[] { method });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setUserSession(String session, UserSession user) {
/*      */     try {
/*  292 */       this._pushAuth.confirmSession(user.userid, user.loginseq);
/*      */     }
/*  294 */     catch (Exception e) {
/*      */       
/*  296 */       throw new MCException(e, Core_Msg_FW_A.FCBGC0428, new Object[0]);
/*      */     } 
/*  298 */     this._userMap.put(session, user);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   UserSession removeUserSession(String session) {
/*  310 */     return this._userMap.remove(session);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   UserSession getUserSession(String session) {
/*  322 */     return this._userMap.get(session);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber pushMessage(MCPushMessage msg, MCOperation ope, String... userids) {
/*  342 */     return pushMessage(msg, ope.getOperationInfo(), userids);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber pushMessage(MCPushMessage msg, MCOperationInfo ope, String... userids) {
/*  360 */     String mid = null;
/*  361 */     String lid = null;
/*  362 */     String oid = null;
/*  363 */     if (ope != null) {
/*  364 */       mid = ope.moduleId;
/*  365 */       lid = ope.logicId;
/*  366 */       oid = ope.operationId;
/*      */     } 
/*  368 */     return pushMessage(msg, mid, lid, oid, userids);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber pushMessage(MCPushMessage msg, String mid, String lid, String oid, String... userids) {
/*  390 */     return sendMessage("1", msg, mid, lid, oid, userids);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber mailMessage(MCPushMessage msg, MCOperation ope, String... userids) {
/*  409 */     return mailMessage(msg, ope.getOperationInfo(), userids);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber mailMessage(MCPushMessage msg, MCOperationInfo ope, String... userids) {
/*  427 */     String mid = null;
/*  428 */     String lid = null;
/*  429 */     String oid = null;
/*  430 */     if (ope != null) {
/*  431 */       mid = ope.moduleId;
/*  432 */       lid = ope.logicId;
/*  433 */       oid = ope.operationId;
/*      */     } 
/*  435 */     return mailMessage(msg, mid, lid, oid, userids);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber mailMessage(MCPushMessage msg, String mid, String lid, String oid, String... userids) {
/*  457 */     return sendMessage("2", msg, mid, lid, oid, userids);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber storeMessage(MCPushMessage msg, MCOperation ope, String... userids) {
/*  478 */     return storeMessage(msg, ope.getOperationInfo(), userids);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber storeMessage(MCPushMessage msg, MCOperationInfo ope, String... userids) {
/*  498 */     String mid = null;
/*  499 */     String lid = null;
/*  500 */     String oid = null;
/*  501 */     if (ope != null) {
/*  502 */       mid = ope.moduleId;
/*  503 */       lid = ope.logicId;
/*  504 */       oid = ope.operationId;
/*      */     } 
/*  506 */     return storeMessage(msg, mid, lid, oid, userids);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber storeMessage(MCPushMessage msg, String mid, String lid, String oid, String... userids) {
/*  530 */     return sendMessage("0", msg, mid, lid, oid, userids);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber sendMessage(MCPushMessage msg, MCOperation ope, String... userids) {
/*  552 */     return sendMessage(msg, ope.getOperationInfo(), userids);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber sendMessage(MCPushMessage msg, MCOperationInfo ope, String... userids) {
/*  573 */     String mid = null;
/*  574 */     String lid = null;
/*  575 */     String oid = null;
/*  576 */     if (ope != null) {
/*  577 */       mid = ope.moduleId;
/*  578 */       lid = ope.logicId;
/*  579 */       oid = ope.operationId;
/*      */     } 
/*  581 */     return sendMessage(msg, mid, lid, oid, userids);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCNumber sendMessage(MCPushMessage msg, String mid, String lid, String oid, String... userids) {
/*  606 */     return sendMessage("3", msg, mid, lid, oid, userids);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MCNumber sendMessage(String sendtype, MCPushMessage msg, String mid, String lid, String oid, String... userids) {
/*  629 */     if (msg == null || msg.getMessage() == null)
/*      */     {
/*  631 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  636 */     MCList<UserR> userL = MCList.create(UserR.class);
/*  637 */     Set<String> userSet = new HashSet<>(); byte b; int i; String[] arrayOfString;
/*  638 */     for (i = (arrayOfString = userids).length, b = 0; b < i; ) { String userid = arrayOfString[b];
/*  639 */       if (userid != null)
/*      */       {
/*      */ 
/*      */         
/*  643 */         if (userSet.add(userid)) {
/*      */ 
/*      */ 
/*      */           
/*  647 */           UserR userR = (UserR)userL.createRow();
/*  648 */           userR.userid(userid);
/*  649 */           userL.add((MCRow)userR);
/*      */         }  }  b++; }
/*  651 */      if (userL.size() <= 0)
/*      */     {
/*  653 */       return null;
/*      */     }
/*      */ 
/*      */     
/*  657 */     String user = MCSys.user.ID();
/*  658 */     String cocd = MCSys.user.coCD();
/*      */     
/*      */     try {
/*  661 */       Map<String, MCPushAuthInfo> infoM = this._pushAuth
/*  662 */         .getPushAuthInfo(userL.getString("userid"));
/*      */ 
/*      */       
/*  665 */       MCNumber pid = entryMessageHistory(user, cocd, mid, lid, oid, msg, userL, 
/*  666 */           infoM);
/*      */ 
/*      */       
/*  669 */       MCList<UserR> socketL = MCList.create(UserR.class);
/*  670 */       MCList<UserR> mailL = MCList.create(UserR.class);
/*  671 */       MCList<UserR> refuseL = MCList.create(UserR.class);
/*  672 */       setPushTypeUserList(mid, lid, oid, msg, userL, socketL, mailL, refuseL, 
/*  673 */           infoM); String str;
/*  674 */       switch ((str = sendtype).hashCode()) { case 48: if (!str.equals("0")) {
/*      */             break;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  692 */           refuseL.merge((Collection)socketL, new String[] { "userid" });
/*  693 */           refuseL.merge((Collection)mailL, new String[] { "userid" });
/*  694 */           socketL.clear();
/*  695 */           mailL.clear(); break;
/*      */         case 49:
/*      */           if (!str.equals("1"))
/*      */             break;  refuseL.merge((Collection)mailL, new String[] { "userid" }); refuseL.removeAll((Collection)socketL); mailL.clear(); break;
/*      */         case 50:
/*      */           if (!str.equals("2"))
/*      */             break;  refuseL.merge((Collection)socketL, new String[] { "userid" }); refuseL.removeAll((Collection)mailL); socketL.clear(); break;
/*      */         case 51:
/*      */           if (!str.equals("3")); break; }
/*      */       
/*  705 */       if (socketL.size() > 0) {
/*  706 */         sendMessageSocket(pid, user, cocd, mid, lid, oid, msg, socketL);
/*      */       }
/*  708 */       if (mailL.size() > 0) {
/*  709 */         sendMessageMail(pid, user, cocd, mid, lid, oid, msg, mailL, infoM);
/*      */       }
/*  711 */       if (refuseL.size() > 0)
/*      */       {
/*  713 */         checkUnreadMessage(
/*  714 */             new MCOperationInfo(mid, lid, oid, null, null), 
/*  715 */             (MCList)refuseL, "userid");
/*      */       }
/*      */       
/*  718 */       return pid;
/*      */     }
/*  720 */     catch (Exception e) {
/*      */ 
/*      */       
/*  723 */       MCLog.write(e);
/*  724 */       if (e instanceof MCException) {
/*  725 */         MCMessagePool.add(((MCException)e).getMCMessage());
/*      */       } else {
/*      */         
/*  728 */         MCMessagePool.add((new MCException(e)).getMCMessage());
/*      */       } 
/*  730 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MCNumber entryMessageHistory(String user, String cocd, String mid, String lid, String oid, MCPushMessage msg, MCList<UserR> userL, Map<String, MCPushAuthInfo> infoM) {
/*  754 */     if (getPushID(msg) != null)
/*      */     {
/*  756 */       return getPushID(msg);
/*      */     }
/*      */ 
/*      */     
/*  760 */     MCDBTransaction tran = MCTransactionManager.createDBTran();
/*  761 */     MCException mce = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  766 */     try { MCRow row = MCRow.create();
/*  767 */       MCTransactionManager.dbTran().statement()
/*  768 */         .executeQuery(
/*  769 */           "FC_GET_FCS_PUSH_ID", 
/*  770 */           CoreSql.get().getSequenceSql("FCS_PUSH_ID"), 
/*  771 */           null, 
/*  772 */           null, 
/*  773 */           null, 
/*  774 */           row);
/*      */       
/*  776 */       MCNumber pid = row.getNumber("VAL");
/*      */ 
/*      */       
/*  779 */       FCT_PUSHMSG_R pushR = FCT_PUSHMSG_R.create("T");
/*  780 */       pushR.push_id(pid);
/*  781 */       pushR.user_id(user);
/*  782 */       pushR.co_cd(cocd);
/*  783 */       pushR.module_id(mid);
/*  784 */       pushR.logic_id(lid);
/*  785 */       pushR.operation_id(oid);
/*  786 */       pushR.msg_id(msg.getMessage().getID());
/*  787 */       pushR.msg_bind(createMessageBindForDB(msg.getMessage()));
/*  788 */       if (msg.getTitle() != null) {
/*  789 */         pushR.title_id(msg.getTitle().getID());
/*  790 */         pushR.title_bind(createMessageBindForDB(msg.getTitle()));
/*      */       } 
/*  792 */       pushR.importance(msg.isImportance());
/*  793 */       MCQueryApiBuilder pushBuilder = MCQueryApiBuilder.create((MCDBContainer)pushR);
/*  794 */       MCDBUtil.dbInsert("FC_MCServerPushManager_entryMessageHistory_1", (MCRow)pushR, pushBuilder);
/*      */ 
/*      */       
/*  797 */       MCList<FCT_PUSHMSG_SCREEN_R> push_scrL = MCList.create(FCT_PUSHMSG_SCREEN_R.class);
/*  798 */       convScreenParamToList(msg, push_scrL, 
/*  799 */           "clt_typ_cd", 
/*  800 */           "param_key", 
/*  801 */           "param_val");
/*  802 */       push_scrL.setNumber("push_id", pid);
/*  803 */       FCT_PUSHMSG_SCREEN_R push_scrDbc = FCT_PUSHMSG_SCREEN_R.create("T");
/*  804 */       MCQueryApiBuilder push_scrBuilder = MCQueryApiBuilder.create((MCDBContainer)push_scrDbc);
/*  805 */       MCDBUtil.dbInsert("FC_MCServerPushManager_entryMessageHistory_2", push_scrL, push_scrBuilder);
/*      */ 
/*      */       
/*  808 */       MCList<FCT_PUSHMSG_SEND_R> push_sndL = MCList.create(FCT_PUSHMSG_SEND_R.class);
/*  809 */       MCDate send = MCDate.now();
/*      */       
/*  811 */       userL.forEach(userR -> {
/*      */             MCPushAuthInfo info = (MCPushAuthInfo)paramMap.get(userR.userid());
/*      */             
/*      */             if (!isStaffOnly(info)) {
/*      */               FCT_PUSHMSG_SEND_R push_sndR = (FCT_PUSHMSG_SEND_R)paramMCList.createRow();
/*      */               push_sndR.push_id(paramMCNumber);
/*      */               push_sndR.user_id(userR.userid());
/*      */               push_sndR.send_dt(paramMCDate);
/*      */               paramMCList.add((MCRow)push_sndR);
/*      */             } 
/*      */           });
/*  822 */       FCT_PUSHMSG_SEND_R sendDbc = FCT_PUSHMSG_SEND_R.create("T");
/*  823 */       MCQueryApiBuilder sendBuilder = MCQueryApiBuilder.create((MCDBContainer)sendDbc);
/*  824 */       MCDBUtil.dbInsert("FC_MCServerPushManager_entryMessageHistory_3", push_sndL, sendBuilder);
/*      */       
/*  826 */       MCNumber mCNumber1 = pid;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  834 */       try { if (mce == null) {
/*  835 */           tran.commit();
/*      */         } }
/*      */       finally
/*      */       
/*  839 */       { MCTransactionManager.releaseDBTran(tran); }  } catch (Exception e) { mce = (e instanceof MCException) ? (MCException)e : new MCException(e); throw mce; } finally { try { if (mce == null) tran.commit();  } finally { MCTransactionManager.releaseDBTran(tran); }
/*      */        }
/*      */   
/*      */   }
/*      */   
/*      */   private boolean isStaffOnly(MCPushAuthInfo info) {
/*  845 */     return (info != null && !info.system_user());
/*      */   }
/*      */   
/*      */   private String getMailAddress(MCPushAuthInfo info) {
/*  849 */     return (info != null) ? info.mail_addr() : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setPushTypeUserList(String mid, String lid, String oid, MCPushMessage msg, MCList<UserR> userL, MCList<UserR> socketL, MCList<UserR> mailL, MCList<UserR> refuseL, Map<String, MCPushAuthInfo> infoM) {
/*  873 */     socketL.clear();
/*  874 */     mailL.clear();
/*  875 */     refuseL.clear();
/*      */ 
/*      */     
/*  878 */     MCList<FCM_PUSHMSG_SETTING_R> settingL = MCList.create(FCM_PUSHMSG_SETTING_R.class);
/*  879 */     FCM_PUSHMSG_SETTING_R dbc = FCM_PUSHMSG_SETTING_R.create("M");
/*  880 */     MCQueryApiBuilder builder = MCQueryApiBuilder.create((MCDBContainer)dbc);
/*  881 */     builder.addWhereWithAnd(
/*      */         
/*  883 */         dbc.module_id.eq(IFMCSQL.bind("1"))
/*  884 */         .and(dbc.logic_id.eq(IFMCSQL.bind("2")))
/*  885 */         .and(dbc.operation_id.eq(IFMCSQL.bind("3")))
/*  886 */         .and(dbc.param_key.eq(IFMCSQL.bind("4")))
/*      */         
/*  888 */         .or(
/*  889 */           dbc.module_id.eq(IFMCSQL.bind("5"))
/*  890 */           .and(dbc.logic_id.eq(IFMCSQL.bind("6")))
/*  891 */           .and(dbc.operation_id.eq(IFMCSQL.bind("7")))
/*  892 */           .and(dbc.param_key.eq(IFMCSQL.bind("8")))), new Comparable[] {
/*      */           
/*  894 */           "*", 
/*  895 */           "*", 
/*  896 */           "*", 
/*  897 */           "$level$", 
/*  898 */           mid, 
/*  899 */           lid, 
/*  900 */           oid, 
/*  901 */           msg.getMessage().getID()
/*      */         });
/*      */     
/*  904 */     builder.addWhereInWithAnd((IFMCSQL.MCPermColumn)dbc.user_id, userL.getString("userid"));
/*      */     
/*  906 */     MCDBUtil.dbSelect("FC_MCServerPushManager_setPushTypeUserList", settingL, builder);
/*      */     
/*  908 */     MCMessageLevel msgLv = msg.getMessage().getLevel();
/*  909 */     MCIndexKey index = settingL.createIndex(new String[] { "user_id" });
/*  910 */     userL.forEach(userR -> {
/*      */           MCPushAuthInfo info = (MCPushAuthInfo)paramMap.get(userR.userid());
/*      */           if (isStaffOnly(info)) {
/*      */             paramMCList1.add((MCRow)userR);
/*      */           } else {
/*      */             MCList<FCM_PUSHMSG_SETTING_R> usrsetL = paramMCList2.subList(paramMCIndexKey, new Comparable[] { userR.userid() });
/*      */             for (FCM_PUSHMSG_SETTING_R usrsetR : usrsetL) {
/*      */               if ("$level$".equals(usrsetR.param_key())) {
/*      */                 char lv = usrsetR.param_val().charAt(0);
/*      */                 MCMessageLevel rejLv = MCMessageLevel.valueOf(lv);
/*      */                 if (paramMCMessageLevel.compareTo((Enum)rejLv) < 0) {
/*      */                   paramMCList3.add((MCRow)userR);
/*      */                   userR = null;
/*      */                 } 
/*      */                 continue;
/*      */               } 
/*      */               String str;
/*      */               switch ((str = usrsetR.param_val()).hashCode()) {
/*      */                 case 48:
/*      */                   if (!str.equals("0")) {
/*      */                     continue;
/*      */                   }
/*      */                   paramMCList3.add((MCRow)userR);
/*      */                   userR = null;
/*      */ 
/*      */                 
/*      */                 case 49:
/*      */                   if (!str.equals("1")) {
/*      */                     continue;
/*      */                   }
/*      */                   paramMCList4.add((MCRow)userR);
/*      */                   userR = null;
/*      */                 
/*      */                 case 50:
/*      */                   if (!str.equals("2")) {
/*      */                     continue;
/*      */                   }
/*      */                   paramMCList1.add((MCRow)userR);
/*      */                   userR = null;
/*      */                 
/*      */                 case 51:
/*      */                   if (!str.equals("3")) {
/*      */                     continue;
/*      */                   }
/*      */                   paramMCList1.add((MCRow)userR);
/*      */                   paramMCList4.add((MCRow)userR);
/*      */                   userR = null;
/*      */               } 
/*      */             
/*      */             } 
/*      */             if (userR != null) {
/*      */               paramMCList4.add((MCRow)userR);
/*      */               paramMCList1.add((MCRow)userR);
/*      */             } 
/*      */           } 
/*      */         });
/*  966 */     socketL.removeAll((Collection)refuseL);
/*  967 */     mailL.removeAll((Collection)refuseL);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void sendMessageSocket(MCNumber pid, String user, String cocd, String mid, String lid, String oid, MCPushMessage msg, MCList<UserR> userL) {
/*  994 */     NoticeR noticeR = NoticeR.create();
/*  995 */     noticeR.pushid(pid);
/*  996 */     noticeR.userid(user);
/*  997 */     noticeR.cocd(cocd);
/*  998 */     noticeR.modid(mid);
/*  999 */     noticeR.logid(lid);
/* 1000 */     noticeR.opeid(oid);
/* 1001 */     noticeR.msgid(msg.getMessage().getID());
/* 1002 */     noticeR.msgbind(createMessageBindForDB(msg.getMessage()));
/* 1003 */     if (msg.getTitle() != null) {
/* 1004 */       noticeR.titleid(msg.getTitle().getID());
/* 1005 */       noticeR.titlebind(createMessageBindForDB(msg.getTitle()));
/*      */     } 
/* 1007 */     noticeR.importance(msg.isImportance());
/*      */     
/* 1009 */     MCList<ScreenR> screenL = MCList.create(ScreenR.class);
/* 1010 */     convScreenParamToList(msg, screenL, "type", "key", "val");
/*      */ 
/*      */ 
/*      */     
/* 1014 */     MCBroadcastCaller<MCServerPush_FW.Broadcast> caller = 
/*      */       
/* 1016 */       new MCBroadcastCaller(new MCClusterServerRole[] { MCClusterServerRole.PUSH });
/* 1017 */     MCServerPush_FW.Broadcast bc = MCServerPush.crtBroadcast();
/* 1018 */     MCRow.copyall((MCRow)bc.up0(), (MCRow)noticeR);
/* 1019 */     bc.up1().addAll((Collection)userL);
/* 1020 */     bc.up2().addAll((Collection)screenL);
/* 1021 */     MCServerPush_FW.Broadcast[] ops = (MCServerPush_FW.Broadcast[])caller.broadcast((MCOperation)bc); byte b; int i; MCServerPush_FW.Broadcast[] arrayOfBroadcast1;
/* 1022 */     for (i = (arrayOfBroadcast1 = ops).length, b = 0; b < i; ) { MCServerPush_FW.Broadcast op = arrayOfBroadcast1[b];
/* 1023 */       MCException e = caller.getException((MCOperation)op);
/* 1024 */       if (e != null) {
/* 1025 */         if (e instanceof mcframe.commonCore.notice.MCServerException || e instanceof mcframe.commonCore.notice.MCServerAppException) {
/*      */           
/* 1027 */           MCClusterCaller<MCServerPush_FW.Broadcast>.Task task = caller.getTask((MCOperation)op);
/* 1028 */           int taskno = task.getNo();
/* 1029 */           String url = task.getURL();
/* 1030 */           String clreqno = task.getParam().getClientRequestNo();
/* 1031 */           String svreqno = task.getParam().getServerRequestNo();
/* 1032 */           MCLog.write(Core_Msg_FW_A.FCBGC0439, new Object[] { Integer.valueOf(taskno), url, clreqno, svreqno });
/*      */         }
/*      */         else {
/*      */           
/* 1036 */           MCLog.write((Throwable)e);
/*      */         } 
/*      */       }
/*      */       b++; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void sendMessageSocket(Broadcast2_NoticeR noticeR, MCList<Broadcast2_UserR> userL, MCList<ScreenR> screenL) {
/* 1063 */     MCBroadcastCaller<MCServerPush_FW.Broadcast2> caller = new MCBroadcastCaller(new MCClusterServerRole[] {
/* 1064 */           MCClusterServerRole.PUSH });
/* 1065 */     MCServerPush_FW.Broadcast2 bc = MCServerPush.crtBroadcast2();
/* 1066 */     MCRow.copyall((MCRow)bc.up0(), (MCRow)noticeR);
/* 1067 */     bc.up1().addAll((Collection)userL);
/* 1068 */     bc.up2().addAll((Collection)screenL);
/* 1069 */     MCServerPush_FW.Broadcast2[] ops = (MCServerPush_FW.Broadcast2[])caller.broadcast((MCOperation)bc); byte b; int i; MCServerPush_FW.Broadcast2[] arrayOfBroadcast21;
/* 1070 */     for (i = (arrayOfBroadcast21 = ops).length, b = 0; b < i; ) { MCServerPush_FW.Broadcast2 op = arrayOfBroadcast21[b];
/* 1071 */       MCException e = caller.getException((MCOperation)op);
/* 1072 */       if (e != null) {
/* 1073 */         if (e instanceof mcframe.commonCore.notice.MCServerException || 
/* 1074 */           e instanceof mcframe.commonCore.notice.MCServerAppException) {
/*      */           
/* 1076 */           MCClusterCaller<MCServerPush_FW.Broadcast2>.Task task = caller
/* 1077 */             .getTask((MCOperation)op);
/* 1078 */           int taskno = task.getNo();
/* 1079 */           String url = task.getURL();
/* 1080 */           String clreqno = task.getParam().getClientRequestNo();
/* 1081 */           String svreqno = task.getParam().getServerRequestNo();
/* 1082 */           MCLog.write(Core_Msg_FW_A.FCBGC0439, new Object[] { Integer.valueOf(taskno), url, clreqno, 
/* 1083 */                 svreqno });
/*      */         }
/*      */         else {
/*      */           
/* 1087 */           MCLog.write((Throwable)e);
/*      */         } 
/*      */       }
/*      */       b++; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void sendMessageMail(MCNumber pid, String user, String cocd, String mid, String lid, String oid, MCPushMessage msg, MCList<UserR> userL, Map<String, MCPushAuthInfo> infoM) {
/* 1113 */     List<String> toList = new ArrayList<>();
/* 1114 */     List<String> noaddrList = new ArrayList<>();
/* 1115 */     userL.forEach(userR -> {
/*      */           MCPushAuthInfo info = (MCPushAuthInfo)paramMap.get(userR.userid());
/*      */           
/*      */           String to = getMailAddress(info);
/*      */           
/*      */           if (to != null) {
/*      */             paramList1.add(to);
/*      */           } else {
/*      */             paramList2.add(userR.userid());
/*      */           } 
/*      */         });
/* 1126 */     if (noaddrList.size() > 0) {
/*      */       
/* 1128 */       String list = MCStringUtil.join("\n", noaddrList.<String>toArray(
/* 1129 */             new String[noaddrList.size()]));
/* 1130 */       MCLog.write(Core_Msg_FW_A.FCBGC0447, new Object[] { list });
/*      */     } 
/* 1132 */     String[] to = toList.<String>toArray(new String[toList.size()]);
/* 1133 */     if (to.length <= 0) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 1138 */     String from = MCConfig.common.getString("mail.default.addr", 
/* 1139 */         this._pushAuth.getMailAddress(MCSys.user.ID()));
/*      */ 
/*      */     
/* 1142 */     Locale locale = MCSys.user.locale();
/* 1143 */     MCMessageConst msgconst = MCLocaleConst.message(locale);
/*      */ 
/*      */     
/* 1146 */     String text = msg.getMessage().toString(msgconst);
/* 1147 */     Map<String, String> scrMap = msg.getScreenParamMap("PC");
/* 1148 */     String msid = scrMap.get("$screen$");
/* 1149 */     if (msid != null) {
/*      */       
/* 1151 */       String[] ids = analyzeScreenValue(msid);
/* 1152 */       Map<String, String> tmpMap = new HashMap<>(scrMap);
/* 1153 */       tmpMap.remove("$screen$");
/* 1154 */       List<String> initList = msg.getScreenInitParamList("PC");
/* 1155 */       String url = MCUtil.openURL(ids[0], ids[1], tmpMap, initList);
/* 1156 */       text = (new MCMessage(Core_Msg_FW_A.FCBGC0441, new Object[] { text, url })).toString(msgconst);
/*      */     } 
/*      */ 
/*      */     
/* 1160 */     msg.isImportance();
/* 1161 */     MCMessage title = msg.getTitle();
/* 1162 */     String subject = (title == null) ? 
/* 1163 */       createTitle(null, null, mid, lid, oid, locale) : 
/* 1164 */       title.toString(msgconst);
/*      */ 
/*      */     
/*      */     try {
/* 1168 */       String charset = MCConfig.common.getString("mail.default.charset", 
/* 1169 */           "UTF-8");
/* 1170 */       MCMailMessage mail = new MCMailMessage(charset);
/* 1171 */       mail.setFrom(from);
/* 1172 */       mail.setTo(to);
/* 1173 */       mail.setSubject(subject);
/* 1174 */       mail.setText(text);
/* 1175 */       MCMailSender smtp = new MCMailSender();
/* 1176 */       smtp.send(mail, true);
/*      */     }
/* 1178 */     catch (Exception e) {
/*      */       
/* 1180 */       List<String> userList = userL.getString("userid");
/* 1181 */       String list = MCStringUtil.join("\n", userList.<String>toArray(
/* 1182 */             new String[userList.size()]));
/* 1183 */       MCLog.write((Throwable)new MCException(e, Core_Msg_FW_A.FCBGC0446, new Object[] { list }));
/*      */     } 
/*      */ 
/*      */     
/* 1187 */     MCDBTransaction tranSendMail = MCTransactionManager.createDBTran();
/* 1188 */     MCException mce = null;
/*      */     try {
/* 1190 */       MCList<FCT_PUSHMSG_SEND_R> sendL = MCList.create(FCT_PUSHMSG_SEND_R.class);
/* 1191 */       FCT_PUSHMSG_SEND_R dbc = FCT_PUSHMSG_SEND_R.create("T");
/* 1192 */       MCQueryApiBuilder builder = MCQueryApiBuilder.create((MCDBContainer)dbc);
/* 1193 */       builder.addWhereWithAnd(dbc.push_id.eq(IFMCSQL.bind("1")), new Comparable[] { (Comparable)pid });
/* 1194 */       builder.addWhereInWithAnd((IFMCSQL.MCPermColumn)dbc.user_id, userL.getString("userid"));
/* 1195 */       if (MCDBUtil.dbSelectForUpdate("FC_MCServerPushManager.sendMessageMail_1", sendL, builder) > 0) {
/* 1196 */         sendL.setDate("recv_dt", MCDate.now());
/* 1197 */         MCDBUtil.dbUpdateKey("FC_MCServerPushManager.sendMessageMail_2", sendL, builder);
/*      */       }
/*      */     
/* 1200 */     } catch (Exception e) {
/* 1201 */       mce = (e instanceof MCException) ? (MCException)e : new MCException(e);
/* 1202 */       throw mce;
/*      */     } finally {
/*      */       
/*      */       try {
/* 1206 */         if (mce == null) {
/* 1207 */           tranSendMail.commit();
/*      */         }
/*      */       } finally {
/*      */         
/* 1211 */         MCTransactionManager.releaseDBTran(tranSendMail);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void readMessage(String userid, MCList<? extends MCRow> list, String pushcol) {
/* 1226 */     MCList<FCT_PUSHMSG_SEND_R> sendL = MCList.create(FCT_PUSHMSG_SEND_R.class);
/* 1227 */     FCT_PUSHMSG_SEND_R dbc = FCT_PUSHMSG_SEND_R.create("T");
/* 1228 */     MCQueryApiBuilder builder = MCQueryApiBuilder.create((MCDBContainer)dbc);
/* 1229 */     builder.addWhereWithAnd(dbc.user_id.eq(IFMCSQL.bind("1")), new Comparable[] { userid });
/* 1230 */     builder.addWhereWithAnd(dbc.push_id.eq(IFMCSQL.bind(pushcol)), new Comparable[0]);
/* 1231 */     if (MCDBUtil.dbSelectForUpdate("FC_MCServerPushManager_readMessage_1", sendL, builder, list) > 0) {
/* 1232 */       MCDate date = MCDate.now();
/* 1233 */       sendL.setDate("recv_dt", date);
/* 1234 */       MCDBUtil.dbUpdateKey("FC_MCServerPushManager_readMessage_2", sendL, builder);
/*      */     } 
/*      */ 
/*      */     
/* 1238 */     deleteOldMessage(Arrays.asList(new String[] { userid }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void deleteOldMessage(List<String> users) {
/* 1250 */     MCList<FCM_PUSHMSG_SETTING_R> settingL = MCList.create(FCM_PUSHMSG_SETTING_R.class);
/* 1251 */     FCM_PUSHMSG_SETTING_R settingDbc = FCM_PUSHMSG_SETTING_R.create("M");
/* 1252 */     MCQueryApiBuilder builder = MCQueryApiBuilder.create((MCDBContainer)settingDbc);
/* 1253 */     builder.addWhereWithAnd(
/* 1254 */         settingDbc.module_id.eq(IFMCSQL.bind("1"))
/* 1255 */         .and(settingDbc.logic_id.eq(IFMCSQL.bind("2")))
/* 1256 */         .and(settingDbc.operation_id.eq(IFMCSQL.bind("3")))
/* 1257 */         .and(settingDbc.param_key.eq(IFMCSQL.bind("4"))), new Comparable[] {
/* 1258 */           "*", 
/* 1259 */           "*", 
/* 1260 */           "*", 
/* 1261 */           "$history$"
/*      */         });
/* 1263 */     builder.addWhereInWithAnd((IFMCSQL.MCPermColumn)settingDbc.user_id, users);
/* 1264 */     MCDBUtil.dbSelect("FC_MCServerPushManager_deleteOldMessage_1", settingL, builder);
/*      */     
/* 1266 */     MCIndexKey cntidx = settingL.createIndex(new String[] { "user_id" });
/* 1267 */     MCNumber cntdef = getDefaultHistoryCount();
/*      */ 
/*      */     
/* 1270 */     MCList<FCT_PUSHMSG_SEND_R> send_delL = MCList.create(FCT_PUSHMSG_SEND_R.class);
/* 1271 */     MCList<FCT_PUSHMSG_SEND_R> send_oldL = MCList.create(FCT_PUSHMSG_SEND_R.class);
/* 1272 */     FCT_PUSHMSG_SEND_R sendDbc = FCT_PUSHMSG_SEND_R.create("T");
/* 1273 */     for (String user : users) {
/*      */       
/* 1275 */       MCNumber max_n = null;
/* 1276 */       FCM_PUSHMSG_SETTING_R settingR = (FCM_PUSHMSG_SETTING_R)settingL.getFirst(cntidx, new Comparable[] { user });
/* 1277 */       if (settingR == null) {
/* 1278 */         max_n = cntdef;
/*      */       } else {
/*      */         
/* 1281 */         String max_s = settingR.param_val();
/* 1282 */         max_n = (max_s != null) ? MCNumber.valueOf(max_s) : null;
/*      */       } 
/* 1284 */       if (max_n == null) {
/*      */         continue;
/*      */       }
/* 1287 */       int max = max_n.intValue();
/*      */ 
/*      */       
/* 1290 */       send_oldL.clear();
/* 1291 */       MCQueryApiBuilder sendBuilder = MCQueryApiBuilder.create((MCDBContainer)sendDbc);
/* 1292 */       sendBuilder.setWhere(sendDbc.user_id.eq(IFMCSQL.bind("1")), new Comparable[] { user });
/* 1293 */       sendBuilder.addWhereWithAnd(sendDbc.recv_dt.isNotNull(), new Comparable[0]);
/* 1294 */       sendBuilder.setOrderByAsc(new IFMCSQL.MCExprColumn[] { (IFMCSQL.MCExprColumn)sendDbc.send_dt, (IFMCSQL.MCExprColumn)sendDbc.push_id });
/* 1295 */       int cnt = MCDBUtil.dbSelect("FC_MCServerPushManager_deleteOldMessage_2", send_oldL, sendBuilder);
/* 1296 */       if (cnt > max) {
/* 1297 */         for (int i = 0; i < cnt - max; i++) {
/* 1298 */           FCT_PUSHMSG_SEND_R send_delR = (FCT_PUSHMSG_SEND_R)send_oldL.get(i);
/* 1299 */           send_delL.add((MCRow)send_delR);
/*      */         } 
/*      */       }
/*      */     } 
/*      */     
/* 1304 */     if (send_delL.size() > 0) {
/*      */       
/* 1306 */       MCDBUtil.dbDeleteKey("FC_MCServerPushManager_deleteOldMessage_3", send_delL, (MCDBContainer)sendDbc);
/*      */ 
/*      */       
/* 1309 */       deleteUnusedMessage();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void deleteUnusedMessage() {
/* 1320 */     FCT_PUSHMSG_SEND_R sendDbc = FCT_PUSHMSG_SEND_R.create("SEND");
/*      */ 
/*      */     
/* 1323 */     MCList<FCT_PUSHMSG_R> msgL = MCList.create(FCT_PUSHMSG_R.class);
/* 1324 */     FCT_PUSHMSG_R msgDbc = FCT_PUSHMSG_R.create("T");
/* 1325 */     MCQueryApiBuilder msgBuilder = MCQueryApiBuilder.create((MCDBContainer)msgDbc);
/* 1326 */     msgBuilder.setSelect((IFMCSQL.MCColumn[])msgDbc.getKeyColumn$());
/* 1327 */     IFMCSQL.MCColumnSubQuery mCColumnSubQuery1 = IFMCSQL.subQuery().select(new IFMCFMSQL.MCFMEDColumnGroup[] { (IFMCFMSQL.MCFMEDColumnGroup)sendDbc.push_id }).from((IFMCSQL.MCDerivedView)sendDbc).where(sendDbc.push_id.eq(msgDbc.push_id));
/* 1328 */     msgBuilder.setWhere(IFMCSQL.notExists((IFMCSQL.MCSubQuery)mCColumnSubQuery1), new Comparable[0]);
/* 1329 */     if (MCDBUtil.dbSelectForUpdate("FC_MCServerPushManager_deleteUnusedMessage_1", msgL, msgBuilder) > 0) {
/* 1330 */       MCDBUtil.dbDeleteKey("FC_MCServerPushManager_deleteUnusedMessage_2", msgL, (MCDBContainer)msgDbc);
/*      */     }
/*      */ 
/*      */     
/* 1334 */     MCList<FCT_PUSHMSG_SCREEN_R> scrL = MCList.create(FCT_PUSHMSG_SCREEN_R.class);
/* 1335 */     FCT_PUSHMSG_SCREEN_R scrDbc = FCT_PUSHMSG_SCREEN_R.create("T");
/* 1336 */     MCQueryApiBuilder scrBuilder = MCQueryApiBuilder.create((MCDBContainer)scrDbc);
/* 1337 */     scrBuilder.setSelect((IFMCSQL.MCColumn[])scrDbc.getKeyColumn$());
/* 1338 */     IFMCSQL.MCColumnSubQuery mCColumnSubQuery2 = IFMCSQL.subQuery().select(new IFMCFMSQL.MCFMEDColumnGroup[] { (IFMCFMSQL.MCFMEDColumnGroup)sendDbc.push_id }).from((IFMCSQL.MCDerivedView)sendDbc).where(sendDbc.push_id.eq(scrDbc.push_id));
/* 1339 */     scrBuilder.setWhere(IFMCSQL.notExists((IFMCSQL.MCSubQuery)mCColumnSubQuery2), new Comparable[0]);
/* 1340 */     if (MCDBUtil.dbSelectForUpdate("FC_MCServerPushManager_deleteUnusedMessage_3", scrL, scrBuilder) > 0) {
/* 1341 */       MCDBUtil.dbDeleteKey("FC_MCServerPushManager_deleteUnusedMessage_4", scrL, (MCDBContainer)scrDbc);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCList<FCT_PUSHMSG_SEND_R> getReceiveHistory(String user, String unrecv_col) {
/* 1367 */     MCList<FCT_PUSHMSG_SEND_R> sendL = MCList.create(FCT_PUSHMSG_SEND_R.class);
/* 1368 */     MCRow bind = MCRow.create();
/* 1369 */     bind.setStringNE("user_id", user);
/* 1370 */     if (Query.FCBAL0020_FCT_PUSHMSG_SEND_S01().executeQuery(bind, sendL) == 0) {
/* 1371 */       return sendL;
/*      */     }
/* 1373 */     if (unrecv_col != null) {
/* 1374 */       sendL.addBooleanColumn(unrecv_col, false);
/*      */     }
/*      */ 
/*      */     
/* 1378 */     MCList<FCT_PUSHMSG_SEND_R> unread_allL = 
/* 1379 */       sendL.subList("recv_dt", null);
/* 1380 */     MCList<FCT_PUSHMSG_SEND_R> unreadL = 
/* 1381 */       unread_allL.subList("importance", 
/* 1382 */         MCBooleanUtil.booleanToDBString(false));
/* 1383 */     unreadL.setDate("recv_dt", MCDate.now());
/* 1384 */     MCQueryApiBuilder builder = MCQueryApiBuilder.create((MCDBContainer)FCT_PUSHMSG_SEND_R.create("T"));
/* 1385 */     MCDBUtil.dbUpdateKey("FC_MCServerPushManager_getReceiveHistory", unreadL, builder);
/* 1386 */     if (unrecv_col != null) {
/* 1387 */       unread_allL.setBoolean(unrecv_col, true);
/*      */     }
/*      */     
/* 1390 */     return sendL;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCJoinKey<MCList<FCT_PUSHMSG_R>> joinReceiveHistoryMsg(MCList<FCT_PUSHMSG_SEND_R> sendL) {
/* 1406 */     MCList<FCT_PUSHMSG_R> msgL = MCList.create(FCT_PUSHMSG_R.class);
/* 1407 */     FCT_PUSHMSG_R dbc = FCT_PUSHMSG_R.create("T");
/* 1408 */     MCQueryApiBuilder builder = MCQueryApiBuilder.create((MCDBContainer)dbc);
/* 1409 */     builder.setSelectAll();
/* 1410 */     builder.setWhere(dbc.push_id.eq(IFMCSQL.bind("PUSH_ID")), new Comparable[0]);
/* 1411 */     MCDBUtil.dbSelect("FC_MCServerPushManager_joinReceiveHistoryMsg", msgL, builder, sendL);
/* 1412 */     return sendL.join("push_id", msgL, "push_id");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCJoinKey<MCList<FCT_PUSHMSG_SCREEN_R>> joinReceiveHistoryScreen(MCList<FCT_PUSHMSG_SEND_R> sendL) {
/* 1428 */     MCList<FCT_PUSHMSG_SCREEN_R> scrL = MCList.create(FCT_PUSHMSG_SCREEN_R.class);
/* 1429 */     FCT_PUSHMSG_SCREEN_R dbc = FCT_PUSHMSG_SCREEN_R.create("T");
/* 1430 */     MCQueryApiBuilder builder = MCQueryApiBuilder.create((MCDBContainer)dbc);
/* 1431 */     builder.setWhere(dbc.push_id.eq(IFMCSQL.bind("PUSH_ID")), new Comparable[0]);
/* 1432 */     MCDBUtil.dbSelect("FC_MCServerPushManager_joinReceiveHistoryScreen", scrL, builder, sendL);
/* 1433 */     return sendL.join("push_id", scrL, "push_id");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void deleteReceiveHistory(MCList<FCT_PUSHMSG_SEND_R> list) {
/* 1447 */     MCList<FCT_PUSHMSG_SEND_R> delL = MCList.create(FCT_PUSHMSG_SEND_R.class);
/* 1448 */     FCT_PUSHMSG_SEND_R dbc = FCT_PUSHMSG_SEND_R.create("T");
/* 1449 */     if (MCDBUtil.dbSelectKeyForUpdate("FC_MCServerPushManager_deleteReceiveHistory_1", delL, (MCDBContainer)dbc, list) > 0) {
/* 1450 */       MCDBUtil.dbDeleteKey("FC_MCServerPushManager_deleteReceiveHistory_2", delL, (MCDBContainer)dbc);
/*      */     }
/*      */ 
/*      */     
/* 1454 */     getManager().deleteUnusedMessage();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCList<FCM_PUSHMSG_SETTING_R> getReceiveSetting(String user) {
/* 1466 */     MCList<FCM_PUSHMSG_SETTING_R> setL = MCList.create(FCM_PUSHMSG_SETTING_R.class);
/* 1467 */     FCM_PUSHMSG_SETTING_R dbc = FCM_PUSHMSG_SETTING_R.create("M");
/* 1468 */     MCQueryApiBuilder builder = MCQueryApiBuilder.create((MCDBContainer)dbc);
/* 1469 */     builder.setWhere(dbc.user_id.eq(IFMCSQL.bind("1")), new Comparable[] { user });
/* 1470 */     MCDBUtil.dbSelect("FC_MCServerPushManager_getReceiveSetting", setL, builder);
/* 1471 */     return setL;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setReceiveSetting(MCList<FCM_PUSHMSG_SETTING_R> typeL, MCList<FCM_PUSHMSG_SETTING_R> commonL) {
/* 1488 */     MCList<FCM_PUSHMSG_SETTING_R> defaultL = 
/* 1489 */       typeL.subList("param_val", "3");
/* 1490 */     typeL.removeAll((Collection)defaultL);
/*      */ 
/*      */ 
/*      */     
/* 1494 */     MCList<FCM_PUSHMSG_SETTING_R> delL = MCList.create(FCM_PUSHMSG_SETTING_R.class);
/* 1495 */     FCM_PUSHMSG_SETTING_R dbc = FCM_PUSHMSG_SETTING_R.create("M");
/* 1496 */     MCDBUtil.dbSelectKeyForUpdate("FC_MCServerPushManager_setReceiveSetting_1", 
/* 1497 */         delL, (MCDBContainer)dbc, defaultL);
/* 1498 */     MCDBUtil.dbDeleteKey("FC_MCServerPushManager_setReceiveSetting_2", delL, (MCDBContainer)dbc);
/*      */     
/* 1500 */     IFMCSQL.MCPredicate where = IFMCSQL.value(0).eq(IFMCSQL.value(0))
/* 1501 */       .and(dbc.module_id.eq(IFMCSQL.value("*")))
/* 1502 */       .and(dbc.logic_id.eq(IFMCSQL.value("*")))
/* 1503 */       .and(dbc.operation_id.eq(IFMCSQL.value("*")))
/* 1504 */       .and(dbc.user_id.eq(IFMCSQL.bind("USER_ID")));
/* 1505 */     MCDBUtil.execDbDelete("FC_MCServerPushManager_setReceiveSetting_3", (MCDBContainer)dbc, where, 
/* 1506 */         commonL.groupBy(new String[] { "user_id" }));
/*      */ 
/*      */     
/* 1509 */     MCList<FCM_PUSHMSG_SETTING_R> insL = MCList.create(FCM_PUSHMSG_SETTING_R.class);
/* 1510 */     MCList<FCM_PUSHMSG_SETTING_R> updL = MCList.create(FCM_PUSHMSG_SETTING_R.class);
/* 1511 */     if (MCDBUtil.dbSelectKeyForUpdate("FC_MCServerPushManager_setReceiveSetting_4", updL, (MCDBContainer)dbc, typeL) > 0) {
/* 1512 */       String[] keys = ((FCM_PUSHMSG_SETTING_R)typeL.get(0)).getKeyColumn();
/* 1513 */       MCJoinKey<MCList<FCM_PUSHMSG_SETTING_R>> joinupd = 
/* 1514 */         typeL.join(keys, updL, keys);
/* 1515 */       for (FCM_PUSHMSG_SETTING_R typeR : typeL) {
/* 1516 */         FCM_PUSHMSG_SETTING_R joinR = (FCM_PUSHMSG_SETTING_R)typeR.getJoinedRow(joinupd);
/* 1517 */         if (joinR == null) {
/* 1518 */           insL.add((MCRow)typeR);
/*      */         }
/*      */       } 
/*      */     } else {
/*      */       
/* 1523 */       insL.addAll((Collection)typeL);
/*      */     } 
/*      */     
/* 1526 */     typeL.removeAll((Collection)insL);
/*      */ 
/*      */     
/* 1529 */     insL.addAll((Collection)commonL);
/*      */ 
/*      */     
/* 1532 */     MCQueryApiBuilder builder = MCQueryApiBuilder.create((MCDBContainer)dbc);
/* 1533 */     MCDBUtil.dbUpdateKey("FC_MCServerPushManager_setReceiveSetting_5", typeL, builder);
/* 1534 */     MCDBUtil.dbInsert("FC_MCServerPushManager_setReceiveSetting_6", insL, builder);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setReceiveType(FCM_PUSHMSG_SETTING_R typeR) {
/* 1547 */     if (typeR.param_key() != null) {
/*      */       String str;
/*      */       
/* 1550 */       switch ((str = typeR.param_key()).hashCode()) { case -1973663180: if (!str.equals("$history$")) break;  return;case 779233860: if (!str.equals("$level$")) {
/*      */             break;
/*      */           }
/*      */           return; }
/*      */ 
/*      */       
/* 1556 */       FCM_PUSHMSG_SETTING_R lockR = FCM_PUSHMSG_SETTING_R.create("M");
/* 1557 */       if (typeR.param_key() != null) {
/*      */         String str1;
/*      */         
/* 1560 */         switch ((str1 = typeR.param_val()).hashCode()) { case 51: if (!str1.equals("3")) {
/*      */               break;
/*      */             }
/* 1563 */             if (MCDBUtil.dbSelectKeyForUpdate("FC_MCServerPushManager_setReceiveType_1", (MCRow)lockR, (MCDBContainer)lockR, (MCRow)typeR) > 0) {
/* 1564 */               MCDBUtil.dbDeleteKey("FC_MCServerPushManager_setReceiveType_2", (MCRow)typeR, (MCDBContainer)lockR);
/*      */             }
/*      */             return; }
/*      */         
/* 1568 */         MCQueryApiBuilder builder = MCQueryApiBuilder.create((MCDBContainer)lockR);
/* 1569 */         if (MCDBUtil.dbSelectKeyForUpdate("FC_MCServerPushManager_setReceiveType_3", (MCRow)lockR, (MCDBContainer)lockR, (MCRow)typeR) > 0) {
/*      */           
/* 1571 */           MCDBUtil.dbUpdateKey("FC_MCServerPushManager_setReceiveType_4", (MCRow)typeR, builder);
/*      */         }
/*      */         else {
/*      */           
/* 1575 */           MCDBUtil.dbInsert("FC_MCServerPushManager_setReceiveType_5", (MCRow)typeR, builder);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void checkUnreadMessage(MCOperationInfo ope, MCList<? extends MCRow> list, String usercol) {
/* 1603 */     MCList<Broadcast2_UserR> userL = MCList.create(Broadcast2_UserR.class);
/*      */     
/* 1605 */     MCPushMessage push = new MCPushMessage(new MCMessage(Core_Msg_FW_A.FCBGC0420, new Object[0]), false);
/*      */     
/* 1607 */     push.setScreenPC("FS", "FSBGP0120");
/* 1608 */     push.addScreenParamPC("$action$", "__search__");
/*      */ 
/*      */     
/* 1611 */     list.forEach(row -> {
/*      */           String userid = row.getStringNE(paramString);
/*      */           
/*      */           if (userid != null) {
/*      */             int cnt_imp = 0;
/*      */             
/*      */             int cnt_nrm = 0;
/*      */             
/*      */             MCList<FCT_PUSHMSG_R> msgL = MCList.create(FCT_PUSHMSG_R.class);
/*      */             
/*      */             MCRow bind = MCRow.create();
/*      */             
/*      */             bind.setStringNE("user_id", userid);
/*      */             
/*      */             if (Query.FCBAL0020_FCT_PUSHMSG_SEND_S02().executeQuery(bind, msgL) > 0) {
/*      */               for (FCT_PUSHMSG_R msgR : msgL) {
/*      */                 if (msgR.importance()) {
/*      */                   cnt_imp += msgR.getNumber("count").intValue();
/*      */                   
/*      */                   continue;
/*      */                 } 
/*      */                 
/*      */                 cnt_nrm += msgR.getNumber("count").intValue();
/*      */               } 
/*      */             }
/*      */             
/*      */             MCPushMessage m = new MCPushMessage(new MCMessage(Core_Msg_FW_A.FCBGC0420, new Object[] { Integer.valueOf(cnt_imp + cnt_nrm), Integer.valueOf(cnt_imp), Integer.valueOf(cnt_nrm) }), false);
/*      */             
/*      */             Broadcast2_UserR userR = (Broadcast2_UserR)paramMCList.createRow();
/*      */             
/*      */             userR.userid(userid);
/*      */             userR.msgid(m.getMessage().getID());
/*      */             userR.msgbind(createMessageBindForDB(m.getMessage()));
/*      */             if (m.getTitle() != null) {
/*      */               userR.titleid(m.getTitle().getID());
/*      */               userR.titlebind(createMessageBindForDB(m.getTitle()));
/*      */             } 
/*      */             userR.importance(m.isImportance());
/*      */             paramMCList.add((MCRow)userR);
/*      */           } 
/*      */         });
/* 1652 */     Broadcast2_NoticeR noticeR = Broadcast2_NoticeR.create();
/* 1653 */     noticeR.pushid(MCNumber.valueOf(-1002));
/* 1654 */     noticeR.userid(MCSys.user.ID());
/* 1655 */     noticeR.cocd(MCSys.user.coCD());
/* 1656 */     noticeR.modid(ope.moduleId);
/* 1657 */     noticeR.logid(ope.logicId);
/* 1658 */     noticeR.opeid(ope.operationId);
/*      */ 
/*      */     
/* 1661 */     MCList<ScreenR> screenL = MCList.create(ScreenR.class);
/* 1662 */     convScreenParamToList(push, screenL, "type", "key", "val");
/*      */ 
/*      */     
/* 1665 */     sendMessageSocket(noticeR, userL, screenL);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void updateGadgetList(MCOperationInfo ope, boolean user, String... ids) {
/* 1679 */     MCPushMessage push = new MCPushMessage(
/* 1680 */         new MCMessage(Core_Msg_FW_A.FCBGC0444, (Object[])ids), 
/* 1681 */         false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1687 */     MCList<UserR> userL = MCList.create(UserR.class);
/* 1688 */     if (user) {
/*      */       
/* 1690 */       UserR userR = (UserR)userL.add();
/* 1691 */       userR.userid(MCSys.user.ID());
/*      */     }
/*      */     else {
/*      */       
/* 1695 */       String[] userids = this._pushAuth.getActiveUsers(MCSys.user.coCD()); byte b; int i; String[] arrayOfString1;
/* 1696 */       for (i = (arrayOfString1 = userids).length, b = 0; b < i; ) { String userid = arrayOfString1[b];
/* 1697 */         UserR userR = (UserR)userL.add();
/* 1698 */         userR.userid(userid);
/*      */         
/*      */         b++; }
/*      */     
/*      */     } 
/* 1703 */     sendMessageSocket(MCNumber.valueOf(-2001), 
/* 1704 */         MCSys.user.ID(), MCSys.user.coCD(), 
/* 1705 */         ope.moduleId, ope.logicId, ope.operationId, 
/* 1706 */         push, userL);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void updateGadgetData(MCOperationInfo ope, String... ids) {
/* 1719 */     MCPushMessage push = new MCPushMessage(
/* 1720 */         new MCMessage(Core_Msg_FW_A.FCBGC0450, (Object[])ids), 
/* 1721 */         false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1727 */     MCList<UserR> userL = MCList.create(UserR.class);
/* 1728 */     String[] userids = this._pushAuth.getActiveUsers(MCSys.user.coCD()); byte b; int i; String[] arrayOfString1;
/* 1729 */     for (i = (arrayOfString1 = userids).length, b = 0; b < i; ) { String userid = arrayOfString1[b];
/* 1730 */       UserR userR = (UserR)userL.add();
/* 1731 */       userR.userid(userid);
/*      */       
/*      */       b++; }
/*      */     
/* 1735 */     sendMessageSocket(MCNumber.valueOf(-2002), 
/* 1736 */         MCSys.user.ID(), MCSys.user.coCD(), 
/* 1737 */         ope.moduleId, ope.logicId, ope.operationId, 
/* 1738 */         push, userL);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void closeUserSession(String... users) {
/* 1755 */     MCList<UserR> userL = MCList.create(UserR.class); byte b1; int i; String[] arrayOfString;
/* 1756 */     for (i = (arrayOfString = users).length, b1 = 0; b1 < i; ) { String user = arrayOfString[b1];
/* 1757 */       UserR userR = (UserR)userL.add();
/* 1758 */       userR.userid(user);
/*      */       
/*      */       b1++; }
/*      */     
/* 1762 */     MCBroadcastCaller<MCServerPush_FW.Close> caller = 
/* 1763 */       new MCBroadcastCaller();
/* 1764 */     MCServerPush_FW.Close close = MCServerPush.crtClose();
/* 1765 */     close.up0().addAll((Collection)userL);
/* 1766 */     MCServerPush_FW.Close[] ops = (MCServerPush_FW.Close[])caller.broadcast((MCOperation)close); byte b2; int j; MCServerPush_FW.Close[] arrayOfClose1;
/* 1767 */     for (j = (arrayOfClose1 = ops).length, b2 = 0; b2 < j; ) { MCServerPush_FW.Close op = arrayOfClose1[b2];
/* 1768 */       MCException e = caller.getException((MCOperation)op);
/* 1769 */       if (e != null) {
/* 1770 */         if (e instanceof mcframe.commonCore.notice.MCServerException || e instanceof mcframe.commonCore.notice.MCServerAppException) {
/*      */           
/* 1772 */           MCClusterCaller<MCServerPush_FW.Close>.Task task = caller.getTask((MCOperation)op);
/* 1773 */           int taskno = task.getNo();
/* 1774 */           String url = task.getURL();
/* 1775 */           String clreqno = task.getParam().getClientRequestNo();
/* 1776 */           String svreqno = task.getParam().getServerRequestNo();
/* 1777 */           MCLog.write(Core_Msg_FW_A.FCBGC0439, new Object[] { Integer.valueOf(taskno), url, clreqno, svreqno });
/*      */         }
/*      */         else {
/*      */           
/* 1781 */           MCLog.write((Throwable)e);
/*      */         } 
/*      */       }
/*      */       b2++; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void push(NoticeR noticeR, MCList<UserR> userL, MCList<ScreenR> screenL) {
/* 1806 */     MCServerPushProxy proxy = getProxy();
/* 1807 */     if (proxy == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 1812 */     MCParam param = createPushParam(noticeR, userL, screenL);
/*      */ 
/*      */     
/* 1815 */     MCDPFormat format = MCDPFormat.JSON;
/* 1816 */     MCP2THeaderReader dRdrH = MCDPReaderFactory.downHeaderToText(format);
/* 1817 */     MCP2TBodyReader dRdrB = MCDPReaderFactory.downBodyToText(
/* 1818 */         format, MCDPParseType.NOMAL);
/*      */ 
/*      */     
/* 1821 */     for (Map.Entry<String, UserSession> entry : this._userMap.entrySet()) {
/* 1822 */       UserSession user = entry.getValue();
/* 1823 */       if (userL.getFirst("userid", user.userid) != null) {
/*      */         
/* 1825 */         Locale locale = MCResource.convLocale(user.locale);
/* 1826 */         param.setClientLocale(locale);
/*      */ 
/*      */         
/* 1829 */         noticeR.title(createTitle(
/* 1830 */               noticeR.titleid(), noticeR.titlebind(), 
/* 1831 */               noticeR.modid(), noticeR.logid(), noticeR.opeid(), 
/* 1832 */               locale));
/*      */ 
/*      */         
/* 1835 */         StringWriter sw = new StringWriter(1024);
/* 1836 */         MCDPWriter dpw = new MCDPWriter(sw, false);
/* 1837 */         dRdrH.read(param, dpw);
/* 1838 */         dRdrB.read(param, dpw);
/* 1839 */         proxy.send(noticeR.pushid(), sw.toString(), new String[] { entry.getKey() });
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void push(Broadcast2_NoticeR noticeR, MCList<Broadcast2_UserR> userL, MCList<ScreenR> screenL) {
/* 1856 */     MCServerPushProxy proxy = getProxy();
/* 1857 */     if (proxy == null) {
/*      */       return;
/*      */     }
/*      */     
/* 1861 */     if (this._userMap.isEmpty()) {
/*      */       return;
/*      */     }
/*      */     
/* 1865 */     for (int i = 0; i < userL.size(); i++) {
/* 1866 */       Broadcast2_UserR userR = (Broadcast2_UserR)userL.get(i);
/*      */       
/* 1868 */       NoticeR n = NoticeR.create();
/* 1869 */       n.pushid(noticeR.pushid());
/* 1870 */       n.userid(noticeR.userid());
/* 1871 */       n.cocd(noticeR.cocd());
/* 1872 */       n.modid(noticeR.modid());
/* 1873 */       n.logid(noticeR.logid());
/* 1874 */       n.opeid(noticeR.opeid());
/* 1875 */       n.msgid(userR.msgid());
/* 1876 */       n.msgbind(userR.msgbind());
/* 1877 */       n.titleid(userR.titleid());
/* 1878 */       n.titlebind(userR.titlebind());
/* 1879 */       n.title(userR.title());
/* 1880 */       n.importance(userR.importance());
/*      */       
/* 1882 */       MCList<UserR> uL = MCList.create(UserR.class);
/* 1883 */       ((UserR)uL.add()).userid(userR.userid());
/*      */ 
/*      */       
/* 1886 */       MCParam param = createPushParam(n, uL, screenL);
/*      */ 
/*      */       
/* 1889 */       MCDPFormat format = MCDPFormat.JSON;
/* 1890 */       MCP2THeaderReader dRdrH = MCDPReaderFactory.downHeaderToText(format);
/* 1891 */       MCP2TBodyReader dRdrB = MCDPReaderFactory.downBodyToText(format, 
/* 1892 */           MCDPParseType.NOMAL);
/*      */ 
/*      */       
/* 1895 */       for (Map.Entry<String, UserSession> entry : this._userMap.entrySet()) {
/* 1896 */         UserSession user = entry.getValue();
/* 1897 */         if (userR.userid().equals(user.userid)) {
/*      */           
/* 1899 */           Locale locale = MCResource.convLocale(user.locale);
/* 1900 */           param.setClientLocale(locale);
/*      */ 
/*      */           
/* 1903 */           n.title(createTitle(n.titleid(), n.titlebind(), n.modid(), n.logid(), 
/* 1904 */                 n.opeid(), locale));
/*      */           
/* 1906 */           StringWriter sw = new StringWriter(1024);
/* 1907 */           MCDPWriter dpw = new MCDPWriter(sw, false);
/* 1908 */           dRdrH.read(param, dpw);
/* 1909 */           dRdrB.read(param, dpw);
/* 1910 */           proxy.send(n.pushid(), sw.toString(), new String[] { entry.getKey() });
/*      */           break;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MCParam createPushParam(NoticeR noticeR, MCList<UserR> userL, MCList<ScreenR> screenL) {
/* 1929 */     MCOperationInfo ope = new MCOperationInfo(
/* 1930 */         "FC", "FCBGL0100", "Notice", "000000", (MCDef)new PDef());
/* 1931 */     MCParam param = new MCParam(ope);
/* 1932 */     param.setLimitDLSize(MCNumber.valueOf(-1));
/*      */ 
/*      */     
/* 1935 */     MCMessage message = createMessageFromDB(noticeR.msgid(), noticeR.msgbind());
/* 1936 */     MCMessageRowParam row = new MCMessageRowParam();
/* 1937 */     row.setMsg(message);
/* 1938 */     param.getMessageParam().addMessageRow(row);
/*      */     
/* 1940 */     param.addDownBlock((MCContainer)noticeR);
/* 1941 */     param.addDownBlock((MCContainer)screenL);
/* 1942 */     return param;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   UserSession authenticated(String session) {
/* 1957 */     UserSession user = this._userMap.get(session);
/* 1958 */     if (user == null) {
/* 1959 */       return null;
/*      */     }
/*      */ 
/*      */     
/* 1963 */     MCMessage msg = new MCMessage(Core_Msg_FW_A.FCBGC0416, new Object[] {
/* 1964 */           MCConfig.server.getString("server.name")
/*      */         });
/*      */     
/* 1967 */     NoticeR noticeR = NoticeR.create();
/* 1968 */     MCList<UserR> userL = MCList.create(UserR.class);
/* 1969 */     MCList<ScreenR> screenL = MCList.create(ScreenR.class);
/*      */ 
/*      */     
/* 1972 */     UserR userR = (UserR)userL.createRow();
/* 1973 */     userR.userid(user.userid);
/* 1974 */     userL.add((MCRow)userR);
/*      */ 
/*      */     
/* 1977 */     noticeR.pushid(-1001);
/* 1978 */     noticeR.msgid(msg.getID());
/* 1979 */     noticeR.msgbind(createMessageBindForDB(msg));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1985 */     push(noticeR, userL, screenL);
/*      */     
/* 1987 */     return user;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void close(MCList<UserR> userL) {
/* 2000 */     MCServerPushProxy proxy = getProxy();
/* 2001 */     if (proxy == null) {
/*      */       return;
/*      */     }
/*      */     
/* 2005 */     List<String> list = new ArrayList<>();
/* 2006 */     for (Map.Entry<String, UserSession> entry : this._userMap.entrySet()) {
/* 2007 */       UserSession user = entry.getValue();
/* 2008 */       if (userL.getFirst("userid", user.userid) != null) {
/* 2009 */         list.add(entry.getKey());
/*      */       }
/*      */     } 
/*      */     
/* 2013 */     proxy.close(list.<String>toArray(new String[list.size()]));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void disable() {
/* 2027 */     MCServerPushProxy proxy = getProxy();
/* 2028 */     if (proxy == null) {
/*      */       return;
/*      */     }
/*      */     
/* 2032 */     proxy.disable();
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\push\MCServerPushManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */