/*    */ package mcframe.serverCore.push;
/*    */ 
/*    */ import mcframe.commonCore.container.MCList;
/*    */ import mcframe.commonCore.param.MCOperationInfo;
/*    */ import mcframe.serverCore.push.ctrl.Broadcast2_NoticeR;
/*    */ import mcframe.serverCore.push.ctrl.Broadcast2_UserR;
/*    */ import mcframe.serverCore.push.ctrl.NoticeR;
/*    */ import mcframe.serverCore.push.ctrl.ScreenR;
/*    */ import mcframe.serverCore.push.ctrl.UserR;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbsMCPackageProxy
/*    */ {
/*    */   protected void push(NoticeR noticeR, MCList<UserR> userL, MCList<ScreenR> screenL) {
/* 39 */     MCServerPushManager.getManager().push(noticeR, userL, screenL);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void push(Broadcast2_NoticeR noticeR, MCList<Broadcast2_UserR> userL, MCList<ScreenR> screenL) {
/* 50 */     MCServerPushManager.getManager().push(noticeR, userL, screenL);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void close(MCList<UserR> userL) {
/* 60 */     MCServerPushManager.getManager().close(userL);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void updateGadgetList(MCOperationInfo ope, boolean user, String... ids) {
/* 70 */     MCServerPushManager.getManager().updateGadgetList(ope, user, ids);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void updateGadgetData(MCOperationInfo ope, String... ids) {
/* 80 */     MCServerPushManager.getManager().updateGadgetData(ope, ids);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\push\AbsMCPackageProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */