/*      */ package mcframe.serverCore.push.ctrl;
/*      */ 
/*      */ import mcframe.commonCore.container.MCContainer;
/*      */ import mcframe.commonCore.container.MCList;
/*      */ import mcframe.commonCore.param.MCOperationInfo;
/*      */ import mcframe.commonCore.param.MCParam;
/*      */ import mcframe.serverCore.logic.MCLogic;
/*      */ import mcframe.serverCore.logic.MCLogicBase;
/*      */ import mcframe.serverCore.logic.MCLogicUtil;
/*      */ import mcframe.serverCore.logic.MCOperation;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class MCServerPush_FW_A
/*      */   extends MCLogicBase
/*      */ {
/*      */   public static final String MODULE_ID = "FC";
/*      */   public static final String SUBMODULE_ID = "FCBG";
/*      */   public static final String LOGIC_ID = "FCBGL0100";
/*      */   protected MCServerPush_FW.Broadcast aBroadcast;
/*      */   protected MCServerPush_FW.Broadcast2 aBroadcast2;
/*      */   protected MCServerPush_FW.Close aClose;
/*      */   protected MCServerPush_FW.Unread aUnread;
/*      */   protected MCServerPush_FW.Read aRead;
/*      */   protected MCServerPush_FW.ClientSend aClientSend;
/*      */   
/*      */   public String getModuleID() {
/*   42 */     return "FC";
/*      */   } public String getSubmoduleID() {
/*   44 */     return "FCBG";
/*      */   } public String getLogicID() {
/*   46 */     return "FCBGL0100";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initBroadcast() {
/*   53 */     this.info = PDef.FC_FCBGL0100_Broadcast_INFO;
/*   54 */     ((MCServerPush)this).getClass(); this.aBroadcast = new MCServerPush_FW.Broadcast((MCServerPush)this);
/*      */   }
/*      */   
/*      */   public static MCServerPush_FW.Broadcast crtBroadcast() {
/*   58 */     MCServerPush lgc = new MCServerPush();
/*   59 */     lgc.initBroadcast();
/*   60 */     return lgc.aBroadcast;
/*      */   }
/*      */   
/*      */   protected void paramBroadcast(MCParam p) {
/*   64 */     if (this.aBroadcast == null) {
/*      */       return;
/*      */     }
/*   67 */     p.setDef(this.info.def);
/*   68 */     p.addUpBlock((MCContainer)this.aBroadcast.up0());
/*   69 */     p.addUpBlock((MCContainer)this.aBroadcast.up1());
/*   70 */     p.addUpBlock((MCContainer)this.aBroadcast.up2());
/*      */   }
/*      */   
/*      */   protected void doBroadcast() {
/*   74 */     this.aBroadcast.call();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NoticeR createNoticeR() {
/*   83 */     return NoticeR.create();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public UserR createUserR() {
/*   92 */     return UserR.create();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCList<UserR> createUserL() {
/*  101 */     return MCList.create(UserR.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ScreenR createScreenR() {
/*  110 */     return ScreenR.create();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCList<ScreenR> createScreenL() {
/*  119 */     return MCList.create(ScreenR.class);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void initBroadcast2() {
/*  124 */     this.info = PDef.FC_FCBGL0100_Broadcast2_INFO;
/*  125 */     ((MCServerPush)this).getClass(); this.aBroadcast2 = new MCServerPush_FW.Broadcast2((MCServerPush)this);
/*      */   }
/*      */   
/*      */   public static MCServerPush_FW.Broadcast2 crtBroadcast2() {
/*  129 */     MCServerPush lgc = new MCServerPush();
/*  130 */     lgc.initBroadcast2();
/*  131 */     return lgc.aBroadcast2;
/*      */   }
/*      */   
/*      */   protected void paramBroadcast2(MCParam p) {
/*  135 */     if (this.aBroadcast2 == null) {
/*      */       return;
/*      */     }
/*  138 */     p.setDef(this.info.def);
/*  139 */     p.addUpBlock((MCContainer)this.aBroadcast2.up0());
/*  140 */     p.addUpBlock((MCContainer)this.aBroadcast2.up1());
/*  141 */     p.addUpBlock((MCContainer)this.aBroadcast2.up2());
/*      */   }
/*      */   
/*      */   protected void doBroadcast2() {
/*  145 */     this.aBroadcast2.call();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Broadcast2_NoticeR createBroadcast2_NoticeR() {
/*  154 */     return Broadcast2_NoticeR.create();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Broadcast2_UserR createBroadcast2_UserR() {
/*  163 */     return Broadcast2_UserR.create();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCList<Broadcast2_UserR> createBroadcast2_UserL() {
/*  172 */     return MCList.create(Broadcast2_UserR.class);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void initClose() {
/*  177 */     this.info = PDef.FC_FCBGL0100_Close_INFO;
/*  178 */     ((MCServerPush)this).getClass(); this.aClose = new MCServerPush_FW.Close((MCServerPush)this);
/*      */   }
/*      */   
/*      */   public static MCServerPush_FW.Close crtClose() {
/*  182 */     MCServerPush lgc = new MCServerPush();
/*  183 */     lgc.initClose();
/*  184 */     return lgc.aClose;
/*      */   }
/*      */   
/*      */   protected void paramClose(MCParam p) {
/*  188 */     if (this.aClose == null) {
/*      */       return;
/*      */     }
/*  191 */     p.setDef(this.info.def);
/*  192 */     p.addUpBlock((MCContainer)this.aClose.up0());
/*      */   }
/*      */   
/*      */   protected void doClose() {
/*  196 */     this.aClose.call();
/*      */   }
/*      */ 
/*      */   
/*      */   protected void initUnread() {
/*  201 */     this.info = PDef.FC_FCBGL0100_Unread_INFO;
/*  202 */     ((MCServerPush)this).getClass(); this.aUnread = new MCServerPush_FW.Unread((MCServerPush)this);
/*      */   }
/*      */   
/*      */   public static MCServerPush_FW.Unread crtUnread() {
/*  206 */     MCServerPush lgc = new MCServerPush();
/*  207 */     lgc.initUnread();
/*  208 */     return lgc.aUnread;
/*      */   }
/*      */   
/*      */   protected void paramUnread(MCParam p) {
/*  212 */     if (this.aUnread == null) {
/*      */       return;
/*      */     }
/*  215 */     p.setDef(this.info.def);
/*  216 */     p.addUpBlock((MCContainer)this.aUnread.up0());
/*      */   }
/*      */   
/*      */   protected void doUnread() {
/*  220 */     this.aUnread.call();
/*      */   }
/*      */ 
/*      */   
/*      */   protected void initRead() {
/*  225 */     this.info = PDef.FC_FCBGL0100_Read_INFO;
/*  226 */     ((MCServerPush)this).getClass(); this.aRead = new MCServerPush_FW.Read((MCServerPush)this);
/*      */   }
/*      */   
/*      */   public static MCServerPush_FW.Read crtRead() {
/*  230 */     MCServerPush lgc = new MCServerPush();
/*  231 */     lgc.initRead();
/*  232 */     return lgc.aRead;
/*      */   }
/*      */   
/*      */   protected void paramRead(MCParam p) {
/*  236 */     if (this.aRead == null) {
/*      */       return;
/*      */     }
/*  239 */     p.setDef(this.info.def);
/*  240 */     p.addUpBlock((MCContainer)this.aRead.up0());
/*  241 */     p.addUpBlock((MCContainer)this.aRead.up1());
/*      */   }
/*      */   
/*      */   protected void doRead() {
/*  245 */     this.aRead.call();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCList<NoticeR> createNoticeL() {
/*  254 */     return MCList.create(NoticeR.class);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void initClientSend() {
/*  259 */     this.info = PDef.FC_FCBGL0100_ClientSend_INFO;
/*  260 */     ((MCServerPush)this).getClass(); this.aClientSend = new MCServerPush_FW.ClientSend((MCServerPush)this);
/*      */   }
/*      */   
/*      */   public static MCServerPush_FW.ClientSend crtClientSend() {
/*  264 */     MCServerPush lgc = new MCServerPush();
/*  265 */     lgc.initClientSend();
/*  266 */     return lgc.aClientSend;
/*      */   }
/*      */   
/*      */   protected void paramClientSend(MCParam p) {
/*  270 */     if (this.aClientSend == null) {
/*      */       return;
/*      */     }
/*  273 */     p.setDef(this.info.def);
/*  274 */     p.addUpBlock((MCContainer)this.aClientSend.up0());
/*  275 */     p.addUpBlock((MCContainer)this.aClientSend.up1());
/*  276 */     p.addUpBlock((MCContainer)this.aClientSend.up2());
/*      */   }
/*      */   
/*      */   protected void doClientSend() {
/*  280 */     this.aClientSend.call();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract class Broadcast
/*      */     extends MCOperation
/*      */   {
/*      */     public static final String OPERATION_ID = "Broadcast";
/*      */ 
/*      */     
/*      */     private final NoticeR up0;
/*      */ 
/*      */     
/*      */     private final MCList<UserR> up1;
/*      */ 
/*      */     
/*      */     private final MCList<ScreenR> up2;
/*      */ 
/*      */     
/*      */     public String getOperationID() {
/*  301 */       return "Broadcast";
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected Broadcast() {
/*  316 */       this.up0 = NoticeR.create();
/*  317 */       this.up1 = MCList.create(UserR.class);
/*  318 */       this.up2 = MCList.create(ScreenR.class);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void mapUpContainers(String key) {
/*  332 */       super.mapUpContainers(key);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void mapDownContainers(String key) {
/*  340 */       super.mapDownContainers(key);
/*      */     }
/*      */     
/*      */     public MCContainer up(int i) {
/*  344 */       if (i == 0) return (MCContainer)up0(); 
/*  345 */       if (i == 1) return (MCContainer)up1(); 
/*  346 */       if (i == 2) return (MCContainer)up2(); 
/*  347 */       return null;
/*      */     }
/*      */     
/*      */     public MCContainer down(int i) {
/*  351 */       return null;
/*      */     }
/*      */     
/*      */     public void exec() {
/*  355 */       clear();
/*  356 */       MCLogicUtil.invoke((MCLogic)MCServerPush_FW_A.this);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void clear() {}
/*      */ 
/*      */ 
/*      */     
/*      */     public NoticeR createNoticeR() {
/*  367 */       return NoticeR.create();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public UserR createUserR() {
/*  376 */       return UserR.create();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MCList<UserR> createUserL() {
/*  385 */       return MCList.create(UserR.class);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ScreenR createScreenR() {
/*  394 */       return ScreenR.create();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MCList<ScreenR> createScreenL() {
/*  403 */       return MCList.create(ScreenR.class);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public NoticeR up0() {
/*  429 */       return this.up0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MCList<UserR> up1() {
/*  444 */       return this.up1;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MCList<ScreenR> up2() {
/*  461 */       return this.up2;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MCOperationInfo getOperationInfo() {
/*  469 */       return MCServerPush_FW_A.this.info;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract class Broadcast2
/*      */     extends MCOperation
/*      */   {
/*      */     public static final String OPERATION_ID = "Broadcast2";
/*      */     
/*      */     private final Broadcast2_NoticeR up0;
/*      */     
/*      */     private final MCList<Broadcast2_UserR> up1;
/*      */     
/*      */     private final MCList<ScreenR> up2;
/*      */ 
/*      */     
/*      */     public String getOperationID() {
/*  488 */       return "Broadcast2";
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected Broadcast2() {
/*  503 */       this.up0 = Broadcast2_NoticeR.create();
/*  504 */       this.up1 = MCList.create(Broadcast2_UserR.class);
/*  505 */       this.up2 = MCList.create(ScreenR.class);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void mapUpContainers(String key) {
/*  519 */       super.mapUpContainers(key);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void mapDownContainers(String key) {
/*  527 */       super.mapDownContainers(key);
/*      */     }
/*      */     
/*      */     public MCContainer up(int i) {
/*  531 */       if (i == 0) return (MCContainer)up0(); 
/*  532 */       if (i == 1) return (MCContainer)up1(); 
/*  533 */       if (i == 2) return (MCContainer)up2(); 
/*  534 */       return null;
/*      */     }
/*      */     
/*      */     public MCContainer down(int i) {
/*  538 */       return null;
/*      */     }
/*      */     
/*      */     public void exec() {
/*  542 */       clear();
/*  543 */       MCLogicUtil.invoke((MCLogic)MCServerPush_FW_A.this);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void clear() {}
/*      */ 
/*      */ 
/*      */     
/*      */     public Broadcast2_NoticeR createBroadcast2_NoticeR() {
/*  554 */       return Broadcast2_NoticeR.create();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Broadcast2_UserR createBroadcast2_UserR() {
/*  563 */       return Broadcast2_UserR.create();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MCList<Broadcast2_UserR> createBroadcast2_UserL() {
/*  572 */       return MCList.create(Broadcast2_UserR.class);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ScreenR createScreenR() {
/*  581 */       return ScreenR.create();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MCList<ScreenR> createScreenL() {
/*  590 */       return MCList.create(ScreenR.class);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Broadcast2_NoticeR up0() {
/*  611 */       return this.up0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MCList<Broadcast2_UserR> up1() {
/*  631 */       return this.up1;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MCList<ScreenR> up2() {
/*  648 */       return this.up2;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MCOperationInfo getOperationInfo() {
/*  656 */       return MCServerPush_FW_A.this.info;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract class Close
/*      */     extends MCOperation
/*      */   {
/*      */     public static final String OPERATION_ID = "Close";
/*      */ 
/*      */ 
/*      */     
/*      */     private final MCList<UserR> up0;
/*      */ 
/*      */ 
/*      */     
/*      */     public String getOperationID() {
/*  675 */       return "Close";
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected Close() {
/*  686 */       this.up0 = MCList.create(UserR.class);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void mapUpContainers(String key) {
/*  700 */       super.mapUpContainers(key);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void mapDownContainers(String key) {
/*  708 */       super.mapDownContainers(key);
/*      */     }
/*      */     
/*      */     public MCContainer up(int i) {
/*  712 */       if (i == 0) return (MCContainer)up0(); 
/*  713 */       return null;
/*      */     }
/*      */     
/*      */     public MCContainer down(int i) {
/*  717 */       return null;
/*      */     }
/*      */     
/*      */     public void exec() {
/*  721 */       clear();
/*  722 */       MCLogicUtil.invoke((MCLogic)MCServerPush_FW_A.this);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void clear() {}
/*      */ 
/*      */ 
/*      */     
/*      */     public UserR createUserR() {
/*  733 */       return UserR.create();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MCList<UserR> createUserL() {
/*  742 */       return MCList.create(UserR.class);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MCList<UserR> up0() {
/*  758 */       return this.up0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MCOperationInfo getOperationInfo() {
/*  766 */       return MCServerPush_FW_A.this.info;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract class Unread
/*      */     extends MCOperation
/*      */   {
/*      */     public static final String OPERATION_ID = "Unread";
/*      */ 
/*      */ 
/*      */     
/*      */     private final MCList<UserR> up0;
/*      */ 
/*      */ 
/*      */     
/*      */     public String getOperationID() {
/*  785 */       return "Unread";
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected Unread() {
/*  796 */       this.up0 = MCList.create(UserR.class);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void mapUpContainers(String key) {
/*  810 */       super.mapUpContainers(key);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void mapDownContainers(String key) {
/*  818 */       super.mapDownContainers(key);
/*      */     }
/*      */     
/*      */     public MCContainer up(int i) {
/*  822 */       if (i == 0) return (MCContainer)up0(); 
/*  823 */       return null;
/*      */     }
/*      */     
/*      */     public MCContainer down(int i) {
/*  827 */       return null;
/*      */     }
/*      */     
/*      */     public void exec() {
/*  831 */       clear();
/*  832 */       MCLogicUtil.invoke((MCLogic)MCServerPush_FW_A.this);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void clear() {}
/*      */ 
/*      */ 
/*      */     
/*      */     public UserR createUserR() {
/*  843 */       return UserR.create();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MCList<UserR> createUserL() {
/*  852 */       return MCList.create(UserR.class);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MCList<UserR> up0() {
/*  868 */       return this.up0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MCOperationInfo getOperationInfo() {
/*  876 */       return MCServerPush_FW_A.this.info;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract class Read
/*      */     extends MCOperation
/*      */   {
/*      */     public static final String OPERATION_ID = "Read";
/*      */ 
/*      */     
/*      */     private final MCList<NoticeR> up0;
/*      */ 
/*      */     
/*      */     private final UserR up1;
/*      */ 
/*      */     
/*      */     public String getOperationID() {
/*  895 */       return "Read";
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected Read() {
/*  908 */       this.up0 = MCList.create(NoticeR.class);
/*  909 */       this.up1 = UserR.create();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void mapUpContainers(String key) {
/*  923 */       super.mapUpContainers(key);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void mapDownContainers(String key) {
/*  931 */       super.mapDownContainers(key);
/*      */     }
/*      */     
/*      */     public MCContainer up(int i) {
/*  935 */       if (i == 0) return (MCContainer)up0(); 
/*  936 */       if (i == 1) return (MCContainer)up1(); 
/*  937 */       return null;
/*      */     }
/*      */     
/*      */     public MCContainer down(int i) {
/*  941 */       return null;
/*      */     }
/*      */     
/*      */     public void exec() {
/*  945 */       clear();
/*  946 */       MCLogicUtil.invoke((MCLogic)MCServerPush_FW_A.this);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void clear() {}
/*      */ 
/*      */ 
/*      */     
/*      */     public NoticeR createNoticeR() {
/*  957 */       return NoticeR.create();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MCList<NoticeR> createNoticeL() {
/*  966 */       return MCList.create(NoticeR.class);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public UserR createUserR() {
/*  975 */       return UserR.create();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MCList<NoticeR> up0() {
/*  991 */       return this.up0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public UserR up1() {
/* 1006 */       return this.up1;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MCOperationInfo getOperationInfo() {
/* 1014 */       return MCServerPush_FW_A.this.info;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract class ClientSend
/*      */     extends MCOperation
/*      */   {
/*      */     public static final String OPERATION_ID = "ClientSend";
/*      */     
/*      */     private final NoticeR up0;
/*      */     
/*      */     private final MCList<UserR> up1;
/*      */     
/*      */     private final MCList<ScreenR> up2;
/*      */ 
/*      */     
/*      */     public String getOperationID() {
/* 1033 */       return "ClientSend";
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected ClientSend() {
/* 1048 */       this.up0 = NoticeR.create();
/* 1049 */       this.up1 = MCList.create(UserR.class);
/* 1050 */       this.up2 = MCList.create(ScreenR.class);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void mapUpContainers(String key) {
/* 1064 */       super.mapUpContainers(key);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void mapDownContainers(String key) {
/* 1072 */       super.mapDownContainers(key);
/*      */     }
/*      */     
/*      */     public MCContainer up(int i) {
/* 1076 */       if (i == 0) return (MCContainer)up0(); 
/* 1077 */       if (i == 1) return (MCContainer)up1(); 
/* 1078 */       if (i == 2) return (MCContainer)up2(); 
/* 1079 */       return null;
/*      */     }
/*      */     
/*      */     public MCContainer down(int i) {
/* 1083 */       return null;
/*      */     }
/*      */     
/*      */     public void exec() {
/* 1087 */       clear();
/* 1088 */       MCLogicUtil.invoke((MCLogic)MCServerPush_FW_A.this);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void clear() {}
/*      */ 
/*      */ 
/*      */     
/*      */     public NoticeR createNoticeR() {
/* 1099 */       return NoticeR.create();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public UserR createUserR() {
/* 1108 */       return UserR.create();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MCList<UserR> createUserL() {
/* 1117 */       return MCList.create(UserR.class);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public ScreenR createScreenR() {
/* 1126 */       return ScreenR.create();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MCList<ScreenR> createScreenL() {
/* 1135 */       return MCList.create(ScreenR.class);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public NoticeR up0() {
/* 1159 */       return this.up0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MCList<UserR> up1() {
/* 1174 */       return this.up1;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MCList<ScreenR> up2() {
/* 1191 */       return this.up2;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public MCOperationInfo getOperationInfo() {
/* 1199 */       return MCServerPush_FW_A.this.info;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\push\ctrl\MCServerPush_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */