/*     */ package mcframe.serverCore.push.ctrl;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.commonCore.container.MCConstRow;
/*     */ import mcframe.commonCore.container.MCExtMap;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class NoticeR_FW_A
/*     */   extends MCConstRow
/*     */ {
/*     */   public static final String $pushid = "pushid";
/*     */   public static final String $userid = "userid";
/*     */   public static final String $cocd = "cocd";
/*     */   public static final String $modid = "modid";
/*     */   public static final String $logid = "logid";
/*     */   public static final String $opeid = "opeid";
/*     */   public static final String $msgid = "msgid";
/*     */   public static final String $msgbind = "msgbind";
/*     */   public static final String $titleid = "titleid";
/*     */   public static final String $titlebind = "titlebind";
/*     */   public static final String $title = "title";
/*     */   public static final String $importance = "importance";
/*  90 */   public static final MCMeta pushid_META = createNumberMeta("pushid");
/*  91 */   public static final MCMeta userid_META = createStringMeta("userid");
/*  92 */   public static final MCMeta cocd_META = createStringMeta("cocd");
/*  93 */   public static final MCMeta modid_META = createStringMeta("modid");
/*  94 */   public static final MCMeta logid_META = createStringMeta("logid");
/*  95 */   public static final MCMeta opeid_META = createStringMeta("opeid");
/*  96 */   public static final MCMeta msgid_META = createStringMeta("msgid");
/*  97 */   public static final MCMeta msgbind_META = createStringMeta("msgbind");
/*  98 */   public static final MCMeta titleid_META = createStringMeta("titleid");
/*  99 */   public static final MCMeta titlebind_META = createStringMeta("titlebind");
/* 100 */   public static final MCMeta title_META = createStringMeta("title");
/* 101 */   public static final MCMeta importance_META = createBooleanMeta("importance");
/*     */   
/* 103 */   protected static final MCRow.ConstMetaList<NoticeR> constMetas = new MCRow.ConstMetaList(
/* 104 */       MCConstRow.constMetas, 
/* 105 */       new MCMeta[] { 
/* 106 */         pushid_META, 
/* 107 */         userid_META, 
/* 108 */         cocd_META, 
/* 109 */         modid_META, 
/* 110 */         logid_META, 
/* 111 */         opeid_META, 
/* 112 */         msgid_META, 
/* 113 */         msgbind_META, 
/* 114 */         titleid_META, 
/* 115 */         titlebind_META, 
/* 116 */         title_META, 
/* 117 */         importance_META
/*     */       },
/* 119 */       new String[][] { {}, {} });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 131 */   protected static final MCExtMap EXTMAP = new MCExtMap(
/* 132 */       null, new MCExtMap.Entry[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] colnames() {
/* 144 */     return constMetas.toNameArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMeta[] colmetas() {
/* 156 */     return constMetas.toMetaArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 162 */   private static final int offset = constMetas.offset();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getExtMap(String aGroup) {
/* 168 */     if (aGroup == null) return null; 
/* 169 */     return (Map<String, String>)EXTMAP.get(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getKeys(String aGroup) {
/* 176 */     if (aGroup == null) return null; 
/* 177 */     return EXTMAP.getKeyList(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExtGroups() {
/* 184 */     Set<String> ret = EXTMAP.keySet();
/* 185 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected NoticeR_FW_A(MCRow.ConstMetaList<? extends NoticeR> metas) {
/* 192 */     super(metas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NoticeR clone() {
/* 199 */     return (NoticeR)super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NoticeR createInstance() {
/* 206 */     return (NoticeR)super.createInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NoticeR getValues(String... names) {
/* 213 */     return (NoticeR)super.getValues(names);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireValueChanged(String column, Comparable<?> newvalue, Comparable<?> oldvalue) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCNumber pushid() {
/* 229 */     return getConstNumber(offset + 0, "pushid");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pushid(MCNumber value) {
/* 237 */     setConstNumber(offset + 0, "pushid", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pushid(int value) {
/* 245 */     setConstNumber(offset + 0, "pushid", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pushid(long value) {
/* 253 */     setConstNumber(offset + 0, "pushid", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pushid(float value) {
/* 261 */     setConstNumber(offset + 0, "pushid", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pushid(double value) {
/* 269 */     setConstNumber(offset + 0, "pushid", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String userid() {
/* 278 */     return getConstString(offset + 1, "userid");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void userid(String value) {
/* 286 */     setConstString(offset + 1, "userid", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String cocd() {
/* 295 */     return getConstString(offset + 2, "cocd");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cocd(String value) {
/* 303 */     setConstString(offset + 2, "cocd", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String modid() {
/* 312 */     return getConstString(offset + 3, "modid");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void modid(String value) {
/* 320 */     setConstString(offset + 3, "modid", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String logid() {
/* 329 */     return getConstString(offset + 4, "logid");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logid(String value) {
/* 337 */     setConstString(offset + 4, "logid", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String opeid() {
/* 346 */     return getConstString(offset + 5, "opeid");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void opeid(String value) {
/* 354 */     setConstString(offset + 5, "opeid", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String msgid() {
/* 363 */     return getConstString(offset + 6, "msgid");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void msgid(String value) {
/* 371 */     setConstString(offset + 6, "msgid", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String msgbind() {
/* 380 */     return getConstString(offset + 7, "msgbind");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void msgbind(String value) {
/* 388 */     setConstString(offset + 7, "msgbind", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String titleid() {
/* 397 */     return getConstString(offset + 8, "titleid");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void titleid(String value) {
/* 405 */     setConstString(offset + 8, "titleid", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String titlebind() {
/* 414 */     return getConstString(offset + 9, "titlebind");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void titlebind(String value) {
/* 422 */     setConstString(offset + 9, "titlebind", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String title() {
/* 431 */     return getConstString(offset + 10, "title");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void title(String value) {
/* 439 */     setConstString(offset + 10, "title", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean importance() {
/* 448 */     return getConstBoolean(offset + 11, "importance");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void importance(boolean value) {
/* 456 */     setConstBoolean(offset + 11, "importance", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString(String name) {
/* 461 */     if ("userid".equalsIgnoreCase(name)) {
/* 462 */       return userid();
/*     */     }
/* 464 */     if ("cocd".equalsIgnoreCase(name)) {
/* 465 */       return cocd();
/*     */     }
/* 467 */     if ("modid".equalsIgnoreCase(name)) {
/* 468 */       return modid();
/*     */     }
/* 470 */     if ("logid".equalsIgnoreCase(name)) {
/* 471 */       return logid();
/*     */     }
/* 473 */     if ("opeid".equalsIgnoreCase(name)) {
/* 474 */       return opeid();
/*     */     }
/* 476 */     if ("msgid".equalsIgnoreCase(name)) {
/* 477 */       return msgid();
/*     */     }
/* 479 */     if ("msgbind".equalsIgnoreCase(name)) {
/* 480 */       return msgbind();
/*     */     }
/* 482 */     if ("titleid".equalsIgnoreCase(name)) {
/* 483 */       return titleid();
/*     */     }
/* 485 */     if ("titlebind".equalsIgnoreCase(name)) {
/* 486 */       return titlebind();
/*     */     }
/* 488 */     if ("title".equalsIgnoreCase(name)) {
/* 489 */       return title();
/*     */     }
/* 491 */     return super.getString(name);
/*     */   }
/*     */   public MCNumber getNumber(String name) {
/* 494 */     if ("pushid".equalsIgnoreCase(name)) {
/* 495 */       return pushid();
/*     */     }
/* 497 */     return super.getNumber(name);
/*     */   }
/*     */   public boolean getBoolean(String name) {
/* 500 */     if ("importance".equalsIgnoreCase(name)) {
/* 501 */       return importance();
/*     */     }
/* 503 */     return super.getBoolean(name);
/*     */   }
/*     */   
/*     */   public String getStringNE(String name) {
/* 507 */     if ("userid".equalsIgnoreCase(name)) {
/* 508 */       return userid();
/*     */     }
/* 510 */     if ("cocd".equalsIgnoreCase(name)) {
/* 511 */       return cocd();
/*     */     }
/* 513 */     if ("modid".equalsIgnoreCase(name)) {
/* 514 */       return modid();
/*     */     }
/* 516 */     if ("logid".equalsIgnoreCase(name)) {
/* 517 */       return logid();
/*     */     }
/* 519 */     if ("opeid".equalsIgnoreCase(name)) {
/* 520 */       return opeid();
/*     */     }
/* 522 */     if ("msgid".equalsIgnoreCase(name)) {
/* 523 */       return msgid();
/*     */     }
/* 525 */     if ("msgbind".equalsIgnoreCase(name)) {
/* 526 */       return msgbind();
/*     */     }
/* 528 */     if ("titleid".equalsIgnoreCase(name)) {
/* 529 */       return titleid();
/*     */     }
/* 531 */     if ("titlebind".equalsIgnoreCase(name)) {
/* 532 */       return titlebind();
/*     */     }
/* 534 */     if ("title".equalsIgnoreCase(name)) {
/* 535 */       return title();
/*     */     }
/* 537 */     return super.getStringNE(name);
/*     */   }
/*     */   public MCNumber getNumberNE(String name) {
/* 540 */     if ("pushid".equalsIgnoreCase(name)) {
/* 541 */       return pushid();
/*     */     }
/* 543 */     return super.getNumberNE(name);
/*     */   }
/*     */   public boolean getBooleanNE(String name) {
/* 546 */     if ("importance".equalsIgnoreCase(name)) {
/* 547 */       return importance();
/*     */     }
/* 549 */     return super.getBooleanNE(name);
/*     */   }
/*     */   
/*     */   public void setString(String name, String value) {
/* 553 */     if ("userid".equalsIgnoreCase(name)) {
/* 554 */       userid(value);
/*     */       return;
/*     */     } 
/* 557 */     if ("cocd".equalsIgnoreCase(name)) {
/* 558 */       cocd(value);
/*     */       return;
/*     */     } 
/* 561 */     if ("modid".equalsIgnoreCase(name)) {
/* 562 */       modid(value);
/*     */       return;
/*     */     } 
/* 565 */     if ("logid".equalsIgnoreCase(name)) {
/* 566 */       logid(value);
/*     */       return;
/*     */     } 
/* 569 */     if ("opeid".equalsIgnoreCase(name)) {
/* 570 */       opeid(value);
/*     */       return;
/*     */     } 
/* 573 */     if ("msgid".equalsIgnoreCase(name)) {
/* 574 */       msgid(value);
/*     */       return;
/*     */     } 
/* 577 */     if ("msgbind".equalsIgnoreCase(name)) {
/* 578 */       msgbind(value);
/*     */       return;
/*     */     } 
/* 581 */     if ("titleid".equalsIgnoreCase(name)) {
/* 582 */       titleid(value);
/*     */       return;
/*     */     } 
/* 585 */     if ("titlebind".equalsIgnoreCase(name)) {
/* 586 */       titlebind(value);
/*     */       return;
/*     */     } 
/* 589 */     if ("title".equalsIgnoreCase(name)) {
/* 590 */       title(value);
/*     */       return;
/*     */     } 
/* 593 */     super.setString(name, value);
/*     */   }
/*     */   public void setNumber(String name, MCNumber value) {
/* 596 */     if ("pushid".equalsIgnoreCase(name)) {
/* 597 */       pushid(value);
/*     */       return;
/*     */     } 
/* 600 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, int value) {
/* 603 */     if ("pushid".equalsIgnoreCase(name)) {
/* 604 */       pushid(value);
/*     */       return;
/*     */     } 
/* 607 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, long value) {
/* 610 */     if ("pushid".equalsIgnoreCase(name)) {
/* 611 */       pushid(value);
/*     */       return;
/*     */     } 
/* 614 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, float value) {
/* 617 */     if ("pushid".equalsIgnoreCase(name)) {
/* 618 */       pushid(value);
/*     */       return;
/*     */     } 
/* 621 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, double value) {
/* 624 */     if ("pushid".equalsIgnoreCase(name)) {
/* 625 */       pushid(value);
/*     */       return;
/*     */     } 
/* 628 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setBoolean(String name, boolean value) {
/* 631 */     if ("importance".equalsIgnoreCase(name)) {
/* 632 */       importance(value);
/*     */       return;
/*     */     } 
/* 635 */     super.setBoolean(name, value);
/*     */   }
/*     */   
/*     */   public void setStringNE(String name, String value) {
/* 639 */     if ("userid".equalsIgnoreCase(name)) {
/* 640 */       userid(value);
/*     */       return;
/*     */     } 
/* 643 */     if ("cocd".equalsIgnoreCase(name)) {
/* 644 */       cocd(value);
/*     */       return;
/*     */     } 
/* 647 */     if ("modid".equalsIgnoreCase(name)) {
/* 648 */       modid(value);
/*     */       return;
/*     */     } 
/* 651 */     if ("logid".equalsIgnoreCase(name)) {
/* 652 */       logid(value);
/*     */       return;
/*     */     } 
/* 655 */     if ("opeid".equalsIgnoreCase(name)) {
/* 656 */       opeid(value);
/*     */       return;
/*     */     } 
/* 659 */     if ("msgid".equalsIgnoreCase(name)) {
/* 660 */       msgid(value);
/*     */       return;
/*     */     } 
/* 663 */     if ("msgbind".equalsIgnoreCase(name)) {
/* 664 */       msgbind(value);
/*     */       return;
/*     */     } 
/* 667 */     if ("titleid".equalsIgnoreCase(name)) {
/* 668 */       titleid(value);
/*     */       return;
/*     */     } 
/* 671 */     if ("titlebind".equalsIgnoreCase(name)) {
/* 672 */       titlebind(value);
/*     */       return;
/*     */     } 
/* 675 */     if ("title".equalsIgnoreCase(name)) {
/* 676 */       title(value);
/*     */       return;
/*     */     } 
/* 679 */     super.setStringNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, MCNumber value) {
/* 682 */     if ("pushid".equalsIgnoreCase(name)) {
/* 683 */       pushid(value);
/*     */       return;
/*     */     } 
/* 686 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, int value) {
/* 689 */     if ("pushid".equalsIgnoreCase(name)) {
/* 690 */       pushid(value);
/*     */       return;
/*     */     } 
/* 693 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, long value) {
/* 696 */     if ("pushid".equalsIgnoreCase(name)) {
/* 697 */       pushid(value);
/*     */       return;
/*     */     } 
/* 700 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, float value) {
/* 703 */     if ("pushid".equalsIgnoreCase(name)) {
/* 704 */       pushid(value);
/*     */       return;
/*     */     } 
/* 707 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, double value) {
/* 710 */     if ("pushid".equalsIgnoreCase(name)) {
/* 711 */       pushid(value);
/*     */       return;
/*     */     } 
/* 714 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setBooleanNE(String name, boolean value) {
/* 717 */     if ("importance".equalsIgnoreCase(name)) {
/* 718 */       importance(value);
/*     */       return;
/*     */     } 
/* 721 */     super.setBooleanNE(name, value);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\push\ctrl\NoticeR_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */