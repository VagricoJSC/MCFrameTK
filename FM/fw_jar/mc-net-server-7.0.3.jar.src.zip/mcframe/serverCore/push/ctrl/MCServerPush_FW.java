/*     */ package mcframe.serverCore.push.ctrl;
/*     */ 
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCMessage;
/*     */ import mcframe.commonCore.push.MCPushMessage;
/*     */ import mcframe.serverCore.notice.MCMessagePool;
/*     */ import mcframe.serverCore.push.MCServerPushManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MCServerPush_FW
/*     */   extends MCServerPush_FW_A
/*     */ {
/*     */   public class Broadcast
/*     */     extends MCServerPush_FW_A.Broadcast
/*     */   {
/*     */     protected void call() {
/*  42 */       MCPushProxy.PROXY.push(up0(), up1(), up2());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class Close
/*     */     extends MCServerPush_FW_A.Close
/*     */   {
/*     */     protected void call() {
/*  53 */       MCPushProxy.PROXY.close(up0());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class Unread
/*     */     extends MCServerPush_FW_A.Unread
/*     */   {
/*     */     protected void call() {
/*  64 */       MCServerPushManager.getManager().checkUnreadMessage(
/*  65 */           getOperationInfo(), up0(), "userid");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class Read
/*     */     extends MCServerPush_FW_A.Read
/*     */   {
/*     */     protected void call() {
/*  76 */       MCServerPushManager.getManager().readMessage(
/*  77 */           up1().userid(), up0(), "pushid");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class ClientSend
/*     */     extends MCServerPush_FW_A.ClientSend
/*     */   {
/*     */     protected void call() {
/*  88 */       NoticeR noticeR = up0();
/*  89 */       MCList<UserR> userL = up1();
/*  90 */       MCList<ScreenR> scrL = up2();
/*     */ 
/*     */       
/*  93 */       MCMessage msg = MCServerPushManager.createMessageFromDB(
/*  94 */           noticeR.msgid(), noticeR.msgbind());
/*  95 */       MCMessage title = MCServerPushManager.createMessageFromDB(
/*  96 */           noticeR.titleid(), noticeR.titlebind());
/*  97 */       MCPushMessage pmsg = new MCPushMessage(msg, title, noticeR.importance());
/*     */ 
/*     */       
/* 100 */       MCList<ScreenR> xaL = scrL.subList("type", "PC");
/* 101 */       for (ScreenR xaR : xaL) {
/* 102 */         pmsg.addScreenParamPC(xaR.key(), xaR.val());
/*     */       }
/* 104 */       MCList<ScreenR> mdL = scrL.subList("type", "MD");
/* 105 */       for (ScreenR mdR : mdL) {
/* 106 */         pmsg.addScreenParamMD(mdR.key(), mdR.val());
/*     */       }
/*     */ 
/*     */       
/* 110 */       String[] userids = (String[])userL.getString("userid").toArray((Object[])new String[userL.size()]);
/*     */ 
/*     */       
/* 113 */       MCServerPushManager.getManager().pushMessage(
/* 114 */           pmsg, 
/* 115 */           noticeR.modid(), noticeR.logid(), noticeR.opeid(), 
/* 116 */           userids);
/*     */       
/* 118 */       if (!MCMessagePool.isEmpty()) {
/*     */ 
/*     */         
/* 121 */         MCException e = new MCException(Core_Msg_FW_A.FCBGC0440, new Object[0]);
/* 122 */         e.addCauseMessageList(MCMessagePool.getMessageList());
/* 123 */         throw e;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public class Broadcast2
/*     */     extends MCServerPush_FW_A.Broadcast2
/*     */   {
/*     */     protected void call() {
/* 134 */       MCPushProxy.PROXY.push(up0(), up1(), up2());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\push\ctrl\MCServerPush_FW.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */