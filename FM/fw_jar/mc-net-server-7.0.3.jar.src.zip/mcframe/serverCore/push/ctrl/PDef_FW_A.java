/*     */ package mcframe.serverCore.push.ctrl;
/*     */ 
/*     */ import mcframe.commonCore.param.MCBlockDef;
/*     */ import mcframe.commonCore.param.MCContainerDef;
/*     */ import mcframe.commonCore.param.MCDef;
/*     */ import mcframe.commonCore.param.MCGeneralContainerDef;
/*     */ import mcframe.commonCore.param.MCItemDef;
/*     */ import mcframe.commonCore.param.MCOperationInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PDef_FW_A
/*     */   extends MCDef
/*     */ {
/*     */   public MCContainerDef getCustomDef(String id) {
/*  22 */     if (id == null) {
/*  23 */       return null;
/*     */     }
/*     */     
/*  26 */     if (id.equals("FC.FCBGL0100.Broadcast.UP.BLOCK0")) {
/*  27 */       return FC_FCBGL0100_Broadcast_UP_BLOCK0();
/*     */     }
/*  29 */     if (id.equals("FC.FCBGL0100.Broadcast.UP.BLOCK1")) {
/*  30 */       return FC_FCBGL0100_Broadcast_UP_BLOCK1();
/*     */     }
/*  32 */     if (id.equals("FC.FCBGL0100.Broadcast.UP.BLOCK2")) {
/*  33 */       return FC_FCBGL0100_Broadcast_UP_BLOCK2();
/*     */     }
/*  35 */     if (id.equals("FC.FCBGL0100.Broadcast2.UP.BLOCK0")) {
/*  36 */       return FC_FCBGL0100_Broadcast2_UP_BLOCK0();
/*     */     }
/*  38 */     if (id.equals("FC.FCBGL0100.Broadcast2.UP.BLOCK1")) {
/*  39 */       return FC_FCBGL0100_Broadcast2_UP_BLOCK1();
/*     */     }
/*  41 */     if (id.equals("FC.FCBGL0100.Broadcast2.UP.BLOCK2")) {
/*  42 */       return FC_FCBGL0100_Broadcast2_UP_BLOCK2();
/*     */     }
/*  44 */     if (id.equals("FC.FCBGL0100.Close.UP.BLOCK0")) {
/*  45 */       return FC_FCBGL0100_Close_UP_BLOCK0();
/*     */     }
/*  47 */     if (id.equals("FC.FCBGL0100.Unread.UP.BLOCK0")) {
/*  48 */       return FC_FCBGL0100_Unread_UP_BLOCK0();
/*     */     }
/*  50 */     if (id.equals("FC.FCBGL0100.Read.UP.BLOCK0")) {
/*  51 */       return FC_FCBGL0100_Read_UP_BLOCK0();
/*     */     }
/*  53 */     if (id.equals("FC.FCBGL0100.Read.UP.BLOCK1")) {
/*  54 */       return FC_FCBGL0100_Read_UP_BLOCK1();
/*     */     }
/*  56 */     if (id.equals("FC.FCBGL0100.Notice.DOWN.BLOCK0")) {
/*  57 */       return FC_FCBGL0100_Notice_DOWN_BLOCK0();
/*     */     }
/*  59 */     if (id.equals("FC.FCBGL0100.Notice.DOWN.BLOCK1")) {
/*  60 */       return FC_FCBGL0100_Notice_DOWN_BLOCK1();
/*     */     }
/*  62 */     if (id.equals("FC.FCBGL0100.ClientSend.UP.BLOCK0")) {
/*  63 */       return FC_FCBGL0100_ClientSend_UP_BLOCK0();
/*     */     }
/*  65 */     if (id.equals("FC.FCBGL0100.ClientSend.UP.BLOCK1")) {
/*  66 */       return FC_FCBGL0100_ClientSend_UP_BLOCK1();
/*     */     }
/*  68 */     if (id.equals("FC.FCBGL0100.ClientSend.UP.BLOCK2")) {
/*  69 */       return FC_FCBGL0100_ClientSend_UP_BLOCK2();
/*     */     }
/*     */ 
/*     */     
/*  73 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  79 */   static final MCOperationInfo FC_FCBGL0100_Broadcast_INFO = new MCOperationInfo("FC", "FCBGL0100", "Broadcast", "000000", new PDef());
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL0100_Broadcast_UP_BLOCK0() {
/*  83 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL0100", "Broadcast", 
/*  84 */         new MCItemDef[] { 
/*  85 */           MCItemDef.create("pushid", true, "pushid"), 
/*  86 */           MCItemDef.create("userid", true, "userid"), 
/*  87 */           MCItemDef.create("cocd", "cocd"), 
/*  88 */           MCItemDef.create("modid", "modid"), 
/*  89 */           MCItemDef.create("logid", "logid"), 
/*  90 */           MCItemDef.create("opeid", "opeid"), 
/*  91 */           MCItemDef.create("msgid", true, "msgid"), 
/*  92 */           MCItemDef.create("msgbind", "msgbind"), 
/*  93 */           MCItemDef.create("titleid", "titleid"), 
/*  94 */           MCItemDef.create("titlebind", "titlebind"), 
/*  95 */           MCItemDef.create("importance", true, "importance")
/*     */ 
/*     */         
/*  98 */         }MCBlockDef.create("Notice"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL0100_Broadcast_UP_BLOCK1() {
/* 104 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL0100", "Broadcast", 
/* 105 */         new MCItemDef[] {
/* 106 */           MCItemDef.create("userid", true, "userid")
/*     */ 
/*     */         
/* 109 */         }MCBlockDef.create("User"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL0100_Broadcast_UP_BLOCK2() {
/* 115 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL0100", "Broadcast", 
/* 116 */         new MCItemDef[] {
/* 117 */           MCItemDef.create("type", true, "type"), 
/* 118 */           MCItemDef.create("key", true, "key"), 
/* 119 */           MCItemDef.create("val", true, "val")
/*     */ 
/*     */         
/* 122 */         }MCBlockDef.create("Screen"));
/*     */   }
/*     */ 
/*     */   
/* 126 */   static final MCOperationInfo FC_FCBGL0100_Broadcast2_INFO = new MCOperationInfo("FC", "FCBGL0100", "Broadcast2", "000000", new PDef());
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL0100_Broadcast2_UP_BLOCK0() {
/* 130 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL0100", "Broadcast2", 
/* 131 */         new MCItemDef[] {
/* 132 */           MCItemDef.create("pushid", true, "pushid"), 
/* 133 */           MCItemDef.create("userid", true, "userid"), 
/* 134 */           MCItemDef.create("cocd", "cocd"), 
/* 135 */           MCItemDef.create("modid", "modid"), 
/* 136 */           MCItemDef.create("logid", "logid"), 
/* 137 */           MCItemDef.create("opeid", "opeid")
/*     */ 
/*     */         
/* 140 */         }MCBlockDef.create("Broadcast2_Notice"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL0100_Broadcast2_UP_BLOCK1() {
/* 146 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL0100", "Broadcast2", 
/* 147 */         new MCItemDef[] {
/* 148 */           MCItemDef.create("userid", true, "userid"), 
/* 149 */           MCItemDef.create("msgid", true, "msgid"), 
/* 150 */           MCItemDef.create("msgbind", "msgbind"), 
/* 151 */           MCItemDef.create("titleid", "titleid"), 
/* 152 */           MCItemDef.create("titlebind", "titlebind"), 
/* 153 */           MCItemDef.create("importance", true, "importance")
/*     */ 
/*     */         
/* 156 */         }MCBlockDef.create("Broadcast2_User"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL0100_Broadcast2_UP_BLOCK2() {
/* 162 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL0100", "Broadcast2", 
/* 163 */         new MCItemDef[] {
/* 164 */           MCItemDef.create("type", true, "type"), 
/* 165 */           MCItemDef.create("key", true, "key"), 
/* 166 */           MCItemDef.create("val", true, "val")
/*     */ 
/*     */         
/* 169 */         }MCBlockDef.create("Screen"));
/*     */   }
/*     */ 
/*     */   
/* 173 */   static final MCOperationInfo FC_FCBGL0100_Close_INFO = new MCOperationInfo("FC", "FCBGL0100", "Close", "000000", new PDef());
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL0100_Close_UP_BLOCK0() {
/* 177 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL0100", "Close", 
/* 178 */         new MCItemDef[] {
/* 179 */           MCItemDef.create("userid", true, "userid")
/*     */ 
/*     */         
/* 182 */         }MCBlockDef.create("User"));
/*     */   }
/*     */ 
/*     */   
/* 186 */   static final MCOperationInfo FC_FCBGL0100_Unread_INFO = new MCOperationInfo("FC", "FCBGL0100", "Unread", "000000", new PDef());
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL0100_Unread_UP_BLOCK0() {
/* 190 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL0100", "Unread", 
/* 191 */         new MCItemDef[] {
/* 192 */           MCItemDef.create("userid", true, "userid")
/*     */ 
/*     */         
/* 195 */         }MCBlockDef.create("User"));
/*     */   }
/*     */ 
/*     */   
/* 199 */   static final MCOperationInfo FC_FCBGL0100_Read_INFO = new MCOperationInfo("FC", "FCBGL0100", "Read", "000000", new PDef());
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL0100_Read_UP_BLOCK0() {
/* 203 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL0100", "Read", 
/* 204 */         new MCItemDef[] {
/* 205 */           MCItemDef.create("pushid", true, "pushid")
/*     */ 
/*     */         
/* 208 */         }MCBlockDef.create("Notice"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL0100_Read_UP_BLOCK1() {
/* 214 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL0100", "Read", 
/* 215 */         new MCItemDef[] {
/* 216 */           MCItemDef.create("userid", true, "userid")
/*     */ 
/*     */         
/* 219 */         }MCBlockDef.create("User"));
/*     */   }
/*     */ 
/*     */   
/* 223 */   static final MCOperationInfo FC_FCBGL0100_Notice_INFO = new MCOperationInfo("FC", "FCBGL0100", "Notice", "000000", new PDef());
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL0100_Notice_DOWN_BLOCK0() {
/* 228 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL0100", "Notice", 
/* 229 */         new MCItemDef[] {
/* 230 */           MCItemDef.create("pushid", true, "pushid"), 
/* 231 */           MCItemDef.create("userid", true, "userid"), 
/* 232 */           MCItemDef.create("cocd", "cocd"), 
/* 233 */           MCItemDef.create("title", "title"), 
/* 234 */           MCItemDef.create("importance", true, "importance")
/*     */ 
/*     */         
/* 237 */         }MCBlockDef.create("Notice"));
/*     */   }
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL0100_Notice_DOWN_BLOCK1() {
/* 242 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL0100", "Notice", 
/* 243 */         new MCItemDef[] {
/* 244 */           MCItemDef.create("type", true, "type"), 
/* 245 */           MCItemDef.create("key", true, "key"), 
/* 246 */           MCItemDef.create("val", true, "val")
/*     */ 
/*     */         
/* 249 */         }MCBlockDef.create("Screen"));
/*     */   }
/*     */ 
/*     */   
/* 253 */   static final MCOperationInfo FC_FCBGL0100_ClientSend_INFO = new MCOperationInfo("FC", "FCBGL0100", "ClientSend", "000000", new PDef());
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL0100_ClientSend_UP_BLOCK0() {
/* 257 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL0100", "ClientSend", 
/* 258 */         new MCItemDef[] {
/* 259 */           MCItemDef.create("userid", true, "userid"), 
/* 260 */           MCItemDef.create("cocd", "cocd"), 
/* 261 */           MCItemDef.create("modid", "modid"), 
/* 262 */           MCItemDef.create("logid", "logid"), 
/* 263 */           MCItemDef.create("msgid", true, "msgid"), 
/* 264 */           MCItemDef.create("msgbind", "msgbind"), 
/* 265 */           MCItemDef.create("titleid", "titleid"), 
/* 266 */           MCItemDef.create("titlebind", "titlebind"), 
/* 267 */           MCItemDef.create("importance", true, "importance")
/*     */ 
/*     */         
/* 270 */         }MCBlockDef.create("Notice"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL0100_ClientSend_UP_BLOCK1() {
/* 276 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL0100", "ClientSend", 
/* 277 */         new MCItemDef[] {
/* 278 */           MCItemDef.create("userid", true, "userid")
/*     */ 
/*     */         
/* 281 */         }MCBlockDef.create("User"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL0100_ClientSend_UP_BLOCK2() {
/* 287 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL0100", "ClientSend", 
/* 288 */         new MCItemDef[] {
/* 289 */           MCItemDef.create("type", true, "type"), 
/* 290 */           MCItemDef.create("key", true, "key"), 
/* 291 */           MCItemDef.create("val", true, "val")
/*     */ 
/*     */         
/* 294 */         }MCBlockDef.create("Screen"));
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\push\ctrl\PDef_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */