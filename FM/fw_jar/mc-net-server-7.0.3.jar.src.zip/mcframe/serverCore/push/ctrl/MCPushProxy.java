/*    */ package mcframe.serverCore.push.ctrl;
/*    */ 
/*    */ import mcframe.commonCore.container.MCList;
/*    */ import mcframe.serverCore.push.AbsMCPackageProxy;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MCPushProxy
/*    */   extends AbsMCPackageProxy
/*    */ {
/* 15 */   static final MCPushProxy PROXY = new MCPushProxy();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void push(NoticeR noticeR, MCList<UserR> userL, MCList<ScreenR> screenL) {
/* 28 */     super.push(noticeR, userL, screenL);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void push(Broadcast2_NoticeR noticeR, MCList<Broadcast2_UserR> userL, MCList<ScreenR> screenL) {
/* 34 */     super.push(noticeR, userL, screenL);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void close(MCList<UserR> userL) {
/* 39 */     super.close(userL);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\push\ctrl\MCPushProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */