/*     */ package mcframe.serverCore.push.ctrl;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.commonCore.container.MCConstRow;
/*     */ import mcframe.commonCore.container.MCExtMap;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class Broadcast2_UserR_FW_A
/*     */   extends MCConstRow
/*     */ {
/*     */   public static final String $userid = "userid";
/*     */   public static final String $msgid = "msgid";
/*     */   public static final String $msgbind = "msgbind";
/*     */   public static final String $titleid = "titleid";
/*     */   public static final String $titlebind = "titlebind";
/*     */   public static final String $title = "title";
/*     */   public static final String $importance = "importance";
/*  65 */   public static final MCMeta userid_META = createStringMeta("userid");
/*  66 */   public static final MCMeta msgid_META = createStringMeta("msgid");
/*  67 */   public static final MCMeta msgbind_META = createStringMeta("msgbind");
/*  68 */   public static final MCMeta titleid_META = createStringMeta("titleid");
/*  69 */   public static final MCMeta titlebind_META = createStringMeta("titlebind");
/*  70 */   public static final MCMeta title_META = createStringMeta("title");
/*  71 */   public static final MCMeta importance_META = createBooleanMeta("importance");
/*     */   
/*  73 */   protected static final MCRow.ConstMetaList<Broadcast2_UserR> constMetas = new MCRow.ConstMetaList(
/*  74 */       MCConstRow.constMetas, 
/*  75 */       new MCMeta[] {
/*  76 */         userid_META, 
/*  77 */         msgid_META, 
/*  78 */         msgbind_META, 
/*  79 */         titleid_META, 
/*  80 */         titlebind_META, 
/*  81 */         title_META, 
/*  82 */         importance_META
/*     */       },
/*  84 */       new String[][] { {}, {} });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   protected static final MCExtMap EXTMAP = new MCExtMap(
/*  97 */       null, new MCExtMap.Entry[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] colnames() {
/* 109 */     return constMetas.toNameArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMeta[] colmetas() {
/* 121 */     return constMetas.toMetaArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 127 */   private static final int offset = constMetas.offset();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getExtMap(String aGroup) {
/* 133 */     if (aGroup == null) return null; 
/* 134 */     return (Map<String, String>)EXTMAP.get(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getKeys(String aGroup) {
/* 141 */     if (aGroup == null) return null; 
/* 142 */     return EXTMAP.getKeyList(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExtGroups() {
/* 149 */     Set<String> ret = EXTMAP.keySet();
/* 150 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Broadcast2_UserR_FW_A(MCRow.ConstMetaList<? extends Broadcast2_UserR> metas) {
/* 157 */     super(metas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Broadcast2_UserR clone() {
/* 164 */     return (Broadcast2_UserR)super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Broadcast2_UserR createInstance() {
/* 171 */     return (Broadcast2_UserR)super.createInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Broadcast2_UserR getValues(String... names) {
/* 178 */     return (Broadcast2_UserR)super.getValues(names);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireValueChanged(String column, Comparable<?> newvalue, Comparable<?> oldvalue) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String userid() {
/* 194 */     return getConstString(offset + 0, "userid");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void userid(String value) {
/* 202 */     setConstString(offset + 0, "userid", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String msgid() {
/* 211 */     return getConstString(offset + 1, "msgid");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void msgid(String value) {
/* 219 */     setConstString(offset + 1, "msgid", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String msgbind() {
/* 228 */     return getConstString(offset + 2, "msgbind");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void msgbind(String value) {
/* 236 */     setConstString(offset + 2, "msgbind", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String titleid() {
/* 245 */     return getConstString(offset + 3, "titleid");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void titleid(String value) {
/* 253 */     setConstString(offset + 3, "titleid", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String titlebind() {
/* 262 */     return getConstString(offset + 4, "titlebind");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void titlebind(String value) {
/* 270 */     setConstString(offset + 4, "titlebind", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String title() {
/* 279 */     return getConstString(offset + 5, "title");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void title(String value) {
/* 287 */     setConstString(offset + 5, "title", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean importance() {
/* 296 */     return getConstBoolean(offset + 6, "importance");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void importance(boolean value) {
/* 304 */     setConstBoolean(offset + 6, "importance", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString(String name) {
/* 309 */     if ("userid".equalsIgnoreCase(name)) {
/* 310 */       return userid();
/*     */     }
/* 312 */     if ("msgid".equalsIgnoreCase(name)) {
/* 313 */       return msgid();
/*     */     }
/* 315 */     if ("msgbind".equalsIgnoreCase(name)) {
/* 316 */       return msgbind();
/*     */     }
/* 318 */     if ("titleid".equalsIgnoreCase(name)) {
/* 319 */       return titleid();
/*     */     }
/* 321 */     if ("titlebind".equalsIgnoreCase(name)) {
/* 322 */       return titlebind();
/*     */     }
/* 324 */     if ("title".equalsIgnoreCase(name)) {
/* 325 */       return title();
/*     */     }
/* 327 */     return super.getString(name);
/*     */   }
/*     */   public boolean getBoolean(String name) {
/* 330 */     if ("importance".equalsIgnoreCase(name)) {
/* 331 */       return importance();
/*     */     }
/* 333 */     return super.getBoolean(name);
/*     */   }
/*     */   
/*     */   public String getStringNE(String name) {
/* 337 */     if ("userid".equalsIgnoreCase(name)) {
/* 338 */       return userid();
/*     */     }
/* 340 */     if ("msgid".equalsIgnoreCase(name)) {
/* 341 */       return msgid();
/*     */     }
/* 343 */     if ("msgbind".equalsIgnoreCase(name)) {
/* 344 */       return msgbind();
/*     */     }
/* 346 */     if ("titleid".equalsIgnoreCase(name)) {
/* 347 */       return titleid();
/*     */     }
/* 349 */     if ("titlebind".equalsIgnoreCase(name)) {
/* 350 */       return titlebind();
/*     */     }
/* 352 */     if ("title".equalsIgnoreCase(name)) {
/* 353 */       return title();
/*     */     }
/* 355 */     return super.getStringNE(name);
/*     */   }
/*     */   public boolean getBooleanNE(String name) {
/* 358 */     if ("importance".equalsIgnoreCase(name)) {
/* 359 */       return importance();
/*     */     }
/* 361 */     return super.getBooleanNE(name);
/*     */   }
/*     */   
/*     */   public void setString(String name, String value) {
/* 365 */     if ("userid".equalsIgnoreCase(name)) {
/* 366 */       userid(value);
/*     */       return;
/*     */     } 
/* 369 */     if ("msgid".equalsIgnoreCase(name)) {
/* 370 */       msgid(value);
/*     */       return;
/*     */     } 
/* 373 */     if ("msgbind".equalsIgnoreCase(name)) {
/* 374 */       msgbind(value);
/*     */       return;
/*     */     } 
/* 377 */     if ("titleid".equalsIgnoreCase(name)) {
/* 378 */       titleid(value);
/*     */       return;
/*     */     } 
/* 381 */     if ("titlebind".equalsIgnoreCase(name)) {
/* 382 */       titlebind(value);
/*     */       return;
/*     */     } 
/* 385 */     if ("title".equalsIgnoreCase(name)) {
/* 386 */       title(value);
/*     */       return;
/*     */     } 
/* 389 */     super.setString(name, value);
/*     */   }
/*     */   public void setBoolean(String name, boolean value) {
/* 392 */     if ("importance".equalsIgnoreCase(name)) {
/* 393 */       importance(value);
/*     */       return;
/*     */     } 
/* 396 */     super.setBoolean(name, value);
/*     */   }
/*     */   
/*     */   public void setStringNE(String name, String value) {
/* 400 */     if ("userid".equalsIgnoreCase(name)) {
/* 401 */       userid(value);
/*     */       return;
/*     */     } 
/* 404 */     if ("msgid".equalsIgnoreCase(name)) {
/* 405 */       msgid(value);
/*     */       return;
/*     */     } 
/* 408 */     if ("msgbind".equalsIgnoreCase(name)) {
/* 409 */       msgbind(value);
/*     */       return;
/*     */     } 
/* 412 */     if ("titleid".equalsIgnoreCase(name)) {
/* 413 */       titleid(value);
/*     */       return;
/*     */     } 
/* 416 */     if ("titlebind".equalsIgnoreCase(name)) {
/* 417 */       titlebind(value);
/*     */       return;
/*     */     } 
/* 420 */     if ("title".equalsIgnoreCase(name)) {
/* 421 */       title(value);
/*     */       return;
/*     */     } 
/* 424 */     super.setStringNE(name, value);
/*     */   }
/*     */   public void setBooleanNE(String name, boolean value) {
/* 427 */     if ("importance".equalsIgnoreCase(name)) {
/* 428 */       importance(value);
/*     */       return;
/*     */     } 
/* 431 */     super.setBooleanNE(name, value);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\push\ctrl\Broadcast2_UserR_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */