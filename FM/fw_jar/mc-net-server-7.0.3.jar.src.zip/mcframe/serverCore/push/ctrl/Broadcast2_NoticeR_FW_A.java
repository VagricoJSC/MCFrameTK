/*     */ package mcframe.serverCore.push.ctrl;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.commonCore.container.MCConstRow;
/*     */ import mcframe.commonCore.container.MCExtMap;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class Broadcast2_NoticeR_FW_A
/*     */   extends MCConstRow
/*     */ {
/*     */   public static final String $pushid = "pushid";
/*     */   public static final String $userid = "userid";
/*     */   public static final String $cocd = "cocd";
/*     */   public static final String $modid = "modid";
/*     */   public static final String $logid = "logid";
/*     */   public static final String $opeid = "opeid";
/*  60 */   public static final MCMeta pushid_META = createNumberMeta("pushid");
/*  61 */   public static final MCMeta userid_META = createStringMeta("userid");
/*  62 */   public static final MCMeta cocd_META = createStringMeta("cocd");
/*  63 */   public static final MCMeta modid_META = createStringMeta("modid");
/*  64 */   public static final MCMeta logid_META = createStringMeta("logid");
/*  65 */   public static final MCMeta opeid_META = createStringMeta("opeid");
/*     */   
/*  67 */   protected static final MCRow.ConstMetaList<Broadcast2_NoticeR> constMetas = new MCRow.ConstMetaList(
/*  68 */       MCConstRow.constMetas, 
/*  69 */       new MCMeta[] {
/*  70 */         pushid_META, 
/*  71 */         userid_META, 
/*  72 */         cocd_META, 
/*  73 */         modid_META, 
/*  74 */         logid_META, 
/*  75 */         opeid_META
/*     */       },
/*  77 */       new String[][] { {}, {} });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   protected static final MCExtMap EXTMAP = new MCExtMap(
/*  90 */       null, new MCExtMap.Entry[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] colnames() {
/* 102 */     return constMetas.toNameArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMeta[] colmetas() {
/* 114 */     return constMetas.toMetaArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 120 */   private static final int offset = constMetas.offset();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getExtMap(String aGroup) {
/* 126 */     if (aGroup == null) return null; 
/* 127 */     return (Map<String, String>)EXTMAP.get(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getKeys(String aGroup) {
/* 134 */     if (aGroup == null) return null; 
/* 135 */     return EXTMAP.getKeyList(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExtGroups() {
/* 142 */     Set<String> ret = EXTMAP.keySet();
/* 143 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Broadcast2_NoticeR_FW_A(MCRow.ConstMetaList<? extends Broadcast2_NoticeR> metas) {
/* 150 */     super(metas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Broadcast2_NoticeR clone() {
/* 157 */     return (Broadcast2_NoticeR)super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Broadcast2_NoticeR createInstance() {
/* 164 */     return (Broadcast2_NoticeR)super.createInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Broadcast2_NoticeR getValues(String... names) {
/* 171 */     return (Broadcast2_NoticeR)super.getValues(names);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireValueChanged(String column, Comparable<?> newvalue, Comparable<?> oldvalue) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCNumber pushid() {
/* 187 */     return getConstNumber(offset + 0, "pushid");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pushid(MCNumber value) {
/* 195 */     setConstNumber(offset + 0, "pushid", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pushid(int value) {
/* 203 */     setConstNumber(offset + 0, "pushid", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pushid(long value) {
/* 211 */     setConstNumber(offset + 0, "pushid", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pushid(float value) {
/* 219 */     setConstNumber(offset + 0, "pushid", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pushid(double value) {
/* 227 */     setConstNumber(offset + 0, "pushid", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String userid() {
/* 236 */     return getConstString(offset + 1, "userid");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void userid(String value) {
/* 244 */     setConstString(offset + 1, "userid", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String cocd() {
/* 253 */     return getConstString(offset + 2, "cocd");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cocd(String value) {
/* 261 */     setConstString(offset + 2, "cocd", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String modid() {
/* 270 */     return getConstString(offset + 3, "modid");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void modid(String value) {
/* 278 */     setConstString(offset + 3, "modid", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String logid() {
/* 287 */     return getConstString(offset + 4, "logid");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void logid(String value) {
/* 295 */     setConstString(offset + 4, "logid", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String opeid() {
/* 304 */     return getConstString(offset + 5, "opeid");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void opeid(String value) {
/* 312 */     setConstString(offset + 5, "opeid", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString(String name) {
/* 317 */     if ("userid".equalsIgnoreCase(name)) {
/* 318 */       return userid();
/*     */     }
/* 320 */     if ("cocd".equalsIgnoreCase(name)) {
/* 321 */       return cocd();
/*     */     }
/* 323 */     if ("modid".equalsIgnoreCase(name)) {
/* 324 */       return modid();
/*     */     }
/* 326 */     if ("logid".equalsIgnoreCase(name)) {
/* 327 */       return logid();
/*     */     }
/* 329 */     if ("opeid".equalsIgnoreCase(name)) {
/* 330 */       return opeid();
/*     */     }
/* 332 */     return super.getString(name);
/*     */   }
/*     */   public MCNumber getNumber(String name) {
/* 335 */     if ("pushid".equalsIgnoreCase(name)) {
/* 336 */       return pushid();
/*     */     }
/* 338 */     return super.getNumber(name);
/*     */   }
/*     */   
/*     */   public String getStringNE(String name) {
/* 342 */     if ("userid".equalsIgnoreCase(name)) {
/* 343 */       return userid();
/*     */     }
/* 345 */     if ("cocd".equalsIgnoreCase(name)) {
/* 346 */       return cocd();
/*     */     }
/* 348 */     if ("modid".equalsIgnoreCase(name)) {
/* 349 */       return modid();
/*     */     }
/* 351 */     if ("logid".equalsIgnoreCase(name)) {
/* 352 */       return logid();
/*     */     }
/* 354 */     if ("opeid".equalsIgnoreCase(name)) {
/* 355 */       return opeid();
/*     */     }
/* 357 */     return super.getStringNE(name);
/*     */   }
/*     */   public MCNumber getNumberNE(String name) {
/* 360 */     if ("pushid".equalsIgnoreCase(name)) {
/* 361 */       return pushid();
/*     */     }
/* 363 */     return super.getNumberNE(name);
/*     */   }
/*     */   
/*     */   public void setString(String name, String value) {
/* 367 */     if ("userid".equalsIgnoreCase(name)) {
/* 368 */       userid(value);
/*     */       return;
/*     */     } 
/* 371 */     if ("cocd".equalsIgnoreCase(name)) {
/* 372 */       cocd(value);
/*     */       return;
/*     */     } 
/* 375 */     if ("modid".equalsIgnoreCase(name)) {
/* 376 */       modid(value);
/*     */       return;
/*     */     } 
/* 379 */     if ("logid".equalsIgnoreCase(name)) {
/* 380 */       logid(value);
/*     */       return;
/*     */     } 
/* 383 */     if ("opeid".equalsIgnoreCase(name)) {
/* 384 */       opeid(value);
/*     */       return;
/*     */     } 
/* 387 */     super.setString(name, value);
/*     */   }
/*     */   public void setNumber(String name, MCNumber value) {
/* 390 */     if ("pushid".equalsIgnoreCase(name)) {
/* 391 */       pushid(value);
/*     */       return;
/*     */     } 
/* 394 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, int value) {
/* 397 */     if ("pushid".equalsIgnoreCase(name)) {
/* 398 */       pushid(value);
/*     */       return;
/*     */     } 
/* 401 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, long value) {
/* 404 */     if ("pushid".equalsIgnoreCase(name)) {
/* 405 */       pushid(value);
/*     */       return;
/*     */     } 
/* 408 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, float value) {
/* 411 */     if ("pushid".equalsIgnoreCase(name)) {
/* 412 */       pushid(value);
/*     */       return;
/*     */     } 
/* 415 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, double value) {
/* 418 */     if ("pushid".equalsIgnoreCase(name)) {
/* 419 */       pushid(value);
/*     */       return;
/*     */     } 
/* 422 */     super.setNumber(name, value);
/*     */   }
/*     */   
/*     */   public void setStringNE(String name, String value) {
/* 426 */     if ("userid".equalsIgnoreCase(name)) {
/* 427 */       userid(value);
/*     */       return;
/*     */     } 
/* 430 */     if ("cocd".equalsIgnoreCase(name)) {
/* 431 */       cocd(value);
/*     */       return;
/*     */     } 
/* 434 */     if ("modid".equalsIgnoreCase(name)) {
/* 435 */       modid(value);
/*     */       return;
/*     */     } 
/* 438 */     if ("logid".equalsIgnoreCase(name)) {
/* 439 */       logid(value);
/*     */       return;
/*     */     } 
/* 442 */     if ("opeid".equalsIgnoreCase(name)) {
/* 443 */       opeid(value);
/*     */       return;
/*     */     } 
/* 446 */     super.setStringNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, MCNumber value) {
/* 449 */     if ("pushid".equalsIgnoreCase(name)) {
/* 450 */       pushid(value);
/*     */       return;
/*     */     } 
/* 453 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, int value) {
/* 456 */     if ("pushid".equalsIgnoreCase(name)) {
/* 457 */       pushid(value);
/*     */       return;
/*     */     } 
/* 460 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, long value) {
/* 463 */     if ("pushid".equalsIgnoreCase(name)) {
/* 464 */       pushid(value);
/*     */       return;
/*     */     } 
/* 467 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, float value) {
/* 470 */     if ("pushid".equalsIgnoreCase(name)) {
/* 471 */       pushid(value);
/*     */       return;
/*     */     } 
/* 474 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, double value) {
/* 477 */     if ("pushid".equalsIgnoreCase(name)) {
/* 478 */       pushid(value);
/*     */       return;
/*     */     } 
/* 481 */     super.setNumberNE(name, value);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\push\ctrl\Broadcast2_NoticeR_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */