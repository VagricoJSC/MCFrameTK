/*     */ package mcframe.serverCore.push.ctrl;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.commonCore.container.MCConstRow;
/*     */ import mcframe.commonCore.container.MCExtMap;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class ScreenR_FW_A
/*     */   extends MCConstRow
/*     */ {
/*     */   public static final String $type = "type";
/*     */   public static final String $key = "key";
/*     */   public static final String $val = "val";
/*  45 */   public static final MCMeta type_META = createStringMeta("type");
/*  46 */   public static final MCMeta key_META = createStringMeta("key");
/*  47 */   public static final MCMeta val_META = createStringMeta("val");
/*     */   
/*  49 */   protected static final MCRow.ConstMetaList<ScreenR> constMetas = new MCRow.ConstMetaList(
/*  50 */       MCConstRow.constMetas, 
/*  51 */       new MCMeta[] {
/*  52 */         type_META, 
/*  53 */         key_META, 
/*  54 */         val_META
/*     */       },
/*  56 */       new String[][] { {}, {} });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   protected static final MCExtMap EXTMAP = new MCExtMap(
/*  69 */       null, new MCExtMap.Entry[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] colnames() {
/*  81 */     return constMetas.toNameArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMeta[] colmetas() {
/*  93 */     return constMetas.toMetaArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  99 */   private static final int offset = constMetas.offset();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getExtMap(String aGroup) {
/* 105 */     if (aGroup == null) return null; 
/* 106 */     return (Map<String, String>)EXTMAP.get(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getKeys(String aGroup) {
/* 113 */     if (aGroup == null) return null; 
/* 114 */     return EXTMAP.getKeyList(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExtGroups() {
/* 121 */     Set<String> ret = EXTMAP.keySet();
/* 122 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ScreenR_FW_A(MCRow.ConstMetaList<? extends ScreenR> metas) {
/* 129 */     super(metas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ScreenR clone() {
/* 136 */     return (ScreenR)super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ScreenR createInstance() {
/* 143 */     return (ScreenR)super.createInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ScreenR getValues(String... names) {
/* 150 */     return (ScreenR)super.getValues(names);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireValueChanged(String column, Comparable<?> newvalue, Comparable<?> oldvalue) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String type() {
/* 166 */     return getConstString(offset + 0, "type");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void type(String value) {
/* 174 */     setConstString(offset + 0, "type", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String key() {
/* 183 */     return getConstString(offset + 1, "key");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void key(String value) {
/* 191 */     setConstString(offset + 1, "key", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String val() {
/* 200 */     return getConstString(offset + 2, "val");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void val(String value) {
/* 208 */     setConstString(offset + 2, "val", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString(String name) {
/* 213 */     if ("type".equalsIgnoreCase(name)) {
/* 214 */       return type();
/*     */     }
/* 216 */     if ("key".equalsIgnoreCase(name)) {
/* 217 */       return key();
/*     */     }
/* 219 */     if ("val".equalsIgnoreCase(name)) {
/* 220 */       return val();
/*     */     }
/* 222 */     return super.getString(name);
/*     */   }
/*     */   
/*     */   public String getStringNE(String name) {
/* 226 */     if ("type".equalsIgnoreCase(name)) {
/* 227 */       return type();
/*     */     }
/* 229 */     if ("key".equalsIgnoreCase(name)) {
/* 230 */       return key();
/*     */     }
/* 232 */     if ("val".equalsIgnoreCase(name)) {
/* 233 */       return val();
/*     */     }
/* 235 */     return super.getStringNE(name);
/*     */   }
/*     */   
/*     */   public void setString(String name, String value) {
/* 239 */     if ("type".equalsIgnoreCase(name)) {
/* 240 */       type(value);
/*     */       return;
/*     */     } 
/* 243 */     if ("key".equalsIgnoreCase(name)) {
/* 244 */       key(value);
/*     */       return;
/*     */     } 
/* 247 */     if ("val".equalsIgnoreCase(name)) {
/* 248 */       val(value);
/*     */       return;
/*     */     } 
/* 251 */     super.setString(name, value);
/*     */   }
/*     */   
/*     */   public void setStringNE(String name, String value) {
/* 255 */     if ("type".equalsIgnoreCase(name)) {
/* 256 */       type(value);
/*     */       return;
/*     */     } 
/* 259 */     if ("key".equalsIgnoreCase(name)) {
/* 260 */       key(value);
/*     */       return;
/*     */     } 
/* 263 */     if ("val".equalsIgnoreCase(name)) {
/* 264 */       val(value);
/*     */       return;
/*     */     } 
/* 267 */     super.setStringNE(name, value);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\push\ctrl\ScreenR_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */