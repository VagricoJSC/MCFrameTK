package mcframe.serverCore.push.ctrl;

import mcframe.commonCore.annotation.EI;

@EI
public class MCServerPush extends MCServerPush_FW {}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\push\ctrl\MCServerPush.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */