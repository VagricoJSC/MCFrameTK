/*     */ package mcframe.serverCore.push;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.Future;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import javax.websocket.CloseReason;
/*     */ import javax.websocket.EndpointConfig;
/*     */ import javax.websocket.OnClose;
/*     */ import javax.websocket.OnError;
/*     */ import javax.websocket.OnMessage;
/*     */ import javax.websocket.OnOpen;
/*     */ import javax.websocket.Session;
/*     */ import javax.websocket.server.ServerEndpoint;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCError;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.push.MCServerPushProxy;
/*     */ import mcframe.serverCore.mcjdbc.MCTransactionManager;
/*     */ import mcframe.serverCore.resource.MCConfig;
/*     */ import mcframe.serverCore.sys.MCSys;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @ServerEndpoint(value = "/MCPush", configurator = MCServerPushConfig.class)
/*     */ public class MCServerPushAgent
/*     */ {
/*  52 */   public static final String PROP_REQUEST_INFO = HttpSession.class.getName();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String ATTR_REMOTE_ADDR = "_mc_remote_addr";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String ATTR_REMOTE_HOST = "_mc_remote_host";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class MCServerPushProxyImpl
/*     */     implements MCServerPushProxy
/*     */   {
/*     */     public void send(MCNumber pushid, String message, String... ids) {
/*  76 */       MCServerPushAgent.send(pushid, message, ids);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void close(String... ids) {
/*  82 */       MCServerPushAgent.close(ids);
/*     */     }
/*     */ 
/*     */     
/*     */     public void disable() {
/*  87 */       MCServerPushAgent.disable();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  97 */   private static Map<String, Session> _sessionMap = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static List<Future<Void>> send(MCNumber pushid, String message, String... ids) {
/* 117 */     MCServerPushManager spmgr = MCServerPushManager.getManager();
/* 118 */     String pid = pushid.toSimpleString();
/* 119 */     MCLog.write(Core_Msg_FW_A.FCBGC0422, new Object[] { pid, message });
/* 120 */     List<Future<Void>> futureList = new ArrayList<>(); byte b; int i; String[] arrayOfString;
/* 121 */     for (i = (arrayOfString = ids).length, b = 0; b < i; ) { String id = arrayOfString[b];
/* 122 */       Session session = _sessionMap.get(id);
/* 123 */       if (session != null) {
/*     */         
/* 125 */         MCServerPushManager.UserSession user = spmgr.getUserSession(id);
/* 126 */         MCLog.write(Core_Msg_FW_A.FCBGC0442, new Object[] { pid, user.userid, id, user.host, user.ip });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 139 */         futureList.add(session.getAsyncRemote().sendText(message));
/*     */       }  b++; }
/*     */     
/* 142 */     return futureList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void disable() {
/* 152 */     for (Map.Entry<String, Session> entry : _sessionMap.entrySet()) {
/* 153 */       String id = entry.getKey();
/* 154 */       _sessionMap.remove(id);
/* 155 */       Session session = entry.getValue();
/* 156 */       close(id, session, 
/* 157 */           4002, 
/* 158 */           "this server is not serving push messages");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void close(String... ids) {
/*     */     byte b;
/*     */     int i;
/*     */     String[] arrayOfString;
/* 171 */     for (i = (arrayOfString = ids).length, b = 0; b < i; ) { String id = arrayOfString[b];
/* 172 */       Session session = _sessionMap.remove(id);
/*     */       
/* 174 */       close(id, session, 
/* 175 */           4001, 
/* 176 */           "forced close : [ " + id + " ]");
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void close(String id, Session session, final int code, String message) {
/* 191 */     if (session != null) {
/*     */       try {
/* 193 */         session.close(new CloseReason(new CloseReason.CloseCode()
/*     */               {
/*     */                 public int getCode()
/*     */                 {
/* 197 */                   return code;
/*     */                 }
/* 199 */               },  message));
/*     */       
/*     */       }
/* 202 */       catch (IOException e) {
/* 203 */         MCLog.developDebug("*** push *** forced/disabled close error : [ " + session.getId() + " ] " + e.getMessage());
/* 204 */         MCLog.write(e);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 211 */     MCServerPushManager spmgr = MCServerPushManager.getManager();
/* 212 */     spmgr.removeUserSession(id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getClientIP(Session session) {
/* 224 */     Map<?, ?> mcmap = getClientInfo(session);
/* 225 */     return (String)mcmap.get("_mc_remote_addr");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getClientHost(Session session) {
/* 237 */     Map<?, ?> mcmap = getClientInfo(session);
/* 238 */     return (String)mcmap.get("_mc_remote_host");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Map<?, ?> getClientInfo(Session session) {
/* 250 */     Map<String, Object> prop = session.getUserProperties();
/* 251 */     return (Map<?, ?>)prop.get(PROP_REQUEST_INFO);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void setClientInfo(Session session, EndpointConfig config) {
/* 263 */     Map<?, ?> mcmap = (Map<?, ?>)config.getUserProperties()
/* 264 */       .get(PROP_REQUEST_INFO);
/* 265 */     session.getUserProperties().put(PROP_REQUEST_INFO, mcmap);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @OnOpen
/*     */   public void onOpen(Session session, EndpointConfig config) {
/* 272 */     setClientInfo(session, config);
/*     */     
/* 274 */     String ip = getClientIP(session);
/* 275 */     String host = getClientHost(session);
/* 276 */     if (!MCSys.isInitialized())
/*     */     {
/* 278 */       throw new MCError("mcframe not ready.[{1}({2})] Session Open Failed", new String[] { host, ip });
/*     */     }
/*     */     
/* 281 */     MCLog.write(Core_Msg_FW_A.FCBGC0426, new Object[] { host, ip });
/*     */     
/* 283 */     MCLog.write(Core_Msg_FW_A.FCBGC0421, new Object[] { session.getId(), host, ip });
/*     */     
/* 285 */     MCLog.write(Core_Msg_FW_A.FCBGC0427, new Object[] { host, ip });
/*     */ 
/*     */     
/* 288 */     MCNumber tonum = MCConfig.server.getNumber("push.timeout.auth");
/* 289 */     long to = (tonum != null) ? tonum.longValue() : 30L;
/* 290 */     session.setMaxIdleTimeout(to * 1000L);
/*     */   }
/*     */ 
/*     */   
/*     */   @OnMessage
/*     */   public void onMessage(Session session, String message) {
/* 296 */     String ip = getClientIP(session);
/* 297 */     String host = getClientHost(session);
/* 298 */     if (!MCSys.isInitialized())
/*     */     {
/* 300 */       throw new MCError("mcframe not ready.[{1}({2})] Receive Message Failed\n{3}", new String[] { host, ip, message });
/*     */     }
/*     */     
/* 303 */     if (!MCServerPushManager.getManager().isEnabled()) {
/*     */       
/* 305 */       close(session.getId(), session, 
/* 306 */           4002, 
/* 307 */           "this server is not serving push messages");
/*     */       
/*     */       return;
/*     */     } 
/* 311 */     MCLog.write(Core_Msg_FW_A.FCBGC0426, new Object[] { host, ip });
/*     */     
/* 313 */     MCServerPushManager spmgr = MCServerPushManager.getManager();
/* 314 */     MCServerPushManager.UserSession user = spmgr.getUserSession(session.getId());
/*     */     
/* 316 */     String userid = (user != null) ? user.userid : null;
/* 317 */     MCLog.write(Core_Msg_FW_A.FCBGC0423, new Object[] { userid, session.getId(), host, ip, message });
/*     */ 
/*     */     
/*     */     try {
/*     */       MCNumber tonum;
/*     */       
/*     */       long to;
/*     */       
/* 325 */       String method = spmgr.recvMessage(session.getId(), host, message); String str1;
/* 326 */       switch ((str1 = method).hashCode()) { case 2020776: if (!str1.equals("AUTH")) {
/*     */             break;
/*     */           }
/*     */ 
/*     */           
/* 331 */           tonum = MCConfig.server.getNumber("push.timeout.message");
/* 332 */           to = (tonum != null) ? tonum.longValue() : 86400L;
/* 333 */           session.setMaxIdleTimeout(to * 1000L);
/*     */ 
/*     */           
/* 336 */           _sessionMap.put(session.getId(), session);
/*     */ 
/*     */           
/* 339 */           user = spmgr.authenticated(session.getId());
/* 340 */           user.ip = ip;
/* 341 */           user.host = host;
/*     */           break; }
/*     */ 
/*     */     
/* 345 */     } catch (Exception e) {
/* 346 */       MCLog.write(e);
/*     */       
/* 348 */       if (!_sessionMap.containsKey(session.getId())) {
/*     */         
/*     */         try {
/* 351 */           session.close(new CloseReason(new CloseReason.CloseCode()
/*     */                 {
/*     */                   public int getCode()
/*     */                   {
/* 355 */                     return 4999;
/*     */                   }
/* 357 */                 },  e.getMessage()));
/*     */         
/*     */         }
/* 360 */         catch (IOException e1) {
/* 361 */           MCLog.write(e1);
/*     */         
/*     */         }
/*     */       
/*     */       }
/*     */     }
/*     */     finally {
/*     */       
/* 369 */       MCTransactionManager.finalClose();
/*     */     } 
/*     */     
/* 372 */     MCLog.write(Core_Msg_FW_A.FCBGC0427, new Object[] { host, ip });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @OnMessage
/*     */   public void onBinaryMessage(ByteBuffer data) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @OnError
/*     */   public void onError(Session session, Throwable t) {
/*     */     MCError mCError;
/* 388 */     _sessionMap.remove(session.getId());
/* 389 */     MCServerPushManager spmgr = MCServerPushManager.getManager();
/* 390 */     MCServerPushManager.UserSession user = 
/* 391 */       spmgr.removeUserSession(session.getId());
/*     */ 
/*     */     
/* 394 */     String userid = (user != null) ? user.userid : null;
/* 395 */     String host = (user != null) ? user.host : null;
/* 396 */     String ip = (user != null) ? user.ip : null;
/*     */     
/* 398 */     if (!MCSys.isInitialized()) {
/*     */       
/* 400 */       if (!(t instanceof MCError)) {
/* 401 */         mCError = new MCError(t, "mcframe not ready.[{1}({2})]", new String[] { host, ip });
/*     */       }
/* 403 */       mCError.printStackTrace();
/*     */       
/*     */       return;
/*     */     } 
/* 407 */     MCLog.write(Core_Msg_FW_A.FCBGC0426, new Object[] { host, ip });
/*     */     
/* 409 */     MCLog.write(Core_Msg_FW_A.FCBGC0424, new Object[] { userid, session.getId(), host, ip, mCError.getMessage() });
/* 410 */     MCLog.write((Throwable)mCError);
/*     */     
/* 412 */     MCLog.write(Core_Msg_FW_A.FCBGC0427, new Object[] { host, ip });
/*     */   }
/*     */ 
/*     */   
/*     */   @OnClose
/*     */   public void onClose(Session session, CloseReason reason) {
/* 418 */     _sessionMap.remove(session.getId());
/* 419 */     MCServerPushManager spmgr = MCServerPushManager.getManager();
/* 420 */     MCServerPushManager.UserSession user = 
/* 421 */       spmgr.removeUserSession(session.getId());
/*     */ 
/*     */     
/* 424 */     String userid = (user != null) ? user.userid : null;
/* 425 */     String host = (user != null) ? user.host : null;
/* 426 */     String ip = (user != null) ? user.ip : null;
/*     */     
/* 428 */     if (!MCSys.isInitialized()) {
/*     */       
/* 430 */       MCError t = new MCError("mcframe not ready.[{1}({2})] Session Close Failed", new String[] { host, ip });
/* 431 */       t.printStackTrace();
/*     */       
/*     */       return;
/*     */     } 
/* 435 */     MCLog.write(Core_Msg_FW_A.FCBGC0426, new Object[] { host, ip });
/*     */     
/* 437 */     MCLog.write(Core_Msg_FW_A.FCBGC0425, new Object[] { userid, session.getId(), host, ip, 
/* 438 */           Integer.valueOf(reason.getCloseCode().getCode()), reason.getReasonPhrase() });
/*     */     
/* 440 */     MCLog.write(Core_Msg_FW_A.FCBGC0427, new Object[] { host, ip });
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\push\MCServerPushAgent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */