/*    */ package mcframe.serverCore.date;
/*    */ 
/*    */ import mcframe.commonCore.param.MCBlockDef;
/*    */ import mcframe.commonCore.param.MCContainerDef;
/*    */ import mcframe.commonCore.param.MCDef;
/*    */ import mcframe.commonCore.param.MCGeneralContainerDef;
/*    */ import mcframe.commonCore.param.MCItemDef;
/*    */ import mcframe.commonCore.param.MCOperationInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PDef_FW_A
/*    */   extends MCDef
/*    */ {
/*    */   public MCContainerDef getCustomDef(String id) {
/* 22 */     if (id == null) {
/* 23 */       return null;
/*    */     }
/*    */     
/* 26 */     if (id.equals("FC.FCBGL0150.Srch01.DOWN.BLOCK0")) {
/* 27 */       return FC_FCBGL0150_Srch01_DOWN_BLOCK0();
/*    */     }
/*    */ 
/*    */     
/* 31 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 37 */   static final MCOperationInfo FC_FCBGL0150_Srch01_INFO = new MCOperationInfo("FC", "FCBGL0150", "Srch01", "000000", new PDef());
/*    */ 
/*    */ 
/*    */   
/*    */   public static MCContainerDef FC_FCBGL0150_Srch01_DOWN_BLOCK0() {
/* 42 */     return (MCContainerDef)new MCGeneralContainerDef(
/* 43 */         new MCItemDef[] {
/* 44 */           MCItemDef.create("today", "today")
/*    */ 
/*    */         
/* 47 */         }MCBlockDef.create("Srch01_Rslt"));
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\date\PDef_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */