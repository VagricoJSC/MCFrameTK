/*    */ package mcframe.serverCore.date;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import mcframe.commonCore.annotation.EI;
/*    */ import mcframe.commonCore.container.MCRow;
/*    */ import mcframe.commonCore.lang.MCDate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @EI
/*    */ public class Srch01_RsltR
/*    */   extends Srch01_RsltR_FW_A
/*    */ {
/*    */   public static Srch01_RsltR create() {
/* 43 */     Srch01_RsltR row = new Srch01_RsltR(constMetas);
/* 44 */     return row;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static <T extends MCRow> Srch01_RsltR createByName(T proto) {
/* 54 */     Srch01_RsltR row = create();
/* 55 */     copyByName((MCRow)row, (MCRow)proto);
/* 56 */     return row;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Srch01_RsltR(MCRow.ConstMetaList<? extends Srch01_RsltR> metas) {
/* 63 */     super(metas);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\date\Srch01_RsltR.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */