/*     */ package mcframe.serverCore.date;
/*     */ 
/*     */ import mcframe.commonCore.container.MCContainer;
/*     */ import mcframe.commonCore.param.MCOperationInfo;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.serverCore.logic.MCLogic;
/*     */ import mcframe.serverCore.logic.MCLogicBase;
/*     */ import mcframe.serverCore.logic.MCLogicUtil;
/*     */ import mcframe.serverCore.logic.MCOperation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class CoToday_FW_A
/*     */   extends MCLogicBase
/*     */ {
/*     */   public static final String MODULE_ID = "FC";
/*     */   public static final String SUBMODULE_ID = "FCBG";
/*     */   public static final String LOGIC_ID = "FCBGL0150";
/*     */   protected CoToday_FW.Srch01 aSrch01;
/*     */   
/*     */   public String getModuleID() {
/*  42 */     return "FC";
/*     */   } public String getSubmoduleID() {
/*  44 */     return "FCBG";
/*     */   } public String getLogicID() {
/*  46 */     return "FCBGL0150";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initSrch01() {
/*  53 */     this.info = PDef.FC_FCBGL0150_Srch01_INFO;
/*  54 */     ((CoToday)this).getClass(); this.aSrch01 = new CoToday_FW.Srch01((CoToday)this);
/*     */   }
/*     */   
/*     */   public static CoToday_FW.Srch01 crtSrch01() {
/*  58 */     CoToday lgc = new CoToday();
/*  59 */     lgc.initSrch01();
/*  60 */     return lgc.aSrch01;
/*     */   }
/*     */   
/*     */   protected void paramSrch01(MCParam p) {
/*  64 */     if (this.aSrch01 == null) {
/*     */       return;
/*     */     }
/*  67 */     p.setDef(this.info.def);
/*  68 */     p.addDownBlock((MCContainer)this.aSrch01.down0());
/*     */   }
/*     */   
/*     */   protected void doSrch01() {
/*  72 */     this.aSrch01.call();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Srch01_RsltR createSrch01_RsltR() {
/*  81 */     return Srch01_RsltR.create();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract class Srch01
/*     */     extends MCOperation
/*     */   {
/*     */     public static final String OPERATION_ID = "Srch01";
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final Srch01_RsltR down0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getOperationID() {
/* 103 */       return "Srch01";
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected Srch01() {
/* 114 */       this.down0 = Srch01_RsltR.create();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void mapUpContainers(String key) {
/* 128 */       super.mapUpContainers(key);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void mapDownContainers(String key) {
/* 136 */       super.mapDownContainers(key);
/*     */     }
/*     */     
/*     */     public MCContainer up(int i) {
/* 140 */       return null;
/*     */     }
/*     */     
/*     */     public MCContainer down(int i) {
/* 144 */       if (i == 0) return (MCContainer)down0(); 
/* 145 */       return null;
/*     */     }
/*     */     
/*     */     public void exec() {
/* 149 */       clear();
/* 150 */       MCLogicUtil.invoke((MCLogic)CoToday_FW_A.this);
/*     */     }
/*     */     
/*     */     protected void clear() {
/* 154 */       down0().clear();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Srch01_RsltR createSrch01_RsltR() {
/* 162 */       return Srch01_RsltR.create();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Srch01_RsltR down0() {
/* 185 */       return this.down0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MCOperationInfo getOperationInfo() {
/* 192 */       return CoToday_FW_A.this.info;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\date\CoToday_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */