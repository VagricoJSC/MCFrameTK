/*    */ package mcframe.serverCore.date;
/*    */ 
/*    */ import mcframe.serverCore.mcjdbc.FWDBUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class CoToday_FW
/*    */   extends CoToday_FW_A
/*    */ {
/*    */   public class Srch01
/*    */     extends CoToday_FW_A.Srch01
/*    */   {
/*    */     protected void call() {
/* 27 */       down0().today(FWDBUtil.coToday());
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\date\CoToday_FW.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */