/*     */ package mcframe.serverCore.date;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.commonCore.container.MCConstRow;
/*     */ import mcframe.commonCore.container.MCExtMap;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCDate;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ import mcframe.commonCore.meta.M_META;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class Srch01_RsltR_FW_A
/*     */   extends MCConstRow
/*     */ {
/*     */   public static final String $today = "today";
/*  35 */   public static final MCMeta today_META = createCommonMeta("today", M_META.DT);
/*     */   
/*  37 */   protected static final MCRow.ConstMetaList<Srch01_RsltR> constMetas = new MCRow.ConstMetaList(
/*  38 */       MCConstRow.constMetas, 
/*  39 */       new MCMeta[] {
/*  40 */         today_META
/*     */       },
/*  42 */       new String[][] { {}, {} });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   protected static final MCExtMap EXTMAP = new MCExtMap(
/*  55 */       null, new MCExtMap.Entry[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] colnames() {
/*  67 */     return constMetas.toNameArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMeta[] colmetas() {
/*  79 */     return constMetas.toMetaArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  85 */   private static final int offset = constMetas.offset();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getExtMap(String aGroup) {
/*  91 */     if (aGroup == null) return null; 
/*  92 */     return (Map<String, String>)EXTMAP.get(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getKeys(String aGroup) {
/*  99 */     if (aGroup == null) return null; 
/* 100 */     return EXTMAP.getKeyList(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExtGroups() {
/* 107 */     Set<String> ret = EXTMAP.keySet();
/* 108 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Srch01_RsltR_FW_A(MCRow.ConstMetaList<? extends Srch01_RsltR> metas) {
/* 115 */     super(metas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Srch01_RsltR clone() {
/* 122 */     return (Srch01_RsltR)super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Srch01_RsltR createInstance() {
/* 129 */     return (Srch01_RsltR)super.createInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Srch01_RsltR getValues(String... names) {
/* 136 */     return (Srch01_RsltR)super.getValues(names);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireValueChanged(String column, Comparable<?> newvalue, Comparable<?> oldvalue) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCDate today() {
/* 152 */     return getConstDate(offset + 0, "today");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void today(MCDate value) {
/* 160 */     setConstDate(offset + 0, "today", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCDate getDate(String name) {
/* 165 */     if ("today".equalsIgnoreCase(name)) {
/* 166 */       return today();
/*     */     }
/* 168 */     return super.getDate(name);
/*     */   }
/*     */   
/*     */   public MCDate getDateNE(String name) {
/* 172 */     if ("today".equalsIgnoreCase(name)) {
/* 173 */       return today();
/*     */     }
/* 175 */     return super.getDateNE(name);
/*     */   }
/*     */   
/*     */   public void setDate(String name, MCDate value) {
/* 179 */     if ("today".equalsIgnoreCase(name)) {
/* 180 */       today(value);
/*     */       return;
/*     */     } 
/* 183 */     super.setDate(name, value);
/*     */   }
/*     */   
/*     */   public void setDateNE(String name, MCDate value) {
/* 187 */     if ("today".equalsIgnoreCase(name)) {
/* 188 */       today(value);
/*     */       return;
/*     */     } 
/* 191 */     super.setDateNE(name, value);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\date\Srch01_RsltR_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */