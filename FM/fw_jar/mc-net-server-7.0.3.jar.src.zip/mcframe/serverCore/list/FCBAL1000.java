package mcframe.serverCore.list;

import mcframe.commonCore.annotation.EI;

@EI
public class FCBAL1000 extends FCBAL1000_FW {}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\list\FCBAL1000.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */