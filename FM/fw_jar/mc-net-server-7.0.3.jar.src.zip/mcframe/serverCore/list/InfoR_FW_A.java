/*     */ package mcframe.serverCore.list;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.commonCore.container.MCConstRow;
/*     */ import mcframe.commonCore.container.MCExtMap;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class InfoR_FW_A
/*     */   extends MCConstRow
/*     */ {
/*     */   public static final String $CLASS = "CLASS";
/*     */   public static final String $METHOD = "METHOD";
/*  32 */   public static final MCMeta CLASS_META = createStringMeta("CLASS", 1);
/*  33 */   public static final MCMeta METHOD_META = createStringMeta("METHOD", 1);
/*     */   
/*  35 */   protected static final MCRow.ConstMetaList<InfoR> constMetas = new MCRow.ConstMetaList(
/*  36 */       MCConstRow.constMetas, 
/*  37 */       new MCMeta[] {
/*  38 */         CLASS_META, 
/*  39 */         METHOD_META
/*     */       },
/*  41 */       new String[][] { {}, {} });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   protected static final MCExtMap EXTMAP = new MCExtMap(
/*  54 */       null, new MCExtMap.Entry[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] colnames() {
/*  66 */     return constMetas.toNameArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMeta[] colmetas() {
/*  78 */     return constMetas.toMetaArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   private static final int offset = constMetas.offset();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getExtMap(String aGroup) {
/*  90 */     if (aGroup == null) return null; 
/*  91 */     return (Map<String, String>)EXTMAP.get(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getKeys(String aGroup) {
/*  98 */     if (aGroup == null) return null; 
/*  99 */     return EXTMAP.getKeyList(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExtGroups() {
/* 106 */     Set<String> ret = EXTMAP.keySet();
/* 107 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected InfoR_FW_A(MCRow.ConstMetaList<? extends InfoR> metas) {
/* 114 */     super(metas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InfoR clone() {
/* 121 */     return (InfoR)super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InfoR createInstance() {
/* 128 */     return (InfoR)super.createInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InfoR getValues(String... names) {
/* 135 */     return (InfoR)super.getValues(names);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireValueChanged(String column, Comparable<?> newvalue, Comparable<?> oldvalue) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String CLASS() {
/* 147 */     return getConstString(offset + 0, "CLASS");
/*     */   }
/*     */   
/*     */   public void CLASS(String value) {
/* 151 */     setConstString(offset + 0, "CLASS", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String METHOD() {
/* 156 */     return getConstString(offset + 1, "METHOD");
/*     */   }
/*     */   
/*     */   public void METHOD(String value) {
/* 160 */     setConstString(offset + 1, "METHOD", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString(String name) {
/* 165 */     if ("CLASS".equalsIgnoreCase(name)) {
/* 166 */       return CLASS();
/*     */     }
/* 168 */     if ("METHOD".equalsIgnoreCase(name)) {
/* 169 */       return METHOD();
/*     */     }
/* 171 */     return super.getString(name);
/*     */   }
/*     */   
/*     */   public String getStringNE(String name) {
/* 175 */     if ("CLASS".equalsIgnoreCase(name)) {
/* 176 */       return CLASS();
/*     */     }
/* 178 */     if ("METHOD".equalsIgnoreCase(name)) {
/* 179 */       return METHOD();
/*     */     }
/* 181 */     return super.getStringNE(name);
/*     */   }
/*     */   
/*     */   public void setString(String name, String value) {
/* 185 */     if ("CLASS".equalsIgnoreCase(name)) {
/* 186 */       CLASS(value);
/*     */       return;
/*     */     } 
/* 189 */     if ("METHOD".equalsIgnoreCase(name)) {
/* 190 */       METHOD(value);
/*     */       return;
/*     */     } 
/* 193 */     super.setString(name, value);
/*     */   }
/*     */   
/*     */   public void setStringNE(String name, String value) {
/* 197 */     if ("CLASS".equalsIgnoreCase(name)) {
/* 198 */       CLASS(value);
/*     */       return;
/*     */     } 
/* 201 */     if ("METHOD".equalsIgnoreCase(name)) {
/* 202 */       METHOD(value);
/*     */       return;
/*     */     } 
/* 205 */     super.setStringNE(name, value);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\list\InfoR_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */