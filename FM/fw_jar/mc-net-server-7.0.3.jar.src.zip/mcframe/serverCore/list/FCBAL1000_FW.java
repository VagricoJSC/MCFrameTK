/*     */ package mcframe.serverCore.list;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import mcframe.commonCore.container.MCContainer;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCDataType;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.commonCore.sys.MCFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FCBAL1000_FW
/*     */   extends FCBAL1000_FW_A
/*     */ {
/*     */   protected void paramSrch03(MCParam p) {
/*  23 */     if (this.aSrch03 == null) {
/*     */       return;
/*     */     }
/*  26 */     p.setDef(this.info.def);
/*  27 */     p.addUpBlock((MCContainer)this.aSrch03.up0());
/*  28 */     p.addUpBlock((MCContainer)this.aSrch03._up1());
/*  29 */     p.addDownBlock((MCContainer)this.aSrch03._down0());
/*  30 */     p.addDownBlock((MCContainer)this.aSrch03._down1());
/*  31 */     p.addDownBlock((MCContainer)this.aSrch03._down2());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void paramSrch04(MCParam p) {
/*  36 */     if (this.aSrch04 == null) {
/*     */       return;
/*     */     }
/*  39 */     p.setDef(this.info.def);
/*  40 */     p.addUpBlock((MCContainer)this.aSrch04.up0());
/*  41 */     p.addUpBlock((MCContainer)this.aSrch04._up1());
/*  42 */     p.addDownBlock((MCContainer)this.aSrch04._down0());
/*  43 */     p.addDownBlock((MCContainer)this.aSrch04._down1());
/*  44 */     p.addDownBlock((MCContainer)this.aSrch04._down2());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class Srch01
/*     */     extends FCBAL1000_FW_A.Srch01
/*     */   {
/*     */     protected void call() {
/*  55 */       down0().addAllByName((Collection)getList());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private MCList<TypeR> getList() {
/*  66 */       Object o = MCFactory.create(Object.class, up0().CLASS());
/*  67 */       Class[] a = {
/*  68 */           MCRow.class
/*     */         };
/*  70 */       MCList<?> l = (MCList)MCFactory.invoke(o, up0().METHOD(), a, 
/*  71 */           new Object[] {
/*  72 */             FCBAL1000_FW.access$0(this.this$0, up1())
/*     */           });
/*  74 */       return createDownDataList(l);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private MCList<TypeR> createDownDataList(MCList<?> list) {
/*  86 */       MCList<TypeR> result = MCList.create(TypeR.class);
/*  87 */       if (list != null) {
/*  88 */         MCRow[] rows = list.toArray();
/*  89 */         int length = rows.length;
/*  90 */         for (int i = 0; i < length; i++) {
/*  91 */           MCRow row = rows[i];
/*  92 */           String[] names = row.getNameArray();
/*  93 */           int count = names.length;
/*  94 */           for (int j = 0; j < count; j++) {
/*  95 */             result.add((MCRow)FCBAL1000_FW.this.setValue(row, names[j], i));
/*     */           }
/*     */         } 
/*     */       } 
/*  99 */       return result;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class Srch02
/*     */     extends FCBAL1000_FW_A.Srch02
/*     */   {
/*     */     protected void call() {
/* 111 */       down0().addAllByName((Collection)getRow());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private MCList<TypeR> getRow() {
/* 122 */       Object o = MCFactory.create(Object.class, up0().CLASS());
/* 123 */       Class[] a = {
/* 124 */           MCRow.class
/*     */         };
/* 126 */       MCRow c = (MCRow)MCFactory.invoke(o, up0().METHOD(), a, new Object[] {
/* 127 */             FCBAL1000_FW.access$0(this.this$0, up1())
/*     */           });
/* 129 */       return createDownDataList(c);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private MCList<TypeR> createDownDataList(MCRow row) {
/* 141 */       MCList<TypeR> result = MCList.create(TypeR.class);
/* 142 */       if (row != null) {
/* 143 */         String[] names = row.getNameArray();
/* 144 */         int count = names.length;
/* 145 */         for (int i = 0; i < count; i++) {
/* 146 */           result.add((MCRow)FCBAL1000_FW.this.setValue(row, names[i], 0));
/*     */         }
/*     */       } 
/* 149 */       return result;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCRow createCondition(MCList<TypeR> list) {
/* 162 */     MCRow result = MCRow.create();
/* 163 */     TypeR[] rows = (TypeR[])list.toArray();
/* 164 */     int count = rows.length;
/* 165 */     for (int i = 0; i < count; i++) {
/* 166 */       setValue(result, rows[i]);
/*     */     }
/* 168 */     return result;
/*     */   }
/*     */   
/*     */   private void setValue(MCRow target, TypeR row) {
/* 172 */     String name = row.NAME();
/* 173 */     MCDataType type = MCDataType.valueOf(row.TYPE());
/* 174 */     switch (type) {
/*     */       case STRING:
/* 176 */         target.setStringNE(name, row.STRING_VAL());
/*     */         return;
/*     */       case DATE:
/* 179 */         target.setDateNE(name, row.DATE_VAL());
/*     */         return;
/*     */       case TIMESTAMP:
/* 182 */         target.setTimestampNE(name, row.TIMESTAMP_VAL());
/*     */         return;
/*     */       case NUMBER:
/* 185 */         target.setNumberNE(name, row.NUMBER_VAL());
/*     */         return;
/*     */       case BOOLEAN:
/* 188 */         target.setBooleanNE(name, row.BOOLEAN_VAL());
/*     */         return;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TypeR setValue(MCRow row, String name, int index) {
/* 204 */     TypeR result = TypeR.create();
/* 205 */     result.NAME(name);
/* 206 */     MCDataType type = row.getDataType(name);
/* 207 */     result.TYPE(type.toString());
/* 208 */     switch (type) {
/*     */       case STRING:
/* 210 */         result.STRING_VAL(row.getString(name));
/*     */         break;
/*     */       case DATE:
/* 213 */         result.DATE_VAL(row.getDate(name));
/*     */         break;
/*     */       case TIMESTAMP:
/* 216 */         result.TIMESTAMP_VAL(row.getTimestamp(name));
/*     */         break;
/*     */       case NUMBER:
/* 219 */         result.NUMBER_VAL(row.getNumber(name));
/*     */         break;
/*     */       case BOOLEAN:
/* 222 */         result.BOOLEAN_VAL(row.getBoolean(name));
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 227 */     result.ROW_NUM(String.valueOf(index));
/* 228 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public class Srch03
/*     */     extends FCBAL1000_FW_A.Srch03
/*     */   {
/*     */     final MCRow up1;
/*     */ 
/*     */     
/*     */     final MCRow down0;
/*     */ 
/*     */     
/*     */     final MCRow down1;
/*     */ 
/*     */     
/*     */     final MCList<MCRow> down2;
/*     */ 
/*     */     
/*     */     protected Srch03() {
/* 249 */       this.up1 = MCRow.create();
/* 250 */       this.down0 = MCRow.create();
/* 251 */       this.down1 = MCRow.create();
/* 252 */       this.down2 = MCList.create(MCRow.class);
/*     */     }
/*     */     
/*     */     protected MCRow _up1() {
/* 256 */       return this.up1;
/*     */     }
/*     */     
/*     */     protected MCRow _down0() {
/* 260 */       return this.down0;
/*     */     }
/*     */     
/*     */     protected MCRow _down1() {
/* 264 */       return this.down1;
/*     */     }
/*     */     
/*     */     protected MCList<MCRow> _down2() {
/* 268 */       return this.down2;
/*     */     }
/*     */ 
/*     */     
/*     */     public void call() {
/* 273 */       MCList<? extends MCRow> d2 = getList();
/* 274 */       if (d2 != null && d2.size() > 0) {
/* 275 */         Map<String, MCMeta> ms = null;
/* 276 */         for (MCRow r : d2) {
/* 277 */           String[] na = r.getNameArray();
/* 278 */           if (ms == null) {
/* 279 */             ms = new LinkedHashMap<>(na.length);
/*     */           }
/* 281 */           MCMeta[] ma = r.getMetaArray();
/* 282 */           for (int i = 0; i < na.length; i++) {
/* 283 */             ms.put(na[i], ma[i]);
/*     */           }
/*     */         } 
/* 286 */         if (ms != null) {
/* 287 */           for (Map.Entry<String, MCMeta> e : ms.entrySet()) {
/* 288 */             String n = e.getKey();
/*     */             
/* 290 */             _down0().addStringColumn(n, n);
/* 291 */             _down1().addStringColumn(n, ((MCMeta)e.getValue()).type().name());
/*     */           } 
/*     */         }
/*     */         
/* 295 */         _down2().setAll((Collection)d2);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private MCList<? extends MCRow> getList() {
/* 308 */       Object o = MCFactory.create(Object.class, up0().CLASS());
/* 309 */       Class[] a = {
/* 310 */           MCRow.class
/*     */         };
/*     */ 
/*     */ 
/*     */       
/* 315 */       Object r = MCFactory.invoke(o, up0().METHOD(), a, new Object[] {
/* 316 */             _up1()
/*     */           });
/* 318 */       return (MCList<? extends MCRow>)r;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public class Srch04
/*     */     extends FCBAL1000_FW_A.Srch04
/*     */   {
/*     */     final MCRow up1;
/*     */ 
/*     */     
/*     */     final MCRow down0;
/*     */     
/*     */     final MCRow down1;
/*     */     
/*     */     final MCRow down2;
/*     */ 
/*     */     
/*     */     protected Srch04() {
/* 338 */       this.up1 = MCRow.create();
/* 339 */       this.down0 = MCRow.create();
/* 340 */       this.down1 = MCRow.create();
/* 341 */       this.down2 = MCRow.create();
/*     */     }
/*     */     
/*     */     protected MCRow _up1() {
/* 345 */       return this.up1;
/*     */     }
/*     */     
/*     */     protected MCRow _down0() {
/* 349 */       return this.down0;
/*     */     }
/*     */     
/*     */     protected MCRow _down1() {
/* 353 */       return this.down1;
/*     */     }
/*     */     
/*     */     protected MCRow _down2() {
/* 357 */       return this.down2;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void call() {
/* 363 */       MCRow r = getRow();
/* 364 */       if (r != null) {
/* 365 */         String[] na = r.getNameArray();
/* 366 */         MCMeta[] ma = r.getMetaArray();
/* 367 */         for (int i = 0; i < na.length; i++) {
/* 368 */           String n = na[i];
/* 369 */           MCMeta m = ma[i];
/* 370 */           _down0().addStringColumn(n, n);
/* 371 */           _down1().addStringColumn(n, m.type().name());
/* 372 */           if (!_down2().contains(n)) {
/* 373 */             _down2().addValueColumn(n, m.type());
/*     */           }
/*     */         } 
/* 376 */         _down2().setValuesByName(r);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private MCRow getRow() {
/* 388 */       Object o = MCFactory.create(Object.class, up0().CLASS());
/* 389 */       Class[] a = {
/* 390 */           MCRow.class
/*     */         };
/*     */ 
/*     */ 
/*     */       
/* 395 */       MCRow c = (MCRow)MCFactory.invoke(o, up0().METHOD(), a, new Object[] {
/* 396 */             _up1()
/*     */           });
/* 398 */       return c;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\list\FCBAL1000_FW.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */