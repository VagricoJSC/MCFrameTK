/*    */ package mcframe.serverCore.list;
/*    */ 
/*    */ import mcframe.commonCore.sys.MCFactory;
/*    */ import mcframe.commonCore.util.MCListLogicUtil;
/*    */ import mcframe.serverCore.logic.MCLogicBase;
/*    */ import mcframe.serverCore.resource.MCConst;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCListLogicUtil
/*    */   extends MCListLogicUtil
/*    */ {
/*    */   public static MCLogicBase getServerClass(String listLogicId) {
/* 17 */     String s = MCConst.ll.getServerClass(listLogicId);
/* 18 */     return (MCLogicBase)MCFactory.create(MCLogicBase.class, s);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\list\MCListLogicUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */