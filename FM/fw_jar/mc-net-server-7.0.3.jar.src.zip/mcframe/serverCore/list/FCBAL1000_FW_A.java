/*     */ package mcframe.serverCore.list;
/*     */ 
/*     */ import mcframe.commonCore.container.MCContainer;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.param.MCOperationInfo;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.serverCore.logic.MCLogic;
/*     */ import mcframe.serverCore.logic.MCLogicBase;
/*     */ import mcframe.serverCore.logic.MCLogicUtil;
/*     */ import mcframe.serverCore.logic.MCOperation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FCBAL1000_FW_A
/*     */   extends MCLogicBase
/*     */ {
/*     */   public static final String MODULE_ID = "FC";
/*     */   public static final String SUBMODULE_ID = "FCBA";
/*     */   public static final String LOGIC_ID = "FCBAL1000";
/*     */   protected FCBAL1000_FW.Srch01 aSrch01;
/*     */   protected FCBAL1000_FW.Srch02 aSrch02;
/*     */   protected FCBAL1000_FW.Srch03 aSrch03;
/*     */   protected FCBAL1000_FW.Srch04 aSrch04;
/*     */   
/*     */   public String getModuleID() {
/*  42 */     return "FC";
/*     */   } public String getSubmoduleID() {
/*  44 */     return "FCBA";
/*     */   } public String getLogicID() {
/*  46 */     return "FCBAL1000";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InfoR createInfoR() {
/*  56 */     return InfoR.create();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeR createTypeR() {
/*  65 */     return TypeR.create();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initSrch01() {
/*  70 */     this.info = PDef.FC_FCBAL1000_Srch01_INFO;
/*  71 */     ((FCBAL1000)this).getClass(); this.aSrch01 = new FCBAL1000_FW.Srch01((FCBAL1000)this);
/*     */   }
/*     */   
/*     */   public static FCBAL1000_FW.Srch01 crtSrch01() {
/*  75 */     FCBAL1000 lgc = new FCBAL1000();
/*  76 */     lgc.initSrch01();
/*  77 */     return lgc.aSrch01;
/*     */   }
/*     */   
/*     */   protected void paramSrch01(MCParam p) {
/*  81 */     if (this.aSrch01 == null) {
/*     */       return;
/*     */     }
/*  84 */     p.setDef(this.info.def);
/*  85 */     p.addUpBlock((MCContainer)this.aSrch01.up0());
/*  86 */     p.addUpBlock((MCContainer)this.aSrch01.up1());
/*  87 */     p.addDownBlock((MCContainer)this.aSrch01.down0());
/*     */   }
/*     */   
/*     */   protected void doSrch01() {
/*  91 */     this.aSrch01.call();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCList<TypeR> createTypeL() {
/* 100 */     return MCList.create(TypeR.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeR createRsltR() {
/* 109 */     return TypeR.create();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCList<TypeR> createRsltL() {
/* 118 */     return MCList.create(TypeR.class);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initSrch02() {
/* 123 */     this.info = PDef.FC_FCBAL1000_Srch02_INFO;
/* 124 */     ((FCBAL1000)this).getClass(); this.aSrch02 = new FCBAL1000_FW.Srch02((FCBAL1000)this);
/*     */   }
/*     */   
/*     */   public static FCBAL1000_FW.Srch02 crtSrch02() {
/* 128 */     FCBAL1000 lgc = new FCBAL1000();
/* 129 */     lgc.initSrch02();
/* 130 */     return lgc.aSrch02;
/*     */   }
/*     */   
/*     */   protected void paramSrch02(MCParam p) {
/* 134 */     if (this.aSrch02 == null) {
/*     */       return;
/*     */     }
/* 137 */     p.setDef(this.info.def);
/* 138 */     p.addUpBlock((MCContainer)this.aSrch02.up0());
/* 139 */     p.addUpBlock((MCContainer)this.aSrch02.up1());
/* 140 */     p.addDownBlock((MCContainer)this.aSrch02.down0());
/*     */   }
/*     */   
/*     */   protected void doSrch02() {
/* 144 */     this.aSrch02.call();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initSrch03() {
/* 149 */     this.info = PDef.FC_FCBAL1000_Srch03_INFO;
/* 150 */     ((FCBAL1000)this).getClass(); this.aSrch03 = new FCBAL1000_FW.Srch03((FCBAL1000)this);
/*     */   }
/*     */   
/*     */   public static FCBAL1000_FW.Srch03 crtSrch03() {
/* 154 */     FCBAL1000 lgc = new FCBAL1000();
/* 155 */     lgc.initSrch03();
/* 156 */     return lgc.aSrch03;
/*     */   }
/*     */   
/*     */   protected void paramSrch03(MCParam p) {
/* 160 */     if (this.aSrch03 == null) {
/*     */       return;
/*     */     }
/* 163 */     p.setDef(this.info.def);
/* 164 */     p.addUpBlock((MCContainer)this.aSrch03.up0());
/*     */   }
/*     */   
/*     */   protected void doSrch03() {
/* 168 */     this.aSrch03.call();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initSrch04() {
/* 173 */     this.info = PDef.FC_FCBAL1000_Srch04_INFO;
/* 174 */     ((FCBAL1000)this).getClass(); this.aSrch04 = new FCBAL1000_FW.Srch04((FCBAL1000)this);
/*     */   }
/*     */   
/*     */   public static FCBAL1000_FW.Srch04 crtSrch04() {
/* 178 */     FCBAL1000 lgc = new FCBAL1000();
/* 179 */     lgc.initSrch04();
/* 180 */     return lgc.aSrch04;
/*     */   }
/*     */   
/*     */   protected void paramSrch04(MCParam p) {
/* 184 */     if (this.aSrch04 == null) {
/*     */       return;
/*     */     }
/* 187 */     p.setDef(this.info.def);
/* 188 */     p.addUpBlock((MCContainer)this.aSrch04.up0());
/*     */   }
/*     */   
/*     */   protected void doSrch04() {
/* 192 */     this.aSrch04.call();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract class Srch01
/*     */     extends MCOperation
/*     */   {
/*     */     public static final String OPERATION_ID = "Srch01";
/*     */ 
/*     */     
/*     */     private final InfoR up0;
/*     */ 
/*     */     
/*     */     private final MCList<TypeR> up1;
/*     */ 
/*     */     
/*     */     private final MCList<TypeR> down0;
/*     */ 
/*     */ 
/*     */     
/*     */     public String getOperationID() {
/* 214 */       return "Srch01";
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected Srch01() {
/* 229 */       this.up0 = InfoR.create();
/* 230 */       this.up1 = MCList.create(TypeR.class);
/* 231 */       this.down0 = MCList.create(TypeR.class);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void mapUpContainers(String key) {
/* 245 */       super.mapUpContainers(key);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void mapDownContainers(String key) {
/* 253 */       super.mapDownContainers(key);
/*     */     }
/*     */     
/*     */     public MCContainer up(int i) {
/* 257 */       if (i == 0) return (MCContainer)up0(); 
/* 258 */       if (i == 1) return (MCContainer)up1(); 
/* 259 */       return null;
/*     */     }
/*     */     
/*     */     public MCContainer down(int i) {
/* 263 */       if (i == 0) return (MCContainer)down0(); 
/* 264 */       return null;
/*     */     }
/*     */     
/*     */     public void exec() {
/* 268 */       clear();
/* 269 */       MCLogicUtil.invoke((MCLogic)FCBAL1000_FW_A.this);
/*     */     }
/*     */     
/*     */     protected void clear() {
/* 273 */       down0().clear();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public InfoR createInfoR() {
/* 281 */       return InfoR.create();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeR createTypeR() {
/* 290 */       return TypeR.create();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MCList<TypeR> createTypeL() {
/* 299 */       return MCList.create(TypeR.class);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeR createRsltR() {
/* 308 */       return TypeR.create();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MCList<TypeR> createRsltL() {
/* 317 */       return MCList.create(TypeR.class);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public InfoR up0() {
/* 343 */       return this.up0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MCList<TypeR> up1() {
/* 392 */       return this.up1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MCList<TypeR> down0() {
/* 442 */       return this.down0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MCOperationInfo getOperationInfo() {
/* 449 */       return FCBAL1000_FW_A.this.info;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract class Srch02
/*     */     extends MCOperation
/*     */   {
/*     */     public static final String OPERATION_ID = "Srch02";
/*     */ 
/*     */     
/*     */     private final InfoR up0;
/*     */     
/*     */     private final MCList<TypeR> up1;
/*     */     
/*     */     private final MCList<TypeR> down0;
/*     */ 
/*     */     
/*     */     public String getOperationID() {
/* 469 */       return "Srch02";
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected Srch02() {
/* 484 */       this.up0 = InfoR.create();
/* 485 */       this.up1 = MCList.create(TypeR.class);
/* 486 */       this.down0 = MCList.create(TypeR.class);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void mapUpContainers(String key) {
/* 500 */       super.mapUpContainers(key);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void mapDownContainers(String key) {
/* 508 */       super.mapDownContainers(key);
/*     */     }
/*     */     
/*     */     public MCContainer up(int i) {
/* 512 */       if (i == 0) return (MCContainer)up0(); 
/* 513 */       if (i == 1) return (MCContainer)up1(); 
/* 514 */       return null;
/*     */     }
/*     */     
/*     */     public MCContainer down(int i) {
/* 518 */       if (i == 0) return (MCContainer)down0(); 
/* 519 */       return null;
/*     */     }
/*     */     
/*     */     public void exec() {
/* 523 */       clear();
/* 524 */       MCLogicUtil.invoke((MCLogic)FCBAL1000_FW_A.this);
/*     */     }
/*     */     
/*     */     protected void clear() {
/* 528 */       down0().clear();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public InfoR createInfoR() {
/* 536 */       return InfoR.create();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeR createTypeR() {
/* 545 */       return TypeR.create();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MCList<TypeR> createTypeL() {
/* 554 */       return MCList.create(TypeR.class);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeR createRsltR() {
/* 563 */       return TypeR.create();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MCList<TypeR> createRsltL() {
/* 572 */       return MCList.create(TypeR.class);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public InfoR up0() {
/* 598 */       return this.up0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MCList<TypeR> up1() {
/* 647 */       return this.up1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MCList<TypeR> down0() {
/* 697 */       return this.down0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MCOperationInfo getOperationInfo() {
/* 704 */       return FCBAL1000_FW_A.this.info;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract class Srch03
/*     */     extends MCOperation
/*     */   {
/*     */     public static final String OPERATION_ID = "Srch03";
/*     */ 
/*     */ 
/*     */     
/*     */     private final InfoR up0;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getOperationID() {
/* 724 */       return "Srch03";
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected Srch03() {
/* 735 */       this.up0 = InfoR.create();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void mapUpContainers(String key) {
/* 749 */       super.mapUpContainers(key);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void mapDownContainers(String key) {
/* 757 */       super.mapDownContainers(key);
/*     */     }
/*     */     
/*     */     public MCContainer up(int i) {
/* 761 */       if (i == 0) return (MCContainer)up0(); 
/* 762 */       return null;
/*     */     }
/*     */     
/*     */     public MCContainer down(int i) {
/* 766 */       return null;
/*     */     }
/*     */     
/*     */     public void exec() {
/* 770 */       clear();
/* 771 */       MCLogicUtil.invoke((MCLogic)FCBAL1000_FW_A.this);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void clear() {}
/*     */ 
/*     */ 
/*     */     
/*     */     public InfoR createInfoR() {
/* 782 */       return InfoR.create();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public InfoR up0() {
/* 808 */       return this.up0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MCOperationInfo getOperationInfo() {
/* 816 */       return FCBAL1000_FW_A.this.info;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract class Srch04
/*     */     extends MCOperation
/*     */   {
/*     */     public static final String OPERATION_ID = "Srch04";
/*     */ 
/*     */ 
/*     */     
/*     */     private final InfoR up0;
/*     */ 
/*     */ 
/*     */     
/*     */     public String getOperationID() {
/* 835 */       return "Srch04";
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected Srch04() {
/* 846 */       this.up0 = InfoR.create();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void mapUpContainers(String key) {
/* 860 */       super.mapUpContainers(key);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void mapDownContainers(String key) {
/* 868 */       super.mapDownContainers(key);
/*     */     }
/*     */     
/*     */     public MCContainer up(int i) {
/* 872 */       if (i == 0) return (MCContainer)up0(); 
/* 873 */       return null;
/*     */     }
/*     */     
/*     */     public MCContainer down(int i) {
/* 877 */       return null;
/*     */     }
/*     */     
/*     */     public void exec() {
/* 881 */       clear();
/* 882 */       MCLogicUtil.invoke((MCLogic)FCBAL1000_FW_A.this);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void clear() {}
/*     */ 
/*     */ 
/*     */     
/*     */     public InfoR createInfoR() {
/* 893 */       return InfoR.create();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public InfoR up0() {
/* 919 */       return this.up0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MCOperationInfo getOperationInfo() {
/* 927 */       return FCBAL1000_FW_A.this.info;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\list\FCBAL1000_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */