/*     */ package mcframe.serverCore.list;
/*     */ 
/*     */ import mcframe.commonCore.param.MCContainerDef;
/*     */ import mcframe.commonCore.param.MCDef;
/*     */ import mcframe.commonCore.param.MCGeneralContainerDef;
/*     */ import mcframe.commonCore.param.MCItemDef;
/*     */ import mcframe.commonCore.param.MCOperationInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PDef_FW_A
/*     */   extends MCDef
/*     */ {
/*     */   public MCContainerDef getCustomDef(String id) {
/*  21 */     if (id == null) {
/*  22 */       return null;
/*     */     }
/*     */     
/*  25 */     if (id.equals("FC.FCBAL1000.Srch01.UP.BLOCK0")) {
/*  26 */       return FC_FCBAL1000_Srch01_UP_BLOCK0();
/*     */     }
/*  28 */     if (id.equals("FC.FCBAL1000.Srch01.UP.BLOCK1")) {
/*  29 */       return FC_FCBAL1000_Srch01_UP_BLOCK1();
/*     */     }
/*  31 */     if (id.equals("FC.FCBAL1000.Srch01.DOWN.BLOCK0")) {
/*  32 */       return FC_FCBAL1000_Srch01_DOWN_BLOCK0();
/*     */     }
/*  34 */     if (id.equals("FC.FCBAL1000.Srch02.UP.BLOCK0")) {
/*  35 */       return FC_FCBAL1000_Srch02_UP_BLOCK0();
/*     */     }
/*  37 */     if (id.equals("FC.FCBAL1000.Srch02.UP.BLOCK1")) {
/*  38 */       return FC_FCBAL1000_Srch02_UP_BLOCK1();
/*     */     }
/*  40 */     if (id.equals("FC.FCBAL1000.Srch02.DOWN.BLOCK0")) {
/*  41 */       return FC_FCBAL1000_Srch02_DOWN_BLOCK0();
/*     */     }
/*  43 */     if (id.equals("FC.FCBAL1000.Srch03.UP.BLOCK0")) {
/*  44 */       return FC_FCBAL1000_Srch03_UP_BLOCK0();
/*     */     }
/*  46 */     if (id.equals("FC.FCBAL1000.Srch04.UP.BLOCK0")) {
/*  47 */       return FC_FCBAL1000_Srch04_UP_BLOCK0();
/*     */     }
/*     */ 
/*     */     
/*  51 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  57 */   static final MCOperationInfo FC_FCBAL1000_Srch01_INFO = new MCOperationInfo("FC", "FCBAL1000", "Srch01", "000000", new PDef());
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBAL1000_Srch01_UP_BLOCK0() {
/*  61 */     return (MCContainerDef)new MCGeneralContainerDef(
/*  62 */         new MCItemDef[] {
/*  63 */           MCItemDef.create("CLASS", "CLASS"), 
/*  64 */           MCItemDef.create("METHOD", "METHOD")
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBAL1000_Srch01_UP_BLOCK1() {
/*  71 */     return (MCContainerDef)new MCGeneralContainerDef(
/*  72 */         new MCItemDef[] {
/*  73 */           MCItemDef.create("ROW_NUM", "ROW_NUM"), 
/*  74 */           MCItemDef.create("STRING_VAL", "STRING_VAL"), 
/*  75 */           MCItemDef.create("NUMBER_VAL", "NUMBER_VAL"), 
/*  76 */           MCItemDef.create("DATE_VAL", "DATE_VAL"), 
/*  77 */           MCItemDef.create("TIMESTAMP_VAL", "TIMESTAMP_VAL"), 
/*  78 */           MCItemDef.create("BOOLEAN_VAL", "BOOLEAN_VAL"), 
/*  79 */           MCItemDef.create("NAME", "NAME"), 
/*  80 */           MCItemDef.create("TYPE", "TYPE")
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBAL1000_Srch01_DOWN_BLOCK0() {
/*  88 */     return (MCContainerDef)new MCGeneralContainerDef(
/*  89 */         new MCItemDef[] {
/*  90 */           MCItemDef.create("ROW_NUM", "ROW_NUM"), 
/*  91 */           MCItemDef.create("STRING_VAL", "STRING_VAL"), 
/*  92 */           MCItemDef.create("NUMBER_VAL", "NUMBER_VAL"), 
/*  93 */           MCItemDef.create("DATE_VAL", "DATE_VAL"), 
/*  94 */           MCItemDef.create("TIMESTAMP_VAL", "TIMESTAMP_VAL"), 
/*  95 */           MCItemDef.create("BOOLEAN_VAL", "BOOLEAN_VAL"), 
/*  96 */           MCItemDef.create("NAME", "NAME"), 
/*  97 */           MCItemDef.create("TYPE", "TYPE")
/*     */         });
/*     */   }
/*     */ 
/*     */   
/* 102 */   static final MCOperationInfo FC_FCBAL1000_Srch02_INFO = new MCOperationInfo("FC", "FCBAL1000", "Srch02", "000000", new PDef());
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBAL1000_Srch02_UP_BLOCK0() {
/* 106 */     return (MCContainerDef)new MCGeneralContainerDef(
/* 107 */         new MCItemDef[] {
/* 108 */           MCItemDef.create("CLASS", "CLASS"), 
/* 109 */           MCItemDef.create("METHOD", "METHOD")
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBAL1000_Srch02_UP_BLOCK1() {
/* 116 */     return (MCContainerDef)new MCGeneralContainerDef(
/* 117 */         new MCItemDef[] {
/* 118 */           MCItemDef.create("ROW_NUM", "ROW_NUM"), 
/* 119 */           MCItemDef.create("STRING_VAL", "STRING_VAL"), 
/* 120 */           MCItemDef.create("NUMBER_VAL", "NUMBER_VAL"), 
/* 121 */           MCItemDef.create("DATE_VAL", "DATE_VAL"), 
/* 122 */           MCItemDef.create("TIMESTAMP_VAL", "TIMESTAMP_VAL"), 
/* 123 */           MCItemDef.create("BOOLEAN_VAL", "BOOLEAN_VAL"), 
/* 124 */           MCItemDef.create("NAME", "NAME"), 
/* 125 */           MCItemDef.create("TYPE", "TYPE")
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBAL1000_Srch02_DOWN_BLOCK0() {
/* 133 */     return (MCContainerDef)new MCGeneralContainerDef(
/* 134 */         new MCItemDef[] {
/* 135 */           MCItemDef.create("ROW_NUM", "ROW_NUM"), 
/* 136 */           MCItemDef.create("STRING_VAL", "STRING_VAL"), 
/* 137 */           MCItemDef.create("NUMBER_VAL", "NUMBER_VAL"), 
/* 138 */           MCItemDef.create("DATE_VAL", "DATE_VAL"), 
/* 139 */           MCItemDef.create("TIMESTAMP_VAL", "TIMESTAMP_VAL"), 
/* 140 */           MCItemDef.create("BOOLEAN_VAL", "BOOLEAN_VAL"), 
/* 141 */           MCItemDef.create("NAME", "NAME"), 
/* 142 */           MCItemDef.create("TYPE", "TYPE")
/*     */         });
/*     */   }
/*     */ 
/*     */   
/* 147 */   static final MCOperationInfo FC_FCBAL1000_Srch03_INFO = new MCOperationInfo("FC", "FCBAL1000", "Srch03", "000000", new PDef());
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBAL1000_Srch03_UP_BLOCK0() {
/* 151 */     return (MCContainerDef)new MCGeneralContainerDef(
/* 152 */         new MCItemDef[] {
/* 153 */           MCItemDef.create("CLASS", "CLASS"), 
/* 154 */           MCItemDef.create("METHOD", "METHOD")
/*     */         });
/*     */   }
/*     */ 
/*     */   
/* 159 */   static final MCOperationInfo FC_FCBAL1000_Srch04_INFO = new MCOperationInfo("FC", "FCBAL1000", "Srch04", "000000", new PDef());
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBAL1000_Srch04_UP_BLOCK0() {
/* 163 */     return (MCContainerDef)new MCGeneralContainerDef(
/* 164 */         new MCItemDef[] {
/* 165 */           MCItemDef.create("CLASS", "CLASS"), 
/* 166 */           MCItemDef.create("METHOD", "METHOD")
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\list\PDef_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */