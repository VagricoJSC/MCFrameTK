/*     */ package mcframe.serverCore.list;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.commonCore.container.MCConstRow;
/*     */ import mcframe.commonCore.container.MCExtMap;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCDate;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.lang.MCTimestamp;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class TypeR_FW_A
/*     */   extends MCConstRow
/*     */ {
/*     */   public static final String $ROW_NUM = "ROW_NUM";
/*     */   public static final String $STRING_VAL = "STRING_VAL";
/*     */   public static final String $NUMBER_VAL = "NUMBER_VAL";
/*     */   public static final String $DATE_VAL = "DATE_VAL";
/*     */   public static final String $TIMESTAMP_VAL = "TIMESTAMP_VAL";
/*     */   public static final String $BOOLEAN_VAL = "BOOLEAN_VAL";
/*     */   public static final String $NAME = "NAME";
/*     */   public static final String $TYPE = "TYPE";
/*  38 */   public static final MCMeta ROW_NUM_META = createStringMeta("ROW_NUM", 1);
/*  39 */   public static final MCMeta STRING_VAL_META = createStringMeta("STRING_VAL", 1);
/*  40 */   public static final MCMeta NUMBER_VAL_META = createNumberMeta("NUMBER_VAL", 1, 0, true);
/*  41 */   public static final MCMeta DATE_VAL_META = createDateMeta("DATE_VAL");
/*  42 */   public static final MCMeta TIMESTAMP_VAL_META = createTimestampMeta("TIMESTAMP_VAL");
/*  43 */   public static final MCMeta BOOLEAN_VAL_META = createBooleanMeta("BOOLEAN_VAL");
/*  44 */   public static final MCMeta NAME_META = createStringMeta("NAME", 1);
/*  45 */   public static final MCMeta TYPE_META = createStringMeta("TYPE", 1);
/*     */   
/*  47 */   protected static final MCRow.ConstMetaList<TypeR> constMetas = new MCRow.ConstMetaList(
/*  48 */       MCConstRow.constMetas, 
/*  49 */       new MCMeta[] {
/*  50 */         ROW_NUM_META, 
/*  51 */         STRING_VAL_META, 
/*  52 */         NUMBER_VAL_META, 
/*  53 */         DATE_VAL_META, 
/*  54 */         TIMESTAMP_VAL_META, 
/*  55 */         BOOLEAN_VAL_META, 
/*  56 */         NAME_META, 
/*  57 */         TYPE_META
/*     */       },
/*  59 */       new String[][] { {}, {} });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   protected static final MCExtMap EXTMAP = new MCExtMap(
/*  72 */       null, new MCExtMap.Entry[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] colnames() {
/*  84 */     return constMetas.toNameArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMeta[] colmetas() {
/*  96 */     return constMetas.toMetaArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   private static final int offset = constMetas.offset();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getExtMap(String aGroup) {
/* 108 */     if (aGroup == null) return null; 
/* 109 */     return (Map<String, String>)EXTMAP.get(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getKeys(String aGroup) {
/* 116 */     if (aGroup == null) return null; 
/* 117 */     return EXTMAP.getKeyList(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExtGroups() {
/* 124 */     Set<String> ret = EXTMAP.keySet();
/* 125 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected TypeR_FW_A(MCRow.ConstMetaList<? extends TypeR> metas) {
/* 132 */     super(metas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeR clone() {
/* 139 */     return (TypeR)super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeR createInstance() {
/* 146 */     return (TypeR)super.createInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeR getValues(String... names) {
/* 153 */     return (TypeR)super.getValues(names);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireValueChanged(String column, Comparable<?> newvalue, Comparable<?> oldvalue) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String ROW_NUM() {
/* 165 */     return getConstString(offset + 0, "ROW_NUM");
/*     */   }
/*     */   
/*     */   public void ROW_NUM(String value) {
/* 169 */     setConstString(offset + 0, "ROW_NUM", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String STRING_VAL() {
/* 174 */     return getConstString(offset + 1, "STRING_VAL");
/*     */   }
/*     */   
/*     */   public void STRING_VAL(String value) {
/* 178 */     setConstString(offset + 1, "STRING_VAL", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCNumber NUMBER_VAL() {
/* 183 */     return getConstNumber(offset + 2, "NUMBER_VAL");
/*     */   }
/*     */   
/*     */   public void NUMBER_VAL(MCNumber value) {
/* 187 */     setConstNumber(offset + 2, "NUMBER_VAL", value);
/*     */   }
/*     */   
/*     */   public void NUMBER_VAL(int value) {
/* 191 */     setConstNumber(offset + 2, "NUMBER_VAL", value);
/*     */   }
/*     */   
/*     */   public void NUMBER_VAL(long value) {
/* 195 */     setConstNumber(offset + 2, "NUMBER_VAL", value);
/*     */   }
/*     */   
/*     */   public void NUMBER_VAL(float value) {
/* 199 */     setConstNumber(offset + 2, "NUMBER_VAL", value);
/*     */   }
/*     */   
/*     */   public void NUMBER_VAL(double value) {
/* 203 */     setConstNumber(offset + 2, "NUMBER_VAL", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCDate DATE_VAL() {
/* 208 */     return getConstDate(offset + 3, "DATE_VAL");
/*     */   }
/*     */   
/*     */   public void DATE_VAL(MCDate value) {
/* 212 */     setConstDate(offset + 3, "DATE_VAL", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCTimestamp TIMESTAMP_VAL() {
/* 217 */     return getConstTimestamp(offset + 4, "TIMESTAMP_VAL");
/*     */   }
/*     */   
/*     */   public void TIMESTAMP_VAL(MCTimestamp value) {
/* 221 */     setConstTimestamp(offset + 4, "TIMESTAMP_VAL", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean BOOLEAN_VAL() {
/* 226 */     return getConstBoolean(offset + 5, "BOOLEAN_VAL");
/*     */   }
/*     */   
/*     */   public void BOOLEAN_VAL(boolean value) {
/* 230 */     setConstBoolean(offset + 5, "BOOLEAN_VAL", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String NAME() {
/* 235 */     return getConstString(offset + 6, "NAME");
/*     */   }
/*     */   
/*     */   public void NAME(String value) {
/* 239 */     setConstString(offset + 6, "NAME", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String TYPE() {
/* 244 */     return getConstString(offset + 7, "TYPE");
/*     */   }
/*     */   
/*     */   public void TYPE(String value) {
/* 248 */     setConstString(offset + 7, "TYPE", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString(String name) {
/* 253 */     if ("ROW_NUM".equalsIgnoreCase(name)) {
/* 254 */       return ROW_NUM();
/*     */     }
/* 256 */     if ("STRING_VAL".equalsIgnoreCase(name)) {
/* 257 */       return STRING_VAL();
/*     */     }
/* 259 */     if ("NAME".equalsIgnoreCase(name)) {
/* 260 */       return NAME();
/*     */     }
/* 262 */     if ("TYPE".equalsIgnoreCase(name)) {
/* 263 */       return TYPE();
/*     */     }
/* 265 */     return super.getString(name);
/*     */   }
/*     */   public MCNumber getNumber(String name) {
/* 268 */     if ("NUMBER_VAL".equalsIgnoreCase(name)) {
/* 269 */       return NUMBER_VAL();
/*     */     }
/* 271 */     return super.getNumber(name);
/*     */   }
/*     */   public MCDate getDate(String name) {
/* 274 */     if ("DATE_VAL".equalsIgnoreCase(name)) {
/* 275 */       return DATE_VAL();
/*     */     }
/* 277 */     return super.getDate(name);
/*     */   }
/*     */   public MCTimestamp getTimestamp(String name) {
/* 280 */     if ("TIMESTAMP_VAL".equalsIgnoreCase(name)) {
/* 281 */       return TIMESTAMP_VAL();
/*     */     }
/* 283 */     return super.getTimestamp(name);
/*     */   }
/*     */   public boolean getBoolean(String name) {
/* 286 */     if ("BOOLEAN_VAL".equalsIgnoreCase(name)) {
/* 287 */       return BOOLEAN_VAL();
/*     */     }
/* 289 */     return super.getBoolean(name);
/*     */   }
/*     */   
/*     */   public String getStringNE(String name) {
/* 293 */     if ("ROW_NUM".equalsIgnoreCase(name)) {
/* 294 */       return ROW_NUM();
/*     */     }
/* 296 */     if ("STRING_VAL".equalsIgnoreCase(name)) {
/* 297 */       return STRING_VAL();
/*     */     }
/* 299 */     if ("NAME".equalsIgnoreCase(name)) {
/* 300 */       return NAME();
/*     */     }
/* 302 */     if ("TYPE".equalsIgnoreCase(name)) {
/* 303 */       return TYPE();
/*     */     }
/* 305 */     return super.getStringNE(name);
/*     */   }
/*     */   public MCNumber getNumberNE(String name) {
/* 308 */     if ("NUMBER_VAL".equalsIgnoreCase(name)) {
/* 309 */       return NUMBER_VAL();
/*     */     }
/* 311 */     return super.getNumberNE(name);
/*     */   }
/*     */   public MCDate getDateNE(String name) {
/* 314 */     if ("DATE_VAL".equalsIgnoreCase(name)) {
/* 315 */       return DATE_VAL();
/*     */     }
/* 317 */     return super.getDateNE(name);
/*     */   }
/*     */   public MCTimestamp getTimestampNE(String name) {
/* 320 */     if ("TIMESTAMP_VAL".equalsIgnoreCase(name)) {
/* 321 */       return TIMESTAMP_VAL();
/*     */     }
/* 323 */     return super.getTimestampNE(name);
/*     */   }
/*     */   public boolean getBooleanNE(String name) {
/* 326 */     if ("BOOLEAN_VAL".equalsIgnoreCase(name)) {
/* 327 */       return BOOLEAN_VAL();
/*     */     }
/* 329 */     return super.getBooleanNE(name);
/*     */   }
/*     */   
/*     */   public void setString(String name, String value) {
/* 333 */     if ("ROW_NUM".equalsIgnoreCase(name)) {
/* 334 */       ROW_NUM(value);
/*     */       return;
/*     */     } 
/* 337 */     if ("STRING_VAL".equalsIgnoreCase(name)) {
/* 338 */       STRING_VAL(value);
/*     */       return;
/*     */     } 
/* 341 */     if ("NAME".equalsIgnoreCase(name)) {
/* 342 */       NAME(value);
/*     */       return;
/*     */     } 
/* 345 */     if ("TYPE".equalsIgnoreCase(name)) {
/* 346 */       TYPE(value);
/*     */       return;
/*     */     } 
/* 349 */     super.setString(name, value);
/*     */   }
/*     */   public void setNumber(String name, MCNumber value) {
/* 352 */     if ("NUMBER_VAL".equalsIgnoreCase(name)) {
/* 353 */       NUMBER_VAL(value);
/*     */       return;
/*     */     } 
/* 356 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, int value) {
/* 359 */     if ("NUMBER_VAL".equalsIgnoreCase(name)) {
/* 360 */       NUMBER_VAL(value);
/*     */       return;
/*     */     } 
/* 363 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, long value) {
/* 366 */     if ("NUMBER_VAL".equalsIgnoreCase(name)) {
/* 367 */       NUMBER_VAL(value);
/*     */       return;
/*     */     } 
/* 370 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, float value) {
/* 373 */     if ("NUMBER_VAL".equalsIgnoreCase(name)) {
/* 374 */       NUMBER_VAL(value);
/*     */       return;
/*     */     } 
/* 377 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, double value) {
/* 380 */     if ("NUMBER_VAL".equalsIgnoreCase(name)) {
/* 381 */       NUMBER_VAL(value);
/*     */       return;
/*     */     } 
/* 384 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setDate(String name, MCDate value) {
/* 387 */     if ("DATE_VAL".equalsIgnoreCase(name)) {
/* 388 */       DATE_VAL(value);
/*     */       return;
/*     */     } 
/* 391 */     super.setDate(name, value);
/*     */   }
/*     */   public void setTimestamp(String name, MCTimestamp value) {
/* 394 */     if ("TIMESTAMP_VAL".equalsIgnoreCase(name)) {
/* 395 */       TIMESTAMP_VAL(value);
/*     */       return;
/*     */     } 
/* 398 */     super.setTimestamp(name, value);
/*     */   }
/*     */   public void setBoolean(String name, boolean value) {
/* 401 */     if ("BOOLEAN_VAL".equalsIgnoreCase(name)) {
/* 402 */       BOOLEAN_VAL(value);
/*     */       return;
/*     */     } 
/* 405 */     super.setBoolean(name, value);
/*     */   }
/*     */   
/*     */   public void setStringNE(String name, String value) {
/* 409 */     if ("ROW_NUM".equalsIgnoreCase(name)) {
/* 410 */       ROW_NUM(value);
/*     */       return;
/*     */     } 
/* 413 */     if ("STRING_VAL".equalsIgnoreCase(name)) {
/* 414 */       STRING_VAL(value);
/*     */       return;
/*     */     } 
/* 417 */     if ("NAME".equalsIgnoreCase(name)) {
/* 418 */       NAME(value);
/*     */       return;
/*     */     } 
/* 421 */     if ("TYPE".equalsIgnoreCase(name)) {
/* 422 */       TYPE(value);
/*     */       return;
/*     */     } 
/* 425 */     super.setStringNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, MCNumber value) {
/* 428 */     if ("NUMBER_VAL".equalsIgnoreCase(name)) {
/* 429 */       NUMBER_VAL(value);
/*     */       return;
/*     */     } 
/* 432 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, int value) {
/* 435 */     if ("NUMBER_VAL".equalsIgnoreCase(name)) {
/* 436 */       NUMBER_VAL(value);
/*     */       return;
/*     */     } 
/* 439 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, long value) {
/* 442 */     if ("NUMBER_VAL".equalsIgnoreCase(name)) {
/* 443 */       NUMBER_VAL(value);
/*     */       return;
/*     */     } 
/* 446 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, float value) {
/* 449 */     if ("NUMBER_VAL".equalsIgnoreCase(name)) {
/* 450 */       NUMBER_VAL(value);
/*     */       return;
/*     */     } 
/* 453 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, double value) {
/* 456 */     if ("NUMBER_VAL".equalsIgnoreCase(name)) {
/* 457 */       NUMBER_VAL(value);
/*     */       return;
/*     */     } 
/* 460 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setDateNE(String name, MCDate value) {
/* 463 */     if ("DATE_VAL".equalsIgnoreCase(name)) {
/* 464 */       DATE_VAL(value);
/*     */       return;
/*     */     } 
/* 467 */     super.setDateNE(name, value);
/*     */   }
/*     */   public void setTimestampNE(String name, MCTimestamp value) {
/* 470 */     if ("TIMESTAMP_VAL".equalsIgnoreCase(name)) {
/* 471 */       TIMESTAMP_VAL(value);
/*     */       return;
/*     */     } 
/* 474 */     super.setTimestampNE(name, value);
/*     */   }
/*     */   public void setBooleanNE(String name, boolean value) {
/* 477 */     if ("BOOLEAN_VAL".equalsIgnoreCase(name)) {
/* 478 */       BOOLEAN_VAL(value);
/*     */       return;
/*     */     } 
/* 481 */     super.setBooleanNE(name, value);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\list\TypeR_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */