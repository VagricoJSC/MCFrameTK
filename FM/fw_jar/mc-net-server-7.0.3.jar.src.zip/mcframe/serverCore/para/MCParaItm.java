/*    */ package mcframe.serverCore.para;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MCParaItm
/*    */ {
/*    */   final String reqNo;
/*    */   final MCParaConfig conf;
/*    */   
/*    */   MCParaItm(String reqNo, MCParaConfig conf) {
/* 42 */     this.reqNo = reqNo;
/* 43 */     this.conf = conf;
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\para\MCParaItm.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */