/*    */ package mcframe.serverCore.para;
/*    */ 
/*    */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*    */ import mcframe.commonCore.notice.MCException;
/*    */ import mcframe.commonCore.notice.MCLog;
/*    */ import mcframe.commonCore.param.MCParam;
/*    */ import mcframe.serverCore.phase.MCPhase;
/*    */ import mcframe.serverCore.resource.MCConfig;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCParaOpeCtrl
/*    */   implements MCPhase
/*    */ {
/* 27 */   protected static final MCParaQueue queue = MCParaQueue.createParaQueue();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private MCParaConfig _para_config;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void invoke(MCParam p) {
/* 48 */     int retry = 0;
/* 49 */     int interval = 0;
/*    */     try {
/* 51 */       retry = MCConfig.server.getInteger("process.parallel.retry", 0);
/* 52 */       interval = MCConfig.server.getInteger("process.parallel.interval", 0);
/*    */     }
/* 54 */     catch (MCException e) {
/*    */       
/* 56 */       MCLog.write(Core_Msg_FW_A.FCBGC0316, new Object[] { e.getMCMessage().toString() });
/*    */     } 
/*    */ 
/*    */     
/* 60 */     MCLog.write(Core_Msg_FW_A.FCBGC0306, new Object[] { Integer.valueOf(retry), Integer.valueOf(interval) });
/*    */     
/* 62 */     MCParaConfig conf = queue.createParaConfig(p);
/* 63 */     String req_id = p.getServerRequestNo();
/*    */     
/* 65 */     queue.offer(conf, req_id);
/* 66 */     queue.queue(retry, interval, conf, req_id);
/*    */     
/* 68 */     this._para_config = conf;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void destroy(MCParam p) {
/* 81 */     if (this._para_config == null) {
/* 82 */       this._para_config = queue.createParaConfig(p);
/*    */     }
/* 84 */     String req_no = p.getServerRequestNo();
/* 85 */     queue.remove(this._para_config, req_no);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\para\MCParaOpeCtrl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */