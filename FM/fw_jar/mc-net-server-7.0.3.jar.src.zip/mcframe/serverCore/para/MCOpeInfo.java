/*     */ package mcframe.serverCore.para;
/*     */ 
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCOpeInfo
/*     */ {
/*  23 */   private static Set<String> EXCEPT_OPE_IDS = new HashSet<>();
/*     */   static {
/*  25 */     EXCEPT_OPE_IDS.add(crtOpeId("FS", "FSBGL0010", "*"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  35 */   private static final int NULL_HASH_CODE = "".hashCode();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final String ope_id;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final String co_cd;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final String ext_attr1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final String ext_attr2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final String ext_attr3;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean man_flg;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  98 */   static final MCOpeInfo ANONIMOUS_MAN_OPE = new MCOpeInfo("*", null, null, null, null, 
/*  99 */       true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int hashcode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 117 */   private String tostringtxt = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCOpeInfo(String moduleId, String logicId, String operationId, String co_cd, String ext_attr1, String ext_attr2, String ext_attr3) {
/* 135 */     this(moduleId, logicId, operationId, co_cd, ext_attr1, ext_attr2, ext_attr3, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCOpeInfo(String ope_id, String co_cd, String ext_attr1, String ext_attr2, String ext_attr3) {
/* 151 */     this(ope_id, co_cd, ext_attr1, ext_attr2, ext_attr3, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCOpeInfo(String moduleId, String logicId, String operationId, String co_cd, String ext_attr1, String ext_attr2, String ext_attr3, boolean man_flg) {
/* 170 */     this.ope_id = crtOpeId(moduleId, logicId, operationId);
/* 171 */     this.co_cd = co_cd;
/* 172 */     this.ext_attr1 = ext_attr1;
/* 173 */     this.ext_attr2 = ext_attr2;
/* 174 */     this.ext_attr3 = ext_attr3;
/* 175 */     this.man_flg = man_flg;
/*     */     
/* 177 */     this.hashcode = (String.valueOf(this.ope_id) + this.co_cd + this.ext_attr1 + this.ext_attr2 + this.ext_attr3)
/* 178 */       .hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCOpeInfo(String ope_id, String co_cd, String ext_attr1, String ext_attr2, String ext_attr3, boolean man_flg) {
/* 195 */     this.ope_id = ope_id;
/* 196 */     this.co_cd = co_cd;
/* 197 */     this.ext_attr1 = ext_attr1;
/* 198 */     this.ext_attr2 = ext_attr2;
/* 199 */     this.ext_attr3 = ext_attr3;
/* 200 */     this.man_flg = man_flg;
/*     */ 
/*     */     
/* 203 */     this.hashcode = (String.valueOf(this.ope_id) + this.co_cd + this.ext_attr1 + this.ext_attr2 + this.ext_attr3)
/* 204 */       .hashCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String crtOpeId(String moduleId, String logicId, String operationId) {
/* 218 */     return String.valueOf(moduleId) + "." + logicId + "." + operationId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 234 */     if (o == null || this.ope_id == null) {
/* 235 */       return false;
/*     */     }
/* 237 */     if (this == o) {
/* 238 */       return true;
/*     */     }
/* 240 */     if (o instanceof MCOpeInfo) {
/* 241 */       MCOpeInfo ope = (MCOpeInfo)o;
/* 242 */       if (this.ope_id.equals(ope.ope_id) && (
/* 243 */         this.co_cd == ope.co_cd || this.co_cd.equals(ope.co_cd)) && (
/* 244 */         this.ext_attr1 == ope.ext_attr1 || this.ext_attr1.equals(ope.ext_attr1)) && (
/* 245 */         this.ext_attr2 == ope.ext_attr2 || this.ext_attr2.equals(ope.ext_attr2)) && (
/* 246 */         this.ext_attr3 == ope.ext_attr3 || this.ext_attr3.equals(ope.ext_attr3))) {
/* 247 */         return true;
/*     */       }
/*     */     } 
/* 250 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 263 */     return this.hashcode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 276 */     if (this.tostringtxt == null) {
/* 277 */       this.tostringtxt = String.valueOf(this.ope_id) + "." + this.co_cd + "." + this.ext_attr1 + "." + this.ext_attr2 + "." + 
/* 278 */         this.ext_attr3;
/*     */     }
/* 280 */     return this.tostringtxt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean exceptTar() {
/* 292 */     for (String except_id : EXCEPT_OPE_IDS) {
/* 293 */       String[] tmp = MCStringUtil.match(except_id, new String[] {
/* 294 */             this.ope_id
/* 295 */           }, '.');
/* 296 */       if (tmp.length == 1) {
/* 297 */         return true;
/*     */       }
/*     */     } 
/* 300 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\para\MCOpeInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */