/*     */ package mcframe.serverCore.para;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.serverCore.dbc.FCM_PARA_OPE_CTRL_R;
/*     */ import mcframe.serverCore.dbc.FCM_PARA_OPE_GRP_ITM_R;
/*     */ import mcframe.serverCore.dbc.FCM_PARA_OPE_GRP_R;
/*     */ import mcframe.serverCore.dbc.FCT_EXCLD_GRPS_R;
/*     */ import mcframe.serverCore.dbc.FCT_RUNNING_GRPS_R;
/*     */ import mcframe.serverCore.mcjdbc.MCLockTableMode;
/*     */ import mcframe.serverCore.mcjdbc.MCSavepoint;
/*     */ import mcframe.serverCore.mcjdbc.MCTransactionManager;
/*     */ import mcframe.serverCore.queryapi.IFMCFMSQL;
/*     */ import mcframe.serverCore.queryapi.IFMCSQL;
/*     */ import mcframe.serverCore.queryapi.MCDBContainer;
/*     */ import mcframe.serverCore.queryapi.MCQueryApiBuilder;
/*     */ import mcframe.serverCore.resource.MCConfig;
/*     */ import mcframe.serverCore.sys.MCSys;
/*     */ import mcframe.serverCore.util.MCDBUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCParaQueue
/*     */ {
/*  94 */   private static final MCParaQueue _obj = new MCParaQueue();
/*     */ 
/*     */   
/*     */   private MCList<FCM_PARA_OPE_GRP_ITM_R> c_itms;
/*     */   
/*     */   private MCList<FCM_PARA_OPE_GRP_R> c_grps;
/*     */   
/*     */   private MCList<FCM_PARA_OPE_CTRL_R> c_pairs;
/*     */   
/* 103 */   private Map<MCOpeInfo, MCParaConfig> cache = new HashMap<>();
/* 104 */   private Map<MCOpeInfo, LinkedList<MCParaItm>> opeQueue = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCParaQueue createParaQueue() {
/* 115 */     return _obj;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void offer(MCParaConfig conf, String req_no) {
/*     */     LinkedList<MCParaItm> queue;
/* 128 */     MCParaItm itm = new MCParaItm(req_no, conf);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 133 */     synchronized (this.opeQueue) {
/* 134 */       if ((queue = this.opeQueue.get(conf.ope)) == null) {
/* 135 */         queue = new LinkedList<>();
/* 136 */         this.opeQueue.put(conf.ope, queue);
/*     */       } 
/*     */     } 
/*     */     
/* 140 */     synchronized (queue) {
/* 141 */       queue.offer(itm);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void queue(int retry, int interval, MCParaConfig conf, String req_no) {
/* 158 */     int waitSum = 0;
/* 159 */     int retrySum = 0;
/*     */     try {
/* 161 */       while (!confirm(conf.ope, req_no)) {
/* 162 */         Thread.sleep(interval);
/* 163 */         waitSum += interval;
/* 164 */         if (retry <= retrySum)
/*     */         {
/* 166 */           throw new MCException(Core_Msg_FW_A.FCBGC0058, new Object[] { Integer.valueOf(waitSum), Integer.valueOf(retrySum) });
/*     */         }
/* 168 */         retrySum++;
/*     */       }
/*     */     
/* 171 */     } catch (MCException e) {
/* 172 */       throw e;
/*     */     }
/* 174 */     catch (Exception e) {
/*     */       
/* 176 */       MCLog.write(Core_Msg_FW_A.FCBGC0309, new Object[0]);
/* 177 */       throw new MCException(e, Core_Msg_FW_A.FCBGC0057, new Object[0]);
/*     */     } finally {
/*     */       
/* 180 */       removeQueue(conf.ope, req_no);
/*     */     } 
/*     */     
/* 183 */     MCLog.write(Core_Msg_FW_A.FCBGC0308, new Object[] { Integer.valueOf(waitSum), Integer.valueOf(retrySum) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(MCParaConfig conf, String req_no) {
/* 196 */     if (conf.ope != MCOpeInfo.ANONIMOUS_MAN_OPE && (
/* 197 */       conf.mygrps.size() == 0 || conf.exgrps.size() == 0)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 202 */     FCT_EXCLD_GRPS_R egDbc = FCT_EXCLD_GRPS_R.create("T");
/* 203 */     IFMCSQL.MCPredicate egWhere = egDbc.req_no.eq(IFMCSQL.bind("1")).and(egDbc.man_flg.eq(IFMCSQL.bind("2")));
/* 204 */     MCDBUtil.execDbDelete("FC_MCParaQueue_remove_1", (MCDBContainer)egDbc, egWhere, new Comparable[] { req_no, Boolean.valueOf(conf.ope.man_flg) });
/* 205 */     FCT_RUNNING_GRPS_R rgDbc = FCT_RUNNING_GRPS_R.create("T");
/* 206 */     IFMCSQL.MCPredicate rgWhere = rgDbc.req_no.eq(IFMCSQL.bind("1")).and(rgDbc.man_flg.eq(IFMCSQL.bind("2")));
/* 207 */     MCDBUtil.execDbDelete("FC_MCParaQueue_remove_2", (MCDBContainer)rgDbc, rgWhere, new Comparable[] { req_no, Boolean.valueOf(conf.ope.man_flg) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCParaConfig createParaConfig(String moduleId, String logicId, String operationId, String co_cd, String ext_attr1, String ext_attr2, String ext_attr3) {
/* 227 */     MCOpeInfo info = new MCOpeInfo(moduleId, logicId, operationId, co_cd, ext_attr1, 
/* 228 */         ext_attr2, ext_attr3);
/* 229 */     return getConf(info);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCParaConfig createParaConfig(MCParam p) {
/* 241 */     return createParaConfig(p.getModuleId(), p.getLogicId(), p.getOperationId(), 
/* 242 */         MCSys.user.coCD(), MCSys.user.extattr1(), MCSys.user.extattr2(), 
/* 243 */         MCSys.user.extattr3());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCParaConfig createManParaConfig(String ope_id, String co_cd, String ext_attr1, String ext_attr2, String ext_attr3) {
/* 260 */     MCOpeInfo info = new MCOpeInfo(ope_id, co_cd, ext_attr1, ext_attr2, ext_attr3, 
/* 261 */         true);
/* 262 */     return getConf(info);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCParaConfig createManParaConfig(MCNumber gid) {
/* 274 */     MCParaConfig conf = new MCParaConfig(MCOpeInfo.ANONIMOUS_MAN_OPE);
/* 275 */     readDB(conf, gid);
/* 276 */     return conf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCParaConfig createManParaConfig() {
/* 287 */     return new MCParaConfig(MCOpeInfo.ANONIMOUS_MAN_OPE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCParaConfig getConf(MCOpeInfo ope) {
/* 299 */     MCParaConfig conf = new MCParaConfig(ope);
/* 300 */     if (isCache()) {
/* 301 */       MCParaConfig cacheConf = this.cache.get(ope);
/* 302 */       if (cacheConf == null) {
/* 303 */         readDB(conf);
/* 304 */         this.cache.put(ope, conf);
/*     */       } else {
/*     */         
/* 307 */         copyCache(conf, cacheConf);
/*     */       } 
/*     */     } else {
/*     */       
/* 311 */       readDB(conf);
/*     */     } 
/* 313 */     return conf;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void copyCache(MCParaConfig conf, MCParaConfig cacheConf) {
/* 325 */     conf.exgrps.addAll(cacheConf.exgrps);
/* 326 */     conf.mygrps.addAll(cacheConf.mygrps);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean confirm(MCOpeInfo ope, String req_no) {
/* 339 */     MCParaItm head = getHead(ope);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 346 */     if (ope.exceptTar() || head.conf.mygrps.size() == 0) {
/* 347 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 351 */     if (!isHead(head, req_no)) {
/* 352 */       return false;
/*     */     }
/*     */     
/* 355 */     MCSavepoint s = null;
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 360 */       if (ope.man_flg) {
/* 361 */         MCTransactionManager.createDBTran();
/*     */       }
/*     */       else {
/*     */         
/* 365 */         s = MCTransactionManager.dbTran().setSavepoint();
/*     */       } 
/*     */       
/* 368 */       if (checkExcluded(head)) {
/*     */ 
/*     */ 
/*     */         
/* 372 */         if (head.conf.exgrps.size() != 0) {
/* 373 */           insOpe(head);
/*     */         }
/*     */         
/* 376 */         MCTransactionManager.dbTran().commit();
/* 377 */         return true;
/*     */       } 
/*     */       
/* 380 */       if (s != null) {
/* 381 */         MCTransactionManager.dbTran().rollback(s);
/*     */       }
/* 383 */       return false;
/*     */     
/*     */     }
/* 386 */     catch (MCException e) {
/*     */       
/* 388 */       throw e;
/*     */     } finally {
/*     */       
/* 391 */       if (ope.man_flg) {
/* 392 */         MCTransactionManager.releaseDBTran(MCTransactionManager.dbTran());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean checkExcluded(MCParaItm head) {
/*     */     try {
/* 408 */       MCLockTableMode mode = islockStrictly() ? MCLockTableMode.SRX : 
/* 409 */         MCLockTableMode.S;
/* 410 */       MCTransactionManager.dbTran().statement().lockTable("FCT_EXCLD_GRPS", mode, true);
/*     */     }
/* 412 */     catch (MCException e) {
/* 413 */       if (e.getID().equals(Core_Msg_FW_A.FCBCC0110)) {
/* 414 */         return false;
/*     */       }
/* 416 */       throw e;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 421 */     return !isExcluded(head);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean islockStrictly() {
/* 439 */     return MCConfig.server.getBoolean("process.parallel.tblsrx", false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCParaItm getHead(MCOpeInfo ope) {
/* 451 */     LinkedList<MCParaItm> l = this.opeQueue.get(ope);
/* 452 */     return (l.size() > 0) ? l.get(0) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isHead(MCParaItm itm, String req_no) {
/* 465 */     return itm.reqNo.equals(req_no);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isExcluded(MCParaItm itm) {
/* 477 */     MCList<FCT_EXCLD_GRPS_R> ls = MCList.create(FCT_EXCLD_GRPS_R.class);
/* 478 */     FCT_EXCLD_GRPS_R dbc = FCT_EXCLD_GRPS_R.create("T");
/* 479 */     MCQueryApiBuilder builder = MCQueryApiBuilder.create((MCDBContainer)dbc);
/* 480 */     builder.setSelect(new IFMCSQL.MCColumn[] { (IFMCSQL.MCColumn)dbc.gid });
/* 481 */     builder.setWhere(IFMCSQL.value(0).eq(IFMCSQL.value(1)), new Comparable[0]);
/* 482 */     for (MCNumber s : itm.conf.mygrps) {
/* 483 */       builder.addWhereWithOr(dbc.gid.eq(IFMCSQL.bind("1")), new Comparable[] { (Comparable)s });
/*     */     } 
/*     */     
/* 486 */     return (MCDBUtil.dbSelect("FC_MCParaQueue_isExcluded", ls, builder) > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void insOpe(MCParaItm itm) {
/* 497 */     MCList<FCT_EXCLD_GRPS_R> ex = MCList.create(FCT_EXCLD_GRPS_R.class);
/* 498 */     for (MCNumber s : itm.conf.exgrps) {
/* 499 */       FCT_EXCLD_GRPS_R r = FCT_EXCLD_GRPS_R.create();
/* 500 */       r.gid(s);
/* 501 */       r.ope_id(itm.conf.ope.ope_id);
/* 502 */       r.req_no(itm.reqNo);
/* 503 */       r.man_flg(itm.conf.ope.man_flg);
/* 504 */       ex.add((MCRow)r);
/*     */     } 
/* 506 */     MCList<FCT_RUNNING_GRPS_R> rn = MCList.create(FCT_RUNNING_GRPS_R.class);
/* 507 */     for (MCNumber s : itm.conf.mygrps) {
/* 508 */       FCT_RUNNING_GRPS_R r = FCT_RUNNING_GRPS_R.create();
/* 509 */       r.gid(s);
/* 510 */       r.ope_id(itm.conf.ope.ope_id);
/* 511 */       r.req_no(itm.reqNo);
/* 512 */       r.man_flg(itm.conf.ope.man_flg);
/* 513 */       rn.add((MCRow)r);
/*     */     } 
/* 515 */     FCT_EXCLD_GRPS_R exDbc = FCT_EXCLD_GRPS_R.create("T");
/* 516 */     MCQueryApiBuilder exBuilder = MCQueryApiBuilder.create((MCDBContainer)exDbc);
/* 517 */     MCDBUtil.dbInsert("FC_MCParaQueue_insOpe_1", ex, exBuilder);
/* 518 */     FCT_RUNNING_GRPS_R rnDbc = FCT_RUNNING_GRPS_R.create("T");
/* 519 */     MCQueryApiBuilder rnBuilder = MCQueryApiBuilder.create((MCDBContainer)rnDbc);
/* 520 */     MCDBUtil.dbInsert("FC_MCParaQueue_insOpe_2", rn, rnBuilder);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void removeQueue(MCOpeInfo ope, String req_no) {
/* 530 */     LinkedList<MCParaItm> queue = this.opeQueue.get(ope);
/* 531 */     if (queue == null) {
/*     */       return;
/*     */     }
/* 534 */     LinkedList<MCParaItm> del = new LinkedList<>();
/*     */     
/* 536 */     synchronized (queue) {
/* 537 */       for (MCParaItm itm : queue) {
/*     */ 
/*     */         
/* 540 */         String itm_req_no = itm.reqNo;
/* 541 */         if (itm_req_no.equals(req_no)) {
/* 542 */           del.add(itm);
/*     */         }
/*     */       } 
/* 545 */       queue.removeAll(del);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readDB(MCParaConfig conf) {
/* 558 */     refresh();
/*     */ 
/*     */     
/* 561 */     Set<MCNumber> g1 = new HashSet<>();
/* 562 */     for (FCM_PARA_OPE_GRP_ITM_R r : getGrpItm(conf)) {
/* 563 */       g1.add(r.gid());
/*     */     }
/* 565 */     if (g1.size() == 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 570 */     Set<MCNumber> mygrps = new HashSet<>();
/* 571 */     for (FCM_PARA_OPE_GRP_R r : getGrp(conf, g1.<MCNumber>toArray(new MCNumber[0]))) {
/* 572 */       mygrps.add(r.gid());
/*     */     }
/* 574 */     if (mygrps.size() == 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 579 */     Set<MCNumber> exgrps = new HashSet<>();
/* 580 */     for (FCM_PARA_OPE_CTRL_R r : getCtrl(mygrps.<MCNumber>toArray(new MCNumber[0]))) {
/* 581 */       exgrps.add(r.gid2());
/*     */     }
/*     */ 
/*     */     
/* 585 */     conf.mygrps.addAll(mygrps);
/* 586 */     conf.exgrps.addAll(exgrps);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readDB(MCParaConfig conf, MCNumber mygrp) {
/* 598 */     refresh();
/*     */ 
/*     */     
/* 601 */     Set<MCNumber> exgrps = new HashSet<>();
/* 602 */     for (FCM_PARA_OPE_CTRL_R r : getCtrl(new MCNumber[] { mygrp })) {
/* 603 */       exgrps.add(r.gid2());
/*     */     }
/*     */ 
/*     */     
/* 607 */     conf.mygrps.add(mygrp);
/* 608 */     conf.exgrps.addAll(exgrps);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized void refresh() {
/* 620 */     if (this.c_pairs == null || this.c_grps == null || this.c_itms == null || !isCache()) {
/* 621 */       this.cache.clear();
/* 622 */       this.c_pairs = null;
/* 623 */       this.c_grps = null;
/* 624 */       this.c_itms = null;
/* 625 */       if (isCache()) {
/*     */         
/* 627 */         this.c_pairs = MCList.create(FCM_PARA_OPE_CTRL_R.class);
/* 628 */         FCM_PARA_OPE_CTRL_R poc = FCM_PARA_OPE_CTRL_R.create("M");
/* 629 */         ((IFMCSQL.MCMainQuery)IFMCSQL.sql("FC_MCParaQueue_refresh_1")
/* 630 */           .mainQuery()
/* 631 */           .select((IFMCFMSQL.MCFMEDColumnGroup[])poc.getBaseColumns$())
/* 632 */           .from((IFMCSQL.MCDerivedView)poc))
/* 633 */           .executeQuery(this.c_pairs);
/* 634 */         this.c_grps = MCList.create(FCM_PARA_OPE_GRP_R.class);
/* 635 */         FCM_PARA_OPE_GRP_R pog = FCM_PARA_OPE_GRP_R.create("M");
/* 636 */         ((IFMCSQL.MCMainQuery)IFMCSQL.sql("FC_MCParaQueue_refresh_2")
/* 637 */           .mainQuery()
/* 638 */           .select((IFMCFMSQL.MCFMEDColumnGroup[])pog.getBaseColumns$())
/* 639 */           .from((IFMCSQL.MCDerivedView)pog))
/* 640 */           .executeQuery(this.c_grps);
/* 641 */         this.c_itms = MCList.create(FCM_PARA_OPE_GRP_ITM_R.class);
/* 642 */         FCM_PARA_OPE_GRP_ITM_R pogi = FCM_PARA_OPE_GRP_ITM_R.create("M");
/* 643 */         ((IFMCSQL.MCMainQuery)IFMCSQL.sql("FC_MCParaQueue_refresh_3")
/* 644 */           .mainQuery()
/* 645 */           .select((IFMCFMSQL.MCFMEDColumnGroup[])pogi.getBaseColumns$())
/* 646 */           .from((IFMCSQL.MCDerivedView)pogi))
/* 647 */           .executeQuery(this.c_itms);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized MCList<FCM_PARA_OPE_CTRL_R> getCtrl(MCNumber... gids) {
/* 662 */     if (isCache()) {
/*     */       
/* 664 */       MCList<FCM_PARA_OPE_CTRL_R> l = this.c_pairs.createInstance();
/* 665 */       for (FCM_PARA_OPE_CTRL_R o : this.c_pairs) {
/* 666 */         byte b1; int j; MCNumber[] arrayOfMCNumber1; for (j = (arrayOfMCNumber1 = gids).length, b1 = 0; b1 < j; ) { MCNumber g = arrayOfMCNumber1[b1];
/*     */           
/* 668 */           if (o.gid1().eq((BigDecimal)g))
/* 669 */             l.add((MCRow)o); 
/*     */           b1++; }
/*     */       
/*     */       } 
/* 673 */       return l;
/*     */     } 
/*     */     
/* 676 */     if (this.c_pairs != null) {
/* 677 */       return this.c_pairs;
/*     */     }
/*     */ 
/*     */     
/* 681 */     this.c_pairs = MCList.create(FCM_PARA_OPE_CTRL_R.class);
/* 682 */     FCM_PARA_OPE_CTRL_R dbc = FCM_PARA_OPE_CTRL_R.create("M");
/* 683 */     MCQueryApiBuilder builder = MCQueryApiBuilder.create((MCDBContainer)dbc);
/* 684 */     builder.setWhere(IFMCSQL.value(0).eq(IFMCSQL.value(1)), new Comparable[0]); byte b; int i; MCNumber[] arrayOfMCNumber;
/* 685 */     for (i = (arrayOfMCNumber = gids).length, b = 0; b < i; ) { MCNumber s = arrayOfMCNumber[b];
/* 686 */       builder.addWhereWithOr(dbc.gid1.eq(IFMCSQL.bind("1")), new Comparable[] { (Comparable)s }); b++; }
/*     */     
/* 688 */     MCDBUtil.dbSelect("FC_MCParaQueue_getCtrl", this.c_pairs, builder);
/*     */     
/* 690 */     return this.c_pairs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized MCList<FCM_PARA_OPE_GRP_R> getGrp(MCParaConfig c, MCNumber... gids) {
/* 704 */     if (isCache()) {
/*     */       
/* 706 */       MCList<FCM_PARA_OPE_GRP_R> l = this.c_grps.createInstance();
/* 707 */       for (FCM_PARA_OPE_GRP_R o : this.c_grps) {
/* 708 */         if (!MCStringUtil.eq(o.co_cd(), c.ope.co_cd) || 
/* 709 */           !MCStringUtil.eq(o.ext_attr1(), c.ope.ext_attr1) || 
/* 710 */           !MCStringUtil.eq(o.ext_attr2(), c.ope.ext_attr2) || 
/* 711 */           !MCStringUtil.eq(o.ext_attr3(), c.ope.ext_attr3))
/*     */           continue;  byte b; int j;
/*     */         MCNumber[] arrayOfMCNumber;
/* 714 */         for (j = (arrayOfMCNumber = gids).length, b = 0; b < j; ) { MCNumber g = arrayOfMCNumber[b];
/*     */           
/* 716 */           if (o.gid().eq((BigDecimal)g))
/* 717 */             l.add((MCRow)o); 
/*     */           b++; }
/*     */       
/*     */       } 
/* 721 */       return l;
/*     */     } 
/*     */     
/* 724 */     if (this.c_grps != null) {
/* 725 */       return this.c_grps;
/*     */     }
/*     */ 
/*     */     
/* 729 */     this.c_grps = MCList.create(FCM_PARA_OPE_GRP_R.class);
/* 730 */     FCM_PARA_OPE_GRP_R dbc = FCM_PARA_OPE_GRP_R.create("M");
/* 731 */     MCQueryApiBuilder builder = MCQueryApiBuilder.create((MCDBContainer)dbc);
/* 732 */     builder.addWhereWithAnd(IFMCSQL.bind("1").isNull().and(dbc.co_cd.isNull()).or(dbc.co_cd.eq(IFMCSQL.bind("1"))), new Comparable[] { c.ope.co_cd });
/* 733 */     builder.addWhereWithAnd(IFMCSQL.bind("1").isNull().and(dbc.ext_attr1.isNull()).or(dbc.ext_attr1.eq(IFMCSQL.bind("1"))), new Comparable[] { c.ope.ext_attr1 });
/* 734 */     builder.addWhereWithAnd(IFMCSQL.bind("1").isNull().and(dbc.ext_attr2.isNull()).or(dbc.ext_attr2.eq(IFMCSQL.bind("1"))), new Comparable[] { c.ope.ext_attr2 });
/* 735 */     builder.addWhereWithAnd(IFMCSQL.bind("1").isNull().and(dbc.ext_attr3.isNull()).or(dbc.ext_attr3.eq(IFMCSQL.bind("1"))), new Comparable[] { c.ope.ext_attr3 });
/* 736 */     IFMCSQL.MCPredicate where = IFMCSQL.value(0).eq(IFMCSQL.value(1));
/* 737 */     for (int i = 0; i < gids.length; i++) {
/* 738 */       where = where.or(dbc.gid.eq(IFMCSQL.bind(String.valueOf(i + 1))));
/*     */     }
/* 740 */     builder.addWhereWithAnd(where, (Comparable[])gids);
/* 741 */     MCDBUtil.dbSelect("FC_MCParaQueue_getGrp", this.c_grps, builder);
/*     */     
/* 743 */     return this.c_grps;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized MCList<FCM_PARA_OPE_GRP_ITM_R> getGrpItm(MCParaConfig c) {
/* 757 */     if (this.c_itms == null) {
/* 758 */       this.c_itms = MCList.create(FCM_PARA_OPE_GRP_ITM_R.class);
/* 759 */       FCM_PARA_OPE_GRP_ITM_R dbc = FCM_PARA_OPE_GRP_ITM_R.create("M");
/* 760 */       ((IFMCSQL.MCMainQuery)IFMCSQL.sql("FC_MCParaQueue_getGrpItm")
/* 761 */         .mainQuery()
/* 762 */         .select((IFMCFMSQL.MCFMEDColumnGroup[])dbc.getBaseColumns$())
/* 763 */         .from((IFMCSQL.MCDerivedView)dbc))
/* 764 */         .executeQuery(this.c_itms);
/*     */     } 
/*     */ 
/*     */     
/* 768 */     MCList<FCM_PARA_OPE_GRP_ITM_R> l = this.c_itms.createInstance();
/* 769 */     for (FCM_PARA_OPE_GRP_ITM_R o : this.c_itms) {
/* 770 */       if (match(c.ope.ope_id, o.ptn())) {
/* 771 */         l.add((MCRow)o);
/*     */       }
/*     */     } 
/*     */     
/* 775 */     return l;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean match(String ope_id, String ptn) {
/* 788 */     String[] tar = MCStringUtil.match(ptn, new String[] {
/* 789 */           ope_id
/* 790 */         }, '.');
/* 791 */     return (tar.length == 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isCache() {
/* 802 */     return MCConfig.server.getBoolean("process.parallel.cache", true);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\para\MCParaQueue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */