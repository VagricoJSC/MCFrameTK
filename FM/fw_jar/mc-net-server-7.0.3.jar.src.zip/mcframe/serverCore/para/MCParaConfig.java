/*    */ package mcframe.serverCore.para;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import mcframe.commonCore.lang.MCNumber;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCParaConfig
/*    */ {
/*    */   final MCOpeInfo ope;
/*    */   final Set<MCNumber> mygrps;
/*    */   final Set<MCNumber> exgrps;
/*    */   
/*    */   MCParaConfig(MCOpeInfo ope) {
/* 53 */     this.ope = ope;
/* 54 */     this.mygrps = new HashSet<>();
/* 55 */     this.exgrps = new HashSet<>();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean hasExGrps() {
/* 73 */     if (this.mygrps.size() == 0) {
/* 74 */       return false;
/*    */     }
/* 76 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\para\MCParaConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */