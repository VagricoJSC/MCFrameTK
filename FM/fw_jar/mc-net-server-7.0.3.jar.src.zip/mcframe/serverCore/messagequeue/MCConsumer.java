package mcframe.serverCore.messagequeue;

public interface MCConsumer<T extends mcframe.commonCore.container.MCRow> {
  void execute(T paramT, boolean paramBoolean, String paramString);
  
  T createParamRow();
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\messagequeue\MCConsumer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */