/*     */ package mcframe.serverCore.messagequeue;
/*     */ 
/*     */ import java.io.StringWriter;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.concurrent.Callable;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCBooleanUtil;
/*     */ import mcframe.commonCore.lang.MCDataType;
/*     */ import mcframe.commonCore.lang.MCDate;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.lang.MCTimestamp;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.param.MCDPWriter;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.commonCore.pio.util.MCDPToken;
/*     */ import mcframe.commonCore.sys.MCFactory;
/*     */ import mcframe.serverCore.dbc.FCT_MESSAGE_QUEUE_R;
/*     */ import mcframe.serverCore.mcjdbc.MCTransactionManager;
/*     */ import mcframe.serverCore.requester.MCDispatcherContext;
/*     */ import mcframe.serverCore.requester.MCRequestStatus;
/*     */ import mcframe.serverCore.requester.MCRequestStatusImpl;
/*     */ import mcframe.serverCore.requester.MCRequesterPackageProxy;
/*     */ import mcframe.serverCore.requester.MCServerSignalManagerImpl;
/*     */ import mcframe.serverCore.resource.MCConfig;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ConsumerExecuter
/*     */   implements Callable<ConsumerResult>
/*     */ {
/*     */   private final FCT_MESSAGE_QUEUE_R _messageQueueRec;
/*     */   private final String _srvRecNo;
/*     */   private final boolean _isRetry;
/*     */   private final String _moduleId;
/*     */   private final String _subModuleId;
/*     */   private final String _LogicId;
/*     */   private final String _className;
/*     */   private final Locale _locale;
/*     */   
/*     */   ConsumerExecuter(FCT_MESSAGE_QUEUE_R message, String srvRecNo, boolean isRetry) {
/* 109 */     this._messageQueueRec = message;
/* 110 */     this._srvRecNo = srvRecNo;
/* 111 */     this._isRetry = isRetry;
/*     */     
/* 113 */     String consumerId = message.consumer_id();
/*     */     
/* 115 */     this._moduleId = MCMessageQueueConfig.getConsumerModuleId(consumerId);
/* 116 */     this._subModuleId = MCMessageQueueConfig.getConsumerSubModuleId(consumerId);
/* 117 */     this._LogicId = MCMessageQueueConfig.getConsumerLogicId(consumerId);
/* 118 */     this._className = MCMessageQueueConfig.getConsumerClass(consumerId);
/* 119 */     this._locale = new Locale(message.locale_language(), message.locale_country());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConsumerResult call() throws Exception {
/* 133 */     ConsumerResult result = ConsumerResult.fail();
/* 134 */     MCException err = null;
/* 135 */     MCRequestStatus status = null;
/*     */     
/*     */     try {
/* 138 */       status = init();
/*     */       
/* 140 */       MCConsumer<MCRow> consumer = (MCConsumer<MCRow>)MCFactory.create(MCConsumer.class, 
/* 141 */           makeConsumerClassName());
/* 142 */       MCRow param = consumer.createParamRow();
/* 143 */       createParam(MCMessageQueue.getMessageParam(this._messageQueueRec), param);
/*     */       
/* 145 */       MCLog.write(Core_Msg_FW_A.FCBMC0003, new Object[] { this._messageQueueRec.message_queue_id() });
/* 146 */       status.run();
/*     */       try {
/* 148 */         MCTransactionManager.listenerStart();
/* 149 */         MCServerSignalManagerImpl.addServerRequest(this._srvRecNo);
/* 150 */         consumer.execute(param, this._isRetry, this._messageQueueRec.message_queue_id());
/*     */       } finally {
/*     */         
/* 153 */         MCServerSignalManagerImpl.delServerRequest(this._srvRecNo);
/* 154 */         MCTransactionManager.listenerStop();
/*     */       } 
/* 156 */       result = ConsumerResult.ok();
/* 157 */       MCLog.write(Core_Msg_FW_A.FCBMC0004, new Object[] { this._messageQueueRec.message_queue_id() });
/* 158 */       MCTransactionManager.commit();
/* 159 */       status.success();
/*     */     }
/* 161 */     catch (MCException e) {
/* 162 */       result = ConsumerResult.fail();
/* 163 */       err = e;
/* 164 */       MCLog.write(Core_Msg_FW_A.FCBMC0005, new Object[] { this._messageQueueRec.message_queue_id() });
/* 165 */       MCLog.write((Throwable)err);
/* 166 */       MCTransactionManager.rollBack();
/*     */       
/* 168 */       if (status != null) {
/* 169 */         status.error();
/*     */       }
/*     */     }
/* 172 */     catch (Throwable e) {
/* 173 */       result = ConsumerResult.fail();
/* 174 */       if (e instanceof mcframe.commonCore.notice.MCError && e.getCause() instanceof MCException) {
/* 175 */         err = (MCException)e.getCause();
/*     */       } else {
/*     */         
/* 178 */         err = new MCException(e, Core_Msg_FW_A.FCBMC0006, new Object[] { this._messageQueueRec.message_queue_id() });
/*     */       } 
/* 180 */       MCLog.write(Core_Msg_FW_A.FCBMC0005, new Object[] { this._messageQueueRec.message_queue_id() });
/* 181 */       MCLog.write((Throwable)err);
/* 182 */       MCTransactionManager.rollBack();
/*     */       
/* 184 */       if (status != null) {
/* 185 */         status.error();
/*     */       }
/*     */     } finally {
/*     */       
/* 189 */       MCMessageQueue.updStatus2End(this._messageQueueRec, result.isOk(), err);
/* 190 */       destoryRequestObject();
/* 191 */       MCTransactionManager.finalClose();
/*     */     } 
/*     */     
/* 194 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCRequestStatus init() {
/* 206 */     initRequestObject();
/*     */     
/* 208 */     MCParam param = new MCParam();
/* 209 */     param.setUserId(this._messageQueueRec.user_id());
/* 210 */     param.setUserName(this._messageQueueRec.user_nm());
/* 211 */     param.setLogicId(this._LogicId);
/* 212 */     param.setModuleId(this._moduleId);
/* 213 */     param.setOperationId(this._className);
/* 214 */     param.setServerId(MCConfig.server.getString("server.name"));
/* 215 */     param.setServerRequestNo(this._srvRecNo);
/*     */     
/* 217 */     param.setClientRequestNo("0");
/* 218 */     param.setClientId(MCConfig.server.getString("server.name"));
/* 219 */     param.setCreatedTime(MCTimestamp.now());
/* 220 */     param.setReqSrcId("FSBGP0180");
/*     */     
/* 222 */     MCDispatcherContext cntx = MCRequesterPackageProxy.NewMCDispatcherContext(param);
/* 223 */     MCDPToken tkn = MCDPToken.create("up");
/* 224 */     cntx.setUpDPT(tkn);
/* 225 */     MCRequesterPackageProxy.MCRequestInit(cntx);
/*     */     
/* 227 */     MCRequesterPackageProxy.MCUserInit(this._messageQueueRec.user_id(), 
/* 228 */         this._messageQueueRec.co_cd());
/*     */     
/* 230 */     ((Map<String, String>)MCTransactionManager.USER_CNTEXT.get()).put("processid", this._srvRecNo);
/* 231 */     ((Map<String, String>)MCTransactionManager.USER_CNTEXT.get()).put("userid", this._messageQueueRec.user_id());
/* 232 */     ((Map<String, String>)MCTransactionManager.USER_CNTEXT.get()).put("usernm", this._messageQueueRec.user_nm());
/*     */     
/* 234 */     ((Map<String, String>)MCTransactionManager.USER_CNTEXT.get()).put("co_cd", this._messageQueueRec.co_cd());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 239 */     ((Map<String, String>)MCTransactionManager.USER_CNTEXT.get()).put("language", this._locale.toString());
/*     */ 
/*     */     
/* 242 */     ((Map<String, String>)MCTransactionManager.USER_CNTEXT.get()).put("locale", this._locale.toString());
/* 243 */     ((Map<String, String>)MCTransactionManager.USER_CNTEXT.get()).put("call_pg_id", this._messageQueueRec.func_id());
/*     */     
/* 245 */     StringWriter sw = new StringWriter(1024);
/* 246 */     MCDPWriter w = new MCDPWriter(sw, true);
/* 247 */     return (MCRequestStatus)new MCRequestStatusImpl(param, w);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void initRequestObject() {
/* 253 */     MCRequesterPackageProxy.MCRequestObjectDestory();
/* 254 */     MCRequesterPackageProxy.MCRequestObjectInit();
/*     */   }
/*     */   
/*     */   private void destoryRequestObject() {
/* 258 */     MCRequesterPackageProxy.MCRequestObjectDestory();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void createParam(Optional<Map<String, String>> paramMap, MCRow dest) {
/* 272 */     Map<String, String> m = paramMap.orElse(new HashMap<>());
/* 273 */     m.entrySet().forEach(entry -> bind(paramMCRow, entry.getKey(), entry.getValue()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void bind(MCRow dist, String key, String value) {
/* 279 */     MCMeta meta = dist.getMeta(key);
/* 280 */     if (meta == null) {
/*     */       
/* 282 */       dist.setStringNE(key, value);
/*     */       
/*     */       return;
/*     */     } 
/* 286 */     switch (meta.type()) {
/*     */       case STRING:
/* 288 */         dist.setStringNE(key, value);
/*     */         break;
/*     */       case NUMBER:
/* 291 */         dist.setNumberNE(key, MCNumber.valueOf(value));
/*     */         break;
/*     */       case DATE:
/* 294 */         dist.setDateNE(key, MCDate.valueOf(value, "yyyyMMddHHmmss"));
/*     */         break;
/*     */       case TIMESTAMP:
/* 297 */         dist.setTimestampNE(key, 
/* 298 */             MCTimestamp.valueOf(value, "yyyyMMddHHmmssSSS"));
/*     */         break;
/*     */       case BOOLEAN:
/* 301 */         dist.setBooleanNE(key, MCBooleanUtil.dbStringToBoolean(value));
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String makeConsumerClassName() {
/* 317 */     return String.format("mcframe.server%s.%s.%s", new Object[] { this._subModuleId, this._LogicId, 
/* 318 */           this._className });
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\messagequeue\ConsumerExecuter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */