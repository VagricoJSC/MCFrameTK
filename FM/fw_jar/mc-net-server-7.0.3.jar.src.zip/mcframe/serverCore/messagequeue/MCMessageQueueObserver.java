/*     */ package mcframe.serverCore.messagequeue;
/*     */ 
/*     */ import java.util.Optional;
/*     */ import java.util.Queue;
/*     */ import java.util.concurrent.ConcurrentLinkedQueue;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import mcframe.commonCore.constant.FCC_MESSAGE_QUEUE_STATUS;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.serverCore.dbc.FCT_MESSAGE_QUEUE_R;
/*     */ import mcframe.serverCore.mcjdbc.MCTransactionManager;
/*     */ import mcframe.serverCore.requester.MCRequesterPackageProxy;
/*     */ import mcframe.serverCore.resource.MCConst;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCMessageQueueObserver
/*     */   implements MessageQueueObserver, Runnable
/*     */ {
/*  41 */   private static boolean MESSAGE_QUEUE_VALID = MCConst.plugin
/*  42 */     .getBoolean(MCConst.createKey(new String[] { "messagequeue", "valid" }, ), true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   private static final int MESSAGE_QUEUE_MONITORING_INTERVAL = MCConst.plugin
/*  51 */     .getInteger(MCConst.createKey(new String[] { "messagequeue", "monitoring", "interval"
/*  52 */         }, ), 3000);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final String NAME = "@@MCMessageQueueObserver";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void monitoring() {
/*  82 */     if (!isValid()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  87 */     Thread t = new Thread(new MCMessageQueueObserver(), "@@MCMessageQueueObserver");
/*  88 */     t.setDaemon(true);
/*  89 */     t.start();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*     */     try {
/* 102 */       init();
/*     */       
/*     */       while (true) {
/* 105 */         runImpl();
/*     */       }
/*     */     }
/* 108 */     catch (Exception e) {
/* 109 */       e.printStackTrace();
/* 110 */       MCLog.write((Throwable)new MCException(e, Core_Msg_FW_A.FCBMC0002, new Object[0]));
/*     */     } finally {
/*     */       
/* 113 */       MCTransactionManager.finalClose();
/* 114 */       MCRequesterPackageProxy.MCRequestObjectDestory();
/*     */ 
/*     */       
/* 117 */       Thread t = new Thread(new MCMessageQueueObserver(), "@@MCMessageQueueObserver");
/* 118 */       t.setDaemon(true);
/* 119 */       t.start();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init() {
/* 132 */     MCRequesterPackageProxy.MCRequestObjectInit();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void runImpl() throws Exception {
/* 143 */     TimeUnit.MILLISECONDS.sleep(MESSAGE_QUEUE_MONITORING_INTERVAL);
/*     */     
/* 145 */     MCList<FCT_MESSAGE_QUEUE_R> msgList = MCMessageQueue.searchRunnableMessage();
/*     */     
/* 147 */     ExecutorService e = Executors.newFixedThreadPool(1);
/* 148 */     Queue<Future<ConsumerResult>> resultQueue = new ConcurrentLinkedQueue<>();
/*     */     
/* 150 */     msgList.forEach(msg -> {
/*     */           Optional<FCT_MESSAGE_QUEUE_R> lockedMsg = MCMessageQueue.lockMessage(msg);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*     */           lockedMsg.ifPresent(());
/*     */         });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 169 */     while (!resultQueue.isEmpty()) {
/* 170 */       (ConsumerResult)((Future<ConsumerResult>)resultQueue.poll()).get();
/*     */     }
/* 172 */     e.shutdown();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Future<ConsumerResult> execConsumer(FCT_MESSAGE_QUEUE_R msg, boolean isRetry, ExecutorService e, String srvRecNo) {
/* 189 */     ConsumerExecuter c = new ConsumerExecuter(msg, srvRecNo, isRetry);
/* 190 */     Future<ConsumerResult> result = e.submit(c);
/* 191 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isValid() {
/* 204 */     return MESSAGE_QUEUE_VALID;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   void runOnlyOnce() throws Exception {
/* 218 */     Thread t = new Thread(new Runnable()
/*     */         {
/*     */           public void run() {
/*     */             try {
/* 222 */               MCMessageQueueObserver.this.init();
/* 223 */               MCMessageQueueObserver.this.runImpl();
/*     */             }
/* 225 */             catch (Exception e) {
/* 226 */               e.printStackTrace();
/*     */             } finally {
/*     */               
/* 229 */               MCTransactionManager.finalClose();
/* 230 */               MCRequesterPackageProxy.MCRequestObjectDestory();
/*     */             } 
/*     */           }
/*     */         });
/*     */     
/* 235 */     t.start();
/* 236 */     t.join();
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\messagequeue\MCMessageQueueObserver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */