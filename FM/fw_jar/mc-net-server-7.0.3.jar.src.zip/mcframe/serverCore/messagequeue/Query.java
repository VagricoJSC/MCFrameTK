/*     */ package mcframe.serverCore.messagequeue;
/*     */ 
/*     */ import mcframe.commonCore.constant.FCC_MESSAGE_QUEUE_STATUS;
/*     */ import mcframe.serverCore.dbc.CoreFunction;
/*     */ import mcframe.serverCore.dbc.FCT_MESSAGE_QUEUE_PARAM_R;
/*     */ import mcframe.serverCore.dbc.FCT_MESSAGE_QUEUE_R;
/*     */ import mcframe.serverCore.queryapi.IFMCFMSQL;
/*     */ import mcframe.serverCore.queryapi.IFMCSQL;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Query
/*     */ {
/*     */   static final IFMCSQL.MCMainQuery FCT_MESSAGE_QUEUE_S01() {
/*  31 */     FCT_MESSAGE_QUEUE_R T = FCT_MESSAGE_QUEUE_R.create();
/*  32 */     IFMCSQL.MCMainQuery q = (IFMCSQL.MCMainQuery)((IFMCSQL.MCMainQuery)IFMCSQL.sql("FCT_MESSAGE_QUEUE_S01").mainQuery()
/*  33 */       .select(new IFMCFMSQL.MCFMEDColumnGroup[] { (IFMCFMSQL.MCFMEDColumnGroup)T.message_queue_id }).from((IFMCSQL.MCDerivedView)T))
/*  34 */       .where(T.status
/*  35 */         .eq(IFMCSQL.value(FCC_MESSAGE_QUEUE_STATUS.WAIT_FOR_EXECUTION.value()))
/*  36 */         .or(T.status.eq(IFMCSQL.value(
/*  37 */               FCC_MESSAGE_QUEUE_STATUS.WAIT_FOR_REPLAY.value()))));
/*  38 */     return q;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final IFMCSQL.MCMainQuery FCT_MESSAGE_QUEUE_S02() {
/*  50 */     FCT_MESSAGE_QUEUE_R T = FCT_MESSAGE_QUEUE_R.create();
/*  51 */     IFMCSQL.MCMainQuery q = ((IFMCSQL.MCMainQuery)((IFMCSQL.MCMainQuery)IFMCSQL.sql("FCT_MESSAGE_QUEUE_S02").mainQuery()
/*  52 */       .select((IFMCFMSQL.MCFMEDColumnGroup[])T.getBaseColumns$()).from((IFMCSQL.MCDerivedView)T))
/*  53 */       .where(T.message_queue_id.eq(IFMCSQL.bind("message_queue_id"))
/*  54 */         .and(T.status
/*  55 */           .eq(IFMCSQL.value(FCC_MESSAGE_QUEUE_STATUS.WAIT_FOR_EXECUTION
/*  56 */               .value()))
/*  57 */           .or(T.status
/*  58 */             .eq(IFMCSQL.value(FCC_MESSAGE_QUEUE_STATUS.WAIT_FOR_REPLAY
/*  59 */                 .value()))))))
/*  60 */       .forUpdateNoWait(new IFMCFMSQL.MCFMAGPermColumn[0]);
/*  61 */     return q;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final IFMCSQL.MCMainQuery FCT_MESSAGE_QUEUE_S03() {
/*  73 */     FCT_MESSAGE_QUEUE_R T = FCT_MESSAGE_QUEUE_R.create();
/*  74 */     IFMCSQL.MCMainQuery q = ((IFMCSQL.MCMainQuery)((IFMCSQL.MCMainQuery)IFMCSQL.sql("FCT_MESSAGE_QUEUE_S03").mainQuery()
/*  75 */       .select(new IFMCFMSQL.MCFMEDColumnGroup[] { (IFMCFMSQL.MCFMEDColumnGroup)T.message_queue_id, (IFMCFMSQL.MCFMEDColumnGroup)T.status, (IFMCFMSQL.MCFMEDColumnGroup)T.upd_cntr }).from((IFMCSQL.MCDerivedView)T))
/*  76 */       .where(T.message_queue_id.eq(IFMCSQL.bind("message_queue_id"))
/*  77 */         .and(T.status.eq(
/*  78 */             IFMCSQL.value(FCC_MESSAGE_QUEUE_STATUS.ABNORMAL_END.value())))))
/*  79 */       .forUpdateNoWait(new IFMCFMSQL.MCFMAGPermColumn[0]);
/*  80 */     return q;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final IFMCSQL.MCMainQuery FCT_MESSAGE_QUEUE_S04() {
/*  92 */     FCT_MESSAGE_QUEUE_R T = FCT_MESSAGE_QUEUE_R.create();
/*  93 */     IFMCSQL.MCMainQuery q = ((IFMCSQL.MCMainQuery)((IFMCSQL.MCMainQuery)IFMCSQL.sql("FCT_MESSAGE_QUEUE_S04").mainQuery()
/*  94 */       .select(new IFMCFMSQL.MCFMEDColumnGroup[] { (IFMCFMSQL.MCFMEDColumnGroup)T.message_queue_id, (IFMCFMSQL.MCFMEDColumnGroup)T.status, (IFMCFMSQL.MCFMEDColumnGroup)T.upd_cntr }).from((IFMCSQL.MCDerivedView)T))
/*  95 */       .where(T.message_queue_id.eq(IFMCSQL.bind("message_queue_id"))
/*  96 */         .and(T.status.in((Object[])new IFMCFMSQL.MCFMAGStringExpr[] {
/*  97 */               (IFMCFMSQL.MCFMAGStringExpr)IFMCSQL.value(FCC_MESSAGE_QUEUE_STATUS.NORMAL_END.value()), 
/*  98 */               (IFMCFMSQL.MCFMAGStringExpr)IFMCSQL.value(FCC_MESSAGE_QUEUE_STATUS.ABNORMAL_END.value())
/*  99 */             })))).forUpdateNoWait(new IFMCFMSQL.MCFMAGPermColumn[0]);
/* 100 */     return q;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final IFMCSQL.MCMainQuery FCT_MESSAGE_QUEUE_S05() {
/* 112 */     FCT_MESSAGE_QUEUE_R T = FCT_MESSAGE_QUEUE_R.create();
/* 113 */     IFMCSQL.MCMainQuery q = ((IFMCSQL.MCMainQuery)((IFMCSQL.MCMainQuery)IFMCSQL.sql("FCT_MESSAGE_QUEUE_S05").mainQuery()
/* 114 */       .select(new IFMCFMSQL.MCFMEDColumnGroup[] { (IFMCFMSQL.MCFMEDColumnGroup)T.message_queue_id, (IFMCFMSQL.MCFMEDColumnGroup)T.status, (IFMCFMSQL.MCFMEDColumnGroup)T.upd_cntr }).from((IFMCSQL.MCDerivedView)T))
/* 115 */       .where(T.message_queue_id.eq(IFMCSQL.bind("message_queue_id"))
/* 116 */         .and(T.status
/* 117 */           .eq(IFMCSQL.value(FCC_MESSAGE_QUEUE_STATUS.RUNNING.value())))))
/* 118 */       .forUpdateNoWait(new IFMCFMSQL.MCFMAGPermColumn[0]);
/* 119 */     return q;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final IFMCSQL.MCMainQuery FCT_MESSAGE_QUEUE_PARAM_S01() {
/* 130 */     FCT_MESSAGE_QUEUE_PARAM_R T = FCT_MESSAGE_QUEUE_PARAM_R.create();
/* 131 */     IFMCSQL.MCMainQuery q = (IFMCSQL.MCMainQuery)((IFMCSQL.MCMainQuery)IFMCSQL.sql("FCT_MESSAGE_QUEUE_PARAM_S01").mainQuery()
/* 132 */       .select((IFMCFMSQL.MCFMEDColumnGroup[])T.getBaseColumns$()).from((IFMCSQL.MCDerivedView)T)).where(T.message_queue_id
/* 133 */         .eq(IFMCSQL.bind("message_queue_id")));
/* 134 */     return q;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final IFMCSQL.MCUpdate FCT_MESSAGE_QUEUE_U01() {
/* 146 */     FCT_MESSAGE_QUEUE_R T = FCT_MESSAGE_QUEUE_R.create();
/* 147 */     IFMCSQL.MCUpdate q = IFMCSQL.sql("FCT_MESSAGE_QUEUE_U01").update((IFMCSQL.MCPermView)T).set((IFMCFMSQL.MCFMAGPermColumn)T.status)
/* 148 */       .eq((IFMCFMSQL.MCFMAGExpr)IFMCSQL.bindEx("status")).set((IFMCFMSQL.MCFMAGPermColumn)T.srv_req_no)
/* 149 */       .eq((IFMCFMSQL.MCFMAGExpr)IFMCSQL.bindEx("srv_req_no")).set((IFMCFMSQL.MCFMAGPermColumn)T.start_ts)
/* 150 */       .eq((IFMCFMSQL.MCFMAGExpr)CoreFunction.FCPA_DATE_UTIL$F_MCSYSTIMESTAMP_CO(
/* 151 */           (IFMCFMSQL.MCFMAGStringExpr)IFMCSQL.bindEx("co_cd")))
/* 152 */       .set((IFMCFMSQL.MCFMAGPermColumn)T.end_ts).eq((IFMCFMSQL.MCFMAGExpr)IFMCSQL.nullValue()).where(T.message_queue_id
/* 153 */         .eq(IFMCSQL.bind("message_queue_id")));
/* 154 */     return q;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final IFMCSQL.MCUpdate FCT_MESSAGE_QUEUE_U02() {
/* 166 */     FCT_MESSAGE_QUEUE_R T = FCT_MESSAGE_QUEUE_R.create();
/* 167 */     IFMCSQL.MCUpdate u = IFMCSQL.sql("FCT_MESSAGE_QUEUE_U02").update((IFMCSQL.MCPermView)T).set((IFMCFMSQL.MCFMAGPermColumn)T.status)
/* 168 */       .eq((IFMCFMSQL.MCFMAGExpr)IFMCSQL.bind("status")).set((IFMCFMSQL.MCFMAGPermColumn)T.end_ts)
/* 169 */       .eq((IFMCFMSQL.MCFMAGExpr)CoreFunction.FCPA_DATE_UTIL$F_MCSYSTIMESTAMP_CO(
/* 170 */           (IFMCFMSQL.MCFMAGStringExpr)IFMCSQL.bind("co_cd")))
/* 171 */       .set((IFMCFMSQL.MCFMAGPermColumn)T.msg_id).eq((IFMCFMSQL.MCFMAGExpr)IFMCSQL.bind("msg_id")).set((IFMCFMSQL.MCFMAGPermColumn)T.msg_lvl)
/* 172 */       .eq((IFMCFMSQL.MCFMAGExpr)IFMCSQL.bind("msg_lvl")).set((IFMCFMSQL.MCFMAGPermColumn)T.msg_txt)
/* 173 */       .eq((IFMCFMSQL.MCFMAGExpr)IFMCSQL.bind("msg_txt")).where(T.message_queue_id
/* 174 */         .eq(IFMCSQL.bind("message_queue_id")));
/* 175 */     return u;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final IFMCSQL.MCUpdate FCT_MESSAGE_QUEUE_U03() {
/* 187 */     FCT_MESSAGE_QUEUE_R T = FCT_MESSAGE_QUEUE_R.create();
/* 188 */     IFMCSQL.MCUpdate u = IFMCSQL.sql("FCT_MESSAGE_QUEUE_U03").update((IFMCSQL.MCPermView)T).set((IFMCFMSQL.MCFMAGPermColumn)T.status)
/* 189 */       .eq((IFMCFMSQL.MCFMAGExpr)IFMCSQL.bind("status")).set((IFMCFMSQL.MCFMAGPermColumn)T.srv_req_no)
/* 190 */       .eq((IFMCFMSQL.MCFMAGExpr)IFMCSQL.bind("srv_req_no")).set((IFMCFMSQL.MCFMAGPermColumn)T.start_ts)
/* 191 */       .eq((IFMCFMSQL.MCFMAGExpr)IFMCSQL.bind("start_ts")).set((IFMCFMSQL.MCFMAGPermColumn)T.end_ts)
/* 192 */       .eq((IFMCFMSQL.MCFMAGExpr)IFMCSQL.bind("end_ts")).set((IFMCFMSQL.MCFMAGPermColumn)T.msg_id)
/* 193 */       .eq((IFMCFMSQL.MCFMAGExpr)IFMCSQL.bind("msg_id")).set((IFMCFMSQL.MCFMAGPermColumn)T.msg_lvl)
/* 194 */       .eq((IFMCFMSQL.MCFMAGExpr)IFMCSQL.bind("msg_lvl")).set((IFMCFMSQL.MCFMAGPermColumn)T.msg_txt)
/* 195 */       .eq((IFMCFMSQL.MCFMAGExpr)IFMCSQL.bind("msg_txt")).where(T.message_queue_id
/* 196 */         .eq(IFMCSQL.bind("message_queue_id")));
/* 197 */     return u;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final IFMCSQL.MCDelete FCT_MESSAGE_QUEUE_D01() {
/* 209 */     FCT_MESSAGE_QUEUE_R T = FCT_MESSAGE_QUEUE_R.create();
/* 210 */     IFMCSQL.MCDelete d = IFMCSQL.sql("FCT_MESSAGE_QUEUE_D01").delete((IFMCSQL.MCPermView)T).where(
/* 211 */         T.message_queue_id.eq(IFMCSQL.bind("message_queue_id")));
/* 212 */     return d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final IFMCSQL.MCDelete FCT_MESSAGE_QUEUE_PARAM_D01() {
/* 224 */     FCT_MESSAGE_QUEUE_PARAM_R T = FCT_MESSAGE_QUEUE_PARAM_R.create();
/* 225 */     IFMCSQL.MCDelete d = IFMCSQL.sql("FCT_MESSAGE_QUEUE_PARAM_D01").delete((IFMCSQL.MCPermView)T).where(
/* 226 */         T.message_queue_id.eq(IFMCSQL.bind("message_queue_id")));
/* 227 */     return d;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\messagequeue\Query.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */