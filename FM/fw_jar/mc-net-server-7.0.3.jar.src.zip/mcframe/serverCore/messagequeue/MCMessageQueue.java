/*     */ package mcframe.serverCore.messagequeue;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Optional;
/*     */ import java.util.UUID;
/*     */ import mcframe.commonCore.constant.FCC_MESSAGE_QUEUE_STATUS;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.meta.M_META;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.resource.MCLocaleConst;
/*     */ import mcframe.commonCore.resource.MCMessageConst;
/*     */ import mcframe.serverCore.dbc.FCT_MESSAGE_QUEUE_PARAM_R;
/*     */ import mcframe.serverCore.dbc.FCT_MESSAGE_QUEUE_R;
/*     */ import mcframe.serverCore.mcjdbc.FWDBUtil;
/*     */ import mcframe.serverCore.mcjdbc.MCDBTransaction;
/*     */ import mcframe.serverCore.mcjdbc.MCTransactionManager;
/*     */ import mcframe.serverCore.queryapi.MCDBContainer;
/*     */ import mcframe.serverCore.queryapi.MCQueryApiBuilder;
/*     */ import mcframe.serverCore.sys.MCSys;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCMessageQueue
/*     */ {
/*     */   public static Optional<String> request(MCMQMessage message) {
/*  57 */     return request(message, MCTransactionManager.dbTran());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Optional<String> request(MCMQMessage message, MCDBTransaction tran) {
/*  71 */     if (message == null) {
/*  72 */       return Optional.empty();
/*     */     }
/*     */     
/*  75 */     String id = requestMessageQueue(message, tran);
/*  76 */     requestMessageQueueParam(message, id, tran);
/*  77 */     return Optional.of(id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String makeMessageQueueId() {
/*  89 */     return UUID.randomUUID().toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String requestMessageQueue(MCMQMessage message, MCDBTransaction tran) {
/* 104 */     FCT_MESSAGE_QUEUE_R T = FCT_MESSAGE_QUEUE_R.create("T");
/*     */     
/* 106 */     String id = makeMessageQueueId();
/* 107 */     T.message_queue_id(id);
/* 108 */     T.user_id(MCSys.user.ID());
/* 109 */     T.user_nm(MCSys.user.name());
/* 110 */     T.co_cd(MCSys.user.coCD());
/* 111 */     T.locale_language(MCSys.user.locale().getLanguage());
/* 112 */     T.locale_country(MCSys.user.locale().getCountry());
/* 113 */     T.func_id(makeFuncId());
/* 114 */     T.status(FCC_MESSAGE_QUEUE_STATUS.WAIT_FOR_EXECUTION.value());
/* 115 */     T.consumer_id(message.consumerId());
/*     */     
/* 117 */     MCQueryApiBuilder builder = MCQueryApiBuilder.create((MCDBContainer)T);
/* 118 */     builder.setValuesAll();
/* 119 */     builder.buildInsert("FCT_MESSAGE_QUEUE_I01").executeUpdate(tran, (MCRow)T, null);
/*     */     
/* 121 */     return id;
/*     */   }
/*     */   
/*     */   private static String makeFuncId() {
/* 125 */     String func_id = MCSys.request.reqSrcId();
/* 126 */     if (func_id == null) {
/* 127 */       return null;
/*     */     }
/* 129 */     if (func_id.length() > M_META.CALL_PG_ID.length()) {
/* 130 */       func_id = func_id.substring(0, 
/* 131 */           M_META.CALL_PG_ID.length());
/*     */     }
/* 133 */     return func_id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void requestMessageQueueParam(MCMQMessage message, String id, MCDBTransaction tran) {
/* 149 */     if (message.paramSize() == 0) {
/*     */       return;
/*     */     }
/*     */     
/* 153 */     MCList<FCT_MESSAGE_QUEUE_PARAM_R> bindList = 
/* 154 */       MCList.create(FCT_MESSAGE_QUEUE_PARAM_R.class);
/* 155 */     message.paramStream().forEach(param -> {
/*     */           FCT_MESSAGE_QUEUE_PARAM_R row = FCT_MESSAGE_QUEUE_PARAM_R.create();
/*     */           
/*     */           row.message_queue_id(paramString);
/*     */           row.param_key(param.getKey());
/*     */           row.param_val(param.getValue());
/*     */           paramMCList.add((MCRow)row);
/*     */         });
/* 163 */     FCT_MESSAGE_QUEUE_PARAM_R T = FCT_MESSAGE_QUEUE_PARAM_R.create();
/* 164 */     MCQueryApiBuilder builder = MCQueryApiBuilder.create((MCDBContainer)T);
/* 165 */     builder.setValuesAll();
/* 166 */     builder.buildInsert("FCT_MESSAGE_QUEUE_PARAM_I01").executeBatchUpdate(tran, 
/* 167 */         bindList, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static MCList<FCT_MESSAGE_QUEUE_R> searchRunnableMessage() {
/* 181 */     MCList<FCT_MESSAGE_QUEUE_R> result = MCList.create(FCT_MESSAGE_QUEUE_R.class);
/* 182 */     MCTransactionManager.dbTran().statement()
/* 183 */       ._selectMessageQueue(Query.FCT_MESSAGE_QUEUE_S01().toString(), result);
/* 184 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Optional<FCT_MESSAGE_QUEUE_R> lockMessage(FCT_MESSAGE_QUEUE_R bind) {
/* 199 */     Optional<FCT_MESSAGE_QUEUE_R> result = Optional.empty();
/* 200 */     FCT_MESSAGE_QUEUE_R msg = FCT_MESSAGE_QUEUE_R.create();
/* 201 */     int cnt = 0;
/*     */     try {
/* 203 */       cnt = Query.FCT_MESSAGE_QUEUE_S02().executeQuery((MCRow)bind, (MCRow)msg);
/* 204 */       if (cnt == 1) {
/* 205 */         result = Optional.of(msg);
/*     */       }
/*     */     }
/* 208 */     catch (MCException e) {
/*     */       
/* 210 */       if (!e.getMCMessage().getID().equalsIgnoreCase(Core_Msg_FW_A.FCBCC0110)) {
/* 211 */         throw e;
/*     */       }
/*     */     } 
/*     */     
/* 215 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Optional<Map<String, String>> getMessageParam(FCT_MESSAGE_QUEUE_R bind) {
/* 229 */     MCList<FCT_MESSAGE_QUEUE_PARAM_R> result = 
/* 230 */       MCList.create(FCT_MESSAGE_QUEUE_PARAM_R.class);
/* 231 */     int cnt = Query.FCT_MESSAGE_QUEUE_PARAM_S01().executeQuery((MCRow)bind, result);
/* 232 */     if (cnt == 0) {
/* 233 */       return Optional.empty();
/*     */     }
/*     */     
/* 236 */     Map<String, String> m = new HashMap<>();
/* 237 */     result.forEach(r -> paramMap.put(r.param_key(), r.param_val()));
/*     */ 
/*     */ 
/*     */     
/* 241 */     return Optional.of(m);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String updStatus2Running(FCT_MESSAGE_QUEUE_R bind) {
/* 255 */     String srvRecNo = FWDBUtil.nextRoundReqNo();
/* 256 */     FCT_MESSAGE_QUEUE_R exBind = FCT_MESSAGE_QUEUE_R.create();
/* 257 */     exBind.status(FCC_MESSAGE_QUEUE_STATUS.RUNNING.value());
/* 258 */     exBind.srv_req_no(srvRecNo);
/*     */     
/* 260 */     MCDBTransaction tran = MCTransactionManager.dbTran();
/* 261 */     Query.FCT_MESSAGE_QUEUE_U01().executeUpdate(tran, (MCRow)bind, (MCRow)exBind);
/* 262 */     tran.commit();
/* 263 */     return srvRecNo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void updStatus2End(FCT_MESSAGE_QUEUE_R bind, boolean isNormalEnd, MCException e) {
/* 280 */     FCT_MESSAGE_QUEUE_R m = FCT_MESSAGE_QUEUE_R.create();
/* 281 */     m.message_queue_id(bind.message_queue_id());
/* 282 */     m.co_cd(bind.co_cd());
/* 283 */     m.status(isNormalEnd ? FCC_MESSAGE_QUEUE_STATUS.NORMAL_END.value() : 
/* 284 */         FCC_MESSAGE_QUEUE_STATUS.ABNORMAL_END.value());
/* 285 */     makeErrorBind(m, e);
/* 286 */     MCDBTransaction tran = MCTransactionManager.dbTran();
/* 287 */     Query.FCT_MESSAGE_QUEUE_U02().executeUpdate(tran, (MCRow)m, null);
/* 288 */     tran.commit();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void makeErrorBind(FCT_MESSAGE_QUEUE_R bind, MCException e) {
/* 301 */     if (e == null) {
/*     */       return;
/*     */     }
/* 304 */     MCMessageConst msgConst = MCLocaleConst.message(MCSys.user.locale());
/* 305 */     bind.msg_id(e.getID());
/* 306 */     bind.msg_lvl(
/* 307 */         (e.getLevel() == null) ? null : e.getLevel().toString().substring(0, 1));
/* 308 */     String s = e.getMCMessage().toString(msgConst);
/* 309 */     if (s != null) {
/* 310 */       int len = bind.getMeta("msg_txt").length();
/* 311 */       if (s.length() > len) {
/* 312 */         s = s.substring(0, len);
/*     */       }
/*     */     } 
/* 315 */     bind.msg_txt(s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FCT_MESSAGE_QUEUE_R lockErrorMessage(String messageQueueId) {
/* 328 */     FCT_MESSAGE_QUEUE_R bind = FCT_MESSAGE_QUEUE_R.create();
/* 329 */     FCT_MESSAGE_QUEUE_R result = FCT_MESSAGE_QUEUE_R.create();
/* 330 */     bind.message_queue_id(messageQueueId);
/* 331 */     int i = Query.FCT_MESSAGE_QUEUE_S03().executeQuery((MCRow)bind, (MCRow)result);
/* 332 */     return (i == 0) ? null : result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FCT_MESSAGE_QUEUE_R lockRunningMessage(String messageQueueId) {
/* 345 */     FCT_MESSAGE_QUEUE_R bind = FCT_MESSAGE_QUEUE_R.create();
/* 346 */     FCT_MESSAGE_QUEUE_R result = FCT_MESSAGE_QUEUE_R.create();
/* 347 */     bind.message_queue_id(messageQueueId);
/* 348 */     int i = Query.FCT_MESSAGE_QUEUE_S05().executeQuery((MCRow)bind, (MCRow)result);
/* 349 */     return (i == 0) ? null : result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void updStatus2WaitForReplay(MCList<FCT_MESSAGE_QUEUE_R> bind) {
/* 362 */     Query.FCT_MESSAGE_QUEUE_U03().executeBatchUpdate(bind);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FCT_MESSAGE_QUEUE_R createBindWaitForReplay(String messageQueueId) {
/* 375 */     FCT_MESSAGE_QUEUE_R result = FCT_MESSAGE_QUEUE_R.create();
/* 376 */     result.message_queue_id(messageQueueId);
/* 377 */     result.srv_req_no(null);
/* 378 */     result.status(FCC_MESSAGE_QUEUE_STATUS.WAIT_FOR_REPLAY.value());
/* 379 */     result.start_ts(null);
/* 380 */     result.end_ts(null);
/* 381 */     result.msg_id(null);
/* 382 */     result.msg_lvl(null);
/* 383 */     result.msg_txt(null);
/* 384 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FCT_MESSAGE_QUEUE_R lockMessageNormalOrError(String messageQueueId) {
/* 397 */     FCT_MESSAGE_QUEUE_R bind = FCT_MESSAGE_QUEUE_R.create();
/* 398 */     FCT_MESSAGE_QUEUE_R result = FCT_MESSAGE_QUEUE_R.create();
/* 399 */     bind.message_queue_id(messageQueueId);
/* 400 */     int i = Query.FCT_MESSAGE_QUEUE_S04().executeQuery((MCRow)bind, (MCRow)result);
/* 401 */     return (i == 0) ? null : result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void deleteMessage(MCList<FCT_MESSAGE_QUEUE_R> bind) {
/* 413 */     Query.FCT_MESSAGE_QUEUE_PARAM_D01().executeBatchUpdate(bind);
/* 414 */     Query.FCT_MESSAGE_QUEUE_D01().executeBatchUpdate(bind);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\messagequeue\MCMessageQueue.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */