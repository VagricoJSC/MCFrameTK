/*     */ package mcframe.serverCore.messagequeue;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.stream.Stream;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCBooleanUtil;
/*     */ import mcframe.commonCore.lang.MCDate;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.lang.MCTimestamp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCMQMessage
/*     */ {
/*     */   private final String _consumerId;
/*  37 */   private final Map<String, String> _paramMap = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCMQMessage(String consumerId) {
/*  49 */     MCMessageQueueConfig.getConsumerClass(consumerId);
/*  50 */     this._consumerId = consumerId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMQMessage create(String consumerId) {
/*  64 */     return new MCMQMessage(consumerId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String consumerId() {
/*  76 */     return this._consumerId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addParam(String key, String value) {
/*  93 */     if (MCStringUtil.isNull(key)) {
/*     */       return;
/*     */     }
/*  96 */     this._paramMap.put(key, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Stream<Map.Entry<String, String>> paramStream() {
/* 108 */     return this._paramMap.entrySet().stream();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int paramSize() {
/* 120 */     return this._paramMap.size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addParam(String key, MCNumber value) {
/* 136 */     if (MCStringUtil.isNull(key)) {
/*     */       return;
/*     */     }
/* 139 */     addParam(key, (value != null) ? value.toSimpleString() : null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addParam(String key, MCDate value) {
/* 155 */     if (MCStringUtil.isNull(key)) {
/*     */       return;
/*     */     }
/* 158 */     addParam(key, (value != null) ? value.toString("yyyyMMddHHmmss") : null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addParam(String key, MCTimestamp value) {
/* 174 */     if (MCStringUtil.isNull(key)) {
/*     */       return;
/*     */     }
/* 177 */     addParam(key, 
/* 178 */         (value != null) ? value.toString("yyyyMMddHHmmssSSS") : null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addParam(String key, boolean value) {
/* 194 */     if (MCStringUtil.isNull(key)) {
/*     */       return;
/*     */     }
/* 197 */     addParam(key, MCBooleanUtil.booleanToDBString(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addParam(MCRow row, String... keys) {
/* 218 */     if (row == null || keys == null || keys.length == 0) {
/*     */       return;
/*     */     }
/*     */     
/* 222 */     Arrays.<String>stream(keys).filter(key -> !MCStringUtil.isNull(key))
/*     */       
/* 224 */       .forEach(key -> {
/*     */           Comparable<?> c = paramMCRow.getValueNE(key);
/*     */           if (c == null) {
/*     */             addParam(key, (String)null);
/*     */           } else if (c instanceof String) {
/*     */             addParam(key, (String)c);
/*     */           } else if (c instanceof MCNumber) {
/*     */             addParam(key, (MCNumber)c);
/*     */           } else if (c instanceof MCDate) {
/*     */             addParam(key, (MCDate)c);
/*     */           } else if (c instanceof MCTimestamp) {
/*     */             addParam(key, (MCTimestamp)c);
/*     */           } else if (c instanceof Boolean) {
/*     */             addParam(key, ((Boolean)c).booleanValue());
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeParam(String key) {
/* 260 */     if (MCStringUtil.isNull(key)) {
/*     */       return;
/*     */     }
/* 263 */     this._paramMap.remove(key);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\messagequeue\MCMQMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */