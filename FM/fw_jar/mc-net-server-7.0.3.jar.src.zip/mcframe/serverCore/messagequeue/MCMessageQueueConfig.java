/*     */ package mcframe.serverCore.messagequeue;
/*     */ 
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.serverCore.resource.MCConst;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MCMessageQueueConfig
/*     */ {
/*     */   static String getConsumerModuleIdKey(String consumerId) {
/*  28 */     return MCConst.createKey(new String[] { "messagequeue", "consumer", consumerId, "module_id" });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String getConsumerModuleId(String consumerId) {
/*  41 */     String result = MCConst.plugin.getString(getConsumerModuleIdKey(consumerId), 
/*  42 */         null);
/*  43 */     if (result == null) {
/*  44 */       throw new MCException(Core_Msg_FW_A.FCBMC0001, new Object[] { getConsumerModuleIdKey(consumerId) });
/*     */     }
/*     */     
/*  47 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String getConsumerSubModuleIdKey(String consumerId) {
/*  60 */     return MCConst.createKey(new String[] { "messagequeue", "consumer", consumerId, "sub_module_id" });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String getConsumerSubModuleId(String consumerId) {
/*  73 */     String result = MCConst.plugin.getString(getConsumerSubModuleIdKey(consumerId), 
/*  74 */         null);
/*  75 */     if (result == null) {
/*  76 */       throw new MCException(Core_Msg_FW_A.FCBMC0001, new Object[] { getConsumerSubModuleIdKey(consumerId) });
/*     */     }
/*     */     
/*  79 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String getConsumerLogicIdKey(String consumerId) {
/*  92 */     return MCConst.createKey(new String[] { "messagequeue", "consumer", consumerId, "logic_id" });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String getConsumerLogicId(String consumerId) {
/* 105 */     String result = MCConst.plugin.getString(getConsumerLogicIdKey(consumerId), null);
/* 106 */     if (result == null) {
/* 107 */       throw new MCException(Core_Msg_FW_A.FCBMC0001, new Object[] { getConsumerLogicIdKey(consumerId) });
/*     */     }
/*     */     
/* 110 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String getConsumerClassKey(String consumerId) {
/* 123 */     return MCConst.createKey(new String[] { "messagequeue", "consumer", consumerId, "class" });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String getConsumerClass(String consumerId) {
/* 136 */     String result = MCConst.plugin.getString(getConsumerClassKey(consumerId), null);
/* 137 */     if (result == null) {
/* 138 */       throw new MCException(Core_Msg_FW_A.FCBMC0001, new Object[] { getConsumerClassKey(consumerId) });
/*     */     }
/*     */     
/* 141 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\messagequeue\MCMessageQueueConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */