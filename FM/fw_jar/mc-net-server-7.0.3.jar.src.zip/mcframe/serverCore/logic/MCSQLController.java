/*     */ package mcframe.serverCore.logic;
/*     */ 
/*     */ import mcframe.commonCore.container.MCContainer;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCSQLController
/*     */   extends MCController
/*     */ {
/*     */   private final String sql;
/*     */   public final MCRow up0;
/*     */   public final MCList up1;
/*     */   public final MCList down0;
/*     */   
/*     */   public MCSQLController(String sql, MCRow up0, MCList up1, MCList down0) {
/*  63 */     this.sql = sql;
/*  64 */     this.up0 = up0;
/*  65 */     this.up1 = up1;
/*  66 */     this.down0 = down0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCSQLController(String sql, MCRow up0, MCList down0) {
/*  79 */     this.sql = sql;
/*  80 */     this.up0 = up0;
/*  81 */     this.up1 = null;
/*  82 */     this.down0 = down0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCSQLController(String sql, MCList down0) {
/*  94 */     this.sql = sql;
/*  95 */     this.up0 = null;
/*  96 */     this.up1 = null;
/*  97 */     this.down0 = down0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String sql() {
/* 108 */     return this.sql;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCContainer up(int i) {
/* 122 */     if (i == 0) {
/* 123 */       return (MCContainer)this.up0;
/*     */     }
/* 125 */     if (i == 1) {
/* 126 */       return (MCContainer)this.up1;
/*     */     }
/* 128 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCContainer down(int i) {
/* 142 */     if (i == 0) {
/* 143 */       return (MCContainer)this.down0;
/*     */     }
/* 145 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\logic\MCSQLController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */