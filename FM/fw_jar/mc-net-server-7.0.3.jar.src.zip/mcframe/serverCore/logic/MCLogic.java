package mcframe.serverCore.logic;

import mcframe.commonCore.param.MCOperationInfo;
import mcframe.commonCore.param.MCParam;

public interface MCLogic {
  void init(MCParam paramMCParam);
  
  void destroy();
  
  MCOperationInfo info();
  
  String getModuleID();
  
  String getSubmoduleID();
  
  String getLogicID();
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\logic\MCLogic.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */