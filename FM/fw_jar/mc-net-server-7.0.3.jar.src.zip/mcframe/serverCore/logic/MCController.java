/*    */ package mcframe.serverCore.logic;
/*    */ 
/*    */ import mcframe.commonCore.container.MCContainer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class MCController
/*    */ {
/*    */   public abstract MCContainer up(int paramInt);
/*    */   
/*    */   public abstract MCContainer down(int paramInt);
/*    */   
/*    */   public static <T extends mcframe.serverCore.queryapi.MCDBContainer> MCDBSubOperation<T> create(T dbc) {
/* 47 */     return new MCDBSubOperation<>(dbc);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\logic\MCController.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */