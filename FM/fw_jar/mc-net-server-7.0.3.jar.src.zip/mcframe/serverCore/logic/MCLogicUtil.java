/*     */ package mcframe.serverCore.logic;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import mcframe.commonCore.container.MCContainer;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.notice.MCMessageList;
/*     */ import mcframe.commonCore.param.MCContainerDef;
/*     */ import mcframe.commonCore.param.MCDef;
/*     */ import mcframe.commonCore.param.MCItemDef;
/*     */ import mcframe.commonCore.param.MCOperationInfo;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.commonCore.pio.MCDPReaderFactory;
/*     */ import mcframe.commonCore.pio.MCP2TBodyReader;
/*     */ import mcframe.commonCore.pio.MCP2THeaderReader;
/*     */ import mcframe.commonCore.pio.MCT2PHeaderReader;
/*     */ import mcframe.commonCore.pio.util.MCDPFormat;
/*     */ import mcframe.commonCore.pio.util.MCDPToken;
/*     */ import mcframe.commonCore.pio.util.MCParseTypeUtil;
/*     */ import mcframe.commonCore.requester.MCParamHeaderUtil;
/*     */ import mcframe.commonCore.resource.MCLabelConst;
/*     */ import mcframe.commonCore.resource.MCLocaleConst;
/*     */ import mcframe.commonCore.sys.MCUser;
/*     */ import mcframe.serverCore.mcjdbc.FWDBUtil;
/*     */ import mcframe.serverCore.requester.MCDispatcherContext;
/*     */ import mcframe.serverCore.requester.MCGpBatchRequester;
/*     */ import mcframe.serverCore.requester.MCLogicRefUtil;
/*     */ import mcframe.serverCore.requester.MCRequestHandler;
/*     */ import mcframe.serverCore.requester.MCRequestObject;
/*     */ import mcframe.serverCore.requester.MCUser;
/*     */ import mcframe.serverCore.sys.MCSys;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MCLogicUtil
/*     */ {
/*     */   public static final String REQ_SRC_ID_SEP = "/";
/*  49 */   private static boolean _autotest = Boolean.valueOf(MCSys.env.getVMEnv("autotest")).booleanValue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public static final void invoke(MCLogic lgc) {
/*  60 */     mcframe.serverCore.requester.MCLogicUtil.invoke(lgc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void getDefInfo(MCOperationInfo info, boolean isUp, int block, MCList list, String idCol, String lblCol, String reqCol) {
/*  76 */     MCContainerDef c_def = info.def.getDef(MCDef.toDefId(info.moduleId, info.logicId, 
/*  77 */           info.operationId, isUp, block));
/*  78 */     MCLabelConst lbl = MCLocaleConst.label(MCSys.user.locale(), new Class[] { info.def.getClass() }); byte b; int i; MCItemDef[] arrayOfMCItemDef;
/*  79 */     for (i = (arrayOfMCItemDef = c_def.transItems()).length, b = 0; b < i; ) { MCItemDef i_def = arrayOfMCItemDef[b];
/*  80 */       MCRow r = list.createRow();
/*  81 */       r.setStringNE(idCol, i_def.id);
/*  82 */       if (c_def.block() != null) {
/*  83 */         String label = lbl.getLogicLabel(info.moduleId, info.logicId, 
/*  84 */             info.operationId, (c_def.block()).id, i_def.id);
/*  85 */         r.setStringNE(lblCol, MCStringUtil.isNull(label) ? i_def.id : label);
/*     */       } 
/*  87 */       if (!MCStringUtil.isNull(reqCol)) {
/*  88 */         r.setBooleanNE(reqCol, i_def.required);
/*     */       }
/*  90 */       list.add(r);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMessageList batchInvoke(String moduleId, String logicId, String operationId, String version, MCRow row) {
/*     */     MCParam p;
/*     */     try {
/* 117 */       p = createParam(moduleId, logicId, operationId, version);
/* 118 */       checkContainerParam(p, moduleId, logicId, operationId, version, row);
/* 119 */       initParam(p);
/* 120 */       setupUpParam(p, row);
/* 121 */       if (_autotest) {
/* 122 */         MCParam current = (MCParam)MCRequestObject.object(MCParam.class);
/* 123 */         current.getArgs().forEach((key, value) -> { 
/* 124 */             }); p.getArgs().put("batchInvoke", "1");
/*     */       }
/*     */     
/* 127 */     } catch (Throwable t) {
/* 128 */       throw new MCException(t, Core_Msg_FW_A.FCBGC0138, new Object[] { moduleId, logicId, operationId, version });
/*     */     } 
/* 130 */     return batchInvoke(paramToText(p));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void checkContainerParam(MCParam p, String moduleId, String logicId, String operationId, String version, MCRow row) {
/* 146 */     if (row == null && p.getContainerParam().up().size() == 0) {
/*     */       return;
/*     */     }
/* 149 */     if (row != null && p.getContainerParam().up().size() == 1) {
/*     */       return;
/*     */     }
/* 152 */     throw new MCException(Core_Msg_FW_A.FCBGC0139, new Object[] { moduleId, logicId, operationId, version });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static MCParam createParam(String moduleId, String logicId, String operationId, String version) {
/* 168 */     MCParam p = new MCParam(moduleId, logicId, operationId, version);
/* 169 */     MCLogic lgc = MCLogicRefUtil.crtLgc(p);
/* 170 */     MCLogicRefUtil.initLgcPrm(lgc, p);
/* 171 */     return p;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void initParam(MCParam p) {
/* 182 */     p.setCreatedTime(MCSys.request.createTime());
/* 183 */     MCParamHeaderUtil.toUpHeader(p, MCSys.request.clientId(), 
/* 184 */         MCSys.request.clientRequestNo(), MCSys.request.limitDLSize(), (MCUser)MCSys.user);
/*     */     
/* 186 */     p.setReqSrcId(getReqSrcId(p.getLogicId()));
/*     */     
/* 188 */     p.setOperationHis(MCSys.request.clientOperation());
/*     */     
/* 190 */     p.setOperationAsync(MCSys.request.async());
/*     */   }
/*     */   
/*     */   private static String getReqSrcId(String logic_id) {
/* 194 */     return (MCSys.request.reqSrcId() == null) ? logic_id : (
/* 195 */       String.valueOf(MCSys.request.reqSrcId()) + "/" + logic_id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void setupUpParam(MCParam p, MCRow row) {
/* 208 */     if (row != null) {
/*     */       try {
/* 210 */         MCContainer c = p.getContainerParam().up().get(0);
/* 211 */         if (c instanceof MCRow) {
/* 212 */           MCRow.copyall((MCRow)c, row);
/*     */         }
/* 214 */         else if (c instanceof MCList) {
/* 215 */           ((MCList)c).add(row);
/*     */         }
/*     */       
/* 218 */       } catch (Throwable t) {
/* 219 */         throw new MCException(t, Core_Msg_FW_A.FCBGC0139, new Object[] { p.getModuleId(), p.getLogicId(), 
/* 220 */               p.getOperationId(), p.getVersion() });
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static MCMessageList batchInvoke(String pt) {
/* 234 */     MCRequestHandler hndl = new BatchRequestHandler();
/* 235 */     MCDispatcherContext ctx = parseUpHdr(pt, hndl);
/*     */     
/* 237 */     MCGpBatchRequester req = new MCGpBatchRequester(ctx, hndl, pt);
/* 238 */     req.start();
/*     */     try {
/* 240 */       req.join();
/* 241 */       if (req.getError() != null) {
/* 242 */         throw req.getError();
/*     */       }
/*     */       
/* 245 */       if (!ctx.param().getExceptionParam().isEmpty()) {
/* 246 */         throw ctx.param().getExceptionParam().getExceptionRowParam().getEx();
/*     */       }
/* 248 */       if (_autotest) {
/*     */         try {
/* 250 */           String index = (String)ctx.param().getArgs().get("batchIndex");
/* 251 */           if (index != null)
/*     */           {
/* 253 */             Class<?> c = Class.forName("mcframe.serverCore.servunit.AutoTestParam");
/* 254 */             Object o = MCRequestObject.object(c);
/* 255 */             Method m = c.getMethod("setIndex", new Class[] { Integer.class });
/* 256 */             m.invoke(o, new Object[] { Integer.valueOf(index) });
/*     */           }
/*     */         
/* 259 */         } catch (ClassNotFoundException e) {
/* 260 */           e.printStackTrace();
/* 261 */           throw new MCException(e);
/*     */         } 
/*     */       }
/*     */       
/* 265 */       return ctx.param().getMessageParam().getMessage();
/*     */     }
/* 267 */     catch (Throwable e) {
/* 268 */       MCLog.write(e);
/* 269 */       if (e instanceof Error) {
/* 270 */         throw (Error)e;
/*     */       }
/* 272 */       if (e instanceof MCException) {
/* 273 */         throw (MCException)e;
/*     */       }
/* 275 */       throw new MCException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static MCDispatcherContext parseUpHdr(String up, MCRequestHandler hndl) {
/* 289 */     if (up == null) {
/* 290 */       return null;
/*     */     }
/* 292 */     MCParam p = new MCParam();
/* 293 */     p.setServerId(MCSys.request.serverId());
/* 294 */     p.setServerRequestNo(FWDBUtil.nextRoundReqNo());
/* 295 */     p.setOperationAsync(MCSys.request.async());
/* 296 */     MCDPToken tkn = MCDPToken.create(up);
/* 297 */     MCDPFormat fmt = tkn.getFormat();
/* 298 */     MCT2PHeaderReader hr = MCDPReaderFactory.upHeaderToParam(fmt);
/* 299 */     hr.parse(tkn, p);
/* 300 */     MCDispatcherContext ctx = hndl.crtNewDispatcherContextforGpBatch(p);
/* 301 */     ctx.setUpDPT(tkn);
/* 302 */     return ctx;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String paramToText(MCParam p) {
/* 314 */     MCDPFormat format = MCDPFormat.forClient();
/* 315 */     MCP2THeaderReader hr = MCDPReaderFactory.upHeaderToText(format);
/* 316 */     String hdr = hr.parse(p);
/* 317 */     MCP2TBodyReader br = MCDPReaderFactory.upBodyToText(format, 
/* 318 */         MCParseTypeUtil.getParseType(p));
/* 319 */     String bdy = br.parse(p);
/* 320 */     return String.valueOf(hdr) + bdy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class BatchRequestHandler
/*     */     extends MCRequestHandler
/*     */   {
/*     */     private final MCRow logininfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public BatchRequestHandler() {
/* 345 */       this.logininfo = MCRow.create();
/* 346 */       this.logininfo.setStringNE("co_cd", MCSys.user.coCD());
/* 347 */       this.logininfo.setStringNE("ext_attr1", MCSys.user.extattr1());
/* 348 */       this.logininfo.setStringNE("ext_attr2", MCSys.user.extattr2());
/* 349 */       this.logininfo.setStringNE("ext_attr3", MCSys.user.extattr3());
/* 350 */       this.logininfo.setStringNE("user_nm", MCSys.user.name());
/*     */     }
/*     */ 
/*     */     
/*     */     protected void initUserName(MCParam p) {
/* 355 */       p.setUserName(this.logininfo.getString("user_nm"));
/*     */     }
/*     */ 
/*     */     
/*     */     protected void setUserAttr() {
/* 360 */       MCUser.setLoginInfo(this.logininfo);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\logic\MCLogicUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */