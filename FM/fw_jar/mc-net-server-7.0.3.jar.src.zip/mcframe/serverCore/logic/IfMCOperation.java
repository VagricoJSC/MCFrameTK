package mcframe.serverCore.logic;

public interface IfMCOperation {
  void exec();
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\logic\IfMCOperation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */