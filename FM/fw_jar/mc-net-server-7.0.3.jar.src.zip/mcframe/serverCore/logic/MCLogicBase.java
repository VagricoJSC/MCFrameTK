/*     */ package mcframe.serverCore.logic;
/*     */ 
/*     */ import mcframe.commonCore.notice.Core_Msg;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.param.MCOperationInfo;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.commonCore.sys.MCFactory;
/*     */ import mcframe.serverCore.requester.MCLogicRefUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCLogicBase
/*     */   implements MCLogic
/*     */ {
/*     */   protected MCOperationInfo info;
/*     */   
/*     */   public void init(MCParam param) {}
/*     */   
/*     */   public void destroy() {}
/*     */   
/*     */   public MCOperationInfo info() {
/*  50 */     return this.info;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getModuleID() {
/*  60 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSubmoduleID() {
/*  69 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLogicID() {
/*  78 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends IfMCOperation> T createOperation(String moduleId, String logicId, String operationId, Class<T> clazz) {
/*  99 */     return (T)MCLogicRefUtil.createOperation(moduleId, logicId, 
/* 100 */         operationId, clazz);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends IfMCOperation> T createOperationWD(String moduleId, String logicId, String operationId, Class<T> clazz) {
/*     */     IfMCOperation ifMCOperation;
/* 128 */     T ret = null;
/*     */     try {
/* 130 */       ifMCOperation = MCLogicRefUtil.createOperation(moduleId, logicId, 
/* 131 */           operationId, clazz);
/* 132 */     } catch (MCException ex) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 137 */       if (!Core_Msg.FCBJC0048.equals(ex.getID())) {
/* 138 */         throw ex;
/*     */       }
/*     */     } 
/* 141 */     if (ifMCOperation == null) {
/* 142 */       String m = (String)MCFactory.getFieldValue(clazz, String.class, "DEFAULT_MODULE_ID");
/* 143 */       String l = (String)MCFactory.getFieldValue(clazz, String.class, "DEFAULT_LOGIC_ID");
/* 144 */       String o = (String)MCFactory.getFieldValue(clazz, String.class, "DEFAULT_OPERATION_ID");
/* 145 */       ifMCOperation = MCLogicRefUtil.createOperation(m, l, o, clazz);
/*     */     } 
/* 147 */     return (T)ifMCOperation;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\logic\MCLogicBase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */