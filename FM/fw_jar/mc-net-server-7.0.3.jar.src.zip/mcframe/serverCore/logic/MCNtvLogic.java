/*     */ package mcframe.serverCore.logic;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import mcframe.commonCore.lang.MCTimestamp;
/*     */ import mcframe.commonCore.param.MCDef;
/*     */ import mcframe.commonCore.param.MCOperationInfo;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.serverCore.resource.MCConst;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCNtvLogic
/*     */   implements MCLogic
/*     */ {
/*  30 */   protected int retCd = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String svcName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String upBody;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String dwBody;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String moduleId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String logicId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String operationId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String version;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCDef def;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String createdTime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String serverId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String serverRequestNo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String clientId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String clientRequestNo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String clientLocale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String clientTimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String userId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String loginSequence;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String reqSrcId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String requestTime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String commitTime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int limitDLSize;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String rOperationTyp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String rActionId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 241 */   protected String rLabel = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 248 */   protected Map<String, String> args = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 259 */   private MCParam _param = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 266 */   private MCOperationInfo _opeInfo = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCNtvLogic(MCParam param) {
/* 277 */     this._param = param;
/* 278 */     this._opeInfo = new MCOperationInfo(
/* 279 */         this._param.getModuleId(), 
/* 280 */         this._param.getLogicId(), 
/* 281 */         this._param.getOperationId(), 
/* 282 */         this._param.getVersion(), 
/* 283 */         this._param.getDef());
/* 284 */     writeJNIInfo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUpDP(String up) {
/* 297 */     this.upBody = up;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUpDP() {
/* 310 */     return this.upBody;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDwDP() {
/* 323 */     return this.dwBody;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getServiceName() {
/* 335 */     return this.svcName;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getModuleID() {
/* 340 */     return this.moduleId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSubmoduleID() {
/* 347 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLogicID() {
/* 352 */     return this.logicId;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCOperationInfo info() {
/* 357 */     return this._opeInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init(MCParam param) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeJNIInfo() {
/* 374 */     this.moduleId = this._param.getModuleId();
/* 375 */     this.logicId = this._param.getLogicId();
/* 376 */     this.operationId = this._param.getOperationId();
/* 377 */     this.version = this._param.getVersion();
/* 378 */     this.def = this._param.getDef();
/* 379 */     this.createdTime = (this._param.getCreatedTime() != null) ? 
/* 380 */       this._param.getCreatedTime().toString("yyyyMMddHHmmssSSS") : 
/* 381 */       null;
/* 382 */     this.serverId = this._param.getServerId();
/* 383 */     this.serverRequestNo = this._param.getServerRequestNo();
/* 384 */     this.clientId = this._param.getClientId();
/* 385 */     this.clientRequestNo = this._param.getClientRequestNo();
/* 386 */     this.clientLocale = (this._param.getClientLocale() != null) ? 
/* 387 */       this._param.getClientLocale().toString() : null;
/* 388 */     this.clientTimeZone = (this._param.getClientTimeZone() != null) ? 
/* 389 */       this._param.getClientTimeZone().getID() : null;
/* 390 */     this.userId = this._param.getUserId();
/* 391 */     this.loginSequence = this._param.getLoginSequence();
/* 392 */     this.reqSrcId = this._param.getReqSrcId();
/* 393 */     this.limitDLSize = (this._param.getLimitDLSize() != null) ? 
/* 394 */       this._param.getLimitDLSize().intValue() : -1;
/* 395 */     this.rOperationTyp = this._param.getOperationTypeHis();
/* 396 */     this.rActionId = this._param.getActionIdHis();
/* 397 */     this.rLabel = this._param.getActionLabelHis();
/* 398 */     this.args = (this._param.getArgs() != null) ? 
/* 399 */       new HashMap<>(this._param.getArgs()) : 
/* 400 */       new HashMap<>();
/* 401 */     this.svcName = MCConst.operation.getMethod(this.moduleId, this.logicId, this.operationId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int invoke() {
/* 413 */     this.retCd = invokeOpeJNI();
/* 414 */     return this.retCd;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private native int invokeOpeJNI();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() {
/* 429 */     readJNIInfo();
/*     */     
/* 431 */     this._param = null;
/* 432 */     this._opeInfo = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readJNIInfo() {
/* 442 */     MCTimestamp ts = MCTimestamp.valueOf(this.requestTime, "yyyyMMddHHmmssSSS");
/* 443 */     this._param.setRequestTime(ts);
/* 444 */     this._param.setCommitTime(ts);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\logic\MCNtvLogic.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */