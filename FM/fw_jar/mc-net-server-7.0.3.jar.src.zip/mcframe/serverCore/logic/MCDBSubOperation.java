/*     */ package mcframe.serverCore.logic;
/*     */ 
/*     */ import mcframe.commonCore.container.MCContainer;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.serverCore.queryapi.MCDBContainer;
/*     */ import mcframe.serverCore.queryapi.MCQueryApiBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCDBSubOperation<T extends MCDBContainer>
/*     */   extends MCController
/*     */ {
/*     */   private final MCQueryApiBuilder builder;
/*     */   private final T dbc;
/*     */   public final MCRow up0;
/*     */   public final MCList<T> up1;
/*     */   public final MCList<T> down0;
/*     */   
/*     */   public MCDBSubOperation(T dbc) {
/*  72 */     this.dbc = dbc;
/*  73 */     this.builder = MCQueryApiBuilder.create((MCDBContainer)dbc);
/*  74 */     this.up0 = dbc.createInstance();
/*  75 */     this.up1 = MCList.create((MCRow)dbc);
/*  76 */     this.down0 = MCList.create((MCRow)dbc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCQueryApiBuilder builder() {
/*  87 */     return this.builder;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T dbc() {
/*  98 */     return this.dbc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCContainer up(int i) {
/* 112 */     if (i == 0) {
/* 113 */       return (MCContainer)this.up0;
/*     */     }
/* 115 */     if (i == 1) {
/* 116 */       return (MCContainer)this.up1;
/*     */     }
/* 118 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCContainer down(int i) {
/* 132 */     if (i == 0) {
/* 133 */       return (MCContainer)this.down0;
/*     */     }
/* 135 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\logic\MCDBSubOperation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */