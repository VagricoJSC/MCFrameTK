/*     */ package mcframe.serverCore.logic;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.commonCore.container.MCContainer;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.param.MCOperationInfo;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.serverCore.requester.MCLogicRefUtil;
/*     */ import mcframe.serverCore.requester.MCRequestObject;
/*     */ import mcframe.serverCore.requester.MCRequestStatusImpl;
/*     */ import mcframe.serverCore.requester.MCServerThreadListener;
/*     */ import mcframe.serverCore.requester.MCServerThreadManager;
/*     */ import mcframe.serverCore.sys.MCSys;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MCOperation
/*     */   extends MCController
/*     */   implements IfMCOperation
/*     */ {
/*  40 */   protected final Map<String, List<MCController>> operations = new HashMap<>();
/*     */   
/*  42 */   private boolean _autotest = Boolean.valueOf(MCSys.env.getVMEnv("autotest")).booleanValue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   protected final Set<String> operationGroups = new HashSet<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getGrpNames() {
/*  69 */     return this.operationGroups;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<MCController> getSubOpes(String key) {
/*  82 */     return this.operations.get(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, List<MCController>> getAllSubOpes() {
/*  93 */     return this.operations;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mapUpContainers(String key) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mapDownContainers(String key) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void appendOpeGrp(String grp) {
/* 129 */     this.operationGroups.add(grp);
/* 130 */     if (!this.operations.containsKey(grp)) {
/* 131 */       this.operations.put(grp, new ArrayList<>());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void appendOpe(String grp, MCController ctrl) {
/* 144 */     appendOpeGrp(grp);
/* 145 */     ((List<MCController>)this.operations.get(grp)).add(ctrl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void appendIfOpe(String grp, IfMCOperation ope) {
/* 156 */     appendOpe(grp, (MCController)ope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCOperationInfo getOperationInfo() {
/* 167 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getOperationID() {
/* 178 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void doOpeExec(MCLogic lgc, MCParam p) {
/* 196 */     if (isThreadExec(p)) {
/* 197 */       doThreadExec(lgc, p);
/*     */     } else {
/*     */       
/* 200 */       if (this._autotest) {
/* 201 */         MCParam current = (MCParam)MCRequestObject.object(MCParam.class);
/* 202 */         p.getArgs().forEach((key, value) -> { 
/* 203 */             }); current.getArgs().put("parentModule", p.getModuleId());
/* 204 */         current.getArgs().put("parentLogic", p.getLogicId());
/*     */       } 
/* 206 */       MCLogicRefUtil.invokeOpe(lgc, p);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doThreadExec(MCLogic lgc, MCParam p) {
/* 221 */     lgc.init(p);
/*     */     
/* 223 */     initThreadExec();
/*     */ 
/*     */     
/* 226 */     List<MCOperation> oL = splitParam(lgc, p);
/*     */ 
/*     */     
/* 229 */     invokeThread(oL);
/*     */ 
/*     */     
/* 232 */     setDownParm(p, oL);
/*     */     
/* 234 */     lgc.destroy();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isThreadExec(MCParam p) {
/* 253 */     if (getSplitRowCount() < 1) {
/* 254 */       return false;
/*     */     }
/* 256 */     MCList<? extends MCRow> list = null;
/* 257 */     list = getSplitList(p);
/* 258 */     if (list == null) {
/* 259 */       return false;
/*     */     }
/* 261 */     return (list.size() > getSplitRowCount());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getSplitRowCount() {
/* 277 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected <T extends MCRow> MCList<T> getSplitList(MCParam p) {
/* 291 */     List<MCContainer> contL = p.getContainerParam().up();
/* 292 */     MCList<T> list = null;
/* 293 */     for (int i = 0; i < contL.size(); i++) {
/* 294 */       MCContainer cont = contL.get(i);
/* 295 */       if (cont instanceof MCList) {
/* 296 */         if (list != null) {
/* 297 */           throw new MCException(Core_Msg_FW_A.FCBGC0124, new Object[0]);
/*     */         }
/* 299 */         list = (MCList<T>)cont;
/*     */       } 
/*     */     } 
/* 302 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initThreadExec() {
/* 312 */     MCServerThreadManager.setUseMainDBTran(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected <T extends MCRow> List<MCOperation> splitParam(MCLogic lgc, MCParam p) {
/* 330 */     List<MCOperation> retL = new ArrayList<>();
/*     */     
/* 332 */     List<MCContainer> contL = p.getContainerParam().up();
/* 333 */     List<MCList> list = splitUpListParm(getSplitList(p));
/*     */     
/* 335 */     if (list == null) {
/* 336 */       throw new MCException(Core_Msg_FW_A.FCBGC0125, new Object[0]);
/*     */     }
/*     */     
/* 339 */     for (MCList<T> l : list) {
/* 340 */       MCOperation ret = createInstance(lgc, p);
/* 341 */       for (int i = 0; i < contL.size(); i++) {
/* 342 */         MCContainer cont = contL.get(i);
/* 343 */         if (cont instanceof MCRow) {
/* 344 */           setUpRowParam(i, (MCRow)ret.up(i), (MCRow)cont);
/*     */         } else {
/*     */           
/* 347 */           setUpListParam(i, (MCList<T>)ret.up(i), l);
/*     */         } 
/*     */       } 
/* 350 */       retL.add(ret);
/*     */     } 
/* 352 */     return retL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setUpRowParam(int blockNo, MCRow dest, MCRow src) {
/* 367 */     dest.setValuesByName(src);
/* 368 */     dest.setAttributes(src);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected <T extends MCRow> void setUpListParam(int blockNo, MCList<T> dest, MCList<T> src) {
/* 385 */     dest.addAll((Collection)src);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected <T extends MCRow> List<MCList> splitUpListParm(MCList<T> list) {
/* 400 */     List<MCList> ret = new ArrayList<>();
/* 401 */     int max = getSplitRowCount();
/* 402 */     if (max >= list.size()) {
/* 403 */       ret.add(list);
/* 404 */       return ret;
/*     */     } 
/* 406 */     MCList<T> tmp = list.createInstance();
/* 407 */     int cnt = 1;
/*     */     
/* 409 */     for (int i = 0; i < list.size(); i++) {
/* 410 */       tmp.add(list.get(i));
/* 411 */       if (cnt == max || i == list.size() - 1) {
/* 412 */         MCList<T> l = list.createInstance();
/* 413 */         l.setAll((Collection)tmp);
/* 414 */         ret.add(l);
/*     */         
/* 416 */         tmp.clear();
/* 417 */         cnt = 0;
/*     */       } 
/* 419 */       cnt++;
/*     */     } 
/*     */     
/* 422 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCOperation createInstance(MCLogic lgc, MCParam p) {
/* 435 */     return MCLogicRefUtil.invokeCrtOpe(lgc, p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void invokeThread(List<MCOperation> oL) {
/* 446 */     MCServerThreadManager.invokeAndWait(oL, getServerThreadListener(), new Class[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCServerThreadListener getServerThreadListener() {
/* 459 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected <T extends MCOperation> void setDownParm(MCParam p, List<T> opL) {
/* 474 */     List<MCContainer> contL = p.getContainerParam().down();
/* 475 */     for (MCOperation mCOperation : opL) {
/* 476 */       for (int i = 0; i < contL.size(); i++) {
/* 477 */         MCContainer cont = contL.get(i);
/* 478 */         if (cont instanceof MCRow) {
/* 479 */           setDownRowParam(i, (MCRow)cont, (MCRow)mCOperation.down(i));
/*     */         } else {
/*     */           
/* 482 */           setDownListParam(i, (MCList<MCRow>)cont, (MCList<MCRow>)mCOperation.down(i));
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setDownRowParam(int blockNo, MCRow dest, MCRow src) {
/* 500 */     dest.setValuesByName(src);
/* 501 */     dest.setAttributes(src);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected <T extends MCRow> void setDownListParam(int blockNo, MCList<T> dest, MCList<T> src) {
/* 518 */     dest.addAll((Collection)src);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean registerFile(File... files) {
/* 534 */     return MCRequestStatusImpl.registerFile(files);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean registerFile(String... fileNames) {
/* 548 */     return MCRequestStatusImpl.registerFile(fileNames);
/*     */   }
/*     */   
/*     */   protected abstract void call();
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\logic\MCOperation.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */