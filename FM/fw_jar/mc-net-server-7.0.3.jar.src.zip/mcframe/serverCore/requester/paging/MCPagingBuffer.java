/*     */ package mcframe.serverCore.requester.paging;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import mcframe.commonCore.container.MCContainer;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.container.MCSortPolicy;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.param.MCContainerDef;
/*     */ import mcframe.commonCore.param.MCDef;
/*     */ import mcframe.commonCore.param.MCItemDef;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.commonCore.pio.MCDPReaderFactory;
/*     */ import mcframe.commonCore.pio.MCP2TBodyReader;
/*     */ import mcframe.commonCore.pio.MCP2THeaderReader;
/*     */ import mcframe.commonCore.pio.util.MCDPFormat;
/*     */ import mcframe.commonCore.requester.MCFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCPagingBuffer
/*     */ {
/*     */   private static final int MAX_BUF_SIZE = 1000;
/*     */   private final MCParam pageParam;
/*     */   private final MCList firstPage;
/*     */   private final MCList buf;
/*     */   private final MCSortPolicy sp;
/*     */   private final PageR page;
/*     */   private final int tarBlk;
/*     */   private final int pageSize;
/*     */   private int currentIndex;
/*     */   private boolean isFlushed;
/*     */   
/*     */   public MCPagingBuffer(MCParam param, MCParam decParam) {
/*     */     try {
/*  45 */       MCList<PageR> pages = decParam.getContainerParam().up().get(1);
/*  46 */       PageR page = (PageR)pages.get(0);
/*  47 */       this.tarBlk = page.tar_blk().intValue();
/*  48 */       this.pageSize = page.page_size().intValue();
/*  49 */       this.page = page;
/*  50 */       this.page.cache_id(MCPager.createCacheID(this.tarBlk));
/*  51 */       this.page.total(MCNumber.ZERO);
/*     */ 
/*     */       
/*  54 */       MCList<SortItemR> so = decParam.getContainerParam().up().get(2);
/*  55 */       so = resolveSort(so, param, this.tarBlk);
/*  56 */       this.sp = new MCSortPolicy();
/*  57 */       for (SortItemR r : so) {
/*  58 */         this.sp.add(MCList.SortType.valueOf(r.sort_typ()), r.nm());
/*     */       }
/*     */ 
/*     */       
/*  62 */       this.pageParam = param;
/*  63 */       this.firstPage = param.getContainerParam().down().get(this.tarBlk);
/*  64 */       this.buf = ((MCList)param.getContainerParam().down().get(this.tarBlk)).createInstance();
/*  65 */       this.currentIndex = 0;
/*  66 */       this.isFlushed = false;
/*  67 */       check();
/*     */     }
/*  69 */     catch (Exception e) {
/*  70 */       throw new MCException(e, Core_Msg_FW_A.FCBGC0094, new Object[0]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCList<SortItemR> resolveSort(MCList<SortItemR> sis, MCParam p_tar, int blk) {
/*  82 */     MCList<SortItemR> ret = MCList.create(SortItemR.class);
/*  83 */     if (p_tar == null) {
/*  84 */       return ret;
/*     */     }
/*  86 */     MCDef def = p_tar.getDef();
/*  87 */     MCContainerDef cdef = def.getDef(MCDef.toDefId(p_tar, false, blk));
/*  88 */     if (cdef == null) {
/*  89 */       return ret;
/*     */     }
/*  91 */     MCItemDef[] idefs = cdef.transItems();
/*  92 */     int len = idefs.length;
/*  93 */     int taridx = 0;
/*  94 */     for (SortItemR si : sis) {
/*     */       try {
/*  96 */         taridx = Integer.parseInt(si.nm());
/*  97 */       } catch (NumberFormatException numberFormatException) {
/*     */         break;
/*     */       } 
/* 100 */       if (taridx < 0 || taridx >= len) {
/*     */         break;
/*     */       }
/* 103 */       SortItemR r = SortItemR.create();
/* 104 */       r.nm((idefs[taridx]).id);
/* 105 */       r.sort_typ(si.sort_typ());
/* 106 */       ret.add((MCRow)r);
/*     */     } 
/* 108 */     return ret;
/*     */   }
/*     */   
/*     */   public MCSortPolicy getSortPolicy() {
/* 112 */     return this.sp;
/*     */   }
/*     */   
/*     */   public void append(MCList l) {
/* 116 */     if (this.isFlushed) {
/* 117 */       throw new MCException(Core_Msg_FW_A.FCBGC0095, new Object[0]);
/*     */     }
/*     */ 
/*     */     
/* 121 */     if (this.firstPage.size() < this.pageSize) {
/* 122 */       this.firstPage.addAll((Collection)l);
/*     */     }
/*     */ 
/*     */     
/* 126 */     this.buf.addAll((Collection)l);
/* 127 */     if (this.buf.size() > 1000) {
/* 128 */       save(false);
/*     */     }
/*     */   }
/*     */   
/*     */   public void flush() {
/* 133 */     if (this.isFlushed) {
/* 134 */       throw new MCException(Core_Msg_FW_A.FCBGC0095, new Object[0]);
/*     */     }
/*     */ 
/*     */     
/* 138 */     save(true);
/*     */ 
/*     */     
/* 141 */     MCList tar = this.pageParam.getContainerParam().down().get(this.tarBlk);
/* 142 */     tar.setAll((Collection)this.firstPage.subList(0, this.pageSize));
/* 143 */     this.isFlushed = true;
/*     */   }
/*     */ 
/*     */   
/*     */   private void save(boolean flush) {
/* 148 */     MCDPFormat format = MCDPFormat.forClient();
/* 149 */     MCP2THeaderReader hr = MCDPReaderFactory.downHeaderToText(format);
/* 150 */     MCP2TBodyReader br = MCDPReaderFactory.downBodyToText(format);
/* 151 */     String dir = MCPager.getCacheDir(this.page.cache_id());
/* 152 */     MCFile f = new MCFile();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 157 */     int total = this.buf.size();
/*     */     
/* 159 */     int saveSize = 0;
/* 160 */     int lastIdx = (total - 1) / 500 + 1;
/*     */ 
/*     */     
/* 163 */     for (int i = 0; i < lastIdx; i++) {
/* 164 */       int end, bgn = i * 500;
/*     */       
/* 166 */       if (i == lastIdx - 1) {
/*     */         
/* 168 */         if (flush) {
/* 169 */           end = total;
/*     */         }
/*     */         else {
/*     */           
/* 173 */           this.buf.setAll((Collection)this.buf.subList(bgn, total));
/*     */           
/*     */           break;
/*     */         } 
/*     */       } else {
/* 178 */         end = (i + 1) * 500;
/*     */       } 
/*     */ 
/*     */       
/* 182 */       MCList sub = this.buf.subList(bgn, end);
/* 183 */       this.pageParam.getContainerParam().down().set(this.tarBlk, sub);
/* 184 */       String th = hr.parse(this.pageParam);
/* 185 */       String tb = br.parse(this.pageParam);
/* 186 */       String fName = MCPager.getCacheFile(this.currentIndex);
/* 187 */       f.saveData(String.valueOf(th) + tb, dir, fName);
/* 188 */       saveSize += sub.size();
/*     */       
/* 190 */       this.currentIndex++;
/*     */     } 
/* 192 */     this.page.total(this.page.total().add(saveSize));
/*     */   }
/*     */ 
/*     */   
/*     */   private void check() {
/* 197 */     if (this.tarBlk < 0 || this.pageParam.getContainerParam().down().size() <= this.tarBlk)
/* 198 */       throw new MCException(Core_Msg_FW_A.FCBGC0070, new Object[] {
/* 199 */             String.valueOf(this.pageParam.getModuleId()) + "." + 
/* 200 */             this.pageParam.getLogicId() + "." + 
/* 201 */             this.pageParam.getOperationId(), 
/* 202 */             String.valueOf(this.tarBlk), 
/* 203 */             null
/*     */           }); 
/* 205 */     if (!(this.pageParam.getContainerParam().down().get(this.tarBlk) instanceof MCList))
/* 206 */       throw new MCException(Core_Msg_FW_A.FCBGC0070, new Object[] {
/* 207 */             String.valueOf(this.pageParam.getModuleId()) + "." + 
/* 208 */             this.pageParam.getLogicId() + "." + 
/* 209 */             this.pageParam.getOperationId(), 
/* 210 */             String.valueOf(this.tarBlk), (
/* 211 */             (MCContainer)this.pageParam.getContainerParam().down().get(this.tarBlk))
/* 212 */             .getClass().getName()
/*     */           }); 
/* 214 */     if (this.pageSize < 0)
/* 215 */       throw new MCException(Core_Msg_FW_A.FCBGC1101, new Object[] { String.valueOf(0), 
/* 216 */             String.valueOf(this.pageSize) }); 
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\paging\MCPagingBuffer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */