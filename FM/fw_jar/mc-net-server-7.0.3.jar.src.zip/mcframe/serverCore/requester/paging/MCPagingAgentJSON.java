/*     */ package mcframe.serverCore.requester.paging;
/*     */ 
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.param.MCPagingParam;
/*     */ import mcframe.commonCore.param.MCPagingRowParam;
/*     */ import mcframe.commonCore.param.MCPagingSortParam;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.commonCore.pio.util.MCDPFormat;
/*     */ import mcframe.serverCore.requester.MCDispatcherContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCPagingAgentJSON
/*     */ {
/*     */   public static void paging(MCDispatcherContext ctx) {
/*  32 */     if (!ctx.param().getPagingParam().isEnabled()) {
/*     */       return;
/*     */     }
/*     */     
/*  36 */     if (ctx.param().getPagingParam().isFirst()) {
/*     */       
/*  38 */       doCallPaging(ctx);
/*     */     }
/*     */     else {
/*     */       
/*  42 */       doGetPage(ctx);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void doCallPaging(MCDispatcherContext ctx) {
/*  59 */     MCParam p = ctx.param();
/*     */ 
/*     */     
/*  62 */     MCList<PageR> reqL = MCList.create(PageR.class);
/*  63 */     MCList<SortItemR> sortL = MCList.create(SortItemR.class);
/*  64 */     convSDParam2XAParam(p.getPagingParam(), reqL, sortL);
/*     */     
/*  66 */     MCPager pager = new MCPager(MCDPFormat.JSON);
/*  67 */     MCList<PageR> resL = pager.init(p, reqL, sortL);
/*     */ 
/*     */     
/*  70 */     convXAParam2SDParam(resL, p.getPagingParam());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void doGetPage(MCDispatcherContext ctx) {
/*  83 */     MCParam p = ctx.param();
/*     */ 
/*     */     
/*  86 */     MCList<PageR> reqL = MCList.create(PageR.class);
/*  87 */     convSDParam2XAParam(p.getPagingParam(), reqL, null);
/*     */     
/*  89 */     MCPager pager = new MCPager(MCDPFormat.JSON);
/*  90 */     pager.request(p, reqL);
/*     */ 
/*     */     
/*  93 */     convXAParam2SDParam(reqL, p.getPagingParam());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void convSDParam2XAParam(MCPagingParam p, MCList<PageR> reqL, MCList<SortItemR> sortL) {
/* 108 */     if (reqL != null) {
/* 109 */       for (MCPagingRowParam row : p.getPagingRowParamList()) {
/* 110 */         PageR reqR = (PageR)reqL.createRow();
/* 111 */         reqR.tar_blk(row.getBlockIdx());
/* 112 */         reqR.page_size(row.getPageSize());
/* 113 */         reqR.total(row.getTotalSize());
/* 114 */         reqR.from(convFromIdx4XA(row.getFromIdx()));
/* 115 */         reqR.cache_id(row.getCacheId());
/* 116 */         reqL.add((MCRow)reqR);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 121 */     if (sortL != null) {
/* 122 */       int blkidx = -1;
/* 123 */       int sort_no = -1;
/* 124 */       for (MCPagingSortParam row : p.getPagingSortParamList()) {
/*     */         
/* 126 */         SortItemR sortR = (SortItemR)sortL.createRow();
/* 127 */         if (!row.getBlockIdx().eq(blkidx)) {
/*     */           
/* 129 */           blkidx = row.getBlockIdx().intValue();
/* 130 */           sort_no = 0;
/*     */         } 
/* 132 */         sortR.tar_blk(row.getBlockIdx());
/* 133 */         sortR.sort_no(sort_no++);
/* 134 */         sortR.nm(row.getKey());
/* 135 */         sortR.sort_typ(convSortType(row.getType()));
/* 136 */         sortL.add((MCRow)sortR);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static MCNumber convFromIdx4XA(MCNumber sd) {
/* 152 */     if (sd == null) {
/* 153 */       return null;
/*     */     }
/* 155 */     return sd.subtract(1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String convSortType(MCNumber type) {
/* 167 */     switch (type.intValue()) {
/*     */       case 0:
/* 169 */         return MCList.SortType.ASC.name();
/*     */       case 1:
/* 171 */         return MCList.SortType.DESC.name();
/*     */     } 
/* 173 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void convXAParam2SDParam(MCList<PageR> resL, MCPagingParam p) {
/* 186 */     p.getPagingRowParamList().clear();
/* 187 */     for (PageR resR : resL) {
/* 188 */       MCPagingRowParam row = new MCPagingRowParam();
/* 189 */       row.setBlockIdx(resR.tar_blk());
/* 190 */       row.setPageSize(resR.page_size());
/* 191 */       row.setTotalSize(resR.total());
/* 192 */       row.setFromIdx(convFromIdx4SD(resR.from()));
/* 193 */       row.setCacheId(resR.cache_id());
/* 194 */       p.getPagingRowParamList().add(row);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static MCNumber convFromIdx4SD(MCNumber xa) {
/* 209 */     if (xa == null) {
/* 210 */       return null;
/*     */     }
/* 212 */     return xa.add(1);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\paging\MCPagingAgentJSON.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */