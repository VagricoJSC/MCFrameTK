/*    */ package mcframe.serverCore.requester.paging;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import mcframe.commonCore.annotation.EI;
/*    */ import mcframe.commonCore.container.MCRow;
/*    */ import mcframe.commonCore.lang.MCNumber;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @EI
/*    */ public class PageR
/*    */   extends PageR_FW_A
/*    */ {
/*    */   public static PageR create() {
/* 75 */     PageR row = new PageR(constMetas);
/* 76 */     return row;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static <T extends MCRow> PageR createByName(T proto) {
/* 86 */     PageR row = create();
/* 87 */     copyByName((MCRow)row, (MCRow)proto);
/* 88 */     return row;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public PageR(MCRow.ConstMetaList<? extends PageR> metas) {
/* 95 */     super(metas);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\paging\PageR.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */