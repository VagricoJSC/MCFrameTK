/*     */ package mcframe.serverCore.requester.paging;
/*     */ 
/*     */ import mcframe.commonCore.container.MCContainer;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.param.MCOperationInfo;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.serverCore.logic.MCLogic;
/*     */ import mcframe.serverCore.logic.MCLogicUtil;
/*     */ import mcframe.serverCore.requester.decorator.DecR;
/*     */ import mcframe.serverCore.requester.decorator.MCDecorator;
/*     */ import mcframe.serverCore.requester.decorator.MCDecorator_FW;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MCPagingAgent_FW_A
/*     */   extends MCDecorator
/*     */ {
/*     */   public static final String MODULE_ID = "FC";
/*     */   public static final String SUBMODULE_ID = "FCBG";
/*     */   public static final String LOGIC_ID = "FCBGL2000";
/*     */   protected MCPagingAgent_FW.CallPaging aCallPaging;
/*     */   protected MCPagingAgent_FW.CallBufferPaging aCallBufferPaging;
/*     */   protected MCPagingAgent_FW.GetPage aGetPage;
/*     */   
/*     */   public String getModuleID() {
/*  42 */     return "FC";
/*     */   } public String getSubmoduleID() {
/*  44 */     return "FCBG";
/*     */   } public String getLogicID() {
/*  46 */     return "FCBGL2000";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initCallPaging() {
/*  53 */     this.info = PDef.FC_FCBGL2000_CallPaging_INFO;
/*  54 */     ((MCPagingAgent)this).getClass(); this.aCallPaging = new MCPagingAgent_FW.CallPaging((MCPagingAgent)this);
/*     */   }
/*     */   
/*     */   public static MCPagingAgent_FW.CallPaging crtCallPaging() {
/*  58 */     MCPagingAgent lgc = new MCPagingAgent();
/*  59 */     lgc.initCallPaging();
/*  60 */     return lgc.aCallPaging;
/*     */   }
/*     */   
/*     */   protected void paramCallPaging(MCParam p) {
/*  64 */     if (this.aCallPaging == null) {
/*     */       return;
/*     */     }
/*  67 */     p.setDef(this.info.def);
/*  68 */     p.addUpBlock((MCContainer)this.aCallPaging.up0());
/*  69 */     p.addUpBlock((MCContainer)this.aCallPaging.up1());
/*  70 */     p.addUpBlock((MCContainer)this.aCallPaging.up2());
/*  71 */     p.addDownBlock((MCContainer)this.aCallPaging.down0());
/*  72 */     p.addDownBlock((MCContainer)this.aCallPaging.down1());
/*     */   }
/*     */   
/*     */   protected void doCallPaging() {
/*  76 */     this.aCallPaging.call();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DecR createDecR() {
/*  85 */     return DecR.create();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PageR createPageR() {
/*  94 */     return PageR.create();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCList<PageR> createPageL() {
/* 103 */     return MCList.create(PageR.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SortItemR createSortItemR() {
/* 112 */     return SortItemR.create();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCList<SortItemR> createSortItemL() {
/* 121 */     return MCList.create(SortItemR.class);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initCallBufferPaging() {
/* 126 */     this.info = PDef.FC_FCBGL2000_CallBufferPaging_INFO;
/* 127 */     ((MCPagingAgent)this).getClass(); this.aCallBufferPaging = new MCPagingAgent_FW.CallBufferPaging((MCPagingAgent)this);
/*     */   }
/*     */   
/*     */   public static MCPagingAgent_FW.CallBufferPaging crtCallBufferPaging() {
/* 131 */     MCPagingAgent lgc = new MCPagingAgent();
/* 132 */     lgc.initCallBufferPaging();
/* 133 */     return lgc.aCallBufferPaging;
/*     */   }
/*     */   
/*     */   protected void paramCallBufferPaging(MCParam p) {
/* 137 */     if (this.aCallBufferPaging == null) {
/*     */       return;
/*     */     }
/* 140 */     p.setDef(this.info.def);
/* 141 */     p.addUpBlock((MCContainer)this.aCallBufferPaging.up0());
/* 142 */     p.addUpBlock((MCContainer)this.aCallBufferPaging.up1());
/* 143 */     p.addUpBlock((MCContainer)this.aCallBufferPaging.up2());
/* 144 */     p.addDownBlock((MCContainer)this.aCallBufferPaging.down0());
/* 145 */     p.addDownBlock((MCContainer)this.aCallBufferPaging.down1());
/*     */   }
/*     */   
/*     */   protected void doCallBufferPaging() {
/* 149 */     this.aCallBufferPaging.call();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initGetPage() {
/* 154 */     this.info = PDef.FC_FCBGL2000_GetPage_INFO;
/* 155 */     ((MCPagingAgent)this).getClass(); this.aGetPage = new MCPagingAgent_FW.GetPage((MCPagingAgent)this);
/*     */   }
/*     */   
/*     */   public static MCPagingAgent_FW.GetPage crtGetPage() {
/* 159 */     MCPagingAgent lgc = new MCPagingAgent();
/* 160 */     lgc.initGetPage();
/* 161 */     return lgc.aGetPage;
/*     */   }
/*     */   
/*     */   protected void paramGetPage(MCParam p) {
/* 165 */     if (this.aGetPage == null) {
/*     */       return;
/*     */     }
/* 168 */     p.setDef(this.info.def);
/* 169 */     p.addUpBlock((MCContainer)this.aGetPage.up0());
/* 170 */     p.addUpBlock((MCContainer)this.aGetPage.up1());
/* 171 */     p.addDownBlock((MCContainer)this.aGetPage.down0());
/*     */   }
/*     */   
/*     */   protected void doGetPage() {
/* 175 */     this.aGetPage.call();
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract class CallPaging
/*     */     extends MCDecorator_FW.Decorate
/*     */   {
/*     */     public static final String OPERATION_ID = "CallPaging";
/*     */     
/*     */     private final DecR up0;
/*     */     
/*     */     private final MCList<PageR> up1;
/*     */     
/*     */     private final MCList<SortItemR> up2;
/*     */     
/*     */     private final DecR down0;
/*     */     
/*     */     private final MCList<PageR> down1;
/*     */ 
/*     */     
/*     */     public String getOperationID() {
/* 196 */       return "CallPaging";
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected CallPaging() {
/* 212 */       super((MCDecorator_FW)MCPagingAgent_FW_A.this);
/*     */ 
/*     */       
/* 215 */       this.up0 = DecR.create();
/* 216 */       this.up1 = MCList.create(PageR.class);
/* 217 */       this.up2 = MCList.create(SortItemR.class);
/* 218 */       this.down0 = DecR.create();
/* 219 */       this.down1 = MCList.create(PageR.class);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void mapUpContainers(String key) {
/* 233 */       super.mapUpContainers(key);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void mapDownContainers(String key) {
/* 241 */       super.mapDownContainers(key);
/*     */     }
/*     */     
/*     */     public MCContainer up(int i) {
/* 245 */       if (i == 0) return (MCContainer)up0(); 
/* 246 */       if (i == 1) return (MCContainer)up1(); 
/* 247 */       if (i == 2) return (MCContainer)up2(); 
/* 248 */       return null;
/*     */     }
/*     */     
/*     */     public MCContainer down(int i) {
/* 252 */       if (i == 0) return (MCContainer)down0(); 
/* 253 */       if (i == 1) return (MCContainer)down1(); 
/* 254 */       return null;
/*     */     }
/*     */     
/*     */     public void exec() {
/* 258 */       clear();
/* 259 */       MCLogicUtil.invoke((MCLogic)MCPagingAgent_FW_A.this);
/*     */     }
/*     */     
/*     */     protected void clear() {
/* 263 */       down0().clear();
/* 264 */       down1().clear();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DecR createDecR() {
/* 272 */       return DecR.create();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public PageR createPageR() {
/* 281 */       return PageR.create();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MCList<PageR> createPageL() {
/* 290 */       return MCList.create(PageR.class);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public SortItemR createSortItemR() {
/* 299 */       return SortItemR.create();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MCList<SortItemR> createSortItemL() {
/* 308 */       return MCList.create(SortItemR.class);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DecR up0() {
/* 324 */       return this.up0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MCList<PageR> up1() {
/* 340 */       return this.up1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MCList<SortItemR> up2() {
/* 358 */       return this.up2;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DecR down0() {
/* 374 */       return this.down0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MCList<PageR> down1() {
/* 392 */       return this.down1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MCOperationInfo getOperationInfo() {
/* 399 */       return MCPagingAgent_FW_A.this.info;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract class CallBufferPaging
/*     */     extends MCDecorator_FW.Decorate
/*     */   {
/*     */     public static final String OPERATION_ID = "CallBufferPaging";
/*     */     
/*     */     private final DecR up0;
/*     */     
/*     */     private final MCList<PageR> up1;
/*     */     
/*     */     private final MCList<SortItemR> up2;
/*     */     private final DecR down0;
/*     */     private final MCList<PageR> down1;
/*     */     
/*     */     public String getOperationID() {
/* 418 */       return "CallBufferPaging";
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected CallBufferPaging() {
/* 434 */       super((MCDecorator_FW)MCPagingAgent_FW_A.this);
/*     */ 
/*     */       
/* 437 */       this.up0 = DecR.create();
/* 438 */       this.up1 = MCList.create(PageR.class);
/* 439 */       this.up2 = MCList.create(SortItemR.class);
/* 440 */       this.down0 = DecR.create();
/* 441 */       this.down1 = MCList.create(PageR.class);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void mapUpContainers(String key) {
/* 455 */       super.mapUpContainers(key);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void mapDownContainers(String key) {
/* 463 */       super.mapDownContainers(key);
/*     */     }
/*     */     
/*     */     public MCContainer up(int i) {
/* 467 */       if (i == 0) return (MCContainer)up0(); 
/* 468 */       if (i == 1) return (MCContainer)up1(); 
/* 469 */       if (i == 2) return (MCContainer)up2(); 
/* 470 */       return null;
/*     */     }
/*     */     
/*     */     public MCContainer down(int i) {
/* 474 */       if (i == 0) return (MCContainer)down0(); 
/* 475 */       if (i == 1) return (MCContainer)down1(); 
/* 476 */       return null;
/*     */     }
/*     */     
/*     */     public void exec() {
/* 480 */       clear();
/* 481 */       MCLogicUtil.invoke((MCLogic)MCPagingAgent_FW_A.this);
/*     */     }
/*     */     
/*     */     protected void clear() {
/* 485 */       down0().clear();
/* 486 */       down1().clear();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DecR createDecR() {
/* 494 */       return DecR.create();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public PageR createPageR() {
/* 503 */       return PageR.create();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MCList<PageR> createPageL() {
/* 512 */       return MCList.create(PageR.class);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public SortItemR createSortItemR() {
/* 521 */       return SortItemR.create();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MCList<SortItemR> createSortItemL() {
/* 530 */       return MCList.create(SortItemR.class);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DecR up0() {
/* 546 */       return this.up0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MCList<PageR> up1() {
/* 562 */       return this.up1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MCList<SortItemR> up2() {
/* 580 */       return this.up2;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DecR down0() {
/* 596 */       return this.down0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MCList<PageR> down1() {
/* 614 */       return this.down1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MCOperationInfo getOperationInfo() {
/* 621 */       return MCPagingAgent_FW_A.this.info;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract class GetPage
/*     */     extends MCDecorator_FW.Decorate
/*     */   {
/*     */     public static final String OPERATION_ID = "GetPage";
/*     */     
/*     */     private final DecR up0;
/*     */     
/*     */     private final MCList<PageR> up1;
/*     */     
/*     */     private final DecR down0;
/*     */ 
/*     */     
/*     */     public String getOperationID() {
/* 640 */       return "GetPage";
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected GetPage() {
/* 652 */       super((MCDecorator_FW)MCPagingAgent_FW_A.this);
/*     */ 
/*     */       
/* 655 */       this.up0 = DecR.create();
/* 656 */       this.up1 = MCList.create(PageR.class);
/* 657 */       this.down0 = DecR.create();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void mapUpContainers(String key) {
/* 671 */       super.mapUpContainers(key);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void mapDownContainers(String key) {
/* 679 */       super.mapDownContainers(key);
/*     */     }
/*     */     
/*     */     public MCContainer up(int i) {
/* 683 */       if (i == 0) return (MCContainer)up0(); 
/* 684 */       if (i == 1) return (MCContainer)up1(); 
/* 685 */       return null;
/*     */     }
/*     */     
/*     */     public MCContainer down(int i) {
/* 689 */       if (i == 0) return (MCContainer)down0(); 
/* 690 */       return null;
/*     */     }
/*     */     
/*     */     public void exec() {
/* 694 */       clear();
/* 695 */       MCLogicUtil.invoke((MCLogic)MCPagingAgent_FW_A.this);
/*     */     }
/*     */     
/*     */     protected void clear() {
/* 699 */       down0().clear();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DecR createDecR() {
/* 707 */       return DecR.create();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public PageR createPageR() {
/* 716 */       return PageR.create();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MCList<PageR> createPageL() {
/* 725 */       return MCList.create(PageR.class);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DecR up0() {
/* 741 */       return this.up0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MCList<PageR> up1() {
/* 759 */       return this.up1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DecR down0() {
/* 775 */       return this.down0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MCOperationInfo getOperationInfo() {
/* 782 */       return MCPagingAgent_FW_A.this.info;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\paging\MCPagingAgent_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */