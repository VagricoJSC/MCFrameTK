/*     */ package mcframe.serverCore.requester.paging;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.param.MCDPWriter;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.commonCore.pio.MCDPReaderFactory;
/*     */ import mcframe.commonCore.pio.MCP2TBodyReader;
/*     */ import mcframe.commonCore.pio.MCP2THeaderReader;
/*     */ import mcframe.commonCore.pio.util.MCDPFormat;
/*     */ import mcframe.serverCore.logic.MCLogic;
/*     */ import mcframe.serverCore.requester.MCDispatcherContext;
/*     */ import mcframe.serverCore.requester.MCLogicRefUtil;
/*     */ import mcframe.serverCore.requester.decorator.MCDecorator_FW;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MCPagingAgent_FW
/*     */   extends MCPagingAgent_FW_A
/*     */ {
/*     */   protected static final int ROLL_SIZE = 500;
/*     */   
/*     */   public static boolean isPagingOperation(MCParam p) {
/*  50 */     return ("FC".equals(p.getModuleId()) && 
/*  51 */       "FCBGL2000".equals(p.getLogicId()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class CallPaging
/*     */     extends MCPagingAgent_FW_A.CallPaging
/*     */   {
/*     */     private String down;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CallPaging()
/*     */     {
/*  71 */       this.down = null;
/*     */     }
/*     */     
/*     */     protected void decorate(MCDispatcherContext ctx) {
/*  75 */       super.decorate(ctx);
/*     */ 
/*     */       
/*  78 */       if (!ctx.param().getExceptionParam().isEmpty()) {
/*  79 */         this.down = MCPagingAgent_FW.this.parseDw(ctx, ctx.param());
/*     */       
/*     */       }
/*     */       else {
/*     */         
/*  84 */         MCPager pager = new MCPager(MCDPFormat.MCDP);
/*  85 */         MCList<PageR> pageL = pager.init(ctx.param(), up1(), up2());
/*  86 */         down1().addAll((Collection)pageL);
/*     */ 
/*     */         
/*  89 */         this.down = MCPagingAgent_FW.this.parseDw(ctx, ctx.param());
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected String decorateDown(String down) {
/*  96 */       return this.down;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void call() {
/*     */       String down = callDecorate(up0().denbun());
/*     */       down0().denbun(down);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public class GetPage
/*     */     extends MCPagingAgent_FW_A.GetPage
/*     */   {
/*     */     private String down;
/*     */ 
/*     */ 
/*     */     
/*     */     public GetPage() {
/* 118 */       this.down = null;
/*     */     }
/*     */ 
/*     */     
/*     */     protected void call() {
/*     */       String down = callDecorate(up0().denbun());
/*     */       down0().denbun(down);
/*     */     }
/*     */     
/*     */     protected void decorate(MCDispatcherContext ctx) {
/* 128 */       MCPagingAgent_FW.this.logger.writeUpLog(ctx, this.decoratedUp);
/*     */       
/* 130 */       MCParam p = ctx.param();
/* 131 */       MCLogic lgc = MCLogicRefUtil.crtLgc(p);
/* 132 */       MCLogicRefUtil.initLgcPrm(lgc, p);
/*     */ 
/*     */ 
/*     */       
/* 136 */       MCPager pager = new MCPager(MCDPFormat.MCDP);
/* 137 */       pager.request(p, up1());
/*     */ 
/*     */       
/* 140 */       this.down = MCPagingAgent_FW.this.parseDw(ctx, p);
/*     */     }
/*     */     
/*     */     protected void setRequestStatus(MCDispatcherContext ctx, MCDPWriter dwdpw) {}
/*     */     
/*     */     protected String decorateDown(String down) {
/* 146 */       return this.down;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String parseDw(MCDispatcherContext ctx, MCParam p) {
/* 164 */     String down = parseDw(p);
/*     */     
/* 166 */     ctx.setErr(false);
/* 167 */     return down;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String parseDw(MCParam p) {
/* 179 */     MCDPFormat format = MCDPFormat.forClient();
/* 180 */     MCP2THeaderReader hr = MCDPReaderFactory.downHeaderToText(format);
/* 181 */     String th = hr.parse(p);
/* 182 */     MCP2TBodyReader br = MCDPReaderFactory.downBodyToText(format);
/* 183 */     String tb = br.parse(p);
/* 184 */     return String.valueOf(th) + tb;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class CallBufferPaging
/*     */     extends MCPagingAgent_FW_A.CallBufferPaging
/*     */   {
/*     */     protected void call() {
/* 196 */       String down = callDecorate(up0().denbun());
/* 197 */       down0().denbun(down);
/* 198 */       setRslt();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void setRslt() {
/* 208 */       down1().setAll((Collection)up1());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\paging\MCPagingAgent_FW.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */