/*     */ package mcframe.serverCore.requester.paging;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import mcframe.commonCore.container.MCContainer;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.container.MCSortPolicy;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCMessageList;
/*     */ import mcframe.commonCore.param.MCContainerDef;
/*     */ import mcframe.commonCore.param.MCDef;
/*     */ import mcframe.commonCore.param.MCItemDef;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.commonCore.pio.MCDPReaderFactory;
/*     */ import mcframe.commonCore.pio.MCP2TBodyReader;
/*     */ import mcframe.commonCore.pio.MCP2THeaderReader;
/*     */ import mcframe.commonCore.pio.MCT2PBodyReader;
/*     */ import mcframe.commonCore.pio.MCT2PHeaderReader;
/*     */ import mcframe.commonCore.pio.util.MCDPFormat;
/*     */ import mcframe.commonCore.pio.util.MCDPToken;
/*     */ import mcframe.commonCore.requester.MCFile;
/*     */ import mcframe.serverCore.requester.MCCapAgent;
/*     */ import mcframe.serverCore.resource.MCConfig;
/*     */ import mcframe.serverCore.sys.MCSys;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MCPager
/*     */ {
/*     */   static final int ROLL_SIZE = 500;
/*     */   private final MCDPFormat _fmt;
/*     */   
/*     */   static String createCacheID(int tarblk) {
/*  54 */     return String.valueOf(MCSys.request.clientRequestNo()) + "_" + MCSys.request.serverRequestNo() + 
/*  55 */       tarblk;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String getCacheDir(String id) {
/*  67 */     String home = MCConfig.server.getString("net.paging.dir");
/*  68 */     return String.valueOf(home) + MCFile.PATH_SEP + id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String getCacheFile(int idx) {
/*  80 */     return "cache_" + String.valueOf(idx);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCPager(MCDPFormat fmt) {
/*  98 */     this._fmt = fmt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCList<PageR> init(MCParam p, MCList<PageR> reqL, MCList<SortItemR> sortL) {
/* 113 */     MCList<PageR> resL = MCList.create(PageR.class);
/*     */ 
/*     */     
/* 116 */     List<MCContainer> paramDown = p.getContainerParam().down();
/*     */ 
/*     */     
/* 119 */     List<MCContainer> defDown = new ArrayList<>(paramDown.size());
/* 120 */     defDown.addAll(paramDown);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 125 */     List<MCContainer> emptyDown = new ArrayList<>(paramDown.size());
/* 126 */     for (MCContainer c : paramDown) {
/* 127 */       if (c instanceof MCRow) {
/* 128 */         emptyDown.add(((MCRow)c).createInstance()); continue;
/*     */       } 
/* 130 */       if (c instanceof MCList) {
/* 131 */         emptyDown.add(((MCList)c).createInstance());
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 138 */     for (PageR reqR : reqL) {
/* 139 */       PageR resR = PageR.create();
/* 140 */       int tarSize = 0;
/* 141 */       int tarblk = reqR.tar_blk().intValue();
/* 142 */       int pageSize = reqR.page_size().intValue();
/*     */       
/* 144 */       check(p, tarblk, pageSize, 0);
/*     */ 
/*     */       
/* 147 */       MCList<?> tar = (MCList)defDown.get(tarblk);
/*     */ 
/*     */       
/* 150 */       if (sortL != null && sortL.size() > 0) {
/* 151 */         MCList<SortItemR> so = resolveSort(sortL, p, tarblk);
/* 152 */         sort(so, tar);
/*     */       } 
/*     */       
/* 155 */       tarSize = tar.size();
/* 156 */       resR.total(tarSize);
/* 157 */       resR.tar_blk(reqR.tar_blk());
/* 158 */       resR.page_size(reqR.page_size());
/* 159 */       resR.from(reqR.from());
/* 160 */       resL.add((MCRow)resR);
/* 161 */       if (tarSize > pageSize) {
/*     */ 
/*     */         
/* 164 */         int to = reqR.page_size().intValue();
/* 165 */         MCList<?> current = tar.subList(0, to);
/*     */ 
/*     */         
/* 168 */         String id = createCacheID(tarblk);
/* 169 */         resR.cache_id(id);
/*     */ 
/*     */         
/* 172 */         savePagedFiles(id, tarSize, tar, tarblk, p, emptyDown);
/*     */ 
/*     */         
/* 175 */         MCContainer tc = defDown.get(tarblk);
/* 176 */         ((MCList)tc).setAll((Collection)current);
/*     */       } 
/*     */     } 
/*     */     
/* 180 */     paramDown.clear();
/* 181 */     paramDown.addAll(defDown);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 186 */     checkOverCap(p);
/*     */     
/* 188 */     return resL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void request(MCParam p, MCList<PageR> reqL) {
/* 200 */     MCFile ioUtil = new MCFile();
/*     */ 
/*     */     
/* 203 */     List<MCContainer> paramDown = p.getContainerParam().down();
/*     */ 
/*     */     
/* 206 */     List<MCContainer> defDown = new ArrayList<>(paramDown.size());
/* 207 */     defDown.addAll(paramDown);
/*     */     
/* 209 */     for (PageR reqR : reqL) {
/*     */       
/* 211 */       int tarblk = reqR.tar_blk().intValue();
/* 212 */       int from = reqR.from().intValue();
/* 213 */       int page_size = reqR.page_size().intValue();
/* 214 */       int rest = page_size;
/*     */       
/* 216 */       check(p, tarblk, page_size, from);
/*     */       
/* 218 */       int f_st = from / 500;
/* 219 */       int f_row_st = from % 500;
/*     */ 
/*     */       
/* 222 */       MCList<MCRow> cache = ((MCList)p.getContainerParam()
/* 223 */         .getDownBlock(tarblk)).createInstance();
/*     */       
/* 225 */       int f_i = f_st;
/*     */       
/* 227 */       for (; rest > 0; f_i++) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 232 */         if (f_i != f_st) {
/* 233 */           f_row_st = 0;
/*     */         }
/*     */ 
/*     */         
/* 237 */         String dp = getTargetDP(ioUtil, reqR.cache_id(), getCacheFile(f_i));
/* 238 */         if (dp == null) {
/*     */           break;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 244 */         parseDwText(dp, p);
/*     */ 
/*     */         
/* 247 */         MCList<?> tgt = (MCList)p.getContainerParam().getDownBlock(tarblk);
/* 248 */         int f_row_end = f_row_st + rest;
/* 249 */         if (f_row_end > tgt.size()) {
/* 250 */           f_row_end = tgt.size();
/*     */         }
/* 252 */         tgt = tgt.subList(f_row_st, f_row_end);
/*     */ 
/*     */         
/* 255 */         cache.addAll((Collection)tgt);
/* 256 */         rest -= tgt.size();
/*     */       } 
/*     */       
/* 259 */       MCContainer tc = defDown.get(tarblk);
/* 260 */       ((MCList)tc).setAll((Collection)cache);
/*     */     } 
/* 262 */     paramDown.clear();
/* 263 */     paramDown.addAll(defDown);
/*     */ 
/*     */     
/* 266 */     checkOverCap(p);
/*     */   }
/*     */ 
/*     */   
/*     */   private String getTargetDP(MCFile ioUtil, String cache_id, String fName) {
/*     */     try {
/* 272 */       return ioUtil.loadData(getCacheDir(cache_id), fName);
/*     */     }
/* 274 */     catch (MCException e) {
/* 275 */       if (e.getID().equals(Core_Msg_FW_A.FCBGC0065)) {
/* 276 */         return null;
/*     */       }
/*     */       
/* 279 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void check(MCParam p, int tarblk, int size, int from) {
/* 296 */     if (tarblk < 0 || p.getContainerParam().down().size() <= tarblk) {
/* 297 */       throw new MCException(Core_Msg_FW_A.FCBGC0070, new Object[] { String.valueOf(p.getModuleId()) + "." + p.getLogicId() + "." + 
/* 298 */             p.getOperationId(), String.valueOf(tarblk), null });
/*     */     }
/*     */     
/* 301 */     if (!(p.getContainerParam().down().get(tarblk) instanceof MCList)) {
/* 302 */       throw new MCException(Core_Msg_FW_A.FCBGC0070, new Object[] { String.valueOf(p.getModuleId()) + "." + p.getLogicId() + "." + 
/* 303 */             p.getOperationId(), String.valueOf(tarblk), ((MCContainer)p.getContainerParam()
/* 304 */             .down().get(tarblk)).getClass().getName() });
/*     */     }
/*     */     
/* 307 */     if (from < 0 || size < 0) {
/* 308 */       throw new MCException(Core_Msg_FW_A.FCBGC1101, new Object[] { String.valueOf(from), String.valueOf(from + 
/* 309 */               size) });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkOverCap(MCParam param) {
/* 324 */     if (MCCapAgent.capacityCheckParam(param)) {
/* 325 */       MCMessageList msglist = new MCMessageList();
/* 326 */       MCCapAgent agnt = new MCCapAgent(param, msglist);
/* 327 */       agnt.parse();
/* 328 */       param.getMessageParam().setMessage(msglist);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void savePagedFiles(String id, int total, MCList<?> tar, int tarblk, MCParam p, List<MCContainer> emptyDown) {
/* 348 */     String dir = getCacheDir(id);
/* 349 */     MCFile f = new MCFile();
/*     */     
/* 351 */     int lastIdx = (total - 1) / 500 + 1;
/* 352 */     int bgn = 0;
/* 353 */     int end = 0;
/* 354 */     for (int i = 0; i < lastIdx; i++) {
/* 355 */       bgn = i * 500;
/* 356 */       if (i == lastIdx - 1) {
/* 357 */         end = total;
/*     */       } else {
/*     */         
/* 360 */         end = (i + 1) * 500;
/*     */       } 
/*     */ 
/*     */       
/* 364 */       MCList<?> page = tar.subList(bgn, end);
/* 365 */       List<MCContainer> paramDown = p.getContainerParam().down();
/* 366 */       emptyDown.set(tarblk, page);
/* 367 */       paramDown.clear();
/* 368 */       paramDown.addAll(emptyDown);
/*     */       
/* 370 */       String pagedDw = parseDwParam(p);
/* 371 */       String fName = getCacheFile(i);
/* 372 */       f.saveData(pagedDw, dir, fName);
/* 373 */       page.clear();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String parseDwParam(MCParam p) {
/* 387 */     MCP2THeaderReader hr = MCDPReaderFactory.downHeaderToText(this._fmt);
/* 388 */     String th = hr.parse(p);
/* 389 */     MCP2TBodyReader br = MCDPReaderFactory.downBodyToText(this._fmt);
/* 390 */     String tb = br.parse(p);
/* 391 */     return String.valueOf(th) + tb;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseDwText(String t, MCParam p) {
/* 403 */     MCDPToken tkn = MCDPToken.create(t);
/* 404 */     MCT2PHeaderReader hr = MCDPReaderFactory.downHeaderToParam(this._fmt);
/* 405 */     MCT2PBodyReader br = MCDPReaderFactory.downBodyToParam(this._fmt);
/* 406 */     hr.parse(tkn, p);
/* 407 */     br.parse(tkn, p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCList<SortItemR> resolveSort(MCList<SortItemR> sis, MCParam p_tar, int blk) {
/* 421 */     MCList<SortItemR> ret = MCList.create(SortItemR.class);
/* 422 */     if (p_tar == null) {
/* 423 */       return ret;
/*     */     }
/* 425 */     MCDef def = p_tar.getDef();
/* 426 */     MCContainerDef cdef = def.getDef(MCDef.toDefId(p_tar, false, blk));
/* 427 */     if (cdef == null) {
/* 428 */       return ret;
/*     */     }
/* 430 */     MCItemDef[] idefs = cdef.transItems();
/* 431 */     int len = idefs.length;
/* 432 */     int taridx = 0;
/* 433 */     for (SortItemR si : sis.subList("tar_blk", (Comparable)MCNumber.valueOf(blk))) {
/* 434 */       String nm = si.nm();
/*     */       try {
/* 436 */         taridx = Integer.parseInt(si.nm());
/* 437 */         if (taridx < 0 || taridx >= len) {
/*     */           break;
/*     */         }
/* 440 */         nm = (idefs[taridx]).id;
/*     */       }
/* 442 */       catch (NumberFormatException numberFormatException) {}
/*     */ 
/*     */ 
/*     */       
/* 446 */       SortItemR r = SortItemR.create();
/* 447 */       r.sort_no(si.sort_no());
/* 448 */       r.nm(nm);
/* 449 */       r.sort_typ(si.sort_typ());
/* 450 */       ret.add((MCRow)r);
/*     */     } 
/* 452 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void sort(MCList<SortItemR> so, MCList<?> tar) {
/* 464 */     MCSortPolicy p = new MCSortPolicy();
/* 465 */     so.sort(new String[] { "sort_no" });
/* 466 */     for (SortItemR r : so) {
/* 467 */       p.add(MCList.SortType.valueOf(r.sort_typ()), r.nm());
/*     */     }
/* 469 */     tar.sort(p);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\paging\MCPager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */