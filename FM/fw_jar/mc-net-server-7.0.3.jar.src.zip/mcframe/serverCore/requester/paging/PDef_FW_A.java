/*     */ package mcframe.serverCore.requester.paging;
/*     */ 
/*     */ import mcframe.commonCore.param.MCBlockDef;
/*     */ import mcframe.commonCore.param.MCContainerDef;
/*     */ import mcframe.commonCore.param.MCDef;
/*     */ import mcframe.commonCore.param.MCGeneralContainerDef;
/*     */ import mcframe.commonCore.param.MCItemDef;
/*     */ import mcframe.commonCore.param.MCOperationInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PDef_FW_A
/*     */   extends MCDef
/*     */ {
/*     */   public MCContainerDef getCustomDef(String id) {
/*  22 */     if (id == null) {
/*  23 */       return null;
/*     */     }
/*     */     
/*  26 */     if (id.equals("FC.FCBGL2000.CallPaging.UP.BLOCK0")) {
/*  27 */       return FC_FCBGL2000_CallPaging_UP_BLOCK0();
/*     */     }
/*  29 */     if (id.equals("FC.FCBGL2000.CallPaging.UP.BLOCK1")) {
/*  30 */       return FC_FCBGL2000_CallPaging_UP_BLOCK1();
/*     */     }
/*  32 */     if (id.equals("FC.FCBGL2000.CallPaging.UP.BLOCK2")) {
/*  33 */       return FC_FCBGL2000_CallPaging_UP_BLOCK2();
/*     */     }
/*  35 */     if (id.equals("FC.FCBGL2000.CallPaging.DOWN.BLOCK0")) {
/*  36 */       return FC_FCBGL2000_CallPaging_DOWN_BLOCK0();
/*     */     }
/*  38 */     if (id.equals("FC.FCBGL2000.CallPaging.DOWN.BLOCK1")) {
/*  39 */       return FC_FCBGL2000_CallPaging_DOWN_BLOCK1();
/*     */     }
/*  41 */     if (id.equals("FC.FCBGL2000.CallBufferPaging.UP.BLOCK0")) {
/*  42 */       return FC_FCBGL2000_CallBufferPaging_UP_BLOCK0();
/*     */     }
/*  44 */     if (id.equals("FC.FCBGL2000.CallBufferPaging.UP.BLOCK1")) {
/*  45 */       return FC_FCBGL2000_CallBufferPaging_UP_BLOCK1();
/*     */     }
/*  47 */     if (id.equals("FC.FCBGL2000.CallBufferPaging.UP.BLOCK2")) {
/*  48 */       return FC_FCBGL2000_CallBufferPaging_UP_BLOCK2();
/*     */     }
/*  50 */     if (id.equals("FC.FCBGL2000.CallBufferPaging.DOWN.BLOCK0")) {
/*  51 */       return FC_FCBGL2000_CallBufferPaging_DOWN_BLOCK0();
/*     */     }
/*  53 */     if (id.equals("FC.FCBGL2000.CallBufferPaging.DOWN.BLOCK1")) {
/*  54 */       return FC_FCBGL2000_CallBufferPaging_DOWN_BLOCK1();
/*     */     }
/*  56 */     if (id.equals("FC.FCBGL2000.GetPage.UP.BLOCK0")) {
/*  57 */       return FC_FCBGL2000_GetPage_UP_BLOCK0();
/*     */     }
/*  59 */     if (id.equals("FC.FCBGL2000.GetPage.UP.BLOCK1")) {
/*  60 */       return FC_FCBGL2000_GetPage_UP_BLOCK1();
/*     */     }
/*  62 */     if (id.equals("FC.FCBGL2000.GetPage.DOWN.BLOCK0")) {
/*  63 */       return FC_FCBGL2000_GetPage_DOWN_BLOCK0();
/*     */     }
/*     */ 
/*     */     
/*  67 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   static final MCOperationInfo FC_FCBGL2000_CallPaging_INFO = new MCOperationInfo("FC", "FCBGL2000", "CallPaging", "000000", new PDef());
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL2000_CallPaging_UP_BLOCK0() {
/*  77 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL2000", "CallPaging", 
/*  78 */         new MCItemDef[] {
/*  79 */           MCItemDef.create("denbun", true, "denbun")
/*     */ 
/*     */         
/*  82 */         }MCBlockDef.create("Dec"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL2000_CallPaging_UP_BLOCK1() {
/*  88 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL2000", "CallPaging", 
/*  89 */         new MCItemDef[] {
/*  90 */           MCItemDef.create("tar_blk", "tar_blk"), 
/*  91 */           MCItemDef.create("page_size", "page_size")
/*     */ 
/*     */         
/*  94 */         }MCBlockDef.create("Page"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL2000_CallPaging_UP_BLOCK2() {
/* 100 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL2000", "CallPaging", 
/* 101 */         new MCItemDef[] {
/* 102 */           MCItemDef.create("tar_blk", "tar_blk"), 
/* 103 */           MCItemDef.create("sort_no", "sort_no"), 
/* 104 */           MCItemDef.create("nm", "nm"), 
/* 105 */           MCItemDef.create("sort_typ", "sort_typ")
/*     */ 
/*     */         
/* 108 */         }MCBlockDef.create("SortItem"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL2000_CallPaging_DOWN_BLOCK0() {
/* 115 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL2000", "CallPaging", 
/* 116 */         new MCItemDef[] {
/* 117 */           MCItemDef.create("denbun", true, "denbun")
/*     */ 
/*     */         
/* 120 */         }MCBlockDef.create("Dec"));
/*     */   }
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL2000_CallPaging_DOWN_BLOCK1() {
/* 125 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL2000", "CallPaging", 
/* 126 */         new MCItemDef[] {
/* 127 */           MCItemDef.create("tar_blk", "tar_blk"), 
/* 128 */           MCItemDef.create("page_size", "page_size"), 
/* 129 */           MCItemDef.create("total", "total"), 
/* 130 */           MCItemDef.create("cache_id", "cache_id")
/*     */ 
/*     */         
/* 133 */         }MCBlockDef.create("Page"));
/*     */   }
/*     */ 
/*     */   
/* 137 */   static final MCOperationInfo FC_FCBGL2000_CallBufferPaging_INFO = new MCOperationInfo("FC", "FCBGL2000", "CallBufferPaging", "000000", new PDef());
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL2000_CallBufferPaging_UP_BLOCK0() {
/* 141 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL2000", "CallBufferPaging", 
/* 142 */         new MCItemDef[] {
/* 143 */           MCItemDef.create("denbun", true, "denbun")
/*     */ 
/*     */         
/* 146 */         }MCBlockDef.create("Dec"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL2000_CallBufferPaging_UP_BLOCK1() {
/* 152 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL2000", "CallBufferPaging", 
/* 153 */         new MCItemDef[] {
/* 154 */           MCItemDef.create("tar_blk", "tar_blk"), 
/* 155 */           MCItemDef.create("page_size", "page_size")
/*     */ 
/*     */         
/* 158 */         }MCBlockDef.create("Page"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL2000_CallBufferPaging_UP_BLOCK2() {
/* 164 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL2000", "CallBufferPaging", 
/* 165 */         new MCItemDef[] {
/* 166 */           MCItemDef.create("tar_blk", "tar_blk"), 
/* 167 */           MCItemDef.create("sort_no", "sort_no"), 
/* 168 */           MCItemDef.create("nm", "nm"), 
/* 169 */           MCItemDef.create("sort_typ", "sort_typ")
/*     */ 
/*     */         
/* 172 */         }MCBlockDef.create("SortItem"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL2000_CallBufferPaging_DOWN_BLOCK0() {
/* 179 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL2000", "CallBufferPaging", 
/* 180 */         new MCItemDef[] {
/* 181 */           MCItemDef.create("denbun", true, "denbun")
/*     */ 
/*     */         
/* 184 */         }MCBlockDef.create("Dec"));
/*     */   }
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL2000_CallBufferPaging_DOWN_BLOCK1() {
/* 189 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL2000", "CallBufferPaging", 
/* 190 */         new MCItemDef[] {
/* 191 */           MCItemDef.create("tar_blk", "tar_blk"), 
/* 192 */           MCItemDef.create("page_size", "page_size"), 
/* 193 */           MCItemDef.create("total", "total"), 
/* 194 */           MCItemDef.create("cache_id", "cache_id")
/*     */ 
/*     */         
/* 197 */         }MCBlockDef.create("Page"));
/*     */   }
/*     */ 
/*     */   
/* 201 */   static final MCOperationInfo FC_FCBGL2000_GetPage_INFO = new MCOperationInfo("FC", "FCBGL2000", "GetPage", "000000", new PDef());
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL2000_GetPage_UP_BLOCK0() {
/* 205 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL2000", "GetPage", 
/* 206 */         new MCItemDef[] {
/* 207 */           MCItemDef.create("denbun", true, "denbun")
/*     */ 
/*     */         
/* 210 */         }MCBlockDef.create("Dec"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL2000_GetPage_UP_BLOCK1() {
/* 216 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL2000", "GetPage", 
/* 217 */         new MCItemDef[] {
/* 218 */           MCItemDef.create("tar_blk", "tar_blk"), 
/* 219 */           MCItemDef.create("page_size", "page_size"), 
/* 220 */           MCItemDef.create("from", "from"), 
/* 221 */           MCItemDef.create("cache_id", "cache_id")
/*     */ 
/*     */         
/* 224 */         }MCBlockDef.create("Page"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBGL2000_GetPage_DOWN_BLOCK0() {
/* 231 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL2000", "GetPage", 
/* 232 */         new MCItemDef[] {
/* 233 */           MCItemDef.create("denbun", true, "denbun")
/*     */ 
/*     */         
/* 236 */         }MCBlockDef.create("Dec"));
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\paging\PDef_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */