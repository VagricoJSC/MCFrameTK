/*     */ package mcframe.serverCore.requester.paging;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.commonCore.container.MCConstRow;
/*     */ import mcframe.commonCore.container.MCExtMap;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class PageR_FW_A
/*     */   extends MCConstRow
/*     */ {
/*     */   public static final String $tar_blk = "tar_blk";
/*     */   public static final String $page_size = "page_size";
/*     */   public static final String $total = "total";
/*     */   public static final String $cache_id = "cache_id";
/*     */   public static final String $from = "from";
/*  35 */   public static final MCMeta tar_blk_META = createNumberMeta("tar_blk");
/*  36 */   public static final MCMeta page_size_META = createNumberMeta("page_size");
/*  37 */   public static final MCMeta total_META = createNumberMeta("total");
/*  38 */   public static final MCMeta cache_id_META = createStringMeta("cache_id");
/*  39 */   public static final MCMeta from_META = createNumberMeta("from");
/*     */   
/*  41 */   protected static final MCRow.ConstMetaList<PageR> constMetas = new MCRow.ConstMetaList(
/*  42 */       MCConstRow.constMetas, 
/*  43 */       new MCMeta[] {
/*  44 */         tar_blk_META, 
/*  45 */         page_size_META, 
/*  46 */         total_META, 
/*  47 */         cache_id_META, 
/*  48 */         from_META
/*     */       },
/*  50 */       new String[][] { {}, {} });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   protected static final MCExtMap EXTMAP = new MCExtMap(
/*  63 */       null, new MCExtMap.Entry[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] colnames() {
/*  75 */     return constMetas.toNameArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMeta[] colmetas() {
/*  87 */     return constMetas.toMetaArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  93 */   private static final int offset = constMetas.offset();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getExtMap(String aGroup) {
/*  99 */     if (aGroup == null) return null; 
/* 100 */     return (Map<String, String>)EXTMAP.get(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getKeys(String aGroup) {
/* 107 */     if (aGroup == null) return null; 
/* 108 */     return EXTMAP.getKeyList(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExtGroups() {
/* 115 */     Set<String> ret = EXTMAP.keySet();
/* 116 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PageR_FW_A(MCRow.ConstMetaList<? extends PageR> metas) {
/* 123 */     super(metas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PageR clone() {
/* 130 */     return (PageR)super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PageR createInstance() {
/* 137 */     return (PageR)super.createInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PageR getValues(String... names) {
/* 144 */     return (PageR)super.getValues(names);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireValueChanged(String column, Comparable<?> newvalue, Comparable<?> oldvalue) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCNumber tar_blk() {
/* 156 */     return getConstNumber(offset + 0, "tar_blk");
/*     */   }
/*     */   
/*     */   public void tar_blk(MCNumber value) {
/* 160 */     setConstNumber(offset + 0, "tar_blk", value);
/*     */   }
/*     */   
/*     */   public void tar_blk(int value) {
/* 164 */     setConstNumber(offset + 0, "tar_blk", value);
/*     */   }
/*     */   
/*     */   public void tar_blk(long value) {
/* 168 */     setConstNumber(offset + 0, "tar_blk", value);
/*     */   }
/*     */   
/*     */   public void tar_blk(float value) {
/* 172 */     setConstNumber(offset + 0, "tar_blk", value);
/*     */   }
/*     */   
/*     */   public void tar_blk(double value) {
/* 176 */     setConstNumber(offset + 0, "tar_blk", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCNumber page_size() {
/* 181 */     return getConstNumber(offset + 1, "page_size");
/*     */   }
/*     */   
/*     */   public void page_size(MCNumber value) {
/* 185 */     setConstNumber(offset + 1, "page_size", value);
/*     */   }
/*     */   
/*     */   public void page_size(int value) {
/* 189 */     setConstNumber(offset + 1, "page_size", value);
/*     */   }
/*     */   
/*     */   public void page_size(long value) {
/* 193 */     setConstNumber(offset + 1, "page_size", value);
/*     */   }
/*     */   
/*     */   public void page_size(float value) {
/* 197 */     setConstNumber(offset + 1, "page_size", value);
/*     */   }
/*     */   
/*     */   public void page_size(double value) {
/* 201 */     setConstNumber(offset + 1, "page_size", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCNumber total() {
/* 206 */     return getConstNumber(offset + 2, "total");
/*     */   }
/*     */   
/*     */   public void total(MCNumber value) {
/* 210 */     setConstNumber(offset + 2, "total", value);
/*     */   }
/*     */   
/*     */   public void total(int value) {
/* 214 */     setConstNumber(offset + 2, "total", value);
/*     */   }
/*     */   
/*     */   public void total(long value) {
/* 218 */     setConstNumber(offset + 2, "total", value);
/*     */   }
/*     */   
/*     */   public void total(float value) {
/* 222 */     setConstNumber(offset + 2, "total", value);
/*     */   }
/*     */   
/*     */   public void total(double value) {
/* 226 */     setConstNumber(offset + 2, "total", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String cache_id() {
/* 231 */     return getConstString(offset + 3, "cache_id");
/*     */   }
/*     */   
/*     */   public void cache_id(String value) {
/* 235 */     setConstString(offset + 3, "cache_id", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCNumber from() {
/* 240 */     return getConstNumber(offset + 4, "from");
/*     */   }
/*     */   
/*     */   public void from(MCNumber value) {
/* 244 */     setConstNumber(offset + 4, "from", value);
/*     */   }
/*     */   
/*     */   public void from(int value) {
/* 248 */     setConstNumber(offset + 4, "from", value);
/*     */   }
/*     */   
/*     */   public void from(long value) {
/* 252 */     setConstNumber(offset + 4, "from", value);
/*     */   }
/*     */   
/*     */   public void from(float value) {
/* 256 */     setConstNumber(offset + 4, "from", value);
/*     */   }
/*     */   
/*     */   public void from(double value) {
/* 260 */     setConstNumber(offset + 4, "from", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString(String name) {
/* 265 */     if ("cache_id".equalsIgnoreCase(name)) {
/* 266 */       return cache_id();
/*     */     }
/* 268 */     return super.getString(name);
/*     */   }
/*     */   public MCNumber getNumber(String name) {
/* 271 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 272 */       return tar_blk();
/*     */     }
/* 274 */     if ("page_size".equalsIgnoreCase(name)) {
/* 275 */       return page_size();
/*     */     }
/* 277 */     if ("total".equalsIgnoreCase(name)) {
/* 278 */       return total();
/*     */     }
/* 280 */     if ("from".equalsIgnoreCase(name)) {
/* 281 */       return from();
/*     */     }
/* 283 */     return super.getNumber(name);
/*     */   }
/*     */   
/*     */   public String getStringNE(String name) {
/* 287 */     if ("cache_id".equalsIgnoreCase(name)) {
/* 288 */       return cache_id();
/*     */     }
/* 290 */     return super.getStringNE(name);
/*     */   }
/*     */   public MCNumber getNumberNE(String name) {
/* 293 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 294 */       return tar_blk();
/*     */     }
/* 296 */     if ("page_size".equalsIgnoreCase(name)) {
/* 297 */       return page_size();
/*     */     }
/* 299 */     if ("total".equalsIgnoreCase(name)) {
/* 300 */       return total();
/*     */     }
/* 302 */     if ("from".equalsIgnoreCase(name)) {
/* 303 */       return from();
/*     */     }
/* 305 */     return super.getNumberNE(name);
/*     */   }
/*     */   
/*     */   public void setString(String name, String value) {
/* 309 */     if ("cache_id".equalsIgnoreCase(name)) {
/* 310 */       cache_id(value);
/*     */       return;
/*     */     } 
/* 313 */     super.setString(name, value);
/*     */   }
/*     */   public void setNumber(String name, MCNumber value) {
/* 316 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 317 */       tar_blk(value);
/*     */       return;
/*     */     } 
/* 320 */     if ("page_size".equalsIgnoreCase(name)) {
/* 321 */       page_size(value);
/*     */       return;
/*     */     } 
/* 324 */     if ("total".equalsIgnoreCase(name)) {
/* 325 */       total(value);
/*     */       return;
/*     */     } 
/* 328 */     if ("from".equalsIgnoreCase(name)) {
/* 329 */       from(value);
/*     */       return;
/*     */     } 
/* 332 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, int value) {
/* 335 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 336 */       tar_blk(value);
/*     */       return;
/*     */     } 
/* 339 */     if ("page_size".equalsIgnoreCase(name)) {
/* 340 */       page_size(value);
/*     */       return;
/*     */     } 
/* 343 */     if ("total".equalsIgnoreCase(name)) {
/* 344 */       total(value);
/*     */       return;
/*     */     } 
/* 347 */     if ("from".equalsIgnoreCase(name)) {
/* 348 */       from(value);
/*     */       return;
/*     */     } 
/* 351 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, long value) {
/* 354 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 355 */       tar_blk(value);
/*     */       return;
/*     */     } 
/* 358 */     if ("page_size".equalsIgnoreCase(name)) {
/* 359 */       page_size(value);
/*     */       return;
/*     */     } 
/* 362 */     if ("total".equalsIgnoreCase(name)) {
/* 363 */       total(value);
/*     */       return;
/*     */     } 
/* 366 */     if ("from".equalsIgnoreCase(name)) {
/* 367 */       from(value);
/*     */       return;
/*     */     } 
/* 370 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, float value) {
/* 373 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 374 */       tar_blk(value);
/*     */       return;
/*     */     } 
/* 377 */     if ("page_size".equalsIgnoreCase(name)) {
/* 378 */       page_size(value);
/*     */       return;
/*     */     } 
/* 381 */     if ("total".equalsIgnoreCase(name)) {
/* 382 */       total(value);
/*     */       return;
/*     */     } 
/* 385 */     if ("from".equalsIgnoreCase(name)) {
/* 386 */       from(value);
/*     */       return;
/*     */     } 
/* 389 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, double value) {
/* 392 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 393 */       tar_blk(value);
/*     */       return;
/*     */     } 
/* 396 */     if ("page_size".equalsIgnoreCase(name)) {
/* 397 */       page_size(value);
/*     */       return;
/*     */     } 
/* 400 */     if ("total".equalsIgnoreCase(name)) {
/* 401 */       total(value);
/*     */       return;
/*     */     } 
/* 404 */     if ("from".equalsIgnoreCase(name)) {
/* 405 */       from(value);
/*     */       return;
/*     */     } 
/* 408 */     super.setNumber(name, value);
/*     */   }
/*     */   
/*     */   public void setStringNE(String name, String value) {
/* 412 */     if ("cache_id".equalsIgnoreCase(name)) {
/* 413 */       cache_id(value);
/*     */       return;
/*     */     } 
/* 416 */     super.setStringNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, MCNumber value) {
/* 419 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 420 */       tar_blk(value);
/*     */       return;
/*     */     } 
/* 423 */     if ("page_size".equalsIgnoreCase(name)) {
/* 424 */       page_size(value);
/*     */       return;
/*     */     } 
/* 427 */     if ("total".equalsIgnoreCase(name)) {
/* 428 */       total(value);
/*     */       return;
/*     */     } 
/* 431 */     if ("from".equalsIgnoreCase(name)) {
/* 432 */       from(value);
/*     */       return;
/*     */     } 
/* 435 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, int value) {
/* 438 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 439 */       tar_blk(value);
/*     */       return;
/*     */     } 
/* 442 */     if ("page_size".equalsIgnoreCase(name)) {
/* 443 */       page_size(value);
/*     */       return;
/*     */     } 
/* 446 */     if ("total".equalsIgnoreCase(name)) {
/* 447 */       total(value);
/*     */       return;
/*     */     } 
/* 450 */     if ("from".equalsIgnoreCase(name)) {
/* 451 */       from(value);
/*     */       return;
/*     */     } 
/* 454 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, long value) {
/* 457 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 458 */       tar_blk(value);
/*     */       return;
/*     */     } 
/* 461 */     if ("page_size".equalsIgnoreCase(name)) {
/* 462 */       page_size(value);
/*     */       return;
/*     */     } 
/* 465 */     if ("total".equalsIgnoreCase(name)) {
/* 466 */       total(value);
/*     */       return;
/*     */     } 
/* 469 */     if ("from".equalsIgnoreCase(name)) {
/* 470 */       from(value);
/*     */       return;
/*     */     } 
/* 473 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, float value) {
/* 476 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 477 */       tar_blk(value);
/*     */       return;
/*     */     } 
/* 480 */     if ("page_size".equalsIgnoreCase(name)) {
/* 481 */       page_size(value);
/*     */       return;
/*     */     } 
/* 484 */     if ("total".equalsIgnoreCase(name)) {
/* 485 */       total(value);
/*     */       return;
/*     */     } 
/* 488 */     if ("from".equalsIgnoreCase(name)) {
/* 489 */       from(value);
/*     */       return;
/*     */     } 
/* 492 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, double value) {
/* 495 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 496 */       tar_blk(value);
/*     */       return;
/*     */     } 
/* 499 */     if ("page_size".equalsIgnoreCase(name)) {
/* 500 */       page_size(value);
/*     */       return;
/*     */     } 
/* 503 */     if ("total".equalsIgnoreCase(name)) {
/* 504 */       total(value);
/*     */       return;
/*     */     } 
/* 507 */     if ("from".equalsIgnoreCase(name)) {
/* 508 */       from(value);
/*     */       return;
/*     */     } 
/* 511 */     super.setNumberNE(name, value);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\paging\PageR_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */