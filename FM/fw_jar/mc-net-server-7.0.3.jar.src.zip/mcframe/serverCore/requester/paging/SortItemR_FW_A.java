/*     */ package mcframe.serverCore.requester.paging;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.commonCore.container.MCConstRow;
/*     */ import mcframe.commonCore.container.MCExtMap;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class SortItemR_FW_A
/*     */   extends MCConstRow
/*     */ {
/*     */   public static final String $tar_blk = "tar_blk";
/*     */   public static final String $sort_no = "sort_no";
/*     */   public static final String $nm = "nm";
/*     */   public static final String $sort_typ = "sort_typ";
/*  34 */   public static final MCMeta tar_blk_META = createNumberMeta("tar_blk");
/*  35 */   public static final MCMeta sort_no_META = createNumberMeta("sort_no");
/*  36 */   public static final MCMeta nm_META = createStringMeta("nm");
/*  37 */   public static final MCMeta sort_typ_META = createStringMeta("sort_typ");
/*     */   
/*  39 */   protected static final MCRow.ConstMetaList<SortItemR> constMetas = new MCRow.ConstMetaList(
/*  40 */       MCConstRow.constMetas, 
/*  41 */       new MCMeta[] {
/*  42 */         tar_blk_META, 
/*  43 */         sort_no_META, 
/*  44 */         nm_META, 
/*  45 */         sort_typ_META
/*     */       },
/*  47 */       new String[][] { {}, {} });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   protected static final MCExtMap EXTMAP = new MCExtMap(
/*  60 */       null, new MCExtMap.Entry[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] colnames() {
/*  72 */     return constMetas.toNameArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMeta[] colmetas() {
/*  84 */     return constMetas.toMetaArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   private static final int offset = constMetas.offset();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getExtMap(String aGroup) {
/*  96 */     if (aGroup == null) return null; 
/*  97 */     return (Map<String, String>)EXTMAP.get(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getKeys(String aGroup) {
/* 104 */     if (aGroup == null) return null; 
/* 105 */     return EXTMAP.getKeyList(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExtGroups() {
/* 112 */     Set<String> ret = EXTMAP.keySet();
/* 113 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SortItemR_FW_A(MCRow.ConstMetaList<? extends SortItemR> metas) {
/* 120 */     super(metas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SortItemR clone() {
/* 127 */     return (SortItemR)super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SortItemR createInstance() {
/* 134 */     return (SortItemR)super.createInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SortItemR getValues(String... names) {
/* 141 */     return (SortItemR)super.getValues(names);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireValueChanged(String column, Comparable<?> newvalue, Comparable<?> oldvalue) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCNumber tar_blk() {
/* 153 */     return getConstNumber(offset + 0, "tar_blk");
/*     */   }
/*     */   
/*     */   public void tar_blk(MCNumber value) {
/* 157 */     setConstNumber(offset + 0, "tar_blk", value);
/*     */   }
/*     */   
/*     */   public void tar_blk(int value) {
/* 161 */     setConstNumber(offset + 0, "tar_blk", value);
/*     */   }
/*     */   
/*     */   public void tar_blk(long value) {
/* 165 */     setConstNumber(offset + 0, "tar_blk", value);
/*     */   }
/*     */   
/*     */   public void tar_blk(float value) {
/* 169 */     setConstNumber(offset + 0, "tar_blk", value);
/*     */   }
/*     */   
/*     */   public void tar_blk(double value) {
/* 173 */     setConstNumber(offset + 0, "tar_blk", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCNumber sort_no() {
/* 178 */     return getConstNumber(offset + 1, "sort_no");
/*     */   }
/*     */   
/*     */   public void sort_no(MCNumber value) {
/* 182 */     setConstNumber(offset + 1, "sort_no", value);
/*     */   }
/*     */   
/*     */   public void sort_no(int value) {
/* 186 */     setConstNumber(offset + 1, "sort_no", value);
/*     */   }
/*     */   
/*     */   public void sort_no(long value) {
/* 190 */     setConstNumber(offset + 1, "sort_no", value);
/*     */   }
/*     */   
/*     */   public void sort_no(float value) {
/* 194 */     setConstNumber(offset + 1, "sort_no", value);
/*     */   }
/*     */   
/*     */   public void sort_no(double value) {
/* 198 */     setConstNumber(offset + 1, "sort_no", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String nm() {
/* 203 */     return getConstString(offset + 2, "nm");
/*     */   }
/*     */   
/*     */   public void nm(String value) {
/* 207 */     setConstString(offset + 2, "nm", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String sort_typ() {
/* 212 */     return getConstString(offset + 3, "sort_typ");
/*     */   }
/*     */   
/*     */   public void sort_typ(String value) {
/* 216 */     setConstString(offset + 3, "sort_typ", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString(String name) {
/* 221 */     if ("nm".equalsIgnoreCase(name)) {
/* 222 */       return nm();
/*     */     }
/* 224 */     if ("sort_typ".equalsIgnoreCase(name)) {
/* 225 */       return sort_typ();
/*     */     }
/* 227 */     return super.getString(name);
/*     */   }
/*     */   public MCNumber getNumber(String name) {
/* 230 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 231 */       return tar_blk();
/*     */     }
/* 233 */     if ("sort_no".equalsIgnoreCase(name)) {
/* 234 */       return sort_no();
/*     */     }
/* 236 */     return super.getNumber(name);
/*     */   }
/*     */   
/*     */   public String getStringNE(String name) {
/* 240 */     if ("nm".equalsIgnoreCase(name)) {
/* 241 */       return nm();
/*     */     }
/* 243 */     if ("sort_typ".equalsIgnoreCase(name)) {
/* 244 */       return sort_typ();
/*     */     }
/* 246 */     return super.getStringNE(name);
/*     */   }
/*     */   public MCNumber getNumberNE(String name) {
/* 249 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 250 */       return tar_blk();
/*     */     }
/* 252 */     if ("sort_no".equalsIgnoreCase(name)) {
/* 253 */       return sort_no();
/*     */     }
/* 255 */     return super.getNumberNE(name);
/*     */   }
/*     */   
/*     */   public void setString(String name, String value) {
/* 259 */     if ("nm".equalsIgnoreCase(name)) {
/* 260 */       nm(value);
/*     */       return;
/*     */     } 
/* 263 */     if ("sort_typ".equalsIgnoreCase(name)) {
/* 264 */       sort_typ(value);
/*     */       return;
/*     */     } 
/* 267 */     super.setString(name, value);
/*     */   }
/*     */   public void setNumber(String name, MCNumber value) {
/* 270 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 271 */       tar_blk(value);
/*     */       return;
/*     */     } 
/* 274 */     if ("sort_no".equalsIgnoreCase(name)) {
/* 275 */       sort_no(value);
/*     */       return;
/*     */     } 
/* 278 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, int value) {
/* 281 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 282 */       tar_blk(value);
/*     */       return;
/*     */     } 
/* 285 */     if ("sort_no".equalsIgnoreCase(name)) {
/* 286 */       sort_no(value);
/*     */       return;
/*     */     } 
/* 289 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, long value) {
/* 292 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 293 */       tar_blk(value);
/*     */       return;
/*     */     } 
/* 296 */     if ("sort_no".equalsIgnoreCase(name)) {
/* 297 */       sort_no(value);
/*     */       return;
/*     */     } 
/* 300 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, float value) {
/* 303 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 304 */       tar_blk(value);
/*     */       return;
/*     */     } 
/* 307 */     if ("sort_no".equalsIgnoreCase(name)) {
/* 308 */       sort_no(value);
/*     */       return;
/*     */     } 
/* 311 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, double value) {
/* 314 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 315 */       tar_blk(value);
/*     */       return;
/*     */     } 
/* 318 */     if ("sort_no".equalsIgnoreCase(name)) {
/* 319 */       sort_no(value);
/*     */       return;
/*     */     } 
/* 322 */     super.setNumber(name, value);
/*     */   }
/*     */   
/*     */   public void setStringNE(String name, String value) {
/* 326 */     if ("nm".equalsIgnoreCase(name)) {
/* 327 */       nm(value);
/*     */       return;
/*     */     } 
/* 330 */     if ("sort_typ".equalsIgnoreCase(name)) {
/* 331 */       sort_typ(value);
/*     */       return;
/*     */     } 
/* 334 */     super.setStringNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, MCNumber value) {
/* 337 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 338 */       tar_blk(value);
/*     */       return;
/*     */     } 
/* 341 */     if ("sort_no".equalsIgnoreCase(name)) {
/* 342 */       sort_no(value);
/*     */       return;
/*     */     } 
/* 345 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, int value) {
/* 348 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 349 */       tar_blk(value);
/*     */       return;
/*     */     } 
/* 352 */     if ("sort_no".equalsIgnoreCase(name)) {
/* 353 */       sort_no(value);
/*     */       return;
/*     */     } 
/* 356 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, long value) {
/* 359 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 360 */       tar_blk(value);
/*     */       return;
/*     */     } 
/* 363 */     if ("sort_no".equalsIgnoreCase(name)) {
/* 364 */       sort_no(value);
/*     */       return;
/*     */     } 
/* 367 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, float value) {
/* 370 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 371 */       tar_blk(value);
/*     */       return;
/*     */     } 
/* 374 */     if ("sort_no".equalsIgnoreCase(name)) {
/* 375 */       sort_no(value);
/*     */       return;
/*     */     } 
/* 378 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, double value) {
/* 381 */     if ("tar_blk".equalsIgnoreCase(name)) {
/* 382 */       tar_blk(value);
/*     */       return;
/*     */     } 
/* 385 */     if ("sort_no".equalsIgnoreCase(name)) {
/* 386 */       sort_no(value);
/*     */       return;
/*     */     } 
/* 389 */     super.setNumberNE(name, value);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\paging\SortItemR_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */