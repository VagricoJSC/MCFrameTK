/*     */ package mcframe.serverCore.requester;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.net.InetAddress;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Comparator;
/*     */ import java.util.List;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCBinary;
/*     */ import mcframe.commonCore.lang.MCDate;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.param.MCDPWriter;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.commonCore.param.MCParamFileUtil;
/*     */ import mcframe.commonCore.resource.MCConst;
/*     */ import mcframe.serverCore.dbc.FCT_SRV_REQUEST_FILE_R;
/*     */ import mcframe.serverCore.dbc.FCT_SRV_REQUEST_R;
/*     */ import mcframe.serverCore.mcjdbc.FWDBUtil;
/*     */ import mcframe.serverCore.mcjdbc.MCTransactionManager;
/*     */ import mcframe.serverCore.queryapi.IFMCSQL;
/*     */ import mcframe.serverCore.queryapi.MCDBContainer;
/*     */ import mcframe.serverCore.queryapi.MCQueryApiBuilder;
/*     */ import mcframe.serverCore.sys.MCSys;
/*     */ import mcframe.serverCore.util.MCDBUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCRequestStatusImpl
/*     */   implements MCRequestStatus
/*     */ {
/*     */   public static final String STATUS_RUNNING = "0";
/*     */   public static final String STATUS_SUCCESS = "1";
/*     */   public static final String STATUS_INI = "2";
/*     */   public static final String STATUS_ERROR = "3";
/*     */   public static final String STATUS_SYSERR = "4";
/*     */   public static final String STATUS_INIERR = "5";
/*     */   private static final String KEY_STATUS_BASE = "requester.status";
/*     */   private static final String KEY_REGISTER = "register";
/*     */   private static final String KEY_PTN = "ptn";
/*     */   private static final String KEY_EXCLUDE = "exclude";
/*     */   private static final String KEY_ORDER = "order";
/*     */   private static final boolean DEF_STATUS_REGISTER = false;
/*     */   private static List<MCStatusRegister> _registerList;
/*     */   private final boolean save;
/*     */   private final FCT_SRV_REQUEST_R dbc;
/*     */   private String status;
/*     */   private MCDPWriter writer;
/*     */   
/*     */   public MCRequestStatusImpl(MCParam p, MCDPWriter writer) {
/* 173 */     this.save = isSaveStatus(p);
/* 174 */     this.writer = writer;
/* 175 */     this.writer.setSaveStatus(this.save);
/* 176 */     this.dbc = createContainer(p);
/* 177 */     init(p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init(MCParam p) {
/*     */     try {
/* 190 */       this.status = "2";
/* 191 */       this.dbc.status("2");
/* 192 */       MCQueryApiBuilder builder = MCQueryApiBuilder.create((MCDBContainer)this.dbc);
/* 193 */       MCDBUtil.dbInsert("FC_MCRequestStatusImpl_init", (MCRow)this.dbc, builder);
/* 194 */       MCTransactionManager.dbTran().commit();
/*     */     }
/* 196 */     catch (Throwable t) {
/* 197 */       throw new MCException(t, Core_Msg_FW_A.FCBGC0140, new Object[0]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private FCT_SRV_REQUEST_R createContainer(MCParam p) {
/* 210 */     FCT_SRV_REQUEST_R ret = FCT_SRV_REQUEST_R.create("T");
/* 211 */     ret.srv_req_no(p.getServerRequestNo());
/* 212 */     ret.user_id(p.getUserId());
/* 213 */     ret.clt_id(p.getClientId());
/* 214 */     ret.c_req_no(p.getClientRequestNo());
/* 215 */     ret.c_req_ts(p.getCreatedTime());
/* 216 */     if (p.getClientLocale() != null) {
/* 217 */       ret.c_locale(p.getClientLocale().toString());
/*     */     }
/* 219 */     if (p.getClientTimeZone() != null) {
/* 220 */       ret.c_time_zone(p.getClientTimeZone().getID());
/*     */     }
/*     */     
/* 223 */     if (p.getReqSrcId() != null && p.getReqSrcId()
/* 224 */       .length() > FCT_SRV_REQUEST_R.call_pg_id_META.length()) {
/* 225 */       ret.call_pg_id(p.getReqSrcId().substring(0, 
/* 226 */             FCT_SRV_REQUEST_R.call_pg_id_META.length()));
/*     */     } else {
/*     */       
/* 229 */       ret.call_pg_id(p.getReqSrcId());
/*     */     } 
/* 231 */     ret.operation_cd(p.getOperationTypeHis());
/* 232 */     ret.btn_res_key(p.getActionLabelHis());
/* 233 */     ret.action_id(p.getActionIdHis());
/* 234 */     ret.module_id(p.getModuleId());
/* 235 */     ret.logic_id(p.getLogicId());
/* 236 */     ret.ope_id(p.getOperationId());
/* 237 */     ret.srv_id(getHostName());
/* 238 */     ret.async_flg(p.isOperationAsync());
/* 239 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getHostName() {
/*     */     try {
/* 251 */       return InetAddress.getLocalHost().getHostName();
/*     */     }
/* 253 */     catch (Exception exception) {
/* 254 */       return "UnKnown";
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*     */     try {
/* 262 */       this.status = "0";
/* 263 */       this.dbc.status("0");
/* 264 */       this.dbc.start_dt(MCDate.now());
/* 265 */       File up = MCParamFileUtil.getUpParamFile();
/* 266 */       if (up.exists()) {
/* 267 */         this.dbc.up_param(MCBinary.valueOf(up));
/*     */       }
/*     */       try {
/* 270 */         this.dbc.co_cd(MCSys.user.coCD());
/* 271 */         this.dbc.ext_attr1(MCSys.user.extattr1());
/* 272 */         this.dbc.ext_attr2(MCSys.user.extattr2());
/* 273 */         this.dbc.ext_attr3(MCSys.user.extattr3());
/* 274 */         this.dbc.gp_batch_grp_cd(FWDBUtil.getGpBatchGrpCd());
/* 275 */         MCQueryApiBuilder builder = MCQueryApiBuilder.create((MCDBContainer)this.dbc);
/* 276 */         builder.setSet(new IFMCSQL.MCPermColumn[] { (IFMCSQL.MCPermColumn)this.dbc.status, (IFMCSQL.MCPermColumn)this.dbc.start_dt, (IFMCSQL.MCPermColumn)this.dbc.up_param, (IFMCSQL.MCPermColumn)this.dbc.co_cd, (IFMCSQL.MCPermColumn)this.dbc.ext_attr1, (IFMCSQL.MCPermColumn)this.dbc.ext_attr2, 
/* 277 */               (IFMCSQL.MCPermColumn)this.dbc.ext_attr3, (IFMCSQL.MCPermColumn)this.dbc.gp_batch_grp_cd });
/* 278 */         MCDBUtil.dbUpdateKey("FC_MCRequestStatusImpl_run", (MCRow)this.dbc, builder);
/* 279 */         MCTransactionManager.dbTran().commit();
/*     */       } finally {
/*     */         
/* 282 */         up.delete();
/*     */       }
/*     */     
/* 285 */     } catch (Throwable t) {
/* 286 */       throw new MCException(t, Core_Msg_FW_A.FCBGC0140, new Object[0]);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void success() {
/* 292 */     this.status = "1";
/* 293 */     end();
/*     */   }
/*     */ 
/*     */   
/*     */   public void initerror() {
/* 298 */     this.status = "5";
/* 299 */     end();
/*     */   }
/*     */ 
/*     */   
/*     */   public void error() {
/* 304 */     this.status = "3";
/* 305 */     end();
/*     */   }
/*     */ 
/*     */   
/*     */   public void syserror() {
/* 310 */     this.status = "4";
/* 311 */     end();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void end() {
/* 323 */     this.writer.flushDump();
/* 324 */     this.writer.closeDump();
/*     */     
/* 326 */     MCQueryApiBuilder builder = MCQueryApiBuilder.create((MCDBContainer)this.dbc);
/* 327 */     if (MCDBUtil.dbSelectKeyForUpdate("FC_MCRequestStatusImpl_end_1", (MCRow)this.dbc, (MCDBContainer)this.dbc, new Comparable[] { this.dbc.srv_req_no() }) < 1) {
/*     */       return;
/*     */     }
/* 330 */     File dw = null;
/*     */     try {
/* 332 */       if (this.save) {
/*     */         
/* 334 */         this.dbc.status(this.status);
/* 335 */         this.dbc.end_dt(MCDate.now());
/* 336 */         dw = MCParamFileUtil.getDownParamFile();
/* 337 */         if (dw.exists()) {
/* 338 */           this.dbc.down_param(MCBinary.valueOf(dw));
/*     */         }
/* 340 */         builder.setSet(new IFMCSQL.MCPermColumn[] { (IFMCSQL.MCPermColumn)this.dbc.status, (IFMCSQL.MCPermColumn)this.dbc.down_param, (IFMCSQL.MCPermColumn)this.dbc.end_dt });
/* 341 */         MCDBUtil.dbUpdateKey("FC_MCRequestStatusImpl_end_2", (MCRow)this.dbc, builder);
/*     */       } else {
/*     */         
/* 344 */         MCDBUtil.dbDeleteKey("FC_MCRequestStatusImpl_end_3", (MCRow)this.dbc, (MCDBContainer)this.dbc);
/*     */       } 
/* 346 */       MCTransactionManager.dbTran().commit();
/*     */     }
/* 348 */     catch (Throwable t) {
/* 349 */       throw new MCException(t, Core_Msg_FW_A.FCBGC0140, new Object[0]);
/*     */     } finally {
/*     */       
/* 352 */       if (dw != null) {
/* 353 */         dw.delete();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getStatus() {
/* 360 */     return this.status;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSave() {
/* 365 */     return this.save;
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateGpBatchGrpCd() {
/*     */     try {
/* 371 */       this.dbc.gp_batch_grp_cd(FWDBUtil.getGpBatchGrpCd());
/* 372 */       MCQueryApiBuilder builder = MCQueryApiBuilder.create((MCDBContainer)this.dbc);
/* 373 */       builder.setSet(new IFMCSQL.MCPermColumn[] { (IFMCSQL.MCPermColumn)this.dbc.gp_batch_grp_cd });
/* 374 */       MCDBUtil.dbUpdateKey("FC_MCRequestStatusImpl_updateGpBatchGrpCd", (MCRow)this.dbc, builder);
/* 375 */       MCTransactionManager.dbTran().commit();
/*     */     }
/* 377 */     catch (Throwable t) {
/* 378 */       throw new MCException(t, Core_Msg_FW_A.FCBGC0140, new Object[0]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isSaveStatus() {
/* 391 */     if (MCSys.request.async()) {
/* 392 */       return true;
/*     */     }
/* 394 */     return isSaveStatus(MCSys.request.moduleId(), MCSys.request.logicId(), 
/* 395 */         MCSys.request.operationId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isSaveStatus(MCParam p) {
/* 408 */     if (p.isOperationAsync()) {
/* 409 */       return true;
/*     */     }
/* 411 */     return isSaveStatus(p.getModuleId(), p.getLogicId(), p.getOperationId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isSaveStatus(String module_id, String logic_id, String ope_id) {
/* 424 */     String[] id = {
/* 425 */         MCStringUtil.join(".", new String[] { module_id, logic_id, ope_id })
/*     */       };
/* 427 */     List<MCStatusRegister> l = getRegisterList();
/* 428 */     for (MCStatusRegister r : l) {
/* 429 */       if (r.match(id)) {
/* 430 */         return r.register;
/*     */       }
/*     */     } 
/* 433 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static synchronized List<MCStatusRegister> getRegisterList() {
/* 444 */     if (_registerList == null) {
/* 445 */       initRegisterList();
/*     */     }
/* 447 */     return _registerList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void initRegisterList() {
/* 457 */     _registerList = new ArrayList<>();
/* 458 */     addStatusRegister(MCConst.plugin.findPattern("requester.status.*"));
/* 459 */     _registerList.sort(new Comparator<MCStatusRegister>()
/*     */         {
/*     */           public int compare(MCRequestStatusImpl.MCStatusRegister o1, MCRequestStatusImpl.MCStatusRegister o2) {
/* 462 */             return Integer.compare(o1.order, o2.order);
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void addStatusRegister(String[] keys) {
/*     */     byte b;
/*     */     int i;
/*     */     String[] arrayOfString;
/* 475 */     for (i = (arrayOfString = keys).length, b = 0; b < i; ) { String key = arrayOfString[b];
/* 476 */       String rKey = MCConst.createKey(new String[] { key, "register" });
/* 477 */       if (MCConst.plugin.containsKey(rKey)) {
/*     */ 
/*     */         
/* 480 */         String ptn = MCConst.plugin.getString(MCConst.createKey(new String[] { key, "ptn" }, ), "");
/* 481 */         if (!MCStringUtil.isNull(ptn)) {
/*     */ 
/*     */           
/* 484 */           boolean register = MCConst.plugin.getBoolean(rKey, false);
/* 485 */           int order = MCConst.plugin.getInteger(MCConst.createKey(new String[] { key, "order"
/* 486 */                 }, ), 2147483647);
/* 487 */           String exclude = MCConst.plugin.getString(MCConst.createKey(new String[] { key, "exclude"
/* 488 */                 }, ), "");
/* 489 */           _registerList.add(new MCStatusRegister(order, ptn, exclude, register));
/*     */         } 
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class MCStatusRegister
/*     */   {
/*     */     private int order;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String[] ptn;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String[] exclude;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean register;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MCStatusRegister(int order, String ptn, String exclude, boolean register) {
/* 533 */       this.order = order;
/* 534 */       this.ptn = MCStringUtil.split(",", ptn);
/* 535 */       this.exclude = MCStringUtil.split(",", exclude);
/* 536 */       this.register = register;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean match(String[] id) {
/* 549 */       if (!exclude(id)) {
/* 550 */         byte b; int i; String[] arrayOfString; for (i = (arrayOfString = this.ptn).length, b = 0; b < i; ) { String p = arrayOfString[b];
/* 551 */           if (!MCStringUtil.isNull(p) && (
/* 552 */             MCStringUtil.match(p, id, '.')).length > 0)
/* 553 */             return true; 
/*     */           b++; }
/*     */       
/*     */       } 
/* 557 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean exclude(String[] id) {
/*     */       byte b;
/*     */       int i;
/*     */       String[] arrayOfString;
/* 569 */       for (i = (arrayOfString = this.exclude).length, b = 0; b < i; ) { String p = arrayOfString[b];
/* 570 */         if (!MCStringUtil.isNull(p) && (
/* 571 */           MCStringUtil.match(p, id, '.')).length > 0)
/* 572 */           return true; 
/*     */         b++; }
/*     */       
/* 575 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean registerFile(File... files) {
/* 588 */     if (files == null) {
/* 589 */       throw new MCException(Core_Msg_FW_A.FCBGC0133, new Object[] { "" });
/*     */     }
/* 591 */     if (!isSaveStatus()) {
/* 592 */       MCLog.write(Core_Msg_FW_A.FCBGC0132, new Object[0]);
/* 593 */       return false;
/*     */     }  byte b; int i;
/*     */     File[] arrayOfFile;
/* 596 */     for (i = (arrayOfFile = files).length, b = 0; b < i; ) { File file = arrayOfFile[b];
/* 597 */       if (file == null || file.isDirectory()) {
/* 598 */         throw new MCException(Core_Msg_FW_A.FCBGC0133, new Object[] { "" });
/*     */       }
/* 600 */       if (!file.exists()) {
/* 601 */         throw new MCException(Core_Msg_FW_A.FCBGC0133, new Object[] { file.getName() });
/*     */       }
/*     */       b++; }
/*     */     
/* 605 */     MCTransactionManager.createDBTran();
/*     */     
/*     */     try {
/* 608 */       MCList<FCT_SRV_REQUEST_FILE_R> list = MCList.create(FCT_SRV_REQUEST_FILE_R.class);
/*     */       File[] arrayOfFile1;
/* 610 */       for (int j = (arrayOfFile1 = files).length; i < j; ) { File file = arrayOfFile1[i];
/* 611 */         FCT_SRV_REQUEST_FILE_R row = FCT_SRV_REQUEST_FILE_R.create();
/* 612 */         row.srv_req_no(MCSys.request.serverRequestNo());
/* 613 */         row.file_bin(MCBinary.valueOf(file));
/* 614 */         row.file_name(file.getName());
/* 615 */         list.add((MCRow)row);
/*     */         i++; }
/*     */       
/* 618 */       MCQueryApiBuilder builder = MCQueryApiBuilder.create((MCDBContainer)FCT_SRV_REQUEST_FILE_R.create("T"));
/* 619 */       MCDBUtil.dbInsert("FC_MCRequestStatusImpl_registerFile", list, builder);
/* 620 */       MCTransactionManager.dbTran().commit();
/*     */     } finally {
/*     */       
/* 623 */       MCTransactionManager.releaseDBTran(MCTransactionManager.dbTran());
/*     */     } 
/*     */     
/* 626 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean registerFile(String... fileNames) {
/* 638 */     if (fileNames == null) {
/* 639 */       throw new MCException(Core_Msg_FW_A.FCBGC0133, new Object[] { "" });
/*     */     }
/*     */     
/* 642 */     File[] files = new File[fileNames.length];
/*     */     
/* 644 */     for (int i = 0; i < fileNames.length; i++) {
/* 645 */       if (MCStringUtil.isNull(fileNames[i])) {
/* 646 */         throw new MCException(Core_Msg_FW_A.FCBGC0133, new Object[] { "" });
/*     */       }
/* 648 */       files[i] = new File(fileNames[i]);
/*     */     } 
/*     */     
/* 651 */     boolean ret = registerFile(files);
/* 652 */     return ret;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\MCRequestStatusImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */