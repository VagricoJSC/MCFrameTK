/*     */ package mcframe.serverCore.requester;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.SocketException;
/*     */ import java.net.URLEncoder;
/*     */ import java.util.Locale;
/*     */ import javax.servlet.annotation.WebServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import mcframe.commonCore.lang.MCTimestamp;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.param.MCDownloadStream;
/*     */ import mcframe.commonCore.param.MCUploadFileParam;
/*     */ import mcframe.serverCore.mcjdbc.MCTransactionManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @WebServlet(name = "MCDownload", urlPatterns = {"/MCDownload"}, loadOnStartup = 2)
/*     */ public class MCDownloadAgent
/*     */   extends MCServletAgent
/*     */ {
/*     */   protected void doMCFServPost(String up, MCUploadFileParam upfp, String charset, boolean gzip, HttpServletRequest req, HttpServletResponse res) {
/*  38 */     MCDownloadStream[] ina = null;
/*  39 */     BufferedOutputStream out = null;
/*     */     
/*  41 */     MCLog.write(Core_Msg_FW_A.FCBGC0346, new Object[] { up });
/*     */ 
/*     */     
/*     */     try {
/*  45 */       ina = executeDL(null, up);
/*     */       
/*  47 */       if (ina.length > 0) {
/*  48 */         MCDownloadStream in = ina[0];
/*     */ 
/*     */         
/*  51 */         setResponseHeader(res, in);
/*     */ 
/*     */         
/*  54 */         out = new BufferedOutputStream((OutputStream)res.getOutputStream());
/*  55 */         byte[] buf = new byte[4096];
/*     */         int size;
/*  57 */         while ((size = in.read(buf)) != -1) {
/*  58 */           out.write(buf, 0, size);
/*     */         }
/*     */       }
/*     */     
/*  62 */     } catch (SocketException socketException) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*  74 */     catch (Throwable ex) {
/*     */       
/*  76 */       throw (ex instanceof MCException) ? (MCException)ex : new MCException(ex);
/*     */     }
/*     */     finally {
/*     */       
/*  80 */       if (ina != null) {
/*  81 */         for (int i = 0, len = ina.length; i < len; i++) {
/*     */           try {
/*  83 */             if (ina[i] != null) {
/*  84 */               ina[i].close();
/*     */             }
/*     */           }
/*  87 */           catch (IOException ex) {
/*     */             
/*  89 */             MCLog.write(ex);
/*     */           } 
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/*  95 */       MCTransactionManager.finalClose();
/*     */       
/*     */       try {
/*  98 */         if (out != null) {
/*  99 */           out.flush();
/* 100 */           out.close();
/*     */         }
/*     */       
/* 103 */       } catch (IOException ex) {
/*     */         
/* 105 */         MCLog.write(ex);
/*     */       } 
/*     */       
/* 108 */       MCLog.write(Core_Msg_FW_A.FCBGC0347, new Object[0]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCDownloadStream[] executeDL(String id, String up) {
/* 124 */     MCServerRequester requester = new MCServerRequester();
/* 125 */     return requester.srvDownload(up);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setResponseHeader(HttpServletResponse resp, MCDownloadStream in) {
/* 139 */     String name = in.getName();
/* 140 */     int size = (int)in.size();
/* 141 */     MCTimestamp ts = in.getLastModify();
/* 142 */     String lastmod = (ts != null) ? 
/* 143 */       timestampToHTTPString(ts) : 
/* 144 */       null;
/*     */ 
/*     */ 
/*     */     
/* 148 */     resp.setContentType(getContentType());
/* 149 */     if (size >= 0) {
/* 150 */       resp.setContentLength(size);
/*     */     }
/* 152 */     if (name != null) {
/*     */ 
/*     */       
/*     */       try {
/*     */         
/* 157 */         name = URLEncoder.encode(name, "UTF-8");
/*     */       }
/* 159 */       catch (UnsupportedEncodingException e) {
/*     */         
/* 161 */         e.printStackTrace();
/*     */       } 
/* 163 */       resp.setHeader("Content-Disposition", 
/* 164 */           "attachment; filename=" + name);
/*     */     } 
/* 166 */     if (lastmod != null) {
/* 167 */       resp.setHeader("Last-Modified", lastmod);
/*     */     }
/*     */     
/* 170 */     resp.setHeader("Cache-Control", 
/* 171 */         "must-revalidate, post-check=0,pre-check=0");
/*     */ 
/*     */     
/* 174 */     resp.setHeader("Pragma", "private");
/*     */     
/* 176 */     resp.setHeader("Expires", "0");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String timestampToHTTPString(MCTimestamp ts) {
/* 197 */     if (ts == null) {
/* 198 */       return null;
/*     */     }
/* 200 */     return ts.toString("EEE, d MMM yyyy HH:mm:ss 'GMT'", Locale.UK);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getContentType() {
/* 207 */     return "application/octet-stream";
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\MCDownloadAgent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */