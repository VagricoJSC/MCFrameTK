/*     */ package mcframe.serverCore.requester;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.servlet.Servlet;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServlet;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import mcframe.serverCore.sys.MCSys;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCWebExecAgent
/*     */   extends HttpServlet
/*     */   implements Servlet
/*     */ {
/*     */   public void init() throws ServletException {
/*  50 */     super.init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
/*  57 */     doPost(req, res);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
/*  65 */     String home = MCSys.env.MCF_HOME();
/*  66 */     File file = new File(home, "webexec");
/*  67 */     file = new File(file, "mc_launcher.html");
/*  68 */     InputStream is = null;
/*     */     try {
/*  70 */       is = new FileInputStream(file);
/*     */     }
/*  72 */     catch (FileNotFoundException fileNotFoundException) {
/*  73 */       is = null;
/*     */     } 
/*  75 */     if (is == null) {
/*  76 */       sendErrorResponse(res, "file not found.:" + file);
/*     */       
/*     */       return;
/*     */     } 
/*  80 */     BufferedReader br = null;
/*     */     try {
/*  82 */       br = new BufferedReader(new InputStreamReader(is, "UTF-8"));
/*     */     }
/*  84 */     catch (UnsupportedEncodingException unsupportedEncodingException) {}
/*     */ 
/*     */     
/*  87 */     if (br == null) {
/*  88 */       sendErrorResponse(res, "UtF-8 not support.");
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  93 */     Map<String, String[]> paramMap = (Map)new HashMap<>(req.getParameterMap());
/*  94 */     PrintWriter pw = createResponseWriter(res);
/*  95 */     String line = null;
/*  96 */     String[] values = null;
/*  97 */     while ((line = br.readLine()) != null) {
/*  98 */       if (line.startsWith("//=IMP_OPEN_PARAM")) {
/*  99 */         if (paramMap.size() <= 0) {
/*     */           continue;
/*     */         }
/*     */ 
/*     */         
/* 104 */         pw.print("var openparam = \"");
/*     */ 
/*     */         
/* 107 */         String[] login_keys = {
/* 108 */             "locale", "user_id", "password" }; byte b; int i;
/*     */         String[] arrayOfString1;
/* 110 */         for (i = (arrayOfString1 = login_keys).length, b = 0; b < i; ) { String login_key = arrayOfString1[b];
/* 111 */           values = paramMap.remove(login_key);
/* 112 */           if (values != null && values.length > 0) {
/* 113 */             pw.print("APPOPTION+");
/* 114 */             pw.print(login_key);
/* 115 */             pw.print("=");
/* 116 */             pw.print(values[0]);
/* 117 */             pw.println(" ");
/*     */           } 
/*     */           
/*     */           b++; }
/*     */         
/* 122 */         values = paramMap.remove("open_id");
/* 123 */         if (values != null && values.length > 0) {
/* 124 */           pw.print("APPOPTION+open_id=");
/* 125 */           pw.print(values[0]);
/* 126 */           pw.print('?');
/* 127 */           for (Map.Entry<String, String[]> entry : paramMap.entrySet()) {
/* 128 */             values = entry.getValue();
/* 129 */             if (values.length <= 0) {
/*     */               continue;
/*     */             }
/* 132 */             pw.print(entry.getKey());
/* 133 */             pw.print('=');
/* 134 */             pw.print(values[0]);
/* 135 */             pw.print(';');
/*     */           } 
/*     */         } 
/*     */         
/* 139 */         pw.println("\";");
/*     */         continue;
/*     */       } 
/* 142 */       pw.println(line);
/*     */     } 
/*     */     
/* 145 */     if (pw != null) {
/* 146 */       pw.flush();
/* 147 */       pw.close();
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 152 */       br.close();
/*     */     }
/* 154 */     catch (IOException iOException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected PrintWriter createResponseWriter(HttpServletResponse res) {
/* 168 */     String charset = "UTF-8";
/* 169 */     OutputStreamWriter osw = null;
/* 170 */     PrintWriter printw = null;
/*     */     try {
/* 172 */       res.setContentType("text/html;charset=" + charset);
/* 173 */       osw = new OutputStreamWriter((OutputStream)res.getOutputStream(), charset);
/* 174 */       printw = new PrintWriter(osw);
/*     */     }
/* 176 */     catch (Exception e) {
/*     */ 
/*     */       
/* 179 */       sendErrorResponse(res, 
/* 180 */           "steram create error.:" + e.getLocalizedMessage());
/* 181 */       if (printw != null) {
/* 182 */         printw.flush();
/* 183 */         printw.close();
/*     */       } 
/* 185 */       if (osw != null) {
/*     */         try {
/* 187 */           osw.close();
/*     */         }
/* 189 */         catch (IOException iOException) {}
/*     */       }
/*     */ 
/*     */       
/* 193 */       printw = null;
/*     */     } 
/* 195 */     return printw;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void sendErrorResponse(HttpServletResponse resp, String text) {
/* 208 */     resp.reset();
/*     */     
/*     */     try {
/* 211 */       resp.sendError(500, text);
/*     */     }
/* 213 */     catch (IOException iOException) {}
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\MCWebExecAgent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */