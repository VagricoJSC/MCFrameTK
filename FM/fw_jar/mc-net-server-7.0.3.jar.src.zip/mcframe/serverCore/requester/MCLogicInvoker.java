/*     */ package mcframe.serverCore.requester;
/*     */ 
/*     */ import java.util.List;
/*     */ import mcframe.commonCore.container.MCContainer;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.lang.MCTimestamp;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.param.MCContainerParam;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.commonCore.pio.MCDPReaderFactory;
/*     */ import mcframe.commonCore.pio.MCP2TBodyReader;
/*     */ import mcframe.commonCore.pio.MCP2THeaderReader;
/*     */ import mcframe.commonCore.pio.MCT2PBodyReader;
/*     */ import mcframe.commonCore.pio.util.MCDPFormat;
/*     */ import mcframe.commonCore.pio.util.MCParseTypeUtil;
/*     */ import mcframe.commonCore.sys.MCFactory;
/*     */ import mcframe.serverCore.logic.MCLogic;
/*     */ import mcframe.serverCore.mcjdbc.FWDBUtil;
/*     */ import mcframe.serverCore.mcjdbc.MCTransactionManager;
/*     */ import mcframe.serverCore.metrics.MetricsLogger;
/*     */ import mcframe.serverCore.metrics.OperationLog;
/*     */ import mcframe.serverCore.metrics.OperationMetricsLogger;
/*     */ import mcframe.serverCore.notice.MCMessagePool;
/*     */ import mcframe.serverCore.phase.MCLogicBeforeAfter;
/*     */ import mcframe.serverCore.phase.MCPhase;
/*     */ import mcframe.serverCore.requester.paging.MCPagingAgent;
/*     */ import mcframe.serverCore.requester.paging.MCPagingAgentJSON;
/*     */ import mcframe.serverCore.resource.MCConfig;
/*     */ import mcframe.serverCore.resource.MCConst;
/*     */ import mcframe.serverCore.sys.MCSys;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCLogicInvoker
/*     */ {
/*     */   public void invoke(MCDispatcherContext ctx) {
/*  60 */     MCLog.write(Core_Msg_FW_A.FCBGC0304, new Object[] { ctx.param().getModuleId(), ctx.param().getLogicId(), 
/*  61 */           ctx.param().getOperationId(), ctx.param().getVersion() });
/*     */ 
/*     */     
/*  64 */     boolean cf = false;
/*  65 */     boolean lf = false;
/*     */ 
/*     */     
/*     */     try {
/*  69 */       MCLogic lgc = MCLogicRefUtil.crtLgc(ctx.param());
/*     */       
/*  71 */       MCLogicRefUtil.initLgcPrm(lgc, ctx.param());
/*     */ 
/*     */       
/*  74 */       parseUp(ctx, lgc);
/*     */ 
/*     */       
/*  77 */       registerRefTime(ctx.param());
/*     */ 
/*     */       
/*  80 */       MCLogicProxy.proxy.startSQLTrace();
/*     */ 
/*     */       
/*  83 */       writeMetricsLog(ctx);
/*     */ 
/*     */       
/*  86 */       doLogicPhase(ctx, lgc);
/*     */       
/*  88 */       lf = true;
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/*  93 */         MCTransactionManager.listenerStart();
/*  94 */         MCTransactionManager.commit();
/*     */       } finally {
/*     */         
/*  97 */         MCTransactionManager.listenerStop();
/*     */       } 
/*     */       
/* 100 */       cf = true;
/*     */ 
/*     */ 
/*     */       
/* 104 */       notifyUpdateCache();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 109 */       MCServerSignalManagerImpl.delServerRequest(MCSys.request.serverRequestNo());
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 114 */         printRegister();
/*     */ 
/*     */         
/* 117 */         MCLogicProxy.proxy.stopSQLTrace();
/*     */ 
/*     */         
/* 120 */         registerCommitTime(ctx.param());
/*     */ 
/*     */         
/* 123 */         registerCoSysTimestamp(ctx.param());
/*     */ 
/*     */         
/* 126 */         checkOverCap(ctx);
/*     */ 
/*     */         
/* 129 */         parseDown(ctx);
/*     */       }
/* 131 */       catch (Throwable t) {
/*     */ 
/*     */ 
/*     */         
/* 135 */         throw MCRequesterUtil.convertAfterOperationException(t);
/*     */       } 
/*     */     } finally {
/*     */ 
/*     */       
/*     */       try {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 147 */         if (!cf) {
/* 148 */           MCTransactionManager.rollBack();
/*     */         }
/* 150 */         if (!lf)
/*     */         {
/* 152 */           MCLogicProxy.proxy.stopSQLTrace();
/*     */         }
/*     */       }
/* 155 */       catch (Exception e) {
/* 156 */         MCLog.write(e);
/*     */       } 
/*     */ 
/*     */       
/* 160 */       MCLog.write(Core_Msg_FW_A.FCBGC0305, new Object[] { ctx.param().getModuleId(), ctx.param().getLogicId(), 
/* 161 */             ctx.param().getOperationId(), ctx.param().getVersion() });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void checkOverCap(MCDispatcherContext ctx) {
/* 178 */     checkOverCapDefault(ctx);
/*     */   }
/*     */ 
/*     */   
/*     */   void checkOverCapDefault(MCDispatcherContext ctx) {
/* 183 */     MCDispatcherContext pctx = ctx.prevCtx();
/* 184 */     if (pctx != null && 
/* 185 */       MCPagingAgent.isPagingOperation(pctx.param())) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 192 */     if (ctx.param().getPagingParam().isEnabled()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 199 */     if (MCCapAgent.capacityCheckParam(ctx.param())) {
/* 200 */       MCCapAgent agnt = new MCCapAgent(ctx.param());
/* 201 */       agnt.parse();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void parseUp(MCDispatcherContext ctx, MCLogic lgc) {
/* 216 */     chkOpeVer(ctx.param(), lgc);
/*     */ 
/*     */     
/* 219 */     String path = MCRequesterUtil.uploadPath();
/* 220 */     ctx.param().getUploadFileParam().setResponseFilePath(path);
/*     */ 
/*     */ 
/*     */     
/* 224 */     MCDPFormat fmt = ctx.getUpDPT().getFormat();
/* 225 */     MCT2PBodyReader u_rdr = MCDPReaderFactory.upBodyToParam(fmt, 
/* 226 */         MCParseTypeUtil.getParseType(ctx.param()));
/* 227 */     u_rdr.parse(ctx.getUpDPT(), ctx.param());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void parseDown(MCDispatcherContext ctx) {
/* 240 */     MCPagingAgentJSON.paging(ctx);
/*     */ 
/*     */     
/* 243 */     ctx.param().getMessageParam().setMessage(MCMessagePool.getWrappedMessageList());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 248 */     MCDPFormat fmt = ctx.getUpDPT().getFormat();
/* 249 */     MCP2THeaderReader dRdrH = MCDPReaderFactory.downHeaderToText(fmt);
/* 250 */     dRdrH.read(ctx.param(), ctx.getDwDPW());
/* 251 */     MCP2TBodyReader d_rdr = MCDPReaderFactory.downBodyToText(fmt, 
/* 252 */         MCParseTypeUtil.getParseType(ctx.param()));
/* 253 */     d_rdr.read(ctx.param(), ctx.getDwDPW());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doLogicPhase(MCDispatcherContext ctx, MCLogic lgc) {
/* 267 */     if (ctx.param().getPagingParam().isEnabled() && 
/* 268 */       !ctx.param().getPagingParam().isFirst()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 275 */       MCTransactionManager.listenerStart();
/*     */ 
/*     */       
/* 278 */       MCPhase ph = crtLogicBeforeAfter(ctx.param());
/* 279 */       MCLogicBeforeAfter aph = crtCommonLogicBeforeAfter(ctx.param());
/*     */ 
/*     */       
/* 282 */       if (ph == null && aph == null) {
/*     */         
/* 284 */         invokeOpe(lgc, ctx.param());
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 290 */       else if (ph instanceof MCLogicBeforeAfter) {
/*     */         
/* 292 */         MCLogicBeforeAfter lba = (MCLogicBeforeAfter)ph;
/* 293 */         invokeOpeWithBeforeAfter(ctx, lgc, lba, aph);
/*     */       }
/* 295 */       else if (ph != null) {
/*     */         
/* 297 */         invokeOpeWithBeforeAfter(ctx, lgc, ph);
/*     */       } else {
/*     */         
/* 300 */         invokeOpeWithBeforeAfter(ctx, lgc, null, aph);
/*     */       }
/*     */     
/*     */     }
/*     */     finally {
/*     */       
/* 306 */       MCTransactionManager.listenerStop();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void invokeOpe(MCLogic lgc, MCParam p) {
/*     */     try {
/* 326 */       MCLogicRefUtil.invokeOpeExec(lgc, p);
/* 327 */       MCServerThreadManager.shutdown();
/*     */     }
/* 329 */     catch (Throwable t) {
/*     */       try {
/* 331 */         MCServerThreadManager.shutdownNow();
/* 332 */         MCServerThreadManager.joinAll();
/*     */       }
/* 334 */       catch (Throwable e) {
/*     */         
/* 336 */         if (!MCServerThreadManager.isInterruptedException(e) && 
/* 337 */           !MCServerThreadManager.isServerThreadException(e)) {
/* 338 */           MCLog.write(e);
/*     */         }
/*     */       } 
/* 341 */       if (t instanceof MCException) {
/* 342 */         MCException e = (MCException)t;
/* 343 */         List<MCException> exList = MCServerThreadManager.getCauseExeptionList();
/* 344 */         if ((MCServerThreadManager.isInterruptedException((Throwable)e) || 
/* 345 */           MCServerThreadManager.isServerThreadException((Throwable)e)) && 
/* 346 */           !exList.isEmpty())
/*     */         {
/* 348 */           e = exList.remove(0);
/*     */         }
/* 350 */         for (MCException e2 : exList) {
/* 351 */           e.addCauseMessage(e2.getMCMessage());
/*     */         }
/* 353 */         throw e;
/*     */       } 
/* 355 */       throw t;
/*     */     } finally {
/*     */       
/* 358 */       MCServerThreadManager.destroy();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void invokeOpeWithBeforeAfter(MCDispatcherContext ctx, MCLogic lgc, MCLogicBeforeAfter mlba, MCLogicBeforeAfter lba) {
/* 380 */     if (lba != null) {
/*     */       try {
/* 382 */         lba.invoke(ctx.param());
/*     */       }
/* 384 */       catch (Throwable t) {
/*     */         
/* 386 */         throwCatchedThrowable(t);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 391 */     if (mlba != null) {
/*     */       try {
/* 393 */         mlba.invoke(ctx.param());
/*     */       }
/* 395 */       catch (Throwable t) {
/*     */ 
/*     */         
/* 398 */         if (lba != null) {
/*     */           try {
/* 400 */             t = lba.destroy(ctx.param(), t);
/*     */           }
/* 402 */           catch (Throwable t2) {
/* 403 */             MCLog.write(t2);
/*     */           } 
/* 405 */           if (t != null) {
/* 406 */             throwCatchedThrowable(t);
/*     */           }
/*     */           
/*     */           return;
/*     */         } 
/* 411 */         throwCatchedThrowable(t);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 418 */       invokeOpe(lgc, ctx.param());
/*     */     }
/* 420 */     catch (Throwable t) {
/*     */       
/* 422 */       if (mlba != null) {
/*     */         try {
/* 424 */           t = mlba.destroy(ctx.param(), t);
/*     */         }
/* 426 */         catch (Throwable t2) {
/* 427 */           MCLog.write(t2);
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 432 */       if (lba != null)
/*     */       {
/*     */         
/* 435 */         if (t != null) {
/*     */           try {
/* 437 */             t = lba.destroy(ctx.param(), t);
/*     */           }
/* 439 */           catch (Throwable t2) {
/* 440 */             MCLog.write(t2);
/*     */           } 
/* 442 */           if (t != null) {
/* 443 */             throwCatchedThrowable(t);
/*     */           }
/*     */         } else {
/*     */ 
/*     */           
/*     */           try {
/*     */             
/* 450 */             lba.destroy(ctx.param());
/*     */           }
/* 452 */           catch (Throwable t2) {
/* 453 */             throwCatchedThrowable(t2);
/*     */           } 
/*     */         } 
/*     */       }
/*     */       
/* 458 */       if (t != null) {
/* 459 */         throwCatchedThrowable(t);
/*     */       } else {
/*     */         return;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 467 */     if (mlba != null) {
/*     */       try {
/* 469 */         mlba.destroy(ctx.param());
/*     */       }
/* 471 */       catch (Throwable t) {
/*     */ 
/*     */         
/* 474 */         if (lba != null) {
/*     */           try {
/* 476 */             t = lba.destroy(ctx.param(), t);
/*     */           }
/* 478 */           catch (Throwable t2) {
/* 479 */             MCLog.write(t2);
/*     */           } 
/* 481 */           if (t != null) {
/* 482 */             throwCatchedThrowable(t);
/*     */           }
/*     */           
/*     */           return;
/*     */         } 
/* 487 */         throwCatchedThrowable(t);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 493 */     if (lba != null) {
/*     */       try {
/* 495 */         lba.destroy(ctx.param());
/*     */       }
/* 497 */       catch (Throwable t) {
/* 498 */         throwCatchedThrowable(t);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void invokeOpeWithBeforeAfter(MCDispatcherContext ctx, MCLogic lgc, MCPhase ph) {
/* 521 */     Throwable err = null;
/*     */     
/*     */     try {
/* 524 */       ph.invoke(ctx.param());
/*     */ 
/*     */       
/* 527 */       invokeOpe(lgc, ctx.param());
/*     */     }
/* 529 */     catch (Throwable t) {
/*     */       
/* 531 */       err = t;
/*     */     } finally {
/*     */ 
/*     */       
/*     */       try {
/* 536 */         ph.destroy(ctx.param());
/*     */       }
/* 538 */       catch (Throwable t) {
/* 539 */         if (err == null) {
/*     */ 
/*     */           
/* 542 */           err = t;
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */           
/* 548 */           MCLog.write(t);
/*     */         } 
/*     */       } 
/*     */       
/* 552 */       if (err != null) {
/* 553 */         throwCatchedThrowable(err);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void throwCatchedThrowable(Throwable t) {
/* 573 */     if (t instanceof MCException)
/*     */     {
/* 575 */       throw (MCException)t;
/*     */     }
/* 577 */     if (t instanceof Error)
/*     */     {
/* 579 */       throw (Error)t;
/*     */     }
/*     */     
/* 582 */     throw new MCException(t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void chkOpeVer(MCParam p, MCLogic lgc) {
/* 595 */     MCLog.write(Core_Msg_FW_A.FCBGC0243, new Object[] { p.getModuleId(), p.getLogicId(), p.getOperationId(), 
/* 596 */           p.getVersion(), (lgc.info()).moduleId, (lgc.info()).logicId, 
/* 597 */           (lgc.info()).operationId, (lgc.info()).version });
/*     */ 
/*     */     
/* 600 */     if (p.getDlVersion() != null && p.getIdentifier() != null) {
/* 601 */       String sdver = MCConfig.server.getString("sd.version");
/* 602 */       String sdbld = MCConfig.server.getString("sd.build");
/* 603 */       if (sdver != null) {
/*     */         
/* 605 */         String dlver = p.getDlVersion();
/* 606 */         if (dlver == null || !dlver.equals(sdver))
/*     */         {
/* 608 */           throw new MCException(Core_Msg_FW_A.FCBGC0071, new Object[] { p.getModuleId(), p.getLogicId(), 
/* 609 */                 p.getOperationId(), dlver, sdver });
/*     */         }
/* 611 */         if (sdbld != null) {
/*     */           
/* 613 */           String dlbld = p.getDlBuild();
/* 614 */           if (dlbld == null || !dlbld.equals(sdbld))
/*     */           {
/* 616 */             throw new MCException(Core_Msg_FW_A.FCBGC0071, new Object[] { p.getModuleId(), p.getLogicId(), 
/* 617 */                   p.getOperationId(), String.valueOf(dlver) + "(" + dlbld + ")", 
/* 618 */                   String.valueOf(sdver) + "(" + sdbld + ")" });
/*     */           }
/*     */         } 
/*     */       } 
/* 622 */       if (p.getVersion() == null) {
/*     */         return;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 628 */     if (p.getVersion() == null || (lgc.info()).version == null || 
/* 629 */       !p.getVersion().equals((lgc.info()).version)) {
/* 630 */       throw new MCException(Core_Msg_FW_A.FCBGC0071, new Object[] { p.getModuleId(), p.getLogicId(), 
/* 631 */             p.getOperationId(), p.getVersion(), (lgc.info()).version });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCPhase crtLogicBeforeAfter(MCParam p) {
/* 646 */     String key = String.valueOf(p.getModuleId()) + ".class";
/* 647 */     MCPhase ph = (MCPhase)MCConst.plugin.create(MCPhase.class, 
/* 648 */         "dispatcher.logicBeforeAfter." + key);
/* 649 */     if (ph == null)
/*     */     {
/* 651 */       ph = (MCPhase)MCConst.plugin.create(MCPhase.class, 
/* 652 */           "dispatcher.logicBeforAfter." + key);
/*     */     }
/* 654 */     return ph;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCLogicBeforeAfter crtCommonLogicBeforeAfter(MCParam p) {
/* 664 */     return (MCLogicBeforeAfter)MCConst.plugin.create(MCLogicBeforeAfter.class, 
/* 665 */         "dispatcher.logicBeforeAfter.class");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void registerRefTime(MCParam p) {
/* 677 */     MCTimestamp ts = FWDBUtil.systimestampCo();
/*     */ 
/*     */     
/* 680 */     ts = ts.addMilliSecond(getAjustTime());
/*     */     
/* 682 */     p.setRequestTime(ts);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 688 */   static Integer AJUST_TM = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int getAjustTime() {
/* 698 */     if (AJUST_TM == null) {
/* 699 */       setAjustTime();
/*     */     }
/* 701 */     return AJUST_TM.intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static synchronized void setAjustTime() {
/* 711 */     AJUST_TM = 
/* 712 */       Integer.valueOf(MCConfig.server.getInteger(MCConfig.createKey(new String[] { "dispatcher", "AdjustRefTime" }, ), -1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void notifyUpdateCache() {
/* 726 */     if (MCConfig.server.getStringArray("tablecache.system.table") != null) {
/* 727 */       MCFactory.invokeStatic(
/* 728 */           MCFactory.getClass(Object.class, 
/* 729 */             "mcframe.serverCore.requester.MCCacheUpdateNotifier"), 
/* 730 */           "notifyFromRequest", null, null);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void printRegister() {
/* 741 */     if (MCReportSpooler.isSpool()) {
/*     */       try {
/* 743 */         MCFactory.invokeStatic(
/* 744 */             MCFactory.getClass(Object.class, 
/* 745 */               "mcframe.serverCore.report.MCServerReportManager"), 
/* 746 */             "printRegister", null, null);
/*     */       }
/* 748 */       catch (Throwable t) {
/* 749 */         MCLog.write((Throwable)new MCException(t, Core_Msg_FW_A.FCBIC0109, new Object[0]));
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void registerCommitTime(MCParam p) {
/* 763 */     if (p.getExceptionParam().isEmpty())
/*     */     {
/*     */       
/* 766 */       p.setCommitTime(MCTransactionManager.dbTran().commitTs());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void registerCoSysTimestamp(MCParam p) {
/* 780 */     if (p.getExceptionParam().isEmpty()) {
/* 781 */       p.setCoSysTimestamp(FWDBUtil.systimestampCo());
/*     */     }
/*     */   }
/*     */   
/*     */   private void writeMetricsLog(MCDispatcherContext ctx) {
/* 786 */     OperationMetricsLogger oml = MetricsLogger.operationLogger();
/* 787 */     OperationLog log = oml.createLog();
/*     */     
/* 789 */     log.setCoCd(MCSys.user.coCD());
/* 790 */     log.setUserId(MCSys.user.ID());
/* 791 */     log.setSrvReqNo(ctx.param().getServerRequestNo());
/* 792 */     log.setCallFuncId(ctx.param().getReqSrcId());
/* 793 */     log.setModuleId(ctx.param().getModuleId());
/* 794 */     log.setLogicId(ctx.param().getLogicId());
/* 795 */     log.setOpeId(ctx.param().getOperationId());
/*     */     
/* 797 */     MCContainerParam cp = ctx.param().getContainerParam();
/* 798 */     List<MCContainer> up = cp.up();
/*     */ 
/*     */     
/* 801 */     log.setBlock0Size((up.size() <= 0) ? null : Long.valueOf(getDenbunSize(up.get(0))));
/* 802 */     log.setBlock1Size((up.size() <= 1) ? null : Long.valueOf(getDenbunSize(up.get(1))));
/* 803 */     log.setBlock2Size((up.size() <= 2) ? null : Long.valueOf(getDenbunSize(up.get(2))));
/* 804 */     log.setBlock3Size((up.size() <= 3) ? null : Long.valueOf(getDenbunSize(up.get(3))));
/* 805 */     log.setBlock4Size((up.size() <= 4) ? null : Long.valueOf(getDenbunSize(up.get(4))));
/* 806 */     oml.write(log);
/*     */   }
/*     */   
/*     */   private long getDenbunSize(MCContainer c) {
/* 810 */     if (c == null) {
/* 811 */       return 0L;
/*     */     }
/* 813 */     if (c instanceof mcframe.commonCore.container.MCRow) {
/* 814 */       return 1L;
/*     */     }
/* 816 */     if (c instanceof MCList) {
/* 817 */       MCList<?> l = (MCList)c;
/* 818 */       return l.size();
/*     */     } 
/*     */     
/* 821 */     return 0L;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\MCLogicInvoker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */