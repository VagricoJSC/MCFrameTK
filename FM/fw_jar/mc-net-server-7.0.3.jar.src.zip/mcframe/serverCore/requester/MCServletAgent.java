/*      */ package mcframe.serverCore.requester;
/*      */ 
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import java.io.OutputStreamWriter;
/*      */ import java.io.PrintWriter;
/*      */ import java.io.StringWriter;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.net.URLDecoder;
/*      */ import java.nio.charset.Charset;
/*      */ import java.util.Enumeration;
/*      */ import java.util.zip.GZIPOutputStream;
/*      */ import javax.servlet.Servlet;
/*      */ import javax.servlet.ServletException;
/*      */ import javax.servlet.ServletInputStream;
/*      */ import javax.servlet.ServletOutputStream;
/*      */ import javax.servlet.annotation.WebServlet;
/*      */ import javax.servlet.http.HttpServlet;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import javax.servlet.http.HttpServletResponse;
/*      */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*      */ import mcframe.commonCore.notice.MCException;
/*      */ import mcframe.commonCore.notice.MCLog;
/*      */ import mcframe.commonCore.notice.MCMessage;
/*      */ import mcframe.commonCore.notice.MCMessageList;
/*      */ import mcframe.commonCore.param.MCDPWriter;
/*      */ import mcframe.commonCore.param.MCUploadFileParam;
/*      */ import mcframe.commonCore.param.MCUploadStream;
/*      */ import mcframe.commonCore.sys.MCCatalog;
/*      */ import mcframe.commonCore.sys.MCProduct;
/*      */ import mcframe.serverCore.resource.MCConfig;
/*      */ import mcframe.serverCore.sys.MCSys;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ @WebServlet(name = "MCServlet", urlPatterns = {"/MCServlet"}, loadOnStartup = 1)
/*      */ public class MCServletAgent
/*      */   extends HttpServlet
/*      */   implements Servlet
/*      */ {
/*   57 */   protected static String default_MCFrame_Charset = "UTF-8";
/*      */ 
/*      */   
/*      */   protected static boolean iso_8859_1_convert = true;
/*      */ 
/*      */   
/*      */   protected static boolean isInitSuccess = false;
/*      */ 
/*      */   
/*   66 */   protected static Exception initException = null;
/*      */ 
/*      */   
/*      */   protected static final String AcceptEncoding = "Accept-Encoding";
/*      */   
/*      */   protected static final String ContentEncoding = "Content-Encoding";
/*      */   
/*      */   protected static final String ContentCoding_GZIP = "gzip";
/*      */   
/*      */   protected static final String ContentType = "Content-Type";
/*      */   
/*      */   protected static final String ContentType_boundary = "boundary";
/*      */   
/*      */   protected static final String ContentType_charset = "charset";
/*      */   
/*      */   protected static final String ContentType_MULTIPART = "multipart/form-data";
/*      */   
/*      */   protected static final String ContentType_HTML = "text/html";
/*      */   
/*      */   protected static final String ContentType_TEXT = "text/plain";
/*      */   
/*      */   protected static final String ContentType_BINARY = "application/octet-stream";
/*      */   
/*      */   protected static final String ContentType_JSON = "application/json";
/*      */   
/*      */   protected static final String ContentDisposition = "Content-Disposition";
/*      */   
/*      */   protected static final String ContentDisposition_name = "name";
/*      */   
/*      */   protected static final String ContentDisposition_filename = "filename";
/*      */   
/*      */   protected static final String AccessControlAllowOrigin = "Access-Control-Allow-Origin";
/*      */   
/*      */   protected static final String UserAgent = "User-Agent";
/*      */   
/*      */   protected static final String ForwardedFor = "X-Forwarded-For";
/*      */   
/*      */   protected static final String MCFrameCharset = "X-MCFrame-Charset";
/*      */   
/*      */   protected static final String Parameter_argument = "argument";
/*      */   
/*      */   protected static final String PART_SEP = "\r\n";
/*      */ 
/*      */   
/*      */   public static String successStatusHtmlHead() {
/*  111 */     StringBuilder sb = new StringBuilder();
/*  112 */     sb.append("<head>");
/*  113 */     sb.append("<title>mcframe Server Status</title>");
/*  114 */     sb.append("</head>");
/*  115 */     sb.append("<body>");
/*  116 */     sb.append("<h1>mcframe server start SUCCESS.</h1>");
/*  117 */     return sb.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void logRequestDetail(HttpServletRequest req) {
/*  132 */     if (!MCLog.isEnabled(Core_Msg_FW_A.FCBGC0400)) {
/*      */       return;
/*      */     }
/*      */     
/*  136 */     StringBuilder sb = new StringBuilder();
/*      */     
/*  138 */     sb.append("##### Static");
/*  139 */     sb.append("\nAUTH_TYPE : " + req.getAuthType());
/*  140 */     sb.append("\nCharacterEncoding : " + req.getCharacterEncoding());
/*  141 */     sb.append("\nCONTENT_LENGTH : " + req.getContentLength());
/*  142 */     sb.append("\nCONTENT_TYPE : " + req.getContentType());
/*  143 */     sb.append("\nContextPath : " + req.getContextPath());
/*  144 */     sb.append("\nLocale : " + req.getLocale().toString());
/*  145 */     sb.append("\nLocalAddr : " + req.getLocalAddr());
/*  146 */     sb.append("\nLocalName : " + req.getLocalName());
/*  147 */     sb.append("\nLocalPort : " + req.getLocalPort());
/*  148 */     sb.append("\nREQUEST_METHOD : " + req.getMethod());
/*  149 */     sb.append("\nPATH_INFO : " + req.getPathInfo());
/*  150 */     sb.append("\nPATH_TRANSLATED : " + req.getPathTranslated());
/*  151 */     sb.append("\nSERVER_PROTOCOL : " + req.getProtocol());
/*  152 */     sb.append("\nQUERY_STRING : " + req.getQueryString());
/*  153 */     sb.append("\nREMOTE_ADDR : " + req.getRemoteAddr());
/*  154 */     sb.append("\nREMOTE_HOST : " + req.getRemoteHost());
/*  155 */     sb.append("\nRemotePort : " + req.getRemotePort());
/*  156 */     sb.append("\nREMOTE_USER : " + req.getRemoteUser());
/*  157 */     sb.append("\nRequestedSessionId : " + req.getRequestedSessionId());
/*  158 */     sb.append("\nRequestURI : " + req.getRequestURI());
/*  159 */     sb.append("\nRequestURL : " + req.getRequestURL());
/*  160 */     sb.append("\nScheme : " + req.getScheme());
/*  161 */     sb.append("\nSERVER_NAME : " + req.getServerName());
/*  162 */     sb.append("\nSERVER_PORT : " + req.getServerPort());
/*  163 */     sb.append("\nSCRIPT_NAME : " + req.getServletPath());
/*  164 */     sb.append("\n");
/*      */ 
/*      */ 
/*      */     
/*  168 */     sb.append("##### Header\n");
/*  169 */     Enumeration<?> e = req.getHeaderNames();
/*  170 */     while (e.hasMoreElements()) {
/*  171 */       String key = (String)e.nextElement();
/*  172 */       sb.append(String.valueOf(key) + " : " + req.getHeader(key));
/*  173 */       sb.append("\n");
/*      */     } 
/*      */     
/*  176 */     sb.append("##### Attribute\n");
/*  177 */     e = req.getAttributeNames();
/*  178 */     while (e.hasMoreElements()) {
/*  179 */       String key = (String)e.nextElement();
/*  180 */       sb.append(String.valueOf(key) + " : " + req.getAttribute(key));
/*  181 */       sb.append("\n");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void init() throws ServletException {
/*  203 */     super.init();
/*      */ 
/*      */ 
/*      */     
/*  207 */     if (isInitSuccess || initException != null) {
/*      */       return;
/*      */     }
/*      */     
/*  211 */     System.setProperty("MCF_TIER", "3");
/*      */     try {
/*  213 */       MCServerRequester.initFor3Tier(getServletName());
/*  214 */       isInitSuccess = true;
/*      */     }
/*  216 */     catch (Exception e) {
/*  217 */       isInitSuccess = false;
/*  218 */       initException = e;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
/*  237 */     doPost(req, res);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
/*  260 */     String ip = req.getHeader("X-Forwarded-For");
/*  261 */     ip = (ip != null) ? ip : req.getRemoteAddr();
/*  262 */     MCLog.write(Core_Msg_FW_A.FCBGC0398, new Object[] { req.getRemoteHost(), ip });
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  267 */     String charset = getCharset(req);
/*  268 */     req.setCharacterEncoding(charset);
/*      */     
/*  270 */     logRequestDetail(req);
/*      */ 
/*      */ 
/*      */     
/*  274 */     doRequest(charset, req, res);
/*      */ 
/*      */     
/*  277 */     MCLog.write(Core_Msg_FW_A.FCBGC0399, new Object[] { req.getRemoteHost(), ip });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getCharset(HttpServletRequest req) {
/*  293 */     String X_MCFrame_Charset = req.getHeader("X-MCFrame-Charset");
/*  294 */     if (X_MCFrame_Charset == null) {
/*  295 */       X_MCFrame_Charset = default_MCFrame_Charset;
/*      */     }
/*  297 */     else if (!Charset.isSupported(X_MCFrame_Charset)) {
/*      */       
/*  299 */       X_MCFrame_Charset = default_MCFrame_Charset;
/*      */     } 
/*  301 */     return X_MCFrame_Charset;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doRequest(String charset, HttpServletRequest req, HttpServletResponse res) {
/*  322 */     boolean gzip = isSupportGzip(req);
/*      */ 
/*      */     
/*  325 */     String boundary = getMultipartBoundary(req);
/*      */     
/*      */     try {
/*  328 */       if (boundary == null)
/*      */       {
/*  330 */         doSinglePartRequest(charset, gzip, req, res);
/*      */       }
/*      */       else
/*      */       {
/*  334 */         doMultiPartRequest(boundary, charset, gzip, req, res);
/*      */       }
/*      */     
/*  337 */     } catch (Throwable e) {
/*  338 */       MCException mce = (e instanceof MCException) ? (MCException)e : new MCException(e);
/*  339 */       MCLog.write((Throwable)mce);
/*      */       
/*  341 */       sendErrorResponse(res, mce.getMessage());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isSupportGzip(HttpServletRequest req) {
/*  355 */     boolean supportedGzip = false;
/*  356 */     String encoding = req.getHeader("Accept-Encoding");
/*  357 */     if (encoding != null && 
/*  358 */       encoding.toLowerCase().indexOf("gzip") > -1) {
/*  359 */       supportedGzip = true;
/*      */     }
/*  361 */     return supportedGzip;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getMultipartBoundary(HttpServletRequest req) {
/*  373 */     if (req == null) {
/*  374 */       return null;
/*      */     }
/*  376 */     String ct = req.getHeader("Content-Type");
/*  377 */     if (ct == null)
/*      */     {
/*  379 */       return null;
/*      */     }
/*  381 */     if (ct.startsWith("multipart/form-data")) {
/*      */       
/*  383 */       int begin = ct.indexOf("boundary=") + 
/*  384 */         "boundary".length() + 1;
/*  385 */       int end = ct.indexOf(';', begin);
/*  386 */       return (end > -1) ? ct.substring(begin, end) : ct.substring(begin);
/*      */     } 
/*      */ 
/*      */     
/*  390 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doMultiPartRequest(String boundary, String charset, boolean gzip, HttpServletRequest req, HttpServletResponse res) {
/*  414 */     String up = null;
/*      */     
/*  416 */     MCUploadFileParam upfp = new MCUploadFileParam();
/*      */ 
/*      */     
/*  419 */     String start = "--" + boundary;
/*  420 */     String end = String.valueOf(start) + "--";
/*      */     
/*  422 */     byte[] start_b = start.getBytes();
/*  423 */     byte[] end_b = end.getBytes();
/*  424 */     byte[] sep_b = "\r\n".getBytes();
/*  425 */     int seplen = sep_b.length;
/*      */ 
/*      */     
/*  428 */     int templen = (end_b.length + 2 > 8192) ? (
/*  429 */       end_b.length + 2) : 8192;
/*  430 */     byte[] temp = new byte[templen];
/*      */ 
/*      */     
/*  433 */     byte[] line = new byte[templen];
/*  434 */     int linelen = 0;
/*  435 */     boolean part = false;
/*  436 */     boolean content = false;
/*  437 */     String name = null;
/*  438 */     MCUploadStream file = null;
/*      */     try {
/*  440 */       ServletInputStream sis = req.getInputStream(); int readlen;
/*  441 */       while ((readlen = sis.readLine(temp, 0, templen)) > -1) {
/*  442 */         if (byteStartWith(start_b, temp, 0, readlen)) {
/*      */           
/*  444 */           if (content)
/*      */           {
/*  446 */             if (file == null) {
/*      */               
/*  448 */               if (name != null && 
/*  449 */                 name.equals("argument") && 
/*  450 */                 up == null)
/*      */               {
/*      */ 
/*      */                 
/*  454 */                 up = mcURLDecode(line, 0, linelen - seplen, charset);
/*      */               
/*      */               }
/*      */             
/*      */             }
/*      */             else {
/*      */               
/*  461 */               file.cutoff(seplen);
/*      */               
/*  463 */               upfp.addResponse(name, file);
/*      */             } 
/*      */           }
/*  466 */           linelen = 0;
/*  467 */           part = false;
/*  468 */           content = false;
/*  469 */           name = null;
/*  470 */           file = null;
/*      */           
/*  472 */           if (byteStartWith(end_b, temp, 0, readlen)) {
/*      */             break;
/*      */           }
/*      */ 
/*      */           
/*  477 */           part = true;
/*      */           continue;
/*      */         } 
/*  480 */         if (!part) {
/*      */           continue;
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*  486 */         if (!content) {
/*      */           
/*  488 */           line = addByte(line, linelen, temp, readlen);
/*  489 */           linelen += readlen;
/*  490 */           if (!byteStartWith(sep_b, temp, readlen - seplen, readlen)) {
/*      */             continue;
/*      */           }
/*      */ 
/*      */           
/*  495 */           if (linelen == seplen) {
/*      */             
/*  497 */             content = true;
/*      */ 
/*      */           
/*      */           }
/*      */           else {
/*      */ 
/*      */ 
/*      */             
/*  505 */             String header = new String(line, 0, linelen, charset);
/*      */ 
/*      */ 
/*      */             
/*  509 */             if (header.startsWith("Content-Disposition:")) {
/*      */               
/*  511 */               name = getFieldParamValue(header, 
/*  512 */                   "name");
/*      */               
/*  514 */               String filename = getFieldParamValue(header, 
/*  515 */                   "filename");
/*  516 */               if (filename != null)
/*      */               {
/*  518 */                 file = createUploadStream(name, filename);
/*      */               }
/*      */             } 
/*      */           } 
/*      */           
/*  523 */           linelen = 0;
/*      */           
/*      */           continue;
/*      */         } 
/*  527 */         if (file != null) {
/*      */           
/*  529 */           file.write(temp, 0, readlen);
/*      */           
/*      */           continue;
/*      */         } 
/*  533 */         line = addByte(line, linelen, temp, readlen);
/*  534 */         linelen += readlen;
/*      */       } 
/*      */ 
/*      */       
/*  538 */       doRequestMain(up, upfp, charset, gzip, req, res);
/*      */     }
/*  540 */     catch (Throwable ex) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  549 */       throw (ex instanceof MCException) ? (MCException)ex : new MCException(ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getFieldParamValue(String data, String param) {
/*  563 */     int begin = data.indexOf(String.valueOf(param) + '=');
/*  564 */     if (begin < 0)
/*      */     {
/*  566 */       return null;
/*      */     }
/*      */     
/*  569 */     char last = ';';
/*  570 */     begin += param.length() + 1;
/*  571 */     if (data.charAt(begin) == '"') {
/*      */       
/*  573 */       begin++;
/*  574 */       last = '"';
/*      */     } 
/*  576 */     int end = data.indexOf(last, begin);
/*  577 */     return data.substring(begin, (end < 0) ? data.length() : end);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private byte[] addByte(byte[] dest, int offset, byte[] src, int length) {
/*  597 */     if (dest.length < offset + length) {
/*  598 */       byte[] temp = new byte[offset + length + 128];
/*  599 */       System.arraycopy(dest, 0, temp, 0, offset);
/*  600 */       dest = temp;
/*      */     } 
/*  602 */     System.arraycopy(src, 0, dest, offset, length);
/*  603 */     return dest;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean byteStartWith(byte[] prefix, byte[] data, int offset, int length) {
/*  626 */     if (data == null) {
/*  627 */       return false;
/*      */     }
/*  629 */     if (prefix == null) {
/*  630 */       return false;
/*      */     }
/*  632 */     if (offset < 0 || length <= offset) {
/*  633 */       return false;
/*      */     }
/*  635 */     int pre_len = prefix.length;
/*  636 */     if (pre_len > length - offset) {
/*  637 */       return false;
/*      */     }
/*  639 */     for (int i = 0; i < pre_len; i++) {
/*  640 */       if (data[offset + i] != prefix[i]) {
/*  641 */         return false;
/*      */       }
/*      */     } 
/*  644 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MCUploadStream createUploadStream(String id, String srcname) {
/*  660 */     return new MCUploadStream(id, srcname);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doSinglePartRequest(String charset, boolean gzip, HttpServletRequest req, HttpServletResponse res) {
/*      */     try {
/*  679 */       int templen = 8192;
/*  680 */       byte[] temp = new byte[templen];
/*      */ 
/*      */       
/*  683 */       ByteArrayOutputStream baos = new ByteArrayOutputStream();
/*      */       
/*  685 */       ServletInputStream sis = req.getInputStream();
/*  686 */       int readlen = sis.readLine(temp, 0, 17);
/*      */ 
/*      */       
/*  689 */       while ((readlen = sis.readLine(temp, 0, templen)) > -1)
/*      */       {
/*      */         
/*  692 */         baos.write(temp, 0, readlen);
/*      */       }
/*      */       
/*  695 */       String up = mcURLDecode(baos.toByteArray(), charset);
/*  696 */       doRequestMain(up, (MCUploadFileParam)null, charset, gzip, req, res);
/*      */     }
/*  698 */     catch (Throwable ex) {
/*      */       
/*  700 */       throw (ex instanceof MCException) ? (MCException)ex : new MCException(ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void sendErrorResponse(HttpServletResponse resp, String text) {
/*  720 */     resp.reset();
/*      */     
/*      */     try {
/*  723 */       resp.sendError(500, text);
/*      */     }
/*  725 */     catch (IOException ex) {
/*      */ 
/*      */       
/*  728 */       MCLog.write(ex);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String mcURLDecode(byte[] data, String charset) throws UnsupportedEncodingException {
/*  749 */     if (data == null || data.length == 0) {
/*  750 */       return "";
/*      */     }
/*  752 */     return mcURLDecode(data, 0, data.length, charset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String mcURLDecode(byte[] data, int offset, int length, String charset) throws UnsupportedEncodingException {
/*  774 */     if (data == null || data.length == 0) {
/*  775 */       return "";
/*      */     }
/*  777 */     if (length > data.length) {
/*  778 */       length = data.length;
/*      */     }
/*      */ 
/*      */     
/*  782 */     String up = new String(data, offset, length, "UTF-8");
/*  783 */     if (charset.equals(default_MCFrame_Charset))
/*      */     {
/*      */ 
/*      */       
/*  787 */       up = up.replaceAll("%C0%80", "%00");
/*      */     }
/*  789 */     return URLDecoder.decode(up, charset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doRequestMain(String up, MCUploadFileParam upfp, String charset, boolean gzip, HttpServletRequest req, HttpServletResponse res) {
/*  880 */     if (up == null || up.equals("")) {
/*      */       
/*  882 */       doServTest(charset, gzip, req, res);
/*      */     }
/*      */     else {
/*      */       
/*  886 */       doMCFServPost(up, upfp, charset, gzip, req, res);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doMCFServPost(String up, MCUploadFileParam upfp, String charset, boolean gzip, HttpServletRequest req, HttpServletResponse res) {
/*  913 */     MCLog.write(Core_Msg_FW_A.FCBGC0346, new Object[] { up });
/*      */ 
/*      */     
/*  916 */     logUpload(upfp);
/*      */     
/*  918 */     if (isMCNETRequest(req))
/*      */     {
/*      */ 
/*      */       
/*  922 */       charset = null;
/*      */     }
/*      */     
/*  925 */     execute(up, upfp, res, gzip, charset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void logUpload(MCUploadFileParam upfp) {
/*  939 */     if (upfp != null) {
/*  940 */       MCLog.write(Core_Msg_FW_A.FCBGC0349, new Object[] { upfp.toString() });
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isMCNETRequest(HttpServletRequest req) {
/*  954 */     String agent = req.getHeader("User-Agent");
/*  955 */     return (agent != null && agent.equals("mcframe NET DLL"));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void execute(String up, MCUploadFileParam upfp, HttpServletResponse res, boolean gzip, String charset) {
/*  973 */     MCDPWriter pw = getResponseWriter(res, gzip, charset);
/*  974 */     if (pw == null) {
/*      */       return;
/*      */     }
/*      */     
/*  978 */     MCServerRequester requester = new MCServerRequester();
/*  979 */     requester.srvRequest(pw, up, upfp);
/*  980 */     pw.flush();
/*  981 */     pw.close();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MCDPWriter getResponseWriter(HttpServletResponse resp, boolean isSupportGzip, String charset) {
/*  999 */     if (resp == null) {
/* 1000 */       return null;
/*      */     }
/*      */ 
/*      */     
/* 1004 */     OutputStream outputStream = null;
/*      */     try {
/* 1006 */       ServletOutputStream servletOutputStream = resp.getOutputStream();
/* 1007 */       if (isSupportGzip) {
/* 1008 */         outputStream = new GZIPOutputStream((OutputStream)servletOutputStream);
/*      */       }
/*      */     }
/* 1011 */     catch (IOException e) {
/*      */       
/* 1013 */       MCLog.write(e);
/* 1014 */       if (outputStream != null) {
/*      */         try {
/* 1016 */           outputStream.flush();
/* 1017 */           outputStream.close();
/*      */         }
/* 1019 */         catch (IOException iOException) {}
/*      */       }
/*      */ 
/*      */       
/* 1023 */       return null;
/*      */     } 
/*      */ 
/*      */     
/* 1027 */     MCDPWriter dpw = null;
/* 1028 */     if (charset != null) {
/*      */       
/*      */       try {
/* 1031 */         dpw = new MCDPWriter(new OutputStreamWriter(outputStream, charset), 
/* 1032 */             true);
/*      */       }
/* 1034 */       catch (Exception e) {
/*      */         
/* 1036 */         MCLog.write(e);
/* 1037 */         return null;
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/* 1042 */       dpw = new MCDPWriter(outputStream, true);
/* 1043 */       charset = default_MCFrame_Charset;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1048 */     String ct = getContentType();
/* 1049 */     resp.setContentType(String.valueOf(ct) + ';' + "charset" + '=' + charset);
/* 1050 */     resp.setHeader("X-MCFrame-Charset", charset);
/* 1051 */     if (isSupportGzip) {
/* 1052 */       resp.setHeader("Content-Encoding", "gzip");
/*      */     }
/*      */ 
/*      */     
/* 1056 */     String allowOrigin = MCConfig.server.getString("http.cors.allow-origin", "*");
/* 1057 */     resp.setHeader("Access-Control-Allow-Origin", allowOrigin);
/*      */     
/* 1059 */     return dpw;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getContentType() {
/* 1072 */     return MCConfig.server.getString("http.header.contenttype", 
/* 1073 */         "text/plain");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void sendResponse(HttpServletResponse resp, String response, boolean isSupportGzip, String charset) {
/*      */     try {
/*      */       ServletOutputStream servletOutputStream;
/* 1093 */       resp.setContentType("text/html;charset=" + 
/* 1094 */           charset);
/* 1095 */       resp.setHeader("X-MCFrame-Charset", charset);
/*      */       
/* 1097 */       OutputStream os = null;
/* 1098 */       if (isSupportGzip) {
/* 1099 */         resp.setHeader("Content-Encoding", "gzip");
/* 1100 */         os = new GZIPOutputStream((OutputStream)resp.getOutputStream());
/*      */       } else {
/*      */         
/* 1103 */         servletOutputStream = resp.getOutputStream();
/*      */       } 
/*      */       try {
/* 1106 */         Exception exception2, exception1 = null;
/*      */ 
/*      */       
/*      */       }
/*      */       finally {
/*      */ 
/*      */ 
/*      */         
/* 1114 */         if (servletOutputStream != null)
/*      */         {
/* 1116 */           servletOutputStream.close();
/*      */         }
/*      */       }
/*      */     
/* 1120 */     } catch (Exception e) {
/*      */ 
/*      */       
/* 1123 */       throw new MCException(e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doServTest(String charset, boolean gzip, HttpServletRequest req, HttpServletResponse res) {
/* 1148 */     if (!isInitSuccess) {
/* 1149 */       sendServTestErrResponse(res, gzip, charset);
/*      */       return;
/*      */     } 
/* 1152 */     sendServTestSucResponse(res, gzip, charset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void sendServTestSucResponse(HttpServletResponse resp, boolean isSupportGzip, String charset) {
/* 1169 */     StringBuilder sb = new StringBuilder(successStatusHtmlHead());
/*      */ 
/*      */     
/* 1172 */     addVersionHTML(sb, "MCF_HOME", MCSys.catalog, MCSys.product);
/*      */ 
/*      */     
/* 1175 */     String warpath = getServletContext().getRealPath("/WEB-INF");
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1180 */     if (warpath != null) {
/* 1181 */       File wardir = new File(warpath);
/* 1182 */       addVersionHTML(sb, "WEB-INF", 
/* 1183 */           new MCCatalog(wardir), new MCProduct(wardir));
/*      */     } 
/*      */     
/* 1186 */     sb.append("</body>");
/* 1187 */     sendResponse(resp, sb.toString(), isSupportGzip, charset);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void addVersionHTML(StringBuilder sb, String title, MCCatalog c, MCProduct p) {
/* 1202 */     MCMessageList list = MCSys.getVersionMessages(c, p);
/* 1203 */     int size = list.size();
/* 1204 */     if (size > 0) {
/* 1205 */       sb.append("<h3>Version (");
/* 1206 */       sb.append(title);
/* 1207 */       sb.append(")</h3>");
/* 1208 */       for (int i = 0; i < size; i++) {
/* 1209 */         MCMessage msg = (MCMessage)list.get(i);
/* 1210 */         sb.append(msg.toString());
/* 1211 */         sb.append("<br>");
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void sendServTestErrResponse(HttpServletResponse resp, boolean isSupportGzip, String charset) {
/* 1230 */     StringWriter sw = new StringWriter();
/* 1231 */     PrintWriter pw = new PrintWriter(sw);
/* 1232 */     pw
/* 1233 */       .append("<html>")
/* 1234 */       .append("<head>")
/* 1235 */       .append("<title>mcframe Server Status</title>")
/* 1236 */       .append("</head>")
/* 1237 */       .append("<body>")
/* 1238 */       .append("<h1>mcframe server start ERROR.</h1>")
/* 1239 */       .append("cause:<br/>")
/* 1240 */       .append(initException.getMessage())
/* 1241 */       .append("<br/>")
/* 1242 */       .append("<pre>");
/* 1243 */     initException.printStackTrace(pw);
/* 1244 */     pw
/* 1245 */       .append("</pre>")
/* 1246 */       .append("</body>");
/* 1247 */     String errHtm = sw.toString();
/*      */     
/* 1249 */     sendResponse(resp, errHtm, isSupportGzip, charset);
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\MCServletAgent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */