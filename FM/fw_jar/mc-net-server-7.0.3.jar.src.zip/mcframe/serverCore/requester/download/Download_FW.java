/*     */ package mcframe.serverCore.requester.download;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import mcframe.commonCore.lang.MCBinary;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.param.MCDownloadStream;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.commonCore.requester.MCDownloadUtil;
/*     */ import mcframe.serverCore.mcjdbc.MCTransactionManager;
/*     */ import mcframe.serverCore.resource.MCConfig;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Download_FW
/*     */   extends Download_FW_A
/*     */ {
/*  48 */   private MCParam _dlp = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paramBinDl(MCParam p) {
/*  54 */     super.paramBinDl(p);
/*  55 */     this._dlp = p;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void paramMCBinDl(MCParam p) {
/*  60 */     super.paramMCBinDl(p);
/*  61 */     this._dlp = p;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void paramFileDl(MCParam p) {
/*  66 */     super.paramFileDl(p);
/*  67 */     this._dlp = p;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class BinDl
/*     */     extends Download_FW_A.BinDl
/*     */   {
/*     */     protected void call() {
/*  80 */       CndR cndR = up0();
/*  81 */       MCNumber pointer = cndR.pointer();
/*     */ 
/*     */       
/*  84 */       MCDownloadStream dls = Download_FW.this.getDBFileStream(pointer.longValue());
/*     */ 
/*     */       
/*  87 */       Download_FW.this._dlp.getDownloadStreamParam().add(dls);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class MCBinDl
/*     */     extends Download_FW_A.MCBinDl
/*     */   {
/*     */     protected void call() {
/*  98 */       CndR cndR = up0();
/*  99 */       MCBinary bin = cndR.bin();
/* 100 */       if (bin == null)
/*     */       {
/* 102 */         throw new MCException(Core_Msg_FW_A.FCBGC0085, new Object[] { bin });
/*     */       }
/*     */       
/* 105 */       MCDownloadStream dls = null;
/* 106 */       if (bin.isDBFile()) {
/*     */         
/* 108 */         dls = Download_FW.this.getDBFileStream(bin.toDBPointer());
/*     */       } else {
/*     */         
/* 111 */         File file = bin.toFile();
/* 112 */         dls = Download_FW.this.getLocalFileStream(file);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 117 */       Download_FW.this._dlp.getDownloadStreamParam().add(dls);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class FileDl
/*     */     extends Download_FW_A.FileDl
/*     */   {
/*     */     protected void call() {
/* 128 */       CndR cndR = up0();
/*     */ 
/*     */       
/* 131 */       String path = cndR.path();
/*     */ 
/*     */       
/* 134 */       String base = MCConfig.server.getString("net.download.dir", 
/* 135 */           MCDownloadUtil.downloadPath());
/* 136 */       File file = new File(base, path);
/*     */ 
/*     */ 
/*     */       
/* 140 */       MCDownloadStream dls = Download_FW.this.getLocalFileStream(file);
/* 141 */       Download_FW.this._dlp.getDownloadStreamParam().add(dls);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCDownloadStream getDBFileStream(long pointer) {
/* 156 */     if (pointer == Long.MIN_VALUE)
/*     */     {
/* 158 */       throw new MCException(Core_Msg_FW_A.FCBGC0085, new Object[] { "(blank pointer)" });
/*     */     }
/*     */ 
/*     */     
/* 162 */     MCDownloadStream dls = MCTransactionManager.dbTran().statement().selectBinary(pointer);
/* 163 */     if (dls == null)
/*     */     {
/* 165 */       throw new MCException(Core_Msg_FW_A.FCBGC0085, new Object[] { String.valueOf(pointer) });
/*     */     }
/*     */ 
/*     */     
/* 169 */     String name = MCDownloadUtil.createBinaryFileName(
/* 170 */         String.valueOf(pointer), dls.getName());
/* 171 */     dls.setName(name);
/*     */     
/* 173 */     return dls;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCDownloadStream getLocalFileStream(File file) {
/* 186 */     if (file == null)
/*     */     {
/* 188 */       throw new MCException(Core_Msg_FW_A.FCBGC0078, new Object[] { file });
/*     */     }
/* 190 */     if (!file.isFile())
/*     */     {
/* 192 */       throw new MCException(Core_Msg_FW_A.FCBGC0078, new Object[] { file.getAbsolutePath() });
/*     */     }
/*     */ 
/*     */     
/* 196 */     FileInputStream fis = null;
/* 197 */     MCDownloadStream dls = null;
/*     */     
/*     */     try {
/* 200 */       fis = new FileInputStream(file);
/* 201 */       dls = new MCDownloadStream(fis, file);
/*     */     }
/* 203 */     catch (FileNotFoundException fileNotFoundException) {
/*     */       
/* 205 */       throw new MCException(Core_Msg_FW_A.FCBGC0078, new Object[] { file.getAbsolutePath() });
/*     */     }
/* 207 */     catch (Exception ex) {
/* 208 */       MCException mce = (ex instanceof MCException) ? 
/* 209 */         (MCException)ex : 
/* 210 */         new MCException(ex);
/* 211 */       if (dls != null) {
/*     */         try {
/* 213 */           dls.close();
/*     */         }
/* 215 */         catch (IOException iOException) {}
/*     */       }
/*     */ 
/*     */       
/* 219 */       if (fis != null) {
/*     */         try {
/* 221 */           fis.close();
/*     */         }
/* 223 */         catch (IOException iOException) {}
/*     */       }
/*     */ 
/*     */       
/* 227 */       throw mce;
/*     */     } 
/* 229 */     return dls;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\download\Download_FW.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */