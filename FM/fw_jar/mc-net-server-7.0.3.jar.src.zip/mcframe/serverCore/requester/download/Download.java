package mcframe.serverCore.requester.download;

import mcframe.commonCore.annotation.EI;

@EI
public class Download extends Download_FW {}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\download\Download.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */