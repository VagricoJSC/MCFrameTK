/*     */ package mcframe.serverCore.requester.download;
/*     */ 
/*     */ import mcframe.commonCore.container.MCContainer;
/*     */ import mcframe.commonCore.param.MCOperationInfo;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.serverCore.logic.MCLogic;
/*     */ import mcframe.serverCore.logic.MCLogicBase;
/*     */ import mcframe.serverCore.logic.MCLogicUtil;
/*     */ import mcframe.serverCore.logic.MCOperation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Download_FW_A
/*     */   extends MCLogicBase
/*     */ {
/*     */   public static final String MODULE_ID = "FC";
/*     */   public static final String SUBMODULE_ID = "FCBG";
/*     */   public static final String LOGIC_ID = "FCBGL0020";
/*     */   protected Download_FW.BinDl aBinDl;
/*     */   protected Download_FW.FileDl aFileDl;
/*     */   protected Download_FW.MCBinDl aMCBinDl;
/*     */   
/*     */   public String getModuleID() {
/*  42 */     return "FC";
/*     */   } public String getSubmoduleID() {
/*  44 */     return "FCBG";
/*     */   } public String getLogicID() {
/*  46 */     return "FCBGL0020";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CndR createCndR() {
/*  56 */     return CndR.create();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initBinDl() {
/*  61 */     this.info = PDef.FC_FCBGL0020_BinDl_INFO;
/*  62 */     ((Download)this).getClass(); this.aBinDl = new Download_FW.BinDl((Download)this);
/*     */   }
/*     */   
/*     */   public static Download_FW.BinDl crtBinDl() {
/*  66 */     Download lgc = new Download();
/*  67 */     lgc.initBinDl();
/*  68 */     return lgc.aBinDl;
/*     */   }
/*     */   
/*     */   protected void paramBinDl(MCParam p) {
/*  72 */     if (this.aBinDl == null) {
/*     */       return;
/*     */     }
/*  75 */     p.setDef(this.info.def);
/*  76 */     p.addUpBlock((MCContainer)this.aBinDl.up0());
/*     */   }
/*     */   
/*     */   protected void doBinDl() {
/*  80 */     this.aBinDl.call();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initFileDl() {
/*  85 */     this.info = PDef.FC_FCBGL0020_FileDl_INFO;
/*  86 */     ((Download)this).getClass(); this.aFileDl = new Download_FW.FileDl((Download)this);
/*     */   }
/*     */   
/*     */   public static Download_FW.FileDl crtFileDl() {
/*  90 */     Download lgc = new Download();
/*  91 */     lgc.initFileDl();
/*  92 */     return lgc.aFileDl;
/*     */   }
/*     */   
/*     */   protected void paramFileDl(MCParam p) {
/*  96 */     if (this.aFileDl == null) {
/*     */       return;
/*     */     }
/*  99 */     p.setDef(this.info.def);
/* 100 */     p.addUpBlock((MCContainer)this.aFileDl.up0());
/*     */   }
/*     */   
/*     */   protected void doFileDl() {
/* 104 */     this.aFileDl.call();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initMCBinDl() {
/* 109 */     this.info = PDef.FC_FCBGL0020_MCBinDl_INFO;
/* 110 */     ((Download)this).getClass(); this.aMCBinDl = new Download_FW.MCBinDl((Download)this);
/*     */   }
/*     */   
/*     */   public static Download_FW.MCBinDl crtMCBinDl() {
/* 114 */     Download lgc = new Download();
/* 115 */     lgc.initMCBinDl();
/* 116 */     return lgc.aMCBinDl;
/*     */   }
/*     */   
/*     */   protected void paramMCBinDl(MCParam p) {
/* 120 */     if (this.aMCBinDl == null) {
/*     */       return;
/*     */     }
/* 123 */     p.setDef(this.info.def);
/* 124 */     p.addUpBlock((MCContainer)this.aMCBinDl.up0());
/*     */   }
/*     */   
/*     */   protected void doMCBinDl() {
/* 128 */     this.aMCBinDl.call();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract class BinDl
/*     */     extends MCOperation
/*     */   {
/*     */     public static final String OPERATION_ID = "BinDl";
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final CndR up0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getOperationID() {
/* 150 */       return "BinDl";
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected BinDl() {
/* 161 */       this.up0 = CndR.create();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void mapUpContainers(String key) {
/* 175 */       super.mapUpContainers(key);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void mapDownContainers(String key) {
/* 183 */       super.mapDownContainers(key);
/*     */     }
/*     */     
/*     */     public MCContainer up(int i) {
/* 187 */       if (i == 0) return (MCContainer)up0(); 
/* 188 */       return null;
/*     */     }
/*     */     
/*     */     public MCContainer down(int i) {
/* 192 */       return null;
/*     */     }
/*     */     
/*     */     public void exec() {
/* 196 */       clear();
/* 197 */       MCLogicUtil.invoke((MCLogic)Download_FW_A.this);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void clear() {}
/*     */ 
/*     */ 
/*     */     
/*     */     public CndR createCndR() {
/* 208 */       return CndR.create();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CndR up0() {
/* 224 */       return this.up0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MCOperationInfo getOperationInfo() {
/* 232 */       return Download_FW_A.this.info;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract class FileDl
/*     */     extends MCOperation
/*     */   {
/*     */     public static final String OPERATION_ID = "FileDl";
/*     */ 
/*     */ 
/*     */     
/*     */     private final CndR up0;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getOperationID() {
/* 252 */       return "FileDl";
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected FileDl() {
/* 263 */       this.up0 = CndR.create();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void mapUpContainers(String key) {
/* 277 */       super.mapUpContainers(key);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void mapDownContainers(String key) {
/* 285 */       super.mapDownContainers(key);
/*     */     }
/*     */     
/*     */     public MCContainer up(int i) {
/* 289 */       if (i == 0) return (MCContainer)up0(); 
/* 290 */       return null;
/*     */     }
/*     */     
/*     */     public MCContainer down(int i) {
/* 294 */       return null;
/*     */     }
/*     */     
/*     */     public void exec() {
/* 298 */       clear();
/* 299 */       MCLogicUtil.invoke((MCLogic)Download_FW_A.this);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void clear() {}
/*     */ 
/*     */ 
/*     */     
/*     */     public CndR createCndR() {
/* 310 */       return CndR.create();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CndR up0() {
/* 326 */       return this.up0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MCOperationInfo getOperationInfo() {
/* 334 */       return Download_FW_A.this.info;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract class MCBinDl
/*     */     extends MCOperation
/*     */   {
/*     */     public static final String OPERATION_ID = "MCBinDl";
/*     */ 
/*     */ 
/*     */     
/*     */     private final CndR up0;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getOperationID() {
/* 354 */       return "MCBinDl";
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected MCBinDl() {
/* 365 */       this.up0 = CndR.create();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void mapUpContainers(String key) {
/* 379 */       super.mapUpContainers(key);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void mapDownContainers(String key) {
/* 387 */       super.mapDownContainers(key);
/*     */     }
/*     */     
/*     */     public MCContainer up(int i) {
/* 391 */       if (i == 0) return (MCContainer)up0(); 
/* 392 */       return null;
/*     */     }
/*     */     
/*     */     public MCContainer down(int i) {
/* 396 */       return null;
/*     */     }
/*     */     
/*     */     public void exec() {
/* 400 */       clear();
/* 401 */       MCLogicUtil.invoke((MCLogic)Download_FW_A.this);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void clear() {}
/*     */ 
/*     */ 
/*     */     
/*     */     public CndR createCndR() {
/* 412 */       return CndR.create();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CndR up0() {
/* 428 */       return this.up0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MCOperationInfo getOperationInfo() {
/* 436 */       return Download_FW_A.this.info;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\download\Download_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */