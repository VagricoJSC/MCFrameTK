/*    */ package mcframe.serverCore.requester.download;
/*    */ 
/*    */ import mcframe.commonCore.param.MCBlockDef;
/*    */ import mcframe.commonCore.param.MCContainerDef;
/*    */ import mcframe.commonCore.param.MCDef;
/*    */ import mcframe.commonCore.param.MCGeneralContainerDef;
/*    */ import mcframe.commonCore.param.MCItemDef;
/*    */ import mcframe.commonCore.param.MCOperationInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PDef_FW_A
/*    */   extends MCDef
/*    */ {
/*    */   public MCContainerDef getCustomDef(String id) {
/* 22 */     if (id == null) {
/* 23 */       return null;
/*    */     }
/*    */     
/* 26 */     if (id.equals("FC.FCBGL0020.BinDl.UP.BLOCK0")) {
/* 27 */       return FC_FCBGL0020_BinDl_UP_BLOCK0();
/*    */     }
/* 29 */     if (id.equals("FC.FCBGL0020.FileDl.UP.BLOCK0")) {
/* 30 */       return FC_FCBGL0020_FileDl_UP_BLOCK0();
/*    */     }
/* 32 */     if (id.equals("FC.FCBGL0020.MCBinDl.UP.BLOCK0")) {
/* 33 */       return FC_FCBGL0020_MCBinDl_UP_BLOCK0();
/*    */     }
/*    */ 
/*    */     
/* 37 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 43 */   static final MCOperationInfo FC_FCBGL0020_BinDl_INFO = new MCOperationInfo("FC", "FCBGL0020", "BinDl", "000000", new PDef());
/*    */ 
/*    */   
/*    */   public static MCContainerDef FC_FCBGL0020_BinDl_UP_BLOCK0() {
/* 47 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL0020", "BinDl", 
/* 48 */         new MCItemDef[] {
/* 49 */           MCItemDef.create("pointer", "pointer")
/*    */ 
/*    */         
/* 52 */         }MCBlockDef.create("Cnd"));
/*    */   }
/*    */ 
/*    */   
/* 56 */   static final MCOperationInfo FC_FCBGL0020_FileDl_INFO = new MCOperationInfo("FC", "FCBGL0020", "FileDl", "000000", new PDef());
/*    */ 
/*    */   
/*    */   public static MCContainerDef FC_FCBGL0020_FileDl_UP_BLOCK0() {
/* 60 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL0020", "FileDl", 
/* 61 */         new MCItemDef[] {
/* 62 */           MCItemDef.create("path", "path")
/*    */ 
/*    */         
/* 65 */         }MCBlockDef.create("Cnd"));
/*    */   }
/*    */ 
/*    */   
/* 69 */   static final MCOperationInfo FC_FCBGL0020_MCBinDl_INFO = new MCOperationInfo("FC", "FCBGL0020", "MCBinDl", "000000", new PDef());
/*    */ 
/*    */   
/*    */   public static MCContainerDef FC_FCBGL0020_MCBinDl_UP_BLOCK0() {
/* 73 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL0020", "MCBinDl", 
/* 74 */         new MCItemDef[] {
/* 75 */           MCItemDef.create("bin", "bin")
/*    */ 
/*    */         
/* 78 */         }MCBlockDef.create("Cnd"));
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\download\PDef_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */