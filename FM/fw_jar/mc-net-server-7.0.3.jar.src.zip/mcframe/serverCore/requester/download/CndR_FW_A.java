/*     */ package mcframe.serverCore.requester.download;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.commonCore.container.MCConstRow;
/*     */ import mcframe.commonCore.container.MCExtMap;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCBinary;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ import mcframe.commonCore.meta.M_META;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class CndR_FW_A
/*     */   extends MCConstRow
/*     */ {
/*     */   public static final String $pointer = "pointer";
/*     */   public static final String $bin = "bin";
/*     */   public static final String $path = "path";
/*  45 */   public static final MCMeta pointer_META = createCommonMeta("pointer", M_META.BID);
/*  46 */   public static final MCMeta bin_META = createBinaryMeta("bin");
/*  47 */   public static final MCMeta path_META = createStringMeta("path");
/*     */   
/*  49 */   protected static final MCRow.ConstMetaList<CndR> constMetas = new MCRow.ConstMetaList(
/*  50 */       MCConstRow.constMetas, 
/*  51 */       new MCMeta[] {
/*  52 */         pointer_META, 
/*  53 */         bin_META, 
/*  54 */         path_META
/*     */       },
/*  56 */       new String[][] { {}, {} });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   protected static final MCExtMap EXTMAP = new MCExtMap(
/*  69 */       null, new MCExtMap.Entry[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] colnames() {
/*  81 */     return constMetas.toNameArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMeta[] colmetas() {
/*  93 */     return constMetas.toMetaArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  99 */   private static final int offset = constMetas.offset();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getExtMap(String aGroup) {
/* 105 */     if (aGroup == null) return null; 
/* 106 */     return (Map<String, String>)EXTMAP.get(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getKeys(String aGroup) {
/* 113 */     if (aGroup == null) return null; 
/* 114 */     return EXTMAP.getKeyList(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExtGroups() {
/* 121 */     Set<String> ret = EXTMAP.keySet();
/* 122 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CndR_FW_A(MCRow.ConstMetaList<? extends CndR> metas) {
/* 129 */     super(metas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CndR clone() {
/* 136 */     return (CndR)super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CndR createInstance() {
/* 143 */     return (CndR)super.createInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CndR getValues(String... names) {
/* 150 */     return (CndR)super.getValues(names);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireValueChanged(String column, Comparable<?> newvalue, Comparable<?> oldvalue) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCNumber pointer() {
/* 166 */     return getConstNumber(offset + 0, "pointer");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pointer(MCNumber value) {
/* 174 */     setConstNumber(offset + 0, "pointer", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pointer(int value) {
/* 182 */     setConstNumber(offset + 0, "pointer", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pointer(long value) {
/* 190 */     setConstNumber(offset + 0, "pointer", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pointer(float value) {
/* 198 */     setConstNumber(offset + 0, "pointer", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pointer(double value) {
/* 206 */     setConstNumber(offset + 0, "pointer", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCBinary bin() {
/* 215 */     return getConstBinary(offset + 1, "bin");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void bin(MCBinary value) {
/* 223 */     setConstBinary(offset + 1, "bin", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String path() {
/* 232 */     return getConstString(offset + 2, "path");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void path(String value) {
/* 240 */     setConstString(offset + 2, "path", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString(String name) {
/* 245 */     if ("path".equalsIgnoreCase(name)) {
/* 246 */       return path();
/*     */     }
/* 248 */     return super.getString(name);
/*     */   }
/*     */   public MCNumber getNumber(String name) {
/* 251 */     if ("pointer".equalsIgnoreCase(name)) {
/* 252 */       return pointer();
/*     */     }
/* 254 */     return super.getNumber(name);
/*     */   }
/*     */   public MCBinary getBinary(String name) {
/* 257 */     if ("bin".equalsIgnoreCase(name)) {
/* 258 */       return bin();
/*     */     }
/* 260 */     return super.getBinary(name);
/*     */   }
/*     */   
/*     */   public String getStringNE(String name) {
/* 264 */     if ("path".equalsIgnoreCase(name)) {
/* 265 */       return path();
/*     */     }
/* 267 */     return super.getStringNE(name);
/*     */   }
/*     */   public MCNumber getNumberNE(String name) {
/* 270 */     if ("pointer".equalsIgnoreCase(name)) {
/* 271 */       return pointer();
/*     */     }
/* 273 */     return super.getNumberNE(name);
/*     */   }
/*     */   public MCBinary getBinaryNE(String name) {
/* 276 */     if ("bin".equalsIgnoreCase(name)) {
/* 277 */       return bin();
/*     */     }
/* 279 */     return super.getBinaryNE(name);
/*     */   }
/*     */   
/*     */   public void setString(String name, String value) {
/* 283 */     if ("path".equalsIgnoreCase(name)) {
/* 284 */       path(value);
/*     */       return;
/*     */     } 
/* 287 */     super.setString(name, value);
/*     */   }
/*     */   public void setNumber(String name, MCNumber value) {
/* 290 */     if ("pointer".equalsIgnoreCase(name)) {
/* 291 */       pointer(value);
/*     */       return;
/*     */     } 
/* 294 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, int value) {
/* 297 */     if ("pointer".equalsIgnoreCase(name)) {
/* 298 */       pointer(value);
/*     */       return;
/*     */     } 
/* 301 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, long value) {
/* 304 */     if ("pointer".equalsIgnoreCase(name)) {
/* 305 */       pointer(value);
/*     */       return;
/*     */     } 
/* 308 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, float value) {
/* 311 */     if ("pointer".equalsIgnoreCase(name)) {
/* 312 */       pointer(value);
/*     */       return;
/*     */     } 
/* 315 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, double value) {
/* 318 */     if ("pointer".equalsIgnoreCase(name)) {
/* 319 */       pointer(value);
/*     */       return;
/*     */     } 
/* 322 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setBinary(String name, MCBinary value) {
/* 325 */     if ("bin".equalsIgnoreCase(name)) {
/* 326 */       bin(value);
/*     */       return;
/*     */     } 
/* 329 */     super.setBinary(name, value);
/*     */   }
/*     */   
/*     */   public void setStringNE(String name, String value) {
/* 333 */     if ("path".equalsIgnoreCase(name)) {
/* 334 */       path(value);
/*     */       return;
/*     */     } 
/* 337 */     super.setStringNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, MCNumber value) {
/* 340 */     if ("pointer".equalsIgnoreCase(name)) {
/* 341 */       pointer(value);
/*     */       return;
/*     */     } 
/* 344 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, int value) {
/* 347 */     if ("pointer".equalsIgnoreCase(name)) {
/* 348 */       pointer(value);
/*     */       return;
/*     */     } 
/* 351 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, long value) {
/* 354 */     if ("pointer".equalsIgnoreCase(name)) {
/* 355 */       pointer(value);
/*     */       return;
/*     */     } 
/* 358 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, float value) {
/* 361 */     if ("pointer".equalsIgnoreCase(name)) {
/* 362 */       pointer(value);
/*     */       return;
/*     */     } 
/* 365 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, double value) {
/* 368 */     if ("pointer".equalsIgnoreCase(name)) {
/* 369 */       pointer(value);
/*     */       return;
/*     */     } 
/* 372 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setBinaryNE(String name, MCBinary value) {
/* 375 */     if ("bin".equalsIgnoreCase(name)) {
/* 376 */       bin(value);
/*     */       return;
/*     */     } 
/* 379 */     super.setBinaryNE(name, value);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\download\CndR_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */