/*     */ package mcframe.serverCore.requester;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Optional;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCSimpleMultiPartParam
/*     */ {
/*  20 */   private List<MCFileDisposition> fileList = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  25 */   private List<MCStringDisposition> stringList = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addParam(String name, String value) {
/*  37 */     addParam(name, value, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addParam(String name, String value, String contentType) {
/*  50 */     this.stringList.add(new MCStringDisposition(name, value, contentType, null));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addParam(String name, String filename, File file, String contentType) {
/*  64 */     this.fileList.add(new MCFileDisposition(name, filename, file, contentType, null));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   List<MCStringDisposition> getStringDisposition() {
/*  74 */     return this.stringList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   List<MCFileDisposition> getFileDisposition() {
/*  84 */     return this.fileList;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   class MCFileDisposition
/*     */   {
/*     */     private String name;
/*     */ 
/*     */     
/*     */     private String contentType;
/*     */ 
/*     */     
/*     */     private String filename;
/*     */     
/*     */     private File file;
/*     */ 
/*     */     
/*     */     private MCFileDisposition(String name, String filename, File file, String contentType) {
/* 103 */       this.name = name;
/* 104 */       this.filename = filename;
/* 105 */       this.file = file;
/* 106 */       this.contentType = contentType;
/*     */     }
/*     */     
/*     */     String getName() {
/* 110 */       return this.name;
/*     */     }
/*     */     
/*     */     String getContentType() {
/* 114 */       return this.contentType;
/*     */     }
/*     */     
/*     */     String getFilename() {
/* 118 */       return this.filename;
/*     */     }
/*     */     
/*     */     File getFile() {
/* 122 */       return this.file;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   class MCStringDisposition
/*     */   {
/*     */     private String name;
/*     */ 
/*     */     
/*     */     private Optional<String> contentType;
/*     */     
/*     */     private String value;
/*     */ 
/*     */     
/*     */     private MCStringDisposition(String name, String value, String contentType) {
/* 139 */       this.name = name;
/* 140 */       this.contentType = Optional.ofNullable(contentType);
/* 141 */       this.value = value;
/*     */     }
/*     */     
/*     */     String getName() {
/* 145 */       return this.name;
/*     */     }
/*     */     
/*     */     Optional<String> getContentType() {
/* 149 */       return this.contentType;
/*     */     }
/*     */     
/*     */     String getValue() {
/* 153 */       return this.value;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\MCSimpleMultiPartParam.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */