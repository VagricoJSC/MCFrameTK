/*     */ package mcframe.serverCore.requester;
/*     */ 
/*     */ import java.util.List;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.notice.MCMessageList;
/*     */ import mcframe.commonCore.requester.MCClusterServerRole;
/*     */ import mcframe.commonCore.sys.MCFactory;
/*     */ import mcframe.serverCore.dbc.FCM_SERVER_R;
/*     */ import mcframe.serverCore.mcjdbc.MCDBTransaction;
/*     */ import mcframe.serverCore.mcjdbc.MCLockTableMode;
/*     */ import mcframe.serverCore.mcjdbc.MCTransactionManager;
/*     */ import mcframe.serverCore.push.MCServerPushManager;
/*     */ import mcframe.serverCore.queryapi.IFMCFMSQL;
/*     */ import mcframe.serverCore.queryapi.IFMCSQL;
/*     */ import mcframe.serverCore.queryapi.MCDBContainer;
/*     */ import mcframe.serverCore.queryapi.MCQueryApiBuilder;
/*     */ import mcframe.serverCore.resource.MCConfig;
/*     */ import mcframe.serverCore.sys.MCSys;
/*     */ import mcframe.serverCore.util.MCDBUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCClusterManager
/*     */ {
/*  44 */   private static MCClusterManager _mgr = new MCClusterManager();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCClusterManager getManager() {
/*  54 */     return _mgr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void entryServer(String servletName) {
/*  83 */     MCDBTransaction tran = null;
/*     */     try {
/*  85 */       String url = getServerURL();
/*  86 */       String name = getServerName();
/*  87 */       if (url == null)
/*     */       {
/*  89 */         throw new MCException(Core_Msg_FW_A.FCBGC0451, new Object[] { url, name, servletName });
/*     */       }
/*  91 */       if (url.lastIndexOf("/" + servletName) < 0)
/*     */       {
/*  93 */         throw new MCException(Core_Msg_FW_A.FCBGC0451, new Object[] { url, name, servletName });
/*     */       }
/*  95 */       if (name == null)
/*     */       {
/*  97 */         throw new MCException(Core_Msg_FW_A.FCBGC0451, new Object[] { url, name, servletName });
/*     */       }
/*     */ 
/*     */       
/* 101 */       tran = MCTransactionManager.createDBTran();
/*     */ 
/*     */ 
/*     */       
/* 105 */       MCList<FCM_SERVER_R> list = getServer(url, name);
/* 106 */       boolean newsrv = (list.size() <= 0);
/*     */       
/* 108 */       FCM_SERVER_R dbc = FCM_SERVER_R.create("M");
/*     */       
/* 110 */       boolean taskmgr = newsrv ? (
/*     */         
/* 112 */         (MCDBUtil.execDbCount("FC_MCClusterManager_entryServer_1", (MCDBContainer)dbc) <= 0)) : (
/*     */         
/* 114 */         (list.getFirst("task_sche_mgr", Boolean.valueOf(true)) != null));
/*     */ 
/*     */       
/* 117 */       int flags = 65535;
/* 118 */       if (!newsrv) {
/* 119 */         MCNumber role = ((FCM_SERVER_R)list.get(0)).srv_role();
/* 120 */         if (role != null) {
/* 121 */           flags = role.intValue();
/*     */         }
/*     */         
/* 124 */         MCDBUtil.dbDeleteKey("FC_MCClusterManager_entryServer_2", list, (MCDBContainer)dbc);
/*     */       } 
/*     */ 
/*     */       
/* 128 */       FCM_SERVER_R row = FCM_SERVER_R.create("M");
/* 129 */       row.url(url);
/* 130 */       row.srv_id(name);
/* 131 */       row.srv_role(flags);
/* 132 */       row.task_sche_mgr(taskmgr);
/* 133 */       MCQueryApiBuilder builder = MCQueryApiBuilder.create((MCDBContainer)row);
/* 134 */       MCDBUtil.dbInsert("FC_MCClusterManager_entryServer_3", (MCRow)row, builder);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 140 */       tran.commit();
/*     */ 
/*     */       
/* 143 */       MCList<FCM_SERVER_R> own = MCList.create(FCM_SERVER_R.class);
/* 144 */       own.add((MCRow)row);
/* 145 */       updateServerRole(own);
/*     */ 
/*     */       
/* 148 */       if (taskmgr)
/*     */       {
/*     */         
/* 151 */         Class<?> miningClass = MCFactory.getClass(
/* 152 */             Object.class, "mcframe.serverCore.mining.MCMiningManager");
/* 153 */         Object mining = MCFactory.invokeStatic(miningClass, "getManager", null, null);
/* 154 */         Object msgs = MCFactory.invoke(mining, "promote", null, null);
/* 155 */         if (((MCMessageList)msgs).size() > 0)
/*     */         {
/* 157 */           MCLog.write(Core_Msg_FW_A.FCBAC0463, new Object[0]);
/*     */         }
/*     */         
/* 160 */         tran.commit();
/*     */       }
/*     */     
/*     */     }
/* 164 */     catch (Exception e) {
/* 165 */       MCException mce = (e instanceof MCException) ? 
/* 166 */         (MCException)e : new MCException(e);
/* 167 */       MCLog.write((Throwable)mce);
/*     */       
/* 169 */       throw mce;
/*     */     
/*     */     }
/*     */     finally {
/*     */       
/* 174 */       MCTransactionManager.finalClose();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getServerName() {
/* 186 */     return MCConfig.server.getString("server.name");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getServerURL() {
/* 197 */     return MCConfig.server.getString("server.url");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int lives(MCClusterServerRole... roles) {
/* 210 */     return getLiveServer(roles).size();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getLiveURLs(MCClusterServerRole... roles) {
/* 223 */     MCList<FCM_SERVER_R> srvL = getLiveServer(roles);
/* 224 */     List<String> urlList = srvL.getString("url");
/* 225 */     return urlList.<String>toArray(new String[urlList.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCList<FCM_SERVER_R> getLiveServer(MCClusterServerRole... roles) {
/* 238 */     if (!MCSys.env.is3Tier())
/*     */     {
/* 240 */       return MCList.create(FCM_SERVER_R.class);
/*     */     }
/*     */ 
/*     */     
/* 244 */     MCList<FCM_SERVER_R> srvL = getActiveServer(roles);
/*     */ 
/*     */     
/* 247 */     MCList<FCM_SERVER_R> infoL = MCList.create(FCM_SERVER_R.class);
/* 248 */     for (FCM_SERVER_R srvR : srvL) {
/* 249 */       if (checkLiveURL(srvR.url())) {
/* 250 */         infoL.add((MCRow)srvR);
/*     */       }
/*     */     } 
/*     */     
/* 254 */     return infoL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkLiveURL(String url) {
/* 270 */     String ok = MCServletAgent.successStatusHtmlHead();
/*     */     try {
/* 272 */       MCClusterRequester req = new MCClusterRequester(url);
/* 273 */       req.setTimeout(10000);
/* 274 */       String res = req.request(null, null, null);
/* 275 */       if (!res.contains(ok))
/*     */       {
/* 277 */         MCLog.write(Core_Msg_FW_A.FCBGC0432, new Object[] { url });
/* 278 */         return false;
/*     */       }
/*     */     
/* 281 */     } catch (Exception e) {
/*     */       
/* 283 */       MCLog.write((Throwable)new MCException(e, Core_Msg_FW_A.FCBGC0432, new Object[] { url }));
/* 284 */       return false;
/*     */     } 
/* 286 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getActiveURLs(MCClusterServerRole... roles) {
/* 299 */     MCList<FCM_SERVER_R> srvL = getActiveServer(roles);
/* 300 */     List<String> urlList = srvL.getString("url");
/* 301 */     return urlList.<String>toArray(new String[urlList.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCList<FCM_SERVER_R> getActiveServer(MCClusterServerRole... roles) {
/* 314 */     MCList<FCM_SERVER_R> srvL = MCList.create(FCM_SERVER_R.class);
/* 315 */     FCM_SERVER_R dbc = FCM_SERVER_R.create("M");
/* 316 */     MCQueryApiBuilder builder = MCQueryApiBuilder.create((MCDBContainer)dbc);
/* 317 */     if (roles != null) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 322 */       int flags = 0; byte b; int i; MCClusterServerRole[] arrayOfMCClusterServerRole;
/* 323 */       for (i = (arrayOfMCClusterServerRole = roles).length, b = 0; b < i; ) { MCClusterServerRole role = arrayOfMCClusterServerRole[b];
/* 324 */         if (role != null)
/*     */         {
/*     */           
/* 327 */           flags += role.toFlag(); }  b++; }
/*     */       
/* 329 */       builder.addWhereWithAnd(IFMCSQL.bitAnd((IFMCFMSQL.MCFMAGNumberExpr)dbc.srv_role, (IFMCFMSQL.MCFMAGNumberExpr)IFMCSQL.bind("1")).eq(IFMCSQL.bind("2")), new Comparable[] { Integer.valueOf(flags), Integer.valueOf(flags) });
/*     */     } 
/* 331 */     MCDBUtil.dbSelect("FC_MCClusterManager_getActiveServer", srvL, builder);
/* 332 */     return srvL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateServerRole() {
/* 343 */     String url = getServerURL();
/* 344 */     String name = getServerName();
/* 345 */     MCList<FCM_SERVER_R> list = getServer(url, name);
/*     */     
/* 347 */     updateServerRole(list);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateServerRole(MCList<FCM_SERVER_R> list) {
/* 361 */     if (list != null)
/*     */     {
/* 363 */       for (FCM_SERVER_R row : list) {
/* 364 */         boolean push_enable = false;
/* 365 */         MCNumber roles = row.srv_role();
/* 366 */         if (roles != null) {
/* 367 */           int flags = roles.intValue();
/* 368 */           push_enable = MCClusterServerRole.PUSH.conatinsFlag(flags);
/*     */         } 
/*     */         
/* 371 */         MCServerPushManager.getManager().setEnabled(push_enable);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCList<FCM_SERVER_R> getServer(String url, String name) {
/* 394 */     MCTransactionManager.dbTran().statement().lockTable("FCM_SERVER", MCLockTableMode.X, false);
/*     */     
/* 396 */     MCList<FCM_SERVER_R> list = MCList.create(FCM_SERVER_R.class);
/* 397 */     FCM_SERVER_R dbc = FCM_SERVER_R.create("M");
/* 398 */     MCQueryApiBuilder builder = MCQueryApiBuilder.create((MCDBContainer)dbc);
/* 399 */     builder.setWhere(
/* 400 */         dbc.url.eq(IFMCSQL.bind("1"))
/* 401 */         .or(dbc.srv_id.eq(IFMCSQL.bind("2"))), new Comparable[] {
/* 402 */           url, 
/* 403 */           name
/*     */         });
/* 405 */     MCDBUtil.dbSelect("FC_MCClusterManager_getServer", list, builder);
/* 406 */     return list;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\MCClusterManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */