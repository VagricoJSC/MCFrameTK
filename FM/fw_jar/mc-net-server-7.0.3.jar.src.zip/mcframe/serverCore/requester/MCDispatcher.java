/*     */ package mcframe.serverCore.requester;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.param.MCExceptionParam;
/*     */ import mcframe.commonCore.pio.MCDPReaderFactory;
/*     */ import mcframe.commonCore.pio.MCP2TBodyReader;
/*     */ import mcframe.commonCore.pio.MCP2THeaderReader;
/*     */ import mcframe.commonCore.pio.util.MCDPFormat;
/*     */ import mcframe.commonCore.pio.util.MCParseTypeUtil;
/*     */ import mcframe.serverCore.mcjdbc.MCSavepoint;
/*     */ import mcframe.serverCore.mcjdbc.MCTransactionManager;
/*     */ import mcframe.serverCore.notice.MCMessagePool;
/*     */ import mcframe.serverCore.phase.MCPhase;
/*     */ import mcframe.serverCore.phase.MCPhasesFactory;
/*     */ import mcframe.serverCore.resource.MCConst;
/*     */ import mcframe.serverCore.sys.MCSys;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MCDispatcher
/*     */ {
/*     */   private final MCDispatcherContext ctx;
/*     */   
/*     */   public MCDispatcher(MCDispatcherContext ctx) {
/*  51 */     this.ctx = ctx;
/*  52 */     String m = ctx.param().getModuleId();
/*  53 */     String l = ctx.param().getLogicId();
/*  54 */     String o = ctx.param().getOperationId();
/*     */     
/*  56 */     int type = MCConst.operation.getInvokeType(m, l, o);
/*  57 */     ctx.setInvokeType(type);
/*     */     
/*  59 */     if (MCConst.operation.isListLogic(m, l, o)) {
/*  60 */       ctx.setListLogic();
/*     */     }
/*     */     
/*  63 */     if (MCConst.operation.isNative(m, l, o)) {
/*  64 */       ctx.setNative();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init() {
/*  77 */     if (this.ctx.getRequestStatus() != null) {
/*  78 */       this.ctx.getRequestStatus().run();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() {
/*  91 */     if (this.ctx.getRequestStatus() != null) {
/*  92 */       if (this.ctx.param().getExceptionParam().isEmpty()) {
/*  93 */         this.ctx.getRequestStatus().success();
/*     */       } else {
/*     */         
/*  96 */         this.ctx.getRequestStatus().error();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void execute() {
/* 111 */     MCLog.write(Core_Msg_FW_A.FCBGC0232, new Object[0]); try {
/*     */       MCException phase_ex; Iterator<MCPhase> iterator; boolean isStartSql;
/* 113 */       LinkedList<MCPhase> p_stk = new LinkedList<>();
/*     */ 
/*     */       
/* 116 */       boolean tf = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 122 */       try { MCLogicProxy.proxy.setDBConnectionInfo(MCTransactionManager.dbTran());
/* 123 */         MCTransactionManager.dbTran().getDBConnectionBody().setOperationInfo();
/*     */ 
/*     */         
/* 126 */         MCPhase authenticate = MCPhasesFactory.createAuthentication(this.ctx);
/* 127 */         MCPhase servSts = MCPhasesFactory.createServStsCtrl(this.ctx);
/* 128 */         MCPhase authorize = MCPhasesFactory.createAuthorization(this.ctx);
/* 129 */         MCPhase paraOpe = MCPhasesFactory.createParaOpeCtrl(this.ctx);
/* 130 */         MCPhase maxOpe = MCPhasesFactory.createMaxOpeCtrl(this.ctx);
/*     */         
/* 132 */         MCLogicInvoker li = MCLogicInvokerFactory.create(this.ctx);
/*     */ 
/*     */         
/* 135 */         MCLog.write(Core_Msg_FW_A.FCBGC0326, new Object[] { authenticate.getClass().getName() });
/* 136 */         authenticate.invoke(this.ctx.param());
/* 137 */         p_stk.offer(authenticate);
/*     */ 
/*     */         
/* 140 */         MCLog.write(Core_Msg_FW_A.FCBGC0351, new Object[] { servSts.getClass().getName() });
/* 141 */         servSts.invoke(this.ctx.param());
/* 142 */         p_stk.offer(servSts);
/*     */ 
/*     */         
/* 145 */         MCLog.write(Core_Msg_FW_A.FCBGC0327, new Object[] { authorize.getClass().getName() });
/* 146 */         authorize.invoke(this.ctx.param());
/* 147 */         p_stk.offer(authorize);
/*     */ 
/*     */         
/* 150 */         MCLog.write(Core_Msg_FW_A.FCBGC0328, new Object[] { paraOpe.getClass().getName() });
/* 151 */         paraOpe.invoke(this.ctx.param());
/* 152 */         p_stk.offer(paraOpe);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 158 */         MCLog.write(Core_Msg_FW_A.FCBGC0329, new Object[] { maxOpe.getClass().getName() });
/* 159 */         maxOpe.invoke(this.ctx.param());
/* 160 */         p_stk.offer(maxOpe);
/*     */ 
/*     */ 
/*     */         
/* 164 */         MCTransactionManager.dbTran().commit();
/* 165 */         tf = true;
/*     */ 
/*     */         
/*     */         try {
/* 169 */           MCServerSignalManagerImpl.addServerRequest(MCSys.request.serverRequestNo());
/* 170 */           li.invoke(this.ctx);
/*     */         } finally {
/*     */           
/* 173 */           MCServerSignalManagerImpl.delServerRequest(MCSys.request.serverRequestNo());
/*     */         
/*     */         }
/*     */         
/*     */          }
/*     */       
/* 179 */       catch (Throwable e)
/*     */       
/* 181 */       { if (!tf)
/*     */         {
/* 183 */           MCTransactionManager.dbTran().rollback();
/*     */         }
/*     */         
/* 186 */         handleExecuteException(e);
/*     */ 
/*     */ 
/*     */         
/* 190 */         MCException mCException = null;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 195 */         Iterator<MCPhase> iterator1 = p_stk.descendingIterator(); } finally { MCException mCException = null; Iterator<MCPhase> iterator1 = p_stk.descendingIterator();
/*     */         
/* 197 */         boolean bool = MCTransactionManager.dbTran().isStartSql();
/*     */         try {
/* 199 */           MCSavepoint s = null;
/* 200 */           while (iterator1.hasNext()) {
/* 201 */             MCPhase p = iterator1.next();
/* 202 */             if (p instanceof mcframe.serverCore.phase.MCInactivePhase) {
/*     */               continue;
/*     */             }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             try {
/* 211 */               if (s == null || MCTransactionManager.dbTran().isStartSql()) {
/* 212 */                 s = MCTransactionManager.dbTran().setSavepoint();
/*     */               }
/*     */               
/* 215 */               MCTransactionManager.dbTran()._setStartSqlForPhase(false);
/*     */             
/*     */             }
/* 218 */             catch (Exception ex) {
/* 219 */               MCLog.write(ex);
/*     */               try {
/* 221 */                 s = MCTransactionManager.createDBTran().setSavepoint();
/*     */                 
/* 223 */                 bool = MCTransactionManager.dbTran().isStartSql();
/*     */               }
/* 225 */               catch (Exception ex2) {
/* 226 */                 MCLog.write(ex2);
/*     */               } 
/*     */             } 
/*     */ 
/*     */             
/*     */             try {
/* 232 */               p.destroy(this.ctx.param());
/* 233 */               if (!bool)
/*     */               {
/* 235 */                 bool = MCTransactionManager.dbTran().isStartSql();
/*     */               }
/* 237 */               MCLog.write(Core_Msg_FW_A.FCBGC0403, new Object[] { p.getClass().getName() });
/*     */             }
/* 239 */             catch (Throwable t) {
/*     */ 
/*     */               
/*     */               try {
/*     */ 
/*     */                 
/* 245 */                 if (s != null) {
/* 246 */                   MCTransactionManager.dbTran().rollback(s);
/*     */                   
/* 248 */                   s = null;
/*     */                 }
/*     */               
/* 251 */               } catch (Exception ex) {
/* 252 */                 MCLog.write(ex);
/*     */               } 
/*     */ 
/*     */               
/* 256 */               if (mCException == null)
/*     */               {
/* 258 */                 mCException = new MCException(Core_Msg_FW_A.FCBGC0055, new Object[0]);
/*     */               }
/*     */               
/* 261 */               MCLog.write(t);
/* 262 */               mCException.addCauseMessage((t instanceof MCException) ? (
/* 263 */                   (MCException)t).getMCMessage() : (
/* 264 */                   new MCException(t)).getMCMessage());
/*     */             }
/*     */           
/*     */           } 
/*     */         } finally {
/*     */           
/* 270 */           MCTransactionManager.dbTran()._setStartSqlForPhase(bool);
/* 271 */           if (bool) {
/*     */             
/*     */             try {
/* 274 */               MCTransactionManager.dbTran().commit();
/*     */             }
/* 276 */             catch (Exception ex) {
/* 277 */               MCLog.write(ex);
/*     */             } 
/*     */           }
/*     */         } 
/* 281 */         if (mCException != null)
/*     */         {
/*     */ 
/*     */ 
/*     */           
/* 286 */           MCLog.write((Throwable)mCException);
/*     */         } }
/*     */     
/*     */     } finally {
/*     */       
/* 291 */       MCLog.write(Core_Msg_FW_A.FCBGC0233, new Object[0]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void handleExecuteException(Throwable e) {
/* 304 */     MCException me = MCRequesterUtil.convertDispatcherExecuteException(e);
/*     */     
/* 306 */     MCExceptionParam ep = this.ctx.param().getExceptionParam();
/* 307 */     ep.setException(me);
/* 308 */     parseExPrm();
/* 309 */     this.ctx.setErr(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void parseExPrm() {
/* 320 */     this.ctx.param().getMessageParam().setMessage(MCMessagePool.getWrappedMessageList());
/*     */ 
/*     */     
/* 323 */     MCDPFormat fmt = this.ctx.getUpDPT().getFormat();
/* 324 */     if (!this.ctx.getDwDPW().isWriteHeader()) {
/*     */       
/* 326 */       MCP2THeaderReader dRdrH = MCDPReaderFactory.downHeaderToText(fmt);
/* 327 */       dRdrH.read(this.ctx.param(), this.ctx.getDwDPW());
/*     */     } 
/*     */     
/* 330 */     MCP2TBodyReader dRdrB = MCDPReaderFactory.downBodyToText(fmt, 
/* 331 */         MCParseTypeUtil.getParseType(this.ctx.param()));
/* 332 */     dRdrB.read(this.ctx.param(), this.ctx.getDwDPW());
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\MCDispatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */