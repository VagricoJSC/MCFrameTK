/*    */ package mcframe.serverCore.requester;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ enum MCServerSignal
/*    */ {
/* 12 */   RUNNING
/*    */   {
/*    */     void receive(String serverRequestNo) {
/* 15 */       (new DefaultServerSignalReceiver()).exec(serverRequestNo);
/*    */     }
/*    */   },
/* 18 */   INTERRUPTED
/*    */   {
/*    */     void receive(String serverRequestNo) {
/* 21 */       (new InterruptedSignalReceiver()).exec(serverRequestNo);
/*    */     }
/*    */   },
/* 24 */   END
/*    */   {
/*    */     void receive(String serverRequestNo) {
/* 27 */       (new DefaultServerSignalReceiver()).exec(serverRequestNo);
/*    */     }
/*    */   },
/* 30 */   NONE
/*    */   {
/*    */     void receive(String serverRequestNo) {
/* 33 */       (new DefaultServerSignalReceiver()).exec(serverRequestNo);
/*    */     }
/*    */   };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static MCServerSignal signal(String signalString) {
/* 56 */     if ("01".equals(signalString)) {
/* 57 */       return INTERRUPTED;
/*    */     }
/* 59 */     return NONE;
/*    */   }
/*    */   
/*    */   abstract void receive(String paramString);
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\MCServerSignal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */