/*     */ package mcframe.serverCore.requester;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.commonCore.sys.MCFactory;
/*     */ import mcframe.serverCore.logic.IfMCOperation;
/*     */ import mcframe.serverCore.logic.MCLogic;
/*     */ import mcframe.serverCore.logic.MCLogicBase;
/*     */ import mcframe.serverCore.logic.MCOperation;
/*     */ import mcframe.serverCore.resource.MCConst;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCLogicRefUtil
/*     */ {
/*  37 */   private static final String ERR_ID = Core_Msg_FW_A.FCBGC0053;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String NULL_LOGIC = "null";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   private static final MCLogicRefUtil lru = new MCLogicRefUtil();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <T extends IfMCOperation> T createOperation(String moduleId, String logicId, String operationId, Class<T> clazz) {
/*  81 */     Class<?> lgcClazz = createLogicClass(moduleId, logicId, operationId);
/*  82 */     String mtd = lru.getCrtOpeMtd(moduleId, logicId, operationId);
/*  83 */     Object ret = MCFactory.invokeStatic(lgcClazz, mtd, new Class[0], 
/*  84 */         new Object[0]);
/*     */     try {
/*  86 */       return clazz.cast(ret);
/*     */     }
/*  88 */     catch (Exception e) {
/*     */ 
/*     */       
/*  91 */       throw new MCException(e, Core_Msg_FW_A.FCBEC0003, new Object[] { clazz.getName() });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Class<?> createLogicClass(String moduleId, String logicId, String operationId) {
/* 113 */     String name = lru.getLclCls(moduleId, logicId, operationId);
/*     */     
/*     */     try {
/* 116 */       return MCFactory.getClass(MCLogicBase.class, name);
/*     */     }
/* 118 */     catch (Exception e) {
/* 119 */       throw new MCException(e, Core_Msg_FW_A.FCBGC0069, new Object[] { name });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCLogic crtLgc(MCParam p) {
/* 134 */     return lru.createLogic(p.getModuleId(), p.getLogicId(), p.getOperationId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCLogic crtLgc(String mid, String lid, String oid) {
/* 150 */     return lru.createLogic(mid, lid, oid);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCOperation invokeCrtOpe(MCLogic lgc, MCParam p) {
/* 163 */     Class[] doArgsCls = new Class[0];
/* 164 */     Object[] doArgs = new Object[0];
/*     */     try {
/* 166 */       return (MCOperation)lru.invokeMtd(lgc, lru.getCrtOpeMtd(p), doArgsCls, 
/* 167 */           doArgs);
/*     */     }
/* 169 */     catch (MCException e) {
/*     */       
/* 171 */       throw e;
/*     */     }
/* 173 */     catch (Exception e) {
/*     */       
/* 175 */       throw new MCException(e, Core_Msg_FW_A.FCBGC0030, new Object[] { lgc.getClass().getName() });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void invokeOpeExec(MCLogic lgc, MCParam p) {
/* 200 */     Class[] doArgsCls = {
/* 201 */         MCLogic.class, MCParam.class
/*     */       };
/* 203 */     Object[] doArgs = {
/* 204 */         lgc, p
/*     */       };
/*     */     try {
/* 207 */       lru.invokeMtd(
/* 208 */           MCFactory.getFieldValue(lgc.getClass(), IfMCOperation.class, lgc, 
/* 209 */             lru.getOpeField(p)), "doOpeExec", doArgsCls, doArgs);
/*     */     }
/* 211 */     catch (MCException e) {
/*     */       
/* 213 */       throw e;
/*     */     }
/* 215 */     catch (Exception e) {
/*     */       
/* 217 */       throw new MCException(e, Core_Msg_FW_A.FCBGC0030, new Object[] { lgc.getClass().getName() });
/*     */     } 
/* 219 */     lgc.destroy();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void invokeOpe(MCLogic lgc, MCParam p) {
/* 242 */     Class[] doArgsCls = new Class[0];
/* 243 */     Object[] doArgs = new Object[0];
/* 244 */     lgc.init(p);
/*     */     try {
/* 246 */       lru.invokeMtd(lgc, lru.getLclOpeMtd(p), doArgsCls, doArgs);
/*     */     }
/* 248 */     catch (MCException e) {
/*     */       
/* 250 */       throw e;
/*     */     }
/* 252 */     catch (Exception e) {
/*     */       
/* 254 */       throw new MCException(e, Core_Msg_FW_A.FCBGC0030, new Object[] { lgc.getClass().getName() });
/*     */     } 
/* 256 */     lgc.destroy();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void initLgcPrm(MCLogic lgc, MCParam p) {
/* 270 */     if (lgc == null) {
/* 271 */       throw new MCException(ERR_ID, new Object[] { "null" });
/*     */     }
/*     */     
/*     */     try {
/* 275 */       Class[] argsCls1 = new Class[0];
/* 276 */       Object[] args1 = new Object[0];
/* 277 */       String mtd1 = lru.getinitWithPrmMtd(p.getModuleId(), p.getLogicId(), 
/* 278 */           p.getOperationId());
/* 279 */       lru.invokeMtd(lgc, mtd1, argsCls1, args1);
/*     */       
/* 281 */       Class[] argsCls2 = {
/* 282 */           MCParam.class
/*     */         };
/* 284 */       Object[] args2 = {
/* 285 */           p
/*     */         };
/* 287 */       String mtd2 = lru.getPrmMtd(p.getModuleId(), p.getLogicId(), 
/* 288 */           p.getOperationId());
/* 289 */       lru.invokeMtd(lgc, mtd2, argsCls2, args2);
/*     */ 
/*     */     
/*     */     }
/* 293 */     catch (Exception e) {
/* 294 */       throw new MCException(e, ERR_ID, new Object[] { lgc.getClass().getName() });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void initPrm(MCLogic lgc, MCParam p) {
/* 308 */     if (lgc == null) {
/* 309 */       throw new MCException(ERR_ID, new Object[] { "null" });
/*     */     }
/*     */     try {
/* 312 */       Class[] argsCls = {
/* 313 */           MCParam.class
/*     */         };
/* 315 */       Object[] args = {
/* 316 */           p
/*     */         };
/* 318 */       String mtd = lru.getPrmMtd(p.getModuleId(), p.getLogicId(), 
/* 319 */           p.getOperationId());
/* 320 */       lru.invokeMtd(lgc, mtd, argsCls, args);
/*     */ 
/*     */     
/*     */     }
/* 324 */     catch (Exception e) {
/* 325 */       throw new MCException(e, ERR_ID, new Object[] { lgc.getClass().getName() });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getCrtOpeMtd(String moduleId, String logicId, String operationId) {
/* 342 */     return "crt" + getBaseMtd(moduleId, logicId, operationId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getLclCls(String moduleId, String logicId, String operationId) {
/*     */     try {
/* 359 */       String name = MCConst.operation.getClass(moduleId, logicId, operationId);
/* 360 */       return name;
/*     */     }
/* 362 */     catch (MCException e) {
/* 363 */       MCLog.write(Core_Msg_FW_A.FCBGC0318, new Object[] { moduleId, logicId, operationId, e.getMCMessage()
/* 364 */             .toString() });
/* 365 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final MCLogic createLogic(String moduleId, String logicId, String operationId) {
/* 380 */     String name = getLclCls(moduleId, logicId, operationId);
/*     */     try {
/* 382 */       MCLogic lgc = (MCLogic)MCFactory.create(MCLogic.class, name);
/* 383 */       invokeInitOpe(lgc, moduleId, logicId, operationId);
/* 384 */       return lgc;
/*     */     }
/* 386 */     catch (MCException e) {
/* 387 */       MCLog.write(Core_Msg_FW_A.FCBGC0300, new Object[] { name });
/* 388 */       throw new MCException(e, ERR_ID, new Object[] { name });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void invokeInitOpe(MCLogic lgc, String moduleId, String logicId, String operationId) {
/* 405 */     if (lgc == null) {
/* 406 */       throw new MCException(ERR_ID, new Object[] { "null" });
/*     */     }
/*     */     try {
/* 409 */       Class[] argsCls = new Class[0];
/* 410 */       Object[] args = new Object[0];
/* 411 */       String mtd = lru.getInitMtd(moduleId, logicId, operationId);
/* 412 */       lru.invokeMtd(lgc, mtd, argsCls, args);
/*     */ 
/*     */     
/*     */     }
/* 416 */     catch (Exception e) {
/* 417 */       throw new MCException(e, ERR_ID, new Object[] { lgc.getClass().getName() });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object invokeMtd(Object lgc, String mtd, Class[] argsCls, Object[] args) throws Exception {
/*     */     try {
/* 439 */       Class<?> cls = lgc.getClass();
/* 440 */       Method lm = findExecMethod(cls, mtd, argsCls);
/* 441 */       return lm.invoke(lgc, args);
/*     */     
/*     */     }
/* 444 */     catch (InvocationTargetException ex) {
/* 445 */       throw MCException.getInvocationTargetMCException(ex);
/*     */     
/*     */     }
/* 448 */     catch (NoSuchMethodException ex) {
/* 449 */       MCLog.write(Core_Msg_FW_A.FCBGC0299, new Object[] { lgc.getClass().getName(), mtd });
/* 450 */       throw ex;
/*     */     
/*     */     }
/* 453 */     catch (IllegalAccessException ex) {
/* 454 */       MCLog.write(Core_Msg_FW_A.FCBGC0299, new Object[] { lgc.getClass().getName(), mtd });
/* 455 */       throw ex;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getBaseMtd(MCParam p) {
/* 469 */     String name = getBaseMtd(p.getModuleId(), p.getLogicId(), p.getOperationId());
/* 470 */     return name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getBaseMtd(String moduleId, String logicId, String operationId) {
/*     */     try {
/* 487 */       String name = MCConst.operation.getMethod(moduleId, logicId, operationId);
/* 488 */       return name;
/*     */     }
/* 490 */     catch (MCException e) {
/* 491 */       MCLog.write(Core_Msg_FW_A.FCBGC0319, new Object[] { moduleId, logicId, operationId, e.getMCMessage()
/* 492 */             .toString() });
/*     */       
/* 494 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getLclOpeMtd(MCParam p) {
/* 509 */     return "do" + getBaseMtd(p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getPrmMtd(String moduleId, String logicId, String operationId) {
/* 524 */     return "param" + getBaseMtd(moduleId, logicId, operationId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getinitWithPrmMtd(String moduleId, String logicId, String operationId) {
/* 539 */     return "init" + getBaseMtd(moduleId, logicId, operationId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getInitMtd(String moduleId, String logicId, String operationId) {
/* 554 */     return "init" + getBaseMtd(moduleId, logicId, operationId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getCrtOpeMtd(MCParam p) {
/* 567 */     return "crt" + getBaseMtd(p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getOpeField(MCParam p) {
/* 580 */     return "a" + getBaseMtd(p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Method findExecMethod(Class<?> clazz, String name, Class[] argsCls) throws NoSuchMethodException {
/* 600 */     while (clazz != null) {
/*     */       try {
/* 602 */         Method m = clazz.getDeclaredMethod(name, argsCls);
/*     */ 
/*     */         
/* 605 */         m.setAccessible(true);
/* 606 */         return m;
/*     */       
/*     */       }
/* 609 */       catch (NoSuchMethodException noSuchMethodException) {
/* 610 */         clazz = clazz.getSuperclass();
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 615 */     throw new NoSuchMethodException();
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\MCLogicRefUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */