/*    */ package mcframe.serverCore.requester;
/*    */ 
/*    */ import mcframe.serverCore.resource.MCConst;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCLogicInvokerFactory
/*    */ {
/* 20 */   private static final MCLogicInvokerFactory factory = new MCLogicInvokerFactory();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static MCLogicInvoker create(MCDispatcherContext ctx) {
/* 31 */     return factory.createInvoker(ctx);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected MCLogicInvoker createInvoker(MCDispatcherContext ctx) {
/* 43 */     if (ctx.isNative()) {
/* 44 */       return (MCLogicInvoker)MCConst.plugin.createEx(
/* 45 */           MCLogicInvoker.class, "dispatcher.logicInvoker.nativeClass");
/*    */     }
/* 47 */     if (ctx.isListLogic()) {
/* 48 */       return new MCListLogicInvoker();
/*    */     }
/* 50 */     if (ctx.isSimple()) {
/* 51 */       return new MCSimpleLogicInvoker();
/*    */     }
/* 53 */     return (MCLogicInvoker)MCConst.plugin.createEx(
/* 54 */         MCLogicInvoker.class, "dispatcher.logicInvoker.class");
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\MCLogicInvokerFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */