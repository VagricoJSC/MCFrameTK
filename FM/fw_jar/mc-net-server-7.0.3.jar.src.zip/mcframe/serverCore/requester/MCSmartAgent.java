/*    */ package mcframe.serverCore.requester;
/*    */ 
/*    */ import java.io.BufferedReader;
/*    */ import java.io.IOException;
/*    */ import javax.servlet.annotation.WebServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import mcframe.commonCore.notice.MCException;
/*    */ import mcframe.commonCore.param.MCDPWriter;
/*    */ import mcframe.commonCore.param.MCUploadFileParam;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @WebServlet(name = "MCSmart", urlPatterns = {"/MCSmart"}, loadOnStartup = 3)
/*    */ public class MCSmartAgent
/*    */   extends MCServletAgent
/*    */ {
/* 33 */   private static ThreadLocal<String> reqContentType = new ThreadLocal<>();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void doRequest(String charset, HttpServletRequest req, HttpServletResponse res) {
/* 39 */     reqContentType.set(req.getContentType());
/*    */     
/*    */     try {
/* 42 */       super.doRequest(charset, req, res);
/*    */     } finally {
/*    */       
/* 45 */       reqContentType.remove();
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void doSinglePartRequest(String charset, boolean gzip, HttpServletRequest req, HttpServletResponse res) {
/* 52 */     StringBuilder sb = new StringBuilder();
/* 53 */     BufferedReader br = null;
/* 54 */     String line = null;
/*    */     try {
/* 56 */       br = req.getReader();
/* 57 */       while ((line = br.readLine()) != null) {
/* 58 */         sb.append(line);
/* 59 */         sb.append("\n");
/*    */       } 
/* 61 */       doRequestMain(sb.toString(), null, charset, gzip, req, res);
/*    */     }
/* 63 */     catch (Throwable ex) {
/*    */       
/* 65 */       throw (ex instanceof MCException) ? (MCException)ex : new MCException(ex);
/*    */     } finally {
/*    */       
/* 68 */       if (br != null) {
/*    */         try {
/* 70 */           br.close();
/*    */         }
/* 72 */         catch (IOException iOException) {}
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void execute(String up, MCUploadFileParam upfp, HttpServletResponse res, boolean gzip, String charset) {
/* 82 */     MCDPWriter pw = getResponseWriter(res, gzip, charset);
/* 83 */     if (pw == null) {
/*    */       return;
/*    */     }
/*    */     
/* 87 */     MCServerRequester requester = new MCServerRequester();
/* 88 */     requester.srvSmart(pw, up, upfp);
/* 89 */     pw.flush();
/* 90 */     pw.close();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected String getContentType() {
/* 96 */     String contentType = reqContentType.get();
/* 97 */     return (contentType != null) ? contentType : "application/json";
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\MCSmartAgent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */