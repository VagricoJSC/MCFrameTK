/*     */ package mcframe.serverCore.requester;
/*     */ 
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.commonCore.pio.MCDPReaderFactory;
/*     */ import mcframe.commonCore.pio.MCP2TBodyReader;
/*     */ import mcframe.commonCore.pio.MCP2THeaderReader;
/*     */ import mcframe.commonCore.pio.util.MCDPFormat;
/*     */ import mcframe.commonCore.sys.MCFactory;
/*     */ import mcframe.commonCore.util.MCSimpleList;
/*     */ import mcframe.serverCore.logic.MCLogic;
/*     */ import mcframe.serverCore.notice.MCMessagePool;
/*     */ import mcframe.serverCore.phase.MCLogicBeforeAfter;
/*     */ import mcframe.serverCore.requester.paging.MCPagingBuffer;
/*     */ import mcframe.serverCore.resource.MCConst;
/*     */ import mcframe.serverCore.sys.MCSys;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCLogicUtil
/*     */ {
/*     */   public static MCPagingBuffer createPagingBuffer() {
/*  40 */     return new MCPagingBuffer(MCSys.request.ctx().param(), 
/*  41 */         MCSys.request.ctx().prevCtx().param());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[][] getModuleAndLogicIDs(Class<?> clazz) {
/*  54 */     MCSimpleList<String> ml = new MCSimpleList(String.class);
/*  55 */     MCSimpleList<String> sl = new MCSimpleList(String.class);
/*  56 */     while (clazz != null) {
/*  57 */       String m = (String)MCFactory.getFieldValue(clazz, String.class, "MODULE_ID");
/*  58 */       String s = (String)MCFactory.getFieldValue(clazz, String.class, "LOGIC_ID");
/*  59 */       if (m != null && s != null && (
/*  60 */         !ml.contains(m) || !sl.contains(s))) {
/*  61 */         ml.add(m);
/*  62 */         sl.add(s);
/*     */       } 
/*     */       
/*  65 */       clazz = clazz.getSuperclass();
/*     */     } 
/*  67 */     String[] ma = (String[])ml.array();
/*  68 */     String[] sa = (String[])sl.array();
/*  69 */     String[][] a = new String[ma.length][2];
/*  70 */     for (int i = 0; i < ma.length; i++) {
/*  71 */       a[i][0] = ma[i];
/*  72 */       a[i][1] = sa[i];
/*     */     } 
/*  74 */     return a;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void invoke(MCLogic lgc) {
/*  85 */     MCParam p = new MCParam(lgc.info());
/*     */     
/*  87 */     MCLog.write(Core_Msg_FW_A.FCBGC0304, new Object[] { p.getModuleId(), p.getLogicId(), p.getOperationId(), 
/*  88 */           p.getVersion() });
/*  89 */     MCSys.request.addSubId(p.getModuleId(), p.getLogicId(), p.getOperationId());
/*     */     try {
/*  91 */       upLog(lgc);
/*  92 */       MCLogicRefUtil.invokeOpe(lgc, p);
/*  93 */       dwLog(lgc);
/*     */     }
/*  95 */     catch (RuntimeException t) {
/*  96 */       dwErrLog(lgc, t);
/*  97 */       MCLog.write(Core_Msg_FW_A.FCBGC0297, new Object[] { p.getModuleId(), p.getLogicId(), p.getOperationId(), 
/*  98 */             p.getVersion() });
/*  99 */       throw t;
/*     */     } finally {
/*     */       
/* 102 */       MCSys.request.removeSubId();
/*     */       
/* 104 */       MCLog.write(Core_Msg_FW_A.FCBGC0305, new Object[] { p.getModuleId(), p.getLogicId(), p.getOperationId(), 
/* 105 */             p.getVersion() });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void initHdr(MCParam p) {
/* 119 */     p.setServerRequestNo(MCSys.request.serverRequestNo());
/* 120 */     p.setServerId(MCSys.request.serverId());
/* 121 */     p.setClientRequestNo(MCSys.request.clientRequestNo());
/* 122 */     p.setClientId(MCSys.request.clientId());
/*     */ 
/*     */     
/* 125 */     p.setUserId(MCSys.user.ID());
/* 126 */     p.setLoginSequence(MCSys.user.loginSequence());
/* 127 */     p.setClientLocale(MCSys.user.locale());
/* 128 */     p.setClientTimeZone(MCSys.user.timezone());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void upLog(MCLogic lgc) {
/* 142 */     upLogDispatch(lgc);
/* 143 */     if (!MCLog.isEnabled(Core_Msg_FW_A.FCBGC0335)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 155 */       MCParam p = new MCParam(lgc.info());
/* 156 */       initHdr(p);
/* 157 */       MCLogicRefUtil.initPrm(lgc, p);
/*     */ 
/*     */       
/* 160 */       MCP2THeaderReader hr = 
/* 161 */         MCDPReaderFactory.localUpHeaderToText(getTightFormat());
/* 162 */       String hdr = hr.parse(p);
/* 163 */       MCP2TBodyReader br = MCDPReaderFactory.localUpBodyToText(getTightFormat());
/* 164 */       String bdy = br.parse(p);
/*     */       
/* 166 */       MCLog.write(Core_Msg_FW_A.FCBGC0335, new Object[] { String.valueOf(hdr) + bdy });
/*     */     }
/* 168 */     catch (Exception exception) {
/*     */       
/* 170 */       MCLog.write(Core_Msg_FW_A.FCBGC0236, new Object[0]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void dwLog(MCLogic lgc) {
/* 185 */     dwLogDispatch(lgc);
/* 186 */     if (!MCLog.isEnabled(Core_Msg_FW_A.FCBGC0336)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 198 */       MCParam p = new MCParam(lgc.info());
/* 199 */       initHdr(p);
/* 200 */       MCLogicRefUtil.initPrm(lgc, p);
/*     */       
/* 202 */       p.getMessageParam().setMessage(MCMessagePool.getMessageList());
/*     */       
/* 204 */       MCP2THeaderReader hr = MCDPReaderFactory.downHeaderToText(getTightFormat());
/* 205 */       String hdr = hr.parse(p);
/* 206 */       MCP2TBodyReader br = MCDPReaderFactory.downBodyToText(getTightFormat());
/* 207 */       String bdy = br.parse(p);
/*     */       
/* 209 */       MCLog.write(Core_Msg_FW_A.FCBGC0336, new Object[] { p.getModuleId(), p.getLogicId(), p.getOperationId(), 
/* 210 */             String.valueOf(hdr) + bdy });
/*     */     }
/* 212 */     catch (Exception exception) {
/*     */       
/* 214 */       MCLog.write(Core_Msg_FW_A.FCBGC0236, new Object[0]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void dwErrLog(MCLogic lgc, RuntimeException e) {
/* 229 */     if (!MCLog.isEnabled(Core_Msg_FW_A.FCBGC0336)) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 234 */       MCParam p = new MCParam(lgc.info());
/* 235 */       initHdr(p);
/*     */       
/* 237 */       if (e instanceof MCException) {
/* 238 */         p.getExceptionParam().setException((MCException)e);
/*     */       } else {
/*     */         
/* 241 */         MCException te = new MCException(Core_Msg_FW_A.FCBGC0036, new Object[] { String.valueOf(p.getModuleId()) + "." + 
/* 242 */               p.getLogicId() + "." + p.getOperationId() });
/* 243 */         p.getExceptionParam().setException(te);
/*     */       } 
/*     */       
/* 246 */       p.getMessageParam().setMessage(MCMessagePool.getMessageList());
/*     */ 
/*     */       
/* 249 */       MCP2THeaderReader hr = MCDPReaderFactory.downHeaderToText(getTightFormat());
/* 250 */       String hdr = hr.parse(p);
/* 251 */       MCP2TBodyReader br = MCDPReaderFactory.downBodyToText(getTightFormat());
/* 252 */       String bdy = br.parse(p);
/*     */       
/* 254 */       MCLog.write(Core_Msg_FW_A.FCBGC0336, new Object[] { p.getModuleId(), p.getLogicId(), p.getOperationId(), 
/* 255 */             String.valueOf(hdr) + bdy });
/*     */     }
/* 257 */     catch (Exception exception) {
/*     */       
/* 259 */       MCLog.write(Core_Msg_FW_A.FCBGC0236, new Object[0]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static MCDPFormat getTightFormat() {
/* 272 */     return MCDPFormat.forTight();
/*     */   }
/*     */ 
/*     */   
/*     */   private static void upLogDispatch(MCLogic lgc) {
/* 277 */     Boolean autotest = Boolean.valueOf(MCSys.env.getVMEnv("autotest"));
/* 278 */     if (!autotest.booleanValue()) {
/*     */       return;
/*     */     }
/* 281 */     MCParam p = new MCParam(lgc.info());
/* 282 */     MCLogicBeforeAfter ph = crtCommonSubLogicBeforeAfter(p);
/* 283 */     if (ph != null) {
/* 284 */       initHdr(p);
/* 285 */       MCLogicRefUtil.initPrm(lgc, p);
/* 286 */       ph.invoke(p);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void dwLogDispatch(MCLogic lgc) {
/* 292 */     Boolean autotest = Boolean.valueOf(MCSys.env.getVMEnv("autotest"));
/* 293 */     if (!autotest.booleanValue()) {
/*     */       return;
/*     */     }
/* 296 */     MCParam p = new MCParam(lgc.info());
/* 297 */     MCLogicBeforeAfter ph = crtCommonSubLogicBeforeAfter(p);
/* 298 */     if (ph != null) {
/* 299 */       initHdr(p);
/* 300 */       MCLogicRefUtil.initPrm(lgc, p);
/* 301 */       ph.destroy(p);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static MCLogicBeforeAfter crtCommonSubLogicBeforeAfter(MCParam p) {
/* 308 */     return (MCLogicBeforeAfter)MCConst.plugin.create(MCLogicBeforeAfter.class, 
/* 309 */         "dispatcher.subLogicLogBeforeAfter.class");
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\MCLogicUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */