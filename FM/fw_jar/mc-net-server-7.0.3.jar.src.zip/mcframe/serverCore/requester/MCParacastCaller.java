/*     */ package mcframe.serverCore.requester;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.serverCore.dbc.FCM_SERVER_R;
/*     */ import mcframe.serverCore.logic.MCOperation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCParacastCaller<T extends MCOperation>
/*     */   extends MCClusterCaller<T>
/*     */ {
/*     */   private class Entry
/*     */   {
/*     */     private Entry() {}
/*     */     
/*  53 */     T ope = null;
/*  54 */     String srv = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   private List<Entry> _entryList = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   private int _paraSize = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Map<T, MCClusterCaller<T>.Task> getTaskMap() {
/*  85 */     Map<T, MCClusterCaller<T>.Task> taskMap = new LinkedHashMap<>();
/*  86 */     Set<String> srvSet = new HashSet<>();
/*     */     
/*  88 */     MCList<FCM_SERVER_R> srvL = getLiveServer(new mcframe.commonCore.requester.MCClusterServerRole[0]);
/*  89 */     if (srvL == null || srvL.size() == 0)
/*     */     {
/*  91 */       return taskMap;
/*     */     }
/*     */     
/*  94 */     for (int taskno = 0; taskno < this._entryList.size(); taskno++) {
/*  95 */       Entry e = this._entryList.get(taskno);
/*  96 */       FCM_SERVER_R srvR = (FCM_SERVER_R)srvL.getFirst("srv_id", e.srv);
/*  97 */       if (srvR == null)
/*     */       {
/*  99 */         throw new MCException(Core_Msg_FW_A.FCBGC0463, new Object[] { e.srv });
/*     */       }
/* 101 */       MCClusterCaller<T>.Task task = new MCClusterCaller.Task(this, taskno, srvR.url(), srvR.srv_id(), e.ope);
/* 102 */       taskMap.put(e.ope, task);
/* 103 */       srvSet.add(e.srv);
/*     */     } 
/*     */     
/* 106 */     this._paraSize = srvSet.size();
/* 107 */     return taskMap;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int parallelSize() {
/* 112 */     return this._paraSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(T ope, String srv) {
/* 124 */     Entry entry = new Entry(null);
/* 125 */     entry.ope = ope;
/* 126 */     entry.srv = srv;
/* 127 */     this._entryList.add(entry);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\MCParacastCaller.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */