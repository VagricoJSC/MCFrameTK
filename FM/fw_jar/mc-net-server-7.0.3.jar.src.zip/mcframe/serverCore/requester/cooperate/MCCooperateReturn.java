/*    */ package mcframe.serverCore.requester.cooperate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MCCooperateReturn
/*    */ {
/*    */   private final String co_cd;
/*    */   
/*    */   public MCCooperateReturn(String co_cd) {
/* 26 */     this.co_cd = co_cd;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getCoCD() {
/* 37 */     return this.co_cd;
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\cooperate\MCCooperateReturn.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */