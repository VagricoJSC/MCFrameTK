/*    */ package mcframe.serverCore.requester.cooperate;
/*    */ 
/*    */ import java.util.concurrent.ThreadFactory;
/*    */ import java.util.concurrent.atomic.AtomicInteger;
/*    */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*    */ import mcframe.commonCore.notice.MCLog;
/*    */ import mcframe.serverCore.sys.MCSys;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCCooperateThreadFactory
/*    */   implements ThreadFactory
/*    */ {
/*    */   private final ThreadGroup group;
/* 26 */   private final AtomicInteger threadNumber = new AtomicInteger(1);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private final String namePrefix;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MCCooperateThreadFactory() {
/* 41 */     SecurityManager s = System.getSecurityManager();
/* 42 */     this.group = (s != null) ? s.getThreadGroup() : Thread.currentThread()
/* 43 */       .getThreadGroup();
/* 44 */     this.namePrefix = "mc-cooperate-" + MCSys.request.serverRequestNo() + "-";
/*    */   }
/*    */ 
/*    */   
/*    */   public Thread newThread(Runnable r) {
/* 49 */     String name = String.valueOf(this.namePrefix) + this.threadNumber.incrementAndGet();
/* 50 */     Thread t = new Thread(this.group, r, name, 0L);
/* 51 */     if (t.isDaemon()) t.setDaemon(false); 
/* 52 */     if (t.getPriority() != 5) t.setPriority(5); 
/* 53 */     MCLog.write(Core_Msg_FW_A.FCBGC0148, new Object[] { name });
/* 54 */     return t;
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\cooperate\MCCooperateThreadFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */