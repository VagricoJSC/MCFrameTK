/*     */ package mcframe.serverCore.requester.cooperate;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.RejectedExecutionException;
/*     */ import java.util.concurrent.ThreadPoolExecutor;
/*     */ import java.util.stream.Collectors;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.notice.MCMessageList;
/*     */ import mcframe.commonCore.param.MCOperationInfo;
/*     */ import mcframe.commonCore.resource.MCConst;
/*     */ import mcframe.commonCore.sys.MCFactory;
/*     */ import mcframe.serverCore.dbc.FCM_GRANT_CO_R;
/*     */ import mcframe.serverCore.logic.MCOperation;
/*     */ import mcframe.serverCore.queryapi.IFMCSQL;
/*     */ import mcframe.serverCore.queryapi.MCDBContainer;
/*     */ import mcframe.serverCore.queryapi.MCQueryApiBuilder;
/*     */ import mcframe.serverCore.requester.MCRequestObject;
/*     */ import mcframe.serverCore.resource.MCConfig;
/*     */ import mcframe.serverCore.resource.MCConst;
/*     */ import mcframe.serverCore.sys.MCSys;
/*     */ import mcframe.serverCore.util.MCDBUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCCooperateInvokeManager
/*     */ {
/*  48 */   static final Class<MCCooperateInvokeManager> CLAZZ = MCCooperateInvokeManager.class;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String THREAD_LIMIT_KEY = "cooperate.limitSize";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String $co_cd = "co_cd";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String $co_nm = "co_nm";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String COOPERATE_ACTYPE = "cooperate";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ThreadPoolExecutor executor;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   private ConcurrentHashMap<String, MCException> exMap = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  85 */   private ConcurrentHashMap<String, MCMessageList> msgMap = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   private final ConcurrentHashMap<String, Future<MCCooperateReturn>> futureMap = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   private Integer limitThreadSize = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMessageList exec(String co_cd, MCOperation operation) {
/* 113 */     MCRequestObject.object(CLAZZ);
/* 114 */     Map<String, MCOperation> map = new HashMap<>();
/* 115 */     map.put(co_cd, operation);
/* 116 */     Map<String, MCMessageList> msgMap = exec(1, map);
/* 117 */     return msgMap.get(co_cd);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<String, MCMessageList> exec(int limitSize, Map<String, MCOperation> map) {
/* 138 */     MCCooperateInvokeManager manager = (MCCooperateInvokeManager)MCRequestObject.object(CLAZZ);
/* 139 */     manager.setLimitSize(limitSize);
/* 140 */     return manager.doExec(map);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Map<String, MCMessageList> exec(Map<String, MCOperation> map) {
/* 159 */     MCCooperateInvokeManager manager = (MCCooperateInvokeManager)MCRequestObject.object(CLAZZ);
/* 160 */     return manager.doExec(map);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCException getException(String co_cd) {
/* 172 */     MCCooperateInvokeManager manager = (MCCooperateInvokeManager)MCRequestObject.object(CLAZZ);
/* 173 */     return manager.getExceptionMap().get(co_cd);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isCooperateThread() {
/* 184 */     return !MCStringUtil.isNull(MCSys.request.cooperateCd());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getLimitSize() {
/* 195 */     if (this.limitThreadSize == null) {
/* 196 */       this.limitThreadSize = Integer.valueOf(getLimitSize(MCSys.request.moduleId(), 
/* 197 */             MCSys.request.logicId(), MCSys.request.operationId()));
/*     */     }
/* 199 */     return this.limitThreadSize.intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setLimitSize(int size) {
/* 212 */     if (size != 0) {
/* 213 */       this.limitThreadSize = Integer.valueOf(size);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getLimitSize(String mid, String lgcid, String opeid) {
/* 228 */     String key = MCConfig.server.findHierarchy(new String[] { mid, lgcid, opeid, "cooperate.limitSize" });
/* 229 */     if (MCStringUtil.isNull(key)) {
/* 230 */       return 1;
/*     */     }
/* 232 */     return MCConfig.server.getInteger(key, 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void createExecutor(int count) {
/* 243 */     int limit = getLimitSize();
/* 244 */     int size = (count > limit && limit > 0) ? limit : count;
/* 245 */     this.executor = (ThreadPoolExecutor)Executors.newFixedThreadPool(size, 
/* 246 */         new MCCooperateThreadFactory());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void shutdown() {
/* 256 */     this.executor.shutdown();
/* 257 */     this.executor = null;
/* 258 */     this.limitThreadSize = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, MCMessageList> doExec(Map<String, MCOperation> map) {
/* 270 */     check(map);
/* 271 */     createExecutor(map.size());
/* 272 */     submit(map);
/* 273 */     joinAll();
/* 274 */     shutdown();
/* 275 */     return getMessageMap();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void check(Map<String, MCOperation> map) {
/* 286 */     if (isCooperateThread()) {
/* 287 */       throw new MCException(Core_Msg_FW_A.FCBGC0149, new Object[0]);
/*     */     }
/* 289 */     for (Map.Entry<String, MCOperation> entry : map.entrySet()) {
/* 290 */       check(entry.getKey(), entry.getValue());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void check(String co_cd, MCOperation operation) {
/* 303 */     if (MCStringUtil.isNull(co_cd)) {
/* 304 */       throw new MCException(Core_Msg_FW_A.FCBGC0141, new Object[0]);
/*     */     }
/* 306 */     MCOperationInfo info = operation.getOperationInfo();
/* 307 */     if (!isExecutable(co_cd, info.moduleId, info.logicId)) {
/* 308 */       throw new MCException(Core_Msg_FW_A.FCBGC0142, new Object[] { co_cd, 
/* 309 */             MCConst.createKey(new String[] { info.moduleId, info.logicId, "cooperate" }) });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void submit(Map<String, MCOperation> map) {
/* 321 */     List<MCCooperateInvokeCallable> taskL = new ArrayList<>();
/* 322 */     for (Map.Entry<String, MCOperation> entry : map.entrySet()) {
/* 323 */       taskL.add(createCooperateInvokeCallable(entry.getKey(), entry.getValue()));
/*     */     }
/* 325 */     taskL.forEach(r -> submit(r));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void submit(MCCooperateInvokeCallable task) {
/*     */     try {
/* 337 */       Future<MCCooperateReturn> future = this.executor.submit(task);
/* 338 */       this.futureMap.put(task.co_cd, future);
/* 339 */       MCLog.write(Core_Msg_FW_A.FCBGC0147, new Object[] { task.co_cd });
/*     */     }
/* 341 */     catch (RejectedExecutionException e) {
/*     */       
/* 343 */       throw new MCException(e, Core_Msg_FW_A.FCBGC0112, new Object[0]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCCooperateInvokeCallable createCooperateInvokeCallable(String co_cd, MCOperation operation) {
/*     */     try {
/* 359 */       return new MCCooperateInvokeCallable(co_cd, operation);
/*     */     }
/* 361 */     catch (Throwable t) {
/* 362 */       throw new MCException(t, Core_Msg_FW_A.FCBGC0144, new Object[0]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void joinAll() {
/* 373 */     MCException ex = null;
/* 374 */     for (String co_cd : this.futureMap.keySet()) {
/*     */       try {
/* 376 */         join(co_cd);
/*     */       }
/* 378 */       catch (MCException e) {
/* 379 */         if (ex == null) {
/* 380 */           ex = e;
/*     */         }
/*     */       } 
/*     */     } 
/* 384 */     if (ex != null) {
/* 385 */       throw ex;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void join(String co_cd) {
/* 397 */     Future<MCCooperateReturn> future = this.futureMap.get(co_cd);
/* 398 */     if (future == null) {
/*     */       return;
/*     */     }
/*     */     try {
/* 402 */       future.get();
/*     */     }
/* 404 */     catch (InterruptedException e) {
/* 405 */       throw new MCException(e);
/*     */     }
/* 407 */     catch (ExecutionException|java.util.concurrent.CancellationException e) {
/* 408 */       Throwable cause = e.getCause();
/* 409 */       if (cause == null) {
/* 410 */         cause = e;
/*     */       }
/* 412 */       MCException loge = new MCException(cause, Core_Msg_FW_A.FCBGC0143, new Object[] { co_cd });
/* 413 */       MCLog.write((Throwable)loge);
/* 414 */       MCException mce = (cause instanceof MCException) ? (MCException)cause : loge;
/* 415 */       getExceptionMap().put(co_cd, mce);
/* 416 */       throw mce;
/*     */     } finally {
/*     */       
/* 419 */       future.cancel(true);
/* 420 */       this.futureMap.remove(co_cd);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ConcurrentHashMap<String, MCException> getExceptionMap() {
/* 432 */     return this.exMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ConcurrentHashMap<String, MCMessageList> getMessageMap() {
/* 443 */     return this.msgMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCList<? extends MCRow> getExecutableCoList(String moduleid, String logicid, String operationid) {
/* 462 */     MCList<FCM_GRANT_CO_R> coL = getCo(null);
/* 463 */     return (MCList<? extends MCRow>)coL.stream()
/* 464 */       .filter(r -> authorize(r.co_cd(), paramString1, paramString2, paramString3))
/* 465 */       .collect(
/* 466 */         Collectors.toCollection(() -> MCList.create(FCM_GRANT_CO_R.class)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isExecutable(String co_cd, String moduleid, String logicid, String operationid) {
/* 482 */     if (!isExecutable(co_cd, moduleid, logicid)) {
/* 483 */       return false;
/*     */     }
/* 485 */     return authorize(co_cd, moduleid, logicid, operationid);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isExecutable(String co_cd, String moduleid, String logicid) {
/* 499 */     MCList<FCM_GRANT_CO_R> coL = getCo(co_cd);
/* 500 */     if (coL.isEmpty()) {
/* 501 */       return false;
/*     */     }
/* 503 */     return authorize(co_cd, moduleid, logicid, "cooperate", 
/* 504 */         MCSys.request.operationId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean authorize(String co_cd, String moduleid, String logicid, String operationid) {
/* 520 */     return authorize(co_cd, moduleid, logicid, 
/* 521 */         MCConst.actype.getType(new String[] { moduleid, logicid, operationid
/* 522 */           }, ), MCSys.request.operationId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean authorize(String co_cd, String moduleid, String fncgrpid, String type, String func) {
/* 539 */     Class<?> clazz = MCFactory.getClass(Object.class, 
/* 540 */         "mcframe.serverCore.requester.cooperate.MCCooperateACLManager");
/* 541 */     return ((Boolean)MCFactory.invokeStatic(clazz, "check", new Class[] {
/* 542 */           String.class, String.class, String.class, String.class, String.class
/* 543 */         }, new Object[] {
/* 544 */           co_cd, moduleid, fncgrpid, type, func
/*     */         })).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static MCList<FCM_GRANT_CO_R> getCo(String co_cd) {
/* 557 */     MCList<FCM_GRANT_CO_R> ret = MCList.create(FCM_GRANT_CO_R.class);
/* 558 */     FCM_GRANT_CO_R dbc = FCM_GRANT_CO_R.create("M");
/* 559 */     MCQueryApiBuilder builder = MCQueryApiBuilder.create((MCDBContainer)dbc);
/* 560 */     builder.activeForeign("CO1");
/* 561 */     builder.setSelect(new IFMCSQL.MCColumn[] { (IFMCSQL.MCColumn)dbc.co_cd, (IFMCSQL.MCColumn)dbc.getColumn$("co_nm") });
/* 562 */     builder.setWhere(dbc.user_id.eq(IFMCSQL.bind("1")), new Comparable[] { MCSys.user.ID() });
/* 563 */     builder.addWhereWithCutOffAnd(dbc.co_cd.eq(IFMCSQL.bind("1")), new Comparable[] { co_cd });
/* 564 */     MCDBUtil.dbSelect("FC_MCCooperateInvokeManager_getCo", ret, builder);
/* 565 */     return ret;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\cooperate\MCCooperateInvokeManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */