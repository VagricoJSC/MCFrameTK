/*     */ package mcframe.serverCore.requester.cooperate;
/*     */ 
/*     */ import java.io.StringWriter;
/*     */ import java.util.Collection;
/*     */ import java.util.concurrent.Callable;
/*     */ import mcframe.commonCore.container.MCContainer;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.param.MCContainerParam;
/*     */ import mcframe.commonCore.param.MCDPWriter;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.commonCore.pio.MCDPReaderFactory;
/*     */ import mcframe.commonCore.pio.MCP2TBodyReader;
/*     */ import mcframe.commonCore.pio.MCP2THeaderReader;
/*     */ import mcframe.commonCore.pio.MCT2PHeaderReader;
/*     */ import mcframe.commonCore.pio.MCT2PMessageReader;
/*     */ import mcframe.commonCore.pio.util.MCDPFormat;
/*     */ import mcframe.commonCore.pio.util.MCDPToken;
/*     */ import mcframe.commonCore.pio.util.MCDPTokenMCDP;
/*     */ import mcframe.commonCore.pio.util.MCParseTypeUtil;
/*     */ import mcframe.commonCore.requester.MCParamHeaderUtil;
/*     */ import mcframe.commonCore.sys.MCFactory;
/*     */ import mcframe.commonCore.sys.MCUser;
/*     */ import mcframe.serverCore.logic.MCLogic;
/*     */ import mcframe.serverCore.logic.MCOperation;
/*     */ import mcframe.serverCore.mcjdbc.MCTransactionManager;
/*     */ import mcframe.serverCore.requester.MCCooperateRequestHandler;
/*     */ import mcframe.serverCore.requester.MCDispatcherContext;
/*     */ import mcframe.serverCore.requester.MCLogicRefUtil;
/*     */ import mcframe.serverCore.requester.MCRequestHandler;
/*     */ import mcframe.serverCore.requester.MCRequestObject;
/*     */ import mcframe.serverCore.requester.MCRequestStatus;
/*     */ import mcframe.serverCore.sys.MCSys;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MCCooperateInvokeCallable
/*     */   implements Callable<MCCooperateReturn>
/*     */ {
/*     */   private final MCRequestHandler hndl;
/*     */   private final MCDispatcherContext ctx;
/*     */   private final MCCooperateInvokeManager manager;
/*     */   final String co_cd;
/*     */   final MCOperation op;
/*     */   private final StringWriter sw;
/*     */   private final MCDPWriter dwdpw;
/*     */   
/*     */   public MCCooperateInvokeCallable(String co_cd, MCOperation op) {
/*  90 */     this.co_cd = co_cd;
/*  91 */     this.op = op;
/*  92 */     this.manager = (MCCooperateInvokeManager)MCRequestObject.object(MCCooperateInvokeManager.CLAZZ);
/*  93 */     this.hndl = (MCRequestHandler)new MCCooperateRequestHandler(co_cd);
/*  94 */     this.ctx = parseUpHdr(createParamText(op), this.hndl);
/*  95 */     this.sw = new StringWriter(1024);
/*  96 */     this.dwdpw = new MCDPWriter(this.sw, true);
/*  97 */     this.dwdpw.setOperationID(this.ctx.param().getModuleId(), this.ctx.param().getLogicId(), 
/*  98 */         this.ctx.param().getOperationId());
/*  99 */     this.ctx.setDwDPW(this.dwdpw);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static MCDispatcherContext parseUpHdr(String up, MCRequestHandler hndl) {
/* 112 */     if (up == null) {
/* 113 */       return null;
/*     */     }
/* 115 */     MCParam p = new MCParam();
/* 116 */     p.setServerId(MCSys.request.serverId());
/* 117 */     p.setServerRequestNo(MCSys.request.serverRequestNo());
/* 118 */     MCDPToken tkn = MCDPToken.create(up);
/* 119 */     MCDPFormat fmt = tkn.getFormat();
/* 120 */     MCT2PHeaderReader hr = MCDPReaderFactory.upHeaderToParam(fmt);
/* 121 */     hr.parse(tkn, p);
/* 122 */     MCDispatcherContext ctx = hndl.crtNewDispatcherContextforGpBatch(p);
/* 123 */     ctx.setUpDPT(tkn);
/* 124 */     return ctx;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String createParamText(MCOperation op) {
/* 136 */     MCParam p_srv = createParam(op);
/* 137 */     initParam(p_srv);
/* 138 */     setupUpParam(p_srv, op);
/* 139 */     return paramToText(p_srv);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCParam createParam(MCOperation op) {
/* 151 */     MCParam p = new MCParam(op.getOperationInfo());
/* 152 */     MCLogic lgc = MCLogicRefUtil.crtLgc(p);
/* 153 */     MCLogicRefUtil.initLgcPrm(lgc, p);
/* 154 */     return p;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initParam(MCParam p) {
/* 165 */     p.setCreatedTime(MCSys.request.createTime());
/* 166 */     MCParamHeaderUtil.toUpHeader(p, MCSys.request.clientId(), 
/* 167 */         MCSys.request.clientRequestNo(), MCSys.request.limitDLSize(), (MCUser)MCSys.user);
/*     */     
/* 169 */     p.setReqSrcId(MCSys.request.reqSrcId());
/*     */     
/* 171 */     p.setOperationHis(MCSys.request.clientOperation());
/*     */     
/* 173 */     p.setOperationAsync(MCSys.request.async());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setupUpParam(MCParam p_srv, MCOperation op) {
/* 186 */     int i = 0;
/*     */     while (true) {
/* 188 */       MCContainer cont = op.up(i);
/* 189 */       if (cont == null) {
/*     */         break;
/*     */       }
/* 192 */       if (cont instanceof MCRow) {
/* 193 */         MCRow.copyall((MCRow)p_srv.getContainerParam().getUpBlock(i), 
/* 194 */             (MCRow)cont);
/*     */       } else {
/*     */         
/* 197 */         ((MCList)p_srv.getContainerParam().getUpBlock(i))
/* 198 */           .addAll((Collection)cont);
/*     */       } 
/* 200 */       i++;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String paramToText(MCParam p) {
/* 213 */     MCDPFormat format = MCDPFormat.forClient();
/* 214 */     MCP2THeaderReader hr = MCDPReaderFactory.upHeaderToText(format);
/* 215 */     String hdr = hr.parse(p);
/* 216 */     MCP2TBodyReader br = MCDPReaderFactory.upBodyToText(format, 
/* 217 */         MCParseTypeUtil.getParseType(p));
/* 218 */     String bdy = br.parse(p);
/* 219 */     return String.valueOf(hdr) + bdy;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCCooperateReturn call() throws Exception {
/*     */     try {
/* 225 */       this.hndl.initRequestObject(this.ctx);
/*     */ 
/*     */       
/* 228 */       MCRequestStatus reqSts = getClassForRequestStatus(this.dwdpw);
/* 229 */       if (reqSts != null) {
/* 230 */         this.ctx.setRequestStatus(reqSts);
/*     */       }
/*     */ 
/*     */       
/* 234 */       this.hndl.dispatch(this.ctx);
/* 235 */       this.hndl.destroy();
/*     */ 
/*     */       
/* 238 */       throwInitEx(this.sw);
/*     */     }
/*     */     finally {
/*     */       
/* 242 */       MCTransactionManager.finalClose();
/*     */     } 
/* 244 */     return end();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCRequestStatus getClassForRequestStatus(MCDPWriter dwdpw) {
/*     */     try {
/* 256 */       String testClassName = MCFactory.createClassName(new String[] { "mcframe", "serverFZBH", "FZBHL0100", "MCRequestStatusCoopeTest" });
/* 257 */       Class<? extends MCRequestStatus> cls = MCFactory.getClass(MCRequestStatus.class, testClassName);
/* 258 */       Class[] types = { MCParam.class, MCDPWriter.class };
/* 259 */       Object[] args = { this.ctx.param(), dwdpw };
/*     */       
/* 261 */       return (MCRequestStatus)MCFactory.create(cls, types, args);
/* 262 */     } catch (MCException mCException) {
/*     */       
/* 264 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void throwInitEx(StringWriter sw) {
/* 275 */     MCDPTokenMCDP tkn = (MCDPTokenMCDP)MCDPToken.create(sw.toString());
/* 276 */     MCDPFormat fmt = tkn.getFormat();
/* 277 */     MCParam p = new MCParam();
/*     */     
/* 279 */     parseHeader(fmt, tkn, p);
/*     */     
/* 281 */     if (tkn.hasNext()) {
/* 282 */       parseBody(fmt, tkn, p);
/*     */       
/* 284 */       if (!p.getExceptionParam().isEmpty()) {
/* 285 */         throw p.getExceptionParam().getExceptionRowParam().getEx();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseHeader(MCDPFormat fmt, MCDPTokenMCDP tkn, MCParam p) {
/* 299 */     MCT2PHeaderReader hr = MCDPReaderFactory.downHeaderToParam(fmt);
/* 300 */     hr.parse((MCDPToken)tkn, p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseBody(MCDPFormat fmt, MCDPTokenMCDP tkn, MCParam p) {
/* 312 */     MCT2PMessageReader mCT2PMessageReader = MCDPReaderFactory.downMessageToParam(fmt);
/* 313 */     mCT2PMessageReader.parse((MCDPToken)tkn, p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCCooperateReturn end() {
/* 324 */     setDown();
/* 325 */     this.manager.getMessageMap().put(this.co_cd, this.ctx.param().getMessageParam().getMessage());
/* 326 */     if (!this.ctx.param().getExceptionParam().isEmpty()) {
/* 327 */       throw this.ctx.param().getExceptionParam().getExceptionRowParam().getEx();
/*     */     }
/* 329 */     return new MCCooperateReturn(this.co_cd);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setDown() {
/* 337 */     MCContainerParam p = this.ctx.param().getContainerParam();
/* 338 */     for (int i = 0; i < p.down().size(); i++) {
/* 339 */       MCContainer cnt = p.getDownBlock(i);
/* 340 */       if (cnt instanceof MCRow) {
/* 341 */         MCRow.copyall((MCRow)this.op.down(i), (MCRow)cnt);
/*     */       } else {
/*     */         
/* 344 */         ((MCList)this.op.down(i)).addAll((Collection)cnt);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\cooperate\MCCooperateInvokeCallable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */