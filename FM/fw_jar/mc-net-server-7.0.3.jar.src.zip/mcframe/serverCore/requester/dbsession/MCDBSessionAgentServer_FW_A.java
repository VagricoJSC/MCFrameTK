/*     */ package mcframe.serverCore.requester.dbsession;
/*     */ 
/*     */ import mcframe.commonCore.container.MCContainer;
/*     */ import mcframe.commonCore.param.MCOperationInfo;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.serverCore.logic.MCLogic;
/*     */ import mcframe.serverCore.logic.MCLogicUtil;
/*     */ import mcframe.serverCore.requester.decorator.MCDecorator;
/*     */ import mcframe.serverCore.requester.decorator.MCDecorator_FW;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MCDBSessionAgentServer_FW_A
/*     */   extends MCDecorator
/*     */ {
/*     */   public static final String MODULE_ID = "FC";
/*     */   public static final String SUBMODULE_ID = "FCBC";
/*     */   public static final String LOGIC_ID = "FCBCL0000";
/*     */   protected MCDBSessionAgentServer_FW.SessionKill aSessionKill;
/*     */   
/*     */   public String getModuleID() {
/*  42 */     return "FC";
/*     */   } public String getSubmoduleID() {
/*  44 */     return "FCBC";
/*     */   } public String getLogicID() {
/*  46 */     return "FCBCL0000";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initSessionKill() {
/*  53 */     this.info = PDef.FC_FCBCL0000_SessionKill_INFO;
/*  54 */     ((MCDBSessionAgentServer)this).getClass(); this.aSessionKill = new MCDBSessionAgentServer_FW.SessionKill((MCDBSessionAgentServer)this);
/*     */   }
/*     */   
/*     */   public static MCDBSessionAgentServer_FW.SessionKill crtSessionKill() {
/*  58 */     MCDBSessionAgentServer lgc = new MCDBSessionAgentServer();
/*  59 */     lgc.initSessionKill();
/*  60 */     return lgc.aSessionKill;
/*     */   }
/*     */   
/*     */   protected void paramSessionKill(MCParam p) {
/*  64 */     if (this.aSessionKill == null) {
/*     */       return;
/*     */     }
/*  67 */     p.setDef(this.info.def);
/*  68 */     p.addUpBlock((MCContainer)this.aSessionKill.up0());
/*     */   }
/*     */   
/*     */   protected void doSessionKill() {
/*  72 */     this.aSessionKill.call();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SessionR createSessionR() {
/*  81 */     return SessionR.create();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract class SessionKill
/*     */     extends MCDecorator_FW.Decorate
/*     */   {
/*     */     public static final String OPERATION_ID = "SessionKill";
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final SessionR up0;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getOperationID() {
/* 102 */       return "SessionKill";
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected SessionKill() {
/* 110 */       super((MCDecorator_FW)MCDBSessionAgentServer_FW_A.this);
/*     */ 
/*     */       
/* 113 */       this.up0 = SessionR.create();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void mapUpContainers(String key) {
/* 127 */       super.mapUpContainers(key);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void mapDownContainers(String key) {
/* 135 */       super.mapDownContainers(key);
/*     */     }
/*     */     
/*     */     public MCContainer up(int i) {
/* 139 */       if (i == 0) return (MCContainer)up0(); 
/* 140 */       return null;
/*     */     }
/*     */     
/*     */     public MCContainer down(int i) {
/* 144 */       return null;
/*     */     }
/*     */     
/*     */     public void exec() {
/* 148 */       clear();
/* 149 */       MCLogicUtil.invoke((MCLogic)MCDBSessionAgentServer_FW_A.this);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void clear() {}
/*     */ 
/*     */ 
/*     */     
/*     */     public SessionR createSessionR() {
/* 160 */       return SessionR.create();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public SessionR up0() {
/* 196 */       return this.up0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MCOperationInfo getOperationInfo() {
/* 204 */       return MCDBSessionAgentServer_FW_A.this.info;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\dbsession\MCDBSessionAgentServer_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */