package mcframe.serverCore.requester.dbsession;

import mcframe.commonCore.annotation.EI;

@EI
public class MCDBSessionAgentServer extends MCDBSessionAgentServer_FW {}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\dbsession\MCDBSessionAgentServer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */