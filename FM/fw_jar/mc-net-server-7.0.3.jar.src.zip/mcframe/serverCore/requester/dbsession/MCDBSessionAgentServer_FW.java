/*     */ package mcframe.serverCore.requester.dbsession;
/*     */ 
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCTimestamp;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.serverCore.dbc.FCT_DB_SESSION_R;
/*     */ import mcframe.serverCore.dbc.FCT_SERVER_SIGNAL_R;
/*     */ import mcframe.serverCore.dbc.FCT_SRV_REQUEST_R;
/*     */ import mcframe.serverCore.mcjdbc.MCConnectionPool;
/*     */ import mcframe.serverCore.notice.MCMessagePool;
/*     */ import mcframe.serverCore.queryapi.IFMCFMSQL;
/*     */ import mcframe.serverCore.queryapi.IFMCSQL;
/*     */ import mcframe.serverCore.queryapi.MCDBContainer;
/*     */ import mcframe.serverCore.resource.MCConst;
/*     */ import mcframe.serverCore.util.MCDBUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MCDBSessionAgentServer_FW
/*     */   extends MCDBSessionAgentServer_FW_A
/*     */ {
/*  43 */   private static final int SERVERSIGNAL_INTERRUPT_MODE = MCConst.app.getInteger(
/*  44 */       MCConst.createKey(new String[] { "serversignal", "interrupt", "mode" }, ), 2);
/*     */   
/*     */   private static final IFMCSQL.MCMainQuery SERVERSIGNAL_GET_SRV_REQ_NO_S01() {
/*  47 */     FCT_DB_SESSION_R S0S = FCT_DB_SESSION_R.create("S");
/*  48 */     FCT_SRV_REQUEST_R S0T = FCT_SRV_REQUEST_R.create("T");
/*     */     
/*  50 */     return (IFMCSQL.MCMainQuery)((IFMCSQL.MCMainQuery)IFMCSQL.sql("SERVERSIGNAL_GET_SRV_REQ_NO_S01")
/*  51 */       .mainQuery()
/*  52 */       .selectDistinct(new IFMCFMSQL.MCFMEDColumnGroup[] { (IFMCFMSQL.MCFMEDColumnGroup)S0S.srv_req_no
/*  53 */         }).from(
/*  54 */         (IFMCSQL.MCDerivedView)S0S
/*  55 */         .innerJoin((IFMCSQL.MCSingleView)S0T).on(
/*  56 */           S0S.srv_req_no.eq(S0T.srv_req_no))))
/*     */ 
/*     */       
/*  59 */       .where(
/*  60 */         S0T.user_id.eq(IFMCSQL.bind("user_id"))
/*  61 */         .and(
/*  62 */           IFMCSQL.bracket(
/*  63 */             S0T.co_cd.isNull()
/*  64 */             .and(IFMCSQL.bind("co_cd").isNull()))
/*     */           
/*  66 */           .or(S0T.co_cd.eq(IFMCSQL.bind("co_cd"))))
/*     */         
/*  68 */         .and(
/*  69 */           IFMCSQL.bracket(
/*  70 */             S0T.ext_attr1.isNull()
/*  71 */             .and(IFMCSQL.bind("ext_attr1").isNull()))
/*     */           
/*  73 */           .or(S0T.ext_attr1.eq(IFMCSQL.bind("ext_attr1"))))
/*     */         
/*  75 */         .and(
/*  76 */           IFMCSQL.bracket(
/*  77 */             S0T.ext_attr2.isNull()
/*  78 */             .and(IFMCSQL.bind("ext_attr2").isNull()))
/*     */           
/*  80 */           .or(S0T.ext_attr2.eq(IFMCSQL.bind("ext_attr2"))))
/*     */         
/*  82 */         .and(
/*  83 */           IFMCSQL.bracket(
/*  84 */             S0T.ext_attr3.isNull()
/*  85 */             .and(IFMCSQL.bind("ext_attr3").isNull()))
/*     */           
/*  87 */           .or(S0T.ext_attr3.eq(IFMCSQL.bind("ext_attr3"))))
/*     */         
/*  89 */         .and(S0T.c_req_no.eq(IFMCSQL.bind("c_req_no")))
/*  90 */         .and(S0T.c_req_ts.eq(IFMCSQL.bind("c_req_ts")))
/*  91 */         .and(S0T.module_id.eq(IFMCSQL.bind("module_id")))
/*  92 */         .and(S0T.logic_id.eq(IFMCSQL.bind("logic_id")))
/*  93 */         .and(S0T.ope_id.eq(IFMCSQL.bind("ope_id")))
/*  94 */         .and(S0S.srv_req_no.isNotNull()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class SessionKill
/*     */     extends MCDBSessionAgentServer_FW_A.SessionKill
/*     */   {
/*     */     protected void call() {
/* 106 */       super.call();
/*     */       
/* 108 */       if (up0().isEmpty(new String[] { "user_id", "co_cd", "ext_attr1", 
/* 109 */             "ext_attr2", "ext_attr3", "c_req_no", 
/* 110 */             "c_req_ts", "module_id", "logic_id", 
/* 111 */             "ope_id" })) {
/*     */         
/* 113 */         if (MCDBSessionAgentServer_FW.SERVERSIGNAL_INTERRUPT_MODE == 2 && !up0().sid_mode()) {
/* 114 */           InterruptOperation(up0().mcf_db_sid());
/*     */         } else {
/*     */           
/* 117 */           MCConnectionPool.sessionKill(up0().mcf_db_sid());
/*     */         
/*     */         }
/*     */       
/*     */       }
/* 122 */       else if (MCDBSessionAgentServer_FW.SERVERSIGNAL_INTERRUPT_MODE == 2 && !up0().sid_mode()) {
/* 123 */         InterruptOperation(up0().user_id(), up0().co_cd(), up0().ext_attr1(), 
/* 124 */             up0().ext_attr2(), up0().ext_attr3(), up0().c_req_no(), 
/* 125 */             up0().c_req_ts(), up0().module_id(), up0().logic_id(), 
/* 126 */             up0().ope_id());
/*     */       } else {
/*     */         
/* 129 */         MCConnectionPool.sessionKill(up0().user_id(), up0().co_cd(), 
/* 130 */             up0().ext_attr1(), up0().ext_attr2(), up0().ext_attr3(), 
/* 131 */             up0().c_req_no(), up0().c_req_ts(), up0().module_id(), 
/* 132 */             up0().logic_id(), up0().ope_id());
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void InterruptOperation(String mcf_db_sid) {
/* 148 */       FCT_DB_SESSION_R r = FCT_DB_SESSION_R.create("T");
/* 149 */       r.mcf_db_sid(mcf_db_sid);
/*     */       
/* 151 */       int cnt = MCDBUtil.dbSelectKey("FC_MCDBSessionAgentServer_FW_SessionKill_InterruptOperation", (MCRow)r, (MCDBContainer)r, (MCRow)r);
/* 152 */       if (cnt == 0 || r.srv_req_no() == null || r.srv_req_no().isEmpty()) {
/* 153 */         MCMessagePool.add(Core_Msg_FW_A.FCBGC0165, new Object[] { mcf_db_sid });
/*     */         
/*     */         return;
/*     */       } 
/* 157 */       InterruptOperation(r);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void InterruptOperation(String user_id, String co_cd, String ext_attr1, String ext_attr2, String ext_attr3, String c_req_no, MCTimestamp c_req_ts, String module_id, String logic_id, String ope_id) {
/* 184 */       MCRow bindMap = MCRow.create();
/* 185 */       bindMap.setStringNE("user_id", user_id);
/* 186 */       bindMap.setStringNE("co_cd", co_cd);
/* 187 */       bindMap.setStringNE("ext_attr1", ext_attr1);
/* 188 */       bindMap.setStringNE("ext_attr2", ext_attr2);
/* 189 */       bindMap.setStringNE("ext_attr3", ext_attr3);
/* 190 */       bindMap.setStringNE("c_req_no", c_req_no);
/* 191 */       bindMap.setTimestampNE("c_req_ts", c_req_ts);
/* 192 */       bindMap.setStringNE("module_id", module_id);
/* 193 */       bindMap.setStringNE("logic_id", logic_id);
/* 194 */       bindMap.setStringNE("ope_id", ope_id);
/*     */ 
/*     */       
/* 197 */       MCList<FCT_DB_SESSION_R> ls = MCList.create(FCT_DB_SESSION_R.class);
/*     */       
/* 199 */       int cnt = MCDBSessionAgentServer_FW.SERVERSIGNAL_GET_SRV_REQ_NO_S01().executeQuery(bindMap, ls);
/* 200 */       if (cnt == 0) {
/* 201 */         MCMessagePool.add(Core_Msg_FW_A.FCBGC0155, new Object[] { user_id, ext_attr1, ext_attr2, ext_attr3, c_req_no, 
/* 202 */               c_req_ts, module_id, logic_id, ope_id });
/*     */         
/*     */         return;
/*     */       } 
/* 206 */       for (FCT_DB_SESSION_R r : ls) {
/* 207 */         InterruptOperation(r);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void InterruptOperation(FCT_DB_SESSION_R r) {
/*     */       try {
/* 219 */         FCT_SERVER_SIGNAL_R S0 = FCT_SERVER_SIGNAL_R.create("T");
/*     */         
/* 221 */         IFMCSQL.sql("FC_MCDBSessionAgentServer_FW_SessionKill_InterruptOperation")
/* 222 */           .insert((IFMCSQL.MCPermView)S0)
/* 223 */           .columns(new IFMCFMSQL.MCFMAGPermColumn[] {
/* 224 */               (IFMCFMSQL.MCFMAGPermColumn)S0.srv_req_no, 
/* 225 */               (IFMCFMSQL.MCFMAGPermColumn)S0.srv_signal_typ
/*     */             
/* 227 */             }).values(new IFMCFMSQL.MCFMAGExpr[] {
/* 228 */               (IFMCFMSQL.MCFMAGExpr)IFMCSQL.bind("srv_req_no"), 
/* 229 */               (IFMCFMSQL.MCFMAGExpr)IFMCSQL.value("01")
/* 230 */             }).executeUpdate((MCRow)r);
/* 231 */         MCLog.write(Core_Msg_FW_A.FCBGC0154, new Object[] { r.srv_req_no() });
/*     */       }
/* 233 */       catch (MCException e) {
/* 234 */         if (Core_Msg_FW_A.FCBCC0136.equals(e.getMCMessage().getID())) {
/* 235 */           MCLog.write(Core_Msg_FW_A.FCBGC0160, new Object[] { r.srv_req_no() });
/*     */         } else {
/*     */           
/* 238 */           throw e;
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\dbsession\MCDBSessionAgentServer_FW.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */