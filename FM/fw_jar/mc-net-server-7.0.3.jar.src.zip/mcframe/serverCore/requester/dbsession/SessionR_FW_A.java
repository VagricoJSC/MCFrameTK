/*     */ package mcframe.serverCore.requester.dbsession;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.commonCore.container.MCConstRow;
/*     */ import mcframe.commonCore.container.MCExtMap;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCTimestamp;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ import mcframe.commonCore.meta.M_META;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class SessionR_FW_A
/*     */   extends MCConstRow
/*     */ {
/*     */   public static final String $mcf_db_sid = "mcf_db_sid";
/*     */   public static final String $user_id = "user_id";
/*     */   public static final String $co_cd = "co_cd";
/*     */   public static final String $ext_attr1 = "ext_attr1";
/*     */   public static final String $ext_attr2 = "ext_attr2";
/*     */   public static final String $ext_attr3 = "ext_attr3";
/*     */   public static final String $clt_id = "clt_id";
/*     */   public static final String $c_req_no = "c_req_no";
/*     */   public static final String $c_req_ts = "c_req_ts";
/*     */   public static final String $c_locale = "c_locale";
/*     */   public static final String $c_time_zone = "c_time_zone";
/*     */   public static final String $call_pg_id = "call_pg_id";
/*     */   public static final String $operation_cd = "operation_cd";
/*     */   public static final String $btn_res_key = "btn_res_key";
/*     */   public static final String $action_id = "action_id";
/*     */   public static final String $srv_req_no = "srv_req_no";
/*     */   public static final String $module_id = "module_id";
/*     */   public static final String $logic_id = "logic_id";
/*     */   public static final String $ope_id = "ope_id";
/*     */   public static final String $srv_id = "srv_id";
/*     */   public static final String $sid_mode = "sid_mode";
/*  51 */   public static final MCMeta mcf_db_sid_META = createCommonMeta("mcf_db_sid", M_META.MCF_DB_SESSION_ID);
/*  52 */   public static final MCMeta user_id_META = createCommonMeta("user_id", M_META.USR_ID);
/*  53 */   public static final MCMeta co_cd_META = createCommonMeta("co_cd", M_META.CO_CD);
/*  54 */   public static final MCMeta ext_attr1_META = createCommonMeta("ext_attr1", M_META.USR_EXT_ATTR);
/*  55 */   public static final MCMeta ext_attr2_META = createCommonMeta("ext_attr2", M_META.USR_EXT_ATTR);
/*  56 */   public static final MCMeta ext_attr3_META = createCommonMeta("ext_attr3", M_META.USR_EXT_ATTR);
/*  57 */   public static final MCMeta clt_id_META = createCommonMeta("clt_id", M_META.MACHINE);
/*  58 */   public static final MCMeta c_req_no_META = createCommonMeta("c_req_no", M_META.SRV_REQ_NO);
/*  59 */   public static final MCMeta c_req_ts_META = createCommonMeta("c_req_ts", M_META.TS);
/*  60 */   public static final MCMeta c_locale_META = createCommonMeta("c_locale", M_META.LOCALE_CD);
/*  61 */   public static final MCMeta c_time_zone_META = createCommonMeta("c_time_zone", M_META.TIME_ZONE);
/*  62 */   public static final MCMeta call_pg_id_META = createCommonMeta("call_pg_id", M_META.SCREEN_ID);
/*  63 */   public static final MCMeta operation_cd_META = createCommonMeta("operation_cd", M_META.OPERATION_CD);
/*  64 */   public static final MCMeta btn_res_key_META = createCommonMeta("btn_res_key", M_META.RES_KEY);
/*  65 */   public static final MCMeta action_id_META = createCommonMeta("action_id", M_META.ACTION_ID);
/*  66 */   public static final MCMeta srv_req_no_META = createCommonMeta("srv_req_no", M_META.SRV_REQ_NO);
/*  67 */   public static final MCMeta module_id_META = createCommonMeta("module_id", M_META.MODULE_ID);
/*  68 */   public static final MCMeta logic_id_META = createCommonMeta("logic_id", M_META.LOGIC_ID);
/*  69 */   public static final MCMeta ope_id_META = createCommonMeta("ope_id", M_META.OPERATION_ID);
/*  70 */   public static final MCMeta srv_id_META = createCommonMeta("srv_id", M_META.MACHINE);
/*  71 */   public static final MCMeta sid_mode_META = createBooleanMeta("sid_mode");
/*     */   
/*  73 */   protected static final MCRow.ConstMetaList<SessionR> constMetas = new MCRow.ConstMetaList(
/*  74 */       MCConstRow.constMetas, 
/*  75 */       new MCMeta[] { 
/*  76 */         mcf_db_sid_META, 
/*  77 */         user_id_META, 
/*  78 */         co_cd_META, 
/*  79 */         ext_attr1_META, 
/*  80 */         ext_attr2_META, 
/*  81 */         ext_attr3_META, 
/*  82 */         clt_id_META, 
/*  83 */         c_req_no_META, 
/*  84 */         c_req_ts_META, 
/*  85 */         c_locale_META, 
/*  86 */         c_time_zone_META, 
/*  87 */         call_pg_id_META, 
/*  88 */         operation_cd_META, 
/*  89 */         btn_res_key_META, 
/*  90 */         action_id_META, 
/*  91 */         srv_req_no_META, 
/*  92 */         module_id_META, 
/*  93 */         logic_id_META, 
/*  94 */         ope_id_META, 
/*  95 */         srv_id_META, 
/*  96 */         sid_mode_META
/*     */       },
/*  98 */       new String[][] { {}, {} });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   protected static final MCExtMap EXTMAP = new MCExtMap(
/* 111 */       null, new MCExtMap.Entry[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] colnames() {
/* 123 */     return constMetas.toNameArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMeta[] colmetas() {
/* 135 */     return constMetas.toMetaArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 141 */   private static final int offset = constMetas.offset();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getExtMap(String aGroup) {
/* 147 */     if (aGroup == null) return null; 
/* 148 */     return (Map<String, String>)EXTMAP.get(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getKeys(String aGroup) {
/* 155 */     if (aGroup == null) return null; 
/* 156 */     return EXTMAP.getKeyList(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExtGroups() {
/* 163 */     Set<String> ret = EXTMAP.keySet();
/* 164 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected SessionR_FW_A(MCRow.ConstMetaList<? extends SessionR> metas) {
/* 171 */     super(metas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SessionR clone() {
/* 178 */     return (SessionR)super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SessionR createInstance() {
/* 185 */     return (SessionR)super.createInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SessionR getValues(String... names) {
/* 192 */     return (SessionR)super.getValues(names);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireValueChanged(String column, Comparable<?> newvalue, Comparable<?> oldvalue) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String mcf_db_sid() {
/* 204 */     return getConstString(offset + 0, "mcf_db_sid");
/*     */   }
/*     */   
/*     */   public void mcf_db_sid(String value) {
/* 208 */     setConstString(offset + 0, "mcf_db_sid", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String user_id() {
/* 213 */     return getConstString(offset + 1, "user_id");
/*     */   }
/*     */   
/*     */   public void user_id(String value) {
/* 217 */     setConstString(offset + 1, "user_id", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String co_cd() {
/* 222 */     return getConstString(offset + 2, "co_cd");
/*     */   }
/*     */   
/*     */   public void co_cd(String value) {
/* 226 */     setConstString(offset + 2, "co_cd", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String ext_attr1() {
/* 231 */     return getConstString(offset + 3, "ext_attr1");
/*     */   }
/*     */   
/*     */   public void ext_attr1(String value) {
/* 235 */     setConstString(offset + 3, "ext_attr1", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String ext_attr2() {
/* 240 */     return getConstString(offset + 4, "ext_attr2");
/*     */   }
/*     */   
/*     */   public void ext_attr2(String value) {
/* 244 */     setConstString(offset + 4, "ext_attr2", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String ext_attr3() {
/* 249 */     return getConstString(offset + 5, "ext_attr3");
/*     */   }
/*     */   
/*     */   public void ext_attr3(String value) {
/* 253 */     setConstString(offset + 5, "ext_attr3", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String clt_id() {
/* 258 */     return getConstString(offset + 6, "clt_id");
/*     */   }
/*     */   
/*     */   public void clt_id(String value) {
/* 262 */     setConstString(offset + 6, "clt_id", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String c_req_no() {
/* 267 */     return getConstString(offset + 7, "c_req_no");
/*     */   }
/*     */   
/*     */   public void c_req_no(String value) {
/* 271 */     setConstString(offset + 7, "c_req_no", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCTimestamp c_req_ts() {
/* 276 */     return getConstTimestamp(offset + 8, "c_req_ts");
/*     */   }
/*     */   
/*     */   public void c_req_ts(MCTimestamp value) {
/* 280 */     setConstTimestamp(offset + 8, "c_req_ts", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String c_locale() {
/* 285 */     return getConstString(offset + 9, "c_locale");
/*     */   }
/*     */   
/*     */   public void c_locale(String value) {
/* 289 */     setConstString(offset + 9, "c_locale", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String c_time_zone() {
/* 294 */     return getConstString(offset + 10, "c_time_zone");
/*     */   }
/*     */   
/*     */   public void c_time_zone(String value) {
/* 298 */     setConstString(offset + 10, "c_time_zone", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String call_pg_id() {
/* 303 */     return getConstString(offset + 11, "call_pg_id");
/*     */   }
/*     */   
/*     */   public void call_pg_id(String value) {
/* 307 */     setConstString(offset + 11, "call_pg_id", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String operation_cd() {
/* 312 */     return getConstString(offset + 12, "operation_cd");
/*     */   }
/*     */   
/*     */   public void operation_cd(String value) {
/* 316 */     setConstString(offset + 12, "operation_cd", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String btn_res_key() {
/* 321 */     return getConstString(offset + 13, "btn_res_key");
/*     */   }
/*     */   
/*     */   public void btn_res_key(String value) {
/* 325 */     setConstString(offset + 13, "btn_res_key", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String action_id() {
/* 330 */     return getConstString(offset + 14, "action_id");
/*     */   }
/*     */   
/*     */   public void action_id(String value) {
/* 334 */     setConstString(offset + 14, "action_id", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String srv_req_no() {
/* 339 */     return getConstString(offset + 15, "srv_req_no");
/*     */   }
/*     */   
/*     */   public void srv_req_no(String value) {
/* 343 */     setConstString(offset + 15, "srv_req_no", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String module_id() {
/* 348 */     return getConstString(offset + 16, "module_id");
/*     */   }
/*     */   
/*     */   public void module_id(String value) {
/* 352 */     setConstString(offset + 16, "module_id", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String logic_id() {
/* 357 */     return getConstString(offset + 17, "logic_id");
/*     */   }
/*     */   
/*     */   public void logic_id(String value) {
/* 361 */     setConstString(offset + 17, "logic_id", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String ope_id() {
/* 366 */     return getConstString(offset + 18, "ope_id");
/*     */   }
/*     */   
/*     */   public void ope_id(String value) {
/* 370 */     setConstString(offset + 18, "ope_id", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String srv_id() {
/* 375 */     return getConstString(offset + 19, "srv_id");
/*     */   }
/*     */   
/*     */   public void srv_id(String value) {
/* 379 */     setConstString(offset + 19, "srv_id", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean sid_mode() {
/* 384 */     return getConstBoolean(offset + 20, "sid_mode");
/*     */   }
/*     */   
/*     */   public void sid_mode(boolean value) {
/* 388 */     setConstBoolean(offset + 20, "sid_mode", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString(String name) {
/* 393 */     if ("mcf_db_sid".equalsIgnoreCase(name)) {
/* 394 */       return mcf_db_sid();
/*     */     }
/* 396 */     if ("user_id".equalsIgnoreCase(name)) {
/* 397 */       return user_id();
/*     */     }
/* 399 */     if ("co_cd".equalsIgnoreCase(name)) {
/* 400 */       return co_cd();
/*     */     }
/* 402 */     if ("ext_attr1".equalsIgnoreCase(name)) {
/* 403 */       return ext_attr1();
/*     */     }
/* 405 */     if ("ext_attr2".equalsIgnoreCase(name)) {
/* 406 */       return ext_attr2();
/*     */     }
/* 408 */     if ("ext_attr3".equalsIgnoreCase(name)) {
/* 409 */       return ext_attr3();
/*     */     }
/* 411 */     if ("clt_id".equalsIgnoreCase(name)) {
/* 412 */       return clt_id();
/*     */     }
/* 414 */     if ("c_req_no".equalsIgnoreCase(name)) {
/* 415 */       return c_req_no();
/*     */     }
/* 417 */     if ("c_locale".equalsIgnoreCase(name)) {
/* 418 */       return c_locale();
/*     */     }
/* 420 */     if ("c_time_zone".equalsIgnoreCase(name)) {
/* 421 */       return c_time_zone();
/*     */     }
/* 423 */     if ("call_pg_id".equalsIgnoreCase(name)) {
/* 424 */       return call_pg_id();
/*     */     }
/* 426 */     if ("operation_cd".equalsIgnoreCase(name)) {
/* 427 */       return operation_cd();
/*     */     }
/* 429 */     if ("btn_res_key".equalsIgnoreCase(name)) {
/* 430 */       return btn_res_key();
/*     */     }
/* 432 */     if ("action_id".equalsIgnoreCase(name)) {
/* 433 */       return action_id();
/*     */     }
/* 435 */     if ("srv_req_no".equalsIgnoreCase(name)) {
/* 436 */       return srv_req_no();
/*     */     }
/* 438 */     if ("module_id".equalsIgnoreCase(name)) {
/* 439 */       return module_id();
/*     */     }
/* 441 */     if ("logic_id".equalsIgnoreCase(name)) {
/* 442 */       return logic_id();
/*     */     }
/* 444 */     if ("ope_id".equalsIgnoreCase(name)) {
/* 445 */       return ope_id();
/*     */     }
/* 447 */     if ("srv_id".equalsIgnoreCase(name)) {
/* 448 */       return srv_id();
/*     */     }
/* 450 */     return super.getString(name);
/*     */   }
/*     */   public MCTimestamp getTimestamp(String name) {
/* 453 */     if ("c_req_ts".equalsIgnoreCase(name)) {
/* 454 */       return c_req_ts();
/*     */     }
/* 456 */     return super.getTimestamp(name);
/*     */   }
/*     */   public boolean getBoolean(String name) {
/* 459 */     if ("sid_mode".equalsIgnoreCase(name)) {
/* 460 */       return sid_mode();
/*     */     }
/* 462 */     return super.getBoolean(name);
/*     */   }
/*     */   
/*     */   public String getStringNE(String name) {
/* 466 */     if ("mcf_db_sid".equalsIgnoreCase(name)) {
/* 467 */       return mcf_db_sid();
/*     */     }
/* 469 */     if ("user_id".equalsIgnoreCase(name)) {
/* 470 */       return user_id();
/*     */     }
/* 472 */     if ("co_cd".equalsIgnoreCase(name)) {
/* 473 */       return co_cd();
/*     */     }
/* 475 */     if ("ext_attr1".equalsIgnoreCase(name)) {
/* 476 */       return ext_attr1();
/*     */     }
/* 478 */     if ("ext_attr2".equalsIgnoreCase(name)) {
/* 479 */       return ext_attr2();
/*     */     }
/* 481 */     if ("ext_attr3".equalsIgnoreCase(name)) {
/* 482 */       return ext_attr3();
/*     */     }
/* 484 */     if ("clt_id".equalsIgnoreCase(name)) {
/* 485 */       return clt_id();
/*     */     }
/* 487 */     if ("c_req_no".equalsIgnoreCase(name)) {
/* 488 */       return c_req_no();
/*     */     }
/* 490 */     if ("c_locale".equalsIgnoreCase(name)) {
/* 491 */       return c_locale();
/*     */     }
/* 493 */     if ("c_time_zone".equalsIgnoreCase(name)) {
/* 494 */       return c_time_zone();
/*     */     }
/* 496 */     if ("call_pg_id".equalsIgnoreCase(name)) {
/* 497 */       return call_pg_id();
/*     */     }
/* 499 */     if ("operation_cd".equalsIgnoreCase(name)) {
/* 500 */       return operation_cd();
/*     */     }
/* 502 */     if ("btn_res_key".equalsIgnoreCase(name)) {
/* 503 */       return btn_res_key();
/*     */     }
/* 505 */     if ("action_id".equalsIgnoreCase(name)) {
/* 506 */       return action_id();
/*     */     }
/* 508 */     if ("srv_req_no".equalsIgnoreCase(name)) {
/* 509 */       return srv_req_no();
/*     */     }
/* 511 */     if ("module_id".equalsIgnoreCase(name)) {
/* 512 */       return module_id();
/*     */     }
/* 514 */     if ("logic_id".equalsIgnoreCase(name)) {
/* 515 */       return logic_id();
/*     */     }
/* 517 */     if ("ope_id".equalsIgnoreCase(name)) {
/* 518 */       return ope_id();
/*     */     }
/* 520 */     if ("srv_id".equalsIgnoreCase(name)) {
/* 521 */       return srv_id();
/*     */     }
/* 523 */     return super.getStringNE(name);
/*     */   }
/*     */   public MCTimestamp getTimestampNE(String name) {
/* 526 */     if ("c_req_ts".equalsIgnoreCase(name)) {
/* 527 */       return c_req_ts();
/*     */     }
/* 529 */     return super.getTimestampNE(name);
/*     */   }
/*     */   public boolean getBooleanNE(String name) {
/* 532 */     if ("sid_mode".equalsIgnoreCase(name)) {
/* 533 */       return sid_mode();
/*     */     }
/* 535 */     return super.getBooleanNE(name);
/*     */   }
/*     */   
/*     */   public void setString(String name, String value) {
/* 539 */     if ("mcf_db_sid".equalsIgnoreCase(name)) {
/* 540 */       mcf_db_sid(value);
/*     */       return;
/*     */     } 
/* 543 */     if ("user_id".equalsIgnoreCase(name)) {
/* 544 */       user_id(value);
/*     */       return;
/*     */     } 
/* 547 */     if ("co_cd".equalsIgnoreCase(name)) {
/* 548 */       co_cd(value);
/*     */       return;
/*     */     } 
/* 551 */     if ("ext_attr1".equalsIgnoreCase(name)) {
/* 552 */       ext_attr1(value);
/*     */       return;
/*     */     } 
/* 555 */     if ("ext_attr2".equalsIgnoreCase(name)) {
/* 556 */       ext_attr2(value);
/*     */       return;
/*     */     } 
/* 559 */     if ("ext_attr3".equalsIgnoreCase(name)) {
/* 560 */       ext_attr3(value);
/*     */       return;
/*     */     } 
/* 563 */     if ("clt_id".equalsIgnoreCase(name)) {
/* 564 */       clt_id(value);
/*     */       return;
/*     */     } 
/* 567 */     if ("c_req_no".equalsIgnoreCase(name)) {
/* 568 */       c_req_no(value);
/*     */       return;
/*     */     } 
/* 571 */     if ("c_locale".equalsIgnoreCase(name)) {
/* 572 */       c_locale(value);
/*     */       return;
/*     */     } 
/* 575 */     if ("c_time_zone".equalsIgnoreCase(name)) {
/* 576 */       c_time_zone(value);
/*     */       return;
/*     */     } 
/* 579 */     if ("call_pg_id".equalsIgnoreCase(name)) {
/* 580 */       call_pg_id(value);
/*     */       return;
/*     */     } 
/* 583 */     if ("operation_cd".equalsIgnoreCase(name)) {
/* 584 */       operation_cd(value);
/*     */       return;
/*     */     } 
/* 587 */     if ("btn_res_key".equalsIgnoreCase(name)) {
/* 588 */       btn_res_key(value);
/*     */       return;
/*     */     } 
/* 591 */     if ("action_id".equalsIgnoreCase(name)) {
/* 592 */       action_id(value);
/*     */       return;
/*     */     } 
/* 595 */     if ("srv_req_no".equalsIgnoreCase(name)) {
/* 596 */       srv_req_no(value);
/*     */       return;
/*     */     } 
/* 599 */     if ("module_id".equalsIgnoreCase(name)) {
/* 600 */       module_id(value);
/*     */       return;
/*     */     } 
/* 603 */     if ("logic_id".equalsIgnoreCase(name)) {
/* 604 */       logic_id(value);
/*     */       return;
/*     */     } 
/* 607 */     if ("ope_id".equalsIgnoreCase(name)) {
/* 608 */       ope_id(value);
/*     */       return;
/*     */     } 
/* 611 */     if ("srv_id".equalsIgnoreCase(name)) {
/* 612 */       srv_id(value);
/*     */       return;
/*     */     } 
/* 615 */     super.setString(name, value);
/*     */   }
/*     */   public void setTimestamp(String name, MCTimestamp value) {
/* 618 */     if ("c_req_ts".equalsIgnoreCase(name)) {
/* 619 */       c_req_ts(value);
/*     */       return;
/*     */     } 
/* 622 */     super.setTimestamp(name, value);
/*     */   }
/*     */   public void setBoolean(String name, boolean value) {
/* 625 */     if ("sid_mode".equalsIgnoreCase(name)) {
/* 626 */       sid_mode(value);
/*     */       return;
/*     */     } 
/* 629 */     super.setBoolean(name, value);
/*     */   }
/*     */   
/*     */   public void setStringNE(String name, String value) {
/* 633 */     if ("mcf_db_sid".equalsIgnoreCase(name)) {
/* 634 */       mcf_db_sid(value);
/*     */       return;
/*     */     } 
/* 637 */     if ("user_id".equalsIgnoreCase(name)) {
/* 638 */       user_id(value);
/*     */       return;
/*     */     } 
/* 641 */     if ("co_cd".equalsIgnoreCase(name)) {
/* 642 */       co_cd(value);
/*     */       return;
/*     */     } 
/* 645 */     if ("ext_attr1".equalsIgnoreCase(name)) {
/* 646 */       ext_attr1(value);
/*     */       return;
/*     */     } 
/* 649 */     if ("ext_attr2".equalsIgnoreCase(name)) {
/* 650 */       ext_attr2(value);
/*     */       return;
/*     */     } 
/* 653 */     if ("ext_attr3".equalsIgnoreCase(name)) {
/* 654 */       ext_attr3(value);
/*     */       return;
/*     */     } 
/* 657 */     if ("clt_id".equalsIgnoreCase(name)) {
/* 658 */       clt_id(value);
/*     */       return;
/*     */     } 
/* 661 */     if ("c_req_no".equalsIgnoreCase(name)) {
/* 662 */       c_req_no(value);
/*     */       return;
/*     */     } 
/* 665 */     if ("c_locale".equalsIgnoreCase(name)) {
/* 666 */       c_locale(value);
/*     */       return;
/*     */     } 
/* 669 */     if ("c_time_zone".equalsIgnoreCase(name)) {
/* 670 */       c_time_zone(value);
/*     */       return;
/*     */     } 
/* 673 */     if ("call_pg_id".equalsIgnoreCase(name)) {
/* 674 */       call_pg_id(value);
/*     */       return;
/*     */     } 
/* 677 */     if ("operation_cd".equalsIgnoreCase(name)) {
/* 678 */       operation_cd(value);
/*     */       return;
/*     */     } 
/* 681 */     if ("btn_res_key".equalsIgnoreCase(name)) {
/* 682 */       btn_res_key(value);
/*     */       return;
/*     */     } 
/* 685 */     if ("action_id".equalsIgnoreCase(name)) {
/* 686 */       action_id(value);
/*     */       return;
/*     */     } 
/* 689 */     if ("srv_req_no".equalsIgnoreCase(name)) {
/* 690 */       srv_req_no(value);
/*     */       return;
/*     */     } 
/* 693 */     if ("module_id".equalsIgnoreCase(name)) {
/* 694 */       module_id(value);
/*     */       return;
/*     */     } 
/* 697 */     if ("logic_id".equalsIgnoreCase(name)) {
/* 698 */       logic_id(value);
/*     */       return;
/*     */     } 
/* 701 */     if ("ope_id".equalsIgnoreCase(name)) {
/* 702 */       ope_id(value);
/*     */       return;
/*     */     } 
/* 705 */     if ("srv_id".equalsIgnoreCase(name)) {
/* 706 */       srv_id(value);
/*     */       return;
/*     */     } 
/* 709 */     super.setStringNE(name, value);
/*     */   }
/*     */   public void setTimestampNE(String name, MCTimestamp value) {
/* 712 */     if ("c_req_ts".equalsIgnoreCase(name)) {
/* 713 */       c_req_ts(value);
/*     */       return;
/*     */     } 
/* 716 */     super.setTimestampNE(name, value);
/*     */   }
/*     */   public void setBooleanNE(String name, boolean value) {
/* 719 */     if ("sid_mode".equalsIgnoreCase(name)) {
/* 720 */       sid_mode(value);
/*     */       return;
/*     */     } 
/* 723 */     super.setBooleanNE(name, value);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\dbsession\SessionR_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */