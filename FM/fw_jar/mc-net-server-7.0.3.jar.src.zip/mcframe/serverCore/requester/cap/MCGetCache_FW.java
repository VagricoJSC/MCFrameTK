/*    */ package mcframe.serverCore.requester.cap;
/*    */ 
/*    */ import mcframe.commonCore.param.MCDPWriter;
/*    */ import mcframe.commonCore.param.MCParam;
/*    */ import mcframe.commonCore.requester.MCFile;
/*    */ import mcframe.serverCore.logic.MCLogic;
/*    */ import mcframe.serverCore.requester.MCCapAgent;
/*    */ import mcframe.serverCore.requester.MCDispatcherContext;
/*    */ import mcframe.serverCore.requester.MCLogicRefUtil;
/*    */ import mcframe.serverCore.requester.decorator.MCDecorator_FW;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class MCGetCache_FW
/*    */   extends MCGetCache_FW_A
/*    */ {
/*    */   public class GetCache
/*    */     extends MCGetCache_FW_A.GetCache
/*    */   {
/*    */     protected void call() {
/* 44 */       String down = callDecorate(up0().denbun());
/* 45 */       down0().denbun(down);
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */     
/*    */     protected void setRequestStatus(MCDispatcherContext ctx, MCDPWriter dwdpw) {}
/*    */ 
/*    */ 
/*    */     
/*    */     protected void decorate(MCDispatcherContext ctx) {
/* 56 */       MCGetCache_FW.this.logger.writeUpLog(ctx, this.decoratedUp);
/*    */       
/* 58 */       MCParam p = ctx.param();
/* 59 */       MCLogic lgc = MCLogicRefUtil.crtLgc(p);
/* 60 */       MCLogicRefUtil.initLgcPrm(lgc, p);
/*    */       
/* 62 */       String fName = MCGetCache_FW.getCacheFile(up1().cache_id());
/* 63 */       MCFile f = new MCFile();
/*    */ 
/*    */ 
/*    */       
/* 67 */       String dp = f.loadData(fName);
/*    */       
/* 69 */       ctx.getDwDPW().write(dp);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String getCacheFile(String id) {
/* 84 */     return String.valueOf(MCCapAgent.getCacheDir()) + 
/* 85 */       MCFile.PATH_SEP + 
/* 86 */       id;
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\cap\MCGetCache_FW.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */