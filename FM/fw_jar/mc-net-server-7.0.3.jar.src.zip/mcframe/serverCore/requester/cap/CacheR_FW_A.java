/*     */ package mcframe.serverCore.requester.cap;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.commonCore.container.MCConstRow;
/*     */ import mcframe.commonCore.container.MCExtMap;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class CacheR_FW_A
/*     */   extends MCConstRow
/*     */ {
/*     */   public static final String $total = "total";
/*     */   public static final String $cache_id = "cache_id";
/*  32 */   public static final MCMeta total_META = createNumberMeta("total");
/*  33 */   public static final MCMeta cache_id_META = createStringMeta("cache_id");
/*     */   
/*  35 */   protected static final MCRow.ConstMetaList<CacheR> constMetas = new MCRow.ConstMetaList(
/*  36 */       MCConstRow.constMetas, 
/*  37 */       new MCMeta[] {
/*  38 */         total_META, 
/*  39 */         cache_id_META
/*     */       },
/*  41 */       new String[][] { {}, {} });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   protected static final MCExtMap EXTMAP = new MCExtMap(
/*  54 */       null, new MCExtMap.Entry[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] colnames() {
/*  66 */     return constMetas.toNameArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMeta[] colmetas() {
/*  78 */     return constMetas.toMetaArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  84 */   private static final int offset = constMetas.offset();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getExtMap(String aGroup) {
/*  90 */     if (aGroup == null) return null; 
/*  91 */     return (Map<String, String>)EXTMAP.get(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getKeys(String aGroup) {
/*  98 */     if (aGroup == null) return null; 
/*  99 */     return EXTMAP.getKeyList(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExtGroups() {
/* 106 */     Set<String> ret = EXTMAP.keySet();
/* 107 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CacheR_FW_A(MCRow.ConstMetaList<? extends CacheR> metas) {
/* 114 */     super(metas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CacheR clone() {
/* 121 */     return (CacheR)super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CacheR createInstance() {
/* 128 */     return (CacheR)super.createInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CacheR getValues(String... names) {
/* 135 */     return (CacheR)super.getValues(names);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireValueChanged(String column, Comparable<?> newvalue, Comparable<?> oldvalue) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCNumber total() {
/* 147 */     return getConstNumber(offset + 0, "total");
/*     */   }
/*     */   
/*     */   public void total(MCNumber value) {
/* 151 */     setConstNumber(offset + 0, "total", value);
/*     */   }
/*     */   
/*     */   public void total(int value) {
/* 155 */     setConstNumber(offset + 0, "total", value);
/*     */   }
/*     */   
/*     */   public void total(long value) {
/* 159 */     setConstNumber(offset + 0, "total", value);
/*     */   }
/*     */   
/*     */   public void total(float value) {
/* 163 */     setConstNumber(offset + 0, "total", value);
/*     */   }
/*     */   
/*     */   public void total(double value) {
/* 167 */     setConstNumber(offset + 0, "total", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String cache_id() {
/* 172 */     return getConstString(offset + 1, "cache_id");
/*     */   }
/*     */   
/*     */   public void cache_id(String value) {
/* 176 */     setConstString(offset + 1, "cache_id", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString(String name) {
/* 181 */     if ("cache_id".equalsIgnoreCase(name)) {
/* 182 */       return cache_id();
/*     */     }
/* 184 */     return super.getString(name);
/*     */   }
/*     */   public MCNumber getNumber(String name) {
/* 187 */     if ("total".equalsIgnoreCase(name)) {
/* 188 */       return total();
/*     */     }
/* 190 */     return super.getNumber(name);
/*     */   }
/*     */   
/*     */   public String getStringNE(String name) {
/* 194 */     if ("cache_id".equalsIgnoreCase(name)) {
/* 195 */       return cache_id();
/*     */     }
/* 197 */     return super.getStringNE(name);
/*     */   }
/*     */   public MCNumber getNumberNE(String name) {
/* 200 */     if ("total".equalsIgnoreCase(name)) {
/* 201 */       return total();
/*     */     }
/* 203 */     return super.getNumberNE(name);
/*     */   }
/*     */   
/*     */   public void setString(String name, String value) {
/* 207 */     if ("cache_id".equalsIgnoreCase(name)) {
/* 208 */       cache_id(value);
/*     */       return;
/*     */     } 
/* 211 */     super.setString(name, value);
/*     */   }
/*     */   public void setNumber(String name, MCNumber value) {
/* 214 */     if ("total".equalsIgnoreCase(name)) {
/* 215 */       total(value);
/*     */       return;
/*     */     } 
/* 218 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, int value) {
/* 221 */     if ("total".equalsIgnoreCase(name)) {
/* 222 */       total(value);
/*     */       return;
/*     */     } 
/* 225 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, long value) {
/* 228 */     if ("total".equalsIgnoreCase(name)) {
/* 229 */       total(value);
/*     */       return;
/*     */     } 
/* 232 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, float value) {
/* 235 */     if ("total".equalsIgnoreCase(name)) {
/* 236 */       total(value);
/*     */       return;
/*     */     } 
/* 239 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, double value) {
/* 242 */     if ("total".equalsIgnoreCase(name)) {
/* 243 */       total(value);
/*     */       return;
/*     */     } 
/* 246 */     super.setNumber(name, value);
/*     */   }
/*     */   
/*     */   public void setStringNE(String name, String value) {
/* 250 */     if ("cache_id".equalsIgnoreCase(name)) {
/* 251 */       cache_id(value);
/*     */       return;
/*     */     } 
/* 254 */     super.setStringNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, MCNumber value) {
/* 257 */     if ("total".equalsIgnoreCase(name)) {
/* 258 */       total(value);
/*     */       return;
/*     */     } 
/* 261 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, int value) {
/* 264 */     if ("total".equalsIgnoreCase(name)) {
/* 265 */       total(value);
/*     */       return;
/*     */     } 
/* 268 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, long value) {
/* 271 */     if ("total".equalsIgnoreCase(name)) {
/* 272 */       total(value);
/*     */       return;
/*     */     } 
/* 275 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, float value) {
/* 278 */     if ("total".equalsIgnoreCase(name)) {
/* 279 */       total(value);
/*     */       return;
/*     */     } 
/* 282 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, double value) {
/* 285 */     if ("total".equalsIgnoreCase(name)) {
/* 286 */       total(value);
/*     */       return;
/*     */     } 
/* 289 */     super.setNumberNE(name, value);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\cap\CacheR_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */