/*    */ package mcframe.serverCore.requester.cap;
/*    */ 
/*    */ import mcframe.commonCore.param.MCBlockDef;
/*    */ import mcframe.commonCore.param.MCContainerDef;
/*    */ import mcframe.commonCore.param.MCDef;
/*    */ import mcframe.commonCore.param.MCGeneralContainerDef;
/*    */ import mcframe.commonCore.param.MCItemDef;
/*    */ import mcframe.commonCore.param.MCOperationInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PDef_FW_A
/*    */   extends MCDef
/*    */ {
/*    */   public MCContainerDef getCustomDef(String id) {
/* 22 */     if (id == null) {
/* 23 */       return null;
/*    */     }
/*    */     
/* 26 */     if (id.equals("FC.FCBGL1000.GetCache.UP.BLOCK0")) {
/* 27 */       return FC_FCBGL1000_GetCache_UP_BLOCK0();
/*    */     }
/* 29 */     if (id.equals("FC.FCBGL1000.GetCache.UP.BLOCK1")) {
/* 30 */       return FC_FCBGL1000_GetCache_UP_BLOCK1();
/*    */     }
/* 32 */     if (id.equals("FC.FCBGL1000.GetCache.DOWN.BLOCK0")) {
/* 33 */       return FC_FCBGL1000_GetCache_DOWN_BLOCK0();
/*    */     }
/*    */ 
/*    */     
/* 37 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 43 */   static final MCOperationInfo FC_FCBGL1000_GetCache_INFO = new MCOperationInfo("FC", "FCBGL1000", "GetCache", "000000", new PDef());
/*    */ 
/*    */   
/*    */   public static MCContainerDef FC_FCBGL1000_GetCache_UP_BLOCK0() {
/* 47 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL1000", "GetCache", 
/* 48 */         new MCItemDef[] {
/* 49 */           MCItemDef.create("denbun", true, "denbun")
/*    */ 
/*    */         
/* 52 */         }MCBlockDef.create("Dec"));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static MCContainerDef FC_FCBGL1000_GetCache_UP_BLOCK1() {
/* 58 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL1000", "GetCache", 
/* 59 */         new MCItemDef[] {
/* 60 */           MCItemDef.create("cache_id", true, "cache_id")
/*    */ 
/*    */         
/* 63 */         }MCBlockDef.create("Cache"));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static MCContainerDef FC_FCBGL1000_GetCache_DOWN_BLOCK0() {
/* 70 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBGL1000", "GetCache", 
/* 71 */         new MCItemDef[] {
/* 72 */           MCItemDef.create("denbun", true, "denbun")
/*    */ 
/*    */         
/* 75 */         }MCBlockDef.create("Dec"));
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\cap\PDef_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */