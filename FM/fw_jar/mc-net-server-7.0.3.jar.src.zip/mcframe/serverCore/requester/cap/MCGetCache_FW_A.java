/*     */ package mcframe.serverCore.requester.cap;
/*     */ 
/*     */ import mcframe.commonCore.container.MCContainer;
/*     */ import mcframe.commonCore.param.MCOperationInfo;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.serverCore.logic.MCLogic;
/*     */ import mcframe.serverCore.logic.MCLogicUtil;
/*     */ import mcframe.serverCore.requester.decorator.DecR;
/*     */ import mcframe.serverCore.requester.decorator.MCDecorator;
/*     */ import mcframe.serverCore.requester.decorator.MCDecorator_FW;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MCGetCache_FW_A
/*     */   extends MCDecorator
/*     */ {
/*     */   public static final String MODULE_ID = "FC";
/*     */   public static final String SUBMODULE_ID = "FCBG";
/*     */   public static final String LOGIC_ID = "FCBGL1000";
/*     */   protected MCGetCache_FW.GetCache aGetCache;
/*     */   
/*     */   public String getModuleID() {
/*  42 */     return "FC";
/*     */   } public String getSubmoduleID() {
/*  44 */     return "FCBG";
/*     */   } public String getLogicID() {
/*  46 */     return "FCBGL1000";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initGetCache() {
/*  53 */     this.info = PDef.FC_FCBGL1000_GetCache_INFO;
/*  54 */     ((MCGetCache)this).getClass(); this.aGetCache = new MCGetCache_FW.GetCache((MCGetCache)this);
/*     */   }
/*     */   
/*     */   public static MCGetCache_FW.GetCache crtGetCache() {
/*  58 */     MCGetCache lgc = new MCGetCache();
/*  59 */     lgc.initGetCache();
/*  60 */     return lgc.aGetCache;
/*     */   }
/*     */   
/*     */   protected void paramGetCache(MCParam p) {
/*  64 */     if (this.aGetCache == null) {
/*     */       return;
/*     */     }
/*  67 */     p.setDef(this.info.def);
/*  68 */     p.addUpBlock((MCContainer)this.aGetCache.up0());
/*  69 */     p.addUpBlock((MCContainer)this.aGetCache.up1());
/*  70 */     p.addDownBlock((MCContainer)this.aGetCache.down0());
/*     */   }
/*     */   
/*     */   protected void doGetCache() {
/*  74 */     this.aGetCache.call();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DecR createDecR() {
/*  83 */     return DecR.create();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CacheR createCacheR() {
/*  92 */     return CacheR.create();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract class GetCache
/*     */     extends MCDecorator_FW.Decorate
/*     */   {
/*     */     public static final String OPERATION_ID = "GetCache";
/*     */ 
/*     */     
/*     */     private final DecR up0;
/*     */ 
/*     */     
/*     */     private final CacheR up1;
/*     */ 
/*     */     
/*     */     private final DecR down0;
/*     */ 
/*     */     
/*     */     public String getOperationID() {
/* 113 */       return "GetCache";
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected GetCache() {
/* 125 */       super((MCDecorator_FW)MCGetCache_FW_A.this);
/*     */ 
/*     */       
/* 128 */       this.up0 = DecR.create();
/* 129 */       this.up1 = CacheR.create();
/* 130 */       this.down0 = DecR.create();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void mapUpContainers(String key) {
/* 144 */       super.mapUpContainers(key);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void mapDownContainers(String key) {
/* 152 */       super.mapDownContainers(key);
/*     */     }
/*     */     
/*     */     public MCContainer up(int i) {
/* 156 */       if (i == 0) return (MCContainer)up0(); 
/* 157 */       if (i == 1) return (MCContainer)up1(); 
/* 158 */       return null;
/*     */     }
/*     */     
/*     */     public MCContainer down(int i) {
/* 162 */       if (i == 0) return (MCContainer)down0(); 
/* 163 */       return null;
/*     */     }
/*     */     
/*     */     public void exec() {
/* 167 */       clear();
/* 168 */       MCLogicUtil.invoke((MCLogic)MCGetCache_FW_A.this);
/*     */     }
/*     */     
/*     */     protected void clear() {
/* 172 */       down0().clear();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DecR createDecR() {
/* 180 */       return DecR.create();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CacheR createCacheR() {
/* 189 */       return CacheR.create();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DecR up0() {
/* 205 */       return this.up0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CacheR up1() {
/* 220 */       return this.up1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DecR down0() {
/* 236 */       return this.down0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MCOperationInfo getOperationInfo() {
/* 243 */       return MCGetCache_FW_A.this.info;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\cap\MCGetCache_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */