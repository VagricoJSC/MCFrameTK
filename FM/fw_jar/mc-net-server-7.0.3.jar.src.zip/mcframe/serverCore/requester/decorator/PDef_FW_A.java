/*    */ package mcframe.serverCore.requester.decorator;
/*    */ 
/*    */ import mcframe.commonCore.param.MCContainerDef;
/*    */ import mcframe.commonCore.param.MCDef;
/*    */ import mcframe.commonCore.param.MCOperationInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PDef_FW_A
/*    */   extends MCDef
/*    */ {
/*    */   public MCContainerDef getCustomDef(String id) {
/* 22 */     if (id == null) {
/* 23 */       return null;
/*    */     }
/*    */ 
/*    */ 
/*    */     
/* 28 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 34 */   static final MCOperationInfo FC_FCBGL0800_Decorate_INFO = new MCOperationInfo("FC", "FCBGL0800", "Decorate", "000000", new PDef());
/*    */   
/* 36 */   static final MCOperationInfo FC_FCBGL0800_P01_INFO = new MCOperationInfo("FC", "FCBGL0800", "P01", "000000", new PDef());
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\decorator\PDef_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */