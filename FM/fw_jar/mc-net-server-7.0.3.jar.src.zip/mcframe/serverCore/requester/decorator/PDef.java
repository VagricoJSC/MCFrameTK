package mcframe.serverCore.requester.decorator;

import mcframe.commonCore.annotation.EI;

@EI
public class PDef extends PDef_FW_A {}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\decorator\PDef.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */