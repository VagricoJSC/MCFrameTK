/*     */ package mcframe.serverCore.requester.decorator;
/*     */ 
/*     */ import java.io.StringWriter;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.param.MCDPWriter;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.commonCore.param.MCUploadFileParam;
/*     */ import mcframe.commonCore.pio.MCDPReaderFactory;
/*     */ import mcframe.commonCore.pio.MCT2PHeaderReader;
/*     */ import mcframe.commonCore.pio.util.MCDPFormat;
/*     */ import mcframe.commonCore.pio.util.MCDPToken;
/*     */ import mcframe.serverCore.mcjdbc.MCTransactionManager;
/*     */ import mcframe.serverCore.requester.MCDispatcherContext;
/*     */ import mcframe.serverCore.requester.MCRequestHandler;
/*     */ import mcframe.serverCore.requester.MCRequestStatus;
/*     */ import mcframe.serverCore.requester.MCRequestStatusImpl;
/*     */ import mcframe.serverCore.requester.MCServerRequester;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MCDecorator_FW
/*     */   extends MCDecorator_FW_A
/*     */ {
/*  43 */   protected MCRequestHandler hndl = new MCRequestHandler();
/*  44 */   protected InfoLogger logger = new InfoLogger();
/*     */   
/*  46 */   protected MCUploadFileParam _upfiles = null;
/*     */   
/*     */   public void init(MCParam param) {
/*  49 */     super.init(param);
/*  50 */     this._upfiles = param.getUploadFileParam();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class Decorate
/*     */     extends MCDecorator_FW_A.Decorate
/*     */   {
/*     */     protected String decoratedUp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void call() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected String callDecorate(String up) {
/*  85 */       MCDecorator_FW.this.logger.writeStartLog();
/*     */       
/*  87 */       this.decoratedUp = decorateUp(up);
/*     */       
/*  89 */       MCDispatcherContext ctx = parseUpHdr(this.decoratedUp);
/*     */       
/*  91 */       StringWriter sw = new StringWriter(1024);
/*  92 */       MCDPWriter dwdpw = new MCDPWriter(sw, true);
/*  93 */       dwdpw.setOperationID(ctx.param().getModuleId(), ctx.param().getLogicId(), ctx
/*  94 */           .param().getOperationId());
/*  95 */       dwdpw.setDumpId(MCDecorator_FW.this.logger.downId());
/*  96 */       ctx.setDwDPW(dwdpw);
/*  97 */       setRequestStatus(ctx, dwdpw);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 103 */         decorateUpHdr(ctx);
/*     */       }
/* 105 */       catch (Throwable t) {
/* 106 */         ctx.getRequestStatus().initerror();
/* 107 */         throw t;
/*     */       } 
/*     */       
/* 110 */       decorate(ctx);
/*     */ 
/*     */       
/* 113 */       String down = sw.toString();
/*     */       
/* 115 */       down = decorateDown(down);
/*     */ 
/*     */ 
/*     */       
/* 119 */       MCDecorator_FW.this.logger.writeEndLog();
/*     */       
/* 121 */       return down;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected String decorateUp(String up) {
/* 134 */       return up;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected MCDispatcherContext parseUpHdr(String up) {
/* 147 */       if (up == null) {
/* 148 */         return null;
/*     */       }
/* 150 */       MCParam p = MCDecorator_FW.this.hndl.crtServPrm();
/*     */       
/* 152 */       MCDPToken tkn = MCDPToken.create(up);
/* 153 */       MCDPFormat fmt = tkn.getFormat();
/* 154 */       MCT2PHeaderReader hr = MCDPReaderFactory.upHeaderToParam(fmt);
/* 155 */       hr.parse(tkn, p);
/* 156 */       MCDispatcherContext ctx = MCDecorator_FW.this.hndl.crtNewDispatcherContext(p);
/*     */       
/* 158 */       ctx.setUpDPT(tkn);
/* 159 */       return ctx;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void setRequestStatus(MCDispatcherContext ctx, MCDPWriter dwdpw) {
/* 172 */       ctx.setRequestStatus((MCRequestStatus)new MCRequestStatusImpl(ctx.param(), dwdpw));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void decorateUpHdr(MCDispatcherContext ctx) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void decorate(MCDispatcherContext ctx) {
/* 195 */       PrivateRequester req = new PrivateRequester(null);
/* 196 */       req.ctx = ctx;
/*     */       
/* 198 */       ctx.param().getUploadFileParam().addAll(MCDecorator_FW.this._upfiles);
/*     */       
/* 200 */       req.up = this.decoratedUp;
/* 201 */       req.start();
/*     */       try {
/* 203 */         req.join();
/*     */         
/* 205 */         if (req.err != null) {
/* 206 */           throw req.err;
/*     */         }
/*     */       }
/* 209 */       catch (Throwable e) {
/* 210 */         MCLog.write(e);
/* 211 */         if (e instanceof Error) {
/* 212 */           throw (Error)e;
/*     */         }
/* 214 */         throw new MCException(e);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private class PrivateRequester
/*     */       extends Thread
/*     */     {
/*     */       MCDispatcherContext ctx;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       String up;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 244 */       Throwable err = null;
/*     */ 
/*     */       
/*     */       public void run() {
/*     */         try {
/* 249 */           (MCDecorator_FW.Decorate.access$0(MCDecorator_FW.Decorate.this)).hndl.initRequestObject(this.ctx);
/*     */           
/* 251 */           (MCDecorator_FW.Decorate.access$0(MCDecorator_FW.Decorate.this)).logger.writeUpLog(this.ctx, this.up);
/* 252 */           (MCDecorator_FW.Decorate.access$0(MCDecorator_FW.Decorate.this)).hndl.dispatch(this.ctx);
/*     */         }
/* 254 */         catch (Throwable t) {
/* 255 */           this.err = t;
/*     */         } 
/*     */         
/*     */         try {
/* 259 */           (MCDecorator_FW.Decorate.access$0(MCDecorator_FW.Decorate.this)).hndl.destroy();
/*     */ 
/*     */           
/* 262 */           MCTransactionManager.finalClose();
/*     */         
/*     */         }
/* 265 */         catch (Throwable t) {
/* 266 */           if (this.err == null) {
/* 267 */             this.err = t;
/*     */           } else {
/*     */             
/* 270 */             MCLog.write(t);
/*     */           } 
/*     */         } 
/*     */         
/* 274 */         MCLog.write(Core_Msg_FW_A.FCBGC0150, new Object[] { "MCDecorator_FW.PrivateRequester finally done." });
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       private PrivateRequester() {}
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected String decorateDown(String down) {
/* 318 */       return down;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class P01
/*     */     extends MCDecorator_FW_A.P01
/*     */   {
/*     */     protected void call() {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static class InfoLogger
/*     */     extends MCServerRequester.UserInfoLogger
/*     */   {
/*     */     protected String startId() {
/* 347 */       return Core_Msg_FW_A.FCBGC0385;
/*     */     }
/*     */ 
/*     */     
/*     */     protected String endId() {
/* 352 */       return Core_Msg_FW_A.FCBGC0386;
/*     */     }
/*     */ 
/*     */     
/*     */     protected String upId() {
/* 357 */       return Core_Msg_FW_A.FCBGC0387;
/*     */     }
/*     */ 
/*     */     
/*     */     protected String downId() {
/* 362 */       return Core_Msg_FW_A.FCBGC0388;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\decorator\MCDecorator_FW.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */