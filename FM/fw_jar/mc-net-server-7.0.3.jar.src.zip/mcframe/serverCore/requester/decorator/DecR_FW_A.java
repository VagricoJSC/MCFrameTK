/*     */ package mcframe.serverCore.requester.decorator;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.commonCore.container.MCConstRow;
/*     */ import mcframe.commonCore.container.MCExtMap;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class DecR_FW_A
/*     */   extends MCConstRow
/*     */ {
/*     */   public static final String $denbun = "denbun";
/*  31 */   public static final MCMeta denbun_META = createStringMeta("denbun");
/*     */   
/*  33 */   protected static final MCRow.ConstMetaList<DecR> constMetas = new MCRow.ConstMetaList(
/*  34 */       MCConstRow.constMetas, 
/*  35 */       new MCMeta[] {
/*  36 */         denbun_META
/*     */       },
/*  38 */       new String[][] { {}, {} });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   protected static final MCExtMap EXTMAP = new MCExtMap(
/*  51 */       null, new MCExtMap.Entry[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] colnames() {
/*  63 */     return constMetas.toNameArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMeta[] colmetas() {
/*  75 */     return constMetas.toMetaArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   private static final int offset = constMetas.offset();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getExtMap(String aGroup) {
/*  87 */     if (aGroup == null) return null; 
/*  88 */     return (Map<String, String>)EXTMAP.get(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getKeys(String aGroup) {
/*  95 */     if (aGroup == null) return null; 
/*  96 */     return EXTMAP.getKeyList(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExtGroups() {
/* 103 */     Set<String> ret = EXTMAP.keySet();
/* 104 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DecR_FW_A(MCRow.ConstMetaList<? extends DecR> metas) {
/* 111 */     super(metas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DecR clone() {
/* 118 */     return (DecR)super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DecR createInstance() {
/* 125 */     return (DecR)super.createInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DecR getValues(String... names) {
/* 132 */     return (DecR)super.getValues(names);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireValueChanged(String column, Comparable<?> newvalue, Comparable<?> oldvalue) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String denbun() {
/* 144 */     return getConstString(offset + 0, "denbun");
/*     */   }
/*     */   
/*     */   public void denbun(String value) {
/* 148 */     setConstString(offset + 0, "denbun", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString(String name) {
/* 153 */     if ("denbun".equalsIgnoreCase(name)) {
/* 154 */       return denbun();
/*     */     }
/* 156 */     return super.getString(name);
/*     */   }
/*     */   
/*     */   public String getStringNE(String name) {
/* 160 */     if ("denbun".equalsIgnoreCase(name)) {
/* 161 */       return denbun();
/*     */     }
/* 163 */     return super.getStringNE(name);
/*     */   }
/*     */   
/*     */   public void setString(String name, String value) {
/* 167 */     if ("denbun".equalsIgnoreCase(name)) {
/* 168 */       denbun(value);
/*     */       return;
/*     */     } 
/* 171 */     super.setString(name, value);
/*     */   }
/*     */   
/*     */   public void setStringNE(String name, String value) {
/* 175 */     if ("denbun".equalsIgnoreCase(name)) {
/* 176 */       denbun(value);
/*     */       return;
/*     */     } 
/* 179 */     super.setStringNE(name, value);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\decorator\DecR_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */