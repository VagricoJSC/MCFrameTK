/*     */ package mcframe.serverCore.requester.decorator;
/*     */ 
/*     */ import mcframe.commonCore.container.MCContainer;
/*     */ import mcframe.commonCore.param.MCOperationInfo;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.serverCore.logic.MCLogic;
/*     */ import mcframe.serverCore.logic.MCLogicBase;
/*     */ import mcframe.serverCore.logic.MCLogicUtil;
/*     */ import mcframe.serverCore.logic.MCOperation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MCDecorator_FW_A
/*     */   extends MCLogicBase
/*     */ {
/*     */   public static final String MODULE_ID = "FC";
/*     */   public static final String SUBMODULE_ID = "FCBG";
/*     */   public static final String LOGIC_ID = "FCBGL0800";
/*     */   protected MCDecorator_FW.Decorate aDecorate;
/*     */   protected MCDecorator_FW.P01 aP01;
/*     */   
/*     */   public String getModuleID() {
/*  42 */     return "FC";
/*     */   } public String getSubmoduleID() {
/*  44 */     return "FCBG";
/*     */   } public String getLogicID() {
/*  46 */     return "FCBGL0800";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initDecorate() {
/*  53 */     this.info = PDef.FC_FCBGL0800_Decorate_INFO;
/*  54 */     ((MCDecorator)this).getClass(); this.aDecorate = new MCDecorator_FW.Decorate((MCDecorator)this);
/*     */   }
/*     */   
/*     */   public static MCDecorator_FW.Decorate crtDecorate() {
/*  58 */     MCDecorator lgc = new MCDecorator();
/*  59 */     lgc.initDecorate();
/*  60 */     return lgc.aDecorate;
/*     */   }
/*     */   
/*     */   protected void paramDecorate(MCParam p) {
/*  64 */     if (this.aDecorate == null) {
/*     */       return;
/*     */     }
/*  67 */     p.setDef(this.info.def);
/*     */   }
/*     */   
/*     */   protected void doDecorate() {
/*  71 */     this.aDecorate.call();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initP01() {
/*  76 */     this.info = PDef.FC_FCBGL0800_P01_INFO;
/*  77 */     ((MCDecorator)this).getClass(); this.aP01 = new MCDecorator_FW.P01((MCDecorator)this);
/*     */   }
/*     */   
/*     */   public static MCDecorator_FW.P01 crtP01() {
/*  81 */     MCDecorator lgc = new MCDecorator();
/*  82 */     lgc.initP01();
/*  83 */     return lgc.aP01;
/*     */   }
/*     */   
/*     */   protected void paramP01(MCParam p) {
/*  87 */     if (this.aP01 == null) {
/*     */       return;
/*     */     }
/*  90 */     p.setDef(this.info.def);
/*     */   }
/*     */   
/*     */   protected void doP01() {
/*  94 */     this.aP01.call();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DecR createDecR() {
/* 103 */     return DecR.create();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract class Decorate
/*     */     extends MCOperation
/*     */   {
/*     */     public static final String OPERATION_ID = "Decorate";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getOperationID() {
/* 124 */       return "Decorate";
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void mapUpContainers(String key) {
/* 146 */       super.mapUpContainers(key);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void mapDownContainers(String key) {
/* 154 */       super.mapDownContainers(key);
/*     */     }
/*     */     
/*     */     public MCContainer up(int i) {
/* 158 */       return null;
/*     */     }
/*     */     
/*     */     public MCContainer down(int i) {
/* 162 */       return null;
/*     */     }
/*     */     
/*     */     public void exec() {
/* 166 */       clear();
/* 167 */       MCLogicUtil.invoke((MCLogic)MCDecorator_FW_A.this);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void clear() {}
/*     */ 
/*     */ 
/*     */     
/*     */     public MCOperationInfo getOperationInfo() {
/* 178 */       return MCDecorator_FW_A.this.info;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract class P01
/*     */     extends MCOperation
/*     */   {
/*     */     public static final String OPERATION_ID = "P01";
/*     */ 
/*     */ 
/*     */     
/*     */     private final DecR aDec;
/*     */ 
/*     */ 
/*     */     
/*     */     public String getOperationID() {
/* 197 */       return "P01";
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected P01() {
/* 208 */       this.aDec = DecR.create();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void mapUpContainers(String key) {
/* 222 */       super.mapUpContainers(key);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void mapDownContainers(String key) {
/* 230 */       super.mapDownContainers(key);
/*     */     }
/*     */     
/*     */     public MCContainer up(int i) {
/* 234 */       return null;
/*     */     }
/*     */     
/*     */     public MCContainer down(int i) {
/* 238 */       return null;
/*     */     }
/*     */     
/*     */     public void exec() {
/* 242 */       clear();
/* 243 */       MCLogicUtil.invoke((MCLogic)MCDecorator_FW_A.this);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void clear() {}
/*     */ 
/*     */ 
/*     */     
/*     */     public DecR createDecR() {
/* 254 */       return DecR.create();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public DecR Dec() {
/* 266 */       return this.aDec;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public MCOperationInfo getOperationInfo() {
/* 272 */       return MCDecorator_FW_A.this.info;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\decorator\MCDecorator_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */