/*    */ package mcframe.serverCore.requester.decorator;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import mcframe.commonCore.annotation.EI;
/*    */ import mcframe.commonCore.container.MCRow;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @EI
/*    */ public class DecR
/*    */   extends DecR_FW_A
/*    */ {
/*    */   public static DecR create() {
/* 43 */     DecR row = new DecR(constMetas);
/* 44 */     return row;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static <T extends MCRow> DecR createByName(T proto) {
/* 54 */     DecR row = create();
/* 55 */     copyByName((MCRow)row, (MCRow)proto);
/* 56 */     return row;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DecR(MCRow.ConstMetaList<? extends DecR> metas) {
/* 63 */     super(metas);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\decorator\DecR.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */