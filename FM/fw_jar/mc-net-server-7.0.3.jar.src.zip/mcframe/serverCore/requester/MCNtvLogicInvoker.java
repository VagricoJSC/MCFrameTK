/*     */ package mcframe.serverCore.requester;
/*     */ 
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.param.MCOperationInfo;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.commonCore.pio.MCDPReaderFactory;
/*     */ import mcframe.commonCore.pio.MCP2THeaderReader;
/*     */ import mcframe.commonCore.pio.util.MCDPToken;
/*     */ import mcframe.commonCore.pio.util.MCDPTokenMCDP;
/*     */ import mcframe.serverCore.logic.MCLogic;
/*     */ import mcframe.serverCore.logic.MCNtvLogic;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCNtvLogicInvoker
/*     */   extends MCLogicInvoker
/*     */ {
/*     */   public void invoke(MCDispatcherContext ctx) {
/* 478 */     MCLog.write(Core_Msg_FW_A.FCBGC0304, new Object[] { ctx.param().getModuleId(), 
/* 479 */           ctx.param().getLogicId(), 
/* 480 */           ctx.param().getOperationId(), 
/* 481 */           ctx.param().getVersion() });
/*     */ 
/*     */     
/*     */     try {
/* 485 */       MCNtvLogic lgc = new MCNtvLogic(ctx.param());
/*     */ 
/*     */       
/* 488 */       parseUp(ctx, lgc);
/*     */ 
/*     */       
/* 491 */       doLogicPhase(ctx, (MCLogic)lgc);
/*     */ 
/*     */       
/* 494 */       parseDown(ctx, lgc);
/*     */     }
/*     */     finally {
/*     */       
/* 498 */       MCLog.write(Core_Msg_FW_A.FCBGC0305, new Object[] {
/* 499 */             ctx.param().getModuleId(), 
/* 500 */             ctx.param().getLogicId(), 
/* 501 */             ctx.param().getOperationId(), 
/* 502 */             ctx.param().getVersion()
/*     */           });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void parseUp(MCDispatcherContext ctx, MCNtvLogic lgc) {
/* 517 */     chkOpeVer(ctx.param(), (MCLogic)lgc);
/*     */ 
/*     */     
/* 520 */     String path = MCRequesterUtil.uploadPath();
/* 521 */     ctx.param().getUploadFileParam().setResponseFilePath(path);
/*     */ 
/*     */     
/* 524 */     MCDPTokenMCDP tkn = (MCDPTokenMCDP)ctx.getUpDPT();
/* 525 */     lgc.setUpDP(tkn.toStringNext());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void invokeOpe(MCLogic lgc, MCParam p) {
/* 530 */     MCNtvLogic nlgc = (MCNtvLogic)lgc;
/* 531 */     MCOperationInfo info = nlgc.info();
/*     */     
/* 533 */     nlgc.init(p);
/*     */     
/* 535 */     MCLog.write(Core_Msg_FW_A.FCBGC0382, new Object[] { info.moduleId, info.logicId, info.operationId, 
/* 536 */           nlgc.getServiceName(), nlgc.getUpDP() });
/* 537 */     int ret = nlgc.invoke();
/* 538 */     MCLog.write(Core_Msg_FW_A.FCBGC0383, new Object[] { info.moduleId, info.logicId, info.operationId, 
/* 539 */           nlgc.getServiceName(), String.valueOf(ret), nlgc.getDwDP() });
/*     */     
/* 541 */     nlgc.destroy();
/*     */ 
/*     */     
/* 544 */     if (ret == -1 || nlgc.getDwDP() == null) {
/* 545 */       throw new MCException(Core_Msg_FW_A.FCBGC0384, new Object[] {
/* 546 */             info.moduleId, info.logicId, info.operationId, 
/* 547 */             nlgc.getServiceName()
/*     */           });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void parseDown(MCDispatcherContext ctx, MCNtvLogic lgc) {
/* 561 */     String dwBody = lgc.getDwDP();
/* 562 */     boolean hasErr = false;
/*     */     
/* 564 */     MCDPTokenMCDP tkn = (MCDPTokenMCDP)MCDPToken.create(dwBody);
/*     */ 
/*     */     
/* 567 */     while (tkn.hasNext()) {
/* 568 */       if (tkn.nextTokenIsTag()) {
/* 569 */         if (tkn.nextToken().startsWith("<ERROR>")) {
/* 570 */           hasErr = true;
/*     */           break;
/*     */         } 
/*     */         continue;
/*     */       } 
/* 575 */       tkn.nextTokenNE();
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 581 */     MCP2THeaderReader dRdrH = MCDPReaderFactory.downHeaderToText(tkn.getFormat());
/* 582 */     dRdrH.read(ctx.param(), ctx.getDwDPW());
/* 583 */     ctx.getDwDPW().write(dwBody);
/* 584 */     ctx.setErr(hasErr);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\MCNtvLogicInvoker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */