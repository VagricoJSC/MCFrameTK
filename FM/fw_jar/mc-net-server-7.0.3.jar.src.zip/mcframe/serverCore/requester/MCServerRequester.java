/*     */ package mcframe.serverCore.requester;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.StringWriter;
/*     */ import mcframe.commonCore.container.MCVolumeManager;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.param.MCDPWriter;
/*     */ import mcframe.commonCore.param.MCDownloadStream;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.commonCore.param.MCParamFileUtil;
/*     */ import mcframe.commonCore.param.MCUploadFileParam;
/*     */ import mcframe.commonCore.pio.MCDPReaderFactory;
/*     */ import mcframe.commonCore.pio.MCP2TBodyReader;
/*     */ import mcframe.commonCore.pio.MCP2THeaderReader;
/*     */ import mcframe.commonCore.pio.MCT2PHeaderReader;
/*     */ import mcframe.commonCore.pio.util.MCDPFormat;
/*     */ import mcframe.commonCore.pio.util.MCDPToken;
/*     */ import mcframe.commonCore.pio.util.MCParseTypeUtil;
/*     */ import mcframe.commonCore.requester.MCControlRequester;
/*     */ import mcframe.commonCore.requester.MCDownloadUtil;
/*     */ import mcframe.commonCore.util.MCFileUtil;
/*     */ import mcframe.serverCore.mcjdbc.MCTransactionManager;
/*     */ import mcframe.serverCore.sys.MCSys;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCServerRequester
/*     */   extends MCControlRequester
/*     */ {
/*  47 */   protected static Throwable INI_ERR = null;
/*     */ 
/*     */   
/*     */   private String up_dp;
/*     */ 
/*     */   
/*     */   private MCUploadFileParam up_f;
/*     */ 
/*     */   
/*     */   static {
/*     */     try {
/*  58 */       MCSys.init();
/*  59 */       MCLog.write(Core_Msg_FW_A.FCBGC0218, new Object[0]);
/*     */ 
/*     */     
/*     */     }
/*  63 */     catch (Throwable e) {
/*  64 */       INI_ERR = e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void initFor3Tier(String servletName) {
/*  82 */     if (INI_ERR == null) {
/*     */       try {
/*  84 */         MCClusterManager.getManager().entryServer(servletName);
/*     */       }
/*  86 */       catch (Throwable e) {
/*  87 */         INI_ERR = e;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*  92 */     confirmInit();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void confirmInit() {
/* 107 */     if (INI_ERR != null) {
/* 108 */       throw new MCException(INI_ERR, Core_Msg_FW_A.FCBGC0044, new Object[0]);
/*     */     }
/*     */ 
/*     */     
/* 112 */     syncMCSysTime();
/*     */     
/* 114 */     MCLog.write(Core_Msg_FW_A.FCBGC0220, new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 143 */   private MCDPWriter dw_dpw = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private InfoLogger ilog;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private UserInfoLogger uilog;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCDispatcherContext ctx;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCRequestHandler hndl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String request(String id, String up, MCUploadFileParam p_up_f) {
/* 198 */     if (p_up_f != null) {
/*     */       
/* 200 */       int upfsize = p_up_f.requestSize();
/* 201 */       if (upfsize > 0) {
/* 202 */         String[][] reqs = p_up_f.toRequestArrays();
/* 203 */         for (int i = 0; i < upfsize; i++) {
/* 204 */           p_up_f.addResponseFile(reqs[0][i], new File(reqs[1][i]));
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 209 */       MCLog.write(Core_Msg_FW_A.FCBGC0349, new Object[] { p_up_f.toString() });
/*     */     } 
/*     */     
/* 212 */     return srvRequest(up, p_up_f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String batchRequest(String id, String up) {
/* 229 */     return request(id, up, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected File download(String up, File dir, String name) {
/* 249 */     File file = null;
/*     */     
/* 251 */     MCDownloadStream[] down = srvDownload(up);
/* 252 */     for (int i = 0, len = down.length; i < len; i++) {
/* 253 */       MCDownloadStream in = down[i];
/*     */       try {
/* 255 */         if (i == 0) {
/* 256 */           file = MCDownloadUtil.saveFile(in, dir, name);
/*     */         }
/*     */       } finally {
/*     */         
/* 260 */         if (in != null) {
/*     */           try {
/* 262 */             in.close();
/*     */           }
/* 264 */           catch (IOException ex) {
/*     */             
/* 266 */             MCLog.write(ex);
/*     */           } 
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 272 */         MCTransactionManager.finalClose();
/* 273 */         MCTransactionManager.finalClose();
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 278 */     return file;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String srvRequest(String up, MCUploadFileParam p_up_f) {
/* 299 */     StringWriter sw = new StringWriter(1024);
/* 300 */     srvRequest(new MCDPWriter(sw, true), up, p_up_f);
/* 301 */     return sw.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void srvRequest(MCDPWriter writer, String up, MCUploadFileParam p_up_f) {
/* 319 */     srvRequest(writer, up, p_up_f, MCDPFormat.MCDP);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCDownloadStream[] srvDownload(String p_up_dp) {
/*     */     try {
/* 344 */       init(new MCDPWriter(null, true), p_up_dp, null);
/*     */     }
/* 346 */     catch (Throwable t) {
/* 347 */       MCLog.write(t);
/* 348 */       return doEnd4Dl(true);
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 353 */       crtCtx();
/*     */ 
/*     */ 
/*     */       
/* 357 */       doRequest();
/*     */     }
/* 359 */     catch (Throwable t) {
/*     */       
/* 361 */       MCLog.write(t);
/* 362 */       return doEnd4Dl(true);
/*     */     } 
/*     */ 
/*     */     
/* 366 */     return doEnd4Dl(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void srvSmart(MCDPWriter writer, String up, MCUploadFileParam p_up_f) {
/* 383 */     srvRequest(writer, up, p_up_f, MCDPFormat.JSON);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String srvSmart(String up, MCUploadFileParam p_up_f) {
/* 398 */     StringWriter sw = new StringWriter(1024);
/* 399 */     srvSmart(new MCDPWriter(sw, true), up, p_up_f);
/* 400 */     return sw.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void srvRequest(MCDPWriter writer, String up, MCUploadFileParam p_up_f, MCDPFormat format) {
/*     */     try {
/* 424 */       init(writer, up, p_up_f);
/*     */     }
/* 426 */     catch (Throwable t) {
/* 427 */       MCLog.write(t);
/*     */ 
/*     */       
/* 430 */       MCDPToken tkn = MCDPToken.create(up);
/* 431 */       writer.write(MCRequesterUtil.createInitExceptionText(t, tkn.getFormat()));
/* 432 */       doEnd(t);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*     */     try {
/* 438 */       crtCtx();
/*     */     }
/* 440 */     catch (Throwable t) {
/* 441 */       MCLog.write(t);
/*     */ 
/*     */       
/* 444 */       MCDPToken tkn = MCDPToken.create(up);
/* 445 */       writer.write(MCRequesterUtil.createInitExceptionText(t, tkn.getFormat()));
/* 446 */       if (this.ctx != null && this.ctx.getRequestStatus() != null) {
/* 447 */         this.ctx.getRequestStatus().initerror();
/*     */       }
/* 449 */       doEnd(t);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 454 */     if (this.ctx.getUpDPT().getFormat() != format) {
/* 455 */       MCDPFormat upformat = this.ctx.getUpDPT().getFormat();
/* 456 */       MCException e = new MCException(Core_Msg_FW_A.FCBGC1201, new Object[] { format, upformat });
/* 457 */       writer.write(MCRequesterUtil.createInitExceptionText((Throwable)e, upformat));
/* 458 */       this.ctx.getRequestStatus().initerror();
/* 459 */       MCLog.write((Throwable)e);
/* 460 */       doEnd((Throwable)e);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 465 */     if (format == MCDPFormat.MCDP) {
/*     */       try {
/* 467 */         checkApplicationVersion();
/*     */       }
/* 469 */       catch (Throwable t) {
/* 470 */         this.ctx.getRequestStatus().initerror();
/* 471 */         MCLog.write(t);
/* 472 */         doEnd(t);
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */     }
/*     */     
/*     */     try {
/* 480 */       doRequest();
/*     */     }
/* 482 */     catch (Throwable t) {
/*     */ 
/*     */ 
/*     */       
/* 486 */       MCLog.write(t);
/* 487 */       this.ctx.getRequestStatus().syserror();
/* 488 */       doEnd(t);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 493 */     doEnd((Throwable)this.ctx.param().getExceptionParam().getException());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void syncMCSysTime() {
/* 504 */     MCTransactionManager.syncMCSysTime();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean init(MCDPWriter pw, String up_dp, MCUploadFileParam up_f) {
/* 524 */     this.ilog = new InfoLogger(null);
/* 525 */     this.uilog = new UserInfoLogger();
/* 526 */     confirmInit();
/* 527 */     this.up_dp = up_dp;
/* 528 */     this.up_f = up_f;
/*     */     
/* 530 */     this.dw_dpw = pw;
/* 531 */     this.hndl = new MCRequestHandler();
/* 532 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean crtCtx() {
/* 546 */     MCParam p_srv = this.hndl.crtServPrm();
/*     */ 
/*     */ 
/*     */     
/* 550 */     p_srv.getUploadFileParam().addAll(this.up_f);
/* 551 */     MCDPToken tkn = MCDPToken.create(this.up_dp);
/* 552 */     MCDPFormat fmt = tkn.getFormat();
/* 553 */     MCLog.write(Core_Msg_FW_A.FCBGC0223, new Object[0]);
/* 554 */     MCT2PHeaderReader uRdrH = MCDPReaderFactory.upHeaderToParam(fmt);
/* 555 */     uRdrH.parse(tkn, p_srv);
/* 556 */     MCLog.write(Core_Msg_FW_A.FCBGC0224, new Object[0]);
/*     */ 
/*     */     
/* 559 */     this.ctx = this.hndl.crtDispatcherContext(p_srv);
/*     */     
/* 561 */     this.ctx.setUpDPT(tkn);
/*     */     
/* 563 */     this.dw_dpw.setOperationID(this.ctx.param().getModuleId(), this.ctx.param().getLogicId(), this.ctx
/* 564 */         .param().getOperationId());
/* 565 */     this.ctx.setDwDPW(this.dw_dpw);
/* 566 */     this.ctx.setRequestStatus(new MCRequestStatusImpl(this.ctx.param(), this.dw_dpw));
/* 567 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkApplicationVersion() {
/* 583 */     String sysid = this.ctx.param().getSystemId();
/* 584 */     String appver = this.ctx.param().getApplicationVersion();
/* 585 */     String appbld = this.ctx.param().getApplicationBuild();
/*     */     
/* 587 */     if (sysid == null && appver == null && appbld == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 592 */     if (!MCStringUtil.eq(sysid, MCSys.catalog.systemid()) || 
/* 593 */       !MCStringUtil.eq(appver, MCSys.catalog.version()) || 
/* 594 */       !MCStringUtil.eq(appbld, MCSys.catalog.build())) {
/*     */ 
/*     */       
/* 597 */       MCException e = new MCException(Core_Msg_FW_A.FCBGC0458, new Object[] { sysid, appver, appbld, 
/* 598 */             MCSys.catalog.systemid(), MCSys.catalog.version(), MCSys.catalog.build() });
/*     */       
/* 600 */       MCException me = MCRequesterUtil.convertDispatcherExecuteException((Throwable)e);
/* 601 */       this.ctx.param().getExceptionParam().setException(me);
/*     */ 
/*     */ 
/*     */       
/* 605 */       MCDPFormat fmt = this.ctx.getUpDPT().getFormat();
/* 606 */       MCP2THeaderReader dRdrH = MCDPReaderFactory.downHeaderToText(fmt);
/* 607 */       dRdrH.read(this.ctx.param(), this.ctx.getDwDPW());
/* 608 */       MCP2TBodyReader dRdrB = MCDPReaderFactory.downBodyToText(fmt, 
/* 609 */           MCParseTypeUtil.getParseType(this.ctx.param()));
/* 610 */       dRdrB.read(this.ctx.param(), this.ctx.getDwDPW());
/* 611 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void doRequest() {
/* 625 */     this.ilog.writeStartLog();
/* 626 */     this.ilog.writeAccessUsertLog();
/*     */     try {
/* 628 */       this.hndl.initRequestObject(this.ctx);
/*     */     }
/* 630 */     catch (Throwable t) {
/*     */ 
/*     */       
/* 633 */       this.ctx.getDwDPW().write(
/* 634 */           MCRequesterUtil.createExceptionText(t, this.ctx.getUpDPT().getFormat()));
/* 635 */       throw t;
/*     */     } 
/*     */     
/* 638 */     this.uilog.writeStartLog();
/* 639 */     this.uilog.writeAccessUsertLog();
/* 640 */     this.uilog.writeUpLog(this.ctx, this.up_dp);
/* 641 */     this.hndl.dispatch(this.ctx);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCDownloadStream[] doEnd4Dl(boolean hasErr) {
/*     */     try {
/* 657 */       this.uilog.writeEndLog();
/*     */       
/* 659 */       this.hndl.destroy();
/* 660 */       this.ilog.writeEndLog();
/* 661 */       if (hasErr || this.ctx.hasErr())
/*     */       {
/* 663 */         throw new MCException(Core_Msg_FW_A.FCBGC0086, new Object[0]);
/*     */       }
/*     */       
/* 666 */       return this.ctx.param().getDownloadStreamParam().toArray();
/*     */     
/*     */     }
/* 669 */     catch (Throwable t) {
/* 670 */       MCLog.write(t);
/*     */ 
/*     */ 
/*     */       
/* 674 */       MCTransactionManager.finalClose();
/* 675 */       MCTransactionManager.finalClose();
/*     */ 
/*     */       
/* 678 */       throw new MCException(t, Core_Msg_FW_A.FCBGC0033, new Object[0]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void doEnd(Throwable th) {
/*     */     try {
/* 694 */       if (this.uilog != null)
/*     */       {
/*     */         
/* 697 */         this.uilog.writeEndLog();
/*     */       }
/*     */       
/* 700 */       if (this.hndl != null) {
/* 701 */         this.hndl.destroy();
/*     */       }
/*     */       
/* 704 */       if (this.ilog != null) {
/* 705 */         this.ilog.writeEndLog();
/*     */       }
/*     */     }
/* 708 */     catch (Throwable t) {
/* 709 */       MCLog.write(t);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 714 */     MCTransactionManager.finalClose();
/* 715 */     MCTransactionManager.finalClose();
/*     */ 
/*     */     
/* 718 */     this.ctx = null;
/* 719 */     MCVolumeManager.doGC(th);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class InfoLogger
/*     */   {
/*     */     private InfoLogger() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void writeStartLog() {
/* 738 */       if (MCServerRequester.this.ctx != null) {
/* 739 */         MCLog.write(Core_Msg_FW_A.FCBGC0340, new Object[] { MCServerRequester.access$0(this.this$0).param().getServerRequestNo(), MCServerRequester.access$0(this.this$0).param()
/* 740 */               .getServerId() });
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void writeAccessUsertLog() {
/* 751 */       if (MCServerRequester.this.ctx != null) {
/* 752 */         MCLog.write(Core_Msg_FW_A.FCBGC0341, new Object[] { MCServerRequester.access$0(this.this$0).param().getUserId(), MCServerRequester.access$0(this.this$0).param()
/* 753 */               .getLoginSequence(), null, null, null, MCServerRequester.access$0(this.this$0).param().getClientId(), 
/* 754 */               MCServerRequester.access$0(this.this$0).param().getClientRequestNo() });
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void writeEndLog() {
/* 765 */       if (MCServerRequester.this.ctx != null) {
/* 766 */         MCLog.write(Core_Msg_FW_A.FCBGC0342, new Object[] { MCServerRequester.access$0(this.this$0).param().getServerRequestNo(), MCServerRequester.access$0(this.this$0).param()
/* 767 */               .getServerId() });
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class UserInfoLogger
/*     */   {
/*     */     private final String NA = "N/A";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public UserInfoLogger() {
/* 787 */       this.NA = "N/A";
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected String startId() {
/* 797 */       return Core_Msg_FW_A.FCBGC0343;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected String endId() {
/* 808 */       return Core_Msg_FW_A.FCBGC0344;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected String upId() {
/* 819 */       return Core_Msg_FW_A.FCBGC0234;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected String downId() {
/* 830 */       return Core_Msg_FW_A.FCBGC0235;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected String accessUserId() {
/* 841 */       return Core_Msg_FW_A.FCBGC0341;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void writeStartLog() {
/* 851 */       MCLog.write(startId(), new Object[0]);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void writeUpLog(MCDispatcherContext ctx, String up_dp) {
/* 866 */       if (ctx == null) {
/* 867 */         MCLog.write(upId(), new Object[] { "N/A", "N/A", "N/A", up_dp });
/*     */       } else {
/*     */         
/* 870 */         MCLog.write(upId(), new Object[] { ctx.param().getModuleId(), ctx.param().getLogicId(), 
/* 871 */               ctx.param().getOperationId(), up_dp });
/* 872 */         if (ctx.isSaveStatus()) {
/* 873 */           MCFileUtil.writeText(up_dp, MCParamFileUtil.getUpParamFile(), 
/* 874 */               "UTF-8");
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void writeAccessUsertLog() {
/* 886 */       MCLog.write(accessUserId(), new Object[] { MCSys.user.ID(), MCSys.user.loginSequence(), 
/* 887 */             MCSys.user.coCD(), MCSys.user.extattr1(), MCSys.user.extattr2(), 
/* 888 */             MCSys.user.extattr3(), MCSys.request.clientId(), 
/* 889 */             MCSys.request.clientRequestNo() });
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void writeDwLog(MCDispatcherContext ctx, String dw_dp) {
/* 908 */       if (ctx == null) {
/* 909 */         MCLog.write(downId(), new Object[] { "N/A", "N/A", "N/A", dw_dp });
/*     */       } else {
/*     */         
/* 912 */         MCLog.write(downId(), new Object[] { ctx.param().getModuleId(), 
/* 913 */               ctx.param().getLogicId(), ctx.param().getOperationId(), dw_dp });
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void writeEndLog() {
/* 924 */       MCLog.write(endId(), new Object[0]);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\MCServerRequester.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */