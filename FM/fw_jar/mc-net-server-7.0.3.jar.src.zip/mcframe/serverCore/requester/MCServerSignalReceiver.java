package mcframe.serverCore.requester;

interface MCServerSignalReceiver {
  void exec(String paramString);
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\MCServerSignalReceiver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */