/*     */ package mcframe.serverCore.requester;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.Proxy;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import mcframe.commonCore.net.MCNetConsts;
/*     */ import mcframe.commonCore.net.MCPostMethodSimple;
/*     */ import mcframe.commonCore.net.MCSimpleClient;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.serverCore.resource.MCConfig;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCSimpleRequester
/*     */ {
/*  39 */   private long _limitbyte = -1L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   private int _retry = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   private int _timeout = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   private Proxy _proxy = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  67 */   private LinkedHashMap<String, String> _header = new LinkedHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   private String _encode = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean _ignoreCertification = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   private String _method = "POST";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   private int _responseCode = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, List<String>> _responseHeader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCSimpleRequester() {
/* 114 */     loadConfig(null);
/* 115 */     initHeader();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCSimpleRequester(String requestId) {
/* 130 */     loadConfig(requestId);
/* 131 */     initHeader();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCSimpleRequester setRetry(int retry) {
/* 144 */     this._retry = retry;
/* 145 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCSimpleRequester setTimeout(int timeout) {
/* 158 */     this._timeout = timeout;
/* 159 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCSimpleRequester setHeader(String key, String value) {
/* 173 */     this._header.put(key, value);
/* 174 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCSimpleRequester addHeaders(LinkedHashMap<String, String> headers) {
/* 187 */     this._header.putAll(headers);
/* 188 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCSimpleRequester setMethod(String method) {
/* 201 */     this._method = method;
/* 202 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCSimpleRequester setEncode(String encode) {
/* 216 */     this._encode = encode;
/* 217 */     if (this._encode == null) {
/* 218 */       this._header.remove("Accept-Encoding");
/*     */     } else {
/*     */       
/* 221 */       this._header.put("Accept-Encoding", this._encode);
/*     */     } 
/* 223 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setContentType(String type) {
/* 235 */     if (type != null) {
/* 236 */       this._header.put("Content-Type", type);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCSimpleRequester initHeader() {
/* 251 */     this._header.clear();
/*     */     
/* 253 */     this._header.put("User-Agent", MCNetConsts.USER_AGENT);
/* 254 */     setContentType("application/json");
/* 255 */     if (this._encode != null) {
/* 256 */       this._header.put("Accept-Encoding", this._encode);
/*     */     }
/* 258 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCSimpleRequester clearHeader() {
/* 269 */     this._header.clear();
/* 270 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCSimpleRequester loadConfig(String requestId) {
/* 286 */     if (requestId != null) {
/* 287 */       this._limitbyte = MCConfig.server.getInteger(
/* 288 */           "net.request." + requestId + ".limitSize", 
/* 289 */           MCConfig.server.getInteger("net.request.limitSize", -1));
/* 290 */       this._retry = MCConfig.server.getInteger("net.request." + requestId + ".retry", 
/* 291 */           MCConfig.server.getInteger("net.request.retry", -1));
/* 292 */       this._timeout = MCConfig.server.getInteger(
/* 293 */           "net.request." + requestId + ".receive_timeout", 
/* 294 */           MCConfig.server.getInteger("net.request.receive_timeout", -1));
/* 295 */       this._encode = MCConfig.common.getString("http.accept." + requestId + ".encode", 
/* 296 */           MCConfig.common.getString("http.accept.encode"), null);
/* 297 */       this._ignoreCertification = MCConfig.server.getBoolean(
/* 298 */           "net.request." + requestId + ".java.ignoreCertification", 
/* 299 */           MCConfig.server.getBoolean("net.request.java.ignoreCertification", 
/* 300 */             false));
/*     */     } else {
/*     */       
/* 303 */       this._limitbyte = MCConfig.server.getInteger("net.request.limitSize", -1);
/* 304 */       this._retry = MCConfig.server.getInteger("net.request.retry", -1);
/* 305 */       this._timeout = MCConfig.server.getInteger("net.request.receive_timeout", -1);
/* 306 */       this._encode = MCConfig.common.getString("http.accept.encode", null);
/* 307 */       this._ignoreCertification = MCConfig.server
/* 308 */         .getBoolean("net.request.java.ignoreCertification", false);
/*     */     } 
/*     */     
/* 311 */     if (this._encode != null) {
/* 312 */       this._header.put("Accept-Encoding", this._encode);
/*     */     }
/*     */     
/* 315 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getResponseCode() {
/* 327 */     return this._responseCode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String request(String url, String up) {
/* 347 */     this._responseCode = -1;
/*     */     
/* 349 */     return httpRequest(url, up, this._method);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String request(String url, String up, String contenType) {
/* 369 */     setContentType(contenType);
/* 370 */     return request(url, up);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String request(String url) {
/* 388 */     this._responseCode = -1;
/*     */     
/* 390 */     return httpRequest(url, null, "GET");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String request(String url, MCSimpleMultiPartParam up) {
/* 409 */     this._responseCode = -1;
/*     */     
/* 411 */     return httpRequest(url, up);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String httpRequest(String url, String up, String reqMethod) {
/* 432 */     MCPostMethodSimple method = createPostMethod(url, reqMethod);
/*     */     
/* 434 */     MCSimpleClient client = createHttpClient(up, method);
/*     */     
/* 436 */     this._responseCode = client.executeMethod(method);
/* 437 */     this._responseHeader = client.getHeaderFields();
/* 438 */     checkHTTPStatus(this._responseCode, url);
/* 439 */     return method.getResponseBodyAsString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String httpRequest(String url, MCSimpleMultiPartParam up) {
/* 457 */     setContentType("multipart/form-data; boundary=--------MCFRAMEBOUNDARY");
/*     */     
/* 459 */     MCPostMethodSimple method = createPostMethod(url, "POST");
/*     */     
/* 461 */     MCSimpleClient client = createHttpClient(up, method);
/*     */     
/* 463 */     this._responseCode = client.executeMethod(method);
/* 464 */     this._responseHeader = client.getHeaderFields();
/* 465 */     checkHTTPStatus(this._responseCode, url);
/* 466 */     return method.getResponseBodyAsString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, List<String>> getResponseHeader() {
/* 478 */     return this._responseHeader;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkHTTPStatus(int responseCode, String url) {
/* 494 */     if (responseCode >= 400) {
/*     */       
/* 496 */       if (responseCode <= 499)
/*     */       {
/* 498 */         throw new MCException(Core_Msg_FW_A.FCBGC1104, new Object[] { "HTTP " + responseCode, url });
/*     */       }
/* 500 */       if (responseCode <= 599)
/*     */       {
/* 502 */         throw new MCException(Core_Msg_FW_A.FCBGC1103, new Object[] { Integer.valueOf(responseCode), url });
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCSimpleClient createHttpClient(final String up, MCPostMethodSimple method) {
/* 518 */     MCSimpleClient http = new MCSimpleClient()
/*     */       {
/*     */         protected final void createHeader(HttpURLConnection conn)
/*     */         {
/* 522 */           MCSimpleRequester.this._header.entrySet().forEach(s -> param1HttpURLConnection.setRequestProperty(s.getKey(), s.getValue()));
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         protected final void writeData(OutputStream out) throws IOException {
/* 530 */           writeData(out, up);
/*     */         }
/*     */       };
/* 533 */     http.setLimitResponseByte(this._limitbyte);
/* 534 */     http.setRetry(this._retry);
/* 535 */     http.setTimeout(this._timeout);
/* 536 */     return http;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCSimpleClient createHttpClient(final MCSimpleMultiPartParam up, MCPostMethodSimple method) {
/* 551 */     MCSimpleClient http = new MCSimpleClient()
/*     */       {
/*     */         protected final void createHeader(HttpURLConnection conn)
/*     */         {
/* 555 */           MCSimpleRequester.this._header.entrySet().forEach(s -> param1HttpURLConnection.setRequestProperty(s.getKey(), s.getValue()));
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         protected final void writeData(OutputStream out) throws IOException {
/* 563 */           for (null = up.getStringDisposition().iterator(); null.hasNext(); ) { MCSimpleMultiPartParam.MCStringDisposition d = null.next();
/*     */             
/* 565 */             writeData(out, "--");
/* 566 */             writeData(out, "--------MCFRAMEBOUNDARY");
/* 567 */             writeData(out, "\r\n");
/*     */             
/* 569 */             writeData(out, "Content-Disposition: form-data; name=\"");
/* 570 */             writeData(out, d.getName());
/* 571 */             writeData(out, "\"");
/* 572 */             writeData(out, "\r\n");
/* 573 */             d.getContentType().ifPresent(s -> {
/*     */                   try {
/*     */                     writeData(param1OutputStream, "Content-Type: ");
/*     */                     
/*     */                     writeData(param1OutputStream, s);
/*     */                     writeData(param1OutputStream, "\r\n");
/* 579 */                   } catch (IOException e) {
/*     */                     expCommunication(e, msgRequestError());
/*     */                   } 
/*     */                 });
/*     */ 
/*     */             
/* 585 */             writeData(out, "\r\n");
/* 586 */             writeData(out, d.getValue());
/*     */             
/* 588 */             writeData(out, "\r\n"); }
/*     */           
/* 590 */           for (MCSimpleMultiPartParam.MCFileDisposition d : up.getFileDisposition()) {
/*     */ 
/*     */             
/* 593 */             writeData(out, "--");
/* 594 */             writeData(out, "--------MCFRAMEBOUNDARY");
/* 595 */             writeData(out, "\r\n");
/*     */             
/* 597 */             writeData(out, "Content-Disposition: form-data; name=\"");
/* 598 */             writeData(out, d.getName());
/* 599 */             writeData(out, "\"; filename=\"");
/* 600 */             writeData(out, d.getFilename());
/* 601 */             writeData(out, "\"");
/* 602 */             writeData(out, "\r\n");
/* 603 */             writeData(out, "Content-Type: ");
/* 604 */             writeData(out, d.getContentType());
/* 605 */             writeData(out, "\r\n");
/*     */ 
/*     */             
/* 608 */             writeData(out, "\r\n");
/* 609 */             writeData(out, d.getFile());
/* 610 */             writeData(out, "\r\n");
/*     */           } 
/* 612 */           writeData(out, "--");
/* 613 */           writeData(out, "--------MCFRAMEBOUNDARY");
/* 614 */           writeData(out, "--");
/* 615 */           writeData(out, "\r\n");
/*     */         }
/*     */       };
/* 618 */     http.setLimitResponseByte(this._limitbyte);
/* 619 */     http.setRetry(this._retry);
/* 620 */     http.setTimeout(this._timeout);
/* 621 */     return http;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCPostMethodSimple createPostMethod(String url, String reqMethod) {
/* 634 */     MCPostMethodSimple method = new MCPostMethodSimple(url);
/* 635 */     method.setIgnoreCertification(this._ignoreCertification);
/* 636 */     method.setMethodType(reqMethod);
/* 637 */     method.setProxy(this._proxy);
/* 638 */     return method;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\MCSimpleRequester.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */