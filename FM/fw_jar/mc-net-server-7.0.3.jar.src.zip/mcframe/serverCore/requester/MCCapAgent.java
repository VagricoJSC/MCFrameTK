/*     */ package mcframe.serverCore.requester;
/*     */ 
/*     */ import java.util.List;
/*     */ import mcframe.commonCore.container.MCContainer;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.login.MCAuth;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.notice.MCMessage;
/*     */ import mcframe.commonCore.notice.MCMessageList;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.commonCore.pio.MCDPReaderFactory;
/*     */ import mcframe.commonCore.pio.MCP2TBodyReader;
/*     */ import mcframe.commonCore.pio.MCP2THeaderReader;
/*     */ import mcframe.commonCore.pio.util.MCDPFormat;
/*     */ import mcframe.commonCore.pio.util.MCParseTypeUtil;
/*     */ import mcframe.commonCore.requester.MCFile;
/*     */ import mcframe.serverCore.notice.MCMessagePool;
/*     */ import mcframe.serverCore.resource.MCConfig;
/*     */ import mcframe.serverCore.sys.MCSys;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCCapAgent
/*     */ {
/*     */   private static final String MODULE = "FC";
/*     */   private static final String LOGIC_MENU = "FCBAL0010";
/*     */   private int c_cap;
/*     */   private int s_cap;
/*     */   private MCParam p;
/*     */   private MCMessageList msglist;
/*     */   
/*     */   public static boolean capacityCheckParam(MCParam param) {
/*  43 */     return !(MCAuth.isLoginOperation(param) || MCAuth.isLogoutOperation(param) || 
/*  44 */       MCAuth.isACLOperation(param) || MCAuth.isResourceOperation(param) || 
/*  45 */       isMenuOperation(param));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isMenuOperation(MCParam param) {
/*  80 */     return isMenuOperation(param.getModuleId(), param.getLogicId(), 
/*  81 */         param.getOperationId());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isMenuOperation(String mid, String lid, String oid) {
/*  95 */     return (MCStringUtil.eq(mid, "FC") && MCStringUtil.eq(lid, "FCBAL0010"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCCapAgent(MCParam p) {
/* 147 */     this(p, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCCapAgent(MCParam p, MCMessageList msglist) {
/* 160 */     this.c_cap = (p.getLimitDLSize() != null) ? p.getLimitDLSize().intValue() : -1;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 166 */       this.s_cap = MCConfig.server.getInteger("http.response.limitSize", -1);
/*     */     }
/* 168 */     catch (MCException mCException) {
/* 169 */       this.s_cap = -1;
/*     */     } 
/*     */     
/* 172 */     this.p = p;
/*     */     
/* 174 */     this.msglist = (msglist == null) ? MCMessagePool.getMessageList() : msglist;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void parse() {
/* 206 */     if (!this.p.getExceptionParam().isEmpty()) {
/*     */       return;
/*     */     }
/*     */     
/* 210 */     MCLog.write(Core_Msg_FW_A.FCBGC0238, new Object[] { String.valueOf(this.c_cap), String.valueOf(this.s_cap) });
/*     */     
/* 212 */     Counter cnt = count();
/*     */ 
/*     */     
/* 215 */     parseSCap(cnt);
/*     */ 
/*     */     
/* 218 */     parseCCap(cnt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void parseSCap(Counter cnt) {
/* 232 */     if (this.s_cap < 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 237 */     if (this.s_cap < cnt.rslt) {
/* 238 */       overSCap(this.s_cap, cnt.rslt);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseCCap(Counter cnt) {
/* 252 */     if (this.c_cap < 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 257 */     if (this.c_cap >= cnt.rslt) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 262 */     overCCap(cnt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Counter count() {
/* 274 */     Counter cnt = new Counter();
/* 275 */     cnt.count(this.p);
/*     */ 
/*     */     
/* 278 */     MCLog.write(Core_Msg_FW_A.FCBGC0239, new Object[] { Integer.toString(this.p.getContainerParam().down().size()), 
/* 279 */           Integer.toString(cnt.rNum), Integer.toString(cnt.dsNum), 
/* 280 */           Integer.toString(cnt.rslt) });
/* 281 */     return cnt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void overSCap(int _s_cap, int _sum) {
/* 294 */     throw new MCException(Core_Msg_FW_A.FCBGC0051, new Object[] { String.valueOf(_s_cap), String.valueOf(_sum) });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void overCCap(Counter cnt) {
/* 307 */     saveParam();
/* 308 */     registerCapNGMsg(this.c_cap, cnt.rslt);
/*     */     
/* 310 */     cnt.clearParam();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void registerCapNGMsg(int _c_cap, int _sum) {
/* 323 */     this.msglist.add(
/* 324 */         new MCMessage(Core_Msg_FW_A.FCBGC1000, new Object[] { String.valueOf(_c_cap), String.valueOf(_sum) }));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void saveParam() {
/* 335 */     MCDPFormat fmt = MCSys.request.dpFormat();
/* 336 */     MCP2THeaderReader hr = MCDPReaderFactory.downHeaderToText(fmt);
/* 337 */     String hdr = hr.parse(this.p);
/* 338 */     MCP2TBodyReader br = MCDPReaderFactory.downBodyToText(fmt, 
/* 339 */         MCParseTypeUtil.getParseType(this.p));
/* 340 */     String bdy = br.parse(this.p);
/* 341 */     saveDP(String.valueOf(hdr) + bdy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void saveDP(String dp) {
/* 352 */     MCFile f = new MCFile();
/*     */     
/* 354 */     String capDir = getCacheDir();
/* 355 */     String fName = getCacheFile();
/*     */     
/* 357 */     f.saveData(dp, capDir, fName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getCacheDir() {
/* 369 */     return MCConfig.server.getString("net.cap.dir");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCacheFile() {
/* 381 */     return String.valueOf(this.p.getClientRequestNo()) + "_" + this.p.getServerRequestNo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class Counter
/*     */   {
/* 430 */     int rslt = 0;
/* 431 */     int dsNum = 0;
/* 432 */     int rNum = 0;
/* 433 */     List<MCContainer> tar = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void count(MCParam p) {
/* 444 */       this.tar = p.getContainerParam().down();
/* 445 */       for (MCContainer c : this.tar) {
/* 446 */         if (c instanceof MCList) {
/* 447 */           this.dsNum++;
/* 448 */           this.rslt += ((MCList)c).size();
/*     */           continue;
/*     */         } 
/* 451 */         this.rNum++;
/* 452 */         this.rslt++;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     void clearParam() {
/* 458 */       for (MCContainer c : this.tar) {
/*     */         
/* 460 */         if (c instanceof MCList)
/* 461 */           c.clear(); 
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\MCCapAgent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */