/*    */ package mcframe.serverCore.requester;
/*    */ 
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ import mcframe.serverCore.mcjdbc.AbsMCPackageProxy;
/*    */ import mcframe.serverCore.mcjdbc.MCDBTransaction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MCLogicProxy
/*    */   extends AbsMCPackageProxy
/*    */ {
/* 31 */   public static final MCLogicProxy proxy = new MCLogicProxy();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void setDBConnectionInfo(MCDBTransaction tran) {
/* 44 */     super.setDBConnectionInfo(tran);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void setCoInfo() {
/* 49 */     super.setCoInfo();
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean getSqlTraceFlg() {
/* 54 */     return super.getSqlTraceFlg();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void setSqlTraceFlg(boolean value) {
/* 59 */     super.setSqlTraceFlg(value);
/*    */   }
/*    */ 
/*    */   
/*    */   protected List<MCDBTransaction> getDbTranPool() {
/* 64 */     return super.getDbTranPool();
/*    */   }
/*    */ 
/*    */   
/*    */   protected Set<MCDBTransaction> getBLOBPool() {
/* 69 */     return super.getBLOBPool();
/*    */   }
/*    */ 
/*    */   
/*    */   protected List<MCDBTransaction> getAutoCommitDbTranPool() {
/* 74 */     return super.getAutoCommitDbTranPool();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void setTRA_LSNR(boolean value) {
/* 80 */     super.setTRA_LSNR(value);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void startSQLTrace() {
/* 85 */     super.startSQLTrace();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void stopSQLTrace() {
/* 90 */     super.stopSQLTrace();
/*    */   }
/*    */ 
/*    */   
/*    */   protected MCDBTransaction createDBTran(boolean canCurrentTran, boolean pool) {
/* 95 */     return super.createDBTran(canCurrentTran, pool);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\MCLogicProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */