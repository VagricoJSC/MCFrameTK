/*     */ package mcframe.serverCore.requester;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import mcframe.commonCore.container.MCContainer;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.param.MCContainerDef;
/*     */ import mcframe.commonCore.param.MCDef;
/*     */ import mcframe.commonCore.param.MCItemDef;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.commonCore.pio.util.MCPioUtil;
/*     */ import mcframe.commonCore.resource.MCLabelConst;
/*     */ import mcframe.commonCore.resource.MCLocaleConst;
/*     */ import mcframe.serverCore.logic.MCLogicBase;
/*     */ import mcframe.serverCore.logic.MCOperation;
/*     */ import mcframe.serverCore.resource.MCConst;
/*     */ import mcframe.serverCore.sys.MCSys;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCLogicLabelUtil
/*     */ {
/*     */   public static String getLabel(Locale locale, MCRow row, String colName, boolean isUp) {
/*  46 */     if (row == null || MCStringUtil.isNull(colName)) {
/*  47 */       return null;
/*     */     }
/*  49 */     String lbl = getParamLabel(locale, row, colName, isUp);
/*  50 */     if (lbl == null) {
/*  51 */       lbl = getIDLabel(locale, row, colName, isUp);
/*     */     }
/*  53 */     return lbl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<String> getLabelList(Locale locale, MCRow row, List<String> colL, boolean isUp) {
/*  69 */     List<String> result = new ArrayList<>();
/*  70 */     for (int i = 0; i < colL.size(); i++) {
/*  71 */       result.add(null);
/*     */     }
/*  73 */     if (row != null) {
/*  74 */       addParamLabel(locale, row, colL, result, isUp);
/*  75 */       if (result.contains(null)) {
/*  76 */         addIDLabel(locale, row, colL, result, isUp);
/*     */       }
/*     */     } 
/*  79 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void addParamLabel(Locale locale, MCRow row, List<String> colL, List<String> labelL, boolean isUp) {
/*  95 */     if (row.getParamIndex() < 0) {
/*     */       return;
/*     */     }
/*     */     
/*  99 */     MCParam p = MCSys.request.ctx().param();
/* 100 */     if ((isUp && p.getContainerParam().up().size() <= row.getParamIndex()) || (
/* 101 */       !isUp && p.getContainerParam().down().size() <= row.getParamIndex())) {
/*     */       return;
/*     */     }
/*     */     
/* 105 */     MCDef def = p.getDef();
/* 106 */     String defid = MCDef.toDefId(p, isUp, row.getParamIndex());
/* 107 */     if (MCStringUtil.isNull(defid)) {
/*     */       return;
/*     */     }
/*     */     
/* 111 */     MCContainerDef cdef = def.getDefNE(defid);
/* 112 */     if (cdef == null || cdef.block() == null) {
/*     */       return;
/*     */     }
/*     */     
/* 116 */     MCLabelConst lblcnst = MCLocaleConst.label(locale, getPackages(cdef));
/*     */     
/* 118 */     MCContainer proto = isUp ? p.getContainerParam().getUpBlock(row.getParamIndex()) : 
/* 119 */       p.getContainerParam().getDownBlock(row.getParamIndex());
/* 120 */     MCItemDef[] items = MCPioUtil.transItems(p, defid, proto);
/*     */     
/* 122 */     for (int i = 0; i < colL.size(); i++) {
/* 123 */       String colName = colL.get(i);
/* 124 */       if (colName != null) {
/* 125 */         int pci = row.getParamColIndexNE(colName);
/* 126 */         String itm = null;
/* 127 */         if (pci >= 0 && 
/* 128 */           items.length > pci) {
/* 129 */           itm = (items[pci]).id;
/*     */         }
/*     */         
/* 132 */         if (MCStringUtil.isNull(itm)) {
/* 133 */           itm = colName;
/*     */         }
/* 135 */         labelL.set(i, getLabel(lblcnst, cdef, itm));
/*     */       } else {
/*     */         
/* 138 */         labelL.set(i, null);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void addIDLabel(Locale locale, MCRow row, List<String> colL, List<String> labelL, boolean isUp) {
/* 156 */     String id = MCSys.request.subId();
/* 157 */     if (!MCStringUtil.isNull(id)) {
/* 158 */       String[] idarray = MCStringUtil.split(".", id);
/* 159 */       MCOperation op = (MCOperation)MCLogicBase.createOperation(idarray[0], idarray[1], 
/* 160 */           idarray[2], MCOperation.class);
/* 161 */       int i = 0;
/*     */       while (true) {
/* 163 */         MCContainer cnt = isUp ? op.up(i) : op.down(i);
/* 164 */         if (cnt == null) {
/* 165 */           i = -1;
/*     */           break;
/*     */         } 
/* 168 */         if ((cnt instanceof MCRow) ? 
/* 169 */           cnt.getClass().equals(row.getClass()) : (
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 174 */           (MCList)cnt).createRow().getClass().equals(row.getClass())) {
/*     */           break;
/*     */         }
/*     */         
/* 178 */         i++;
/*     */       } 
/* 180 */       if (i != -1) {
/* 181 */         MCContainerDef cdef = (op.getOperationInfo()).def
/* 182 */           .getDefNE(MCDef.toDefId(id, isUp, i));
/* 183 */         MCLabelConst lblcnst = MCLocaleConst.label(locale, getPackages(cdef));
/* 184 */         for (int j = 0; j < colL.size(); j++) {
/* 185 */           if (labelL.get(j) == null) {
/* 186 */             labelL.set(j, getLabel(lblcnst, cdef, colL.get(j)));
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getLabel(Locale locale, MCRow row, String colName) {
/* 205 */     return getLabel(locale, row, colName, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getParamLabel(Locale locale, MCRow row, String colName, boolean isUp) {
/* 221 */     if (row.getParamIndex() < 0) {
/* 222 */       return null;
/*     */     }
/* 224 */     MCParam p = MCSys.request.ctx().param();
/* 225 */     if ((isUp && p.getContainerParam().up().size() <= row.getParamIndex()) || (
/* 226 */       !isUp && p.getContainerParam().down().size() <= row.getParamIndex())) {
/* 227 */       return null;
/*     */     }
/* 229 */     MCDef def = p.getDef();
/* 230 */     String defid = MCDef.toDefId(p, isUp, row.getParamIndex());
/* 231 */     if (MCStringUtil.isNull(defid)) {
/* 232 */       return null;
/*     */     }
/* 234 */     MCContainerDef cdef = def.getDefNE(defid);
/* 235 */     if (cdef == null || cdef.block() == null) {
/* 236 */       return null;
/*     */     }
/* 238 */     int pci = row.getParamColIndexNE(colName);
/* 239 */     String itm = null;
/* 240 */     if (pci >= 0) {
/* 241 */       MCContainer proto = isUp ? 
/* 242 */         p.getContainerParam().getUpBlock(row.getParamIndex()) : 
/* 243 */         p.getContainerParam().getDownBlock(row.getParamIndex());
/* 244 */       MCItemDef[] items = MCPioUtil.transItems(p, defid, proto);
/* 245 */       if (items.length > pci) {
/* 246 */         itm = (items[pci]).id;
/*     */       }
/*     */     } 
/* 249 */     if (MCStringUtil.isNull(itm)) {
/* 250 */       itm = colName;
/*     */     }
/* 252 */     return getParamLabel(locale, cdef, itm);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getParamLabel(Locale locale, MCContainerDef cdef, String itm) {
/* 266 */     MCLabelConst lblcnst = MCLocaleConst.label(locale, getPackages(cdef));
/* 267 */     return getLabel(lblcnst, cdef, itm);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getIDLabel(Locale locale, MCRow row, String colName, boolean isUp) {
/* 283 */     String id = MCSys.request.subId();
/* 284 */     if (MCStringUtil.isNull(id)) {
/* 285 */       return null;
/*     */     }
/* 287 */     String[] idarray = MCStringUtil.split(".", id);
/* 288 */     MCOperation op = (MCOperation)MCLogicBase.createOperation(idarray[0], idarray[1], idarray[2], 
/* 289 */         MCOperation.class);
/* 290 */     int i = 0;
/*     */     while (true) {
/* 292 */       MCContainer cnt = isUp ? op.up(i) : op.down(i);
/* 293 */       if (cnt == null) {
/* 294 */         i = -1;
/*     */         break;
/*     */       } 
/* 297 */       if ((cnt instanceof MCRow) ? 
/* 298 */         cnt.getClass().equals(row.getClass()) : (
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 303 */         (MCList)cnt).createRow().getClass().equals(row.getClass())) {
/*     */         break;
/*     */       }
/*     */       
/* 307 */       i++;
/*     */     } 
/* 309 */     if (i == -1) {
/* 310 */       return null;
/*     */     }
/* 312 */     MCContainerDef cdef = (op.getOperationInfo()).def
/* 313 */       .getDefNE(MCDef.toDefId(id, isUp, i));
/* 314 */     return getParamLabel(locale, cdef, colName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String[] getPackages(MCContainerDef cdef) {
/* 326 */     List<String> ret = new ArrayList<>();
/* 327 */     while (cdef != null) {
/* 328 */       String pkg = MCConst.operation.getPackage(cdef.moduleId(), cdef.logicId());
/* 329 */       if (!MCStringUtil.isNull(pkg)) {
/* 330 */         ret.add(pkg);
/*     */       }
/* 332 */       cdef = cdef.parent();
/*     */     } 
/* 334 */     return ret.<String>toArray(new String[ret.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getLabel(MCLabelConst lblcnst, MCContainerDef cdef, String itm) {
/* 349 */     if (cdef == null || cdef.block() == null) {
/* 350 */       return null;
/*     */     }
/* 352 */     String blk = (cdef.block()).id;
/* 353 */     String lbl = lblcnst.getLogicLabel(cdef.moduleId(), cdef.logicId(), 
/* 354 */         cdef.operationId(), blk, itm);
/* 355 */     if (MCStringUtil.isNull(lbl)) {
/* 356 */       return getLabel(lblcnst, cdef.parent(), itm);
/*     */     }
/* 358 */     return lbl;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\MCLogicLabelUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */