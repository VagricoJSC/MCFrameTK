package mcframe.serverCore.requester;

class DefaultServerSignalReceiver implements MCServerSignalReceiver {
  public void exec(String serverRequestNo) {}
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\DefaultServerSignalReceiver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */