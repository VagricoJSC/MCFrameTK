/*     */ package mcframe.serverCore.requester;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.notice.MCMessage;
/*     */ import mcframe.serverCore.dbc.CoreFunction;
/*     */ import mcframe.serverCore.dbc.FCT_SERVER_SIGNAL_R;
/*     */ import mcframe.serverCore.dbc.FCT_SRV_REQUEST_R;
/*     */ import mcframe.serverCore.mcjdbc.MCConnectionPool;
/*     */ import mcframe.serverCore.mcjdbc.MCDBTransaction;
/*     */ import mcframe.serverCore.mcjdbc.MCTransactionManager;
/*     */ import mcframe.serverCore.queryapi.IFMCFMSQL;
/*     */ import mcframe.serverCore.queryapi.IFMCSQL;
/*     */ import mcframe.serverCore.resource.MCConst;
/*     */ import mcframe.serverCore.sys.MCSys;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCServerSignalManagerImpl
/*     */   implements MCServerSignalManager
/*     */ {
/*  43 */   private static final ConcurrentHashMap<String, MCServerSignal> _reqList = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   private static final ConcurrentHashMap<String, Long> _reqCount = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   private static final ConcurrentHashMap<String, Long> _killCount = new ConcurrentHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   private static final boolean SERVERSIGNAL_MODE = MCConst.app.getBoolean(
/*  71 */       MCConst.createKey(new String[] { "serversignal", "valid" }, ), true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   private static final boolean SESSION_AUTOKILL = MCConst.app.getBoolean(
/*  83 */       MCConst.createKey(new String[] { "serversignal", "autokill", "valid" }, ), false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   private static final int SESSION_AUTOKILL_PERIOD = MCConst.app.getInteger(
/*  96 */       MCConst.createKey(new String[] { "serversignal", "autokill", "period" }, ), 5);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 104 */   private static final MCNumber CLEANUP_DAYS = MCConst.app.getNumber(
/* 105 */       MCConst.createKey(new String[] { "serversignal", "cleanupdays" }, ), MCNumber.valueOf(3));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 113 */   private static final int SERVERSIGNAL_MONITORING_INTERVAL = MCConst.app.getInteger(
/* 114 */       MCConst.createKey(new String[] { "serversignal", "monitoring", "interval" }, ), 3000);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 126 */   private static final int STATUS_CHECK_COUNT = MCConst.app.getInteger(
/* 127 */       MCConst.createKey(new String[] { "serversignal", "status", "checkcnt" }, ), 10);
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 132 */   private static IFMCSQL.MCDateTimeFmt[] DATETIMEFMT_FOR_CAST = new IFMCSQL.MCDateTimeFmt[] { IFMCSQL.MCDateTimeFmt.YYYY, IFMCSQL.MCDateTimeFmt.MM, IFMCSQL.MCDateTimeFmt.DD };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final IFMCSQL.MCMainQuery FCT_SERVER_SIGNAL_LOCK() {
/* 141 */     FCT_SERVER_SIGNAL_R S0 = FCT_SERVER_SIGNAL_R.create("T");
/* 142 */     return ((IFMCSQL.MCMainQuery)((IFMCSQL.MCMainQuery)((IFMCSQL.MCMainQuery)IFMCSQL.sql("FCT_SERVER_SIGNAL_LOCK")
/* 143 */       .mainQuery()
/* 144 */       .select(new IFMCFMSQL.MCFMEDColumnGroup[] { (IFMCFMSQL.MCFMEDColumnGroup)S0.srv_req_no
/* 145 */         }).from((IFMCSQL.MCDerivedView)S0))
/* 146 */       .where(
/* 147 */         IFMCSQL.trunc((IFMCFMSQL.MCFMAGDateExpr)CoreFunction.FCPA_DATE_UTIL$F_MCSYSDATE().subtractDays((IFMCFMSQL.MCFMAGNumberExpr)IFMCSQL.bind("days")), IFMCSQL.MCDateFmt.DD).gt(IFMCSQL.trunc((IFMCFMSQL.MCFMAGDateExpr)IFMCSQL.toDate((IFMCFMSQL.MCFMAGStringExpr)IFMCSQL.toChar((IFMCFMSQL.MCFMAGTimestampExpr)S0.ins_ts, DATETIMEFMT_FOR_CAST), DATETIMEFMT_FOR_CAST), IFMCSQL.MCDateFmt.DD))))
/*     */       
/* 149 */       .orderBy(new IFMCFMSQL.MCFMEDOrder[] { (IFMCFMSQL.MCFMEDOrder)S0.srv_req_no.asc()
/* 150 */         })).forUpdateNoWait(new IFMCFMSQL.MCFMAGPermColumn[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final IFMCSQL.MCDelete FCT_SERVER_SIGNAL_CLEAN() {
/* 160 */     FCT_SERVER_SIGNAL_R S0 = FCT_SERVER_SIGNAL_R.create("T");
/*     */     
/* 162 */     return IFMCSQL.sql("FCT_SERVER_SIGNAL_CLEAN")
/* 163 */       .delete((IFMCSQL.MCPermView)S0)
/* 164 */       .where(
/* 165 */         IFMCSQL.trunc((IFMCFMSQL.MCFMAGDateExpr)CoreFunction.FCPA_DATE_UTIL$F_MCSYSDATE().subtractDays((IFMCFMSQL.MCFMAGNumberExpr)IFMCSQL.bind("days")), IFMCSQL.MCDateFmt.DD).gt(IFMCSQL.trunc((IFMCFMSQL.MCFMAGDateExpr)IFMCSQL.toDate((IFMCFMSQL.MCFMAGStringExpr)IFMCSQL.toChar((IFMCFMSQL.MCFMAGTimestampExpr)S0.ins_ts, DATETIMEFMT_FOR_CAST), DATETIMEFMT_FOR_CAST), IFMCSQL.MCDateFmt.DD)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final IFMCSQL.MCMainQuery FCT_SRV_REQUEST_S01() {
/* 175 */     FCT_SRV_REQUEST_R S0 = FCT_SRV_REQUEST_R.create();
/*     */     
/* 177 */     return (IFMCSQL.MCMainQuery)((IFMCSQL.MCMainQuery)IFMCSQL.sql("FCT_SRV_REQUEST_S01")
/* 178 */       .mainQuery()
/* 179 */       .select(new IFMCFMSQL.MCFMEDColumnGroup[] {
/* 180 */           (IFMCFMSQL.MCFMEDColumnGroup)S0.user_id, 
/* 181 */           (IFMCFMSQL.MCFMEDColumnGroup)S0.co_cd, 
/* 182 */           (IFMCFMSQL.MCFMEDColumnGroup)S0.ext_attr1, 
/* 183 */           (IFMCFMSQL.MCFMEDColumnGroup)S0.ext_attr2, 
/* 184 */           (IFMCFMSQL.MCFMEDColumnGroup)S0.ext_attr3, 
/* 185 */           (IFMCFMSQL.MCFMEDColumnGroup)S0.c_req_no, 
/* 186 */           (IFMCFMSQL.MCFMEDColumnGroup)S0.c_req_ts, 
/* 187 */           (IFMCFMSQL.MCFMEDColumnGroup)S0.module_id, 
/* 188 */           (IFMCFMSQL.MCFMEDColumnGroup)S0.logic_id, 
/* 189 */           (IFMCFMSQL.MCFMEDColumnGroup)S0.ope_id
/*     */         
/* 191 */         }).from((IFMCSQL.MCDerivedView)S0))
/* 192 */       .where(
/* 193 */         S0.srv_req_no.eq(IFMCSQL.bind("srv_req_no")));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isSignalValid() {
/* 205 */     return SERVERSIGNAL_MODE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isAutoKillValid() {
/* 219 */     return SESSION_AUTOKILL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addServerRequest(String serverRequestNo) {
/* 231 */     if (!isSignalValid()) {
/*     */       return;
/*     */     }
/* 234 */     _reqList.put(serverRequestNo, MCServerSignal.RUNNING);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void stop(String serverRequestNo) {
/* 246 */     if (!isSignalValid()) {
/*     */       return;
/*     */     }
/* 249 */     MCServerSignal signal = _reqList.get(serverRequestNo);
/* 250 */     if (signal == null) {
/*     */       return;
/*     */     }
/*     */     
/* 254 */     if (signal != MCServerSignal.END)
/*     */     {
/* 256 */       _reqList.put(serverRequestNo, MCServerSignal.INTERRUPTED);
/*     */     }
/*     */ 
/*     */     
/* 260 */     MCRow r = MCRow.create();
/* 261 */     r.setStringNE("srv_req_no", serverRequestNo);
/*     */     
/* 263 */     MCDBTransaction t = null;
/*     */     try {
/* 265 */       t = MCTransactionManager.createDBTran(true);
/* 266 */       FCT_SERVER_SIGNAL_R S0 = FCT_SERVER_SIGNAL_R.create();
/*     */       
/* 268 */       IFMCSQL.sql("FC_MCServerSignalManagerImpl_stop")
/* 269 */         .delete((IFMCSQL.MCPermView)S0)
/* 270 */         .where(
/* 271 */           S0.srv_req_no.eq(IFMCSQL.bind("srv_req_no"))
/* 272 */           .and(S0.srv_signal_typ.eq(IFMCSQL.value("01"))))
/* 273 */         .executeUpdate(t, r, null);
/* 274 */       t.commit();
/*     */     }
/* 276 */     catch (MCException e) {
/* 277 */       MCLog.write((Throwable)e);
/*     */     } finally {
/*     */       
/* 280 */       if (t != null) {
/* 281 */         MCTransactionManager.releaseDBTran(t);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void delServerRequest(String serverRequestNo) {
/* 295 */     if (!isSignalValid()) {
/*     */       return;
/*     */     }
/* 298 */     _reqList.put(serverRequestNo, MCServerSignal.END);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void resumeServerRequest(String serverRequestNo) {
/* 310 */     if (!isSignalValid()) {
/*     */       return;
/*     */     }
/* 313 */     _reqList.put(serverRequestNo, MCServerSignal.INTERRUPTED);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void gc() {
/* 324 */     if (!isSignalValid()) {
/*     */       return;
/*     */     }
/* 327 */     for (Map.Entry<String, MCServerSignal> entry : _reqList.entrySet()) {
/* 328 */       String reqNo = entry.getKey();
/* 329 */       MCServerSignal signal = entry.getValue();
/*     */       
/* 331 */       if (signal == MCServerSignal.END) {
/* 332 */         Long cnt = Long.valueOf((_reqCount.get(reqNo) != null) ? ((Long)_reqCount.get(reqNo)).longValue() : 0L);
/*     */         
/* 334 */         if (cnt.longValue() > STATUS_CHECK_COUNT) {
/*     */           
/* 336 */           _reqList.remove(reqNo);
/* 337 */           _reqCount.remove(reqNo);
/*     */           continue;
/*     */         } 
/* 340 */         _reqCount.put(reqNo, Long.valueOf(cnt.longValue() + 1L));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void killSession() {
/* 356 */     if (!isSignalValid() || !isAutoKillValid()) {
/*     */       return;
/*     */     }
/* 359 */     for (Map.Entry<String, MCServerSignal> entry : _reqList.entrySet()) {
/* 360 */       String reqNo = entry.getKey();
/* 361 */       MCServerSignal signal = entry.getValue();
/*     */       
/* 363 */       if (signal == MCServerSignal.INTERRUPTED) {
/* 364 */         Long cnt = Long.valueOf((_killCount.get(reqNo) != null) ? ((Long)_killCount.get(reqNo)).longValue() : 0L);
/* 365 */         long waitingSec = cnt.longValue() * (
/* 366 */           SERVERSIGNAL_MONITORING_INTERVAL / 1000);
/*     */         
/* 368 */         if (waitingSec > (SESSION_AUTOKILL_PERIOD * 60)) {
/* 369 */           MCLog.write(Core_Msg_FW_A.FCBGC0163, new Object[] { Integer.valueOf(SESSION_AUTOKILL_PERIOD), reqNo });
/* 370 */           _killSession(reqNo);
/*     */ 
/*     */           
/* 373 */           delServerRequest(reqNo);
/* 374 */           _killCount.remove(reqNo);
/* 375 */           _killCount.remove(reqNo);
/*     */           continue;
/*     */         } 
/* 378 */         _killCount.put(reqNo, Long.valueOf(cnt.longValue() + 1L));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void _killSession(String reqNo) {
/* 385 */     MCRow bind = MCRow.create();
/* 386 */     bind.setStringNE("srv_req_no", reqNo);
/* 387 */     MCList<FCT_SRV_REQUEST_R> ls = MCList.create(FCT_SRV_REQUEST_R.class);
/*     */     
/* 389 */     MCDBTransaction t = null;
/*     */     try {
/* 391 */       t = MCTransactionManager.createDBTran(true);
/* 392 */       FCT_SRV_REQUEST_S01().executeQuery(t, bind, null, ls);
/*     */       
/* 394 */       for (FCT_SRV_REQUEST_R r : ls) {
/*     */         try {
/* 396 */           MCConnectionPool.sessionKill(r.user_id(), r.co_cd(), r.ext_attr1(), 
/* 397 */               r.ext_attr2(), r.ext_attr3(), r.c_req_no(), r.c_req_ts(), 
/* 398 */               r.module_id(), r.logic_id(), r.ope_id());
/* 399 */           MCTransactionManager.dbTran().commit();
/*     */         }
/* 401 */         catch (MCException mCException) {
/*     */           
/* 403 */           MCTransactionManager.dbTran().rollback();
/*     */         } 
/*     */       } 
/*     */     } finally {
/*     */       
/* 408 */       if (t != null) {
/* 409 */         MCTransactionManager.releaseDBTran(t);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void monitoring() {
/* 426 */     if (!isSignalValid()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 431 */     clearServerSignal();
/*     */ 
/*     */     
/* 434 */     Thread t = new Thread(new MCServerSignalMonitor(), "@@MCServerSignalMonitor");
/* 435 */     t.setDaemon(true);
/* 436 */     t.start();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void clearServerSignal() {
/* 447 */     if (!isSignalValid()) {
/*     */       return;
/*     */     }
/*     */     
/* 451 */     MCDBTransaction t = null;
/* 452 */     MCRow bindMap = MCRow.create();
/* 453 */     bindMap.setNumberNE("days", CLEANUP_DAYS);
/*     */     try {
/* 455 */       t = MCTransactionManager.dbTran();
/* 456 */       FCT_SERVER_SIGNAL_LOCK().executeQuery(t, bindMap, null, null);
/* 457 */       FCT_SERVER_SIGNAL_CLEAN().executeUpdate(t, bindMap, null);
/* 458 */       t.commit();
/*     */     }
/* 460 */     catch (MCException e) {
/*     */       
/* 462 */       MCLog.write((Throwable)new MCException((Throwable)e, Core_Msg_FW_A.FCBGC0159, new Object[0]));
/*     */     } finally {
/*     */       
/* 465 */       if (t != null) {
/* 466 */         MCTransactionManager.releaseDBTran(t);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInterrupted() {
/* 484 */     String n = MCSys.request.serverRequestNo();
/* 485 */     if (n == null) {
/* 486 */       return false;
/*     */     }
/* 488 */     if (MCServerSignal.INTERRUPTED == _reqList.get(n)) {
/* 489 */       delServerRequest(n);
/* 490 */       return true;
/*     */     } 
/* 492 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resume() {
/* 502 */     String n = MCSys.request.serverRequestNo();
/* 503 */     if (n == null) {
/*     */       return;
/*     */     }
/* 506 */     if (MCServerSignal.END == _reqList.get(n)) {
/* 507 */       resumeServerRequest(n);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCMessage getInterruptedMessage() {
/* 521 */     return new MCMessage(Core_Msg_FW_A.FCBGC0152, new Object[] { MCSys.request.serverRequestNo() });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCMessage getInterruptedMessage4GUI() {
/* 534 */     return new MCMessage(Core_Msg_FW_A.FCBGC0158, new Object[] { MCSys.request.serverRequestNo() });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class MCServerSignalMonitor
/*     */     implements Runnable
/*     */   {
/*     */     static final String NAME = "@@MCServerSignalMonitor";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void run() {
/*     */       try {
/* 566 */         MCRequestObject.init();
/*     */         while (true) {
/* 568 */           TimeUnit.MILLISECONDS.sleep(MCServerSignalManagerImpl.SERVERSIGNAL_MONITORING_INTERVAL);
/*     */           
/* 570 */           monitoringSignal();
/*     */           
/* 572 */           MCServerSignalManagerImpl.gc();
/*     */           
/* 574 */           MCServerSignalManagerImpl.killSession();
/*     */         }
/*     */       
/* 577 */       } catch (Throwable e) {
/* 578 */         MCLog.write((Throwable)new MCException(e, Core_Msg_FW_A.FCBGC0153, new Object[0]));
/*     */       } finally {
/*     */         
/* 581 */         MCTransactionManager.finalClose();
/* 582 */         MCRequestObject.destory();
/*     */         
/* 584 */         Thread t = new Thread(new MCServerSignalMonitor(), "@@MCServerSignalMonitor");
/* 585 */         t.setDaemon(true);
/* 586 */         t.start();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void monitoringSignal() {
/* 598 */       MCList<MCRow> list = MCList.create(MCRow.class);
/* 599 */       MCTransactionManager.dbTran().statement()._selectServerSignal(list);
/*     */       
/* 601 */       for (MCRow row : list) {
/* 602 */         String no = row.getStringNE("SRV_REQ_NO");
/* 603 */         MCServerSignal signal = MCServerSignal.signal(row
/* 604 */             .getStringNE("SRV_SIGNAL_TYP"));
/* 605 */         signal.receive(no);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\MCServerSignalManagerImpl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */