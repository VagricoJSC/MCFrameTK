/*     */ package mcframe.serverCore.requester;
/*     */ 
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.commonCore.pio.util.MCDataConverter4DP;
/*     */ import mcframe.serverCore.dbc.CoreFunction;
/*     */ import mcframe.serverCore.dbc.FCT_LOGIN_R;
/*     */ import mcframe.serverCore.mcjdbc.FWDBUtil;
/*     */ import mcframe.serverCore.mcjdbc.MCTransactionManager;
/*     */ import mcframe.serverCore.queryapi.IFMCFMSQL;
/*     */ import mcframe.serverCore.queryapi.IFMCSQL;
/*     */ import mcframe.serverCore.queryapi.MCDBContainer;
/*     */ import mcframe.serverCore.queryapi.MCQueryApiBuilder;
/*     */ import mcframe.serverCore.resource.MCConfig;
/*     */ import mcframe.serverCore.sys.MCSys;
/*     */ import mcframe.serverCore.util.MCDBUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCRequestHandler
/*     */ {
/*     */   private boolean ini_flg = false;
/*     */   
/*     */   public MCParam crtServPrm() {
/*  46 */     MCParam p = new MCParam();
/*  47 */     p.setServerId(MCConfig.server.getString("server.name"));
/*  48 */     p.setServerRequestNo(FWDBUtil.nextRoundReqNo());
/*  49 */     return p;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCDispatcherContext crtDispatcherContext(MCParam p) {
/*  61 */     return new MCDispatcherContext(p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCDispatcherContext crtNewDispatcherContext(MCParam p) {
/*  75 */     return new MCDispatcherContext(p, MCSys.request.ctx());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCDispatcherContext crtNewDispatcherContextforGpBatch(MCParam p) {
/*  90 */     MCDispatcherContext ctx = crtNewDispatcherContext(p);
/*  91 */     ctx.setInvokeType(MCInvokeType.GP_BATCH);
/*  92 */     return ctx;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initRequestObject(MCDispatcherContext ctx) {
/* 108 */     MCRequestObject.init();
/* 109 */     MCRequest.init(ctx);
/* 110 */     initUserName(ctx.param());
/* 111 */     MCUser.init(ctx.param());
/*     */ 
/*     */     
/* 114 */     setUserAttr();
/*     */ 
/*     */     
/* 117 */     MCLogicProxy.proxy.setCoInfo();
/*     */ 
/*     */     
/* 120 */     syncMCCoSysTime();
/*     */     
/* 122 */     this.ini_flg = true;
/* 123 */     MCLog.write(Core_Msg_FW_A.FCBGC0229, new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initUserName(MCParam p) {
/* 135 */     FCT_LOGIN_R loginR = FCT_LOGIN_R.create("T");
/* 136 */     MCQueryApiBuilder builder = MCQueryApiBuilder.create((MCDBContainer)loginR);
/* 137 */     builder.setSelect(new IFMCSQL.MCColumn[] { (IFMCSQL.MCColumn)loginR.user_nm });
/* 138 */     builder.setWhere(
/* 139 */         loginR.user_id.eq(IFMCSQL.bind("1"))
/* 140 */         .and(loginR.login_seq.eq(IFMCSQL.bind("2"))), new Comparable[] {
/* 141 */           p.getUserId(), 
/* 142 */           p.getLoginSequence()
/*     */         });
/* 144 */     MCDBUtil.dbSelect("FC_MCRequestHandler_initUserName", (MCRow)loginR, builder);
/* 145 */     p.setUserName(loginR.user_nm());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setUserAttr() {
/* 158 */     FCT_LOGIN_R loginR = FCT_LOGIN_R.create("T");
/* 159 */     MCQueryApiBuilder builder = MCQueryApiBuilder.create((MCDBContainer)loginR);
/* 160 */     builder.setWhere(
/* 161 */         loginR.user_id.eq(IFMCSQL.bind("1"))
/* 162 */         .and(loginR.login_seq.eq(IFMCSQL.bind("2"))), new Comparable[] {
/* 163 */           MCUser.getInstance().ID(), 
/* 164 */           MCUser.getInstance().loginSequence() });
/* 165 */     MCDBUtil.dbSelect("FC_MCRequestHandler_setUserAttr_FCT_LOGIN", (MCRow)loginR, builder);
/*     */ 
/*     */     
/* 168 */     MCRow bindR = MCRow.create();
/* 169 */     bindR.addStringColumn("co", loginR.co_cd());
/* 170 */     bindR.addStringColumn("locale", MCUser.getInstance().locale().toString());
/* 171 */     String coNm = MCDBUtil.execFuncString("FC_MCRequestHandler_setUserAttr_F_GET_CO_NM2", 
/* 172 */         CoreFunction.FCPA_CO$F_GET_CO_NM2((IFMCFMSQL.MCFMAGStringExpr)IFMCSQL.bind("co"), (IFMCFMSQL.MCFMAGStringExpr)IFMCSQL.bind("locale")), bindR);
/* 173 */     loginR.co_nm(coNm);
/*     */     
/* 175 */     MCUser.setLoginInfo((MCRow)loginR);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void syncMCCoSysTime() {
/* 185 */     MCTransactionManager.syncMCCoSysTime();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dispatch(MCDispatcherContext ctx) {
/* 200 */     if (!this.ini_flg) {
/*     */       return;
/*     */     }
/*     */     
/* 204 */     MCDispatcher dispatcher = new MCDispatcher(ctx);
/*     */     
/*     */     try {
/* 207 */       dispatcher.init();
/*     */     }
/* 209 */     catch (Throwable t) {
/* 210 */       MCLog.write(t);
/*     */ 
/*     */       
/* 213 */       ctx.getDwDPW().write(
/* 214 */           MCRequesterUtil.createExceptionText(t, ctx.getUpDPT().getFormat()));
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 219 */     dispatcher.execute();
/*     */ 
/*     */     
/*     */     try {
/* 223 */       dispatcher.destroy();
/*     */     }
/* 225 */     catch (Throwable t) {
/*     */ 
/*     */ 
/*     */       
/* 229 */       throw MCRequesterUtil.convertAfterOperationException(t);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void destroy() {
/* 245 */     if (this.ini_flg)
/*     */     {
/* 247 */       MCReportSpooler.removeSpool();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 254 */     removeThreadLocal();
/*     */ 
/*     */ 
/*     */     
/* 258 */     MCLog.write(Core_Msg_FW_A.FCBGC0230, new Object[0]);
/*     */     
/* 260 */     if (!this.ini_flg) {
/*     */       return;
/*     */     }
/* 263 */     MCTransactionManager.close();
/*     */ 
/*     */     
/* 266 */     this.ini_flg = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removeThreadLocal() {
/* 281 */     MCRequestObject.destory();
/* 282 */     MCDataConverter4DP.destroy();
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\MCRequestHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */