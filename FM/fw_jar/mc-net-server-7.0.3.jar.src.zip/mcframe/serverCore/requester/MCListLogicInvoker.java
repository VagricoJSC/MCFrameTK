/*    */ package mcframe.serverCore.requester;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCListLogicInvoker
/*    */   extends MCSimpleLogicInvoker
/*    */ {
/*    */   protected void checkOverCap(MCDispatcherContext ctx) {
/* 28 */     checkOverCapDefault(ctx);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\MCListLogicInvoker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */