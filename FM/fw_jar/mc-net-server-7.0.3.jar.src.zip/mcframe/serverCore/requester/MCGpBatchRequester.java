/*     */ package mcframe.serverCore.requester;
/*     */ 
/*     */ import java.io.StringWriter;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.param.MCDPWriter;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.commonCore.pio.MCDPReaderFactory;
/*     */ import mcframe.commonCore.pio.MCT2PHeaderReader;
/*     */ import mcframe.commonCore.pio.MCT2PMessageReader;
/*     */ import mcframe.commonCore.pio.util.MCDPFormat;
/*     */ import mcframe.commonCore.pio.util.MCDPToken;
/*     */ import mcframe.commonCore.pio.util.MCDPTokenMCDP;
/*     */ import mcframe.commonCore.sys.MCFactory;
/*     */ import mcframe.serverCore.mcjdbc.FWDBUtil;
/*     */ import mcframe.serverCore.mcjdbc.MCTransactionManager;
/*     */ import mcframe.serverCore.sys.MCSys;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCGpBatchRequester
/*     */   extends Thread
/*     */ {
/*     */   private final MCDispatcherContext ctx;
/*     */   private final MCRequestHandler hndl;
/*     */   private final String up;
/*     */   private Throwable err;
/*     */   private String gp_batch_grp_cd;
/*     */   private String[] licmods;
/*     */   
/*     */   public MCGpBatchRequester(MCDispatcherContext ctx, MCRequestHandler hndl, String up) {
/*  71 */     this.ctx = ctx;
/*  72 */     this.hndl = hndl;
/*  73 */     this.up = up;
/*  74 */     this.gp_batch_grp_cd = MCTransactionManager.getGpBatchGrpCd();
/*  75 */     this.licmods = MCSys.user.licmods();
/*     */   }
/*     */ 
/*     */   
/*     */   public void run() {
/*     */     try {
/*  81 */       BatchInvokeLogger logger = new BatchInvokeLogger();
/*  82 */       logger.writeStartLog();
/*     */       
/*     */       try {
/*  85 */         StringWriter sw = new StringWriter(1024);
/*  86 */         MCDPWriter dwdpw = new MCDPWriter(sw, true);
/*  87 */         dwdpw.setOperationID(this.ctx.param().getModuleId(), this.ctx.param().getLogicId(), 
/*  88 */             this.ctx.param().getOperationId());
/*  89 */         dwdpw.setDumpId(logger.downId());
/*  90 */         this.ctx.setDwDPW(dwdpw);
/*     */         
/*  92 */         this.hndl.initRequestObject(this.ctx);
/*  93 */         FWDBUtil.setGpBatchGrpCd(this.gp_batch_grp_cd);
/*  94 */         MCUser.setLicmods(this.licmods);
/*     */ 
/*     */         
/*  97 */         this.ctx.setRequestStatus(getClassForRequestStatus(dwdpw));
/*     */ 
/*     */         
/* 100 */         logger.writeUpLog(this.ctx, this.up);
/* 101 */         this.hndl.dispatch(this.ctx);
/* 102 */         this.hndl.destroy();
/*     */ 
/*     */         
/* 105 */         throwInitEx(sw);
/*     */       }
/*     */       finally {
/*     */         
/* 109 */         logger.writeEndLog();
/*     */       }
/*     */     
/* 112 */     } catch (Throwable t) {
/* 113 */       this.err = t;
/*     */     } finally {
/*     */       
/* 116 */       MCTransactionManager.finalClose();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCRequestStatus getClassForRequestStatus(MCDPWriter dwdpw) {
/*     */     try {
/* 129 */       String testClassName = MCFactory.createClassName(new String[] { "mcframe", "serverFZBH", "FZBHL0100", "MCRequestStatusBatchTest" });
/* 130 */       Class<? extends MCRequestStatus> cls = MCFactory.getClass(MCRequestStatus.class, testClassName);
/* 131 */       Class[] types = { MCParam.class, MCDPWriter.class };
/* 132 */       Object[] args = { this.ctx.param(), dwdpw };
/*     */       
/* 134 */       return (MCRequestStatus)MCFactory.create(cls, types, args);
/* 135 */     } catch (MCException mCException) {
/*     */       
/* 137 */       return new MCRequestStatusImpl(this.ctx.param(), dwdpw);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void throwInitEx(StringWriter sw) {
/* 148 */     MCDPTokenMCDP tkn = (MCDPTokenMCDP)MCDPToken.create(sw.toString());
/* 149 */     MCDPFormat fmt = tkn.getFormat();
/* 150 */     MCParam p = new MCParam();
/*     */     
/* 152 */     parseHeader(fmt, tkn, p);
/*     */     
/* 154 */     if (tkn.hasNext()) {
/* 155 */       parseBody(fmt, tkn, p);
/*     */       
/* 157 */       if (!p.getExceptionParam().isEmpty()) {
/* 158 */         throw p.getExceptionParam().getExceptionRowParam().getEx();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseHeader(MCDPFormat fmt, MCDPTokenMCDP tkn, MCParam p) {
/* 172 */     MCT2PHeaderReader hr = MCDPReaderFactory.downHeaderToParam(fmt);
/* 173 */     hr.parse((MCDPToken)tkn, p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void parseBody(MCDPFormat fmt, MCDPTokenMCDP tkn, MCParam p) {
/* 185 */     MCT2PMessageReader mCT2PMessageReader = MCDPReaderFactory.downMessageToParam(fmt);
/* 186 */     mCT2PMessageReader.parse((MCDPToken)tkn, p);
/*     */   }
/*     */   
/*     */   public Throwable getError() {
/* 190 */     return this.err;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class BatchInvokeLogger
/*     */     extends MCServerRequester.UserInfoLogger
/*     */   {
/*     */     protected String startId() {
/* 204 */       return Core_Msg_FW_A.FCBGC0134;
/*     */     }
/*     */ 
/*     */     
/*     */     protected String endId() {
/* 209 */       return Core_Msg_FW_A.FCBGC0135;
/*     */     }
/*     */ 
/*     */     
/*     */     protected String upId() {
/* 214 */       return Core_Msg_FW_A.FCBGC0136;
/*     */     }
/*     */ 
/*     */     
/*     */     protected String downId() {
/* 219 */       return Core_Msg_FW_A.FCBGC0137;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\MCGpBatchRequester.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */