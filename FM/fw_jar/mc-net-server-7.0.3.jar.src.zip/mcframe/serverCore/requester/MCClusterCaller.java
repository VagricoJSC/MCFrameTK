/*     */ package mcframe.serverCore.requester;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutionException;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.Consumer;
/*     */ import mcframe.commonCore.container.MCContainer;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.notice.MCServerAppException;
/*     */ import mcframe.commonCore.notice.MCServerException;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.commonCore.requester.MCClusterServerRole;
/*     */ import mcframe.commonCore.requester.MCControlRequester;
/*     */ import mcframe.commonCore.requester.MCParamHeaderUtil;
/*     */ import mcframe.serverCore.dbc.FCM_SERVER_R;
/*     */ import mcframe.serverCore.logic.MCOperation;
/*     */ import mcframe.serverCore.sys.MCSys;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MCClusterCaller<T extends MCOperation>
/*     */ {
/*     */   protected static final String URL_2TIER = "(2Tier)";
/*     */   protected boolean _wait = true;
/*  88 */   private Map<T, MCException> _mceMap = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  97 */   private Map<T, Task> _taskMap = new LinkedHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Map<T, Task> getTaskMap();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract int parallelSize();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCList<FCM_SERVER_R> getLiveServer(MCClusterServerRole... roles) {
/* 149 */     MCList<FCM_SERVER_R> srvL = null;
/* 150 */     if (MCSys.env.is3Tier()) {
/*     */       
/* 152 */       srvL = MCClusterManager.getManager().getLiveServer(roles);
/*     */     } else {
/*     */       
/* 155 */       srvL = MCList.create(FCM_SERVER_R.class);
/* 156 */       FCM_SERVER_R srvR = (FCM_SERVER_R)srvL.add();
/* 157 */       srvR.url("(2Tier)");
/* 158 */       srvR.srv_id("(2Tier)");
/*     */     } 
/* 160 */     return srvL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Task getTask(T ope) {
/* 179 */     return this._taskMap.get(ope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCException getException(T ope) {
/* 191 */     return this._mceMap.get(ope);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean call() {
/* 210 */     int err = 0;
/*     */ 
/*     */     
/* 213 */     this._taskMap = getTaskMap();
/* 214 */     List<Task> tasks = new ArrayList<>(this._taskMap.values());
/* 215 */     int parasize = parallelSize();
/* 216 */     if (tasks.size() <= 0)
/*     */     {
/* 218 */       return true;
/*     */     }
/* 220 */     if (parasize <= 0) {
/*     */       
/* 222 */       for (Task task : tasks) {
/* 223 */         MCLog.write(Core_Msg_FW_A.FCBGC0435, new Object[] { Integer.valueOf(Task.access$1(task)) });
/*     */       } 
/* 225 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 229 */     ExecutorService es = Executors.newFixedThreadPool(parasize);
/* 230 */     List<Future<T>> futures = null;
/*     */     try {
/* 232 */       futures = es.invokeAll((Collection)tasks);
/*     */     }
/* 234 */     catch (InterruptedException interruptedException) {}
/*     */ 
/*     */     
/* 237 */     if (this._wait) {
/* 238 */       for (int i = 0; i < futures.size(); i++) {
/* 239 */         MCOperation mCOperation; MCException mce = null;
/* 240 */         Future<T> future = futures.get(i);
/* 241 */         T ope = null;
/*     */         
/*     */         try {
/* 244 */           mCOperation = (MCOperation)future.get();
/*     */         }
/* 246 */         catch (ExecutionException|InterruptedException e) {
/*     */           
/* 248 */           Throwable t = e.getCause();
/* 249 */           mce = (t instanceof MCException) ? 
/* 250 */             (MCException)t : new MCException(t);
/* 251 */           err++;
/*     */         } 
/* 253 */         this._mceMap.put((T)mCOperation, mce);
/*     */       } 
/*     */     }
/* 256 */     es.shutdown();
/*     */     
/* 258 */     return !(err > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean call(Consumer<T> success) {
/* 280 */     return call(success, null, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean call(Consumer<T> success, BiConsumer<T, MCException> error) {
/* 303 */     return call(success, error, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean call(Consumer<T> success, BiConsumer<T, MCException> error, Consumer<T> last) {
/* 327 */     boolean ret = call();
/* 328 */     for (MCOperation mCOperation : this._taskMap.keySet()) {
/*     */       try {
/* 330 */         MCException e = getException((T)mCOperation);
/* 331 */         if (e == null && success != null) {
/* 332 */           success.accept((T)mCOperation);
/*     */         }
/* 334 */         else if (e != null && error != null) {
/* 335 */           error.accept((T)mCOperation, e);
/*     */         } 
/*     */       } finally {
/*     */         
/* 339 */         if (last != null) {
/* 340 */           last.accept((T)mCOperation);
/*     */         }
/*     */       } 
/*     */     } 
/* 344 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class Task
/*     */     implements Callable<T>
/*     */   {
/*     */     private final int taskno;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final String url;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final String srv;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final T ope;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final MCParam param;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final Map<Class<?>, Object> reqobj;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected Task(int taskno, String url, String srv, T ope) {
/* 407 */       this.taskno = taskno;
/* 408 */       this.srv = srv;
/* 409 */       this.url = url;
/* 410 */       this.ope = ope;
/* 411 */       this.param = createParam(taskno, ope);
/* 412 */       this.reqobj = MCRequestObject.get();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private MCParam createParam(int taskno, T ope) {
/* 425 */       MCParam param = new MCParam(ope.getOperationInfo());
/* 426 */       setHdrInfo(taskno, param);
/* 427 */       MCContainer up = null;
/* 428 */       for (int i = 0; (up = ope.up(i)) != null; i++) {
/* 429 */         param.addUpBlock(up);
/*     */       }
/* 431 */       MCContainer down = null;
/* 432 */       for (int j = 0; (down = ope.down(j)) != null; j++) {
/* 433 */         param.addDownBlock(down);
/*     */       }
/* 435 */       return param;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void setHdrInfo(int taskno, MCParam p) {
/* 447 */       String taskno_s = String.format("%1$03d", new Object[] { Integer.valueOf(taskno) });
/*     */       
/* 449 */       MCParamHeaderUtil.toUpHeader(p, 
/* 450 */           MCSys.user.clientID(), 
/* 451 */           String.valueOf(MCSys.request.serverRequestNo()) + "_BC" + taskno_s, 
/* 452 */           MCNumber.valueOf(-1));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getNo() {
/* 464 */       return this.taskno;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getURL() {
/* 475 */       return this.url;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getServer() {
/* 486 */       return this.srv;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public T getOperation() {
/* 504 */       return this.ope;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MCParam getParam() {
/* 515 */       return this.param;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public T call() {
/*     */       try {
/* 522 */         MCRequestObject.init();
/* 523 */         initRequestObject();
/*     */ 
/*     */         
/* 526 */         if (this.url == null || this.param == null) {
/* 527 */           MCLog.write(Core_Msg_FW_A.FCBGC0435, new Object[] { Integer.valueOf(this.taskno) });
/* 528 */           return null;
/*     */         } 
/*     */         
/* 531 */         MCLog.write(Core_Msg_FW_A.FCBGC0433, new Object[] { Integer.valueOf(this.taskno), this.url, this.param.getClientRequestNo() });
/* 532 */         MCControlRequester requester = createRequester(this.url);
/* 533 */         requester.request(this.param);
/*     */         
/* 535 */         if (!this.param.getExceptionParam().isEmpty()) {
/*     */           
/* 537 */           MCException tar = this.param.getExceptionParam().getException();
/* 538 */           MCException ex = (tar instanceof mcframe.commonCore.notice.MCAppException) ? 
/* 539 */             (MCException)new MCServerAppException(tar.getID(), new Object[0]) : 
/* 540 */             (MCException)new MCServerException(tar.getID(), new Object[0]);
/* 541 */           ex.setBind((Object[])tar.getBindArray());
/* 542 */           ex.setCauseMessageList(tar.getCauseMessageList());
/* 543 */           ex.setCauseRow(tar.getCauseRow(), tar.getCauseColumn());
/* 544 */           ex = new MCException((Throwable)ex, Core_Msg_FW_A.FCBGC0443, new Object[] { Integer.valueOf(this.taskno), this.url, 
/* 545 */                 this.param.getClientRequestNo(), 
/* 546 */                 this.param.getServerRequestNo() });
/* 547 */           throw ex;
/*     */         } 
/* 549 */         MCLog.write(Core_Msg_FW_A.FCBGC0434, new Object[] { Integer.valueOf(this.taskno), this.url, this.param.getClientRequestNo(), 
/* 550 */               this.param.getServerRequestNo() });
/*     */         
/* 552 */         return this.ope;
/*     */       }
/*     */       finally {
/*     */         
/* 556 */         MCRequestObject.destory();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void initRequestObject() {
/* 569 */       MCRequestInfo reqinfo = (MCRequestInfo)this.reqobj.get(MCRequestInfo.class);
/* 570 */       MCRequest.init(reqinfo);
/*     */ 
/*     */       
/* 573 */       MCUserInfo usrinfo = (MCUserInfo)this.reqobj.get(MCUserInfo.class);
/* 574 */       MCUser.init(usrinfo);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private MCControlRequester createRequester(String url) {
/* 586 */       return MCSys.env.is3Tier() ? (
/* 587 */         (url != null) ? 
/* 588 */         (MCControlRequester)new MCClusterRequester(url) : 
/* 589 */         null) : 
/* 590 */         new MCServerRequester();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\MCClusterCaller.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */