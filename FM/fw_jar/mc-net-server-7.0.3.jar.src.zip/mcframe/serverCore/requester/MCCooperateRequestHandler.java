/*    */ package mcframe.serverCore.requester;
/*    */ 
/*    */ import mcframe.commonCore.container.MCRow;
/*    */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*    */ import mcframe.commonCore.notice.MCLog;
/*    */ import mcframe.commonCore.param.MCParam;
/*    */ import mcframe.serverCore.sys.MCSys;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCCooperateRequestHandler
/*    */   extends MCRequestHandler
/*    */ {
/*    */   private final MCRow logininfo;
/*    */   
/*    */   public MCCooperateRequestHandler(String co_cd) {
/* 34 */     this.logininfo = MCRow.create();
/* 35 */     this.logininfo.setStringNE("co_cd", co_cd);
/* 36 */     this.logininfo.setStringNE("ext_attr1", MCSys.user.extattr1());
/* 37 */     this.logininfo.setStringNE("ext_attr2", MCSys.user.extattr2());
/* 38 */     this.logininfo.setStringNE("ext_attr3", MCSys.user.extattr3());
/* 39 */     this.logininfo.setStringNE("user_nm", MCSys.user.name());
/*    */   }
/*    */ 
/*    */   
/*    */   protected void initUserName(MCParam p) {
/* 44 */     p.setUserName(this.logininfo.getString("user_nm"));
/*    */   }
/*    */   
/*    */   protected void setUserAttr() {
/* 48 */     MCUser.setLoginInfo(this.logininfo);
/*    */   }
/*    */ 
/*    */   
/*    */   public void initRequestObject(MCDispatcherContext ctx) {
/* 53 */     String co_cd = this.logininfo.getString("co_cd");
/* 54 */     MCLog.write(Core_Msg_FW_A.FCBGC0145, new Object[] { co_cd });
/* 55 */     super.initRequestObject(ctx);
/* 56 */     MCRequest.setCooperateCd(co_cd);
/*    */   }
/*    */ 
/*    */   
/*    */   public void destroy() {
/* 61 */     super.destroy();
/* 62 */     MCLog.write(Core_Msg_FW_A.FCBGC0146, new Object[] { this.logininfo.getString("co_cd") });
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\MCCooperateRequestHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */