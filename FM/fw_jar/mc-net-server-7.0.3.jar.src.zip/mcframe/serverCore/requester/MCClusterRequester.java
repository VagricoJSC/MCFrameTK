/*     */ package mcframe.serverCore.requester;
/*     */ 
/*     */ import java.io.File;
/*     */ import mcframe.commonCore.net.MCHttpClient;
/*     */ import mcframe.commonCore.param.MCUploadFileParam;
/*     */ import mcframe.commonCore.requester.MCHTTPRequester;
/*     */ import mcframe.commonCore.resource.ctrl.MCReadableResource;
/*     */ import mcframe.serverCore.resource.MCConfig;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCClusterRequester
/*     */   extends MCHTTPRequester
/*     */ {
/*     */   private final String _url;
/*  32 */   private long _limitbyte = MCConfig.getByteValue((MCReadableResource)MCConfig.server, "net.request.limitSize");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  38 */   private int _retry = MCConfig.server.getInteger("net.request.retry", -1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  44 */   private int _timeout = MCConfig.server.getInteger("net.request.receive_timeout", -1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCClusterRequester(String url) {
/*  54 */     this._url = url;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setRetry(int retry) {
/*  65 */     this._retry = retry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setTimeout(int timeout) {
/*  76 */     this._timeout = timeout;
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCHttpClient createHttpClient() {
/*  81 */     MCHttpClient http = super.createHttpClient();
/*     */ 
/*     */     
/*  84 */     http.setLimitResponseByte(this._limitbyte);
/*     */     
/*  86 */     http.setRetry(this._retry);
/*     */     
/*  88 */     http.setTimeout(this._timeout);
/*     */     
/*  90 */     return http;
/*     */   }
/*     */ 
/*     */   
/*     */   protected String request(String id, String up, MCUploadFileParam upf) {
/*  95 */     return super.request(id, up, upf);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getServletURL(String id) {
/* 100 */     return this._url;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getDownloadURL() {
/* 106 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected File download(String up, File dir, String name) {
/* 112 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String batchRequest(String id, String up) {
/* 118 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\MCClusterRequester.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */