/*     */ package mcframe.serverCore.requester;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.function.BiConsumer;
/*     */ import java.util.function.Consumer;
/*     */ import mcframe.commonCore.container.MCContainer;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.param.MCOperationInfo;
/*     */ import mcframe.commonCore.requester.MCClusterServerRole;
/*     */ import mcframe.serverCore.dbc.FCM_SERVER_R;
/*     */ import mcframe.serverCore.logic.MCOperation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCBroadcastCaller<T extends MCOperation>
/*     */   extends MCClusterCaller<T>
/*     */ {
/*     */   private boolean _atonce = false;
/*  72 */   private int _paraSize = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   private T _bc = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   private List<T> _opList = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   private MCClusterServerRole[] _serverRoles = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCBroadcastCaller() {
/* 106 */     this((MCClusterServerRole[])null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCBroadcastCaller(MCClusterServerRole... roles) {
/* 118 */     Set<MCClusterServerRole> set = new HashSet<>();
/* 119 */     if (roles != null) {
/* 120 */       byte b; int i; MCClusterServerRole[] arrayOfMCClusterServerRole; for (i = (arrayOfMCClusterServerRole = roles).length, b = 0; b < i; ) { MCClusterServerRole role = arrayOfMCClusterServerRole[b];
/* 121 */         if (role != null)
/* 122 */           set.add(role); 
/*     */         b++; }
/*     */     
/*     */     } 
/* 126 */     this._serverRoles = set.<MCClusterServerRole>toArray(new MCClusterServerRole[set.size()]);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Map<T, MCClusterCaller<T>.Task> getTaskMap() {
/* 131 */     Map<T, MCClusterCaller<T>.Task> taskMap = new LinkedHashMap<>();
/*     */     
/* 133 */     MCList<FCM_SERVER_R> srvL = getLiveServer(this._serverRoles);
/*     */ 
/*     */     
/* 136 */     if (srvL != null && srvL.size() > 0) {
/*     */       
/* 138 */       if (this._bc != null) {
/* 139 */         setBroadcastOperationList(srvL.size());
/*     */       }
/*     */ 
/*     */       
/* 143 */       for (int srvno = 0, taskno = 0; taskno < this._opList.size(); taskno++) {
/* 144 */         MCOperation mCOperation = (MCOperation)this._opList.get(taskno);
/* 145 */         if (srvno >= srvL.size()) {
/* 146 */           srvno = 0;
/*     */         }
/*     */         
/* 149 */         FCM_SERVER_R srvR = (FCM_SERVER_R)srvL.get(srvno++);
/* 150 */         MCClusterCaller<T>.Task task = new MCClusterCaller.Task(this, taskno, srvR.url(), srvR.srv_id(), (T)mCOperation);
/* 151 */         taskMap.put((T)mCOperation, task);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 156 */     this._paraSize = this._atonce ? 
/* 157 */       taskMap.size() : (
/* 158 */       (srvL != null) ? srvL.size() : 0);
/*     */     
/* 160 */     return taskMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setBroadcastOperationList(int size) {
/* 176 */     this._opList.clear();
/*     */     
/* 178 */     if (this._bc == null) {
/*     */       return;
/*     */     }
/*     */     
/* 182 */     for (int i = 0; i < size; i++) {
/*     */       
/* 184 */       MCOperationInfo info = this._bc.getOperationInfo();
/* 185 */       MCOperation mCOperation = (MCOperation)MCLogicRefUtil.createOperation(
/* 186 */           info.moduleId, info.logicId, info.operationId, 
/* 187 */           this._bc.getClass());
/* 188 */       MCContainer up = null;
/* 189 */       for (int j = 0; (up = this._bc.up(j)) != null; j++) {
/* 190 */         MCContainer opup = mCOperation.up(j);
/* 191 */         if (up instanceof MCRow) {
/* 192 */           MCRow.copyall((MCRow)opup, (MCRow)up);
/*     */         }
/* 194 */         else if (up instanceof MCList) {
/* 195 */           ((MCList)opup).addAll((Collection)up);
/*     */         } 
/*     */       } 
/* 198 */       this._opList.add((T)mCOperation);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected int parallelSize() {
/* 204 */     return this._paraSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAtOnce(boolean atonce) {
/* 220 */     this._atonce = atonce;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAll(List<T> opList) {
/* 231 */     if (opList != null) {
/* 232 */       this._opList.addAll(opList);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(MCOperation... ops) {
/* 244 */     if (ops != null) {
/* 245 */       byte b; int i; MCOperation[] arrayOfMCOperation; for (i = (arrayOfMCOperation = ops).length, b = 0; b < i; ) { MCOperation mCOperation = arrayOfMCOperation[b];
/* 246 */         this._opList.add((T)mCOperation);
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T[] broadcast(T op) {
/*     */     try {
/* 271 */       this._bc = op;
/*     */       
/* 273 */       call();
/*     */       
/* 275 */       MCOperation[] opsArray = (MCOperation[])Array.newInstance(op.getClass(), this._opList.size());
/* 276 */       return (T[])this._opList.<MCOperation>toArray(opsArray);
/*     */     } finally {
/*     */       
/* 279 */       this._bc = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T[] broadcast(T op, Consumer<T> success) {
/* 304 */     return broadcast(op, success, (BiConsumer<T, MCException>)null, (Consumer<T>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T[] broadcast(T op, Consumer<T> success, BiConsumer<T, MCException> error) {
/* 329 */     return broadcast(op, success, error, (Consumer<T>)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T[] broadcast(T op, Consumer<T> success, BiConsumer<T, MCException> error, Consumer<T> last) {
/* 355 */     MCOperation[] opList = (MCOperation[])broadcast(op); byte b; int i; MCOperation[] arrayOfMCOperation1;
/* 356 */     for (i = (arrayOfMCOperation1 = opList).length, b = 0; b < i; ) { MCOperation mCOperation = arrayOfMCOperation1[b];
/*     */       try {
/* 358 */         MCException e = getException((T)mCOperation);
/* 359 */         if (e == null && success != null) {
/* 360 */           success.accept((T)mCOperation);
/*     */         }
/* 362 */         else if (e != null && error != null) {
/* 363 */           error.accept((T)mCOperation, e);
/*     */         } 
/*     */       } finally {
/*     */         
/* 367 */         if (last != null)
/* 368 */           last.accept((T)mCOperation); 
/*     */       } 
/*     */       b++; }
/*     */     
/* 372 */     return (T[])opList;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\MCBroadcastCaller.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */