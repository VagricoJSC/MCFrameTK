/*    */ package mcframe.serverCore.requester;
/*    */ 
/*    */ import mcframe.commonCore.param.MCParam;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCRequesterPackageProxy
/*    */ {
/*    */   public static void MCRequestObjectInit() {
/* 18 */     MCRequestObject.init();
/*    */   }
/*    */   
/*    */   public static void MCRequestObjectDestory() {
/* 22 */     MCRequestObject.destory();
/*    */   }
/*    */   
/*    */   public static MCDispatcherContext NewMCDispatcherContext(MCParam param) {
/* 26 */     return new MCDispatcherContext(param);
/*    */   }
/*    */   
/*    */   public static void MCRequestInit(MCDispatcherContext ctx) {
/* 30 */     MCRequest.init(ctx);
/*    */   }
/*    */   
/*    */   public static void MCUserInit(String id, String coCd) {
/* 34 */     MCUserInfo ui = new MCUserInfo();
/* 35 */     ui.ID = id;
/* 36 */     ui.loginSequence = "";
/* 37 */     ui.clientID = "";
/* 38 */     ui.licmods = new String[] {
/* 39 */         ""
/*    */       };
/* 41 */     ui.coCD = coCd;
/* 42 */     MCUser.init(ui);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\MCRequesterPackageProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */