/*     */ package mcframe.serverCore.requester;
/*     */ 
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.serverCore.logic.MCLogic;
/*     */ import mcframe.serverCore.mcjdbc.MCTransactionManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCSimpleLogicInvoker
/*     */   extends MCLogicInvoker
/*     */ {
/*     */   public void invoke(MCDispatcherContext ctx) {
/*  32 */     String START_LOG_ID = Core_Msg_FW_A.FCBGC0304;
/*  33 */     String END_LOG_ID = Core_Msg_FW_A.FCBGC0305;
/*     */ 
/*     */     
/*  36 */     MCLog.write(START_LOG_ID, new Object[] { ctx.param().getModuleId(), ctx.param().getLogicId(), 
/*  37 */           ctx.param().getOperationId(), ctx.param().getVersion() });
/*     */     
/*     */     try {
/*  40 */       invokeMain(ctx);
/*     */     } finally {
/*     */ 
/*     */       
/*     */       try {
/*  45 */         MCTransactionManager.dbTran().rollback();
/*     */ 
/*     */         
/*  48 */         MCLogicProxy.proxy.stopSQLTrace();
/*     */       }
/*  50 */       catch (Exception e) {
/*  51 */         MCLog.write(e);
/*     */       } 
/*     */ 
/*     */       
/*  55 */       MCLog.write(END_LOG_ID, new Object[] { ctx.param().getModuleId(), ctx.param().getLogicId(), 
/*  56 */             ctx.param().getOperationId(), ctx.param().getVersion() });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void invokeMain(MCDispatcherContext ctx) {
/*  64 */     MCLogic lgc = createLogic(ctx);
/*  65 */     initLogicParam(lgc, ctx);
/*     */ 
/*     */     
/*  68 */     parseUp(ctx, lgc);
/*     */ 
/*     */     
/*  71 */     MCLogicProxy.proxy.startSQLTrace();
/*     */ 
/*     */     
/*  74 */     doLogicPhase(ctx, lgc);
/*     */ 
/*     */     
/*  77 */     checkOverCap(ctx);
/*     */ 
/*     */     
/*  80 */     parseDown(ctx);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void checkOverCap(MCDispatcherContext ctx) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCLogic createLogic(MCDispatcherContext ctx) {
/*  96 */     return MCLogicRefUtil.crtLgc(ctx.param());
/*     */   }
/*     */   
/*     */   protected void initLogicParam(MCLogic lgc, MCDispatcherContext ctx) {
/* 100 */     MCLogicRefUtil.initLgcPrm(lgc, ctx.param());
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\MCSimpleLogicInvoker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */