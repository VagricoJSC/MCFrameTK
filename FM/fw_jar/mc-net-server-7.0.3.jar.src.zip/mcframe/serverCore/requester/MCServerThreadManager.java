/*      */ package mcframe.serverCore.requester;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.ExecutionException;
/*      */ import java.util.concurrent.Executors;
/*      */ import java.util.concurrent.Future;
/*      */ import java.util.concurrent.RejectedExecutionException;
/*      */ import java.util.concurrent.ThreadFactory;
/*      */ import java.util.concurrent.ThreadPoolExecutor;
/*      */ import java.util.concurrent.atomic.AtomicBoolean;
/*      */ import java.util.concurrent.atomic.AtomicInteger;
/*      */ import mcframe.commonCore.container.MCVolumeManager;
/*      */ import mcframe.commonCore.lang.MCStringUtil;
/*      */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*      */ import mcframe.commonCore.notice.MCException;
/*      */ import mcframe.commonCore.notice.MCLog;
/*      */ import mcframe.commonCore.notice.MCMessageList;
/*      */ import mcframe.serverCore.logic.IfMCOperation;
/*      */ import mcframe.serverCore.mcjdbc.MCConnectionPool;
/*      */ import mcframe.serverCore.mcjdbc.MCDBTransaction;
/*      */ import mcframe.serverCore.mcjdbc.MCTransactionManager;
/*      */ import mcframe.serverCore.notice.MCMessagePool;
/*      */ import mcframe.serverCore.resource.MCConfig;
/*      */ import mcframe.serverCore.sys.MCSys;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MCServerThreadManager
/*      */ {
/*   53 */   static final Class<MCServerThreadManager> CLAZZ = MCServerThreadManager.class;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final String PARENT_THREAD_NO = "0";
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String THREAD_LIMIT_KEY = "thread.limitSize";
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   68 */   private static final MCServerThreadListener defaultServerThreadListener = new MCServerThreadListener();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ThreadPoolExecutor executor;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   78 */   private final ConcurrentHashMap<IfMCOperation, Future<MCThreadReturn>> futureMap = new ConcurrentHashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   83 */   private final ConcurrentHashMap<IfMCOperation, Integer> numMap = new ConcurrentHashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   88 */   private ConcurrentHashMap<IfMCOperation, MCException> exMap = new ConcurrentHashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   93 */   private ConcurrentHashMap<IfMCOperation, MCMessageList> msgMap = new ConcurrentHashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   99 */   private ConcurrentHashMap<IfMCOperation, Thread> runningOpeMap = new ConcurrentHashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  104 */   private static final Thread DUMMY_THREAD = new Thread();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  109 */   private static final Integer WAIT_SLEEP_MILLIS = Integer.valueOf(MCConfig.server.getInteger("thread.sleepMillis", 500));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  115 */   private final List<MCDBTransaction> dbTranList = Collections.synchronizedList(new ArrayList<>());
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  120 */   private MCDBTransaction mainDBTran = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean useMainDBTran = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean commitAndRollback = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean shutdownOnError = true;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<MCDBTransaction> dbTranListSub;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Set<MCDBTransaction> BLOBSet;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Set<MCDBTransaction> autoCommitDbTranSet;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  155 */   private Integer limitThreadSize = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  160 */   private AtomicInteger opeCount = new AtomicInteger(1);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  165 */   private AtomicInteger completedOpeCount = new AtomicInteger(0);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final MCUserInfo userInfo;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final MCRequestInfo requestInfo;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final MCVolumeManager.ThreadVolumeManager threadMgr;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean sqlTraceFlg;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final Map<String, String> USER_CNTEXT;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  195 */   private AtomicBoolean shutdown = new AtomicBoolean(false);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  200 */   private AtomicBoolean changing = new AtomicBoolean(false);
/*      */   
/*  202 */   private static boolean _autotest = Boolean.valueOf(MCSys.env.getVMEnv("autotest")).booleanValue();
/*      */ 
/*      */   
/*      */   public MCServerThreadManager() {
/*  206 */     this.threadMgr = MCVolumeManager.getThreadVolumeManager();
/*  207 */     this.sqlTraceFlg = MCLogicProxy.proxy.getSqlTraceFlg();
/*  208 */     this.USER_CNTEXT = MCTransactionManager.USER_CNTEXT.get();
/*  209 */     this.userInfo = (MCUserInfo)MCRequestObject.object(MCUserInfo.class);
/*  210 */     this.requestInfo = (MCRequestInfo)MCRequestObject.object(MCRequestInfo.class);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ThreadPoolExecutor getExecutor() {
/*  223 */     if (this.executor == null && !getDbTranList().isEmpty()) {
/*  224 */       this.executor = (ThreadPoolExecutor)Executors.newFixedThreadPool(
/*  225 */           getDbTranList().size(), new MCServerThreadFactory());
/*  226 */       MCLog.write(Core_Msg_FW_A.FCBGC0111, new Object[] { Integer.valueOf(getDbTranList().size()) });
/*  227 */       this.shutdown.set(false);
/*      */     } 
/*  229 */     return this.executor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int getOpeNo() {
/*  240 */     return this.opeCount.getAndIncrement();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int getOpeCount() {
/*  251 */     return this.opeCount.get() - 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int getCompletedOpeCount() {
/*  262 */     return this.completedOpeCount.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void addCompletedOpeCount() {
/*  272 */     this.completedOpeCount.getAndIncrement();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void startOperation(IfMCOperation op, Thread thread) {
/*  284 */     this.runningOpeMap.put(op, thread);
/*  285 */     if (isShutdown()) {
/*  286 */       errorOperation(op);
/*  287 */       throw new MCException(new InterruptedException());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void errorOperation(IfMCOperation op) {
/*  297 */     this.runningOpeMap.put(op, DUMMY_THREAD);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void endOperation(IfMCOperation op) {
/*  306 */     this.runningOpeMap.remove(op);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void waitCompletion(IfMCOperation op) {
/*      */     Thread thread;
/*  317 */     while ((thread = this.runningOpeMap.get(op)) != null) {
/*  318 */       if (thread != DUMMY_THREAD && !thread.isInterrupted())
/*      */       {
/*  320 */         thread.interrupt();
/*      */       }
/*      */       try {
/*  323 */         Thread.sleep(WAIT_SLEEP_MILLIS.intValue());
/*      */       }
/*  325 */       catch (InterruptedException interruptedException) {}
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ConcurrentHashMap<IfMCOperation, Future<MCThreadReturn>> getFutureMap() {
/*  340 */     return this.futureMap;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ConcurrentHashMap<IfMCOperation, Integer> getNumMap() {
/*  351 */     return this.numMap;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ConcurrentHashMap<IfMCOperation, MCException> getExceptionMap() {
/*  362 */     return this.exMap;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ConcurrentHashMap<IfMCOperation, MCMessageList> getMessageMap() {
/*  373 */     return this.msgMap;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   List<MCDBTransaction> getDbTranList() {
/*  384 */     return this.dbTranList;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void releaseDbTran() {
/*  394 */     shutdown();
/*  395 */     List<MCDBTransaction> tranL = new ArrayList<>(this.dbTranList);
/*  396 */     for (MCDBTransaction tran : tranL) {
/*  397 */       this.dbTranList.remove(tran);
/*  398 */       if (tran.isClose()) {
/*      */         continue;
/*      */       }
/*  401 */       if (!isMainDBTran(tran)) {
/*  402 */         MCTransactionManager.releaseDBTran(tran);
/*      */       }
/*      */     } 
/*  405 */     this.mainDBTran = null;
/*      */     
/*  407 */     this.executor = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void addDbTranListSub(List<MCDBTransaction> tran) {
/*  418 */     for (MCDBTransaction t : tran) {
/*  419 */       synchronized (this.dbTranList) {
/*  420 */         if (!this.dbTranList.contains(t)) {
/*  421 */           if (this.dbTranListSub == null) {
/*  422 */             this.dbTranListSub = new ArrayList<>();
/*      */           }
/*  424 */           this.dbTranListSub.add(t);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized void addBLOBSet(Set<MCDBTransaction> blob) {
/*  438 */     if (!blob.isEmpty()) {
/*  439 */       if (this.BLOBSet == null) {
/*  440 */         this.BLOBSet = new HashSet<>();
/*      */       }
/*  442 */       this.BLOBSet.addAll(blob);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized void addAutoCommitDbTranSet(List<MCDBTransaction> dbTran) {
/*  454 */     if (!dbTran.isEmpty()) {
/*  455 */       if (this.autoCommitDbTranSet == null) {
/*  456 */         this.autoCommitDbTranSet = new HashSet<>();
/*      */       }
/*  458 */       this.autoCommitDbTranSet.addAll(dbTran);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isChildThread() {
/*  470 */     return !MCStringUtil.same(MCSys.request.serverThreadNo(), "0");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static List<MCException> getCauseExeptionList() {
/*  483 */     List<MCException> ret = new ArrayList<>();
/*  484 */     for (MCException e : ((MCServerThreadManager)MCRequestObject.object(CLAZZ)).getExceptionMap().values()) {
/*  485 */       if (!isInterruptedException((Throwable)e)) {
/*  486 */         ret.add(e);
/*      */       }
/*      */     } 
/*  489 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setUseMainDBTran(boolean use) {
/*  502 */     MCServerThreadManager manager = (MCServerThreadManager)MCRequestObject.object(CLAZZ);
/*  503 */     if (manager.getDbTranList().isEmpty()) {
/*  504 */       manager.useMainDBTran = use;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isUseMainDBTran() {
/*  516 */     return ((MCServerThreadManager)MCRequestObject.object(CLAZZ)).useMainDBTran;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setCommitAndRollback(boolean use) {
/*  527 */     ((MCServerThreadManager)MCRequestObject.object(CLAZZ)).commitAndRollback = use;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isCommitAndRollback() {
/*  538 */     return ((MCServerThreadManager)MCRequestObject.object(CLAZZ)).commitAndRollback;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setShutdownOnError(boolean use) {
/*  549 */     ((MCServerThreadManager)MCRequestObject.object(CLAZZ)).shutdownOnError = use;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isShutdownOnError() {
/*  560 */     return ((MCServerThreadManager)MCRequestObject.object(CLAZZ)).shutdownOnError;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void destroy() {
/*  571 */     MCServerThreadManager manager = (MCServerThreadManager)MCRequestObject.object(CLAZZ);
/*  572 */     for (MCDBTransaction tran : manager.dbTranList) {
/*  573 */       if (!tran.isClose()) {
/*  574 */         MCLogicProxy.proxy.getDbTranPool().add(tran);
/*      */       }
/*      */     } 
/*  577 */     manager.dbTranList.clear();
/*  578 */     if (manager.dbTranListSub != null) {
/*  579 */       MCLogicProxy.proxy.getDbTranPool().addAll(manager.dbTranListSub);
/*  580 */       manager.dbTranListSub.clear();
/*      */     } 
/*  582 */     if (manager.BLOBSet != null) {
/*  583 */       MCLogicProxy.proxy.getBLOBPool().addAll(manager.BLOBSet);
/*  584 */       manager.BLOBSet.clear();
/*      */     } 
/*  586 */     if (manager.autoCommitDbTranSet != null) {
/*  587 */       MCLogicProxy.proxy.getAutoCommitDbTranPool().addAll(manager.autoCommitDbTranSet);
/*  588 */       manager.autoCommitDbTranSet.clear();
/*      */     } 
/*  590 */     manager.executor = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void increaseThreadPoolSize() {
/*  603 */     if (!isShutdown() && !isMaxThread() && !setChanging(true)) {
/*      */       
/*  605 */       String no = MCSys.request.serverThreadNo();
/*  606 */       MCRequest.setServerThreadNo("0");
/*      */       try {
/*  608 */         increaseThreadPoolSize((getIncompleteTaskCount() - 1));
/*      */       } finally {
/*      */         
/*  611 */         setChanging(false);
/*  612 */         MCRequest.setServerThreadNo(no);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean setChanging(boolean v) {
/*  626 */     return this.changing.getAndSet(v);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int increaseThreadPoolSize(long num) {
/*  641 */     if (num == 0L) {
/*  642 */       return getDbTranList().size();
/*      */     }
/*      */     
/*  645 */     long max = getLimitSize();
/*  646 */     if ((max < 0L || max > num) && num > 0L) {
/*  647 */       max = num;
/*      */     }
/*  649 */     if (max < 0L)
/*      */     {
/*  651 */       max = MCConnectionPool.getDBInfo().getMaxConnection();
/*      */     }
/*  653 */     if (getDbTranList().size() >= max) {
/*  654 */       return getDbTranList().size();
/*      */     }
/*      */     
/*  657 */     synchronized (this.dbTranList) {
/*  658 */       if (getDbTranList().isEmpty() && isUseMainDBTran()) {
/*  659 */         this.mainDBTran = MCTransactionManager.dbTran();
/*  660 */         getDbTranList().add(this.mainDBTran);
/*      */       } 
/*  662 */       max -= getDbTranList().size();
/*      */       try {
/*  664 */         MCLog.write(Core_Msg_FW_A.FCBGC0129, new Object[] { Integer.valueOf(getDbTranList().size()), Long.valueOf(max) });
/*  665 */         for (int i = 0; i < max; i++) {
/*  666 */           MCDBTransaction tran = MCLogicProxy.proxy.createDBTran(true, false);
/*  667 */           getDbTranList().add(tran);
/*      */         }
/*      */       
/*  670 */       } catch (MCException e) {
/*  671 */         if (getDbTranList().isEmpty())
/*      */         {
/*  673 */           throw e;
/*      */         }
/*  675 */         MCLog.write((Throwable)e);
/*  676 */         MCLog.write(Core_Msg_FW_A.FCBGC0110, new Object[0]);
/*      */       } 
/*  678 */       return changePoolSize(getDbTranList().size());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int changePoolSize(int size) {
/*  690 */     if (size > getExecutor().getCorePoolSize()) {
/*  691 */       getExecutor().setMaximumPoolSize(size);
/*  692 */       getExecutor().setCorePoolSize(size);
/*  693 */       MCLog.write(Core_Msg_FW_A.FCBGC0111, new Object[] { Integer.valueOf(size) });
/*      */     } 
/*  695 */     return getExecutor().getCorePoolSize();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void addThreadPoolSize(int num) {
/*  706 */     if (!isMaxThread()) {
/*  707 */       increaseThreadPoolSize((getIncompleteTaskCount() + num));
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int getIncompleteTaskCount() {
/*  727 */     return getOpeCount() - getCompletedOpeCount();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isTaskWaiting() {
/*  738 */     return !(getExecutor().isShutdown() && 
/*  739 */       getIncompleteTaskCount() <= getExecutor().getPoolSize());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getThreadCount(int num) {
/*  755 */     return ((MCServerThreadManager)MCRequestObject.object(CLAZZ)).increaseThreadPoolSize(num);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getLimitThreadSize() {
/*  768 */     return ((MCServerThreadManager)MCRequestObject.object(CLAZZ)).getLimitSize();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setLimitThreadSize(int size) {
/*  781 */     ((MCServerThreadManager)MCRequestObject.object(CLAZZ)).setLimitSize(size);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int getLimitSize() {
/*  792 */     if (this.limitThreadSize == null) {
/*  793 */       this.limitThreadSize = Integer.valueOf(getLimitSize(MCSys.request.moduleId(), 
/*  794 */             MCSys.request.logicId(), MCSys.request.operationId()));
/*      */     }
/*  796 */     return this.limitThreadSize.intValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setLimitSize(int size) {
/*  809 */     if (size != 0) {
/*  810 */       this.limitThreadSize = Integer.valueOf(size);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getLimitSize(String mid, String lgcid, String opeid) {
/*  825 */     String key = MCConfig.server.findHierarchy(new String[] { mid, lgcid, opeid, "thread.limitSize" });
/*  826 */     if (MCStringUtil.isNull(key)) {
/*  827 */       return 1;
/*      */     }
/*  829 */     return MCConfig.server.getInteger(key, 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isMaxThread() {
/*  840 */     return !((getLimitSize() <= -1 || getDbTranList().size() <= getLimitSize()) && 
/*  841 */       !isMaxConnection());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isMaxConnection() {
/*  852 */     int size = getDbTranList().size();
/*  853 */     if (!isUseMainDBTran()) {
/*  854 */       size++;
/*      */     }
/*  856 */     return (size == MCConnectionPool.getDBInfo().getMaxConnection());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends IfMCOperation> void invoke(List<T> opList, Class... copyObject) {
/*  872 */     invoke(opList, (MCServerThreadListener)null, copyObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends IfMCOperation> void invokeAndWait(List<T> opList, Class... copyObject) {
/*  888 */     invokeAndWait(opList, (MCServerThreadListener)null, copyObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends IfMCOperation> void invokeAndWait(int size, List<T> opList, Class... copyObject) {
/*  906 */     invokeAndWait(size, opList, null, copyObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends IfMCOperation> void invoke(List<T> opList, MCServerThreadListener listener, Class... copyObject) {
/*  923 */     if (opList.isEmpty()) {
/*      */       return;
/*      */     }
/*  926 */     MCServerThreadManager manager = (MCServerThreadManager)MCRequestObject.object(CLAZZ);
/*  927 */     manager.addThreadPoolSize(opList.size());
/*  928 */     MCLog.write(Core_Msg_FW_A.FCBGC0127, new Object[] { Integer.valueOf(opList.size()), Integer.valueOf(manager.getLimitSize()), 
/*  929 */           Boolean.valueOf(manager.commitAndRollback), Boolean.valueOf(manager.useMainDBTran), 
/*  930 */           Boolean.valueOf(manager.shutdownOnError) });
/*  931 */     for (IfMCOperation ifMCOperation : opList) {
/*  932 */       invokeThread(ifMCOperation, listener, copyObject);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends IfMCOperation> void invokeAndWait(List<T> opList, MCServerThreadListener listener, Class... copyObject) {
/*  950 */     invokeAndWait(0, opList, listener, copyObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends IfMCOperation> void invokeAndWait(int size, List<T> opList, MCServerThreadListener listener, Class... copyObject) {
/*  969 */     if (opList.isEmpty()) {
/*      */       return;
/*      */     }
/*  972 */     MCServerThreadManager manager = (MCServerThreadManager)MCRequestObject.object(CLAZZ);
/*  973 */     manager.setLimitSize(size);
/*  974 */     manager.addThreadPoolSize(opList.size());
/*  975 */     MCLog.write(Core_Msg_FW_A.FCBGC0126, new Object[] { Integer.valueOf(opList.size()), Integer.valueOf(manager.getLimitSize()), 
/*  976 */           Boolean.valueOf(manager.commitAndRollback), Boolean.valueOf(manager.useMainDBTran), 
/*  977 */           Boolean.valueOf(manager.shutdownOnError) });
/*      */     
/*  979 */     if (_autotest) {
/*  980 */       List<Class<?>> ls = new ArrayList<>();
/*  981 */       if (copyObject != null && copyObject.length > 0) {
/*  982 */         ls.addAll(Arrays.asList(copyObject));
/*      */       }
/*      */ 
/*      */       
/*      */       try {
/*  987 */         Class<?> c = Class.forName("mcframe.serverCore.servunit.AutoTestParam");
/*  988 */         ls.add(c);
/*      */       }
/*  990 */       catch (ClassNotFoundException e) {
/*  991 */         e.printStackTrace();
/*  992 */         throw new MCException(e);
/*      */       } 
/*      */       
/*  995 */       copyObject = (Class[])ls.<Class<?>[]>toArray((Class<?>[][])new Class[ls.size()]);
/*      */     } 
/*      */     
/*  998 */     for (IfMCOperation ifMCOperation : opList) {
/*  999 */       invokeThread(ifMCOperation, listener, copyObject);
/*      */     }
/* 1001 */     if (manager.commitAndRollback)
/*      */     {
/* 1003 */       manager.getExecutor().shutdown();
/*      */     }
/*      */     
/* 1006 */     join(opList);
/*      */     
/* 1008 */     if (manager.commitAndRollback) {
/* 1009 */       manager.releaseDbTran();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends IfMCOperation> void invoke(T op, Class... copyObject) {
/* 1025 */     invoke(op, (MCServerThreadListener)null, copyObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends IfMCOperation> void invoke(T op, MCServerThreadListener listener, Class... copyObject) {
/* 1042 */     MCServerThreadManager manager = (MCServerThreadManager)MCRequestObject.object(CLAZZ);
/* 1043 */     manager.addThreadPoolSize(1);
/* 1044 */     MCLog.write(Core_Msg_FW_A.FCBGC0127, new Object[] { Integer.valueOf(1), Integer.valueOf(manager.getLimitSize()), Boolean.valueOf(manager.commitAndRollback), 
/* 1045 */           Boolean.valueOf(manager.useMainDBTran), Boolean.valueOf(manager.shutdownOnError) });
/* 1046 */     invokeThread(op, listener, copyObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static <T extends IfMCOperation> void invokeThread(T op, MCServerThreadListener listener, Class... copyObject) {
/* 1060 */     if (isChildThread()) {
/* 1061 */       throw new MCException(Core_Msg_FW_A.FCBGC0121, new Object[0]);
/*      */     }
/* 1063 */     MCServerThreadManager manager = (MCServerThreadManager)MCRequestObject.object(CLAZZ);
/* 1064 */     Future<MCThreadReturn> f = null;
/*      */     try {
/* 1066 */       int no = manager.getOpeNo();
/* 1067 */       f = manager.getExecutor().submit(
/* 1068 */           manager.createServerThreadCallble((IfMCOperation)op, listener, no, copyObject));
/* 1069 */       manager.getFutureMap().put((IfMCOperation)op, f);
/* 1070 */       manager.getNumMap().put((IfMCOperation)op, Integer.valueOf(no));
/* 1071 */       MCLog.write(Core_Msg_FW_A.FCBGC0118, new Object[] { Integer.valueOf(no) });
/*      */     }
/* 1073 */     catch (RejectedExecutionException e) {
/* 1074 */       throw new MCException(e, Core_Msg_FW_A.FCBGC0112, new Object[0]);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends IfMCOperation> void join(List<T> opList) {
/* 1087 */     MCException ex = null;
/* 1088 */     for (IfMCOperation ifMCOperation : opList) {
/*      */       try {
/* 1090 */         join(ifMCOperation);
/*      */       }
/* 1092 */       catch (MCException e) {
/* 1093 */         if (ex == null || isInterruptedException((Throwable)ex)) {
/* 1094 */           ex = e;
/*      */         }
/*      */       } 
/*      */     } 
/* 1098 */     if (ex != null) {
/* 1099 */       throw ex;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends IfMCOperation> void join(T op) {
/* 1112 */     Future<MCThreadReturn> f = ((MCServerThreadManager)MCRequestObject.object(CLAZZ)).getFutureMap().get(op);
/* 1113 */     if (f != null) {
/* 1114 */       join(op, f);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void joinAll() {
/* 1125 */     join(new ArrayList<>(((MCServerThreadManager)MCRequestObject.object(CLAZZ)).getFutureMap().keySet()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void rollbackAll() {
/* 1139 */     throwChildEx();
/* 1140 */     joinAll();
/*      */     
/* 1142 */     for (MCDBTransaction tran : getDBTransaction()) {
/* 1143 */       tran.rollback();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void commitAll() {
/* 1158 */     throwChildEx();
/* 1159 */     joinAll();
/*      */     
/* 1161 */     for (MCDBTransaction tran : getDBTransaction()) {
/* 1162 */       tran.commit();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<MCDBTransaction> getDBTransaction() {
/* 1178 */     throwChildEx();
/* 1179 */     joinAll();
/*      */     
/* 1181 */     MCServerThreadManager manager = (MCServerThreadManager)MCRequestObject.object(CLAZZ);
/* 1182 */     List<MCDBTransaction> ret = new ArrayList<>();
/* 1183 */     ret.addAll(manager.getDbTranList());
/* 1184 */     if (manager.dbTranListSub != null) {
/* 1185 */       ret.addAll(manager.dbTranListSub);
/*      */     }
/* 1187 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void throwChildEx() {
/* 1197 */     if (isChildThread()) {
/* 1198 */       throw new MCException(Core_Msg_FW_A.FCBGC0131, new Object[0]);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static <T extends IfMCOperation> MCException getException(T op) {
/* 1214 */     return ((MCServerThreadManager)MCRequestObject.object(CLAZZ)).getExceptionMap().get(op);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void shutdown() {
/* 1226 */     ThreadPoolExecutor exe = ((MCServerThreadManager)MCRequestObject.object(CLAZZ)).getExecutor();
/* 1227 */     if (exe != null) {
/* 1228 */       exe.shutdown();
/* 1229 */       joinAll();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void shutdownNow() {
/* 1240 */     shutdownNow(null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void shutdownNow(IfMCOperation op) {
/* 1251 */     MCServerThreadManager manager = (MCServerThreadManager)MCRequestObject.object(CLAZZ);
/* 1252 */     if (manager.setShutdown()) {
/*      */       return;
/*      */     }
/* 1255 */     ThreadPoolExecutor exe = manager.getExecutor();
/* 1256 */     if (exe != null) {
/* 1257 */       exe.shutdownNow();
/*      */     }
/*      */     
/* 1260 */     Iterator<Map.Entry<IfMCOperation, Future<MCThreadReturn>>> iterator = manager.futureMap.entrySet().iterator(); while (iterator.hasNext()) { Map.Entry<IfMCOperation, Future<MCThreadReturn>> entry = iterator.next();
/* 1261 */       Future<MCThreadReturn> v = entry.getValue();
/* 1262 */       if (!v.isDone() && !v.isCancelled() && entry.getKey() != op)
/*      */       {
/* 1264 */         v.cancel(true);
/*      */       } }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean setShutdown() {
/* 1278 */     return this.shutdown.getAndSet(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isShutdown() {
/* 1289 */     return this.shutdown.get();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static <T extends IfMCOperation> void join(T op, Future<MCThreadReturn> f) {
/*      */     MCMessageList l;
/* 1303 */     MCServerThreadManager manager = (MCServerThreadManager)MCRequestObject.object(CLAZZ);
/*      */     try {
/* 1305 */       MCThreadReturn p = f.get();
/* 1306 */       MCLog.write(Core_Msg_FW_A.FCBGC0120, new Object[] { Integer.valueOf(p.getNo()), p.getThreadNum() });
/*      */     }
/* 1308 */     catch (InterruptedException e) {
/* 1309 */       throw new MCException(e);
/*      */     }
/* 1311 */     catch (ExecutionException|java.util.concurrent.CancellationException e) {
/* 1312 */       MCException mce; if (isInterruptedException(e)) {
/* 1313 */         if (e.getCause() != null) {
/* 1314 */           if (e.getCause() instanceof MCException) {
/* 1315 */             throw (MCException)e.getCause();
/*      */           }
/* 1317 */           throw new MCException(e.getCause());
/*      */         } 
/* 1319 */         throw new MCException(e);
/*      */       } 
/*      */       
/* 1322 */       if (isServerThreadException(e)) {
/* 1323 */         mce = (MCException)e.getCause();
/*      */       } else {
/*      */         
/* 1326 */         Throwable cause = e.getCause();
/* 1327 */         if (cause == null) {
/* 1328 */           cause = e;
/*      */         }
/* 1330 */         Integer num = manager.getNumMap().get(op);
/* 1331 */         mce = new MCException(cause, Core_Msg_FW_A.FCBGC0113, new Object[] { (num != null) ? num : "-", "-" });
/* 1332 */         manager.getExceptionMap().put((IfMCOperation)op, 
/* 1333 */             (cause instanceof MCException) ? (MCException)cause : mce);
/* 1334 */         MCLog.write((Throwable)mce);
/*      */       } 
/* 1336 */       throw mce;
/*      */     }
/*      */     finally {
/*      */       
/* 1340 */       if (f.isCancelled()) {
/* 1341 */         manager.waitCompletion((IfMCOperation)op);
/*      */       }
/*      */       
/* 1344 */       manager.getFutureMap().remove(op);
/* 1345 */       MCMessageList mCMessageList = manager.getMessageMap().remove(op);
/* 1346 */       if (mCMessageList != null) {
/* 1347 */         MCMessagePool.addAll(mCMessageList);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static boolean isInterruptedException(Throwable t) {
/* 1361 */     if (t == null) {
/* 1362 */       return false;
/*      */     }
/* 1364 */     if (t instanceof InterruptedException || t instanceof java.util.concurrent.CancellationException) {
/* 1365 */       return true;
/*      */     }
/* 1367 */     if (t instanceof MCException) {
/* 1368 */       String id = ((MCException)t).getID();
/*      */       
/* 1370 */       if (MCStringUtil.same(id, Core_Msg_FW_A.FCBGC0112)) {
/* 1371 */         return true;
/*      */       }
/*      */     } 
/* 1374 */     return isInterruptedException(t.getCause());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static boolean isServerThreadException(Throwable t) {
/*      */     MCException e;
/* 1387 */     if (t instanceof MCException) {
/* 1388 */       e = (MCException)t;
/*      */     }
/* 1390 */     else if (t.getCause() != null && t.getCause() instanceof MCException) {
/* 1391 */       e = (MCException)t.getCause();
/*      */     } else {
/*      */       
/* 1394 */       return false;
/*      */     } 
/* 1396 */     return MCStringUtil.same(e.getID(), Core_Msg_FW_A.FCBGC0113);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isMainDBTran(MCDBTransaction tran) {
/* 1408 */     return (this.mainDBTran == tran);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MCServerThreadCallable createServerThreadCallble(IfMCOperation op, MCServerThreadListener listener, int no, Class... copyObject) {
/* 1424 */     listener = (listener == null) ? defaultServerThreadListener : listener;
/* 1425 */     return new MCServerThreadCallable(op, listener, this.commitAndRollback, 
/* 1426 */         this.shutdownOnError, this, no, copyObject);
/*      */   }
/*      */   
/*      */   MCVolumeManager.ThreadVolumeManager getThreadMgr() {
/* 1430 */     return this.threadMgr;
/*      */   }
/*      */   
/*      */   Map<String, String> getUSER_CNTEXT() {
/* 1434 */     return this.USER_CNTEXT;
/*      */   }
/*      */   
/*      */   MCUserInfo getUserInfo() {
/* 1438 */     return this.userInfo;
/*      */   }
/*      */   
/*      */   MCRequestInfo getRequestInfo() {
/* 1442 */     return this.requestInfo;
/*      */   }
/*      */   
/*      */   boolean isSqlTraceFlg() {
/* 1446 */     return this.sqlTraceFlg;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private class MCServerThreadFactory
/*      */     implements ThreadFactory
/*      */   {
/*      */     private final ThreadGroup group;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1466 */     private final AtomicInteger threadNumber = new AtomicInteger(1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final String namePrefix;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     MCServerThreadFactory() {
/* 1480 */       SecurityManager s = System.getSecurityManager();
/* 1481 */       this.group = (s != null) ? s.getThreadGroup() : 
/* 1482 */         Thread.currentThread().getThreadGroup();
/* 1483 */       this.namePrefix = "mcpool-" + MCSys.request.serverRequestNo() + "-";
/*      */     }
/*      */ 
/*      */     
/*      */     public Thread newThread(Runnable r) {
/* 1488 */       int threadNum = this.threadNumber.getAndIncrement();
/* 1489 */       MCDBTransaction tran = MCServerThreadManager.this.dbTranList.get(threadNum - 1);
/* 1490 */       Thread t = new MCServerThread(this.group, r, this.namePrefix, threadNum, 0L, tran);
/* 1491 */       if (t.isDaemon()) t.setDaemon(false); 
/* 1492 */       if (t.getPriority() != 5)
/* 1493 */         t.setPriority(5); 
/* 1494 */       MCLog.write(Core_Msg_FW_A.FCBGC0164, new Object[] { Integer.valueOf(threadNum), tran.getDBConnectionBody().getSessionStr() });
/* 1495 */       return t;
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\MCServerThreadManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */