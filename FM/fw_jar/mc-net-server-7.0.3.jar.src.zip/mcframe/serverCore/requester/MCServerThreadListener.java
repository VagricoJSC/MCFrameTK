/*    */ package mcframe.serverCore.requester;
/*    */ 
/*    */ import mcframe.commonCore.notice.MCAppException;
/*    */ import mcframe.commonCore.notice.MCException;
/*    */ import mcframe.serverCore.logic.IfMCOperation;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCServerThreadListener
/*    */ {
/*    */   public void logicBefore(IfMCOperation op) {}
/*    */   
/*    */   public void logicAfter(IfMCOperation op) {}
/*    */   
/*    */   public void handleAppException(IfMCOperation op, MCAppException e) {
/* 45 */     throw e;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void handleException(IfMCOperation op, MCException e) {
/* 57 */     throw e;
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\MCServerThreadListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */