/*     */ package mcframe.serverCore.requester.history;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.commonCore.container.MCConstRow;
/*     */ import mcframe.commonCore.container.MCExtMap;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class InfoR_FW_A
/*     */   extends MCConstRow
/*     */ {
/*     */   public static final String $ActionId = "ActionId";
/*     */   public static final String $MethodName = "MethodName";
/*  40 */   public static final MCMeta ActionId_META = createStringMeta("ActionId", 50);
/*  41 */   public static final MCMeta MethodName_META = createStringMeta("MethodName", 50);
/*     */   
/*  43 */   protected static final MCRow.ConstMetaList<InfoR> constMetas = new MCRow.ConstMetaList(
/*  44 */       MCConstRow.constMetas, 
/*  45 */       new MCMeta[] {
/*  46 */         ActionId_META, 
/*  47 */         MethodName_META
/*     */       },
/*  49 */       new String[][] { {}, {} });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   protected static final MCExtMap EXTMAP = new MCExtMap(
/*  62 */       null, new MCExtMap.Entry[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] colnames() {
/*  74 */     return constMetas.toNameArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMeta[] colmetas() {
/*  86 */     return constMetas.toMetaArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  92 */   private static final int offset = constMetas.offset();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getExtMap(String aGroup) {
/*  98 */     if (aGroup == null) return null; 
/*  99 */     return (Map<String, String>)EXTMAP.get(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> getKeys(String aGroup) {
/* 106 */     if (aGroup == null) return null; 
/* 107 */     return EXTMAP.getKeyList(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExtGroups() {
/* 114 */     Set<String> ret = EXTMAP.keySet();
/* 115 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected InfoR_FW_A(MCRow.ConstMetaList<? extends InfoR> metas) {
/* 122 */     super(metas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InfoR clone() {
/* 129 */     return (InfoR)super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InfoR createInstance() {
/* 136 */     return (InfoR)super.createInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InfoR getValues(String... names) {
/* 143 */     return (InfoR)super.getValues(names);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void fireValueChanged(String column, Comparable<?> newvalue, Comparable<?> oldvalue) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String ActionId() {
/* 159 */     return getConstString(offset + 0, "ActionId");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void ActionId(String value) {
/* 167 */     setConstString(offset + 0, "ActionId", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String MethodName() {
/* 176 */     return getConstString(offset + 1, "MethodName");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void MethodName(String value) {
/* 184 */     setConstString(offset + 1, "MethodName", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString(String name) {
/* 189 */     if ("ActionId".equalsIgnoreCase(name)) {
/* 190 */       return ActionId();
/*     */     }
/* 192 */     if ("MethodName".equalsIgnoreCase(name)) {
/* 193 */       return MethodName();
/*     */     }
/* 195 */     return super.getString(name);
/*     */   }
/*     */   
/*     */   public String getStringNE(String name) {
/* 199 */     if ("ActionId".equalsIgnoreCase(name)) {
/* 200 */       return ActionId();
/*     */     }
/* 202 */     if ("MethodName".equalsIgnoreCase(name)) {
/* 203 */       return MethodName();
/*     */     }
/* 205 */     return super.getStringNE(name);
/*     */   }
/*     */   
/*     */   public void setString(String name, String value) {
/* 209 */     if ("ActionId".equalsIgnoreCase(name)) {
/* 210 */       ActionId(value);
/*     */       return;
/*     */     } 
/* 213 */     if ("MethodName".equalsIgnoreCase(name)) {
/* 214 */       MethodName(value);
/*     */       return;
/*     */     } 
/* 217 */     super.setString(name, value);
/*     */   }
/*     */   
/*     */   public void setStringNE(String name, String value) {
/* 221 */     if ("ActionId".equalsIgnoreCase(name)) {
/* 222 */       ActionId(value);
/*     */       return;
/*     */     } 
/* 225 */     if ("MethodName".equalsIgnoreCase(name)) {
/* 226 */       MethodName(value);
/*     */       return;
/*     */     } 
/* 229 */     super.setStringNE(name, value);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\history\InfoR_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */