/*    */ package mcframe.serverCore.requester.history;
/*    */ 
/*    */ import mcframe.commonCore.param.MCBlockDef;
/*    */ import mcframe.commonCore.param.MCContainerDef;
/*    */ import mcframe.commonCore.param.MCDef;
/*    */ import mcframe.commonCore.param.MCGeneralContainerDef;
/*    */ import mcframe.commonCore.param.MCItemDef;
/*    */ import mcframe.commonCore.param.MCOperationInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PDef_FW_A
/*    */   extends MCDef
/*    */ {
/*    */   public MCContainerDef getCustomDef(String id) {
/* 22 */     if (id == null) {
/* 23 */       return null;
/*    */     }
/*    */     
/* 26 */     if (id.equals("FC.FCBHL0100.Exec.UP.BLOCK0")) {
/* 27 */       return FC_FCBHL0100_Exec_UP_BLOCK0();
/*    */     }
/* 29 */     if (id.equals("FC.FCBHL0100.Exec.DOWN.BLOCK0")) {
/* 30 */       return FC_FCBHL0100_Exec_DOWN_BLOCK0();
/*    */     }
/*    */ 
/*    */     
/* 34 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 40 */   static final MCOperationInfo FC_FCBHL0100_Exec_INFO = new MCOperationInfo("FC", "FCBHL0100", "Exec", "000000", new PDef());
/*    */ 
/*    */   
/*    */   public static MCContainerDef FC_FCBHL0100_Exec_UP_BLOCK0() {
/* 44 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBHL0100", "Exec", 
/* 45 */         new MCItemDef[] {
/* 46 */           MCItemDef.create("MethodName", "MethodName")
/*    */ 
/*    */         
/* 49 */         }MCBlockDef.create("Info"));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static MCContainerDef FC_FCBHL0100_Exec_DOWN_BLOCK0() {
/* 56 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBHL0100", "Exec", 
/* 57 */         new MCItemDef[] {
/* 58 */           MCItemDef.create("ActionId", "ActionId")
/*    */ 
/*    */         
/* 61 */         }MCBlockDef.create("Info"));
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\history\PDef_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */