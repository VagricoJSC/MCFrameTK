/*     */ package mcframe.serverCore.requester.history;
/*     */ 
/*     */ import mcframe.commonCore.container.MCContainer;
/*     */ import mcframe.commonCore.param.MCOperationInfo;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ import mcframe.serverCore.logic.MCLogic;
/*     */ import mcframe.serverCore.logic.MCLogicBase;
/*     */ import mcframe.serverCore.logic.MCLogicUtil;
/*     */ import mcframe.serverCore.logic.MCOperation;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MCHistoryRegister_FW_A
/*     */   extends MCLogicBase
/*     */ {
/*     */   public static final String MODULE_ID = "FC";
/*     */   public static final String SUBMODULE_ID = "FCBH";
/*     */   public static final String LOGIC_ID = "FCBHL0100";
/*     */   protected MCHistoryRegister_FW.Exec aExec;
/*     */   
/*     */   public String getModuleID() {
/*  42 */     return "FC";
/*     */   } public String getSubmoduleID() {
/*  44 */     return "FCBH";
/*     */   } public String getLogicID() {
/*  46 */     return "FCBHL0100";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initExec() {
/*  53 */     this.info = PDef.FC_FCBHL0100_Exec_INFO;
/*  54 */     ((MCHistoryRegister)this).getClass(); this.aExec = new MCHistoryRegister_FW.Exec((MCHistoryRegister)this);
/*     */   }
/*     */   
/*     */   public static MCHistoryRegister_FW.Exec crtExec() {
/*  58 */     MCHistoryRegister lgc = new MCHistoryRegister();
/*  59 */     lgc.initExec();
/*  60 */     return lgc.aExec;
/*     */   }
/*     */   
/*     */   protected void paramExec(MCParam p) {
/*  64 */     if (this.aExec == null) {
/*     */       return;
/*     */     }
/*  67 */     p.setDef(this.info.def);
/*  68 */     p.addUpBlock((MCContainer)this.aExec.up0());
/*  69 */     p.addDownBlock((MCContainer)this.aExec.down0());
/*     */   }
/*     */   
/*     */   protected void doExec() {
/*  73 */     this.aExec.call();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InfoR createInfoR() {
/*  82 */     return InfoR.create();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract class Exec
/*     */     extends MCOperation
/*     */   {
/*     */     public static final String OPERATION_ID = "Exec";
/*     */ 
/*     */ 
/*     */     
/*     */     private final InfoR up0;
/*     */ 
/*     */     
/*     */     private final InfoR down0;
/*     */ 
/*     */ 
/*     */     
/*     */     public String getOperationID() {
/* 103 */       return "Exec";
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected Exec() {
/* 116 */       this.up0 = InfoR.create();
/* 117 */       this.down0 = InfoR.create();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void mapUpContainers(String key) {
/* 131 */       super.mapUpContainers(key);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void mapDownContainers(String key) {
/* 139 */       super.mapDownContainers(key);
/*     */     }
/*     */     
/*     */     public MCContainer up(int i) {
/* 143 */       if (i == 0) return (MCContainer)up0(); 
/* 144 */       return null;
/*     */     }
/*     */     
/*     */     public MCContainer down(int i) {
/* 148 */       if (i == 0) return (MCContainer)down0(); 
/* 149 */       return null;
/*     */     }
/*     */     
/*     */     public void exec() {
/* 153 */       clear();
/* 154 */       MCLogicUtil.invoke((MCLogic)MCHistoryRegister_FW_A.this);
/*     */     }
/*     */     
/*     */     protected void clear() {
/* 158 */       down0().clear();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public InfoR createInfoR() {
/* 166 */       return InfoR.create();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public InfoR up0() {
/* 182 */       return this.up0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public InfoR down0() {
/* 198 */       return this.down0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MCOperationInfo getOperationInfo() {
/* 205 */       return MCHistoryRegister_FW_A.this.info;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\history\MCHistoryRegister_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */