/*     */ package mcframe.serverCore.requester.history;
/*     */ 
/*     */ import java.util.Map;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.sys.MCClientOperation;
/*     */ import mcframe.serverCore.dbc.FCT_OPRHISTORY_R;
/*     */ import mcframe.serverCore.mcjdbc.FWDBUtil;
/*     */ import mcframe.serverCore.mcjdbc.MCTransactionManager;
/*     */ import mcframe.serverCore.queryapi.MCDBContainer;
/*     */ import mcframe.serverCore.queryapi.MCQueryApiBuilder;
/*     */ import mcframe.serverCore.sys.MCSys;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MCHistoryRegister_FW
/*     */   extends MCHistoryRegister_FW_A
/*     */ {
/*     */   public class Exec
/*     */     extends MCHistoryRegister_FW_A.Exec
/*     */   {
/*     */     protected void call() {
/*  42 */       MCClientOperation cope = MCSys.request.clientOperation();
/*     */ 
/*     */       
/*  45 */       String action_id = FWDBUtil.getActionId();
/*     */ 
/*     */       
/*  48 */       FCT_OPRHISTORY_R r = FCT_OPRHISTORY_R.create("T");
/*     */       
/*  50 */       if (cope.getScreenID() != null && cope.getScreenID().trim().length() > 0) {
/*  51 */         r.screen_id(cope.getScreenID());
/*     */ 
/*     */         
/*  54 */         int s = cope.getScreenID().indexOf('.');
/*  55 */         if (s >= 0) {
/*  56 */           r.screen_name(cope.getScreenID().substring(s + 1));
/*     */         } else {
/*     */           
/*  59 */           r.screen_id("NoScreenID");
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/*  64 */         r.screen_id("NoScreenID");
/*     */       } 
/*     */       
/*  67 */       if (MCSys.user.ID() != null && MCSys.user.ID().trim().length() > 0) {
/*  68 */         r.user_id(MCSys.user.ID());
/*     */       } else {
/*     */         
/*  71 */         r.user_id("ANONYMOUS");
/*     */       } 
/*  73 */       r.operation_cd(cope.getOperationCD());
/*     */       
/*  75 */       r.button_name(up0().MethodName());
/*     */       
/*  77 */       r.button_label(cope.getLabel());
/*  78 */       r.access_ts(FWDBUtil.sysdate());
/*  79 */       r.action_id(action_id);
/*  80 */       r.machine(MCSys.request.clientId());
/*  81 */       r.co_cd(MCSys.user.coCD());
/*  82 */       r.ext_attr1(MCSys.user.extattr1());
/*  83 */       r.ext_attr2(MCSys.user.extattr2());
/*  84 */       r.ext_attr3(MCSys.user.extattr3());
/*     */       
/*  86 */       MCQueryApiBuilder builder = MCQueryApiBuilder.create((MCDBContainer)r);
/*  87 */       builder.buildInsert("FC_MCHistoryRegister_FW.Exec.call").executeUpdate((MCRow)r);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  97 */       MCSys.request.clientOperation().setActionID(action_id);
/*  98 */       ((Map<String, String>)MCTransactionManager.USER_CNTEXT.get()).put("action_id", action_id);
/*     */ 
/*     */       
/* 101 */       down0().ActionId(action_id);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\history\MCHistoryRegister_FW.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */