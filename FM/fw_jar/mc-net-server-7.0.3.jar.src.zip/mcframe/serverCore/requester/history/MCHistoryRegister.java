package mcframe.serverCore.requester.history;

import mcframe.commonCore.annotation.EI;

@EI
public class MCHistoryRegister extends MCHistoryRegister_FW {}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\history\MCHistoryRegister.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */