/*     */ package mcframe.serverCore.requester;
/*     */ 
/*     */ import mcframe.commonCore.container.MCContainerSignalManager;
/*     */ import mcframe.commonCore.container.MCVolumeManager;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCError;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.notice.MCMessageLevel;
/*     */ import mcframe.commonCore.pio.MCDPReaderFactory;
/*     */ import mcframe.commonCore.pio.MCE2TReader;
/*     */ import mcframe.commonCore.pio.util.MCDPFormat;
/*     */ import mcframe.commonCore.requester.MCDownloadUtil;
/*     */ import mcframe.commonCore.resource.MCLocaleConst;
/*     */ import mcframe.commonCore.resource.MCMessageConst;
/*     */ import mcframe.serverCore.resource.MCConfig;
/*     */ import mcframe.serverCore.sys.MCSys;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MCRequesterUtil
/*     */ {
/*     */   static String uploadPath() {
/*  41 */     return MCConfig.server.getString("net.download.dir", 
/*  42 */         MCDownloadUtil.downloadPath());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static MCException convertDispatcherExecuteException(Throwable t) {
/*  61 */     MCException me = null;
/*     */ 
/*     */     
/*  64 */     if (t instanceof OutOfMemoryError) {
/*     */       
/*  66 */       me = new MCException(t, Core_Msg_FW_A.FCBGC0047, new Object[0]);
/*     */     }
/*  68 */     else if (t instanceof MCError) {
/*     */       
/*  70 */       MCError err = (MCError)t;
/*  71 */       Throwable cause = err.getCause();
/*  72 */       if (cause != null && cause instanceof MCException) {
/*  73 */         MCException mce = (MCException)cause;
/*  74 */         String id = mce.getID();
/*  75 */         if (MCVolumeManager.isVolumeManageMessage(id) || MCContainerSignalManager.isInterruptedMessage(id))
/*     */         {
/*  77 */           me = mce;
/*     */         }
/*     */       } 
/*  80 */       if (me == null) {
/*  81 */         me = new MCException(t, Core_Msg_FW_A.FCBGC0033, new Object[0]);
/*     */       }
/*     */     }
/*  84 */     else if (t instanceof MCException) {
/*     */ 
/*     */       
/*  87 */       me = (MCException)t;
/*     */       
/*  89 */       me = MCMessageLevel.checkWrappedErrorLevel(me.getLevel()) ? 
/*  90 */         new MCException((Throwable)me, Core_Msg_FW_A.FCBGC0033, new Object[] { me.getID() }) : me;
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/*  96 */       me = new MCException(t, Core_Msg_FW_A.FCBGC0033, new Object[0]);
/*     */     } 
/*  98 */     MCLog.write(t);
/*  99 */     return me;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static MCException convertAfterOperationException(Throwable t) {
/* 118 */     MCException e = null;
/* 119 */     if (t instanceof MCException) {
/* 120 */       e = (MCException)t;
/* 121 */       if (MCStringUtil.eq(Core_Msg_FW_A.FCBGC0051, e.getID()))
/*     */       {
/* 123 */         return e;
/*     */       }
/* 125 */       e = new MCException(t, Core_Msg_FW_A.FCBGC0054, new Object[] { e.getID() });
/*     */     }
/* 127 */     else if (t instanceof MCError) {
/* 128 */       MCError err = (MCError)t;
/* 129 */       Throwable cause = err.getCause();
/* 130 */       if (cause != null && cause instanceof MCException) {
/* 131 */         MCException mce = (MCException)cause;
/* 132 */         String id = mce.getID();
/* 133 */         if (MCVolumeManager.isVolumeManageMessage(id)) {
/*     */           
/* 135 */           MCMessageConst msgConst = MCLocaleConst.message(MCSys.user.locale());
/* 136 */           e = new MCException(t, Core_Msg_FW_A.FCBGC0445, new Object[] {
/* 137 */                 mce.getMCMessage().toString(msgConst) });
/*     */         } 
/*     */       } 
/*     */     } 
/* 141 */     if (e == null)
/*     */     {
/* 143 */       e = new MCException(t, Core_Msg_FW_A.FCBGC0054, new Object[0]);
/*     */     }
/* 145 */     MCLog.write(t);
/* 146 */     return e;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String createInitExceptionText(Throwable t, MCDPFormat format) {
/* 161 */     MCE2TReader e2t = MCDPReaderFactory.downExceptionToText(format);
/* 162 */     return e2t.parse(Core_Msg_FW_A.FCBGC0044, t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String createExceptionText(Throwable t, MCDPFormat format) {
/* 179 */     MCE2TReader e2t = MCDPReaderFactory.downExceptionToText(format);
/* 180 */     return e2t.parse(t);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-net-server-7.0.3.jar!\mcframe\serverCore\requester\MCRequesterUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */