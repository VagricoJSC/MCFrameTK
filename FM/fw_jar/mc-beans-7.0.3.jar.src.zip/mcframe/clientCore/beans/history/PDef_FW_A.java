/*    */ package mcframe.clientCore.beans.history;
/*    */ 
/*    */ import mcframe.commonCore.param.MCContainerDef;
/*    */ import mcframe.commonCore.param.MCDef;
/*    */ import mcframe.commonCore.param.MCGeneralContainerDef;
/*    */ import mcframe.commonCore.param.MCItemDef;
/*    */ import mcframe.commonCore.param.MCOperationInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PDef_FW_A
/*    */   extends MCDef
/*    */ {
/*    */   public MCContainerDef getCustomDef(String id) {
/* 18 */     if (id == null) {
/* 19 */       return null;
/*    */     }
/*    */     
/* 22 */     if (id.equals("FC.FCBHL0100.Exec.UP.BLOCK0")) {
/* 23 */       return FC_FCBHL0100_Exec_UP_BLOCK0();
/*    */     }
/* 25 */     if (id.equals("FC.FCBHL0100.Exec.DOWN.BLOCK0")) {
/* 26 */       return FC_FCBHL0100_Exec_DOWN_BLOCK0();
/*    */     }
/*    */ 
/*    */     
/* 30 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 36 */   static final MCOperationInfo FC_FCBHL0100_Exec_INFO = new MCOperationInfo("FC", "FCBHL0100", "Exec", "000000", new PDef());
/*    */ 
/*    */   
/*    */   public static MCContainerDef FC_FCBHL0100_Exec_UP_BLOCK0() {
/* 40 */     return (MCContainerDef)new MCGeneralContainerDef(
/* 41 */         new MCItemDef[] {
/* 42 */           MCItemDef.create("MethodName", "MethodName")
/*    */         });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static MCContainerDef FC_FCBHL0100_Exec_DOWN_BLOCK0() {
/* 50 */     return (MCContainerDef)new MCGeneralContainerDef(
/* 51 */         new MCItemDef[] {
/* 52 */           MCItemDef.create("ActionId", "ActionId")
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\history\PDef_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */