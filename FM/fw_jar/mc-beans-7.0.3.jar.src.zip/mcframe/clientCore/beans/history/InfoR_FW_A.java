/*     */ package mcframe.clientCore.beans.history;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.clientCore.container.MCKeyList;
/*     */ import mcframe.commonCore.container.MCExtMap;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class InfoR_FW_A
/*     */   extends MCConstRow
/*     */ {
/*     */   public static final String $ActionId = "ActionId";
/*     */   public static final String $MethodName = "MethodName";
/*  31 */   public static final MCMeta ActionId_META = createStringMeta("ActionId", 50);
/*  32 */   public static final MCMeta MethodName_META = createStringMeta("MethodName", 50);
/*     */   
/*  34 */   protected static final MCRow.ConstMetaList<InfoR> constMetas = new MCRow.ConstMetaList(
/*  35 */       MCConstRow.constMetas, 
/*  36 */       new MCMeta[] {
/*  37 */         ActionId_META, 
/*  38 */         MethodName_META
/*     */       },
/*  40 */       new String[][] { {}, {} });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   protected static final MCKeyList KEYS = new MCKeyList(
/*  52 */       null, 
/*  53 */       new String[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   protected static final MCExtMap EXTMAP = new MCExtMap(
/*  62 */       null, new MCExtMap.Entry[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] colnames() {
/*  74 */     return constMetas.toNameArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMeta[] colmetas() {
/*  86 */     return constMetas.toMetaArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  92 */   private static final int offset = constMetas.offset();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCKeyList getKeys() {
/*  98 */     return KEYS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getExtMap(String aGroup) {
/* 105 */     if (aGroup == null) return null; 
/* 106 */     return (Map<String, String>)EXTMAP.get(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCKeyList getKeys(String aGroup) {
/* 113 */     if (aGroup == null) return null; 
/* 114 */     return new MCKeyList(EXTMAP.getKeyList(aGroup));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExtGroups() {
/* 121 */     Set<String> ret = EXTMAP.keySet();
/* 122 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected InfoR_FW_A(MCRow.ConstMetaList<? extends InfoR> metas) {
/* 129 */     super(metas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InfoR clone() {
/* 136 */     return (InfoR)super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InfoR createInstance() {
/* 143 */     return (InfoR)super.createInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InfoR getValues(String... names) {
/* 150 */     return (InfoR)super.getValues(names);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String ActionId() {
/* 161 */     return getConstString(offset + 0, "ActionId");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void ActionId(String value) {
/* 170 */     setConstString(offset + 0, "ActionId", value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String MethodName() {
/* 180 */     return getConstString(offset + 1, "MethodName");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void MethodName(String value) {
/* 189 */     setConstString(offset + 1, "MethodName", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString(String name) {
/* 194 */     if ("ActionId".equalsIgnoreCase(name)) {
/* 195 */       return ActionId();
/*     */     }
/* 197 */     if ("MethodName".equalsIgnoreCase(name)) {
/* 198 */       return MethodName();
/*     */     }
/* 200 */     return super.getString(name);
/*     */   }
/*     */   
/*     */   public String getStringNE(String name) {
/* 204 */     if ("ActionId".equalsIgnoreCase(name)) {
/* 205 */       return ActionId();
/*     */     }
/* 207 */     if ("MethodName".equalsIgnoreCase(name)) {
/* 208 */       return MethodName();
/*     */     }
/* 210 */     return super.getStringNE(name);
/*     */   }
/*     */   
/*     */   public void setString(String name, String value) {
/* 214 */     if ("ActionId".equalsIgnoreCase(name)) {
/* 215 */       ActionId(value);
/*     */       return;
/*     */     } 
/* 218 */     if ("MethodName".equalsIgnoreCase(name)) {
/* 219 */       MethodName(value);
/*     */       return;
/*     */     } 
/* 222 */     super.setString(name, value);
/*     */   }
/*     */   
/*     */   public void setStringNE(String name, String value) {
/* 226 */     if ("ActionId".equalsIgnoreCase(name)) {
/* 227 */       ActionId(value);
/*     */       return;
/*     */     } 
/* 230 */     if ("MethodName".equalsIgnoreCase(name)) {
/* 231 */       MethodName(value);
/*     */       return;
/*     */     } 
/* 234 */     super.setStringNE(name, value);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\history\InfoR_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */