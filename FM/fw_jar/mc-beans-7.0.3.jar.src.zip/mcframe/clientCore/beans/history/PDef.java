package mcframe.clientCore.beans.history;

import mcframe.commonCore.annotation.EI;

@EI
public class PDef extends PDef_FW_A {}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\history\PDef.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */