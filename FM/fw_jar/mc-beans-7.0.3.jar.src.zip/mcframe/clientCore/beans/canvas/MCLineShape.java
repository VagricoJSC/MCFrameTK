/*     */ package mcframe.clientCore.beans.canvas;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.Stroke;
/*     */ import java.awt.geom.GeneralPath;
/*     */ import java.awt.geom.Point2D;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCLineShape
/*     */   extends MCPlane
/*     */ {
/*  25 */   private int _pointCount = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  32 */   private int _incruseUnit = 10;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  39 */   protected Point2D[] _points = new Point2D[this._incruseUnit];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean _close = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCLineShape(Point2D[] points) {
/*  62 */     this.shape = new GeneralPath();
/*     */     
/*  64 */     if (points == null) {
/*  65 */       points = new Point2D[0];
/*     */     }
/*  67 */     increaseCapacity(points.length); byte b; int i; Point2D[] arrayOfPoint2D;
/*  68 */     for (i = (arrayOfPoint2D = points).length, b = 0; b < i; ) { Point2D point = arrayOfPoint2D[b];
/*  69 */       addPoint((point != null) ? (Point2D)point.clone() : point);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBounds(int x, int y, int width, int height) {
/*  76 */     Rectangle org = getBounds();
/*  77 */     super.setBounds(x, y, width, height);
/*     */ 
/*     */ 
/*     */     
/*  81 */     double raito_x = this.w / org.getWidth();
/*  82 */     double raito_y = this.h / org.getHeight();
/*  83 */     int diff_x = this.x - org.x;
/*  84 */     int diff_y = this.y - org.y;
/*  85 */     for (int i = 0; i < this._pointCount; i++) {
/*  86 */       Point2D point = this._points[i];
/*  87 */       if (point != null) {
/*  88 */         double newx = point.getX() + diff_x;
/*  89 */         double newy = point.getY() + diff_y;
/*  90 */         newx = this.x + (newx - this.x) * raito_x;
/*  91 */         newy = this.y + (newy - this.y) * raito_y;
/*  92 */         this._points[i] = new Point2D.Double(newx, newy);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  97 */     updateShape();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void cloneImpl(MCShape base) {
/* 102 */     super.cloneImpl(base);
/*     */ 
/*     */     
/* 105 */     this.shape = new GeneralPath();
/* 106 */     Point2D[] org = this._points;
/* 107 */     this._points = new Point2D[this._points.length];
/* 108 */     for (int i = 0; i < org.length; i++) {
/* 109 */       this._points[i] = (org[i] != null) ? (Point2D)org[i].clone() : null;
/*     */     }
/* 111 */     updateShape();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void updateShape() {
/* 122 */     GeneralPath path = (GeneralPath)this.shape;
/* 123 */     path.reset();
/* 124 */     this._close = true;
/* 125 */     for (int i = 0; i < this._pointCount; i++) {
/* 126 */       Point2D point = this._points[i];
/* 127 */       modifyPath(point);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addPoint(Point2D point) {
/* 145 */     increaseCapacity(this._pointCount + 1);
/* 146 */     this._points[this._pointCount] = point;
/* 147 */     this._pointCount++;
/*     */ 
/*     */     
/* 150 */     modifyPath(point);
/*     */ 
/*     */     
/* 153 */     if (point != null) {
/* 154 */       int addX = (int)point.getX();
/* 155 */       int addY = (int)point.getY();
/* 156 */       if (this._pointCount <= 1) {
/*     */         
/* 158 */         this.x = addX;
/* 159 */         this.y = addY;
/* 160 */         this.w = 0;
/* 161 */         this.h = 0;
/*     */       }
/*     */       else {
/*     */         
/* 165 */         if (addX < this.x) {
/* 166 */           this.w += this.x - addX;
/* 167 */           this.x = addX;
/*     */         }
/* 169 */         else if (this.x + this.w < addX) {
/* 170 */           this.w = addX - this.x;
/*     */         } 
/*     */         
/* 173 */         if (addY < this.y) {
/* 174 */           this.h += this.y - addY;
/* 175 */           this.y = addY;
/*     */         }
/* 177 */         else if (this.y + this.h < addY) {
/* 178 */           this.h = addY - this.y;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void modifyPath(Point2D point) {
/* 192 */     GeneralPath path = (GeneralPath)this.shape;
/*     */     
/* 194 */     if (point == null) {
/*     */       
/* 196 */       path.closePath();
/* 197 */       this._close = true;
/*     */       
/*     */       return;
/*     */     } 
/* 201 */     if (this._close) {
/* 202 */       path.moveTo(point.getX(), point.getY());
/* 203 */       this._close = false;
/*     */     } else {
/*     */       
/* 206 */       path.lineTo(point.getX(), point.getY());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isClose() {
/* 218 */     return this._close;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void increaseCapacity(int length) {
/* 232 */     if (length <= this._points.length) {
/*     */       return;
/*     */     }
/*     */     
/* 236 */     int unit = length / this._incruseUnit;
/* 237 */     if (length % this._incruseUnit > 0) {
/* 238 */       unit++;
/*     */     }
/* 240 */     this._points = Arrays.<Point2D>copyOf(this._points, this._incruseUnit * unit);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\canvas\MCLineShape.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */