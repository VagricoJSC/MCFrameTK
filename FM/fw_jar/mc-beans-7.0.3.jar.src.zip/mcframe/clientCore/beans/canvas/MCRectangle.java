/*    */ package mcframe.clientCore.beans.canvas;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.awt.Rectangle;
/*    */ import java.awt.Stroke;
/*    */ import java.awt.geom.Rectangle2D;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCRectangle
/*    */   extends MCPlane
/*    */ {
/*    */   public MCRectangle() {
/* 24 */     this(0, 0, 0, 0);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MCRectangle(int x, int y, int width, int height) {
/* 36 */     this.shape = new Rectangle2D.Double();
/*    */     
/* 38 */     setBounds(x, y, width, height);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void cloneImpl(MCShape base) {
/* 44 */     super.cloneImpl(base);
/*    */ 
/*    */     
/* 47 */     this.shape = new Rectangle2D.Double();
/* 48 */     setBounds(base.getBounds());
/*    */   }
/*    */ 
/*    */   
/*    */   public void setBounds(int x, int y, int width, int height) {
/* 53 */     super.setBounds(x, y, width, height);
/*    */ 
/*    */     
/* 56 */     Rectangle2D r = (Rectangle2D)this.shape;
/* 57 */     r.setFrame(this.x, this.y, this.w, this.h);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\canvas\MCRectangle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */