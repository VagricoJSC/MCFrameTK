/*     */ package mcframe.clientCore.beans.canvas;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.FlowLayout;
/*     */ import java.util.Arrays;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JToolBar;
/*     */ import mcframe.clientCore.beans.MCBeansCompatibilityFactory;
/*     */ import mcframe.clientCore.beans.MCButton;
/*     */ import mcframe.clientCore.beans.MCCanvas;
/*     */ import mcframe.clientCore.event.MCEventListener;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCCanvasToolBar
/*     */ {
/*     */   private MCCanvas _canvas;
/*     */   private MCEventListener _listener;
/*     */   private final JToolBar _base;
/*  56 */   private MCButton[] _buttons = new MCButton[10];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean _floatable = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCCanvasToolBar(MCCanvas canvas) {
/*  74 */     this._canvas = canvas;
/*     */     
/*  76 */     String name = String.valueOf((this._canvas != null) ? this._canvas.getName() : "null") + "_toolbar";
/*  77 */     this._base = new JToolBar(name);
/*  78 */     this._base.setLayout(new FlowLayout(0, 0, 0));
/*  79 */     this._base.setFloatable(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCCanvas getCanvas() {
/*  90 */     return this._canvas;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JComponent getComponent() {
/* 101 */     return this._base;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 114 */     return this._base.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEventListener(MCEventListener listener) {
/* 125 */     this._listener = listener;
/* 126 */     for (int i = 0; i < this._buttons.length; i++) {
/* 127 */       if (this._buttons[i] != null) {
/* 128 */         this._buttons[i].addAllListener(this._listener);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVisible(boolean b) {
/* 141 */     this._base.setVisible(b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void ensureCapacity(int id) {
/* 157 */     if (id >= this._buttons.length) {
/* 158 */       this._buttons = Arrays.<MCButton>copyOf(this._buttons, id + 1);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JButton getButton(int id) {
/* 171 */     if (id <= this._buttons.length - 1) {
/* 172 */       return (JButton)this._buttons[id];
/*     */     }
/* 174 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getButtonID(Object b) {
/* 186 */     for (int i = 0; i < this._buttons.length; i++) {
/* 187 */       if (this._buttons[i] == b) {
/* 188 */         return i;
/*     */       }
/*     */     } 
/* 191 */     return Integer.MIN_VALUE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Icon getButtonIcon(int id) {
/* 203 */     JButton b = getButton(id);
/* 204 */     if (b != null) {
/* 205 */       b.getIcon();
/*     */     }
/* 207 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setButtonVisible(int id, boolean visible) {
/* 221 */     JButton b = getButton(id);
/* 222 */     if (b != null) {
/* 223 */       b.setVisible(visible);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setButtonEnabled(int id, boolean enable) {
/* 238 */     JButton b = getButton(id);
/* 239 */     if (b != null) {
/* 240 */       b.setEnabled(enable);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFloatable(boolean floatable) {
/* 252 */     this._floatable = floatable;
/* 253 */     Component[] compos = this._base.getComponents(); byte b; int i; Component[] arrayOfComponent1;
/* 254 */     for (i = (arrayOfComponent1 = compos).length, b = 0; b < i; ) { Component compo = arrayOfComponent1[b];
/* 255 */       if (compo instanceof JToolBar) {
/* 256 */         ((JToolBar)compo).setFloatable(this._floatable);
/*     */       }
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public GroupBar addGroup(String name) {
/* 271 */     GroupBar child = new GroupBar(name, this, null);
/* 272 */     this._base.add(child._bar);
/* 273 */     return child;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class GroupBar
/*     */   {
/*     */     private MCCanvasToolBar _parent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private final JToolBar _bar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private GroupBar(String name, MCCanvasToolBar parent) {
/* 305 */       this._parent = parent;
/* 306 */       this._bar = new JToolBar(name);
/* 307 */       this._bar.setLayout(new FlowLayout(0, 5, 0));
/* 308 */       this._bar.setFloatable(parent._floatable);
/* 309 */       this._bar.setRollover(true);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void setVisible(boolean visible) {
/* 320 */       this._bar.setVisible(visible);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void addSeparator() {
/* 330 */       this._bar.addSeparator();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private MCButton createButton(int id, String reskey) {
/* 343 */       MCButton b = MCBeansCompatibilityFactory.createButton("canvas_tool_" + id, "toolbar");
/* 344 */       b.setIcon(reskey);
/* 345 */       b.addAllListener(this._parent._listener);
/* 346 */       String tooltipKey = MCConst.createKey(new String[] { reskey, "message" });
/* 347 */       String text = MCConst.label.getLabel(tooltipKey);
/* 348 */       b.setToolTipText(text);
/* 349 */       return b;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void addButton(int id, String reskey) {
/* 385 */       this._parent.ensureCapacity(id);
/* 386 */       MCButton b = createButton(id, reskey);
/* 387 */       this._parent._buttons[id] = b;
/* 388 */       this._bar.add((Component)b);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\canvas\MCCanvasToolBar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */