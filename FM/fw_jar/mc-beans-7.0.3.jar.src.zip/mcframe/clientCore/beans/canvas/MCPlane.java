/*     */ package mcframe.clientCore.beans.canvas;
/*     */ 
/*     */ import java.awt.AlphaComposite;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Image;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.Stroke;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.ImageObserver;
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import javax.imageio.ImageIO;
/*     */ import mcframe.clientCore.beans.MCCanvas;
/*     */ import mcframe.clientCore.beans.MCLabel;
/*     */ import mcframe.clientCore.requester.MCDownloader;
/*     */ import mcframe.commonCore.lang.MCBinary;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MCPlane
/*     */   extends MCShape
/*     */ {
/*     */   public static final String PROPERTY_LOCATION = "location";
/*     */   public static final String PROPERTY_SIZE = "size";
/*  56 */   private Color _fill_color = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCLabel _text;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   private BufferedImage _image = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   private MCBinary _imagebin = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  85 */   protected int min_w = 10;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  92 */   protected int min_h = 10;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  99 */   protected int default_w = 100;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 106 */   protected int default_h = 100;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCPlane() {
/* 116 */     this._text = createTextDrawer();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCShapeSelector<?> createSelector(MCCanvas canvas) {
/* 121 */     return new MCPlaneSelector(canvas, this);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCShapeEditor<?> createEditor(MCCanvas canvas) {
/* 126 */     return new MCPlaneEditor(canvas, this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void cloneImpl(MCShape base) {
/* 132 */     this._text = createTextDrawer();
/* 133 */     setText(((MCPlane)base).getText());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCLabel createTextDrawer() {
/* 144 */     MCLabel text = new MCLabel("text");
/* 145 */     text.setOpaque(false);
/* 146 */     text.setText(null);
/* 147 */     text.setVerticalAlignment(0);
/* 148 */     text.setHorizontalAlignment(0);
/* 149 */     return text;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setText(String text) {
/* 160 */     this._text.setText(text);
/* 161 */     Dimension size = this._text.getPreferredSize();
/* 162 */     this._text.setSize(size);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText() {
/* 173 */     return this._text.getLabelByLocale();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTextFont(Font font) {
/* 184 */     this._text.setFont(font);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Font getTextFont() {
/* 195 */     return this._text.getFont();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTextColor(Color c) {
/* 206 */     this._text.setForeground(c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getTextColor() {
/* 217 */     return this._text.getForeground();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTextVerticalAlignment(int alignment) {
/* 229 */     this._text.setVerticalAlignment(alignment);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTextVerticalAlignment() {
/* 241 */     return this._text.getVerticalAlignment();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFillColor(Color c) {
/* 263 */     this._fill_color = c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getFillColor() {
/* 276 */     return this._fill_color;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setImage(MCBinary bin) {
/* 287 */     this._imagebin = bin;
/* 288 */     this._image = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCBinary getImage() {
/* 299 */     return this._imagebin;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean initBounds(MCCanvas canvas, int x, int y) {
/* 304 */     Rectangle r = getBounds();
/* 305 */     Dimension d = getMinSize();
/* 306 */     r.x = x;
/* 307 */     r.y = y;
/* 308 */     r.width = d.width;
/* 309 */     r.height = d.height;
/* 310 */     setBounds(r);
/* 311 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBounds(Rectangle r) {
/* 328 */     setBounds(r.x, r.y, r.width, r.height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBounds(int x, int y, int width, int height) {
/* 349 */     if (width < this.min_w) {
/* 350 */       width = this.min_w;
/*     */     }
/* 352 */     if (height < this.min_h) {
/* 353 */       height = this.min_h;
/*     */     }
/*     */     
/* 356 */     Point oldp = new Point(this.x, this.y);
/* 357 */     Dimension oldd = new Dimension(this.w, this.h);
/*     */     
/* 359 */     this.x = x;
/* 360 */     this.y = y;
/* 361 */     this.w = width;
/* 362 */     this.h = height;
/*     */     
/* 364 */     Point newp = (this.x != oldp.x || this.y != oldp.y) ? 
/* 365 */       new Point(this.x, this.y) : null;
/* 366 */     Dimension newd = (this.w != oldd.width || this.h != oldd.height) ? 
/* 367 */       new Dimension(this.w, this.h) : null;
/* 368 */     if (newp != null) {
/* 369 */       firePropertyChange("location", oldp, newp);
/*     */     }
/* 371 */     if (newd != null) {
/* 372 */       firePropertyChange("size", oldd, newd);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension getMinSize() {
/* 384 */     return new Dimension(this.min_w, this.min_h);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMinSize(Dimension d) {
/* 397 */     setMinSize(d.width, d.height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMinSize(int width, int height) {
/* 412 */     this.min_w = (width < 0) ? 0 : width;
/* 413 */     if (this.min_w > this.default_w) {
/* 414 */       this.default_w = this.min_w;
/*     */     }
/* 416 */     this.min_h = (height < 0) ? 0 : height;
/* 417 */     if (this.min_h > this.default_h) {
/* 418 */       this.default_h = this.min_h;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension getDefaultSize() {
/* 431 */     return new Dimension(this.default_w, this.default_h);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultSize(Dimension d) {
/* 444 */     setDefaultSize(d.width, d.height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDefaultSize(int width, int height) {
/* 458 */     this.default_w = (width < this.min_w) ? this.min_w : width;
/* 459 */     this.default_h = (height < this.min_h) ? this.min_h : height;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getStatusText() {
/* 469 */     return "x[" + this.x + "] y[" + this.y + "] " + 
/* 470 */       "width[" + this.w + "] height[" + this.h + "]";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void paint(Graphics2D g2) {
/* 476 */     if (this.shape == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 482 */     Rectangle bk_clip = g2.getClipBounds();
/* 483 */     Color bk_color = g2.getColor();
/* 484 */     Stroke bk_stroke = g2.getStroke();
/*     */ 
/*     */     
/* 487 */     paintShape(g2);
/*     */ 
/*     */     
/* 490 */     paintText(g2);
/*     */ 
/*     */     
/* 493 */     g2.setStroke(bk_stroke);
/* 494 */     g2.setColor(bk_color);
/* 495 */     g2.setClip(bk_clip);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintShape(Graphics2D g2) {
/* 507 */     g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, 
/* 508 */         RenderingHints.VALUE_ANTIALIAS_ON);
/*     */ 
/*     */     
/* 511 */     Stroke stroke = getStroke();
/*     */ 
/*     */     
/* 514 */     Rectangle shape_rect = stroke.createStrokedShape(this.shape).getBounds();
/* 515 */     Rectangle clip = g2.getClipBounds();
/* 516 */     clip = clip.intersection(shape_rect);
/* 517 */     if (clip.isEmpty()) {
/*     */       return;
/*     */     }
/*     */     
/* 521 */     g2.clipRect(clip.x, clip.y, clip.width, clip.height);
/*     */ 
/*     */     
/* 524 */     Color fill = getFillColor();
/* 525 */     if (fill != null) {
/* 526 */       g2.setPaint(fill);
/* 527 */       g2.fill(this.shape);
/*     */     } 
/*     */ 
/*     */     
/* 531 */     paintImage(g2);
/*     */ 
/*     */     
/* 534 */     Color line = getLineColor();
/* 535 */     if (line != null) {
/* 536 */       g2.setStroke(stroke);
/* 537 */       g2.setPaint(line);
/* 538 */       g2.draw(this.shape);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintImage(Graphics2D g2) {
/* 552 */     if (this._imagebin == null) {
/*     */       return;
/*     */     }
/* 555 */     if (this._image == null) {
/*     */       
/* 557 */       URL url = MCDownloader.getBinaryURL(this._imagebin);
/* 558 */       if (url == null) {
/*     */         return;
/*     */       }
/*     */       
/*     */       try {
/* 563 */         this._image = ImageIO.read(url);
/*     */       }
/* 565 */       catch (IOException e) {
/* 566 */         MCLog.write(e);
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     
/* 573 */     Rectangle sr = this.shape.getBounds();
/* 574 */     int iw = this._image.getWidth();
/* 575 */     int ih = this._image.getHeight();
/* 576 */     double p = Math.min(sr.getWidth() / iw, sr.getHeight() / ih);
/* 577 */     iw = (int)(iw * p);
/* 578 */     ih = (int)(ih * p);
/*     */ 
/*     */     
/* 581 */     int offset_x = sr.x + (sr.width - iw) / 2;
/* 582 */     int offset_y = sr.y + (sr.height - ih) / 2;
/*     */ 
/*     */     
/* 585 */     Image img = this._image.getScaledInstance(iw, ih, 4);
/*     */ 
/*     */     
/* 588 */     BufferedImage img2 = new BufferedImage(iw, ih, 2);
/* 589 */     Graphics2D ig = img2.createGraphics();
/*     */ 
/*     */     
/* 592 */     ig.translate(-offset_x, -offset_y);
/* 593 */     ig.setPaint(Color.LIGHT_GRAY);
/* 594 */     ig.fill(this.shape);
/* 595 */     ig.translate(offset_x, offset_y);
/*     */ 
/*     */     
/* 598 */     ig.setComposite(AlphaComposite.SrcIn);
/* 599 */     ig.drawImage(img, 0, 0, (ImageObserver)null);
/* 600 */     ig.dispose();
/*     */ 
/*     */     
/* 603 */     g2.translate(offset_x, offset_y);
/* 604 */     g2.drawImage(img2, 0, 0, (ImageObserver)null);
/* 605 */     g2.translate(-offset_x, -offset_y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintText(Graphics2D g2) {
/* 616 */     String text = this._text.getLabelByLocale();
/* 617 */     if (text == null || text.length() <= 0) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 623 */     g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, 
/* 624 */         RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
/*     */ 
/*     */     
/* 627 */     Stroke stroke = getStroke();
/* 628 */     Rectangle text_rect = stroke.createStrokedShape(this.shape).getBounds();
/* 629 */     float text_offset = getLineWidth();
/* 630 */     text_rect.x = (int)(text_rect.x + text_offset);
/* 631 */     text_rect.y = (int)(text_rect.y + text_offset);
/* 632 */     text_rect.width = (int)(text_rect.width - text_offset * 2.0F - 1.0F);
/* 633 */     text_rect.height = (int)(text_rect.height - text_offset * 2.0F - 1.0F);
/* 634 */     Rectangle clip = g2.getClipBounds();
/* 635 */     clip = clip.intersection(text_rect);
/* 636 */     if (clip.isEmpty()) {
/*     */       return;
/*     */     }
/*     */     
/* 640 */     g2.clipRect(clip.x, clip.y, clip.width, clip.height);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 649 */     Point p = getTextAlignmentLocation(text_rect);
/* 650 */     g2.translate(p.x, p.y);
/* 651 */     this._text.paint(g2);
/* 652 */     g2.translate(-p.x, -p.y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Point getTextAlignmentLocation(Rectangle rect) {
/* 669 */     Point p = new Point();
/* 670 */     Dimension size = this._text.getSize();
/*     */     
/* 672 */     p.x = rect.x + (rect.width - size.width) / 2;
/* 673 */     if (rect.width < size.width)
/*     */     {
/* 675 */       p.x = rect.x;
/*     */     }
/*     */     
/* 678 */     int v = this._text.getVerticalAlignment();
/* 679 */     if (rect.height < size.height)
/*     */     {
/* 681 */       v = 1;
/*     */     }
/* 683 */     switch (v)
/*     */     { case 1:
/* 685 */         p.y = rect.y;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 695 */         return p;case 3: p.y = rect.y + rect.height - size.height; return p; }  p.y = rect.y + (rect.height - size.height) / 2; return p;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\canvas\MCPlane.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */