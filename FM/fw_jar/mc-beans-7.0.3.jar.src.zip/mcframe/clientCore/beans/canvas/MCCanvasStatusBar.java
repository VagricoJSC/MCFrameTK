/*    */ package mcframe.clientCore.beans.canvas;
/*    */ 
/*    */ import mcframe.clientCore.beans.MCCanvas;
/*    */ import mcframe.clientCore.beans.statusbar.MCStatusBar;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCCanvasStatusBar
/*    */   extends MCStatusBar
/*    */ {
/*    */   private MCCanvas _canvas;
/*    */   
/*    */   public MCCanvasStatusBar(String name) {
/* 34 */     super(name);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void addTo(MCCanvas canvas) {
/* 48 */     this._canvas = canvas;
/* 49 */     this._canvas.add(getComponent(), "South");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setVisible(boolean b) {
/* 60 */     getComponent().setVisible(b);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\canvas\MCCanvasStatusBar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */