/*     */ package mcframe.clientCore.beans.canvas;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Cursor;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.Stroke;
/*     */ import java.awt.event.MouseEvent;
/*     */ import mcframe.clientCore.beans.MCCanvas;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCConnectorSelector
/*     */   extends MCShapeSelector<MCConnector>
/*     */ {
/*     */   private final int _thick;
/*     */   private boolean _drag;
/*     */   private boolean _direction;
/*     */   private MCPlane _target;
/*     */   
/*     */   public void resetBounds() {
/*     */     int offset = this._thick / 2;
/*     */     Rectangle r = this.shape.getBounds();
/*     */     this.x = r.x - offset;
/*     */     this.y = r.y - offset;
/*     */     this.w = r.width + offset * 2;
/*     */     this.h = r.height + offset * 2;
/*     */   }
/*     */   
/*     */   protected MCConnectorSelector(MCCanvas canvas, MCConnector conn) {
/*  42 */     super(canvas, conn);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  89 */     this._drag = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  97 */     this._direction = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 105 */     this._target = null;
/*     */     this._thick = 9;
/*     */     setLineColor(Color.RED);
/*     */     resetBounds();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean direction() {
/* 115 */     return this._direction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isResizeDirection(Point p) {
/*     */     return getShape().canSelect(p.x, p.y);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   MCPlane getTarget() {
/* 128 */     return this._target;
/*     */   } protected void paintSelector(Graphics2D g2) { g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON); g2.setColor(getLineColor()); Point p_s = this.shape.getStartPoint();
/*     */     Point p_e = this.shape.getEndPoint();
/*     */     int offset = this._thick / 2;
/*     */     g2.fillArc(p_s.x - offset, p_s.y - offset, this._thick, this._thick, 0, 360);
/* 133 */     g2.fillArc(p_e.x - offset, p_e.y - offset, this._thick, this._thick, 0, 360); } protected void setCursor(MouseEvent e, MCCanvas canvas) { canvas.setCursor(Cursor.getPredefinedCursor(1)); }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void mousePressed(MouseEvent e, MCCanvas canvas, Point start) {
/* 138 */     Point p = e.getPoint();
/* 139 */     Point[] halfs = this.shape.getHalfPoints();
/* 140 */     if (this.shape.canSelectStart(p.x, p.y)) {
/*     */       
/* 142 */       this._direction = ((this.shape.getStartPoint()).x == (halfs[0]).x);
/* 143 */       this._target = this.shape.getStartPlane();
/*     */     }
/* 145 */     else if (this.shape.canSelectEnd(p.x, p.y)) {
/*     */       
/* 147 */       this._direction = ((this.shape.getEndPoint()).x == (halfs[1]).x);
/* 148 */       this._target = this.shape.getEndPlane();
/*     */     }
/* 150 */     else if (this.shape.canSelectHalf(p.x, p.y)) {
/*     */       
/* 152 */       Point spoint = halfs[0];
/* 153 */       Point epoint = halfs[1];
/* 154 */       this._direction = (spoint.x == epoint.x);
/* 155 */       this._target = this._direction ? (
/* 156 */         (Math.abs(p.y - spoint.y) < Math.abs(p.y - epoint.y)) ? 
/* 157 */         this.shape.getStartPlane() : this.shape.getEndPlane()) : (
/* 158 */         (Math.abs(p.x - spoint.x) < Math.abs(p.x - epoint.x)) ? 
/* 159 */         this.shape.getStartPlane() : this.shape.getEndPlane());
/*     */     }
/*     */     else {
/*     */       
/* 163 */       this._target = null;
/* 164 */       this._direction = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void mouseDragged(MouseEvent e, MCCanvas canvas, Point start) {
/* 170 */     if (this._target == null) {
/*     */       return;
/*     */     }
/*     */     
/* 174 */     if (!this._drag)
/*     */     {
/* 176 */       canvas.createEditorShape(this.shape);
/*     */     }
/*     */ 
/*     */     
/* 180 */     Point orgPoint = start;
/* 181 */     Point newPoint = e.getPoint();
/* 182 */     canvas.resizeEditorShape(this.shape, orgPoint, newPoint, this);
/*     */ 
/*     */     
/* 185 */     this._drag = true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void mouseReleased(MouseEvent e, MCCanvas canvas, Point start) {
/* 191 */     canvas.commitEditorShape(getShape());
/*     */ 
/*     */     
/* 194 */     canvas.removeEditorShapes();
/*     */ 
/*     */     
/* 197 */     this._drag = false;
/* 198 */     this._target = null;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\canvas\MCConnectorSelector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */