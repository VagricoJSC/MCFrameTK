/*     */ package mcframe.clientCore.beans.canvas;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.Stroke;
/*     */ import java.awt.geom.GeneralPath;
/*     */ import java.awt.geom.Point2D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCPolygon
/*     */   extends MCPlane
/*     */ {
/*     */   protected Point2D[] _points;
/*     */   private final Point2D[] _defaultPoint;
/*     */   private final Rectangle _defaultRect;
/*     */   
/*     */   public MCPolygon(Point2D[] points) {
/*  53 */     this.shape = new GeneralPath();
/*  54 */     this._points = (points == null) ? new Point2D[0] : (Point2D[])points.clone();
/*  55 */     for (int i = 0; i < this._points.length; i++) {
/*  56 */       this._points[i] = (this._points[i] != null) ? 
/*  57 */         (Point2D)this._points[i].clone() : null;
/*     */     }
/*  59 */     updateShape();
/*     */ 
/*     */     
/*  62 */     this._defaultPoint = (Point2D[])this._points.clone();
/*  63 */     this._defaultRect = getBounds();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateShape() {
/*  74 */     GeneralPath path = (GeneralPath)this.shape;
/*  75 */     path.reset();
/*  76 */     for (int i = 0; i < this._points.length; i++) {
/*  77 */       Point2D point = this._points[i];
/*  78 */       if (point == null) {
/*     */         break;
/*     */       }
/*     */ 
/*     */       
/*  83 */       if (i == 0) {
/*  84 */         path.moveTo(point.getX(), point.getY());
/*     */       } else {
/*     */         
/*  87 */         path.lineTo(point.getX(), point.getY());
/*     */       } 
/*     */     } 
/*  90 */     path.closePath();
/*     */     
/*  92 */     updateBounds();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateBounds() {
/* 103 */     Point oldp = new Point(this.x, this.y);
/* 104 */     Dimension oldd = new Dimension(this.w, this.h);
/*     */ 
/*     */     
/* 107 */     this.x = 0;
/* 108 */     this.y = 0;
/* 109 */     this.w = 0;
/* 110 */     this.h = 0;
/*     */     
/* 112 */     for (int i = 0; i < this._points.length; i++) {
/* 113 */       Point2D point = this._points[i];
/* 114 */       if (point == null) {
/*     */         break;
/*     */       }
/*     */ 
/*     */       
/* 119 */       int addX = (int)point.getX();
/* 120 */       int addY = (int)point.getY();
/* 121 */       if (this.w == 0 && this.h == 0) {
/*     */         
/* 123 */         this.x = addX;
/* 124 */         this.y = addY;
/* 125 */         this.w = 1;
/* 126 */         this.h = 1;
/*     */       }
/*     */       else {
/*     */         
/* 130 */         if (addX < this.x) {
/* 131 */           this.w += this.x - addX;
/* 132 */           this.x = addX;
/*     */         }
/* 134 */         else if (this.x + this.w - 1 < addX) {
/* 135 */           this.w = addX - this.x + 1;
/*     */         } 
/*     */         
/* 138 */         if (addY < this.y) {
/* 139 */           this.h += this.y - addY;
/* 140 */           this.y = addY;
/*     */         }
/* 142 */         else if (this.y + this.h - 1 < addY) {
/* 143 */           this.h = addY - this.y + 1;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 148 */     Point newp = (this.x != oldp.x || this.y != oldp.y) ? 
/* 149 */       new Point(this.x, this.y) : null;
/* 150 */     Dimension newd = (this.w != oldd.width || this.h != oldd.height) ? 
/* 151 */       new Dimension(this.w, this.h) : null;
/* 152 */     if (newp != null) {
/* 153 */       firePropertyChange("location", oldp, newp);
/*     */     }
/* 155 */     if (newd != null) {
/* 156 */       firePropertyChange("size", oldd, newd);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void cloneImpl(MCShape base) {
/* 162 */     super.cloneImpl(base);
/*     */ 
/*     */     
/* 165 */     this.shape = new GeneralPath();
/* 166 */     Point2D[] org = this._points;
/* 167 */     this._points = new Point2D[this._points.length];
/* 168 */     for (int i = 0; i < org.length; i++) {
/* 169 */       this._points[i] = (org[i] != null) ? (Point2D)org[i].clone() : null;
/*     */     }
/* 171 */     updateShape();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBounds(int x, int y, int width, int height) {
/* 177 */     this._points = (Point2D[])this._defaultPoint.clone();
/* 178 */     Rectangle org_r = this._defaultRect;
/*     */ 
/*     */ 
/*     */     
/* 182 */     double org_w = org_r.getWidth() - 1.0D;
/* 183 */     double org_h = org_r.getHeight() - 1.0D;
/* 184 */     double new_w = (width - 1);
/* 185 */     double new_h = (height - 1);
/* 186 */     for (int i = 0; i < this._points.length; i++) {
/* 187 */       Point2D org_p = this._points[i];
/* 188 */       if (org_p == null) {
/*     */         break;
/*     */       }
/*     */ 
/*     */       
/* 193 */       double raito_x = (org_w == 0.0D) ? 
/* 194 */         0.0D : ((org_p.getX() - org_r.getX()) / org_w);
/* 195 */       double newx = x + new_w * raito_x;
/* 196 */       double raito_y = (org_h == 0.0D) ? 
/* 197 */         0.0D : ((org_p.getY() - org_r.getY()) / org_h);
/* 198 */       double newy = y + new_h * raito_y;
/* 199 */       this._points[i] = new Point2D.Double(newx, newy);
/*     */     } 
/*     */ 
/*     */     
/* 203 */     updateShape();
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\canvas\MCPolygon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */