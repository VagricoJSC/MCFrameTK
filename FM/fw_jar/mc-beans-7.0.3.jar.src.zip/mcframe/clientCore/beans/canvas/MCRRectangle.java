/*     */ package mcframe.clientCore.beans.canvas;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.Stroke;
/*     */ import java.awt.geom.RoundRectangle2D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCRRectangle
/*     */   extends MCPlane
/*     */ {
/*  20 */   private int _d_width = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  27 */   private int _d_height = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCRRectangle() {
/*  39 */     this(0, 0, 0, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCRRectangle(int x, int y, int width, int height) {
/*  53 */     this(x, y, width, height, 16, 16);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCRRectangle(int x, int y, int width, int height, int d_width, int d_height) {
/*  70 */     this._d_width = d_width;
/*  71 */     this._d_height = d_height;
/*  72 */     this.shape = createShape();
/*     */     
/*  74 */     setBounds(x, y, width, height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private RoundRectangle2D createShape() {
/*  85 */     return new RoundRectangle2D.Double(0.0D, 0.0D, 0.0D, 0.0D, this._d_width, this._d_height);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void cloneImpl(MCShape base) {
/*  90 */     super.cloneImpl(base);
/*     */ 
/*     */     
/*  93 */     this.shape = createShape();
/*  94 */     setBounds(base.getBounds());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setBounds(int x, int y, int width, int height) {
/*  99 */     super.setBounds(x, y, width, height);
/*     */ 
/*     */     
/* 102 */     RoundRectangle2D r = (RoundRectangle2D)this.shape;
/* 103 */     r.setFrame(this.x, this.y, this.w, this.h);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\canvas\MCRRectangle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */