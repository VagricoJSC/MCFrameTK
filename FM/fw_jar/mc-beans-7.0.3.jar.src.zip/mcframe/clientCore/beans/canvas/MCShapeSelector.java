/*     */ package mcframe.clientCore.beans.canvas;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Cursor;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.Stroke;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import mcframe.clientCore.beans.MCCanvas;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MCShapeSelector<E extends MCShape>
/*     */   extends MCCanvasItem
/*     */ {
/*     */   protected final MCCanvas canvas;
/*     */   protected final E shape;
/*     */   
/*  47 */   private PropertyChangeListener pcListener = new PropertyChangeListener()
/*     */     {
/*     */       public void propertyChange(PropertyChangeEvent evt) {
/*  50 */         Object src = evt.getSource();
/*  51 */         if (src == MCShapeSelector.this.shape) {
/*  52 */           if (evt.getPropertyName().equals("size")) {
/*  53 */             MCShapeSelector.this.resetBounds();
/*     */           }
/*  55 */           if (evt.getPropertyName().equals("location")) {
/*  56 */             MCShapeSelector.this.resetBounds();
/*     */           }
/*     */         } 
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCShapeSelector(MCCanvas canvas, E shape) {
/*  72 */     this.canvas = canvas;
/*  73 */     this.shape = shape;
/*  74 */     shape.addPropertyChangeListener(this.pcListener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public E getShape() {
/* 103 */     return this.shape;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void removed() {
/* 109 */     if (this.shape != null) {
/* 110 */       this.shape.removePropertyChangeListener(this.pcListener);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(int x, int y) {
/* 116 */     return getShape().contains(x, y);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canSelect(int x, int y) {
/* 121 */     return getShape().canSelect(x, y);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void paint(Graphics2D g2) {
/* 127 */     Rectangle bk_clip = g2.getClipBounds();
/* 128 */     Color bk_color = g2.getColor();
/* 129 */     Stroke bk_stroke = g2.getStroke();
/*     */ 
/*     */     
/* 132 */     paintSelector(g2);
/*     */ 
/*     */     
/* 135 */     g2.setStroke(bk_stroke);
/* 136 */     g2.setColor(bk_color);
/* 137 */     g2.setClip(bk_clip);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setCursor(MouseEvent e, MCCanvas canvas) {
/* 162 */     canvas.setCursor(Cursor.getPredefinedCursor(0));
/*     */   }
/*     */   
/*     */   protected void mousePressed(MouseEvent e, MCCanvas canvas, Point start) {}
/*     */   
/*     */   protected void mouseDragged(MouseEvent e, MCCanvas canvas, Point start) {}
/*     */   
/*     */   protected void mouseReleased(MouseEvent e, MCCanvas canvas, Point start) {}
/*     */   
/*     */   public abstract void resetBounds();
/*     */   
/*     */   public abstract boolean isResizeDirection(Point paramPoint);
/*     */   
/*     */   protected abstract void paintSelector(Graphics2D paramGraphics2D);
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\canvas\MCShapeSelector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */