/*     */ package mcframe.clientCore.beans.canvas;
/*     */ 
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import mcframe.clientCore.beans.MCCanvas;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCConnectorEditor
/*     */   extends MCShapeEditor<MCConnector>
/*     */ {
/*     */   public MCConnectorEditor(MCCanvas canvas, MCConnector base) {
/*  28 */     super(canvas, base);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean commit() {
/*  33 */     if (!ready()) {
/*  34 */       return false;
/*     */     }
/*     */     
/*  37 */     return (this.edit.getEndPlane() == null) ? commitReserve() : commitEdit();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean commitReserve() {
/*  48 */     Point p = this.edit.getEndPoint();
/*  49 */     if (p != null) {
/*  50 */       MCPlane end = this.canvas.getPlane(p.x, p.y);
/*  51 */       if (end != null && end != this.edit.getStartPlane()) {
/*  52 */         this.edit.setEnd(end);
/*  53 */         this.base.setStart(this.edit.getStartPlane());
/*  54 */         this.base.setEnd(this.edit.getEndPlane());
/*  55 */         return true;
/*     */       } 
/*     */     } 
/*  58 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean commitEdit() {
/*  69 */     Point[] half = this.edit.getHalfPoints();
/*  70 */     this.base.setPoint(
/*  71 */         this.edit.getStartPoint(), half[0], half[1], this.edit.getEndPoint());
/*  72 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCConnector copy() {
/*  77 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void move(Point p1, Point p2) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resize(Point p1, Point p2, Object option) {
/*  90 */     if (!ready()) {
/*     */       return;
/*     */     }
/*     */     
/*  94 */     if (this.edit.getEndPlane() == null) {
/*     */       
/*  96 */       resizeReserve(p2);
/*     */     } else {
/*     */       
/*  99 */       MCConnectorSelector selector = (MCConnectorSelector)option;
/* 100 */       resizeExist(p2, selector);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void resizeReserve(Point p) {
/* 112 */     this.edit.setEnd(p.x, p.y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void resizeExist(Point p, MCConnectorSelector selector) {
/* 123 */     MCPlane target = selector.getTarget();
/* 124 */     MCPlane splane = this.edit.getStartPlane();
/* 125 */     MCPlane eplane = this.edit.getEndPlane();
/* 126 */     Point spoint = this.edit.getStartPoint();
/* 127 */     Point epoint = this.edit.getEndPoint();
/* 128 */     Point[] hpoint = this.edit.getHalfPoints();
/* 129 */     boolean horizontal = selector.direction();
/*     */     
/* 131 */     Point npoint = (Point)p.clone();
/* 132 */     MCPlane[] planes = null;
/* 133 */     Point[] points = null;
/* 134 */     if (target == splane) {
/*     */       
/* 136 */       planes = new MCPlane[] { splane, eplane };
/* 137 */       points = new Point[] { spoint, hpoint[0], hpoint[1], epoint };
/*     */     }
/*     */     else {
/*     */       
/* 141 */       planes = new MCPlane[] { eplane, splane };
/* 142 */       points = new Point[] { epoint, hpoint[1], hpoint[0], spoint };
/*     */     } 
/*     */ 
/*     */     
/* 146 */     if (horizontal) {
/* 147 */       npoint.y = (points[2]).y;
/*     */     } else {
/*     */       
/* 150 */       npoint.x = (points[2]).x;
/*     */     } 
/*     */     
/* 153 */     int sd = this.edit.analyzeDirection(points[0], points[1]);
/* 154 */     int ed = this.edit.analyzeDirection(points[3], points[2]);
/*     */     
/* 156 */     sd = resizeConnectLine(points[0], points[1], npoint, 
/* 157 */         planes[0], planes[1], sd, ed, horizontal, true);
/*     */     
/* 159 */     resizeHalfLine(points[2], ed, points[1], sd);
/* 160 */     npoint = points[2];
/*     */     
/* 162 */     ed = resizeConnectLine(points[3], points[2], npoint, 
/* 163 */         planes[1], planes[0], ed, sd, horizontal, false);
/*     */     
/* 165 */     resizeHalfLine(points[2], ed, points[1], sd);
/*     */     
/* 167 */     this.edit.setPoint(spoint, hpoint[0], hpoint[1], epoint);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int resizeConnectLine(Point spoint, Point epoint, Point npoint, MCPlane splane, MCPlane oplane, int sdir, int odir, boolean horizontal, boolean target) {
/* 190 */     int newdir = -1;
/* 191 */     switch (sdir) {
/*     */       case 0:
/*     */       case 1:
/* 194 */         newdir = resizeConnectLineVertical(spoint, epoint, npoint, 
/* 195 */             splane, oplane, sdir, odir, 
/* 196 */             horizontal, target);
/*     */         break;
/*     */       case 2:
/*     */       case 3:
/* 200 */         newdir = resizeConnectLineHorizontal(spoint, epoint, npoint, 
/* 201 */             splane, oplane, sdir, odir, 
/* 202 */             horizontal, target);
/*     */         break;
/*     */     } 
/* 205 */     return newdir;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int resizeConnectLineVertical(Point spoint, Point epoint, Point npoint, MCPlane splane, MCPlane oplane, int sdir, int odir, boolean horizontal, boolean target) {
/* 231 */     int newdir = -1;
/* 232 */     Rectangle sr = splane.getBounds();
/* 233 */     if (horizontal) {
/*     */       
/* 235 */       epoint.x = npoint.x;
/* 236 */       if (sr.getMaxX() <= npoint.x)
/*     */       {
/* 238 */         spoint.x = (int)sr.getMaxX() - 1;
/* 239 */         spoint.y = (int)sr.getCenterY();
/* 240 */         epoint.y = spoint.y;
/* 241 */         newdir = 2;
/*     */       }
/* 243 */       else if (npoint.x < sr.getMinX())
/*     */       {
/* 245 */         spoint.x = (int)sr.getMinX();
/* 246 */         spoint.y = (int)sr.getCenterY();
/* 247 */         epoint.y = spoint.y;
/* 248 */         newdir = 3;
/*     */       }
/*     */       else
/*     */       {
/* 252 */         spoint.x = npoint.x;
/* 253 */         if (oplane.contains(epoint.x, epoint.y)) {
/*     */           
/* 255 */           Rectangle or = oplane.getBounds();
/* 256 */           if (sdir == 0) {
/* 257 */             int sr_y = (int)sr.getMaxY() - 1;
/* 258 */             int diff = or.y - sr_y;
/* 259 */             epoint.y = sr_y + diff / 2;
/*     */           } else {
/*     */             
/* 262 */             int or_y = (int)or.getMaxY() - 1;
/* 263 */             int diff = sr.y - or_y;
/* 264 */             epoint.y = or_y + diff / 2;
/*     */           } 
/*     */         } 
/* 267 */         newdir = (spoint.y == (int)sr.getMinY()) ? 
/* 268 */           1 : 0;
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 273 */       Rectangle or = oplane.getBounds();
/* 274 */       if (sr.getMinY() <= npoint.y && npoint.y < sr.getMaxY()) {
/*     */         
/* 276 */         double cx = sr.getCenterX();
/* 277 */         if (Math.abs(cx - or.getMaxX() - 1.0D) < Math.abs(cx - or.getMinX())) {
/* 278 */           spoint.x = (int)sr.getMinX();
/* 279 */           newdir = 3;
/*     */         } else {
/*     */           
/* 282 */           spoint.x = (int)sr.getMaxX() - 1;
/* 283 */           newdir = 2;
/*     */         } 
/* 285 */         boolean samedir = this.edit.sameDirection(newdir, odir);
/* 286 */         spoint.y = (samedir && !target) ? 
/* 287 */           (int)sr.getCenterY() : npoint.y;
/*     */         
/* 289 */         epoint.y = spoint.y;
/* 290 */         if (samedir) {
/*     */           
/* 292 */           if (newdir == 2) {
/* 293 */             int sr_x = (int)sr.getMaxX() - 1;
/* 294 */             int diff = or.x - sr_x;
/* 295 */             epoint.x = sr_x + diff / 2;
/*     */           } else {
/*     */             
/* 298 */             int or_x = (int)or.getMaxX() - 1;
/* 299 */             int diff = sr.x - or_x;
/* 300 */             epoint.x = or_x + diff / 2;
/*     */           }
/*     */         
/*     */         } else {
/*     */           
/* 305 */           epoint.x = npoint.x;
/* 306 */           if (sr.contains(epoint))
/*     */           {
/* 308 */             newdir = (newdir == 2) ? 
/* 309 */               3 : 2;
/*     */           }
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 315 */         epoint.y = npoint.y;
/* 316 */         newdir = (spoint.y == (int)sr.getMinY()) ? 
/* 317 */           1 : 0;
/*     */       } 
/*     */     } 
/* 320 */     return newdir;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int resizeConnectLineHorizontal(Point spoint, Point epoint, Point npoint, MCPlane splane, MCPlane oplane, int sdir, int odir, boolean horizontal, boolean target) {
/* 346 */     int newdir = -1;
/* 347 */     Rectangle sr = splane.getBounds();
/* 348 */     if (horizontal) {
/*     */       
/* 350 */       Rectangle or = oplane.getBounds();
/* 351 */       if (sr.getMinX() <= npoint.x && npoint.x < sr.getMaxX()) {
/*     */         
/* 353 */         double cy = sr.getCenterY();
/* 354 */         if (Math.abs(cy - or.getMaxY() - 1.0D) < Math.abs(cy - or.getMinY())) {
/* 355 */           spoint.y = (int)sr.getMinY();
/* 356 */           newdir = 1;
/*     */         } else {
/*     */           
/* 359 */           spoint.y = (int)sr.getMaxY() - 1;
/* 360 */           newdir = 0;
/*     */         } 
/* 362 */         boolean samedir = this.edit.sameDirection(newdir, odir);
/* 363 */         spoint.x = (samedir && !target) ? 
/* 364 */           (int)sr.getCenterX() : npoint.x;
/*     */         
/* 366 */         epoint.x = spoint.x;
/* 367 */         if (samedir) {
/*     */           
/* 369 */           if (newdir == 0) {
/* 370 */             int sr_y = (int)sr.getMaxY() - 1;
/* 371 */             int diff = or.y - sr_y;
/* 372 */             epoint.y = sr_y + diff / 2;
/*     */           } else {
/*     */             
/* 375 */             int or_y = (int)or.getMaxY() - 1;
/* 376 */             int diff = sr.y - or_y;
/* 377 */             epoint.y = or_y + diff / 2;
/*     */           }
/*     */         
/*     */         } else {
/*     */           
/* 382 */           epoint.y = npoint.y;
/* 383 */           if (sr.contains(epoint))
/*     */           {
/* 385 */             newdir = (newdir == 0) ? 
/* 386 */               1 : 0;
/*     */           }
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 392 */         epoint.x = npoint.x;
/* 393 */         newdir = (spoint.x == (int)sr.getMinX()) ? 
/* 394 */           3 : 2;
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 399 */       epoint.y = npoint.y;
/* 400 */       if (sr.getMaxY() <= npoint.y) {
/*     */         
/* 402 */         spoint.x = (int)sr.getCenterX();
/* 403 */         spoint.y = (int)sr.getMaxY() - 1;
/* 404 */         epoint.x = spoint.x;
/* 405 */         newdir = 0;
/*     */       }
/* 407 */       else if (npoint.y < sr.getMinY()) {
/*     */         
/* 409 */         spoint.x = (int)sr.getCenterX();
/* 410 */         spoint.y = (int)sr.getMinY();
/* 411 */         epoint.x = spoint.x;
/* 412 */         newdir = 1;
/*     */       }
/*     */       else {
/*     */         
/* 416 */         spoint.y = npoint.y;
/* 417 */         if (oplane.contains(epoint.x, epoint.y)) {
/*     */           
/* 419 */           Rectangle or = oplane.getBounds();
/* 420 */           if (sdir == 2) {
/* 421 */             int sr_x = (int)sr.getMaxX() - 1;
/* 422 */             int diff = or.x - sr_x;
/* 423 */             epoint.x = sr_x + diff / 2;
/*     */           } else {
/*     */             
/* 426 */             int or_x = (int)or.getMaxX() - 1;
/* 427 */             int diff = sr.x - or_x;
/* 428 */             epoint.x = or_x + diff / 2;
/*     */           } 
/*     */         } 
/* 431 */         newdir = (spoint.x == (int)sr.getMinX()) ? 
/* 432 */           3 : 2;
/*     */       } 
/*     */     } 
/* 435 */     return newdir;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void resizeHalfLine(Point target_p, int target_d, Point base_p, int base_d) {
/* 449 */     if (this.edit.sameDirection(base_d, target_d)) {
/*     */       
/* 451 */       switch (target_d) {
/*     */         case 0:
/*     */         case 1:
/* 454 */           target_p.y = base_p.y;
/*     */           break;
/*     */         case 2:
/*     */         case 3:
/* 458 */           target_p.x = base_p.x;
/*     */           break;
/*     */       } 
/*     */ 
/*     */     
/*     */     } else {
/* 464 */       target_p.x = base_p.x;
/* 465 */       target_p.y = base_p.y;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void zoom(Point p1, Point p2, Object option) {}
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\canvas\MCConnectorEditor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */