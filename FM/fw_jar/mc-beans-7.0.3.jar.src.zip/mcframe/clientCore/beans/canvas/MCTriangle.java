/*    */ package mcframe.clientCore.beans.canvas;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.awt.Rectangle;
/*    */ import java.awt.Stroke;
/*    */ import java.awt.geom.Point2D;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCTriangle
/*    */   extends MCPolygon
/*    */ {
/*    */   public MCTriangle() {
/* 24 */     this(0, 0, 0, 0);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MCTriangle(int x, int y, int width, int height) {
/* 42 */     super(new Point2D[] { new Point2D.Double(49.0D, 0.0D), new Point2D.Double(98.0D, 98.0D), new Point2D.Double(0.0D, 98.0D) });
/*    */     
/* 44 */     setBounds(x, y, width, height);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\canvas\MCTriangle.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */