/*    */ package mcframe.clientCore.beans.canvas;
/*    */ 
/*    */ import java.awt.Point;
/*    */ import mcframe.clientCore.beans.MCCanvas;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class MCShapeEditor<E extends MCShape>
/*    */ {
/*    */   protected final MCCanvas canvas;
/*    */   protected final E base;
/*    */   protected final E edit;
/*    */   
/*    */   protected MCShapeEditor(MCCanvas canvas, E base) {
/* 52 */     this.canvas = canvas;
/* 53 */     this.base = base;
/* 54 */     this.edit = (E)base.clone();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean ready() {
/* 65 */     return (this.base != null && this.edit != null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public E getShape() {
/* 76 */     return this.base;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public E getEditShape() {
/* 87 */     return this.edit;
/*    */   }
/*    */   
/*    */   public abstract boolean commit();
/*    */   
/*    */   public abstract E copy();
/*    */   
/*    */   public abstract void move(Point paramPoint1, Point paramPoint2);
/*    */   
/*    */   public abstract void resize(Point paramPoint1, Point paramPoint2, Object paramObject);
/*    */   
/*    */   public abstract void zoom(Point paramPoint1, Point paramPoint2, Object paramObject);
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\canvas\MCShapeEditor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */