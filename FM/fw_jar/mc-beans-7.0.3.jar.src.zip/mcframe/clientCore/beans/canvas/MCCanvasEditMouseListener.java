/*     */ package mcframe.clientCore.beans.canvas;
/*     */ 
/*     */ import java.awt.Cursor;
/*     */ import java.awt.Point;
/*     */ import java.awt.event.MouseEvent;
/*     */ import javax.swing.event.MouseInputListener;
/*     */ import mcframe.clientCore.beans.MCCanvas;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCCanvasEditMouseListener
/*     */   implements MouseInputListener
/*     */ {
/*     */   private MCCanvas _canvas;
/*  38 */   private Point _orgPoint = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  47 */   private MCShapeSelector<?> _selector = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean _drag = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   private MCCanvas.ResizeDirection _resize = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   private MCShape _last = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCCanvasEditMouseListener(MCCanvas canvas) {
/*  80 */     this._canvas = canvas;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCCanvas getParentCanvas() {
/*  91 */     return this._canvas;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCShapeSelector<?> getTargetSelector() {
/* 102 */     return this._selector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Point getOrgPoint() {
/* 113 */     return (this._orgPoint == null) ? null : (Point)this._orgPoint.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isDragging() {
/* 124 */     return this._drag;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCCanvas.ResizeDirection getResizeDirection() {
/* 135 */     return this._resize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCCanvas.ResizeDirection getDirection(int orgx, int orgy, int newx, int newy) {
/* 150 */     if (newx < orgx) {
/* 151 */       if (newy <= orgy) {
/* 152 */         return MCCanvas.ResizeDirection.LT;
/*     */       }
/* 154 */       return MCCanvas.ResizeDirection.LB;
/*     */     } 
/* 156 */     if (newy <= orgy) {
/* 157 */       return MCCanvas.ResizeDirection.RT;
/*     */     }
/* 159 */     return MCCanvas.ResizeDirection.RB;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCShape getLastClickShape() {
/* 185 */     return this._last;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setLastClickShape(int x, int y) {
/* 200 */     MCShape[] shapes = getParentCanvas().getShapes();
/* 201 */     for (int i = shapes.length - 1; i >= 0; i--) {
/* 202 */       MCShape shape = shapes[i];
/* 203 */       if (shape.canSelect(x, y)) {
/* 204 */         this._last = shape;
/*     */         return;
/*     */       } 
/*     */     } 
/* 208 */     this._last = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setMousePointer(MouseEvent e) {
/* 219 */     int cursor = 0;
/*     */     
/* 221 */     if (getParentCanvas().getReserveShape() != null) {
/*     */       
/* 223 */       cursor = 1;
/*     */     } else {
/*     */       
/* 226 */       Point p = e.getPoint();
/* 227 */       MCShapeSelector<?> selector = getParentCanvas().getSelector(p.x, p.y);
/* 228 */       if (selector != null) {
/* 229 */         selector.setCursor(e, getParentCanvas());
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 234 */     getParentCanvas().setCursor(Cursor.getPredefinedCursor(cursor));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setDragMousePointer(MouseEvent e) {
/* 245 */     getParentCanvas().setCursor(
/* 246 */         Cursor.getPredefinedCursor(1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setStatusBarText() {
/* 256 */     MCShape shape = null;
/* 257 */     if (getTargetSelector() != null) {
/* 258 */       shape = (MCShape)getTargetSelector().getShape();
/*     */     }
/* 260 */     else if (getParentCanvas().getReserveShape() != null) {
/* 261 */       shape = getParentCanvas().getReserveShape();
/*     */     } 
/* 263 */     getParentCanvas().setStatusBarInfo(shape);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mousePressed(MouseEvent e) {
/* 272 */     this._orgPoint = e.getPoint();
/*     */ 
/*     */     
/* 275 */     setLastClickShape(this._orgPoint.x, this._orgPoint.y);
/*     */     
/* 277 */     if (getParentCanvas().getReserveShape() != null) {
/*     */       
/* 279 */       mousePressedReserve(e);
/*     */     }
/*     */     else {
/*     */       
/* 283 */       mousePressedCanvas(e);
/*     */     } 
/*     */ 
/*     */     
/* 287 */     setStatusBarText();
/*     */     
/* 289 */     getParentCanvas().repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void mousePressedCanvas(MouseEvent e) {
/* 300 */     Point p = this._orgPoint;
/*     */ 
/*     */     
/* 303 */     MCShapeSelector<?> selector = getParentCanvas().getSelector(p.x, p.y);
/* 304 */     if (selector == null) {
/*     */       
/* 306 */       MCShape top = getParentCanvas().getShape(p.x, p.y);
/* 307 */       if (top == null)
/*     */       {
/* 309 */         getParentCanvas().cancelAllSelect();
/*     */       }
/*     */       else
/*     */       {
/* 313 */         if (!e.isControlDown())
/*     */         {
/* 315 */           getParentCanvas().cancelAllSelect();
/*     */         }
/*     */         
/* 318 */         this._selector = getParentCanvas().selectShape(top);
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 323 */       MCShape top = getParentCanvas().getShape(p.x, p.y);
/* 324 */       if (selector.getShape() == top) {
/*     */ 
/*     */         
/* 327 */         this._selector = selector;
/* 328 */         this._selector.mousePressed(e, getParentCanvas(), p);
/*     */ 
/*     */       
/*     */       }
/* 332 */       else if (selector.isResizeDirection(p)) {
/*     */         
/* 334 */         this._selector = selector;
/* 335 */         this._selector.mousePressed(e, getParentCanvas(), p);
/*     */       }
/*     */       else {
/*     */         
/* 339 */         if (!e.isControlDown())
/*     */         {
/* 341 */           getParentCanvas().cancelAllSelect();
/*     */         }
/*     */         
/* 344 */         this._selector = getParentCanvas().selectShape(top);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void mousePressedReserve(MouseEvent e) {
/* 358 */     if (getParentCanvas().getReserveShape() == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 363 */     Point p = e.getPoint();
/* 364 */     getParentCanvas().setReserveShapeLocation(p.x, p.y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseDragged(MouseEvent e) {
/* 371 */     setDragMousePointer(e);
/*     */     
/* 373 */     if (getParentCanvas().getReserveShape() != null) {
/*     */       
/* 375 */       mouseDraggedReserve(e);
/*     */     }
/* 377 */     else if (getTargetSelector() != null) {
/*     */       
/* 379 */       mouseDraggedShape(e);
/*     */     }
/*     */     else {
/*     */       
/* 383 */       mouseDraggedCanvas(e);
/*     */     } 
/*     */ 
/*     */     
/* 387 */     this._drag = true;
/*     */ 
/*     */     
/* 390 */     setStatusBarText();
/*     */     
/* 392 */     getParentCanvas().repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void mouseDraggedCanvas(MouseEvent e) {
/* 404 */     Point orgPoint = getOrgPoint();
/* 405 */     Point newPoint = e.getPoint();
/* 406 */     getParentCanvas().setMultiSelector(
/* 407 */         orgPoint.x, 
/* 408 */         orgPoint.y, 
/* 409 */         newPoint.x - orgPoint.x, 
/* 410 */         newPoint.y - orgPoint.y);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void mouseDraggedShape(MouseEvent e) {
/* 422 */     this._selector.mouseDragged(e, getParentCanvas(), this._orgPoint);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void mouseDraggedReserve(MouseEvent e) {
/* 433 */     Point orgPoint = getOrgPoint();
/* 434 */     Point newPoint = e.getPoint();
/* 435 */     if (getResizeDirection() == null) {
/* 436 */       this._resize = getDirection(
/* 437 */           orgPoint.x, orgPoint.y, newPoint.x, newPoint.y);
/*     */     }
/* 439 */     getParentCanvas().resizeReserveShape(orgPoint, newPoint, this._resize);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseReleased(MouseEvent e) {
/* 445 */     if (getParentCanvas().getReserveShape() != null) {
/*     */       
/* 447 */       mouseReleasedReserve(e);
/*     */     }
/* 449 */     else if (getTargetSelector() != null) {
/*     */       
/* 451 */       mouseReleasedShape(e);
/*     */     }
/*     */     else {
/*     */       
/* 455 */       mouseReleasedCanvas(e);
/*     */     } 
/*     */ 
/*     */     
/* 459 */     setStatusBarText();
/*     */ 
/*     */     
/* 462 */     setMousePointer(e);
/*     */ 
/*     */     
/* 465 */     this._orgPoint = null;
/*     */     
/* 467 */     this._drag = false;
/*     */     
/* 469 */     this._selector = null;
/*     */     
/* 471 */     this._resize = null;
/*     */     
/* 473 */     this._canvas.repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void mouseReleasedCanvas(MouseEvent e) {
/* 484 */     if (!isDragging()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 489 */     getParentCanvas().multiSelectShapes();
/*     */ 
/*     */     
/* 492 */     getParentCanvas().removeEditorShapes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void mouseReleasedShape(MouseEvent e) {
/* 503 */     this._selector.mouseReleased(e, getParentCanvas(), this._orgPoint);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void mouseReleasedReserve(MouseEvent e) {
/* 515 */     getParentCanvas().cancelAllSelect();
/*     */     
/* 517 */     MCShape shape = getParentCanvas().getReserveShape();
/* 518 */     if (getResizeDirection() == null)
/*     */     {
/* 520 */       getParentCanvas().resizeReserveShapeDefault();
/*     */     }
/*     */ 
/*     */     
/* 524 */     getParentCanvas().commitReserveShape();
/*     */ 
/*     */     
/* 527 */     getParentCanvas().selectShape(shape);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseClicked(MouseEvent e) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseEntered(MouseEvent e) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseExited(MouseEvent e) {
/* 542 */     if (getParentCanvas().getReserveShape() != null) {
/* 543 */       getParentCanvas().removeReserveCursor();
/* 544 */       getParentCanvas().repaint();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseMoved(MouseEvent e) {
/* 551 */     setMousePointer(e);
/*     */ 
/*     */     
/* 554 */     if (getParentCanvas().getReserveShape() != null) {
/* 555 */       Point p = e.getPoint();
/* 556 */       getParentCanvas().setReserveCursor(p.x, p.y);
/* 557 */       getParentCanvas().repaint();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\canvas\MCCanvasEditMouseListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */