/*     */ package mcframe.clientCore.beans.canvas;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import mcframe.clientCore.beans.MCCanvas;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCPlaneEditor
/*     */   extends MCShapeEditor<MCPlane>
/*     */ {
/*     */   public MCPlaneEditor(MCCanvas canvas, MCPlane base) {
/*  28 */     super(canvas, base);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean commit() {
/*  33 */     if (!ready()) {
/*  34 */       return false;
/*     */     }
/*     */     
/*  37 */     this.base.setBounds(this.edit.getBounds());
/*  38 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCPlane copy() {
/*  43 */     if (!ready()) {
/*  44 */       return null;
/*     */     }
/*     */     
/*  47 */     return (MCPlane)this.edit.clone();
/*     */   }
/*     */ 
/*     */   
/*     */   public void move(Point p1, Point p2) {
/*  52 */     if (!ready()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  57 */     int x = p2.x - p1.x;
/*  58 */     int y = p2.y - p1.y;
/*     */     
/*  60 */     Rectangle pr = this.base.getBounds();
/*  61 */     Rectangle er = pr.getBounds();
/*  62 */     pr.x += x;
/*  63 */     er.y += y;
/*  64 */     this.edit.setBounds(er);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void resize(Point p1, Point p2, Object option) {
/*  71 */     if (!ready()) {
/*     */       return;
/*     */     }
/*  74 */     if (!(option instanceof MCCanvas.ResizeDirection)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  79 */     MCCanvas.ResizeDirection direction = (MCCanvas.ResizeDirection)option;
/*     */ 
/*     */     
/*  82 */     int x = p2.x - p1.x;
/*  83 */     int y = p2.y - p1.y;
/*     */     
/*  85 */     Rectangle pr = this.base.getBounds();
/*  86 */     Rectangle er = pr.getBounds();
/*  87 */     switch (direction) {
/*     */       case LT:
/*  89 */         pr.x += x;
/*  90 */         pr.y += y;
/*  91 */         pr.width -= x;
/*  92 */         pr.height -= y;
/*     */         break;
/*     */       case null:
/*  95 */         pr.x += x;
/*     */         
/*  97 */         pr.width -= x;
/*  98 */         pr.height += y;
/*     */         
/* 100 */         y = 0;
/*     */         break;
/*     */       
/*     */       case RT:
/* 104 */         pr.y += y;
/* 105 */         pr.width += x;
/* 106 */         pr.height -= y;
/*     */         
/* 108 */         x = 0;
/*     */         break;
/*     */ 
/*     */       
/*     */       case RB:
/* 113 */         pr.width += x;
/* 114 */         pr.height += y;
/*     */         
/* 116 */         x = 0;
/* 117 */         y = 0;
/*     */         break;
/*     */     } 
/*     */     
/* 121 */     Dimension min = this.base.getMinSize();
/* 122 */     if (er.width < min.width) {
/* 123 */       int amount = min.width - er.width;
/* 124 */       er.x += amount * ((x == 0) ? 0 : ((x < 0) ? 1 : -1));
/* 125 */       er.width += amount;
/*     */     } 
/* 127 */     if (er.height < min.height) {
/* 128 */       int amount = min.height - er.height;
/* 129 */       er.y += amount * ((y == 0) ? 0 : ((y < 0) ? 1 : -1));
/* 130 */       er.height += amount;
/*     */     } 
/*     */     
/* 133 */     this.edit.setBounds(er);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void zoom(Point p1, Point p2, Object option) {
/* 140 */     if (!ready()) {
/*     */       return;
/*     */     }
/* 143 */     if (!(option instanceof MCCanvas.ResizeDirection)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 148 */     MCCanvas.ResizeDirection direction = (MCCanvas.ResizeDirection)option;
/*     */ 
/*     */     
/* 151 */     int x = p2.x - p1.x;
/* 152 */     int y = p2.y - p1.y;
/*     */     
/* 154 */     Rectangle pr = this.base.getBounds();
/* 155 */     Rectangle er = pr.getBounds();
/* 156 */     switch (direction) {
/*     */       case LT:
/* 158 */         pr.x += x;
/* 159 */         pr.y += y;
/* 160 */         pr.width -= x * 2;
/* 161 */         pr.height -= y * 2;
/*     */         break;
/*     */       case null:
/* 164 */         pr.x += x;
/* 165 */         pr.y -= y;
/* 166 */         pr.width -= x * 2;
/* 167 */         pr.height += y * 2;
/*     */         break;
/*     */       case RT:
/* 170 */         pr.x -= x;
/* 171 */         pr.y += y;
/* 172 */         pr.width += x * 2;
/* 173 */         pr.height -= y * 2;
/*     */         break;
/*     */       case RB:
/* 176 */         pr.x -= x;
/* 177 */         pr.y -= y;
/* 178 */         pr.width += x * 2;
/* 179 */         pr.height += y * 2;
/*     */         break;
/*     */     } 
/*     */     
/* 183 */     Dimension min = this.base.getMinSize();
/* 184 */     if (er.width < min.width) {
/* 185 */       int amount = min.width - er.width;
/* 186 */       er.x -= amount / 2;
/* 187 */       er.width += amount;
/*     */     } 
/* 189 */     if (er.height < min.height) {
/* 190 */       int amount = min.height - er.height;
/* 191 */       er.y -= amount / 2;
/* 192 */       er.height += amount;
/*     */     } 
/*     */     
/* 195 */     this.edit.setBounds(er);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\canvas\MCPlaneEditor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */