/*     */ package mcframe.clientCore.beans.canvas;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.Stroke;
/*     */ import java.awt.geom.GeneralPath;
/*     */ import java.awt.geom.Line2D;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import mcframe.clientCore.beans.MCCanvas;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCConnector
/*     */   extends MCShape
/*     */ {
/*  32 */   private MCPlane _plane_s = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  39 */   private MCPlane _plane_e = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  47 */   private Point _point_s = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   private Point _point_e = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   private Point _half_s = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   private Point _half_e = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean _arrow_s = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean _arrow_e = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  91 */   private int _selmargin = 3;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  99 */   private PropertyChangeListener pcListener = new PropertyChangeListener()
/*     */     {
/*     */       public void propertyChange(PropertyChangeEvent evt) {
/* 102 */         Object src = evt.getSource();
/* 103 */         if (src == MCConnector.this._plane_s || src == MCConnector.this._plane_e) {
/* 104 */           if (evt.getPropertyName().equals("size")) {
/* 105 */             MCConnector.this.updateAuto();
/*     */           }
/* 107 */           if (evt.getPropertyName().equals("location")) {
/* 108 */             MCConnector.this.updateAuto();
/*     */           }
/*     */         } 
/*     */       }
/*     */     };
/*     */ 
/*     */   
/*     */   protected static final int CONN_NONE = -1;
/*     */   protected static final int CONN_B = 0;
/*     */   protected static final int CONN_T = 1;
/*     */   protected static final int CONN_R = 2;
/*     */   protected static final int CONN_L = 3;
/*     */   
/*     */   public MCConnector() {
/* 122 */     this.shape = new GeneralPath();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean initBounds(MCCanvas canvas, int x, int y) {
/* 127 */     MCPlane start = canvas.getPlane(x, y);
/* 128 */     if (start == null) {
/* 129 */       return false;
/*     */     }
/*     */     
/* 132 */     setStart(start);
/*     */     
/* 134 */     setEnd(x, y);
/*     */     
/* 136 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void removed() {
/* 142 */     if (this._plane_s != null) {
/* 143 */       this._plane_s.removePropertyChangeListener(this.pcListener);
/*     */     }
/* 145 */     if (this._plane_e != null) {
/* 146 */       this._plane_e.removePropertyChangeListener(this.pcListener);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension getDefaultSize() {
/* 160 */     return getBounds().getSize();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStart(MCPlane plane) {
/* 174 */     if (this._plane_s != null) {
/* 175 */       this._plane_s.removePropertyChangeListener(this.pcListener);
/*     */     }
/* 177 */     this._plane_s = plane;
/* 178 */     if (this._plane_s != null) {
/* 179 */       this._plane_s.addPropertyChangeListener(this.pcListener);
/*     */     }
/*     */ 
/*     */     
/* 183 */     this._point_s = null;
/* 184 */     updateAuto();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnd(MCPlane plane) {
/* 198 */     if (this._plane_e != null) {
/* 199 */       this._plane_e.removePropertyChangeListener(this.pcListener);
/*     */     }
/* 201 */     if (plane == this._plane_s) {
/* 202 */       this._plane_e = null;
/* 203 */       this._point_e = null;
/*     */       return;
/*     */     } 
/* 206 */     this._plane_e = plane;
/* 207 */     if (this._plane_e != null) {
/* 208 */       this._plane_e.addPropertyChangeListener(this.pcListener);
/*     */     }
/*     */ 
/*     */     
/* 212 */     this._point_e = null;
/* 213 */     updateAuto();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setEnd(int x, int y) {
/* 230 */     if (this._plane_e != null) {
/* 231 */       this._plane_e.removePropertyChangeListener(this.pcListener);
/*     */     }
/* 233 */     this._plane_e = null;
/* 234 */     this._point_e = new Point(x, y);
/* 235 */     updateAuto();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCPlane getStartPlane() {
/* 249 */     return (this._plane_s != null) ? this._plane_s : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point getStartPoint() {
/* 263 */     return (this._point_s != null) ? (Point)this._point_s.clone() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCPlane getEndPlane() {
/* 277 */     return (this._plane_e != null) ? this._plane_e : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point getEndPoint() {
/* 291 */     return (this._point_e != null) ? (Point)this._point_e.clone() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point[] getHalfPoints() {
/* 302 */     return new Point[] {
/* 303 */         (this._half_s != null) ? (Point)this._half_s.clone() : null, 
/* 304 */         (this._half_e != null) ? (Point)this._half_e.clone() : null
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setStartArrow(boolean enable) {
/* 316 */     this._arrow_s = enable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEndArrow(boolean enable) {
/* 327 */     this._arrow_e = enable;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCShapeSelector<?> createSelector(MCCanvas canvas) {
/* 332 */     return new MCConnectorSelector(canvas, this);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCShapeEditor<?> createEditor(MCCanvas canvas) {
/* 337 */     return new MCConnectorEditor(canvas, this);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canSelect(int x, int y) {
/* 342 */     if (this._point_s == null || this._point_e == null) {
/* 343 */       return false;
/*     */     }
/* 345 */     return !(!canSelectStart(x, y) && 
/* 346 */       !canSelectHalf(x, y) && 
/* 347 */       !canSelectEnd(x, y));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean canSelectStart(int x, int y) {
/* 360 */     Rectangle r = getSelectableArea(this._point_s, this._half_s);
/* 361 */     return (r != null && r.contains(x, y));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean canSelectEnd(int x, int y) {
/* 374 */     Rectangle r = getSelectableArea(this._half_e, this._point_e);
/* 375 */     return (r != null && r.contains(x, y));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean canSelectHalf(int x, int y) {
/* 389 */     Rectangle r = getSelectableArea(this._half_s, this._half_e);
/* 390 */     return (r != null && r.contains(x, y));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Rectangle getSelectableArea(Point p1, Point p2) {
/* 403 */     if (p1.x == p2.x)
/*     */     {
/* 405 */       return (new Line2D.Double((
/* 406 */           p1.x - this._selmargin), p1.y, (p2.x + this._selmargin), p2.y))
/* 407 */         .getBounds();
/*     */     }
/* 409 */     if (p1.y == p2.y)
/*     */     {
/* 411 */       return (new Line2D.Double(
/* 412 */           p1.x, (p1.y - this._selmargin), p2.x, (p2.y + this._selmargin)))
/* 413 */         .getBounds();
/*     */     }
/* 415 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void cloneImpl(MCShape base) {
/* 421 */     this.shape = new GeneralPath();
/* 422 */     MCConnector conn = (MCConnector)base;
/* 423 */     this._point_s = (Point)conn._point_s.clone();
/* 424 */     this._point_e = (Point)conn._point_e.clone();
/* 425 */     this._half_s = (Point)conn._half_s.clone();
/* 426 */     this._half_e = (Point)conn._half_e.clone();
/* 427 */     updateShape();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean setPoint(Point s, Point hs, Point he, Point e) {
/* 474 */     s = (Point)s.clone();
/* 475 */     if (adjustPoint(this._plane_s, s) == -1)
/*     */     {
/* 477 */       return false;
/*     */     }
/*     */     
/* 480 */     e = (Point)e.clone();
/* 481 */     if (this._plane_e != null && adjustPoint(this._plane_e, e) == -1)
/*     */     {
/* 483 */       return false;
/*     */     }
/*     */     
/* 486 */     if (hs.x != he.x && hs.y != he.y)
/*     */     {
/* 488 */       return false;
/*     */     }
/*     */     
/* 491 */     this._point_s = s;
/* 492 */     this._half_s = (Point)hs.clone();
/* 493 */     this._half_e = (Point)he.clone();
/* 494 */     this._point_e = e;
/*     */ 
/*     */     
/* 497 */     updateShape();
/*     */     
/* 499 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int analyzeDirection(Point s, Point e) {
/* 511 */     if (s.x == e.x)
/*     */     {
/* 513 */       return (e.y - s.y >= 0) ? 0 : 1;
/*     */     }
/* 515 */     if (s.y == e.y)
/*     */     {
/* 517 */       return (e.x - s.x >= 0) ? 2 : 3;
/*     */     }
/* 519 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean sameDirection(int d1, int d2) {
/* 532 */     return (d1 >> 1 == d2 >> 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int adjustPoint(MCPlane plane, Point point) {
/* 545 */     if (point == null) {
/* 546 */       return -1;
/*     */     }
/* 548 */     if (plane == null) {
/* 549 */       return -1;
/*     */     }
/* 551 */     if (!plane.contains(point.x, point.y)) {
/* 552 */       return -1;
/*     */     }
/*     */     
/* 555 */     Rectangle r = plane.getBounds();
/* 556 */     int x_pos = point.x - r.x;
/* 557 */     int x_max = r.width - 1;
/* 558 */     int y_pos = point.y - r.y;
/* 559 */     int y_max = r.height - 1;
/* 560 */     if (x_pos == 0) {
/* 561 */       return 3;
/*     */     }
/* 563 */     if (x_pos == x_max) {
/* 564 */       return 2;
/*     */     }
/* 566 */     if (y_pos == 0) {
/* 567 */       return 1;
/*     */     }
/* 569 */     if (y_pos == y_max) {
/* 570 */       return 2;
/*     */     }
/*     */ 
/*     */     
/* 574 */     int direction = -1;
/* 575 */     int x_diff = (x_pos < x_max / 2) ? (x_pos - x_max / 2) : (x_max - x_pos);
/* 576 */     int y_diff = (y_pos < y_max / 2) ? (y_pos - y_max / 2) : (y_max - y_pos);
/* 577 */     int near = (Math.abs(x_diff) < Math.abs(y_diff)) ? x_diff : y_diff;
/* 578 */     if (near == x_diff) {
/* 579 */       if (x_diff < 0) {
/* 580 */         direction = 3;
/* 581 */         point.setLocation(r.getMinX(), point.getY());
/*     */       } else {
/*     */         
/* 584 */         direction = 2;
/* 585 */         point.setLocation(r.getMaxX() - 1.0D, point.getY());
/*     */       }
/*     */     
/*     */     }
/* 589 */     else if (y_diff < 0) {
/* 590 */       direction = 1;
/* 591 */       point.setLocation(point.getX(), r.getMinY());
/*     */     } else {
/*     */       
/* 594 */       direction = 0;
/* 595 */       point.setLocation(point.getX(), r.getMaxY() - 1.0D);
/*     */     } 
/*     */     
/* 598 */     return direction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void updateAuto() {
/* 611 */     if (this._plane_s == null) {
/*     */       return;
/*     */     }
/*     */     
/* 615 */     if (this._plane_e == null && this._point_e == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 620 */     int[] directions = analyzeAutoDirection();
/* 621 */     int _direction_s = directions[0];
/*     */ 
/*     */     
/* 624 */     int half_x = (this._point_s.x + this._point_e.x) / 2;
/* 625 */     int half_y = (this._point_s.y + this._point_e.y) / 2;
/* 626 */     switch (_direction_s) {
/*     */       
/*     */       case 0:
/*     */       case 1:
/* 630 */         this._half_s = new Point(this._point_s.x, half_y);
/* 631 */         this._half_e = new Point(this._point_e.x, half_y);
/*     */         break;
/*     */       
/*     */       case 2:
/*     */       case 3:
/* 636 */         this._half_s = new Point(half_x, this._point_s.y);
/* 637 */         this._half_e = new Point(half_x, this._point_e.y);
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 642 */     updateShape();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int[] analyzeAutoDirection() {
/* 654 */     Rectangle r_s = this._plane_s.getBounds();
/* 655 */     this._point_s = new Point();
/* 656 */     this._point_s.setLocation(r_s.getCenterX(), r_s.getCenterY());
/* 657 */     Rectangle r_e = null;
/* 658 */     if (this._plane_e != null) {
/* 659 */       r_e = this._plane_e.getBounds();
/* 660 */       this._point_e = new Point();
/* 661 */       this._point_e.setLocation(r_e.getCenterX(), r_e.getCenterY());
/*     */     } 
/*     */ 
/*     */     
/* 665 */     int diff_x = this._point_e.x - this._point_s.x;
/* 666 */     int diff_y = this._point_e.y - this._point_s.y;
/*     */ 
/*     */ 
/*     */     
/* 670 */     (new int[2])[0] = 2; (new int[2])[1] = 3;
/* 671 */     (new int[2])[0] = 3; (new int[2])[1] = 2;
/*     */ 
/*     */     
/* 674 */     (new int[2])[1] = 1;
/* 675 */     (new int[2])[0] = 1; int[] directions = (Math.abs(diff_x) > Math.abs(diff_y)) ? ((this._point_s.getX() < this._point_e.getX()) ? new int[2] : new int[2]) : ((this._point_s.getY() < this._point_e.getY()) ? new int[2] : new int[2]);
/*     */ 
/*     */ 
/*     */     
/* 679 */     switch (directions[0]) {
/*     */       case 0:
/* 681 */         this._point_s.setLocation(r_s.getCenterX(), r_s.getMaxY() - 1.0D);
/*     */         break;
/*     */       case 1:
/* 684 */         this._point_s.setLocation(r_s.getCenterX(), r_s.getMinY());
/*     */         break;
/*     */       case 2:
/* 687 */         this._point_s.setLocation(r_s.getMaxX() - 1.0D, r_s.getCenterY());
/*     */         break;
/*     */       case 3:
/* 690 */         this._point_s.setLocation(r_s.getMinX(), r_s.getCenterY());
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 695 */     if (r_e != null) {
/* 696 */       switch (directions[1]) {
/*     */         case 1:
/* 698 */           this._point_e.setLocation(r_e.getCenterX(), r_e.getMinY());
/*     */           break;
/*     */         case 0:
/* 701 */           this._point_e.setLocation(r_e.getCenterX(), r_e.getMaxY() - 1.0D);
/*     */           break;
/*     */         case 3:
/* 704 */           this._point_e.setLocation(r_e.getMinX(), r_e.getCenterY());
/*     */           break;
/*     */         case 2:
/* 707 */           this._point_e.setLocation(r_e.getMaxX() - 1.0D, r_e.getCenterY());
/*     */           break;
/*     */       } 
/*     */     
/*     */     }
/* 712 */     return directions;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateShape() {
/* 722 */     GeneralPath path = (GeneralPath)this.shape;
/* 723 */     path.reset();
/*     */ 
/*     */     
/* 726 */     path.moveTo(this._point_s.getX(), this._point_s.getY());
/* 727 */     path.lineTo(this._half_s.getX(), this._half_s.getY());
/* 728 */     path.lineTo(this._half_e.getX(), this._half_e.getY());
/* 729 */     path.lineTo(this._point_e.getX(), this._point_e.getY());
/*     */ 
/*     */     
/* 732 */     if (this._arrow_s) {
/* 733 */       addArrowShape(this._point_s, this._half_s, (GeneralPath)this.shape);
/*     */     }
/* 735 */     if (this._arrow_e) {
/* 736 */       addArrowShape(this._point_e, this._half_e, (GeneralPath)this.shape);
/*     */     }
/*     */ 
/*     */     
/* 740 */     Rectangle r = (new Line2D.Double(this._point_s, this._point_e)).getBounds();
/* 741 */     this.x = r.x;
/* 742 */     this.y = r.y;
/* 743 */     this.w = r.width;
/* 744 */     this.h = r.height;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addArrowShape(Point s, Point e, GeneralPath path) {
/* 756 */     int len = 8;
/* 757 */     int wide = 4;
/* 758 */     int direction = analyzeDirection(s, e);
/* 759 */     switch (direction) {
/*     */       case 0:
/* 761 */         path.moveTo(s.getX() - wide, s.getY() + len);
/* 762 */         path.lineTo(s.getX(), s.getY());
/* 763 */         path.lineTo(s.getX() + wide, s.getY() + len);
/*     */         break;
/*     */       case 1:
/* 766 */         path.moveTo(s.getX() - wide, s.getY() - len);
/* 767 */         path.lineTo(s.getX(), s.getY());
/* 768 */         path.lineTo(s.getX() + wide, s.getY() - len);
/*     */         break;
/*     */       case 2:
/* 771 */         path.moveTo(s.getX() + len, s.getY() - wide);
/* 772 */         path.lineTo(s.getX(), s.getY());
/* 773 */         path.lineTo(s.getX() + len, s.getY() + wide);
/*     */         break;
/*     */       case 3:
/* 776 */         path.moveTo(s.getX() - len, s.getY() - wide);
/* 777 */         path.lineTo(s.getX(), s.getY());
/* 778 */         path.lineTo(s.getX() - len, s.getY() + wide);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getStatusText() {
/* 787 */     return "x1[" + this._point_s.x + "] y1[" + this._point_s.y + "] - " + 
/* 788 */       "x2[" + this._half_s.x + "] y2[" + this._half_s.y + "] - " + 
/* 789 */       "x3[" + this._half_e.x + "] y3[" + this._half_e.y + "] -" + 
/* 790 */       "x4[" + this._point_e.x + "] y4[" + this._point_e.y + "]";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void paint(Graphics2D g2) {
/* 796 */     if (this.shape == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 802 */     Rectangle bk_clip = g2.getClipBounds();
/* 803 */     Color bk_color = g2.getColor();
/* 804 */     Stroke bk_stroke = g2.getStroke();
/*     */ 
/*     */ 
/*     */     
/* 808 */     g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, 
/* 809 */         RenderingHints.VALUE_ANTIALIAS_ON);
/*     */ 
/*     */     
/* 812 */     Stroke stroke = getStroke();
/*     */ 
/*     */     
/* 815 */     Rectangle shape_rect = stroke.createStrokedShape(this.shape).getBounds();
/* 816 */     Rectangle clip = g2.getClipBounds();
/* 817 */     clip = clip.intersection(shape_rect);
/* 818 */     if (clip.isEmpty()) {
/*     */       return;
/*     */     }
/*     */     
/* 822 */     g2.clipRect(clip.x, clip.y, clip.width, clip.height);
/*     */ 
/*     */     
/* 825 */     Color line = getLineColor();
/* 826 */     if (line != null) {
/* 827 */       g2.setStroke(stroke);
/* 828 */       g2.setPaint(line);
/* 829 */       g2.draw(this.shape);
/*     */ 
/*     */       
/* 832 */       float[] dash = getLineDash();
/* 833 */       setLineDash((float[])null);
/* 834 */       g2.setStroke(getStroke());
/* 835 */       if (this._arrow_s) {
/* 836 */         GeneralPath arrow = new GeneralPath();
/* 837 */         addArrowShape(this._point_s, this._half_s, arrow);
/* 838 */         g2.draw(arrow);
/*     */       } 
/* 840 */       if (this._arrow_e) {
/* 841 */         GeneralPath arrow = new GeneralPath();
/* 842 */         addArrowShape(this._point_e, this._half_e, arrow);
/* 843 */         g2.draw(arrow);
/*     */       } 
/* 845 */       setLineDash(dash);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 850 */     g2.setStroke(bk_stroke);
/* 851 */     g2.setColor(bk_color);
/* 852 */     g2.setClip(bk_clip);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\canvas\MCConnector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */