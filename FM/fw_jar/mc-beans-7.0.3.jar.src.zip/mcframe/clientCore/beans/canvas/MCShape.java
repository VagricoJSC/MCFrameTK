/*     */ package mcframe.clientCore.beans.canvas;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.Shape;
/*     */ import java.awt.Stroke;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import mcframe.clientCore.beans.MCCanvas;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MCShape
/*     */   extends MCCanvasItem
/*     */   implements Cloneable
/*     */ {
/*     */   protected Shape shape;
/*  39 */   private Object _lockObj = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   private Set<PropertyChangeListener> pcListenerSet = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void addPropertyChangeListener(PropertyChangeListener listener) {
/*  56 */     if (listener == null) {
/*     */       return;
/*     */     }
/*  59 */     synchronized (this._lockObj) {
/*  60 */       if (this.pcListenerSet == null) {
/*  61 */         this.pcListenerSet = new HashSet<>();
/*     */       }
/*  63 */       this.pcListenerSet.add(listener);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void removePropertyChangeListener(PropertyChangeListener listener) {
/*  75 */     synchronized (this._lockObj) {
/*  76 */       if (this.pcListenerSet != null) {
/*  77 */         this.pcListenerSet.remove(listener);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void firePropertyChange(String name, Object oldValue, Object newValue) {
/*  92 */     PropertyChangeEvent evt = new PropertyChangeEvent(this, name, oldValue, newValue);
/*  93 */     if (this.pcListenerSet == null) {
/*     */       return;
/*     */     }
/*  96 */     for (PropertyChangeListener l : this.pcListenerSet) {
/*  97 */       l.propertyChange(evt);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCShapeSelector<?> createSelector(MCCanvas canvas) {
/* 123 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCShapeEditor<?> createEditor(MCCanvas canvas) {
/* 138 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean contains(int x, int y) {
/* 164 */     return (this.shape != null) ? this.shape.contains(x, y) : false;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCShape clone() {
/*     */     try {
/* 170 */       MCShape shape = (MCShape)super.clone();
/* 171 */       shape.cloneImpl(this);
/* 172 */       return shape;
/*     */     }
/* 174 */     catch (CloneNotSupportedException cloneNotSupportedException) {
/*     */ 
/*     */       
/* 177 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public abstract String getStatusText();
/*     */   
/*     */   public abstract boolean initBounds(MCCanvas paramMCCanvas, int paramInt1, int paramInt2);
/*     */   
/*     */   public abstract Dimension getDefaultSize();
/*     */   
/*     */   protected abstract void cloneImpl(MCShape paramMCShape);
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\canvas\MCShape.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */