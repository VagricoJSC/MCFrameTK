package mcframe.clientCore.beans.canvas;

import java.awt.Component;
import java.awt.Point;
import javax.swing.border.Border;
import mcframe.clientCore.beans.MCCanvas;

public interface MCSelectorBorder extends Border {
  MCCanvas.ResizeDirection getResizeDirection(Component paramComponent, Point paramPoint);
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\canvas\MCSelectorBorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */