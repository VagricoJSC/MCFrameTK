/*     */ package mcframe.clientCore.beans.canvas;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Cursor;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.Stroke;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.geom.GeneralPath;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import mcframe.clientCore.beans.MCCanvas;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCPlaneSelector
/*     */   extends MCShapeSelector<MCPlane>
/*     */ {
/*     */   private final int _thick;
/*  41 */   private MCCanvas.ResizeDirection _resize = null; private boolean _drag; private boolean _cancel; public boolean canSelect(int x, int y) { if (super.canSelect(x, y))
/*     */       return true; 
/*     */     return (getResizeDirection(new Point(x, y)) != null); }
/*     */   public void resetBounds() { int offset = this._thick / 2;
/*     */     Rectangle r = getShape().getBounds();
/*     */     this.x = r.x - offset;
/*     */     this.y = r.y - offset;
/*     */     this.w = r.width + offset * 2;
/*     */     this.h = r.height + offset * 2; }
/*     */   public boolean isResizeDirection(Point p) {
/*     */     return (getResizeDirection(p) != null);
/*     */   }
/*  53 */   protected MCPlaneSelector(MCCanvas canvas, MCPlane shape) { super(canvas, shape);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 267 */     this._drag = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 274 */     this._cancel = false; this._thick = 7; setLineWidth(1.0F); setLineColor(Color.BLUE); resetBounds(); }
/*     */   private MCCanvas.ResizeDirection getResizeDirection(Point p) { Rectangle r = getBounds(); int x1 = r.x; int x2 = r.x + r.width - this._thick; int y1 = r.y; int y2 = r.y + r.height - this._thick; r.setSize(this._thick, this._thick); r.setLocation(x1, y1); if (r.contains(p)) return MCCanvas.ResizeDirection.LT;  r.setLocation(x1, y2); if (r.contains(p))
/*     */       return MCCanvas.ResizeDirection.LB;  r.setLocation(x2, y1); if (r.contains(p))
/*     */       return MCCanvas.ResizeDirection.RT;  r.setLocation(x2, y2); if (r.contains(p))
/* 278 */       return MCCanvas.ResizeDirection.RB;  return null; } protected void setCursor(MouseEvent e, MCCanvas canvas) { int cursor = 0;
/* 279 */     Point p = e.getPoint();
/* 280 */     MCCanvas.ResizeDirection direction = getResizeDirection(p);
/* 281 */     if (direction != null) {
/* 282 */       switch (direction) {
/*     */         case LT:
/* 284 */           cursor = 6;
/*     */           break;
/*     */         case null:
/* 287 */           cursor = 4;
/*     */           break;
/*     */         case RT:
/* 290 */           cursor = 7;
/*     */           break;
/*     */         case RB:
/* 293 */           cursor = 5;
/*     */           break;
/*     */       } 
/*     */     }
/* 297 */     if (cursor == 0 && 
/* 298 */       contains(p.x, p.y))
/*     */     {
/* 300 */       cursor = 12;
/*     */     }
/*     */     
/* 303 */     canvas.setCursor(Cursor.getPredefinedCursor(cursor)); }
/*     */   protected void createEditorShapes() { this.canvas.createEditorShapes(); }
/*     */   protected void removeEditorShapes() { this.canvas.removeEditorShapes(); } protected void zoomEditorShapes(Point orgPoint, Point newPoint) {
/*     */     if (this._resize != null)
/*     */       this.canvas.zoomEditorShapes(orgPoint, newPoint, this._resize); 
/*     */   } protected void resizeEditorShapes(Point orgPoint, Point newPoint) {
/*     */     if (this._resize != null)
/*     */       this.canvas.resizeEditorShapes(orgPoint, newPoint, this._resize); 
/*     */   } protected void moveEditorShapes(Point orgPoint, Point newPoint) {
/*     */     this.canvas.moveEditorShapes(orgPoint, newPoint);
/*     */   } private void setDragCursor(MCCanvas canvas) {
/* 314 */     canvas.setCursor(Cursor.getPredefinedCursor(1));
/*     */   } protected void commitEditorShapes() {
/*     */     this.canvas.commitEditorShapes();
/*     */   }
/*     */   protected void copyEditorShapes() {
/*     */     this.canvas.copyEditorShapes();
/*     */   }
/* 321 */   protected void mousePressed(MouseEvent e, MCCanvas canvas, Point start) { if (e.isControlDown())
/*     */     {
/* 323 */       this._cancel = true;
/*     */     }
/*     */     
/* 326 */     this._resize = getResizeDirection(start);
/* 327 */     if (this._resize != null)
/*     */     {
/*     */       
/* 330 */       setDragCursor(canvas); }  } protected void cancelSelect() { this.canvas.cancelSelect(getShape()); }
/*     */   protected void paintSelector(Graphics2D g2) { g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON); Stroke stroke = getStroke(); Rectangle shape_rect = getBounds(); Rectangle clip = g2.getClipBounds(); clip = clip.intersection(shape_rect); if (clip.isEmpty())
/*     */       return;  g2.clipRect(clip.x, clip.y, clip.width, clip.height); Color color = getLineColor(); if (color == null)
/*     */       return;  g2.setStroke(stroke); g2.setPaint(color); int offset = this._thick / 2; g2.draw(new Rectangle2D.Double((this.x + offset), (this.y + offset), (this.w - offset * 2), (this.h - offset * 2))); GeneralPath path = new GeneralPath(); path.reset(); int x2 = this.x + this.w - this._thick; int y2 = this.y + this.h - this._thick; path.append(new Rectangle2D.Double(this.x, this.y, this._thick, this._thick), false); path.append(new Rectangle2D.Double(this.x, y2, this._thick, this._thick), false);
/*     */     path.append(new Rectangle2D.Double(x2, this.y, this._thick, this._thick), false);
/*     */     path.append(new Rectangle2D.Double(x2, y2, this._thick, this._thick), false);
/*     */     g2.fill(path); }
/* 337 */   protected void mouseDragged(MouseEvent e, MCCanvas canvas, Point start) { this._cancel = false;
/*     */     
/* 339 */     if (!this._drag)
/*     */     {
/* 341 */       createEditorShapes();
/*     */     }
/*     */     
/* 344 */     Point orgPoint = start;
/* 345 */     Point newPoint = e.getPoint();
/* 346 */     if (this._resize != null) {
/* 347 */       if (e.isControlDown())
/*     */       {
/* 349 */         zoomEditorShapes(orgPoint, newPoint);
/*     */       }
/*     */       else
/*     */       {
/* 353 */         resizeEditorShapes(orgPoint, newPoint);
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 358 */       moveEditorShapes(orgPoint, newPoint);
/*     */     } 
/*     */ 
/*     */     
/* 362 */     this._drag = true; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void mouseReleased(MouseEvent e, MCCanvas canvas, Point start) {
/* 368 */     boolean ctrl = e.isControlDown();
/*     */     
/* 370 */     if (this._cancel) {
/*     */       
/* 372 */       cancelSelect();
/*     */ 
/*     */     
/*     */     }
/* 376 */     else if (this._resize != null) {
/*     */       
/* 378 */       commitEditorShapes();
/*     */     
/*     */     }
/* 381 */     else if (ctrl) {
/*     */       
/* 383 */       copyEditorShapes();
/*     */     }
/*     */     else {
/*     */       
/* 387 */       commitEditorShapes();
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 393 */     removeEditorShapes();
/*     */ 
/*     */     
/* 396 */     this._drag = false;
/* 397 */     this._cancel = false;
/* 398 */     this._resize = null;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\canvas\MCPlaneSelector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */