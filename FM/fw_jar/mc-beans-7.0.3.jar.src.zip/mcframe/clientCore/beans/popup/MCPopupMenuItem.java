package mcframe.clientCore.beans.popup;

import javax.swing.KeyStroke;
import mcframe.clientCore.beans.MCACBeans;
import mcframe.clientCore.beans.MCModeBeans;
import mcframe.clientCore.beans.MCResourceBeans;
import mcframe.clientCore.event.MCAPBeans;
import mcframe.clientCore.event.MCNEBeans;
import mcframe.clientCore.event.MCNXBeans;

public interface MCPopupMenuItem extends MCAPBeans, MCNEBeans, MCNXBeans, MCResourceBeans, MCACBeans, MCModeBeans {
  void setOrder(int paramInt);
  
  int getOrder();
  
  void setAccelerator(KeyStroke paramKeyStroke);
  
  void setAccelerator(int paramInt);
  
  void setAccelerator(int paramInt1, int paramInt2);
  
  KeyStroke getAccelerator();
  
  boolean isVisible();
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\popup\MCPopupMenuItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */