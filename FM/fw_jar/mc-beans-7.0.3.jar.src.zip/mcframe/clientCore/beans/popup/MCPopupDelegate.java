/*     */ package mcframe.clientCore.beans.popup;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MCPopupDelegate
/*     */ {
/*     */   private final MCPopupBeans _compo;
/*  24 */   private Map<String, MCMenu> _menu_map = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  32 */   private Map<String, MCTextPopupMenuItem> _item_map = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCPopupDelegate(MCPopupBeans compo) {
/*  42 */     this._compo = compo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, MCMenu> getMenuMap() {
/*  53 */     return (this._menu_map != null) ? 
/*  54 */       this._menu_map : (this._menu_map = new HashMap<>());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, MCTextPopupMenuItem> getMenuItemMap() {
/*  65 */     return (this._item_map != null) ? 
/*  66 */       this._item_map : (
/*  67 */       this._item_map = new HashMap<>());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCMenu getMenu(String name) {
/*  79 */     Map<String, MCMenu> a = getMenuMap();
/*  80 */     MCMenu m = a.get(name);
/*  81 */     if (m != null) {
/*  82 */       return m;
/*     */     }
/*  84 */     m = new MCMenu(getMenuName(name));
/*  85 */     a.put(name, m);
/*  86 */     return m;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCTextPopupMenuItem getMenuItem(String name) {
/*  98 */     Map<String, MCTextPopupMenuItem> a = getMenuItemMap();
/*  99 */     MCTextPopupMenuItem m = a.get(name);
/* 100 */     if (m != null) {
/* 101 */       return m;
/*     */     }
/* 103 */     m = new MCTextPopupMenuItem(getMenuName(name));
/* 104 */     a.put(name, m);
/* 105 */     return m;
/*     */   }
/*     */   
/*     */   private String getMenuName(String name) {
/* 109 */     return MCConst.createKey(new String[] { this._compo.getType(), name });
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\popup\MCPopupDelegate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */