package mcframe.clientCore.beans.popup;

import mcframe.clientCore.beans.MCResourceBeans;
import mcframe.clientCore.beans.text.MCCalendarValidator;
import mcframe.commonCore.lang.MCCalendarDate;
import mcframe.commonCore.notice.MCMessageList;

public interface MCCalendarBeans<T extends MCCalendarDate<?>> extends MCResourceBeans {
  void popupMenuWillBecomeVisible();
  
  void popupMenuWillBecomeInvisible();
  
  void setCalendarEnabled(boolean paramBoolean);
  
  boolean isCalendarEnabled();
  
  void showCalendar();
  
  T getViewValue();
  
  void setCalendarValue(T paramT);
  
  T doParse(String paramString);
  
  String doFormat(MCCalendarDate<?> paramMCCalendarDate);
  
  MCMessageList checkValue(Comparable<?> paramComparable);
  
  MCCalendarValidator getCalendarValidator();
  
  void setInitCalendarFocus(T paramT);
  
  T getInitCalendarFocus();
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\popup\MCCalendarBeans.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */