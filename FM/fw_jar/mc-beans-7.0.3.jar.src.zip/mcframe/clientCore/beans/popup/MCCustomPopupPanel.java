package mcframe.clientCore.beans.popup;

public interface MCCustomPopupPanel {
  void afterInit(MCCustomPopup paramMCCustomPopup);
  
  MCCustomPopup getCustomPopup();
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\popup\MCCustomPopupPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */