/*     */ package mcframe.clientCore.beans.popup;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JPopupMenu;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.event.PopupMenuEvent;
/*     */ import javax.swing.event.PopupMenuListener;
/*     */ import mcframe.clientCore.beans.MCBeans;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCFrame;
/*     */ import mcframe.clientCore.beans.MCResourceBeans;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.layout.MCHiresoManager;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.util.MCCollectionUtil;
/*     */ import mcframe.commonCore.util.MCSimpleList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MCPopupMenu
/*     */   extends JPopupMenu
/*     */ {
/*  48 */   private static MCPopupMenu ACTIVE = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final MCPopupBeans _compo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<JPopupMenu.Separator, MCSeparatorInfo> _separator_info_map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCPopupMenu(MCPopupBeans compo) {
/*  75 */     if (compo != null) {
/*  76 */       this._compo = compo;
/*     */     } else {
/*     */       
/*  79 */       throw new MCException(Core_Msg_FW_A.FCBAC0151, new Object[0]);
/*     */     } 
/*  81 */     init();
/*     */   }
/*     */   
/*     */   private final void init() {
/*  85 */     initPopup();
/*     */   }
/*     */   
/*     */   private final void initPopup() {
/*  89 */     addPropertyChangeListener(new MCPropertyChangeListener(null));
/*  90 */     setMenuScroller();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class MCPropertyChangeListener
/*     */     implements PropertyChangeListener
/*     */   {
/*     */     private MCPropertyChangeListener() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void propertyChange(PropertyChangeEvent evt) {
/* 109 */       if ("visible".equals(evt.getPropertyName()) && 
/* 110 */         MCBeansUtil.suppressAfter()) {
/* 111 */         MCPopupMenu.this.setVisible(false);
/* 112 */         MCBeansUtil.suppressAfter(false);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCTextPopupMenuItem add(MCTextPopupMenuItem item) {
/* 128 */     if (item == null) {
/* 129 */       return item;
/*     */     }
/*     */     
/* 132 */     item.setBeans(getBeans());
/* 133 */     item.added();
/* 134 */     return (MCTextPopupMenuItem)add(item);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCTextPopupMenuItem add(MCTextPopupMenuItem item, int index) {
/* 148 */     if (item == null) {
/* 149 */       return item;
/*     */     }
/*     */     
/* 152 */     item.setBeans(getBeans());
/* 153 */     item.added();
/* 154 */     return (MCTextPopupMenuItem)add(item, index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCMenu add(MCMenu menu) {
/* 167 */     if (menu == null) {
/* 168 */       return menu;
/*     */     }
/*     */     
/* 171 */     if (menu.getBeans() == null) {
/* 172 */       menu.setBeans(getBeans());
/*     */     }
/* 174 */     menu.added();
/* 175 */     return (MCMenu)add(menu);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCMenu add(MCMenu menu, int index) {
/* 189 */     if (menu == null) {
/* 190 */       return menu;
/*     */     }
/*     */     
/* 193 */     if (menu.getBeans() == null) {
/* 194 */       menu.setBeans(getBeans());
/*     */     }
/* 196 */     menu.added();
/* 197 */     return (MCMenu)add(menu, index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCPopupBeans getBeans() {
/* 208 */     return this._compo;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void show(Component invoker, int x, int y) {
/* 214 */     if (getParent() == null) {
/* 215 */       MCPopupBeans compo = getBeans();
/*     */       
/*     */       try {
/* 218 */         MCRootPanel bp = compo.getBaseRootPanel();
/*     */ 
/*     */ 
/*     */         
/* 222 */         JComponent owner = MCBeansUtil.getFocusOwner(bp);
/*     */         
/* 224 */         if (!MCBeansUtil.requestCommit(owner)) {
/*     */           return;
/*     */         }
/*     */         
/* 228 */         if (bp != null) {
/* 229 */           MCFrame f = bp.getFrame();
/* 230 */           if (f != null && !f.isActive()) {
/*     */             return;
/*     */           }
/*     */         } 
/*     */         
/* 235 */         MCPopupMenu menu = compo.configurePopup();
/* 236 */         if (menu == null || (menu.getComponents()).length == 0) {
/*     */           return;
/*     */         }
/*     */ 
/*     */         
/* 241 */         boolean v = false; Component o; byte b; int i; Component[] arrayOfComponent;
/* 242 */         for (i = (arrayOfComponent = menu.getComponents()).length, b = 0, o = arrayOfComponent[b]; b < i && 
/* 243 */           !(v = o.isVisible()); b++);
/*     */ 
/*     */ 
/*     */         
/* 247 */         if (!v) {
/*     */           return;
/*     */         }
/*     */ 
/*     */         
/* 252 */         compo.popupMenuWillBecomeVisible();
/*     */ 
/*     */ 
/*     */         
/* 256 */         MCHiresoManager.updateMenuFont(bp, menu);
/*     */ 
/*     */         
/* 259 */         menu.showPopup(invoker, x, y);
/*     */       }
/* 261 */       catch (Throwable t) {
/* 262 */         compo.handle(t);
/*     */       } 
/*     */     } else {
/*     */       
/* 266 */       showPopup(invoker, x, y);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void showPopup(Component invoker, int x, int y) {
/* 273 */     ACTIVE = this;
/* 274 */     super.show(invoker, x, y);
/*     */   }
/*     */ 
/*     */   
/*     */   public void sort() {
/* 279 */     TreeMap<Integer, Component> o_map = new TreeMap<>();
/* 280 */     MCSimpleList<Component> no_list = new MCSimpleList(Component.class);
/* 281 */     Component[] cs = getComponents();
/* 282 */     int cnt = cs.length;
/* 283 */     for (int i = 0; i < cnt; i++) {
/* 284 */       Component c = cs[i];
/* 285 */       if (c instanceof MCMenu) {
/* 286 */         MCMenu m = (MCMenu)c;
/* 287 */         if (m.isVisible()) {
/* 288 */           m.sort();
/* 289 */           int o = m.getOrder();
/* 290 */           if (o > 0) {
/* 291 */             o_map.put(Integer.valueOf(adjustOrder(o_map, o)), c);
/*     */           } else {
/*     */             
/* 294 */             no_list.add(c);
/*     */           } 
/* 296 */           remove(c);
/*     */         }
/*     */       
/* 299 */       } else if (c instanceof MCPopupMenuItem) {
/* 300 */         MCPopupMenuItem m = (MCPopupMenuItem)c;
/* 301 */         if (m.isVisible()) {
/* 302 */           int o = m.getOrder();
/* 303 */           if (o > 0) {
/* 304 */             o_map.put(Integer.valueOf(adjustOrder(o_map, o)), c);
/*     */           } else {
/*     */             
/* 307 */             no_list.add(c);
/*     */           } 
/* 309 */           remove(c);
/*     */         }
/*     */       
/* 312 */       } else if (c instanceof JPopupMenu.Separator) {
/* 313 */         JPopupMenu.Separator s = (JPopupMenu.Separator)c;
/*     */         
/* 315 */         MCSeparatorInfo si = getSeparatorInfoMap().get(s);
/* 316 */         if (si != null) {
/* 317 */           Boolean v = si.getResourceVisible(getBeans());
/* 318 */           if (Boolean.FALSE.equals(v)) {
/* 319 */             s.setVisible(false);
/*     */           }
/* 321 */           if (s.isVisible()) {
/* 322 */             Integer o = si.getResourceOrder(getBeans());
/* 323 */             if (o != null && o.intValue() > 0) {
/* 324 */               o_map.put(Integer.valueOf(adjustOrder(o_map, o.intValue())), s);
/*     */             } else {
/*     */               
/* 327 */               no_list.add(c);
/*     */             } 
/* 329 */             remove(c);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 335 */     Component[] no_items = (Component[])no_list.array();
/* 336 */     int n_cnt = no_items.length;
/* 337 */     if (n_cnt != 0) {
/*     */       
/* 339 */       int x = -1;
/* 340 */       for (Integer integer : o_map.keySet()) {
/* 341 */         x = Math.max(x, integer.intValue());
/*     */       }
/* 343 */       for (int k = 0; k < n_cnt; k++) {
/* 344 */         Component c = no_items[k];
/* 345 */         o_map.put(Integer.valueOf(++x), c);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 367 */     cnt = o_map.size();
/* 368 */     Component[] compos = (Component[])o_map.values().toArray((Object[])new Component[cnt]);
/* 369 */     for (int j = 0; j < cnt; j++) {
/* 370 */       add(compos[j]);
/*     */     }
/*     */   }
/*     */   
/*     */   private int adjustOrder(Map<Integer, Component> map, int order) {
/*     */     while (true) {
/* 376 */       if (!map.containsKey(Integer.valueOf(order))) {
/* 377 */         return order;
/*     */       }
/* 379 */       order++;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVisible(boolean visible) {
/* 386 */     if (!visible) {
/* 387 */       getBeans().popupMenuWillBecomeInvisible();
/* 388 */       super.setVisible(visible);
/* 389 */       ACTIVE = null;
/*     */ 
/*     */ 
/*     */       
/* 393 */       SwingUtilities.invokeLater(new Runnable()
/*     */           {
/*     */             public void run()
/*     */             {
/* 397 */               MCBeansUtil.suppressAfter(false);
/*     */             }
/*     */           });
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */       
/* 407 */       super.setVisible(visible);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void hideActivePopupMenu() {
/* 419 */     if (ACTIVE != null) {
/* 420 */       ACTIVE.setVisible(false);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void localeChanged() {
/* 431 */     localeChanged(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void localeChanged(Container cont) {
/* 442 */     Component[] cs = cont.getComponents();
/* 443 */     int cnt = cs.length;
/* 444 */     for (int i = 0; i < cnt; i++) {
/* 445 */       Component c = cs[i];
/* 446 */       if (c instanceof MCBeans) {
/* 447 */         ((MCBeans)c).localeChanged();
/*     */       }
/* 449 */       else if (c instanceof Container) {
/* 450 */         localeChanged((Container)c);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource() {
/* 462 */     updateResources(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateResources(Container cont) {
/* 473 */     Component[] cs = cont.getComponents();
/* 474 */     int cnt = cs.length;
/* 475 */     for (int i = 0; i < cnt; i++) {
/* 476 */       Component c = cs[i];
/* 477 */       if (c instanceof MCResourceBeans) {
/* 478 */         ((MCResourceBeans)c).updateResource();
/*     */       }
/* 480 */       else if (c instanceof Container) {
/* 481 */         updateResources((Container)c);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource(MCRootPanel panel) {
/* 494 */     updateResources(this, panel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateResources(Container cont, MCRootPanel panel) {
/*     */     byte b;
/*     */     int i;
/*     */     Component[] arrayOfComponent;
/* 506 */     for (i = (arrayOfComponent = cont.getComponents()).length, b = 0; b < i; ) { Component c = arrayOfComponent[b];
/* 507 */       if (c instanceof MCResourceBeans) {
/* 508 */         ((MCResourceBeans)c).updateResource(panel);
/*     */       }
/* 510 */       else if (c instanceof Container) {
/* 511 */         updateResources((Container)c, panel);
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void addSeparator() {
/* 522 */     super.addSeparator();
/*     */   }
/*     */   
/*     */   public void addSeparator(String name) {
/* 526 */     if (!MCStringUtil.isNull(name)) {
/* 527 */       getSeparatorInfoMap().put(
/* 528 */           (JPopupMenu.Separator)add(new JPopupMenu.Separator()), 
/* 529 */           new MCSeparatorInfo(name));
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean contains(Component compo) {
/* 534 */     return contains(this, compo);
/*     */   }
/*     */   
/*     */   private boolean contains(Container cont, Component compo) {
/* 538 */     Component[] cs = cont.getComponents(); byte b; int i; Component[] arrayOfComponent1;
/* 539 */     for (i = (arrayOfComponent1 = cs).length, b = 0; b < i; ) { Component c = arrayOfComponent1[b];
/* 540 */       if (c == compo) {
/* 541 */         return true;
/*     */       }
/* 543 */       if (c instanceof Container && 
/* 544 */         contains((Container)c, compo)) {
/* 545 */         return true;
/*     */       }
/*     */       b++; }
/*     */     
/* 549 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void remove(Component comp) {
/* 559 */     super.remove(comp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeMenu(MCMenu menu) {
/* 570 */     remove(this, getComponents(), menu);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeMenuItem(MCTextPopupMenuItem item) {
/* 581 */     remove(this, getComponents(), item);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void remove(Container parent, Component[] compos, Component compo) {
/* 597 */     if (MCCollectionUtil.contains(compo, (Object[])compos)) {
/* 598 */       parent.remove(compo); return;
/*     */     } 
/*     */     byte b;
/*     */     int i;
/*     */     Component[] arrayOfComponent;
/* 603 */     for (i = (arrayOfComponent = compos).length, b = 0; b < i; ) { Component c = arrayOfComponent[b];
/* 604 */       if (c instanceof MCMenu) {
/* 605 */         MCMenu m = (MCMenu)c;
/* 606 */         remove(m, m.getMenuComponents(), compo);
/*     */       }
/* 608 */       else if (c instanceof Container) {
/* 609 */         Container o = (Container)c;
/* 610 */         remove(o, o.getComponents(), compo);
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<JPopupMenu.Separator, MCSeparatorInfo> getSeparatorInfoMap() {
/* 624 */     return (this._separator_info_map != null) ? 
/* 625 */       this._separator_info_map : (
/* 626 */       this._separator_info_map = new LinkedHashMap<>());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 635 */   private int _interval = 150;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 643 */   private int _firstIndex = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCMenuScrollItem _upItem;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCMenuScrollItem _downItem;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Component[] _orgComponents;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMenuScroller() {
/* 668 */     this._upItem = new MCMenuScrollItem(MCPopupScrollIcon.UP, -1, this._interval, 
/* 669 */         new PopupMenuScrollEvent(null));
/*     */     
/* 671 */     this._downItem = new MCMenuScrollItem(MCPopupScrollIcon.DOWN, 1, this._interval, 
/* 672 */         new PopupMenuScrollEvent(null));
/*     */     
/* 674 */     addPopupMenuListener(new MCMenuScrollListener(null));
/*     */   }
/*     */   
/*     */   private class PopupMenuScrollEvent implements MCPopupMenuScrollEvent { private PopupMenuScrollEvent() {}
/*     */     
/*     */     public void actionPerformed(int increment) {
/* 680 */       MCPopupMenu.this._firstIndex = MCPopupMenu.this._firstIndex + increment;
/* 681 */       MCPopupMenu.this.adjustMenuItems();
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class MCMenuScrollListener
/*     */     implements PopupMenuListener
/*     */   {
/*     */     private MCMenuScrollListener() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void popupMenuWillBecomeVisible(PopupMenuEvent e) {
/* 702 */       MCPopupMenu.this._firstIndex = 0;
/* 703 */       setMenuItems();
/*     */     }
/*     */ 
/*     */     
/*     */     public void popupMenuWillBecomeInvisible(PopupMenuEvent e) {
/* 708 */       restoreMenuItems();
/*     */     }
/*     */ 
/*     */     
/*     */     public void popupMenuCanceled(PopupMenuEvent e) {
/* 713 */       restoreMenuItems();
/*     */     }
/*     */     
/*     */     private void setMenuItems() {
/* 717 */       MCPopupMenu.this._orgComponents = MCPopupMenu.this.getComponents();
/* 718 */       MCPopupMenu.this.adjustMenuItems();
/*     */     }
/*     */     
/*     */     private void restoreMenuItems() {
/* 722 */       MCPopupMenu.this.removeAll();
/* 723 */       MCPopupMenu.this._firstIndex = 0; byte b; int i; Component[] arrayOfComponent;
/* 724 */       for (i = (arrayOfComponent = MCPopupMenu.this._orgComponents).length, b = 0; b < i; ) { Component component = arrayOfComponent[b];
/* 725 */         MCPopupMenu.this.add(component);
/*     */         b++; }
/*     */     
/*     */     } }
/*     */   
/*     */   private void adjustMenuItems() {
/* 731 */     int maxItemCnt = MCPopupUtil.getMaxItemCnt();
/* 732 */     int cnt = MCPopupUtil.getVisibleItemCount(this._orgComponents);
/* 733 */     if (maxItemCnt <= 0 || cnt <= maxItemCnt) {
/*     */       return;
/*     */     }
/*     */     
/* 737 */     removeAll();
/*     */     
/* 739 */     add(this._upItem);
/*     */     
/* 741 */     while (!this._orgComponents[this._firstIndex].isVisible())
/*     */     {
/*     */       
/* 744 */       this._firstIndex++;
/*     */     }
/* 746 */     this._upItem.setEnabled(
/* 747 */         (this._firstIndex > MCPopupUtil.getFirstVisibleItemIndex(this._orgComponents)));
/* 748 */     this._downItem.setEnabled(true);
/*     */     
/* 750 */     int added = 0;
/* 751 */     int i = this._firstIndex;
/* 752 */     int lastVisible = MCPopupUtil.getLastVisibleItemIndex(this._orgComponents);
/* 753 */     while (added < maxItemCnt && i < lastVisible + 1) {
/* 754 */       if (this._orgComponents[i].isVisible()) {
/* 755 */         add(this._orgComponents[i]);
/* 756 */         added++;
/*     */       } 
/* 758 */       i++;
/*     */     } 
/*     */     
/* 761 */     add(this._downItem);
/* 762 */     if (i == lastVisible + 1) {
/* 763 */       this._downItem.setEnabled(false);
/*     */     }
/*     */     
/* 766 */     pack();
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\popup\MCPopupMenu.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */