package mcframe.clientCore.beans.popup;

public interface MCPopupMenuScrollEvent {
  void actionPerformed(int paramInt);
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\popup\MCPopupMenuScrollEvent.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */