/*    */ package mcframe.clientCore.beans.popup;
/*    */ 
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import javax.swing.Timer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCMenuScrollTimer
/*    */   extends Timer
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public MCMenuScrollTimer(int increment, int interval, MCPopupMenuScrollEvent event) {
/* 21 */     super(interval, new ActionListener(event, increment)
/*    */         {
/*    */           public void actionPerformed(ActionEvent e) {
/* 24 */             event.actionPerformed(increment);
/*    */           }
/*    */         });
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\popup\MCMenuScrollTimer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */