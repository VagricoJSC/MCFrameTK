/*    */ package mcframe.clientCore.beans.popup;
/*    */ 
/*    */ import javax.swing.JMenuItem;
/*    */ import javax.swing.event.ChangeEvent;
/*    */ import javax.swing.event.ChangeListener;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCMenuScrollItem
/*    */   extends JMenuItem
/*    */   implements ChangeListener
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private MCMenuScrollTimer _timer;
/*    */   
/*    */   public MCMenuScrollItem(MCPopupScrollIcon icon, int increment, int interval, MCPopupMenuScrollEvent event) {
/* 22 */     setIcon(icon);
/* 23 */     setDisabledIcon(icon);
/* 24 */     this._timer = new MCMenuScrollTimer(increment, interval, event);
/* 25 */     addChangeListener(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public void stateChanged(ChangeEvent e) {
/* 30 */     if (isArmed() && !this._timer.isRunning()) {
/* 31 */       this._timer.start();
/*    */     }
/* 33 */     if (!isArmed() && this._timer.isRunning())
/* 34 */       this._timer.stop(); 
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\popup\MCMenuScrollItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */