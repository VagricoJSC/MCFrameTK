/*      */ package mcframe.clientCore.beans.popup;
/*      */ 
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.Container;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Font;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.event.MouseEvent;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.Map;
/*      */ import java.util.TreeMap;
/*      */ import javax.swing.JMenu;
/*      */ import javax.swing.JMenuItem;
/*      */ import javax.swing.JPopupMenu;
/*      */ import javax.swing.event.PopupMenuEvent;
/*      */ import javax.swing.event.PopupMenuListener;
/*      */ import mcframe.clientCore.beans.MCACBeans;
/*      */ import mcframe.clientCore.beans.MCBeans;
/*      */ import mcframe.clientCore.beans.MCBeansDelegate;
/*      */ import mcframe.clientCore.beans.MCBeansUtil;
/*      */ import mcframe.clientCore.beans.MCMode;
/*      */ import mcframe.clientCore.beans.MCModeBeans;
/*      */ import mcframe.clientCore.beans.MCModeInfo;
/*      */ import mcframe.clientCore.beans.MCResourceBeans;
/*      */ import mcframe.clientCore.beans.MCRootPanel;
/*      */ import mcframe.clientCore.beans.layout.MCHiresoManager;
/*      */ import mcframe.clientCore.event.MCEventBeans;
/*      */ import mcframe.clientCore.event.MCEventInfo;
/*      */ import mcframe.clientCore.event.MCEventList;
/*      */ import mcframe.clientCore.event.MCEventListener;
/*      */ import mcframe.clientCore.event.MCNEBeans;
/*      */ import mcframe.clientCore.event.MCNEListener;
/*      */ import mcframe.clientCore.event.MCNXBeans;
/*      */ import mcframe.clientCore.event.MCNXListener;
/*      */ import mcframe.clientCore.resource.MCConst;
/*      */ import mcframe.commonCore.lang.MCStringUtil;
/*      */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*      */ import mcframe.commonCore.notice.MCException;
/*      */ import mcframe.commonCore.resource.MCConst;
/*      */ import mcframe.commonCore.resource.ctrl.MCResource;
/*      */ import mcframe.commonCore.util.MCSimpleList;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MCMenu
/*      */   extends JMenu
/*      */   implements MCNEBeans, MCNXBeans, MCModeBeans, MCACBeans
/*      */ {
/*   64 */   private final MCEventList _event_list = new MCEventList();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   72 */   private MCEventInfo _event_info = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   80 */   private MCMode _mode = MCMode.NULL;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   88 */   private MCBeansDelegate _delegate = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MCPopupBeans _compo;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Map<JPopupMenu.Separator, MCSeparatorInfo> _separator_info_map;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  112 */   private int _order = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  120 */   private Boolean _stock_visible = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  128 */   private String _message_name_resource = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  136 */   private String _message_name = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  144 */   private String _label_name = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  152 */   private String _ac_type = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int _interval;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int _firstIndex;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MCMenuScrollItem _upItem;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MCMenuScrollItem _downItem;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Component[] _orgComponents;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setBeans(MCPopupBeans compo) {
/*  196 */     this._compo = compo;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void init() {
/*  206 */     updateResource();
/*  207 */     setMenuScroller();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initResource() {
/*  217 */     setForeground((MCRootPanel)null);
/*  218 */     setBackground((MCRootPanel)null);
/*  219 */     setFont((MCRootPanel)null);
/*      */ 
/*      */     
/*  222 */     String m = MCBeansProxy.PROXY.getLabelMsg(getName());
/*  223 */     if (m != null) {
/*  224 */       this._message_name_resource = m;
/*      */     }
/*      */ 
/*      */     
/*  228 */     String l = MCBeansProxy.PROXY.getLabel(getName());
/*  229 */     if (l != null) {
/*  230 */       this._label_name = l;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setName(String name) {
/*  244 */     MCBeansUtil.checkName(name);
/*  245 */     super.setName(name);
/*  246 */     initResource();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCTextPopupMenuItem add(MCTextPopupMenuItem item) {
/*  259 */     if (item == null) {
/*  260 */       return null;
/*      */     }
/*      */     
/*  263 */     item.setBeans(getBeans());
/*  264 */     item.added();
/*  265 */     return (MCTextPopupMenuItem)add(item);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCTextPopupMenuItem add(MCTextPopupMenuItem item, int index) {
/*  279 */     if (item == null) {
/*  280 */       return item;
/*      */     }
/*      */     
/*  283 */     item.setBeans(getBeans());
/*  284 */     item.added();
/*  285 */     return (MCTextPopupMenuItem)add(item, index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCMenu add(MCMenu menu) {
/*  298 */     if (menu == null) {
/*  299 */       return menu;
/*      */     }
/*      */     
/*  302 */     menu.setBeans(getBeans());
/*  303 */     menu.added();
/*  304 */     return (MCMenu)add(menu);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCMenu add(MCMenu menu, int index) {
/*  318 */     if (menu == null) {
/*  319 */       return menu;
/*      */     }
/*      */     
/*  322 */     menu.setBeans(getBeans());
/*  323 */     menu.added();
/*  324 */     return (MCMenu)add(menu, index);
/*      */   }
/*      */   
/*      */   public boolean contains(Component compo) {
/*  328 */     Component[] cs = getMenuComponents(); byte b; int i; Component[] arrayOfComponent1;
/*  329 */     for (i = (arrayOfComponent1 = cs).length, b = 0; b < i; ) { Component c = arrayOfComponent1[b];
/*  330 */       if (c == compo) {
/*  331 */         return true;
/*      */       }
/*  333 */       if (c instanceof Container && 
/*  334 */         contains((Container)c, compo)) {
/*  335 */         return true;
/*      */       }
/*      */       b++; }
/*      */     
/*  339 */     return contains(this, compo);
/*      */   }
/*      */   
/*      */   private boolean contains(Container cont, Component compo) {
/*  343 */     Component[] cs = cont.getComponents(); byte b; int i; Component[] arrayOfComponent1;
/*  344 */     for (i = (arrayOfComponent1 = cs).length, b = 0; b < i; ) { Component c = arrayOfComponent1[b];
/*  345 */       if (c == compo) {
/*  346 */         return true;
/*      */       }
/*  348 */       if (c instanceof Container && 
/*  349 */         contains((Container)c, compo)) {
/*  350 */         return true;
/*      */       }
/*      */       b++; }
/*      */     
/*  354 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public MCEventInfo getEventInfo() {
/*  359 */     if (this._event_info == null) {
/*  360 */       this._event_info = new MCEventInfo();
/*  361 */       MCEventProxy.PROXY.setComponent(this._event_info, (MCEventBeans)this);
/*      */     } 
/*  363 */     return this._event_info;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addAllListener(MCEventListener listener) {
/*  384 */     addNEListener((MCNEListener)listener);
/*  385 */     addNXListener((MCNXListener)listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAllListener(MCEventListener listener) {
/*  406 */     setNEListener((MCNEListener)listener);
/*  407 */     setNXListener((MCNXListener)listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void addNXListener(MCNXListener listener) {
/*  412 */     this._event_list.add(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNXListener(MCNXListener listener) {
/*  417 */     this._event_list.set(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void removeNXListener(MCNXListener listener) {
/*  422 */     this._event_list.remove(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public final MCNXListener[] getNXListeners() {
/*  427 */     return this._event_list.nx();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void doNX() {
/*  449 */     MCBeansUtil.nx(this);
/*      */   }
/*      */ 
/*      */   
/*      */   public final MCNEListener[] getNEListeners() {
/*  454 */     return this._event_list.ne();
/*      */   }
/*      */ 
/*      */   
/*      */   public final void addNEListener(MCNEListener listener) {
/*  459 */     this._event_list.add(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNEListener(MCNEListener listener) {
/*  464 */     this._event_list.set(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void removeNEListener(MCNEListener listener) {
/*  469 */     this._event_list.remove(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void doNE() {
/*  491 */     MCBeansUtil.ne(this);
/*      */   }
/*      */ 
/*      */   
/*      */   public MCMode getMode() {
/*  496 */     return this._mode;
/*      */   }
/*      */ 
/*      */   
/*      */   public final MCModeInfo getModeInfo() {
/*  501 */     return getModeInfo(getMode());
/*      */   }
/*      */ 
/*      */   
/*      */   public final MCModeInfo getModeInfo(MCMode mode) {
/*  506 */     return getDelegate().getModeInfo(this, mode);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setMode(MCMode mode) {
/*  511 */     MCRootPanel bp = getBaseRootPanel();
/*  512 */     if (!MCMode.isNull(mode)) {
/*  513 */       MCBeansUtil.log(bp, (MCBeans)this, Core_Msg_FW_A.FCBAC0013, new Object[] { mode.getName() });
/*  514 */       this._mode = mode;
/*  515 */       MCModeInfo mi = getModeInfo();
/*  516 */       int s = mi.getStatus();
/*  517 */       switch (s) {
/*      */         case 1:
/*  519 */           setVisible(true);
/*  520 */           setEnabled(true);
/*  521 */           setFocusable(true);
/*      */           break;
/*      */         case 2:
/*  524 */           setVisible(true);
/*  525 */           setEnabled(false);
/*  526 */           setFocusable(false);
/*      */           break;
/*      */         case 3:
/*  529 */           setVisible(false);
/*      */           break;
/*      */       } 
/*      */ 
/*      */       
/*  534 */       setForeground(mi.getForeground());
/*  535 */       setBackground(mi.getBackground());
/*  536 */       MCBeansUtil.log(bp, (MCBeans)this, Core_Msg_FW_A.FCBAC0014, new Object[] { mode.getName() });
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void added() {
/*  542 */     if (MCMode.isNull(this._mode)) {
/*  543 */       this._mode = MCMode.ENABLE;
/*      */     }
/*      */     
/*  546 */     Component[] compos = getComponents();
/*  547 */     int cnt = compos.length;
/*  548 */     for (int i = 0; i < cnt; i++) {
/*  549 */       Component c = compos[i];
/*  550 */       if (c instanceof MCTextPopupMenuItem) {
/*  551 */         ((MCTextPopupMenuItem)c).setBeans(getBeans());
/*  552 */         ((MCTextPopupMenuItem)c).added();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean equalsIgnoreCase(Component compo) {
/*  559 */     return equals(compo);
/*      */   }
/*      */ 
/*      */   
/*      */   public MCRootPanel getBaseRootPanel() {
/*  564 */     MCPopupBeans c = getBeans();
/*  565 */     return (c != null) ? c.getBaseRootPanel() : null;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getLabelByLocale() {
/*  570 */     return getText();
/*      */   }
/*      */ 
/*      */   
/*      */   public String getMessageByLocale() {
/*  575 */     String result = this._message_name;
/*  576 */     if (result == null) {
/*  577 */       result = this._message_name_resource;
/*      */     }
/*  579 */     if (MCStringUtil.isNull(result)) {
/*  580 */       result = getLabelByLocale();
/*      */     }
/*  582 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public MCRootPanel getRootPanel() {
/*  587 */     MCPopupBeans c = getBeans();
/*  588 */     return (c != null) ? c.getRootPanel() : null;
/*      */   }
/*      */ 
/*      */   
/*      */   public MCRootPanel getNearestRootPanel() {
/*  593 */     MCPopupBeans c = getBeans();
/*  594 */     return (c != null) ? c.getNearestRootPanel() : null;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getType() {
/*  599 */     return "popup";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void initialized() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void localeChanged() {
/*  621 */     updateResource();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removed() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void updateBounds(int ratio) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void updateFontSize(int ratio) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateResource() {
/*  667 */     updateResource(getBaseRootPanel());
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateResource(MCRootPanel panel) {
/*  672 */     if (panel != null) {
/*  673 */       setForeground(panel);
/*  674 */       setBackground(panel);
/*  675 */       setOrder(panel);
/*  676 */       setFont(panel);
/*      */ 
/*      */       
/*  679 */       setLabelText();
/*      */       
/*  681 */       String m = MCBeansUtil.getMessageName((MCResourceBeans)this);
/*  682 */       if (m != null) {
/*  683 */         this._message_name_resource = m;
/*      */       }
/*      */       
/*  686 */       setMCToolTipText(
/*  687 */           (this._message_name != null) ? this._message_name : this._message_name_resource);
/*      */       
/*  689 */       setACType();
/*      */       
/*  691 */       setVisible();
/*      */     } 
/*  693 */     updateResources(this, panel);
/*      */   }
/*      */   
/*      */   private void updateResources(MCMenu menu, MCRootPanel panel) {
/*  697 */     _updateResources(menu, panel);
/*  698 */     _updateResources(menu.getPopupMenu(), panel); } private void _updateResources(Container cont, MCRootPanel panel) {
/*      */     byte b;
/*      */     int i;
/*      */     Component[] arrayOfComponent;
/*  702 */     for (i = (arrayOfComponent = cont.getComponents()).length, b = 0; b < i; ) { Component c = arrayOfComponent[b];
/*  703 */       if (c instanceof MCResourceBeans) {
/*  704 */         ((MCResourceBeans)c).updateResource(panel);
/*      */       }
/*  706 */       else if (c instanceof Container) {
/*  707 */         _updateResources((Container)c, panel);
/*      */       } 
/*      */       b++; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setForeground(MCRootPanel panel) {
/*  720 */     Color def = getForeground();
/*  721 */     String prefix = MCResource.createKey(new String[] { getType(), getName(), "fg" });
/*  722 */     String key = MCBeansProxy.PROXY.getBeansKey((MCResourceBeans)this, prefix);
/*  723 */     if (MCStringUtil.isNull(key)) {
/*  724 */       prefix = MCResource.createKey(new String[] { getType(), "fg" });
/*  725 */       key = MCBeansProxy.PROXY.getBeansKey((MCResourceBeans)this, prefix);
/*      */     } 
/*  727 */     if (!MCStringUtil.isNull(key)) {
/*  728 */       Color col = MCConst.beans.getColor(key, def);
/*  729 */       if (col != def) {
/*  730 */         setForeground(col);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setBackground(MCRootPanel panel) {
/*  743 */     Color def = getBackground();
/*  744 */     String prefix = MCResource.createKey(new String[] { getType(), getName(), "bg" });
/*  745 */     String key = MCBeansProxy.PROXY.getBeansKey((MCResourceBeans)this, prefix);
/*  746 */     if (MCStringUtil.isNull(key)) {
/*  747 */       prefix = MCResource.createKey(new String[] { getType(), "bg" });
/*  748 */       key = MCBeansProxy.PROXY.getBeansKey((MCResourceBeans)this, prefix);
/*      */     } 
/*  750 */     if (!MCStringUtil.isNull(key)) {
/*  751 */       Color col = MCConst.beans.getColor(key, def);
/*  752 */       if (col != def) {
/*  753 */         setBackground(col);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setOpaque(boolean opaque) {
/*  760 */     super.setOpaque(true);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isOpaque() {
/*  765 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setFont(MCRootPanel panel) {
/*  776 */     Font def = getFont();
/*  777 */     String prefix = MCResource.createKey(new String[] { getType(), "font" });
/*  778 */     String key = MCBeansProxy.PROXY.getBeansKey((MCResourceBeans)this, prefix);
/*  779 */     if (!MCStringUtil.isNull(key)) {
/*  780 */       Font font = MCConst.beans.getFont(key, def);
/*  781 */       if (font != def) {
/*  782 */         setFont(font);
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void setLabelText() {
/*  788 */     String l = MCBeansUtil.getLabel((MCBeans)this);
/*  789 */     if (l != null) {
/*  790 */       this._label_name = l;
/*      */     }
/*  792 */     String t = this._label_name;
/*  793 */     if (t != null && !t.equals(getText())) {
/*  794 */       setText(t);
/*      */     }
/*      */   }
/*      */   
/*      */   protected void setMCToolTipText(String text) {
/*  799 */     if (!MCStringUtil.isNull(text)) {
/*  800 */       setToolTipText(text);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getToolTipText(MouseEvent event) {
/*  807 */     String tip = getToolTipText();
/*  808 */     tip = MCHiresoManager.getToolTipText(this, tip);
/*  809 */     return tip;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void addAliasName(String alias, MCRootPanel panel) {
/*  814 */     getDelegate().addAliasName(alias, panel);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setAliasName(String alias, MCRootPanel panel) {
/*  819 */     getDelegate().setAliasName(alias, panel);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void removeAliasName(MCRootPanel panel) {
/*  824 */     getDelegate().removeAliasName(panel);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void removeAliasNames() {
/*  829 */     getDelegate().removeAliasNames();
/*      */   }
/*      */ 
/*      */   
/*      */   public final String getAliasName(MCRootPanel panel) {
/*  834 */     return getDelegate().getAliasName(panel);
/*      */   }
/*      */ 
/*      */   
/*      */   public final String[] getAliasNames() {
/*  839 */     return getDelegate().getAliasNames();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MCBeansDelegate getDelegate() {
/*  850 */     if (this._delegate == null) {
/*  851 */       this._delegate = new MCBeansDelegate();
/*      */     }
/*  853 */     return this._delegate;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCPopupBeans getBeans() {
/*  864 */     return this._compo;
/*      */   }
/*      */   
/*      */   protected void setOrder(MCRootPanel panel) {
/*  868 */     int def = this._order;
/*  869 */     String prefix = MCResource.createKey(new String[] { getType(), getName(), "order" });
/*  870 */     String key = MCBeansProxy.PROXY.getBeansKey((MCResourceBeans)this, prefix);
/*  871 */     if (MCStringUtil.isNull(key)) {
/*  872 */       prefix = MCResource.createKey(new String[] { getType(), "order" });
/*  873 */       key = MCBeansProxy.PROXY.getBeansKey((MCResourceBeans)this, prefix);
/*      */     } 
/*  875 */     if (!MCStringUtil.isNull(key)) {
/*  876 */       int o = MCConst.beans.getInteger(key, def);
/*  877 */       if (o != def) {
/*  878 */         setOrder(o);
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   public final void setOrder(int o) {
/*  884 */     this._order = o;
/*      */   }
/*      */   
/*      */   public int getOrder() {
/*  888 */     return this._order;
/*      */   }
/*      */   
/*      */   final void sort() {
/*  892 */     TreeMap<Integer, Component> o_map = new TreeMap<>();
/*  893 */     MCSimpleList<Component> no_list = new MCSimpleList(Component.class);
/*  894 */     Component[] cs = getMenuComponents();
/*  895 */     int cnt = cs.length;
/*  896 */     for (int i = 0; i < cnt; i++) {
/*  897 */       Component c = cs[i];
/*  898 */       if (c instanceof MCMenu) {
/*  899 */         MCMenu m = (MCMenu)c;
/*  900 */         if (m.isVisible()) {
/*  901 */           m.sort();
/*  902 */           int o = m.getOrder();
/*  903 */           if (o > 0) {
/*  904 */             o_map.put(Integer.valueOf(adjustOrder(o_map, o)), c);
/*      */           } else {
/*      */             
/*  907 */             no_list.add(c);
/*      */           } 
/*  909 */           remove(c);
/*      */         }
/*      */       
/*  912 */       } else if (c instanceof MCPopupMenuItem) {
/*  913 */         MCPopupMenuItem m = (MCPopupMenuItem)c;
/*  914 */         if (m.isVisible()) {
/*  915 */           int o = m.getOrder();
/*  916 */           if (o > 0) {
/*  917 */             o_map.put(Integer.valueOf(adjustOrder(o_map, o)), c);
/*      */           } else {
/*      */             
/*  920 */             no_list.add(c);
/*      */           } 
/*  922 */           remove(c);
/*      */         }
/*      */       
/*  925 */       } else if (c instanceof JPopupMenu.Separator) {
/*  926 */         JPopupMenu.Separator s = (JPopupMenu.Separator)c;
/*      */         
/*  928 */         MCSeparatorInfo si = getSeparatorInfoMap().get(s);
/*  929 */         if (si != null) {
/*  930 */           Boolean v = si.getResourceVisible(getBeans());
/*  931 */           if (Boolean.FALSE.equals(v)) {
/*  932 */             s.setVisible(false);
/*      */           }
/*  934 */           if (s.isVisible()) {
/*  935 */             Integer o = si.getResourceOrder(getBeans());
/*  936 */             if (o != null && o.intValue() > 0) {
/*  937 */               o_map.put(Integer.valueOf(adjustOrder(o_map, o.intValue())), s);
/*      */             } else {
/*      */               
/*  940 */               no_list.add(c);
/*      */             } 
/*  942 */             remove(c);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  948 */     Component[] no_items = (Component[])no_list.array();
/*  949 */     int n_cnt = no_items.length;
/*  950 */     if (n_cnt != 0) {
/*      */       
/*  952 */       int x = -1;
/*  953 */       for (Integer integer : o_map.keySet()) {
/*  954 */         x = Math.max(x, integer.intValue());
/*      */       }
/*  956 */       for (int k = 0; k < n_cnt; k++) {
/*  957 */         Component c = no_items[k];
/*  958 */         o_map.put(Integer.valueOf(++x), c);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  980 */     cnt = o_map.size();
/*  981 */     Component[] compos = (Component[])o_map.values().toArray((Object[])new Component[cnt]);
/*  982 */     for (int j = 0; j < cnt; j++) {
/*  983 */       add(compos[j]);
/*      */     }
/*      */   }
/*      */   
/*      */   private int adjustOrder(Map<Integer, Component> map, int order) {
/*      */     while (true) {
/*  989 */       if (!map.containsKey(Integer.valueOf(order))) {
/*  990 */         return order;
/*      */       }
/*  992 */       order++;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isVisible() {
/*  998 */     return (super.isVisible() && authorize());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setVisible() {
/* 1008 */     if (this._stock_visible != null) {
/*      */       return;
/*      */     }
/*      */     
/* 1012 */     String p = MCResource.createKey(new String[] { "popup", getName(), "visible" });
/* 1013 */     Boolean visible = null;
/* 1014 */     if (isExcludeVisiblePtn() && !isIncludeVisiblePtn()) {
/* 1015 */       visible = Boolean.valueOf(!MCConst.beans.getBoolean(p));
/*      */     }
/*      */     
/* 1018 */     if (visible == null) {
/*      */       
/* 1020 */       String k = MCBeansProxy.PROXY.getBeansKey(getBeans(), p);
/* 1021 */       if (MCStringUtil.isNull(k)) {
/* 1022 */         p = MCResource.createKey(new String[] { "popup", "visible" });
/* 1023 */         k = MCBeansProxy.PROXY.getBeansKey(getBeans(), p);
/*      */       } 
/* 1025 */       if (!MCStringUtil.isNull(k)) {
/* 1026 */         this._stock_visible = Boolean.valueOf(MCConst.beans.getBoolean(k, true));
/*      */       }
/*      */     } else {
/*      */       
/* 1030 */       this._stock_visible = visible;
/*      */     } 
/*      */     
/* 1033 */     if (this._stock_visible != null) {
/* 1034 */       setVisible(this._stock_visible.booleanValue());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isExcludeVisiblePtn() {
/* 1046 */     return isIncludePtn(
/* 1047 */         MCResource.createKey(new String[] { "popup", getName(), "visible", "*", "excld" }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isIncludeVisiblePtn() {
/* 1058 */     return isIncludePtn(
/* 1059 */         MCResource.createKey(new String[] { "popup", getName(), "visible", "*", "incld" }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isIncludePtn(String k) {
/* 1071 */     String[] ids = {
/* 1072 */         getBeans().getBaseRootPanel().getScreenID()
/*      */       };
/* 1074 */     String[] keys = MCConst.beans.findPattern(
/* 1075 */         MCConst.createKey(new String[] { getBeans().getBaseRootPanel().getModuleID(), k })); byte b; int i; String[] arrayOfString1;
/* 1076 */     for (i = (arrayOfString1 = keys).length, b = 0; b < i; ) { String key = arrayOfString1[b];
/* 1077 */       String value = MCConst.beans.getString(key);
/* 1078 */       if (!MCStringUtil.isNull(value)) {
/* 1079 */         String[] ptns = MCStringUtil.split(",", value); byte b1; int j; String[] arrayOfString2;
/* 1080 */         for (j = (arrayOfString2 = ptns).length, b1 = 0; b1 < j; ) { String ptn = arrayOfString2[b1];
/* 1081 */           if (!MCStringUtil.isNull(ptn)) {
/* 1082 */             String[] results = MCStringUtil.match(ptn.trim(), ids, '.');
/* 1083 */             if (results.length > 0)
/* 1084 */               return true; 
/*      */           }  b1++; }
/*      */       
/*      */       } 
/*      */       b++; }
/*      */     
/* 1090 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void addSeparator() {
/* 1099 */     super.addSeparator();
/*      */   }
/*      */   
/*      */   public void addSeparator(String name) {
/* 1103 */     if (!MCStringUtil.isNull(name)) {
/* 1104 */       getSeparatorInfoMap().put((JPopupMenu.Separator)add(new JPopupMenu.Separator()), 
/* 1105 */           new MCSeparatorInfo(name));
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public MCMode getMode(MCRootPanel panel, String status) {
/* 1111 */     return getDelegate().getMode(panel, status);
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] getStatuses(MCRootPanel panel) {
/* 1116 */     return getDelegate().getStatuses(panel);
/*      */   }
/*      */ 
/*      */   
/*      */   public void putMode(MCRootPanel panel, String status, MCMode mode) {
/* 1121 */     getDelegate().putMode(panel, status, mode);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setMode(MCRootPanel panel, String status) {
/* 1126 */     setMode(getMode(panel, status));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setVisible(boolean visible) {
/* 1131 */     this._stock_visible = Boolean.valueOf(visible);
/* 1132 */     super.setVisible(visible);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void _setVisible(boolean visible) {
/* 1141 */     super.setVisible(visible);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void _restoreVisible() {
/* 1153 */     if (this._stock_visible != null) {
/* 1154 */       super.setVisible(this._stock_visible.booleanValue());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Dimension getDefaultSize() {
/* 1169 */     return getSize();
/*      */   }
/*      */   
/*      */   public void setDefaultSize(Rectangle r) {
/* 1173 */     setBounds(r);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void afterRequestFocus() {}
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void handle(Throwable t) {}
/*      */ 
/*      */   
/*      */   public void setMessageName(String name) {
/* 1188 */     this._message_name = MCBeansProxy.PROXY.adjustMessageName(name);
/*      */ 
/*      */     
/* 1191 */     setMCToolTipText((this._message_name != null) ? this._message_name : this._message_name_resource);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public String _getMessageName() {
/* 1197 */     return this._message_name;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void _cacheDefaultBounds(Rectangle bounds) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public Rectangle getDefaultBounds() {
/* 1208 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void _setDefaultBounds() {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void remove(Component c) {
/* 1223 */     super.remove(c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void remove(JMenuItem item) {
/* 1233 */     super.remove(item);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean authorize() {
/* 1239 */     if (MCBeansProxy.PROXY.isACTypeDisable(this)) {
/* 1240 */       return true;
/*      */     }
/*      */     
/* 1243 */     return MCBeansUtil.authorize(this);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean checkAC() {
/* 1248 */     return authorize();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public boolean checkPassword() {
/* 1261 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setACType() {
/* 1271 */     String k = MCBeansUtil.getACTypeKey((MCResourceBeans)this);
/* 1272 */     if (!MCStringUtil.isNull(k)) {
/* 1273 */       String a = MCConst.actype.getType(new String[] { k });
/* 1274 */       this._ac_type = a;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public String getACType() {
/* 1280 */     return this._ac_type;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public boolean needsPassword() {
/* 1293 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void setPasswordDialog(String module, String screen) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public String[] getPasswordDialogID() {
/* 1319 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Map<JPopupMenu.Separator, MCSeparatorInfo> getSeparatorInfoMap() {
/* 1330 */     return (this._separator_info_map != null) ? this._separator_info_map : (
/* 1331 */       this._separator_info_map = new LinkedHashMap<>());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCMenu(MCPopupBeans compo, String name) {
/* 1340 */     this._interval = 150;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1348 */     this._firstIndex = 0; if (compo != null) { this._compo = compo; setName(name); init(); } else { throw new MCException(Core_Msg_FW_A.FCBAC0151, new Object[0]); }  } public MCMenu(String name) { this._interval = 150; this._firstIndex = 0;
/*      */     setName(name);
/*      */     init(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMenuScroller() {
/* 1373 */     this._upItem = new MCMenuScrollItem(MCPopupScrollIcon.UP, -1, this._interval, 
/* 1374 */         new PopupMenuScrollEvent(null));
/*      */     
/* 1376 */     this._downItem = new MCMenuScrollItem(MCPopupScrollIcon.DOWN, 1, this._interval, 
/* 1377 */         new PopupMenuScrollEvent(null));
/*      */     
/* 1379 */     getPopupMenu().addPopupMenuListener(new MCMenuScrollListener(null));
/*      */   }
/*      */   
/*      */   private class PopupMenuScrollEvent implements MCPopupMenuScrollEvent { private PopupMenuScrollEvent() {}
/*      */     
/*      */     public void actionPerformed(int increment) {
/* 1385 */       MCMenu.this._firstIndex = MCMenu.this._firstIndex + increment;
/* 1386 */       MCMenu.this.adjustMenuItems();
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private class MCMenuScrollListener
/*      */     implements PopupMenuListener
/*      */   {
/*      */     private MCMenuScrollListener() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void popupMenuWillBecomeVisible(PopupMenuEvent e) {
/* 1407 */       MCMenu.this._firstIndex = 0;
/* 1408 */       setMenuItems();
/*      */     }
/*      */ 
/*      */     
/*      */     public void popupMenuWillBecomeInvisible(PopupMenuEvent e) {
/* 1413 */       restoreMenuItems();
/*      */     }
/*      */ 
/*      */     
/*      */     public void popupMenuCanceled(PopupMenuEvent e) {
/* 1418 */       restoreMenuItems();
/*      */     }
/*      */     
/*      */     private void setMenuItems() {
/* 1422 */       MCMenu.this._orgComponents = MCMenu.this.getMenuComponents();
/* 1423 */       MCMenu.this.adjustMenuItems();
/*      */     }
/*      */     
/*      */     private void restoreMenuItems() {
/* 1427 */       MCMenu.this.removeAll();
/* 1428 */       MCMenu.this._firstIndex = 0; byte b; int i; Component[] arrayOfComponent;
/* 1429 */       for (i = (arrayOfComponent = MCMenu.this._orgComponents).length, b = 0; b < i; ) { Component component = arrayOfComponent[b];
/* 1430 */         MCMenu.this.add(component);
/*      */         b++; }
/*      */     
/*      */     } }
/*      */   
/*      */   private void adjustMenuItems() {
/* 1436 */     int maxItemCnt = MCPopupUtil.getMaxItemCnt();
/* 1437 */     int cnt = MCPopupUtil.getVisibleItemCount(this._orgComponents);
/* 1438 */     if (maxItemCnt <= 0 || cnt <= maxItemCnt) {
/*      */       return;
/*      */     }
/*      */     
/* 1442 */     JPopupMenu popupMenu = getPopupMenu();
/* 1443 */     popupMenu.removeAll();
/*      */     
/* 1445 */     popupMenu.add(this._upItem);
/*      */     
/* 1447 */     while (!this._orgComponents[this._firstIndex].isVisible())
/*      */     {
/*      */       
/* 1450 */       this._firstIndex++;
/*      */     }
/* 1452 */     this._upItem.setEnabled(
/* 1453 */         (this._firstIndex > MCPopupUtil.getFirstVisibleItemIndex(this._orgComponents)));
/* 1454 */     this._downItem.setEnabled(true);
/*      */     
/* 1456 */     int added = 0;
/* 1457 */     int i = this._firstIndex;
/* 1458 */     int lastVisible = MCPopupUtil.getLastVisibleItemIndex(this._orgComponents);
/* 1459 */     while (added < maxItemCnt && i < lastVisible + 1) {
/* 1460 */       if (this._orgComponents[i].isVisible()) {
/* 1461 */         popupMenu.add(this._orgComponents[i]);
/* 1462 */         added++;
/*      */       } 
/* 1464 */       i++;
/*      */     } 
/*      */     
/* 1467 */     popupMenu.add(this._downItem);
/* 1468 */     if (i == lastVisible + 1) {
/* 1469 */       this._downItem.setEnabled(false);
/*      */     }
/*      */     
/* 1472 */     popupMenu.pack();
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\popup\MCMenu.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */