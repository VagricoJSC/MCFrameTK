/*    */ package mcframe.clientCore.beans.popup;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.awt.Component;
/*    */ import java.awt.Dimension;
/*    */ import java.awt.Graphics;
/*    */ import javax.swing.Icon;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum MCPopupScrollIcon
/*    */   implements Icon
/*    */ {
/* 19 */   UP(new int[] { 9, 1, 9 }),
/* 20 */   DOWN(new int[] { 6, 14, 6 });
/* 21 */   final int[] xPoints = new int[] {
/* 22 */       1, 5, 9
/*    */     };
/*    */   
/*    */   final int[] yPoints;
/*    */   
/*    */   MCPopupScrollIcon(int... yPoints) {
/* 28 */     this.yPoints = yPoints;
/*    */   }
/*    */ 
/*    */   
/*    */   public void paintIcon(Component c, Graphics g, int x, int y) {
/* 33 */     Dimension size = c.getSize();
/* 34 */     Graphics g2 = g.create(size.width / 2 - 5, 0, 15, 15);
/* 35 */     g2.setColor(Color.GRAY);
/* 36 */     g2.drawPolygon(this.xPoints, this.yPoints, 3);
/* 37 */     if (c.isEnabled()) {
/* 38 */       g2.setColor(Color.BLACK);
/* 39 */       g2.fillPolygon(this.xPoints, this.yPoints, 3);
/*    */     } 
/* 41 */     g2.dispose();
/*    */   }
/*    */ 
/*    */   
/*    */   public int getIconWidth() {
/* 46 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getIconHeight() {
/* 51 */     return 15;
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\popup\MCPopupScrollIcon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */