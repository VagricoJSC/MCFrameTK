/*    */ package mcframe.clientCore.beans.popup;
/*    */ 
/*    */ import mcframe.clientCore.resource.MCConst;
/*    */ import mcframe.commonCore.lang.MCStringUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MCSeparatorInfo
/*    */ {
/*    */   private final String _separator_name;
/*    */   
/*    */   MCSeparatorInfo(String separatorName) {
/* 24 */     this._separator_name = separatorName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   String getSeparatorName() {
/* 35 */     return this._separator_name;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   Boolean getResourceVisible(MCPopupBeans compo) {
/* 48 */     String pfx = MCConst.createKey(new String[] { "popup", getSeparatorName(), "visible" });
/* 49 */     String k = MCBeansProxy.PROXY.getBeansKey(compo, pfx);
/* 50 */     if (MCStringUtil.isNull(k)) {
/* 51 */       pfx = MCConst.createKey(new String[] { "popup", "visible" });
/* 52 */       k = MCBeansProxy.PROXY.getBeansKey(compo, pfx);
/*    */     } 
/* 54 */     if (!MCStringUtil.isNull(k)) {
/* 55 */       return Boolean.valueOf(MCConst.beans.getBoolean(k, true));
/*    */     }
/* 57 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   Integer getResourceOrder(MCPopupBeans compo) {
/* 70 */     String pfx = MCConst.createKey(new String[] { "popup", getSeparatorName(), "order" });
/* 71 */     String k = MCBeansProxy.PROXY.getBeansKey(compo, pfx);
/* 72 */     if (MCStringUtil.isNull(k)) {
/* 73 */       pfx = MCConst.createKey(new String[] { "popup", "order" });
/* 74 */       k = MCBeansProxy.PROXY.getBeansKey(compo, pfx);
/*    */     } 
/* 76 */     if (!MCStringUtil.isNull(k)) {
/* 77 */       return Integer.valueOf(MCConst.beans.getInteger(k, -1));
/*    */     }
/* 79 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\popup\MCSeparatorInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */