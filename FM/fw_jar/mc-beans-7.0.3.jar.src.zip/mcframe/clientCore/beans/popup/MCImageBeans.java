package mcframe.clientCore.beans.popup;

import mcframe.clientCore.beans.MCModeBeans;
import mcframe.commonCore.lang.MCBinary;
import mcframe.commonCore.notice.MCMessageList;

public interface MCImageBeans extends MCModeBeans {
  void setImagePanelEnabled(boolean paramBoolean);
  
  boolean isImagePanelEnabled();
  
  void setImagePanel(String paramString1, String paramString2);
  
  String[] getImagePanelID();
  
  String getImagePanelModuleID();
  
  String getImagePanelScreenID();
  
  MCMessageList setValue(MCBinary paramMCBinary);
  
  MCBinary getValue();
  
  void setImagePanelInfo(MCImagePanelInfo paramMCImagePanelInfo);
  
  MCImagePanelInfo getImagePanelInfo();
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\popup\MCImageBeans.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */