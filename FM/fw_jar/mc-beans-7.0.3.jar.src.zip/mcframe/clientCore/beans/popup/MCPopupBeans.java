package mcframe.clientCore.beans.popup;

import mcframe.clientCore.beans.MCResourceBeans;

public interface MCPopupBeans extends MCResourceBeans {
  MCPopupMenu configurePopup();
  
  void popupMenuWillBecomeVisible();
  
  void popupMenuWillBecomeInvisible();
  
  void setPopupConfig(MCPopupConfig paramMCPopupConfig);
  
  MCPopupConfig getPopupConfig();
  
  void setComponentPopupMenu(MCPopupMenu paramMCPopupMenu);
  
  MCPopupMenu getComponentPopupMenu();
  
  void removeComponentPopupMenu();
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\popup\MCPopupBeans.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */