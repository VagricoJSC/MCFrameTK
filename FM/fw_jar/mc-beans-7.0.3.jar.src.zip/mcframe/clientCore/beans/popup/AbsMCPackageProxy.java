/*    */ package mcframe.clientCore.beans.popup;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import javax.swing.JLayeredPane;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbsMCPackageProxy
/*    */ {
/*    */   protected void setVisible(boolean visible, MCTextPopupMenuItem... items) {
/* 21 */     if (items == null)
/*    */       return;  byte b; int i;
/*    */     MCTextPopupMenuItem[] arrayOfMCTextPopupMenuItem;
/* 24 */     for (i = (arrayOfMCTextPopupMenuItem = items).length, b = 0; b < i; ) { MCTextPopupMenuItem mCTextPopupMenuItem = arrayOfMCTextPopupMenuItem[b];
/* 25 */       if (mCTextPopupMenuItem != null)
/* 26 */         mCTextPopupMenuItem._setVisible(visible); 
/*    */       b++; }
/*    */   
/*    */   }
/*    */   
/*    */   protected void restoreVisible(MCTextPopupMenuItem... items) {
/* 32 */     if (items == null)
/*    */       return;  byte b; int i;
/*    */     MCTextPopupMenuItem[] arrayOfMCTextPopupMenuItem;
/* 35 */     for (i = (arrayOfMCTextPopupMenuItem = items).length, b = 0; b < i; ) { MCTextPopupMenuItem mCTextPopupMenuItem = arrayOfMCTextPopupMenuItem[b];
/* 36 */       if (mCTextPopupMenuItem != null)
/* 37 */         mCTextPopupMenuItem._restoreVisible(); 
/*    */       b++; }
/*    */   
/*    */   }
/*    */   
/*    */   protected void setVisible(boolean visible, MCMenu... menus) {
/* 43 */     if (menus == null)
/*    */       return;  byte b; int i;
/*    */     MCMenu[] arrayOfMCMenu;
/* 46 */     for (i = (arrayOfMCMenu = menus).length, b = 0; b < i; ) { MCMenu mCMenu = arrayOfMCMenu[b];
/* 47 */       if (mCMenu != null)
/* 48 */         mCMenu._setVisible(visible); 
/*    */       b++; }
/*    */   
/*    */   }
/*    */   
/*    */   protected void restoreVisible(MCMenu... menus) {
/* 54 */     if (menus == null)
/*    */       return;  byte b; int i;
/*    */     MCMenu[] arrayOfMCMenu;
/* 57 */     for (i = (arrayOfMCMenu = menus).length, b = 0; b < i; ) { MCMenu mCMenu = arrayOfMCMenu[b];
/* 58 */       if (mCMenu != null)
/* 59 */         mCMenu._restoreVisible(); 
/*    */       b++; }
/*    */   
/*    */   }
/*    */   
/*    */   protected void setBeans(MCTextPopupMenuItem item, MCPopupBeans compo) {
/* 65 */     item.setBeans(compo);
/*    */   }
/*    */   
/*    */   protected void setBeans(MCMenu menu, MCPopupBeans compo) {
/* 69 */     menu.setBeans(compo);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void addCalenderToLayerdPane(MCCalendarPopup p, Component invoker, int x, int y, JLayeredPane lp) {
/* 74 */     p.addCalenderToLayerdPane(invoker, x, y, lp);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\popup\AbsMCPackageProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */