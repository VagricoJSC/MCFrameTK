/*     */ package mcframe.clientCore.beans.popup;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Point;
/*     */ import javax.swing.JLayeredPane;
/*     */ import javax.swing.JPopupMenu;
/*     */ import javax.swing.SwingUtilities;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCLayouter;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ import mcframe.commonCore.lang.MCCalendarDate;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCCalendarPopup
/*     */   extends JPopupMenu
/*     */ {
/*  37 */   private static MCCalendarPopup ACTIVE = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final MCCalendarBeans _compo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  53 */   private MCCalendarDate _value = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean _addLayerdPane = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   private MCCalendarPanel _panel = null;
/*     */   
/*  70 */   private MCCalendarPanel _laypanel = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   private String _module = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  86 */   private String _screen = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCCalendarPopup() {
/*  95 */     this._compo = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCCalendarPopup(MCCalendarBeans<?> compo) {
/* 108 */     if (compo != null) {
/* 109 */       this._compo = compo;
/*     */     } else {
/*     */       
/* 112 */       throw new MCException(Core_Msg_FW_A.FCBAC0167, new Object[0]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setCalendarPanel(String module, String screen) {
/* 125 */     setModuleID(module);
/* 126 */     setScreenID(screen);
/* 127 */     setCalendarPanel(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setLayerCalenderPanel(String module, String screen) {
/* 139 */     setModuleID(module);
/* 140 */     setScreenID(screen);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCCalendarPanel createPanel() {
/* 152 */     MCRootPanel parent = getCalendarBeans().getBaseRootPanel();
/* 153 */     Class<? extends MCRootPanel> clazz = MCConst.screen.getClass(getModuleID(), 
/* 154 */         getScreenID(), MCRootPanel.class);
/* 155 */     MCRootPanel panel = MCBeansUtil.createPanelOnly(parent, clazz, new Object[0]);
/* 156 */     if (panel instanceof MCCalendarPanel) {
/* 157 */       return (MCCalendarPanel)panel;
/*     */     }
/*     */     
/* 160 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setCalendarPanel(MCCalendarPanel panel) {
/* 172 */     this._panel = panel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCCalendarPanel getCalendarPanel() {
/* 189 */     if (addedToLayerdPane()) {
/* 190 */       return this._laypanel;
/*     */     }
/* 192 */     return this._panel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void afterInit() {
/* 202 */     getCalendarPanel().setCalendarPopup(this);
/*     */   }
/*     */   
/*     */   protected void popupMenuWillBecomeInvisible() {
/* 206 */     getCalendarBeans().popupMenuWillBecomeInvisible();
/*     */   }
/*     */   
/*     */   protected void popupMenuWillBecomeVisible() {
/* 210 */     getCalendarBeans().popupMenuWillBecomeVisible();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCurrentDate(MCCalendarDate<?> value) {
/* 222 */     this._value = value;
/*     */   }
/*     */   
/*     */   private void addToLayerdPane(boolean f) {
/* 226 */     this._addLayerdPane = f;
/*     */   }
/*     */   
/*     */   public boolean addedToLayerdPane() {
/* 230 */     return this._addLayerdPane;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCCalendarDate getCurrentDate() {
/* 247 */     return this._value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCCalendarBeans getCalendarBeans() {
/* 258 */     return this._compo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCCalendarPopup getActivePopup() {
/* 274 */     return ACTIVE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void hideActivePopup() {
/* 285 */     if (ACTIVE != null) {
/* 286 */       ACTIVE.setVisible(false);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setModuleID(String module) {
/* 299 */     this._module = module;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setScreenID(String screen) {
/* 311 */     this._screen = screen;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getModuleID() {
/* 328 */     return this._module;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getScreenID() {
/* 345 */     return this._screen;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void addCalenderToLayerdPane(Component invoker, int x, int y, JLayeredPane lp) {
/* 358 */     addToLayerdPane(true);
/* 359 */     MCCalendarPanel calendar = createPanel();
/* 360 */     if (calendar != null) {
/* 361 */       this._laypanel = calendar;
/* 362 */       MCRootPanel panel = (MCRootPanel)calendar;
/* 363 */       afterInit();
/* 364 */       if (MCBeansUtil.doBeforeOpens(panel)) {
/* 365 */         Component ccal = (Component)calendar;
/* 366 */         if (invoker != null) {
/* 367 */           Point invokerscreenpoint = invoker.getLocationOnScreen();
/* 368 */           Point calscreenPoint = (Point)invokerscreenpoint.clone();
/* 369 */           Point invokerlpPoint = (Point)invokerscreenpoint.clone();
/* 370 */           SwingUtilities.convertPointFromScreen(invokerlpPoint, lp);
/* 371 */           Point callpPoint = (Point)invokerlpPoint.clone();
/*     */           
/* 373 */           calscreenPoint.y += y;
/* 374 */           callpPoint.y += y;
/* 375 */           ccal.setLocation(callpPoint);
/*     */           
/* 377 */           Component w = SwingUtilities.getWindowAncestor(invoker);
/* 378 */           if (w == null) {
/* 379 */             w = lp;
/*     */           }
/* 381 */           Point wsp = w.getLocationOnScreen();
/* 382 */           int wbtm = wsp.y + w.getHeight();
/* 383 */           int wleft = wsp.x + w.getWidth();
/* 384 */           if (w instanceof Container) {
/* 385 */             Insets wi = ((Container)w).getInsets();
/* 386 */             wbtm -= wi.bottom;
/* 387 */             wleft -= wi.left;
/*     */           } 
/*     */ 
/*     */           
/* 391 */           int cbtm = calscreenPoint.y + ccal.getHeight();
/* 392 */           if (wbtm < cbtm) {
/* 393 */             callpPoint.y -= y + ccal.getHeight();
/*     */           }
/*     */           
/* 396 */           int cleft = calscreenPoint.x + ccal.getWidth();
/* 397 */           int nx = cleft - wleft;
/* 398 */           if (nx > 0) {
/* 399 */             callpPoint.x -= nx;
/*     */           }
/* 401 */           ccal.setLocation(callpPoint);
/*     */         } 
/*     */ 
/*     */         
/* 405 */         lp.add(ccal, JLayeredPane.PALETTE_LAYER);
/* 406 */         ccal.setVisible(true);
/* 407 */         MCBeansUtil.doAfterOpens(panel);
/* 408 */         afterShow();
/* 409 */         invoker.requestFocus();
/*     */       } 
/*     */     } else {
/*     */       
/* 413 */       throw new MCException(Core_Msg_FW_A.FCBAC0116, new Object[0]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void hideIfAddedToLayerdPane(boolean focus) {
/* 425 */     Component c = (Component)getCalendarPanel();
/* 426 */     if (c != null) {
/* 427 */       c.setVisible(false);
/* 428 */       Container cc = c.getParent();
/* 429 */       if (cc != null) {
/* 430 */         cc.remove(c);
/*     */       }
/*     */     } 
/* 433 */     if (focus) {
/* 434 */       ((Component)getCalendarBeans()).requestFocus();
/*     */     }
/* 436 */     addToLayerdPane(false);
/* 437 */     ACTIVE = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void showPopup(Component invoker, int x, int y) {
/* 451 */     MCCalendarPanel calendar = createPanel();
/* 452 */     if (calendar != null) {
/* 453 */       setCalendarPanel(calendar);
/* 454 */       MCRootPanel panel = (MCRootPanel)calendar;
/* 455 */       add((Component)panel);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 460 */       int ratio = this._compo.getBaseRootPanel().getLayoutRatio();
/* 461 */       panel.initialized();
/* 462 */       MCLayouter.fontRatioChange(panel, ratio);
/*     */ 
/*     */       
/* 465 */       afterInit();
/* 466 */       if (MCBeansUtil.doBeforeOpens(panel)) {
/* 467 */         popupMenuWillBecomeVisible();
/* 468 */         ACTIVE = this;
/* 469 */         show(invoker, x, y);
/* 470 */         MCBeansUtil.doAfterOpens(panel);
/* 471 */         afterShow();
/*     */       } 
/*     */     } else {
/*     */       
/* 475 */       throw new MCException(Core_Msg_FW_A.FCBAC0116, new Object[0]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void show(Component invoker, int x, int y) {
/* 486 */     super.show(invoker, x, y);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setVisible(boolean b) {
/* 491 */     if (!b) {
/* 492 */       popupMenuWillBecomeInvisible();
/* 493 */       MCRootPanel panel = (MCRootPanel)getCalendarPanel();
/* 494 */       if (panel != null) {
/* 495 */         if (addedToLayerdPane()) {
/* 496 */           hideIfAddedToLayerdPane(false);
/*     */         
/*     */         }
/* 499 */         else if (MCBeansUtil.doBeforeCloses(panel)) {
/* 500 */           ACTIVE = null;
/* 501 */           super.setVisible(b);
/* 502 */           MCBeansUtil.doPanelClosed(panel);
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 507 */         super.setVisible(b);
/*     */       } 
/*     */     } else {
/*     */       
/* 511 */       super.setVisible(b);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void afterShow() {
/* 522 */     MCRootPanel panel = (MCRootPanel)getCalendarPanel();
/*     */     
/* 524 */     Component owner = MCBeansProxy.PROXY.getFocusOwnerForOpen(panel);
/* 525 */     if (owner == null) {
/* 526 */       owner = panel.getFocusTraversalPolicy().getFirstComponent((Container)panel);
/*     */     }
/* 528 */     if (owner != null) {
/* 529 */       owner.requestFocus();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void setCalendarValue(MCCalendarDate<?> value) {
/* 535 */     getCalendarBeans().setCalendarValue(value);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\popup\MCCalendarPopup.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */