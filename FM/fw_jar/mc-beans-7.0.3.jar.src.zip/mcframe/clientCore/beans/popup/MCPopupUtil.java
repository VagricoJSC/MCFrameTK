/*    */ package mcframe.clientCore.beans.popup;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import mcframe.clientCore.resource.MCConst;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCPopupUtil
/*    */ {
/* 23 */   private static int _maxItemCnt = MCConst.beans
/* 24 */     .getInteger(MCConst.createKey(new String[] { "popup", "max_item_cnt" }, ), -1);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static int getMaxItemCnt() {
/* 33 */     return _maxItemCnt;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static int getVisibleItemCount(Component[] components) {
/* 44 */     int result = 0; byte b; int i; Component[] arrayOfComponent;
/* 45 */     for (i = (arrayOfComponent = components).length, b = 0; b < i; ) { Component c = arrayOfComponent[b];
/* 46 */       if (c.isVisible())
/* 47 */         result++; 
/*    */       b++; }
/*    */     
/* 50 */     return result;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static int getFirstVisibleItemIndex(Component[] components) {
/* 60 */     int result = 0;
/* 61 */     for (int i = 0; i < components.length; i++) {
/* 62 */       if (components[i].isVisible()) {
/* 63 */         result = i;
/*    */         break;
/*    */       } 
/*    */     } 
/* 67 */     return result;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static int getLastVisibleItemIndex(Component[] components) {
/* 77 */     int result = 0;
/* 78 */     for (int i = components.length - 1; i >= 0; i--) {
/* 79 */       if (components[i].isVisible()) {
/* 80 */         result = i;
/*    */         break;
/*    */       } 
/*    */     } 
/* 84 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\popup\MCPopupUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */