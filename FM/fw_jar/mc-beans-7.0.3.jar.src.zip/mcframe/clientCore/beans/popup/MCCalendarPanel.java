package mcframe.clientCore.beans.popup;

public interface MCCalendarPanel {
  void setCalendarPopup(MCCalendarPopup paramMCCalendarPopup);
  
  MCCalendarPopup getCalendarPopup();
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\popup\MCCalendarPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */