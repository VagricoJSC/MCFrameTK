/*    */ package mcframe.clientCore.beans.popup;
/*    */ 
/*    */ import mcframe.clientCore.event.AbsMCPackageProxy;
/*    */ import mcframe.clientCore.event.MCEventBeans;
/*    */ import mcframe.clientCore.event.MCEventInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MCEventProxy
/*    */   extends AbsMCPackageProxy
/*    */ {
/* 30 */   static final MCEventProxy PROXY = new MCEventProxy();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void setComponent(MCEventInfo info, MCEventBeans compo) {
/* 42 */     super.setComponent(info, compo);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\popup\MCEventProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */