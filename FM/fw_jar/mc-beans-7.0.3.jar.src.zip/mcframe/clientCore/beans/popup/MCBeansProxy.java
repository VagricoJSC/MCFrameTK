/*    */ package mcframe.clientCore.beans.popup;
/*    */ 
/*    */ import javax.swing.JComponent;
/*    */ import mcframe.clientCore.beans.AbsMCPackageProxy;
/*    */ import mcframe.clientCore.beans.MCACBeans;
/*    */ import mcframe.clientCore.beans.MCResourceBeans;
/*    */ import mcframe.clientCore.beans.MCRootPanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MCBeansProxy
/*    */   extends AbsMCPackageProxy
/*    */ {
/* 25 */   static final MCBeansProxy PROXY = new MCBeansProxy();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected String getBeansKey(MCResourceBeans compo, String prefix) {
/* 38 */     return super.getBeansKey(compo, prefix);
/*    */   }
/*    */ 
/*    */   
/*    */   protected String getLabel(String name) {
/* 43 */     return super.getLabel(name);
/*    */   }
/*    */ 
/*    */   
/*    */   protected String getLabelMsg(String name) {
/* 48 */     return super.getLabelMsg(name);
/*    */   }
/*    */ 
/*    */   
/*    */   protected JComponent getFocusOwnerForOpen(MCRootPanel panel) {
/* 53 */     return super.getFocusOwnerForOpen(panel);
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean isACTypeDisable(MCACBeans compo) {
/* 58 */     return super.isACTypeDisable(compo);
/*    */   }
/*    */ 
/*    */   
/*    */   protected String adjustMessageName(String name) {
/* 63 */     return super.adjustMessageName(name);
/*    */   }
/*    */ 
/*    */   
/*    */   protected String[] getPasswordDialogID(MCRootPanel panel) {
/* 68 */     return super.getPasswordDialogID(panel);
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean checkPassword(MCACBeans compo) {
/* 73 */     return super.checkPassword(compo);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\popup\MCBeansProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */