/*      */ package mcframe.clientCore.beans.popup;
/*      */ 
/*      */ import mcframe.clientCore.beans.MCBeansReader;
/*      */ import mcframe.clientCore.beans.MCRootPanel;
/*      */ import mcframe.clientCore.beans.table.MCColumnConfig;
/*      */ import mcframe.clientCore.beans.table.MCTable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MCPopupConfig
/*      */ {
/*      */   public static final String FILE_TYPE_INS_UPD = "ins_upd";
/*      */   public static final String FILE_TYPE_UPD = "upd";
/*      */   @Deprecated
/*      */   protected boolean _ignorePanelPopup = false;
/*      */   @Deprecated
/*      */   protected boolean _ignoreTablePopup = false;
/*      */   @Deprecated
/*      */   protected boolean _ignorePanelFileIo = false;
/*      */   @Deprecated
/*      */   protected boolean _ignorePanelOperation = false;
/*      */   @Deprecated
/*      */   protected boolean _ignoreTableFileIo = false;
/*      */   @Deprecated
/*      */   protected boolean _ignoreTableOperation = false;
/*      */   @Deprecated
/*      */   protected boolean _ignoreTableUserSetting = false;
/*      */   @Deprecated
/*      */   protected boolean _ignorePanelExcelOut = false;
/*      */   @Deprecated
/*      */   protected boolean _ignoreTableExcelOut = false;
/*      */   @Deprecated
/*      */   protected boolean _ignorePanelExcelOpen = false;
/*      */   @Deprecated
/*      */   protected boolean _ignoreTableExcelOpen = false;
/*      */   @Deprecated
/*      */   protected boolean _ignorePanelExcelIn = false;
/*      */   @Deprecated
/*      */   protected boolean _ignoreTableExcelIn = false;
/*      */   @Deprecated
/*      */   protected boolean _ignorePanelCsvOut = false;
/*      */   @Deprecated
/*      */   protected boolean _ignoreTableCsvOut = false;
/*      */   @Deprecated
/*      */   protected boolean _ignorePanelCsvIn = false;
/*      */   @Deprecated
/*      */   protected boolean _ignoreTableCsvIn = false;
/*      */   @Deprecated
/*      */   protected boolean _ignoreFontRatioChange = false;
/*      */   @Deprecated
/*      */   protected boolean _ignoreSaveScreenSize = false;
/*      */   @Deprecated
/*      */   protected boolean _ignoreTableSizeChange = false;
/*      */   @Deprecated
/*      */   protected boolean _ignoreMemo = false;
/*      */   @Deprecated
/*      */   protected boolean _ignoreBookmark = false;
/*      */   @Deprecated
/*      */   protected boolean _ignoreSortOrder = false;
/*      */   @Deprecated
/*      */   protected boolean _ignoreSortOrderRegister = false;
/*      */   @Deprecated
/*      */   protected boolean _ignoreTableSort = false;
/*      */   @Deprecated
/*      */   protected boolean _ignoreColumnWidth = false;
/*      */   @Deprecated
/*      */   protected boolean _ignoreColumnWidthRegister = false;
/*      */   @Deprecated
/*      */   protected boolean _ignoreFontRatioDefault = false;
/*      */   @Deprecated
/*      */   protected boolean _ignoreRowCopy = false;
/*      */   @Deprecated
/*      */   protected boolean _ignoreRowFilter = false;
/*      */   @Deprecated
/*      */   protected boolean _ignoreRowFilterRegister = false;
/*      */   @Deprecated
/*      */   protected boolean _ignoreRowSignal = false;
/*      */   @Deprecated
/*      */   protected boolean _ignoreSumInfo = false;
/*  381 */   protected String _fileInMenuType = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCPopupMenu configurePopup(MCPopupMenu menu, MCRootPanel panel) {
/*  404 */     if (ignorePanelPopup()) {
/*  405 */       menu.removeAll();
/*  406 */       return menu;
/*      */     } 
/*      */     
/*  409 */     if (ignorePanelFileIO()) {
/*  410 */       menu.removeMenu(panel.getFileIOMenu());
/*      */     }
/*      */     
/*  413 */     if (ignorePanelOperation()) {
/*  414 */       menu.removeMenu(panel.getOperationMenu());
/*      */     }
/*      */     
/*  417 */     if (ignorePanelExcelOut()) {
/*  418 */       menu.removeMenuItem(panel.getExcelOutMenuItem());
/*  419 */       menu.removeMenuItem(panel.getExcelOutVisibleMenuItem());
/*      */     } 
/*      */     
/*  422 */     if (ignorePanelExcelOpen()) {
/*  423 */       menu.removeMenuItem(panel.getExcelOpenMenuItem());
/*  424 */       menu.removeMenuItem(panel.getExcelOpenVisibleMenuItem());
/*      */     } 
/*      */     
/*  427 */     if (ignorePanelExcelIn()) {
/*  428 */       menu.removeMenuItem(panel.getExcelInMenuItem());
/*      */     }
/*      */     
/*  431 */     if (ignorePanelCsvOut()) {
/*  432 */       menu.removeMenuItem(panel.getCSVOutMenuItem());
/*  433 */       menu.removeMenuItem(panel.getCSVOutVisibleMenuItem());
/*      */     } 
/*      */     
/*  436 */     if (ignorePanelCsvIn()) {
/*  437 */       menu.removeMenuItem(panel.getCSVInMenuItem());
/*      */     }
/*      */     
/*  440 */     if (ignoreFontRatioChange()) {
/*  441 */       menu.removeMenuItem(panel.getFontRatioChangeMenuItem());
/*      */     }
/*      */     
/*  444 */     if (ignoreSaveScreenSize()) {
/*  445 */       menu.removeMenuItem(panel.getSaveScreenSizeMenuItem());
/*      */     }
/*      */     
/*  448 */     if (ignoreTableSizeChange()) {
/*  449 */       menu.removeMenuItem(panel.getTableSizeChangeMenuItem());
/*  450 */       menu.removeMenuItem(panel.getTableSizeDefaultMenuItem());
/*      */     } 
/*      */     
/*  453 */     if (ignoreMemo()) {
/*  454 */       menu.removeMenuItem(panel.getMemoMenuItem());
/*      */     }
/*      */     
/*  457 */     return menu;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCPopupMenu configurePopup(MCPopupMenu menu, MCTable<?> table) {
/*  471 */     MCRootPanel bp = table.getBaseRootPanel();
/*      */ 
/*      */     
/*  474 */     if (ignoreTablePopup()) {
/*  475 */       menu.removeAll();
/*  476 */       return menu;
/*      */     } 
/*      */     
/*  479 */     if (ignoreTableFileIO()) {
/*  480 */       menu.removeMenu(table.getFileIOMenu());
/*      */     }
/*      */     
/*  483 */     if (ignoreTableOperation()) {
/*  484 */       menu.removeMenu(table.getOperationMenu());
/*      */     }
/*      */     
/*  487 */     if (ignoreTableExcelOut()) {
/*  488 */       menu.removeMenuItem(table.getExcelOutMenuItem());
/*  489 */       menu.removeMenuItem(table.getExcelOutVisibleMenuItem());
/*  490 */       menu.removeMenuItem(table.getExcelOutSelectMenuItem());
/*      */     } 
/*      */     
/*  493 */     if (ignoreTableExcelOpen()) {
/*  494 */       menu.removeMenuItem(table.getExcelOpenMenuItem());
/*  495 */       menu.removeMenuItem(table.getExcelOpenVisibleMenuItem());
/*  496 */       menu.removeMenuItem(table.getExcelOpenSelectMenuItem());
/*      */     } 
/*      */     
/*  499 */     if (ignoreTableExcelIn(table)) {
/*  500 */       menu.removeMenuItem(table.getExcelInMenuItem());
/*      */     }
/*      */     
/*  503 */     if (ignoreTableCsvOut()) {
/*  504 */       menu.removeMenuItem(table.getCSVOutMenuItem());
/*  505 */       menu.removeMenuItem(table.getCSVOutVisibleMenuItem());
/*  506 */       menu.removeMenuItem(table.getCSVOutSelectMenuItem());
/*      */     } 
/*      */     
/*  509 */     if (ignoreTableCsvIn(table)) {
/*  510 */       menu.removeMenuItem(table.getCSVInMenuItem());
/*      */     }
/*      */     
/*  513 */     if (ignoreFontRatioDefault()) {
/*  514 */       menu.removeMenuItem(table.getFontRatioDefaultMenuItem());
/*      */     }
/*      */     
/*  517 */     if (ignoreTableSizeChange()) {
/*  518 */       menu.removeMenuItem(table.getTableSizeChangeMenuItem());
/*  519 */       menu.removeMenuItem(table.getTableSizeDefaultMenuItem());
/*      */     } 
/*      */     
/*  522 */     if (bp.isPersonalizeLoadError() || ignoreSortOrder()) {
/*  523 */       menu.removeMenu(table.getSortOrderMenu());
/*      */     }
/*      */     
/*  526 */     if (ignoreSortOrderRegister()) {
/*  527 */       menu.removeMenuItem(table.getSortOrderPanelMenuItem());
/*      */     }
/*      */     
/*  530 */     if (ignoreTableSort()) {
/*  531 */       menu.removeMenuItem(table.getTableSortMenuItem());
/*      */     }
/*      */     
/*  534 */     if (bp.isPersonalizeLoadError() || ignoreColumnWidth()) {
/*  535 */       menu.removeMenu(table.getColumnWidthMenu());
/*      */     }
/*      */     
/*  538 */     if (ignoreColumnWidthRegister()) {
/*  539 */       menu.removeMenuItem(table.getColumnWidthPanelMenuItem());
/*      */     }
/*      */     
/*  542 */     if (ignoreRowCopy()) {
/*  543 */       menu.removeMenuItem(table.getRowCopyMenuItem());
/*      */     }
/*      */     
/*  546 */     if (bp.isPersonalizeLoadError() || ignoreRowFilter()) {
/*  547 */       menu.removeMenu(table.getRowFilterMenu());
/*      */     }
/*      */     
/*  550 */     if (ignoreRowFilterRegister()) {
/*  551 */       menu.removeMenuItem(table.getRowFilterPanelMenuItem());
/*      */     }
/*      */     
/*  554 */     if (bp.isPersonalizeLoadError() || ignoreRowSignal()) {
/*  555 */       menu.removeMenuItem(table.getRowSignalMenuItem());
/*      */     }
/*      */     
/*  558 */     if (bp.isPersonalizeLoadError() || ignoreSumInfo()) {
/*  559 */       menu.removeMenuItem(table.getSumInfoPanelMenuItem());
/*      */     }
/*      */     
/*  562 */     return menu;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCPopupMenu configurePopup(MCPopupMenu menu, MCTable<?> table, int index, MCColumnConfig column) {
/*  578 */     return menu;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCPopupMenu configurePopup(MCPopupMenu menu, MCPopupBeans compo) {
/*  591 */     return menu;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ignorePanelPopup(boolean ignore) {
/*  602 */     this._ignorePanelPopup = ignore;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean ignorePanelPopup() {
/*  613 */     return this._ignorePanelPopup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ignoreTablePopup(boolean ignore) {
/*  624 */     this._ignoreTablePopup = ignore;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean ignoreTablePopup() {
/*  635 */     return this._ignoreTablePopup;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ignorePanelFileIO(boolean ignore) {
/*  646 */     this._ignorePanelFileIo = ignore;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean ignorePanelFileIO() {
/*  657 */     return this._ignorePanelFileIo;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ignoreTableFileIO(boolean ignore) {
/*  668 */     this._ignoreTableFileIo = ignore;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean ignoreTableFileIO() {
/*  679 */     return this._ignoreTableFileIo;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ignoreExcelOut(boolean ignore) {
/*  690 */     ignorePanelExcelOut(ignore);
/*  691 */     ignoreTableExcelOut(ignore);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ignorePanelExcelOut(boolean ignore) {
/*  702 */     this._ignorePanelExcelOut = ignore;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ignoreTableExcelOut(boolean ignore) {
/*  713 */     this._ignoreTableExcelOut = ignore;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean ignorePanelExcelOut() {
/*  724 */     return this._ignorePanelExcelOut;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean ignoreTableExcelOut() {
/*  735 */     return this._ignoreTableExcelOut;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ignoreExcelOpen(boolean ignore) {
/*  746 */     ignorePanelExcelOpen(ignore);
/*  747 */     ignoreTableExcelOpen(ignore);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ignorePanelExcelOpen(boolean ignore) {
/*  758 */     this._ignorePanelExcelOpen = ignore;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ignoreTableExcelOpen(boolean ignore) {
/*  769 */     this._ignoreTableExcelOpen = ignore;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean ignorePanelExcelOpen() {
/*  780 */     return this._ignorePanelExcelOpen;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean ignoreTableExcelOpen() {
/*  791 */     return this._ignoreTableExcelOpen;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ignoreExcelIn(boolean ignore) {
/*  802 */     ignorePanelExcelIn(ignore);
/*  803 */     ignoreTableExcelIn(ignore);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ignorePanelExcelIn(boolean ignore) {
/*  814 */     this._ignorePanelExcelIn = ignore;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ignoreTableExcelIn(boolean ignore) {
/*  825 */     this._ignoreTableExcelIn = ignore;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean ignorePanelExcelIn() {
/*  836 */     return this._ignorePanelExcelIn;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean ignoreTableExcelIn() {
/*  847 */     return this._ignoreTableExcelIn;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean ignoreTableExcelIn(MCTable t) {
/*  861 */     return !(!ignoreTableExcelIn() && MCBeansReader.existsInputColumn(t));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ignoreCsvOut(boolean ignore) {
/*  872 */     ignorePanelCsvOut(ignore);
/*  873 */     ignoreTableCsvOut(ignore);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ignorePanelCsvOut(boolean ignore) {
/*  884 */     this._ignorePanelCsvOut = ignore;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ignoreTableCsvOut(boolean ignore) {
/*  895 */     this._ignoreTableCsvOut = ignore;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean ignorePanelCsvOut() {
/*  906 */     return this._ignorePanelCsvOut;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean ignoreTableCsvOut() {
/*  917 */     return this._ignoreTableCsvOut;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ignoreCsvIn(boolean ignore) {
/*  928 */     ignorePanelCsvIn(ignore);
/*  929 */     ignoreTableCsvIn(ignore);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ignorePanelCsvIn(boolean ignore) {
/*  940 */     this._ignorePanelCsvIn = ignore;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ignoreTableCsvIn(boolean ignore) {
/*  951 */     this._ignoreTableCsvIn = ignore;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean ignorePanelCsvIn() {
/*  962 */     return this._ignorePanelCsvIn;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean ignoreTableCsvIn() {
/*  973 */     return this._ignoreTableCsvIn;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean ignoreTableCsvIn(MCTable t) {
/*  987 */     return !(!ignoreTableCsvIn() && MCBeansReader.existsInputColumn(t));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ignorePanelOperation(boolean ignore) {
/*  998 */     this._ignorePanelOperation = ignore;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean ignorePanelOperation() {
/* 1009 */     return this._ignorePanelOperation;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ignoreFontRatioChange(boolean ignore) {
/* 1020 */     this._ignoreFontRatioChange = ignore;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean ignoreFontRatioChange() {
/* 1031 */     return this._ignoreFontRatioChange;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ignoreSaveScreenSize(boolean ignore) {
/* 1042 */     this._ignoreSaveScreenSize = ignore;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean ignoreSaveScreenSize() {
/* 1053 */     return this._ignoreSaveScreenSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ignoreTableSizeChange(boolean ignore) {
/* 1066 */     this._ignoreTableSizeChange = ignore;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean ignoreTableSizeChange() {
/* 1079 */     return this._ignoreTableSizeChange;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ignoreMemo(boolean ignore) {
/* 1090 */     this._ignoreMemo = ignore;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean ignoreMemo() {
/* 1101 */     return this._ignoreMemo;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ignoreBookmark(boolean ignore) {
/* 1112 */     this._ignoreBookmark = ignore;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean ignoreBookmark() {
/* 1123 */     return this._ignoreBookmark;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ignoreTableOperation(boolean ignore) {
/* 1134 */     this._ignoreTableOperation = ignore;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean ignoreTableOperation() {
/* 1145 */     return this._ignoreTableOperation;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ignoreTableUserSetting(boolean ignore) {
/* 1156 */     this._ignoreTableUserSetting = ignore;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean ignoreTableUserSetting() {
/* 1167 */     return this._ignoreTableUserSetting;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ignoreSortOrder(boolean ignore) {
/* 1178 */     this._ignoreSortOrder = ignore;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean ignoreSortOrder() {
/* 1189 */     return this._ignoreSortOrder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ignoreSortOrderRegister(boolean ignore) {
/* 1200 */     this._ignoreSortOrderRegister = ignore;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean ignoreSortOrderRegister() {
/* 1211 */     return this._ignoreSortOrderRegister;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ignoreTableSort(boolean ignore) {
/* 1222 */     this._ignoreTableSort = ignore;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean ignoreTableSort() {
/* 1233 */     return this._ignoreTableSort;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void ignoreColumnWidthPanel(boolean ignore) {
/* 1242 */     this._ignoreColumnWidth = ignore;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ignoreColumnWidth(boolean ignore) {
/* 1253 */     ignoreColumnWidthPanel(ignore);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected boolean ignoreColumnWidthPanel() {
/* 1262 */     return this._ignoreColumnWidth;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean ignoreColumnWidth() {
/* 1273 */     return ignoreColumnWidthPanel();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ignoreColumnWidthRegister(boolean ignore) {
/* 1284 */     this._ignoreColumnWidthRegister = ignore;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean ignoreColumnWidthRegister() {
/* 1295 */     return this._ignoreColumnWidthRegister;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ignoreFontRatioDefault(boolean ignore) {
/* 1306 */     this._ignoreFontRatioDefault = ignore;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean ignoreFontRatioDefault() {
/* 1317 */     return this._ignoreFontRatioDefault;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ignoreRowCopy(boolean ignore) {
/* 1328 */     this._ignoreRowCopy = ignore;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean ignoreRowCopy() {
/* 1339 */     return this._ignoreRowCopy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ignoreRowFilter(boolean ignore) {
/* 1350 */     this._ignoreRowFilter = ignore;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean ignoreRowFilter() {
/* 1361 */     return this._ignoreRowFilter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ignoreRowFilterRegister(boolean ignore) {
/* 1372 */     this._ignoreRowFilterRegister = ignore;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean ignoreRowFilterRegister() {
/* 1383 */     return this._ignoreRowFilterRegister;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ignoreRowSignal(boolean ignore) {
/* 1394 */     this._ignoreRowSignal = ignore;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean ignoreRowSignal() {
/* 1405 */     return this._ignoreRowSignal;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ignoreSumInfo(boolean ignore) {
/* 1416 */     this._ignoreSumInfo = ignore;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean ignoreSumInfo() {
/* 1427 */     return this._ignoreSumInfo;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFileInMenuType(String type) {
/* 1440 */     this._fileInMenuType = type;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getFileInMenuType() {
/* 1455 */     return this._fileInMenuType;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isIgnoreColumnWidth() {
/* 1461 */     return ignoreColumnWidth();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isIgnoreRowFilter() {
/* 1467 */     return ignoreRowFilter();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isIgnoreSortOrder() {
/* 1473 */     return ignoreSortOrder();
/*      */   }
/*      */   
/*      */   public boolean isIgnoreRowSignal() {
/* 1477 */     return ignoreRowSignal();
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\popup\MCPopupConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */