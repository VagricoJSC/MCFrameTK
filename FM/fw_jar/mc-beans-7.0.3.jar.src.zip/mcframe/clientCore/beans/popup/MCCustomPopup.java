/*     */ package mcframe.clientCore.beans.popup;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import javax.swing.JPopupMenu;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCLayouter;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.MCRowBeans;
/*     */ import mcframe.clientCore.beans.list.MCLinkBeans;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCCustomPopup
/*     */   extends JPopupMenu
/*     */ {
/*  46 */   private static MCCustomPopup ACTIVE = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final MCRowBeans _compo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final MCLinkBeans _listcompo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   private MCCustomPopupPanel _panel = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   private String _module = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  86 */   private String _screen = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCCustomPopup(MCRowBeans compo, MCLinkBeans t) {
/*  98 */     if (compo != null && t != null) {
/*  99 */       this._compo = compo;
/* 100 */       this._listcompo = t;
/*     */     } else {
/*     */       
/* 103 */       throw new MCException(Core_Msg_FW_A.FCBAC0151, new Object[0]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setCustomPanel(String module, String screen) {
/* 116 */     setModuleID(module);
/* 117 */     setScreenID(screen);
/* 118 */     setCustomPanel((MCCustomPopupPanel)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setViewValue(String key) {
/* 129 */     this._compo.setViewValue(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCCustomPopupPanel createPanel() {
/* 140 */     MCRootPanel parent = getCustomBeans().getBaseRootPanel();
/* 141 */     Class<? extends MCRootPanel> clazz = MCConst.screen.getClass(getModuleID(), 
/* 142 */         getScreenID(), MCRootPanel.class);
/* 143 */     MCRootPanel panel = MCBeansUtil.createPanelOnly(parent, clazz, new Object[0]);
/* 144 */     if (panel instanceof MCRootPanel) {
/* 145 */       return (MCCustomPopupPanel)panel;
/*     */     }
/*     */     
/* 148 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setCustomPanel(MCCustomPopupPanel panel) {
/* 160 */     this._panel = panel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCCustomPopupPanel getCustomPanel() {
/* 177 */     return this._panel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void afterInit() {
/* 187 */     getCustomPanel().afterInit(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCRowBeans getCustomBeans() {
/* 198 */     return this._compo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCCustomPopup getActivePopup() {
/* 214 */     return ACTIVE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void hideActivePopup() {
/* 225 */     if (ACTIVE != null) {
/* 226 */       ACTIVE.setVisible(false);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setModuleID(String module) {
/* 239 */     this._module = module;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setScreenID(String screen) {
/* 251 */     this._screen = screen;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getModuleID() {
/* 268 */     return this._module;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getScreenID() {
/* 285 */     return this._screen;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void showPopup(Component invoker, int x, int y) {
/* 298 */     removeAll();
/* 299 */     MCCustomPopupPanel c = createPanel();
/* 300 */     if (c != null) {
/* 301 */       setCustomPanel(c);
/* 302 */       MCRootPanel panel = (MCRootPanel)c;
/* 303 */       add((Component)panel);
/*     */ 
/*     */ 
/*     */       
/* 307 */       int ratio = this._compo.getBaseRootPanel().getLayoutRatio();
/* 308 */       panel.initialized();
/* 309 */       MCLayouter.fontRatioChange(panel, ratio);
/*     */       
/* 311 */       afterInit();
/* 312 */       if (MCBeansUtil.doBeforeOpens(panel)) {
/* 313 */         ((MCPopupBeans)this._compo).popupMenuWillBecomeVisible();
/* 314 */         ACTIVE = this;
/* 315 */         show(invoker, x, y);
/* 316 */         MCBeansUtil.doAfterOpens(panel);
/* 317 */         afterShow();
/*     */       } 
/*     */     } else {
/*     */       
/* 321 */       throw new MCException(Core_Msg_FW_A.FCBAC0116, new Object[0]);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public MCLinkBeans getLinkBean() {
/* 327 */     return this._listcompo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void show(Component invoker, int x, int y) {
/* 335 */     super.show(invoker, x, y);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setVisible(boolean b) {
/* 340 */     if (!b) {
/* 341 */       ((MCPopupBeans)this._compo).popupMenuWillBecomeInvisible();
/* 342 */       MCRootPanel panel = (MCRootPanel)getCustomPanel();
/* 343 */       if (panel != null) {
/*     */         
/* 345 */         if (MCBeansUtil.doBeforeCloses(panel)) {
/* 346 */           ACTIVE = null;
/* 347 */           super.setVisible(b);
/* 348 */           MCBeansUtil.doPanelClosed(panel);
/*     */         } 
/*     */       } else {
/*     */         
/* 352 */         super.setVisible(b);
/*     */       } 
/*     */     } else {
/*     */       
/* 356 */       super.setVisible(b);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void afterShow() {
/* 367 */     MCRootPanel panel = (MCRootPanel)getCustomPanel();
/* 368 */     Component owner = MCBeansProxy.PROXY.getFocusOwnerForOpen(panel);
/* 369 */     if (owner == null) {
/* 370 */       owner = panel.getFocusTraversalPolicy().getFirstComponent((Container)panel);
/*     */     }
/* 372 */     if (owner != null)
/* 373 */       owner.requestFocus(); 
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\popup\MCCustomPopup.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */