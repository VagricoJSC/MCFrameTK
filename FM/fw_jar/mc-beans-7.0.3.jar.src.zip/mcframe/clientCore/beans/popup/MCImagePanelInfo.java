/*     */ package mcframe.clientCore.beans.popup;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import mcframe.clientCore.beans.table.MCColumnConfig;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCImagePanelInfo
/*     */ {
/*     */   private MCImageBeans _compo;
/*     */   private MCColumnConfig _column;
/*     */   private int _index;
/*     */   private Integer _min_ratio;
/*     */   private Integer _max_ratio;
/*     */   private Boolean _editable;
/*     */   private Boolean _adjust_image_ratio;
/*  32 */   private List<String> _file_type_list = new ArrayList<>(Arrays.asList(new String[] { "ALL", 
/*  33 */           "GIF", "JPG", "PNG" }));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLinkComponent(MCImageBeans c) {
/*  47 */     this._compo = c;
/*  48 */     this._column = null;
/*  49 */     this._index = -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLinkComponent(MCColumnConfig c, int i) {
/*  64 */     this._compo = null;
/*  65 */     this._column = c;
/*  66 */     this._index = i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCImageBeans getLinkComponent() {
/*  75 */     return this._compo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCColumnConfig getLinkColumn() {
/*  84 */     return this._column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLinkIndex() {
/*  93 */     return this._index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRatio(int m, int x) {
/* 103 */     this._min_ratio = Integer.valueOf(m);
/* 104 */     this._max_ratio = Integer.valueOf(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getMinRatio() {
/* 115 */     return this._min_ratio;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getMaxRatio() {
/* 126 */     return this._max_ratio;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEditable(boolean e) {
/* 135 */     this._editable = Boolean.valueOf(e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean isEditable() {
/* 146 */     return this._editable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAdjustImageRatio(boolean e) {
/* 155 */     this._adjust_image_ratio = Boolean.valueOf(e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean isAdjustImageRatio() {
/* 166 */     return this._adjust_image_ratio;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFileTypes(String... types) {
/* 177 */     this._file_type_list.clear(); byte b; int i; String[] arrayOfString;
/* 178 */     for (i = (arrayOfString = types).length, b = 0; b < i; ) { String y = arrayOfString[b];
/* 179 */       this._file_type_list.add(y);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getFileTypes() {
/* 198 */     return this._file_type_list.<String>toArray(new String[0]);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\popup\MCImagePanelInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */