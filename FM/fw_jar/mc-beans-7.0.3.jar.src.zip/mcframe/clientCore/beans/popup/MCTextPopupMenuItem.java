/*      */ package mcframe.clientCore.beans.popup;
/*      */ 
/*      */ import java.awt.AWTEvent;
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Font;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.MouseEvent;
/*      */ import javax.swing.Icon;
/*      */ import javax.swing.JMenuItem;
/*      */ import javax.swing.KeyStroke;
/*      */ import mcframe.clientCore.beans.MCBeans;
/*      */ import mcframe.clientCore.beans.MCBeansDelegate;
/*      */ import mcframe.clientCore.beans.MCBeansUtil;
/*      */ import mcframe.clientCore.beans.MCMode;
/*      */ import mcframe.clientCore.beans.MCModeInfo;
/*      */ import mcframe.clientCore.beans.MCRootPanel;
/*      */ import mcframe.clientCore.beans.action.MCActionBeans;
/*      */ import mcframe.clientCore.beans.layout.MCHiresoManager;
/*      */ import mcframe.clientCore.event.MCAPListener;
/*      */ import mcframe.clientCore.event.MCEventBeans;
/*      */ import mcframe.clientCore.event.MCEventInfo;
/*      */ import mcframe.clientCore.event.MCEventList;
/*      */ import mcframe.clientCore.event.MCEventListener;
/*      */ import mcframe.clientCore.event.MCNEListener;
/*      */ import mcframe.clientCore.event.MCNXListener;
/*      */ import mcframe.clientCore.resource.MCConst;
/*      */ import mcframe.commonCore.lang.MCStringUtil;
/*      */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*      */ import mcframe.commonCore.resource.MCConst;
/*      */ import mcframe.commonCore.resource.ctrl.MCResource;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MCTextPopupMenuItem
/*      */   extends JMenuItem
/*      */   implements MCPopupMenuItem, MCActionBeans
/*      */ {
/*   54 */   private MCBeansDelegate _delegate = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   62 */   private final MCEventList _event_list = new MCEventList();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MCPopupBeans _compo;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   78 */   private MCMode _mode = MCMode.ENABLE;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   86 */   private int _order = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   94 */   private Boolean _stock_visible = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  102 */   private MCEventInfo _event_info = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  110 */   private String _message_name_resource = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  118 */   private String _message_name = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  126 */   private String _ac_type = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  134 */   private String _label_name = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  142 */   private String _ap_method_name = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  150 */   private MCRootPanel _update_resource_panel = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  158 */   private MCPopupBeans _update_resource_beans = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String[] _password_dialog_id;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCTextPopupMenuItem(String name) {
/*  175 */     setName(name);
/*  176 */     init();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void init() {
/*  186 */     initResource();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initResource() {
/*  196 */     setForeground((MCRootPanel)null);
/*  197 */     setBackground((MCRootPanel)null);
/*  198 */     setFont((MCRootPanel)null);
/*      */ 
/*      */     
/*  201 */     String m = MCBeansProxy.PROXY.getLabelMsg(getName());
/*  202 */     if (m != null) {
/*  203 */       this._message_name_resource = m;
/*      */     }
/*      */ 
/*      */     
/*  207 */     String l = MCBeansProxy.PROXY.getLabel(getName());
/*  208 */     if (l != null) {
/*  209 */       this._label_name = l;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public String getType() {
/*  215 */     return "popup";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setName(String name) {
/*  231 */     setName(name, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void setName(String name, boolean init) {
/*  246 */     MCBeansUtil.checkName(name);
/*  247 */     super.setName(name);
/*  248 */     if (init) {
/*  249 */       updateResource();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public String getMessageByLocale() {
/*  255 */     String result = this._message_name;
/*  256 */     if (result == null) {
/*  257 */       result = this._message_name_resource;
/*      */     }
/*  259 */     if (MCStringUtil.isNull(result)) {
/*  260 */       result = getLabelByLocale();
/*      */     }
/*  262 */     return result;
/*      */   }
/*      */ 
/*      */   
/*      */   public final String getLabelByLocale() {
/*  267 */     return getText();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void setBeans(MCPopupBeans c) {
/*  279 */     this._compo = c;
/*  280 */     updateResource();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final MCPopupBeans getBeans() {
/*  293 */     return this._compo;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setMode(MCMode mode) {
/*  298 */     MCRootPanel bp = getBaseRootPanel();
/*  299 */     if (!MCMode.isNull(mode)) {
/*  300 */       MCBeansUtil.log(bp, (MCBeans)this, Core_Msg_FW_A.FCBAC0013, new Object[] { mode.getName() });
/*  301 */       this._mode = mode;
/*  302 */       MCModeInfo mi = getModeInfo();
/*  303 */       int s = mi.getStatus();
/*  304 */       switch (s) {
/*      */         case 1:
/*  306 */           setVisible(true);
/*  307 */           setEnabled(true);
/*  308 */           setFocusable(true);
/*      */           break;
/*      */         case 2:
/*  311 */           setVisible(true);
/*  312 */           setEnabled(false);
/*  313 */           setFocusable(false);
/*      */           break;
/*      */         case 3:
/*  316 */           setVisible(false);
/*      */           break;
/*      */       } 
/*      */ 
/*      */       
/*  321 */       setForeground(mi.getForeground());
/*  322 */       setBackground(mi.getBackground());
/*  323 */       MCBeansUtil.log(bp, (MCBeans)this, Core_Msg_FW_A.FCBAC0014, new Object[] { mode.getName() });
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public MCMode getMode() {
/*  329 */     return this._mode;
/*      */   }
/*      */ 
/*      */   
/*      */   public MCEventInfo getEventInfo() {
/*  334 */     if (this._event_info == null) {
/*  335 */       this._event_info = new MCEventInfo();
/*  336 */       MCEventProxy.PROXY.setComponent(this._event_info, (MCEventBeans)this);
/*      */     } 
/*  338 */     return this._event_info;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void addAllListener(MCEventListener l) {
/*  361 */     addAPListener((MCAPListener)l);
/*  362 */     addNEListener((MCNEListener)l);
/*  363 */     addNXListener((MCNXListener)l);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setAllListener(MCEventListener l) {
/*  386 */     setAPListener((MCAPListener)l);
/*  387 */     setNEListener((MCNEListener)l);
/*  388 */     setNXListener((MCNXListener)l);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void addAPListener(MCAPListener listener) {
/*  393 */     this._event_list.add(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setAPListener(MCAPListener listener) {
/*  398 */     this._event_list.set(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void removeAPListener(MCAPListener listener) {
/*  403 */     this._event_list.remove(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public final MCAPListener[] getAPListeners() {
/*  408 */     return this._event_list.ap();
/*      */   }
/*      */ 
/*      */   
/*      */   public void doAP() {
/*  413 */     MCBeansUtil.ap(this);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void addNEListener(MCNEListener listener) {
/*  418 */     this._event_list.add(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNEListener(MCNEListener listener) {
/*  423 */     this._event_list.set(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void removeNEListener(MCNEListener listener) {
/*  428 */     this._event_list.remove(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public final MCNEListener[] getNEListeners() {
/*  433 */     return this._event_list.ne();
/*      */   }
/*      */ 
/*      */   
/*      */   public void doNE() {
/*  438 */     MCBeansUtil.ne(this);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void addNXListener(MCNXListener listener) {
/*  443 */     this._event_list.add(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNXListener(MCNXListener listener) {
/*  448 */     this._event_list.set(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void removeNXListener(MCNXListener listener) {
/*  453 */     this._event_list.remove(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public final MCNXListener[] getNXListeners() {
/*  458 */     return this._event_list.nx();
/*      */   }
/*      */ 
/*      */   
/*      */   public void doNX() {
/*  463 */     MCBeansUtil.nx(this);
/*      */   }
/*      */ 
/*      */   
/*      */   public MCRootPanel getBaseRootPanel() {
/*  468 */     MCPopupBeans compo = getBeans();
/*  469 */     return (compo != null) ? compo.getBaseRootPanel() : null;
/*      */   }
/*      */ 
/*      */   
/*      */   public MCRootPanel getRootPanel() {
/*  474 */     MCPopupBeans compo = getBeans();
/*  475 */     return (compo != null) ? compo.getRootPanel() : null;
/*      */   }
/*      */ 
/*      */   
/*      */   public MCRootPanel getNearestRootPanel() {
/*  480 */     MCPopupBeans c = getBeans();
/*  481 */     return (c != null) ? c.getNearestRootPanel() : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void added() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removed() {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAccelerator(int c) {
/*  500 */     setAccelerator(KeyStroke.getKeyStroke(c, 0));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setAccelerator(int c, int m) {
/*  505 */     setAccelerator(KeyStroke.getKeyStroke(c, m));
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setOrder(int o) {
/*  510 */     this._order = o;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getOrder() {
/*  515 */     return this._order;
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateResource() {
/*  520 */     updateResource(getBaseRootPanel());
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateResource(MCRootPanel panel) {
/*  525 */     if (panel == null) {
/*      */       return;
/*      */     }
/*      */     
/*  529 */     if (this._update_resource_panel == panel && this._update_resource_beans == getBeans()) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  534 */     setForeground(panel);
/*  535 */     setBackground(panel);
/*  536 */     setFont(panel);
/*  537 */     setOrder(panel);
/*      */ 
/*      */     
/*  540 */     boolean setted = false;
/*  541 */     String l = null;
/*  542 */     String m = null;
/*  543 */     String n = getName();
/*  544 */     if (n.endsWith("POPUP_CSV_IN") || 
/*  545 */       n.endsWith("POPUP_EXCEL_IN")) {
/*  546 */       MCPopupBeans o = getBeans();
/*  547 */       if (o != null) {
/*  548 */         MCPopupConfig p = o.getPopupConfig();
/*  549 */         if (p != null) {
/*  550 */           String y = p.getFileInMenuType();
/*  551 */           if (y != null) {
/*      */             try {
/*  553 */               setName(MCConst.createKey(new String[] { n, y }, ), false);
/*      */               
/*  555 */               l = MCBeansUtil.getLabel((MCBeans)this);
/*  556 */               if (l == null) {
/*  557 */                 l = MCBeansProxy.PROXY.getLabel(getName());
/*      */               }
/*      */               
/*  560 */               m = MCBeansUtil.getMessageName(this);
/*  561 */               if (m == null) {
/*  562 */                 m = MCBeansProxy.PROXY.getLabelMsg(getName());
/*      */               }
/*      */             }
/*      */             finally {
/*      */               
/*  567 */               setName(n, false);
/*      */             } 
/*      */             
/*  570 */             setted = true;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*  575 */     if (!setted) {
/*  576 */       l = MCBeansUtil.getLabel((MCBeans)this);
/*  577 */       m = MCBeansUtil.getMessageName(this);
/*      */     } 
/*      */     
/*  580 */     if (l != null) {
/*  581 */       this._label_name = l;
/*      */     }
/*  583 */     if (this._label_name != null && !this._label_name.equals(getText())) {
/*  584 */       setText(this._label_name);
/*      */     }
/*      */     
/*  587 */     if (m != null) {
/*  588 */       this._message_name_resource = m;
/*      */     }
/*      */     
/*  591 */     setMCToolTipText((this._message_name != null) ? this._message_name : this._message_name_resource);
/*      */     
/*  593 */     setACType();
/*      */     
/*  595 */     setVisible();
/*      */     
/*  597 */     this._update_resource_beans = getBeans();
/*  598 */     this._update_resource_panel = panel;
/*      */   }
/*      */ 
/*      */   
/*      */   public void localeChanged() {
/*  603 */     updateResource();
/*      */   }
/*      */   
/*      */   protected void setMCToolTipText(String text) {
/*  607 */     if (!MCStringUtil.isNull(text)) {
/*  608 */       setToolTipText(text);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getToolTipText(MouseEvent event) {
/*  615 */     String tip = getToolTipText();
/*  616 */     tip = MCHiresoManager.getToolTipText(this, tip);
/*  617 */     return tip;
/*      */   }
/*      */   
/*      */   protected void setOrder(MCRootPanel panel) {
/*  621 */     int def = this._order;
/*  622 */     String prefix = MCResource.createKey(new String[] { getType(), getName(), "order" });
/*  623 */     String key = MCBeansProxy.PROXY.getBeansKey(this, prefix);
/*  624 */     if (MCStringUtil.isNull(key)) {
/*  625 */       prefix = MCResource.createKey(new String[] { getType(), "order" });
/*  626 */       key = MCBeansProxy.PROXY.getBeansKey(this, prefix);
/*      */     } 
/*  628 */     if (!MCStringUtil.isNull(key)) {
/*  629 */       int o = MCConst.beans.getInteger(key, def);
/*  630 */       if (o != def) {
/*  631 */         setOrder(o);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setForeground(MCRootPanel panel) {
/*  644 */     Color def = super.getForeground();
/*  645 */     String prefix = MCResource.createKey(new String[] { getType(), getName(), "fg" });
/*  646 */     String key = MCBeansProxy.PROXY.getBeansKey(this, prefix);
/*  647 */     if (MCStringUtil.isNull(key)) {
/*  648 */       prefix = MCResource.createKey(new String[] { getType(), "fg" });
/*  649 */       key = MCBeansProxy.PROXY.getBeansKey(this, prefix);
/*      */     } 
/*  651 */     if (!MCStringUtil.isNull(key)) {
/*  652 */       Color col = MCConst.beans.getColor(key, def);
/*  653 */       if (col != def) {
/*  654 */         setForeground(col);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setBackground(MCRootPanel panel) {
/*  667 */     Color def = super.getBackground();
/*  668 */     String prefix = MCResource.createKey(new String[] { getType(), getName(), "bg" });
/*  669 */     String key = MCBeansProxy.PROXY.getBeansKey(this, prefix);
/*  670 */     if (MCStringUtil.isNull(key)) {
/*  671 */       prefix = MCResource.createKey(new String[] { getType(), "bg" });
/*  672 */       key = MCBeansProxy.PROXY.getBeansKey(this, prefix);
/*      */     } 
/*  674 */     if (!MCStringUtil.isNull(key)) {
/*  675 */       Color col = MCConst.beans.getColor(key, def);
/*  676 */       if (col != def) {
/*  677 */         setBackground(col);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setFont(MCRootPanel panel) {
/*  690 */     Font def = getFont();
/*  691 */     String prefix = MCResource.createKey(new String[] { getType(), "font" });
/*  692 */     String key = MCBeansProxy.PROXY.getBeansKey(this, prefix);
/*  693 */     if (!MCStringUtil.isNull(key)) {
/*  694 */       Font font = MCConst.beans.getFont(key, def);
/*  695 */       if (font != def) {
/*  696 */         setFont(font);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setIcon(String key) {
/*  712 */     Icon icon = MCBeansUtil.get(this, key);
/*  713 */     if (icon != null) {
/*  714 */       setIcon(icon);
/*      */     } else {
/*      */       
/*  717 */       handleIconError();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void handleIconError() {
/*  728 */     setText(getMessageByLocale());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setIconPath(String path) {
/*  741 */     Icon icon = MCBeansUtil.getFromPath(this, path);
/*  742 */     if (icon != null) {
/*  743 */       setIcon(icon);
/*      */     } else {
/*      */       
/*  746 */       handleIconError();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPasswordDialog(String module, String screen) {
/*  754 */     if (MCStringUtil.containsNull(new String[] { module, screen })) {
/*  755 */       this._password_dialog_id = null;
/*      */     } else {
/*      */       
/*  758 */       this._password_dialog_id = new String[] { module, screen };
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] getPasswordDialogID() {
/*  764 */     return (this._password_dialog_id != null) ? 
/*  765 */       this._password_dialog_id : 
/*  766 */       MCBeansProxy.PROXY.getPasswordDialogID(getBaseRootPanel());
/*      */   }
/*      */ 
/*      */   
/*      */   public final String getACType() {
/*  771 */     return this._ac_type;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setACType() {
/*  781 */     String k = MCBeansUtil.getACTypeKey(this);
/*  782 */     if (!MCStringUtil.isNull(k)) {
/*  783 */       String a = MCConst.actype.getType(new String[] { k });
/*  784 */       this._ac_type = a;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean checkAC() {
/*  790 */     return authorize() ? (needsPassword() ? checkPassword() : true) : false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean authorize() {
/*  796 */     if (MCBeansProxy.PROXY.isACTypeDisable(this)) {
/*  797 */       return true;
/*      */     }
/*      */     
/*  800 */     return MCBeansUtil.authorize(this);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean needsPassword() {
/*  806 */     if (MCBeansProxy.PROXY.isACTypeDisable(this)) {
/*  807 */       return false;
/*      */     }
/*      */     
/*  810 */     return MCBeansUtil.needsPassword(this);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean checkPassword() {
/*  815 */     return MCBeansProxy.PROXY.checkPassword(this);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isVisible() {
/*  820 */     return (super.isVisible() && authorize());
/*      */   }
/*      */ 
/*      */   
/*      */   public void setVisible(boolean visible) {
/*  825 */     this._stock_visible = Boolean.valueOf(visible);
/*  826 */     super.setVisible(visible);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void _setVisible(boolean visible) {
/*  835 */     super.setVisible(visible);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void _restoreVisible() {
/*  847 */     if (this._stock_visible != null) {
/*  848 */       super.setVisible(this._stock_visible.booleanValue());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setVisible() {
/*  859 */     if (this._stock_visible != null) {
/*      */       return;
/*      */     }
/*      */     
/*  863 */     String p = MCResource.createKey(new String[] { "popup", getName(), "visible" });
/*  864 */     Boolean visible = null;
/*  865 */     if (isExcludeVisiblePtn() && 
/*  866 */       !isIncludeVisiblePtn()) {
/*  867 */       visible = Boolean.valueOf(!MCConst.beans.getBoolean(p));
/*      */     }
/*      */     
/*  870 */     if (visible == null) {
/*      */       
/*  872 */       String k = MCBeansProxy.PROXY.getBeansKey(getBeans(), p);
/*  873 */       if (MCStringUtil.isNull(k)) {
/*  874 */         p = MCResource.createKey(new String[] { "popup", "visible" });
/*  875 */         k = MCBeansProxy.PROXY.getBeansKey(getBeans(), p);
/*      */       } 
/*  877 */       if (!MCStringUtil.isNull(k)) {
/*  878 */         this._stock_visible = Boolean.valueOf(MCConst.beans.getBoolean(k, true));
/*      */       }
/*      */     } else {
/*      */       
/*  882 */       this._stock_visible = visible;
/*      */     } 
/*  884 */     if (this._stock_visible != null) {
/*  885 */       setVisible(this._stock_visible.booleanValue());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isExcludeVisiblePtn() {
/*  897 */     return isIncludePtn(MCResource.createKey(new String[] { "popup", getName(), "visible", "*", "excld" }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isIncludeVisiblePtn() {
/*  908 */     return isIncludePtn(MCResource.createKey(new String[] { "popup", getName(), "visible", "*", "incld" }));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isIncludePtn(String k) {
/*  920 */     String[] ids = { getBeans().getBaseRootPanel().getScreenID() };
/*  921 */     String[] keys = MCConst.beans.findPattern(MCConst.createKey(new String[] { getBeans().getBaseRootPanel().getModuleID(), k })); byte b; int i; String[] arrayOfString1;
/*  922 */     for (i = (arrayOfString1 = keys).length, b = 0; b < i; ) { String key = arrayOfString1[b];
/*  923 */       String value = MCConst.beans.getString(key);
/*  924 */       if (!MCStringUtil.isNull(value)) {
/*  925 */         String[] ptns = MCStringUtil.split(",", value); byte b1; int j; String[] arrayOfString2;
/*  926 */         for (j = (arrayOfString2 = ptns).length, b1 = 0; b1 < j; ) { String ptn = arrayOfString2[b1];
/*  927 */           if (!MCStringUtil.isNull(ptn)) {
/*  928 */             String[] results = MCStringUtil.match(ptn.trim(), ids, '.');
/*  929 */             if (results.length > 0)
/*  930 */               return true; 
/*      */           }  b1++; }
/*      */       
/*      */       } 
/*      */       b++; }
/*      */     
/*  936 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public void fireActionPerformed(ActionEvent e) {
/*  941 */     if (checkAC()) {
/*      */       try {
/*  943 */         MCBeansUtil.setClientOperationType(this, "BP");
/*  944 */         MCBeansUtil.doHistoryRegister(this);
/*  945 */         super.fireActionPerformed(e);
/*  946 */         doAP();
/*      */       } finally {
/*      */         
/*  949 */         MCBeansUtil.setClientOperation((MCBeans)this, null);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected void processEvent(AWTEvent e) {
/*      */     try {
/*  957 */       super.processEvent(e);
/*      */     }
/*  959 */     catch (Throwable t) {
/*  960 */       handle(t);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void handle(Throwable t) {
/*  967 */     MCBeansUtil.handle(this, t);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean equalsIgnoreCase(Component compo) {
/*  972 */     return equals(compo);
/*      */   }
/*      */ 
/*      */   
/*      */   public final MCModeInfo getModeInfo() {
/*  977 */     return getModeInfo(getMode());
/*      */   }
/*      */ 
/*      */   
/*      */   public final MCModeInfo getModeInfo(MCMode mode) {
/*  982 */     return getDelegate().getModeInfo(this, mode);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void initialized() {}
/*      */ 
/*      */   
/*      */   public boolean doAction() {
/*  991 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MCBeansDelegate getDelegate() {
/* 1002 */     if (this._delegate == null) {
/* 1003 */       this._delegate = new MCBeansDelegate();
/*      */     }
/* 1005 */     return this._delegate;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void addAliasName(String alias, MCRootPanel panel) {
/* 1010 */     getDelegate().addAliasName(alias, panel);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setAliasName(String alias, MCRootPanel panel) {
/* 1015 */     getDelegate().setAliasName(alias, panel);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void removeAliasName(MCRootPanel panel) {
/* 1020 */     getDelegate().removeAliasName(panel);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void removeAliasNames() {
/* 1025 */     getDelegate().removeAliasNames();
/*      */   }
/*      */ 
/*      */   
/*      */   public final String getAliasName(MCRootPanel panel) {
/* 1030 */     return getDelegate().getAliasName(panel);
/*      */   }
/*      */ 
/*      */   
/*      */   public final String[] getAliasNames() {
/* 1035 */     return getDelegate().getAliasNames();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final void updateBounds(int ratio) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final void updateFontSize(int ratio) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCMode getMode(MCRootPanel panel, String status) {
/* 1056 */     return getDelegate().getMode(panel, status);
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] getStatuses(MCRootPanel panel) {
/* 1061 */     return getDelegate().getStatuses(panel);
/*      */   }
/*      */ 
/*      */   
/*      */   public void putMode(MCRootPanel panel, String status, MCMode mode) {
/* 1066 */     getDelegate().putMode(panel, status, mode);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setMode(MCRootPanel panel, String status) {
/* 1071 */     setMode(getMode(panel, status));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getForeground() {
/* 1077 */     Color c = null;
/* 1078 */     if (!authorize()) {
/* 1079 */       c = getModeInfo(MCMode.UNAUTHORIZED).getForeground();
/*      */     }
/* 1081 */     if (c == null) {
/* 1082 */       c = super.getForeground();
/*      */     }
/* 1084 */     return c;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Color getBackground() {
/* 1090 */     Color c = null;
/* 1091 */     if (!authorize()) {
/* 1092 */       c = getModeInfo(MCMode.UNAUTHORIZED).getBackground();
/*      */     }
/* 1094 */     if (c == null) {
/* 1095 */       c = super.getBackground();
/*      */     }
/* 1097 */     return c;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getAPMethodName() {
/* 1102 */     return this._ap_method_name;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setAPMethodName(String name) {
/* 1107 */     this._ap_method_name = name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Dimension getDefaultSize() {
/* 1121 */     return getSize();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void afterRequestFocus() {}
/*      */ 
/*      */   
/*      */   public void setMessageName(String name) {
/* 1131 */     this._message_name = MCBeansProxy.PROXY.adjustMessageName(name);
/*      */ 
/*      */     
/* 1134 */     setMCToolTipText((this._message_name != null) ? 
/* 1135 */         this._message_name : this._message_name_resource);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public String _getMessageName() {
/* 1141 */     return this._message_name;
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void _cacheDefaultBounds(Rectangle bounds) {}
/*      */ 
/*      */   
/*      */   public Rectangle getDefaultBounds() {
/* 1150 */     return null;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public void _setDefaultBounds() {}
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\popup\MCTextPopupMenuItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */