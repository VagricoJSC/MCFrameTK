/*    */ package mcframe.clientCore.beans.border;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCISFieldBorder
/*    */   extends AbsMCFieldBorder
/*    */ {
/*    */   static final String _res_key = "is.border.color";
/*    */   
/*    */   String getResKey(AbsMCBorder.CornerType c) {
/* 15 */     return "is.border.color";
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\border\MCISFieldBorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */