/*    */ package mcframe.clientCore.beans.border;
/*    */ 
/*    */ public class MCTableHeaderBorder
/*    */   extends AbsMCBorder {
/*    */   static final String _res_key = "border.color";
/*    */   
/*    */   public MCTableHeaderBorder() {
/*  8 */     super("table.header");
/*    */   }
/*    */ 
/*    */   
/*    */   String getResKey(AbsMCBorder.CornerType c) {
/* 13 */     return "border.color";
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\border\MCTableHeaderBorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */