/*     */ package mcframe.clientCore.beans.border;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import java.util.EnumMap;
/*     */ import java.util.Map;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.plaf.metal.MetalLookAndFeel;
/*     */ import mcframe.clientCore.beans.MCBeans;
/*     */ import mcframe.clientCore.beans.plaf.metal.MCTheme;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbsMCBorder
/*     */   implements Border
/*     */ {
/*  26 */   Map<CornerType, Color> _cache = new EnumMap<>(CornerType.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private String _def_guityp;
/*     */ 
/*     */   
/*     */   private String _compo_guityp;
/*     */ 
/*     */   
/*     */   private static final String NULL_GUITYP = "";
/*     */ 
/*     */   
/*     */   private Insets _insets;
/*     */ 
/*     */ 
/*     */   
/*     */   public AbsMCBorder(String typ) {
/*  44 */     this._def_guityp = typ;
/*     */   }
/*     */ 
/*     */   
/*     */   public Insets getBorderInsets(Component c) {
/*  49 */     if (this._insets == null) {
/*  50 */       this._insets = getTextInsets(c);
/*     */     }
/*     */     
/*  53 */     return (Insets)this._insets.clone();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isBorderOpaque() {
/*  58 */     return false;
/*     */   }
/*     */   
/*     */   Color getNewColor(Component o, Color c, CornerType corner) {
/*  62 */     return c;
/*     */   }
/*     */ 
/*     */   
/*     */   final Insets getTextInsets(Component o) {
/*  67 */     initCompoGuiTyp(o);
/*  68 */     Insets rtn = MCTheme.getInsets(String.valueOf(this._def_guityp) + ".border.insets", 
/*  69 */         MCTheme.getInsets("border.insets", new Insets(3, 3, 1, 2)));
/*     */     
/*  71 */     if ("".equals(this._compo_guityp)) {
/*  72 */       return rtn;
/*     */     }
/*  74 */     return MCTheme.getInsets(String.valueOf(this._compo_guityp) + ".border.insets", rtn);
/*     */   }
/*     */ 
/*     */   
/*     */   private void initCompoGuiTyp(Component o) {
/*  79 */     if (this._compo_guityp == null) {
/*  80 */       if (o instanceof MCBeans) {
/*  81 */         MCBeans b = (MCBeans)o;
/*  82 */         this._compo_guityp = b.getType();
/*     */       } else {
/*     */         
/*  85 */         this._compo_guityp = "";
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
/*  92 */     paintFocusBorder(c, g, x, y, w, h);
/*     */   }
/*     */   
/*     */   private void paintFocusBorder(Component c, Graphics g, int x, int y, int w, int h) {
/*  96 */     g.translate(x, y);
/*     */ 
/*     */     
/*  99 */     Color o = getTopOuterColor(c);
/* 100 */     if (o != null) {
/* 101 */       g.setColor(o);
/* 102 */       g.drawLine(0, 0, w - 2, 0);
/*     */     } 
/*     */ 
/*     */     
/* 106 */     o = getTopInnerColor(c);
/* 107 */     if (o != null) {
/* 108 */       g.setColor(o);
/* 109 */       g.drawLine(1, 1, w - 2, 1);
/*     */     } 
/*     */ 
/*     */     
/* 113 */     o = getLeftOuterColor(c);
/* 114 */     if (o != null) {
/* 115 */       g.setColor(o);
/* 116 */       g.drawLine(0, 0, 0, h - 2);
/*     */     } 
/*     */ 
/*     */     
/* 120 */     o = getLeftInnerColor(c);
/* 121 */     if (o != null) {
/* 122 */       g.setColor(o);
/* 123 */       g.drawLine(1, 1, 1, h - 2);
/*     */     } 
/*     */ 
/*     */     
/* 127 */     o = getBottomOuterColor(c);
/* 128 */     if (o != null) {
/* 129 */       g.setColor(o);
/* 130 */       g.drawLine(0, h - 1, w - 1, h - 1);
/*     */     } 
/*     */ 
/*     */     
/* 134 */     o = getBottomInnerColor(c);
/* 135 */     if (o != null) {
/* 136 */       g.setColor(o);
/* 137 */       g.drawLine(1, h - 2, w - 2, h - 2);
/*     */     } 
/*     */ 
/*     */     
/* 141 */     o = getRightOuterColor(c);
/* 142 */     if (o != null) {
/* 143 */       g.setColor(o);
/* 144 */       g.drawLine(w - 1, 0, w - 1, h - 2);
/*     */     } 
/*     */ 
/*     */     
/* 148 */     o = getRightInnerColor(c);
/* 149 */     if (o != null) {
/* 150 */       g.setColor(o);
/* 151 */       g.drawLine(w - 2, 1, w - 2, h - 2);
/*     */     } 
/*     */     
/* 154 */     g.setColor(MetalLookAndFeel.getControl());
/* 155 */     g.drawLine(0, h - 1, 1, h - 2);
/* 156 */     g.drawLine(w - 1, 0, w - 2, 1);
/* 157 */     g.translate(-x, -y);
/*     */   }
/*     */   
/*     */   Color getTopOuterColor(Component o) {
/* 161 */     return getColorFromResource(o, getResKey(CornerType.ot), CornerType.ot);
/*     */   }
/*     */   
/*     */   Color getTopInnerColor(Component o) {
/* 165 */     return getColorFromResource(o, getResKey(CornerType.it), CornerType.it);
/*     */   }
/*     */   
/*     */   Color getBottomOuterColor(Component o) {
/* 169 */     return getColorFromResource(o, getResKey(CornerType.ob), CornerType.ob);
/*     */   }
/*     */   
/*     */   Color getBottomInnerColor(Component o) {
/* 173 */     return getColorFromResource(o, getResKey(CornerType.ib), CornerType.ib);
/*     */   }
/*     */   
/*     */   Color getLeftOuterColor(Component o) {
/* 177 */     return getColorFromResource(o, getResKey(CornerType.ol), CornerType.ol);
/*     */   }
/*     */   
/*     */   Color getLeftInnerColor(Component o) {
/* 181 */     return getColorFromResource(o, getResKey(CornerType.il), CornerType.il);
/*     */   }
/*     */   
/*     */   Color getRightOuterColor(Component o) {
/* 185 */     return getColorFromResource(o, getResKey(CornerType.or), CornerType.or);
/*     */   }
/*     */   
/*     */   Color getRightInnerColor(Component o) {
/* 189 */     return getColorFromResource(o, getResKey(CornerType.ir), CornerType.ir);
/*     */   }
/*     */   
/*     */   private Color getColorFromResource(Component o, String key, CornerType corner) {
/* 193 */     if (!corner.isOuter() && !MCConst.beans.getBoolean("border.innerpaint")) {
/* 194 */       return null;
/*     */     }
/* 196 */     Color c = null;
/*     */     
/* 198 */     c = this._cache.get(corner);
/* 199 */     if (c != null) {
/* 200 */       c = getNewColor(o, c, corner);
/* 201 */       return c;
/*     */     } 
/*     */     
/* 204 */     initCompoGuiTyp(o);
/*     */     
/* 206 */     if (!"".equals(this._compo_guityp)) {
/* 207 */       c = MCConst.beans
/* 208 */         .getColor(MCConst.createKey(new String[] { this._compo_guityp, key, corner.name() }));
/* 209 */       if (c != null) {
/* 210 */         this._cache.put(corner, c);
/* 211 */         c = getNewColor(o, c, corner);
/* 212 */         return c;
/*     */       } 
/* 214 */       c = MCConst.beans.getColor(MCConst.createKey(new String[] { this._compo_guityp }));
/* 215 */       if (c != null) {
/* 216 */         this._cache.put(corner, c);
/* 217 */         c = getNewColor(o, c, corner);
/* 218 */         return c;
/*     */       } 
/*     */     } 
/* 221 */     c = MCConst.beans.getColor(MCConst.createKey(new String[] { this._def_guityp, key, corner.name() }));
/* 222 */     if (c != null) {
/* 223 */       this._cache.put(corner, c);
/* 224 */       c = getNewColor(o, c, corner);
/* 225 */       return c;
/*     */     } 
/* 227 */     c = MCConst.beans.getColor(MCConst.createKey(new String[] { this._def_guityp, key }));
/* 228 */     if (c != null) {
/* 229 */       this._cache.put(corner, c);
/* 230 */       c = getNewColor(o, c, corner);
/* 231 */       return c;
/*     */     } 
/* 233 */     c = MCConst.beans.getColor(MCConst.createKey(new String[] { key, corner.name() }));
/* 234 */     if (c != null) {
/* 235 */       this._cache.put(corner, c);
/* 236 */       c = getNewColor(o, c, corner);
/* 237 */       return c;
/*     */     } 
/* 239 */     c = MCConst.beans.getColor(MCConst.createKey(new String[] { key }));
/* 240 */     if (c != null) {
/* 241 */       this._cache.put(corner, c);
/* 242 */       c = getNewColor(o, c, corner);
/* 243 */       return c;
/*     */     } 
/* 245 */     this._cache.put(corner, c);
/* 246 */     return null;
/*     */   }
/*     */   
/*     */   abstract String getResKey(CornerType paramCornerType);
/*     */   
/*     */   enum CornerType
/*     */   {
/* 253 */     ot
/*     */     {
/*     */ 
/*     */       
/*     */       boolean isOuter()
/*     */       {
/* 259 */         return true;
/*     */       }
/*     */     },
/* 262 */     ol
/*     */     {
/*     */ 
/*     */       
/*     */       boolean isOuter()
/*     */       {
/* 268 */         return true;
/*     */       }
/*     */     },
/* 271 */     ob
/*     */     {
/*     */ 
/*     */       
/*     */       boolean isOuter()
/*     */       {
/* 277 */         return true;
/*     */       }
/*     */     },
/* 280 */     or
/*     */     {
/*     */ 
/*     */       
/*     */       boolean isOuter()
/*     */       {
/* 286 */         return true;
/*     */       }
/*     */     },
/* 289 */     it
/*     */     {
/*     */ 
/*     */       
/*     */       boolean isOuter()
/*     */       {
/* 295 */         return false;
/*     */       }
/*     */     },
/* 298 */     il
/*     */     {
/*     */ 
/*     */       
/*     */       boolean isOuter()
/*     */       {
/* 304 */         return false;
/*     */       }
/*     */     },
/* 307 */     ib
/*     */     {
/*     */ 
/*     */       
/*     */       boolean isOuter()
/*     */       {
/* 313 */         return false;
/*     */       }
/*     */     },
/* 316 */     ir
/*     */     {
/*     */ 
/*     */       
/*     */       boolean isOuter()
/*     */       {
/* 322 */         return false;
/*     */       }
/*     */     };
/*     */     
/*     */     abstract boolean isOuter();
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\border\AbsMCBorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */