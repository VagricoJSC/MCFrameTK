/*     */ package mcframe.clientCore.beans.border;
/*     */ 
/*     */ import java.awt.AlphaComposite;
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.Shape;
/*     */ import java.awt.geom.Path2D;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.awt.geom.RoundRectangle2D;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.border.LineBorder;
/*     */ import mcframe.clientCore.beans.plaf.MCGraphicsUtil;
/*     */ import mcframe.clientCore.beans.plaf.metal.MCMetalButtonUI;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCButtonLineBorder
/*     */   extends LineBorder
/*     */ {
/*     */   private final int _defaultTickness;
/*     */   private final boolean _isHalfArc;
/*  39 */   private static final MCGraphicsUtil _gu = new MCGraphicsUtil();
/*     */ 
/*     */   
/*     */   public MCButtonLineBorder(int thickness, boolean roundedCorners, boolean isHalfArc) {
/*  43 */     super(null, thickness, roundedCorners);
/*  44 */     this._defaultTickness = thickness;
/*  45 */     this._isHalfArc = isHalfArc;
/*     */   }
/*     */   
/*     */   public final void setRatio(int ratio) {
/*  49 */     this.thickness = 
/*  50 */       Double.valueOf(this._defaultTickness * Double.valueOf(ratio).doubleValue() / 
/*  51 */         Double.valueOf(100.0D).doubleValue())
/*  52 */       .intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
/*  58 */     paintBorderImpl(c, g, x, y, width, height);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void paintShadow(Graphics g, Component c) {
/*  64 */     Graphics2D g2 = (Graphics2D)g;
/*  65 */     Rectangle r = c.getBounds();
/*  66 */     int len = 2;
/*  67 */     Rectangle right = new Rectangle();
/*  68 */     right.x = r.x + r.width + 1;
/*  69 */     right.width = len;
/*  70 */     right.y = r.y;
/*  71 */     right.height += len;
/*     */     
/*  73 */     Rectangle bottom = new Rectangle();
/*  74 */     bottom.x = r.x;
/*  75 */     r.width += len;
/*  76 */     bottom.y = r.y + r.height + 1;
/*  77 */     bottom.height = len;
/*     */ 
/*     */     
/*  80 */     Path2D path = new Path2D.Float();
/*  81 */     path.append(right, false);
/*  82 */     path.append(bottom, false);
/*  83 */     g2.clip(path);
/*     */ 
/*     */     
/*  86 */     g2.setColor(Color.red);
/*  87 */     g2.fill(path);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void paintBorderImpl(Component c, Graphics g, int x, int y, int width, int height) {
/* 100 */     if (this.thickness > 0 && g instanceof Graphics2D) {
/* 101 */       Graphics2D g2d = (Graphics2D)g;
/*     */       
/* 103 */       Color oldColor = g2d.getColor();
/* 104 */       Color bg1 = null;
/* 105 */       Color bg2 = null;
/* 106 */       AbstractButton b = null;
/* 107 */       if (c instanceof AbstractButton) {
/* 108 */         b = (AbstractButton)c;
/* 109 */         if (b instanceof javax.swing.JToggleButton && b.isSelected()) {
/* 110 */           bg1 = Color.black;
/*     */         }
/* 112 */         else if (MCMetalButtonUI.isComboButton(b)) {
/* 113 */           bg1 = UIManager.getColor("Combobutton.bordercolor");
/* 114 */           bg2 = UIManager.getColor("Combobutton.bordercolor2");
/*     */         } else {
/*     */           
/* 117 */           bg1 = UIManager.getColor(MCGraphicsUtil.getUIKey(b, "bordercolor"));
/* 118 */           bg2 = UIManager.getColor(MCGraphicsUtil.getUIKey(b, "bordercolor2"));
/*     */           
/* 120 */           if (bg1 == null) {
/* 121 */             bg1 = Color.green;
/*     */           }
/* 123 */           if (bg2 == null) {
/* 124 */             bg2 = bg1;
/*     */           }
/*     */         } 
/* 127 */         if (b.getModel().isPressed()) {
/* 128 */           bg1 = bg1.brighter();
/*     */         }
/* 130 */         else if (b.getModel().isRollover()) {
/* 131 */           Color rb1 = 
/* 132 */             UIManager.getColor(MCGraphicsUtil.getUIKey(b, "borderrollover"));
/* 133 */           Color rb2 = 
/* 134 */             UIManager.getColor(MCGraphicsUtil.getUIKey(b, "borderrollover2"));
/* 135 */           if (rb1 != null) {
/* 136 */             bg1 = rb1;
/*     */           }
/* 138 */           if (rb2 != null) {
/* 139 */             bg2 = rb2;
/*     */           }
/*     */         } 
/*     */       } else {
/*     */         
/* 144 */         bg1 = c.getBackground();
/*     */       } 
/* 146 */       if (this.roundedCorners) {
/* 147 */         g2d.setColor(bg1);
/* 148 */         final Color fbg2 = bg2;
/*     */         
/* 150 */         _gu.getClass(); MCGraphicsUtil.draw(g2d, createClipShape(x, y, width, height), width, height, new MCGraphicsUtil.MCBorderPainter(_gu)
/*     */             {
/*     */               public void paintBorder(Graphics2D g2, Shape clipShape)
/*     */               {
/* 154 */                 paintBorderGlow(g2, clipShape, MCButtonLineBorder.this.getThickness());
/*     */               }
/*     */ 
/*     */               
/*     */               private void paintBorderGlow(Graphics2D g2, Shape clipShape, int glowWidth) {
/* 159 */                 int gw = glowWidth * 2;
/*     */                 
/* 161 */                 for (int i = gw; i >= 2; i -= 2) {
/* 162 */                   float pct = (gw - i) / (gw - 1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                   
/* 173 */                   g2.setColor((fbg2 == null) ? 
/* 174 */                       g2.getColor().darker().darker() : fbg2);
/* 175 */                   g2.setComposite(
/* 176 */                       AlphaComposite.getInstance(10, pct));
/* 177 */                   g2.setStroke(new BasicStroke(i));
/* 178 */                   g2.draw(clipShape);
/*     */                 } 
/*     */               }
/*     */             });
/*     */       } else {
/*     */         
/* 184 */         Color oldc = this.lineColor;
/* 185 */         int oldt = this.thickness;
/*     */ 
/*     */         
/*     */         try {
/* 189 */           if (this.thickness > 1) {
/* 190 */             int outert = this.thickness / 2;
/* 191 */             int innert = this.thickness - outert;
/* 192 */             this.thickness = outert;
/* 193 */             this.lineColor = bg2;
/* 194 */             super.paintBorder(c, g2d, x, y, width, height);
/* 195 */             this.thickness = innert;
/* 196 */             this.lineColor = bg1;
/* 197 */             super.paintBorder(c, g2d, x + outert, y + outert, 
/* 198 */                 width - outert * 2, height - outert * 2);
/*     */           } else {
/*     */             
/* 201 */             this.lineColor = bg1;
/* 202 */             super.paintBorder(c, g2d, x, y, width, height);
/*     */           } 
/*     */         } finally {
/*     */           
/* 206 */           this.lineColor = oldc;
/* 207 */           this.thickness = oldt;
/*     */         } 
/*     */       } 
/* 210 */       if (b != null && !b.isFocusOwner()) {
/* 211 */         MCGraphicsUtil.paintCornerMark(g2d, b, null, "id", null, 
/* 212 */             MCGraphicsUtil.CornerMarkLocation.OUTER);
/*     */       }
/* 214 */       g2d.setColor(oldColor);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Shape createClipShape(int x, int y, int width, int height) {
/* 220 */     Path2D path = new Path2D.Float(0);
/* 221 */     Shape[] sp = getInnerAndOuter(x, y, width, height);
/* 222 */     Shape inner = sp[0];
/* 223 */     Shape outer = sp[1];
/* 224 */     path.append(outer, false);
/* 225 */     path.append(inner, false);
/* 226 */     return path;
/*     */   }
/*     */   
/*     */   public Shape getInnerArea(int x, int y, int width, int height) {
/* 230 */     return getInnerAndOuter(x, y, width, height)[0];
/*     */   }
/*     */   
/*     */   public Shape getOuterArea(int x, int y, int width, int height) {
/* 234 */     return getInnerAndOuter(x, y, width, height)[1];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Shape[] getInnerAndOuter(int x, int y, int width, int height) {
/*     */     Shape outer, inner;
/* 241 */     int offs = this.thickness;
/* 242 */     int size = offs + offs;
/* 243 */     if (this.roundedCorners) {
/*     */       float arc;
/* 245 */       if (this._isHalfArc) {
/* 246 */         arc = ((width < height) ? (width >> 1) : (height >> 1));
/* 247 */         arc += 4.0F;
/*     */       } else {
/*     */         
/* 250 */         arc = (offs + size);
/*     */       } 
/* 252 */       outer = new RoundRectangle2D.Float(x, y, width, height, arc + size, 
/* 253 */           arc + size);
/* 254 */       inner = new RoundRectangle2D.Float((x + offs), (y + offs), (width - size), (
/* 255 */           height - size), arc, arc);
/*     */     } else {
/*     */       
/* 258 */       outer = new Rectangle2D.Float(x, y, width, height);
/* 259 */       inner = new Rectangle2D.Float((x + offs), (y + offs), (width - size), (
/* 260 */           height - size));
/*     */     } 
/* 262 */     return new Shape[] {
/* 263 */         inner, outer
/*     */       };
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\border\MCButtonLineBorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */