/*    */ package mcframe.clientCore.beans.border;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCPluralValueFieldBorder
/*    */   extends AbsMCFieldBorder
/*    */ {
/*    */   static final String _res_key = "plural_value.border.color";
/*    */   
/*    */   String getResKey(AbsMCBorder.CornerType c) {
/* 15 */     return "plural_value.border.color";
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\border\MCPluralValueFieldBorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */