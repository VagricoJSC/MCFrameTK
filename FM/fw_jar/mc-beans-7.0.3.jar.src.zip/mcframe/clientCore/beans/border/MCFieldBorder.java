/*    */ package mcframe.clientCore.beans.border;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import java.awt.Graphics;
/*    */ import javax.swing.JComponent;
/*    */ import mcframe.clientCore.beans.MCModeBeans;
/*    */ import mcframe.clientCore.beans.MCRowBeans;
/*    */ import mcframe.clientCore.beans.combobox.AbsMCComboBox;
/*    */ import mcframe.clientCore.beans.plaf.MCGraphicsUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCFieldBorder
/*    */   extends AbsMCFieldBorder
/*    */ {
/*    */   String getResKey(AbsMCBorder.CornerType c) {
/* 21 */     return "border.color";
/*    */   }
/*    */ 
/*    */   
/*    */   public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
/* 26 */     super.paintBorder(c, g, x, y, w, h);
/* 27 */     paintModeCornerMark(c, g, x, y, w, h, "mode");
/*    */   }
/*    */ 
/*    */   
/*    */   protected void paintModeCornerMark(Component c, Graphics g, int x, int y, int w, int h, String typ) {
/* 32 */     if (c.getParent() instanceof AbsMCComboBox) {
/* 33 */       AbsMCComboBox cb = (AbsMCComboBox)c.getParent();
/* 34 */       if (cb.getRowValue() == null) {
/* 35 */         MCGraphicsUtil.paintCornerMark(g, (JComponent)c, null, typ, (
/* 36 */             (MCModeBeans)c.getParent()).getMode(), 
/* 37 */             MCGraphicsUtil.CornerMarkLocation.OUTER);
/*    */       }
/*    */     }
/* 40 */     else if (c instanceof MCRowBeans && (
/* 41 */       (MCRowBeans)c).getRowValue() == null) {
/* 42 */       MCGraphicsUtil.paintCornerMark(g, (JComponent)c, null, typ, (
/* 43 */           (MCModeBeans)c).getMode(), 
/* 44 */           MCGraphicsUtil.CornerMarkLocation.OUTER);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\border\MCFieldBorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */