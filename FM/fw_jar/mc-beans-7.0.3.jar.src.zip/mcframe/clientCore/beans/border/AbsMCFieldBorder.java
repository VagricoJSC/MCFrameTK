/*    */ package mcframe.clientCore.beans.border;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.awt.Component;
/*    */ import java.awt.Graphics;
/*    */ import javax.swing.FocusManager;
/*    */ import javax.swing.text.JTextComponent;
/*    */ import mcframe.clientCore.resource.MCConst;
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbsMCFieldBorder
/*    */   extends AbsMCBorder
/*    */ {
/*    */   public static final String _rtype = "field";
/*    */   static Color _cacheFocusColor;
/*    */   
/*    */   static void initFocusColor() {
/* 19 */     if (_cacheFocusColor == null)
/*    */     {
/*    */ 
/*    */       
/* 23 */       _cacheFocusColor = MCConst.beans.getColor("field.border.focus.color", 
/* 24 */           new DummyColor(0, 0, 0));
/*    */     }
/*    */   }
/*    */   
/*    */   static boolean useFocusColor() {
/* 29 */     return !(_cacheFocusColor instanceof DummyColor);
/*    */   }
/*    */   
/*    */   static class DummyColor
/*    */     extends Color
/*    */   {
/*    */     public DummyColor(int r, int g, int b) {
/* 36 */       super(r, g, b);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public AbsMCFieldBorder() {
/* 51 */     super("field");
/*    */   }
/*    */ 
/*    */   
/*    */   Color getNewColor(Component o, Color c, AbsMCBorder.CornerType corner) {
/* 56 */     if ((corner == AbsMCBorder.CornerType.ir || corner == AbsMCBorder.CornerType.or) && 
/* 57 */       o instanceof mcframe.clientCore.beans.combobox.MCComboField) {
/* 58 */       return null;
/*    */     }
/* 60 */     return c;
/*    */   }
/*    */ 
/*    */   
/*    */   public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
/* 65 */     if (c instanceof JTextComponent) {
/* 66 */       initFocusColor();
/* 67 */       if (!useFocusColor() || !((JTextComponent)c).isEditable() || 
/* 68 */         FocusManager.getCurrentManager().getFocusOwner() != c) {
/* 69 */         super.paintBorder(c, g, x, y, w, h);
/*    */       }
/*    */       else {
/*    */         
/* 73 */         g.translate(-x, -y);
/*    */ 
/*    */ 
/*    */         
/* 77 */         g.setColor(_cacheFocusColor);
/* 78 */         g.drawRect(x, y, w - 1, h - 1);
/* 79 */         g.translate(x, y);
/*    */       } 
/*    */       
/*    */       return;
/*    */     } 
/* 84 */     super.paintBorder(c, g, x, y, w, h);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\border\AbsMCFieldBorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */