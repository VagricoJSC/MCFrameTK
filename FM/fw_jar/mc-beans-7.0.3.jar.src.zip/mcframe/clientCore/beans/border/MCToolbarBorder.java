/*    */ package mcframe.clientCore.beans.border;
/*    */ 
/*    */ public class MCToolbarBorder extends AbsMCBorder {
/*    */   public static final String _rtype = "toolbar";
/*    */   
/*    */   public MCToolbarBorder() {
/*  7 */     super("toolbar");
/*    */   }
/*    */ 
/*    */   
/*    */   String getResKey(AbsMCBorder.CornerType c) {
/* 12 */     return "border.color";
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\border\MCToolbarBorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */