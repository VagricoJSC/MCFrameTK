/*    */ package mcframe.clientCore.beans.border;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import java.awt.Graphics;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCPluralValueISFieldBorder
/*    */   extends AbsMCFieldBorder
/*    */ {
/*    */   String getResKey(AbsMCBorder.CornerType c) {
/* 17 */     switch (c) {
/*    */       case ot:
/* 19 */         return "is.border.color";
/*    */       case ol:
/* 21 */         return "is.border.color";
/*    */       case ob:
/* 23 */         return "plural_value.border.color";
/*    */       case or:
/* 25 */         return "plural_value.border.color";
/*    */       case it:
/* 27 */         return "is.border.color";
/*    */       case il:
/* 29 */         return "is.border.color";
/*    */       case null:
/* 31 */         return "plural_value.border.color";
/*    */       case ir:
/* 33 */         return "plural_value.border.color";
/*    */     } 
/* 35 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
/* 41 */     super.paintBorder(c, g, x, y, w, h);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\border\MCPluralValueISFieldBorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */