/*     */ package mcframe.clientCore.beans.fxgraph;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.event.ComponentAdapter;
/*     */ import java.awt.event.ComponentEvent;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.Semaphore;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import javafx.application.Platform;
/*     */ import javafx.embed.swing.JFXPanel;
/*     */ import javafx.event.Event;
/*     */ import javafx.event.EventHandler;
/*     */ import javafx.scene.Parent;
/*     */ import javafx.scene.Scene;
/*     */ import javafx.scene.chart.PieChart;
/*     */ import javafx.scene.chart.XYChart;
/*     */ import javafx.scene.layout.AnchorPane;
/*     */ import javafx.scene.layout.Pane;
/*     */ import javafx.stage.Stage;
/*     */ import javafx.stage.WindowEvent;
/*     */ import javax.swing.SwingUtilities;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCPanel;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.layout.MCHiresoManager;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCFXGraph
/*     */   extends MCFXGraphCore
/*     */ {
/*     */   protected String graphDetailClassName;
/*     */   protected MCPanel targetPanel;
/*     */   protected MCRootPanel targetRootPanel;
/*     */   
/*     */   public static String createColorValue(MCNumber r, MCNumber g, MCNumber b) {
/*     */     if (r == null || g == null || b == null)
/*     */       return null; 
/*     */     int rint = r.intValue();
/*     */     int gint = g.intValue();
/*     */     int bint = b.intValue();
/*     */     try {
/*     */       return String.format("%1$02x%2$02x%3$02x", new Object[] { Integer.valueOf(rint), Integer.valueOf(gint), Integer.valueOf(bint) });
/*     */     } catch (Exception e) {
/*     */       throw new MCException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public MCFXGraph() {
/* 110 */     this.graphDetailClassName = "mcframe.clientFSBA.FSBAP0520.FSBAP0520";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getGraphDetailClassName() {
/* 120 */     return this.graphDetailClassName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGraphDetailClassName(String graphDetailClassName) {
/* 131 */     this.graphDetailClassName = graphDetailClassName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCNumber[] splitColorValue(String rgb) {
/*     */     if (rgb == null) {
/*     */       return new MCNumber[3];
/*     */     }
/*     */     try {
/*     */       int r = Integer.parseUnsignedInt(rgb.substring(0, 2), 16);
/*     */       int g = Integer.parseUnsignedInt(rgb.substring(2, 4), 16);
/*     */       int b = Integer.parseUnsignedInt(rgb.substring(4, 6), 16);
/*     */       return new MCNumber[] { MCNumber.valueOf(r), MCNumber.valueOf(g), MCNumber.valueOf(b) };
/*     */     } catch (Exception e) {
/*     */       throw new MCException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Stage getOuterStage() {
/* 160 */     return this.outerStage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCPanel getTargetPanel() {
/* 170 */     return this.targetPanel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTargetPanel(MCPanel p) {
/* 180 */     this.targetPanel = p;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCRootPanel getTargetRootPanel() {
/* 190 */     return this.targetRootPanel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTargetRootPanel(MCRootPanel rp) {
/* 200 */     this.targetRootPanel = rp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCList<MCRow> getTableList() {
/* 210 */     return this.tableList;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTableList(MCList<MCRow> t) {
/* 220 */     this.tableList = t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void initInnerGraphControl(MCPanel panel, String aTitle, List<Integer> aGraphTypeList, List<String> aGraphColorList, MCList aTableList, String aLabelColumnName, String aLabelColumnNameLabel, List<String> aValueColumnNameList, List<String> aValueColumnNameLabelList, String aValueLabel) {
/* 244 */     List<String> labelColumnNameList = new ArrayList<>();
/* 245 */     labelColumnNameList.add(aLabelColumnName);
/*     */     
/* 247 */     ArrayList<Integer> graphTypeList = new ArrayList<>();
/* 248 */     for (Iterator<Integer> iterator = aGraphTypeList.iterator(); iterator.hasNext(); ) { int n = ((Integer)iterator.next()).intValue();
/* 249 */       graphTypeList.add(Integer.valueOf(n)); }
/*     */ 
/*     */ 
/*     */     
/* 253 */     ArrayList<String> graphColorList = new ArrayList<>();
/* 254 */     if (aGraphColorList == null) {
/* 255 */       graphColorList = null;
/*     */     } else {
/* 257 */       for (String s : aGraphColorList) {
/* 258 */         graphColorList.add(s);
/*     */       }
/*     */     } 
/*     */     
/* 262 */     initInnerGraphControl(panel, aTitle, graphTypeList, graphColorList, aTableList, labelColumnNameList, 
/* 263 */         aLabelColumnNameLabel, aValueColumnNameList, aValueColumnNameLabelList, aValueLabel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initInnerGraphControl(final MCPanel panel, final String aTitle, final List<Integer> aGraphTypeList, final List<String> aGraphColorList, final MCList aTableList, final List<String> aLabelColumnNameList, final String aLabelColumnNameLabel, final List<String> aValueColumnNameList, final List<String> aValueColumnNameLabelList, final String aValueLabel) {
/* 288 */     Platform.setImplicitExit(false);
/*     */ 
/*     */     
/* 291 */     final Semaphore _fxSemaphore = new Semaphore(0);
/*     */     class ResizeListener
/*     */       extends ComponentAdapter
/*     */     {
/*     */       public void componentResized(ComponentEvent e) {
/* 296 */         Platform.runLater(new Runnable() {
/*     */               public void run() {
/* 298 */                 MCFXGraph.ResizeListener.access$0(MCFXGraph.ResizeListener.this).getScaleManager().updateRootPaneSize();
/*     */               }
/*     */             });
/*     */       }
/*     */     };
/*     */     
/* 304 */     if (this._fxPanel != null) {
/* 305 */       panel.remove((Component)this._fxPanel);
/*     */     }
/* 307 */     this._fxPanel = new JFXPanel();
/* 308 */     this._fxPanel.setSize(panel.getSize());
/* 309 */     this._fxPanel.addComponentListener(new ResizeListener());
/*     */ 
/*     */     
/* 312 */     Platform.runLater(new Runnable()
/*     */         {
/*     */           public void run() {
/* 315 */             synchronized (MCFXGraph.this._lockFxPanel) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 324 */               MCFXGraph.this.targetPanel = panel;
/* 325 */               MCFXGraph.this.targetRootPanel = panel.getRootPanel();
/* 326 */               MCFXGraph.this.graphTitle = aTitle;
/* 327 */               MCFXGraph.this._tableGraphTypeList = aGraphTypeList;
/* 328 */               MCFXGraph.this.tableGraphColorList = aGraphColorList;
/* 329 */               MCFXGraph.this.tableList = aTableList;
/*     */               
/* 331 */               MCFXGraph.this.labelColumnNameList = aLabelColumnNameList;
/* 332 */               MCFXGraph.this.labelColumnNameLabel = aLabelColumnNameLabel;
/*     */               
/* 334 */               MCFXGraph.this._valueColumnNameList = aValueColumnNameList;
/* 335 */               MCFXGraph.this.valueColumnNameLabelList = aValueColumnNameLabelList;
/*     */               
/* 337 */               MCFXGraph.this.valueLabel = aValueLabel;
/*     */               
/* 339 */               MCFXGraph.this.usePieGraph = false;
/*     */               
/* 341 */               if (!MCFXGraph.this._isDebug)
/*     */               {
/* 343 */                 MCFXGraph.this.getScaleManager().setÛseMouseWheel(MCHiresoManager.isEnableGraphWheel());
/*     */               }
/*     */ 
/*     */               
/* 347 */               int idx = 0;
/* 348 */               for (Iterator<Integer> iterator = aGraphTypeList.iterator(); iterator.hasNext(); ) { int graphType = ((Integer)iterator.next()).intValue();
/* 349 */                 if (graphType == 1) {
/* 350 */                   MCFXGraph.this.usePieGraph = true;
/* 351 */                   MCFXGraph.this.pieGraphIndex = idx;
/*     */                   break;
/*     */                 } 
/* 354 */                 MCFXGraph.this.usePieGraph = false;
/*     */                 
/* 356 */                 idx++; }
/*     */ 
/*     */ 
/*     */               
/*     */               try {
/* 361 */                 if (MCFXGraph.this._fxPanel != null) {
/* 362 */                   if (!MCFXGraph.this._isDebug) {
/*     */                     
/* 364 */                     panel.add((Component)MCFXGraph.this._fxPanel);
/* 365 */                     MCFXGraph.this.createInnerGraphPane();
/*     */ 
/*     */                     
/* 368 */                     MCFXGraph.this.getScaleManager().updateRootPaneSize();
/*     */                   } else {
/*     */                     
/* 371 */                     MCFXGraph.this.createBasePane();
/*     */                     
/* 373 */                     Scene scene = new Scene((Parent)MCFXGraph.this.basePane);
/*     */ 
/*     */                     
/* 376 */                     MCFXGraph.this._fxPanel.setScene(scene);
/*     */ 
/*     */                     
/* 379 */                     if (MCFXGraph.this._fxPanel != null)
/*     */                     {
/* 381 */                       panel.add((Component)MCFXGraph.this._fxPanel);
/*     */                     }
/*     */ 
/*     */                     
/* 385 */                     MCFXGraph.this.updateGraph();
/*     */ 
/*     */                     
/* 388 */                     MCFXGraph.this.updateStyleSheet(false);
/*     */ 
/*     */                     
/* 391 */                     MCFXGraph.this.createGraph();
/*     */                     
/* 393 */                     boolean f = MCFXGraph.this.useAnimation();
/* 394 */                     if (f)
/*     */                     {
/* 396 */                       MCFXGraph.this.updateGraphData2();
/*     */                     }
/*     */                   }
/*     */                 
/* 400 */                 } else if (!MCFXGraph.this._isDebug) {
/* 401 */                   MCFXGraph.this.createInnerGraphPane();
/*     */                 } else {
/*     */                   
/* 404 */                   MCFXGraph.this.createBasePane();
/* 405 */                   MCFXGraph.this.createGraph();
/*     */                 }
/*     */               
/* 408 */               } catch (Throwable ex) {
/*     */                 
/* 410 */                 SwingUtilities.invokeLater(() -> MCBeansUtil.handle((Component)param1MCPanel, param1Throwable));
/*     */               } 
/*     */             } 
/*     */             
/* 414 */             _fxSemaphore.release();
/*     */           }
/*     */         });
/*     */ 
/*     */     
/*     */     try {
/* 420 */       _fxSemaphore.tryAcquire(30000L, TimeUnit.MILLISECONDS);
/* 421 */     } catch (InterruptedException interruptedException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initOuterGraphControl(MCRootPanel aRootPanel, String aTitle, Integer[] aGraphType, String[] aGraphColor, MCList aTableList, List<String> aLabelColumnNameList, String aLabelColumnNameLabel, List<String> aValueColumnNameList, List<String> aValueColumnNameLabelList, String aValueLabel) {
/* 445 */     ArrayList<Integer> graphTypeList = new ArrayList<>(); byte b; int i; Integer[] arrayOfInteger;
/* 446 */     for (i = (arrayOfInteger = aGraphType).length, b = 0; b < i; ) { int n = arrayOfInteger[b].intValue();
/* 447 */       graphTypeList.add(Integer.valueOf(n));
/*     */       b++; }
/*     */     
/* 450 */     ArrayList<String> graphColorList = new ArrayList<>();
/* 451 */     if (aGraphColor == null) {
/* 452 */       graphColorList = null;
/*     */     } else {
/* 454 */       String[] arrayOfString; for (int j = (arrayOfString = aGraphColor).length; i < j; ) { String s = arrayOfString[i];
/* 455 */         graphColorList.add(s);
/*     */         i++; }
/*     */     
/*     */     } 
/* 459 */     initOuterGraphControl(aRootPanel, aTitle, graphTypeList, graphColorList, aTableList, aLabelColumnNameList, 
/* 460 */         aLabelColumnNameLabel, aValueColumnNameList, aValueColumnNameLabelList, aValueLabel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initOuterGraphControl(MCRootPanel aRootPanel, String aTitle, List<Integer> aGraphTypeList, List<String> aGraphColorList, MCList aTableList, List<String> aLabelColumnNameList, String aLabelColumnNameLabel, List<String> aValueColumnNameList, List<String> aValueColumnNameLabelList, String aValueLabel) {
/* 484 */     this.targetPanel = null;
/* 485 */     this.targetRootPanel = aRootPanel;
/*     */     
/* 487 */     this.graphTitle = aTitle;
/* 488 */     this._tableGraphTypeList = aGraphTypeList;
/* 489 */     this.tableGraphColorList = aGraphColorList;
/* 490 */     this.tableList = aTableList;
/* 491 */     this.labelColumnNameList = aLabelColumnNameList;
/* 492 */     this._valueColumnNameList = aValueColumnNameList;
/*     */     
/* 494 */     this.labelColumnNameLabel = aLabelColumnNameLabel;
/* 495 */     this.valueColumnNameLabelList = aValueColumnNameLabelList;
/* 496 */     this.valueLabel = aValueLabel;
/*     */     
/* 498 */     if (!this._isDebug)
/*     */     {
/* 500 */       getScaleManager().setÛseMouseWheel(MCHiresoManager.isEnableGraphWheel());
/*     */     }
/*     */     
/* 503 */     synchronized (this._lockFxPanel) {
/*     */ 
/*     */       
/* 506 */       if (!this._isDebug) {
/* 507 */         this._fxPanel = null;
/*     */       }
/*     */     } 
/*     */     
/* 511 */     this.usePieGraph = false;
/*     */     
/* 513 */     for (Iterator<Integer> iterator = aGraphTypeList.iterator(); iterator.hasNext(); ) { int graphType = ((Integer)iterator.next()).intValue();
/* 514 */       if (graphType == 1) {
/* 515 */         this.usePieGraph = true;
/*     */         break;
/*     */       } 
/* 518 */       this.usePieGraph = false; }
/*     */ 
/*     */ 
/*     */     
/* 522 */     updateGraph();
/*     */ 
/*     */     
/* 525 */     if (!this._isDebug) {
/* 526 */       showOuterGraph();
/*     */     } else {
/* 528 */       Platform.runLater(new Runnable()
/*     */           {
/*     */             public void run()
/*     */             {
/* 532 */               final Semaphore sem = new Semaphore(0);
/* 533 */               SwingUtilities.invokeLater(new Runnable() {
/*     */                     public void run() {
/* 535 */                       sem.release();
/*     */                     }
/*     */                   });
/*     */               try {
/* 539 */                 sem.acquire();
/* 540 */               } catch (InterruptedException interruptedException) {}
/*     */ 
/*     */               
/* 543 */               if (MCFXGraph.this.usePieGraph) {
/* 544 */                 MCFXGraph.this.basePane = new AnchorPane();
/* 545 */                 if (MCFXGraph.this.basePane != null) {
/* 546 */                   MCFXGraph.this.outerStage = new Stage();
/* 547 */                   MCFXGraph.this.start(MCFXGraph.this.outerStage, (Pane)MCFXGraph.this.basePane, MCFXGraph.this.graphTitle);
/* 548 */                   MCFXGraph.this.createPieGraph();
/*     */                   
/* 550 */                   boolean f = MCFXGraph.this.useAnimation();
/* 551 */                   if (f)
/*     */                   {
/*     */                     
/* 554 */                     MCFXGraph.this.updateGraphData2();
/*     */                   }
/*     */                 } 
/*     */               } else {
/* 558 */                 double min = 0.0D;
/* 559 */                 double max = Double.MIN_VALUE;
/* 560 */                 MCFXGraph.this.basePane = new AnchorPane();
/* 561 */                 if (MCFXGraph.this.basePane != null) {
/* 562 */                   MCFXGraph.this.outerStage = new Stage();
/*     */                   
/* 564 */                   MCFXGraph.this._start(MCFXGraph.this.outerStage, (Pane)MCFXGraph.this.basePane, MCFXGraph.this.graphTitle, false);
/* 565 */                   MCFXGraph.this.initEvents(MCFXGraph.this.outerStage);
/*     */                   
/* 567 */                   MCFXGraph.this.createXYGraph(min, max);
/* 568 */                   MCFXGraph.this.updateGraph();
/*     */                   
/* 570 */                   boolean f = MCFXGraph.this.useAnimation();
/* 571 */                   if (f)
/*     */                   {
/*     */                     
/* 574 */                     MCFXGraph.this.updateGraphData2();
/*     */                   }
/*     */                   
/* 577 */                   MCFXGraph.this.outerStage.show();
/* 578 */                   MCFXGraph.this.basePane.requestLayout();
/*     */                 } 
/*     */               } 
/*     */             }
/*     */           });
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void start(Stage stage, Pane pane, String title) {
/* 596 */     if (this.outerStage == null) {
/* 597 */       this.outerStage = stage;
/*     */     }
/*     */ 
/*     */     
/* 601 */     String t = title;
/* 602 */     if (t.length() == 0) {
/* 603 */       t = "MCFXGraph";
/*     */     }
/* 605 */     initEvents(stage);
/*     */     
/* 607 */     if (this._isDebug) {
/* 608 */       _start(stage, pane, t, true);
/*     */     } else {
/* 610 */       _start(stage, pane, t, true);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void hideOuterGraph() {
/* 620 */     Platform.runLater(new Runnable() {
/*     */           public void run() {
/* 622 */             if (MCFXGraph.this.outerStage != null) {
/* 623 */               MCFXGraph.this.outerStage.hide();
/*     */             }
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void toFront() {
/* 635 */     Platform.runLater(new Runnable() {
/*     */           public void run() {
/* 637 */             if (MCFXGraph.this.outerStage != null) {
/* 638 */               MCFXGraph.this.outerStage.toFront();
/*     */             }
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initEvents(Stage stage) {
/* 652 */     if (this._isDebug) {
/*     */       
/* 654 */       final MCFXGraph thisGraph = this;
/* 655 */       stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
/*     */             public void handle(WindowEvent we) {
/* 657 */               if (MCFXGraph.this.graphDelegate != null) {
/* 658 */                 MCFXGraph.this.graphDelegate.doCloseOuterGraph(thisGraph);
/*     */               }
/*     */             }
/*     */           });
/*     */     } else {
/* 663 */       super.initEvents(stage);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doClickXYGraph(MCFXGraph graph, XYChart chart, XYChart.Series<String, Number> series, XYChart.Data<String, Number> data, String xValue, Number yValue) {
/* 686 */     Class<?> cl = null;
/*     */     try {
/* 688 */       cl = Class.forName(this.graphDetailClassName);
/* 689 */     } catch (ClassNotFoundException ex) {
/*     */       
/* 691 */       debugLog(ex);
/*     */     } 
/*     */     
/* 694 */     if (cl != null) {
/*     */       Method method;
/*     */       
/*     */       try {
/* 698 */         method = cl.getMethod("doClickXYGraph", new Class[] { MCRootPanel.class, MCFXGraphCore.class, 
/* 699 */               XYChart.class, XYChart.Series.class, XYChart.Data.class, String.class, Number.class });
/*     */       
/*     */       }
/* 702 */       catch (SecurityException e) {
/* 703 */         throw new MCException(e);
/* 704 */       } catch (NoSuchMethodException e) {
/* 705 */         throw new MCException(e);
/*     */       } 
/*     */       
/*     */       try {
/* 709 */         method.invoke(null, new Object[] { graph.targetRootPanel, graph, chart, series, data, xValue, yValue });
/* 710 */       } catch (IllegalArgumentException e) {
/* 711 */         throw new MCException(e);
/* 712 */       } catch (IllegalAccessException e) {
/* 713 */         throw new MCException(e);
/* 714 */       } catch (InvocationTargetException e) {
/* 715 */         throw new MCException(e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doClickPieGraph(MCFXGraph graph, PieChart chart, PieChart.Data data, String xValue, Number yValue) {
/* 735 */     Class<?> cl = null;
/*     */     try {
/* 737 */       cl = Class.forName(this.graphDetailClassName);
/* 738 */     } catch (ClassNotFoundException ex) {
/*     */       
/* 740 */       debugLog(ex);
/* 741 */       cl = null;
/*     */     } 
/*     */     
/* 744 */     if (cl != null) {
/*     */       Method method;
/*     */       try {
/* 747 */         method = cl.getMethod("doClickPieGraph", 
/* 748 */             new Class[] { MCRootPanel.class, MCFXGraphCore.class, PieChart.class, 
/* 749 */               PieChart.Data.class, String.class, Number.class });
/* 750 */       } catch (SecurityException e) {
/* 751 */         throw new MCException(e);
/* 752 */       } catch (NoSuchMethodException e) {
/* 753 */         throw new MCException(e);
/*     */       } 
/*     */       
/*     */       try {
/* 757 */         method.invoke(null, new Object[] { graph.targetRootPanel, graph, chart, data, xValue, yValue });
/* 758 */       } catch (IllegalArgumentException e) {
/* 759 */         throw new MCException(e);
/* 760 */       } catch (IllegalAccessException e) {
/* 761 */         throw new MCException(e);
/* 762 */       } catch (InvocationTargetException e) {
/* 763 */         throw new MCException(e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removePanel() {
/* 775 */     synchronized (this._lockFxPanel) {
/*     */       
/* 777 */       if (this._fxPanel != null) {
/* 778 */         if (this.targetPanel != null) {
/* 779 */           this.targetPanel.remove((Component)this._fxPanel);
/*     */         }
/* 781 */         this._fxPanel = null;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void debugLog(Throwable t) {
/* 788 */     MCLog.developDebug(t);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\fxgraph\MCFXGraph.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */