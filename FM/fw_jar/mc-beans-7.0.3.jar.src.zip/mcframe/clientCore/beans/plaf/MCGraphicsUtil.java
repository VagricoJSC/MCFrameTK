/*     */ package mcframe.clientCore.beans.plaf;
/*     */ 
/*     */ import java.awt.AlphaComposite;
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.GradientPaint;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.GraphicsConfiguration;
/*     */ import java.awt.Image;
/*     */ import java.awt.Insets;
/*     */ import java.awt.LinearGradientPaint;
/*     */ import java.awt.MultipleGradientPaint;
/*     */ import java.awt.Paint;
/*     */ import java.awt.Polygon;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.Shape;
/*     */ import java.awt.geom.Line2D;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.FilteredImageSource;
/*     */ import java.awt.image.ImageObserver;
/*     */ import java.awt.image.RGBImageFilter;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.text.JTextComponent;
/*     */ import mcframe.clientCore.beans.MCButton;
/*     */ import mcframe.clientCore.beans.MCField;
/*     */ import mcframe.clientCore.beans.MCMode;
/*     */ import mcframe.clientCore.beans.MCModeBeans;
/*     */ import mcframe.clientCore.beans.combobox.AbsMCComboBox;
/*     */ import mcframe.clientCore.beans.plaf.metal.MCTheme;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public class MCGraphicsUtil
/*     */ {
/*  58 */   private static final Map<String, Object> _cache = new HashMap<>();
/*     */   
/*     */   public static void clearCache() {
/*  61 */     _cache.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract class MCBorderPainter
/*     */   {
/*     */     public abstract void paintBorder(Graphics2D param1Graphics2D, Shape param1Shape);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void draw(Graphics2D g, Shape s, int width, int height, MCBorderPainter painter) {
/*  79 */     BufferedImage clipImage = createClipImage(s, g, width, height);
/*  80 */     Graphics2D g2 = clipImage.createGraphics();
/*  81 */     g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, 
/*  82 */         RenderingHints.VALUE_ANTIALIAS_ON);
/*  83 */     g2.setComposite(AlphaComposite.SrcAtop);
/*  84 */     g2.setPaint(g.getPaint());
/*  85 */     g2.fill(s);
/*  86 */     if (painter != null) {
/*  87 */       painter.paintBorder(g2, s);
/*     */     }
/*     */     
/*  90 */     g2.dispose();
/*  91 */     g.drawImage(clipImage, 0, 0, (ImageObserver)null);
/*     */   }
/*     */ 
/*     */   
/*     */   private static BufferedImage createClipImage(Shape s, Graphics2D g, int width, int height) {
/*  96 */     GraphicsConfiguration gc = g.getDeviceConfiguration();
/*  97 */     BufferedImage img = gc.createCompatibleImage(width, height, 
/*  98 */         3);
/*  99 */     Graphics2D g2 = img.createGraphics();
/*     */     
/* 101 */     g2.setComposite(AlphaComposite.Clear);
/* 102 */     g2.fillRect(0, 0, width, height);
/*     */     
/* 104 */     g2.setComposite(AlphaComposite.Src);
/* 105 */     g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, 
/* 106 */         RenderingHints.VALUE_ANTIALIAS_ON);
/* 107 */     g2.setColor(Color.WHITE);
/* 108 */     g2.fill(s);
/* 109 */     g2.dispose();
/*     */     
/* 111 */     return img;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LinearGradientPaint createLinerGradientPaint(int height, Color c1, Color c2) {
/* 124 */     float[] dist = {
/* 125 */         0.0F, 0.999F, 1.0F
/*     */       };
/* 127 */     Color[] colors = {
/* 128 */         c1, c2, c2
/*     */       };
/*     */     
/* 131 */     LinearGradientPaint gradient = new LinearGradientPaint(0.0F, 0.0F, 0.0F, height, dist, 
/* 132 */         colors, MultipleGradientPaint.CycleMethod.NO_CYCLE);
/* 133 */     return gradient;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LinearGradientPaint createUp2GradientPaint(int height, Color c1, Color c2) {
/* 146 */     return new LinearGradientPaint(0.0F, (-height >> 1), 0.0F, 
/*     */         
/* 148 */         height, new float[] {
/* 149 */           0.0F, 0.6F, 1.0F
/* 150 */         }, new Color[] {
/* 151 */           c2, c1, c2
/* 152 */         }, MultipleGradientPaint.CycleMethod.NO_CYCLE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LinearGradientPaint createUpGradientPaint(int height, Color c1, Color c2) {
/* 165 */     return new LinearGradientPaint(0.0F, (-height >> 2), 0.0F, 
/*     */         
/* 167 */         height, new float[] {
/* 168 */           0.0F, 0.4F, 0.6F, 1.0F
/* 169 */         }, new Color[] {
/* 170 */           c2, c1, c1, c2
/* 171 */         }, MultipleGradientPaint.CycleMethod.NO_CYCLE);
/*     */   }
/*     */   
/*     */   public enum Corners {
/* 175 */     TOP, LEFT, BOTTOM, RIGHT;
/*     */   }
/*     */   
/*     */   public static void paintLine(Graphics g, Rectangle rect, Corners cnrs, int w) {
/* 179 */     BasicStroke b2 = new BasicStroke(w, 1, 
/* 180 */         0);
/*     */     
/* 182 */     float size = b2.getLineWidth();
/*     */     
/* 184 */     if (size > 0.0F) {
/* 185 */       g = g.create();
/* 186 */       if (g instanceof Graphics2D) {
/* 187 */         Graphics2D g2d = (Graphics2D)g;
/* 188 */         g2d.setStroke(b2);
/*     */ 
/*     */ 
/*     */         
/* 192 */         switch (cnrs) {
/*     */           case TOP:
/* 194 */             g2d.draw(new Line2D.Double(rect.x, rect.y, (rect.x + rect.width), 
/* 195 */                   rect.y));
/*     */             break;
/*     */           case null:
/* 198 */             g2d.draw(new Line2D.Double(rect.x, (rect.y + rect.height), (
/* 199 */                   rect.x + rect.width), (rect.y + rect.height)));
/*     */             break;
/*     */           case LEFT:
/* 202 */             g2d.draw(new Line2D.Double(rect.x, rect.y, rect.x, (
/* 203 */                   rect.y + rect.height)));
/*     */             break;
/*     */           
/*     */           case RIGHT:
/* 207 */             g2d.draw(new Line2D.Double((rect.x + rect.width), rect.y, (
/* 208 */                   rect.x + rect.width), (rect.y + rect.height)));
/*     */             break;
/*     */         } 
/*     */       } 
/* 212 */       g.dispose();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String getUIKey(AbstractButton b, String suff) {
/* 217 */     if (b instanceof MCButton) {
/* 218 */       MCButton mb = (MCButton)b;
/* 219 */       String grp = mb.getGroup();
/* 220 */       if (grp != null && Arrays.binarySearch((Object[])MCTheme.BUTTON_GRPS, grp) >= 0) {
/* 221 */         grp = "_" + grp;
/* 222 */         return "Button" + grp + "." + suff;
/*     */       } 
/* 224 */       return "Button." + suff;
/*     */     } 
/* 226 */     return "Button." + suff;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void drawModeLine(Graphics g, JTextComponent c) {
/* 241 */     boolean doPaint = false;
/* 242 */     if (c instanceof MCField) {
/*     */       
/* 244 */       MCField cf = (MCField)c;
/* 245 */       if (!cf.isMCFocusOwner() && 
/* 246 */         cf.getRowValue() == null) {
/* 247 */         doPaint = true;
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 252 */     else if (c.getParent() instanceof AbsMCComboBox) {
/* 253 */       AbsMCComboBox o = (AbsMCComboBox)c.getParent();
/* 254 */       if (!o.isMCFocusOwner() && 
/* 255 */         o.getRowValue() == null) {
/* 256 */         doPaint = true;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 262 */     if (!doPaint && MCStringUtil.isNull(c.getText())) {
/* 263 */       doPaint = true;
/*     */     }
/* 265 */     if (doPaint) {
/* 266 */       if (c.getParent() instanceof AbsMCComboBox) {
/* 267 */         drawLine(g, c, ((MCModeBeans)c.getParent()).getMode(), Corners.LEFT);
/*     */       }
/* 269 */       else if (c instanceof MCModeBeans) {
/* 270 */         drawLine(g, c, ((MCModeBeans)c).getMode(), Corners.LEFT);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void drawLine(Graphics g, Component c, MCMode mode, Corners cnrs) {
/* 286 */     if (g instanceof Graphics2D) {
/* 287 */       Graphics2D g2 = (Graphics2D)g;
/* 288 */       String keypref = "field.";
/* 289 */       if (mode != null) {
/* 290 */         keypref = String.valueOf(keypref) + "mode." + mode.getName() + ".line";
/*     */       }
/*     */       
/* 293 */       if (!getCacheBoolean(String.valueOf(keypref) + ".use", false)) {
/*     */         return;
/*     */       }
/*     */       
/* 297 */       Color clr = getCacheColor(String.valueOf(keypref) + ".color", g2.getColor());
/*     */ 
/*     */       
/* 300 */       int thickness = getCacheInt(String.valueOf(keypref) + ".thickness", 4);
/*     */       
/* 302 */       int h = c.getHeight();
/* 303 */       g2.setColor(clr);
/* 304 */       paintLine(g2, new Rectangle(5, 3, 0, h - 7), cnrs, thickness);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void drawShadow(Graphics g, Component c, String typ, MCMode mode) {
/* 321 */     if (g instanceof Graphics2D) {
/* 322 */       Graphics2D g2 = (Graphics2D)g;
/* 323 */       String keypref = String.valueOf(typ) + ".shadow";
/* 324 */       if (mode != null) {
/* 325 */         keypref = String.valueOf(keypref) + "." + mode.getName();
/*     */       }
/* 327 */       Boolean top = Boolean.valueOf(getCacheBoolean(String.valueOf(keypref) + ".top", false));
/* 328 */       boolean left = getCacheBoolean(String.valueOf(keypref) + ".left", false);
/* 329 */       if (!top.booleanValue() && !left) {
/*     */         return;
/*     */       }
/* 332 */       Color clr = getCacheColor(String.valueOf(keypref) + ".color", g2.getColor());
/* 333 */       Color clr2 = getCacheColor(String.valueOf(keypref) + ".color2", clr.darker().darker());
/* 334 */       int thickness = getCacheInt(String.valueOf(keypref) + ".thickness", 4);
/* 335 */       int x = 0;
/* 336 */       int y = 0;
/* 337 */       int w = c.getWidth();
/* 338 */       int h = c.getHeight();
/* 339 */       int ttns = thickness;
/* 340 */       int ltns = thickness;
/*     */       
/* 342 */       paintShadow(g2, x, y, w, h, ttns, ltns, top.booleanValue(), left, clr, clr2);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void paintShadow(Graphics2D g2, int x, int y, int w, int h, int topthickness, int leftthickness, boolean top, boolean left, Color clr, Color clr2) {
/* 368 */     Paint old = g2.getPaint();
/*     */     try {
/* 370 */       if (top) {
/* 371 */         int ttns = topthickness;
/* 372 */         g2.setPaint(new GradientPaint(x, y, clr2, x, ttns, clr));
/* 373 */         int[] xp = {
/* 374 */             0, ttns, w, w
/*     */           };
/* 376 */         int[] yp = {
/* 377 */             0, ttns, ttns
/*     */           };
/* 379 */         g2.fill(new Polygon(xp, yp, xp.length));
/*     */       } 
/* 381 */       if (left) {
/* 382 */         int ltns = leftthickness;
/* 383 */         g2.setPaint(new GradientPaint(x, y, clr2, ltns, y, clr));
/* 384 */         int[] xp = {
/* 385 */             0, 0, ltns, ltns
/*     */           };
/* 387 */         int[] yp = {
/* 388 */             0, h, h, ltns
/*     */           };
/* 390 */         g2.fill(new Polygon(xp, yp, xp.length));
/*     */       } 
/*     */     } finally {
/*     */       
/* 394 */       g2.setPaint(old);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean getCacheBoolean(String key, boolean def) {
/* 405 */     Boolean b = (Boolean)_cache.get(key);
/* 406 */     if (b == null) {
/* 407 */       b = Boolean.valueOf(MCConst.beans.getBoolean(key, def));
/* 408 */       _cache.put(key, b);
/*     */     } 
/* 410 */     return b.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Color getCacheColor(String key, Color def) {
/* 420 */     Color clr = (Color)_cache.get(key);
/* 421 */     if (clr == null) {
/* 422 */       clr = MCConst.beans.getColor(key, def);
/* 423 */       _cache.put(key, clr);
/*     */     } 
/* 425 */     return clr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Color getCacheColor(String key) {
/* 435 */     Color clr = (Color)_cache.get(key);
/* 436 */     if (clr == null) {
/* 437 */       if (_cache.containsKey(key)) {
/* 438 */         return null;
/*     */       }
/* 440 */       clr = MCConst.beans.getColor(key);
/* 441 */       _cache.put(key, clr);
/*     */     } 
/* 443 */     return clr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int getCacheInt(String key, int def) {
/* 454 */     Integer o = (Integer)_cache.get(key);
/* 455 */     int thickness = def;
/* 456 */     if (o == null) {
/* 457 */       thickness = MCConst.beans.getInteger(key, thickness);
/* 458 */       _cache.put(key, Integer.valueOf(thickness));
/*     */     } else {
/*     */       
/* 461 */       thickness = o.intValue();
/*     */     } 
/* 463 */     return thickness;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int getCacheInt(String key) {
/* 474 */     Integer i = (Integer)_cache.get(key);
/* 475 */     if (i == null) {
/* 476 */       if (_cache.containsKey(key)) {
/* 477 */         return Integer.MIN_VALUE;
/*     */       }
/* 479 */       i = Integer.valueOf(MCConst.beans.getInteger(key));
/* 480 */       _cache.put(key, i);
/*     */     } 
/* 482 */     return i.intValue();
/*     */   }
/*     */   
/*     */   public static String getRType(JComponent b) {
/* 486 */     if (b instanceof JTextComponent || b instanceof mcframe.clientCore.beans.table.MCCellRenderer) {
/* 487 */       return "field";
/*     */     }
/* 489 */     if (b instanceof mcframe.clientCore.beans.combobox.MCComboButton) {
/* 490 */       return "combo_button";
/*     */     }
/*     */     
/* 493 */     return "button";
/*     */   }
/*     */ 
/*     */   
/*     */   public static Color getUIBeansColor(JComponent b, String suff) {
/* 498 */     String t = getRType(b);
/* 499 */     String defKey = String.valueOf(t) + "." + suff;
/* 500 */     if (b instanceof MCButton) {
/* 501 */       MCButton mb = (MCButton)b;
/* 502 */       String grp = mb.getGroup();
/* 503 */       grp = (grp != null) ? ("_" + grp) : "";
/* 504 */       String k = String.valueOf(t) + grp + "." + suff;
/* 505 */       Color c = getCacheColor(k);
/* 506 */       if (c == null && !defKey.equals(k)) {
/* 507 */         c = getCacheColor(defKey);
/*     */       }
/* 509 */       return c;
/*     */     } 
/*     */     
/* 512 */     return getCacheColor(defKey);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getUIBeansInteger(JComponent b, String suff) {
/* 518 */     int nullval = Integer.MIN_VALUE;
/* 519 */     String t = getRType(b);
/* 520 */     String defKey = String.valueOf(t) + "." + suff;
/* 521 */     if (b instanceof MCButton) {
/* 522 */       MCButton mb = (MCButton)b;
/* 523 */       String grp = mb.getGroup();
/* 524 */       grp = (grp != null) ? ("_" + grp) : "";
/* 525 */       String k = String.valueOf(t) + grp + "." + suff;
/* 526 */       int c = getCacheInt(k, nullval);
/* 527 */       if (c == Integer.MIN_VALUE && !defKey.equals(k)) {
/* 528 */         c = getCacheInt(defKey);
/*     */       }
/* 530 */       return c;
/*     */     } 
/*     */     
/* 533 */     return getCacheInt(defKey, nullval);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean getUIBeansBoolean(JComponent b, String suff, boolean def) {
/* 539 */     String t = getRType(b);
/* 540 */     String defKey = String.valueOf(t) + "." + suff;
/* 541 */     if (b instanceof MCButton) {
/* 542 */       MCButton mb = (MCButton)b;
/* 543 */       String grp = mb.getGroup();
/* 544 */       grp = (grp != null) ? ("_" + grp) : "";
/* 545 */       String k = String.valueOf(t) + grp + "." + suff;
/* 546 */       return getCacheBoolean(k, getCacheBoolean(defKey, def));
/*     */     } 
/*     */     
/* 549 */     return getCacheBoolean(defKey, def);
/*     */   }
/*     */ 
/*     */   
/* 553 */   private static final Rectangle _viewRect = new Rectangle();
/*     */   
/*     */   public enum CornerMarkLocation
/*     */   {
/* 557 */     INNNER, DEFAULT, OUTER;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Rectangle paintCornerMark(Graphics g, JComponent b, Rectangle viewRect, String r_pref, MCMode mode, CornerMarkLocation cml) {
/* 562 */     if (mode != null) {
/* 563 */       r_pref = String.valueOf(r_pref) + "." + mode.getName();
/*     */     }
/* 565 */     if (!getUIBeansBoolean(b, String.valueOf(r_pref) + ".mark.use", false)) {
/* 566 */       return viewRect;
/*     */     }
/* 568 */     Insets i = b.getInsets();
/* 569 */     if (viewRect == null) {
/* 570 */       viewRect = _viewRect;
/* 571 */       viewRect.x = i.left;
/* 572 */       viewRect.y = i.top;
/* 573 */       viewRect.width = b.getWidth() - i.right + viewRect.x;
/* 574 */       viewRect.height = b.getHeight() - i.bottom + viewRect.y;
/*     */     } 
/*     */     
/* 577 */     g = g.create();
/*     */     try {
/* 579 */       if (g instanceof Graphics2D) {
/* 580 */         Graphics2D g2 = (Graphics2D)g;
/* 581 */         Insets insets = b.getInsets();
/* 582 */         g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, 
/* 583 */             RenderingHints.VALUE_ANTIALIAS_ON);
/*     */         
/* 585 */         Color c = getUIBeansColor(b, String.valueOf(r_pref) + ".mark.color");
/* 586 */         if (c == null) {
/* 587 */           c = new Color(128, 0, 0);
/*     */         }
/* 589 */         g2.setColor(c);
/*     */         
/* 591 */         int len = getCornerMarkWidth(b, r_pref);
/* 592 */         if (len == Integer.MIN_VALUE) {
/* 593 */           len = 5;
/*     */         }
/* 595 */         if (getUIBeansBoolean(b, String.valueOf(r_pref) + ".mark.topleft", false)) {
/* 596 */           int x = viewRect.x;
/* 597 */           int y = viewRect.y;
/* 598 */           switch (cml) {
/*     */ 
/*     */             
/*     */             case INNNER:
/* 602 */               x += insets.left;
/* 603 */               y += insets.top;
/*     */               break;
/*     */             case OUTER:
/* 606 */               x -= insets.left;
/* 607 */               y -= insets.top;
/*     */               break;
/*     */           } 
/* 610 */           int[] xPoints = {
/* 611 */               x, x + len, x
/*     */             };
/* 613 */           int[] yPoints = {
/* 614 */               y, y, y + len
/*     */             };
/* 616 */           g2.fillPolygon(xPoints, yPoints, xPoints.length);
/*     */         } 
/* 618 */         if (getUIBeansBoolean(b, String.valueOf(r_pref) + ".mark.leftbottom", false)) {
/* 619 */           int x = viewRect.x;
/* 620 */           int y = viewRect.y + viewRect.height;
/*     */           
/* 622 */           switch (cml) {
/*     */ 
/*     */             
/*     */             case INNNER:
/* 626 */               x += insets.left;
/* 627 */               y -= insets.bottom;
/*     */               break;
/*     */             case OUTER:
/* 630 */               x -= insets.left;
/* 631 */               y += insets.bottom;
/*     */               break;
/*     */           } 
/*     */           
/* 635 */           int[] xPoints = {
/* 636 */               x, x, x + len
/*     */             };
/* 638 */           int[] yPoints = {
/* 639 */               y - len, y, y
/*     */             };
/* 641 */           g2.fillPolygon(xPoints, yPoints, xPoints.length);
/*     */         } 
/* 643 */         if (getUIBeansBoolean(b, String.valueOf(r_pref) + ".mark.bottomright", false)) {
/* 644 */           int x = viewRect.x + viewRect.width;
/* 645 */           int y = viewRect.y + viewRect.height;
/*     */           
/* 647 */           switch (cml) {
/*     */ 
/*     */             
/*     */             case INNNER:
/* 651 */               x -= insets.right;
/* 652 */               y -= insets.bottom;
/*     */               break;
/*     */             case OUTER:
/* 655 */               x += insets.right;
/* 656 */               y += insets.bottom;
/*     */               break;
/*     */           } 
/* 659 */           int[] xPoints = {
/* 660 */               x, x - len, x
/*     */             };
/* 662 */           int[] yPoints = {
/* 663 */               y - len, y, y
/*     */             };
/* 665 */           g2.fillPolygon(xPoints, yPoints, xPoints.length);
/*     */         } 
/* 667 */         if (getUIBeansBoolean(b, String.valueOf(r_pref) + ".mark.righttop", false)) {
/* 668 */           int x = viewRect.x + viewRect.width;
/* 669 */           int y = viewRect.y;
/*     */           
/* 671 */           switch (cml) {
/*     */ 
/*     */             
/*     */             case INNNER:
/* 675 */               x -= insets.right;
/* 676 */               y += insets.top;
/*     */               break;
/*     */             case OUTER:
/* 679 */               x += insets.right;
/* 680 */               y -= insets.top;
/*     */               break;
/*     */           } 
/* 683 */           int[] xPoints = {
/* 684 */               x - len, x, x
/*     */             };
/* 686 */           int[] yPoints = {
/* 687 */               y, y, y + len
/*     */             };
/* 689 */           g2.fillPolygon(xPoints, yPoints, xPoints.length);
/*     */         } 
/*     */       } 
/*     */     } finally {
/*     */       
/* 694 */       g.dispose();
/*     */     } 
/*     */     
/* 697 */     return viewRect;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   private static int getCornerMarkWidth(JComponent b, String r_pref) {
/* 704 */     return getUIBeansInteger(b, String.valueOf(r_pref) + ".mark.width");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FilteredImageSource createReverseIconFilltered(Image image) {
/* 716 */     return new FilteredImageSource(image.getSource(), new ReverseIconFillter());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FilteredImageSource createHalfAlphaIconFilltered(Image image) {
/* 728 */     return new FilteredImageSource(image.getSource(), new HalfAlphaIconFillter());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static FilteredImageSource createMonoIconFilltered(Image image) {
/* 740 */     return new FilteredImageSource(image.getSource(), new MonoIconFillter());
/*     */   }
/*     */   
/*     */   private static class HalfAlphaIconFillter
/*     */     extends RGBImageFilter {
/*     */     public HalfAlphaIconFillter() {
/* 746 */       this.canFilterIndexColorModel = true;
/*     */     }
/*     */ 
/*     */     
/*     */     public int filterRGB(int x, int y, int rgb) {
/* 751 */       int a = MCGraphicsUtil.ImageUtil.a(rgb);
/* 752 */       int r = MCGraphicsUtil.ImageUtil.r(rgb);
/* 753 */       int g = MCGraphicsUtil.ImageUtil.g(rgb);
/* 754 */       int b = MCGraphicsUtil.ImageUtil.b(rgb);
/* 755 */       if (a != 0) {
/* 756 */         a >>= 1;
/*     */       }
/* 758 */       return MCGraphicsUtil.ImageUtil.argb(a, r, g, b);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static class MonoIconFillter
/*     */     extends RGBImageFilter
/*     */   {
/*     */     public int filterRGB(int x, int y, int rgb) {
/* 770 */       int a = MCGraphicsUtil.ImageUtil.a(rgb);
/* 771 */       int r = MCGraphicsUtil.ImageUtil.r(rgb);
/* 772 */       int g = MCGraphicsUtil.ImageUtil.g(rgb);
/* 773 */       int b = MCGraphicsUtil.ImageUtil.b(rgb);
/* 774 */       int mono = (int)(0.299D * r + 0.587D * g + 0.114D * b);
/* 775 */       return (a << 24) + (mono << 16) + (mono << 8) + mono;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class ReverseIconFillter
/*     */     extends RGBImageFilter {
/*     */     public ReverseIconFillter() {
/* 782 */       this.canFilterIndexColorModel = true;
/*     */     }
/*     */ 
/*     */     
/*     */     public int filterRGB(int x, int y, int rgb) {
/* 787 */       int a = MCGraphicsUtil.ImageUtil.a(rgb);
/* 788 */       int r = 255 - MCGraphicsUtil.ImageUtil.r(rgb);
/* 789 */       int g = 255 - MCGraphicsUtil.ImageUtil.g(rgb);
/* 790 */       int b = 255 - MCGraphicsUtil.ImageUtil.b(rgb);
/*     */       
/* 792 */       return MCGraphicsUtil.ImageUtil.argb(a, r, g, b);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class ImageUtil {
/*     */     public static int a(int c) {
/* 798 */       return c >>> 24;
/*     */     }
/*     */     
/*     */     public static int r(int c) {
/* 802 */       return c >> 16 & 0xFF;
/*     */     }
/*     */     
/*     */     public static int g(int c) {
/* 806 */       return c >> 8 & 0xFF;
/*     */     }
/*     */     
/*     */     public static int b(int c) {
/* 810 */       return c & 0xFF;
/*     */     }
/*     */     
/*     */     public static int argb(int a, int r, int g, int b) {
/* 814 */       return a << 24 | r << 16 | g << 8 | b;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\plaf\MCGraphicsUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */