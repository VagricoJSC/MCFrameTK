/*     */ package mcframe.clientCore.beans.plaf;
/*     */ 
/*     */ import java.awt.Shape;
/*     */ import java.awt.geom.GeneralPath;
/*     */ import java.awt.geom.Line2D;
/*     */ import java.awt.geom.Point2D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCShapeFactory
/*     */ {
/*     */   public enum MCArrowType
/*     */   {
/*  33 */     STRAIGHT
/*     */     {
/*     */       public MCShapeFactory.MCArrowTypeGroup getGroup() {
/*  36 */         return MCShapeFactory.MCArrowTypeGroup.STRAIGHT;
/*     */       }
/*     */     },
/*  39 */     ELBOW_1
/*     */     {
/*     */       public MCShapeFactory.MCArrowTypeGroup getGroup() {
/*  42 */         return MCShapeFactory.MCArrowTypeGroup.ELBOW;
/*     */       }
/*     */     },
/*  45 */     ELBOW_2
/*     */     {
/*     */       public MCShapeFactory.MCArrowTypeGroup getGroup() {
/*  48 */         return MCShapeFactory.MCArrowTypeGroup.ELBOW;
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */     
/*     */     public abstract MCShapeFactory.MCArrowTypeGroup getGroup();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public enum MCArrowTypeGroup
/*     */   {
/*  61 */     STRAIGHT, ELBOW;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Shape createArrow(Point2D start, Point2D end, double headheight, double headAngle, MCArrowType at) {
/*     */     Line2D lx1, ly, lx2;
/*     */     double centerx, w;
/*     */     Line2D lx;
/*  80 */     double h, headAnglePar2 = headAngle / 2.0D;
/*  81 */     double edgelen = 1.0D / Math.cos(headAnglePar2) * headheight;
/*     */     
/*  83 */     GeneralPath rtn = null;
/*     */     
/*  85 */     switch (at) {
/*     */       case ELBOW_2:
/*  87 */         lx1 = null;
/*  88 */         ly = null;
/*  89 */         lx2 = null;
/*     */         
/*  91 */         centerx = start.getX();
/*  92 */         w = end.getX() - start.getX();
/*  93 */         if (w == 0.0D) {
/*  94 */           ly = new Line2D.Double(start, end);
/*  95 */           return addArrowHead(ly, headAnglePar2, edgelen);
/*     */         } 
/*  97 */         centerx = start.getX() + w / 2.0D;
/*  98 */         if (start.getY() != end.getY()) {
/*  99 */           ly = new Line2D.Double(centerx, start.getY(), centerx, 
/* 100 */               end.getY());
/* 101 */           lx1 = new Line2D.Double(start.getX(), start.getY(), 
/* 102 */               centerx, start.getY());
/* 103 */           lx2 = new Line2D.Double(centerx, end.getY(), end.getX(), 
/* 104 */               end.getY());
/* 105 */           rtn = addArrowHead(lx2, headAnglePar2, edgelen);
/* 106 */           rtn.append(ly, false);
/* 107 */           rtn.append(lx1, false);
/* 108 */           return rtn;
/*     */         } 
/*     */         break;
/*     */ 
/*     */       
/*     */       case null:
/* 114 */         lx = null;
/*     */         
/* 116 */         h = end.getY() - start.getY();
/* 117 */         if (h == 0.0D) {
/* 118 */           lx = new Line2D.Double(start, end);
/* 119 */           return addArrowHead(lx, headAnglePar2, edgelen);
/*     */         } 
/* 121 */         lx = new Line2D.Double(start.getX(), start.getY(), end.getX(), 
/* 122 */             start.getY());
/* 123 */         ly = new Line2D.Double(end.getX(), start.getY(), end.getX(), 
/* 124 */             end.getY());
/* 125 */         rtn = addArrowHead(ly, headAnglePar2, edgelen);
/* 126 */         rtn.append(lx, false);
/* 127 */         return rtn;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 133 */     Line2D l = new Line2D.Double(start, end);
/* 134 */     return addArrowHead(l, headAnglePar2, edgelen);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static GeneralPath addArrowHead(Line2D centerline, double headAnglePar2, double edgelen) {
/* 150 */     Point2D start = centerline.getP1();
/* 151 */     Point2D end = centerline.getP2();
/* 152 */     double rad = Math.atan2(end.getY() - start.getY(), 
/* 153 */         end.getX() - start.getX());
/* 154 */     double prad = rad + headAnglePar2;
/* 155 */     double mrad = rad - headAnglePar2;
/*     */     
/* 157 */     double x1 = end.getX() - Math.cos(prad) * edgelen;
/* 158 */     double y1 = end.getY() - Math.sin(prad) * edgelen;
/* 159 */     double x2 = end.getX() - Math.cos(mrad) * edgelen;
/* 160 */     double y2 = end.getY() - Math.sin(mrad) * edgelen;
/*     */     
/* 162 */     Line2D one = new Line2D.Double(x1, y1, end.getX(), end.getY());
/* 163 */     Line2D ano = new Line2D.Double(x2, y2, end.getX(), end.getY());
/*     */     
/* 165 */     GeneralPath rtn = new GeneralPath(centerline);
/* 166 */     rtn.append(one, true);
/* 167 */     rtn.append(ano, true);
/* 168 */     return rtn;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\plaf\MCShapeFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */