/*    */ package mcframe.clientCore.beans.plaf.metal;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.awt.Graphics;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.JPanel;
/*    */ import javax.swing.LookAndFeel;
/*    */ import javax.swing.UIManager;
/*    */ import javax.swing.plaf.ComponentUI;
/*    */ import javax.swing.plaf.PanelUI;
/*    */ import javax.swing.plaf.basic.BasicPanelUI;
/*    */ import mcframe.clientCore.beans.MCPanel;
/*    */ import mcframe.clientCore.resource.MCConst;
/*    */ 
/*    */ public class MCMetalTempPanelUI
/*    */   extends BasicPanelUI {
/*    */   private static PanelUI panelUI;
/*    */   
/*    */   public static ComponentUI createUI(JComponent c) {
/* 20 */     if (panelUI == null) {
/* 21 */       panelUI = new MCMetalTempPanelUI();
/*    */     }
/* 23 */     return panelUI;
/*    */   }
/*    */ 
/*    */   
/*    */   public void paint(Graphics g, JComponent c) {
/* 28 */     super.paint(g, c);
/* 29 */     MCPanel rs = (MCPanel)c;
/* 30 */     if (c.isOpaque()) {
/* 31 */       int x = 0;
/* 32 */       int y = 0;
/* 33 */       int w = c.getWidth();
/* 34 */       int h = c.getHeight();
/*    */       
/* 36 */       fill(g, rs, x, y, w, h);
/*    */       
/* 38 */       paintBorder(g, rs, x, y, w, h);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   private void fill(Graphics g, MCPanel rs, int x, int y, int w, int h) {
/* 44 */     Color fc = UIManager.getColor("TmpPanel.background");
/* 45 */     if (fc != null) {
/* 46 */       g.setColor(fc);
/* 47 */       g.fillRect(x, y, w, h);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   private void paintBorder(Graphics g, MCPanel rs, int x, int y, int w, int h) {
/* 53 */     if (!rs.getRootPanel().isPartsPanel()) {
/*    */       
/* 55 */       Color bc = UIManager.getColor("TmpPanel.bordercolor");
/* 56 */       if (bc != null) {
/* 57 */         g.setColor(bc);
/*    */       }
/* 59 */       g.drawRect(x, y, w - 1, h - 1);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   protected void installDefaults(JPanel p) {
/* 65 */     super.installDefaults(p);
/* 66 */     LookAndFeel.installProperty(p, "opaque", 
/* 67 */         Boolean.valueOf(MCConst.beans.getBoolean("panel.layouter.rootsub.opaque", false)));
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\plaf\metal\MCMetalTempPanelUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */