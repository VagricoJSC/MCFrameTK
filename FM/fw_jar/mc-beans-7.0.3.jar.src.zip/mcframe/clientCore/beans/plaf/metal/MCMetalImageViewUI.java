/*     */ package mcframe.clientCore.beans.plaf.metal;
/*     */ 
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Rectangle;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.ButtonModel;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.LookAndFeel;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.metal.MetalButtonUI;
/*     */ 
/*     */ public class MCMetalImageViewUI
/*     */   extends MetalButtonUI
/*     */ {
/*  16 */   private static final MCMetalImageViewUI UI = new MCMetalImageViewUI();
/*     */   
/*     */   public static ComponentUI createUI(JComponent c) {
/*  19 */     return UI;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void installDefaults(AbstractButton b) {
/*  25 */     LookAndFeel.installBorder(b, "ImageView.border");
/*     */     
/*  27 */     super.installDefaults(b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintIcon(Graphics g, JComponent c, Rectangle iconRect) {
/*  38 */     AbstractButton b = (AbstractButton)c;
/*  39 */     ButtonModel model = b.getModel();
/*  40 */     Icon icon = b.getIcon();
/*  41 */     Icon tmpIcon = null;
/*     */     
/*  43 */     if (icon == null) {
/*     */       return;
/*     */     }
/*     */     
/*  47 */     Icon selectedIcon = null;
/*     */ 
/*     */     
/*  50 */     if (model.isSelected()) {
/*  51 */       selectedIcon = b.getSelectedIcon();
/*  52 */       if (selectedIcon != null) {
/*  53 */         icon = selectedIcon;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  72 */     if (model.isPressed() && model.isArmed()) {
/*  73 */       tmpIcon = b.getPressedIcon();
/*  74 */       if (tmpIcon != null)
/*     */       {
/*  76 */         clearTextShiftOffset();
/*     */       }
/*     */     }
/*  79 */     else if (b.isRolloverEnabled() && model.isRollover()) {
/*  80 */       if (model.isSelected()) {
/*  81 */         tmpIcon = b.getRolloverSelectedIcon();
/*  82 */         if (tmpIcon == null) {
/*  83 */           tmpIcon = selectedIcon;
/*     */         }
/*     */       } 
/*     */       
/*  87 */       if (tmpIcon == null) {
/*  88 */         tmpIcon = b.getRolloverIcon();
/*     */       }
/*     */     } 
/*     */     
/*  92 */     if (tmpIcon != null) {
/*  93 */       icon = tmpIcon;
/*     */     }
/*     */     
/*  96 */     if (model.isPressed() && model.isArmed()) {
/*  97 */       icon.paintIcon(c, g, iconRect.x + getTextShiftOffset(), iconRect.y + 
/*  98 */           getTextShiftOffset());
/*     */     } else {
/*     */       
/* 101 */       icon.paintIcon(c, g, iconRect.x, iconRect.y);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\plaf\metal\MCMetalImageViewUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */