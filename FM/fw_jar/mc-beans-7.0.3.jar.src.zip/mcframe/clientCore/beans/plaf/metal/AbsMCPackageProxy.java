/*    */ package mcframe.clientCore.beans.plaf.metal;
/*    */ 
/*    */ import mcframe.clientCore.beans.MCCalendarField;
/*    */ import mcframe.clientCore.beans.MCTabbedPane;
/*    */ 
/*    */ public class AbsMCPackageProxy {
/*    */   protected int calculateMaxTabWidth(MCTabbedPane b, int tabplacement) {
/*  8 */     MCMetalTabbedPaneUI t = (MCMetalTabbedPaneUI)b.getUI();
/*  9 */     return t.calculateMaxTabWidth(tabplacement);
/*    */   }
/*    */   
/*    */   protected boolean calenderIconExistence(MCCalendarField f) {
/* 13 */     MCMetalTextFieldUI u = (MCMetalTextFieldUI)f.getUI();
/* 14 */     return u.useCalenderIcon();
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\plaf\metal\AbsMCPackageProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */