/*    */ package mcframe.clientCore.beans.plaf.metal;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import java.awt.Point;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.plaf.ComponentUI;
/*    */ import javax.swing.plaf.basic.BasicToolBarUI;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCMetalStatusBarUI
/*    */   extends BasicToolBarUI
/*    */ {
/*    */   public static ComponentUI createUI(JComponent c) {
/* 32 */     return new MCMetalStatusBarUI();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean canDock(Component c, Point p) {
/* 37 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\plaf\metal\MCMetalStatusBarUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */