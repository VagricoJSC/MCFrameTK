/*     */ package mcframe.clientCore.beans.plaf.metal;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.Insets;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.UIDefaults;
/*     */ import javax.swing.plaf.ColorUIResource;
/*     */ import javax.swing.plaf.InsetsUIResource;
/*     */ import javax.swing.plaf.metal.OceanTheme;
/*     */ import mcframe.clientCore.beans.border.MCButtonLineBorder;
/*     */ import mcframe.clientCore.beans.border.MCFieldBorder;
/*     */ import mcframe.clientCore.beans.border.MCTableHeaderBorder;
/*     */ import mcframe.clientCore.beans.border.MCToolbarBorder;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public final class MCTheme
/*     */   extends OceanTheme
/*     */ {
/*  30 */   private static final Color alpha0 = new Color(0, 0, 0, 0);
/*     */ 
/*     */   
/*     */   public static final String BUTTON_DEF = "";
/*     */ 
/*     */   
/*     */   public static final String BUTTON_SRCH = "srch";
/*     */ 
/*     */   
/*     */   public static final String BUTTON_UPD = "upd";
/*     */ 
/*     */   
/*     */   public static final String BUTTON_DEL = "del";
/*     */ 
/*     */   
/*     */   public static final String BUTTON_CANCEL = "cancel";
/*     */ 
/*     */   
/*     */   public static final String BUTTON_DWNLD = "dwnld";
/*     */ 
/*     */   
/*     */   public static final String BUTTON_OPEN = "open";
/*     */   
/*     */   public static final String BUTTON_PRNT = "prnt";
/*     */   
/*     */   public static final String BUTTON_TOOLBAR = "toolbar";
/*     */   
/*     */   public static final String BUTTON_HEADERBAR = "headerbar";
/*     */   
/*     */   public static final String BUTTON_CALENDER_ARROW = "calender_arrow";
/*     */   
/*     */   public static final String BUTTON_CALENDER_DATE = "calender_date";
/*     */   
/*     */   public static final String BUTTON_NO_BORDER = "no_border";
/*     */   
/*     */   public static final String BUTTON_BLACK = "black";
/*     */   
/*     */   public static final String BUTTON_GREEN = "green";
/*     */   
/*     */   @Deprecated
/*  70 */   public static final String[] BUTTON_GRPS = new String[] { 
/*  71 */       "", "srch", "upd", "del", "cancel", "dwnld", 
/*  72 */       "open", "prnt", "toolbar", "headerbar", 
/*  73 */       "calender_arrow", "calender_date", "no_border", "black", 
/*  74 */       "green" };
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  79 */     Arrays.sort((Object[])BUTTON_GRPS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addCustomEntriesToTable(UIDefaults table) {
/*  87 */     super.addCustomEntriesToTable(table);
/*     */ 
/*     */ 
/*     */     
/*  91 */     List buttonGradient = Arrays.asList(new Object[] {
/*  92 */           new Float(0.3F), new Float(0.0F), new ColorUIResource(14543091), getWhite(), 
/*  93 */           getSecondary2()
/*     */         });
/*     */     
/*  96 */     String fg = "ArrowButton.foreground";
/*  97 */     String str7 = "ArrowButton.background";
/*     */     
/*  99 */     Object[] arrayOfObject3 = {
/* 100 */         fg, MCConst.beans.getColor("arrowbutton.fg", alpha0), str7, 
/* 101 */         MCConst.beans.getColor("arrowbutton.bg", alpha0)
/*     */       };
/* 103 */     table.putDefaults(arrayOfObject3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 123 */     String light = "TabbedPane.light";
/* 124 */     String darkShadow = "TabbedPane.darkShadow";
/* 125 */     String borderHightlightColor = "TabbedPane.borderHightlightColor";
/* 126 */     String selectHighlight = "TabbedPane.selectHighlight";
/* 127 */     String selected = "TabbedPane.selected";
/* 128 */     String str12 = "TabbedPane.background";
/* 129 */     String selectedForeground = "TabbedPane.selectedForeground";
/* 130 */     String lselectedForeground = "TabbedPane.leftselectedForeground";
/* 131 */     String str15 = "TabbedPane.foreground";
/* 132 */     String contentAreaColor = "TabbedPane.contentAreaColor";
/* 133 */     String focus = "TabbedPane.focus";
/* 134 */     String tabInsets = "TabbedPane.tabInsets";
/* 135 */     String tabAreaInsets = "TabbedPane.tabAreaInsets";
/* 136 */     String selected2 = "TabbedPane.selected2";
/* 137 */     String lselected1 = "TabbedPane.leftselected1";
/* 138 */     String lselected2 = "TabbedPane.leftselected1";
/* 139 */     String str16 = "TabbedPane.background2";
/* 140 */     String selectedIndicator = "TabbedPane.selectedIndicator";
/* 141 */     String rollover = "TabbedPane.rollover";
/* 142 */     String rollover2 = "TabbedPane.rollover2";
/* 143 */     String lrollover = "TabbedPane.leftrollover";
/* 144 */     String lrollover2 = "TabbedPane.leftrollover2";
/* 145 */     String lbg = "TabbedPane.leftbg";
/* 146 */     String lbg2 = "TabbedPane.leftbg2";
/* 147 */     Object[] arrayOfObject13 = { 
/* 148 */         light, 
/* 149 */         MCConst.beans.getColor("tabbedpane.light", table.getColor(light)), 
/* 150 */         selectHighlight, 
/* 151 */         MCConst.beans.getColor("tabbedpane.selecthighlight", 
/* 152 */           table.getColor(selectHighlight)), 
/* 153 */         darkShadow, 
/* 154 */         MCConst.beans.getColor("tabbedpane.darkshadow", 
/* 155 */           table.getColor(darkShadow)), 
/* 156 */         borderHightlightColor, 
/* 157 */         MCConst.beans.getColor("tabbedpane.borderhightlightcolor", 
/* 158 */           table.getColor(borderHightlightColor)), 
/* 159 */         selected, 
/* 160 */         MCConst.beans.getColor("tabbedpane.selected", 
/* 161 */           table.getColor(selected)), 
/* 162 */         str15, 
/* 163 */         MCConst.beans.getColor("tabbedpane.deffg", 
/* 164 */           table.getColor(str15)), 
/* 165 */         selectedForeground, 
/* 166 */         MCConst.beans.getColor("tabbedpane.selectedfg", 
/* 167 */           table.getColor(selectedForeground)), 
/* 168 */         lselectedForeground, 
/* 169 */         MCConst.beans.getColor("tabbedpane.left.selectedfg", 
/* 170 */           table.getColor(selectedForeground)), 
/* 171 */         str12, 
/* 172 */         MCConst.beans.getColor("tabbedpane.defbg", 
/* 173 */           table.getColor(str12)), 
/* 174 */         contentAreaColor, 
/* 175 */         MCConst.beans.getColor("tabbedpane.contentareacolor", 
/* 176 */           table.getColor(contentAreaColor)), 
/* 177 */         focus, 
/* 178 */         MCConst.beans.getColor("tabbedpane.focusindicator", 
/* 179 */           table.getColor(focus)), 
/* 180 */         tabInsets, 
/* 181 */         getInsets("tabbedpane.tabinsets", table.getInsets(tabInsets)), 
/* 182 */         tabAreaInsets, 
/* 183 */         getInsets("tabbedpane.tabareainsets", table.getInsets(tabAreaInsets)), 
/* 184 */         rollover, MCConst.beans.getColor("tabbedpane.rollover"), rollover2, 
/* 185 */         MCConst.beans.getColor("tabbedpane.rollover2"), lrollover, 
/* 186 */         MCConst.beans.getColor("tabbedpane.left.rollover"), lrollover2, 
/* 187 */         MCConst.beans.getColor("tabbedpane.left.rollover2"), lselected1, 
/* 188 */         MCConst.beans.getColor("tabbedpane.left.selected"), lselected2, 
/* 189 */         MCConst.beans.getColor("tabbedpane.left.selected2"), lbg, 
/* 190 */         MCConst.beans.getColor("tabbedpane.left.bg"), lbg2, 
/* 191 */         MCConst.beans.getColor("tabbedpane.left.bg2") };
/*     */ 
/*     */ 
/*     */     
/* 195 */     table.putDefaults(arrayOfObject13);
/*     */     
/* 197 */     Object[] arrayOfObject14 = {
/* 198 */         selected2, 
/* 199 */         MCConst.beans.getColor("tabbedpane.selected2", 
/* 200 */           table.getColor(selected)), 
/* 201 */         str16, 
/* 202 */         MCConst.beans.getColor("tabbedpane.defbg2", 
/* 203 */           table.getColor(str12)), 
/* 204 */         selectedIndicator, 
/* 205 */         MCConst.beans.getColor("tabbedpane.selectedindicator")
/*     */       };
/* 207 */     table.putDefaults(arrayOfObject14);
/*     */ 
/*     */     
/* 210 */     String str2 = "ScrollBar.background";
/* 211 */     String str6 = "ScrollBar.highlight";
/* 212 */     String shadow = "ScrollBar.shadow";
/* 213 */     String str11 = "ScrollBar.darkShadow";
/* 214 */     String thumb = "ScrollBar.thumb";
/* 215 */     String thumbShadow = "ScrollBar.thumbShadow";
/* 216 */     String thumbHighlight = "ScrollBar.thumbHighlight";
/* 217 */     String thumbGradient = "ScrollBar.gradient";
/* 218 */     String width = "ScrollBar.width";
/* 219 */     Object[] arrayOfObject10 = { 
/* 220 */         str2, 
/* 221 */         MCConst.beans.getColor("scrollbar.bg", table.getColor(str2)), 
/* 222 */         str6, 
/* 223 */         MCConst.beans.getColor("scrollbar.highlight", 
/* 224 */           table.getColor(str6)), 
/* 225 */         shadow, 
/* 226 */         MCConst.beans.getColor("scrollbar.shadow", table.getColor(shadow)), 
/* 227 */         str11, 
/* 228 */         MCConst.beans.getColor("scrollbar.darkshadow", 
/* 229 */           table.getColor(str11)), 
/* 230 */         thumb, 
/* 231 */         MCConst.beans.getColor("scrollbar.thumb.bg", table.getColor(thumb)), 
/* 232 */         thumbShadow, 
/* 233 */         MCConst.beans.getColor("scrollbar.thumb.shadow", 
/* 234 */           table.getColor(thumbShadow)), 
/* 235 */         thumbHighlight, 
/* 236 */         MCConst.beans.getColor("scrollbar.thumb.highlight", 
/* 237 */           table.getColor(thumbHighlight)), 
/* 238 */         thumbGradient, 
/* 239 */         getGradient("scrollbar.thumb.gradient", buttonGradient), width, 
/* 240 */         Integer.valueOf(MCConst.beans.getInteger("scrollbar.width", 13)) };
/*     */     
/* 242 */     table.putDefaults(arrayOfObject10);
/*     */ 
/*     */     
/* 245 */     String border = "ToolBar.border";
/* 246 */     String str5 = "ToolBar.background";
/* 247 */     String str10 = "ToolBar.foreground";
/* 248 */     String dockingBackground = "ToolBar.dockingBackground";
/* 249 */     String floatingBackground = "ToolBar.floatingBackground";
/* 250 */     String dockingForeground = "ToolBar.dockingForeground";
/* 251 */     String floatingForeground = "ToolBar.floatingForeground";
/* 252 */     String str14 = "ToolBar.background2";
/* 253 */     Object[] arrayOfObject8 = { 
/* 254 */         border, new MCToolbarBorder(), str5, 
/* 255 */         MCConst.beans.getColor("toolbar.bg", table.getColor(str5)), 
/* 256 */         str10, 
/* 257 */         MCConst.beans.getColor("toolbar.fg", table.getColor(str10)), 
/* 258 */         dockingBackground, 
/* 259 */         MCConst.beans.getColor("toolbar.dbg", 
/* 260 */           table.getColor(dockingBackground)), 
/* 261 */         dockingForeground, 
/* 262 */         MCConst.beans.getColor("toolbar.dfg", 
/* 263 */           table.getColor(dockingForeground)), 
/* 264 */         floatingBackground, 
/* 265 */         MCConst.beans.getColor("toolbar.fbg", 
/* 266 */           table.getColor(floatingBackground)), 
/* 267 */         floatingForeground, MCConst.beans.getColor("toolbar.ffg", 
/* 268 */           table.getColor(floatingForeground)) };
/*     */     
/* 270 */     table.putDefaults(arrayOfObject8);
/*     */     
/* 272 */     Object[] arrayOfObject9 = {
/* 273 */         str14, 
/* 274 */         MCConst.beans.getColor("toolbar.bg2", table.getColor(str5))
/*     */       };
/* 276 */     table.putDefaults(arrayOfObject9);
/*     */ 
/*     */     
/* 279 */     String openIcon = "Tree.openIcon";
/* 280 */     String closedIcon = "Tree.closedIcon";
/* 281 */     String leafIcon = "Tree.leafIcon";
/* 282 */     String expandedIcon = "Tree.expandedIcon";
/* 283 */     String collapsedIcon = "Tree.collapsedIcon";
/* 284 */     String paintLines = "Tree.paintLines";
/* 285 */     Icon opn = MCConst.beans.getIcon("tree.icon.open");
/* 286 */     Icon cls = MCConst.beans.getIcon("tree.icon.closed");
/* 287 */     Icon lef = MCConst.beans.getIcon("tree.icon.leaf");
/* 288 */     Icon exp = MCConst.beans.getIcon("tree.icon.expanded");
/* 289 */     Icon clp = MCConst.beans.getIcon("tree.icon.collapsed");
/* 290 */     Object[] arrayOfObject12 = { 
/* 291 */         openIcon, (opn != null) ? opn : table.getIcon(openIcon), closedIcon, 
/* 292 */         (cls != null) ? cls : table.getIcon(closedIcon), leafIcon, 
/* 293 */         (lef != null) ? lef : table.getIcon(leafIcon), expandedIcon, 
/* 294 */         (exp != null) ? exp : table.getIcon(expandedIcon), collapsedIcon, 
/* 295 */         (clp != null) ? clp : table.getIcon(collapsedIcon), paintLines, 
/* 296 */         Boolean.valueOf(MCConst.beans.getBoolean("tree.paintlines", 
/* 297 */             table.getBoolean(paintLines))) };
/*     */     
/* 299 */     table.putDefaults(arrayOfObject12);
/*     */ 
/*     */     
/* 302 */     String bg = "Combobutton.background";
/* 303 */     String str4 = "Combobutton.background2";
/* 304 */     String str9 = "Combobutton.border";
/* 305 */     String bdrbg = "Combobutton.bordercolor";
/* 306 */     String bdrbg2 = "Combobutton.bordercolor2";
/* 307 */     String icon = "Combobutton.icon";
/* 308 */     Object[] arrayOfObject6 = { 
/* 309 */         bg, MCConst.beans.getColor("combo_button.bg"), str4, 
/* 310 */         MCConst.beans.getColor("combo_button.bg2"), str9, 
/* 311 */         new MCButtonLineBorder(1, false, false), bdrbg, 
/* 312 */         MCConst.beans.getColor("combo_button.border.color"), bdrbg2, 
/* 313 */         MCConst.beans.getColor("combo_button.border.color2"), icon, 
/* 314 */         MCConst.beans.getIcon("icon.COMBOARROW") };
/*     */     
/* 316 */     table.putDefaults(arrayOfObject6);
/*     */ 
/*     */     
/* 319 */     Color bg2 = null, rocolor = null, rocolor2 = null, bcolor = null;
/* 320 */     Color bcolor2 = null, sbrocolor = null, sbrocolor2 = null; byte b; int i;
/*     */     String[] arrayOfString;
/* 322 */     for (i = (arrayOfString = BUTTON_GRPS).length, b = 0; b < i; ) { String grp = arrayOfString[b];
/* 323 */       grp = "".equals(grp) ? grp : ("_" + grp);
/* 324 */       String str17 = "Button" + grp + ".background";
/* 325 */       String str18 = "Button" + grp + ".background2";
/* 326 */       String str19 = "Button" + grp + ".bgrollover";
/* 327 */       String str20 = "Button" + grp + ".bgrollover2";
/* 328 */       String bordercolor = "Button" + grp + ".bordercolor";
/* 329 */       String bordercolor2 = "Button" + grp + ".bordercolor2";
/* 330 */       String borderrollover = "Button" + grp + ".borderrollover";
/* 331 */       String borderrollover2 = "Button" + grp + ".borderrollover2";
/* 332 */       if ("".equals(grp)) {
/* 333 */         bg2 = table.getColor(str17);
/* 334 */         rocolor = null;
/* 335 */         rocolor2 = null;
/* 336 */         bcolor = bg2;
/* 337 */         bcolor2 = bg2;
/* 338 */         sbrocolor = null;
/* 339 */         sbrocolor2 = null;
/*     */       } 
/* 341 */       Object[] arrayOfObject = { 
/* 342 */           str18, MCConst.beans.getColor("button" + grp + ".bg2", bg2), 
/* 343 */           str19, 
/* 344 */           MCConst.beans.getColor("button" + grp + ".rollover", rocolor), 
/* 345 */           str20, 
/* 346 */           MCConst.beans.getColor("button" + grp + ".rollover2", rocolor2), 
/* 347 */           bordercolor, 
/* 348 */           MCConst.beans.getColor("button" + grp + ".border.color", bcolor), 
/* 349 */           bordercolor2, 
/* 350 */           MCConst.beans.getColor("button" + grp + ".border.color2", 
/* 351 */             bcolor2), 
/* 352 */           borderrollover, 
/* 353 */           MCConst.beans.getColor("button" + grp + ".border.rollover", 
/* 354 */             sbrocolor), 
/* 355 */           borderrollover2, MCConst.beans.getColor(
/* 356 */             "button" + grp + ".border.rollover2", sbrocolor2) };
/*     */       
/* 358 */       table.putDefaults(arrayOfObject);
/*     */       
/* 360 */       if ("".equals(grp)) {
/* 361 */         bg2 = table.getColor(str18);
/* 362 */         bcolor = table.getColor(bordercolor);
/* 363 */         bcolor2 = table.getColor(bordercolor2);
/* 364 */         sbrocolor = table.getColor(borderrollover);
/* 365 */         sbrocolor2 = table.getColor(borderrollover2);
/*     */       }  b++; }
/*     */     
/* 368 */     Object[] arrayOfObject7 = {
/* 369 */         "Button.border", new MCButtonLineBorder(2, false, false)
/*     */       };
/* 371 */     table.putDefaults(arrayOfObject7);
/*     */ 
/*     */     
/* 374 */     Object[] o = {
/* 375 */         "RadioButton.icon", MCConst.beans.getIcon("icon.RADIO"), 
/* 376 */         "RadioButton.icon_dot", MCConst.beans.getIcon("icon.RADIO_DOT")
/*     */       };
/* 378 */     table.putDefaults(o);
/*     */ 
/*     */     
/* 381 */     o = new Object[] {
/* 382 */         "ImageView.border", new MCFieldBorder()
/*     */       };
/* 384 */     table.putDefaults(o);
/*     */ 
/*     */     
/* 387 */     String str1 = "TableHeader.background";
/* 388 */     String background2 = "TableHeader.background2";
/* 389 */     String bdr = "TableHeader.cellBorder";
/* 390 */     Object[] arrayOfObject4 = {
/* 391 */         str1, 
/* 392 */         MCConst.beans.getColor("table.header.bg", table.getColor(str1)), 
/* 393 */         bdr, new MCTableHeaderBorder()
/*     */       };
/* 395 */     table.putDefaults(arrayOfObject4);
/* 396 */     Object[] o2 = {
/* 397 */         background2, 
/* 398 */         MCConst.beans.getColor("table.header.bg2", table.getColor(str1))
/*     */       };
/* 400 */     table.putDefaults(o2);
/*     */ 
/*     */     
/* 403 */     str1 = "Panel.background";
/* 404 */     String tmpbg = "TmpPanel.background";
/* 405 */     String tmpborder = "TmpPanel.bordercolor";
/* 406 */     arrayOfObject4 = new Object[] {
/* 407 */         str1, 
/* 408 */         MCConst.beans.getColor("panel.bg", table.getColor(str1)), tmpbg, 
/* 409 */         MCConst.beans.getColor("panel.layouter.rootsub.bg"), tmpborder, 
/* 410 */         MCConst.beans.getColor("panel.layouter.rootsub.border.color")
/*     */       };
/* 412 */     table.putDefaults(arrayOfObject4);
/*     */ 
/*     */     
/* 415 */     str1 = "SplitPane.background";
/* 416 */     String highlight = "SplitPane.highlight";
/* 417 */     String str8 = "SplitPane.darkShadow";
/*     */     
/* 419 */     String arrowColor = "SplitPane.arrowColor";
/* 420 */     String centerVArrow = "SplitPane.centerVArrow";
/* 421 */     String centerHArrow = "SplitPane.centerHArrow";
/* 422 */     String btnopaque = "SplitPane.oneTouchButtonsOpaque";
/* 423 */     String str13 = "SplitPane.border";
/* 424 */     String divopaque = "SplitPaneDivider.opaque";
/* 425 */     String divcolor = "SplitPaneDivider.color";
/*     */     
/* 427 */     Object[] arrayOfObject11 = { 
/* 428 */         btnopaque, Boolean.valueOf(MCConst.beans.getBoolean("splitpane.btn.opaque", false)), 
/* 429 */         str1, 
/* 430 */         MCConst.beans.getColor("splitpane.bg", table.getColor(str1)), 
/* 431 */         highlight, 
/* 432 */         MCConst.beans.getColor("splitpane.highlight", 
/* 433 */           table.getColor(highlight)), 
/* 434 */         str8, 
/* 435 */         MCConst.beans.getColor("splitpane.darkshadow", 
/* 436 */           table.getColor(str8)), 
/*     */         
/* 438 */         arrowColor, 
/* 439 */         MCConst.beans.getColor("splitpane.arrowcolor", Color.gray), 
/* 440 */         centerVArrow, 
/* 441 */         Boolean.valueOf(MCConst.beans.getBoolean("splitpane.centervarrow", Boolean.FALSE.booleanValue())), 
/* 442 */         centerHArrow, 
/* 443 */         Boolean.valueOf(MCConst.beans.getBoolean("splitpane.centerharrow", Boolean.FALSE.booleanValue())), 
/* 444 */         str13, BorderFactory.createEmptyBorder(), divcolor, 
/* 445 */         MCConst.beans.getColor("splitpane.divider.bg", null), divopaque, 
/* 446 */         Boolean.valueOf(MCConst.beans.getBoolean("splitpane.divider.opaque")) };
/*     */ 
/*     */     
/* 449 */     table.putDefaults(arrayOfObject11);
/*     */ 
/*     */     
/* 452 */     str1 = "ToolTip.background";
/* 453 */     String foreground = "ToolTip.foreground";
/* 454 */     Object[] arrayOfObject2 = {
/* 455 */         str1, 
/* 456 */         MCConst.beans.getColor("tooltip.bg", table.getColor(str1)), 
/* 457 */         foreground, 
/* 458 */         MCConst.beans.getColor("tooltip.fg", table.getColor(foreground))
/*     */       };
/* 460 */     table.putDefaults(arrayOfObject2);
/*     */ 
/*     */     
/* 463 */     String scrollPaneBorder = "Table.scrollPaneBorder";
/* 464 */     String gridColor = "Table.gridColor";
/* 465 */     arrayOfObject2 = new Object[] {
/* 466 */         scrollPaneBorder, BorderFactory.createEmptyBorder(), gridColor, 
/* 467 */         MCConst.beans.getColor("table.gridcolor", table.getColor(gridColor))
/*     */       };
/* 469 */     table.putDefaults(arrayOfObject2);
/*     */ 
/*     */     
/* 472 */     String background = "ScrollPane.background";
/* 473 */     String str3 = "ScrollPane.border";
/* 474 */     arrayOfObject2 = new Object[] {
/* 475 */         background, MCConst.beans.getColor("scrollpane.bg", Color.white), 
/* 476 */         str3, BorderFactory.createEmptyBorder()
/*     */       };
/* 478 */     table.putDefaults(arrayOfObject2);
/*     */ 
/*     */     
/* 481 */     background = "Viewport.background";
/* 482 */     Object[] arrayOfObject1 = {
/* 483 */         background, MCConst.beans.getColor("viewport.bg", Color.white)
/*     */       };
/* 485 */     table.putDefaults(arrayOfObject1);
/*     */ 
/*     */     
/* 488 */     String textBorder = "TextField.border";
/* 489 */     String passBorder = "PasswordField.border";
/* 490 */     String formBorder = "FormattedTextField.border";
/* 491 */     String spnrBorder = "Spinner.border";
/* 492 */     String areaBorder = "TextArea.border";
/*     */     
/* 494 */     MCFieldBorder mCFieldBorder = new MCFieldBorder();
/* 495 */     Object[] arrayOfObject5 = {
/* 496 */         textBorder, mCFieldBorder, passBorder, mCFieldBorder, formBorder, mCFieldBorder, spnrBorder, mCFieldBorder, 
/* 497 */         areaBorder, mCFieldBorder
/*     */       };
/*     */     
/* 500 */     table.putDefaults(arrayOfObject5);
/*     */ 
/*     */     
/* 503 */     Font f = MCConst.beans.getFont("font");
/* 504 */     if (f != null) {
/* 505 */       Object[] arrayOfObject = {
/* 506 */           "InternalFrame.titleFont", f
/*     */         };
/* 508 */       table.putDefaults(arrayOfObject);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static Insets getInsets(String key, Insets def) {
/* 514 */     String[] v = MCConst.beans.getStringArray(key);
/* 515 */     if (v != null && v.length == 4) {
/*     */       try {
/* 517 */         int top = Integer.parseInt(v[0]);
/* 518 */         int left = Integer.parseInt(v[1]);
/* 519 */         int bottom = Integer.parseInt(v[2]);
/* 520 */         int right = Integer.parseInt(v[3]);
/* 521 */         return new InsetsUIResource(top, left, bottom, right);
/*     */       }
/* 523 */       catch (RuntimeException runtimeException) {}
/*     */     }
/*     */     
/* 526 */     return def;
/*     */   }
/*     */   
/*     */   private List getGradient(String key, List<Float> def) {
/* 530 */     MCNumber fn1 = MCConst.beans.getNumber(String.valueOf(key) + "f1");
/* 531 */     MCNumber fn2 = MCConst.beans.getNumber(String.valueOf(key) + "f2");
/* 532 */     Color cn1 = MCConst.beans.getColor(String.valueOf(key) + "1");
/* 533 */     Color cn2 = MCConst.beans.getColor(String.valueOf(key) + "2");
/* 534 */     Color cn3 = MCConst.beans.getColor(String.valueOf(key) + "3");
/*     */     
/* 536 */     if (fn1 == null && fn2 == null && cn1 == null && cn2 == null && cn3 == null) {
/* 537 */       return def;
/*     */     }
/*     */     
/* 540 */     Float f1 = Float.valueOf((fn1 == null) ? ((Float)def.get(0)).floatValue() : fn1.floatValue());
/* 541 */     Float f2 = Float.valueOf((fn2 == null) ? ((Float)def.get(1)).floatValue() : fn2.floatValue());
/* 542 */     Color c1 = (cn1 == null) ? (Color)def.get(3) : new ColorUIResource(cn1);
/* 543 */     Color c2 = (cn2 == null) ? (Color)def.get(4) : new ColorUIResource(cn2);
/* 544 */     Color c3 = (cn3 == null) ? (Color)def.get(5) : new ColorUIResource(cn3);
/*     */     
/* 546 */     return Arrays.asList(new Object[] {
/* 547 */           f1, f2, c1, c2, c3
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\plaf\metal\MCTheme.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */