/*    */ package mcframe.clientCore.beans.plaf.metal;
/*    */ 
/*    */ import java.awt.Container;
/*    */ import java.awt.Dimension;
/*    */ import javax.swing.plaf.metal.MetalScrollButton;
/*    */ import mcframe.clientCore.beans.MCBeans;
/*    */ import mcframe.clientCore.beans.MCFrame;
/*    */ import mcframe.clientCore.beans.MCRootPanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCMetalScrollButton
/*    */   extends MetalScrollButton
/*    */ {
/*    */   MCMetalScrollButton(int direction, int width, boolean freeStanding) {
/* 18 */     super(direction, width, freeStanding);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private int getFontRatio() {
/* 24 */     MCRootPanel rp = null;
/* 25 */     Container c = getParent();
/* 26 */     while (c != null) {
/* 27 */       if (c instanceof MCBeans) {
/* 28 */         rp = ((MCBeans)c).getBaseRootPanel();
/*    */         break;
/*    */       } 
/* 31 */       if (c instanceof MCFrame) {
/* 32 */         rp = ((MCFrame)c).getRootPanel();
/*    */         
/*    */         break;
/*    */       } 
/* 36 */       c = c.getParent();
/*    */     } 
/* 38 */     if (rp == null) {
/* 39 */       return 100;
/*    */     }
/* 41 */     return rp.getFontRatio();
/*    */   }
/*    */ 
/*    */   
/*    */   public Dimension getPreferredSize() {
/* 46 */     Dimension d = super.getPreferredSize();
/*    */ 
/*    */     
/* 49 */     int ratio = getFontRatio();
/* 50 */     if (ratio != 100) {
/* 51 */       d = new Dimension(d.width * ratio / 100, d.height * ratio / 100);
/*    */     }
/*    */     
/* 54 */     return d;
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\plaf\metal\MCMetalScrollButton.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */