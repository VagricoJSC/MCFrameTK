/*     */ package mcframe.clientCore.beans.plaf.metal;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Rectangle;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.ButtonModel;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.metal.MetalCheckBoxUI;
/*     */ import javax.swing.plaf.metal.MetalLookAndFeel;
/*     */ import javax.swing.text.View;
/*     */ import mcframe.clientCore.beans.MCCheckBox;
/*     */ import mcframe.clientCore.beans.MCModeBeans;
/*     */ import sun.swing.SwingUtilities2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MCMetalCheckBoxUI
/*     */   extends MetalCheckBoxUI
/*     */ {
/*  43 */   private JCheckBox _compo = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ComponentUI createUI(JComponent compo) {
/*  63 */     MCMetalCheckBoxUI ui = new MCMetalCheckBoxUI();
/*  64 */     if (compo instanceof JCheckBox) {
/*  65 */       JCheckBox c = (JCheckBox)compo;
/*  66 */       ui.setCheckBox(c);
/*     */     } 
/*  68 */     return ui;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setCheckBox(JCheckBox compo) {
/*  79 */     this._compo = compo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JCheckBox getCheckBox() {
/*  90 */     return this._compo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Color getPressedIconColor() {
/* 101 */     return MetalLookAndFeel.getControlShadow();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Color getBorderColor() {
/* 112 */     return getCheckBox().isEnabled() ? MetalLookAndFeel.getControlDarkShadow() : 
/* 113 */       MetalLookAndFeel.getControlShadow();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Color getIconColor() {
/* 124 */     return getCheckBox().getBackground();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Color getCheckColor() {
/* 135 */     return getCheckBox().getForeground();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Color getInactiveIconColor() {
/* 146 */     return getCheckBox().getForeground();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Color getDisabledTextColor() {
/* 158 */     JCheckBox c = getCheckBox();
/* 159 */     if (c instanceof MCModeBeans) {
/* 160 */       return ((MCModeBeans)c).getModeInfo().getLabelForeground();
/*     */     }
/* 162 */     return super.getDisabledTextColor();
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void paint(Graphics g, JComponent c) {
/* 167 */     JCheckBox compo = (JCheckBox)c;
/* 168 */     ButtonModel model = compo.getModel();
/* 169 */     Dimension size = c.getSize();
/* 170 */     Font font = c.getFont();
/* 171 */     g.setFont(font);
/* 172 */     FontMetrics fm = SwingUtilities2.getFontMetrics(c, g, font);
/*     */ 
/*     */     
/* 175 */     Rectangle viewRect = new Rectangle(size);
/* 176 */     Rectangle iconRect = new Rectangle();
/* 177 */     Rectangle textRect = new Rectangle();
/*     */     
/* 179 */     Insets i = c.getInsets();
/* 180 */     viewRect.x += i.left;
/* 181 */     viewRect.y += i.top;
/* 182 */     viewRect.width -= i.right + viewRect.x;
/* 183 */     viewRect.height -= i.bottom + viewRect.y;
/*     */     
/* 185 */     Icon altIcon = compo.getIcon();
/* 186 */     String text = SwingUtilities.layoutCompoundLabel(c, fm, compo.getText(), 
/* 187 */         (altIcon != null) ? altIcon : getDefaultIcon(), 
/* 188 */         compo.getVerticalAlignment(), compo.getHorizontalAlignment(), 
/* 189 */         compo.getVerticalTextPosition(), compo.getHorizontalTextPosition(), 
/* 190 */         viewRect, iconRect, textRect, compo.getIconTextGap());
/*     */ 
/*     */     
/* 193 */     if (c.isOpaque()) {
/* 194 */       g.setColor(compo.getBackground());
/* 195 */       g.fillRect(0, 0, size.width, size.height);
/*     */     } 
/*     */ 
/*     */     
/* 199 */     if (altIcon != null) {
/* 200 */       if (!model.isEnabled()) {
/* 201 */         if (model.isSelected()) {
/* 202 */           altIcon = compo.getDisabledSelectedIcon();
/*     */         } else {
/*     */           
/* 205 */           altIcon = compo.getDisabledIcon();
/*     */         }
/*     */       
/* 208 */       } else if (model.isPressed() && model.isArmed()) {
/* 209 */         altIcon = compo.getPressedIcon();
/* 210 */         if (altIcon == null)
/*     */         {
/* 212 */           altIcon = compo.getSelectedIcon();
/*     */         }
/*     */       }
/* 215 */       else if (model.isSelected()) {
/* 216 */         if (compo.isRolloverEnabled() && model.isRollover()) {
/* 217 */           altIcon = compo.getRolloverSelectedIcon();
/* 218 */           if (altIcon == null) {
/* 219 */             altIcon = compo.getSelectedIcon();
/*     */           }
/*     */         } else {
/*     */           
/* 223 */           altIcon = compo.getSelectedIcon();
/*     */         }
/*     */       
/* 226 */       } else if (compo.isRolloverEnabled() && model.isRollover()) {
/* 227 */         altIcon = compo.getRolloverIcon();
/*     */       } 
/*     */       
/* 230 */       if (altIcon == null) {
/* 231 */         altIcon = compo.getIcon();
/*     */       }
/*     */       
/* 234 */       altIcon.paintIcon(c, g, iconRect.x, iconRect.y);
/*     */     }
/*     */     else {
/*     */       
/* 238 */       getDefaultIcon().paintIcon(c, g, iconRect.x, iconRect.y);
/*     */     } 
/*     */ 
/*     */     
/* 242 */     if (text != null) {
/*     */       Color color;
/* 244 */       if (compo instanceof MCCheckBox) {
/* 245 */         color = ((MCCheckBox)compo).getModeInfo().getLabelForeground();
/*     */       } else {
/*     */         
/* 248 */         color = compo.getForeground();
/*     */       } 
/* 250 */       View v = (View)c.getClientProperty("html");
/* 251 */       if (v != null) {
/* 252 */         Color tmp = UIManager.getColor("textInactiveText");
/*     */         try {
/* 254 */           UIManager.put("textInactiveText", color);
/* 255 */           v.paint(g, textRect);
/*     */         } finally {
/*     */           
/* 258 */           UIManager.put("textInactiveText", tmp);
/*     */         } 
/*     */       } else {
/*     */         
/* 262 */         int mnemIndex = compo.getDisplayedMnemonicIndex();
/* 263 */         g.setColor(color);
/* 264 */         SwingUtilities2.drawStringUnderlineCharAt(c, g, text, mnemIndex, 
/* 265 */             textRect.x, textRect.y + fm.getAscent());
/*     */       } 
/*     */ 
/*     */       
/* 269 */       if (compo.hasFocus() && compo.isFocusPainted() && textRect.width > 0 && 
/* 270 */         textRect.height > 0) {
/* 271 */         paintFocus(g, textRect, size);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void installDefaults(AbstractButton b) {
/* 278 */     super.installDefaults(b);
/* 279 */     this.icon = new MCMetalCheckBoxIcon((JCheckBox)b);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\plaf\metal\MCMetalCheckBoxUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */