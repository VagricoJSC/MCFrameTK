/*     */ package mcframe.clientCore.beans.plaf.metal;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.KeyListener;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.ButtonModel;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JRadioButton;
/*     */ import javax.swing.KeyStroke;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.metal.MetalLookAndFeel;
/*     */ import javax.swing.plaf.metal.MetalRadioButtonUI;
/*     */ import javax.swing.text.View;
/*     */ import mcframe.clientCore.beans.MCRadioButton;
/*     */ import sun.swing.SwingUtilities2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCMetalRadioButtonUI
/*     */   extends MetalRadioButtonUI
/*     */ {
/*  44 */   private JRadioButton _compo = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ComponentUI createUI(JComponent compo) {
/*  64 */     MCMetalRadioButtonUI ui = new MCMetalRadioButtonUI();
/*  65 */     if (compo instanceof JRadioButton) {
/*  66 */       JRadioButton radio = (JRadioButton)compo;
/*  67 */       ui.setRadioButton(radio);
/*  68 */       if (radio instanceof MCRadioButton) {
/*  69 */         ((MCRadioButton)radio)
/*  70 */           .setIcon(new MCMetalRadioButtonIcon((MCRadioButton)radio));
/*     */       }
/*     */     } 
/*  73 */     return ui;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setRadioButton(JRadioButton compo) {
/*  84 */     this._compo = compo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JRadioButton getRadioButton() {
/*  95 */     return this._compo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Color getBorderColor() {
/* 106 */     return getRadioButton().isEnabled() ? MetalLookAndFeel.getControlDarkShadow() : 
/* 107 */       MetalLookAndFeel.getControlShadow();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Color getIconColor() {
/* 118 */     return getRadioButton().getBackground();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Color getDotColor() {
/* 129 */     return getRadioButton().getForeground();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Color getPressedIconColor() {
/* 140 */     return MetalLookAndFeel.getControlShadow();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Color getInactiveIconColor1() {
/* 152 */     return new Color(215, 215, 215);
/*     */   }
/*     */   
/*     */   Color getInactiveIconColor2() {
/* 156 */     return new Color(180, 180, 180);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Color getDisabledTextColor() {
/* 168 */     JRadioButton compo = getRadioButton();
/* 169 */     if (compo instanceof MCRadioButton) {
/* 170 */       return ((MCRadioButton)compo).getModeInfo().getLabelForeground();
/*     */     }
/* 172 */     return compo.getForeground();
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void paint(Graphics g, JComponent c) {
/* 177 */     JRadioButton compo = (JRadioButton)c;
/* 178 */     ButtonModel model = compo.getModel();
/* 179 */     Dimension size = c.getSize();
/* 180 */     Font font = c.getFont();
/* 181 */     g.setFont(font);
/* 182 */     FontMetrics fm = SwingUtilities2.getFontMetrics(c, g, font);
/*     */ 
/*     */     
/* 185 */     Rectangle viewRect = new Rectangle(size);
/* 186 */     Rectangle iconRect = new Rectangle();
/* 187 */     Rectangle textRect = new Rectangle();
/*     */     
/* 189 */     Insets i = c.getInsets();
/* 190 */     viewRect.x += i.left;
/* 191 */     viewRect.y += i.top;
/* 192 */     viewRect.width -= i.right + viewRect.x;
/* 193 */     viewRect.height -= i.bottom + viewRect.y;
/*     */     
/* 195 */     Icon altIcon = compo.getIcon();
/* 196 */     String text = SwingUtilities.layoutCompoundLabel(c, fm, compo.getText(), 
/* 197 */         (altIcon != null) ? altIcon : getDefaultIcon(), 
/* 198 */         compo.getVerticalAlignment(), compo.getHorizontalAlignment(), 
/* 199 */         compo.getVerticalTextPosition(), compo.getHorizontalTextPosition(), 
/* 200 */         viewRect, iconRect, textRect, compo.getIconTextGap());
/*     */ 
/*     */     
/* 203 */     if (c.isOpaque()) {
/* 204 */       g.setColor(compo.getBackground());
/* 205 */       g.fillRect(0, 0, size.width, size.height);
/*     */     } 
/*     */ 
/*     */     
/* 209 */     if (altIcon != null) {
/* 210 */       if (!model.isEnabled()) {
/* 211 */         if (model.isSelected()) {
/* 212 */           altIcon = compo.getDisabledSelectedIcon();
/*     */         } else {
/*     */           
/* 215 */           altIcon = compo.getDisabledIcon();
/*     */         }
/*     */       
/* 218 */       } else if (model.isPressed() && model.isArmed()) {
/* 219 */         altIcon = compo.getPressedIcon();
/* 220 */         if (altIcon == null)
/*     */         {
/* 222 */           altIcon = compo.getSelectedIcon();
/*     */         }
/*     */       }
/* 225 */       else if (model.isSelected()) {
/* 226 */         if (compo.isRolloverEnabled() && model.isRollover()) {
/* 227 */           altIcon = compo.getRolloverSelectedIcon();
/* 228 */           if (altIcon == null) {
/* 229 */             altIcon = compo.getSelectedIcon();
/*     */           }
/*     */         } else {
/*     */           
/* 233 */           altIcon = compo.getSelectedIcon();
/*     */         }
/*     */       
/* 236 */       } else if (compo.isRolloverEnabled() && model.isRollover()) {
/* 237 */         altIcon = compo.getRolloverIcon();
/*     */       } 
/*     */       
/* 240 */       if (altIcon == null) {
/* 241 */         altIcon = compo.getIcon();
/*     */       }
/*     */       
/* 244 */       altIcon.paintIcon(c, g, iconRect.x, iconRect.y);
/*     */     }
/*     */     else {
/*     */       
/* 248 */       getDefaultIcon().paintIcon(c, g, iconRect.x, iconRect.y);
/*     */     } 
/*     */ 
/*     */     
/* 252 */     if (text != null) {
/* 253 */       Color color; View v = (View)c.getClientProperty("html");
/*     */       
/* 255 */       if (compo instanceof MCRadioButton) {
/* 256 */         color = ((MCRadioButton)compo).getModeInfo().getLabelForeground();
/*     */       } else {
/*     */         
/* 259 */         color = compo.getForeground();
/*     */       } 
/* 261 */       if (v != null) {
/* 262 */         Color tmp = UIManager.getColor("textInactiveText");
/*     */         try {
/* 264 */           UIManager.put("textInactiveText", color);
/* 265 */           v.paint(g, textRect);
/*     */         } finally {
/*     */           
/* 268 */           UIManager.put("textInactiveText", tmp);
/*     */         } 
/*     */       } else {
/*     */         
/* 272 */         int mnemIndex = compo.getDisplayedMnemonicIndex();
/* 273 */         g.setColor(color);
/* 274 */         SwingUtilities2.drawStringUnderlineCharAt(c, g, text, mnemIndex, 
/* 275 */             textRect.x, textRect.y + fm.getAscent());
/*     */       } 
/*     */ 
/*     */       
/* 279 */       if (compo.hasFocus() && compo.isFocusPainted() && textRect.width > 0 && 
/* 280 */         textRect.height > 0) {
/* 281 */         paintFocus(g, textRect, size);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void installListeners(AbstractButton button) {
/* 288 */     super.installListeners(button);
/*     */ 
/*     */     
/* 291 */     button.getActionMap().remove("Previous");
/* 292 */     button.getActionMap().remove("Next");
/*     */     
/* 294 */     button.getInputMap(1)
/* 295 */       .remove(KeyStroke.getKeyStroke("UP"));
/* 296 */     button.getInputMap(1)
/* 297 */       .remove(KeyStroke.getKeyStroke("DOWN"));
/* 298 */     button.getInputMap(1)
/* 299 */       .remove(KeyStroke.getKeyStroke("LEFT"));
/* 300 */     button.getInputMap(1)
/* 301 */       .remove(KeyStroke.getKeyStroke("RIGHT"));
/*     */     
/* 303 */     button.setFocusTraversalKeysEnabled(true);
/*     */     
/* 305 */     KeyListener[] a = button.getKeyListeners(); byte b; int i; KeyListener[] arrayOfKeyListener1;
/* 306 */     for (i = (arrayOfKeyListener1 = a).length, b = 0; b < i; ) { KeyListener l = arrayOfKeyListener1[b];
/* 307 */       Class<?> c = l.getClass();
/* 308 */       String n = c.getName();
/* 309 */       if (n.equals("javax.swing.plaf.basic.BasicRadioButtonUI$KeyHandler"))
/* 310 */         button.removeKeyListener(l); 
/*     */       b++; }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\plaf\metal\MCMetalRadioButtonUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */