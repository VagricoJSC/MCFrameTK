/*     */ package mcframe.clientCore.beans.plaf.metal;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import javax.swing.ButtonModel;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ButtonUI;
/*     */ import javax.swing.plaf.metal.MetalCheckBoxIcon;
/*     */ import mcframe.clientCore.beans.MCCheckBox;
/*     */ import mcframe.clientCore.beans.table.MCCellRendererCheckBox;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MCMetalCheckBoxIcon
/*     */   extends MetalCheckBoxIcon
/*     */ {
/*  30 */   private JCheckBox _compo = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCMetalCheckBoxIcon(JCheckBox compo) {
/*  40 */     this._compo = compo;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final void paintIcon(Component c, Graphics g, int x, int y) {
/*  46 */     JCheckBox cb = (JCheckBox)c;
/*  47 */     ButtonModel model = cb.getModel();
/*  48 */     int controlSize = getControlSize();
/*     */     
/*  50 */     boolean drawCheck = model.isSelected();
/*     */     
/*  52 */     ButtonUI bui = cb.getUI();
/*     */ 
/*     */     
/*  55 */     if (UIManager.getLookAndFeel() instanceof javax.swing.plaf.synth.SynthLookAndFeel) {
/*     */       return;
/*     */     }
/*  58 */     MCMetalCheckBoxUI ui = (MCMetalCheckBoxUI)bui;
/*     */ 
/*     */     
/*  61 */     if (model.isEnabled()) {
/*     */       
/*  63 */       if (model.isPressed() && model.isArmed()) {
/*  64 */         g.setColor(ui.getPressedIconColor());
/*  65 */         g.fillRect(x, y, controlSize - 1, controlSize - 1);
/*     */       } else {
/*     */         
/*  68 */         drawFlush3DBorder(cb, ui, g, x, y, controlSize, controlSize);
/*     */       } 
/*     */       
/*  71 */       g.setColor(ui.getCheckColor());
/*     */     } else {
/*     */       
/*  74 */       g.setColor(ui.getInactiveIconColor());
/*  75 */       g.drawRect(x, y, controlSize - 1, controlSize - 1);
/*     */       
/*  77 */       drawFlush3DBorder(cb, ui, g, x, y, controlSize, controlSize);
/*     */       
/*  79 */       g.setColor(ui.getCheckColor());
/*     */     } 
/*     */     
/*  82 */     if (drawCheck) {
/*  83 */       int xx = x;
/*  84 */       if (cb.isBorderPaintedFlat()) {
/*  85 */         xx++;
/*     */       }
/*  87 */       drawCheck(c, g, xx, y);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void drawFlush3DBorder(JCheckBox check, MCMetalCheckBoxUI checkBoxUI, Graphics g, int x, int y, int w, int h) {
/*  93 */     g.translate(x, y);
/*     */     
/*  95 */     g.setColor(checkBoxUI.getBorderColor());
/*  96 */     g.drawRect(0, 0, w - 1, h - 1);
/*     */     
/*  98 */     g.setColor(checkBoxUI.getIconColor());
/*  99 */     g.fillRect(1, 1, w - 2, h - 2);
/* 100 */     g.translate(-x, -y);
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getControlSize() {
/* 105 */     int i = super.getControlSize();
/*     */     
/* 107 */     if (this._compo != null) {
/* 108 */       if (this._compo instanceof MCCheckBox) {
/* 109 */         i = i * ((MCCheckBox)this._compo).getRatio() / 100;
/*     */       }
/* 111 */       else if (this._compo instanceof MCCellRendererCheckBox) {
/* 112 */         i = i * ((MCCellRendererCheckBox)this._compo).getRatio() / 100;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 117 */     return i;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\plaf\metal\MCMetalCheckBoxIcon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */