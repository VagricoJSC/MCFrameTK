/*     */ package mcframe.clientCore.beans.plaf.metal;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.Paint;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.util.HashSet;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JTabbedPane;
/*     */ import javax.swing.JViewport;
/*     */ import javax.swing.SwingConstants;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.UIResource;
/*     */ import javax.swing.plaf.basic.BasicArrowButton;
/*     */ import javax.swing.plaf.metal.MetalTabbedPaneUI;
/*     */ import javax.swing.text.View;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCPanel;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.MCTabbedPane;
/*     */ import mcframe.clientCore.beans.mouse.MCScrollSupport;
/*     */ import mcframe.clientCore.beans.plaf.MCGraphicsUtil;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ import sun.swing.SwingUtilities2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCMetalTabbedPaneUI
/*     */   extends MetalTabbedPaneUI
/*     */ {
/*     */   protected Color selectedIndicator;
/*     */   private JViewport _viewPort;
/*     */   private MCScrollSupport _sp;
/*  52 */   private static final ImageIcon _rightIcon = MCBeansUtil.getIcon(MCConst.beans.getString("icon.MENU_RIGHT"));
/*     */ 
/*     */   
/*  55 */   private static final boolean _rev_sel_icon = MCConst.beans.getBoolean("tabbedpane.left.rev_sel_icon");
/*     */   
/*     */   public static ComponentUI createUI(JComponent c) {
/*  58 */     return new MCMetalTabbedPaneUI();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int calculateMaxTabWidth(int tabPlacement) {
/*  64 */     return super.calculateMaxTabWidth(tabPlacement);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setRolloverTab(int index) {
/*  70 */     int oldRolloverTab = getRolloverTab();
/*  71 */     super.setRolloverTab(index);
/*     */     
/*  73 */     Rectangle r = null;
/*     */     
/*  75 */     if (oldRolloverTab != index) {
/*  76 */       this.tabPane.repaint();
/*     */     } else {
/*     */       
/*  79 */       if (oldRolloverTab >= 0 && oldRolloverTab < this.tabPane.getTabCount()) {
/*  80 */         r = getTabBounds(this.tabPane, oldRolloverTab);
/*  81 */         if (r != null) {
/*  82 */           this.tabPane.repaint(r);
/*     */         }
/*     */       } 
/*     */       
/*  86 */       if (index >= 0) {
/*  87 */         r = getTabBounds(this.tabPane, index);
/*  88 */         if (r != null) {
/*  89 */           this.tabPane.repaint(r);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintFocusIndicator(Graphics g, int tabPlacement, Rectangle[] rects, int tabIndex, Rectangle iconRect, Rectangle textRect, boolean isSelected) {
/*  98 */     if (this.tabPane.hasFocus() && isSelected) {
/*     */       
/* 100 */       Rectangle tabRect = rects[tabIndex].getBounds();
/* 101 */       Graphics2D g2 = (Graphics2D)g;
/* 102 */       g.setColor(this.focus);
/* 103 */       paintUnderLine(g2, tabPlacement, tabIndex, tabRect.x, tabRect.y, 
/* 104 */           tabRect.width, tabRect.height - 4, isSelected, 2);
/* 105 */       int x = tabRect.x;
/* 106 */       int y = tabRect.y;
/* 107 */       int w = tabRect.width;
/* 108 */       int h = tabRect.height;
/*     */       
/* 110 */       switch (tabPlacement) {
/*     */         case 2:
/*     */         case 4:
/* 113 */           paintTabFocusIndicator(tabIndex, g2, x, y, w, h, isSelected);
/*     */           return;
/*     */       } 
/*     */ 
/*     */       
/* 118 */       paintUnderLine(g2, tabPlacement, tabIndex, x, y, w, h, isSelected, 3);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void paintTabFocusIndicator(int tabIndex, Graphics g, int x, int y, int w, int h, boolean isSelected) {
/* 126 */     int tabCount = this.tabPane.getTabCount();
/* 127 */     int currentRun = getRunForTab(tabCount, tabIndex);
/* 128 */     lastTabInRun(tabCount, currentRun);
/*     */     
/* 130 */     if (this.tabPane.hasFocus() && isSelected) {
/* 131 */       int fi = 5;
/* 132 */       int xx = x + w - fi;
/* 133 */       g.translate(xx, y);
/* 134 */       int bottom = h - 1;
/* 135 */       g.setColor(this.focus);
/* 136 */       g.fillRect(0, 0, fi, bottom);
/* 137 */       g.translate(-xx, -y);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void layoutLabel(int tabPlacement, FontMetrics metrics, int tabIndex, String title, Icon icon, Rectangle tabRect, Rectangle iconRect, Rectangle textRect, boolean isSelected) {
/* 145 */     textRect.x = textRect.y = iconRect.x = iconRect.y = 0;
/*     */     
/* 147 */     View v = getTextViewForTab(tabIndex);
/* 148 */     if (v != null) {
/* 149 */       this.tabPane.putClientProperty("html", v);
/*     */     }
/*     */     
/* 152 */     int ha = 0;
/* 153 */     if (tabPlacement == 2) {
/* 154 */       ha = 10;
/*     */     }
/* 156 */     SwingUtilities.layoutCompoundLabel(this.tabPane, metrics, title, icon, 
/* 157 */         0, ha, 0, 11, 
/* 158 */         tabRect, iconRect, textRect, this.textIconGap);
/*     */     
/* 160 */     this.tabPane.putClientProperty("html", (Object)null);
/*     */     
/* 162 */     int xNudge = getTabLabelShiftX(tabPlacement, tabIndex, isSelected);
/* 163 */     int yNudge = getTabLabelShiftY(tabPlacement, tabIndex, isSelected);
/* 164 */     iconRect.x += xNudge;
/* 165 */     iconRect.y += yNudge;
/* 166 */     textRect.x += xNudge;
/* 167 */     textRect.y += yNudge;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintText(Graphics g, int tabPlacement, Font font, FontMetrics metrics, int tabIndex, String title, Rectangle textRect, boolean isSelected) {
/* 175 */     g.setFont(font);
/*     */     
/* 177 */     View v = getTextViewForTab(tabIndex);
/* 178 */     if (v != null) {
/*     */       
/* 180 */       v.paint(g, textRect);
/*     */     }
/*     */     else {
/*     */       
/* 184 */       int mnemIndex = this.tabPane.getDisplayedMnemonicIndexAt(tabIndex);
/*     */       
/* 186 */       if (this.tabPane.isEnabled() && this.tabPane.isEnabledAt(tabIndex)) {
/* 187 */         Color fg = this.tabPane.getForegroundAt(tabIndex);
/* 188 */         if (isSelected) {
/* 189 */           Color selectedFG = null;
/* 190 */           if (tabPlacement == 2) {
/* 191 */             selectedFG = 
/* 192 */               UIManager.getColor("TabbedPane.leftselectedForeground");
/*     */           } else {
/*     */             
/* 195 */             selectedFG = 
/* 196 */               UIManager.getColor("TabbedPane.selectedForeground");
/*     */           } 
/*     */           
/* 199 */           if (selectedFG != null) {
/* 200 */             fg = selectedFG;
/*     */           }
/*     */         } 
/* 203 */         g.setColor(fg);
/* 204 */         SwingUtilities2.drawStringUnderlineCharAt(this.tabPane, g, title, mnemIndex, 
/* 205 */             textRect.x, textRect.y + metrics.getAscent());
/*     */       } else {
/*     */         
/* 208 */         if (tabPlacement == 2) {
/* 209 */           g.setColor(Color.darkGray);
/*     */         } else {
/*     */           
/* 212 */           g.setColor(this.tabPane.getBackgroundAt(tabIndex).brighter());
/*     */         } 
/*     */         
/* 215 */         SwingUtilities2.drawStringUnderlineCharAt(this.tabPane, g, title, mnemIndex, 
/* 216 */             textRect.x, textRect.y + metrics.getAscent());
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintTabBackground(Graphics g, int tabPlacement, int tabIndex, int x, int y, int w, int h, boolean isSelected) {
/* 230 */     Graphics2D g2 = (Graphics2D)g;
/*     */     
/* 232 */     paintTabBackgroundMetal(g2, tabPlacement, tabIndex, x, y, w, h, isSelected);
/*     */     
/* 234 */     if (isSelected && this.selectedIndicator != null) {
/* 235 */       Paint old = g2.getPaint();
/* 236 */       g.setColor(this.selectedIndicator);
/* 237 */       paintUnderLine(g2, tabPlacement, tabIndex, x, y, w, h, isSelected, 2);
/*     */       
/* 239 */       g2.setPaint(old);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintTabBorder(Graphics g, int tabPlacement, int tabIndex, int x, int y, int w, int h, boolean isSelected) {
/* 246 */     Color tmphl = this.selectHighlight;
/* 247 */     if (this.tabPane.hasFocus() && isSelected) {
/* 248 */       this.selectHighlight = this.focus;
/*     */     }
/*     */     try {
/* 251 */       super.paintTabBorder(g, tabPlacement, tabIndex, x, y, w, h, isSelected);
/*     */     } finally {
/*     */       
/* 254 */       this.selectHighlight = tmphl;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void paintTabBackgroundMetal(Graphics2D g, int tabPlacement, int tabIndex, int x, int y, int w, int h, boolean isSelected) {
/* 261 */     Paint bg = null;
/* 262 */     Color st = null;
/* 263 */     Color ed = null;
/* 264 */     if (isSelected) {
/* 265 */       switch (tabPlacement) {
/*     */         case 2:
/* 267 */           st = UIManager.getColor("TabbedPane.leftselected1");
/* 268 */           ed = UIManager.getColor("TabbedPane.leftselected2");
/*     */           break;
/*     */         
/*     */         default:
/* 272 */           st = this.selectColor;
/* 273 */           ed = UIManager.getColor("TabbedPane.selected2");
/*     */           break;
/*     */       } 
/*     */     
/*     */     } else {
/* 278 */       switch (tabPlacement) {
/*     */         case 2:
/* 280 */           if (getRolloverTab() == tabIndex && this.tabPane.isEnabled() && 
/* 281 */             this.tabPane.isEnabledAt(tabIndex)) {
/* 282 */             st = UIManager.getColor("TabbedPane.leftrollover");
/* 283 */             ed = UIManager.getColor("TabbedPane.leftrollover2");
/*     */             break;
/*     */           } 
/* 286 */           st = UIManager.getColor("TabbedPane.leftbg");
/* 287 */           ed = UIManager.getColor("TabbedPane.leftbg2");
/*     */           break;
/*     */         
/*     */         default:
/* 291 */           if (getRolloverTab() == tabIndex && this.tabPane.isEnabled() && 
/* 292 */             this.tabPane.isEnabledAt(tabIndex)) {
/* 293 */             st = UIManager.getColor("TabbedPane.rollover");
/* 294 */             ed = UIManager.getColor("TabbedPane.rollover2");
/*     */             break;
/*     */           } 
/* 297 */           st = this.tabPane.getBackgroundAt(tabIndex);
/* 298 */           ed = UIManager.getColor("TabbedPane.background2");
/*     */           break;
/*     */       } 
/*     */ 
/*     */     
/*     */     } 
/* 304 */     if (ed == null) {
/* 305 */       ed = st;
/*     */     }
/* 307 */     bg = MCGraphicsUtil.createLinerGradientPaint(h, st, ed);
/*     */     
/* 309 */     g.setPaint(bg);
/* 310 */     switch (tabPlacement) {
/*     */       case 2:
/*     */       case 4:
/* 313 */         h -= 2;
/*     */         break;
/*     */       case 1:
/* 316 */         w -= 2;
/* 317 */         if (!isSelected) {
/* 318 */           h -= 2;
/*     */         }
/*     */         else {
/*     */           
/* 322 */           Paint t = g.getPaint();
/* 323 */           g.setColor(UIManager.getColor("TabbedPane.selectHighlight"));
/* 324 */           g.drawLine(x, y, x + w - 1, y);
/* 325 */           g.setPaint(t);
/*     */         } 
/* 327 */         y++;
/*     */         break;
/*     */       
/*     */       default:
/* 331 */         w -= 2;
/* 332 */         if (!isSelected) {
/* 333 */           h -= 2;
/*     */         }
/*     */         break;
/*     */     } 
/* 337 */     g.fillRect(x, y, w, h);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void paintUnderLine(Graphics g, int tabPlacement, int tabIndex, int x, int y, int w, int h, boolean isSelected, int linewidth) {
/* 355 */     switch (tabPlacement) {
/*     */       case 2:
/*     */       case 4:
/*     */         return;
/*     */     } 
/*     */     
/* 361 */     int m = 9;
/* 362 */     Rectangle tabRect = this.rects[tabIndex].getBounds();
/* 363 */     tabRect.setBounds(tabRect.x + m, tabRect.y, tabRect.width - m - m, 
/* 364 */         tabRect.height - linewidth);
/*     */     
/* 366 */     MCGraphicsUtil.paintLine(g, tabRect, MCGraphicsUtil.Corners.BOTTOM, linewidth);
/*     */   }
/*     */   
/*     */   static boolean isLeftToRight(Component c) {
/* 370 */     return c.getComponentOrientation().isLeftToRight();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintTopTabBorder(int tabIndex, Graphics g, int x, int y, int w, int h, int btm, int rght, boolean isSelected) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintBottomTabBorder(int tabIndex, Graphics g, int x, int y, int w, int h, int btm, int rght, boolean isSelected) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintRightTabBorder(int tabIndex, Graphics g, int x, int y, int w, int h, int btm, int rght, boolean isSelected) {}
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintLeftTabBorder(int tabIndex, Graphics g, int x, int y, int w, int h, int btm, int rght, boolean isSelected) {}
/*     */ 
/*     */ 
/*     */   
/*     */   protected void installListeners() {
/* 395 */     super.installListeners();
/* 396 */     if (this.tabPane.getTabLayoutPolicy() == 1) {
/* 397 */       byte b; int i; Component[] arrayOfComponent; for (i = (arrayOfComponent = this.tabPane.getComponents()).length, b = 0; b < i; ) { Component c = arrayOfComponent[b];
/* 398 */         if (c instanceof JViewport)
/* 399 */           this._viewPort = (JViewport)c; 
/*     */         b++; }
/*     */       
/* 402 */       this._sp = new MCScrollSupport() {
/* 403 */           Point _oldVp = null;
/*     */ 
/*     */           
/*     */           protected boolean move(MouseEvent e, Point src, Point dest) {
/* 407 */             JViewport v = MCMetalTabbedPaneUI.this._viewPort;
/*     */             
/* 409 */             Point curVp = v.getViewPosition();
/* 410 */             int dx = src.x - dest.x;
/* 411 */             int dy = src.y - dest.y;
/*     */             
/* 413 */             if (this._oldVp != null && !this._oldVp.equals(curVp)) {
/* 414 */               this._oldVp = null;
/* 415 */               return false;
/*     */             } 
/*     */             
/* 418 */             Point nextVp = new Point(curVp.x, curVp.y);
/* 419 */             nextVp.translate(dx, dy);
/* 420 */             ((JComponent)v.getView())
/* 421 */               .scrollRectToVisible(new Rectangle(nextVp, v.getSize()));
/* 422 */             Point movedVp = v.getViewPosition();
/* 423 */             if (curVp.equals(movedVp)) {
/*     */               
/* 425 */               this._oldVp = null;
/* 426 */               return false;
/*     */             } 
/*     */             
/* 429 */             this._oldVp = movedVp;
/* 430 */             return true;
/*     */           }
/*     */         };
/*     */       
/* 434 */       this._sp.addTo(this.tabPane);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintIcon(Graphics g, int tabPlacement, int tabIndex, Icon icon, Rectangle iconRect, boolean isSelected) {
/* 442 */     if (tabPlacement != 2) {
/* 443 */       super.paintIcon(g, tabPlacement, tabIndex, icon, iconRect, isSelected);
/*     */       
/*     */       return;
/*     */     } 
/* 447 */     if (this.tabPane.isEnabledAt(tabIndex)) {
/*     */       
/* 449 */       Rectangle lrect = (Rectangle)iconRect.clone();
/*     */       
/* 451 */       Icon licon = getTabLeftIcon(tabIndex);
/* 452 */       if (licon != null)
/*     */       {
/*     */ 
/*     */         
/* 456 */         super.paintIcon(g, tabPlacement, tabIndex, licon, lrect, isSelected);
/*     */       }
/*     */       
/* 459 */       Icon ricon = getTabRightIcon(tabIndex);
/* 460 */       Rectangle rrect = (Rectangle)iconRect.clone();
/* 461 */       rrect.y += (rrect.height >> 1) - (ricon.getIconHeight() >> 1);
/* 462 */       rrect.x = calculateMaxTabWidth(tabPlacement) - ricon.getIconWidth();
/*     */       
/* 464 */       super.paintIcon(g, tabPlacement, tabIndex, ricon, rrect, isSelected);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int calculateTabWidth(int tabPlacement, int tabIndex, FontMetrics metrics) {
/* 471 */     if (tabPlacement != 2) {
/* 472 */       return super.calculateTabWidth(tabPlacement, tabIndex, metrics);
/*     */     }
/*     */     
/* 475 */     Insets tabInsets = getTabInsets(tabPlacement, tabIndex);
/* 476 */     int width = tabInsets.left + tabInsets.right + 3;
/* 477 */     Component tabComponent = this.tabPane.getTabComponentAt(tabIndex);
/* 478 */     if (tabComponent != null) {
/* 479 */       width += (tabComponent.getPreferredSize()).width;
/*     */     }
/*     */     else {
/*     */       
/* 483 */       Icon icon = getTabLeftIcon(tabIndex);
/* 484 */       if (icon != null) {
/* 485 */         width += icon.getIconWidth() + this.textIconGap;
/*     */       }
/* 487 */       Icon ricon = getTabRightIcon(tabIndex);
/* 488 */       if (ricon != null) {
/* 489 */         width += ricon.getIconWidth() + this.textIconGap;
/*     */       }
/*     */       
/* 492 */       View v = getTextViewForTab(tabIndex);
/* 493 */       if (v != null) {
/*     */         
/* 495 */         width += (int)v.getPreferredSpan(0);
/*     */       }
/*     */       else {
/*     */         
/* 499 */         String title = this.tabPane.getTitleAt(tabIndex);
/* 500 */         width += SwingUtilities2.stringWidth(this.tabPane, metrics, title);
/*     */       } 
/*     */     } 
/* 503 */     return width;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int calculateTabHeight(int tabPlacement, int tabIndex, int fontHeight) {
/* 509 */     if (tabPlacement != 2) {
/* 510 */       return super.calculateTabHeight(tabPlacement, tabIndex, fontHeight);
/*     */     }
/* 512 */     int height = 0;
/* 513 */     Component c = this.tabPane.getTabComponentAt(tabIndex);
/* 514 */     if (c != null) {
/* 515 */       height = (c.getPreferredSize()).height;
/*     */     } else {
/*     */       
/* 518 */       View v = getTextViewForTab(tabIndex);
/* 519 */       if (v != null) {
/*     */         
/* 521 */         height += (int)v.getPreferredSpan(1);
/*     */       }
/*     */       else {
/*     */         
/* 525 */         height += fontHeight;
/*     */       } 
/*     */       
/* 528 */       Icon icon = getTabLeftIcon(tabIndex);
/* 529 */       if (icon != null) {
/* 530 */         height = Math.max(height, icon.getIconHeight());
/*     */       }
/* 532 */       Icon ricon = getTabRightIcon(tabIndex);
/* 533 */       if (ricon != null) {
/* 534 */         height = Math.max(height, ricon.getIconHeight());
/*     */       }
/*     */     } 
/* 537 */     Insets tabInsets = getTabInsets(tabPlacement, tabIndex);
/* 538 */     height += tabInsets.top + tabInsets.bottom + 2;
/* 539 */     return height;
/*     */   }
/*     */ 
/*     */   
/*     */   private Icon getTabRightIcon(int tabIndex) {
/* 544 */     if (this.tabPane.getTabPlacement() != 2) {
/* 545 */       return null;
/*     */     }
/* 547 */     ImageIcon i = _rightIcon;
/*     */ 
/*     */     
/* 550 */     MCRootPanel rp = ((MCTabbedPane)this.tabPane).getBaseRootPanel();
/* 551 */     if (rp != null) {
/* 552 */       int ratio = rp.getLayoutRatio();
/* 553 */       if (ratio != 100) {
/* 554 */         int w = i.getIconWidth() * ratio / 100;
/* 555 */         int h = i.getIconHeight() * ratio / 100;
/*     */ 
/*     */         
/* 558 */         i = ((MCTabbedPane)this.tabPane)._adjustIconSize(i, new Dimension(w, h), null);
/*     */       } 
/*     */     } 
/*     */     
/* 562 */     final ImageIcon c = i;
/*     */     
/* 564 */     if (i instanceof ImageIcon) {
/* 565 */       return convIconColor(tabIndex, i);
/*     */     }
/*     */ 
/*     */     
/* 569 */     return new ImageIcon()
/*     */       {
/*     */         public int getIconWidth() {
/* 572 */           return c.getIconWidth();
/*     */         }
/*     */ 
/*     */         
/*     */         public int getIconHeight() {
/* 577 */           return c.getIconHeight();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   protected Icon getIconForTab(int tabIndex) {
/* 584 */     if (!this.tabPane.isEnabled() || !this.tabPane.isEnabledAt(tabIndex)) {
/* 585 */       return this.tabPane.getDisabledIconAt(tabIndex);
/*     */     }
/*     */     
/* 588 */     return getTabLeftIcon(tabIndex);
/*     */   }
/*     */ 
/*     */   
/*     */   private Icon getTabLeftIcon(int tabIndex) {
/* 593 */     Icon i = this.tabPane.getIconAt(tabIndex);
/*     */     
/* 595 */     if (i instanceof ImageIcon && this.tabPane.getTabPlacement() == 2) {
/* 596 */       return convIconColor(tabIndex, (ImageIcon)i);
/*     */     }
/* 598 */     return i;
/*     */   }
/*     */ 
/*     */   
/*     */   private ImageIcon convIconColor(int tabIndex, ImageIcon icon) {
/* 603 */     boolean isSelected = (tabIndex == this.tabPane.getSelectedIndex());
/* 604 */     if (isSelected && _rev_sel_icon) {
/* 605 */       return new ImageIcon(Toolkit.getDefaultToolkit().createImage(
/* 606 */             MCGraphicsUtil.createReverseIconFilltered(icon.getImage())));
/*     */     }
/* 608 */     return icon;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void uninstallListeners() {
/* 613 */     super.uninstallListeners();
/* 614 */     if (this.tabPane.getTabLayoutPolicy() == 1 && 
/* 615 */       this._sp != null) {
/* 616 */       this._sp.removeFrom(this.tabPane);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected void installDefaults() {
/* 622 */     super.installDefaults();
/* 623 */     this.selectedIndicator = UIManager.getColor("TabbedPane.selectedIndicator");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void uninstallDefaults() {
/* 629 */     super.uninstallDefaults();
/* 630 */     this.selectedIndicator = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JButton createScrollButton(int direction) {
/* 637 */     if (direction != 5 && direction != 1 && direction != 3 && 
/* 638 */       direction != 7) {
/* 639 */       throw new IllegalArgumentException("Direction must be one of: SOUTH, NORTH, EAST or WEST");
/*     */     }
/*     */     
/* 642 */     return new MCScrollableTabButton(direction, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final class MCScrollableTabButton
/*     */     extends BasicArrowButton
/*     */     implements UIResource, SwingConstants
/*     */   {
/*     */     protected Dimension _prefSize;
/*     */ 
/*     */ 
/*     */     
/*     */     private MCScrollableTabButton(int direction) {
/* 657 */       super(direction, UIManager.getColor("TabbedPane.selected"), UIManager.getColor("TabbedPane.shadow"), MCConst.beans.getColor("tabbedpane.arrowcolor", UIManager.getColor("TabbedPane.darkShadow")), UIManager.getColor("TabbedPane.highlight"));
/*     */ 
/*     */       
/* 660 */       this._prefSize = null;
/*     */     }
/*     */     public void setPreferredSize(Dimension d) {
/* 663 */       this._prefSize = d;
/* 664 */       super.setPreferredSize(d);
/*     */     }
/*     */     
/*     */     public Dimension getPreferredSize() {
/* 668 */       if (this._prefSize != null) {
/* 669 */         return this._prefSize;
/*     */       }
/* 671 */       return super.getPreferredSize();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Insets getContentBorderInsets(int tabPlacement) {
/* 682 */     boolean b = false;
/* 683 */     if (b) {
/* 684 */       Insets insets3 = new Insets(0, 0, 0, 0);
/* 685 */       return insets3;
/*     */     } 
/* 687 */     Insets insets = super.getContentBorderInsets(tabPlacement);
/* 688 */     if (!(this.tabPane instanceof MCTabbedPane)) {
/* 689 */       return insets;
/*     */     }
/* 691 */     MCRootPanel rp = ((MCTabbedPane)this.tabPane).getBaseRootPanel();
/* 692 */     if (rp == null) {
/* 693 */       return insets;
/*     */     }
/* 695 */     int ratio = rp.getLayoutRatio();
/* 696 */     if (ratio == 100) {
/* 697 */       return insets;
/*     */     }
/* 699 */     int top = insets.top * ratio / 100;
/* 700 */     int bottom = insets.bottom * ratio / 100;
/* 701 */     int right = insets.right * ratio / 100;
/* 702 */     int left = insets.left * ratio / 100;
/* 703 */     Insets insets2 = new Insets(top, left, bottom, right);
/* 704 */     return insets2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Insets getDefaultContentBorderInsets(int tabPlacement) {
/* 715 */     Insets insets = super.getContentBorderInsets(tabPlacement);
/* 716 */     return insets;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected LayoutManager createLayoutManager() {
/* 755 */     if (this.tabPane.getTabLayoutPolicy() == 1) {
/* 756 */       return super.createLayoutManager();
/*     */     }
/* 758 */     return new TabbedPaneLayout();
/*     */   }
/*     */ 
/*     */   
/*     */   public class TabbedPaneLayout
/*     */     extends MetalTabbedPaneUI.TabbedPaneLayout
/*     */   {
/*     */     private boolean b = false;
/*     */     
/* 767 */     private int tabHeight1 = 0;
/* 768 */     private int tabHeight2 = 0;
/* 769 */     private int tabPaneHeight = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void layoutContainer(Container parent) {
/* 776 */       super.layoutContainer(parent);
/* 777 */       resizePanelHeight();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected void resizePanelHeight() {
/* 783 */       if (!this.b) {
/* 784 */         this.b = true;
/*     */ 
/*     */         
/* 787 */         if (MCMetalTabbedPaneUI.this.tabPane.getParent() instanceof MCPanel && 
/* 788 */           MCMetalTabbedPaneUI.this.tabPane.getParent().getParent() instanceof JViewport) {
/* 789 */           HashSet<Integer> set = new HashSet<>();
/*     */           
/* 791 */           this.tabHeight2 = 0;
/* 792 */           for (int i = 0; i < MCMetalTabbedPaneUI.this.tabPane.getTabCount(); i++) {
/* 793 */             Rectangle r = new Rectangle();
/* 794 */             MCMetalTabbedPaneUI.this.getTabBounds(i, r);
/* 795 */             set.add(Integer.valueOf(r.y));
/* 796 */             this.tabHeight2 = r.height;
/*     */           } 
/* 798 */           if (set.size() > 1)
/*     */           {
/* 800 */             if (this.tabPaneHeight != MCMetalTabbedPaneUI.this.tabPane.getParent().getHeight()) {
/* 801 */               this.tabHeight1 = 0;
/*     */             }
/* 803 */             Rectangle r = MCMetalTabbedPaneUI.this.tabPane.getParent().getBounds();
/* 804 */             MCMetalTabbedPaneUI.this.tabPane.getParent().setBounds(r.x, r.y, r.width, r.height + this.tabHeight2 - this.tabHeight1);
/* 805 */             MCMetalTabbedPaneUI.this.tabPane.getParent().setPreferredSize(new Dimension(r.width, r.height + this.tabHeight2 - this.tabHeight1));
/* 806 */             this.tabHeight1 = this.tabHeight2;
/* 807 */             this.tabPaneHeight = MCMetalTabbedPaneUI.this.tabPane.getParent().getHeight();
/*     */           
/*     */           }
/*     */         
/*     */         }
/* 812 */         else if (MCMetalTabbedPaneUI.this.tabPane.getParent() instanceof JViewport && 
/* 813 */           MCMetalTabbedPaneUI.this.tabPane.isShowing()) {
/* 814 */           HashSet<Integer> set = new HashSet<>();
/*     */           
/* 816 */           this.tabHeight2 = 0;
/* 817 */           for (int i = 0; i < MCMetalTabbedPaneUI.this.tabPane.getTabCount(); i++) {
/* 818 */             Rectangle r = new Rectangle();
/* 819 */             MCMetalTabbedPaneUI.this.getTabBounds(i, r);
/* 820 */             set.add(Integer.valueOf(r.y));
/* 821 */             this.tabHeight2 = r.height;
/*     */           } 
/* 823 */           if (set.size() > 1)
/*     */           {
/* 825 */             if (this.tabHeight1 != this.tabHeight2) {
/* 826 */               Rectangle r = MCMetalTabbedPaneUI.this.tabPane.getBounds();
/* 827 */               MCMetalTabbedPaneUI.this.tabPane.setBounds(r.x, r.y, r.width, r.height + this.tabHeight2 - this.tabHeight1);
/* 828 */               MCMetalTabbedPaneUI.this.tabPane.setPreferredSize(new Dimension(r.width, r.height + this.tabHeight2 - this.tabHeight1));
/* 829 */               if (MCMetalTabbedPaneUI.this.tabPane.getParent() instanceof MCPanel) {
/* 830 */                 MCPanel p = (MCPanel)MCMetalTabbedPaneUI.this.tabPane.getParent();
/* 831 */                 Rectangle r2 = p.getBounds();
/* 832 */                 p.setBounds(r2.x, r2.y, r2.width, r2.height + this.tabHeight2 - this.tabHeight1);
/* 833 */                 p.setPreferredSize(new Dimension(r2.width, r2.height + this.tabHeight2 - this.tabHeight1));
/*     */               } 
/* 835 */               this.tabHeight1 = this.tabHeight2;
/*     */             } 
/*     */           }
/*     */         } 
/*     */         
/* 840 */         this.b = false;
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\plaf\metal\MCMetalTabbedPaneUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */