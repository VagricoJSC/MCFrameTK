/*     */ package mcframe.clientCore.beans.plaf.metal;
/*     */ 
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.RenderingHints;
/*     */ import javax.swing.ButtonModel;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JRadioButton;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ButtonUI;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCRadioButton;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MCMetalRadioButtonIcon
/*     */   implements Icon
/*     */ {
/*  37 */   private MCRadioButton _compo = null;
/*     */   
/*  39 */   private ImageIcon icon = (ImageIcon)UIManager.getIcon("RadioButton.icon");
/*     */   
/*  41 */   private ImageIcon icon_dot = (ImageIcon)UIManager.getIcon("RadioButton.icon_dot");
/*     */ 
/*     */   
/*     */   private ImageIcon resizedicon;
/*     */ 
/*     */   
/*     */   private ImageIcon resizedicon_dot;
/*     */ 
/*     */   
/*     */   protected int _dot_r;
/*     */   
/*     */   protected int _oval_r;
/*     */   
/*     */   protected float _stroke;
/*     */   
/*     */   protected float _stroke2;
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void _paintIcon(Component c, Graphics g, int x, int y) {
/*  61 */     JRadioButton compo = (JRadioButton)c;
/*  62 */     ButtonModel model = compo.getModel();
/*  63 */     boolean drawDot = model.isSelected();
/*     */     
/*  65 */     int iw = getIconWidth();
/*  66 */     int ih = getIconHeight();
/*  67 */     if (this.resizedicon == null || this.resizedicon_dot == null) {
/*  68 */       this.resizedicon = this.icon;
/*  69 */       this.resizedicon_dot = this.icon_dot;
/*     */     } 
/*  71 */     ImageIcon base = this.resizedicon;
/*  72 */     ImageIcon dot = this.resizedicon_dot;
/*     */     
/*  74 */     boolean needResize = !(iw == this.resizedicon.getIconWidth() && 
/*  75 */       ih == this.resizedicon.getIconHeight());
/*  76 */     if (needResize) {
/*  77 */       Dimension nd = new Dimension(iw, ih);
/*  78 */       base = this.resizedicon = MCBeansUtil.adjustIconSize(this.icon, nd);
/*  79 */       dot = this.resizedicon_dot = MCBeansUtil.adjustIconSize(this.icon_dot, nd);
/*     */     } 
/*  81 */     if (!c.isEnabled()) {
/*  82 */       base = (ImageIcon)UIManager.getLookAndFeel().getDisabledIcon((JComponent)c, 
/*  83 */           base);
/*  84 */       if (drawDot) {
/*  85 */         dot = (ImageIcon)UIManager.getLookAndFeel()
/*  86 */           .getDisabledIcon((JComponent)c, dot);
/*     */       }
/*     */     } 
/*  89 */     base.paintIcon(c, g, x, y);
/*     */ 
/*     */     
/*  92 */     if (drawDot) {
/*  93 */       dot.paintIcon(compo, g, x, y);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   MCMetalRadioButtonIcon(MCRadioButton compo) {
/*  99 */     this._dot_r = 7;
/* 100 */     this._oval_r = 13;
/* 101 */     this._stroke = 1.0F;
/* 102 */     this._stroke2 = 0.8F;
/*     */     this._compo = compo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void paintIcon(Component c, Graphics g, int x, int y) {
/* 113 */     JRadioButton rb = (JRadioButton)c;
/* 114 */     ButtonModel model = rb.getModel();
/* 115 */     float controlSizeWidth = getIconWidth();
/* 116 */     float controlSizeHeight = getIconHeight();
/*     */     
/* 118 */     boolean drawDot = model.isSelected();
/*     */     
/* 120 */     ButtonUI bui = rb.getUI();
/*     */ 
/*     */     
/* 123 */     if (UIManager.getLookAndFeel() instanceof javax.swing.plaf.synth.SynthLookAndFeel) {
/*     */       return;
/*     */     }
/*     */     
/* 127 */     MCMetalRadioButtonUI ui = (MCMetalRadioButtonUI)bui;
/*     */     
/* 129 */     float centerX = x + controlSizeWidth / 2.0F;
/* 130 */     float centerY = y + controlSizeHeight / 2.0F;
/* 131 */     int fontRatio = this._compo.getRatio();
/*     */     
/* 133 */     float oval_r = (this._oval_r * fontRatio / 100 / 2);
/* 134 */     float dot_r = (this._dot_r * fontRatio / 100 / 2);
/*     */ 
/*     */     
/* 137 */     if (!model.isEnabled()) {
/* 138 */       _drawOval(g, centerX, centerY, oval_r, false, true, ui.getInactiveIconColor1(), ui.getInactiveIconColor2());
/*     */ 
/*     */       
/* 141 */       g.setColor(ui.getInactiveIconColor2());
/*     */     } 
/*     */     
/* 144 */     if (model.isEnabled())
/*     */     {
/* 146 */       if (model.isPressed() && model.isArmed()) {
/* 147 */         _drawOval(g, centerX, centerY, oval_r, true, true, Color.white, ui.getDotColor());
/*     */ 
/*     */         
/* 150 */         g.setColor(getBlendColor(ui.getPressedIconColor(), ui.getDotColor(), 0.5F));
/*     */       } else {
/*     */         
/* 153 */         _drawOval(g, centerX, centerY, oval_r, false, true, Color.white, ui.getDotColor());
/*     */ 
/*     */         
/* 156 */         g.setColor(ui.getDotColor());
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 165 */     if (drawDot) {
/* 166 */       _drawDot(g, centerX, centerY, dot_r);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _drawDot(Graphics g, float centerX, float centerY, float r) {
/* 173 */     Graphics2D g2D = (Graphics2D)g;
/*     */ 
/*     */     
/* 176 */     g2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/*     */     
/* 178 */     g2D.fillOval((int)(centerX - r), (int)(centerY - r), (int)(r * 2.0F), (int)(r * 2.0F));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void _drawOval(Graphics g, float centerX, float centerY, float r, boolean _pressed, boolean _enable, Color col1, Color col2) {
/* 185 */     int fontRatio = this._compo.getRatio();
/* 186 */     Graphics2D g2D = (Graphics2D)g;
/*     */ 
/*     */     
/* 189 */     g2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/*     */     
/* 191 */     if (_pressed) {
/* 192 */       g2D.fillOval((int)(centerX - r), (int)(centerY - r), (int)(r * 2.0F), (int)(r * 2.0F));
/*     */     }
/*     */     
/* 195 */     if (_enable) {
/* 196 */       g2D.setColor(col1);
/* 197 */       g2D.fillOval((int)(centerX - r), (int)(centerY - r), (int)(r * 2.0F) - (int)this._stroke, 
/* 198 */           (int)(r * 2.0F) - (int)this._stroke);
/*     */     } else {
/* 200 */       g.setColor(col1);
/* 201 */       g2D.fillOval((int)(centerX - r), (int)(centerY - r), (int)(r * 2.0F) - (int)this._stroke, 
/* 202 */           (int)(r * 2.0F) - (int)this._stroke);
/*     */     } 
/*     */ 
/*     */     
/* 206 */     g2D.setStroke(new BasicStroke(this._stroke2 * fontRatio / 100.0F));
/* 207 */     g.setColor(col2);
/*     */     
/* 209 */     g2D.drawOval((int)(centerX - r), (int)(centerY - r), (int)(r * 2.0F) - (int)this._stroke, 
/* 210 */         (int)(r * 2.0F) - (int)this._stroke);
/*     */     
/* 212 */     g2D.setStroke(new BasicStroke(1.0F));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Color getBlendColor(Color c1, Color c2, float alpha) {
/* 218 */     float r0 = c1.getRed() * alpha + c2.getRed() * (1.0F - alpha);
/* 219 */     float g0 = c1.getGreen() * alpha + c2.getGreen() * (1.0F - alpha);
/* 220 */     float b0 = c1.getBlue() * alpha + c2.getBlue() * (1.0F - alpha);
/* 221 */     return new Color((int)r0, (int)g0, (int)b0);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getIconWidth() {
/* 226 */     int i = this.icon.getIconWidth();
/* 227 */     if (this._compo != null) {
/* 228 */       i = i * this._compo.getRatio() / 100;
/*     */     }
/* 230 */     return i;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getIconHeight() {
/* 235 */     int i = this.icon.getIconHeight();
/* 236 */     if (this._compo != null) {
/* 237 */       i = i * this._compo.getRatio() / 100;
/*     */     }
/* 239 */     return i;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\plaf\metal\MCMetalRadioButtonIcon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */