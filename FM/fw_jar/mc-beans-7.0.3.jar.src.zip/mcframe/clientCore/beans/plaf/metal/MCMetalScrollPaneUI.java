/*    */ package mcframe.clientCore.beans.plaf.metal;
/*    */ 
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.JScrollPane;
/*    */ import javax.swing.LookAndFeel;
/*    */ import javax.swing.plaf.ComponentUI;
/*    */ import javax.swing.plaf.metal.MetalScrollPaneUI;
/*    */ import mcframe.clientCore.resource.MCConst;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCMetalScrollPaneUI
/*    */   extends MetalScrollPaneUI
/*    */ {
/*    */   public static ComponentUI createUI(JComponent x) {
/* 17 */     return new MCMetalScrollPaneUI();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void installDefaults(JScrollPane scrollpane) {
/* 22 */     super.installDefaults(scrollpane);
/* 23 */     LookAndFeel.installProperty(scrollpane, "opaque", 
/* 24 */         Boolean.valueOf(MCConst.beans.getBoolean("scrollpane.opaque", true)));
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\plaf\metal\MCMetalScrollPaneUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */