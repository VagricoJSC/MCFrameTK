/*     */ package mcframe.clientCore.beans.plaf.metal;
/*     */ 
/*     */ import javax.swing.UIDefaults;
/*     */ import javax.swing.plaf.metal.MetalLookAndFeel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCMetalLookAndFeel
/*     */   extends MetalLookAndFeel
/*     */ {
/*  17 */   private final String metalPackageName = "javax.swing.plaf.metal.";
/*     */   
/*  19 */   private final String mcMetalPackageName = "mcframe.clientCore.beans.plaf.metal.";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initClassDefaults(UIDefaults table) {
/*  32 */     super.initClassDefaults(table);
/*  33 */     Object[] uiDefaults = { 
/*  34 */         "PanelUI", 
/*  35 */         "mcframe.clientCore.beans.plaf.metal.MCMetalPanelUI", 
/*  36 */         "MCTempPanelUI", 
/*  37 */         "mcframe.clientCore.beans.plaf.metal.MCMetalTempPanelUI", 
/*  38 */         "ButtonUI", 
/*  39 */         "mcframe.clientCore.beans.plaf.metal.MCMetalButtonUI", 
/*  40 */         "CheckBoxUI", 
/*  41 */         "mcframe.clientCore.beans.plaf.metal.MCMetalCheckBoxUI", 
/*     */         
/*  43 */         "ComboBoxUI", 
/*  44 */         "mcframe.clientCore.beans.plaf.metal.MCMetalComboBoxUI",
/*     */         
/*  46 */         "DesktopIconUI", 
/*  47 */         "javax.swing.plaf.metal.MetalDesktopIconUI", 
/*  48 */         "FileChooserUI", 
/*  49 */         "mcframe.clientCore.beans.plaf.metal.MCMetalFileChooserUI", 
/*     */ 
/*     */         
/*  52 */         "InternalFrameUI", 
/*  53 */         "javax.swing.plaf.metal.MetalInternalFrameUI", 
/*  54 */         "LabelUI", 
/*  55 */         "javax.swing.plaf.metal.MetalLabelUI", 
/*     */         
/*  57 */         "PopupMenuSeparatorUI", 
/*  58 */         "javax.swing.plaf.metal.MetalPopupMenuSeparatorUI", 
/*  59 */         "ProgressBarUI", 
/*  60 */         "javax.swing.plaf.metal.MetalProgressBarUI", 
/*  61 */         "RadioButtonUI", 
/*  62 */         "mcframe.clientCore.beans.plaf.metal.MCMetalRadioButtonUI", 
/*     */         
/*  64 */         "ScrollBarUI", 
/*  65 */         "mcframe.clientCore.beans.plaf.metal.MCMetalScrollBarUI", 
/*  66 */         "ScrollPaneUI", 
/*  67 */         "mcframe.clientCore.beans.plaf.metal.MCMetalScrollPaneUI", 
/*  68 */         "SeparatorUI", 
/*  69 */         "javax.swing.plaf.metal.MetalSeparatorUI", 
/*  70 */         "SliderUI", 
/*  71 */         "javax.swing.plaf.metal.MetalSliderUI", 
/*  72 */         "SplitPaneUI", 
/*  73 */         "mcframe.clientCore.beans.plaf.metal.MCMetalSplitPaneUI", 
/*  74 */         "TabbedPaneUI", 
/*  75 */         "mcframe.clientCore.beans.plaf.metal.MCMetalTabbedPaneUI", 
/*     */         
/*  77 */         "TextFieldUI", 
/*  78 */         "mcframe.clientCore.beans.plaf.metal.MCMetalTextFieldUI", 
/*  79 */         "PasswordFieldUI", 
/*  80 */         "mcframe.clientCore.beans.plaf.metal.MCMetalPasswordFieldUI", 
/*  81 */         "TextAreaUI", 
/*  82 */         "mcframe.clientCore.beans.plaf.metal.MCMetalTextAreaUI", 
/*  83 */         "ToggleButtonUI", 
/*  84 */         "javax.swing.plaf.metal.MetalToggleButtonUI", 
/*  85 */         "ToolBarUI", 
/*  86 */         "mcframe.clientCore.beans.plaf.metal.MCMetalToolBarUI", 
/*  87 */         "MCStatusBarUI", 
/*  88 */         "mcframe.clientCore.beans.plaf.metal.MCMetalStatusBarUI", 
/*  89 */         "ToolTipUI", 
/*  90 */         "javax.swing.plaf.metal.MetalToolTipUI", 
/*  91 */         "TreeUI", 
/*  92 */         "javax.swing.plaf.metal.MetalTreeUI", 
/*  93 */         "RootPaneUI", 
/*  94 */         "javax.swing.plaf.metal.MetalRootPaneUI", 
/*  95 */         "ViewportUI", 
/*  96 */         "mcframe.clientCore.beans.plaf.metal.MCMetalViewPortUI", 
/*     */ 
/*     */         
/*  99 */         "MCTableUI", 
/* 100 */         "mcframe.clientCore.beans.table.MCTableUI", 
/*     */ 
/*     */         
/* 103 */         "MCColumnGroupTableHeaderUI", 
/* 104 */         "mcframe.clientCore.beans.table.MCColumnGroupTableHeaderUI",
/*     */         
/* 106 */         "MCTable2UI", 
/* 107 */         "mcframe.clientCore.beans.table.MCTable2UI", 
/* 108 */         "MCTable2HeaderUI", 
/* 109 */         "mcframe.clientCore.beans.table.MCTable2HeaderUI", 
/*     */         
/* 111 */         "MCLayoutTableUI", 
/* 112 */         "mcframe.clientCore.beans.table.MCLayoutTableUI", 
/* 113 */         "MCLayoutTableHeaderUI", 
/* 114 */         "mcframe.clientCore.beans.table.MCLayoutTableHeaderUI", 
/*     */ 
/*     */         
/* 117 */         "MCImageViewUI", 
/* 118 */         "mcframe.clientCore.beans.plaf.metal.MCMetalImageViewUI" };
/*     */ 
/*     */ 
/*     */     
/* 122 */     table.putDefaults(uiDefaults);
/*     */   }
/*     */   
/*     */   static boolean usingOcean() {
/* 126 */     return getCurrentTheme() instanceof javax.swing.plaf.metal.OceanTheme;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\plaf\metal\MCMetalLookAndFeel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */