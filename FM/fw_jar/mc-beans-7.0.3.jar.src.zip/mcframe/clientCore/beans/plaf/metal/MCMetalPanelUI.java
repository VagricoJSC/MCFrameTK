/*     */ package mcframe.clientCore.beans.plaf.metal;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Shape;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.LookAndFeel;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.PanelUI;
/*     */ import javax.swing.plaf.basic.BasicPanelUI;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.MCTitledBorder;
/*     */ import mcframe.clientCore.beans.plaf.MCGraphicsUtil;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ 
/*     */ public class MCMetalPanelUI
/*     */   extends BasicPanelUI {
/*     */   private static PanelUI panelUI;
/*     */   
/*     */   public static ComponentUI createUI(JComponent c) {
/*  25 */     if (panelUI == null) {
/*  26 */       panelUI = new MCMetalPanelUI();
/*     */     }
/*  28 */     return panelUI;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void paint(Graphics g, JComponent c) {
/*  34 */     if (paintTableHeader(g, c)) {
/*     */       return;
/*     */     }
/*     */     
/*  38 */     if (paintOther(g, c)) {
/*     */       return;
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean paintOther(Graphics g, JComponent c) {
/*  44 */     super.paint(g, c);
/*     */ 
/*     */     
/*  47 */     Border b = c.getBorder();
/*  48 */     if (b instanceof MCTitledBorder) {
/*  49 */       MCTitledBorder mtb = (MCTitledBorder)b;
/*     */       
/*  51 */       Shape r = mtb.getBorderShape(c, g, 0, 0, c.getWidth(), c.getHeight());
/*  52 */       fillRectDiff(g, c, r);
/*     */     } 
/*  54 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean paintTableHeader(Graphics g, JComponent c) {
/*  59 */     if (c instanceof javax.swing.table.TableCellRenderer) {
/*  60 */       Graphics2D g2 = (Graphics2D)g;
/*  61 */       int h = c.getHeight();
/*  62 */       Color bg = c.getBackground();
/*  63 */       Color bg2 = UIManager.getColor("TableHeader.background2");
/*     */       
/*  65 */       if (bg2 == null) {
/*  66 */         bg2 = Color.white;
/*     */       }
/*  68 */       g2.setPaint(MCGraphicsUtil.createUpGradientPaint(h, bg, bg2));
/*     */       
/*  70 */       g.fillRect(0, 0, c.getWidth(), h);
/*  71 */       return true;
/*     */     } 
/*  73 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private void fillRectDiff(Graphics g, JComponent c, Shape r) {
/*  78 */     Graphics2D g2 = (Graphics2D)g;
/*  79 */     Color bg2 = MCConst.beans.getColor("panel.bg2");
/*  80 */     if (bg2 != null) {
/*  81 */       g2.setColor(bg2);
/*  82 */       MCGraphicsUtil.draw(g2, r, c.getWidth(), c.getHeight(), null);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void installDefaults(JPanel p) {
/*  88 */     super.installDefaults(p);
/*  89 */     if (p instanceof MCRootPanel) {
/*  90 */       MCRootPanel rp = (MCRootPanel)p;
/*  91 */       if (MCConst.screen.getBoolean(
/*  92 */           MCConst.createKey(new String[] { rp.getModuleID(), rp.getScreenID(), "parts"
/*  93 */             }, ), false)) {
/*  94 */         LookAndFeel.installProperty(p, "opaque", 
/*  95 */             Boolean.valueOf(MCConst.beans.getBoolean("rootpanel.parts.opaque", false)));
/*     */       } else {
/*     */         
/*  98 */         LookAndFeel.installProperty(p, "opaque", 
/*  99 */             Boolean.valueOf(MCConst.beans.getBoolean("rootpanel.opaque", false)));
/*     */       } 
/*     */     } else {
/*     */       
/* 103 */       LookAndFeel.installProperty(p, "opaque", 
/* 104 */           Boolean.valueOf(MCConst.beans.getBoolean("panel.opaque", false)));
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\plaf\metal\MCMetalPanelUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */