/*    */ package mcframe.clientCore.beans.plaf.metal;
/*    */ 
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.LookAndFeel;
/*    */ import javax.swing.UIManager;
/*    */ import javax.swing.plaf.ComponentUI;
/*    */ import javax.swing.plaf.basic.BasicSplitPaneDivider;
/*    */ import javax.swing.plaf.basic.BasicSplitPaneUI;
/*    */ import mcframe.clientCore.beans.MCSplitPane;
/*    */ import mcframe.clientCore.resource.MCConst;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCMetalSplitPaneUI
/*    */   extends BasicSplitPaneUI
/*    */ {
/*    */   public static ComponentUI createUI(JComponent x) {
/* 21 */     return new MCMetalSplitPaneUI();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public BasicSplitPaneDivider createDefaultDivider() {
/* 29 */     return new MCMetalSplitPaneDivider(this);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void installDefaults() {
/* 34 */     super.installDefaults();
/* 35 */     MCMetalSplitPaneDivider div = (MCMetalSplitPaneDivider)this.divider;
/* 36 */     div.divideropaque = UIManager.getBoolean("SplitPaneDivider.opaque");
/* 37 */     div.dividerColor = UIManager.getColor("SplitPaneDivider.color");
/* 38 */     LookAndFeel.installProperty(this.splitPane, "opaque", 
/* 39 */         Boolean.valueOf(MCConst.beans.getBoolean("splitpane.opaque", true)));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void finishDraggingTo(int location) {
/* 46 */     if (this.splitPane instanceof MCSplitPane) {
/* 47 */       ((MCSplitPane)this.splitPane).setUseRatio(false);
/* 48 */       super.finishDraggingTo(location);
/* 49 */       ((MCSplitPane)this.splitPane).setUseRatio(true);
/*    */     } else {
/* 51 */       super.finishDraggingTo(location);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\plaf\metal\MCMetalSplitPaneUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */