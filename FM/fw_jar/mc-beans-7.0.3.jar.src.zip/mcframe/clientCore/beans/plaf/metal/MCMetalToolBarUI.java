/*    */ package mcframe.clientCore.beans.plaf.metal;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.awt.Component;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Graphics2D;
/*    */ import java.awt.LinearGradientPaint;
/*    */ import java.awt.MultipleGradientPaint;
/*    */ import java.awt.Point;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.UIManager;
/*    */ import javax.swing.plaf.ComponentUI;
/*    */ import javax.swing.plaf.basic.BasicToolBarUI;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCMetalToolBarUI
/*    */   extends BasicToolBarUI
/*    */ {
/*    */   public static ComponentUI createUI(JComponent c) {
/* 32 */     return new MCMetalToolBarUI();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean canDock(Component c, Point p) {
/* 37 */     return true;
/*    */   }
/*    */   
/*    */   public void paint(Graphics g, JComponent c) {
/* 41 */     super.paint(g, c);
/* 42 */     if (c.isOpaque()) {
/* 43 */       Graphics2D g2 = (Graphics2D)g;
/* 44 */       Color st = c.getBackground();
/* 45 */       Color ed = UIManager.getColor("ToolBar.background2");
/*    */       
/* 47 */       if (ed == null) {
/* 48 */         ed = Color.white;
/*    */       }
/* 50 */       g2.setPaint(
/* 51 */           createGradientPaint(
/* 52 */             st, 
/* 53 */             ed, 
/* 54 */             c.getWidth(), c.getHeight()));
/*    */ 
/*    */       
/* 57 */       g.fillRect(0, 0, c.getWidth(), c.getHeight());
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static LinearGradientPaint createGradientPaint(Color st, Color ed, int w, int h) {
/* 72 */     float[] dist = null;
/* 73 */     Color[] colors = { st, st, ed };
/* 74 */     float[] p = new float[4];
/* 75 */     if (h <= w) {
/* 76 */       dist = new float[] { 0.0F, 0.7F, 1.0F };
/* 77 */       p[0] = 0.0F;
/* 78 */       p[1] = 0.0F;
/* 79 */       p[2] = 0.0F;
/* 80 */       p[3] = h;
/*    */     
/*    */     }
/*    */     else {
/*    */ 
/*    */       
/* 86 */       dist = new float[] { 0.0F, 0.8F, 1.0F };
/* 87 */       p[0] = 0.0F;
/* 88 */       p[1] = 0.0F;
/* 89 */       p[2] = w;
/* 90 */       p[3] = 0.0F;
/*    */     } 
/*    */     
/* 93 */     return new LinearGradientPaint(p[0], p[1], p[2], 
/* 94 */         p[3], dist, colors, MultipleGradientPaint.CycleMethod.NO_CYCLE);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\plaf\metal\MCMetalToolBarUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */