/*    */ package mcframe.clientCore.beans.plaf.metal;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Graphics2D;
/*    */ import java.awt.Rectangle;
/*    */ import javax.swing.AbstractButton;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.UIManager;
/*    */ import javax.swing.border.Border;
/*    */ import javax.swing.plaf.ComponentUI;
/*    */ import javax.swing.plaf.metal.MetalToggleButtonUI;
/*    */ import mcframe.clientCore.beans.border.MCButtonLineBorder;
/*    */ import mcframe.clientCore.beans.plaf.MCGraphicsUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCMetalToggleButtonUI
/*    */   extends MetalToggleButtonUI
/*    */ {
/* 35 */   private static final MCMetalToggleButtonUI metalToggleButtonUI = new MCMetalToggleButtonUI();
/*    */   
/*    */   public static ComponentUI createUI(JComponent c) {
/* 38 */     c.setBorder((Border)new MCButtonLineBorder(1, false, false));
/* 39 */     return metalToggleButtonUI;
/*    */   }
/*    */ 
/*    */   
/*    */   public void update(Graphics g, JComponent c) {
/* 44 */     AbstractButton button = (AbstractButton)c;
/* 45 */     if (button.isContentAreaFilled()) {
/* 46 */       Color bg = c.getBackground();
/* 47 */       if (button.getModel().isRollover()) {
/* 48 */         bg = bg.brighter();
/*    */       }
/*    */       
/* 51 */       MCMetalButtonUI.createUI(c)
/* 52 */         .paintMain((Graphics2D)g, button, bg, null);
/*    */ 
/*    */       
/* 55 */       paint(g, c);
/*    */       return;
/*    */     } 
/* 58 */     super.update(g, c);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void paintButtonPressed(Graphics g, AbstractButton b) {
/* 63 */     if (b.isContentAreaFilled()) {
/*    */       
/* 65 */       Color ed = UIManager.getColor(MCGraphicsUtil.getUIKey(b, "background2"));
/* 66 */       MCMetalButtonUI.createUI(b)
/* 67 */         .paintMain((Graphics2D)g, b, b.getBackground(), ed);
/*    */     } else {
/*    */       
/* 70 */       super.paintButtonPressed(g, b);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void paintFocus(Graphics g, AbstractButton b, Rectangle viewRect, Rectangle textRect, Rectangle iconRect) {
/* 77 */     MCMetalButtonUI.createUI(b)
/* 78 */       .paintFocusSub(g, b, viewRect, textRect, iconRect);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\plaf\metal\MCMetalToggleButtonUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */