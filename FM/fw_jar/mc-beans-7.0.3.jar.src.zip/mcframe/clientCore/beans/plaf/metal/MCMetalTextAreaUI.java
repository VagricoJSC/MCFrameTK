/*    */ package mcframe.clientCore.beans.plaf.metal;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.event.FocusAdapter;
/*    */ import java.awt.event.FocusEvent;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.plaf.ComponentUI;
/*    */ import javax.swing.plaf.basic.BasicTextAreaUI;
/*    */ import javax.swing.text.JTextComponent;
/*    */ import mcframe.clientCore.beans.plaf.MCGraphicsUtil;
/*    */ 
/*    */ public class MCMetalTextAreaUI
/*    */   extends BasicTextAreaUI
/*    */ {
/*    */   public static ComponentUI createUI(JComponent ta) {
/* 17 */     return new MCMetalTextAreaUI();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void paintBackground(Graphics g) {
/* 23 */     super.paintBackground(g);
/* 24 */     getComponent();
/* 25 */     MCGraphicsUtil.drawModeLine(g, getComponent());
/*    */   }
/*    */ 
/*    */   
/*    */   protected void installListeners() {
/* 30 */     super.installListeners();
/* 31 */     JTextComponent c = getComponent();
/* 32 */     if (c != null) {
/* 33 */       c.removeFocusListener(_fa);
/* 34 */       c.addFocusListener(_fa);
/*    */     } 
/*    */   }
/*    */   
/* 38 */   private static final FocusAdapter _fa = new FocusAdapter()
/*    */     {
/*    */       public void focusLost(FocusEvent e) {
/* 41 */         focus(e);
/*    */       }
/*    */ 
/*    */       
/*    */       public void focusGained(FocusEvent e) {
/* 46 */         focus(e);
/*    */       }
/*    */ 
/*    */       
/*    */       private void focus(FocusEvent e) {
/* 51 */         Component c = e.getComponent();
/* 52 */         if (c != null) {
/* 53 */           c.repaint();
/*    */         }
/* 55 */         c = e.getOppositeComponent();
/* 56 */         if (c != null) {
/* 57 */           c.repaint();
/*    */         }
/*    */       }
/*    */     };
/*    */ 
/*    */   
/*    */   protected void uninstallDefaults() {
/* 64 */     super.uninstallDefaults();
/* 65 */     JTextComponent c = getComponent();
/* 66 */     if (c != null)
/* 67 */       c.removeFocusListener(_fa); 
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\plaf\metal\MCMetalTextAreaUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */