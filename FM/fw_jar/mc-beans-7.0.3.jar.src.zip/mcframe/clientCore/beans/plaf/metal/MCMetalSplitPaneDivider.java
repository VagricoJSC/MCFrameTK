/*     */ package mcframe.clientCore.beans.plaf.metal;
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.Cursor;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Point;
/*     */ import java.awt.Polygon;
/*     */ import java.awt.event.MouseEvent;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JSplitPane;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.plaf.basic.BasicSplitPaneDivider;
/*     */ import javax.swing.plaf.basic.BasicSplitPaneUI;
/*     */ import mcframe.clientCore.beans.MCSplitPane;
/*     */ import sun.swing.DefaultLookup;
/*     */ 
/*     */ public class MCMetalSplitPaneDivider extends BasicSplitPaneDivider {
/*     */   Color dividerColor;
/*     */   boolean divideropaque;
/*     */   private int oneTouchSize;
/*     */   private boolean centerOneTouchVArrow;
/*     */   private boolean centerOneTouchHArrow;
/*     */   
/*     */   enum ButtonType {
/*  26 */     LEFT, RIGHT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected class MCDividerLayout
/*     */     extends BasicSplitPaneDivider.DividerLayout
/*     */   {
/*     */     public void layoutContainer(Container c) {
/*  43 */       super.layoutContainer(c);
/*     */       
/*  45 */       if (MCMetalSplitPaneDivider.this.splitPane.isOneTouchExpandable()) {
/*  46 */         Point lp = MCMetalSplitPaneDivider.this.leftButton.getLocation();
/*  47 */         Point rp = MCMetalSplitPaneDivider.this.rightButton.getLocation();
/*  48 */         if (MCMetalSplitPaneDivider.this.centerOneTouchVArrow && MCMetalSplitPaneDivider.this.orientation == 0) {
/*  49 */           int center = MCMetalSplitPaneDivider.this.getWidth() / 2;
/*  50 */           int pw = (rp.x + MCMetalSplitPaneDivider.this.rightButton.getWidth() - lp.x) / 2;
/*  51 */           lp.x = center - pw;
/*  52 */           rp.x = center + pw - MCMetalSplitPaneDivider.this.rightButton.getWidth();
/*  53 */           MCMetalSplitPaneDivider.this.leftButton.setLocation(lp);
/*  54 */           MCMetalSplitPaneDivider.this.rightButton.setLocation(rp);
/*     */         }
/*  56 */         else if (MCMetalSplitPaneDivider.this.centerOneTouchHArrow) {
/*  57 */           int center = MCMetalSplitPaneDivider.this.getHeight() / 2;
/*  58 */           int ph = (rp.y + MCMetalSplitPaneDivider.this.rightButton.getHeight() - lp.y) / 2;
/*  59 */           lp.y = center - ph;
/*  60 */           rp.y = center + ph - MCMetalSplitPaneDivider.this.rightButton.getHeight();
/*  61 */           MCMetalSplitPaneDivider.this.leftButton.setLocation(lp);
/*  62 */           MCMetalSplitPaneDivider.this.rightButton.setLocation(rp);
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private class OneTouchButton
/*     */     extends JButton
/*     */   {
/*     */     private MCMetalSplitPaneDivider.ButtonType _typ;
/*     */     
/*     */     public OneTouchButton(MCMetalSplitPaneDivider.ButtonType typ) {
/*  75 */       this._typ = typ;
/*  76 */       setupOneTouchButton();
/*     */     }
/*     */ 
/*     */     
/*     */     private void setupOneTouchButton() {
/*  81 */       setMinimumSize(new Dimension(MCMetalSplitPaneDivider.this.oneTouchSize, MCMetalSplitPaneDivider.this.oneTouchSize));
/*  82 */       setCursor(Cursor.getPredefinedCursor(0));
/*  83 */       setFocusPainted(false);
/*  84 */       setBorderPainted(false);
/*  85 */       setRequestFocusEnabled(false);
/*     */       
/*  87 */       Object opaque = UIManager.get("SplitPane.oneTouchButtonsOpaque");
/*  88 */       if (opaque != null) {
/*  89 */         setOpaque(((Boolean)opaque).booleanValue());
/*     */       } else {
/*     */         
/*  92 */         setOpaque(false);
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void setBorder(Border b) {}
/*     */ 
/*     */     
/*     */     public void paint(Graphics g) {
/* 102 */       if (MCMetalSplitPaneDivider.this.splitPane != null) {
/*     */         Polygon polygon;
/*     */         
/* 105 */         if (isOpaque()) {
/* 106 */           g.setColor(getBackground());
/* 107 */           g.fillRect(0, 0, getWidth(), getHeight());
/*     */         } 
/* 109 */         g.setColor(UIManager.getColor("SplitPane.arrowColor"));
/* 110 */         if (MCMetalSplitPaneDivider.this.orientation == 0) {
/* 111 */           int blockSize = Math.min(getHeight(), MCMetalSplitPaneDivider.this.oneTouchSize);
/* 112 */           polygon = createVerticalArrow(blockSize, this._typ);
/* 113 */           if (this._typ == MCMetalSplitPaneDivider.ButtonType.LEFT) {
/* 114 */             g.drawPolygon(polygon);
/*     */           }
/*     */         }
/*     */         else {
/*     */           
/* 119 */           int blockSize = Math.min(getWidth(), MCMetalSplitPaneDivider.this.oneTouchSize);
/* 120 */           polygon = createHorizontalArrow(blockSize, this._typ);
/*     */         } 
/*     */         
/* 123 */         g.fillPolygon(polygon);
/*     */       } 
/*     */     }
/*     */     
/*     */     private Polygon createVerticalArrow(int blockSize, MCMetalSplitPaneDivider.ButtonType typ) {
/* 128 */       int[] xs = new int[3];
/* 129 */       int[] ys = new int[3];
/* 130 */       switch (this._typ) {
/*     */         case null:
/* 132 */           xs[0] = blockSize;
/* 133 */           xs[1] = 0;
/* 134 */           xs[2] = blockSize << 1;
/* 135 */           ys[0] = 0;
/* 136 */           ys[2] = blockSize; ys[1] = blockSize;
/*     */           break;
/*     */         case RIGHT:
/* 139 */           xs[0] = blockSize;
/* 140 */           xs[1] = blockSize << 1;
/* 141 */           xs[2] = 0;
/* 142 */           ys[0] = blockSize;
/* 143 */           ys[2] = 0; ys[1] = 0; break;
/*     */       } 
/* 145 */       return new Polygon(xs, ys, 3);
/*     */     }
/*     */     
/*     */     private Polygon createHorizontalArrow(int blockSize, MCMetalSplitPaneDivider.ButtonType typ) {
/* 149 */       int[] xs = new int[3];
/* 150 */       int[] ys = new int[3];
/* 151 */       switch (this._typ) {
/*     */         case null:
/* 153 */           xs[2] = blockSize; xs[0] = blockSize;
/* 154 */           xs[1] = 0;
/* 155 */           ys[0] = 0;
/* 156 */           ys[1] = blockSize;
/* 157 */           ys[2] = blockSize << 1;
/*     */           break;
/*     */         case RIGHT:
/* 160 */           xs[2] = 0; xs[0] = 0;
/* 161 */           xs[1] = blockSize;
/* 162 */           ys[0] = 0;
/* 163 */           ys[1] = blockSize;
/* 164 */           ys[2] = blockSize << 1; break;
/*     */       } 
/* 166 */       return new Polygon(xs, ys, 3);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isFocusTraversable() {
/* 171 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected void processMouseEvent(MouseEvent e) {
/*     */       try {
/* 178 */         ((MCSplitPane)MCMetalSplitPaneDivider.this.splitPane).setUseRatio(false);
/* 179 */         super.processMouseEvent(e);
/*     */       } finally {
/* 181 */         ((MCSplitPane)MCMetalSplitPaneDivider.this.splitPane).setUseRatio(true);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public MCMetalSplitPaneDivider(BasicSplitPaneUI ui) {
/* 187 */     super(ui);
/* 188 */     this.oneTouchSize = DefaultLookup.getInt(ui.getSplitPane(), ui, 
/* 189 */         "SplitPane.oneTouchButtonSize", 6);
/* 190 */     this.centerOneTouchVArrow = DefaultLookup.getBoolean(ui.getSplitPane(), ui, 
/* 191 */         "SplitPane.centerVArrow", true);
/* 192 */     this.centerOneTouchHArrow = DefaultLookup.getBoolean(ui.getSplitPane(), ui, 
/* 193 */         "SplitPane.centerHArrow", true);
/* 194 */     setLayout(new MCDividerLayout());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JButton createLeftOneTouchButton() {
/* 201 */     JButton b = new OneTouchButton(ButtonType.LEFT);
/* 202 */     b.setName("_left");
/* 203 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JButton createRightOneTouchButton() {
/* 210 */     JButton b = new OneTouchButton(ButtonType.RIGHT);
/* 211 */     b.setName("_right");
/* 212 */     return b;
/*     */   }
/*     */ 
/*     */   
/*     */   public void paint(Graphics g) {
/* 217 */     if (this.divideropaque) {
/* 218 */       Graphics g2 = g.create();
/* 219 */       g2.setColor(this.dividerColor);
/* 220 */       g2.fillRect(0, 0, getWidth(), getHeight());
/* 221 */       g2.dispose();
/*     */     } 
/* 223 */     super.paint(g);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void dragDividerTo(int location) {
/* 229 */     ((MCSplitPane)this.splitPane).setUseRatio(false);
/* 230 */     super.dragDividerTo(location);
/* 231 */     ((MCSplitPane)this.splitPane).setUseRatio(true);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\plaf\metal\MCMetalSplitPaneDivider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */