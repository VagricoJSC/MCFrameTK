/*     */ package mcframe.clientCore.beans.plaf.metal;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.Shape;
/*     */ import java.awt.event.FocusAdapter;
/*     */ import java.awt.event.FocusEvent;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.metal.MetalTextFieldUI;
/*     */ import javax.swing.text.Element;
/*     */ import javax.swing.text.FieldView;
/*     */ import javax.swing.text.JTextComponent;
/*     */ import javax.swing.text.View;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCCalendarField;
/*     */ import mcframe.clientCore.beans.plaf.MCGraphicsUtil;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCMetalTextFieldUI
/*     */   extends MetalTextFieldUI
/*     */ {
/*     */   public MCMetalTextFieldUI() {
/* 252 */     this._fa = new FocusAdapter()
/*     */       {
/*     */         public void focusLost(FocusEvent e) {
/* 255 */           _focus(e);
/*     */         }
/*     */ 
/*     */         
/*     */         public void focusGained(FocusEvent e) {
/* 260 */           _focus(e);
/*     */         }
/*     */         
/*     */         private void _focus(FocusEvent e)
/*     */         {
/* 265 */           Component c = e.getComponent();
/* 266 */           if (c != null) {
/* 267 */             c.repaint();
/*     */           }
/* 269 */           c = e.getOppositeComponent();
/* 270 */           if (c != null) {
/* 271 */             c.repaint();
/*     */           }
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   protected void uninstallDefaults() {
/* 278 */     super.uninstallDefaults();
/* 279 */     JTextComponent c = getComponent();
/* 280 */     if (c != null)
/* 281 */       c.removeFocusListener(this._fa); 
/*     */   }
/*     */   
/*     */   private static ImageIcon _isicon = null;
/*     */   private static IconLoc _ISLoc = null;
/*     */   private static ImageIcon _pficon = null;
/*     */   private static IconLoc _PFLoc = null;
/*     */   private static ImageIcon _clicon = null;
/*     */   private static IconLoc _CLLoc = null;
/*     */   private final FocusAdapter _fa;
/*     */   
/*     */   private enum IconLoc {
/*     */     LEFT, RIGHT, NONE;
/*     */   }
/*     */   
/*     */   public static ComponentUI createUI(JComponent c) {
/*     */     return new MCMetalTextFieldUI();
/*     */   }
/*     */   
/*     */   protected void paintBackground(Graphics g) {
/*     */     super.paintBackground(g);
/*     */     MCGraphicsUtil.drawModeLine(g, getComponent());
/*     */     drawIcon(g);
/*     */   }
/*     */   
/*     */   private void drawIcon(Graphics g) {
/*     */     if (useISIcon()) {
/*     */       String kp = "field.is.icon";
/*     */       if (_ISLoc == null)
/*     */         _ISLoc = IconLoc.valueOf(MCConst.beans.getString(String.valueOf(kp) + ".location")); 
/*     */       if (_ISLoc != IconLoc.NONE) {
/*     */         if (_isicon == null)
/*     */           _isicon = MCConst.beans.getIcon(String.valueOf(kp) + ".img"); 
/*     */         drawIcon(g, _isicon, _ISLoc);
/*     */       } 
/*     */     } else if (useCalenderIcon()) {
/*     */       String kp = "field.calendar.icon";
/*     */       if (_CLLoc == null)
/*     */         _CLLoc = IconLoc.valueOf(MCConst.beans.getString(String.valueOf(kp) + ".location")); 
/*     */       if (_CLLoc != IconLoc.NONE) {
/*     */         if (_clicon == null)
/*     */           _clicon = MCConst.beans.getIcon(String.valueOf(kp) + ".img"); 
/*     */         drawIcon(g, _clicon, _CLLoc);
/*     */       } 
/*     */     } else if (usePFIcon()) {
/*     */       String kp = "field.plural_value.icon";
/*     */       if (_PFLoc == null)
/*     */         _PFLoc = IconLoc.valueOf(MCConst.beans.getString(String.valueOf(kp) + ".location")); 
/*     */       if (_PFLoc != IconLoc.NONE) {
/*     */         if (_pficon == null)
/*     */           _pficon = MCConst.beans.getIcon(String.valueOf(kp) + ".img"); 
/*     */         drawIcon(g, _pficon, _PFLoc);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void drawIcon(Graphics g, ImageIcon icon, IconLoc loc) {
/*     */     Insets i = getComponent().getInsets();
/*     */     if (icon != null) {
/*     */       JTextComponent c = getComponent();
/*     */       int h = c.getHeight();
/*     */       h -= i.top + i.bottom;
/*     */       Icon ri = MCBeansUtil.adjustIconSize(icon, new Dimension(h, h));
/*     */       int left = 0;
/*     */       switch (loc) {
/*     */         case null:
/*     */           left = i.left + 5;
/*     */           break;
/*     */         case RIGHT:
/*     */           left = c.getWidth() - i.right - ri.getIconWidth() - i.left;
/*     */           break;
/*     */         case NONE:
/*     */           return;
/*     */       } 
/*     */       ri.paintIcon(getComponent(), g, left, i.top);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean useISIcon() {
/*     */     JTextComponent c = getComponent();
/*     */     Border b = c.getBorder();
/*     */     if (!c.isEditable())
/*     */       return false; 
/*     */     if (!(b instanceof mcframe.clientCore.beans.border.MCISFieldBorder) && !(b instanceof mcframe.clientCore.beans.border.MCPluralValueISFieldBorder))
/*     */       return false; 
/*     */     if (!c.isFocusOwner() && !(c instanceof mcframe.clientCore.beans.table.MCEditorBeans))
/*     */       return false; 
/*     */     if (!MCStringUtil.isNull(c.getText()))
/*     */       return false; 
/*     */     return true;
/*     */   }
/*     */   
/*     */   private boolean usePFIcon() {
/*     */     JTextComponent c = getComponent();
/*     */     Border b = c.getBorder();
/*     */     if (!c.isEditable())
/*     */       return false; 
/*     */     if (!(b instanceof mcframe.clientCore.beans.border.MCPluralValueFieldBorder))
/*     */       return false; 
/*     */     if (!c.isFocusOwner() && !(c instanceof mcframe.clientCore.beans.table.MCEditorBeans))
/*     */       return false; 
/*     */     if (!MCStringUtil.isNull(c.getText()))
/*     */       return false; 
/*     */     return true;
/*     */   }
/*     */   
/*     */   boolean useCalenderIcon() {
/*     */     JTextComponent c = getComponent();
/*     */     c.getBorder();
/*     */     if (!c.isEditable())
/*     */       return false; 
/*     */     if (!(c instanceof MCCalendarField) || !((MCCalendarField)c).isCalendarEnabled())
/*     */       return false; 
/*     */     if (!c.isFocusOwner() && !(c instanceof mcframe.clientCore.beans.table.MCEditorBeans))
/*     */       return false; 
/*     */     if (!MCStringUtil.isNull(c.getText()))
/*     */       return false; 
/*     */     return true;
/*     */   }
/*     */   
/*     */   protected void installListeners() {
/*     */     super.installListeners();
/*     */     JTextComponent c = getComponent();
/*     */     if (c != null) {
/*     */       c.removeFocusListener(this._fa);
/*     */       c.addFocusListener(this._fa);
/*     */     } 
/*     */   }
/*     */   
/*     */   public View create(Element elem) {
/*     */     final JTextComponent c = getComponent();
/*     */     if (c instanceof MCCalendarField)
/*     */       return new FieldView(elem) {
/*     */           protected Shape adjustAllocation(Shape a) {
/*     */             if (a != null) {
/*     */               MCCalendarField<?> cf = (MCCalendarField)c;
/*     */               if (cf.isEnableStatusAmPmField() && cf.isMCFocusOwner()) {
/*     */                 Shape shape = super.adjustAllocation(a);
/*     */                 Rectangle bounds = a.getBounds();
/*     */                 bounds.y = (shape.getBounds()).y;
/*     */                 bounds.width = (int)(bounds.width - MCBeansProxy.PROXY.getAmPmDimension(cf).getHeight());
/*     */                 return bounds;
/*     */               } 
/*     */             } 
/*     */             Shape s = super.adjustAllocation(a);
/*     */             return s;
/*     */           }
/*     */         }; 
/*     */     return super.create(elem);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\plaf\metal\MCMetalTextFieldUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */