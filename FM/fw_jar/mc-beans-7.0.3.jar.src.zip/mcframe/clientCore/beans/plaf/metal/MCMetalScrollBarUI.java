/*    */ package mcframe.clientCore.beans.plaf.metal;
/*    */ 
/*    */ import javax.swing.JButton;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.plaf.ComponentUI;
/*    */ import javax.swing.plaf.metal.MetalScrollBarUI;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCMetalScrollBarUI
/*    */   extends MetalScrollBarUI
/*    */ {
/*    */   public static ComponentUI createUI(JComponent c) {
/* 14 */     return new MCMetalScrollBarUI();
/*    */   }
/*    */ 
/*    */   
/*    */   protected JButton createDecreaseButton(int orientation) {
/* 19 */     this.decreaseButton = new MCMetalScrollButton(orientation, this.scrollBarWidth, 
/* 20 */         this.isFreeStanding);
/* 21 */     return this.decreaseButton;
/*    */   }
/*    */ 
/*    */   
/*    */   protected JButton createIncreaseButton(int orientation) {
/* 26 */     this.increaseButton = new MCMetalScrollButton(orientation, this.scrollBarWidth, 
/* 27 */         this.isFreeStanding);
/* 28 */     return this.increaseButton;
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\plaf\metal\MCMetalScrollBarUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */