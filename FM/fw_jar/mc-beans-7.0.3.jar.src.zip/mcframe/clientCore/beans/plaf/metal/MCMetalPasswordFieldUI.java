/*    */ package mcframe.clientCore.beans.plaf.metal;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.event.FocusAdapter;
/*    */ import java.awt.event.FocusEvent;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.plaf.ComponentUI;
/*    */ import javax.swing.plaf.basic.BasicPasswordFieldUI;
/*    */ import javax.swing.text.JTextComponent;
/*    */ import mcframe.clientCore.beans.plaf.MCGraphicsUtil;
/*    */ 
/*    */ public class MCMetalPasswordFieldUI
/*    */   extends BasicPasswordFieldUI
/*    */ {
/*    */   public static ComponentUI createUI(JComponent c) {
/* 17 */     return new MCMetalPasswordFieldUI();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void paintBackground(Graphics g) {
/* 23 */     super.paintBackground(g);
/* 24 */     MCGraphicsUtil.drawModeLine(g, getComponent());
/*    */   }
/*    */ 
/*    */   
/*    */   protected void installListeners() {
/* 29 */     super.installListeners();
/* 30 */     JTextComponent c = getComponent();
/* 31 */     if (c != null) {
/* 32 */       c.removeFocusListener(_fa);
/* 33 */       c.addFocusListener(_fa);
/*    */     } 
/*    */   }
/*    */   
/* 37 */   private static final FocusAdapter _fa = new FocusAdapter()
/*    */     {
/*    */       public void focusLost(FocusEvent e) {
/* 40 */         focus(e);
/*    */       }
/*    */ 
/*    */       
/*    */       public void focusGained(FocusEvent e) {
/* 45 */         focus(e);
/*    */       }
/*    */ 
/*    */       
/*    */       private void focus(FocusEvent e) {
/* 50 */         Component c = e.getComponent();
/* 51 */         if (c != null) {
/* 52 */           c.repaint();
/*    */         }
/* 54 */         c = e.getOppositeComponent();
/* 55 */         if (c != null) {
/* 56 */           c.repaint();
/*    */         }
/*    */       }
/*    */     };
/*    */ 
/*    */   
/*    */   protected void uninstallDefaults() {
/* 63 */     super.uninstallDefaults();
/* 64 */     JTextComponent c = getComponent();
/* 65 */     if (c != null)
/* 66 */       c.removeFocusListener(_fa); 
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\plaf\metal\MCMetalPasswordFieldUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */