/*     */ package mcframe.clientCore.beans.plaf.metal;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Polygon;
/*     */ import java.awt.RenderingHints;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.metal.MetalComboBoxButton;
/*     */ import javax.swing.plaf.metal.MetalComboBoxIcon;
/*     */ import javax.swing.plaf.metal.MetalComboBoxUI;
/*     */ import mcframe.clientCore.beans.MCBeans;
/*     */ import mcframe.clientCore.beans.table.MCEditorBeans;
/*     */ import sun.swing.StringUIClientPropertyKey;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCMetalComboBoxUI
/*     */   extends MetalComboBoxUI
/*     */ {
/*     */   public static ComponentUI createUI(JComponent c) {
/*  32 */     return new MCMetalComboBoxUI();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   class MCMetalComboBoxIcon
/*     */     extends MetalComboBoxIcon
/*     */   {
/*     */     public final void paintIcon(Component c, Graphics g, int x, int y) {
/*  42 */       Graphics2D g2D = (Graphics2D)g;
/*     */ 
/*     */       
/*  45 */       g2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  50 */       int x0 = 2;
/*  51 */       int y0 = 8;
/*     */       
/*  53 */       int ratio = MCMetalComboBoxUI.this.getRatio();
/*     */       
/*  55 */       int x1 = (3 - x0) * ratio / 100 + x;
/*  56 */       int y1 = (8 - y0) * ratio / 100 + y;
/*     */       
/*  58 */       int x2 = (11 - x0) * ratio / 100 + x;
/*  59 */       int y2 = (8 - y0) * ratio / 100 + y;
/*     */       
/*  61 */       int x3 = (7 - x0) * ratio / 100 + x;
/*  62 */       int y3 = (12 - y0) * ratio / 100 + y;
/*     */       
/*  64 */       Color col = Color.black;
/*  65 */       g.setColor(col);
/*     */       
/*  67 */       g.drawLine(x1, y1, x2, y2);
/*  68 */       g.drawLine(x2, y2, x3, y3);
/*  69 */       g.drawLine(x3, y3, x1, y1);
/*     */       
/*  71 */       Polygon p = new Polygon();
/*  72 */       p.addPoint(x1, y1);
/*  73 */       p.addPoint(x2, y2);
/*  74 */       p.addPoint(x3, y3);
/*  75 */       p.addPoint(x1, y1);
/*     */       
/*  77 */       g.fillPolygon(p);
/*     */     }
/*     */ 
/*     */     
/*     */     public int getIconWidth() {
/*  82 */       int ratio = MCMetalComboBoxUI.this.getRatio();
/*  83 */       return super.getIconWidth() * ratio / 100;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getIconHeight() {
/*  88 */       int ratio = MCMetalComboBoxUI.this.getRatio();
/*  89 */       return super.getIconHeight() * ratio / 100;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JButton createArrowButton() {
/*  97 */     boolean iconOnly = !(!this.comboBox.isEditable() && 
/*  98 */       !MCMetalLookAndFeel.usingOcean());
/*     */     
/* 100 */     JButton button = new MetalComboBoxButton(this.comboBox, 
/* 101 */         new MCMetalComboBoxIcon(), 
/* 102 */         iconOnly, this.currentValuePane, this.listBox);
/*     */     
/* 104 */     if (MCMetalLookAndFeel.usingOcean())
/*     */     {
/*     */       
/* 107 */       button.putClientProperty(NO_BUTTON_ROLLOVER, Boolean.TRUE);
/*     */     }
/* 109 */     updateButtonForOcean(button);
/* 110 */     return button;
/*     */   }
/*     */   
/*     */   private int getRatio() {
/* 114 */     JComponent<Object> c = this.comboBox;
/* 115 */     int ratio = 100;
/* 116 */     if (c.getParent() instanceof MCEditorBeans) {
/* 117 */       MCEditorBeans eb = (MCEditorBeans)c.getParent();
/* 118 */       if (eb.getTable() != null) {
/* 119 */         ratio = eb.getTable().getRatio();
/*     */       }
/*     */     }
/* 122 */     else if (c.getParent() instanceof mcframe.clientCore.beans.MCField) {
/* 123 */       MCBeans bc = (MCBeans)c.getParent();
/* 124 */       if (bc.getRootPanel() != null) {
/* 125 */         ratio = bc.getRootPanel().getLayoutRatio();
/*     */       }
/*     */     } 
/* 128 */     return ratio;
/*     */   }
/*     */ 
/*     */   
/* 132 */   static Object NO_BUTTON_ROLLOVER = new StringUIClientPropertyKey("NoButtonRollover");
/*     */   
/*     */   private void updateButtonForOcean(JButton button) {
/* 135 */     if (MCMetalLookAndFeel.usingOcean())
/*     */     {
/*     */       
/* 138 */       button.setFocusPainted(this.comboBox.isEditable());
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\plaf\metal\MCMetalComboBoxUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */