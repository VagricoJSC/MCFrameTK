/*     */ package mcframe.clientCore.beans.plaf.metal;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.GradientPaint;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Paint;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.Shape;
/*     */ import java.awt.geom.Area;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.LookAndFeel;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.plaf.metal.MetalButtonUI;
/*     */ import javax.swing.text.View;
/*     */ import mcframe.clientCore.beans.MCBeansCompatibilityFactory;
/*     */ import mcframe.clientCore.beans.MCButton;
/*     */ import mcframe.clientCore.beans.MCMode;
/*     */ import mcframe.clientCore.beans.border.MCButtonLineBorder;
/*     */ import mcframe.clientCore.beans.plaf.MCGraphicsUtil;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCMetalButtonUI
/*     */   extends MetalButtonUI
/*     */ {
/*  48 */   private static final MCMetalButtonUI metalButtonUI = new MCMetalButtonUI();
/*     */   
/*     */   static {
/*  51 */     metalButtonUI.setupDefaultButton();
/*     */   }
/*     */   
/*     */   public static MCMetalButtonUI createUI(JComponent c) {
/*  55 */     return metalButtonUI;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  63 */   private MCButton mcbt = MCBeansCompatibilityFactory.createButton("MetalComboBoxButton");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int iconshift;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setupDefaultButton() {
/*  88 */     this.mcbt.setMode(MCMode.ENABLE);
/*     */   }
/*     */ 
/*     */   
/*     */   public void paint(Graphics g, JComponent c) {
/*  93 */     AbstractButton b = (AbstractButton)c;
/*  94 */     if (!(b instanceof MCButton))
/*     */     {
/*  96 */       b.setBackground(this.mcbt.getBackground());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 101 */     if (c instanceof MCButton) {
/* 102 */       ((MCButton)c).getModeInfo().getForeground();
/* 103 */       View v = (View)c.getClientProperty("html");
/* 104 */       if (v != null) {
/* 105 */         Color tmp = UIManager.getColor("textInactiveText");
/*     */ 
/*     */         
/*     */         try {
/* 109 */           UIManager.put("textInactiveText", getDisabledTextColor());
/* 110 */           super.paint(g, c);
/*     */         } finally {
/*     */           
/* 113 */           UIManager.put("textInactiveText", tmp);
/*     */         } 
/*     */       } else {
/*     */         
/* 117 */         super.paint(g, c);
/*     */       } 
/*     */     } else {
/*     */       
/* 121 */       super.paint(g, c);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void update(Graphics g, JComponent c) {
/* 127 */     AbstractButton b = (AbstractButton)c;
/* 128 */     if (b.isContentAreaFilled()) {
/*     */       Color color1, color2;
/*     */       
/* 131 */       if (isComboButton(c)) {
/* 132 */         color1 = UIManager.getColor("Combobutton.background");
/* 133 */         color2 = UIManager.getColor("Combobutton.background2");
/*     */       } else {
/*     */         
/* 136 */         color1 = c.getBackground();
/* 137 */         color2 = color1;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 143 */       if (b.getModel().isRollover()) {
/* 144 */         Color r1 = UIManager.getColor(MCGraphicsUtil.getUIKey(b, "bgrollover"));
/* 145 */         if (r1 != null) {
/* 146 */           color1 = r1;
/*     */         }
/* 148 */         Color r2 = UIManager.getColor(MCGraphicsUtil.getUIKey(b, "bgrollover2"));
/* 149 */         if (r2 != null) {
/* 150 */           color2 = r2;
/*     */         }
/*     */       } 
/* 153 */       paintMain((Graphics2D)g, b, color1, color2);
/*     */       
/* 155 */       paint(g, c);
/*     */     }
/*     */     else {
/*     */       
/* 159 */       super.update(g, c);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void paintButtonPressed(Graphics g, AbstractButton b) {
/* 165 */     if (b.isContentAreaFilled()) {
/*     */       Color st, ed;
/*     */       
/* 168 */       if (isComboButton(b)) {
/* 169 */         st = UIManager.getColor("Combobutton.background");
/* 170 */         ed = UIManager.getColor("Combobutton.background2");
/*     */       } else {
/*     */         
/* 173 */         st = b.getBackground();
/*     */ 
/*     */         
/* 176 */         ed = st;
/*     */       } 
/* 178 */       paintMain((Graphics2D)g, b, ed, st);
/*     */     } else {
/*     */       
/* 181 */       super.paintButtonPressed(g, b);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintFocus(Graphics g, AbstractButton b, Rectangle viewRect, Rectangle textRect, Rectangle iconRect) {
/* 189 */     if (b instanceof MCButton) {
/* 190 */       MCButton mcb = (MCButton)b;
/* 191 */       String grp = mcb.getGroup();
/* 192 */       grp = (grp == null) ? "" : grp;
/*     */       String str1;
/* 194 */       switch ((str1 = grp).hashCode()) { case -1367724422: if (!str1.equals("cancel")) {
/*     */             break;
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 214 */           paintFocusGroup_CANCEL(g, mcb, viewRect, textRect, iconRect);
/*     */           return;
/*     */         case -1140094085:
/*     */           if (!str1.equals("toolbar")) {
/*     */             break;
/*     */           }
/* 220 */           paintFocusGroup_TOOLBAR(g, mcb, viewRect, textRect, iconRect); return;
/*     */         case -907632828:
/*     */           if (!str1.equals("calender_arrow"))
/* 223 */             break;  paintFocusGroup_CALENDER_ARROW(g, mcb, viewRect, textRect, iconRect); return;case 0: if (!str1.equals(""))
/*     */             break;  paintFocusGroup_DEF(g, mcb, viewRect, textRect, iconRect); return;case 99339: if (!str1.equals("del"))
/*     */             break;  paintFocusGroup_DEL(g, mcb, viewRect, textRect, iconRect); return;case 116009: if (!str1.equals("upd"))
/*     */             break;  paintFocusGroup_UPD(g, mcb, viewRect, textRect, iconRect); return;case 3417674: if (!str1.equals("open"))
/*     */             break;  paintFocusGroup_OPEN(g, mcb, viewRect, textRect, iconRect); return;case 3449672: if (!str1.equals("prnt"))
/*     */             break;  paintFocusGroup_PRNT(g, mcb, viewRect, textRect, iconRect); return;
/*     */         case 3538692: if (!str1.equals("srch"))
/*     */             break;  paintFocusGroup_SRCH(g, mcb, viewRect, textRect, iconRect); return;
/*     */         case 93818879: if (!str1.equals("black"))
/* 232 */             break;  paintFocusGroup_BLACK(g, mcb, viewRect, textRect, iconRect); return;case 96006387: if (!str1.equals("dwnld"))
/*     */             break;  paintFocusGroup_DWNLD(g, mcb, viewRect, textRect, iconRect); return;
/*     */         case 98619139: if (!str1.equals("green"))
/* 235 */             break;  paintFocusGroup_GREEN(g, mcb, viewRect, textRect, iconRect); return;case 252090474: if (!str1.equals("no_border"))
/*     */             break;  paintFocusGroup_NO_BORDER(g, mcb, viewRect, textRect, iconRect); return;
/*     */         case 1217720595: if (!str1.equals("calender_date"))
/* 238 */             break;  paintFocusGroup_CALENDER_DATE(g, mcb, viewRect, textRect, iconRect); return; }  paintFocusSub(g, (AbstractButton)mcb, viewRect, textRect, iconRect);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 243 */       paintFocusSub(g, b, viewRect, textRect, iconRect);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void paintFocusGroup_DEF(Graphics g, MCButton b, Rectangle viewRect, Rectangle textRect, Rectangle iconRect) {
/* 249 */     paintFocusSub(g, (AbstractButton)b, viewRect, textRect, iconRect);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintFocusGroup_OPEN(Graphics g, MCButton b, Rectangle viewRect, Rectangle textRect, Rectangle iconRect) {
/* 255 */     paintFocusSub(g, (AbstractButton)b, viewRect, textRect, iconRect);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintFocusGroup_PRNT(Graphics g, MCButton b, Rectangle viewRect, Rectangle textRect, Rectangle iconRect) {
/* 261 */     paintFocusSub(g, (AbstractButton)b, viewRect, textRect, iconRect);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintFocusGroup_GREEN(Graphics g, MCButton b, Rectangle viewRect, Rectangle textRect, Rectangle iconRect) {
/* 267 */     paintFocusSub(g, (AbstractButton)b, viewRect, textRect, iconRect);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void paintFocusGroup_SRCH(Graphics g, MCButton b, Rectangle viewRect, Rectangle textRect, Rectangle iconRect) {
/* 272 */     paintFocusSub(g, (AbstractButton)b, viewRect, textRect, iconRect);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void paintFocusGroup_BLACK(Graphics g, MCButton b, Rectangle viewRect, Rectangle textRect, Rectangle iconRect) {
/* 277 */     paintFocusSub(g, (AbstractButton)b, viewRect, textRect, iconRect);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void paintFocusGroup_UPD(Graphics g, MCButton b, Rectangle viewRect, Rectangle textRect, Rectangle iconRect) {
/* 282 */     paintFocusSub(g, (AbstractButton)b, viewRect, textRect, iconRect);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void paintFocusGroup_DEL(Graphics g, MCButton b, Rectangle viewRect, Rectangle textRect, Rectangle iconRect) {
/* 287 */     paintFocusSub(g, (AbstractButton)b, viewRect, textRect, iconRect);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void paintFocusGroup_CANCEL(Graphics g, MCButton b, Rectangle viewRect, Rectangle textRect, Rectangle iconRect) {
/* 292 */     paintFocusSub(g, (AbstractButton)b, viewRect, textRect, iconRect);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void paintFocusGroup_DWNLD(Graphics g, MCButton b, Rectangle viewRect, Rectangle textRect, Rectangle iconRect) {
/* 297 */     paintFocusSub(g, (AbstractButton)b, viewRect, textRect, iconRect);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void paintFocusGroup_TOOLBAR(Graphics g, MCButton b, Rectangle viewRect, Rectangle textRect, Rectangle iconRect) {
/* 302 */     paintFocusSub(g, (AbstractButton)b, viewRect, textRect, iconRect);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void paintFocusGroup_CALENDER_ARROW(Graphics g, MCButton b, Rectangle viewRect, Rectangle textRect, Rectangle iconRect) {
/* 307 */     paintFocusSub(g, (AbstractButton)b, viewRect, textRect, iconRect);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void paintFocusGroup_CALENDER_DATE(Graphics g, MCButton b, Rectangle viewRect, Rectangle textRect, Rectangle iconRect) {
/* 312 */     paintFocusSub(g, (AbstractButton)b, viewRect, textRect, iconRect);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void paintFocusGroup_NO_BORDER(Graphics g, MCButton b, Rectangle viewRect, Rectangle textRect, Rectangle iconRect) {
/* 317 */     paintFocusSub(g, (AbstractButton)b, viewRect, textRect, iconRect);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintFocusSub(Graphics g, AbstractButton b, Rectangle viewRect, Rectangle textRect, Rectangle iconRect) {
/* 323 */     paintFocusRect(g, b, viewRect, textRect, iconRect);
/* 324 */     MCGraphicsUtil.paintCornerMark(g, b, viewRect, "focused", null, 
/* 325 */         MCGraphicsUtil.CornerMarkLocation.INNNER);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void paintFocusRect(Graphics g, AbstractButton b, Rectangle viewRect, Rectangle textRect, Rectangle iconRect) {
/* 331 */     if (MCGraphicsUtil.getUIBeansBoolean(b, "focused.line.use", false)) {
/* 332 */       Color c1 = MCGraphicsUtil.getUIBeansColor(b, "focused.line.color");
/* 333 */       if (c1 != null) {
/* 334 */         Graphics ng = g.create();
/*     */         try {
/* 336 */           ng.setColor(c1);
/* 337 */           Insets insets = b.getInsets();
/* 338 */           ng.drawRect(insets.left, insets.top, 
/* 339 */               b.getWidth() - insets.left - insets.right - 1, 
/* 340 */               b.getHeight() - insets.top - insets.bottom - 1);
/*     */         } finally {
/*     */           
/* 343 */           ng.dispose();
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void paintMain(Graphics2D g2, AbstractButton c, Color bg1, Color bg2) {
/* 351 */     if (bg1 == null) {
/* 352 */       bg1 = Color.white;
/*     */     }
/* 354 */     if (bg2 == null) {
/* 355 */       bg2 = Color.white;
/*     */     }
/* 357 */     if (isComboButton(c)) {
/* 358 */       paintComboButton(g2, c, bg1, bg2);
/*     */     }
/* 360 */     else if (c instanceof MCButton) {
/* 361 */       MCButton mcb = (MCButton)c;
/* 362 */       String grp = mcb.getGroup();
/* 363 */       grp = (grp == null) ? "" : grp;
/*     */       String str1;
/* 365 */       switch ((str1 = grp).hashCode()) { case -1367724422: if (!str1.equals("cancel")) {
/*     */             break;
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 385 */           paintGroup_CANCEL(g2, (AbstractButton)mcb, bg1, bg2);
/*     */           return;
/*     */         case -1140094085:
/*     */           if (!str1.equals("toolbar")) {
/*     */             break;
/*     */           }
/* 391 */           paintGroup_TOOLBAR(g2, (AbstractButton)mcb, bg1, bg2);
/*     */           return;
/*     */         case -907632828:
/*     */           if (!str1.equals("calender_arrow")) {
/*     */             break;
/*     */           }
/* 397 */           paintGroup_CALENDER_ARROW(g2, (AbstractButton)mcb, bg1, bg2); return;case -213290394: if (!str1.equals("headerbar"))
/*     */             break;  paintGroup_HEADERBAR(g2, (AbstractButton)mcb, bg1, bg2); return;case 0: if (!str1.equals(""))
/*     */             break;  paintGroup_DEF(g2, (AbstractButton)mcb, bg1, bg2); return;case 99339: if (!str1.equals("del"))
/*     */             break;  paintGroup_DEL(g2, (AbstractButton)mcb, bg1, bg2); return;case 116009: if (!str1.equals("upd"))
/*     */             break;  paintGroup_UPD(g2, (AbstractButton)mcb, bg1, bg2); return;case 3417674: if (!str1.equals("open"))
/*     */             break;  paintGroup_OPEN(g2, (AbstractButton)mcb, bg1, bg2); return;case 3449672: if (!str1.equals("prnt"))
/*     */             break;  paintGroup_PRNT(g2, (AbstractButton)mcb, bg1, bg2); return;case 3538692: if (!str1.equals("srch"))
/*     */             break;  paintGroup_SRCH(g2, (AbstractButton)mcb, bg1, bg2); return;
/*     */         case 93818879: if (!str1.equals("black"))
/* 406 */             break;  paintGroup_BLACK(g2, (AbstractButton)mcb, bg1, bg2); return;case 96006387: if (!str1.equals("dwnld"))
/*     */             break;  paintGroup_DWNLD(g2, (AbstractButton)mcb, bg1, bg2); return;
/*     */         case 98619139: if (!str1.equals("green"))
/* 409 */             break;  paintGroup_GREEN(g2, (AbstractButton)mcb, bg1, bg2); return;case 252090474: if (!str1.equals("no_border"))
/*     */             break;  paintGroup_NO_BORDER(g2, (AbstractButton)mcb, bg1, bg2); return;
/*     */         case 1217720595: if (!str1.equals("calender_date"))
/* 412 */             break;  paintGroup_CALENDER_DATE(g2, (AbstractButton)mcb, bg1, bg2); return; }  paintCenter(g2, (AbstractButton)mcb, bg1, bg2);
/*     */     }
/*     */     else {
/*     */       
/* 416 */       paintCenter(g2, c, bg1, bg2);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static boolean isComboButton(JComponent c) {
/* 421 */     return !(!"MCComboBox.arrowButton".equals(c.getName()) && 
/* 422 */       !(c instanceof javax.swing.plaf.metal.MetalComboBoxButton));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintComboButton(Graphics2D g2, AbstractButton c, Color bg1, Color bg2) {
/* 434 */     paintUpGradient(g2, c, bg1, bg2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintGroup_DEF(Graphics2D g2, AbstractButton c, Color bg1, Color bg2) {
/* 445 */     paintCenter(g2, c, bg1, bg2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintGroup_OPEN(Graphics2D g2, AbstractButton c, Color bg1, Color bg2) {
/* 457 */     paintCenter(g2, c, bg1, bg2);
/* 458 */     paintLine(g2, c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintGroup_PRNT(Graphics2D g2, AbstractButton c, Color bg1, Color bg2) {
/* 471 */     paintCenter(g2, c, bg1, bg2);
/* 472 */     paintLine(g2, c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintGroup_GREEN(Graphics2D g2, AbstractButton c, Color bg1, Color bg2) {
/* 485 */     paintCenter(g2, c, bg1, bg2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintGroup_SRCH(Graphics2D g2, AbstractButton c, Color bg1, Color bg2) {
/* 497 */     paintCenter(g2, c, bg1, bg2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintGroup_BLACK(Graphics2D g2, AbstractButton c, Color bg1, Color bg2) {
/* 510 */     paintCenter(g2, c, bg1, bg2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintGroup_UPD(Graphics2D g2, AbstractButton c, Color bg1, Color bg2) {
/* 521 */     paintCenter(g2, c, bg1, bg2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintGroup_DEL(Graphics2D g2, AbstractButton c, Color bg1, Color bg2) {
/* 533 */     paintCenter(g2, c, bg1, bg2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintGroup_CANCEL(Graphics2D g2, AbstractButton c, Color bg1, Color bg2) {
/* 546 */     paintCenter(g2, c, bg1, bg2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintGroup_DWNLD(Graphics2D g2, AbstractButton c, Color bg1, Color bg2) {
/* 559 */     paintCenter(g2, c, bg1, bg2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintGroup_TOOLBAR(Graphics2D g2, AbstractButton c, Color bg1, Color bg2) {
/* 572 */     int h = c.getHeight();
/* 573 */     int hh = h >> 1;
/*     */ 
/*     */ 
/*     */     
/* 577 */     int dr = bg1.getRed() - bg2.getRed() >> 2;
/* 578 */     int dg = bg1.getGreen() - bg2.getGreen() >> 2;
/* 579 */     int db = bg1.getBlue() - bg2.getBlue() >> 2;
/* 580 */     Color mid = new Color(bg2.getRed() + dr, bg2.getGreen() + dg, bg2.getBlue() + db);
/* 581 */     paintCenter(g2, c, new GradientPaint(0.0F, 0.0F, bg1, 0.0F, hh, mid), 
/* 582 */         new GradientPaint(0.0F, 0.0F, mid, 0.0F, hh, bg2));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintGroup_HEADERBAR(Graphics2D g2, AbstractButton c, Color bg1, Color bg2) {
/* 595 */     paintCenter(g2, c, bg1, bg2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintGroup_NO_BORDER(Graphics2D g2, AbstractButton c, Color bg1, Color bg2) {
/* 607 */     paintCenter(g2, c, bg1, bg2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintGroup_CALENDER_ARROW(Graphics2D g2, AbstractButton c, Color bg1, Color bg2) {
/* 619 */     paintCenter(g2, c, bg1, bg2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintGroup_CALENDER_DATE(Graphics2D g2, AbstractButton c, Color bg1, Color bg2) {
/* 632 */     paintCenter(g2, c, bg1, bg2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void paintCenter(Graphics2D g2, AbstractButton c, Color bg1, Color bg2) {
/* 644 */     if (c.isFocusOwner() || c.getModel().isRollover()) {
/* 645 */       paintUpGradient(g2, c, bg1, bg2);
/*     */     } else {
/*     */       
/* 648 */       paintLinerGradient(g2, c, bg1, bg2);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void paintLinerGradient(Graphics2D g2, JComponent c, Color bg1, Color bg2) {
/* 661 */     g2.setPaint(MCGraphicsUtil.createLinerGradientPaint(c.getHeight(), bg1, bg2));
/*     */     
/* 663 */     paintCenterImpl(g2, c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void paintUpGradient(Graphics2D g2, JComponent c, Color bg1, Color bg2) {
/* 676 */     g2.setPaint(MCGraphicsUtil.createUpGradientPaint(c.getHeight(), bg1, bg2));
/* 677 */     paintCenterImpl(g2, c);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void paintCenterImpl(Graphics2D g2, JComponent c) {
/* 683 */     Border bdr = c.getBorder();
/* 684 */     if (bdr instanceof MCButtonLineBorder && (
/* 685 */       (MCButtonLineBorder)bdr).getRoundedCorners()) {
/* 686 */       MCButtonLineBorder b = (MCButtonLineBorder)bdr;
/* 687 */       Shape cs = b.getOuterArea(0, 0, c.getWidth(), c.getHeight());
/* 688 */       MCGraphicsUtil.draw(g2, cs, c.getWidth(), c.getHeight(), null);
/*     */     }
/*     */     else {
/*     */       
/* 692 */       g2.fillRect(0, 0, c.getWidth(), c.getHeight());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void paintCenter(Graphics2D g2, JComponent c, Paint p1, Paint p2) {
/* 699 */     Border bdr = c.getBorder();
/* 700 */     int halfh = c.getHeight() >> 1;
/* 701 */     if (bdr instanceof MCButtonLineBorder && (
/* 702 */       (MCButtonLineBorder)bdr).getRoundedCorners()) {
/* 703 */       MCButtonLineBorder b = (MCButtonLineBorder)bdr;
/* 704 */       Shape cs = b.getOuterArea(0, 0, c.getWidth(), c.getHeight());
/*     */       
/* 706 */       Area up = new Area(cs);
/* 707 */       up.subtract(new Area(new Rectangle(0, halfh, c.getWidth(), halfh)));
/* 708 */       g2.getClipBounds(up.getBounds());
/* 709 */       g2.setPaint(p1);
/* 710 */       MCGraphicsUtil.draw(g2, up, c.getWidth(), halfh, null);
/* 711 */       Area btm = new Area(cs);
/* 712 */       btm.subtract(new Area(new Rectangle(0, 0, c.getWidth(), halfh)));
/* 713 */       g2.getClipBounds(btm.getBounds());
/* 714 */       g2.setPaint(p2);
/* 715 */       MCGraphicsUtil.draw(g2, btm, c.getWidth(), halfh, null);
/*     */     }
/*     */     else {
/*     */       
/* 719 */       g2.setPaint(p1);
/* 720 */       g2.fillRect(0, 0, c.getWidth(), halfh);
/* 721 */       g2.setPaint(p2);
/* 722 */       g2.fillRect(0, halfh, c.getWidth(), halfh);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintLine(Graphics2D g2, JComponent c) {
/* 734 */     if (c instanceof MCButton) {
/* 735 */       MCButton mb = (MCButton)c;
/* 736 */       if (mb.isFocusPainted() && mb.hasFocus()) {
/*     */         
/* 738 */         paintLine(g2, (AbstractButton)mb, mb.getFocusedGrpLine(), 
/* 739 */             new Rectangle(4, 0, 0, mb.getHeight()), 
/* 740 */             MCGraphicsUtil.Corners.LEFT);
/*     */       } else {
/*     */         
/* 743 */         paintLine(g2, (AbstractButton)mb, mb.getGrpLine(), new Rectangle(4, 0, 0, mb.getHeight()), 
/* 744 */             MCGraphicsUtil.Corners.LEFT);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void paintLine(Graphics g, AbstractButton mb, Color bg, Rectangle rect, MCGraphicsUtil.Corners cnrs) {
/* 753 */     Color old = g.getColor();
/* 754 */     if (bg != null) {
/* 755 */       if (!mb.isEnabled()) {
/* 756 */         bg = getMixedColor(bg, 0.5F, old, 0.5F);
/*     */       }
/*     */       try {
/* 759 */         g.setColor(bg);
/* 760 */         MCGraphicsUtil.paintLine(g, rect, cnrs, 5);
/*     */       } finally {
/*     */         
/* 763 */         g.setColor(old);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private Color getMixedColor(Color c1, float pct1, Color c2, float pct2) {
/* 769 */     float[] clr1 = c1.getComponents(null);
/* 770 */     float[] clr2 = c2.getComponents(null);
/* 771 */     for (int i = 0; i < clr1.length; i++) {
/* 772 */       clr1[i] = clr1[i] * pct1 + clr2[i] * pct2;
/*     */     }
/* 774 */     return new Color(clr1[0], clr1[1], clr1[2], clr1[3]);
/*     */   }
/*     */   
/*     */   MCMetalButtonUI() {
/* 778 */     this.iconshift = 5;
/*     */     this.mcbt.resetBorder();
/*     */     this.mcbt.setMode(MCMode.ENABLE);
/*     */   }
/*     */   protected void paintIcon(Graphics g, JComponent c, Rectangle iconRect) {
/* 783 */     if (c instanceof MCButton) {
/* 784 */       MCButton b = (MCButton)c;
/* 785 */       if ("toolbar".equals(b.getGroup()) && 
/* 786 */         !MCStringUtil.isNull(b.getText()))
/*     */       {
/* 788 */         iconRect.x = (c.getInsets()).left + this.iconshift;
/*     */       }
/*     */     } 
/* 791 */     super.paintIcon(g, c, iconRect);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void paintText(Graphics g, JComponent c, Rectangle textRect, String text) {
/* 797 */     if (c instanceof MCButton) {
/* 798 */       MCButton mCButton = (MCButton)c;
/* 799 */       if ("toolbar".equals(mCButton.getGroup())) {
/* 800 */         MCStringUtil.isNull(mCButton.getText());
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 807 */     super.paintText(g, c, textRect, text);
/*     */     
/* 809 */     AbstractButton b = (AbstractButton)c;
/* 810 */     if (!(b instanceof MCButton)) {
/* 811 */       if (b.isFocusPainted() && b.hasFocus()) {
/*     */         
/* 813 */         b.setForeground(this.mcbt.getFocusedForeground());
/*     */       }
/*     */       else {
/*     */         
/* 817 */         b.setForeground(this.mcbt.getForeground());
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Color getDisabledTextColor() {
/* 824 */     return super.getDisabledTextColor();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean contains(JComponent c, int x, int y) {
/* 829 */     Border b = c.getBorder();
/* 830 */     if (b instanceof MCButtonLineBorder) {
/* 831 */       MCButtonLineBorder lb = (MCButtonLineBorder)b;
/* 832 */       if (lb.getRoundedCorners()) {
/* 833 */         Shape s = lb.getOuterArea(c.getX(), c.getY(), c.getWidth(), 
/* 834 */             c.getHeight());
/* 835 */         return s.contains((c.getX() + x), (c.getY() + y));
/*     */       } 
/*     */     } 
/* 838 */     return super.contains(c, x, y);
/*     */   }
/*     */ 
/*     */   
/*     */   public void installDefaults(AbstractButton b) {
/* 843 */     super.installDefaults(b);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 848 */     LookAndFeel.installProperty(b, "opaque", Boolean.FALSE);
/* 849 */     if (b instanceof javax.swing.plaf.basic.BasicArrowButton) {
/* 850 */       LookAndFeel.installColors(b, "ArrowButton.background", 
/* 851 */           "ArrowButton.foreground");
/*     */     }
/* 853 */     else if (isComboButton(b)) {
/* 854 */       b.setBorder(UIManager.getBorder("Combobutton.border"));
/*     */ 
/*     */     
/*     */     }
/* 858 */     else if (b instanceof mcframe.clientCore.beans.table.MCCellRendererButton) {
/* 859 */       b.setBorder(this.mcbt.getBorder());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\plaf\metal\MCMetalButtonUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */