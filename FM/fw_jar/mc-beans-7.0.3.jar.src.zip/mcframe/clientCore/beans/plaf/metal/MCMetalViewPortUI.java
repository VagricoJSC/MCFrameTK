/*    */ package mcframe.clientCore.beans.plaf.metal;
/*    */ 
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.plaf.ComponentUI;
/*    */ import javax.swing.plaf.ViewportUI;
/*    */ import javax.swing.plaf.basic.BasicViewportUI;
/*    */ import mcframe.clientCore.resource.MCConst;
/*    */ 
/*    */ public class MCMetalViewPortUI
/*    */   extends BasicViewportUI {
/*    */   private static ViewportUI viewportUI;
/*    */   
/*    */   public static ComponentUI createUI(JComponent c) {
/* 14 */     if (viewportUI == null) {
/* 15 */       viewportUI = new MCMetalViewPortUI();
/*    */     }
/* 17 */     return viewportUI;
/*    */   }
/*    */ 
/*    */   
/*    */   protected void installDefaults(JComponent c) {
/* 22 */     super.installDefaults(c);
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 27 */     c.setOpaque(MCConst.beans.getBoolean("viewport.opaque", false));
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\plaf\metal\MCMetalViewPortUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */