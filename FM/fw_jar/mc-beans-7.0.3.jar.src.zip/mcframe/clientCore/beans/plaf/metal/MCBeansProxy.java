/*    */ package mcframe.clientCore.beans.plaf.metal;
/*    */ 
/*    */ import java.awt.Dimension;
/*    */ import mcframe.clientCore.beans.AbsMCPackageProxy;
/*    */ import mcframe.clientCore.beans.MCCalendarField;
/*    */ import mcframe.clientCore.beans.MCModelessFrame;
/*    */ 
/*    */ class MCBeansProxy
/*    */   extends AbsMCPackageProxy
/*    */ {
/* 11 */   static MCBeansProxy PROXY = new MCBeansProxy();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected MCModelessFrame getMainMenuFrame() {
/* 18 */     return super.getMainMenuFrame();
/*    */   }
/*    */ 
/*    */   
/*    */   protected Dimension getAmPmDimension(MCCalendarField<?> cf) {
/* 23 */     return super.getAmPmDimension(cf);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\plaf\metal\MCBeansProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */