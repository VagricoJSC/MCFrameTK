/*    */ package mcframe.clientCore.beans.text;
/*    */ 
/*    */ import java.awt.Component;
/*    */ 
/*    */ public abstract class AbsMCPackageProxy
/*    */ {
/*    */   protected void setPasteActionProcessing(MCTextDocument document, boolean flg) {
/*  8 */     document.setPasteActionProcessing(flg);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void installInputMethod(MCIMDelegate delegate, Component compo, MCInputMethodType type) {
/* 13 */     delegate.installInputMethod(compo, type);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void uninstallInputMethod(MCIMDelegate delegate, Component compo, MCInputMethodType type) {
/* 18 */     delegate.uninstallInputMethod(compo, type);
/*    */   }
/*    */   
/*    */   protected MCIMDelegate createIMDelegate() {
/* 22 */     return new MCIMDelegate();
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\text\AbsMCPackageProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */