package mcframe.clientCore.beans.text;

import java.util.List;
import java.util.regex.Pattern;
import javax.swing.JComponent;
import mcframe.clientCore.beans.MCBeans;
import mcframe.clientCore.beans.MCModeInfo;
import mcframe.commonCore.notice.MCMessageList;

public interface MCDocumentBeans extends MCBeans {
  public static final String ACCEPT_KEY = "accept";
  
  public static final String EXCEPT_KEY = "except";
  
  JComponent getComponent();
  
  List<Pattern> getAcceptPattern();
  
  void setAcceptPattern(List<Pattern> paramList);
  
  void addAcceptPattern(String paramString);
  
  void addAcceptPattern(String paramString, int paramInt);
  
  List<Character> getExceptCharacter();
  
  void setExceptCharacter(List<Character> paramList);
  
  void setExceptCharacter(char[] paramArrayOfchar);
  
  void addExceptCharacter(char paramChar);
  
  MCValueChecker getValueChecker();
  
  MCModeInfo getModeInfo();
  
  boolean isInputMethodEditing();
  
  String getText();
  
  MCMessageList checkInputValue(String paramString);
  
  String convToMaximumValues(String paramString1, int paramInt, String paramString2);
  
  boolean isAutoFocus();
  
  void setAutoFocus(boolean paramBoolean);
  
  void transferFocus();
  
  int getLength();
  
  void doAfterInsert();
  
  @Deprecated
  boolean _isLastInsert();
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\text\MCDocumentBeans.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */