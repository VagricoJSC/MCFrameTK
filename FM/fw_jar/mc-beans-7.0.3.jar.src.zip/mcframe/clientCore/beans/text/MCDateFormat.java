/*     */ package mcframe.clientCore.beans.text;
/*     */ 
/*     */ import java.text.DateFormat;
/*     */ import mcframe.clientCore.sys.MCSys;
/*     */ import mcframe.commonCore.lang.MCCalendarDate;
/*     */ import mcframe.commonCore.lang.MCDate;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCDateFormat
/*     */   extends MCCalendarFormat<MCDate>
/*     */ {
/*     */   private static final char MILLI_SECOND = 'S';
/*     */   
/*     */   public MCDate doInputParse(String value) {
/*  39 */     if (MCStringUtil.isNull(value)) {
/*  40 */       return null;
/*     */     }
/*     */     
/*  43 */     return doParse(value, getInputFormat());
/*     */   }
/*     */ 
/*     */   
/*     */   public MCDate doOutputParse(String value) {
/*  48 */     if (MCStringUtil.isNull(value) || value.equals(getOutputBlank())) {
/*  49 */       return null;
/*     */     }
/*     */     
/*  52 */     return doParse(value, getOutputFormat());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCDate doParse(String value, mcframe.commonCore.lang.MCDateFormat format) {
/*  66 */     MCDate v = MCDate.valueOf(value, format);
/*  67 */     if (value.equals(v.toString((DateFormat)format))) {
/*  68 */       return v;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  75 */     String p = format.toPattern();
/*  76 */     if (p == null || p.contains("y") || !p.contains("M")) {
/*  77 */       return v;
/*     */     }
/*     */     
/*  80 */     mcframe.commonCore.lang.MCDateFormat nf = 
/*  81 */       mcframe.commonCore.lang.MCDateFormat.create(
/*  82 */         String.valueOf(p) + "_yyyy", MCSys.user.locale());
/*     */     
/*  84 */     int y = 0;
/*  85 */     int diff = MCDate.today().getMonth() - 
/*  86 */       MCDate.valueOf(String.valueOf(value) + "_2000", nf).getMonth();
/*  87 */     if (diff <= -6) {
/*  88 */       y = -1;
/*     */     }
/*  90 */     else if (diff >= 7) {
/*  91 */       y = 1;
/*     */     } 
/*     */     
/*  94 */     MCDate ny = (MCDate)MCDate.today().addYear(y);
/*  95 */     MCDate nv = (MCDate)MCDate.valueOf(String.valueOf(value) + "_2000", nf).modYear(ny.getYear());
/*     */     
/*  97 */     if (value.equals(nv.toString((DateFormat)format))) {
/*  98 */       return nv;
/*     */     }
/*     */     
/* 101 */     throw new MCException(Core_Msg_FW_A.FCBFC0012, new Object[] { value, p });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCalendarPattern(MCCalendarPattern pattern) {
/* 115 */     if (pattern != null) {
/*     */       
/* 117 */       String i_ptn = pattern.getInputPattern();
/* 118 */       if (containsMilliSecond(i_ptn)) {
/* 119 */         throw new MCException(Core_Msg_FW_A.FCBAC0207, new Object[0]);
/*     */       }
/* 121 */       String o_ptn = pattern.getOutputPattern();
/* 122 */       if (containsMilliSecond(o_ptn)) {
/* 123 */         throw new MCException(Core_Msg_FW_A.FCBAC0207, new Object[0]);
/*     */       }
/* 125 */       super.setCalendarPattern(pattern);
/*     */     } else {
/* 127 */       throw new MCException(Core_Msg_FW_A.FCBAC0191, new Object[0]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean containsMilliSecond(String pattern) {
/* 144 */     if (!MCStringUtil.isNull(pattern)) {
/* 145 */       char[] ps = pattern.toCharArray(); byte b; int i; char[] arrayOfChar1;
/* 146 */       for (i = (arrayOfChar1 = ps).length, b = 0; b < i; ) { char p = arrayOfChar1[b];
/* 147 */         if (p == 'S')
/* 148 */           return true; 
/*     */         b++; }
/*     */     
/*     */     } 
/* 152 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\text\MCDateFormat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */