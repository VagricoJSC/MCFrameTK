/*     */ package mcframe.clientCore.beans.text;
/*     */ 
/*     */ import java.text.DateFormat;
/*     */ import mcframe.clientCore.sys.MCSys;
/*     */ import mcframe.commonCore.lang.MCCalendarDate;
/*     */ import mcframe.commonCore.lang.MCDateFormat;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MCCalendarFormat<T extends MCCalendarDate<?>>
/*     */ {
/*     */   private MCCalendarPattern _pattern;
/*  28 */   private MCDateFormat _input_format = null;
/*  29 */   private MCDateFormat _output_format = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCCalendarFormat() {
/*  38 */     this._pattern = MCCalendarPattern.create("YMD");
/*     */   }
/*     */   
/*     */   protected MCDateFormat getInputFormat() {
/*  42 */     if (this._input_format == null || 
/*  43 */       !MCStringUtil.same(this._input_format.toPattern(), getInputPattern())) {
/*  44 */       this._input_format = 
/*  45 */         MCDateFormat.create(getInputPattern(), 
/*  46 */           MCSys.user.locale());
/*     */     }
/*  48 */     return this._input_format;
/*     */   }
/*     */   protected MCDateFormat getOutputFormat() {
/*  51 */     if (this._output_format == null || 
/*  52 */       !MCStringUtil.same(this._output_format.toPattern(), getOutputPattern())) {
/*  53 */       this._output_format = 
/*  54 */         MCDateFormat.create(getOutputPattern(), 
/*  55 */           MCSys.user.locale());
/*     */     }
/*  57 */     return this._output_format;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCalendarPattern(MCCalendarPattern pattern) {
/*  70 */     if (pattern != null) {
/*  71 */       this._pattern = pattern;
/*     */     } else {
/*  73 */       throw new MCException(Core_Msg_FW_A.FCBAC0191, new Object[0]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCCalendarPattern getCalendarPattern() {
/*  86 */     return this._pattern;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getID() {
/*  97 */     return getCalendarPattern().getID();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getInputPattern() {
/* 108 */     return getCalendarPattern().getInputPattern();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getOutputPattern() {
/* 119 */     return getCalendarPattern().getOutputPattern();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getOutputBlank() {
/* 130 */     return getCalendarPattern().getOutputBlank();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getInputBase() {
/* 141 */     return getCalendarPattern().getInputBase();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getOutputBase() {
/* 152 */     return getCalendarPattern().getOutputBase();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String doInputFormat(MCCalendarDate<?> value) {
/* 164 */     return (value != null) ? value.toString((DateFormat)getInputFormat()) : "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String doOutputFormat(MCCalendarDate<?> value) {
/* 176 */     return (value != null) ? 
/* 177 */       value.toString((DateFormat)getOutputFormat()) : getOutputBlank();
/*     */   }
/*     */   
/*     */   public abstract T doInputParse(String paramString);
/*     */   
/*     */   public abstract T doOutputParse(String paramString);
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\text\MCCalendarFormat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */