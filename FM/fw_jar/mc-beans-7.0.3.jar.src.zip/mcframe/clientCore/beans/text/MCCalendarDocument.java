/*     */ package mcframe.clientCore.beans.text;
/*     */ 
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.text.AbstractDocument;
/*     */ import javax.swing.text.AttributeSet;
/*     */ import javax.swing.text.BadLocationException;
/*     */ import javax.swing.text.PlainDocument;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCCalendarField;
/*     */ import mcframe.commonCore.lang.MCCalendarDate;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.util.MCCollectionUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCCalendarDocument<T extends MCCalendarDate<?>>
/*     */   extends PlainDocument
/*     */ {
/*  29 */   private static final Character[] ENABLE_FORMAT_CHAR = new Character[] {
/*  30 */       Character.valueOf('y'), Character.valueOf('M'), Character.valueOf('d'), Character.valueOf('H'), Character.valueOf('h'), Character.valueOf('m'), Character.valueOf('s'), Character.valueOf('S')
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final MCCalendarDocumentBeans<T> _compo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean _event = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean _editable = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCCalendarDocument(MCCalendarDocumentBeans<T> compo) {
/*  65 */     this._compo = compo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCCalendarDocumentBeans<T> getBeans() {
/*  76 */     return this._compo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEditable(boolean editable) {
/*  88 */     this._editable = editable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEditable() {
/*  99 */     return this._editable;
/*     */   }
/*     */ 
/*     */   
/*     */   public void remove(int offs, int len) throws BadLocationException {
/* 104 */     if (!isEditable()) {
/*     */       return;
/*     */     }
/* 107 */     super.remove(offs, len);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void insertString(int offs, String str, AttributeSet a) throws BadLocationException {
/* 113 */     if (!isEditable()) {
/*     */       return;
/*     */     }
/*     */     
/* 117 */     if (this._event) {
/*     */       return;
/*     */     }
/* 120 */     if (a != null) {
/* 121 */       super.insertString(offs, str, a);
/*     */       return;
/*     */     } 
/*     */     try {
/* 125 */       this._event = true;
/* 126 */       if (!getBeans().isMCFocusOwner()) {
/* 127 */         super.insertString(offs, str, a);
/*     */         
/*     */         return;
/*     */       } 
/* 131 */       MCCalendarDocumentBeans<T> c = getBeans();
/*     */       
/* 133 */       if (offs < 0 || MCStringUtil.isNull(str)) {
/* 134 */         super.insertString(offs, str, a);
/* 135 */         c.doAfterInsert();
/*     */         return;
/*     */       } 
/* 138 */       StringBuilder sb = new StringBuilder(c.getText());
/* 139 */       boolean isEnd = (sb.length() == offs);
/* 140 */       String exstr = getExtractText(str);
/* 141 */       sb.insert(offs, exstr);
/* 142 */       if (checkInputValue(sb.toString())) {
/* 143 */         super.insertString(offs, exstr, a);
/* 144 */         if (isLastInsert() && isEnd && c instanceof MCCalendarField) {
/*     */           
/* 146 */           MCCalendarField<?> cf = (MCCalendarField)c;
/* 147 */           if (cf.isAmPmField()) {
/* 148 */             String s = str.trim().toLowerCase();
/* 149 */             if (s.endsWith("am")) {
/* 150 */               cf.selectAM();
/*     */             }
/* 152 */             else if (s.endsWith("pm")) {
/* 153 */               cf.selectPM();
/*     */             } 
/*     */           } 
/*     */         } 
/* 157 */         c.doAfterInsert();
/*     */       } 
/*     */     } finally {
/*     */       
/* 161 */       this._event = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getExtractText(String value) {
/* 174 */     if (MCStringUtil.isNull(value)) {
/* 175 */       return null;
/*     */     }
/* 177 */     StringBuilder sb = new StringBuilder(); byte b; int i; char[] arrayOfChar;
/* 178 */     for (i = (arrayOfChar = value.toCharArray()).length, b = 0; b < i; ) { char c = arrayOfChar[b];
/* 179 */       if (isNumber(c))
/* 180 */         sb.append(c); 
/*     */       b++; }
/*     */     
/* 183 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean checkInputValue(String value) {
/* 196 */     if (value == null) {
/* 197 */       return true;
/*     */     }
/* 199 */     MCCalendarDocumentBeans<T> c = getBeans();
/* 200 */     MCCalendarFormat<T> f = c.getCalendarFormat();
/* 201 */     String p = trimFormat(f.getInputPattern());
/* 202 */     int l = value.length();
/* 203 */     if (l > p.length()) {
/* 204 */       return false;
/*     */     }
/* 206 */     if (l < p.length()) {
/* 207 */       return true;
/*     */     }
/* 209 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isNumber(char c) {
/* 227 */     return (Character.isDigit(c) && 
/* 228 */       Character.UnicodeBlock.of(c) == Character.UnicodeBlock.BASIC_LATIN);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String trimFormat(String format) {
/* 241 */     StringBuilder sb = new StringBuilder();
/* 242 */     if (format == null)
/* 243 */       return sb.toString();  byte b; int i;
/*     */     char[] arrayOfChar;
/* 245 */     for (i = (arrayOfChar = format.toCharArray()).length, b = 0; b < i; ) { char c = arrayOfChar[b];
/* 246 */       if (MCCollectionUtil.contains(Character.valueOf(c), (Object[])ENABLE_FORMAT_CHAR))
/* 247 */         sb.append(c); 
/*     */       b++; }
/*     */     
/* 250 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public void insertUpdate(AbstractDocument.DefaultDocumentEvent chng, AttributeSet attr) {
/* 255 */     if (attr != null || !getBeans().isAutoFocus()) {
/* 256 */       super.insertUpdate(chng, attr);
/*     */       return;
/*     */     } 
/* 259 */     final MCCalendarDocumentBeans<T> c = getBeans();
/*     */     try {
/* 261 */       c.setAutoFocus(false);
/* 262 */       if (isLastInsert()) {
/* 263 */         super.insertUpdate(chng, (AttributeSet)null);
/*     */         
/* 265 */         SwingUtilities.invokeLater(new Runnable() {
/*     */               public void run() {
/*     */                 try {
/* 268 */                   c.getComponent().transferFocus();
/*     */                 }
/* 270 */                 catch (Exception e) {
/* 271 */                   MCBeansUtil.handle(c.getComponent(), e);
/*     */                 } 
/*     */               }
/*     */             });
/*     */       } 
/*     */     } finally {
/*     */       
/* 278 */       c.setAutoFocus(true);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isLastInsert() {
/* 290 */     MCCalendarDocumentBeans<T> c = getBeans();
/* 291 */     String t = c.getText();
/* 292 */     int l = (t != null) ? t.length() : 0;
/*     */     
/* 294 */     return (l == c.getPattern().length());
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\text\MCCalendarDocument.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */