package mcframe.clientCore.beans.text;

import javax.swing.JComponent;
import mcframe.clientCore.beans.MCRowBeans;
import mcframe.commonCore.lang.MCCalendarDate;

public interface MCCalendarDocumentBeans<T extends MCCalendarDate<?>> extends MCRowBeans {
  JComponent getComponent();
  
  boolean isMCFocusOwner();
  
  String getText();
  
  boolean isAutoFocus();
  
  void setAutoFocus(boolean paramBoolean);
  
  MCCalendarFormat<T> getCalendarFormat();
  
  String getPattern();
  
  MCCalendarValidator getCalendarValidator();
  
  String doFormat(MCCalendarDate<?> paramMCCalendarDate);
  
  void doAfterInsert();
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\text\MCCalendarDocumentBeans.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */