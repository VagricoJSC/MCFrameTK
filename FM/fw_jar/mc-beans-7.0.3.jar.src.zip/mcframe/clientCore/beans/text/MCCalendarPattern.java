/*     */ package mcframe.clientCore.beans.text;
/*     */ 
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.resource.MCConst;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCCalendarPattern
/*     */ {
/*     */   private final String _id;
/*     */   private final String _i_ptn;
/*     */   private final String _i_base;
/*     */   private final String _o_ptn;
/*     */   private final String _o_bnk;
/*     */   private final String _o_base;
/*     */   
/*     */   private MCCalendarPattern(String id, String i_ptn, String i_base, String o_ptn, String o_bnk, String o_base) {
/*  88 */     if (!MCStringUtil.isNull(id)) {
/*  89 */       if (!MCStringUtil.containsNull(new String[] { i_ptn, o_ptn, o_bnk })) {
/*  90 */         this._id = id;
/*  91 */         this._i_ptn = i_ptn;
/*  92 */         this._i_base = i_base;
/*  93 */         this._o_ptn = o_ptn;
/*  94 */         this._o_bnk = o_bnk;
/*  95 */         this._o_base = o_base;
/*     */       } else {
/*     */         
/*  98 */         throw new MCException(Core_Msg_FW_A.FCBAC0190, new Object[] { id, i_ptn, o_ptn, o_bnk });
/*     */       } 
/*     */     } else {
/*     */       
/* 102 */       throw new MCException(Core_Msg_FW_A.FCBAC0187, new Object[0]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCCalendarPattern(String id) {
/* 117 */     if (!MCStringUtil.isNull(id)) {
/* 118 */       String i_ptn = MCConst.format.getDateInputPattern(id);
/* 119 */       String i_base = MCConst.format.getDateInputBase(id);
/* 120 */       String o_ptn = MCConst.format.getDateOutputPattern(id);
/* 121 */       String o_base = MCConst.format.getDateOutputBase(id);
/* 122 */       String o_bnk = MCConst.format.getDateOutputBlank(id);
/* 123 */       if (!MCStringUtil.containsNull(new String[] { i_ptn, o_ptn, o_bnk })) {
/* 124 */         this._id = id;
/* 125 */         this._i_ptn = i_ptn;
/* 126 */         this._i_base = i_base;
/* 127 */         this._o_ptn = o_ptn;
/* 128 */         this._o_base = o_base;
/* 129 */         this._o_bnk = o_bnk;
/*     */       } else {
/*     */         
/* 132 */         throw new MCException(Core_Msg_FW_A.FCBAC0188, new Object[] { id, i_ptn, o_ptn, o_bnk });
/*     */       } 
/*     */     } else {
/*     */       
/* 136 */       throw new MCException(Core_Msg_FW_A.FCBAC0187, new Object[0]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCCalendarPattern create(String id) {
/* 152 */     return new MCCalendarPattern(id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCCalendarPattern create(String id, String i_ptn, String i_base, String o_ptn, String o_bnk, String o_base) {
/* 178 */     return new MCCalendarPattern(id, i_ptn, i_base, o_ptn, o_bnk, o_base);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getID() {
/* 189 */     return this._id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getInputPattern() {
/* 200 */     return this._i_ptn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getInputBase() {
/* 211 */     return this._i_base;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getOutputPattern() {
/* 222 */     return this._o_ptn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getOutputBlank() {
/* 233 */     return this._o_bnk;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getOutputBase() {
/* 244 */     return this._o_base;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\text\MCCalendarPattern.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */