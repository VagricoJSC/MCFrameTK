/*    */ package mcframe.clientCore.beans.text;
/*    */ 
/*    */ import mcframe.clientCore.beans.combobox.AbsMCComboBox;
/*    */ import mcframe.clientCore.beans.combobox.AbsMCPackageProxy;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MCComboBoxProxy
/*    */   extends AbsMCPackageProxy
/*    */ {
/* 16 */   static final MCComboBoxProxy PROXY = new MCComboBoxProxy();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void clearList(AbsMCComboBox<?> compo) {
/* 23 */     super.clearList(compo);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void createListEx(AbsMCComboBox<?> tf, Comparable<?> value) {
/* 28 */     super.createListEx(tf, value);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\text\MCComboBoxProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */