/*    */ package mcframe.clientCore.beans.text;
/*    */ 
/*    */ import mcframe.clientCore.beans.AbsMCPackageProxy;
/*    */ import mcframe.clientCore.beans.MCField;
/*    */ import mcframe.clientCore.beans.MCModeBeans;
/*    */ 
/*    */ final class MCBeansProxy extends AbsMCPackageProxy {
/*  8 */   static final MCBeansProxy PROXY = new MCBeansProxy();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void createListEx(MCField tf, Comparable<?> value) {
/* 15 */     super.createListEx(tf, value);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void clearList(MCField compo) {
/* 20 */     super.clearList(compo);
/*    */   }
/*    */ 
/*    */   
/*    */   protected String createGUIKey(MCModeBeans compo) {
/* 25 */     return super.createGUIKey(compo);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\text\MCBeansProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */