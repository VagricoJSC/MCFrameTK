/*     */ package mcframe.clientCore.beans.text;
/*     */ 
/*     */ import mcframe.commonCore.lang.MCCalendarDate;
/*     */ import mcframe.commonCore.lang.MCDate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCCalendarValidator
/*     */ {
/*     */   private MCCalendarDate _from;
/*     */   private MCCalendarDate _to;
/*     */   
/*     */   public final void setRangeFrom(MCCalendarDate<?> from) {
/*  54 */     setRange(from, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setRangeTo(MCCalendarDate<?> to) {
/*  72 */     setRange(null, to);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setRangeBetween(MCCalendarDate<?> from, MCCalendarDate<?> to) {
/*  92 */     setRange(from, to);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setRangeNotBetween(MCCalendarDate<?> from, MCCalendarDate<?> to) {
/* 113 */     setRange(to, from);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void setRange(MCCalendarDate<?> from, MCCalendarDate<?> to) {
/* 131 */     this._from = from;
/* 132 */     this._to = to;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCCalendarDate getRangeFrom() {
/* 145 */     return this._from;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCCalendarDate getRangeTo() {
/* 158 */     return this._to;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasValidate() {
/* 169 */     return !(this._from == null && this._to == null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkDate(MCCalendarDate<?> value) {
/* 182 */     if (value == null) {
/* 183 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 187 */     MCDate mCDate = MCDate.valueOf("99991231", "yyyyMMdd");
/* 188 */     if (value.gtDate((MCCalendarDate)mCDate)) {
/* 189 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 193 */     if (hasValidate()) {
/* 194 */       MCCalendarDate<?> from = getRangeFrom();
/* 195 */       MCCalendarDate<?> to = getRangeTo();
/* 196 */       if (from == null) {
/* 197 */         return value.lteDate(to);
/*     */       }
/* 199 */       if (to == null) {
/* 200 */         return value.gteDate(from);
/*     */       }
/* 202 */       if (from.lteDate(to)) {
/* 203 */         return (value.gteDate(from) && value.lteDate(to));
/*     */       }
/*     */ 
/*     */       
/* 207 */       return !(!value.gteDate(from) && !value.lteDate(to));
/*     */     } 
/*     */ 
/*     */     
/* 211 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\text\MCCalendarValidator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */