/*    */ package mcframe.clientCore.beans.text;
/*    */ 
/*    */ import mcframe.clientCore.event.AbsMCPackageProxy;
/*    */ import mcframe.clientCore.event.MCEventInfo;
/*    */ 
/*    */ final class MCEventProxy extends AbsMCPackageProxy {
/*  7 */   static final MCEventProxy PROXY = new MCEventProxy();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void setNewValue(MCEventInfo info, Comparable<?> value) {
/* 13 */     super.setNewValue(info, value);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\text\MCEventProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */