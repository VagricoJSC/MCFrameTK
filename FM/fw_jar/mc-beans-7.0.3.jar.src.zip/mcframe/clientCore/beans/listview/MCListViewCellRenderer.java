/*     */ package mcframe.clientCore.beans.listview;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.Box;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.ListCellRenderer;
/*     */ import javax.swing.border.Border;
/*     */ import mcframe.clientCore.beans.MCLabel;
/*     */ import mcframe.clientCore.beans.MCPanel;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MCListViewCellRenderer<P extends MCConstRow>
/*     */   implements ListCellRenderer<P>
/*     */ {
/*     */   private MCPanel _cell;
/*     */   private MCPanel _panel;
/*     */   private Box _west;
/*     */   private Box _east;
/*     */   private MCLabel _slide;
/*     */   private MCLabel _check;
/*     */   private boolean _check_left = true;
/*  85 */   private String _check_col = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCListViewCellRenderer() {
/*  95 */     this._cell = new MCPanel("listviewcell");
/*     */     
/*  97 */     this._west = Box.createHorizontalBox();
/*  98 */     this._east = Box.createHorizontalBox();
/*     */     
/* 100 */     this._slide = new MCLabel(String.valueOf(this._cell.getName()) + ".slide");
/* 101 */     this._slide.setOpaque(false);
/* 102 */     this._west.add((Component)this._slide);
/*     */     
/* 104 */     this._check = new MCLabel(String.valueOf(this._cell.getName()) + ".check");
/* 105 */     this._check.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 5));
/* 106 */     this._check.setOpaque(false);
/* 107 */     this._check.setEnabled(false);
/*     */     
/* 109 */     this._cell.setUseDefaultClip(true);
/* 110 */     this._cell.setOpaque(true);
/* 111 */     this._cell.setBorder(new ListItemBorder(Color.LIGHT_GRAY, 1));
/* 112 */     this._cell.setLayout(new BorderLayout(5, 0));
/* 113 */     this._cell.add(this._west, "West");
/* 114 */     this._cell.add(this._east, "East");
/*     */ 
/*     */     
/* 117 */     createCell();
/*     */ 
/*     */     
/* 120 */     this._cell.initialized();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Component getListCellRendererComponent(JList<? extends P> list, P value, int index, boolean isSelected, boolean cellHasFocus) {
/* 126 */     boolean tmpadd = false;
/*     */     
/*     */     try {
/* 129 */       if (this._cell.getParent() == null) {
/* 130 */         tmpadd = true;
/* 131 */         list.add((Component)this._cell);
/*     */       } 
/*     */       
/* 134 */       MCListView<P> listview = (MCListView)list;
/*     */       
/* 136 */       if (listview.isEnableSlide() && 
/* 137 */         listview.getSlideRow() == value) {
/* 138 */         slide(listview.getSlideSize());
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 143 */       if (isCheckEnabled()) {
/* 144 */         setCheck(value.getBoolean(this._check_col));
/*     */ 
/*     */ 
/*     */         
/* 148 */         this._check.setPreferredSize(null);
/* 149 */         this._check.getParent().setPreferredSize(null);
/*     */       } 
/*     */ 
/*     */       
/* 153 */       if (isSelected) {
/* 154 */         this._cell.setBackground(listview.getSelectionBackground());
/* 155 */         this._cell.setForeground(listview.getSelectionForeground());
/*     */       } else {
/*     */         
/* 158 */         this._cell.setBackground(listview.getBackground());
/* 159 */         this._cell.setForeground(listview.getForeground());
/*     */       } 
/*     */ 
/*     */       
/* 163 */       setListCellRendererComponent(
/* 164 */           (Component)this._cell, listview, value, index, isSelected, cellHasFocus);
/*     */     }
/*     */     finally {
/*     */       
/* 168 */       if (tmpadd && this._cell.getParent() == list) {
/* 169 */         list.remove((Component)this._cell);
/*     */       }
/*     */     } 
/*     */     
/* 173 */     return (Component)this._cell;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void createCell() {
/* 183 */     if (this._panel == null) {
/* 184 */       this._panel = new MCPanel(String.valueOf(this._cell.getName()) + "_panel");
/* 185 */       this._panel.setUseDefaultClip(true);
/* 186 */       this._panel.setOpaque(false);
/* 187 */       this._cell.add((Component)this._panel, "Center");
/* 188 */       createCell(this._panel);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void createCell(MCPanel panel) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setListCellRendererComponent(Component cell, MCListView<P> list, P value, int index, boolean isSelected, boolean cellHasFocus) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Component getCheckComponent() {
/* 240 */     return (Component)this._check;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setCheckColumn(String col) {
/* 254 */     this._check_col = col;
/* 255 */     setEnabledCheck((this._check_col != null));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getCheckColumn() {
/* 266 */     return this._check_col;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isCheckEnabled() {
/* 277 */     return (this._check_col != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setCheckPosition(boolean left) {
/* 288 */     this._check_left = left;
/* 289 */     if (isCheckEnabled())
/*     */     {
/* 291 */       setEnabledCheck(true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setEnabledCheck(boolean enabled) {
/* 303 */     this._check.setEnabled(enabled);
/* 304 */     this._west.remove((Component)this._check);
/* 305 */     this._east.remove((Component)this._check);
/* 306 */     if (enabled) {
/* 307 */       if (this._check_left) {
/* 308 */         this._west.add((Component)this._check, 0);
/*     */       } else {
/*     */         
/* 311 */         this._east.add((Component)this._check);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setCheck(boolean check) {
/* 324 */     ImageIcon icon = check ? 
/* 325 */       MCConst.beans.getIcon("icon.SELECT_ALL") : 
/* 326 */       MCConst.beans.getIcon("icon.DESELECT_ALL");
/* 327 */     this._check.setIcon(icon);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void slide(int size) {
/* 338 */     Dimension d = this._slide.getPreferredSize();
/* 339 */     d.width += size;
/* 340 */     this._slide.setPreferredSize(d);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class ListItemBorder
/*     */     implements Border
/*     */   {
/* 355 */     private Color color = Color.LIGHT_GRAY;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 361 */     private int margin = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     ListItemBorder(Color color, int margin) {
/* 372 */       this.color = color;
/* 373 */       this.margin = margin;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
/* 379 */       Color oldColor = g.getColor();
/*     */       
/* 381 */       Insets insets = getBorderInsets(c);
/*     */       
/* 383 */       g.setColor(this.color);
/* 384 */       g.fillRect(x, y + height - insets.bottom, width, insets.bottom);
/*     */       
/* 386 */       g.setColor(oldColor);
/*     */     }
/*     */ 
/*     */     
/*     */     public Insets getBorderInsets(Component c) {
/* 391 */       return new Insets(0, 0, this.margin, 0);
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isBorderOpaque() {
/* 396 */       return (this.color != null);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\listview\MCListViewCellRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */