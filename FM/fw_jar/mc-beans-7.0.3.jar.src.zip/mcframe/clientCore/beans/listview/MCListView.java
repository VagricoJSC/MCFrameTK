/*      */ package mcframe.clientCore.beans.listview;
/*      */ 
/*      */ import java.awt.AWTEvent;
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.Container;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Font;
/*      */ import java.awt.Point;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.event.KeyAdapter;
/*      */ import java.awt.event.KeyEvent;
/*      */ import java.awt.event.MouseEvent;
/*      */ import java.awt.event.MouseMotionListener;
/*      */ import java.util.Collection;
/*      */ import javax.swing.AbstractListModel;
/*      */ import javax.swing.JComponent;
/*      */ import javax.swing.JList;
/*      */ import javax.swing.JPopupMenu;
/*      */ import javax.swing.ListCellRenderer;
/*      */ import javax.swing.ListModel;
/*      */ import javax.swing.SwingUtilities;
/*      */ import javax.swing.event.ListSelectionEvent;
/*      */ import javax.swing.event.ListSelectionListener;
/*      */ import javax.swing.event.MouseInputListener;
/*      */ import mcframe.clientCore.beans.MCBeans;
/*      */ import mcframe.clientCore.beans.MCBeansDelegate;
/*      */ import mcframe.clientCore.beans.MCBeansUtil;
/*      */ import mcframe.clientCore.beans.MCMode;
/*      */ import mcframe.clientCore.beans.MCModeBeans;
/*      */ import mcframe.clientCore.beans.MCModeInfo;
/*      */ import mcframe.clientCore.beans.MCResourceBeans;
/*      */ import mcframe.clientCore.beans.MCRootPanel;
/*      */ import mcframe.clientCore.beans.MCScrollPane;
/*      */ import mcframe.clientCore.beans.MCTabOrderBeans;
/*      */ import mcframe.clientCore.beans.action.MCKeyActionManager;
/*      */ import mcframe.clientCore.beans.popup.MCPopupBeans;
/*      */ import mcframe.clientCore.beans.popup.MCPopupConfig;
/*      */ import mcframe.clientCore.beans.popup.MCPopupMenu;
/*      */ import mcframe.clientCore.container.MCConstRow;
/*      */ import mcframe.clientCore.container.MCRowEvent;
/*      */ import mcframe.clientCore.container.MCRowListener;
/*      */ import mcframe.clientCore.event.MCDCBeans;
/*      */ import mcframe.clientCore.event.MCDCListener;
/*      */ import mcframe.clientCore.event.MCEventBeans;
/*      */ import mcframe.clientCore.event.MCEventInfo;
/*      */ import mcframe.clientCore.event.MCEventList;
/*      */ import mcframe.clientCore.event.MCEventListener;
/*      */ import mcframe.clientCore.event.MCNCBeans;
/*      */ import mcframe.clientCore.event.MCNCListener;
/*      */ import mcframe.clientCore.resource.MCConst;
/*      */ import mcframe.commonCore.container.MCList;
/*      */ import mcframe.commonCore.container.MCListEvent;
/*      */ import mcframe.commonCore.container.MCListListener;
/*      */ import mcframe.commonCore.container.MCRow;
/*      */ import mcframe.commonCore.container.MCRowMatcher;
/*      */ import mcframe.commonCore.lang.MCStringUtil;
/*      */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*      */ import mcframe.commonCore.notice.MCException;
/*      */ import mcframe.commonCore.resource.ctrl.MCResource;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MCListView<P extends MCConstRow>
/*      */   extends JList<P>
/*      */   implements MCNCBeans, MCDCBeans, MCTabOrderBeans, MCModeBeans, MCPopupBeans
/*      */ {
/*   86 */   private MCRowMatcher<P> _filter = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   93 */   private String _check_col = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _slide_action = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int _drag_action;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  113 */   private P _drag = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  119 */   private int _dragstart = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  125 */   private int _dragsize = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  139 */   private Font _default_font = null;
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String TYPE = "listview";
/*      */ 
/*      */ 
/*      */   
/*      */   private String _message_name_resource;
/*      */ 
/*      */ 
/*      */   
/*      */   private String _message_name;
/*      */ 
/*      */ 
/*      */   
/*      */   private MCRootPanel _panel;
/*      */ 
/*      */ 
/*      */   
/*      */   private MCRootPanel _init_panel;
/*      */ 
/*      */ 
/*      */   
/*      */   private MCMode _mode;
/*      */ 
/*      */   
/*      */   private MCPopupConfig _popup_config;
/*      */ 
/*      */   
/*      */   private MCBeansDelegate _beans_delegate;
/*      */ 
/*      */   
/*      */   private final MCEventList _event_list;
/*      */ 
/*      */   
/*      */   private MCEventInfo _event_info;
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setName(String name) {
/*  180 */     MCBeansUtil.checkName(name);
/*  181 */     super.setName(name);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setModel(ListModel<P> model) {
/*  186 */     if (!(model instanceof MCListViewModel))
/*      */     {
/*  188 */       throw new MCException(Core_Msg_FW_A.FCBAC0451, new Object[] { getName() });
/*      */     }
/*  190 */     super.setModel(model);
/*  191 */     ((MCListViewModel)getModel()).setMatcher(this._filter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setList(MCList<P> list) {
/*  202 */     setModel(new MCListViewModel(list));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setCellRenderer(ListCellRenderer<? super P> cellRenderer) {
/*  207 */     if (cellRenderer instanceof MCListViewCellRenderer) {
/*      */       
/*  209 */       MCListViewCellRenderer<? super P> mccr = 
/*  210 */         (MCListViewCellRenderer<? super P>)cellRenderer;
/*  211 */       mccr.setCheckColumn(this._check_col);
/*      */     } 
/*  213 */     ListCellRenderer<? super P> old = getCellRenderer();
/*  214 */     if (old instanceof MCListViewCellRenderer) {
/*      */       
/*  216 */       MCListViewCellRenderer<? super P> mccr = 
/*  217 */         (MCListViewCellRenderer<? super P>)old;
/*  218 */       mccr.setCheckColumn(null);
/*      */     } 
/*      */     
/*  221 */     super.setCellRenderer(cellRenderer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCheckColumn(String col) {
/*  235 */     this._check_col = col;
/*      */     
/*  237 */     ListCellRenderer<? super P> cr = getCellRenderer();
/*  238 */     if (cr instanceof MCListViewCellRenderer) {
/*      */       
/*  240 */       MCListViewCellRenderer<? super P> mccr = 
/*  241 */         (MCListViewCellRenderer<? super P>)cr;
/*  242 */       mccr.setCheckColumn(this._check_col);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCheckColumn() {
/*  254 */     return this._check_col;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFilter(MCRowMatcher<P> filter) {
/*  267 */     this._filter = filter;
/*  268 */     ((MCListViewModel)getModel()).setMatcher(this._filter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setEnableSlide(boolean enable) {
/*  279 */     this._slide_action = enable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEnableSlide() {
/*  290 */     return this._slide_action;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public P getSlideRow() {
/*  301 */     return this._drag;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getSlideSize() {
/*  312 */     return this._dragsize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void filter(boolean on) {
/*  323 */     int index = getSelectedIndex();
/*  324 */     getListViewModel().filter(on);
/*  325 */     int size = getListViewModel().getSize();
/*  326 */     if (size > 0 && size - 1 < index) {
/*  327 */       setSelectedIndex(0);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void changeCheckedValue(P row) {
/*  340 */     ListCellRenderer<? super P> cr = 
/*  341 */       getCellRenderer();
/*  342 */     if (cr instanceof MCListViewCellRenderer) {
/*  343 */       MCListViewCellRenderer<? super P> renderer = 
/*  344 */         (MCListViewCellRenderer<? super P>)cr;
/*  345 */       if (renderer.isCheckEnabled()) {
/*  346 */         String check = renderer.getCheckColumn();
/*  347 */         row.setBoolean(check, !row.getBoolean(check));
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setDefaultListener() {
/*  360 */     MouseMotionListener[] motions = getMouseMotionListeners(); byte b; int i; MouseMotionListener[] arrayOfMouseMotionListener1;
/*  361 */     for (i = (arrayOfMouseMotionListener1 = motions).length, b = 0; b < i; ) { MouseMotionListener motion = arrayOfMouseMotionListener1[b];
/*  362 */       removeMouseMotionListener(motion);
/*      */       b++; }
/*      */     
/*  365 */     MouseInputListener mouseListener = new MouseInputListener()
/*      */       {
/*      */         public void mouseClicked(MouseEvent e) {
/*  368 */           if (SwingUtilities.isLeftMouseButton(e)) {
/*  369 */             switch (e.getClickCount()) {
/*      */ 
/*      */               
/*      */               case 2:
/*  373 */                 MCListView.this.doDC();
/*      */                 break;
/*      */             } 
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         public void mousePressed(MouseEvent e) {}
/*      */ 
/*      */ 
/*      */         
/*      */         public void mouseReleased(MouseEvent e) {
/*  386 */           MCListView<P> list = MCListView.this;
/*      */           
/*  388 */           if (list.getModel().getSize() == 0) {
/*      */             return;
/*      */           }
/*      */           
/*  392 */           Point pt = e.getPoint();
/*  393 */           int index = list.locationToIndex(pt);
/*  394 */           MCConstRow mCConstRow = list.getModel().getElementAt(index);
/*      */ 
/*      */           
/*  397 */           if (MCListView.this._drag != null) {
/*  398 */             boolean fire = (MCListView.this._dragsize > MCListView.this._drag_action);
/*  399 */             MCListView.this._drag = null;
/*  400 */             MCListView.this._dragstart = 0;
/*  401 */             MCListView.this._dragsize = 0;
/*  402 */             if (fire)
/*      */             {
/*  404 */               MCListView.this.changeCheckedValue((P)mCConstRow);
/*      */             }
/*      */ 
/*      */             
/*  408 */             MCListView.this.repaint();
/*      */             
/*      */             return;
/*      */           } 
/*      */           
/*  413 */           ListCellRenderer<? super P> cr = 
/*  414 */             list.getCellRenderer();
/*  415 */           if (cr instanceof MCListViewCellRenderer) {
/*  416 */             MCListViewCellRenderer<? super P> mcr = 
/*  417 */               (MCListViewCellRenderer<? super P>)cr;
/*  418 */             if (mcr.isCheckEnabled()) {
/*  419 */               Component c = mcr.getListCellRendererComponent(
/*  420 */                   list, (P)mCConstRow, index, true, true);
/*  421 */               Rectangle r = list.getCellBounds(index, index);
/*  422 */               c.setBounds(r);
/*  423 */               MCListView.this.layoutComponent(c);
/*  424 */               pt.translate(-r.x, -r.y);
/*  425 */               Component b = SwingUtilities.getDeepestComponentAt(c, pt.x, pt.y);
/*  426 */               if (b == mcr.getCheckComponent())
/*      */               {
/*  428 */                 MCListView.this.changeCheckedValue((P)mCConstRow);
/*      */               }
/*      */             } 
/*      */           } 
/*      */         }
/*      */         
/*      */         public void mouseDragged(MouseEvent e) {
/*  435 */           MCConstRow mCConstRow = MCListView.this.getSelectedValue();
/*  436 */           if (mCConstRow == null) {
/*      */             return;
/*      */           }
/*      */           
/*  440 */           if (MCListView.this._drag == null) {
/*      */             
/*  442 */             MCListView.this._drag = (P)mCConstRow;
/*  443 */             MCListView.this._dragstart = e.getX();
/*      */           } 
/*  445 */           MCListView.this._dragsize = e.getX() - MCListView.this._dragstart;
/*  446 */           if (MCListView.this._dragsize < 0) {
/*  447 */             MCListView.this._dragsize = 0;
/*      */           }
/*  449 */           MCListView.this.repaint();
/*      */         }
/*      */ 
/*      */         
/*      */         public void mouseMoved(MouseEvent e) {}
/*      */ 
/*      */         
/*      */         public void mouseEntered(MouseEvent e) {}
/*      */ 
/*      */         
/*      */         public void mouseExited(MouseEvent e) {}
/*      */       };
/*  461 */     addMouseListener(mouseListener);
/*  462 */     addMouseMotionListener(mouseListener);
/*      */ 
/*      */     
/*  465 */     addListSelectionListener(new ListSelectionListener()
/*      */         {
/*      */           public void valueChanged(ListSelectionEvent e) {
/*  468 */             MCListView.this.doNC();
/*      */           }
/*      */         });
/*      */ 
/*      */     
/*  473 */     addKeyListener(new KeyAdapter() { public void keyPressed(KeyEvent e) {
/*      */             MCListView<P> list;
/*      */             MCConstRow mCConstRow;
/*  476 */             switch (e.getKeyCode()) {
/*      */               case 10:
/*  478 */                 MCListView.this.doDC();
/*      */                 break;
/*      */               
/*      */               case 32:
/*  482 */                 list = MCListView.this;
/*  483 */                 mCConstRow = (MCConstRow)list.getSelectedValue();
/*  484 */                 MCListView.this.changeCheckedValue((P)mCConstRow);
/*      */                 
/*  486 */                 e.consume();
/*      */                 break;
/*      */             } 
/*      */           } }
/*      */       );
/*      */   }
/*      */ 
/*      */   
/*      */   protected void processEvent(AWTEvent e) {
/*      */     try {
/*  496 */       super.processEvent(e);
/*      */     }
/*  498 */     catch (Throwable t) {
/*  499 */       handle(t);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void layoutComponent(Component comp) {
/*  513 */     comp.doLayout();
/*  514 */     if (comp instanceof Container) {
/*  515 */       Container cont = (Container)comp; byte b; int i; Component[] arrayOfComponent;
/*  516 */       for (i = (arrayOfComponent = cont.getComponents()).length, b = 0; b < i; ) { Component child = arrayOfComponent[b];
/*  517 */         layoutComponent(child);
/*      */         b++; }
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isRequestFocusEnabled() {
/*  551 */     return (super.isRequestFocusEnabled() && isMCRequestFocusEnabled());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isMCRequestFocusEnabled() {
/*  570 */     return MCBeansUtil.isFocusable(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void mcRequestFocus() {
/*  587 */     MCBeansUtil.focus(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void grabFocus() {
/*  600 */     super.grabFocus();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void requestFocus() {
/*  613 */     doFocus(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public boolean requestFocus(boolean temporary) {
/*  628 */     return doFocus(temporary);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean doFocus(boolean temporary) {
/*  657 */     if (super.requestFocus(temporary)) {
/*  658 */       if (!temporary) {
/*  659 */         afterRequestFocus();
/*      */       }
/*  661 */       return true;
/*      */     } 
/*  663 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public boolean requestFocusInWindow() {
/*  677 */     return super.requestFocusInWindow();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected boolean requestFocusInWindow(boolean temporary) {
/*  692 */     return super.requestFocusInWindow(temporary);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MCListViewModel getListViewModel() {
/*  705 */     return (MCListViewModel)getModel();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private class MCListViewModel
/*      */     extends AbstractListModel<P>
/*      */     implements MCListListener, MCRowListener
/*      */   {
/*      */     private MCList<P> list;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private MCList<P> filteredList;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  732 */     private MCRowMatcher<P> matcher = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean _filter = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     MCListViewModel(MCList<P> list) {
/*  748 */       this.list = list;
/*  749 */       this.filteredList = (list != null) ? list.createInstance() : null;
/*  750 */       if (this.list != null) {
/*  751 */         this.list.addListListener(new MCListListener[] { this });
/*  752 */         setRowListener(0, this.list.size());
/*  753 */         filter(this._filter);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public int getSize() {
/*  759 */       return this.filteredList.size();
/*      */     }
/*      */ 
/*      */     
/*      */     public P getElementAt(int index) {
/*      */       P returnValue;
/*  765 */       if (index < this.filteredList.size()) {
/*  766 */         MCConstRow mCConstRow = (MCConstRow)this.filteredList.get(index);
/*      */       } else {
/*      */         
/*  769 */         returnValue = null;
/*      */       } 
/*  771 */       return returnValue;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void setMatcher(MCRowMatcher<P> matcher) {
/*  784 */       this.matcher = matcher;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void filter(boolean on) {
/*  795 */       this.filteredList.clear();
/*  796 */       if (on || this.matcher != null) {
/*  797 */         for (MCConstRow mCConstRow : this.list) {
/*  798 */           if (this.matcher.match((MCRow)mCConstRow)) {
/*  799 */             this.filteredList.add((MCRow)mCConstRow);
/*      */           }
/*      */         } 
/*      */       } else {
/*      */         
/*  804 */         this.filteredList.addAll((Collection)this.list);
/*      */       } 
/*  806 */       this._filter = on;
/*  807 */       fireContentsChanged(this, 0, getSize());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void setRowListener(int start, int end) {
/*  820 */       for (int i = start; i < end; i++) {
/*  821 */         MCConstRow mCConstRow = (MCConstRow)this.list.get(i);
/*  822 */         mCConstRow.removeRowListener(this);
/*  823 */         mCConstRow.addRowListener(new MCRowListener[] { this });
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void rowAdded(MCListEvent event) {
/*  829 */       setRowListener(event.getIndex(), event.getIndex() + event.getCount());
/*  830 */       filter(this._filter);
/*      */     } public void rowRemoved(MCListEvent event) {
/*      */       byte b;
/*      */       int i;
/*      */       MCRow[] arrayOfMCRow;
/*  835 */       for (i = (arrayOfMCRow = event.getRemoveRows()).length, b = 0; b < i; ) { MCRow row = arrayOfMCRow[b];
/*  836 */         ((MCConstRow)row).removeRowListener(this); b++; }
/*      */       
/*  838 */       filter(this._filter);
/*      */     } public void rowRemoved(MCListEvent[] events) {
/*      */       byte b;
/*      */       int i;
/*      */       MCListEvent[] arrayOfMCListEvent;
/*  843 */       for (i = (arrayOfMCListEvent = events).length, b = 0; b < i; ) { MCListEvent event = arrayOfMCListEvent[b]; byte b1; int j; MCRow[] arrayOfMCRow;
/*  844 */         for (j = (arrayOfMCRow = event.getRemoveRows()).length, b1 = 0; b1 < j; ) { MCRow row = arrayOfMCRow[b1];
/*  845 */           ((MCConstRow)row).removeRowListener(this); b1++; }
/*      */          b++; }
/*      */       
/*  848 */       filter(this._filter);
/*      */     }
/*      */ 
/*      */     
/*      */     public void rowSet(MCListEvent event) {
/*  853 */       ((MCConstRow)event.getRemoveRow()).removeRowListener(this);
/*  854 */       ((MCConstRow)event.getAddRow()).removeRowListener(this);
/*  855 */       ((MCConstRow)event.getAddRow()).addRowListener(new MCRowListener[] { this });
/*  856 */       filter(this._filter);
/*      */     }
/*      */ 
/*      */     
/*      */     public void listSorted(MCListEvent event) {
/*  861 */       filter(this._filter);
/*      */     }
/*      */ 
/*      */     
/*      */     public void listCleared(MCListEvent event) {
/*  866 */       filter(this._filter);
/*      */     }
/*      */     
/*      */     public void valueChanged(MCRowEvent event)
/*      */     {
/*  871 */       filter(this._filter);
/*      */     } } public String getType() { return "listview"; } public String getMessageByLocale() { String m = this._message_name; if (m == null) m = this._message_name_resource;  return MCBeansProxy.PROXY.getNameForMessage((MCBeans)this, m); }
/*      */   public String getLabelByLocale() { return MCBeansUtil.getLabel((MCBeans)this); }
/*      */   public MCRootPanel getRootPanel() { if (this._init_panel != null) return this._init_panel;  return getNearestRootPanel(); }
/*      */   public MCRootPanel getBaseRootPanel() { MCRootPanel p = getNearestRootPanel(); return (p != null) ? p.getBaseRootPanel() : null; }
/*      */   public MCRootPanel getNearestRootPanel() { if (this._panel == null) this._panel = MCBeansUtil.getNearestRootPanel(this);  return this._panel; }
/*      */   public void localeChanged() { updateResource(); }
/*      */   public void added() { this._panel = MCBeansUtil.getNearestRootPanel(this); if (MCMode.isNull(getMode()))
/*      */       setMode(MCMode.ENABLE);  }
/*      */   public void removed() { this._panel = MCBeansUtil.getNearestRootPanel(this); }
/*      */   public boolean equalsIgnoreCase(Component compo) { return equals(compo); }
/*      */   public void initialized() { if (this._default_font == null)
/*      */       this._default_font = getFont();  this._init_panel = MCBeansUtil.getRootPanel(this); }
/*      */   private MCBeansDelegate getDelegate() { if (this._beans_delegate == null)
/*      */       this._beans_delegate = new MCBeansDelegate();  return this._beans_delegate; }
/*      */   public void addAliasName(String alias, MCRootPanel panel) { getDelegate().addAliasName(alias, panel); }
/*      */   public void setAliasName(String alias, MCRootPanel panel) { getDelegate().setAliasName(alias, panel); }
/*      */   public void removeAliasName(MCRootPanel panel) { getDelegate().removeAliasName(panel); }
/*      */   public void removeAliasNames() { getDelegate().removeAliasNames(); }
/*  890 */   public MCListView(String name) { this._message_name_resource = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  897 */     this._message_name = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  904 */     this._panel = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  911 */     this._init_panel = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  918 */     this._mode = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  933 */     this._popup_config = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  940 */     this._beans_delegate = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1449 */     this._event_list = new MCEventList();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1457 */     this._event_info = null; setName(name); setDefaultListener(); setList((MCList<P>)null); setComponentPopupMenu(new MCPopupMenu(this)); setSelectionMode(0); this._drag_action = MCConst.app.getInteger("FS.FSBGP0120.list.item.slide.amount", 50); } public String getAliasName(MCRootPanel panel) { return getDelegate().getAliasName(panel); } public String[] getAliasNames() { return getDelegate().getAliasNames(); } @Deprecated public void updateBounds(int ratio) { int h = 0; ListCellRenderer<? super P> cr = getCellRenderer(); ListModel<P> model = getModel(); int size = model.getSize(); for (int i = 0; i < size; i++) { MCConstRow mCConstRow = (MCConstRow)model.getElementAt(i); Component c = cr.getListCellRendererComponent(this, (P)mCConstRow, i, true, true); layoutComponent(c); h += (c.getSize()).height; }  Rectangle r = getBounds(); r.height = h; setBounds(r); } public void updateFontSize(int ratio) { MCBeansProxy.PROXY.updateFontSize(this, ratio, this._default_font); } public Dimension getDefaultSize() { return getSize(); } public void afterRequestFocus() { MCRootPanel bp = getBaseRootPanel(); MCBeansUtil.afterRequestFocus(bp, this); MCBeansUtil.scrollRectToVisible(bp, this); } @Deprecated public void handle(Throwable t) { MCBeansUtil.handle(this, t); } public void setMessageName(String name) { this._message_name = MCBeansProxy.PROXY.adjustMessageName(name); } @Deprecated public String _getMessageName() { return this._message_name; } public void setNextBeans(MCTabOrderBeans compo) { getDelegate().setNextBeans(this, compo, 1); } public MCTabOrderBeans getNextBeans() { return getDelegate().getNextBeans(); }
/*      */   @Deprecated public boolean isFocusableByKeybord() { return (isVisible() && isEnabled() && isFocusable()); }
/*      */   public void insertNextBeans(MCTabOrderBeans compo) { getDelegate().insertNextBeans(this, compo, 1); }
/*      */   public void insertPreviousBeans(MCTabOrderBeans compo) { getDelegate().insertPreviousBeans(this, compo, 1); }
/*      */   @Deprecated public void setPreviousBeans(MCTabOrderBeans compo) { getDelegate().setPreviousBeans(this, compo); }
/* 1462 */   public MCEventInfo getEventInfo() { if (this._event_info == null) {
/* 1463 */       this._event_info = new MCEventInfo();
/* 1464 */       MCEventProxy.PROXY.setComponent(this._event_info, (MCEventBeans)this);
/*      */     } 
/* 1466 */     return this._event_info; }
/*      */   public MCTabOrderBeans getPreviousBeans() { return getDelegate().getPreviousBeans(); }
/*      */   public void setNextBeans(MCTabOrderBeans compo, int updateType) {
/*      */     getDelegate().setNextBeans(this, compo, updateType);
/*      */   } public void insertNextBeans(MCTabOrderBeans compo, int updateType) {
/*      */     getDelegate().insertNextBeans(this, compo, updateType);
/*      */   } public void insertPreviousBeans(MCTabOrderBeans compo, int updateType) {
/*      */     getDelegate().insertPreviousBeans(this, compo, updateType);
/*      */   } @Deprecated
/*      */   public void setTabOrderEnabled(boolean enabled) {
/*      */     getDelegate().setTabOrderEnabled(enabled);
/*      */   } public boolean isTabOrderEnabled() {
/*      */     return getDelegate().isTabOrderEnabled();
/*      */   } @Deprecated
/*      */   public JComponent getTargetComponent() {
/*      */     return this;
/*      */   } public void updateResource() {
/*      */     updateResource(getBaseRootPanel());
/* 1484 */   } public final void addAllListener(MCEventListener listener) { addNCListener((MCNCListener)listener);
/*      */ 
/*      */ 
/*      */     
/* 1488 */     addDCListener((MCDCListener)listener); }
/*      */   public void updateResource(MCRootPanel panel) { if (!panel.isPartsFlag()) { MCKeyActionManager.initScreen((MCResourceBeans)this, getInputMap(1), getActionMap()); MCKeyActionManager.initScreen((MCResourceBeans)this, getInputMap(), getActionMap()); }  setFont(); this._panel.updateResource(panel); String m = MCBeansUtil.getMessageName((MCResourceBeans)this); if (m != null) this._message_name_resource = m;  }
/*      */   protected void setFont() { String key = MCBeansProxy.PROXY.getBeansKey((MCResourceBeans)this, MCResource.createKey(new String[] { getType(), "font" })); if (!MCStringUtil.isNull(key)) { Font temp = getFont(); Font font = MCConst.beans.getFont(key, temp); if (temp != font) setFont(font);  }  }
/*      */   @Deprecated public void _setDefaultBounds() {}
/*      */   @Deprecated public void _cacheDefaultBounds(Rectangle bounds) {}
/*      */   public Rectangle getDefaultBounds() { return null; }
/*      */   public void setMode(MCMode mode) { if (!MCMode.isNull(mode)) { MCRootPanel bp = getBaseRootPanel(); MCBeansUtil.log(bp, (MCBeans)this, Core_Msg_FW_A.FCBAC0013, new Object[] { mode.getName() }); this._mode = mode; MCModeInfo mi = getModeInfo(); int s = mi.getStatus(); MCScrollPane sp = getScrollPane(); switch (s) { case 1: setVisible(true); setEnabled(true); setFocusable(true); sp.setVisible(true); break;case 2: setVisible(true); setEnabled(true); setFocusable(false); sp.setVisible(true); break;case 3: setVisible(false); sp.setVisible(false); break; }  setForeground(mi.getForeground()); Color bg = mi.getBackground(); sp.setMCBackground(bg); setBackground(bg); MCBeansUtil.log(bp, (MCBeans)this, Core_Msg_FW_A.FCBAC0014, new Object[] { mode.getName() }); }  }
/*      */   public MCScrollPane getScrollPane() { return MCBeansUtil.getScrollPane(this); }
/*      */   public MCMode getMode() { return this._mode; }
/*      */   public MCModeInfo getModeInfo() { return getModeInfo(getMode()); }
/*      */   public MCModeInfo getModeInfo(MCMode mode) { return getDelegate().getModeInfo(this, mode); }
/*      */   public void putMode(MCRootPanel panel, String status, MCMode mode) { getDelegate().putMode(panel, status, mode); }
/*      */   public void setMode(MCRootPanel panel, String status) { setMode(getMode(panel, status)); }
/*      */   public MCMode getMode(MCRootPanel panel, String status) { return getDelegate().getMode(panel, status); }
/*      */   public String[] getStatuses(MCRootPanel panel) { return getDelegate().getStatuses(panel); }
/*      */   public MCPopupMenu configurePopup() { MCPopupMenu m = configurePopup(getComponentPopupMenu()); if (m != null) m.sort();  return m; }
/*      */   protected MCPopupMenu configurePopup(MCPopupMenu menu) { MCPopupConfig pc = getPopupConfig(); return (pc != null) ? pc.configurePopup(menu, this) : menu; }
/*      */   public void popupMenuWillBecomeVisible() {}
/* 1506 */   public void popupMenuWillBecomeInvisible() {} public void setPopupConfig(MCPopupConfig config) { this._popup_config = config; } public MCPopupConfig getPopupConfig() { return this._popup_config; } public void setComponentPopupMenu(MCPopupMenu popup) { super.setComponentPopupMenu((JPopupMenu)popup); } @Deprecated public final void setComponentPopupMenu(JPopupMenu popup) { super.setComponentPopupMenu(popup); } public final MCPopupMenu getComponentPopupMenu() { return (MCPopupMenu)super.getComponentPopupMenu(); } public void removeComponentPopupMenu() { setComponentPopupMenu((MCPopupMenu)null); } public final void setAllListener(MCEventListener listener) { setNCListener((MCNCListener)listener);
/*      */ 
/*      */ 
/*      */     
/* 1510 */     setDCListener((MCDCListener)listener); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addNCListener(MCNCListener listener) {
/* 1518 */     this._event_list.add(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setNCListener(MCNCListener listener) {
/* 1523 */     this._event_list.set(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeNCListener(MCNCListener listener) {
/* 1528 */     this._event_list.remove(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public MCNCListener[] getNCListeners() {
/* 1533 */     return this._event_list.nc();
/*      */   }
/*      */ 
/*      */   
/*      */   public void doNC() {
/* 1538 */     MCBeansUtil.nc(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addDCListener(MCDCListener listener) {
/* 1545 */     this._event_list.add(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setDCListener(MCDCListener listener) {
/* 1550 */     this._event_list.set(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeDCListener(MCDCListener listener) {
/* 1555 */     this._event_list.remove(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public MCDCListener[] getDCListeners() {
/* 1560 */     return this._event_list.dc();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void doDC() {
/* 1567 */     MCBeansUtil.dc(this);
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\listview\MCListView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */