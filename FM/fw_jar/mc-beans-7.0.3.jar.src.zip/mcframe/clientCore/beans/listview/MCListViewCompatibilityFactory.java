/*   */ package mcframe.clientCore.beans.listview;
/*   */ 
/*   */ public class MCListViewCompatibilityFactory {
/*   */   public static MCListView createListView(String name) {
/* 5 */     return new MCListView<>(name);
/*   */   }
/*   */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\listview\MCListViewCompatibilityFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */