/*    */ package mcframe.clientCore.beans.listview;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import java.awt.Font;
/*    */ import java.awt.Rectangle;
/*    */ import mcframe.clientCore.beans.AbsMCPackageProxy;
/*    */ import mcframe.clientCore.beans.MCBeans;
/*    */ import mcframe.clientCore.beans.MCResourceBeans;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MCBeansProxy
/*    */   extends AbsMCPackageProxy
/*    */ {
/* 27 */   static final MCBeansProxy PROXY = new MCBeansProxy();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected String getNameForMessage(MCBeans compo, String msg) {
/* 41 */     return super.getNameForMessage(compo, msg);
/*    */   }
/*    */ 
/*    */   
/*    */   protected String adjustMessageName(String name) {
/* 46 */     return super.adjustMessageName(name);
/*    */   }
/*    */ 
/*    */   
/*    */   protected String getBeansKey(MCResourceBeans compo, String prefix) {
/* 51 */     return super.getBeansKey(compo, prefix);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void updateBounds(Component compo, int ratio, Rectangle def) {
/* 56 */     super.updateBounds(compo, ratio, def);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void updateFontSize(Component compo, int ratio, Font def) {
/* 61 */     super.updateFontSize(compo, ratio, def);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\listview\MCBeansProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */