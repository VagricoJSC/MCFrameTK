/*    */ package mcframe.clientCore.beans.action;
/*    */ 
/*    */ import java.util.List;
/*    */ import javax.swing.InputMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MCKeyAssign
/*    */ {
/*    */   private final String _type;
/*    */   private final InputMap _input_map;
/*    */   private final List<MCActionInfo> _action_list;
/*    */   
/*    */   MCKeyAssign(String type, InputMap input, List<MCActionInfo> action) {
/* 50 */     this._type = type;
/* 51 */     this._input_map = input;
/* 52 */     this._action_list = action;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   final String getType() {
/* 63 */     return this._type;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   final InputMap getInputMap() {
/* 74 */     return this._input_map;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   final MCActionInfo[] getActionInfo() {
/* 85 */     List<MCActionInfo> l = this._action_list;
/* 86 */     return l.<MCActionInfo>toArray(new MCActionInfo[l.size()]);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\action\MCKeyAssign.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */