/*    */ package mcframe.clientCore.beans.action;
/*    */ 
/*    */ import mcframe.clientCore.beans.table.AbsMCPackageProxy;
/*    */ import mcframe.clientCore.beans.table.MCTable;
/*    */ 
/*    */ final class MCTableProxy extends AbsMCPackageProxy {
/*  7 */   static final MCTableProxy PROXY = new MCTableProxy();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void nextRowSelectionChange(MCTable<?> table) {
/* 13 */     super.nextRowSelectionChange(table);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void previousRowSelectionChange(MCTable<?> table) {
/* 18 */     super.previousRowSelectionChange(table);
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean commitEditor(MCTable<?> table) {
/* 23 */     return super.commitEditor(table);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\action\MCTableProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */