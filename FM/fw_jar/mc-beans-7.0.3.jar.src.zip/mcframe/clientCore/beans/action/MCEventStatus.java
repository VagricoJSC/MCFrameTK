/*     */ package mcframe.clientCore.beans.action;
/*     */ 
/*     */ import mcframe.clientCore.beans.MCBeans;
/*     */ import mcframe.clientCore.beans.MCFrame;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MCEventStatus
/*     */ {
/*  29 */   private static String MODULE_ID = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  36 */   private static String SCREEN_ID = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  43 */   private static int SERIAL = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   private static String EVENT_COMPO = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   private static long EVENT_END_TIME = -1L;
/*     */ 
/*     */ 
/*     */   
/*  64 */   private static long IGNORE_MILLIS = -1L;
/*     */   
/*     */   private static boolean IS_SHOW_PANEL_END = true;
/*     */   
/*     */   static void setShowPanelEnd(boolean b) {
/*  69 */     IS_SHOW_PANEL_END = b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean setEventStatus(MCRootPanel p, MCBeans c) {
/*  82 */     if (!canEvent(p, c)) {
/*  83 */       return false;
/*     */     }
/*     */     
/*  86 */     MODULE_ID = p.getModuleID();
/*  87 */     SCREEN_ID = p.getScreenID();
/*  88 */     SERIAL = p.getSerial();
/*  89 */     EVENT_COMPO = c.getName();
/*  90 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void setEndTime() {
/*  99 */     EVENT_END_TIME = System.currentTimeMillis();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean canEvent(MCRootPanel p, MCBeans c) {
/* 111 */     MCFrame f = p.getFrame();
/*     */     
/* 113 */     if (f != null && !f.canActive()) {
/* 114 */       return false;
/*     */     }
/*     */     
/* 117 */     if ((!MCStringUtil.eq(MODULE_ID, p.getModuleID()) || 
/* 118 */       !MCStringUtil.eq(SCREEN_ID, p.getScreenID()) || 
/* 119 */       SERIAL != p.getSerial() || !MCStringUtil.eq(EVENT_COMPO, p.getName())) && (
/* 120 */       !isShowPanelEnd() || ignoreMillis())) {
/* 121 */       return false;
/*     */     }
/*     */     
/* 124 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean ignoreMillis() {
/* 135 */     if (IGNORE_MILLIS <= -1L) {
/* 136 */       IGNORE_MILLIS = Long.parseLong(getIgnoreMillisString());
/*     */     }
/*     */     
/* 139 */     if (EVENT_END_TIME != -1L) {
/* 140 */       long l = System.currentTimeMillis() - EVENT_END_TIME;
/* 141 */       if (l < IGNORE_MILLIS) {
/* 142 */         return true;
/*     */       }
/*     */     } 
/* 145 */     return false;
/*     */   }
/*     */   
/*     */   static int getIgnoreMillis() {
/* 149 */     return Integer.parseInt(getIgnoreMillisString());
/*     */   }
/*     */   
/*     */   private static String getIgnoreMillisString() {
/* 153 */     return MCConst.beans.getString(
/* 154 */         "__action.ignoretimemillis", String.valueOf(IGNORE_MILLIS));
/*     */   }
/*     */   
/*     */   static boolean isShowPanelEnd() {
/* 158 */     return IS_SHOW_PANEL_END;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\action\MCEventStatus.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */