/*     */ package mcframe.clientCore.beans.action;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MCKeyAssignCache
/*     */ {
/*  23 */   private final List<MCKeyAssign> list = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String _module_id;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String _screen_id;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCKeyAssignCache() {
/*  48 */     this._module_id = null;
/*  49 */     this._screen_id = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCKeyAssignCache(MCRootPanel panel) {
/*  60 */     this._module_id = panel.getModuleID();
/*  61 */     this._screen_id = panel.getScreenID();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void add(MCKeyAssign key) {
/*  72 */     this.list.add(key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCKeyAssign get(String type) {
/*  85 */     if (type != null) {
/*  86 */       MCKeyAssign[] a = this.list.<MCKeyAssign>toArray(new MCKeyAssign[this.list.size()]); byte b; int i; MCKeyAssign[] arrayOfMCKeyAssign1;
/*  87 */       for (i = (arrayOfMCKeyAssign1 = a).length, b = 0; b < i; ) { MCKeyAssign k = arrayOfMCKeyAssign1[b];
/*  88 */         if (type.equals(k.getType()))
/*  89 */           return k; 
/*     */         b++; }
/*     */     
/*     */     } 
/*  93 */     return null;
/*     */   }
/*     */   
/*     */   boolean equals(MCRootPanel panel) {
/*  97 */     return (panel != null) ? equals(
/*  98 */         panel.getModuleID(), panel.getScreenID()) : false;
/*     */   }
/*     */   
/*     */   private boolean equals(String module, String screen) {
/* 102 */     return (module.equals(this._module_id) && screen.equals(this._screen_id));
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\action\MCKeyAssignCache.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */