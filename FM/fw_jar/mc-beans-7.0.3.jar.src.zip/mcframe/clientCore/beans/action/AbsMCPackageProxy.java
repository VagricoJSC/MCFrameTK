/*    */ package mcframe.clientCore.beans.action;
/*    */ 
/*    */ import mcframe.clientCore.beans.MCBeans;
/*    */ import mcframe.clientCore.beans.MCRootPanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbsMCPackageProxy
/*    */ {
/*    */   protected void setEndTime() {
/* 29 */     MCEventStatus.setEndTime();
/*    */   }
/*    */   
/*    */   protected void setShowPanelEnd(boolean b) {
/* 33 */     MCEventStatus.setShowPanelEnd(b);
/* 34 */     if (b) {
/* 35 */       MCComboBoxProxy.PROXY.setListPressing(false);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean setEventStatus(MCRootPanel p, MCBeans c) {
/* 49 */     return MCEventStatus.setEventStatus(p, c);
/*    */   }
/*    */   
/*    */   protected int getIgnoreMillis() {
/* 53 */     return MCEventStatus.getIgnoreMillis();
/*    */   }
/*    */   
/*    */   protected void clearKeyAssignCache(MCRootPanel panel) {
/* 57 */     MCKeyAssignCacher.clear(panel);
/*    */   }
/*    */   
/*    */   protected MCFunctionKey getF10() {
/* 61 */     return MCFunctionKey.F10;
/*    */   }
/*    */   
/*    */   protected boolean canEvent(MCRootPanel p, MCBeans c) {
/* 65 */     return MCEventStatus.canEvent(p, c);
/*    */   }
/*    */   
/*    */   protected boolean isShowPanelEnd() {
/* 69 */     return MCEventStatus.isShowPanelEnd();
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\action\AbsMCPackageProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */