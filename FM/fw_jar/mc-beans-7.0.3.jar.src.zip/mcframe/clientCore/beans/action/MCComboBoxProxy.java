/*    */ package mcframe.clientCore.beans.action;
/*    */ 
/*    */ import mcframe.clientCore.beans.combobox.AbsMCComboBox;
/*    */ import mcframe.clientCore.beans.combobox.AbsMCPackageProxy;
/*    */ 
/*    */ final class MCComboBoxProxy
/*    */   extends AbsMCPackageProxy {
/*  8 */   static final MCComboBoxProxy PROXY = new MCComboBoxProxy();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void cancelComboPopup(AbsMCComboBox<?> compo) {
/* 21 */     super.cancelComboPopup(compo);
/*    */   }
/*    */ 
/*    */   
/*    */   protected Boolean getFirePopupMenuCanceledProperty(AbsMCComboBox<?> compo) {
/* 26 */     return super.getFirePopupMenuCanceledProperty(compo);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void setFirePopupMenuCanceledProperty(AbsMCComboBox<?> compo, Boolean property) {
/* 32 */     super.setFirePopupMenuCanceledProperty(compo, property);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void setListPressing(boolean pressing) {
/* 37 */     super.setListPressing(pressing);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\action\MCComboBoxProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */