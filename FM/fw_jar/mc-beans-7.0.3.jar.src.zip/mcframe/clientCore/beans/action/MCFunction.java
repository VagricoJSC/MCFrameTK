/*     */ package mcframe.clientCore.beans.action;
/*     */ 
/*     */ import mcframe.clientCore.beans.MCBeans;
/*     */ import mcframe.clientCore.beans.MCFrame;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.event.MCFunctionBeans;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MCFunction
/*     */ {
/*     */   private final MCFunctionKey _key;
/*     */   private final MCFunctionBeans _compo;
/*     */   private final int _type;
/*     */   
/*     */   public MCFunction(MCFunctionKey key, MCFunctionBeans compo, int type) {
/*  51 */     this._key = key;
/*  52 */     this._compo = compo;
/*  53 */     this._type = type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCFunctionKey getKey() {
/*  65 */     return this._key;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCFunctionBeans getBeans() {
/*  77 */     return this._compo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getType() {
/*  88 */     return this._type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void action() {
/*  98 */     MCFunctionBeans b = getBeans();
/*  99 */     if (b != null) {
/* 100 */       MCRootPanel bp = b.getBaseRootPanel();
/*     */ 
/*     */       
/* 103 */       if (!MCBeansProxy.PROXY.isInitFocusLaterEnd(bp)) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 108 */       MCFrame frame = bp.getFrame();
/* 109 */       if (frame != null && frame.isCalling()) {
/*     */         return;
/*     */       }
/*     */ 
/*     */       
/* 114 */       if (!MCEventStatus.setEventStatus(bp, (MCBeans)b)) {
/*     */         return;
/*     */       }
/*     */       
/* 118 */       b.action(this);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\action\MCFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */