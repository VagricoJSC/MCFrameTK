/*    */ package mcframe.clientCore.beans.action;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MCActionInfo
/*    */ {
/*    */   private final String _key;
/*    */   private final String _clazz;
/*    */   private final String _method;
/*    */   
/*    */   MCActionInfo(String key, String clazz, String method) {
/* 46 */     this._key = key;
/* 47 */     this._clazz = clazz;
/* 48 */     this._method = method;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   final String getKey() {
/* 59 */     return this._key;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   final String getClassName() {
/* 70 */     return this._clazz;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   final String getMethodName() {
/* 81 */     return this._method;
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\action\MCActionInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */