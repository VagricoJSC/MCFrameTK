/*     */ package mcframe.clientCore.beans.action;
/*     */ 
/*     */ import java.awt.event.KeyEvent;
/*     */ import javax.swing.KeyStroke;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MCFunctionKey
/*     */ {
/*  22 */   public static final MCFunctionKey F1 = new MCFunctionKey(112);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  30 */   public static final MCFunctionKey F2 = new MCFunctionKey(113);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  38 */   public static final MCFunctionKey F3 = new MCFunctionKey(114);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   public static final MCFunctionKey F4 = new MCFunctionKey(115);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   public static final MCFunctionKey F5 = new MCFunctionKey(116);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   public static final MCFunctionKey F6 = new MCFunctionKey(117);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   public static final MCFunctionKey F7 = new MCFunctionKey(118);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   public static final MCFunctionKey F8 = new MCFunctionKey(119);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  86 */   public static final MCFunctionKey F9 = new MCFunctionKey(120);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   static final MCFunctionKey F10 = new MCFunctionKey(121);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 103 */   public static final MCFunctionKey F11 = new MCFunctionKey(122);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 111 */   public static final MCFunctionKey F12 = new MCFunctionKey(123);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 119 */   public static final MCFunctionKey F13 = new MCFunctionKey(112, 
/* 120 */       61440);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 128 */   public static final MCFunctionKey F14 = new MCFunctionKey(113, 
/* 129 */       61441);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 137 */   public static final MCFunctionKey F15 = new MCFunctionKey(114, 
/* 138 */       61442);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 146 */   public static final MCFunctionKey F16 = new MCFunctionKey(115, 
/* 147 */       61443);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 155 */   public static final MCFunctionKey F17 = new MCFunctionKey(116, 
/* 156 */       61444);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 164 */   public static final MCFunctionKey F18 = new MCFunctionKey(117, 
/* 165 */       61445);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 173 */   public static final MCFunctionKey F19 = new MCFunctionKey(118, 
/* 174 */       61446);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 182 */   public static final MCFunctionKey F20 = new MCFunctionKey(119, 
/* 183 */       61447);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 191 */   public static final MCFunctionKey F21 = new MCFunctionKey(120, 
/* 192 */       61448);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 200 */   public static final MCFunctionKey F23 = new MCFunctionKey(122, 
/* 201 */       61450);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 209 */   public static final MCFunctionKey F24 = new MCFunctionKey(123, 
/* 210 */       61451);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 218 */   private static final MCFunctionKey[] KEYS = new MCFunctionKey[] { 
/* 219 */       F1, F2, F3, F4, F5, F6, F7, F8, F9, F11, F12, F13, F14, F15, F16, F17, F18, 
/* 220 */       F19, F20, F21, F23, F24 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final KeyStroke _stroke;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int _code;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCFunctionKey(int code) {
/* 247 */     this._stroke = KeyStroke.getKeyStroke(code, 0);
/* 248 */     this._code = code;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCFunctionKey(int code, int view) {
/* 260 */     this._stroke = KeyStroke.getKeyStroke(code, 1);
/* 261 */     this._code = view;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final KeyStroke getKeyStroke() {
/* 272 */     return this._stroke;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getKeyCode() {
/* 283 */     return this._code;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getKeyText() {
/* 294 */     return KeyEvent.getKeyText(getKeyCode());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final MCFunctionKey[] array() {
/* 305 */     return KEYS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final MCFunctionKey get(KeyStroke stroke) {
/*     */     byte b;
/*     */     int i;
/*     */     MCFunctionKey[] arrayOfMCFunctionKey;
/* 318 */     for (i = (arrayOfMCFunctionKey = array()).length, b = 0; b < i; ) { MCFunctionKey k = arrayOfMCFunctionKey[b];
/* 319 */       if (k.getKeyStroke().equals(stroke))
/* 320 */         return k; 
/*     */       b++; }
/*     */     
/* 323 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\action\MCFunctionKey.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */