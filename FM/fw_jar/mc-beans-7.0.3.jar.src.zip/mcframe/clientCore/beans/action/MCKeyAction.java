/*      */ package mcframe.clientCore.beans.action;
/*      */ 
/*      */ import java.awt.Component;
/*      */ import java.awt.Container;
/*      */ import java.awt.Point;
/*      */ import java.awt.Rectangle;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import javax.swing.AbstractButton;
/*      */ import javax.swing.JComponent;
/*      */ import javax.swing.JPopupMenu;
/*      */ import javax.swing.text.JTextComponent;
/*      */ import mcframe.clientCore.beans.MCBeansUtil;
/*      */ import mcframe.clientCore.beans.MCButton;
/*      */ import mcframe.clientCore.beans.MCCalendarField;
/*      */ import mcframe.clientCore.beans.MCField;
/*      */ import mcframe.clientCore.beans.MCFrame;
/*      */ import mcframe.clientCore.beans.MCImageView;
/*      */ import mcframe.clientCore.beans.MCListBeans;
/*      */ import mcframe.clientCore.beans.MCMode;
/*      */ import mcframe.clientCore.beans.MCModeBeans;
/*      */ import mcframe.clientCore.beans.MCPanel;
/*      */ import mcframe.clientCore.beans.MCPasswordField;
/*      */ import mcframe.clientCore.beans.MCRootPanel;
/*      */ import mcframe.clientCore.beans.MCRowBeans;
/*      */ import mcframe.clientCore.beans.MCSplitPane;
/*      */ import mcframe.clientCore.beans.MCTabOrderBeans;
/*      */ import mcframe.clientCore.beans.MCTabbedPane;
/*      */ import mcframe.clientCore.beans.MCTextArea;
/*      */ import mcframe.clientCore.beans.combobox.AbsMCComboBox;
/*      */ import mcframe.clientCore.beans.combobox.MCCalendarComboBox;
/*      */ import mcframe.clientCore.beans.combobox.MCDateComboBox;
/*      */ import mcframe.clientCore.beans.combobox.MCFieldComboBox;
/*      */ import mcframe.clientCore.beans.combobox.MCNumberComboBox;
/*      */ import mcframe.clientCore.beans.combobox.MCTextComboBox;
/*      */ import mcframe.clientCore.beans.combobox.MCTimestampComboBox;
/*      */ import mcframe.clientCore.beans.popup.MCPopupMenu;
/*      */ import mcframe.clientCore.beans.table.MCColumnConfig;
/*      */ import mcframe.clientCore.beans.table.MCEditorBeans;
/*      */ import mcframe.clientCore.beans.table.MCEditorCheckBox;
/*      */ import mcframe.clientCore.beans.table.MCEditorDateComboBox;
/*      */ import mcframe.clientCore.beans.table.MCEditorDateField;
/*      */ import mcframe.clientCore.beans.table.MCEditorNumberComboBox;
/*      */ import mcframe.clientCore.beans.table.MCEditorNumberField;
/*      */ import mcframe.clientCore.beans.table.MCEditorPasswordField;
/*      */ import mcframe.clientCore.beans.table.MCEditorTextComboBox;
/*      */ import mcframe.clientCore.beans.table.MCEditorTextField;
/*      */ import mcframe.clientCore.beans.table.MCEditorTimestampComboBox;
/*      */ import mcframe.clientCore.beans.table.MCEditorTimestampField;
/*      */ import mcframe.clientCore.beans.table.MCTable;
/*      */ import mcframe.clientCore.container.MCConstRow;
/*      */ import mcframe.commonCore.lang.MCStringUtil;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MCKeyAction
/*      */ {
/*      */   protected void none(Object object) {}
/*      */   
/*      */   protected void next(Component compo) {
/*   93 */     compo.transferFocus();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void cancel(MCRowBeans compo) {
/*  105 */     compo.setRowToView();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void clear(MCField compo) {
/*  116 */     if (compo.isEditable()) {
/*  117 */       compo.setText(null);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void clear(MCTextArea compo) {
/*  129 */     if (compo.isEditable()) {
/*  130 */       compo.setText(null);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void clear(MCPasswordField compo) {
/*  142 */     if (compo.isEditable()) {
/*  143 */       compo.setText(null);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <T extends mcframe.commonCore.lang.MCCalendarDate<?>> void sysdate(MCCalendarField<T> compo) {
/*  156 */     if (compo.isEditable()) {
/*  157 */       compo.setText(compo.today());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <T extends mcframe.commonCore.lang.MCCalendarDate<?>> void sysdate(MCCalendarComboBox<T> compo) {
/*  170 */     if (compo.isEditable()) {
/*  171 */       compo.setText(compo.today());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <T extends Comparable<?>> void next(AbsMCComboBox<T> compo) {
/*  185 */     compo.transferFocus();
/*  186 */     if (compo.isPopupVisible()) {
/*  187 */       compo.setPopupVisible(false);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void cancel(MCTextComboBox compo) {
/*  201 */     _cancel((AbsMCComboBox<Comparable<?>>)compo);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void cancel(MCNumberComboBox compo) {
/*  214 */     _cancel((AbsMCComboBox<Comparable<?>>)compo);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void cancel(MCDateComboBox compo) {
/*  227 */     _cancel((AbsMCComboBox<Comparable<?>>)compo);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void cancel(MCTimestampComboBox compo) {
/*  240 */     _cancel((AbsMCComboBox<Comparable<?>>)compo);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private <T extends Comparable<?>> void _cancel(AbsMCComboBox<T> compo) {
/*  254 */     if (compo.isPopupVisible()) {
/*  255 */       MCComboBoxProxy.PROXY.cancelComboPopup(compo);
/*      */     }
/*  257 */     compo.setRowToView();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <T extends Comparable<?>> void clear(AbsMCComboBox<T> compo) {
/*  269 */     if (!compo.isEditable()) {
/*      */       return;
/*      */     }
/*  272 */     if (compo.isPopupVisible()) {
/*  273 */       compo.setPopupVisible(false);
/*      */     }
/*  275 */     compo.setText(null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <T extends Comparable<?>> void hidePopup(AbsMCComboBox<T> compo) {
/*  287 */     compo.setPopupVisible(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <T extends Comparable<?>> void selectNext(MCCalendarField<?> compo) {
/*  298 */     if (compo.isAmPmField() && MCMode.isEnable((MCModeBeans)compo)) {
/*  299 */       MCBeansProxy.PROXY.showOrChangeAmPm(compo);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <T extends Comparable<?>> void selectNext(AbsMCComboBox<T> compo) {
/*  312 */     if (compo.isPopupVisible()) {
/*  313 */       compo.selectNextPossibleValue();
/*      */     } else {
/*      */       
/*  316 */       compo.setPopupVisible(true);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <T extends Comparable<?>> void selectPrevious(MCCalendarField<?> compo) {
/*  329 */     if (compo.isAmPmField() && MCMode.isEnable((MCModeBeans)compo)) {
/*  330 */       MCBeansProxy.PROXY.showOrChangeAmPm(compo);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <T extends Comparable<?>> void selectPrevious(AbsMCComboBox<T> compo) {
/*  343 */     compo.selectPreviousPossibleValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <T extends Comparable<?>> void selectPageDown(AbsMCComboBox<T> compo) {
/*  356 */     compo.selectPageDownPossibleValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <T extends Comparable<?>> void selectPageUp(AbsMCComboBox<T> compo) {
/*  369 */     compo.selectPageUpPossibleValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void action(AbstractButton compo) {
/*  380 */     compo.doClick();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void action(MCButton compo) {
/*  391 */     MCBeansProxy.PROXY.writeButtonActionLog(compo, true);
/*  392 */     compo.doClick();
/*  393 */     MCBeansProxy.PROXY.writeButtonActionLog(compo, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void close(MCRootPanel compo) {
/*  404 */     compo.requestCloseWindow();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void next(MCRootPanel compo) {
/*  415 */     MCFrame bf = compo.getFrame();
/*  416 */     if (bf == null || bf.getFrameType() == MCRootPanel.SYSTEM_MODAL) {
/*      */       return;
/*      */     }
/*  419 */     MCFrame[] a = MCBeansUtil.getAllFrames();
/*  420 */     int cnt = a.length;
/*  421 */     if (cnt <= 1) {
/*      */       return;
/*      */     }
/*  424 */     for (int i = 0; i < cnt; ) {
/*  425 */       if (a[i] != bf) {
/*      */         i++; continue;
/*      */       } 
/*  428 */       int idx = (cnt + i + 1) % cnt;
/*      */       while (true) {
/*  430 */         MCFrame f = a[idx];
/*  431 */         if (f == bf) {
/*      */           return;
/*      */         }
/*  434 */         if (f.canActive()) {
/*  435 */           f.active();
/*      */           return;
/*      */         } 
/*  438 */         if (++idx >= cnt) {
/*  439 */           idx = 0;
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void previous(MCRootPanel compo) {
/*  453 */     MCFrame bf = compo.getFrame();
/*  454 */     if (bf == null || bf.getFrameType() == MCRootPanel.SYSTEM_MODAL) {
/*      */       return;
/*      */     }
/*  457 */     MCFrame[] a = MCBeansUtil.getAllFrames();
/*  458 */     int cnt = a.length;
/*  459 */     if (cnt <= 1) {
/*      */       return;
/*      */     }
/*  462 */     for (int i = 0; i < cnt; ) {
/*  463 */       if (a[i] != bf) {
/*      */         i++; continue;
/*      */       } 
/*  466 */       int idx = (cnt + i - 1) % cnt;
/*      */       while (true) {
/*  468 */         MCFrame f = a[idx];
/*  469 */         if (f == bf) {
/*      */           return;
/*      */         }
/*  472 */         if (f.canActive()) {
/*  473 */           f.active();
/*      */           return;
/*      */         } 
/*  476 */         if (--idx < 0) {
/*  477 */           idx = cnt - 1;
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void nextCell(MCTable<?> compo) {
/*  491 */     compo.nextCell();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void previousCell(MCTable<?> compo) {
/*  502 */     compo.previousCell();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void upCell(MCTable<?> compo) {
/*  513 */     compo.verticalCell(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void downCell(MCTable<?> compo) {
/*  524 */     compo.verticalCell(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void leftCell(MCTable<?> compo) {
/*  535 */     compo.horizontalCell(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void rightCell(MCTable<?> compo) {
/*  546 */     compo.horizontalCell(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void firstColumn(MCEditorBeans compo) {
/*  557 */     firstColumn(compo.getTable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void firstColumn(MCTable<?> compo) {
/*  568 */     compo.terminalColumn(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void lastColumn(MCEditorBeans compo) {
/*  579 */     lastColumn(compo.getTable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void lastColumn(MCTable<?> compo) {
/*  590 */     compo.terminalColumn(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void firstRecord(MCTable<?> compo) {
/*  601 */     compo.selectTerminalRecord(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void lastRecord(MCTable<?> compo) {
/*  612 */     compo.selectTerminalRecord(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void firstRecordCell(MCTable<?> compo) {
/*  625 */     recordCell(compo, ((MCConstRow)compo.getViewRows().get(0)).getGUIIndex());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void lastRecordCell(MCTable<?> compo) {
/*  638 */     recordCell(compo, ((MCConstRow)compo.getViewRows().get(compo.getViewRows().size() - 1)).getGUIIndex());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void recordCell(MCTable<?> compo, int index) {
/*  653 */     if (compo.getMCSelectedRow() > -1) {
/*  654 */       MCColumnConfig col = compo.getSelectedColumnConfig();
/*  655 */       if (col != null) {
/*  656 */         compo.focusCellAt(index, col);
/*      */         return;
/*      */       } 
/*      */     } 
/*  660 */     compo.selectRowNoFocus(index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void pageUp(MCTable<?> compo) {
/*  671 */     compo.selectVerticalScroll(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void pageDown(MCTable<?> compo) {
/*  682 */     compo.selectVerticalScroll(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void pageLeft(MCEditorBeans compo) {
/*  693 */     pageLeft(compo.getTable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void pageLeft(MCTable<?> compo) {
/*  704 */     compo.pageHorizontalScroll(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void pageRight(MCEditorBeans compo) {
/*  715 */     pageRight(compo.getTable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void pageRight(MCTable<?> compo) {
/*  726 */     compo.pageHorizontalScroll(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void nextRecord(MCTable<?> compo) {
/*  740 */     compo.nextRecord();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void next(MCTable<?> compo) {
/*  752 */     compo.transferFocus();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void previous(MCTable<?> compo) {
/*  764 */     compo.transferFocusBackward();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void copy(MCTable<?> compo) {
/*  778 */     MCColumnConfig c = compo.getSelectedColumnConfig();
/*  779 */     if (c == null || MCStringUtil.isNull(c.getBaseRowColumnName())) {
/*  780 */       compo.rowCopy(compo.getMCSelectedRows());
/*      */     }
/*      */     else {
/*      */       
/*  784 */       compo.copy();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void rowCopy(MCTable<?> compo) {
/*  796 */     compo.rowCopy(compo.getMCSelectedRows());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void upCell(MCEditorDateField compo) {
/*  806 */     if (compo.isAmPmField() && MCMode.isEnable((MCModeBeans)compo) && 
/*  807 */       MCBeansProxy.PROXY.isShowingAmPmComboList((MCCalendarField<?>)compo)) {
/*  808 */       MCBeansProxy.PROXY.showOrChangeAmPm((MCCalendarField<?>)compo);
/*      */     } else {
/*      */       
/*  811 */       upCell(compo.getTable());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void upCell(MCEditorTimestampField compo) {
/*  821 */     if (compo.isAmPmField() && MCMode.isEnable((MCModeBeans)compo) && 
/*  822 */       MCBeansProxy.PROXY.isShowingAmPmComboList((MCCalendarField<?>)compo)) {
/*  823 */       MCBeansProxy.PROXY.showOrChangeAmPm((MCCalendarField<?>)compo);
/*      */     } else {
/*      */       
/*  826 */       upCell(compo.getTable());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void upCell(MCEditorBeans compo) {
/*  838 */     upCell(compo.getTable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void downCell(MCEditorTimestampField compo) {
/*  848 */     if (compo.isAmPmField() && MCMode.isEnable((MCModeBeans)compo) && 
/*  849 */       MCBeansProxy.PROXY.isShowingAmPmComboList((MCCalendarField<?>)compo)) {
/*  850 */       MCBeansProxy.PROXY.showOrChangeAmPm((MCCalendarField<?>)compo);
/*      */     } else {
/*      */       
/*  853 */       downCell(compo.getTable());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void downCell(MCEditorDateField compo) {
/*  863 */     if (compo.isAmPmField() && MCMode.isEnable((MCModeBeans)compo) && 
/*  864 */       MCBeansProxy.PROXY.isShowingAmPmComboList((MCCalendarField<?>)compo)) {
/*  865 */       MCBeansProxy.PROXY.showOrChangeAmPm((MCCalendarField<?>)compo);
/*      */     } else {
/*      */       
/*  868 */       downCell(compo.getTable());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void downCell(MCEditorBeans compo) {
/*  880 */     downCell(compo.getTable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void leftCell(MCEditorBeans compo) {
/*  891 */     leftCell(compo.getTable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void rightCell(MCEditorBeans compo) {
/*  902 */     rightCell(compo.getTable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void pageUp(MCEditorBeans compo) {
/*  913 */     pageUp(compo.getTable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void pageDown(MCEditorBeans compo) {
/*  924 */     pageDown(compo.getTable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void pageScrollUp(MCEditorBeans compo) {
/*  935 */     pageScrollUp(compo.getTable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void pageScrollUp(MCTable<?> compo) {
/*  946 */     compo.pageVerticalScroll(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void pageScrollDown(MCEditorBeans compo) {
/*  957 */     pageScrollDown(compo.getTable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void pageScrollDown(MCTable<?> compo) {
/*  968 */     compo.pageVerticalScroll(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void next(MCEditorTextField compo) {
/*  980 */     next(compo.getTable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void previous(MCEditorTextField compo) {
/*  992 */     previous(compo.getTable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void upAction(MCEditorTextComboBox compo) {
/* 1004 */     if (compo.isPopupVisible()) {
/* 1005 */       selectPrevious((AbsMCComboBox<Comparable<?>>)compo);
/*      */     } else {
/*      */       
/* 1008 */       upCell(compo.getTable());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void upAction(MCEditorNumberComboBox compo) {
/* 1021 */     if (compo.isPopupVisible()) {
/* 1022 */       selectPrevious((AbsMCComboBox<Comparable<?>>)compo);
/*      */     } else {
/*      */       
/* 1025 */       upCell(compo.getTable());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void upAction(MCEditorDateComboBox compo) {
/* 1038 */     if (compo.isPopupVisible()) {
/* 1039 */       selectPrevious((AbsMCComboBox<Comparable<?>>)compo);
/*      */     } else {
/*      */       
/* 1042 */       upCell(compo.getTable());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void upAction(MCEditorTimestampComboBox compo) {
/* 1055 */     if (compo.isPopupVisible()) {
/* 1056 */       selectPrevious((AbsMCComboBox<Comparable<?>>)compo);
/*      */     } else {
/*      */       
/* 1059 */       upCell(compo.getTable());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void upAction(MCEditorDateField compo) {
/* 1070 */     if (compo.isAmPmField() && MCMode.isEnable((MCModeBeans)compo)) {
/* 1071 */       selectNext((MCCalendarField<?>)compo);
/*      */     } else {
/*      */       
/* 1074 */       upCell(compo.getTable());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void upAction(MCEditorTimestampField compo) {
/* 1084 */     if (compo.isAmPmField() && MCMode.isEnable((MCModeBeans)compo)) {
/* 1085 */       selectNext((MCCalendarField<?>)compo);
/*      */     } else {
/*      */       
/* 1088 */       upCell(compo.getTable());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void downAction(MCEditorDateField compo) {
/* 1098 */     if (compo.isAmPmField() && MCMode.isEnable((MCModeBeans)compo)) {
/* 1099 */       selectNext((MCCalendarField<?>)compo);
/*      */     } else {
/*      */       
/* 1102 */       downCell(compo.getTable());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void downAction(MCEditorTimestampField compo) {
/* 1112 */     if (compo.isAmPmField() && MCMode.isEnable((MCModeBeans)compo)) {
/* 1113 */       selectNext((MCCalendarField<?>)compo);
/*      */     } else {
/*      */       
/* 1116 */       downCell(compo.getTable());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void downAction(MCEditorTextComboBox compo) {
/* 1129 */     if (compo.isPopupVisible()) {
/* 1130 */       selectNext((AbsMCComboBox<Comparable<?>>)compo);
/*      */     } else {
/*      */       
/* 1133 */       downCell(compo.getTable());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void downAction(MCEditorNumberComboBox compo) {
/* 1146 */     if (compo.isPopupVisible()) {
/* 1147 */       selectNext((AbsMCComboBox<Comparable<?>>)compo);
/*      */     } else {
/*      */       
/* 1150 */       downCell(compo.getTable());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void downAction(MCEditorDateComboBox compo) {
/* 1163 */     if (compo.isPopupVisible()) {
/* 1164 */       selectNext((AbsMCComboBox<Comparable<?>>)compo);
/*      */     } else {
/*      */       
/* 1167 */       downCell(compo.getTable());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void downAction(MCEditorTimestampComboBox compo) {
/* 1180 */     if (compo.isPopupVisible()) {
/* 1181 */       selectNext((AbsMCComboBox<Comparable<?>>)compo);
/*      */     } else {
/*      */       
/* 1184 */       downCell(compo.getTable());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void next(MCEditorTextComboBox compo) {
/* 1197 */     next(compo.getTable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void next(MCEditorNumberComboBox compo) {
/* 1209 */     next(compo.getTable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void next(MCEditorDateComboBox compo) {
/* 1221 */     next(compo.getTable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void next(MCEditorTimestampComboBox compo) {
/* 1233 */     next(compo.getTable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void previous(MCEditorTextComboBox compo) {
/* 1245 */     previous(compo.getTable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void previous(MCEditorNumberComboBox compo) {
/* 1257 */     previous(compo.getTable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void previous(MCEditorDateComboBox compo) {
/* 1269 */     previous(compo.getTable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void previous(MCEditorTimestampComboBox compo) {
/* 1281 */     previous(compo.getTable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void next(MCEditorDateField compo) {
/* 1293 */     next(compo.getTable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void previous(MCEditorDateField compo) {
/* 1305 */     previous(compo.getTable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void next(MCEditorNumberField compo) {
/* 1317 */     next(compo.getTable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void previous(MCEditorNumberField compo) {
/* 1329 */     previous(compo.getTable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void nextCell(MCEditorBeans compo) {
/* 1340 */     nextCell(compo.getTable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void previousCell(MCEditorBeans compo) {
/* 1351 */     previousCell(compo.getTable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void nextRecord(MCEditorBeans compo) {
/* 1364 */     nextRecord(compo.getTable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void next(MCEditorCheckBox compo) {
/* 1376 */     next(compo.getTable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void previous(MCEditorCheckBox compo) {
/* 1388 */     previous(compo.getTable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void next(MCEditorPasswordField compo) {
/* 1400 */     next(compo.getTable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void previous(MCEditorPasswordField compo) {
/* 1412 */     previous(compo.getTable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void selectForward(JTextComponent compo) {
/* 1424 */     String text = compo.getText();
/* 1425 */     if (!MCStringUtil.isNull(text)) {
/* 1426 */       int mark = compo.getCaret().getMark();
/* 1427 */       int dot = compo.getCaret().getDot();
/* 1428 */       if (mark > dot) {
/* 1429 */         mark = dot;
/*      */       }
/* 1431 */       compo.select(0, mark);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <T extends Comparable<?>> void selectForward(MCFieldComboBox<T> compo) {
/* 1445 */     compo.selectForward();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void selectBackword(JTextComponent compo) {
/* 1457 */     String text = compo.getText();
/* 1458 */     if (!MCStringUtil.isNull(text)) {
/* 1459 */       int mark = compo.getCaret().getMark();
/* 1460 */       int dot = compo.getCaret().getDot();
/* 1461 */       if (mark < dot) {
/* 1462 */         mark = dot;
/*      */       }
/* 1464 */       compo.select(mark, text.length());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <T extends Comparable<?>> void selectBackword(MCFieldComboBox<T> compo) {
/* 1478 */     compo.selectBackword();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doAction(MCActionBeans compo) {
/* 1489 */     MCRootPanel panel = compo.getRootPanel();
/* 1490 */     boolean consume = false;
/* 1491 */     if (panel != null) {
/* 1492 */       consume = panel.doAction(compo);
/*      */     }
/* 1494 */     if (!consume) {
/* 1495 */       compo.doAction();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <T extends mcframe.commonCore.lang.MCCalendarDate<?>> void showCalendar(MCCalendarField<T> compo) {
/* 1508 */     compo.showCalendar();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void showImagePanel(MCImageView compo) {
/* 1519 */     compo.showImagePanel();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void nextPanel(Component compo) {
/*      */     List<MCTabOrderBeans> bp_list;
/*      */     int bp_cnt;
/*      */     MCTabOrderBeans[] bp_compos;
/* 1536 */     if (!MCBeansUtil.requestCommit(compo)) {
/*      */       return;
/*      */     }
/* 1539 */     MCPanel pnl = getTargetPanel(compo);
/*      */     
/* 1541 */     MCTabOrderBeans last = null;
/*      */ 
/*      */ 
/*      */     
/* 1545 */     if (pnl != null) {
/* 1546 */       MCRootPanel bp = pnl.getBaseRootPanel();
/* 1547 */       bp_list = bp.getTabOrderBeans();
/* 1548 */       List<MCTabOrderBeans> list = pnl.getTabOrderBeans();
/*      */ 
/*      */ 
/*      */       
/* 1552 */       last = list.get(list.size() - 1);
/*      */       
/* 1554 */       bp_cnt = bp_list.size();
/* 1555 */       bp_compos = bp_list.<MCTabOrderBeans>toArray(new MCTabOrderBeans[bp_cnt]);
/*      */     } else {
/*      */       
/* 1558 */       MCRootPanel bp = MCBeansUtil.getBaseRootPanel(compo);
/* 1559 */       bp_list = bp.getTabOrderBeans();
/* 1560 */       bp_cnt = bp_list.size();
/* 1561 */       bp_compos = bp_list.<MCTabOrderBeans>toArray(new MCTabOrderBeans[bp_cnt]);
/* 1562 */       int idx = bp_list.indexOf(compo);
/* 1563 */       while (idx < bp_cnt) {
/* 1564 */         last = bp_compos[idx++];
/* 1565 */         pnl = getTargetPanel((Component)last);
/* 1566 */         if (pnl != null) {
/*      */           break;
/*      */         }
/*      */       } 
/*      */     } 
/* 1571 */     if (last != null) {
/* 1572 */       int bp_idx = bp_list.indexOf(last);
/* 1573 */       int idx = bp_idx + 1;
/* 1574 */       while (idx != bp_idx) {
/* 1575 */         if (idx >= bp_cnt) {
/* 1576 */           idx = 0;
/*      */         }
/* 1578 */         if (transferFocus(bp_compos[idx++], true)) {
/*      */           return;
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void previousPanel(Component compo) {
/*      */     List<MCTabOrderBeans> bp_list;
/*      */     int bp_cnt;
/*      */     MCTabOrderBeans[] bp_compos;
/* 1599 */     if (!MCBeansUtil.requestCommit(compo)) {
/*      */       return;
/*      */     }
/* 1602 */     MCPanel pnl = getTargetPanel(compo);
/*      */     
/* 1604 */     MCTabOrderBeans first = null;
/*      */ 
/*      */ 
/*      */     
/* 1608 */     if (pnl != null) {
/* 1609 */       MCRootPanel bp = pnl.getBaseRootPanel();
/* 1610 */       bp_list = bp.getTabOrderBeans();
/* 1611 */       List<MCTabOrderBeans> list = pnl.getTabOrderBeans();
/* 1612 */       first = list.get(0);
/* 1613 */       bp_cnt = bp_list.size();
/* 1614 */       bp_compos = bp_list.<MCTabOrderBeans>toArray(new MCTabOrderBeans[bp_cnt]);
/*      */     } else {
/*      */       
/* 1617 */       MCRootPanel bp = MCBeansUtil.getBaseRootPanel(compo);
/* 1618 */       bp_list = bp.getTabOrderBeans();
/* 1619 */       first = bp_list.get(0);
/* 1620 */       bp_cnt = bp_list.size();
/* 1621 */       bp_compos = bp_list.<MCTabOrderBeans>toArray(new MCTabOrderBeans[bp_cnt]);
/* 1622 */       int i = bp_cnt - 1;
/* 1623 */       while (i >= 0) {
/* 1624 */         first = bp_compos[i--];
/* 1625 */         pnl = getTargetPanel((Component)first);
/* 1626 */         if (pnl != null) {
/*      */           break;
/*      */         }
/*      */       } 
/*      */     } 
/* 1631 */     int bp_idx = bp_list.indexOf(first);
/* 1632 */     int idx = bp_idx - 1;
/* 1633 */     while (idx != bp_idx) {
/* 1634 */       if (idx == -1) {
/* 1635 */         idx = bp_cnt - 1;
/*      */       }
/* 1637 */       if (transferFocus(bp_compos[idx--], false)) {
/*      */         return;
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean transferFocus(MCTabOrderBeans compo, boolean next) {
/* 1655 */     if (!compo.isTabOrderEnabled()) {
/* 1656 */       return false;
/*      */     }
/* 1658 */     if (!compo.isFocusableByKeybord()) {
/* 1659 */       return false;
/*      */     }
/* 1661 */     if (!checkTab((Component)compo)) {
/* 1662 */       return false;
/*      */     }
/* 1664 */     if (compo instanceof MCListBeans) {
/* 1665 */       ((MCListBeans)compo)
/* 1666 */         .setCellFocusPattern(next ? 1000 : 2000);
/*      */     }
/* 1668 */     ((Component)compo).requestFocus();
/* 1669 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MCPanel getTargetPanel(Component compo) {
/*      */     List<MCPanel> pl;
/* 1685 */     MCRootPanel bp = MCBeansUtil.getBaseRootPanel(compo);
/* 1686 */     if (bp != null) {
/* 1687 */       pl = bp.getMCPanels();
/*      */     } else {
/*      */       
/* 1690 */       pl = new ArrayList<>();
/*      */     } 
/*      */     
/* 1693 */     MCPanel result = null;
/* 1694 */     Container cont = (compo instanceof Container) ? (Container)compo : 
/* 1695 */       compo.getParent();
/* 1696 */     while (cont != null) {
/* 1697 */       if (cont instanceof MCPanel) {
/* 1698 */         MCPanel pnl = (MCPanel)cont;
/* 1699 */         if (pnl.getFirstBeans() != null) {
/* 1700 */           result = pnl;
/* 1701 */           if (pl.contains(result)) {
/* 1702 */             return result;
/*      */           }
/*      */         } 
/*      */       } 
/*      */       
/* 1707 */       cont = cont.getParent();
/*      */     } 
/* 1709 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean checkTab(Component compo) {
/* 1724 */     while (compo != null) {
/* 1725 */       Container c = compo.getParent();
/* 1726 */       if (c instanceof MCTabbedPane) {
/* 1727 */         MCTabbedPane tp = (MCTabbedPane)c;
/* 1728 */         if (tp.getSelectedComponent() != compo) {
/* 1729 */           return false;
/*      */         }
/*      */       } 
/* 1732 */       compo = c;
/*      */     } 
/* 1734 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void showPopup(JComponent compo) {
/* 1746 */     JPopupMenu m = compo.getComponentPopupMenu();
/* 1747 */     if (m == null) {
/*      */       return;
/*      */     }
/* 1750 */     Point p = compo.getPopupLocation(null);
/* 1751 */     if (p == null) {
/* 1752 */       Rectangle e = compo.getVisibleRect();
/* 1753 */       p = new Point(e.x + e.width / 2, e.y + e.height / 2);
/*      */     } 
/* 1755 */     m.show(compo, p.x, p.y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void showPanelPopup(JComponent compo) {
/* 1767 */     MCRootPanel p = MCBeansUtil.getRootPanel(compo);
/* 1768 */     if (p == null) {
/*      */       return;
/*      */     }
/* 1771 */     MCPopupMenu m = p.getComponentPopupMenu();
/* 1772 */     if (m == null) {
/*      */       return;
/*      */     }
/* 1775 */     Point o = compo.getPopupLocation(null);
/* 1776 */     if (o == null) {
/* 1777 */       Rectangle e = compo.getVisibleRect();
/* 1778 */       o = new Point(e.x + e.width / 2, e.y + e.height / 2);
/*      */     } 
/* 1780 */     m.show((Component)p, o.x, o.y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void showTablePopup(MCEditorBeans compo) {
/* 1792 */     MCTable<?> t = compo.getTable().getBaseTable();
/* 1793 */     MCPopupMenu m = t.getComponentPopupMenu();
/* 1794 */     if (m == null) {
/*      */       return;
/*      */     }
/* 1797 */     Point o = ((JComponent)compo).getPopupLocation(null);
/* 1798 */     if (o == null) {
/* 1799 */       Rectangle e = ((JComponent)compo).getVisibleRect();
/* 1800 */       o = new Point(e.x + e.width / 2, e.y + e.height / 2);
/*      */     } 
/* 1802 */     m.show((Component)t, o.x, o.y);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void selectRowNumberColumn(MCEditorBeans compo) {
/* 1814 */     MCTable<?> t = compo.getTable().getBaseTable();
/* 1815 */     MCColumnConfig n = t.getRowNumberColumn();
/* 1816 */     boolean e = false; byte b; int i; MCColumnConfig[] arrayOfMCColumnConfig;
/* 1817 */     for (i = (arrayOfMCColumnConfig = t.getAllViewColumnConfigs()).length, b = 0; b < i; ) { MCColumnConfig c = arrayOfMCColumnConfig[b];
/* 1818 */       if (c == n) {
/* 1819 */         e = true; break;
/*      */       } 
/*      */       b++; }
/*      */     
/* 1823 */     if (e) {
/* 1824 */       t.focusCellAt(compo.getRowIndex(), n);
/*      */     }
/*      */   }
/*      */   
/*      */   protected void shiftDown(MCTable<?> table) {
/* 1829 */     MCTableProxy.PROXY.nextRowSelectionChange(table);
/*      */   }
/*      */   
/*      */   protected void shiftUp(MCTable<?> table) {
/* 1833 */     MCTableProxy.PROXY.previousRowSelectionChange(table);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void focus(MCSplitPane compo) {
/* 1844 */     compo.mcRequestFocus();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void showBeansInfo(MCRootPanel panel) {
/* 1855 */     MCBeansProxy.PROXY.showBeansInfoToolTip(panel.getBaseRootPanel());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <T extends Comparable<?>> void enter(AbsMCComboBox<T> compo) {
/* 1869 */     if (compo.isPopupVisible()) {
/*      */       
/* 1871 */       if (!MCBeansUtil.requestCommit((Component)compo)) {
/* 1872 */         Boolean p = MCComboBoxProxy.PROXY.getFirePopupMenuCanceledProperty(compo);
/*      */         try {
/* 1874 */           MCComboBoxProxy.PROXY.setFirePopupMenuCanceledProperty(compo, 
/* 1875 */               Boolean.TRUE);
/* 1876 */           compo.setPopupVisible(false);
/*      */         } finally {
/*      */           
/* 1879 */           MCComboBoxProxy.PROXY.setFirePopupMenuCanceledProperty(compo, p);
/*      */         } 
/*      */       } else {
/*      */         
/* 1883 */         compo.setPopupVisible(false);
/*      */       
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 1890 */       compo.transferFocus();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void enter(MCEditorTextComboBox compo) {
/* 1905 */     _enter((AbsMCComboBox<?>)compo, (MCEditorBeans)compo);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void enter(MCEditorNumberComboBox compo) {
/* 1927 */     _enter((AbsMCComboBox<?>)compo, (MCEditorBeans)compo);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void enter(MCEditorDateComboBox compo) {
/* 1949 */     _enter((AbsMCComboBox<?>)compo, (MCEditorBeans)compo);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void enter(MCEditorTimestampComboBox compo) {
/* 1971 */     _enter((AbsMCComboBox<?>)compo, (MCEditorBeans)compo);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _enter(AbsMCComboBox<?> compo, MCEditorBeans editor) {
/* 1983 */     if (compo.isPopupVisible()) {
/* 1984 */       if (!commitEditor(editor)) {
/* 1985 */         Boolean p = MCComboBoxProxy.PROXY.getFirePopupMenuCanceledProperty(compo);
/*      */         try {
/* 1987 */           MCComboBoxProxy.PROXY.setFirePopupMenuCanceledProperty(compo, 
/* 1988 */               Boolean.TRUE);
/* 1989 */           compo.setPopupVisible(false);
/*      */         } finally {
/*      */           
/* 1992 */           MCComboBoxProxy.PROXY.setFirePopupMenuCanceledProperty(compo, p);
/*      */         } 
/*      */       } else {
/*      */         
/* 1996 */         compo.setPopupVisible(false);
/*      */       } 
/*      */     } else {
/*      */       
/* 2000 */       nextCell(editor);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean commitEditor(MCEditorBeans compo) {
/* 2013 */     return MCTableProxy.PROXY.commitEditor(compo.getTable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void selectAll(MCTable<?> table) {
/* 2024 */     table.mcSelectAll();
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\action\MCKeyAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */