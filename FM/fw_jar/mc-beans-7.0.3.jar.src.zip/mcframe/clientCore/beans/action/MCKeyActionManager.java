/*     */ package mcframe.clientCore.beans.action;
/*     */ 
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.swing.ActionMap;
/*     */ import javax.swing.InputMap;
/*     */ import javax.swing.KeyStroke;
/*     */ import mcframe.clientCore.beans.MCCacheType;
/*     */ import mcframe.clientCore.beans.MCResourceBeans;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.sys.MCFactory;
/*     */ import mcframe.commonCore.util.MCCollectionUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MCKeyActionManager
/*     */ {
/*     */   public static void init(MCResourceBeans compo, InputMap input, ActionMap action) {
/*  48 */     if (compo == null || input == null || action == null) {
/*     */       return;
/*     */     }
/*  51 */     String t = compo.getType();
/*  52 */     MCKeyAssign c = MCKeyAssignCacher.get(MCCacheType.SYSTEM, null, t);
/*  53 */     if (c == null) {
/*     */ 
/*     */ 
/*     */       
/*  57 */       InputMap im = new InputMap();
/*  58 */       List<MCActionInfo> list = new ArrayList<>();
/*  59 */       setResourceValue(list, im, t);
/*  60 */       c = new MCKeyAssign(t, im, list);
/*  61 */       MCKeyAssignCacher.cache(MCCacheType.SYSTEM, null, c);
/*     */     } 
/*  63 */     setInputMap(c, input);
/*  64 */     setActionMap(compo, c, action);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void initScreen(MCResourceBeans compo, InputMap input, ActionMap action) {
/*  77 */     if (compo == null || input == null || action == null) {
/*     */       return;
/*     */     }
/*  80 */     MCRootPanel bp = compo.getBaseRootPanel();
/*  81 */     if (bp == null) {
/*     */       return;
/*     */     }
/*  84 */     MCKeyAssign c = MCKeyAssignCacher.get(MCCacheType.SCREEN, bp, compo.getType());
/*  85 */     if (c != null) {
/*  86 */       setInputMap(c, input);
/*  87 */       setActionMap(compo, c, action);
/*     */       return;
/*     */     } 
/*  90 */     List<MCActionInfo> list = new ArrayList<>();
/*  91 */     String[][] msa = bp.getModuleAndScreenIDs();
/*  92 */     MCCollectionUtil.reverse((Object[])msa); byte b; int i; String[][] arrayOfString1;
/*  93 */     for (i = (arrayOfString1 = msa).length, b = 0; b < i; ) { String[] ms = arrayOfString1[b];
/*  94 */       String t = MCConst.createKey(new String[] { ms[0], ms[1], compo.getType() });
/*  95 */       setResourceValue(list, input, t); b++; }
/*     */     
/*  97 */     MCKeyAssign k = new MCKeyAssign(compo.getType(), input, list);
/*  98 */     MCKeyAssignCacher.cache(MCCacheType.SCREEN, bp, k);
/*  99 */     setActionMap(compo, k, action);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void setResourceValue(List<MCActionInfo> list, InputMap input, String prefix) {
/* 113 */     String[] a = getKeys(prefix); byte b; int i; String[] arrayOfString1;
/* 114 */     for (i = (arrayOfString1 = a).length, b = 0; b < i; ) { String k = arrayOfString1[b];
/* 115 */       String[] sa = getKeys(k);
/* 116 */       if (sa == null || sa.length == 0) {
/* 117 */         String v = MCConst.keyassign.getString(k);
/* 118 */         if (!MCStringUtil.isNull(v)) {
/* 119 */           setResourceValueImpl(list, input, "common", 
/* 120 */               MCConst.createKey(new String[] { "common", v }));
/*     */         }
/*     */       } else {
/*     */         
/* 124 */         setResourceValueImpl(list, input, prefix, k);
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   }
/*     */   
/*     */   private static void setResourceValueImpl(List<MCActionInfo> list, InputMap input, String prefix, String key) {
/* 131 */     String v = MCConst.keyassign.getString(MCConst.createKey(new String[] { key, "key" }));
/* 132 */     if (MCStringUtil.isNull(v)) {
/*     */       return;
/*     */     }
/* 135 */     int c = ((Integer)MCFactory.getFieldValue(KeyEvent.class, int.class, "VK_" + v)).intValue();
/* 136 */     int m = 0;
/* 137 */     if (MCConst.keyassign.getBoolean(MCConst.createKey(new String[] { key, "shift" }))) {
/* 138 */       m++;
/*     */     }
/* 140 */     if (MCConst.keyassign.getBoolean(MCConst.createKey(new String[] { key, "ctrl" }))) {
/* 141 */       m += 2;
/*     */     }
/* 143 */     if (MCConst.keyassign.getBoolean(MCConst.createKey(new String[] { key, "alt" }))) {
/* 144 */       m += 8;
/*     */     }
/* 146 */     String p = MCConst.keyassign.getString(MCConst.createKey(new String[] { key, "pattern" }));
/* 147 */     KeyStroke ks = KeyStroke.getKeyStroke(c, m, (p != null && p.equals("RELEASED")));
/*     */     
/* 149 */     String s = key.substring(prefix.length() + 1);
/* 150 */     input.put(ks, s);
/* 151 */     String z = MCConst.keyassign.getString(MCConst.createKey(new String[] { key, "class" }));
/* 152 */     String e = MCConst.keyassign.getString(MCConst.createKey(new String[] { key, "method" }));
/* 153 */     list.add(new MCActionInfo(s, z, e));
/*     */   }
/*     */   
/*     */   private static void setInputMap(MCKeyAssign assign, InputMap map) {
/* 157 */     InputMap m = assign.getInputMap();
/*     */     
/* 159 */     if (m != null) {
/* 160 */       KeyStroke[] a = m.keys();
/* 161 */       if (a != null) {
/* 162 */         byte b; int i; KeyStroke[] arrayOfKeyStroke; for (i = (arrayOfKeyStroke = a).length, b = 0; b < i; ) { KeyStroke k = arrayOfKeyStroke[b];
/* 163 */           map.put(k, m.get(k));
/*     */           b++; }
/*     */       
/*     */       } 
/*     */     }  } private static void setActionMap(MCResourceBeans compo, MCKeyAssign assign, ActionMap map) {
/*     */     byte b;
/*     */     int i;
/*     */     MCActionInfo[] arrayOfMCActionInfo;
/* 171 */     for (i = (arrayOfMCActionInfo = assign.getActionInfo()).length, b = 0; b < i; ) { MCActionInfo mCActionInfo = arrayOfMCActionInfo[b];
/* 172 */       String c = mCActionInfo.getClassName();
/* 173 */       String m = mCActionInfo.getMethodName();
/* 174 */       MCAction a = null;
/* 175 */       if (!MCStringUtil.isNull(m)) {
/* 176 */         a = new MCAction(compo, c, m);
/*     */       }
/* 178 */       map.put(mCActionInfo.getKey(), a);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String[] getKeys(String prefix) {
/* 193 */     return MCConst.keyassign.findPattern(MCConst.createKey(new String[] { prefix, "*" }));
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\action\MCKeyActionManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */