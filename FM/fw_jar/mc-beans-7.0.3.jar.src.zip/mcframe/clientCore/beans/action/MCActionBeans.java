package mcframe.clientCore.beans.action;

import mcframe.clientCore.beans.MCBeans;

public interface MCActionBeans extends MCBeans {
  boolean doAction();
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\action\MCActionBeans.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */