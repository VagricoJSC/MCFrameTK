/*    */ package mcframe.clientCore.beans.action;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import mcframe.clientCore.beans.MCCacheType;
/*    */ import mcframe.clientCore.beans.MCRootPanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MCKeyAssignCacher
/*    */ {
/* 24 */   private static final MCKeyAssignCache SYSTEM = new MCKeyAssignCache();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 32 */   private static final List<MCKeyAssignCache> SCREEN = new ArrayList<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static MCKeyAssignCache getScreenCache(MCRootPanel panel) {
/* 43 */     if (panel == null) {
/* 44 */       return null;
/*    */     }
/* 46 */     MCKeyAssignCache[] a = SCREEN.<MCKeyAssignCache>toArray(
/* 47 */         new MCKeyAssignCache[SCREEN.size()]); byte b; int i; MCKeyAssignCache[] arrayOfMCKeyAssignCache1;
/* 48 */     for (i = (arrayOfMCKeyAssignCache1 = a).length, b = 0; b < i; ) { MCKeyAssignCache c = arrayOfMCKeyAssignCache1[b];
/* 49 */       if (c.equals(panel))
/* 50 */         return c; 
/*    */       b++; }
/*    */     
/* 53 */     return null;
/*    */   }
/*    */   
/*    */   static void cache(MCCacheType cache, MCRootPanel panel, MCKeyAssign key) {
/* 57 */     if (MCCacheType.SYSTEM == cache) {
/* 58 */       SYSTEM.add(key);
/*    */     }
/* 60 */     else if (MCCacheType.SCREEN == cache) {
/* 61 */       MCKeyAssignCache c = getScreenCache(panel);
/* 62 */       if (c == null) {
/* 63 */         c = new MCKeyAssignCache(panel);
/* 64 */         SCREEN.add(c);
/*    */       } 
/* 66 */       c.add(key);
/*    */     } 
/*    */   }
/*    */   
/*    */   static MCKeyAssign get(MCCacheType cache, MCRootPanel panel, String type) {
/* 71 */     if (MCCacheType.SYSTEM == cache) {
/* 72 */       return SYSTEM.get(type);
/*    */     }
/* 74 */     if (MCCacheType.SCREEN == cache) {
/* 75 */       MCKeyAssignCache c = getScreenCache(panel);
/* 76 */       if (c != null) {
/* 77 */         return c.get(type);
/*    */       }
/*    */     } 
/* 80 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   static void clear(MCRootPanel panel) {
/* 85 */     MCKeyAssignCache c = getScreenCache(panel);
/* 86 */     if (c != null)
/* 87 */       SCREEN.remove(c); 
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\action\MCKeyAssignCacher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */