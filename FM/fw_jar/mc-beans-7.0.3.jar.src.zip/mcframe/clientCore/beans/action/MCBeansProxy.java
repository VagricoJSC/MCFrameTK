/*    */ package mcframe.clientCore.beans.action;
/*    */ 
/*    */ import mcframe.clientCore.beans.AbsMCPackageProxy;
/*    */ import mcframe.clientCore.beans.MCButton;
/*    */ import mcframe.clientCore.beans.MCCalendarField;
/*    */ import mcframe.clientCore.beans.MCRootPanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MCBeansProxy
/*    */   extends AbsMCPackageProxy
/*    */ {
/* 23 */   static final MCBeansProxy PROXY = new MCBeansProxy();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void writeButtonActionLog(MCButton compo, boolean start) {
/* 36 */     super.writeButtonActionLog(compo, start);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void showBeansInfoToolTip(MCRootPanel panel) {
/* 41 */     super.showBeansInfoToolTip(panel);
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean isInitFocusLaterEnd(MCRootPanel panel) {
/* 46 */     return super.isInitFocusLaterEnd(panel);
/*    */   }
/*    */   
/*    */   protected boolean isShowingAmPmComboList(MCCalendarField<?> cf) {
/* 50 */     return super.isShowingAmPmComboList(cf);
/*    */   }
/*    */   
/*    */   protected void showOrChangeAmPm(MCCalendarField<?> cf) {
/* 54 */     super.showOrChangeAmPm(cf);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\action\MCBeansProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */