/*    */ package mcframe.clientCore.beans.action;
/*    */ 
/*    */ import javax.swing.JComponent;
/*    */ import mcframe.clientCore.beans.MCListBeans;
/*    */ import mcframe.clientCore.beans.table.MCColumnConfig;
/*    */ import mcframe.clientCore.beans.table.MCTable;
/*    */ import mcframe.clientCore.beans.tree.MCTree;
/*    */ import mcframe.clientCore.container.MCConstRow;
/*    */ 
/*    */ 
/*    */ @Deprecated
/*    */ public final class MCFocusReservationInfo
/*    */ {
/*    */   private final JComponent _compo;
/*    */   private final int _table_row_index;
/*    */   private final MCColumnConfig _table_column;
/*    */   private final MCConstRow _tree_row;
/*    */   private final int _focus_pattern;
/*    */   
/*    */   public MCFocusReservationInfo(JComponent c) {
/* 21 */     this._compo = c;
/* 22 */     this._focus_pattern = (c instanceof MCListBeans) ? (
/* 23 */       (MCListBeans)c).getCellFocusPattern() : 3000;
/*    */     
/* 25 */     this._table_row_index = -1;
/* 26 */     this._table_column = null;
/* 27 */     this._tree_row = null;
/*    */   }
/*    */   
/*    */   public MCFocusReservationInfo(MCTable<?> t, int i, MCColumnConfig c) {
/* 31 */     this._compo = (JComponent)t;
/* 32 */     this._table_row_index = i;
/* 33 */     this._table_column = c;
/* 34 */     this._focus_pattern = t.getCellFocusPattern();
/*    */     
/* 36 */     this._tree_row = null;
/*    */   }
/*    */   
/*    */   public MCFocusReservationInfo(MCTree<?> t, MCConstRow o) {
/* 40 */     this._compo = (JComponent)t;
/* 41 */     this._tree_row = o;
/* 42 */     this._focus_pattern = t.getCellFocusPattern();
/*    */     
/* 44 */     this._table_row_index = -1;
/* 45 */     this._table_column = null;
/*    */   }
/*    */   
/*    */   public JComponent getComponent() {
/* 49 */     return this._compo;
/*    */   }
/*    */   
/*    */   public int getTableRowIndex() {
/* 53 */     return this._table_row_index;
/*    */   }
/*    */   
/*    */   public MCColumnConfig getTableColumn() {
/* 57 */     return this._table_column;
/*    */   }
/*    */   
/*    */   public MCConstRow getTreeRow() {
/* 61 */     return this._tree_row;
/*    */   }
/*    */   
/*    */   public int getFocusPattern() {
/* 65 */     return this._focus_pattern;
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\action\MCFocusReservationInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */