/*     */ package mcframe.clientCore.beans.action;
/*     */ 
/*     */ import java.awt.event.ActionEvent;
/*     */ import javax.swing.AbstractAction;
/*     */ import mcframe.clientCore.beans.MCBeans;
/*     */ import mcframe.clientCore.beans.MCResourceBeans;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.sys.MCFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MCAction
/*     */   extends AbstractAction
/*     */ {
/*     */   private final MCResourceBeans _compo;
/*     */   private final String _clazz;
/*     */   private final String _method;
/*     */   
/*     */   MCAction(MCResourceBeans compo, String clazz, String method) {
/*  58 */     this._compo = compo;
/*  59 */     this._clazz = clazz;
/*  60 */     this._method = method;
/*     */   }
/*     */ 
/*     */   
/*     */   public void actionPerformed(ActionEvent e) {
/*  65 */     if (this._compo != null) {
/*  66 */       MCRootPanel bp = this._compo.getBaseRootPanel();
/*     */       
/*  68 */       if (!MCEventStatus.setEventStatus(bp, (MCBeans)this._compo)) {
/*     */         return;
/*     */       }
/*     */     } 
/*  72 */     if (this._clazz != null && this._method != null)
/*     */     {
/*  74 */       invoke();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean invoke() {
/*  93 */     Object o = MCFactory.create(Object.class, this._clazz);
/*     */ 
/*     */     
/*  96 */     Class<?> paramc = this._compo.getClass();
/*     */ 
/*     */     
/*  99 */     if (invokeTraceType(o, paramc)) {
/* 100 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 104 */     return invokeTraceType(o, paramc);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean invokeTraceType(Object o, Class<?> type) {
/* 132 */     Class[] types = {
/* 133 */         type
/*     */       };
/* 135 */     Object[] args = {
/* 136 */         this._compo
/*     */       };
/* 138 */     while (types[0] != null) {
/*     */       try {
/* 140 */         MCFactory.invoke(o, this._method, types, args);
/* 141 */         return true;
/*     */       }
/* 143 */       catch (MCException e) {
/* 144 */         if (!e.getID().equals(Core_Msg_FW_A.FCBEC0015))
/*     */         {
/* 146 */           throw e;
/*     */         }
/*     */ 
/*     */         
/* 150 */         Class[] typeis = types[0].getInterfaces(); byte b; int i; Class[] arrayOfClass1;
/* 151 */         for (i = (arrayOfClass1 = typeis).length, b = 0; b < i; ) { Class<?> typei = arrayOfClass1[b];
/* 152 */           if (invokeTraceType(o, typei)) {
/* 153 */             return true;
/*     */           }
/*     */           
/*     */           b++; }
/*     */         
/* 158 */         types[0] = types[0].getSuperclass();
/*     */       } 
/*     */     } 
/* 161 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\action\MCAction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */