/*     */ package mcframe.clientCore.beans.statusbar;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Insets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.BoxLayout;
/*     */ import javax.swing.JComponent;
/*     */ import mcframe.clientCore.beans.MCMessageBox;
/*     */ import mcframe.clientCore.beans.MCPanel;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.MCTabOrderBeans;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCStatusBar
/*     */ {
/*     */   private final MCRootPanel _base;
/*     */   private final MCTextStatusBarItem _main;
/*     */   private final MCPanel _option;
/*  64 */   private List<MCStatusBarItem> optionItems = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCStatusBar(String name) {
/*  76 */     this._base = new MCRootPanel()
/*     */       {
/*     */         public static final String MODULE_ID = "FC";
/*     */         
/*     */         public static final String SCREEN_ID = "FCBEBBASE";
/*     */         
/*     */         public String getModuleID() {
/*  83 */           return "FC";
/*     */         }
/*     */ 
/*     */         
/*     */         public String getScreenID() {
/*  88 */           return "FCBEBBASE";
/*     */         }
/*     */ 
/*     */         
/*     */         public Insets getInsets() {
/*  93 */           return new Insets(0, 0, 0, 0);
/*     */         }
/*     */ 
/*     */         
/*     */         public void panelClosed() {
/*  98 */           super.panelClosed();
/*     */ 
/*     */ 
/*     */           
/* 102 */           MCStatusBar.this.dispose();
/*     */         }
/*     */         
/*     */         boolean isStartTimer = false;
/*     */         
/*     */         public void repaint() {
/* 108 */           super.repaint();
/* 109 */           if (isShowing())
/*     */           {
/*     */ 
/*     */ 
/*     */             
/* 114 */             if (!this.isStartTimer) {
/* 115 */               this.isStartTimer = true;
/* 116 */               MCStatusBar.this.startTimer();
/*     */             } 
/*     */           }
/*     */         }
/*     */       };
/* 121 */     this._base.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
/* 122 */     this._main = new MCTextStatusBarItem(String.valueOf(name) + "_Text");
/* 123 */     this._main.setFlotable(false);
/* 124 */     this._option = new MCPanel(String.valueOf(name) + "_Option")
/*     */       {
/*     */         public void setPreferredSize(Dimension preferredSize) {}
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 134 */     this._base.setLayout(new BorderLayout());
/* 135 */     this._base.add(this._main.getComponent(), "Center");
/* 136 */     this._base.add((Component)this._option, "East");
/*     */     
/* 138 */     this._option.setLayout(new BoxLayout((Container)this._option, 0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void dispose() {
/* 148 */     this.optionItems.forEach(MCStatusBarItem::dispose);
/* 149 */     this.optionItems.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void startTimer() {
/* 159 */     this.optionItems.forEach(MCStatusBarItem::startTimer);
/* 160 */     this.optionItems.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public JComponent getComponent() {
/* 172 */     return (JComponent)this._base;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setText(String t) {
/* 183 */     this._main.setText(t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getText() {
/* 194 */     return this._main.getText();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(MCStatusBarItem item) {
/* 207 */     this.optionItems.add(item);
/* 208 */     this._option.add(item.getComponent(), 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCStatusBarItem getItem(String name) {
/* 213 */     for (MCStatusBarItem item : this.optionItems) {
/* 214 */       if (item.getComponent().getName().equals(name)) {
/* 215 */         return item;
/*     */       }
/*     */     } 
/* 218 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addPluginItem() {
/* 228 */     String[] parts = MCConst.plugin.findPattern("statusbar.*");
/* 229 */     if (parts.length == 0) {
/*     */       return;
/*     */     }
/* 232 */     String orderkey = "statusbar.order";
/* 233 */     boolean success = true; byte b; int i; String[] arrayOfString1;
/* 234 */     for (i = (arrayOfString1 = parts).length, b = 0; b < i; ) { String part = arrayOfString1[b];
/* 235 */       if (!part.equals(orderkey)) {
/*     */ 
/*     */ 
/*     */         
/* 239 */         String mid = MCConst.plugin.getString(MCConst.createKey(new String[] { part, "moduleid"
/* 240 */               }, ), null);
/* 241 */         String sid = MCConst.plugin.getString(MCConst.createKey(new String[] { part, "screenid"
/* 242 */               }, ), null);
/* 243 */         MCScreenStatusBarItem item = MCScreenStatusBarItem.create(mid, sid);
/* 244 */         if (item != null) {
/* 245 */           add(item);
/*     */ 
/*     */ 
/*     */           
/* 249 */           MCRootPanel p = item.getRootPanel();
/* 250 */           MCTabOrderBeans first = this._base.getFirstBeans();
/* 251 */           this._base.setFirstBeans((MCTabOrderBeans)p);
/* 252 */           p.setNextBeans(first);
/*     */         } else {
/*     */           
/* 255 */           success = false;
/*     */         } 
/*     */       }  b++; }
/* 258 */      if (!success)
/*     */     {
/* 260 */       MCMessageBox.dialog(null, new MCMessage(Core_Msg_FW_A.FCBAC0345, new Object[0]));
/*     */     }
/*     */ 
/*     */     
/* 264 */     this._base.createTabOrderList();
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\statusbar\MCStatusBar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */