/*    */ package mcframe.clientCore.beans.statusbar;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import java.awt.Dimension;
/*    */ import javax.swing.BorderFactory;
/*    */ import mcframe.clientCore.beans.MCLabel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MCTextStatusBarItem
/*    */   extends MCStatusBarItem
/*    */ {
/*    */   private final MCLabel _label;
/*    */   
/*    */   public MCTextStatusBarItem(String name) {
/* 34 */     super(name);
/*    */     
/* 36 */     this._label = new MCLabel(String.valueOf(name) + "_Text")
/*    */       {
/*    */         public void setPreferredSize(Dimension d) {}
/*    */       };
/*    */     
/* 41 */     this._label.updateResource();
/* 42 */     this._label.setBorder(BorderFactory.createEmptyBorder(2, 2, 0, 2));
/* 43 */     getComponent().add((Component)this._label);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setText(String t) {
/* 54 */     this._label.setText(t);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   String getText() {
/* 65 */     return this._label.getText();
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\statusbar\MCTextStatusBarItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */