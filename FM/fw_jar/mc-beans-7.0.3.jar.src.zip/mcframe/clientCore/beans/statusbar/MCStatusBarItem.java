/*     */ package mcframe.clientCore.beans.statusbar;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.Insets;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JToolBar;
/*     */ import javax.swing.Timer;
/*     */ import javax.swing.border.EmptyBorder;
/*     */ import mcframe.clientCore.beans.MCFrame;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MCStatusBarItem
/*     */ {
/*     */   private final JToolBar _panel;
/*     */   private Timer _timer;
/*     */   
/*     */   protected MCStatusBarItem(String name) {
/*  56 */     this._panel = new JToolBar(name)
/*     */       {
/*     */         public String getUIClassID()
/*     */         {
/*  60 */           return "MCStatusBarUI";
/*     */         }
/*     */ 
/*     */         
/*     */         public Insets getMargin() {
/*  65 */           return new Insets(0, 0, 0, 0);
/*     */         }
/*     */ 
/*     */         
/*     */         public boolean isFloatable() {
/*  70 */           return false;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         public void setPreferredSize(Dimension preferredSize) {}
/*     */       };
/*  80 */     this._panel.setBackground(MCConst.beans.getColor("statusbar.bg", Color.LIGHT_GRAY));
/*  81 */     this._panel.setLayout(new FlowLayout(0, 0, 0));
/*  82 */     this._panel.setFloatable(true);
/*  83 */     this._panel.putClientProperty("JToolBar.isRollover", Boolean.TRUE);
/*     */ 
/*     */ 
/*     */     
/*  87 */     this._panel.setBorder(new EmptyBorder(0, 10, 0, 0));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void dispose() {
/*  98 */     if (this._timer != null) {
/*  99 */       disposeTimer();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 113 */   protected static int _timerInterval = 1000;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void startTimer() {
/* 122 */     if (this._timer == null) {
/* 123 */       startTimer(_timerInterval);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setFlotable(boolean flotable) {
/* 136 */     this._panel.setFloatable(flotable);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JComponent getComponent() {
/* 147 */     return this._panel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void startTimer(int interval) {
/* 160 */     if (this._timer == null) {
/* 161 */       this._timer = new Timer(interval, e -> timerEvent(e));
/*     */     } else {
/*     */       
/* 164 */       this._timer.setDelay(interval);
/*     */     } 
/* 166 */     if (!this._timer.isRunning()) {
/* 167 */       this._timer.start();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void stopTimer() {
/* 178 */     if (this._timer != null) {
/* 179 */       this._timer.stop();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void timerEvent(ActionEvent e) {
/* 194 */     if (this._timer != null && 
/* 195 */       !checkPanelForTimer()) {
/* 196 */       disposeTimer();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void disposeTimer() {
/* 208 */     if (this._timer != null) {
/* 209 */       this._timer.stop();
/* 210 */       ActionListener[] als = this._timer.getActionListeners(); byte b; int i; ActionListener[] arrayOfActionListener1;
/* 211 */       for (i = (arrayOfActionListener1 = als).length, b = 0; b < i; ) { ActionListener al = arrayOfActionListener1[b];
/* 212 */         this._timer.removeActionListener(al); b++; }
/*     */       
/* 214 */       this._timer = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean checkPanelForTimer() {
/* 227 */     Container top = this._panel.getTopLevelAncestor();
/* 228 */     if (top instanceof MCFrame && (
/* 229 */       (MCFrame)top).isDisposedFrame()) {
/* 230 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 234 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\statusbar\MCStatusBarItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */