/*     */ package mcframe.clientCore.beans.statusbar;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.event.ActionEvent;
/*     */ import javax.swing.Icon;
/*     */ import mcframe.clientCore.beans.MCBeansCompatibilityUtil;
/*     */ import mcframe.clientCore.beans.MCButton;
/*     */ import mcframe.clientCore.beans.MCMode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCButtonStatusBarItem
/*     */   extends MCStatusBarItem
/*     */ {
/*     */   private final MCButton _btn;
/*     */   
/*     */   protected MCButtonStatusBarItem(String name) {
/*  45 */     super(name);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  50 */     this._btn = MCBeansCompatibilityUtil.createButtonStatusBar(String.valueOf(name) + "_Button");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  55 */     this._btn.addActionListener(e -> buttonEvent(e));
/*     */ 
/*     */     
/*  58 */     this._btn.setMode(MCMode.ENABLE);
/*  59 */     this._btn.setFocusable(false);
/*  60 */     this._btn.updateResource();
/*     */     
/*  62 */     getComponent().add((Component)this._btn);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void buttonEvent(ActionEvent e) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setText(String t) {
/*  84 */     this._btn.setText(t);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getText() {
/*  95 */     return this._btn.getText();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setIcon(Icon icon) {
/* 106 */     this._btn.setIcon(icon);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Icon getIcon() {
/* 117 */     return this._btn.getIcon();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setTextPosition(int pos) {
/* 135 */     this._btn.setHorizontalTextPosition(pos);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\statusbar\MCButtonStatusBarItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */