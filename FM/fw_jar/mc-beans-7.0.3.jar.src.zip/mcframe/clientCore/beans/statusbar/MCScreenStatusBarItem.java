/*     */ package mcframe.clientCore.beans.statusbar;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import javax.swing.JComponent;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MCScreenStatusBarItem
/*     */   extends MCStatusBarItem
/*     */ {
/*     */   private MCRootPanel panel;
/*     */   
/*     */   static MCScreenStatusBarItem create(String moduleid, String screenid) {
/*     */     try {
/*  36 */       return new MCScreenStatusBarItem(moduleid, screenid);
/*     */     }
/*  38 */     catch (Exception e) {
/*  39 */       MCLog.write(e);
/*  40 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCScreenStatusBarItem(String moduleid, String screenid) {
/*  62 */     super(String.valueOf(moduleid) + "." + screenid);
/*     */     
/*     */     try {
/*  65 */       this.panel = MCBeansUtil.createPanelOnly(null, moduleid, screenid, new Object[0]);
/*  66 */       if (!MCBeansUtil.doBeforeOpens(this.panel)) {
/*  67 */         this.panel = null;
/*     */         return;
/*     */       } 
/*  70 */       MCBeansUtil.doAfterOpens(this.panel);
/*     */     }
/*  72 */     catch (Exception e) {
/*     */       
/*  74 */       throw new MCException(e, Core_Msg_FW_A.FCBAC0346, new Object[] { moduleid, screenid });
/*     */     } 
/*     */     
/*  77 */     setOpaqueAllPanel((JComponent)this.panel, false);
/*  78 */     getComponent().add((Component)this.panel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setOpaqueAllPanel(JComponent p, boolean isOpaque) {
/*  94 */     p.setOpaque(isOpaque);
/*     */     
/*  96 */     Component[] cs = p.getComponents(); byte b; int i; Component[] arrayOfComponent1;
/*  97 */     for (i = (arrayOfComponent1 = cs).length, b = 0; b < i; ) { Component c = arrayOfComponent1[b];
/*  98 */       if (c instanceof javax.swing.JPanel || c instanceof javax.swing.JRootPane) {
/*  99 */         JComponent jc = (JComponent)c;
/* 100 */         setOpaqueAllPanel(jc, isOpaque);
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCRootPanel getRootPanel() {
/* 113 */     return this.panel;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\statusbar\MCScreenStatusBarItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */