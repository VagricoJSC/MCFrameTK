/*    */ package mcframe.clientCore.beans.dashboard;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import javax.swing.JComponent;
/*    */ import mcframe.clientCore.beans.MCLabel;
/*    */ import mcframe.clientCore.dashboard.DataR;
/*    */ import mcframe.commonCore.container.MCIndexKey;
/*    */ import mcframe.commonCore.container.MCList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCIconLabelGadget
/*    */   extends MCLabelGadget
/*    */ {
/*    */   public static final String ICON_NONE = "NOTICE_INFO";
/*    */   public static final String ICON_OK = "NOTICE_OK";
/*    */   public static final String ICON_NG = "NOTICE_ERROR";
/*    */   public static final String ICON_WARN = "NOTICE_WARN";
/*    */   private MCLabel _icon;
/*    */   
/*    */   public MCIconLabelGadget(String type, String gadget, String id) {
/* 45 */     super(type, gadget, id);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void initPanel() {
/* 50 */     super.initPanel();
/*    */     
/* 52 */     this._icon = new MCLabel("icon");
/* 53 */     setIcon("NOTICE_INFO");
/*    */     
/* 55 */     JComponent content = getContent();
/* 56 */     content.add((Component)this._icon, "West");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void setIcon(String icon) {
/* 67 */     String image = "NOTICE_INFO"; String str1;
/* 68 */     switch ((str1 = icon).hashCode()) { case 48: if (!str1.equals("0"))
/*    */           break; 
/* 70 */         image = "NOTICE_OK"; break;
/*    */       case 49:
/*    */         if (!str1.equals("1"))
/* 73 */           break;  image = "NOTICE_ERROR"; break;
/*    */       case 50:
/*    */         if (!str1.equals("2"))
/* 76 */           break;  image = "NOTICE_WARN";
/*    */         break; }
/*    */ 
/*    */ 
/*    */     
/* 81 */     this._icon.setIcon(image);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void updateContents(MCList<DataR> dataL, MCIndexKey itemIdx) {
/* 86 */     super.updateContents(dataL, itemIdx);
/*    */     
/* 88 */     DataR dataR = null;
/*    */     
/* 90 */     if ((dataR = (DataR)dataL.getFirst(itemIdx, new Comparable[] { "icon" })) != null) {
/* 91 */       String val = dataR.strval();
/* 92 */       if (val != null)
/* 93 */         setIcon(val); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\dashboard\MCIconLabelGadget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */