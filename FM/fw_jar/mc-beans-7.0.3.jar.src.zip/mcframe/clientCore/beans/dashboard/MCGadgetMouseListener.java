/*     */ package mcframe.clientCore.beans.dashboard;
/*     */ 
/*     */ import java.awt.AlphaComposite;
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.Cursor;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.MouseInfo;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.MouseEvent;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JPopupMenu;
/*     */ import javax.swing.JScrollBar;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.event.MouseInputListener;
/*     */ import mcframe.clientCore.beans.MCDashboard;
/*     */ import mcframe.clientCore.beans.MCGadget;
/*     */ import mcframe.clientCore.beans.MCMessageBox;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCGadgetMouseListener
/*     */   implements MouseInputListener
/*     */ {
/*     */   private final GadgetServer _server;
/*     */   
/*     */   abstract class AutoScrollAdapter
/*     */   {
/*  82 */     final MCGadget gadget = MCGadgetMouseListener.this._drag;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  88 */     final MCDashboard.Board board = this.gadget.getBoard();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  94 */     final MCGadgetMouseListener listener = MCGadgetMouseListener.this;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     abstract int getDirection();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     abstract void setDragOffset(int param1Int);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     abstract JScrollBar getScrollBar();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     abstract void widenDashboard();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     abstract void moveGadget(int param1Int);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 140 */   private final int _autoArea = MCConst.beans.getInteger("dashboard.autoscroll.area", 20);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 146 */   private final int _autoAmount = MCConst.beans.getInteger("dashboard.autoscroll.amount", 5);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean _autoScroll = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 158 */   private int _dragOffset_x = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 164 */   private int _dragOffset_y = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 173 */   private MCGadget _drag = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 179 */   private JPanel _ghost = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 185 */   private Dimension _d_str = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 191 */   private Point _g_str = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 197 */   private Point _m_str = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 203 */   private Point _ghost_str = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCGadgetMouseListener(GadgetServer server) {
/* 215 */     this._server = server;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseClicked(MouseEvent e) {
/* 224 */     if (SwingUtilities.isRightMouseButton(e)) {
/*     */       
/* 226 */       MCGadget gadget = this._server.getActiveGadget();
/* 227 */       if (gadget == null) {
/*     */         return;
/*     */       }
/* 230 */       JPopupMenu popup = gadget.getBase().getComponentPopupMenu();
/* 231 */       if (popup != null) {
/* 232 */         popup.show(e.getComponent(), e.getX(), e.getY());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void mousePressed(MouseEvent e) {
/* 240 */     if (e.getClickCount() == 2) {
/* 241 */       MCGadget gadget = this._server.getActiveGadget();
/* 242 */       if (gadget == null) {
/*     */         return;
/*     */       }
/* 245 */       gadget.openScreen();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void mouseReleased(MouseEvent e) {
/* 251 */     if (isDragged()) {
/* 252 */       releaseDrag(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void mouseDragged(MouseEvent e) {
/* 258 */     if (this._autoScroll) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 263 */     if (!SwingUtilities.isLeftMouseButton(e)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 269 */     if (!isDragged()) {
/* 270 */       startDrag(e);
/*     */       
/* 272 */       if (!isDragged()) {
/*     */         return;
/*     */       }
/*     */     } 
/*     */     
/* 277 */     Point now = e.getLocationOnScreen();
/*     */ 
/*     */     
/* 280 */     int x = now.x - this._m_str.x + this._dragOffset_x;
/* 281 */     int y = now.y - this._m_str.y + this._dragOffset_y;
/* 282 */     this._drag.getBase().setLocation(this._g_str.x + x, this._g_str.y + y);
/*     */ 
/*     */     
/* 285 */     moveGhost(now.x - this._m_str.x, now.y - this._m_str.y);
/*     */ 
/*     */     
/* 288 */     MCDashboard.Board board = this._drag.getBoard();
/* 289 */     setTrashEnabled(board.onTrash(e.getLocationOnScreen()));
/*     */ 
/*     */     
/* 292 */     autoAcroll(now);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDragged() {
/* 304 */     return (this._g_str != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void releaseDrag(MouseEvent e) {
/* 315 */     MCDashboard.Board board = this._drag.getBoard();
/*     */ 
/*     */     
/* 318 */     if (board.onTrash(e.getLocationOnScreen())) {
/* 319 */       MCGadget del = this._drag;
/* 320 */       finishDrag();
/* 321 */       board.removeGadget(del);
/* 322 */       board.updateGrid();
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 327 */     Point np = this._drag.getBase().getLocation();
/* 328 */     Point tp = board.getGridLocation(np.x, np.y);
/* 329 */     if (tp == null) {
/*     */       
/* 331 */       cancelDrag();
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */ 
/*     */     
/* 338 */     int ratio = board.getBaseRootPanel().getLayoutRatio();
/* 339 */     int w = 300 * ratio / 100;
/* 340 */     int h = 150 * ratio / 100;
/*     */ 
/*     */     
/* 343 */     Rectangle nr = new Rectangle(np.x, np.y, w, h);
/*     */ 
/*     */     
/* 346 */     Rectangle[] rs = {
/* 347 */         board.getGadgetBounds(tp.x, tp.y, 1, 1), 
/* 348 */         board.getGadgetBounds(tp.x, tp.y + 1, 1, 1), 
/* 349 */         board.getGadgetBounds(tp.x + 1, tp.y, 1, 1), 
/* 350 */         board.getGadgetBounds(tp.x + 1, tp.y + 1, 1, 1)
/*     */       };
/* 352 */     Rectangle gr = null;
/* 353 */     int gr_s = -1; byte b1; int i; Rectangle[] arrayOfRectangle1;
/* 354 */     for (i = (arrayOfRectangle1 = rs).length, b1 = 0; b1 < i; ) { Rectangle r = arrayOfRectangle1[b1];
/* 355 */       if (r != null) {
/* 356 */         Rectangle ir = nr.intersection(r);
/* 357 */         int s = ir.width * ir.height;
/* 358 */         if (s > gr_s) {
/* 359 */           gr_s = s;
/* 360 */           gr = r;
/*     */         } 
/*     */       }  b1++; }
/*     */     
/* 364 */     if (gr == null) {
/*     */       
/* 366 */       cancelDrag();
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 371 */     Point gp = board.getGridLocation(gr.x, gr.y);
/* 372 */     Dimension gd = this._drag.getGridSize();
/* 373 */     Dimension dd = board.getGrid();
/* 374 */     if (gp.x > dd.width || gp.y > dd.height) {
/*     */       
/* 376 */       cancelDrag();
/*     */       return;
/*     */     } 
/* 379 */     MCGadget[] gadgets = board.intersect(gp.x, gp.y, gd.width, gd.height); byte b2; int j; MCGadget[] arrayOfMCGadget1;
/* 380 */     for (j = (arrayOfMCGadget1 = gadgets).length, b2 = 0; b2 < j; ) { MCGadget gadget = arrayOfMCGadget1[b2];
/* 381 */       if (gadget != this._drag) {
/*     */         
/* 383 */         cancelDrag();
/*     */         
/*     */         return;
/*     */       } 
/*     */       b2++; }
/*     */     
/* 389 */     Point oldp = this._drag.getGridLocation();
/* 390 */     this._drag.setGridLocation(gp.x, gp.y);
/* 391 */     board.updateGrid();
/* 392 */     if (oldp.x < 0 && oldp.y < 0) {
/*     */       
/*     */       try {
/* 395 */         this._drag.showParamConfig();
/* 396 */       } catch (MCException ex) {
/* 397 */         cancelDrag(true);
/* 398 */         throw ex;
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 403 */       this._drag.saveResource(true);
/*     */     } 
/*     */     
/* 406 */     finishDrag();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void cancelDrag() {
/* 417 */     cancelDrag(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void cancelDrag(boolean forceRemove) {
/* 428 */     MCGadget gadget = this._drag;
/* 429 */     Dimension dim = this._d_str;
/*     */     
/* 431 */     finishDrag();
/*     */     
/* 433 */     MCDashboard.Board board = gadget.getBoard();
/* 434 */     Point g = gadget.getGridLocation();
/* 435 */     if (forceRemove || g.x < 0 || g.y < 0) {
/*     */       
/* 437 */       board.removeGadget(gadget);
/* 438 */       board.updateGrid();
/*     */     }
/*     */     else {
/*     */       
/* 442 */       gadget.setGridLocation(g.x, g.y);
/* 443 */       board.setGrid(dim.width, dim.height);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void finishDrag() {
/* 456 */     this._drag.getBoard().setCursor(new Cursor(0));
/*     */ 
/*     */     
/* 459 */     delGhost();
/*     */ 
/*     */     
/* 462 */     setTrashEnabled(false);
/*     */     
/* 464 */     this._d_str = null;
/* 465 */     this._g_str = null;
/* 466 */     this._drag = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void startDrag(MouseEvent e) {
/*     */     try {
/* 479 */       this._drag = this._server.getActiveGadget();
/* 480 */       if (this._drag == null) {
/*     */         return;
/*     */       }
/*     */     }
/* 484 */     catch (Exception ex) {
/*     */       
/* 486 */       MCException mex = !(ex instanceof MCException) ? 
/* 487 */         new MCException(ex) : (MCException)ex;
/* 488 */       MCLog.write((Throwable)mex);
/* 489 */       MCMessageBox.dialog(null, mex);
/* 490 */       throw mex;
/*     */     } 
/*     */ 
/*     */     
/* 494 */     MCDashboard.Board board = this._drag.getBoard();
/* 495 */     this._d_str = board.getGrid();
/* 496 */     this._g_str = this._drag.getBase().getLocation();
/* 497 */     this._m_str = e.getLocationOnScreen();
/* 498 */     this._dragOffset_x = 0;
/* 499 */     this._dragOffset_y = 0;
/*     */ 
/*     */     
/* 502 */     int ratio = board.getBaseRootPanel().getLayoutRatio();
/* 503 */     int gw = 300 * ratio / 100;
/* 504 */     int gh = 150 * ratio / 100;
/*     */ 
/*     */     
/* 507 */     Dimension ps = board.getPreferredSize();
/* 508 */     Dimension s = board.getSize();
/* 509 */     s.width = (s.width > ps.width) ? s.width : ps.width;
/* 510 */     s.height = (s.height > ps.height) ? s.height : ps.height;
/* 511 */     int cell = s.width / gw + (
/* 512 */       (s.width % gw > 0) ? 1 : 0);
/* 513 */     int row = s.height / gh + (
/* 514 */       (s.height % gw > 0) ? 1 : 0);
/* 515 */     board.setGrid(cell, row);
/*     */ 
/*     */     
/* 518 */     board.setComponentZOrder(this._drag.getBase(), 0);
/*     */ 
/*     */     
/* 521 */     setGhost();
/*     */ 
/*     */     
/* 524 */     board.setCursor(new Cursor(12));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean autoAcroll(Point p) {
/* 536 */     AutoScrollAdapter scroll = createAutoScrollAdapter(p);
/* 537 */     if (scroll == null) {
/* 538 */       return false;
/*     */     }
/* 540 */     AutoScrollAdapter adapter = scroll;
/* 541 */     SwingUtilities.invokeLater(new Runnable(adapter) {
/*     */           final MCGadgetMouseListener.AutoScrollAdapter _adapter;
/*     */           
/*     */           public void run() {
/* 545 */             int direction = this._adapter.getDirection();
/* 546 */             if (!this._adapter.listener.isDragged() || direction == 0) {
/* 547 */               this._adapter.listener._autoScroll = false;
/*     */               return;
/*     */             } 
/* 550 */             this._adapter.listener._autoScroll = true;
/* 551 */             int amount = MCGadgetMouseListener.this._autoAmount * direction;
/*     */             
/* 553 */             JScrollBar sb = this._adapter.getScrollBar();
/* 554 */             int pos = sb.getValue() + amount;
/* 555 */             if (pos < 0) {
/*     */               
/* 557 */               pos = 0;
/* 558 */               amount = 0;
/*     */             }
/* 560 */             else if (pos + sb.getVisibleAmount() > sb.getMaximum()) {
/*     */               
/* 562 */               this._adapter.widenDashboard();
/*     */             }
/*     */             else {
/*     */               
/* 566 */               sb.setValue(pos);
/* 567 */               this._adapter.moveGadget(amount);
/* 568 */               this._adapter.setDragOffset(amount);
/*     */             } 
/*     */             
/* 571 */             SwingUtilities.invokeLater(this);
/*     */           }
/*     */         });
/* 574 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private AutoScrollAdapter createAutoScrollAdapter(Point p) {
/* 588 */     if (this._drag == null) {
/* 589 */       return null;
/*     */     }
/* 591 */     MCDashboard.Board board = this._drag.getBoard();
/* 592 */     int direction_h = autoScrollDirectionHorizontal(p, board);
/* 593 */     int direction_v = autoScrollDirectionVertical(p, board);
/*     */     
/* 595 */     AutoScrollAdapter scroll = null;
/* 596 */     if (direction_h != 0 && direction_v == 0) {
/* 597 */       scroll = new AutoScrollAdapter(this)
/*     */         {
/*     */           int getDirection() {
/* 600 */             Point mp = MouseInfo.getPointerInfo().getLocation();
/* 601 */             return MCGadgetMouseListener.this.autoScrollDirectionHorizontal(mp, this.board);
/*     */           }
/*     */           
/*     */           void setDragOffset(int amount) {
/* 605 */             this.listener._dragOffset_x = this.listener._dragOffset_x + amount;
/*     */           }
/*     */           
/*     */           JScrollBar getScrollBar() {
/* 609 */             return this.board.getScrollPane().getHorizontalScrollBar();
/*     */           }
/*     */           
/*     */           void widenDashboard() {
/* 613 */             Dimension g = this.board.getGrid();
/* 614 */             g.width += (MCGadgetMouseListener.this._drag.getGridSize()).width;
/* 615 */             this.board.setGrid(g.width, g.height);
/*     */           }
/*     */           
/*     */           void moveGadget(int amount) {
/* 619 */             JComponent base = this.gadget.getBase();
/* 620 */             Point p = base.getLocation();
/* 621 */             p.x += amount;
/* 622 */             base.setLocation(p.x, p.y);
/*     */           }
/*     */         };
/*     */     }
/* 626 */     else if (direction_h == 0 && direction_v != 0) {
/* 627 */       scroll = new AutoScrollAdapter(this)
/*     */         {
/*     */           int getDirection() {
/* 630 */             Point mp = MouseInfo.getPointerInfo().getLocation();
/* 631 */             return MCGadgetMouseListener.this.autoScrollDirectionVertical(mp, this.board);
/*     */           }
/*     */           
/*     */           void setDragOffset(int amount) {
/* 635 */             this.listener._dragOffset_y = this.listener._dragOffset_y + amount;
/*     */           }
/*     */           
/*     */           JScrollBar getScrollBar() {
/* 639 */             return this.board.getScrollPane().getVerticalScrollBar();
/*     */           }
/*     */           
/*     */           void widenDashboard() {
/* 643 */             Dimension g = this.board.getGrid();
/* 644 */             g.height += (MCGadgetMouseListener.this._drag.getGridSize()).height;
/* 645 */             this.board.setGrid(g.width, g.height);
/*     */           }
/*     */           
/*     */           void moveGadget(int amount) {
/* 649 */             JComponent base = this.gadget.getBase();
/* 650 */             Point p = base.getLocation();
/* 651 */             p.y += amount;
/* 652 */             base.setLocation(p.x, p.y);
/*     */           }
/*     */         };
/*     */     } 
/* 656 */     return scroll;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int autoScrollDirectionHorizontal(Point p, MCDashboard.Board board) {
/* 669 */     Point dp = board.getScrollPane().getLocationOnScreen();
/* 670 */     Rectangle dr = board.getScrollPane().getBounds();
/* 671 */     dr.translate(dp.x, dp.y);
/* 672 */     if (dr.contains(p)) {
/* 673 */       if (p.x < dr.x + this._autoArea) return -1; 
/* 674 */       if (dr.x + dr.width - this._autoArea < p.x) return 1; 
/*     */     } 
/* 676 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int autoScrollDirectionVertical(Point p, MCDashboard.Board board) {
/* 689 */     Point dp = board.getScrollPane().getLocationOnScreen();
/* 690 */     Rectangle dr = board.getScrollPane().getBounds();
/* 691 */     dr.translate(dp.x, dp.y);
/* 692 */     if (dr.contains(p)) {
/* 693 */       if (p.y < dr.y + this._autoArea) return -1; 
/* 694 */       if (dr.y + dr.height - this._autoArea < p.y) return 1; 
/*     */     } 
/* 696 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JPanel createGhost(MCGadget gadget) {
/* 710 */     JPanel ghost = new JPanel()
/*     */       {
/*     */         protected void paintComponent(Graphics g) {
/* 713 */           Graphics2D g2 = (Graphics2D)g;
/* 714 */           g2.setColor(Color.BLUE);
/* 715 */           g2.setComposite(
/* 716 */               AlphaComposite.getInstance(3, 0.3F));
/* 717 */           g2.fillRect(0, 0, getWidth(), getHeight());
/*     */         }
/*     */       };
/* 720 */     JComponent base = gadget.getBase();
/* 721 */     ghost.setBorder(base.getBorder());
/* 722 */     ghost.setOpaque(true);
/* 723 */     ghost.setPreferredSize(base.getPreferredSize());
/* 724 */     ghost.setSize(base.getSize());
/* 725 */     ghost.setLocation(base.getLocation());
/* 726 */     return ghost;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setGhost() {
/* 736 */     if (this._drag == null) {
/*     */       return;
/*     */     }
/* 739 */     MCDashboard.Board board = this._drag.getBoard();
/* 740 */     Container glass = (Container)board.getRootPane().getGlassPane();
/* 741 */     if (glass != null) {
/* 742 */       glass.setVisible(true);
/* 743 */       glass.setLayout((LayoutManager)null);
/*     */       
/* 745 */       this._ghost = createGhost(this._drag);
/* 746 */       Point start = this._drag.getBase().getLocationOnScreen();
/* 747 */       Point base = glass.getLocationOnScreen();
/* 748 */       this._ghost_str = new Point(start.x - base.x, start.y - base.y);
/* 749 */       glass.add(this._ghost);
/*     */       
/* 751 */       moveGhost(0, 0);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void delGhost() {
/* 762 */     if (this._ghost != null) {
/* 763 */       Container glass = this._ghost.getParent();
/* 764 */       glass.setVisible(false);
/* 765 */       glass.remove(this._ghost);
/* 766 */       this._ghost = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void moveGhost(int move_x, int move_y) {
/* 779 */     if (this._drag == null) {
/*     */       return;
/*     */     }
/* 782 */     if (this._ghost != null) {
/* 783 */       Point gp = new Point(this._ghost_str.x + move_x, this._ghost_str.y + move_y);
/* 784 */       this._ghost.setLocation(gp);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setTrashEnabled(boolean enabled) {
/* 796 */     if (this._drag == null) {
/*     */       return;
/*     */     }
/* 799 */     MCDashboard.Board board = this._drag.getBoard();
/* 800 */     board.setTrashEnabled(enabled);
/*     */   }
/*     */   
/*     */   public void mouseEntered(MouseEvent e) {}
/*     */   
/*     */   public void mouseExited(MouseEvent e) {}
/*     */   
/*     */   public void mouseMoved(MouseEvent e) {}
/*     */   
/*     */   public static interface GadgetServer {
/*     */     MCGadget getActiveGadget();
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\dashboard\MCGadgetMouseListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */