/*     */ package mcframe.clientCore.beans.dashboard;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.JComponent;
/*     */ import mcframe.clientCore.beans.MCGadget;
/*     */ import mcframe.clientCore.beans.MCLabel;
/*     */ import mcframe.clientCore.beans.MCScrollPane;
/*     */ import mcframe.clientCore.dashboard.DataR;
/*     */ import mcframe.commonCore.container.MCIndexKey;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCLabelGadget
/*     */   extends MCGadget
/*     */ {
/*     */   private MCLabel _message;
/*     */   
/*     */   public MCLabelGadget(String type, String gadget, String id) {
/*  48 */     super(type, gadget, id);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initPanel() {
/*  53 */     super.initPanel();
/*     */     
/*  55 */     JComponent content = getContent();
/*  56 */     content.setLayout(new BorderLayout(10, 0));
/*  57 */     content.setBorder(BorderFactory.createEmptyBorder());
/*     */     
/*  59 */     this._message = new MCLabel("message");
/*  60 */     this._message.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 0));
/*  61 */     MCScrollPane p = new MCScrollPane("scroll");
/*  62 */     p.setBorder(BorderFactory.createEmptyBorder());
/*  63 */     p.setViewportView((Component)this._message);
/*  64 */     content.add((Component)p, "Center");
/*     */   }
/*     */ 
/*     */   
/*     */   protected void updateContents(MCList<DataR> dataL, MCIndexKey itemIdx) {
/*  69 */     DataR dataR = null;
/*     */ 
/*     */     
/*  72 */     String text = null;
/*  73 */     if ((dataR = (DataR)dataL.getFirst(itemIdx, new Comparable[] { "value" })) != null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  84 */       text = dataR.strval();
/*     */     }
/*  86 */     if (text == null) {
/*  87 */       text = "";
/*     */     }
/*     */ 
/*     */     
/*  91 */     List<String> binds = new ArrayList<>();
/*  92 */     int bindIdx = 1; while (true) {
/*  93 */       if ((dataR = (DataR)dataL.getFirst(itemIdx, new Comparable[] {
/*  94 */             MCDashboardUtil.indexKey("value", new int[] { bindIdx }) })) == null)
/*  95 */         break;  String bind = dataR.strval();
/*  96 */       String size = getPropertyValue(MCDashboardUtil.indexKey("font.size", new int[] { bindIdx
/*  97 */             }), dataL, itemIdx);
/*  98 */       String prop = getPropertyValue(MCDashboardUtil.indexKey("color.fg", new int[] { bindIdx
/*  99 */             }), dataL, itemIdx);
/* 100 */       Color color = (prop != null) ? MCDashboardUtil.colorValue(prop) : null;
/* 101 */       binds.add(toCSSText(bind, size, color));
/* 102 */       bindIdx++;
/*     */     } 
/*     */ 
/*     */     
/* 106 */     MCStringUtil.IndexBindSource src = new MCStringUtil.IndexBindSource(binds);
/* 107 */     src.nullstr("");
/* 108 */     text = MCStringUtil.bind(text, (MCStringUtil.BindSource)src);
/* 109 */     this._message.setText(toHTMLText(new String[] { toCSSText(text) }));
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\dashboard\MCLabelGadget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */