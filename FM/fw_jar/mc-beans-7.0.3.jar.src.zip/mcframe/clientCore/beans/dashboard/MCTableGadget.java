/*     */ package mcframe.clientCore.beans.dashboard;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.GridLayout;
/*     */ import java.util.Map;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.JComponent;
/*     */ import mcframe.clientCore.beans.MCGadget;
/*     */ import mcframe.clientCore.beans.MCLabel;
/*     */ import mcframe.clientCore.beans.MCPanel;
/*     */ import mcframe.clientCore.dashboard.DataR;
/*     */ import mcframe.commonCore.container.MCIndexKey;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.util.MCCollectionUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCTableGadget
/*     */   extends MCGadget
/*     */ {
/*     */   private MCPanel _headerPanel;
/*     */   private MCPanel _contentPanel;
/*     */   private MCLabel _cornerLabel;
/*     */   private MCLabel[] _columnLabels;
/*     */   private MCLabel[] _rowLabels;
/*     */   private MCLabel[][] _values;
/*     */   private String[] _columnTexts;
/*     */   private String[] _rowTexts;
/*  91 */   private int _row = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  98 */   private int _column = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   private int _halign = 4;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCTableGadget(String type, String gadget, String id) {
/* 117 */     super(type, gadget, id);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initPanel() {
/* 122 */     super.initPanel();
/*     */     
/* 124 */     this._headerPanel = new MCPanel("headerpanel");
/* 125 */     this._headerPanel.setPreferredSize(new Dimension(0, 27));
/* 126 */     this._headerPanel.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 5));
/* 127 */     this._headerPanel.setBackground(getBase().getBackground());
/*     */     
/* 129 */     this._contentPanel = new MCPanel("contentpanel");
/* 130 */     this._contentPanel.setBackground(getContent().getBackground());
/*     */     
/* 132 */     JComponent content = getContent();
/* 133 */     content.setLayout(new BorderLayout(0, 1));
/* 134 */     content.add((Component)this._headerPanel, "North");
/* 135 */     content.add((Component)this._contentPanel, "Center");
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setDefaultProperty(Map<String, String> propMap) {
/* 140 */     super.setDefaultProperty(propMap);
/*     */ 
/*     */     
/* 143 */     JComponent content = getContent();
/* 144 */     content.setBackground(Color.GRAY);
/* 145 */     this._headerPanel.setBackground(getColorBG());
/* 146 */     this._contentPanel.setBackground(getColorBG());
/*     */ 
/*     */     
/* 149 */     String halign = propMap.get("halign");
/* 150 */     if (halign != null) {
/* 151 */       this._halign = Integer.valueOf(halign).intValue();
/*     */     }
/*     */ 
/*     */     
/* 155 */     String coltext = propMap.get("columnlabel");
/* 156 */     if (coltext == null)
/* 157 */       throw new MCException(Core_Msg_FW_A.FCBAC0437, new Object[] {
/* 158 */             getGadgetID(), "columnlabel", coltext
/*     */           }); 
/* 160 */     this._columnTexts = coltext.split(",");
/* 161 */     this._column = this._columnTexts.length;
/* 162 */     String rowtext = propMap.get("rowlabel");
/* 163 */     if (rowtext == null)
/* 164 */       throw new MCException(Core_Msg_FW_A.FCBAC0437, new Object[] {
/* 165 */             getGadgetID(), "rowlabel", rowtext
/*     */           }); 
/* 167 */     this._rowTexts = rowtext.split(",");
/* 168 */     this._row = this._rowTexts.length;
/*     */ 
/*     */     
/* 171 */     setLabels();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setLabels() {
/* 181 */     this._headerPanel.removeAll();
/* 182 */     this._contentPanel.removeAll();
/*     */     
/* 184 */     this._headerPanel.setLayout(new GridLayout(1, 0, 0, 0));
/*     */ 
/*     */     
/* 187 */     this._cornerLabel = new MCLabel("cornerlabel");
/* 188 */     this._cornerLabel.setHorizontalAlignment(0);
/* 189 */     this._cornerLabel.setText("");
/* 190 */     this._headerPanel.add((Component)this._cornerLabel);
/*     */ 
/*     */     
/* 193 */     this._columnLabels = new MCLabel[this._column];
/* 194 */     for (int i = 0; i < this._columnLabels.length; i++) {
/* 195 */       MCLabel label = new MCLabel("columnlabel");
/* 196 */       label.setHorizontalAlignment(0);
/* 197 */       label.setText("");
/* 198 */       this._columnLabels[i] = label;
/* 199 */       this._headerPanel.add((Component)label);
/*     */     } 
/*     */ 
/*     */     
/* 203 */     this._contentPanel.setLayout(new GridLayout(this._row, 0));
/* 204 */     this._rowLabels = new MCLabel[this._row];
/* 205 */     this._values = new MCLabel[this._row][];
/* 206 */     for (int row = 0; row < this._row; row++) {
/* 207 */       MCPanel line = new MCPanel("line" + row);
/* 208 */       line.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 5));
/* 209 */       line.setLayout(new GridLayout(1, 0, 0, 10));
/* 210 */       line.setOpaque(false);
/* 211 */       this._contentPanel.add((Component)line);
/*     */ 
/*     */       
/* 214 */       MCLabel label = new MCLabel("rowlabel" + row);
/* 215 */       label.setHorizontalAlignment(0);
/* 216 */       label.setText("");
/* 217 */       this._rowLabels[row] = label;
/* 218 */       line.add((Component)label);
/*     */       
/* 220 */       this._values[row] = new MCLabel[this._column];
/* 221 */       for (int column = 0; column < this._column; column++) {
/* 222 */         MCLabel value = new MCLabel("value" + row + "_" + column);
/* 223 */         value.setHorizontalAlignment(this._halign);
/* 224 */         value.setForeground(getColorFG());
/* 225 */         line.add((Component)value);
/* 226 */         this._values[row][column] = value;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void updateContents(MCList<DataR> dataL, MCIndexKey itemIdx) {
/* 233 */     String prop = null;
/*     */ 
/*     */     
/* 236 */     prop = getPropertyValue("ccolor.fg", dataL, itemIdx);
/* 237 */     setForeground(prop, new MCLabel[] { this._cornerLabel });
/* 238 */     prop = getPropertyValue("ccolor.bg", dataL, itemIdx);
/* 239 */     setBackground(prop, new MCLabel[] { this._cornerLabel });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 245 */     MCLabel[] labels = (MCLabel[])MCCollectionUtil.concat((Object[][])new MCLabel[][] { this._rowLabels, this._columnLabels });
/* 246 */     prop = getPropertyValue("lcolor.fg", dataL, itemIdx);
/* 247 */     setForeground(prop, labels);
/* 248 */     prop = getPropertyValue("lcolor.bg", dataL, itemIdx);
/* 249 */     setBackground(prop, labels);
/*     */     
/* 251 */     prop = getPropertyValue(MCDashboardUtil.posKeyRow("lcolor.fg"), dataL, itemIdx);
/* 252 */     setForeground(prop, this._rowLabels);
/* 253 */     prop = getPropertyValue(MCDashboardUtil.posKeyRow("lcolor.bg"), dataL, itemIdx);
/* 254 */     setBackground(prop, this._rowLabels);
/*     */     int i;
/* 256 */     for (i = 0; i < this._row; i++) {
/* 257 */       prop = getPropertyValue(MCDashboardUtil.posKeyRow("lcolor.fg", i), dataL, itemIdx);
/* 258 */       setForeground(prop, new MCLabel[] { this._rowLabels[i] });
/* 259 */       prop = getPropertyValue(MCDashboardUtil.posKeyRow("lcolor.bg", i), dataL, itemIdx);
/* 260 */       setBackground(prop, new MCLabel[] { this._rowLabels[i] });
/*     */     } 
/*     */     
/* 263 */     prop = getPropertyValue(MCDashboardUtil.posKeyColumn("lcolor.fg"), dataL, itemIdx);
/* 264 */     setForeground(prop, this._columnLabels);
/* 265 */     prop = getPropertyValue(MCDashboardUtil.posKeyColumn("lcolor.bg"), dataL, itemIdx);
/* 266 */     setBackground(prop, this._columnLabels);
/*     */     
/* 268 */     for (i = 0; i < this._column; i++) {
/* 269 */       prop = getPropertyValue(MCDashboardUtil.posKeyColumn("lcolor.fg", i), dataL, itemIdx);
/* 270 */       setForeground(prop, new MCLabel[] { this._columnLabels[i] });
/* 271 */       prop = getPropertyValue(MCDashboardUtil.posKeyColumn("lcolor.bg", i), dataL, itemIdx);
/* 272 */       setBackground(prop, new MCLabel[] { this._columnLabels[i] });
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 279 */     MCLabel[] values = (MCLabel[])MCCollectionUtil.concat((Object[][])this._values);
/* 280 */     prop = getPropertyValue("vcolor.fg", dataL, itemIdx);
/* 281 */     setForeground(prop, values);
/* 282 */     prop = getPropertyValue("vcolor.bg", dataL, itemIdx);
/* 283 */     setBackground(prop, values);
/*     */     
/* 285 */     for (int j = 0; j < this._row; j++) {
/* 286 */       prop = getPropertyValue(MCDashboardUtil.posKeyRow("vcolor.fg", j), dataL, itemIdx);
/* 287 */       setForeground(prop, this._values[j]);
/* 288 */       prop = getPropertyValue(MCDashboardUtil.posKeyRow("vcolor.bg", j), dataL, itemIdx);
/* 289 */       setBackground(prop, this._values[j]);
/*     */     } 
/*     */     
/* 292 */     for (int column = 0; column < this._column; column++) {
/* 293 */       values = new MCLabel[this._row];
/* 294 */       for (int n = 0; n < this._row; n++) {
/* 295 */         values[n] = this._values[n][column];
/*     */       }
/* 297 */       prop = getPropertyValue(MCDashboardUtil.posKeyColumn("vcolor.fg", column), dataL, itemIdx);
/* 298 */       setForeground(prop, values);
/* 299 */       prop = getPropertyValue(MCDashboardUtil.posKeyColumn("vcolor.bg", column), dataL, itemIdx);
/* 300 */       setBackground(prop, values);
/*     */     } 
/*     */     
/* 303 */     for (int row = 0; row < this._row; row++) {
/* 304 */       for (int n = 0; n < this._column; n++) {
/* 305 */         prop = getPropertyValue(MCDashboardUtil.posKey("vcolor.fg", row, n), dataL, itemIdx);
/* 306 */         setForeground(prop, new MCLabel[] { this._values[row][n] });
/* 307 */         prop = getPropertyValue(MCDashboardUtil.posKey("vcolor.bg", row, n), dataL, itemIdx);
/* 308 */         setBackground(prop, new MCLabel[] { this._values[row][n] });
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 316 */     prop = getPropertyValue("cornerlabel", dataL, itemIdx);
/* 317 */     if (prop != null) {
/* 318 */       this._cornerLabel.setText(
/* 319 */           toHTMLText(new String[] { toCSSText(prop, null, this._cornerLabel.getForeground()) }));
/*     */     }
/*     */     
/* 322 */     prop = getPropertyValue("rowlabel", dataL, itemIdx);
/* 323 */     if (prop != null) {
/* 324 */       String[] texts = MCDashboardUtil.arrayValue(prop);
/* 325 */       for (int n = 0; n < labels.length && n < this._row; n++) {
/* 326 */         this._rowLabels[n].setText(toHTMLText(new String[] {
/* 327 */                 toCSSText(texts[n], null, this._rowLabels[n].getForeground())
/*     */               }));
/*     */       } 
/*     */     } 
/* 331 */     prop = getPropertyValue("columnlabel", dataL, itemIdx);
/* 332 */     if (prop != null) {
/* 333 */       String[] texts = MCDashboardUtil.arrayValue(prop);
/* 334 */       for (int n = 0; n < labels.length && n < this._column; n++) {
/* 335 */         this._columnLabels[n].setText(toHTMLText(new String[] {
/* 336 */                 toCSSText(texts[n], null, this._columnLabels[n].getForeground())
/*     */               }));
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 342 */     String xfont_size = getPropertyValue("xfont.size", dataL, itemIdx);
/* 343 */     if (xfont_size != null) {
/* 344 */       xfont_size = getFontSize();
/*     */     }
/*     */     
/* 347 */     String prefix = getPropertyValue("prefix", dataL, itemIdx);
/* 348 */     prefix = (prop != null) ? toCSSText(prefix, xfont_size, null) : "";
/*     */     
/* 350 */     String suffix = getPropertyValue("suffix", dataL, itemIdx);
/* 351 */     suffix = (prop != null) ? toCSSText(suffix, xfont_size, null) : "";
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 356 */     String vsize_default = getPropertyValue("vfont.size", dataL, itemIdx);
/*     */     
/* 358 */     String[] vsize_cols = new String[this._column];
/* 359 */     for (int k = 0; k < this._column; k++) {
/* 360 */       vsize_cols[k] = getPropertyValue(
/* 361 */           MCDashboardUtil.posKeyColumn("vfont.size", k), dataL, itemIdx);
/*     */     }
/*     */     
/* 364 */     DataR dataR = null;
/* 365 */     for (int m = 0; m < this._row; m++) {
/*     */       
/* 367 */       String vsize = getPropertyValue(MCDashboardUtil.posKeyRow("vfont.size", m), dataL, itemIdx);
/* 368 */       if (vsize == null) {
/* 369 */         vsize = vsize_default;
/*     */       }
/* 371 */       for (int n = 0; n < this._column; n++) {
/*     */         
/* 373 */         if (vsize_cols[n] != null) {
/* 374 */           vsize = vsize_cols[n];
/*     */         }
/*     */         
/* 377 */         prop = getPropertyValue(MCDashboardUtil.posKey("vfont.size", m, n), dataL, itemIdx);
/* 378 */         if (prop != null) {
/* 379 */           vsize = prop;
/*     */         }
/*     */ 
/*     */         
/* 383 */         String text = "";
/* 384 */         if ((dataR = (DataR)dataL.getFirst(itemIdx, new Comparable[] { MCDashboardUtil.indexKey(
/* 385 */                 "value", new int[] { m, n }) })) != null) {
/* 386 */           String val = dataR.strval();
/* 387 */           if (val != null) {
/* 388 */             text = toHTMLText(new String[] { prefix, toCSSText(val, vsize, 
/* 389 */                     this._values[m][n].getForeground()), suffix });
/*     */           }
/*     */         } 
/* 392 */         this._values[m][n].setText(text);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setForeground(String color, MCLabel... labels) {
/* 406 */     if (color == null || labels == null) {
/*     */       return;
/*     */     }
/* 409 */     Color c = MCDashboardUtil.colorValue(color); byte b; int i; MCLabel[] arrayOfMCLabel;
/* 410 */     for (i = (arrayOfMCLabel = labels).length, b = 0; b < i; ) { MCLabel label = arrayOfMCLabel[b];
/* 411 */       label.setForeground(c);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setBackground(String color, MCLabel... labels) {
/* 424 */     if (color == null || labels == null) {
/*     */       return;
/*     */     }
/* 427 */     Color c = MCDashboardUtil.colorValue(color); byte b; int i; MCLabel[] arrayOfMCLabel;
/* 428 */     for (i = (arrayOfMCLabel = labels).length, b = 0; b < i; ) { MCLabel label = arrayOfMCLabel[b];
/* 429 */       label.setOpaque(true);
/* 430 */       label.setBackground(c);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\dashboard\MCTableGadget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */