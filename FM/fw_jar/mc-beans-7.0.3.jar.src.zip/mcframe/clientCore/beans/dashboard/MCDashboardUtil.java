/*     */ package mcframe.clientCore.beans.dashboard;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import mcframe.clientCore.acl.MCACLManager;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCDashboard;
/*     */ import mcframe.clientCore.beans.MCGadget;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.dashboard.CndR;
/*     */ import mcframe.clientCore.dashboard.DataR;
/*     */ import mcframe.clientCore.dashboard.DevR;
/*     */ import mcframe.clientCore.dashboard.ListR;
/*     */ import mcframe.clientCore.dashboard.MCValueSupply;
/*     */ import mcframe.clientCore.dashboard.PDef;
/*     */ import mcframe.clientCore.dashboard.PropR;
/*     */ import mcframe.clientCore.requester.MCCaller;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ import mcframe.commonCore.container.MCContainer;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.dashboard.MCDashboardUtil;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.param.MCDef;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCDashboardUtil
/*     */   extends MCDashboardUtil
/*     */ {
/*     */   public static String resval(String key, String... opts) {
/*  52 */     return MCConst.app.getString(reskey(key, opts));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] resarray(String key, String... opts) {
/*  64 */     return MCConst.app.getStringArray(reskey(key, opts));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] resfind(String key, String... opts) {
/*  76 */     return MCConst.app.findKeys(reskey(key, opts));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] reschildren(String key, String... opts) {
/*  88 */     return MCConst.app.findPattern(reskey(key, opts));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void resset(String val, String key, String... opts) {
/* 100 */     MCConst.app.setString(reskey(key, opts), val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void resset(String[] val, String key, String... opts) {
/* 112 */     MCConst.app.setStringArray(reskey(key, opts), val);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void resrem(String key, String... opts) {
/* 123 */     MCConst.app.remove(reskey(key, opts));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCParam callPropOperation(MCList<CndR> cndL) {
/* 138 */     MCList<PropR> propL = MCList.create(PropR.class);
/* 139 */     DevR devR = DevR.create();
/* 140 */     if (cndL == null) {
/* 141 */       cndL = MCList.create(CndR.class);
/*     */     }
/*     */     
/* 144 */     devR.devtype("0");
/*     */     
/* 146 */     MCParam param = createParam("FC", "FCBAL0020", "Srch01", "000000");
/* 147 */     param.getContainerParam().addUpBlock((MCContainer)devR);
/* 148 */     param.getContainerParam().addUpBlock((MCContainer)cndL);
/* 149 */     param.getContainerParam().addDownBlock((MCContainer)propL);
/* 150 */     MCCaller caller = createCaller(param);
/* 151 */     caller.exec();
/* 152 */     return param;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCList<PropR> getPropList(MCParam param) {
/* 166 */     if ("FC".equals(param.getModuleId()) && 
/* 167 */       "FCBAL0020".equals(param.getLogicId()) && 
/* 168 */       "Srch01".equals(param.getOperationId()))
/*     */     {
/* 170 */       return (MCList<PropR>)param.getContainerParam().getDownBlock(0);
/*     */     }
/* 172 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCParam callDataOperation(MCList<CndR> cndL) {
/* 184 */     MCList<DataR> dataL = MCList.create(DataR.class);
/* 185 */     DevR devR = DevR.create();
/* 186 */     if (cndL == null) {
/* 187 */       cndL = MCList.create(CndR.class);
/*     */     }
/*     */     
/* 190 */     devR.devtype("0");
/*     */     
/* 192 */     MCParam param = createParam("FC", "FCBAL0020", "Srch02", "000000");
/* 193 */     param.getContainerParam().addUpBlock((MCContainer)devR);
/* 194 */     param.getContainerParam().addUpBlock((MCContainer)cndL);
/* 195 */     param.getContainerParam().addDownBlock((MCContainer)dataL);
/* 196 */     MCCaller caller = createCaller(param);
/* 197 */     caller.exec();
/* 198 */     return param;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCList<DataR> getDataList(MCParam param) {
/* 212 */     if ("FC".equals(param.getModuleId()) && 
/* 213 */       "FCBAL0020".equals(param.getLogicId()) && 
/* 214 */       "Srch02".equals(param.getOperationId()))
/*     */     {
/* 216 */       return (MCList<DataR>)param.getContainerParam().getDownBlock(0);
/*     */     }
/* 218 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCParam callListOperation(MCList<CndR> cndL) {
/* 230 */     MCList<ListR> listL = MCList.create(ListR.class);
/* 231 */     DevR devR = DevR.create();
/* 232 */     if (cndL == null) {
/* 233 */       cndL = MCList.create(CndR.class);
/*     */     }
/*     */     
/* 236 */     devR.devtype("0");
/*     */     
/* 238 */     MCParam param = createParam("FC", "FCBAL0020", "Srch03", "000000");
/* 239 */     param.getContainerParam().addUpBlock((MCContainer)devR);
/* 240 */     param.getContainerParam().addUpBlock((MCContainer)cndL);
/* 241 */     param.getContainerParam().addDownBlock((MCContainer)listL);
/* 242 */     MCCaller caller = createCaller(param);
/* 243 */     caller.exec();
/* 244 */     return param;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCList<ListR> getListList(MCParam param) {
/* 258 */     if ("FC".equals(param.getModuleId()) && 
/* 259 */       "FCBAL0020".equals(param.getLogicId()) && 
/* 260 */       "Srch03".equals(param.getOperationId()))
/*     */     {
/* 262 */       return (MCList<ListR>)param.getContainerParam().getDownBlock(0);
/*     */     }
/* 264 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static MCParam createParam(String mid, String lid, String oid, String version) {
/* 279 */     MCParam param = new MCParam(mid, lid, oid, version);
/* 280 */     param.setLimitDLSize(MCNumber.valueOf(-1));
/* 281 */     param.setDef((MCDef)new PDef());
/* 282 */     return param;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static MCCaller createCaller(MCParam param) {
/* 294 */     return new MCCaller(param);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Color colorValue(String color) {
/* 307 */     Color c = null;
/* 308 */     String[] items = color.split("[.]"); String str;
/* 309 */     switch ((str = items[0]).hashCode()) { case 69621: if (!str.equals("FIX")) {
/*     */           break;
/*     */         }
/* 312 */         c = MCConst.beans.getColor("color." + items[1]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 318 */         return c; }  c = MCDashboardUtil.colorValue(color); return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CndR addParamSrchRow(MCList<CndR> list, MCGadget gadget, MCValueSupply param) {
/* 338 */     CndR row = (CndR)list.createRow();
/* 339 */     row.gkey(gadget.getKey());
/* 340 */     row.gadget(gadget.getGadgetID());
/* 341 */     row.item((param != null) ? 
/* 342 */         param.column() : "__no_cond__");
/* 343 */     list.add((MCRow)row);
/* 344 */     return row;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ListR addParamComboListRow(MCList<ListR> list, MCGadget gadget, MCValueSupply param, String value, String name) {
/* 362 */     ListR row = (ListR)list.createRow();
/* 363 */     row.gkey(gadget.getKey());
/* 364 */     row.item(param.column());
/* 365 */     row.value(value);
/* 366 */     row.name(name);
/* 367 */     list.add((MCRow)row);
/* 368 */     return row;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void checkACL(String mid, String sid, String gadget) {
/* 386 */     String actype = MCConst.actype.getType(new String[] { mid, sid });
/* 387 */     if (actype == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 393 */     if (!MCACLManager.authorize(mid, sid, actype, gadget))
/*     */     {
/* 395 */       throw new MCException(Core_Msg_FW_A.FCBAC0166, new Object[] { String.valueOf(mid) + "." + sid });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int[] convChartType(String types) {
/* 415 */     String[] ctypes = MCStringUtil.split(",", types);
/* 416 */     int[] gtypes = new int[ctypes.length];
/* 417 */     for (int i = 0; i < ctypes.length; i++) {
/* 418 */       String ctype = ctypes[i];
/* 419 */       int t = 2; String str1;
/* 420 */       switch ((str1 = ctype).hashCode()) { case -1136053708: if (!str1.equals("stackedarea")) {
/*     */             break;
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 434 */           t = 7; break;case 97299: if (!str1.equals("bar"))
/*     */             break;  t = 2; break;
/*     */         case 110988: if (!str1.equals("pie"))
/* 437 */             break;  t = 1; break;
/*     */         case 3002509: if (!str1.equals("area"))
/*     */             break;  t = 5; break;
/*     */         case 3321844: if (!str1.equals("line"))
/*     */             break;  t = 3; break;
/*     */         case 2041563532:
/*     */           if (!str1.equals("stackedbar"))
/* 444 */             break;  t = 4; break; }  gtypes[i] = t;
/*     */     } 
/* 446 */     return gtypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void updateMenuGadgetList(String... ids) {
/* 460 */     MCRootPanel menu = MCBeansUtil.getRootPanel("FS", "FSBCP0000");
/* 461 */     if (menu != null) {
/* 462 */       MCDashboard db = getDashboard((Container)menu);
/* 463 */       if (db != null) {
/* 464 */         db.updateGadgetList(ids);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void updateGadgetData(String... ids) {
/* 477 */     MCRootPanel menu = MCBeansUtil.getRootPanel("FS", "FSBCP0000");
/* 478 */     if (menu != null) {
/* 479 */       MCDashboard db = getDashboard((Container)menu);
/* 480 */       if (db != null) {
/* 481 */         db.updateGadget(ids);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static MCDashboard getDashboard(Container ct) {
/* 495 */     Component[] cps = ct.getComponents(); byte b; int i; Component[] arrayOfComponent1;
/* 496 */     for (i = (arrayOfComponent1 = cps).length, b = 0; b < i; ) { Component cp = arrayOfComponent1[b];
/* 497 */       if (cp instanceof MCDashboard) {
/* 498 */         return (MCDashboard)cp;
/*     */       }
/* 500 */       if (cp instanceof Container) {
/* 501 */         MCDashboard db = getDashboard((Container)cp);
/* 502 */         if (db != null)
/* 503 */           return db; 
/*     */       } 
/*     */       b++; }
/*     */     
/* 507 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean groupMember(String gadget, String... group) {
/* 526 */     if (gadget == null || group == null)
/* 527 */       return false;  byte b; int i;
/*     */     String[] arrayOfString;
/* 529 */     for (i = (arrayOfString = group).length, b = 0; b < i; ) { String g = arrayOfString[b];
/* 530 */       if (g == null) {
/* 531 */         if (!miningGadget(gadget)) {
/* 532 */           return true;
/*     */         
/*     */         }
/*     */       }
/* 536 */       else if (gadget.startsWith(g)) {
/* 537 */         return true;
/*     */       } 
/*     */       b++; }
/*     */     
/* 541 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\dashboard\MCDashboardUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */