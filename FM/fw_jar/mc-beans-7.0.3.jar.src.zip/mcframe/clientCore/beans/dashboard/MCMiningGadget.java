/*    */ package mcframe.clientCore.beans.dashboard;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCMiningGadget
/*    */   extends MCFXChartGadget
/*    */ {
/*    */   public MCMiningGadget(String type, String gadget, String id) {
/* 23 */     super(type, gadget, id);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\dashboard\MCMiningGadget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */