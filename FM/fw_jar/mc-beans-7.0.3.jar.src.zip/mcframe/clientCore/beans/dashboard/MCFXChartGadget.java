/*     */ package mcframe.clientCore.beans.dashboard;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import javafx.scene.chart.PieChart;
/*     */ import javafx.scene.chart.XYChart;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.JPopupMenu;
/*     */ import javax.swing.SwingUtilities;
/*     */ import mcframe.clientCore.beans.MCDashboard;
/*     */ import mcframe.clientCore.beans.MCGadget;
/*     */ import mcframe.clientCore.beans.MCPanel;
/*     */ import mcframe.clientCore.beans.fxgraph.MCFXGraph;
/*     */ import mcframe.clientCore.beans.fxgraph.MCFXGraphCore;
/*     */ import mcframe.clientCore.beans.fxgraph.MCFXGraphDelegate;
/*     */ import mcframe.clientCore.beans.fxgraph.MCFXGraphDetailsTooltip;
/*     */ import mcframe.clientCore.beans.fxgraph.MCFXGraphDetailsTooltipPie;
/*     */ import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
/*     */ import mcframe.clientCore.dashboard.DataR;
/*     */ import mcframe.clientCore.dashboard.MCValueSupply;
/*     */ import mcframe.clientCore.event.MCAPBeans;
/*     */ import mcframe.clientCore.event.MCAPListener;
/*     */ import mcframe.clientCore.event.MCEventInfo;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ import mcframe.commonCore.container.MCIndexKey;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCDataMatcher;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCFXChartGadget
/*     */   extends MCGadget
/*     */   implements MCFXGraphDelegate
/*     */ {
/*     */   private int[] _type_default;
/*     */   private int[] _type;
/*     */   private String[] _color;
/*  70 */   private String _threshold_col = null;
/*     */ 
/*     */ 
/*     */   
/*  74 */   private MCNumber _threshold_val = null;
/*     */ 
/*     */ 
/*     */   
/*  78 */   private String _threshold_rel = null;
/*     */ 
/*     */ 
/*     */   
/*  82 */   private String _pushmsg = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean _pushmsgimp = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  93 */   private MCGadget.GadgetTimerTask _task = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Color _title_bg_org;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCTextPopupMenuItem popup_blink;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCFXGraph graph;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCFXChartGadget(String type, String gadget, String id) {
/* 124 */     super(type, gadget, id);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initPanel() {
/* 129 */     super.initPanel();
/*     */     
/* 131 */     MCPanel content = (MCPanel)getContent();
/* 132 */     content.setLayout(new BorderLayout());
/*     */ 
/*     */     
/* 135 */     this._title_bg_org = getTitle().getBackground();
/*     */ 
/*     */     
/* 138 */     MCList<MCRow> dataL = MCList.create(MCRow.class);
/* 139 */     String title = "";
/* 140 */     int[] typeList = MCDashboardUtil.convChartType("bar");
/* 141 */     String labelColumn = "";
/* 142 */     String labelLabel = "";
/* 143 */     String[] valueColumns = { "" };
/* 144 */     String[] valueColumnsName = { "" };
/* 145 */     String valueLabel = "";
/* 146 */     MCNumber threshold = null;
/* 147 */     int threshold_col = -1;
/* 148 */     createChart(
/* 149 */         dataL, 
/* 150 */         title, 
/* 151 */         typeList, 
/* 152 */         (String[])null, 
/* 153 */         labelColumn, 
/* 154 */         labelLabel, 
/* 155 */         valueColumns, 
/* 156 */         valueColumnsName, 
/* 157 */         valueLabel, 
/* 158 */         threshold, 
/* 159 */         threshold_col);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void createChart(MCList<MCRow> dataL, String title, int[] types, String[] colors, String labelColumn, String labelLabel, String[] valueColumns, String[] valueColumnsName, String valueLabel, MCNumber threshold, int threshold_col) {
/* 204 */     if (this.graph != null) {
/* 205 */       this.graph.removePanel();
/* 206 */       this.graph = null;
/*     */     } 
/*     */ 
/*     */     
/* 210 */     List<Integer> typeList = null;
/* 211 */     if (types != null) {
/* 212 */       typeList = new ArrayList<>(); byte b; int i, arrayOfInt[];
/* 213 */       for (i = (arrayOfInt = types).length, b = 0; b < i; ) { int type = arrayOfInt[b];
/* 214 */         typeList.add(Integer.valueOf(type));
/*     */         b++; }
/*     */     
/*     */     } 
/* 218 */     List<String> colorList = null;
/* 219 */     if (colors != null) {
/* 220 */       colorList = Arrays.asList(colors);
/*     */     }
/*     */     
/* 223 */     List<String> labelColumnList = new ArrayList<>();
/* 224 */     if (labelColumn != null) {
/* 225 */       labelColumnList.add(labelColumn);
/*     */     }
/*     */ 
/*     */     
/* 229 */     MCPanel content = (MCPanel)getContent();
/* 230 */     this.graph = new MCFXGraph();
/* 231 */     this.graph.setGraphDelegate(this);
/* 232 */     this.graph.setUseThresholdRect(false);
/* 233 */     if (threshold == null || threshold_col >= types.length) {
/*     */       
/* 235 */       this.graph.setUseThresholdLine(false);
/*     */     } else {
/*     */       
/* 238 */       this.graph.setUseThresholdLine(true);
/* 239 */       this.graph.setThreshold(threshold.doubleValue());
/*     */       
/* 241 */       if (threshold_col < 0) {
/* 242 */         threshold_col = 0;
/*     */       }
/* 244 */       this.graph.setUseThresholdLineChart(
/*     */           
/* 246 */           (types[threshold_col] == 3));
/*     */     } 
/*     */ 
/*     */     
/* 250 */     List<String> valueColumnsList = new ArrayList<>();
/* 251 */     if (valueColumns != null) {
/* 252 */       valueColumnsList = Arrays.asList(valueColumns);
/*     */     }
/*     */     
/* 255 */     List<String> valueColumnsNameList = new ArrayList<>();
/* 256 */     if (valueColumnsName != null) {
/* 257 */       valueColumnsNameList = Arrays.asList(valueColumnsName);
/*     */     }
/*     */     
/* 260 */     this.graph.initInnerGraphControl(
/* 261 */         content, 
/* 262 */         title, 
/* 263 */         typeList, 
/* 264 */         colorList, 
/* 265 */         dataL, 
/* 266 */         labelColumnList, 
/* 267 */         labelLabel, 
/* 268 */         valueColumnsList, 
/* 269 */         valueColumnsNameList, 
/* 270 */         valueLabel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getDefaultChartType(int index) {
/* 286 */     return (index < this._type_default.length) ? 
/* 287 */       this._type_default[index] : 
/* 288 */       this._type_default[this._type_default.length - 1];
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setDefaultProperty(Map<String, String> propMap) {
/* 293 */     super.setDefaultProperty(propMap);
/*     */ 
/*     */     
/* 296 */     String type = propMap.get("charttype");
/* 297 */     if (type == null)
/* 298 */       throw new MCException(Core_Msg_FW_A.FCBAC0437, new Object[] {
/* 299 */             getGadgetID(), "charttype", type
/*     */           }); 
/* 301 */     this._type_default = MCDashboardUtil.convChartType(type);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setAttributeProperty(Map<String, String> propMap) {
/* 306 */     super.setAttributeProperty(propMap);
/*     */     
/* 308 */     String key = null;
/* 309 */     String name = null;
/* 310 */     MCValueSupply attr = null;
/*     */ 
/*     */     
/* 313 */     key = "charttype";
/* 314 */     String coltext = propMap.get("columnlabel");
/* 315 */     if (coltext == null) {
/*     */       
/* 317 */       name = getAttrLabel(key);
/* 318 */       attr = createGadgetParam(key, name, "1C", false);
/* 319 */       putAttributeMap(key, new MCValueSupply[] { attr });
/* 320 */       this._type = Arrays.copyOf(this._type_default, this._type_default.length);
/* 321 */       this._color = null;
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 326 */       String[] cols = coltext.split(",");
/* 327 */       this._type = new int[cols.length];
/* 328 */       MCValueSupply[] arrayOfMCValueSupply = new MCValueSupply[cols.length];
/* 329 */       for (int i = 0; i < this._type.length; i++) {
/* 330 */         name = String.valueOf(getAttrLabel(key)) + " (" + cols[i] + ")";
/* 331 */         attr = createGadgetParam(String.valueOf(key) + i, name, "1C", false);
/* 332 */         int _default = getDefaultChartType(i);
/* 333 */         attr.value(String.valueOf(_default));
/* 334 */         this._type[i] = _default;
/* 335 */         arrayOfMCValueSupply[i] = attr;
/*     */       } 
/* 337 */       putAttributeMap(key, arrayOfMCValueSupply);
/*     */       
/* 339 */       String colortext = propMap.get("chartcolor");
/* 340 */       this._color = (colortext != null) ? colortext.split(",") : null;
/* 341 */       if (this._color != null && cols.length != this._color.length) {
/* 342 */         this._color = null;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 347 */     key = "threshold";
/* 348 */     name = getAttrLabel(key);
/* 349 */     MCValueSupply[] attrs = {
/* 350 */         createGadgetParam(String.valueOf(key) + ".col", name, "1", false), 
/* 351 */         createGadgetParam(String.valueOf(key) + ".val", name, "2", false), 
/* 352 */         createGadgetParam(String.valueOf(key) + ".rel", name, "1", false)
/*     */       };
/* 354 */     putAttributeMap(key, attrs);
/*     */ 
/*     */     
/* 357 */     key = "pushmsg";
/* 358 */     name = getAttrLabel(key);
/* 359 */     attr = createGadgetParam(key, name, "1A", false);
/* 360 */     putAttributeMap(key, new MCValueSupply[] { attr });
/*     */ 
/*     */     
/* 363 */     key = "pushmsgimp";
/* 364 */     name = getAttrLabel(key);
/* 365 */     attr = createGadgetParam(key, name, "5", false);
/* 366 */     putAttributeMap(key, new MCValueSupply[] { attr });
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean updateAttribute() {
/* 371 */     if (!super.updateAttribute()) {
/* 372 */       return false;
/*     */     }
/*     */     
/* 375 */     Map<String, MCValueSupply[]> attrMap = getAttributeMap();
/* 376 */     MCValueSupply[] attrs = null;
/*     */ 
/*     */     
/* 379 */     int[] typetmp = new int[this._type.length];
/* 380 */     boolean stack = false;
/* 381 */     Set<Integer> typeSet = new HashSet<>();
/* 382 */     attrs = attrMap.get("charttype"); int i;
/* 383 */     for (i = 0; i < attrs.length; i++) {
/* 384 */       MCValueSupply attr = attrs[i];
/* 385 */       if (attr != null) {
/* 386 */         String type = (String)attr.value();
/* 387 */         int typeval = (type != null) ? 
/* 388 */           Integer.parseInt(type) : 
/* 389 */           getDefaultChartType(i);
/* 390 */         if (typeval == 4 || 
/* 391 */           typeval == 7) {
/* 392 */           stack = true;
/*     */         }
/* 394 */         typeSet.add(Integer.valueOf(typeval));
/* 395 */         switch (typeSet.size()) {
/*     */           case 2:
/* 397 */             if (stack)
/*     */             {
/* 399 */               throw new MCException(Core_Msg_FW_A.FCBAC0442, new Object[0]);
/*     */             }
/*     */             break;
/*     */           
/*     */           case 3:
/* 404 */             throw new MCException(Core_Msg_FW_A.FCBAC0443, new Object[0]);
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 409 */         typetmp[i] = typeval;
/*     */       } 
/*     */     } 
/* 412 */     for (i = 0; i < attrs.length; i++) {
/* 413 */       this._type[i] = typetmp[i];
/* 414 */       attrs[i].value(String.valueOf(this._type[i]));
/*     */     } 
/*     */ 
/*     */     
/* 418 */     attrs = attrMap.get("threshold");
/* 419 */     if (attrs != null) {
/* 420 */       if (getDefaultProperty("columnlabel") != null)
/*     */       {
/* 422 */         if (stack)
/*     */         {
/* 424 */           if (attrs[0].value() != null)
/*     */           {
/* 426 */             attrs[0].value(null);
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 443 */       this._threshold_col = (String)attrs[0].value();
/* 444 */       this._threshold_val = (MCNumber)attrs[1].value();
/* 445 */       this._threshold_rel = (String)attrs[2].value();
/*     */     } 
/*     */ 
/*     */     
/* 449 */     attrs = attrMap.get("pushmsg");
/* 450 */     if (attrs != null) {
/* 451 */       this._pushmsg = (String)attrs[0].value();
/*     */     }
/*     */ 
/*     */     
/* 455 */     attrs = attrMap.get("pushmsgimp");
/* 456 */     if (attrs != null) {
/* 457 */       this._pushmsgimp = ((Boolean)attrs[0].value()).booleanValue();
/*     */     }
/*     */     
/* 460 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void updateContents(MCList<DataR> dataL, MCIndexKey itemIdx) {
/* 465 */     String prop = null;
/*     */ 
/*     */ 
/*     */     
/* 469 */     String rowTitle = getPropertyValue("rowtitle", dataL, itemIdx);
/* 470 */     String columnTitle = getPropertyValue("columntitle", dataL, itemIdx);
/*     */     
/* 472 */     prop = getPropertyValue("rowlabel", dataL, itemIdx);
/* 473 */     String[] rowLabels = (prop != null) ? 
/* 474 */       MCDashboardUtil.arrayValue(prop) : new String[0];
/* 475 */     prop = getPropertyValue("columnlabel", dataL, itemIdx);
/* 476 */     String[] columnLabels = (prop != null) ? 
/* 477 */       MCDashboardUtil.arrayValue(prop) : new String[0];
/*     */ 
/*     */     
/* 480 */     int _rowcnt = rowLabels.length;
/* 481 */     int _colcnt = columnLabels.length;
/*     */ 
/*     */     
/* 484 */     MCList<MCRow> list = MCList.create(MCRow.class);
/* 485 */     int colidx = 0;
/*     */ 
/*     */     
/* 488 */     String[] valueColumns = new String[_colcnt];
/* 489 */     for (; colidx < _colcnt; colidx++) {
/* 490 */       valueColumns[colidx] = String.valueOf(colidx);
/* 491 */       list.addNumberColumn(valueColumns[colidx]);
/*     */     } 
/*     */     
/* 494 */     String rowLabelCol = null;
/* 495 */     if (_rowcnt > 0) {
/* 496 */       rowLabelCol = String.valueOf(colidx);
/* 497 */       list.addStringColumn(rowLabelCol);
/*     */     } 
/*     */ 
/*     */     
/* 501 */     boolean stackover = false;
/* 502 */     boolean columnover = false;
/* 503 */     int threshold_col = (this._threshold_col != null) ? 
/* 504 */       Integer.parseInt(this._threshold_col) : -1;
/* 505 */     MCDataMatcher matcher = (this._threshold_val != null) ? 
/* 506 */       MCDataMatcher.create(this._threshold_val, this._threshold_rel) : 
/* 507 */       null;
/* 508 */     DataR dataR = null;
/* 509 */     int row = 0;
/*     */     
/*     */     do {
/* 512 */       MCNumber stack = MCNumber.ZERO;
/* 513 */       MCRow listR = list.createRow();
/* 514 */       int col = 0;
/* 515 */       for (; col < _colcnt; col++) {
/* 516 */         if ((dataR = (DataR)dataL.getFirst(itemIdx, new Comparable[] {
/* 517 */               MCDashboardUtil.indexKey("value", new int[] { row, col })
/*     */             })) == null) {
/*     */           break;
/*     */         }
/* 521 */         MCNumber val = dataR.numval();
/* 522 */         listR.setNumber(valueColumns[col], val);
/* 523 */         if (val != null) {
/* 524 */           stack = stack.add((BigDecimal)val);
/*     */         }
/*     */         
/* 527 */         if ((threshold_col < 0 || col == threshold_col) && 
/* 528 */           matcher != null && matcher.match((Comparable)val)) {
/* 529 */           columnover = true;
/*     */         }
/*     */       } 
/*     */       
/* 533 */       if (dataR == null) {
/*     */         break;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 539 */       if (matcher != null && matcher.match((Comparable)stack)) {
/* 540 */         stackover = true;
/*     */       }
/*     */ 
/*     */       
/* 544 */       if (row < _rowcnt) {
/* 545 */         listR.setString(rowLabelCol, rowLabels[row]);
/*     */       }
/*     */       
/* 548 */       if (col > 0) {
/* 549 */         list.add(listR);
/*     */       }
/* 551 */       row++;
/*     */     }
/* 553 */     while (dataR != null);
/*     */ 
/*     */ 
/*     */     
/* 557 */     int[] types = this._type;
/* 558 */     if (_colcnt != types.length) {
/*     */       
/* 560 */       types = new int[_colcnt];
/* 561 */       Arrays.fill(types, this._type[0]);
/*     */     } 
/* 563 */     String[] colors = this._color;
/* 564 */     if (colors != null && _colcnt != colors.length)
/*     */     {
/* 566 */       colors = null;
/*     */     }
/* 568 */     String title = "";
/* 569 */     String labelColumn = rowLabelCol;
/* 570 */     createChart(list, 
/* 571 */         title, 
/* 572 */         types, 
/* 573 */         colors, 
/* 574 */         labelColumn, 
/* 575 */         rowTitle, 
/* 576 */         valueColumns, 
/* 577 */         columnLabels, 
/* 578 */         columnTitle, 
/* 579 */         this._threshold_val, 
/* 580 */         threshold_col);
/*     */ 
/*     */ 
/*     */     
/* 584 */     boolean over = false;
/* 585 */     if (this._threshold_val != null) {
/*     */ 
/*     */ 
/*     */       
/* 589 */       if (threshold_col < 0) {
/* 590 */         threshold_col = 0;
/*     */       }
/* 592 */       switch (this._type[threshold_col]) {
/*     */         case 4:
/*     */         case 7:
/* 595 */           over = stackover;
/*     */           break;
/*     */         default:
/* 598 */           over = columnover;
/*     */           break;
/*     */       } 
/*     */     
/*     */     } 
/* 603 */     if (over && this._pushmsg != null) {
/*     */       
/* 605 */       if (!isThreshouldPushed()) {
/* 606 */         MCMessage msg = new MCMessage(Core_Msg_FW_A.FCBAC0435, new Object[] { this._pushmsg });
/* 607 */         sendPushMessage(msg, this._pushmsgimp);
/* 608 */         setThreshouldPushed(true);
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 613 */       setThreshouldPushed(false);
/*     */     } 
/*     */     
/* 616 */     if (over) {
/*     */       
/* 618 */       if (this._task == null) {
/* 619 */         this._task = createTitleBlinkTask();
/*     */ 
/*     */ 
/*     */         
/* 623 */         ScheduledExecutorService cron = getBoard().getCron();
/* 624 */         this._task.setFuture(
/* 625 */             cron.scheduleAtFixedRate((Runnable)this._task, 0L, 1000L, TimeUnit.MILLISECONDS));
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/* 631 */     else if (this._task != null) {
/* 632 */       this._task.cancel();
/* 633 */       this._task = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCGadget.GadgetTimerTask createTitleBlinkTask() {
/* 647 */     return new MCGadget.GadgetTimerTask(this)
/*     */       {
/* 649 */         private Color _alt = MCConst.beans.getColor(
/* 650 */             MCConst.createKey(new String[] { MCDashboard.getResKeyGadget(), 
/* 651 */                 "chart", 
/* 652 */                 "threshold", 
/* 653 */                 "bg"
/* 654 */               }, ), Color.RED);
/*     */         
/*     */         private boolean _blink = false;
/*     */         
/*     */         public void run() {
/*     */           try {
/* 660 */             SwingUtilities.invokeLater(() -> {
/*     */                   this._blink ^= 0x1;
/*     */ 
/*     */                   
/*     */                   MCFXChartGadget gadget = MCFXChartGadget.this;
/*     */                   
/*     */                   gadget.getTitle().setBackground(this._blink ? this._alt : gadget._title_bg_org);
/*     */                 });
/* 668 */           } catch (Throwable e) {
/* 669 */             MCFXChartGadget.this.setErrorContents(e);
/*     */           } 
/*     */         }
/*     */ 
/*     */         
/*     */         public boolean cancel() {
/* 675 */           MCFXChartGadget.this.getTitle().setBackground(MCFXChartGadget.this._title_bg_org);
/* 676 */           return super.cancel();
/*     */         }
/*     */       };
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setupPopupMenuItem(MCAPListener ap) {
/* 683 */     super.setupPopupMenuItem(ap);
/*     */ 
/*     */     
/* 686 */     this.popup_blink = createPopupMenuItem("POPUP_GADGET_BLINK");
/* 687 */     this.popup_blink.addAPListener(ap);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setupOperationPopup(JPopupMenu popup) {
/* 692 */     super.setupOperationPopup(popup);
/*     */     
/* 694 */     if (this._task != null)
/*     */     {
/* 696 */       popup.add((JMenuItem)this.popup_blink);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean doPopupEvent(MCAPBeans compo, MCEventInfo info) {
/* 702 */     if (super.doPopupEvent(compo, info)) {
/* 703 */       return true;
/*     */     }
/*     */     
/* 706 */     if (compo == this.popup_blink) {
/*     */       
/* 708 */       setThreshouldPushed(false);
/*     */       
/* 710 */       if (this._task != null) {
/* 711 */         this._task.cancel();
/* 712 */         this._task = null;
/*     */       } 
/* 714 */       return true;
/*     */     } 
/*     */     
/* 717 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doCloseOuterGraph(MCFXGraphCore graph) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean doClickXYGraph(MCFXGraphCore graph, XYChart chart, XYChart.Series<String, Number> series, XYChart.Data data, String xValue, Number yValue) {
/* 730 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean doClickPieGraph(MCFXGraphCore graph, PieChart chart, PieChart.Data item, String labelValue, Number pieValue) {
/* 736 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean installTooltipPie(MCFXGraphCore graph, PieChart chart, PieChart.Data data) {
/* 742 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCFXGraphDetailsTooltip getDetailsTooltip(MCFXGraphCore graph) {
/* 747 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCFXGraphDetailsTooltipPie getDetailsTooltipPie(MCFXGraphCore graph) {
/* 752 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\dashboard\MCFXChartGadget.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */