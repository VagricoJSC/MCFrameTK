/*      */ package mcframe.clientCore.beans.combobox;
/*      */ 
/*      */ import java.awt.BorderLayout;
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Font;
/*      */ import java.awt.Insets;
/*      */ import java.awt.Point;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.event.MouseAdapter;
/*      */ import java.awt.event.MouseEvent;
/*      */ import java.awt.event.MouseListener;
/*      */ import java.util.Collection;
/*      */ import javax.swing.BorderFactory;
/*      */ import javax.swing.InputVerifier;
/*      */ import javax.swing.JComponent;
/*      */ import javax.swing.JList;
/*      */ import javax.swing.JPanel;
/*      */ import javax.swing.SwingUtilities;
/*      */ import javax.swing.Timer;
/*      */ import javax.swing.UIManager;
/*      */ import javax.swing.border.Border;
/*      */ import javax.swing.event.AncestorEvent;
/*      */ import javax.swing.event.AncestorListener;
/*      */ import mcframe.clientCore.acl.MCACLManager;
/*      */ import mcframe.clientCore.beans.MCBeans;
/*      */ import mcframe.clientCore.beans.MCBeansDelegate;
/*      */ import mcframe.clientCore.beans.MCBeansUtil;
/*      */ import mcframe.clientCore.beans.MCLabel;
/*      */ import mcframe.clientCore.beans.MCMode;
/*      */ import mcframe.clientCore.beans.MCModeBeans;
/*      */ import mcframe.clientCore.beans.MCModeInfo;
/*      */ import mcframe.clientCore.beans.MCResourceBeans;
/*      */ import mcframe.clientCore.beans.MCRootPanel;
/*      */ import mcframe.clientCore.beans.MCRowBeans;
/*      */ import mcframe.clientCore.beans.MCTabOrderBeans;
/*      */ import mcframe.clientCore.beans.action.MCActionBeans;
/*      */ import mcframe.clientCore.beans.action.MCKeyActionManager;
/*      */ import mcframe.clientCore.beans.list.MCLinkBeans;
/*      */ import mcframe.clientCore.beans.list.MCLinkedBeans;
/*      */ import mcframe.clientCore.beans.list.MCListConfig;
/*      */ import mcframe.clientCore.beans.list.MCListListener;
/*      */ import mcframe.clientCore.beans.list.MCListPutter;
/*      */ import mcframe.clientCore.beans.list.MCListType;
/*      */ import mcframe.clientCore.beans.table.MCTable;
/*      */ import mcframe.clientCore.beans.text.MCInputVerifier;
/*      */ import mcframe.clientCore.beans.text.MCValueChecker;
/*      */ import mcframe.clientCore.container.MCConstRow;
/*      */ import mcframe.clientCore.container.MCRowEvent;
/*      */ import mcframe.clientCore.container.MCRowListener;
/*      */ import mcframe.clientCore.event.MCDCBeans;
/*      */ import mcframe.clientCore.event.MCDCListener;
/*      */ import mcframe.clientCore.event.MCEventBeans;
/*      */ import mcframe.clientCore.event.MCEventInfo;
/*      */ import mcframe.clientCore.event.MCEventList;
/*      */ import mcframe.clientCore.event.MCEventListener;
/*      */ import mcframe.clientCore.event.MCLCBeans;
/*      */ import mcframe.clientCore.event.MCLCListener;
/*      */ import mcframe.clientCore.event.MCNCBeans;
/*      */ import mcframe.clientCore.event.MCNCListener;
/*      */ import mcframe.clientCore.event.MCNCReceiver;
/*      */ import mcframe.clientCore.event.MCNEBeans;
/*      */ import mcframe.clientCore.event.MCNEListener;
/*      */ import mcframe.clientCore.event.MCNEReceiver;
/*      */ import mcframe.clientCore.event.MCNXBeans;
/*      */ import mcframe.clientCore.event.MCNXListener;
/*      */ import mcframe.clientCore.event.MCNXReceiver;
/*      */ import mcframe.clientCore.event.MCVCBeans;
/*      */ import mcframe.clientCore.event.MCVCListener;
/*      */ import mcframe.clientCore.event.MCVCReceiver;
/*      */ import mcframe.clientCore.resource.MCConst;
/*      */ import mcframe.commonCore.container.MCList;
/*      */ import mcframe.commonCore.container.MCRow;
/*      */ import mcframe.commonCore.lang.MCDataType;
/*      */ import mcframe.commonCore.meta.MCMeta;
/*      */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*      */ import mcframe.commonCore.notice.MCException;
/*      */ import mcframe.commonCore.notice.MCLog;
/*      */ import mcframe.commonCore.notice.MCMessage;
/*      */ import mcframe.commonCore.notice.MCMessageLevel;
/*      */ import mcframe.commonCore.notice.MCMessageList;
/*      */ import mcframe.commonCore.util.MCCollectionUtil;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class AbsMCComboBox<T extends Comparable<?>>
/*      */   extends JPanel
/*      */   implements MCTabOrderBeans, MCModeBeans, MCActionBeans, MCLinkBeans, MCLinkedBeans, MCRowBeans, MCVCBeans, MCVCReceiver, MCNCBeans, MCNCReceiver, MCNEBeans, MCNEReceiver, MCNXBeans, MCNXReceiver, MCLCBeans, MCDCBeans
/*      */ {
/*  105 */   private final MCEventList _event_list = new MCEventList();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  113 */   private MCComboField _field = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  121 */   private MCComboButton _button = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  129 */   private MCComboPopup<T> _popup = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  137 */   private MCComboListModel<T> _model = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  145 */   private MCBeansDelegate _delegate = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  153 */   private MCRootPanel _panel = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  161 */   private MCRootPanel _init_panel = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  169 */   private MCLabel _label = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  177 */   private String _label_name = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  185 */   private String _message_name_resource = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  193 */   private String _message_name = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  201 */   private MCMode _mode = MCMode.NULL;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  209 */   private MCEventInfo _event_info = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  217 */   private int _maximum_row_count = 8;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _do_list_event_null = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _have_link_values_null_when_dupli_key_typed = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _exec_link_error_processing = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  244 */   private MCListConfig _list_config = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  252 */   private MCComboListConfig _combo_list_config = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  260 */   private String[] _visible_column_names = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  268 */   private MCConstRow _data_row = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  276 */   private String _data_row_column_name = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  284 */   private MCDataType _data_row_data_type = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  292 */   private MCMeta _meta = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _ignore_status = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  308 */   private MCValueChecker _value_checker = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  316 */   private Rectangle _default_ratio_bounds = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  324 */   private Font _default_font = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  332 */   private MouseListener _field_mouse_listener = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  340 */   private AncestorListener _field_ancestor_listener = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  348 */   private Color _list_selected_foreground_resource = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  356 */   private Color _list_selected_background_resource = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  364 */   private Color _list_foreground_resource = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  372 */   private Color _list_background_resource = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _required_flg = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean _auto_focus = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean _selectall = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  410 */   private final MCMouseListener _mouse_listener = new MCMouseListener(null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Rectangle _default_bounds;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean _is_handle_processing;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _read_only_flg;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setName(String name) {
/*  436 */     setName(name, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setName(String name, boolean init) {
/*  451 */     MCBeansUtil.checkName(name);
/*  452 */     super.setName(name);
/*  453 */     if (init) {
/*  454 */       updateResource();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void init() {
/*  465 */     initBeans();
/*  466 */     initResource();
/*  467 */     initKeyAssign();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initBeans() {
/*  477 */     setLayout(new BorderLayout());
/*  478 */     super.setBorder(BorderFactory.createEmptyBorder());
/*      */     
/*  480 */     add(getComboField().getComponent(), "Center");
/*  481 */     add(getComboButton(), "East");
/*      */     
/*  483 */     addMouseListener(getMouseListener());
/*  484 */     getComboButton().addMouseListener(getMouseListener());
/*      */     
/*  486 */     getComboButton().addMouseMotionListener(getMouseListener());
/*      */     
/*  488 */     getComboField().getComponent().addMouseListener(getFieldMouseListener());
/*  489 */     getComboField().getComponent().addAncestorListener(getFieldAncestorListener());
/*      */ 
/*      */     
/*  492 */     setInputVerifier((InputVerifier)new MCInputVerifier());
/*      */   }
/*      */   
/*      */   final MCMouseListener getMouseListener() {
/*  496 */     return this._mouse_listener;
/*      */   }
/*      */   
/*      */   private class MCMouseListener extends MouseAdapter {
/*      */     private MCMouseListener() {}
/*      */     
/*      */     public void mousePressed(MouseEvent e) {
/*  503 */       if (!SwingUtilities.isLeftMouseButton(e) || (
/*  504 */         AbsMCComboBox.this._popup != null && e.getSource() == AbsMCComboBox.this._popup.getList())) {
/*  505 */         MCComboPopup.setListPressing(true);
/*      */         
/*      */         return;
/*      */       } 
/*  509 */       if (!AbsMCComboBox.this.isEnabled() || !AbsMCComboBox.this.isEditable()) {
/*      */         return;
/*      */       }
/*  512 */       if (AbsMCComboBox.this.isEditable()) {
/*  513 */         JComponent o = AbsMCComboBox.this.getComboField().getComponent();
/*  514 */         if (o.isRequestFocusEnabled()) {
/*  515 */           if (!o.isFocusOwner() && !o.requestFocus(false)) {
/*      */             return;
/*      */           }
/*      */         } else {
/*      */           return;
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  524 */       MCComboPopup p = AbsMCComboBox.this.getComboPopup();
/*  525 */       if (p.isVisible()) {
/*  526 */         p.setVisible(false);
/*      */       } else {
/*      */         
/*  529 */         p.showPopup();
/*      */       } 
/*      */     }
/*      */     
/*      */     public void mouseReleased(MouseEvent e) {
/*      */       Timer t;
/*  535 */       Object s = e.getSource();
/*  536 */       AbsMCComboBox<Comparable> c = AbsMCComboBox.this;
/*  537 */       MCComboPopup p = c.getComboPopup();
/*  538 */       JList l = p.getList();
/*      */       
/*  540 */       if (s != l && s != c.getComboButton()) {
/*      */         return;
/*      */       }
/*      */       
/*      */       try {
/*  545 */         boolean set_value = false;
/*  546 */         if (s == l) {
/*  547 */           set_value = true;
/*      */         } else {
/*      */           
/*  550 */           Dimension d = ((MCComboButton)s).getSize();
/*  551 */           Rectangle a = new Rectangle(0, 0, d.width - 1, d.height - 1);
/*  552 */           if (!a.contains(e.getPoint())) {
/*  553 */             MouseEvent ne = p.convertMouseEvent(e);
/*  554 */             Point np = ne.getPoint();
/*  555 */             Rectangle na = new Rectangle();
/*  556 */             l.computeVisibleRect(na);
/*  557 */             if (na.contains(np)) {
/*  558 */               set_value = true;
/*      */             }
/*      */           } else {
/*      */             return;
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/*  566 */         if (set_value && l.getModel().getSize() > 0) {
/*  567 */           int i = l.getSelectedIndex();
/*  568 */           MCEventInfo f = c.getEventInfo();
/*  569 */           MCEventProxy.PROXY.setListIndex(f, f.getOldListIndex(), i);
/*  570 */           MCRow o = c.getModel().getRow(i);
/*  571 */           MCEventProxy.PROXY.setNewListRow(f, o);
/*  572 */           c.getModel().setSelectedIndex(i);
/*  573 */           Comparable comparable = (o != null) ? o.getValue(c.getKeyColumnName()) : null;
/*  574 */           c.setText(comparable);
/*      */ 
/*      */           
/*  577 */           if (!p.isVisible()) {
/*  578 */             MCBeansUtil.requestCommit(c);
/*      */           }
/*      */         } 
/*      */         
/*  582 */         if (c.isEditable()) {
/*      */           
/*  584 */           Component o = MCBeansUtil.getFocusOwner(c);
/*  585 */           if (o instanceof MCTable) {
/*  586 */             o = ((MCTable)o).getMCEditorComponent();
/*      */           }
/*  588 */           if (c.equals(o)) {
/*  589 */             c.getComboField().getComponent().requestFocus();
/*      */           }
/*      */         } 
/*  592 */         c.setPopupVisible(false);
/*      */       }
/*  594 */       catch (RuntimeException ex) {
/*      */ 
/*      */         
/*  597 */         c.setPopupVisible(false);
/*  598 */         MCBeansUtil.handle(c, ex);
/*      */         
/*  600 */         if (c.isEditable())
/*      */         {
/*  602 */           Component o = MCBeansUtil.getFocusOwner(c);
/*  603 */           if (o instanceof MCTable) {
/*  604 */             o = ((MCTable)o).getMCEditorComponent();
/*      */           }
/*  606 */           if (c.equals(o)) {
/*  607 */             c.getComboField().getComponent().requestFocus();
/*      */           }
/*      */         }
/*      */       
/*      */       } finally {
/*      */         
/*  613 */         p.stopAutoScrolling();
/*      */ 
/*      */         
/*  616 */         Timer timer = new Timer(MCActionProxy.PROXY.getIgnoreMillis(), 
/*  617 */             new MCComboPopup.TimerAction());
/*  618 */         timer.start();
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void mouseMoved(MouseEvent e) {
/*  624 */       MCComboPopup p = AbsMCComboBox.this._popup;
/*  625 */       if (p == null) {
/*      */         return;
/*      */       }
/*  628 */       JList l = p.getList();
/*  629 */       if (e.getSource() != l) {
/*      */         return;
/*      */       }
/*  632 */       Point o = e.getPoint();
/*  633 */       Rectangle a = new Rectangle();
/*  634 */       l.computeVisibleRect(a);
/*  635 */       if (a.contains(o)) {
/*  636 */         p.updateListBoxSelectionForEvent(e, false);
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     public void mouseDragged(MouseEvent e) {
/*  642 */       MCComboPopup p = AbsMCComboBox.this._popup;
/*  643 */       if (p == null || !p.isVisible()) {
/*      */         return;
/*      */       }
/*      */       
/*  647 */       JList l = p.getList();
/*  648 */       if (e.getSource() == l) {
/*      */         return;
/*      */       }
/*  651 */       MouseEvent m = p.convertMouseEvent(e);
/*  652 */       Rectangle a = new Rectangle();
/*  653 */       l.computeVisibleRect(a);
/*  654 */       if ((m.getPoint()).y >= a.y && (m.getPoint()).y <= a.y + a.height - 1) {
/*  655 */         p._has_entered = true;
/*  656 */         if (p._is_auto_scrolling) {
/*  657 */           p.stopAutoScrolling();
/*      */         }
/*  659 */         Point o = m.getPoint();
/*  660 */         if (a.contains(o)) {
/*  661 */           p.updateListBoxSelectionForEvent(m, false);
/*      */         
/*      */         }
/*      */       }
/*  665 */       else if (p._has_entered) {
/*  666 */         int directionToScroll = ((m.getPoint()).y < a.y) ? 0 : 
/*  667 */           1;
/*  668 */         if (p._is_auto_scrolling && p._scroll_direction != directionToScroll) {
/*  669 */           p.stopAutoScrolling();
/*  670 */           p.startAutoScrolling(directionToScroll);
/*      */         }
/*  672 */         else if (!p._is_auto_scrolling) {
/*  673 */           p.startAutoScrolling(directionToScroll);
/*      */         
/*      */         }
/*      */       
/*      */       }
/*  678 */       else if ((e.getPoint()).y < 0) {
/*  679 */         p._has_entered = true;
/*  680 */         p.startAutoScrolling(0);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initResource() {
/*  695 */     setResourceInfo((MCRootPanel)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setResourceInfo(MCRootPanel panel) {
/*  706 */     setResourceFont(panel);
/*  707 */     setResourceMessageName(panel);
/*  708 */     setResourceLabelName(panel);
/*  709 */     setResourceBounds(panel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getFontKey() {
/*  720 */     return MCConst.createKey(new String[] { getType(), "font" });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setResourceFont(MCRootPanel panel) {
/*  731 */     Font f = MCBeansProxy.PROXY.getBeansFont(getFontKey(), panel);
/*  732 */     if (f != null) {
/*  733 */       setFont(f);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setResourceMessageName(MCRootPanel panel) {
/*  745 */     String n = MCBeansProxy.PROXY.getResourceMessageName((MCResourceBeans)this, panel);
/*  746 */     if (n != null) {
/*  747 */       this._message_name_resource = n;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setResourceLabelName(MCRootPanel panel) {
/*  759 */     String n = MCBeansProxy.PROXY.getResourceLabelName((MCResourceBeans)this, panel);
/*  760 */     if (n != null) {
/*  761 */       this._label_name = n;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setResourceBounds(MCRootPanel panel) {
/*  773 */     if (panel != null) {
/*  774 */       MCBeansProxy.PROXY.setBounds((MCResourceBeans)this);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected AbsMCComboBox(String name) {
/*  784 */     this._default_bounds = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1154 */     this._is_handle_processing = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2862 */     this._read_only_flg = false; setName(name, false); init();
/*      */   }
/*      */   @Deprecated public void _cacheDefaultBounds(Rectangle bounds) { this._default_bounds = bounds; }
/* 2865 */   @Deprecated public void _setDefaultBounds() { if (this._default_bounds != null) setBounds(this._default_bounds);  } public Rectangle _getDefaultBounds() { return this._default_bounds; } public void _setDefaultBounds(Rectangle r) { this._default_bounds = r; } protected void initKeyAssign() { MCKeyActionManager.init((MCResourceBeans)this, getInputMap(1), getActionMap()); JComponent c = getComboField().getComponent(); MCKeyActionManager.init((MCResourceBeans)this, c.getInputMap(), c.getActionMap()); } protected MCBeansDelegate getDelegate() { return (this._delegate != null) ? this._delegate : (this._delegate = new MCBeansDelegate()); } protected MCComboField getComboField() { return (this._field != null) ? this._field : (this._field = createComboField()); } protected MCComboButton getComboButton() { return (this._button != null) ? this._button : (this._button = new MCComboButton()); } protected MCComboListModel<T> getModel() { return (this._model != null) ? this._model : (this._model = createModel()); } protected MCComboListModel<T> createModel() { return new MCComboListModel<>(this); } protected MCComboPopup<T> getComboPopup() { return (this._popup != null) ? this._popup : (this._popup = new MCComboPopup<>(this)); } protected MCComboPopup<T> getActiveComboPopup() { MCComboPopup<T> p = getComboPopup(); return p.isVisible() ? p : null; } protected void showComboPopup() { getComboPopup().showPopup(); } protected void hideComboPopup() { getComboPopup().hidePopup(); } public boolean isPopupVisible() { return (getActiveComboPopup() != null); } public void setPopupVisible(boolean visible) { if (isPopupVisible() != visible) if (visible) { showComboPopup(); } else { hideComboPopup(); }   } void cancelComboPopup() { MCComboPopup<?> p = getComboPopup(); String k = "JPopupMenu.firePopupMenuCanceled"; Object o = p.getClientProperty(k); try { p.putClientProperty(k, Boolean.valueOf(true)); setPopupVisible(false); } finally { p.putClientProperty(k, o); }  } public void setMaximumRowCount(int count) { this._maximum_row_count = count; } public int getMaximumRowCount() { return this._maximum_row_count; } public void setMessageName(String name) { this._message_name = MCBeansProxy.PROXY.adjustMessageName(name); } @Deprecated public String _getMessageName() { return this._message_name; } public String getMessageByLocale() { String m = this._message_name; if (m == null) m = this._message_name_resource;  return MCBeansProxy.PROXY.getNameForMessage((MCBeans)this, m); } public String getLabelByLocale() { MCLabel l = getLabel(); return (l != null) ? l.getLabelByLocale() : null; } public MCRootPanel getRootPanel() { return (this._init_panel != null) ? this._init_panel : getNearestRootPanel(); } public MCRootPanel getBaseRootPanel() { MCRootPanel p = getNearestRootPanel(); return (p != null) ? p.getBaseRootPanel() : null; } public MCRootPanel getNearestRootPanel() { return (this._panel != null) ? this._panel : (this._panel = MCBeansUtil.getNearestRootPanel(this)); } public void localeChanged() { updateResource(); } public void added() { this._panel = MCBeansUtil.getNearestRootPanel(this); if (MCMode.isNull(getMode())) setMode(MCMode.ENABLE);  } public void removed() { this._panel = MCBeansUtil.getNearestRootPanel(this); } public boolean equalsIgnoreCase(Component compo) { return !(compo != this && compo != getComboField()); } public void initialized() { if (this._default_ratio_bounds == null) this._default_ratio_bounds = getBounds();  if (this._default_font == null) this._default_font = getFont();  this._init_panel = MCBeansUtil.getRootPanel(this); setRequiredFlg(MCBeansProxy.PROXY.getRequiredFlg(this, this)); MCRootPanel bp = getBaseRootPanel(); if (bp != null) { String itemid = MCBeansProxy.PROXY.createGUIKey(this); setReadOnlyFlg(MCACLManager.isReadOnly(bp.getModuleID(), bp.getScreenID(), itemid)); }  } public void addAliasName(String alias, MCRootPanel panel) { getDelegate().addAliasName(alias, panel); } public void setAliasName(String alias, MCRootPanel panel) { getDelegate().setAliasName(alias, panel); } public void removeAliasName(MCRootPanel panel) { getDelegate().removeAliasName(panel); } public void removeAliasNames() { getDelegate().removeAliasNames(); } public String getAliasName(MCRootPanel panel) { return getDelegate().getAliasName(panel); } public String[] getAliasNames() { return getDelegate().getAliasNames(); } public void updateBounds(int ratio) { MCBeansProxy.PROXY.updateBounds(this, ratio, this._default_ratio_bounds); getComboButton().adjustIconSize(ratio); } public void updateFontSize(int ratio) { MCBeansProxy.PROXY.updateFontSize(this, ratio, this._default_font); } public Dimension getDefaultSize() { Rectangle a = this._default_ratio_bounds; int w = (a != null) ? a.width : getWidth(); int h = (a != null) ? a.height : getHeight(); return new Dimension(w, h); } public Rectangle getDefaultBounds() { Rectangle a = this._default_ratio_bounds; return (a != null) ? a : bounds(); } public void setDefaultRatioSize(Rectangle r) { this._default_ratio_bounds = r; } @Deprecated public void handle(Throwable t) { if (!this._is_handle_processing) { this._is_handle_processing = true; try { setViewValue(getEventInfo().getOldValue()); MCBeansUtil.handle(this, t); } finally { this._is_handle_processing = false; }  }  setRowToViews(); } public final MCTabOrderBeans getNextBeans() { return getDelegate().getNextBeans(); } public final void setNextBeans(MCTabOrderBeans compo) { getDelegate().setNextBeans(this, compo, 0); } public final void insertNextBeans(MCTabOrderBeans compo) { getDelegate().insertNextBeans(this, compo, 0); } public final void insertPreviousBeans(MCTabOrderBeans compo) { getDelegate().insertPreviousBeans(this, compo, 0); } public final MCTabOrderBeans getPreviousBeans() { return getDelegate().getPreviousBeans(); } @Deprecated public final void setPreviousBeans(MCTabOrderBeans compo) { getDelegate().setPreviousBeans(this, compo); } public final void setNextBeans(MCTabOrderBeans compo, int updateType) { getDelegate().setNextBeans(this, compo, updateType); } public final void insertNextBeans(MCTabOrderBeans compo, int updateType) { getDelegate().insertNextBeans(this, compo, updateType); } public final void insertPreviousBeans(MCTabOrderBeans compo, int updateType) { getDelegate().insertPreviousBeans(this, compo, updateType); } @Deprecated public void setTabOrderEnabled(boolean enabled) { getDelegate().setTabOrderEnabled(enabled); } public boolean isTabOrderEnabled() { return getDelegate().isTabOrderEnabled(); } @Deprecated public JComponent getTargetComponent() { return getComboField().getComponent(); } public void updateResource() { updateResource(getBaseRootPanel()); } public void updateResource(MCRootPanel panel) { if (panel == null) return;  if (!panel.isPartsFlag()) { MCKeyActionManager.initScreen((MCResourceBeans)this, getInputMap(1), getActionMap()); JComponent c = getComboField().getComponent(); MCKeyActionManager.initScreen((MCResourceBeans)this, c.getInputMap(), c.getActionMap()); }  setResourceInfo(panel); MCLabel l = getLabel(); if (l != null) l.updateResource(panel);  } public void setMode(MCMode mode) { if (MCMode.isNull(mode)) return;  MCRootPanel bp = getBaseRootPanel(); MCMode m = mode; if (getModeInfo(m).getStatus() == 1) if (getReadOnlyFlg()) { m = MCMode.READ_ONLY; } else if (getRequiredFlg()) { m = MCMode.REQUIRED; }   MCBeansUtil.log(bp, (MCBeans)this, Core_Msg_FW_A.FCBAC0013, new Object[] { m.getName() }); if (this._mode != mode) this._mode = mode;  setVisible((getModeInfo(m).getStatus() != 3)); getComboField().modeChanged(m); getComboButton().modeChanged(getModeInfo(m)); MCBeansUtil.log(bp, (MCBeans)this, Core_Msg_FW_A.FCBAC0014, new Object[] { m.getName() }); MCLabel l = getLabel(); if (l != null) l.setMode(m);  } public MCMode getMode() { MCMode m = this._mode; MCModeInfo i = getModeInfo(m); if (i != null && i.getStatus() == 1) if (getReadOnlyFlg()) { m = MCMode.READ_ONLY; } else if (getRequiredFlg()) { m = MCMode.REQUIRED; }   return m; } public MCModeInfo getModeInfo() { return getModeInfo(getMode()); } public MCModeInfo getModeInfo(MCMode mode) { return getDelegate().getModeInfo(this, mode); } public void putMode(MCRootPanel panel, String status, MCMode mode) { getDelegate().putMode(panel, status, mode); } public void setMode(MCRootPanel panel, String status) { setMode(getMode(panel, status)); } public MCMode getMode(MCRootPanel panel, String status) { return getDelegate().getMode(panel, status); } public String[] getStatuses(MCRootPanel panel) { return getDelegate().getStatuses(panel); } public boolean doAction() { return false; } public MCEventInfo getEventInfo() { if (this._event_info != null) return this._event_info;  this._event_info = new MCEventInfo(); MCEventProxy.PROXY.setComponent(this._event_info, (MCEventBeans)this); return this._event_info; } public void addAllListener(MCEventListener listener) { addLCListener((MCLCListener)listener); addNCListener((MCNCListener)listener); addNEListener((MCNEListener)listener); addNXListener((MCNXListener)listener); addVCListener((MCVCListener)listener); addDCListener((MCDCListener)listener); } public void setAllListener(MCEventListener listener) { setLCListener((MCLCListener)listener); setNCListener((MCNCListener)listener); setNEListener((MCNEListener)listener); setNXListener((MCNXListener)listener); setVCListener((MCVCListener)listener); setDCListener((MCDCListener)listener); } public void setListConfig(MCListConfig config) { this._list_config = config; } public MCListConfig getListConfig() { return (this._list_config != null) ? this._list_config : (this._list_config = new MCListConfig(this)); } public void setComboListConfig(MCComboListConfig config) { this._combo_list_config = config; } public MCComboListConfig getComboListConfig() { return (this._combo_list_config != null) ? this._combo_list_config : (this._combo_list_config = new MCComboListConfig()); } public void setListEventWithNull(boolean doIt) { this._do_list_event_null = doIt; } public boolean doListEventWithNull() { return this._do_list_event_null; } @Deprecated protected MCList<?> doListEventEx() { MCListListener n = getListListener(); MCList<?> l = null; if (n != null) { MCRow r = null; MCListPutter p = getListConfig().getPutter(); if (p != null) r = p.getBindRow(-1);  if (r == null) r = MCRow.create();  l = n.getList((MCEventBeans)this, r, getEventInfo()); }  if (l != null) l = l.shallowClone();  return l; } public MCList<?> doListEvent() { try { return doListEventEx(); } catch (MCException e) { handle((Throwable)e); return null; }  } public MCList<?> doListEvent(String type) { MCListConfig c = getListConfig(); String t = c.getOpeType(); try { c.setOpeType(type); return doListEvent(); } finally { c.setOpeType(t); }  } public String getBaseRowColumnName() { MCConstRow c = this._data_row; return (c != null) ? c.getRootRowColumnPath(this._data_row_column_name) : this._data_row_column_name; } public String[] getListNames() { MCListPutter p = getListConfig().getPutter(); if (p != null) return p.getColumns();  MCLinkedBeans[] a = getLinkBeans(); int cnt = a.length; String[] n = new String[cnt + 1]; n[0] = getRowColumnName(); for (int i = 0; i < cnt; i++) n[i + 1] = a[i].getRowColumnName();  return n; } public void setValueChecker(MCValueChecker checker) { this._value_checker = checker; } public MCValueChecker getValueChecker() { return (this._value_checker != null) ? this._value_checker : (this._value_checker = new MCValueChecker()); } public MCMessageList setValues(int index, MCRow row) { return setValues(row); } public MCMessageList setValues(MCRow row) { MCMessageList l = new MCMessageList(); MCLinkedBeans[] ca = getLinkBeans(); String[] na = getListNames(); Comparable<?> v = null; if (row != null) { String n = na[0]; if (row.contains(n)) v = row.getValue(n);  }  boolean d = isValueChanged(v, (Comparable<?>)getRowValue()); if (!setValueNoListCheck(v, l, false)) return l;  MCLinkBeans[] ignore = getIgnoreListBeans(); for (int i = 0; i < ca.length; i++) { Comparable<?> lv = null; if (row != null) { String n = na[i + 1]; if (row.contains(n)) lv = row.getValue(n);  }  if (MCCollectionUtil.contains(ca[i], (Object[])ignore)) { if (!((MCLinkBeans)ca[i]).setValueIgnoreList(-1, lv, l)) return l;  } else { ca[i].setViewValue(lv, l); }  if (!l.isEmpty()) return l;  }  if (d) { doLC(); MCComboListModel<T> m = getModel(); m.setOldListIndex(m.getNewListIndex()); MCEventInfo e = getEventInfo(); MCEventProxy.PROXY.setListIndex(e, m.getSelectedIndex()); MCEventProxy.PROXY.setValue(e, (Comparable<?>)getRowValue()); }  return l; } public boolean setValueIgnoreList(int index, Comparable<?> value, MCMessageList list) { if (list == null) list = new MCMessageList();  return setValueNoListCheck(value, list, true); } private boolean setValueNoListCheck(Comparable<?> value, MCMessageList list, boolean doLC) { boolean result = true; boolean changed = false; Comparable<?> v = _adjustValue(value); if (changed = isValueChanged(v)) { if (result = checkInputValue(value, list)) { MCEventInfo e = getEventInfo(); MCEventProxy.PROXY.setValue(e, (Comparable<?>)getRowValue(), value); MCComboListModel<T> m = getModel(); int n = -1; String ope = getListConfig().getOpeType(); if ("list".equals(ope)) { n = m.getSelectedIndex(); } else if ("input".equals(ope)) { n = m.getRowIndex((T)v); }  MCEventProxy.PROXY.setListIndex(e, m.getOldListIndex(), n); MCEventProxy.PROXY.setNewListRow(e, m.getRow(n)); if (result = doVC()) { _setValueFromSetValueNoListCheck((T)v); doNC(); }  }  } else { setRowToViews(); }  if (!result) { doCheckValueError(); } else if (doLC && changed) { doLC(); }  return result; } void _setValueFromSetValueNoListCheck(T value) { setText(value); setViewToRow(); } protected Comparable<?> _adjustValue(Comparable<?> value) { return value; } public MCDataType getDataType() { return this._data_row_data_type; } public void haveLinkValuesNullWhenDupliKeyTyped(boolean clear) { this._have_link_values_null_when_dupli_key_typed = clear; } public boolean haveLinkValuesNullWhenDupliKeyTyped() { return this._have_link_values_null_when_dupli_key_typed; } public MCMessageList setViewValue(int index, Comparable<?> value) { return setViewValue(value); } public void setViewValue(int index, Comparable<?> value, MCMessageList list) { setViewValue(value, list); } public MCMessageList setViewValue(Comparable<?> value) { MCMessageList l = new MCMessageList(); setViewValue(value, l); return l; } public T getViewValue(int index) { return getValue(); } private void setReadOnlyFlg(boolean flg) { this._read_only_flg = flg;
/*      */     
/* 2867 */     setMode(this._mode); }
/*      */   public String getRowColumnName() { return this._data_row_column_name; }
/*      */   public void valueChanged(MCRowEvent event) { setRowToView(); MCEventProxy.PROXY.setValue(getEventInfo(), event.getOldValue(), event.getNewValue()); }
/*      */   public void setRow(MCConstRow row, MCMeta meta) { MCBeansProxy.PROXY.checkRow(this, (MCRow)row, meta); setRow(row, meta.name()); setMeta(meta); }
/* 2871 */   protected void setRow(MCConstRow row, String name) { if (this._data_row != null) this._data_row.removeRowListener((MCRowListener)this);  this._data_row = row; this._data_row_column_name = name; this._data_row_data_type = getBaseRow().getDataType(getBaseRowColumnName()); row.removeRowListener(name, (MCRowListener)this); row.addRowListener(name, new MCRowListener[] { (MCRowListener)this }); setRowToView(); } protected void setMeta(MCMeta meta) { this._meta = meta; } public MCConstRow getRow() { return this._data_row; } public MCConstRow getBaseRow() { MCConstRow c = this._data_row; return (c != null) ? (MCConstRow)c.getRootRow() : null; } public MCMeta getMeta() { return this._meta; } public T getViewValue() { return getValue(); } public void clear() { MCBeansProxy.PROXY.clear(this, null); } public boolean checkValue(Comparable<?> value, MCMessageList list) { MCMessageList l = checkValue(value); if (l.size() == 0) return true;  if (list != null) list.addAll((Collection)l);  return false; } public void setRowToViews() { setRowToView(); MCLinkedBeans[] a = getLinkBeans(); byte b; int i; MCLinkedBeans[] arrayOfMCLinkedBeans1; for (i = (arrayOfMCLinkedBeans1 = a).length, b = 0; b < i; ) { MCLinkedBeans c = arrayOfMCLinkedBeans1[b]; if (c instanceof MCRowBeans) ((MCRowBeans)c).setRowToViews();  b++; }  } public boolean checkInputValue(Comparable<?> value) { return checkInputValue(value, null); } public void setIgnoreStatus(boolean ignore) { this._ignore_status = ignore; } public boolean isIgnoreStatus() { return this._ignore_status; } public void addVCListener(MCVCListener listener) { this._event_list.add(listener); } public void setVCListener(MCVCListener listener) { this._event_list.set(listener); } public void removeVCListener(MCVCListener listener) { this._event_list.remove(listener); } public MCVCListener[] getVCListeners() { return this._event_list.vc(); } public boolean doVC() { return MCBeansUtil.vc(this); } public boolean isValueChanged() { return isValueChanged((Comparable<?>)getValue()); } protected boolean isValueChanged(Comparable<?> value) { return isValueChanged(value, (Comparable<?>)getRowValue()); } protected boolean isValueChanged(Comparable<?> view, Comparable<?> row) { if (isInputMethodEditing()) return true;  return getRootPanel().isValueChanged(this, view, row); } public boolean canChange() { return (canChange(getValue(), (MCMessageList)null).size() == 0); } protected MCMessageList canChange(T value, MCMessageList list) { if (list == null) list = new MCMessageList();  int cnt = list.size(); if (isInputMethodEditing()) { list.add(MCBeansUtil.createCauseMsg(this, Core_Msg_FW_A.FCBAC0033, new Object[0])); return list; }  MCEventProxy.PROXY.setValue(getEventInfo(), (Comparable<?>)getRowValue(), (Comparable<?>)value); checkValue((Comparable<?>)value, list); if (list.size() == cnt) { MCEventInfo i = getEventInfo(); int n = -1; String ope = getListConfig().getOpeType(); if ("list".equals(ope)) { n = getModel().getSelectedIndex(); } else if ("input".equals(ope)) { n = getModel().getRowIndex(value); }  MCEventProxy.PROXY.setListIndex(i, getModel().getOldListIndex(), n); MCEventProxy.PROXY.setNewListRow(i, getModel().getRow(n)); if (!doVC()) list.add(MCBeansUtil.createCauseMsg(this, Core_Msg_FW_A.FCBAC0032, new Object[] { value }));  }  if (list.size() != cnt) doCheckValueError();  return list; } public void addNCListener(MCNCListener listener) { this._event_list.add(listener); } public void setNCListener(MCNCListener listener) { this._event_list.set(listener); } public void removeNCListener(MCNCListener listener) { this._event_list.remove(listener); } public MCNCListener[] getNCListeners() { return this._event_list.nc(); } public void doNC() { MCBeansUtil.nc(this); } public void commitValue() { commitValue(getViewValue(), true); } protected void commitValue(T value, boolean msg) { setViewToRow(value); String t = getListConfig().getOpeType(); T v = getValue(); if ("input".equals(t)) { getModel().setSelectedItem(v); } else if ("list".equals(t)) { if (v == null || "".equals(v)) { getModel().setSelectedItem(v); } else { Comparable<?> m = null; int oi = getModel().getSelectedIndex(); if (oi > -1 && oi < getList().size()) { m = getModel().getRow(oi).getValue(getKeyColumnName()); if (!eqData(v, m)) getModel().setSelectedItem(v);  } else { getModel().setSelectedItem(v); }  }  }  doNC(); MCEventInfo e = getEventInfo(); String n = getKeyColumnName(); if (MCBeansProxy.PROXY.haveLinkValuesNull(e, this, (Comparable<?>)value, getList(), n)) { MCRow o = getModel().getSelectedRow().clone(); o.clear(); o.setValue(n, (Comparable)v); execLink(o, msg); } else { execLink(getModel().getSelectedRow(), msg); }  MCEventProxy.PROXY.setValue(e, (Comparable<?>)getRowValue()); int i = getModel().getSelectedIndex(); MCEventProxy.PROXY.setListIndex(e, i); getModel().setOldListIndex(i); } boolean eqData(T v1, Comparable<?> v2) { return v1.equals(v2); } protected void execLink(MCRow row, boolean msg) { MCLinkedBeans[] a = getLinkBeans(); if (a.length > 0) { if (row == null && MCListType.FREE.equals(getListType())) { row = MCRow.create(); MCBeansProxy.PROXY.addColumn(row, getKeyColumnName(), getDataType(), (Comparable<?>)getViewValue()); }  MCEventInfo mCEventInfo = getEventInfo(); Comparable<?> o = mCEventInfo.getOldValue(); try { MCListPutter p = getListConfig().getPutter(); Comparable<?> ov = mCEventInfo.getOldValue(); Comparable<?> nv = mCEventInfo.getNewValue(); MCMessageList l = (p != null) ? p.setValues(-1, row) : execListLink(row); MCEventProxy.PROXY.setValue(mCEventInfo, ov, nv); if (l.size() > 0) { if (msg) { for (MCMessage mCMessage : l) { MCMessageLevel lv = mCMessage.getLevel(); if (lv != null) switch (lv) { case INFO: case WARN: case ERROR: case FATAL: continue; }   l.remove(mCMessage); }  if (l.size() != 0) { MCLog.write(l); getBaseRootPanel().message(l); }  }  safetySetViewValue(o); } else { doLC(); }  } catch (RuntimeException ex) { safetySetViewValue(o); throw ex; }  } else { doLC(); }  MCComboListModel<T> m = getModel(); m.setOldListIndex(m.getNewListIndex()); MCEventInfo e = getEventInfo(); MCEventProxy.PROXY.setListIndex(e, m.getSelectedIndex()); MCEventProxy.PROXY.setValue(e, (Comparable<?>)getRowValue()); } private void safetySetViewValue(Comparable<?> o) { if (!this._exec_link_error_processing) { this._exec_link_error_processing = true; try { setViewValue(o); } finally { this._exec_link_error_processing = false; }  }  } protected MCMessageList execListLink(MCRow row) { MCLinkedBeans[] ca = getLinkBeans(); String[] na = getListNames(); MCMessageList l = new MCMessageList(); for (int i = 0; i < ca.length; i++) { String n = na[i + 1]; Comparable<?> v = null; if (row != null && row.contains(n)) v = row.getValue(n);  MCMessageList m = ca[i].setViewValue(v); if (m.size() != 0) l.addAll((Collection)m);  }  return l; } protected void setViewToRow(T value) { MCConstRow c = getBaseRow(); String n = getBaseRowColumnName(); if (!MCBeansUtil.isNull(c, n)) { c.setValue(n, (Comparable)value); MCBeansProxy.PROXY.setGUIModified(this, c); }  } public void setViewToRow() { setViewToRow(getViewValue()); } public void addNEListener(MCNEListener listener) { this._event_list.add(listener); } public void setNEListener(MCNEListener listener) { this._event_list.set(listener); } public void removeNEListener(MCNEListener listener) { this._event_list.remove(listener); } public MCNEListener[] getNEListeners() { return this._event_list.ne(); } public void doNE() { MCBeansUtil.ne(this); } public void focusGained() { doNE(); } public void addNXListener(MCNXListener listener) { this._event_list.add(listener); } public void setNXListener(MCNXListener listener) { this._event_list.set(listener); } public void removeNXListener(MCNXListener listener) { this._event_list.remove(listener); } public MCNXListener[] getNXListeners() { return this._event_list.nx(); } public void doNX() { if (isPopupVisible()) setPopupVisible(false);  MCBeansUtil.nx(this); getListConfig().setOpeType("input"); } public void focusLost() { doNX(); } public void addLCListener(MCLCListener listener) { this._event_list.add(listener); } public void setLCListener(MCLCListener listener) { this._event_list.set(listener); } public void removeLCListener(MCLCListener listener) { this._event_list.remove(listener); } public MCLCListener[] getLCListeners() { return this._event_list.lc(); } public void doLC() { MCBeansUtil.lc((MCLCBeans)this); getListConfig().setOpeType("input"); } public void addDCListener(MCDCListener listener) { this._event_list.add(listener); } public void setDCListener(MCDCListener listener) { this._event_list.set(listener); } public void removeDCListener(MCDCListener listener) { this._event_list.remove(listener); } public MCDCListener[] getDCListeners() { return this._event_list.dc(); } public void doDC() { MCBeansUtil.dc(this); } public void setLabel(MCLabel label) { if (this._label != null) this._label.setLabelFor(null);  this._label = label; if (label != null) { label.setLabelFor(this); if (this._label_name != null) label.setText(this._label_name);  }  } public MCLabel getLabel() { return this._label; } public void setListVisibleColumn(String... names) { this._visible_column_names = names; } public String[] getListVisibleColumn() { return this._visible_column_names; } public void setFont(Font font) { super.setFont(font); MCComboField f = getComboField(); if (f != null) f.getComponent().setFont(font);  } public Font getFont() { MCComboField f = getComboField(); return (f != null) ? f.getComponent().getFont() : super.getFont(); } public MCList<?> createList() { MCList<?> l = doListEvent(); getModel().setList(l); return l; } MCList createListEx() { MCList<?> l = doListEventEx(); getModel().setList(l); return l; } void createListEx(Comparable<?> value) { if (!doListEventWithNull() && (value == null || value.equals(""))) return;  if ("input".equals(getListConfig().getOpeType())) { createListEx(); return; }  if (getList() == null) { createListEx(); return; }  getModel().setList(getList()); } public MCList<?> getList() { return getModel().getList(); } public MCRow getListRow(T value) { MCList<?> l = getList(); if (l == null) return null;  for (MCRow o : l) { Comparable<?> v = o.getValue(getListNames()[0]); if (v == null && value == null) return o;  if (value != null && eqData(value, v)) return o;  }  return null; } protected MCRow getSelectedListRow() { return getModel().getSelectedRow(); } protected String getKeyColumnName() { return getListNames()[0]; } public boolean isMCFocusOwner() { return equalsIgnoreCase(MCBeansUtil.getFocusOwner(this)); } public MCMessageList setValue(T value) { return setValue(value, (MCMessageList)null); } public Border getDefaultBorder() { return getComboField().getDefaultFieldBorder(); } public void setBounds(int x, int y, int width, int height) { boolean change = !(x == getX() && y == getY() && width == getWidth() && height == getHeight()); super.setBounds(x, y, width, height); if (change) setButtonBounds(x, y, width, height);  } private void setButtonBounds(int x, int y, int width, int height) { MCComboButton o = getComboButton(); int m = Math.min(width, height); Insets i = getComboField().getComponent().getBorder().getBorderInsets(this); o.setLocation(i.left + width - m, i.top); m -= Math.max(i.left + i.right, i.top + i.bottom); o.setSize(m, 0); o.setPreferredSize(new Dimension(m, 0)); } public boolean isRequestFocusEnabled() { MCComboField f = getComboField(); return (f != null) ? f.getComponent().isRequestFocusEnabled() : super.isRequestFocusEnabled(); } @Deprecated public void grabFocus() { super.grabFocus(); } public void mcRequestFocus() { MCBeansUtil.focus(this); } public void setEnabled(boolean enabled) { super.setEnabled(enabled); MCComboField f = getComboField(); if (f != null) f.getComponent().setEnabled(enabled);  } public boolean isEnabled() { MCComboField f = getComboField(); return (f != null) ? f.getComponent().isEnabled() : super.isEnabled(); } public void selectNextPossibleValue() { if (!isPopupVisible()) return;  int i = getComboPopup().getSelectedIndex(); selectPossibleValueImpl(++i); } public void selectPreviousPossibleValue() { if (!isPopupVisible()) return;  int i = getComboPopup().getSelectedIndex(); selectPossibleValueImpl(--i); } public void selectPageUpPossibleValue() { if (!isPopupVisible()) return;  int c = getModel().getSize(); if (c > 0) { int i = getComboPopup().getSelectedIndex() - getMaximumRowCount(); if (i < 0) i = 0;  selectPossibleValueImpl(i); }  } public void selectPageDownPossibleValue() { if (!isPopupVisible()) return;  int c = getModel().getSize(); if (c > 0) { int i = getComboPopup().getSelectedIndex() + getMaximumRowCount(); if (i >= c) i = c - 1;  selectPossibleValueImpl(i); }  } private void selectPossibleValueImpl(int index) { if (index >= 0 && index < getModel().getSize()) { setSelectedIndex(index); if (isPopupVisible()) getComboPopup().setListSelectedIndex(index);  repaint(); }  } protected void setSelectedIndex(int index) { if (index == -1) { setText((T)null); getModel().setSelectedIndex(-1); return; }  if (index < getModel().getSize()) { MCRow o = getList().get(index); Comparable<?> v = o.getValue(getKeyColumnName()); setText((T)v); getModel().setSelectedIndex(index); } else { getModel().setSelectedIndex(-1); }  } protected void setSelectedItem(T value) { getModel().setSelectedItem(value); } protected Color getListForeground(MCRow row, boolean selected) { return getComboListConfig().getRowForeground(this, row, selected); } protected Color getListBackground(MCRow row, boolean selected) { return getComboListConfig().getRowBackground(this, row, selected); } Color getDefaultListForeground(MCRow row, boolean selected) { if (selected) { if (this._list_selected_foreground_resource != null) return this._list_selected_foreground_resource;  String str = MCConst.createKey(new String[] { getType(), "list", "selfg" }); if (MCConst.beans.containsKey(str)) this._list_selected_foreground_resource = MCConst.beans.getColor(str);  if (this._list_selected_foreground_resource == null) this._list_selected_foreground_resource = UIManager.getColor("ComboBox.selectionForeground");  return this._list_selected_foreground_resource; }  if (this._list_foreground_resource != null) return this._list_foreground_resource;  String k = MCConst.createKey(new String[] { getType(), "list", "fg" }); if (MCConst.beans.containsKey(k)) this._list_foreground_resource = MCConst.beans.getColor(k);  if (this._list_foreground_resource == null) this._list_foreground_resource = UIManager.getColor("ComboBox.foreground");  return this._list_foreground_resource; } Color getDefaultListBackground(MCRow row, boolean selected) { if (selected) { if (this._list_selected_background_resource != null) return this._list_selected_background_resource;  String str = MCConst.createKey(new String[] { getType(), "list", "selbg" }); if (MCConst.beans.containsKey(str)) this._list_selected_background_resource = MCConst.beans.getColor(str);  if (this._list_selected_background_resource == null) this._list_selected_background_resource = UIManager.getColor("ComboBox.selectionBackground");  return this._list_selected_background_resource; }  if (this._list_background_resource != null) return this._list_background_resource;  String k = MCConst.createKey(new String[] { getType(), "list", "bg" }); if (MCConst.beans.containsKey(k)) this._list_background_resource = MCConst.beans.getColor(k);  if (this._list_background_resource == null) this._list_background_resource = UIManager.getColor("ComboBox.background");  return this._list_background_resource; } public void setRequiredFlg(boolean required) { this._required_flg = required; setMode(this._mode); } public boolean getRequiredFlg() { return this._required_flg; } private boolean getReadOnlyFlg() { return this._read_only_flg; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MouseListener getFieldMouseListener() {
/* 2882 */     return (this._field_mouse_listener != null) ? this._field_mouse_listener : (
/* 2883 */       this._field_mouse_listener = createFieldMouseListener());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MouseListener createFieldMouseListener() {
/* 2894 */     return new MCComboFieldMouseListener();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected class MCComboFieldMouseListener
/*      */     extends MouseAdapter
/*      */   {
/*      */     public void mouseClicked(MouseEvent e) {
/* 2908 */       if (!SwingUtilities.isLeftMouseButton(e)) {
/*      */         return;
/*      */       }
/*      */       
/* 2912 */       JComponent c = (JComponent)e.getSource();
/* 2913 */       if (!c.hasFocus()) {
/*      */         return;
/*      */       }
/*      */       
/* 2917 */       Component p = c.getParent();
/* 2918 */       if (p instanceof AbsMCComboBox) {
/* 2919 */         c = (AbsMCComboBox)p;
/*      */       }
/*      */       
/* 2922 */       if (e.getClickCount() == 2 && 
/* 2923 */         c instanceof MCDCBeans) {
/* 2924 */         ((MCDCBeans)c).doDC();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected AncestorListener getFieldAncestorListener() {
/* 2938 */     return (this._field_ancestor_listener != null) ? this._field_ancestor_listener : (
/* 2939 */       this._field_ancestor_listener = createFieldAncestorListener());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected AncestorListener createFieldAncestorListener() {
/* 2950 */     return new MCComboFieldAncestorListener();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected class MCComboFieldAncestorListener
/*      */     implements AncestorListener
/*      */   {
/*      */     public void ancestorAdded(AncestorEvent event) {
/* 2964 */       AbsMCComboBox.this.hideComboPopup();
/*      */     }
/*      */ 
/*      */     
/*      */     public void ancestorRemoved(AncestorEvent event) {
/* 2969 */       AbsMCComboBox.this.hideComboPopup();
/*      */     }
/*      */ 
/*      */     
/*      */     public void ancestorMoved(AncestorEvent event) {
/* 2974 */       Object o = event.getSource();
/* 2975 */       if (o instanceof Component && 
/* 2976 */         AbsMCComboBox.this.equalsIgnoreCase((Component)o)) {
/*      */         return;
/*      */       }
/*      */       
/* 2980 */       AbsMCComboBox.this.hideComboPopup();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInputVerifier(InputVerifier verifier) {
/* 2990 */     getComboField().getComponent().setInputVerifier(verifier);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public InputVerifier getInputVerifier() {
/* 2996 */     return getComboField().getComponent().getInputVerifier();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setVerifyInputWhenFocusTarget(boolean verifyInputWhenFocusTarget) {
/* 3002 */     getComboField().getComponent()
/* 3003 */       .setVerifyInputWhenFocusTarget(verifyInputWhenFocusTarget);
/*      */   }
/*      */ 
/*      */   
/*      */   public Comparable<?> _adjustValueByFormat(Comparable<?> value) {
/* 3008 */     return value;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBorder(Border border) {
/* 3014 */     if (border == null) {
/*      */       return;
/*      */     }
/* 3017 */     getComboField().getComponent().setBorder(border);
/*      */   }
/*      */   
/*      */   Boolean getFirePopupMenuCanceledProperty() {
/* 3021 */     return Boolean.valueOf(Boolean.TRUE.equals(
/* 3022 */           getComboPopup().getClientProperty("JPopupMenu.firePopupMenuCanceled")));
/*      */   }
/*      */   
/*      */   void setFirePopupMenuCanceledProperty(Boolean property) {
/* 3026 */     getComboPopup().putClientProperty("JPopupMenu.firePopupMenuCanceled", property);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void _resetDefaultFont() {
/* 3038 */     this._default_font = getFont();
/*      */   }
/*      */   
/*      */   protected abstract MCComboField createComboField();
/*      */   
/*      */   public abstract T getValue();
/*      */   
/*      */   public abstract T getRowValue();
/*      */   
/*      */   protected abstract void doCheckValueError();
/*      */   
/*      */   public abstract boolean isInputMethodEditing();
/*      */   
/*      */   public abstract void setText(T paramT);
/*      */   
/*      */   public abstract MCMessageList setValue(T paramT, MCMessageList paramMCMessageList);
/*      */   
/*      */   public abstract boolean isEditable();
/*      */   
/*      */   protected abstract boolean doIncrementalSearch();
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\combobox\AbsMCComboBox.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */