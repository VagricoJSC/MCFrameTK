/*     */ package mcframe.clientCore.beans.combobox;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Font;
/*     */ import java.awt.Rectangle;
/*     */ import javax.swing.text.JTextComponent;
/*     */ import mcframe.clientCore.beans.AbsMCPackageProxy;
/*     */ import mcframe.clientCore.beans.MCBeans;
/*     */ import mcframe.clientCore.beans.MCModeBeans;
/*     */ import mcframe.clientCore.beans.MCResourceBeans;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.MCRowBeans;
/*     */ import mcframe.clientCore.beans.list.MCLinkBeans;
/*     */ import mcframe.clientCore.beans.popup.MCPopupBeans;
/*     */ import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.clientCore.event.MCEventInfo;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCCalendarDate;
/*     */ import mcframe.commonCore.lang.MCDataType;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ 
/*     */ final class MCBeansProxy
/*     */   extends AbsMCPackageProxy {
/*  28 */   static final MCBeansProxy PROXY = new MCBeansProxy();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addColumn(MCRow row, String name, MCDataType type, Comparable<?> value) {
/*  35 */     super.addColumn(row, name, type, value);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void clear(MCRowBeans compo, Comparable<?> value) {
/*  40 */     super.clear(compo, value);
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCTextPopupMenuItem createPopupMenuItem(MCPopupBeans compo, String key) {
/*  45 */     return super.createPopupMenuItem(compo, key);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getNameForMessage(MCBeans compo, String msg) {
/*  50 */     return super.getNameForMessage(compo, msg);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean getBeansBoolean(String key, MCRootPanel panel, boolean def) {
/*  55 */     return super.getBeansBoolean(key, panel, def);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Color getBeansColor(String key, MCRootPanel panel) {
/*  60 */     return super.getBeansColor(key, panel);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Font getBeansFont(String key, MCRootPanel panel) {
/*  65 */     return super.getBeansFont(key, panel);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getResourceLabelName(MCResourceBeans compo, MCRootPanel panel) {
/*  70 */     return super.getResourceLabelName(compo, panel);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getResourceMessageName(MCResourceBeans compo, MCRootPanel panel) {
/*  75 */     return super.getResourceMessageName(compo, panel);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getBeansString(String key, MCRootPanel panel) {
/*  80 */     return super.getBeansString(key, panel);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isEventEnabled() {
/*  85 */     return super.isEventEnabled();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isTextSelected(JTextComponent compo) {
/*  90 */     return super.isTextSelected(compo);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setBounds(MCResourceBeans compo) {
/*  95 */     super.setBounds(compo);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setCutCopyPasteMenuVisible(JTextComponent compo, MCTextPopupMenuItem cut, MCTextPopupMenuItem copy, MCTextPopupMenuItem paste) {
/* 101 */     super.setCutCopyPasteMenuVisible(compo, cut, copy, paste);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setEventEnabled(boolean enabled) {
/* 106 */     super.setEventEnabled(enabled);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setGUIModified(MCRowBeans compo, MCConstRow row) {
/* 111 */     super.setGUIModified(compo, row);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void updateBounds(Component compo, int ratio, Rectangle def) {
/* 116 */     super.updateBounds(compo, ratio, def);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void updateFontSize(Component compo, int ratio, Font def) {
/* 121 */     super.updateFontSize(compo, ratio, def);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void checkRow(MCRowBeans compo, MCRow row, MCMeta meta) {
/* 126 */     super.checkRow(compo, row, meta);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String trim(String value, String pattern) {
/* 131 */     return super.trim(value, pattern);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean getRequiredFlg(MCRowBeans compo, Container cont) {
/* 136 */     return super.getRequiredFlg(compo, cont);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String adjustMessageName(String name) {
/* 141 */     return super.adjustMessageName(name);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCCalendarDate<?> adjustValueByFormat(MCCalendarDate<?> value, String pattern) {
/* 147 */     return super.adjustValueByFormat(value, pattern);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean haveLinkValuesNull(MCEventInfo e, MCLinkBeans b, Comparable<?> v, MCList<?> list, String key) {
/* 153 */     return super.haveLinkValuesNull(e, b, v, list, key);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doCheckValueError(MCBeans compo) {
/* 158 */     super.doCheckValueError(compo);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String createGUIKey(MCModeBeans compo) {
/* 163 */     return super.createGUIKey(compo);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\combobox\MCBeansProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */