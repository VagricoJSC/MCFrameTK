/*     */ package mcframe.clientCore.beans.combobox;
/*     */ 
/*     */ import javax.swing.text.Document;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.list.MCListType;
/*     */ import mcframe.clientCore.beans.text.MCCalendarDocument;
/*     */ import mcframe.clientCore.beans.text.MCCalendarDocumentBeans;
/*     */ import mcframe.clientCore.beans.text.MCCalendarFormat;
/*     */ import mcframe.clientCore.beans.text.MCCalendarPattern;
/*     */ import mcframe.clientCore.beans.text.MCCalendarValidator;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCCalendarDate;
/*     */ import mcframe.commonCore.lang.MCDataType;
/*     */ import mcframe.commonCore.lang.MCDate;
/*     */ import mcframe.commonCore.lang.MCDateFieldType;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.lang.MCTimestamp;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCMessageList;
/*     */ import mcframe.commonCore.util.MCUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MCCalendarComboBox<T extends MCCalendarDate<?>>
/*     */   extends MCFieldComboBox<T>
/*     */   implements MCCalendarDocumentBeans<T>
/*     */ {
/*  42 */   private MCCalendarValidator _calendar_validator = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   private MCCalendarFormat<T> _format = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   private MCCalendarFormat<T> _list_format = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCCalendarComboBox(String name) {
/*  68 */     super(name);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initBeans() {
/*  73 */     super.initBeans();
/*     */     
/*  75 */     setFormatID("YMD");
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCCalendarComboField getComboField() {
/*  80 */     return (MCCalendarComboField)super.getComboField();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getType() {
/*  88 */     return "combo-date";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCalendarValidator(MCCalendarValidator validator) {
/*  99 */     this._calendar_validator = validator;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCCalendarValidator getCalendarValidator() {
/* 104 */     return (this._calendar_validator != null) ? this._calendar_validator : (
/* 105 */       this._calendar_validator = new MCCalendarValidator());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setCalendarFormat(MCCalendarFormat<T> format) {
/* 116 */     this._format = format;
/*     */     
/* 118 */     setFormatPattern(getCalendarFormat().getCalendarPattern());
/*     */   }
/*     */ 
/*     */   
/*     */   public MCCalendarFormat<T> getCalendarFormat() {
/* 123 */     return (this._format != null) ? this._format : (this._format = createCalendarFormat());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFormatID(String id) {
/* 145 */     setFormatPattern(MCCalendarPattern.create(id));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFormatPattern(MCCalendarPattern pattern) {
/* 157 */     getCalendarFormat().setCalendarPattern(pattern);
/*     */     
/* 159 */     setText(getRowValue());
/*     */     
/* 161 */     setListFormatPattern(pattern);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setListCalendarFormat(MCCalendarFormat<T> format) {
/* 172 */     this._list_format = format;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCCalendarFormat<T> getListCalendarFormat() {
/* 183 */     return (this._list_format != null) ? 
/* 184 */       this._list_format : (this._list_format = createListCalendarFormat());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setListFormatID(String id) {
/* 206 */     setListFormatPattern(MCCalendarPattern.create(id));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setListFormatPattern(MCCalendarPattern pattern) {
/* 218 */     getListCalendarFormat().setCalendarPattern(pattern);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getPattern() {
/* 223 */     MCCalendarFormat<T> f = getCalendarFormat();
/* 224 */     return isMCFocusOwner() ? f.getInputPattern() : f.getOutputPattern();
/*     */   }
/*     */ 
/*     */   
/*     */   public void focusGained() {
/* 229 */     super.focusGained();
/*     */     
/* 231 */     setText(getRowValue());
/* 232 */     focusGainedSelect();
/*     */   }
/*     */ 
/*     */   
/*     */   public void focusLost() {
/* 237 */     super.focusLost();
/*     */     
/* 239 */     setText(getRowValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public T doParse(String value) {
/* 251 */     MCCalendarFormat<T> f = getCalendarFormat();
/* 252 */     return isMCFocusOwner() ? 
/* 253 */       (T)f.doInputParse(value) : (T)f.doOutputParse(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String doFormat(MCCalendarDate<?> value) {
/* 258 */     MCCalendarFormat<T> f = getCalendarFormat();
/* 259 */     return isMCFocusOwner() ? 
/* 260 */       f.doInputFormat(value) : f.doOutputFormat(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isInputMethodEditing() {
/* 265 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public T getValue() {
/* 271 */     if (isPopupVisible()) {
/* 272 */       MCRow o = getSelectedListRow();
/* 273 */       if (o != null) {
/* 274 */         MCCalendarDate mCCalendarDate = (MCCalendarDate)o.getValue(getKeyColumnName());
/* 275 */         String sv = getCalendarFormat().doInputFormat(mCCalendarDate);
/* 276 */         if (MCStringUtil.eq(getText(), sv)) {
/* 277 */           MCDateFieldType y = _getDateFieldType(
/* 278 */               getCalendarFormat().getInputPattern());
/* 279 */           if (mCCalendarDate != null && y != null) {
/* 280 */             mCCalendarDate = mCCalendarDate.trunc(y);
/*     */           }
/* 282 */           return (T)mCCalendarDate;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 287 */     String t = getText();
/* 288 */     T ov = getRowValue();
/* 289 */     if (ov != null) {
/*     */       try {
/* 291 */         String osv = doFormat((MCCalendarDate<?>)ov);
/* 292 */         if (MCStringUtil.eq(t, osv)) {
/* 293 */           return ov;
/*     */         }
/*     */       }
/* 296 */       catch (MCException mCException) {
/* 297 */         MCCalendarFormat<T> f = getCalendarFormat();
/* 298 */         String osv = isMCFocusOwner() ? 
/* 299 */           f.doOutputFormat((MCCalendarDate)ov) : f.doInputFormat((MCCalendarDate)ov);
/* 300 */         if (MCStringUtil.eq(t, osv)) {
/* 301 */           return ov;
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 309 */       return doParse(t);
/*     */     }
/* 311 */     catch (MCException mCException) {
/* 312 */       MCCalendarFormat<T> f = getCalendarFormat();
/* 313 */       return isMCFocusOwner() ? (T)f.doOutputParse(t) : (T)f.doInputParse(t);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRowToView() {
/* 324 */     MCBeansUtil.checkThread();
/* 325 */     MCConstRow o = getBaseRow();
/* 326 */     String n = getBaseRowColumnName();
/*     */     
/* 328 */     if (MCBeansUtil.isNull(o, n)) {
/*     */       return;
/*     */     }
/*     */     
/* 332 */     T m = getRowValue();
/* 333 */     boolean c = false;
/* 334 */     T v = null;
/*     */     try {
/* 336 */       v = getValue();
/*     */     }
/* 338 */     catch (MCException mCException) {
/* 339 */       c = true;
/*     */     } 
/* 341 */     if (!c) {
/* 342 */       c = !MCUtil.equals(m, v);
/*     */     }
/* 344 */     if (c) {
/* 345 */       boolean e = MCBeansProxy.PROXY.isEventEnabled();
/*     */       try {
/* 347 */         MCEventProxy.PROXY.setValue(getEventInfo(), (Comparable<?>)v, (Comparable<?>)v);
/* 348 */         MCBeansProxy.PROXY.setEventEnabled(false);
/* 349 */         setText(m);
/*     */       } finally {
/*     */         
/* 352 */         MCBeansProxy.PROXY.setEventEnabled(e);
/*     */       } 
/*     */     } 
/*     */     
/* 356 */     getComboField().adjustText();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setText(T text) {
/* 361 */     setDocumentEditable(true);
/* 362 */     boolean e = isAutoFocus();
/*     */     try {
/* 364 */       setAutoFocus(false);
/* 365 */       getComboField().setText(doFormat((MCCalendarDate<?>)text));
/*     */     } finally {
/*     */       
/* 368 */       if (MCListType.SELECT_ONLY == getListType()) {
/* 369 */         setDocumentEditable(false);
/*     */       }
/* 371 */       setAutoFocus(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setDocumentEditable(boolean editable) {
/* 386 */     Document d = getDocument();
/* 387 */     if (d instanceof MCCalendarDocument) {
/* 388 */       ((MCCalendarDocument)d).setEditable(editable);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValueChanged() {
/* 403 */     adjustViewValue();
/*     */     try {
/* 405 */       return isValueChanged((Comparable<?>)getValue());
/*     */     }
/* 407 */     catch (MCException mCException) {
/* 408 */       return true;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValueChanged(Comparable<?> value) {
/*     */     try {
/* 415 */       return isValueChanged(value, (Comparable<?>)getRowValue());
/*     */     }
/* 417 */     catch (MCException mCException) {
/* 418 */       return true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void adjustViewValue() {
/* 431 */     char y = 'y';
/* 432 */     char m = 'M';
/* 433 */     char d = 'd';
/* 434 */     String p = getCalendarFormat().getInputPattern();
/* 435 */     char[] a = p.toCharArray();
/* 436 */     int max = -1;
/* 437 */     for (int i = 0; i < a.length; i++) {
/* 438 */       char c = a[i];
/* 439 */       if (c == y || c == m || c == d) {
/* 440 */         max = i;
/*     */       }
/*     */     } 
/*     */     
/* 444 */     if (max == -1) {
/*     */       return;
/*     */     }
/* 447 */     String t = getText();
/* 448 */     if (!MCStringUtil.isNull(t)) {
/*     */       try {
/* 450 */         doParse(t);
/*     */       }
/* 452 */       catch (MCException mCException) {
/*     */ 
/*     */         
/* 455 */         if (t.length() > max) {
/*     */           
/* 457 */           StringBuilder sb = new StringBuilder(t);
/* 458 */           String f = getCalendarFormat().getInputBase();
/* 459 */           if (f == null) {
/* 460 */             MCTimestamp mCTimestamp; MCCalendarDate<?> v = (MCCalendarDate<?>)today();
/* 461 */             if (v == null) {
/* 462 */               if (MCDataType.DATE.equals(getDataType())) {
/* 463 */                 MCDate mCDate = MCDate.today();
/*     */               } else {
/*     */                 
/* 466 */                 mCTimestamp = MCTimestamp.today();
/*     */               } 
/*     */             }
/* 469 */             f = getCalendarFormat().doInputFormat((MCCalendarDate)mCTimestamp);
/*     */           } 
/* 471 */           if (t.length() < f.length()) {
/* 472 */             sb.append(f.substring(t.length()));
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 483 */           if (!MCStringUtil.eq(
/* 484 */               getComboField().getText(), sb.toString())) {
/* 485 */             getComboField().setText(sb.toString());
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canChange() {
/* 495 */     T v = null;
/*     */     try {
/* 497 */       v = getValue();
/*     */     }
/* 499 */     catch (MCException mCException) {
/* 500 */       doCheckValueError();
/* 501 */       return false;
/*     */     } 
/* 503 */     return (canChange(v, (MCMessageList)null).size() == 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected class MCCalendarComboField
/*     */     extends MCFieldComboBox<T>.MCFieldComboField
/*     */   {
/*     */     protected void initBeans() {
/* 535 */       super.initBeans();
/*     */       
/* 537 */       setHorizontalAlignment(0);
/* 538 */       enableInputMethods(false);
/*     */     }
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public void enableInputMethods(boolean enable) {
/* 544 */       super.enableInputMethods(false);
/*     */     }
/*     */ 
/*     */     
/*     */     protected Document createDefaultModel() {
/* 549 */       return (Document)new MCCalendarDocument(MCCalendarComboBox.this);
/*     */     }
/*     */   }
/*     */   
/*     */   protected MCDateFieldType _getDateFieldType(String pattern) {
/* 554 */     if (MCStringUtil.isNull(pattern)) {
/* 555 */       return null;
/*     */     }
/*     */     
/* 558 */     boolean[] a = new boolean[7]; byte b; int i; char[] arrayOfChar;
/* 559 */     for (i = (arrayOfChar = pattern.toCharArray()).length, b = 0; b < i; ) { char c = arrayOfChar[b];
/* 560 */       if ('y' == c) {
/* 561 */         a[0] = true;
/*     */       }
/* 563 */       else if ('M' == c) {
/* 564 */         a[1] = true;
/*     */       }
/* 566 */       else if ('d' == c) {
/* 567 */         a[2] = true;
/*     */       }
/* 569 */       else if ('H' == c || 'h' == c) {
/* 570 */         a[3] = true;
/*     */       }
/* 572 */       else if ('m' == c) {
/* 573 */         a[4] = true;
/*     */       }
/* 575 */       else if ('s' == c) {
/* 576 */         a[5] = true;
/*     */       }
/* 578 */       else if ('S' == c) {
/* 579 */         a[6] = true;
/*     */       } 
/*     */       b++; }
/*     */     
/* 583 */     if (a[6]) {
/* 584 */       return null;
/*     */     }
/* 586 */     if (a[5]) {
/* 587 */       return MCDateFieldType.SECOND;
/*     */     }
/* 589 */     if (a[4]) {
/* 590 */       return MCDateFieldType.MINUTE;
/*     */     }
/* 592 */     if (a[3]) {
/* 593 */       return MCDateFieldType.HOUR;
/*     */     }
/* 595 */     if (a[2]) {
/* 596 */       return MCDateFieldType.DAY;
/*     */     }
/* 598 */     if (a[1]) {
/* 599 */       return MCDateFieldType.MONTH;
/*     */     }
/* 601 */     if (a[0]) {
/* 602 */       return MCDateFieldType.YEAR;
/*     */     }
/* 604 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void _setValueFromSetValueNoListCheck(T value) {
/* 612 */     setViewToRow(value);
/*     */   }
/*     */   
/*     */   protected abstract MCCalendarComboField createComboField();
/*     */   
/*     */   protected abstract MCCalendarFormat<T> createCalendarFormat();
/*     */   
/*     */   protected abstract MCCalendarFormat<T> createListCalendarFormat();
/*     */   
/*     */   public abstract T getRowValue();
/*     */   
/*     */   public abstract T today();
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\combobox\MCCalendarComboBox.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */