package mcframe.clientCore.beans.combobox;

interface MCComboListSelectionListener {
  void valueChanged(MCComboListSelectionEvent paramMCComboListSelectionEvent);
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\combobox\MCComboListSelectionListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */