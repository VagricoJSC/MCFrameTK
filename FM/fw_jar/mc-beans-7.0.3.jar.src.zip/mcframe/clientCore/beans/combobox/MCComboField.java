package mcframe.clientCore.beans.combobox;

import javax.swing.JComponent;
import javax.swing.border.Border;
import mcframe.clientCore.beans.MCMode;

public interface MCComboField {
  JComponent getComponent();
  
  void modeChanged(MCMode paramMCMode);
  
  @Deprecated
  Border getDefaultFieldBorder();
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\combobox\MCComboField.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */