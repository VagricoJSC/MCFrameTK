/*     */ package mcframe.clientCore.beans.combobox;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import javax.swing.SwingUtilities;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.text.MCCalendarDocumentBeans;
/*     */ import mcframe.clientCore.beans.text.MCCalendarFormat;
/*     */ import mcframe.clientCore.beans.text.MCDateFormat;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCCalendarDate;
/*     */ import mcframe.commonCore.lang.MCDataType;
/*     */ import mcframe.commonCore.lang.MCDate;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCMessageList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCDateComboBox
/*     */   extends MCCalendarComboBox<MCDate>
/*     */   implements MCCalendarDocumentBeans<MCDate>
/*     */ {
/*     */   public MCDateComboBox(String name) {
/*  42 */     super(name);
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCDateComboField getComboField() {
/*  47 */     return (MCDateComboField)super.getComboField();
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCDateComboField createComboField() {
/*  52 */     return new MCDateComboField();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCalendarFormat(MCDateFormat format) {
/*  63 */     setCalendarFormat((MCCalendarFormat<T>)format);
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCCalendarFormat<MCDate> createCalendarFormat() {
/*  68 */     return (MCCalendarFormat<MCDate>)new MCDateFormat();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCDateFormat getCalendarFormat() {
/*  73 */     return (MCDateFormat)super.getCalendarFormat();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setListCalendarFormat(MCDateFormat format) {
/*  84 */     setListCalendarFormat((MCCalendarFormat<T>)format);
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCCalendarFormat<MCDate> createListCalendarFormat() {
/*  89 */     return (MCCalendarFormat<MCDate>)new MCDateFormat();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCDateFormat getListCalendarFormat() {
/*  94 */     return (MCDateFormat)super.getListCalendarFormat();
/*     */   }
/*     */ 
/*     */   
/*     */   public Comparable<?> doListFormat(Comparable<?> value) {
/*     */     MCDate v;
/* 100 */     if (value == null || "".equals(value)) {
/* 101 */       v = null;
/*     */     }
/* 103 */     else if (value instanceof MCDate) {
/* 104 */       v = (MCDate)value;
/*     */     } else {
/*     */       
/* 107 */       throw new MCException(MCBeansUtil.createMsg(this, Core_Msg_FW_A.FCBAC0351, new Object[] { value }));
/*     */     } 
/* 109 */     return getListCalendarFormat().doOutputFormat((MCCalendarDate)v);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean checkInputValue(Comparable<?> value, MCMessageList list) {
/* 114 */     MCMessageList l = getValueChecker().checkInputValue(this, value);
/* 115 */     if (l.size() == 0) {
/* 116 */       return true;
/*     */     }
/* 118 */     if (list != null) {
/* 119 */       list.addAll((Collection)l);
/*     */     }
/* 121 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCMessageList checkValue(Comparable<?> value) {
/* 126 */     return getValueChecker().checkValue(this, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCDate getRowValue() {
/* 131 */     MCConstRow c = getBaseRow();
/* 132 */     String n = getBaseRowColumnName();
/* 133 */     return !MCBeansUtil.isNull(c, n) ? c.getDate(n) : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setViewValue(Comparable<?> value, MCMessageList list) {
/* 138 */     if (list == null) {
/* 139 */       list = new MCMessageList();
/*     */     }
/* 141 */     if (value != null) {
/* 142 */       if (value instanceof MCDate) {
/* 143 */         setValue((MCDate)value, list);
/*     */       } else {
/*     */         
/* 146 */         list.add(MCBeansUtil.createCauseMsg(this, Core_Msg_FW_A.FCBAC0069, new Object[0]));
/*     */       } 
/*     */     } else {
/*     */       
/* 150 */       setValue((MCDate)null, list);
/*     */     } 
/*     */   }
/*     */   
/*     */   public MCDate today() {
/*     */     MCDate v;
/* 156 */     MCRootPanel p = getRootPanel();
/* 157 */     if (p == null) {
/* 158 */       return MCDate.today();
/*     */     }
/*     */     
/*     */     try {
/* 162 */       v = (MCDate)p.today(MCDataType.DATE);
/*     */     }
/* 164 */     catch (Exception exception) {
/* 165 */       v = null;
/*     */     } 
/* 167 */     return (v != null) ? v : MCDate.today();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doAfterInsert() {
/* 172 */     if (!isPopupVisible()) {
/*     */       return;
/*     */     }
/*     */     
/* 176 */     SwingUtilities.invokeLater(new Runnable()
/*     */         {
/*     */           public void run()
/*     */           {
/* 180 */             if (!"list".equals(MCDateComboBox.this.getListConfig().getOpeType())) {
/*     */               return;
/*     */             }
/* 183 */             MCRow o = MCDateComboBox.this.getModel().getSelectedRow();
/* 184 */             if (o != null) {
/* 185 */               MCDateFormat f = MCDateComboBox.this.getCalendarFormat();
/* 186 */               String m = f.doInputFormat((MCCalendarDate)o.getDate(MCDateComboBox.this.getKeyColumnName()));
/*     */               
/* 188 */               MCDate d = null;
/*     */               try {
/* 190 */                 d = MCDateComboBox.this.getValue();
/*     */               }
/* 192 */               catch (MCException mCException) {
/* 193 */                 MCDateComboBox.this.doIncrementalSearch();
/*     */                 return;
/*     */               } 
/* 196 */               String v = f.doInputFormat((MCCalendarDate)d);
/*     */ 
/*     */               
/* 199 */               if (MCStringUtil.eq(m, v)) {
/*     */                 return;
/*     */               }
/*     */             } 
/* 203 */             MCDateComboBox.this.doIncrementalSearch();
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean doIncrementalSearch() {
/* 210 */     String v = getText();
/* 211 */     if (MCStringUtil.isNull(v)) {
/* 212 */       return false;
/*     */     }
/*     */     
/* 215 */     MCList<?> l = getList();
/* 216 */     if (l == null) {
/* 217 */       return false;
/*     */     }
/*     */     
/* 220 */     boolean e = MCBeansProxy.PROXY.isEventEnabled();
/*     */     
/* 222 */     try { MCBeansProxy.PROXY.setEventEnabled(false);
/* 223 */       String n = getKeyColumnName();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */        }
/*     */     
/*     */     finally
/*     */     
/*     */     { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 248 */       MCBeansProxy.PROXY.setEventEnabled(e); }  MCBeansProxy.PROXY.setEventEnabled(e);
/*     */     
/* 250 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public Comparable<?> _adjustValueByFormat(Comparable<?> value) {
/* 255 */     if (value instanceof MCDate) {
/* 256 */       return (Comparable<?>)MCBeansProxy.PROXY.adjustValueByFormat(
/* 257 */           (MCCalendarDate<?>)value, getCalendarFormat().getInputPattern());
/*     */     }
/* 259 */     return value;
/*     */   }
/*     */   
/*     */   protected class MCDateComboField extends MCCalendarComboBox<MCDate>.MCCalendarComboField {}
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\combobox\MCDateComboBox.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */