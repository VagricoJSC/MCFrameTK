/*    */ package mcframe.clientCore.beans.combobox;
/*    */ 
/*    */ import mcframe.commonCore.container.MCList;
/*    */ import mcframe.commonCore.container.MCRow;
/*    */ 
/*    */ public abstract class AbsMCPackageProxy
/*    */ {
/*    */   protected void setPluralValueEnable(MCTextComboBox compo, boolean enable) {
/*  9 */     compo.setPluralValueEnable(enable);
/*    */   }
/*    */   
/*    */   protected void cancelComboPopup(AbsMCComboBox<?> compo) {
/* 13 */     compo.cancelComboPopup();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void clearList(AbsMCComboBox<?> compo) {
/* 20 */     compo.getModel().setList(MCList.create(MCRow.class));
/*    */   }
/*    */   
/*    */   protected void createListEx(AbsMCComboBox<?> tf, Comparable<?> value) {
/* 24 */     tf.createListEx(value);
/*    */   }
/*    */   
/*    */   protected Boolean getFirePopupMenuCanceledProperty(AbsMCComboBox<?> compo) {
/* 28 */     return compo.getFirePopupMenuCanceledProperty();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void setFirePopupMenuCanceledProperty(AbsMCComboBox<?> compo, Boolean property) {
/* 33 */     compo.setFirePopupMenuCanceledProperty(property);
/*    */   }
/*    */   
/*    */   protected void adjustIconSize(AbsMCComboBox c, int ratio) {
/* 37 */     c.getComboButton().adjustIconSize(ratio);
/*    */   }
/*    */   
/*    */   protected void setListPressing(boolean pressing) {
/* 41 */     MCComboPopup.setListPressing(pressing);
/*    */   }
/*    */   
/*    */   protected boolean isListPressing() {
/* 45 */     return MCComboPopup.isListPressing();
/*    */   }
/*    */   
/*    */   protected String _adjustValue(MCTextComboBox e, String old) {
/* 49 */     return (String)e._adjustValue(old);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\combobox\AbsMCPackageProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */