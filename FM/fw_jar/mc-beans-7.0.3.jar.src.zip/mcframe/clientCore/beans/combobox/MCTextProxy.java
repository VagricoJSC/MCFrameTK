/*    */ package mcframe.clientCore.beans.combobox;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import mcframe.clientCore.beans.text.AbsMCPackageProxy;
/*    */ import mcframe.clientCore.beans.text.MCIMDelegate;
/*    */ import mcframe.clientCore.beans.text.MCInputMethodType;
/*    */ import mcframe.clientCore.beans.text.MCTextDocument;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MCTextProxy
/*    */   extends AbsMCPackageProxy
/*    */ {
/* 17 */   static final MCTextProxy PROXY = new MCTextProxy();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void setPasteActionProcessing(MCTextDocument document, boolean flg) {
/* 30 */     super.setPasteActionProcessing(document, flg);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void installInputMethod(MCIMDelegate delegate, Component compo, MCInputMethodType type) {
/* 36 */     super.installInputMethod(delegate, compo, type);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void uninstallInputMethod(MCIMDelegate delegate, Component compo, MCInputMethodType type) {
/* 42 */     super.uninstallInputMethod(delegate, compo, type);
/*    */   }
/*    */ 
/*    */   
/*    */   protected MCIMDelegate createIMDelegate() {
/* 47 */     return super.createIMDelegate();
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\combobox\MCTextProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */