/*    */ package mcframe.clientCore.beans.combobox;
/*    */ 
/*    */ import mcframe.clientCore.beans.action.AbsMCPackageProxy;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MCActionProxy
/*    */   extends AbsMCPackageProxy
/*    */ {
/* 12 */   static final MCActionProxy PROXY = new MCActionProxy();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected int getIgnoreMillis() {
/* 19 */     return super.getIgnoreMillis();
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\combobox\MCActionProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */