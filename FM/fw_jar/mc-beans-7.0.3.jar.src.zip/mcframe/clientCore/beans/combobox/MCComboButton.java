/*     */ package mcframe.clientCore.beans.combobox;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Polygon;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.event.MouseEvent;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.UIManager;
/*     */ import mcframe.clientCore.beans.MCButton;
/*     */ import mcframe.clientCore.beans.MCModeInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MCComboButton
/*     */   extends JButton
/*     */ {
/*     */   private ImageIcon _icon;
/*     */   private Boolean _mc_metal;
/*     */   private static Object DO_NOT_CANCEL_POPUP_PROPERTY;
/*     */   
/*     */   private void setMCMetal(Boolean mcMetal) {
/*  54 */     this._mc_metal = mcMetal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isMCMetal() {
/*  66 */     if (this._mc_metal == null) {
/*  67 */       this._mc_metal = Boolean.valueOf(UIManager.getLookAndFeel() instanceof mcframe.clientCore.beans.plaf.metal.MCMetalLookAndFeel);
/*     */     }
/*  69 */     return this._mc_metal.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Object getDoNotCancelPopupProperty() {
/*  88 */     if (DO_NOT_CANCEL_POPUP_PROPERTY == null) {
/*  89 */       DO_NOT_CANCEL_POPUP_PROPERTY = (new JComboBox())
/*  90 */         .getClientProperty("doNotCancelPopup");
/*     */     }
/*  92 */     return DO_NOT_CANCEL_POPUP_PROPERTY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public MCComboButton() {
/* 104 */     init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init() {
/* 114 */     initBeans();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initBeans() {
/* 124 */     setMCMetal((Boolean)null);
/*     */     
/* 126 */     putClientProperty("doNotCancelPopup", getDoNotCancelPopupProperty());
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateUI() {
/* 131 */     setName("MCComboBox.arrowButton");
/*     */     
/* 133 */     super.updateUI();
/*     */     
/* 135 */     setMCMetal((Boolean)null);
/*     */     
/* 137 */     if (isMCMetal()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 145 */       this._icon = (ImageIcon)UIManager.getIcon("Combobutton.icon");
/*     */ 
/*     */       
/* 148 */       Icon newIcon = new MCMetalComboButtonIcon(100);
/* 149 */       setIcon(newIcon);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 154 */       this._icon = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFocusTraversable() {
/* 160 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void modeChanged(MCModeInfo info) {
/* 171 */     if (info == null) {
/*     */       return;
/*     */     }
/*     */     
/* 175 */     int s = info.getStatus();
/* 176 */     setVisible((s != 3));
/* 177 */     setEnabled((s == 1));
/* 178 */     setFocusable((s == 1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void adjustIconSize(int ratio) {
/* 190 */     ImageIcon i = this._icon;
/* 191 */     if (i != null) {
/* 192 */       Icon newIcon = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 198 */       newIcon = new MCMetalComboButtonIcon(ratio);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 214 */       setIcon(newIcon);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void processMouseEvent(MouseEvent e) {
/* 220 */     if (e.getID() == 501 && MCButton.action()) {
/* 221 */       e.consume();
/*     */       return;
/*     */     } 
/* 224 */     super.processMouseEvent(e);
/*     */   }
/*     */   
/*     */   protected class MCMetalComboButtonIcon
/*     */     implements Icon
/*     */   {
/* 230 */     private int _fontRatio = 100;
/*     */     
/*     */     MCMetalComboButtonIcon(int ratio) {
/* 233 */       this._fontRatio = ratio;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public final void paintIcon(Component c, Graphics g, int x, int y) {
/* 239 */       Graphics2D g2D = (Graphics2D)g;
/*     */ 
/*     */       
/* 242 */       g2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
/*     */ 
/*     */       
/* 245 */       int x0 = 0;
/* 246 */       int y0 = 0;
/*     */       
/* 248 */       int x1 = (3 - x0) * this._fontRatio / 100 + x;
/* 249 */       int y1 = (8 - y0) * this._fontRatio / 100 + y;
/*     */       
/* 251 */       int x2 = (11 - x0) * this._fontRatio / 100 + x;
/* 252 */       int y2 = (8 - y0) * this._fontRatio / 100 + y;
/*     */       
/* 254 */       int x3 = (7 - x0) * this._fontRatio / 100 + x;
/* 255 */       int y3 = (12 - y0) * this._fontRatio / 100 + y;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 264 */       Color col = Color.black;
/* 265 */       if (MCComboButton.this.getParent() != null && MCComboButton.this.getParent() instanceof AbsMCComboBox) {
/* 266 */         if (!((AbsMCComboBox)MCComboButton.this.getParent()).isEnabled() || !((AbsMCComboBox)MCComboButton.this.getParent()).isEditable()) {
/* 267 */           col = new Color(187, 187, 187);
/*     */         
/*     */         }
/*     */       }
/* 271 */       else if (!MCComboButton.this.getParent().isEnabled()) {
/* 272 */         col = new Color(187, 187, 187);
/*     */       } 
/*     */       
/* 275 */       g.setColor(col);
/*     */ 
/*     */       
/* 278 */       g.drawLine(x1, y1, x2, y2);
/* 279 */       g.drawLine(x2, y2, x3, y3);
/* 280 */       g.drawLine(x3, y3, x1, y1);
/*     */       
/* 282 */       Polygon p = new Polygon();
/* 283 */       p.addPoint(x1, y1);
/* 284 */       p.addPoint(x2, y2);
/* 285 */       p.addPoint(x3, y3);
/* 286 */       p.addPoint(x1, y1);
/*     */       
/* 288 */       g.fillPolygon(p);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getIconWidth() {
/* 297 */       Icon _icon = UIManager.getIcon("Combobutton.icon");
/* 298 */       return _icon.getIconWidth() * this._fontRatio / 100;
/*     */     }
/*     */ 
/*     */     
/*     */     public int getIconHeight() {
/* 303 */       Icon _icon = UIManager.getIcon("Combobutton.icon");
/* 304 */       return _icon.getIconHeight() * this._fontRatio / 100;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\combobox\MCComboButton.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */