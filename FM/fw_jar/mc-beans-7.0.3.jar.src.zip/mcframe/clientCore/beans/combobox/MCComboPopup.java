/*     */ package mcframe.clientCore.beans.combobox;
/*     */ 
/*     */ import java.awt.AWTEvent;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.GraphicsConfiguration;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.MouseEvent;
/*     */ import javax.swing.BoxLayout;
/*     */ import javax.swing.ButtonModel;
/*     */ import javax.swing.DefaultListCellRenderer;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JPopupMenu;
/*     */ import javax.swing.JScrollBar;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.ListCellRenderer;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.Timer;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.border.LineBorder;
/*     */ import javax.swing.event.PopupMenuEvent;
/*     */ import javax.swing.event.PopupMenuListener;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCResourceBeans;
/*     */ import mcframe.clientCore.event.MCEventInfo;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MCComboPopup<T extends Comparable<?>>
/*     */   extends JPopupMenu
/*     */ {
/*  62 */   private static final Border LIST_BORDER = new LineBorder(Color.BLACK, 1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final int SCROLL_UP = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final int SCROLL_DOWN = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final AbsMCComboBox<T> _compo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  94 */   private JScrollPane _pane = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   private JList _list = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   private Timer _auto_scroll_timer = null;
/*     */   
/*     */   boolean _has_entered = false;
/*     */   
/*     */   boolean _is_auto_scrolling = false;
/*     */   
/* 116 */   int _scroll_direction = 0;
/*     */   
/*     */   private static boolean IS_LIST_PRESSING = false;
/*     */   
/*     */   private boolean _set_visible_processing;
/*     */ 
/*     */   
/*     */   static void setListPressing(boolean pressing) {
/* 124 */     IS_LIST_PRESSING = pressing;
/*     */   }
/*     */   
/*     */   static boolean isListPressing() {
/* 128 */     return IS_LIST_PRESSING;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void init() {
/* 151 */     initBeans();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initBeans() {
/* 161 */     getComboBox().getModel().setComboListSelectionListener(
/* 162 */         createComboListSelectionListener());
/*     */     
/* 164 */     configureList();
/* 165 */     configureScrollPane();
/* 166 */     configurePopup();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   JList getList() {
/* 177 */     return (this._list != null) ? this._list : (this._list = createList());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JList createList() {
/* 188 */     return new JList(getComboBox().getModel());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void configureList() {
/* 198 */     AbsMCComboBox<T> c = getComboBox();
/* 199 */     JList l = getList();
/*     */     
/* 201 */     l.setFont(c.getFont());
/* 202 */     l.setCellRenderer(createListCellRenderer());
/* 203 */     l.addMouseListener(c.getMouseListener());
/* 204 */     l.addMouseMotionListener(c.getMouseListener());
/*     */     
/* 206 */     l.setVerifyInputWhenFocusTarget(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JScrollPane getScrollPane() {
/* 217 */     return (this._pane != null) ? this._pane : (this._pane = createScrollPane());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JScrollPane createScrollPane() {
/* 228 */     JScrollPane sp = new JScrollPane(getList(), 
/* 229 */         20, 
/* 230 */         31);
/* 231 */     sp.setHorizontalScrollBar((JScrollBar)null);
/* 232 */     return sp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void configureScrollPane() {
/* 242 */     JScrollPane sp = getScrollPane();
/* 243 */     sp.setFocusable(false);
/* 244 */     sp.getVerticalScrollBar().setFocusable(false);
/* 245 */     sp.setBorder((Border)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void configurePopup() {
/* 255 */     setLayout(new BoxLayout(this, 1));
/* 256 */     setBorderPainted(true);
/* 257 */     setBorder(LIST_BORDER);
/* 258 */     setOpaque(false);
/* 259 */     add(getScrollPane());
/* 260 */     setDoubleBuffered(true);
/* 261 */     setFocusable(false);
/*     */ 
/*     */ 
/*     */     
/* 265 */     addPopupMenuListener(createPopupMenuListener());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private AbsMCComboBox<T> getComboBox() {
/* 276 */     return this._compo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void showPopup() {
/* 286 */     if (!canPopupVisible()) {
/*     */       return;
/*     */     }
/*     */     
/* 290 */     AbsMCComboBox<T> c = getComboBox();
/* 291 */     String t = c.getListConfig().getOpeType();
/*     */     try {
/* 293 */       c.getListConfig().setOpeType("list");
/* 294 */       c.createList();
/*     */       
/* 296 */       getList().clearSelection();
/*     */       
/* 298 */       int i = c.getModel().getSelectedIndex();
/* 299 */       getList().setSelectedIndex(i);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 304 */       Point p = getPopupLocation();
/*     */       
/* 306 */       adjustScrollBar();
/*     */       
/* 308 */       show(c, p.x, p.y);
/*     */       
/* 310 */       getList().ensureIndexIsVisible(i);
/*     */     
/*     */     }
/* 313 */     catch (RuntimeException e) {
/* 314 */       c.getListConfig().setOpeType(t);
/*     */       
/* 316 */       MCBeansUtil.handle(c, e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean canPopupVisible() {
/* 329 */     AbsMCComboBox<T> c = getComboBox();
/* 330 */     if (!c.isEnabled() || !c.isEditable()) {
/* 331 */       return false;
/*     */     }
/* 333 */     MCComboButton o = c.getComboButton();
/* 334 */     if (!o.isEnabled()) {
/* 335 */       return false;
/*     */     }
/* 337 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void adjustScrollBar() {
/* 347 */     AbsMCComboBox<T> c = getComboBox();
/* 348 */     JScrollPane sp = getScrollPane();
/* 349 */     JScrollBar v = sp.getVerticalScrollBar();
/* 350 */     if (v != null && v.isVisible()) {
/* 351 */       int i = getSelectedIndex();
/* 352 */       if (i == -1)
/*     */       {
/* 354 */         v.setValue(0);
/*     */       }
/*     */     } 
/* 357 */     MCBeansUtil.initScrollBar((MCResourceBeans)c, sp);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void hidePopup() {
/* 367 */     setVisible(false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void hide() {
/* 373 */     super.hide();
/*     */     
/* 375 */     hideAfter();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCComboPopup(AbsMCComboBox<T> compo) {
/* 384 */     this._set_visible_processing = false;
/*     */     this._compo = compo;
/*     */     init();
/*     */   } public void setVisible(boolean visible) {
/* 388 */     if (visible && !isVisible())
/*     */     {
/* 390 */       getComboBox().setFirePopupMenuCanceledProperty((Boolean)null);
/*     */     }
/* 392 */     if (this._set_visible_processing) {
/*     */       return;
/*     */     }
/*     */     try {
/* 396 */       this._set_visible_processing = true;
/* 397 */       super.setVisible(visible);
/*     */       
/* 399 */       if (!visible) {
/* 400 */         hideAfter();
/*     */       }
/*     */     } finally {
/*     */       
/* 404 */       this._set_visible_processing = false;
/*     */     } 
/*     */   }
/*     */   private void hideAfter() {
/*     */     Timer t;
/*     */     try {
/* 410 */       ButtonModel m = getComboBox().getComboButton().getModel();
/* 411 */       if (m.isPressed()) {
/* 412 */         m.setPressed(false);
/*     */       }
/* 414 */       AbsMCComboBox<T> c = getComboBox();
/* 415 */       c.getListConfig().setOpeType("input");
/*     */     }
/*     */     finally {
/*     */       
/* 419 */       stopAutoScrolling();
/*     */ 
/*     */       
/* 422 */       Timer timer = new Timer(MCActionProxy.PROXY.getIgnoreMillis(), 
/* 423 */           new TimerAction());
/* 424 */       timer.start();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Point getPopupLocation() {
/* 435 */     AbsMCComboBox<T> c = getComboBox();
/* 436 */     Dimension s = getListPreferredSize();
/* 437 */     Insets i = getInsets();
/* 438 */     s.setSize(s.width - i.right + i.left, 
/* 439 */         getPopupHeightForRowCount(c.getMaximumRowCount()));
/*     */     
/* 441 */     Rectangle a = computePopupBounds(0, (c.getBounds()).height, s.width, s.height);
/* 442 */     i = getInsets();
/* 443 */     a.width += i.left + i.right + 2;
/*     */     
/* 445 */     Dimension d = a.getSize();
/* 446 */     JScrollPane sp = getScrollPane();
/*     */     
/* 448 */     sp.setMaximumSize(new Dimension(d));
/* 449 */     sp.setPreferredSize(new Dimension(d));
/* 450 */     sp.setMinimumSize(new Dimension(d));
/*     */     
/* 452 */     return a.getLocation();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Dimension getListPreferredSize() {
/* 463 */     AbsMCComboBox<T> c = getComboBox();
/* 464 */     Dimension d = c.getSize();
/* 465 */     int w = d.width;
/* 466 */     MCList<?> l = c.getList();
/* 467 */     if (l == null) {
/* 468 */       return d;
/*     */     }
/* 470 */     JLabel a = new JLabel();
/* 471 */     a.setFont(c.getFont());
/* 472 */     for (int i = 0; i < l.size(); i++) {
/* 473 */       Object o = c.getModel().getElementAt(i);
/* 474 */       a.setText((o != null) ? o.toString() : "");
/* 475 */       w = Math.max((a.getPreferredSize()).width, w);
/*     */     } 
/* 477 */     d.width = w;
/* 478 */     if (l.size() > c.getMaximumRowCount())
/*     */     {
/* 480 */       d.width += 20;
/*     */     }
/* 482 */     return d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getPopupHeightForRowCount(int maxRowCount) {
/* 494 */     AbsMCComboBox<T> c = getComboBox();
/* 495 */     int h = 0;
/* 496 */     ListCellRenderer<Object> d = getList().getCellRenderer();
/* 497 */     int m = Math.min(maxRowCount, (c.getList() != null) ? c.getList().size() : 0);
/*     */     
/* 499 */     for (int i = 0; i < m; i++) {
/* 500 */       Object v = c.getModel().getElementAt(i);
/* 501 */       Component o = d.getListCellRendererComponent(getList(), v, i, false, false);
/* 502 */       h += (o.getPreferredSize()).height;
/*     */     } 
/*     */     
/* 505 */     if (h == 0) {
/* 506 */       h = c.getHeight();
/*     */     }
/*     */     
/* 509 */     Border b = getScrollPane().getViewportBorder();
/* 510 */     if (b != null) {
/* 511 */       Insets insets = b.getBorderInsets(null);
/* 512 */       h += insets.top + insets.bottom;
/*     */     } 
/* 514 */     b = getScrollPane().getBorder();
/* 515 */     if (b != null) {
/* 516 */       Insets insets = b.getBorderInsets(null);
/* 517 */       h += insets.top + insets.bottom;
/*     */     } 
/*     */     
/* 520 */     return h;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Rectangle computePopupBounds(int px, int py, int pw, int ph) {
/*     */     Rectangle a;
/* 535 */     Toolkit k = Toolkit.getDefaultToolkit();
/*     */ 
/*     */     
/* 538 */     AbsMCComboBox<T> c = getComboBox();
/* 539 */     GraphicsConfiguration gc = c.getGraphicsConfiguration();
/* 540 */     Point p = new Point();
/* 541 */     SwingUtilities.convertPointFromScreen(p, c);
/* 542 */     if (gc != null) {
/* 543 */       Insets i = k.getScreenInsets(gc);
/* 544 */       a = gc.getBounds();
/* 545 */       a.width -= i.left + i.right;
/* 546 */       a.height -= i.top + i.bottom;
/* 547 */       a.x += p.x + i.left;
/* 548 */       a.y += p.y + i.top;
/*     */     } else {
/*     */       
/* 551 */       a = new Rectangle(p, k.getScreenSize());
/*     */     } 
/*     */     
/* 554 */     Rectangle rect = new Rectangle(px, py, pw, ph);
/* 555 */     if (py + ph > a.y + a.height && ph < a.height) {
/* 556 */       rect.y = -rect.height;
/*     */     }
/* 558 */     return rect;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setListSelectedIndex(int index) {
/* 569 */     JList l = getList();
/* 570 */     l.setSelectedIndex(index);
/* 571 */     l.ensureIndexIsVisible(index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getSelectedIndex() {
/* 582 */     return getList().getSelectedIndex();
/*     */   }
/*     */   
/*     */   static class TimerAction
/*     */     implements ActionListener
/*     */   {
/*     */     public void actionPerformed(ActionEvent e) {
/* 589 */       MCComboPopup.IS_LIST_PRESSING = false;
/* 590 */       ((Timer)e.getSource()).stop();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void updateListBoxSelectionForEvent(MouseEvent e, boolean shouldScroll) {
/* 604 */     JList l = getList();
/* 605 */     if (l == null) {
/*     */       return;
/*     */     }
/* 608 */     Point p = e.getPoint();
/* 609 */     int i = l.locationToIndex(p);
/* 610 */     if (i == -1) {
/* 611 */       i = (p.y < 0) ? 0 : (getComboBox().getModel().getSize() - 1);
/*     */     }
/* 613 */     if (l.getSelectedIndex() == i) {
/*     */       return;
/*     */     }
/* 616 */     l.setSelectedIndex(i);
/* 617 */     if (shouldScroll) {
/* 618 */       l.ensureIndexIsVisible(i);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MouseEvent convertMouseEvent(MouseEvent e) {
/* 633 */     Point p = SwingUtilities.convertPoint((Component)e.getSource(), e.getPoint(), 
/* 634 */         getList());
/* 635 */     return new MouseEvent((Component)e.getSource(), e.getID(), e.getWhen(), 
/* 636 */         e.getModifiers(), p.x, p.y, e.getXOnScreen(), e.getYOnScreen(), 
/* 637 */         e.getClickCount(), e.isPopupTrigger(), 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void startAutoScrolling(int direction) {
/* 648 */     if (this._is_auto_scrolling) {
/* 649 */       this._auto_scroll_timer.stop();
/*     */     }
/* 651 */     this._is_auto_scrolling = true;
/*     */     
/* 653 */     JList l = getList();
/* 654 */     JScrollPane sp = getScrollPane();
/*     */     
/* 656 */     if (direction == 0) {
/* 657 */       this._scroll_direction = 0;
/*     */       
/* 659 */       Point p = SwingUtilities.convertPoint(sp, new Point(1, 1), l);
/* 660 */       l.setSelectedIndex(l.locationToIndex(p));
/*     */       
/* 662 */       this._auto_scroll_timer = new Timer(100, new AutoScrollActionHandler(0, null));
/*     */     }
/* 664 */     else if (direction == 1) {
/* 665 */       this._scroll_direction = 1;
/*     */       
/* 667 */       Point p = SwingUtilities.convertPoint(sp, new Point(1, 
/* 668 */             (sp.getSize()).height - 1 - 2), l);
/* 669 */       l.setSelectedIndex(l.locationToIndex(p));
/*     */       
/* 671 */       this._auto_scroll_timer = new Timer(100, new AutoScrollActionHandler(1, null));
/*     */     } 
/* 673 */     this._auto_scroll_timer.start();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void stopAutoScrolling() {
/* 683 */     this._is_auto_scrolling = false;
/* 684 */     if (this._auto_scroll_timer != null) {
/* 685 */       this._auto_scroll_timer.stop();
/* 686 */       this._auto_scroll_timer = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void processEvent(AWTEvent e) {
/*     */     try {
/* 693 */       super.processEvent(e);
/*     */     }
/* 695 */     catch (Throwable t) {
/* 696 */       MCBeansUtil.handle(getComboBox(), t);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCComboListSelectionListener createComboListSelectionListener() {
/* 708 */     return new MCComboPopupListSelectionListener(null);
/*     */   }
/*     */   
/*     */   private class MCComboPopupListSelectionListener
/*     */     implements MCComboListSelectionListener {
/*     */     private MCComboPopupListSelectionListener() {}
/*     */     
/*     */     public void valueChanged(MCComboListSelectionEvent e) {
/* 716 */       if (!MCComboPopup.this.isVisible()) {
/*     */         return;
/*     */       }
/* 719 */       int i = e.getNewListIndex();
/* 720 */       if (i == -1) {
/* 721 */         MCComboPopup.this.getList().clearSelection();
/*     */       } else {
/*     */         
/* 724 */         MCComboPopup.this.getList().setSelectedIndex(i);
/* 725 */         MCComboPopup.this.getList().ensureIndexIsVisible(i);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ListCellRenderer createListCellRenderer() {
/* 738 */     return new MCComboListCellRenderer(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class MCComboListCellRenderer
/*     */     extends DefaultListCellRenderer
/*     */     implements ListCellRenderer<Object>
/*     */   {
/*     */     private MCComboListCellRenderer() {
/* 759 */       setName("MCComboList.cellRenderer");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
/* 765 */       if (!(UIManager.getLookAndFeel() instanceof javax.swing.plaf.synth.SynthLookAndFeel)) {
/* 766 */         AbsMCComboBox<T> c = MCComboPopup.this.getComboBox();
/* 767 */         MCRow o = c.getModel().getRow(index);
/*     */         
/* 769 */         setFont(c.getFont());
/*     */         
/* 771 */         Color f = c.getListForeground(o, isSelected);
/* 772 */         if (f == null) {
/* 773 */           f = c.getDefaultListForeground(o, isSelected);
/*     */         }
/* 775 */         setForeground(f);
/*     */         
/* 777 */         Color b = c.getListBackground(o, isSelected);
/* 778 */         if (b == null) {
/* 779 */           b = c.getDefaultListBackground(o, isSelected);
/*     */         }
/* 781 */         setBackground(b);
/*     */         
/* 783 */         setText((value != null) ? value.toString() : "");
/*     */         
/* 785 */         return this;
/*     */       } 
/*     */       
/* 788 */       return super.getListCellRendererComponent(list, value, index, isSelected, 
/* 789 */           cellHasFocus);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Dimension getPreferredSize() {
/*     */       Dimension s;
/* 797 */       if (MCStringUtil.isNull(getText())) {
/* 798 */         setText(" ");
/* 799 */         s = super.getPreferredSize();
/* 800 */         setText("");
/*     */       } else {
/*     */         
/* 803 */         s = super.getPreferredSize();
/*     */       } 
/* 805 */       return s;
/*     */     }
/*     */   }
/*     */   
/*     */   private class AutoScrollActionHandler
/*     */     implements ActionListener {
/*     */     private int _direction;
/*     */     
/*     */     private AutoScrollActionHandler(int direction) {
/* 814 */       this._direction = direction;
/*     */     }
/*     */ 
/*     */     
/*     */     public void actionPerformed(ActionEvent e) {
/* 819 */       if (this._direction == 0) {
/* 820 */         autoScrollUp();
/*     */       } else {
/*     */         
/* 823 */         autoScrollDown();
/*     */       } 
/*     */       
/* 826 */       MCLog.write(Core_Msg_FW_A.FCBAC0390, new Object[0]);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void autoScrollUp() {
/* 831 */       JList l = MCComboPopup.this.getList();
/* 832 */       int i = l.getSelectedIndex();
/* 833 */       if (i > 0) {
/* 834 */         i--;
/* 835 */         l.setSelectedIndex(i);
/* 836 */         l.ensureIndexIsVisible(i);
/*     */       } 
/*     */     }
/*     */     
/*     */     protected void autoScrollDown() {
/* 841 */       JList l = MCComboPopup.this.getList();
/* 842 */       int i = l.getSelectedIndex();
/* 843 */       int m = l.getModel().getSize() - 1;
/* 844 */       if (i < m) {
/* 845 */         i++;
/* 846 */         l.setSelectedIndex(i);
/* 847 */         l.ensureIndexIsVisible(i);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PopupMenuListener createPopupMenuListener() {
/* 860 */     return new MCPopupMenuListener(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class MCPopupMenuListener
/*     */     implements PopupMenuListener
/*     */   {
/*     */     private boolean _canceled;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private MCPopupMenuListener() {
/* 877 */       this._canceled = false;
/*     */     }
/*     */     
/*     */     public void popupMenuCanceled(PopupMenuEvent e) {
/* 881 */       this._canceled = true;
/*     */     }
/*     */ 
/*     */     
/*     */     public void popupMenuWillBecomeInvisible(PopupMenuEvent e) {
/* 886 */       if (this._canceled) {
/* 887 */         this._canceled = false;
/*     */         return;
/*     */       } 
/* 890 */       AbsMCComboBox<?> c = MCComboPopup.this.getComboBox();
/* 891 */       JList l = MCComboPopup.this.getList();
/* 892 */       int i = l.getSelectedIndex();
/* 893 */       MCEventInfo f = c.getEventInfo();
/* 894 */       MCEventProxy.PROXY.setListIndex(f, f.getOldListIndex(), i);
/* 895 */       MCRow o = c.getModel().getRow(i);
/* 896 */       MCEventProxy.PROXY.setNewListRow(f, o);
/* 897 */       MCBeansUtil.requestCommit(c);
/*     */     }
/*     */     
/*     */     public void popupMenuWillBecomeVisible(PopupMenuEvent e) {}
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\combobox\MCComboPopup.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */