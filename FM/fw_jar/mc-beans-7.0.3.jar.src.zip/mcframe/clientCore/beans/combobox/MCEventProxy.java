/*    */ package mcframe.clientCore.beans.combobox;
/*    */ 
/*    */ import mcframe.clientCore.event.AbsMCPackageProxy;
/*    */ import mcframe.clientCore.event.MCEventBeans;
/*    */ import mcframe.clientCore.event.MCEventInfo;
/*    */ import mcframe.commonCore.container.MCRow;
/*    */ 
/*    */ final class MCEventProxy extends AbsMCPackageProxy {
/*  9 */   static final MCEventProxy PROXY = new MCEventProxy();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void setComponent(MCEventInfo info, MCEventBeans compo) {
/* 15 */     super.setComponent(info, compo);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void setListIndex(MCEventInfo info, int before, int after) {
/* 20 */     super.setListIndex(info, before, after);
/*    */   }
/*    */   
/*    */   void setListIndex(MCEventInfo info, int index) {
/* 24 */     setListIndex(info, index, index);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void setNewListRow(MCEventInfo info, MCRow row) {
/* 29 */     super.setNewListRow(info, row);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void setValue(MCEventInfo info, Comparable<?> before, Comparable<?> after) {
/* 35 */     super.setValue(info, before, after);
/*    */   }
/*    */   
/*    */   void setValue(MCEventInfo info, Comparable<?> value) {
/* 39 */     setValue(info, value, value);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\combobox\MCEventProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */