/*     */ package mcframe.clientCore.beans.combobox;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import mcframe.clientCore.beans.table.MCColumnConfig;
/*     */ import mcframe.clientCore.beans.table.MCTable;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCComboListConfig
/*     */ {
/*     */   public Color getRowBackground(AbsMCComboBox<?> compo, MCRow row, boolean selected) {
/*  31 */     return selected ? getSelectedRowBackground(compo, row) : 
/*  32 */       getRowBackground(compo, row);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Color getSelectedRowBackground(AbsMCComboBox<?> compo, MCRow row) {
/*  46 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Color getRowBackground(AbsMCComboBox<?> compo, MCRow row) {
/*  59 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getRowBackground(MCColumnConfig column, int index, MCTable<?> table, MCRow row, boolean selected) {
/*  76 */     return selected ? getSelectedRowBackground(column, index, table, row) : 
/*  77 */       getRowBackground(column, index, table, row);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Color getSelectedRowBackground(MCColumnConfig column, int index, MCTable<?> table, MCRow row) {
/*  93 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Color getRowBackground(MCColumnConfig column, int index, MCTable<?> table, MCRow row) {
/* 109 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getRowForeground(AbsMCComboBox<?> compo, MCRow row, boolean selected) {
/* 124 */     return selected ? getSelectedRowForeground(compo, row) : 
/* 125 */       getRowForeground(compo, row);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Color getSelectedRowForeground(AbsMCComboBox<?> compo, MCRow row) {
/* 139 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Color getRowForeground(AbsMCComboBox<?> compo, MCRow row) {
/* 152 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getRowForeground(MCColumnConfig column, int index, MCTable<?> table, MCRow row, boolean selected) {
/* 169 */     return selected ? getSelectedRowForeground(column, index, table, row) : 
/* 170 */       getRowForeground(column, index, table, row);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Color getSelectedRowForeground(MCColumnConfig column, int index, MCTable<?> table, MCRow row) {
/* 186 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Color getRowForeground(MCColumnConfig column, int index, MCTable<?> table, MCRow row) {
/* 202 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\combobox\MCComboListConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */