/*     */ package mcframe.clientCore.beans.combobox;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.swing.AbstractListModel;
/*     */ import mcframe.clientCore.beans.list.MCLinkedBeans;
/*     */ import mcframe.clientCore.beans.list.MCListConfig;
/*     */ import mcframe.clientCore.beans.table.MCEditorBeans;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.util.MCUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCComboListModel<T extends Comparable<?>>
/*     */   extends AbstractListModel
/*     */ {
/*     */   private final AbsMCComboBox<T> _compo;
/*  42 */   private MCList<?> _list = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   private final List<Object> _view_list = new ArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   private int _old_list_index = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   private int _new_list_index = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   private int _selected_index = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   private MCComboListSelectionListener _selection_listener = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCComboListModel(AbsMCComboBox<T> compo) {
/*  92 */     this._compo = compo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AbsMCComboBox<T> getComboBox() {
/* 103 */     return this._compo;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getSize() {
/* 108 */     MCList<?> l = getList();
/* 109 */     return (l != null) ? l.size() : 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getElementAt(int index) {
/* 114 */     if (index > -1 && index < this._view_list.size()) {
/* 115 */       return this._view_list.get(index);
/*     */     }
/* 117 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setList(MCList<?> list) {
/* 141 */     MCList<?> old = this._list;
/* 142 */     this._list = list;
/* 143 */     this._view_list.clear();
/*     */     
/* 145 */     AbsMCComboBox<T> c = getComboBox();
/*     */ 
/*     */     
/* 148 */     if (list != null) {
/* 149 */       MCListConfig o = c.getListConfig();
/* 150 */       String[] a = c.getListVisibleColumn();
/* 151 */       if (a == null) {
/* 152 */         a = c.getListNames();
/*     */       }
/* 154 */       if ("list".equals(o.getOpeType())) {
/* 155 */         for (MCRow d : this._list) {
/* 156 */           this._view_list.add(o.format(c, d, a));
/*     */         }
/*     */       }
/* 159 */       fireIntervalAdded(this, 0, list.size());
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 164 */     int i = -1;
/* 165 */     T v = null;
/*     */ 
/*     */     
/* 168 */     boolean ve = false;
/*     */     try {
/* 170 */       v = c.getValue();
/*     */     }
/* 172 */     catch (MCException mCException) {
/*     */ 
/*     */       
/* 175 */       ve = true;
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 180 */       if (v != null && !"".equals(v))
/*     */       {
/*     */ 
/*     */         
/* 184 */         Comparable<?> m = null;
/* 185 */         int oi = getSelectedIndex();
/* 186 */         if (old != null && oi > -1 && oi < old.size()) {
/* 187 */           m = old.get(oi).getValue(getComboBox().getKeyColumnName());
/*     */         }
/*     */         
/* 190 */         if (!v.equals(m) || (list != null && oi > -1 && oi < list.size() && 
/* 191 */           !v.equals(list.get(oi).getValue(getComboBox().getKeyColumnName())))) {
/*     */           
/* 193 */           i = getRowIndex(v);
/*     */         } else {
/*     */           
/* 196 */           i = oi;
/*     */         }
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 202 */     catch (MCException mCException) {}
/*     */ 
/*     */ 
/*     */     
/* 206 */     setSelectedIndex(i);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 211 */     if ("list".equals(c.getListConfig().getOpeType()) && ((
/* 212 */       v != null && !"".equals(v)) || ve) && i == -1) {
/* 213 */       c.doIncrementalSearch();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCList<?> getList() {
/* 227 */     return this._list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCRow getSelectedRow() {
/* 239 */     return getRow(getSelectedIndex());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCRow getRow(int index) {
/* 252 */     MCList<?> l = getList();
/* 253 */     if (l == null) {
/* 254 */       return null;
/*     */     }
/* 256 */     if (index > -1 && index < l.size()) {
/* 257 */       return l.get(index);
/*     */     }
/* 259 */     return null;
/*     */   }
/*     */   
/*     */   protected MCRow getRow(T value) {
/* 263 */     MCList<?> l = getList();
/* 264 */     if (l == null) {
/* 265 */       return null;
/*     */     }
/*     */     
/* 268 */     MCList<?> nl = l.subList(getComboBox().getKeyColumnName(), (Comparable)value);
/* 269 */     switch (nl.size()) {
/*     */       case 0:
/* 271 */         return null;
/*     */       case 1:
/* 273 */         return nl.get(0);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 280 */     MCLinkedBeans[] ca = getComboBox().getLinkBeans();
/* 281 */     String[] na = getComboBox().getListNames();
/* 282 */     int idx = -1;
/* 283 */     if (getComboBox() instanceof MCEditorBeans) {
/* 284 */       idx = ((MCEditorBeans)getComboBox()).getRowIndex();
/*     */     }
/*     */     
/* 287 */     for (int i = 0; i < ca.length; i++) {
/* 288 */       MCList<MCRow> tl = MCList.create(MCRow.class); byte b; int j; MCRow[] arrayOfMCRow;
/* 289 */       for (j = (arrayOfMCRow = nl.toArray()).length, b = 0; b < j; ) { MCRow o = arrayOfMCRow[b];
/* 290 */         Comparable<Comparable> ov = ca[i].getViewValue(idx);
/* 291 */         Comparable nv = o.getValue(na[i + 1]);
/* 292 */         if (ov == null && nv == null) {
/* 293 */           tl.add(o);
/*     */         }
/* 295 */         else if (ov != null && nv != null) {
/*     */ 
/*     */           
/* 298 */           if (ov.compareTo(nv) == 0)
/* 299 */             tl.add(o); 
/*     */         } 
/*     */         b++; }
/*     */       
/* 303 */       switch (tl.size()) {
/*     */         case 0:
/* 305 */           return nl.get(0);
/*     */         case 1:
/* 307 */           return tl.get(0);
/*     */       } 
/* 309 */       nl = tl;
/*     */     } 
/*     */ 
/*     */     
/* 313 */     return null;
/*     */   }
/*     */   
/*     */   protected int getRowIndex(T value) {
/* 317 */     MCRow o = getRow(value);
/* 318 */     return (o != null) ? getList().indexOf(o) : -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setSelectedItem(T value) {
/* 329 */     MCList<?> l = getList();
/* 330 */     if (l == null) {
/* 331 */       setSelectedIndex(-1);
/*     */       return;
/*     */     } 
/* 334 */     String n = getComboBox().getKeyColumnName();
/* 335 */     for (int i = 0; i < l.size(); i++) {
/* 336 */       MCRow o = l.get(i);
/* 337 */       if (MCUtil.equals(o.getValue(n), value)) {
/* 338 */         setSelectedIndex(i);
/*     */         return;
/*     */       } 
/*     */     } 
/* 342 */     setSelectedIndex(-1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setSelectedIndex(int index) {
/* 353 */     this._selected_index = index;
/*     */     
/* 355 */     MCComboListSelectionListener l = getComboListSelectionListener();
/* 356 */     if (l != null) {
/* 357 */       MCComboListSelectionEvent e = new MCComboListSelectionEvent();
/* 358 */       e.setNewListIndex(index);
/* 359 */       l.valueChanged(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getSelectedIndex() {
/* 371 */     return this._selected_index;
/*     */   }
/*     */   
/*     */   protected void setOldListIndex(int index) {
/* 375 */     this._old_list_index = index;
/*     */   }
/*     */   
/*     */   protected int getOldListIndex() {
/* 379 */     return this._old_list_index;
/*     */   }
/*     */   
/*     */   protected void setNewListIndex(int index) {
/* 383 */     this._new_list_index = index;
/*     */   }
/*     */   
/*     */   protected int getNewListIndex() {
/* 387 */     return this._new_list_index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setComboListSelectionListener(MCComboListSelectionListener listener) {
/* 399 */     this._selection_listener = listener;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCComboListSelectionListener getComboListSelectionListener() {
/* 411 */     return this._selection_listener;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\combobox\MCComboListModel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */