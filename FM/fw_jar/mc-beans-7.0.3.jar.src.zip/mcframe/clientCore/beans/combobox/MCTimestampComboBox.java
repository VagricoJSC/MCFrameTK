/*     */ package mcframe.clientCore.beans.combobox;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import javax.swing.SwingUtilities;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.text.MCCalendarDocumentBeans;
/*     */ import mcframe.clientCore.beans.text.MCCalendarFormat;
/*     */ import mcframe.clientCore.beans.text.MCTimestampFormat;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCCalendarDate;
/*     */ import mcframe.commonCore.lang.MCDataType;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.lang.MCTimestamp;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCMessageList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCTimestampComboBox
/*     */   extends MCCalendarComboBox<MCTimestamp>
/*     */   implements MCCalendarDocumentBeans<MCTimestamp>
/*     */ {
/*     */   public MCTimestampComboBox(String name) {
/*  42 */     super(name);
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCTimestampComboField getComboField() {
/*  47 */     return (MCTimestampComboField)super.getComboField();
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCTimestampComboField createComboField() {
/*  52 */     return new MCTimestampComboField();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCalendarFormat(MCTimestampFormat format) {
/*  63 */     setCalendarFormat((MCCalendarFormat<T>)format);
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCCalendarFormat<MCTimestamp> createCalendarFormat() {
/*  68 */     return (MCCalendarFormat<MCTimestamp>)new MCTimestampFormat();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCTimestampFormat getCalendarFormat() {
/*  73 */     return (MCTimestampFormat)super.getCalendarFormat();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setListCalendarFormat(MCTimestampFormat format) {
/*  84 */     setListCalendarFormat((MCCalendarFormat<T>)format);
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCCalendarFormat<MCTimestamp> createListCalendarFormat() {
/*  89 */     return (MCCalendarFormat<MCTimestamp>)new MCTimestampFormat();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCTimestampFormat getListCalendarFormat() {
/*  94 */     return (MCTimestampFormat)super.getListCalendarFormat();
/*     */   }
/*     */ 
/*     */   
/*     */   public Comparable<?> doListFormat(Comparable<?> value) {
/*     */     MCTimestamp v;
/* 100 */     if (value == null || "".equals(value)) {
/* 101 */       v = null;
/*     */     }
/* 103 */     else if (value instanceof MCTimestamp) {
/* 104 */       v = (MCTimestamp)value;
/*     */     } else {
/*     */       
/* 107 */       throw new MCException(MCBeansUtil.createMsg(this, Core_Msg_FW_A.FCBAC0352, new Object[] { value }));
/*     */     } 
/* 109 */     return getListCalendarFormat().doOutputFormat((MCCalendarDate)v);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean checkInputValue(Comparable<?> value, MCMessageList list) {
/* 114 */     MCMessageList l = getValueChecker().checkInputValue(this, value);
/* 115 */     if (l.size() == 0) {
/* 116 */       return true;
/*     */     }
/* 118 */     if (list != null) {
/* 119 */       list.addAll((Collection)l);
/*     */     }
/* 121 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCMessageList checkValue(Comparable<?> value) {
/* 126 */     return getValueChecker().checkValue(this, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCTimestamp getRowValue() {
/* 131 */     MCConstRow c = getBaseRow();
/* 132 */     String n = getBaseRowColumnName();
/* 133 */     return !MCBeansUtil.isNull(c, n) ? c.getTimestamp(n) : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setViewValue(Comparable<?> value, MCMessageList list) {
/* 138 */     if (list == null) {
/* 139 */       list = new MCMessageList();
/*     */     }
/* 141 */     if (value != null) {
/* 142 */       if (value instanceof MCTimestamp) {
/* 143 */         setValue((MCTimestamp)value, list);
/*     */       } else {
/*     */         
/* 146 */         list.add(MCBeansUtil.createCauseMsg(this, Core_Msg_FW_A.FCBAC0087, new Object[0]));
/*     */       } 
/*     */     } else {
/*     */       
/* 150 */       setValue((MCTimestamp)null, list);
/*     */     } 
/*     */   }
/*     */   
/*     */   public MCTimestamp today() {
/*     */     MCTimestamp v;
/* 156 */     MCRootPanel p = getRootPanel();
/* 157 */     if (p == null) {
/* 158 */       return MCTimestamp.today();
/*     */     }
/*     */     
/*     */     try {
/* 162 */       v = (MCTimestamp)p.today(MCDataType.TIMESTAMP);
/*     */     }
/* 164 */     catch (Exception exception) {
/* 165 */       v = null;
/*     */     } 
/* 167 */     return (v != null) ? v : MCTimestamp.today();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doAfterInsert() {
/* 172 */     if (!isPopupVisible()) {
/*     */       return;
/*     */     }
/*     */     
/* 176 */     SwingUtilities.invokeLater(new Runnable()
/*     */         {
/*     */           public void run()
/*     */           {
/* 180 */             if (!"list".equals(MCTimestampComboBox.this.getListConfig().getOpeType())) {
/*     */               return;
/*     */             }
/* 183 */             MCRow o = MCTimestampComboBox.this.getModel().getSelectedRow();
/* 184 */             if (o != null) {
/* 185 */               MCTimestampFormat f = MCTimestampComboBox.this.getCalendarFormat();
/* 186 */               String m = f.doInputFormat((MCCalendarDate)o.getTimestamp(MCTimestampComboBox.this.getKeyColumnName()));
/*     */               
/* 188 */               MCTimestamp ts = null;
/*     */               try {
/* 190 */                 ts = MCTimestampComboBox.this.getValue();
/*     */               }
/* 192 */               catch (MCException mCException) {
/* 193 */                 MCTimestampComboBox.this.doIncrementalSearch();
/*     */                 return;
/*     */               } 
/* 196 */               String v = f.doInputFormat((MCCalendarDate)ts);
/*     */ 
/*     */               
/* 199 */               if (MCStringUtil.eq(m, v)) {
/*     */                 return;
/*     */               }
/*     */             } 
/* 203 */             MCTimestampComboBox.this.doIncrementalSearch();
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   protected boolean doIncrementalSearch() {
/* 209 */     String v = getText();
/* 210 */     if (MCStringUtil.isNull(v)) {
/* 211 */       return false;
/*     */     }
/*     */     
/* 214 */     MCList<?> l = getList();
/* 215 */     if (l == null) {
/* 216 */       return false;
/*     */     }
/*     */     
/* 219 */     boolean e = MCBeansProxy.PROXY.isEventEnabled();
/*     */     
/* 221 */     try { MCBeansProxy.PROXY.setEventEnabled(false);
/* 222 */       String n = getKeyColumnName();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */        }
/*     */     
/*     */     finally
/*     */     
/*     */     { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 247 */       MCBeansProxy.PROXY.setEventEnabled(e); }  MCBeansProxy.PROXY.setEventEnabled(e);
/*     */     
/* 249 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public Comparable<?> _adjustValueByFormat(Comparable<?> value) {
/* 254 */     if (value instanceof MCTimestamp) {
/* 255 */       return (Comparable<?>)MCBeansProxy.PROXY.adjustValueByFormat(
/* 256 */           (MCCalendarDate<?>)value, getCalendarFormat().getInputPattern());
/*     */     }
/* 258 */     return value;
/*     */   }
/*     */   
/*     */   protected class MCTimestampComboField extends MCCalendarComboBox<MCTimestamp>.MCCalendarComboField {}
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\combobox\MCTimestampComboBox.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */