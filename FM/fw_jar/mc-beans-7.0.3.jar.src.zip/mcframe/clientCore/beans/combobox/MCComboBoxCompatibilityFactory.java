/*    */ package mcframe.clientCore.beans.combobox;
/*    */ 
/*    */ public class MCComboBoxCompatibilityFactory {
/*    */   public static MCDateComboBox createDateComboBox(String name) {
/*  5 */     return new MCDateComboBox(name);
/*    */   }
/*    */   
/*    */   public static MCNumberComboBox createNumberComboBox(String name) {
/*  9 */     return new MCNumberComboBox(name);
/*    */   }
/*    */   
/*    */   public static MCTextComboBox createTextComboBox(String name) {
/* 13 */     return new MCTextComboBox(name);
/*    */   }
/*    */   
/*    */   public static MCTimestampComboBox createTimestampComboBox(String name) {
/* 17 */     return new MCTimestampComboBox(name);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\combobox\MCComboBoxCompatibilityFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */