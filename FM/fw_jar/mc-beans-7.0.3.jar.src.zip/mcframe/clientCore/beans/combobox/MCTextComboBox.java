/*     */ package mcframe.clientCore.beans.combobox;
/*     */ 
/*     */ import java.awt.Font;
/*     */ import java.awt.event.InputMethodEvent;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.regex.Pattern;
/*     */ import java.util.regex.PatternSyntaxException;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.text.Document;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCMode;
/*     */ import mcframe.clientCore.beans.MCPluralValueField;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.list.MCListType;
/*     */ import mcframe.clientCore.beans.text.MCDocumentBeans;
/*     */ import mcframe.clientCore.beans.text.MCIMDelegate;
/*     */ import mcframe.clientCore.beans.text.MCInputMethodType;
/*     */ import mcframe.clientCore.beans.text.MCTextDocument;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCMessageList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCTextComboBox
/*     */   extends MCFieldComboBox<String>
/*     */   implements MCDocumentBeans, MCPluralValueField
/*     */ {
/*  53 */   private int _max_len = Integer.MAX_VALUE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String _trim_ptn;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean _input_method_editing = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   private List<Pattern> _accept_ptn = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   private List<Character> _except_chars = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   private MCInputMethodType _input_method_type = MCInputMethodType.NONE; private MCIMDelegate _im_delegate; private boolean _plural_value_enable; protected String getTrimPatternKey() { return MCConst.createKey(new String[] { getType(), "trim" }); }
/*     */   protected MCTextComboField getComboField() { return (MCTextComboField)super.getComboField(); }
/*     */   protected MCTextComboField createComboField() { return new MCTextComboField(); }
/*     */   public String getType() { return "combo"; }
/*     */   public List<Pattern> getAcceptPattern() { if (this._accept_ptn != null)
/*     */       return this._accept_ptn;  String k = MCConst.createKey(new String[] { getType(), "accept" }); String p = MCConst.beans.getString(k); if (p != null)
/*     */       setAcceptPattern(p);  return this._accept_ptn; }
/*     */   public void setAcceptPattern(List<Pattern> l) { this._accept_ptn = l; }
/*     */   public void addAcceptPattern(String ptn) { List<Pattern> l = getAcceptPattern(); if (l == null) { setAcceptPattern(ptn); } else { addAcceptPattern(l, ptn); }  }
/*     */   public void addAcceptPattern(String ptn, int flags) { List<Pattern> l = getAcceptPattern(); if (l == null) { setAcceptPattern(ptn, flags); } else { addAcceptPattern(l, ptn, flags); }  }
/*     */   private void setAcceptPattern(String ptn) { this._accept_ptn = new ArrayList<>(); addAcceptPattern(this._accept_ptn, ptn); }
/*     */   private void setAcceptPattern(String ptn, int flags) { this._accept_ptn = new ArrayList<>(); addAcceptPattern(this._accept_ptn, ptn, flags); }
/*     */   private void addAcceptPattern(List<Pattern> l, String ptn) { try { l.add(Pattern.compile(ptn)); }
/*     */     catch (PatternSyntaxException patternSyntaxException) { throw new MCException(Core_Msg_FW_A.FCBAC0333, new Object[] { ptn }); }
/*     */      }
/*     */   private void addAcceptPattern(List<Pattern> l, String ptn, int flags) { try { l.add(Pattern.compile(ptn)); }
/*     */     catch (PatternSyntaxException patternSyntaxException) { throw new MCException(Core_Msg_FW_A.FCBAC0333, new Object[] { ptn, Integer.valueOf(flags) }); }
/*     */      }
/* 114 */   public MCTextComboBox(String name) { super(name);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 685 */     this._plural_value_enable = false; }
/*     */   public List<Character> getExceptCharacter() { if (this._except_chars != null) return this._except_chars;  String k = MCConst.createKey(new String[] { getType(), "except" }); String s = MCConst.beans.getString(k); if (s != null && s.length() > 0) setExceptCharacter(s.toCharArray());  return this._except_chars; }
/*     */   public void setExceptCharacter(List<Character> l) { this._except_chars = l; }
/*     */   public void setExceptCharacter(char[] cs) { this._except_chars = new ArrayList<>(); byte b; int i; char[] arrayOfChar; for (i = (arrayOfChar = cs).length, b = 0; b < i; ) { Character c = Character.valueOf(arrayOfChar[b]); this._except_chars.add(c); b++; }  }
/*     */   public void addExceptCharacter(char c) { List<Character> l = getExceptCharacter(); if (l == null) { this._except_chars = new ArrayList<>(); l = this._except_chars; }  l.add(Character.valueOf(c)); }
/*     */   public MCMessageList checkInputValue(String value) { return getValueChecker().checkInputValue(this, value); }
/*     */   public String getTrimPattern() { return this._trim_ptn; }
/*     */   public void setTrimPattern(String pattern) { this._trim_ptn = pattern; }
/*     */   protected void setResourceInfo(MCRootPanel panel) { super.setResourceInfo(panel); setResourceTrimPattern(panel); }
/*     */   protected void setResourceTrimPattern(MCRootPanel panel) { String t = MCBeansProxy.PROXY.getBeansString(getTrimPatternKey(), panel); if (t != null) setTrimPattern(t);  } protected void setMeta(MCMeta meta) { super.setMeta(meta); if (meta != null) setLength(meta.length());  } public void setLength(int length) { this._max_len = (length < 0) ? Integer.MAX_VALUE : length; } public int getLength() { return this._max_len; } public void doAfterInsert() { if (!isPopupVisible()) return;  SwingUtilities.invokeLater(new Runnable() {
/*     */           public void run() { if (!"list".equals(MCTextComboBox.this.getListConfig().getOpeType())) return;  MCRow o = MCTextComboBox.this.getModel().getSelectedRow(); if (o != null) { String c = o.getString(MCTextComboBox.this.getKeyColumnName()); String v = MCTextComboBox.this.getValue(); if (MCStringUtil.eq(c, v)) return;  }  MCTextComboBox.this.doIncrementalSearch(); }
/* 696 */         }); } private void setInputMethodEditing(boolean editing) { this._input_method_editing = editing; } public boolean isInputMethodEditing() { return this._input_method_editing; } public boolean checkInputValue(Comparable<?> value, MCMessageList list) { MCMessageList l = getValueChecker().checkInputValue(this, value); if (l.size() == 0) return true;  if (list != null) list.addAll((Collection)l);  return false; } public MCMessageList checkValue(Comparable<?> value) { return getValueChecker().checkValue(this, value); } public String getRowValue() { MCConstRow c = getBaseRow(); String n = getBaseRowColumnName(); return !MCBeansUtil.isNull(c, n) ? c.getString(n) : null; } void setPluralValueEnable(boolean enable) { if (MCConst.plugin.getBoolean(MCConst.createKey(new String[] { "ArrayValue", "invalid"
/* 697 */           }, ), false))
/*     */     
/* 699 */     { this._plural_value_enable = false; }
/*     */     else
/*     */     
/* 702 */     { this._plural_value_enable = enable; }  }
/*     */   public MCMessageList setValue(String value, MCMessageList list) { String v = (String)_adjustValue(value); v = MCBeansUtil._getExtractText(this, v); return super.setValue(v, list); }
/*     */   public void setViewValue(Comparable<?> value, MCMessageList list) { if (list == null) list = new MCMessageList();  if (value != null) { if (value instanceof String) { setValue((String)value, list); } else { list.add(MCBeansUtil.createCauseMsg(this, Core_Msg_FW_A.FCBAC0068, new Object[0])); }  } else { setValue((String)null, list); }  }
/*     */   public String getValue() { String t = getText(); String v = getTrimValue(t); if (!MCStringUtil.eq(t, v)) setText(v);  return !MCStringUtil.isNull(v) ? v : null; }
/*     */   private String getTrimValue(String value) { String v; if (!isPluralValueEnable()) { v = MCBeansProxy.PROXY.trim(value, getTrimPattern()); } else if (!MCStringUtil.isNull(value)) { String[] va = MCStringUtil.arrayValueSplit(value); for (int i = 0; i < va.length; i++) va[i] = MCBeansProxy.PROXY.trim(va[i], getTrimPattern());  v = MCStringUtil.arrayValueJoin(va); } else { v = null; }  return MCStringUtil.isNull(v) ? null : v; }
/*     */   public void setRowToView() { MCBeansUtil.checkThread(); MCConstRow o = getBaseRow(); String n = getBaseRowColumnName(); if (MCBeansUtil.isNull(o, n)) return;  String v = MCStringUtil.convertToLF(o.getString(n)); if (MCStringUtil.isNull(v)) v = null;  String t = getText(); if (MCStringUtil.isNull(t)) t = null;  if (!MCStringUtil.eq(v, t)) { MCEventProxy.PROXY.setValue(getEventInfo(), v, v); boolean e = MCBeansProxy.PROXY.isEventEnabled(); try { MCBeansProxy.PROXY.setEventEnabled(false); setText(v); } finally { MCBeansProxy.PROXY.setEventEnabled(e); }  }  getComboField().adjustText(); }
/*     */   public void setText(String text) { setDocumentEditable(true); boolean e = isAutoFocus(); try { setAutoFocus(false); getComboField().setText(text); } finally { if (MCListType.SELECT_ONLY == getListType())
/* 709 */         setDocumentEditable(false);  setAutoFocus(e); }  } public boolean isPluralValueEnable() { return this._plural_value_enable; } public Comparable<?> doListFormat(Comparable<?> value) { return value; } protected void setDocumentEditable(boolean editable) { Document d = getDocument(); if (d instanceof MCTextDocument) ((MCTextDocument)d).setEditable(editable);  } public void focusGained() { super.focusGained(); _installInputMethod(); } public void focusLost() { super.focusLost(); _uninstallInputMethod(); } public void setInputMethodType(MCInputMethodType type) { if (type == null) type = MCInputMethodType.NONE;  this._input_method_type = type; } public MCInputMethodType getInputMethodType() { if (MCMode.isDisable(this)) return MCInputMethodType.OFF;  return this._input_method_type; } private MCIMDelegate getIMDelegate() { return (this._im_delegate != null) ? this._im_delegate : (this._im_delegate = MCTextProxy.PROXY.createIMDelegate()); }
/*     */   @Deprecated protected void _installInputMethod() { MCTextProxy.PROXY.installInputMethod(getIMDelegate(), this, getInputMethodType()); }
/*     */   @Deprecated protected void _uninstallInputMethod() { MCTextProxy.PROXY.uninstallInputMethod(getIMDelegate(), this, getInputMethodType()); }
/*     */   public void enableInputMethods(boolean enable) { if (getInputMethodType() == MCInputMethodType.OFF) enable = false;  super.enableInputMethods(enable); getComboField().enableInputMethods(enable); }
/*     */   protected boolean doIncrementalSearch() { String v = getText(); if (MCStringUtil.isNull(v)) return false;  MCList<?> l = getList(); if (l == null) return false;  boolean e = MCBeansProxy.PROXY.isEventEnabled(); try { MCBeansProxy.PROXY.setEventEnabled(false); String n = getKeyColumnName(); } finally { MCBeansProxy.PROXY.setEventEnabled(e); }  MCBeansProxy.PROXY.setEventEnabled(e); return false; }
/*     */   protected Comparable<?> _adjustValue(Comparable<?> value) { if (value instanceof String) { String v = MCStringUtil.convertToLF((String)value); v = getTrimValue(v); return v; }  return value; }
/* 715 */   @Deprecated public boolean _isLastInsert() { if (isPluralValueEnable()) {
/* 716 */       return false;
/*     */     }
/*     */     
/* 719 */     return (getLength() == MCStringUtil.codePointCount(getText())); }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAutoFocus() {
/* 724 */     if (isPluralValueEnable()) {
/* 725 */       return false;
/*     */     }
/* 727 */     return super.isAutoFocus();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void execLink(MCRow row, boolean msg) {
/* 733 */     if (isPluralValueEnable()) {
/* 734 */       MCListType y = getListType();
/* 735 */       if ((MCListType.STRICT.equals(y) || MCListType.SELECT_ONLY.equals(y)) && 
/* 736 */         row == null && !MCStringUtil.isNull(getValue())) {
/* 737 */         MCList<?> l = getModel().getList();
/* 738 */         if (l != null) {
/* 739 */           if (l.size() > 0) {
/* 740 */             row = l.get(0).clone();
/* 741 */             row.clear();
/*     */           } else {
/*     */             
/* 744 */             row = l.createRow();
/*     */           } 
/*     */         } else {
/*     */           
/* 748 */           row = MCRow.create();
/*     */         } 
/* 750 */         String n = getKeyColumnName();
/* 751 */         if (!row.contains(n)) {
/* 752 */           row.addStringColumn(n);
/*     */         }
/* 754 */         row.setString(n, getValue());
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 759 */     super.execLink(row, msg);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isValueChanged(Comparable<?> view, Comparable<?> row) {
/* 764 */     return super.isValueChanged(_adjustValue(view), _adjustValue(row));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected class MCTextComboField
/*     */     extends MCFieldComboBox<String>.MCFieldComboField
/*     */   {
/*     */     protected void processInputMethodEvent(InputMethodEvent e) {
/* 791 */       if (!e.isConsumed() && isEditable()) {
/* 792 */         MCTextComboBox.this.setInputMethodEditing((e.getText() != null && 
/* 793 */             e.getCommittedCharacterCount() != e.getText().getEndIndex()));
/*     */       }
/* 795 */       super.processInputMethodEvent(e);
/*     */     }
/*     */ 
/*     */     
/*     */     protected Document createDefaultModel() {
/* 800 */       return (Document)new MCTextDocument(MCTextComboBox.this);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void enableInputMethods(boolean enable) {
/* 815 */       if (MCTextComboBox.this.getInputMethodType() == MCInputMethodType.OFF) {
/* 816 */         enable = false;
/*     */       }
/* 818 */       super.enableInputMethods(enable);
/*     */     }
/*     */ 
/*     */     
/*     */     public void paste() {
/* 823 */       Document o = getDocument();
/* 824 */       if (o instanceof MCTextDocument) {
/* 825 */         MCTextDocument d = (MCTextDocument)o;
/*     */         try {
/* 827 */           MCTextProxy.PROXY.setPasteActionProcessing(d, true);
/* 828 */           super.paste();
/*     */         } finally {
/*     */           
/* 831 */           MCTextProxy.PROXY.setPasteActionProcessing(d, false);
/*     */         } 
/*     */       } else {
/*     */         
/* 835 */         super.paste();
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   void _setFont(Font font) {
/* 841 */     setFont(font);
/*     */   }
/*     */ 
/*     */   
/*     */   public String convToMaximumValues(String before, int offs, String str) {
/* 846 */     return getValueChecker().convMaximumValues(this, before, offs, str);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\combobox\MCTextComboBox.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */