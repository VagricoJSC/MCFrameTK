package mcframe.clientCore.beans.barcode;

import java.awt.Component;
import java.util.ArrayList;
import javax.swing.JComponent;
import mcframe.clientCore.beans.MCBeans;
import mcframe.clientCore.beans.MCButton;
import mcframe.clientCore.beans.MCTabOrderBeans;

public interface MCBarcodeDelegate {
  public static final String barcodeStatusInit = "init";
  
  public static final String barcodeStatusEntryBarcode = "entry";
  
  public static final String barcodeStatusEntryOther = "other";
  
  public static final String barcodeStatusProcessing = "processing";
  
  public static final String barcodeStatusUser = "user";
  
  public static final String barcodeStatusPause = "pause";
  
  void updateBarcodeStatus();
  
  void doStopBarcode();
  
  void setSaveTabOrderList(ArrayList<MCTabOrderBeans> paramArrayList);
  
  void setUserMode();
  
  void setUserMode(boolean paramBoolean);
  
  void setEntryMode(boolean paramBoolean);
  
  void setProcessingMode();
  
  String getBarcodeStatus();
  
  void setBarcodeStatus(String paramString);
  
  void afterRequestFocusForBarcode(JComponent paramJComponent);
  
  void setDisableNextFocus2(boolean paramBoolean);
  
  void doNextFocusForBarcode(Object paramObject);
  
  void doEndFocusForBarcode(MCBeans paramMCBeans);
  
  void setFocus(Object paramObject, boolean paramBoolean);
  
  void doNextButton(MCButton paramMCButton);
  
  void setInitFlag(boolean paramBoolean);
  
  boolean isInitFlag();
  
  void setInitFlag2(boolean paramBoolean);
  
  boolean isInitFlag2();
  
  boolean hasHeaderBarFocus();
  
  void setPause(boolean paramBoolean);
  
  boolean isPause();
  
  MCButton getPausedButton();
  
  void setPausedButton(MCButton paramMCButton);
  
  void setPausedField(Component paramComponent);
  
  void doBarcodeContinue();
  
  void resetBarcodeBeans();
  
  void doButton(MCBeans paramMCBeans, boolean paramBoolean);
  
  void doNextButtonAction(MCBeans paramMCBeans, boolean paramBoolean);
  
  void doButtonAction(MCBeans paramMCBeans, boolean paramBoolean);
  
  boolean getDisableNextFocus4();
  
  void setDisableNextFocus4(boolean paramBoolean);
  
  void _nextButton(MCButton paramMCButton);
  
  void updateStatus();
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\barcode\MCBarcodeDelegate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */