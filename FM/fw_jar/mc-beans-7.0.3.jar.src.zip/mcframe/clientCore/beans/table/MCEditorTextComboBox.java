/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.util.List;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.border.Border;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCMode;
/*     */ import mcframe.clientCore.beans.MCResourceBeans;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.action.MCKeyActionManager;
/*     */ import mcframe.clientCore.beans.combobox.AbsMCComboBox;
/*     */ import mcframe.clientCore.beans.combobox.MCComboField;
/*     */ import mcframe.clientCore.beans.combobox.MCComboListModel;
/*     */ import mcframe.clientCore.beans.combobox.MCFieldComboBox;
/*     */ import mcframe.clientCore.beans.combobox.MCTextComboBox;
/*     */ import mcframe.clientCore.beans.list.MCLinkBeans;
/*     */ import mcframe.clientCore.beans.list.MCLinkedBeans;
/*     */ import mcframe.clientCore.beans.list.MCListConfig;
/*     */ import mcframe.clientCore.beans.list.MCListType;
/*     */ import mcframe.clientCore.beans.popup.MCPopupConfig;
/*     */ import mcframe.clientCore.beans.popup.MCPopupMenu;
/*     */ import mcframe.clientCore.beans.text.MCInputMethodType;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.clientCore.event.MCEventInfo;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCEditorTextComboBox
/*     */   extends MCTextComboBox
/*     */   implements MCEditorBeans
/*     */ {
/*  47 */   private MCTable<?> _table = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   private MCColumnConfig _column = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCEditorTextComboBox(String name, MCColumnConfig column) {
/*  67 */     super(name);
/*     */     
/*  69 */     setColumnConfig(column);
/*  70 */     setTable(column.getBaseTable());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getType() {
/*  75 */     return "table.column.combo";
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initBeans() {
/*  80 */     super.initBeans();
/*     */     
/*  82 */     setFocusTraversalKeysEnabled(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initKeyAssign() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initResource() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setTable(MCTable<?> table) {
/* 101 */     this._table = table;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCTable<?> getTable() {
/* 106 */     return this._table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setColumnConfig(MCColumnConfig column) {
/* 117 */     this._column = column;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCColumnConfig getColumnConfig() {
/* 122 */     return this._column;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getRowIndex() {
/* 127 */     return MCCellUtil.getRowIndex(this);
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCEditorComboField getComboField() {
/* 132 */     return (MCEditorComboField)super.getComboField();
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCEditorComboField createComboField() {
/* 137 */     return new MCEditorComboField();
/*     */   }
/*     */ 
/*     */   
/*     */   public void valueCommited() {
/* 142 */     MCTable<?> t = getTable();
/* 143 */     String o = getListConfig().getOpeType();
/*     */     
/* 145 */     String v = getValue();
/* 146 */     if ("input".equals(o)) {
/* 147 */       setSelectedItem(v);
/*     */     }
/* 149 */     else if ("list".equals(o) && 
/* 150 */       MCStringUtil.isNull(v)) {
/* 151 */       setSelectedItem(v);
/*     */     } 
/*     */ 
/*     */     
/* 155 */     MCRow row = getSelectedListRow();
/*     */     
/* 157 */     if ("input".equals(o)) {
/* 158 */       row = getListRow(getValue());
/*     */     }
/* 160 */     if (row == null && 
/* 161 */       getListType() == MCListType.FREE) {
/* 162 */       row = MCRow.create();
/* 163 */       MCBeansProxy.PROXY.addColumn(row, getListNames()[0], getDataType(), 
/* 164 */           getViewValue());
/*     */     } 
/*     */     
/* 167 */     MCEventInfo e = getEventInfo();
/* 168 */     String key = getKeyColumnName();
/* 169 */     if (MCBeansProxy.PROXY.haveLinkValuesNull(e, (MCLinkBeans)this, getValue(), getList(), key)) {
/* 170 */       MCRow r = row.clone();
/* 171 */       r.clear();
/* 172 */       r.setValue(key, e.getNewValue());
/* 173 */       ((MCTableColumn)getColumnConfig()).execLink(t.getMCEditingRow(), r, true);
/*     */     } else {
/*     */       
/* 176 */       ((MCTableColumn)getColumnConfig()).execLink(t.getMCEditingRow(), row, true);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Border getDefaultBorder() {
/* 182 */     return MCCellUtil.DEFAULT_BORDER;
/*     */   }
/*     */ 
/*     */   
/*     */   public void transferFocus() {
/* 187 */     MCTable<?> t = getTable();
/* 188 */     t.transferFocus(getRowIndex(), t.getViewColumn(getColumnConfig()) + 1, false, 
/* 189 */         true, true);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void execLink(MCRow row, boolean msg) {
/* 194 */     ((MCTableColumn)getColumnConfig()).execLink(getRowIndex(), row, msg);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canChange() {
/*     */     try {
/* 200 */       MCTable.setEditingStoppedEnabled(false);
/*     */ 
/*     */       
/* 203 */       MCEventInfo info = getTable().getEventInfo();
/* 204 */       MCEventProxy.PROXY.setIndex(info, getTable().getMCSelectedRow(), 
/* 205 */           info.getNewIndex());
/*     */       
/* 207 */       return super.canChange();
/*     */     } finally {
/*     */       
/* 210 */       MCTable.setEditingStoppedEnabled(true);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void setColumnInfo(int index, MCColumnConfig column) {
/* 215 */     setColumnConfig(column);
/* 216 */     MCTable<?> table = getTable();
/*     */     
/* 218 */     MCKeyActionManager.init((MCResourceBeans)this, getInputMap(1), 
/* 219 */         getActionMap());
/* 220 */     JComponent c = getComboField().getComponent();
/* 221 */     MCKeyActionManager.init((MCResourceBeans)this, c.getInputMap(), c.getActionMap());
/*     */     
/* 223 */     MCKeyActionManager.initScreen((MCResourceBeans)this, 
/* 224 */         getInputMap(1), getActionMap());
/* 225 */     MCKeyActionManager.initScreen((MCResourceBeans)this, c.getInputMap(), c.getActionMap());
/*     */     
/* 227 */     MCMode mode = MCCellUtil.isCellEditable(index, column, table);
/* 228 */     setMode(mode);
/* 229 */     setForeground(MCCellUtil.getForeground(index, column, table, false, mode));
/* 230 */     setBackground(MCCellUtil.getBackground(index, column, table, false, mode));
/* 231 */     setFont(column.getFont());
/* 232 */     setCaretColor(MCCellUtil.getCaretColor(index, column, table));
/* 233 */     setSelectionColor(MCCellUtil.getSelectionColor(index, column, table));
/* 234 */     setSelectedTextColor(MCCellUtil.getSelectedTextColor(index, column, table));
/* 235 */     setMeta(column.getMeta());
/* 236 */     setLength(column.getLength(index));
/* 237 */     setListVisibleColumn(column.getListVisibleColumn());
/* 238 */     setRow(column.getTable().getRow(index), column.getRowColumnName());
/* 239 */     setAutoFocus(column.isAutoFocus());
/* 240 */     setSelectAll(column.isSelectAll());
/* 241 */     MCListConfig lc = column.getListConfig();
/* 242 */     setListConfig(lc);
/* 243 */     if (lc.getListType() == MCListType.SELECT_ONLY) {
/* 244 */       setDocumentEditable(false);
/*     */     }
/*     */     
/* 247 */     setComboListConfig(column.getComboListConfig());
/*     */     
/* 249 */     setTrimPattern(column.getTrimPattern());
/* 250 */     Border border = MCCellUtil.getEditorBorder(index, column, table);
/* 251 */     if (border != null) {
/* 252 */       setBorder(border);
/*     */     } else {
/*     */       
/* 255 */       setBorder(getDefaultBorder());
/*     */     } 
/* 257 */     MCPopupMenu menu = getComponentPopupMenu();
/* 258 */     if (menu != null) {
/* 259 */       menu.updateResource();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setDummyColumnInfo(MCColumnConfig column, MCConstRow dummy) {
/* 270 */     setColumnConfig(column);
/*     */     
/* 272 */     setMeta(column.getMeta());
/* 273 */     setLength(column.getLength());
/*     */     
/* 275 */     if (dummy.contains(column.getBaseRowColumnName())) {
/* 276 */       setRow(dummy, column.getBaseRowColumnName());
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 283 */       setRow((MCConstRow)column.getTable().getList().createRow(), 
/* 284 */           column.getRowColumnName());
/*     */     } 
/* 286 */     setAutoFocus(false);
/* 287 */     setSelectAll(false);
/* 288 */     setTrimPattern(column.getTrimPattern());
/*     */   }
/*     */   
/*     */   public Border getBorder() {
/* 292 */     Border b = MCCellUtil.getBorder(this);
/* 293 */     return (b != null) ? b : super.getBorder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCRootPanel getRootPanel() {
/* 306 */     return MCCellUtil.getRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCRootPanel getNearestRootPanel() {
/* 311 */     return MCCellUtil.getNearestRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessageByLocale() {
/* 316 */     return getColumnConfig().getMessageByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLabelByLocale() {
/* 321 */     return getColumnConfig().getLabelByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterRequestFocus() {
/* 326 */     MCRootPanel bp = getBaseRootPanel();
/* 327 */     MCBeansUtil.afterRequestFocus(bp, getTable());
/* 328 */     MCBeansUtil.scrollRectToVisible(bp, (JComponent)this, 
/* 329 */         getComboField().getHorizontalAlignment());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 334 */     repaint();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFocusOwner() {
/* 339 */     MCTable<?> t = getTable();
/* 340 */     return (t != null) ? (t.isRemoveNotifyProcessing() ? super.isFocusOwner() : false) : 
/* 341 */       super.isFocusOwner();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValueChanged() {
/* 346 */     return isValueChanged(getRowValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValueChanged(Comparable<?> value) {
/* 351 */     return isValueChanged(getValue(), value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isValueChanged(Comparable<?> view, Comparable<?> row) {
/* 357 */     if (isInputMethodEditing()) {
/* 358 */       return true;
/*     */     }
/*     */     
/* 361 */     return MCCellUtil.isValueChanged(this, view, row);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasFocus() {
/* 366 */     MCTable<?> t = getTable();
/* 367 */     return (t != null) ? ((this == t.getMCEditorComponent())) : super.hasFocus();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isMCFocusOwner() {
/* 372 */     MCTable<?> t = getTable();
/* 373 */     return (t != null) ? ((t.getMCEditorComponent() == this)) : isFocusOwner();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCListType getListType() {
/* 378 */     MCColumnConfig c = getColumnConfig();
/* 379 */     return (c != null) ? c.getListType() : super.getListType();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCLinkedBeans[] getLinkBeans() {
/* 384 */     MCColumnConfig c = getColumnConfig();
/* 385 */     return (c != null) ? c.getLinkBeans() : super.getLinkBeans();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRowToViews() {
/* 390 */     boolean e = MCBeansProxy.PROXY.isEventEnabled();
/*     */     try {
/* 392 */       MCBeansProxy.PROXY.setEventEnabled(false);
/* 393 */       setRowToView();
/* 394 */       MCLinkedBeans[] cs = getLinkBeans(); byte b; int i; MCLinkedBeans[] arrayOfMCLinkedBeans1;
/* 395 */       for (i = (arrayOfMCLinkedBeans1 = cs).length, b = 0; b < i; ) { MCLinkedBeans c = arrayOfMCLinkedBeans1[b];
/* 396 */         if (c instanceof MCColumnConfig) {
/* 397 */           MCColumnConfig col = (MCColumnConfig)c;
/* 398 */           int j = getRowIndex();
/* 399 */           col.setValue(j, 
/* 400 */               getTable().getRow(j).getValue(col.getBaseRowColumnName()));
/*     */         } 
/*     */         b++; }
/*     */     
/*     */     } finally {
/* 405 */       MCBeansProxy.PROXY.setEventEnabled(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCList doListEventEx() {
/* 414 */     MCTableColumn c = (MCTableColumn)getColumnConfig();
/* 415 */     MCEventProxy.PROXY.setEventIndex(c.getEventInfo(), getRowIndex());
/* 416 */     return c.doListEventEx();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCList doListEvent() {
/*     */     try {
/* 422 */       MCColumnConfig c = getColumnConfig();
/* 423 */       MCEventProxy.PROXY.setEventIndex(c.getEventInfo(), getRowIndex());
/* 424 */       return c.doListEvent();
/*     */     }
/* 426 */     catch (MCException e) {
/* 427 */       handle((Throwable)e);
/*     */       
/* 429 */       setRowToViews();
/*     */       
/* 431 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean doListEventWithNull() {
/* 436 */     MCColumnConfig c = getColumnConfig();
/* 437 */     return (c != null) ? c.doListEventWithNull() : false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean haveLinkValuesNullWhenDupliKeyTyped() {
/* 442 */     MCColumnConfig c = getColumnConfig();
/* 443 */     return (c != null) ? c.haveLinkValuesNullWhenDupliKeyTyped() : false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean doVC() {
/* 448 */     return getColumnConfig().doVC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNC() {
/* 453 */     getColumnConfig().doNC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNE() {
/* 458 */     getColumnConfig().doNE();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNX() {
/* 463 */     getColumnConfig().doNX();
/*     */     
/* 465 */     getListConfig().setOpeType("input");
/*     */   }
/*     */ 
/*     */   
/*     */   public void doLC() {
/* 470 */     getColumnConfig().doLC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doDC() {
/* 475 */     getColumnConfig().doDC();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void focusGained() {
/* 481 */     focusGainedSelect();
/*     */     
/* 483 */     _installInputMethod();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void focusLost() {
/* 489 */     _uninstallInputMethod();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCEventInfo getEventInfo() {
/* 494 */     return getColumnConfig().getEventInfo();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource(MCRootPanel panel) {}
/*     */ 
/*     */   
/*     */   public void doCheckValueError() {
/* 507 */     super.doCheckValueError();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCPopupConfig getPopupConfig() {
/* 512 */     MCTable<?> t = getTable();
/* 513 */     return (t != null) ? t.getPopupConfig() : null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCPopupMenu configurePopup(MCPopupMenu menu) {
/* 518 */     MCPopupConfig pc = getPopupConfig();
/* 519 */     return (pc != null) ? 
/* 520 */       pc.configurePopup(menu, getTable(), getRowIndex(), getColumnConfig()) : 
/* 521 */       menu;
/*     */   }
/*     */ 
/*     */   
/*     */   public void processKeyEvent(KeyEvent e) {
/* 526 */     MCCellUtil.beforeKeyEvent(e, this);
/* 527 */     super.processKeyEvent(e);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Pattern> getAcceptPattern() {
/* 532 */     return getColumnConfig().getAcceptPattern();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Character> getExceptCharacter() {
/* 537 */     return getColumnConfig().getExceptCharacter();
/*     */   }
/*     */ 
/*     */   
/*     */   public Comparable<?> doListFormat(Comparable<?> value) {
/* 542 */     return getColumnConfig().doListFormat(getRowIndex(), value);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Color getListForeground(MCRow row, boolean selected) {
/* 547 */     MCColumnConfig c = getColumnConfig();
/* 548 */     return getComboListConfig().getRowForeground(c, getRowIndex(), c.getTable(), row, 
/* 549 */         selected);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Color getListBackground(MCRow row, boolean selected) {
/* 554 */     MCColumnConfig c = getColumnConfig();
/* 555 */     return getComboListConfig().getRowBackground(c, getRowIndex(), c.getTable(), row, 
/* 556 */         selected);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCInputMethodType getInputMethodType() {
/* 561 */     MCColumnConfig c = getColumnConfig();
/* 562 */     return (c != null) ? c.getInputMethodType() : super.getInputMethodType();
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCEditorComboListModel createModel() {
/* 567 */     return new MCEditorComboListModel(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected class MCEditorComboField
/*     */     extends MCTextComboBox.MCTextComboField
/*     */   {
/*     */     protected MCEditorComboField() {
/* 585 */       super(MCEditorTextComboBox.this);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void initBeans() {
/* 590 */       super.initBeans();
/*     */       
/* 592 */       setFocusTraversalKeysEnabled(false);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isRequestFocusEnabled() {
/* 598 */       MCTable<?> t = MCEditorTextComboBox.this.getTable();
/* 599 */       if (!t.equalsIgnoreCase(MCBeansUtil.getFocusOwner(t)) && 
/* 600 */         !t.isRequestFocusEnabled()) {
/* 601 */         return false;
/*     */       }
/*     */       
/* 604 */       return super.isRequestFocusEnabled();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isMCRequestFocusEnabled() {
/* 609 */       return MCCellUtil.isFocusable(MCEditorTextComboBox.this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected class MCEditorComboListModel
/*     */     extends MCComboListModel<String>
/*     */   {
/*     */     protected MCEditorComboListModel(MCEditorTextComboBox compo) {
/* 630 */       super((AbsMCComboBox)compo);
/*     */     }
/*     */ 
/*     */     
/*     */     protected MCEditorTextComboBox getComboBox() {
/* 635 */       return (MCEditorTextComboBox)super.getComboBox();
/*     */     }
/*     */ 
/*     */     
/*     */     protected int getNewListIndex() {
/* 640 */       MCEditorTextComboBox compo = getComboBox();
/* 641 */       int index = compo.getRowIndex();
/* 642 */       MCTableColumn column = (MCTableColumn)compo.getColumnConfig();
/* 643 */       return column.getNewListIndex(index);
/*     */     }
/*     */ 
/*     */     
/*     */     protected int getOldListIndex() {
/* 648 */       MCEditorTextComboBox compo = getComboBox();
/* 649 */       int index = compo.getRowIndex();
/* 650 */       MCTableColumn column = (MCTableColumn)compo.getColumnConfig();
/* 651 */       return column.getOldListIndex(index);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void setNewListIndex(int index) {
/* 656 */       MCEditorTextComboBox compo = getComboBox();
/* 657 */       int row = compo.getRowIndex();
/* 658 */       MCTableColumn column = (MCTableColumn)compo.getColumnConfig();
/* 659 */       column.setNewListIndex(row, Integer.valueOf(index));
/*     */     }
/*     */ 
/*     */     
/*     */     protected void setOldListIndex(int index) {
/* 664 */       MCEditorTextComboBox compo = getComboBox();
/* 665 */       int row = compo.getRowIndex();
/* 666 */       MCTableColumn column = (MCTableColumn)compo.getColumnConfig();
/* 667 */       column.setOldListIndex(row, Integer.valueOf(index));
/*     */     }
/*     */ 
/*     */     
/*     */     protected int getSelectedIndex() {
/* 672 */       MCEditorTextComboBox compo = getComboBox();
/* 673 */       int index = compo.getRowIndex();
/* 674 */       MCTableColumn column = (MCTableColumn)compo.getColumnConfig();
/* 675 */       return (column != null) ? column.getSelectedListIndex(index) : 
/* 676 */         super.getSelectedIndex();
/*     */     }
/*     */ 
/*     */     
/*     */     protected void setSelectedIndex(int index) {
/* 681 */       super.setSelectedIndex(index);
/* 682 */       MCEditorTextComboBox compo = getComboBox();
/* 683 */       int row = compo.getRowIndex();
/* 684 */       MCTableColumn column = (MCTableColumn)compo.getColumnConfig();
/* 685 */       if (column != null) {
/* 686 */         column.setSelectedListIndex(row, Integer.valueOf(index));
/*     */       } else {
/*     */         
/* 689 */         super.setSelectedIndex(index);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCEditorTextComboBox.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */