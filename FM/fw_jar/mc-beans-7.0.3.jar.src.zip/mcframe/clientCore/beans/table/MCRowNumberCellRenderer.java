/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.border.Border;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCRowNumberCellRenderer
/*     */   extends JButton
/*     */   implements MCInfraCellRenderer
/*     */ {
/*     */   private final MCColumnConfig _column;
/*     */   private Border _default_border;
/*     */   
/*     */   protected MCRowNumberCellRenderer(MCColumnConfig column) {
/*  49 */     this._default_border = null;
/*     */     this._column = column;
/*     */     setOpaque(true);
/*     */     setHorizontalAlignment(4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCColumnConfig getColumnConfig() {
/*  59 */     return this._column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setDefaultBorder(Border border) {
/*  71 */     this._default_border = border;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Border getDefaultBorder() {
/*  88 */     return this._default_border;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Component getTableCellRendererComponent(JTable table, Object value, boolean selected, boolean focused, int index, int column) {
/* 106 */     return getRenderer((MCTable)table, value, selected, focused, index, 
/* 107 */         getColumnConfig());
/*     */   }
/*     */ 
/*     */   
/*     */   protected Component getRenderer(MCTable<?> table, Object value, boolean selected, boolean focused, int index, MCColumnConfig column) {
/*     */     try {
/* 113 */       Border def_border = getDefaultBorder();
/* 114 */       if (def_border == null) {
/* 115 */         setDefaultBorder(getBorder());
/*     */       }
/* 117 */       MCCellConfig conf = column.getCellConfig();
/* 118 */       setForeground(conf.getRowNumberColumnForeground(index, column, table, 
/* 119 */             selected));
/* 120 */       setBackground(conf.getRowNumberColumnBackground(index, column, table, 
/* 121 */             selected));
/* 122 */       setBorder(conf.getRowNumberColumnBorder(index, column, table, selected));
/* 123 */       setFont(column.getFont());
/* 124 */       setText(conf.getRowNumberColumnValue(index, column, table, selected));
/*     */     }
/* 126 */     catch (RuntimeException e) {
/* 127 */       MCCellUtil.preHandle(table, e);
/* 128 */       MCCellUtil.handle(table, e);
/*     */     } 
/* 130 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Comparable<?> getValue() {
/* 135 */     return getText();
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCRowNumberCellRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */