/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.util.List;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.border.Border;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCMode;
/*     */ import mcframe.clientCore.beans.MCPasswordField;
/*     */ import mcframe.clientCore.beans.MCResourceBeans;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.action.MCKeyActionManager;
/*     */ import mcframe.clientCore.beans.popup.MCPopupConfig;
/*     */ import mcframe.clientCore.beans.popup.MCPopupMenu;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.clientCore.event.MCEventInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCEditorPasswordField
/*     */   extends MCPasswordField
/*     */   implements MCEditorBeans
/*     */ {
/*     */   private static final String TYPE = "table.column.password";
/*     */   private MCColumnConfig _column;
/*     */   private MCTable<?> _table;
/*     */   
/*     */   protected MCEditorPasswordField(String name, MCColumnConfig column) {
/*  64 */     super(name);
/*  65 */     setColumnConfig(column);
/*  66 */     setTable(column.getBaseTable());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getType() {
/*  71 */     return "table.column.password";
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initBeans() {
/*  76 */     super.initBeans();
/*     */ 
/*     */     
/*  79 */     setFocusTraversalKeysEnabled(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initKeyAssign() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initResource() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setColumnConfig(MCColumnConfig column) {
/* 110 */     this._column = column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCColumnConfig getColumnConfig() {
/* 122 */     return this._column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setTable(MCTable<?> table) {
/* 133 */     this._table = table;
/*     */   }
/*     */ 
/*     */   
/*     */   public final MCTable getTable() {
/* 138 */     return this._table;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getRowIndex() {
/* 144 */     return MCCellUtil.getRowIndex(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void transferFocus() {
/* 149 */     MCTable<?> t = getTable();
/* 150 */     t.transferFocus(getRowIndex(), t.getViewColumn(getColumnConfig()) + 1, false, 
/* 151 */         true, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public Border getDefaultBorder() {
/* 156 */     return MCCellUtil.DEFAULT_BORDER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setColumnInfo(int index, MCColumnConfig column) {
/* 168 */     setColumnConfig(column);
/* 169 */     MCTable<?> table = getTable();
/* 170 */     MCKeyActionManager.init((MCResourceBeans)this, getInputMap(), getActionMap());
/* 171 */     MCKeyActionManager.initScreen((MCResourceBeans)this, getInputMap(), getActionMap());
/* 172 */     MCMode mode = MCCellUtil.isCellEditable(index, column, table);
/* 173 */     setMode(mode);
/* 174 */     setForeground(MCCellUtil.getForeground(index, column, table, false, mode));
/* 175 */     setBackground(MCCellUtil.getBackground(index, column, table, false, mode));
/* 176 */     setFont(column.getFont());
/* 177 */     setCaretColor(MCCellUtil.getCaretColor(index, column, table));
/* 178 */     setSelectionColor(MCCellUtil.getSelectionColor(index, column, table));
/* 179 */     setSelectedTextColor(MCCellUtil.getSelectedTextColor(index, column, table));
/* 180 */     setMeta(column.getMeta());
/* 181 */     setLength(column.getLength(index));
/* 182 */     setEchoChar(column.getEchoChar());
/* 183 */     setRow(column.getTable().getRow(index), column.getRowColumnName());
/*     */     
/* 185 */     setAutoFocus(column.isAutoFocus());
/* 186 */     setSelectAll(column.isSelectAll());
/* 187 */     setTrimPattern(column.getTrimPattern());
/* 188 */     Border border = MCCellUtil.getEditorBorder(index, column, table);
/* 189 */     if (border != null) {
/* 190 */       setBorder(border);
/*     */     } else {
/*     */       
/* 193 */       setBorder(getDefaultBorder());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setDummyColumnInfo(MCColumnConfig column, MCConstRow dummy) {
/* 204 */     setColumnConfig(column);
/* 205 */     MCKeyActionManager.init((MCResourceBeans)this, getInputMap(), getActionMap());
/* 206 */     MCKeyActionManager.initScreen((MCResourceBeans)this, getInputMap(), getActionMap());
/* 207 */     setMeta(column.getMeta());
/* 208 */     setLength(column.getLength());
/*     */     
/* 210 */     if (dummy.contains(column.getBaseRowColumnName())) {
/* 211 */       setRow(dummy, column.getBaseRowColumnName());
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 218 */       setRow((MCConstRow)column.getTable().getList().createRow(), 
/* 219 */           column.getRowColumnName());
/*     */     } 
/*     */     
/* 222 */     setAutoFocus(false);
/* 223 */     setSelectAll(false);
/* 224 */     setTrimPattern(column.getTrimPattern());
/*     */   }
/*     */   
/*     */   public MCRootPanel getRootPanel() {
/* 228 */     return MCCellUtil.getRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCRootPanel getNearestRootPanel() {
/* 233 */     return MCCellUtil.getNearestRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessageByLocale() {
/* 238 */     return getColumnConfig().getMessageByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLabelByLocale() {
/* 243 */     return getColumnConfig().getLabelByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterRequestFocus() {
/* 248 */     MCRootPanel bp = getBaseRootPanel();
/* 249 */     MCBeansUtil.afterRequestFocus(bp, getTable());
/* 250 */     MCBeansUtil.scrollRectToVisible(bp, (JComponent)this, getHorizontalAlignment());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 255 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void commitValue() {}
/*     */ 
/*     */   
/*     */   public boolean isFocusOwner() {
/* 264 */     MCTable<?> t = getTable();
/* 265 */     return (t != null) ? (t.isRemoveNotifyProcessing() ? super.isFocusOwner() : false) : 
/* 266 */       super.isFocusOwner();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValueChanged() {
/* 271 */     return isValueChanged(getRowValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValueChanged(Comparable<?> value) {
/* 285 */     return isValueChanged(getValue(), value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isValueChanged(Comparable<?> view, Comparable<?> row) {
/* 291 */     if (isInputMethodEditing()) {
/* 292 */       return true;
/*     */     }
/*     */     
/* 295 */     return MCCellUtil.isValueChanged(this, view, row);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void valueCommited() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean doVC() {
/* 305 */     return getColumnConfig().doVC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNC() {
/* 310 */     getColumnConfig().doNC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNE() {
/* 315 */     getColumnConfig().doNE();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNX() {
/* 320 */     getColumnConfig().doNX();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doDC() {
/* 325 */     getColumnConfig().doDC();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isMCFocusOwner() {
/* 330 */     MCTable<?> t = getTable();
/* 331 */     return (t != null) ? ((t.getMCEditorComponent() == this)) : isFocusOwner();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCEventInfo getEventInfo() {
/* 336 */     return getColumnConfig().getEventInfo();
/*     */   }
/*     */ 
/*     */   
/*     */   public void focusGained() {
/* 341 */     focusGainedSelect();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void focusLost() {}
/*     */ 
/*     */   
/*     */   public boolean isRequestFocusEnabled() {
/* 350 */     return (MCCellUtil.isRequestFocusEnabled(this) && super.isRequestFocusEnabled());
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isMCRequestFocusEnabled() {
/* 355 */     return MCCellUtil.isFocusable(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public Border getBorder() {
/* 360 */     Border b = MCCellUtil.getBorder(this);
/* 361 */     return (b != null) ? b : super.getBorder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource(MCRootPanel panel) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doCheckValueError() {
/* 386 */     super.doCheckValueError();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCPopupConfig getPopupConfig() {
/* 391 */     MCTable<?> t = getTable();
/* 392 */     return (t != null) ? t.getPopupConfig() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCPopupMenu configurePopup(MCPopupMenu menu) {
/* 406 */     MCPopupConfig pc = getPopupConfig();
/* 407 */     return (pc != null) ? 
/* 408 */       pc.configurePopup(menu, getTable(), getRowIndex(), getColumnConfig()) : 
/* 409 */       menu;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void processKeyEvent(KeyEvent e) {
/* 414 */     MCCellUtil.beforeKeyEvent(e, this);
/* 415 */     super.processKeyEvent(e);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Pattern> getAcceptPattern() {
/* 420 */     return getColumnConfig().getAcceptPattern();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Character> getExceptCharacter() {
/* 425 */     return getColumnConfig().getExceptCharacter();
/*     */   }
/*     */ 
/*     */   
/*     */   public Comparable<?> doListFormat(Comparable<?> value) {
/* 430 */     return getColumnConfig().doListFormat(getRowIndex(), value);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCEditorPasswordField.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */