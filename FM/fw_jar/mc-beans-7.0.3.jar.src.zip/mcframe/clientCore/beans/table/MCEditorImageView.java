/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.event.FocusListener;
/*     */ import java.awt.event.KeyEvent;
/*     */ import javax.swing.border.Border;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCImageView;
/*     */ import mcframe.clientCore.beans.MCMode;
/*     */ import mcframe.clientCore.beans.MCResourceBeans;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.action.MCKeyActionManager;
/*     */ import mcframe.clientCore.beans.popup.MCImagePanelInfo;
/*     */ import mcframe.clientCore.event.MCEventInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCEditorImageView
/*     */   extends MCImageView
/*     */   implements MCEditorBeans
/*     */ {
/*     */   private static final String TYPE = "table.column.imageview";
/*     */   private MCColumnConfig _column;
/*     */   private MCTable<?> _table;
/*     */   
/*     */   protected MCEditorImageView(String name, MCColumnConfig column) {
/*  61 */     super(name);
/*  62 */     setColumnConfig(column);
/*  63 */     setTable(column.getBaseTable());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initBeans() {
/*  68 */     super.initBeans();
/*  69 */     setHorizontalAlignment(0);
/*  70 */     setFocusTraversalKeysEnabled(false);
/*  71 */     setBorder(MCCellUtil.DEFAULT_BORDER); byte b; int i; FocusListener[] arrayOfFocusListener;
/*  72 */     for (i = (arrayOfFocusListener = getFocusListeners()).length, b = 0; b < i; ) { FocusListener l = arrayOfFocusListener[b];
/*  73 */       removeFocusListener(l);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initKeyAssign() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initResource() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getType() {
/*  97 */     return "table.column.imageview";
/*     */   }
/*     */ 
/*     */   
/*     */   public void transferFocus() {
/* 102 */     MCTable<?> t = getTable();
/* 103 */     t.transferFocus(getRowIndex(), t.getViewColumn(getColumnConfig()) + 1, 
/* 104 */         false, true, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCRootPanel getRootPanel() {
/* 109 */     return MCCellUtil.getRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCRootPanel getNearestRootPanel() {
/* 114 */     return MCCellUtil.getNearestRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessageByLocale() {
/* 119 */     return getColumnConfig().getMessageByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLabelByLocale() {
/* 124 */     return getColumnConfig().getLabelByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public void commitValue() {
/* 129 */     getTable().commitValue();
/*     */   }
/*     */   
/*     */   public Border getDefaultBorder() {
/* 133 */     return MCCellUtil.DEFAULT_BORDER;
/*     */   }
/*     */   
/*     */   public final int getRowIndex() {
/* 137 */     return MCCellUtil.getRowIndex(this);
/*     */   }
/*     */   
/*     */   public void valueCommited() {
/* 141 */     MCEventProxy.PROXY.setValue(getEventInfo(), (Comparable<?>)getRowValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setColumnConfig(MCColumnConfig column) {
/* 152 */     this._column = column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCColumnConfig getColumnConfig() {
/* 163 */     return this._column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setTable(MCTable<?> table) {
/* 174 */     this._table = table;
/*     */   }
/*     */   
/*     */   public final MCTable<?> getTable() {
/* 178 */     return this._table;
/*     */   }
/*     */ 
/*     */   
/*     */   public void doCheckValueError() {
/* 183 */     super.doCheckValueError();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setColumnInfo(int index, MCColumnConfig column) {
/* 195 */     setColumnConfig(column);
/* 196 */     MCTable<?> table = getTable();
/* 197 */     MCKeyActionManager.init((MCResourceBeans)this, getInputMap(), getActionMap());
/* 198 */     MCKeyActionManager.initScreen((MCResourceBeans)this, getInputMap(), getActionMap());
/* 199 */     MCMode mode = MCCellUtil.isCellEditable(index, column, table);
/* 200 */     setMode(mode);
/* 201 */     setForeground(MCCellUtil.getForeground(index, column, table, false, mode));
/* 202 */     setBackground(MCCellUtil.getBackground(index, column, table, false, mode));
/* 203 */     setFont(column.getFont());
/* 204 */     setMeta(column.getMeta());
/* 205 */     setRow(column.getTable().getRow(index), column.getRowColumnName());
/* 206 */     Border border = MCCellUtil.getEditorBorder(index, column, table);
/* 207 */     if (border != null) {
/* 208 */       setBorder(border);
/*     */     } else {
/* 210 */       setBorder(getDefaultBorder());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFocusOwner() {
/* 216 */     MCTable<?> t = getTable();
/* 217 */     return (t != null) ? (
/* 218 */       t.isRemoveNotifyProcessing() ? super.isFocusOwner() : false) : 
/* 219 */       super.isFocusOwner();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValueChanged() {
/* 224 */     return isValueChanged((Comparable<?>)getRowValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValueChanged(Comparable<?> value) {
/* 238 */     return isValueChanged((Comparable<?>)getValue(), value);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isValueChanged(Comparable<?> view, Comparable<?> row) {
/* 243 */     return MCCellUtil.isValueChanged(this, view, row);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean doVC() {
/* 248 */     return getColumnConfig().doVC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNC() {
/* 253 */     getColumnConfig().doNC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNE() {
/* 258 */     getColumnConfig().doNE();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNX() {
/* 263 */     getColumnConfig().doNX();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCEventInfo getEventInfo() {
/* 268 */     return getColumnConfig().getEventInfo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void focusGained() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void focusLost() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Border getBorder() {
/* 291 */     Border b = MCCellUtil.getBorder(this);
/* 292 */     return (b != null) ? b : super.getBorder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource(MCRootPanel panel) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterRequestFocus() {
/* 316 */     MCBeansUtil.afterRequestFocus(getTable());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void processKeyEvent(KeyEvent e) {
/* 321 */     MCCellUtil.beforeKeyEvent(e, this);
/* 322 */     super.processKeyEvent(e);
/*     */   }
/*     */ 
/*     */   
/*     */   public Comparable<?> doListFormat(Comparable<?> value) {
/* 327 */     return getColumnConfig().doListFormat(getRowIndex(), value);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isImagePanelEnabled() {
/* 332 */     return getColumnConfig().isImagePanelEnabled();
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getImagePanelID() {
/* 337 */     return getColumnConfig().getImagePanelID();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCImagePanelInfo getImagePanelInfo() {
/* 342 */     return getColumnConfig().getImagePanelInfo();
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected MCImagePanelInfo _createImagePanelInfo() {
/* 348 */     MCImagePanelInfo i = super._createImagePanelInfo();
/*     */     
/* 350 */     i.setLinkComponent(getColumnConfig(), getRowIndex());
/* 351 */     return i;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public final void focusGainedSelect() {}
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCEditorImageView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */