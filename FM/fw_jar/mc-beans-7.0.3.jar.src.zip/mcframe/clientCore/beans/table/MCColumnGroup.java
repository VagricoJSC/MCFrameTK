/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.table.TableColumn;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCColumnGroup
/*     */   implements MCColumnGroupMember
/*     */ {
/*     */   private MCTableColumn column;
/*     */   private List<MCColumnGroupMember> member;
/*     */   
/*     */   public MCColumnGroup(String name) {
/*  60 */     this.member = new ArrayList<>();
/*     */     
/*  62 */     this.column = new MCTableColumn(name, MCColumnType.NULL);
/*  63 */     this.column.setCellEditor(null);
/*  64 */     this.column.setToolTipEnabled(false);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  69 */     return this.column.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setTable(MCColumnGroupTable<?> table) {
/*  82 */     MCTable<?> mctable = table;
/*  83 */     this.column.setTable(mctable);
/*  84 */     this.column.updateResource();
/*  85 */     this.column.setInitWidth();
/*     */ 
/*     */     
/*  88 */     int size = this.member.size();
/*  89 */     for (int i = 0; i < size; i++) {
/*  90 */       MCColumnGroupMember obj = this.member.get(i);
/*  91 */       if (obj instanceof MCColumnGroup) {
/*  92 */         MCColumnGroup cg = (MCColumnGroup)obj;
/*  93 */         cg.setTable(table);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCColumnGroupTable<?> getTable() {
/* 106 */     return (MCColumnGroupTable)this.column.getTable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCTableColumn getColumn() {
/* 117 */     return this.column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addAliasName(String alias, MCRootPanel panel) {
/* 136 */     this.column.addAliasName(alias, panel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAliasName(String alias, MCRootPanel panel) {
/* 155 */     this.column.setAliasName(alias, panel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeAliasName(MCRootPanel panel) {
/* 171 */     this.column.removeAliasName(panel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeAliasNames() {
/* 183 */     this.column.removeAliasNames();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAliasName(MCRootPanel panel) {
/* 200 */     return this.column.getAliasName(panel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getAliasNames() {
/* 213 */     return this.column.getAliasNames();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(MCColumnConfig col) {
/* 225 */     addMember((MCTableColumn)col);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(MCColumnGroup grp) {
/* 236 */     addMember(grp);
/*     */ 
/*     */     
/* 239 */     MCColumnGroupTable<?> table = getTable();
/* 240 */     if (table != null) {
/* 241 */       grp.setTable(table);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(MCTable<?> table) {
/* 253 */     MCTableColumn[] cols = table.getAllAppTableColumns(); byte b; int i; MCTableColumn[] arrayOfMCTableColumn1;
/* 254 */     for (i = (arrayOfMCTableColumn1 = cols).length, b = 0; b < i; ) { MCTableColumn col = arrayOfMCTableColumn1[b];
/* 255 */       add(col);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(MCColumnGroupTable<?> table) {
/* 269 */     MCColumnGroupTableColumnModel model = table.getColumnModel();
/* 270 */     MCTableColumn[] cols = table.getAllAppTableColumns();
/* 271 */     MCColumnGroup current = null; byte b; int i; MCTableColumn[] arrayOfMCTableColumn1;
/* 272 */     for (i = (arrayOfMCTableColumn1 = cols).length, b = 0; b < i; ) { MCTableColumn col = arrayOfMCTableColumn1[b];
/* 273 */       MCColumnGroup[] cgs = model.getColumnGroups(col);
/* 274 */       if (cgs.length <= 0) {
/*     */         
/* 276 */         add(col);
/* 277 */         current = null;
/*     */ 
/*     */       
/*     */       }
/* 281 */       else if (current != cgs[0]) {
/* 282 */         add(cgs[0]);
/* 283 */         current = cgs[0];
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addMember(MCColumnGroupMember obj) {
/* 297 */     if (obj == null) {
/*     */       return;
/*     */     }
/* 300 */     this.member.add(obj);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCColumnGroupMember[] getMembers() {
/* 314 */     return this.member.<MCColumnGroupMember>toArray(new MCColumnGroupMember[this.member.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCColumnConfig[] getAllColumnConfigs() {
/* 334 */     return (MCColumnConfig[])getAllColumns();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCTableColumn[] getAllColumns() {
/* 353 */     List<MCTableColumn> l = new ArrayList<>();
/* 354 */     for (MCColumnGroupMember m : this.member) {
/* 355 */       if (m instanceof MCColumnGroup) {
/* 356 */         MCTableColumn[] cs = ((MCColumnGroup)m).getAllColumns(); byte b; int i; MCTableColumn[] arrayOfMCTableColumn1;
/* 357 */         for (i = (arrayOfMCTableColumn1 = cs).length, b = 0; b < i; ) { MCTableColumn c = arrayOfMCTableColumn1[b];
/* 358 */           l.add(c); b++; }
/*     */          continue;
/*     */       } 
/* 361 */       if (m instanceof MCTableColumn) {
/* 362 */         l.add((MCTableColumn)m);
/*     */       }
/*     */     } 
/* 365 */     return l.<MCTableColumn>toArray(new MCTableColumn[l.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCColumnGroup[] getAllColumnGroups() {
/* 380 */     List<MCColumnGroup> g = new ArrayList<>();
/* 381 */     int size = this.member.size();
/* 382 */     for (int i = 0; i < size; i++) {
/* 383 */       MCColumnGroupMember obj = this.member.get(i);
/* 384 */       if (obj instanceof MCColumnGroup) {
/* 385 */         MCColumnGroup cg = (MCColumnGroup)obj;
/* 386 */         g.add(cg);
/* 387 */         MCColumnGroup[] cgs = cg.getAllColumnGroups(); byte b; int j; MCColumnGroup[] arrayOfMCColumnGroup1;
/* 388 */         for (j = (arrayOfMCColumnGroup1 = cgs).length, b = 0; b < j; ) { MCColumnGroup c = arrayOfMCColumnGroup1[b];
/* 389 */           g.add(c);
/*     */           b++; }
/*     */       
/*     */       } 
/*     */     } 
/* 394 */     return g.<MCColumnGroup>toArray(new MCColumnGroup[g.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   List<MCColumnGroup> getColumnGroups(TableColumn c, List<MCColumnGroup> parent) {
/* 412 */     List<MCColumnGroup> g = (parent == null) ? 
/* 413 */       new ArrayList<>() : 
/* 414 */       new ArrayList<>(parent);
/* 415 */     g.add(this);
/* 416 */     if (this.member.contains(c))
/*     */     {
/* 418 */       return g;
/*     */     }
/*     */     
/* 421 */     int size = this.member.size();
/* 422 */     for (int i = 0; i < size; i++) {
/* 423 */       MCColumnGroupMember obj = this.member.get(i);
/* 424 */       if (obj instanceof MCColumnGroup) {
/* 425 */         MCColumnGroup cg = (MCColumnGroup)obj;
/* 426 */         List<MCColumnGroup> groups = cg.getColumnGroups(c, g);
/* 427 */         if (groups != null) {
/* 428 */           return groups;
/*     */         }
/*     */       } 
/*     */     } 
/* 432 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension getSize() {
/* 451 */     MCTable<?> mctable = this.column.getTable();
/* 452 */     MCHeaderRendererCommon renderer = 
/* 453 */       (MCHeaderRendererCommon)this.column.getHeaderRenderer();
/* 454 */     if (renderer == null)
/*     */     {
/* 456 */       renderer = 
/* 457 */         (MCHeaderRendererCommon)mctable.getTableHeader().getDefaultRenderer();
/*     */     }
/*     */ 
/*     */     
/* 461 */     Component comp = renderer.getTableCellRendererComponent(
/* 462 */         mctable, 
/* 463 */         (Comparable)this.column.getHeaderValue(), 
/* 464 */         false, false, -1, -1, this.column);
/* 465 */     int height = (comp.getPreferredSize()).height;
/* 466 */     int width = 0;
/* 467 */     int size = this.member.size();
/* 468 */     for (int i = 0; i < size; i++) {
/* 469 */       MCColumnGroupMember obj = this.member.get(i);
/* 470 */       width += obj.getWidth();
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 477 */     this.column.setWidth(width);
/*     */     
/* 479 */     return new Dimension(width, height);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getWidth() {
/* 484 */     return (getSize()).width;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void updateResource() {
/* 498 */     this.column.updateResource();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void updateResource(MCRootPanel panel) {
/* 509 */     this.column.updateResource(panel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getHeaderBackground() {
/* 527 */     return this.column.getHeaderBackground();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHeaderBackground(Color color) {
/* 541 */     this.column.setHeaderBackground(color);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Color getHeaderForeground() {
/* 555 */     return this.column.getHeaderForeground();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHeaderForeground(Color color) {
/* 569 */     this.column.setHeaderForeground(color);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Font getHeaderFont() {
/* 583 */     return this.column.getHeaderFont();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHeaderFont(Font font) {
/* 597 */     this.column.setHeaderFont(font);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getHeaderHorizontalAlignment() {
/* 608 */     return this.column.getHeaderHorizontalAlignment();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHeaderHorizontalAlignment(int alignment) {
/* 622 */     this.column.setHeaderHorizontalAlignment(alignment);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Icon getHeaderIcon() {
/* 636 */     return this.column.getHeaderIcon();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHeaderIcon(Icon i) {
/* 649 */     this.column.setHeaderIcon(i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHeaderIcon(String k) {
/* 667 */     this.column.setHeaderIcon(k);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHeaderIconPath(String p) {
/* 684 */     this.column.setHeaderIconPath(p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMessageByLocale() {
/* 695 */     return this.column.getMessageByLocale();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getHeaderName() {
/* 706 */     return this.column.getHeaderName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHeaderName(String name) {
/* 717 */     this.column.setHeaderName(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setHeaderMessage(String text) {
/* 728 */     this.column.setHeaderMessage(text);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCColumnGroup.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */