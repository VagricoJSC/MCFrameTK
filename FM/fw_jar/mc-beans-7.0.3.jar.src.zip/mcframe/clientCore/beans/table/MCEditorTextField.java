/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.util.List;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.border.Border;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCMode;
/*     */ import mcframe.clientCore.beans.MCResourceBeans;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.MCTextField;
/*     */ import mcframe.clientCore.beans.action.MCKeyActionManager;
/*     */ import mcframe.clientCore.beans.list.MCLinkBeans;
/*     */ import mcframe.clientCore.beans.list.MCLinkedBeans;
/*     */ import mcframe.clientCore.beans.list.MCListType;
/*     */ import mcframe.clientCore.beans.popup.MCPopupConfig;
/*     */ import mcframe.clientCore.beans.popup.MCPopupMenu;
/*     */ import mcframe.clientCore.beans.text.MCInputMethodType;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.clientCore.event.MCEventInfo;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCEditorTextField
/*     */   extends MCTextField
/*     */   implements MCEditorBeans
/*     */ {
/*     */   private static final String TYPE = "table.column.text";
/*     */   private MCColumnConfig _column;
/*     */   private MCTable<?> _table;
/*     */   
/*     */   protected MCEditorTextField(String name, MCColumnConfig column) {
/*  71 */     super(name);
/*  72 */     setColumnConfig(column);
/*  73 */     setTable(column.getBaseTable());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getType() {
/*  78 */     return "table.column.text";
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initBeans() {
/*  83 */     super.initBeans();
/*     */ 
/*     */     
/*  86 */     setFocusTraversalKeysEnabled(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initResource() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initKeyAssign() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setColumnConfig(MCColumnConfig column) {
/* 117 */     this._column = column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCColumnConfig getColumnConfig() {
/* 129 */     return this._column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean doListEventWithNull() {
/* 140 */     MCColumnConfig c = getColumnConfig();
/* 141 */     if (c != null) {
/* 142 */       return c.doListEventWithNull();
/*     */     }
/* 144 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean haveLinkValuesNullWhenDupliKeyTyped() {
/* 156 */     MCColumnConfig c = getColumnConfig();
/* 157 */     if (c != null) {
/* 158 */       return c.haveLinkValuesNullWhenDupliKeyTyped();
/*     */     }
/* 160 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setTable(MCTable<?> table) {
/* 171 */     this._table = table;
/*     */   }
/*     */ 
/*     */   
/*     */   public final MCTable getTable() {
/* 176 */     return this._table;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getRowIndex() {
/* 182 */     return MCCellUtil.getRowIndex(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void transferFocus() {
/* 187 */     MCTable<?> t = getTable();
/* 188 */     t.transferFocus(getRowIndex(), t.getViewColumn(getColumnConfig()) + 1, false, 
/* 189 */         true, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public Border getDefaultBorder() {
/* 194 */     return MCCellUtil.DEFAULT_BORDER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setColumnInfo(int index, MCColumnConfig column) {
/* 206 */     setColumnConfig(column);
/* 207 */     MCTable<?> table = getTable();
/* 208 */     MCKeyActionManager.init((MCResourceBeans)this, getInputMap(), getActionMap());
/* 209 */     MCKeyActionManager.initScreen((MCResourceBeans)this, getInputMap(), getActionMap());
/* 210 */     MCMode mode = MCCellUtil.isCellEditable(index, column, table);
/* 211 */     setMode(mode);
/* 212 */     setForeground(MCCellUtil.getForeground(index, column, table, false, mode));
/* 213 */     setBackground(MCCellUtil.getBackground(index, column, table, false, mode));
/* 214 */     setFont(column.getFont());
/* 215 */     setCaretColor(MCCellUtil.getCaretColor(index, column, table));
/* 216 */     setSelectionColor(MCCellUtil.getSelectionColor(index, column, table));
/* 217 */     setSelectedTextColor(MCCellUtil.getSelectedTextColor(index, column, table));
/* 218 */     setMeta(column.getMeta());
/* 219 */     setLength(column.getLength(index));
/* 220 */     setRow(column.getTable().getRow(index), column.getRowColumnName());
/*     */     
/* 222 */     setAutoFocus(column.isAutoFocus());
/* 223 */     setSelectAll(column.isSelectAll());
/* 224 */     setListConfig(column.getListConfig());
/* 225 */     setTrimPattern(column.getTrimPattern());
/* 226 */     Border border = MCCellUtil.getEditorBorder(index, column, table);
/* 227 */     if (border != null) {
/* 228 */       setBorder(border);
/*     */     } else {
/*     */       
/* 231 */       setBorder(getDefaultBorder());
/*     */     } 
/* 233 */     setListListener(column.getListListener());
/*     */     
/* 235 */     MCPopupMenu menu = getComponentPopupMenu();
/* 236 */     if (menu != null) {
/* 237 */       menu.updateResource();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setDummyColumnInfo(MCColumnConfig column, MCConstRow dummy) {
/* 248 */     setColumnConfig(column);
/* 249 */     setMeta(column.getMeta());
/* 250 */     setLength(column.getLength());
/*     */     
/* 252 */     if (dummy.contains(column.getBaseRowColumnName())) {
/* 253 */       setRow(dummy, column.getBaseRowColumnName());
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 260 */       setRow((MCConstRow)column.getTable().getList().createRow(), 
/* 261 */           column.getRowColumnName());
/*     */     } 
/*     */     
/* 264 */     setAutoFocus(false);
/* 265 */     setSelectAll(false);
/* 266 */     setTrimPattern(column.getTrimPattern());
/*     */   }
/*     */ 
/*     */   
/*     */   public MCLinkedBeans[] getLinkBeans() {
/* 271 */     MCColumnConfig c = getColumnConfig();
/* 272 */     return (c != null) ? c.getLinkBeans() : super.getLinkBeans();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCRootPanel getRootPanel() {
/* 277 */     return MCCellUtil.getRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCRootPanel getNearestRootPanel() {
/* 282 */     return MCCellUtil.getNearestRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessageByLocale() {
/* 287 */     return getColumnConfig().getMessageByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLabelByLocale() {
/* 292 */     return getColumnConfig().getLabelByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterRequestFocus() {
/* 297 */     MCRootPanel bp = getBaseRootPanel();
/* 298 */     MCBeansUtil.afterRequestFocus(bp, getTable());
/* 299 */     MCBeansUtil.scrollRectToVisible(bp, (JComponent)this, getHorizontalAlignment());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 304 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void commitValue() {}
/*     */ 
/*     */   
/*     */   public boolean isFocusOwner() {
/* 313 */     MCTable<?> t = getTable();
/* 314 */     return (t != null) ? (t.isRemoveNotifyProcessing() ? super.isFocusOwner() : false) : 
/* 315 */       super.isFocusOwner();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValueChanged() {
/* 320 */     return isValueChanged(getRowValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValueChanged(Comparable<?> value) {
/* 334 */     return isValueChanged(getValue(), value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isValueChanged(Comparable<?> view, Comparable<?> row) {
/* 340 */     if (isInputMethodEditing()) {
/* 341 */       return true;
/*     */     }
/*     */     
/* 344 */     return MCCellUtil.isValueChanged(this, view, row);
/*     */   }
/*     */ 
/*     */   
/*     */   public void valueCommited() {
/* 349 */     MCRow row = null;
/* 350 */     MCEventInfo e = getEventInfo();
/* 351 */     Comparable<?> newvalue = e.getNewValue();
/* 352 */     String key = getListNames()[0];
/* 353 */     MCList<?> l = null;
/* 354 */     if (newvalue != null || doListEventWithNull())
/*     */     {
/* 356 */       l = getList();
/*     */     }
/*     */     
/* 359 */     if ("input".equals(getListConfig().getOpeType()))
/*     */     {
/* 361 */       if (l != null) {
/* 362 */         MCRow[] a = l.toArray(); byte b; int i;
/*     */         MCRow[] arrayOfMCRow1;
/* 364 */         for (i = (arrayOfMCRow1 = a).length, b = 0; b < i; ) { MCRow r = arrayOfMCRow1[b];
/* 365 */           String val = r.getString(key);
/* 366 */           if (val != null && val.equals(newvalue)) {
/* 367 */             row = r;
/*     */             break;
/*     */           } 
/*     */           b++; }
/*     */       
/*     */       }  } 
/* 373 */     if (row == null && 
/* 374 */       getListType() == MCListType.FREE) {
/* 375 */       row = MCRow.create();
/* 376 */       MCBeansProxy.PROXY.addColumn(row, key, getDataType(), 
/* 377 */           getViewValue());
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 383 */     if (MCBeansProxy.PROXY.haveLinkValuesNull(e, (MCLinkBeans)this, getValue(), l, key)) {
/* 384 */       MCRow r = row.clone();
/* 385 */       r.clear();
/* 386 */       r.setValue(key, newvalue);
/* 387 */       ((MCTableColumn)getColumnConfig()).execLink(getTable().getMCEditingRow(), r, 
/* 388 */           true);
/*     */     } else {
/*     */       
/* 391 */       ((MCTableColumn)getColumnConfig()).execLink(getTable().getMCEditingRow(), 
/* 392 */           row, true);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getListNames() {
/* 402 */     return getColumnConfig().getListNames();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isMCFocusOwner() {
/* 407 */     MCTable<?> t = getTable();
/* 408 */     return (t != null) ? ((t.getMCEditorComponent() == this)) : isFocusOwner();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCList doListEventEx() {
/* 416 */     return ((MCTableColumn)getColumnConfig()).doListEventEx();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCList doListEvent() {
/* 421 */     return getColumnConfig().doListEvent();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean doVC() {
/* 426 */     return getColumnConfig().doVC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNC() {
/* 431 */     getColumnConfig().doNC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNE() {
/* 436 */     getColumnConfig().doNE();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNX() {
/* 441 */     getColumnConfig().doNX();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doLC() {
/* 446 */     getColumnConfig().doLC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doDC() {
/* 451 */     getColumnConfig().doDC();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCEventInfo getEventInfo() {
/* 456 */     return getColumnConfig().getEventInfo();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void focusGained() {
/* 462 */     focusGainedSelect();
/*     */     
/* 464 */     _installInputMethod();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void focusLost() {
/* 470 */     _uninstallInputMethod();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRequestFocusEnabled() {
/* 475 */     return (MCCellUtil.isRequestFocusEnabled(this) && super.isRequestFocusEnabled());
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isMCRequestFocusEnabled() {
/* 480 */     return MCCellUtil.isFocusable(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public Border getBorder() {
/* 485 */     Border b = MCCellUtil.getBorder(this);
/* 486 */     return (b != null) ? b : super.getBorder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource(MCRootPanel panel) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doCheckValueError() {
/* 511 */     super.doCheckValueError();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCPopupConfig getPopupConfig() {
/* 516 */     MCTable<?> t = getTable();
/* 517 */     return (t != null) ? t.getPopupConfig() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCPopupMenu configurePopup(MCPopupMenu menu) {
/* 531 */     MCPopupConfig pc = getPopupConfig();
/* 532 */     return (pc != null) ? 
/* 533 */       pc.configurePopup(menu, getTable(), getRowIndex(), getColumnConfig()) : 
/* 534 */       menu;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void processKeyEvent(KeyEvent e) {
/* 539 */     MCCellUtil.beforeKeyEvent(e, this);
/* 540 */     super.processKeyEvent(e);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Pattern> getAcceptPattern() {
/* 545 */     return getColumnConfig().getAcceptPattern();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Character> getExceptCharacter() {
/* 550 */     return getColumnConfig().getExceptCharacter();
/*     */   }
/*     */ 
/*     */   
/*     */   public Comparable<?> doListFormat(Comparable<?> value) {
/* 555 */     return getColumnConfig().doListFormat(getRowIndex(), value);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCInputMethodType getInputMethodType() {
/* 560 */     MCColumnConfig c = getColumnConfig();
/* 561 */     return (c != null) ? c.getInputMethodType() : super.getInputMethodType();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void execLink(MCRow row, boolean msg) {
/* 566 */     row = setPluralValue(row);
/* 567 */     ((MCTableColumn)getColumnConfig()).execLink(getRowIndex(), row, msg);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCEditorTextField.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */