/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import javax.swing.event.TableModelEvent;
/*     */ import javax.swing.table.DefaultTableModel;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.resource.ctrl.MCResource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCTableModel<E extends MCConstRow>
/*     */   extends DefaultTableModel
/*     */ {
/*     */   private final MCTable<E> _table;
/*  39 */   private MCList<E> _list = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  47 */   private int app_fixed_column_count = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCTableModel(MCTable<E> table) {
/*  57 */     this._table = table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final MCTable<E> getTable() {
/*  68 */     return this._table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setList(MCList<E> list) {
/*  79 */     this._list = list;
/*  80 */     setGUIIndex(list, 0);
/*  81 */     fireTableStructureChanged();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final MCList<E> getList() {
/*  92 */     return this._list;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getRowCount() {
/*  97 */     MCList<E> l = getList();
/*  98 */     return (l != null) ? l.size() : 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getColumnCount() {
/* 103 */     MCList<E> l = getList();
/* 104 */     return (l != null) ? (l.getMetaArray()).length : 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void sort(MCList.SortType type, String... names) {
/* 116 */     MCList<E> l = getList();
/* 117 */     if (l != null && l.size() != 0) {
/* 118 */       l.sort(type, names);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setGUIIndex(MCList<E> list, int start) {
/* 131 */     if (list != null && start > -1) {
/* 132 */       MCRow[] ra = list.toArray();
/* 133 */       int cnt = ra.length;
/* 134 */       String n = getTable().getName();
/* 135 */       if (!MCStringUtil.isNull(n)) {
/* 136 */         String[] na = MCResource.splitKey(n);
/* 137 */         if (na.length > 1) {
/* 138 */           for (int i = start; i < cnt; i++) {
/* 139 */             ra[i].setGUIIndex(i);
/*     */           }
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int getFixedColumnCount() {
/* 154 */     return getInfraColumnCount() + getAppFixedColumnCount();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int getInfraColumnCount() {
/* 165 */     return 3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setAppFixedColumnCount(int count) {
/* 176 */     this.app_fixed_column_count = count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final int getAppFixedColumnCount() {
/* 187 */     return this.app_fixed_column_count;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void insertRow(int index, E row) {
/* 199 */     MCList<E> l = getList();
/* 200 */     MCContainerProxy.proxy.setGUICreated((MCRow)row, true);
/* 201 */     l.add(index, (MCRow)row);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void insertRows(int pos, int count) {
/* 213 */     MCList<E> l = getList();
/* 214 */     MCList<E> tl = l.createInstance();
/* 215 */     for (int i = 0; i < count; i++) {
/* 216 */       MCConstRow mCConstRow = (MCConstRow)tl.createRow();
/* 217 */       MCContainerProxy.proxy.setGUICreated((MCRow)mCConstRow, true);
/* 218 */       tl.add((MCRow)mCConstRow);
/*     */     } 
/* 220 */     l.addAll(pos, (Collection)tl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int deleteRow(int index, E row) {
/* 233 */     MCList<E> l = getList();
/* 234 */     if (MCContainerProxy.proxy.isGUIDeleted((MCRow)row)) {
/* 235 */       MCContainerProxy.proxy.setGUIDeleted((MCRow)row, false);
/* 236 */       fireTableRowsUpdated(index, index);
/*     */     }
/* 238 */     else if (MCContainerProxy.proxy.isGUICreated((MCRow)row)) {
/* 239 */       MCTable<E> t = getTable();
/* 240 */       if (t.beforeRemoveRow(index)) {
/* 241 */         l.remove(index);
/*     */ 
/*     */         
/* 244 */         if (l.size() == 0 || t.getViewRows().size() == 0) {
/* 245 */           return -1;
/*     */         }
/*     */         
/* 248 */         int x = l.size() - 1;
/* 249 */         int n = Math.min(index, x);
/* 250 */         while (n < x) {
/* 251 */           if (t.getRowHeight(n) > 0) {
/* 252 */             return n;
/*     */           }
/* 254 */           n++;
/*     */         } 
/* 256 */         n = Math.min(index, x);
/* 257 */         while (n > -1) {
/* 258 */           if (t.getRowHeight(n) > 0) {
/* 259 */             return n;
/*     */           }
/* 261 */           n--;
/*     */         } 
/* 263 */         return index;
/*     */ 
/*     */       
/*     */       }
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 274 */       MCContainerProxy.proxy.setGUIDeleted((MCRow)row, true);
/* 275 */       fireTableRowsUpdated(index, index);
/*     */ 
/*     */       
/* 278 */       int n = index;
/* 279 */       int x = l.size() - 1;
/* 280 */       while (n < x) {
/* 281 */         n++;
/* 282 */         if (getTable().getRowHeight(n) > 0) {
/* 283 */           return n;
/*     */         }
/*     */       } 
/* 286 */       return index;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 293 */     return index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int deleteRows(MCList<E> list) {
/* 314 */     int o = getTable().getMCSelectedRow();
/* 315 */     E oe = getTable().getRow(o);
/*     */     
/* 317 */     MCList<E> del = list.createInstance();
/* 318 */     MCList<E> rev = list.createInstance();
/* 319 */     MCList<E> rem = list.createInstance();
/*     */     
/* 321 */     MCEditorBeans c = getTable().getEditorBeans();
/* 322 */     int sel = (c != null) ? c.getRowIndex() : -1;
/* 323 */     boolean edit = false;
/*     */     
/* 325 */     int n = o;
/*     */     
/* 327 */     for (MCConstRow mCConstRow : list) {
/*     */       
/* 329 */       if (MCContainerProxy.proxy.isGUIDeleted((MCRow)mCConstRow)) {
/* 330 */         rev.add((MCRow)mCConstRow);
/*     */         continue;
/*     */       } 
/* 333 */       if (MCContainerProxy.proxy.isGUICreated((MCRow)mCConstRow)) {
/* 334 */         rem.add((MCRow)mCConstRow);
/*     */         
/* 336 */         if (!edit && sel != -1 && 
/* 337 */           mCConstRow.getGUIIndex() == sel) {
/* 338 */           edit = true;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 343 */         if (n > 0 && mCConstRow.getGUIIndex() < o) {
/* 344 */           n--;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         continue;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 354 */       del.add((MCRow)mCConstRow);
/*     */     } 
/*     */ 
/*     */     
/* 358 */     if (rem.size() > 0) {
/*     */       
/* 360 */       if (edit) {
/* 361 */         MCTable<?> e = getTable().getEditingTable();
/* 362 */         if (e != null) {
/* 363 */           e.removeEditor();
/*     */         }
/*     */       } 
/* 366 */       getList().removeAll((Collection)rem);
/*     */     } 
/*     */     
/* 369 */     for (MCConstRow mCConstRow : rev) {
/* 370 */       MCContainerProxy.proxy.setGUIDeleted((MCRow)mCConstRow, false);
/* 371 */       fireTableRowsUpdated(mCConstRow.getGUIIndex(), mCConstRow.getGUIIndex());
/*     */     } 
/*     */     
/* 374 */     for (MCConstRow mCConstRow : del) {
/* 375 */       MCContainerProxy.proxy.setGUIDeleted((MCRow)mCConstRow, true);
/* 376 */       fireTableRowsUpdated(mCConstRow.getGUIIndex(), mCConstRow.getGUIIndex());
/*     */     } 
/*     */ 
/*     */     
/* 380 */     if (oe != null && MCContainerProxy.proxy.isGUIDeleted((MCRow)oe)) {
/*     */       
/* 382 */       int j = n + 1;
/*     */       
/* 384 */       MCList<E> tmp = list.createInstance();
/* 385 */       tmp.addAll((Collection)list);
/*     */       
/* 387 */       int k = getList().size() - 1;
/* 388 */       while (j < k) {
/* 389 */         MCConstRow mCConstRow = (MCConstRow)getList().get(j);
/* 390 */         if (!tmp.contains(mCConstRow)) {
/*     */           break;
/*     */         }
/* 393 */         tmp.remove(mCConstRow);
/* 394 */         j++;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 403 */     if (getList().size() == 0 || getTable().getViewRows().size() == 0) {
/* 404 */       return -1;
/*     */     }
/*     */ 
/*     */     
/* 408 */     n = Math.max(n, 0);
/*     */     
/* 410 */     int x = getList().size() - 1;
/*     */     
/* 412 */     int i = Math.min(n, x);
/*     */     
/* 414 */     int di = -1;
/*     */     
/* 416 */     MCList<E> tdel = del.createInstance();
/* 417 */     tdel.addAll((Collection)del);
/*     */     
/* 419 */     while (i <= x) {
/* 420 */       boolean v = (getTable().getRowHeight(i) > 0);
/*     */       
/* 422 */       MCConstRow mCConstRow = (MCConstRow)getList().get(i);
/*     */ 
/*     */       
/* 425 */       if (tdel.contains(mCConstRow)) {
/* 426 */         tdel.remove(mCConstRow);
/*     */         
/* 428 */         if (v) {
/* 429 */           di = i;
/*     */         }
/* 431 */         i++;
/*     */         
/*     */         continue;
/*     */       } 
/* 435 */       if (v) {
/* 436 */         return i;
/*     */       }
/* 438 */       i++;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 443 */     if (di != -1) {
/* 444 */       return di;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 449 */     i = Math.min(n, x);
/* 450 */     di = -1;
/*     */     
/* 452 */     tdel = del.createInstance();
/* 453 */     tdel.addAll((Collection)del);
/*     */     
/* 455 */     while (i > -1) {
/* 456 */       boolean v = (getTable().getRowHeight(i) > 0);
/*     */       
/* 458 */       MCConstRow mCConstRow = (MCConstRow)getList().get(i);
/*     */ 
/*     */       
/* 461 */       if (tdel.contains(mCConstRow)) {
/* 462 */         tdel.remove(mCConstRow);
/*     */         
/* 464 */         if (v && di == -1) {
/* 465 */           di = i;
/*     */         }
/* 467 */         i--;
/*     */         
/*     */         continue;
/*     */       } 
/* 471 */       if (v) {
/* 472 */         return i;
/*     */       }
/* 474 */       i--;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 479 */     if (di != -1) {
/* 480 */       return di;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 487 */     return n;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected E truncateRow(int index) {
/* 499 */     MCList<E> l = getList();
/* 500 */     MCConstRow mCConstRow = (MCConstRow)l.get(index);
/* 501 */     if (getTable().beforeRemoveRow(index))
/*     */     {
/* 503 */       l.remove(index);
/*     */     }
/* 505 */     return (E)mCConstRow;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public Object getValueAt(int index, int model) {
/* 521 */     return getValue(index, getModelColumn(model));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Comparable<?> getValue(int index, MCColumnConfig column) {
/* 534 */     if (!column.isLinkRowColumn()) {
/* 535 */       return null;
/*     */     }
/* 537 */     MCList<E> l = getList();
/* 538 */     return (l != null) ? l.getValue(index, column.getBaseRowColumnName()) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setValueAt(Object value, int index, int model) {
/* 554 */     setValue((Comparable)value, index, getModelColumn(model));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public String getColumnName(int model) {
/* 569 */     return getModelColumn(model).getBaseRowColumnName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setValue(Comparable<?> value, int index, MCColumnConfig column) {
/* 582 */     if (!column.isLinkRowColumn()) {
/*     */       return;
/*     */     }
/* 585 */     MCList<E> l = getList();
/* 586 */     if (l == null) {
/*     */       return;
/*     */     }
/* 589 */     MCConstRow mCConstRow = (MCConstRow)l.get(index);
/* 590 */     mCConstRow.setValue(column.getBaseRowColumnName(), value);
/*     */     
/* 592 */     if (!column.isIgnoreStatus()) {
/* 593 */       MCContainerProxy.proxy.setGUIModified((MCRow)mCConstRow, true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void moveRow(int start, int end, int to) {
/* 603 */     int first, last, shift = to - start;
/*     */     
/* 605 */     if (shift < 0) {
/* 606 */       first = to;
/* 607 */       last = end;
/*     */     } else {
/*     */       
/* 610 */       first = start;
/* 611 */       last = to + end - start;
/*     */     } 
/* 613 */     rotate(getList(), first, last + 1, shift);
/*     */     
/* 615 */     fireTableRowsUpdated(first, last);
/*     */   }
/*     */   
/*     */   private void rotate(MCList<E> list, int a, int b, int shift) {
/* 619 */     int size = b - a;
/* 620 */     int r = size - shift;
/* 621 */     int g = gcd(size, r);
/* 622 */     for (int i = 0; i < g; i++) {
/* 623 */       int to = i;
/* 624 */       MCConstRow mCConstRow = (MCConstRow)list.get(a + to);
/* 625 */       for (int from = (to + r) % size; from != i; from = (to + r) % size) {
/* 626 */         list.set(a + to, list.get(a + from));
/* 627 */         to = from;
/*     */       } 
/* 629 */       list.set(a + to, (MCRow)mCConstRow);
/*     */     } 
/*     */   }
/*     */   
/*     */   private int gcd(int i, int j) {
/* 634 */     return (j == 0) ? i : gcd(j, i % j);
/*     */   }
/*     */   
/*     */   private MCColumnConfig getModelColumn(int model) {
/* 638 */     return getTable().getColumnFromModel(model);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void adjustRowHeight() {
/* 648 */     MCList<E> l = getList();
/* 649 */     if (l == null) {
/*     */       return;
/*     */     }
/*     */     
/* 653 */     MCTable<E> t = getTable();
/* 654 */     int d = t.getRowHeight();
/*     */     
/* 656 */     MCConstRow[] a = (MCConstRow[])l.toArray();
/* 657 */     for (int i = 0; i < a.length; i++) {
/* 658 */       int o = t.getRowHeight(i);
/*     */       
/* 660 */       int n = d;
/* 661 */       if (!a[i].isGUIVisible()) {
/* 662 */         n = 0;
/*     */       }
/*     */       
/* 665 */       if (o != n) {
/* 666 */         t.setMCRowHeight(i, n);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void fireTableChanged(TableModelEvent e) {
/* 673 */     super.fireTableChanged(e);
/* 674 */     MCBeansUtil.checkThread();
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCTableModel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */