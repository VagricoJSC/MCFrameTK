/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.table.DefaultTableCellRenderer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCPlainRowNumberCellRenderer
/*     */   extends DefaultTableCellRenderer
/*     */   implements MCInfraCellRenderer
/*     */ {
/*     */   private final MCColumnConfig _column;
/*     */   
/*     */   protected MCPlainRowNumberCellRenderer(MCColumnConfig column) {
/*  40 */     this._column = column;
/*  41 */     setHorizontalAlignment(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCColumnConfig getColumnConfig() {
/*  52 */     return this._column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Color getForeground(MCTable<?> table, int index, MCColumnConfig column, boolean selected) {
/*  68 */     if (column == null) {
/*  69 */       return null;
/*     */     }
/*     */     
/*  72 */     if (selected) {
/*  73 */       Color c = column.getSelectedHeaderForeground();
/*  74 */       if (c != null) {
/*  75 */         return c;
/*     */       }
/*     */     } 
/*     */     
/*  79 */     MCCellConfig conf = column.getCellConfig();
/*  80 */     return conf.getRowNumberColumnForeground(
/*  81 */         index, column, table, selected);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Color getBackground(MCTable<?> table, int index, MCColumnConfig column, boolean selected) {
/*  99 */     if (column == null) {
/* 100 */       return null;
/*     */     }
/*     */     
/* 103 */     if (selected) {
/* 104 */       Color c = column.getSelectedHeaderBackground();
/* 105 */       if (c != null) {
/* 106 */         return c;
/*     */       }
/*     */     } 
/*     */     
/* 110 */     return column.getHeaderBackground();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Component getTableCellRendererComponent(JTable table, Object value, boolean selected, boolean focused, int index, int column) {
/* 129 */     return getRenderer((MCTable)table, value, selected, focused, 
/* 130 */         index, getColumnConfig());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Component getRenderer(MCTable<?> table, Object value, boolean selected, boolean focused, int index, MCColumnConfig column) {
/*     */     try {
/* 149 */       MCCellConfig conf = column.getCellConfig();
/* 150 */       setForeground(getForeground(table, index, column, selected));
/* 151 */       setBackground(getBackground(table, index, column, selected));
/*     */ 
/*     */ 
/*     */       
/* 155 */       setFont(column.getFont());
/* 156 */       setText(conf.getRowNumberColumnValue(
/* 157 */             index, column, table, selected));
/*     */     }
/* 159 */     catch (RuntimeException e) {
/* 160 */       MCCellUtil.preHandle(table, e);
/* 161 */       MCCellUtil.handle(table, e);
/*     */     } 
/* 163 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Comparable<?> getValue() {
/* 168 */     return getText();
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCPlainRowNumberCellRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */