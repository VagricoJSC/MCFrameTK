/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.event.KeyEvent;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.border.Border;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCMode;
/*     */ import mcframe.clientCore.beans.MCModeBeans;
/*     */ import mcframe.clientCore.beans.MCResourceBeans;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.MCTimestampField;
/*     */ import mcframe.clientCore.beans.action.MCKeyActionManager;
/*     */ import mcframe.clientCore.beans.list.MCLinkedBeans;
/*     */ import mcframe.clientCore.beans.list.MCListType;
/*     */ import mcframe.clientCore.beans.popup.MCPopupConfig;
/*     */ import mcframe.clientCore.beans.popup.MCPopupMenu;
/*     */ import mcframe.clientCore.event.MCEventInfo;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCCalendarDate;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.lang.MCTimestamp;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCEditorTimestampField
/*     */   extends MCTimestampField
/*     */   implements MCEditorBeans
/*     */ {
/*     */   private static final String TYPE = "table.column.date";
/*     */   private MCColumnConfig _column;
/*     */   private MCTable<?> _table;
/*     */   
/*     */   public MCEditorTimestampField(String name, MCColumnConfig column) {
/*  71 */     super(name);
/*  72 */     setColumnConfig(column);
/*  73 */     setTable(column.getBaseTable());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getType() {
/*  78 */     return "table.column.date";
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initBeans() {
/*  83 */     super.initBeans();
/*     */ 
/*     */     
/*  86 */     setFocusTraversalKeysEnabled(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initKeyAssign() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initResource() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Border getDefaultBorder() {
/* 111 */     return MCCellUtil.DEFAULT_BORDER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setColumnInfo(int index, MCColumnConfig column) {
/* 123 */     setColumnConfig(column);
/* 124 */     MCTable<?> table = getTable();
/* 125 */     MCKeyActionManager.init((MCResourceBeans)this, getInputMap(), getActionMap());
/* 126 */     MCKeyActionManager.initScreen((MCResourceBeans)this, getInputMap(), getActionMap());
/* 127 */     MCMode mode = MCCellUtil.isCellEditable(index, column, table);
/* 128 */     setMode(mode);
/* 129 */     setForeground(MCCellUtil.getForeground(index, column, table, false, mode));
/* 130 */     setBackground(MCCellUtil.getBackground(index, column, table, false, mode));
/* 131 */     setFont(column.getFont());
/* 132 */     setCaretColor(MCCellUtil.getCaretColor(index, column, table));
/* 133 */     setSelectionColor(MCCellUtil.getSelectionColor(index, column, table));
/* 134 */     setSelectedTextColor(MCCellUtil.getSelectedTextColor(index, column, table));
/* 135 */     setMeta(column.getMeta());
/* 136 */     setAutoFocus(column.isAutoFocus());
/* 137 */     setSelectAll(column.isSelectAll());
/* 138 */     setListConfig(column.getListConfig());
/* 139 */     setCalendarFormat(MCCellUtil.getTimestampFormat(index, column, table, mode));
/*     */     
/* 141 */     setCalendarValidator(column.getCalendarValidator());
/*     */     
/* 143 */     setRow(column.getTable().getRow(index), column.getRowColumnName());
/*     */     
/* 145 */     Border border = MCCellUtil.getEditorBorder(index, column, table);
/* 146 */     if (border != null) {
/* 147 */       setBorder(border);
/*     */     } else {
/*     */       
/* 150 */       setBorder(getDefaultBorder());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValueChanged() {
/* 156 */     return isValueChanged((Comparable<?>)getRowValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValueChanged(Comparable<?> value) {
/* 170 */     adjustViewValue();
/*     */     try {
/* 172 */       return isValueChanged((Comparable<?>)getValue(), value);
/*     */     }
/* 174 */     catch (MCException mCException) {
/* 175 */       return true;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isValueChanged(Comparable<?> view, Comparable<?> row) {
/* 181 */     return MCCellUtil.isValueChanged(this, view, row);
/*     */   }
/*     */ 
/*     */   
/*     */   public void valueCommited() {
/* 186 */     MCRow row = null;
/* 187 */     if ("input".equals(getListConfig().getOpeType())) {
/* 188 */       MCList<?> l = getList();
/* 189 */       if (l != null) {
/* 190 */         MCRow[] a = l.toArray();
/* 191 */         MCTimestamp v = (MCTimestamp)getValue();
/* 192 */         String n = getListNames()[0]; byte b; int i; MCRow[] arrayOfMCRow1;
/* 193 */         for (i = (arrayOfMCRow1 = a).length, b = 0; b < i; ) { MCRow r = arrayOfMCRow1[b];
/* 194 */           MCTimestamp val = r.getTimestamp(n);
/* 195 */           if (val != null && val.eq((MCCalendarDate)v, new mcframe.commonCore.lang.MCDateFieldType[0])) {
/* 196 */             row = r; break;
/*     */           } 
/*     */           b++; }
/*     */       
/*     */       } 
/*     */     } 
/* 202 */     if (row == null && 
/* 203 */       getListType() == MCListType.FREE) {
/* 204 */       row = MCRow.create();
/* 205 */       MCBeansProxy.PROXY.addColumn(row, getListNames()[0], getDataType(), 
/* 206 */           (Comparable<?>)getViewValue());
/*     */     } 
/*     */     
/* 209 */     ((MCTableColumn)getColumnConfig()).execLink(getTable().getMCEditingRow(), row, 
/* 210 */         true);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isMCFocusOwner() {
/* 215 */     MCTable<?> t = getTable();
/* 216 */     return (t != null) ? ((t.getMCEditorComponent() == this)) : isFocusOwner();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCLinkedBeans[] getLinkBeans() {
/* 221 */     MCColumnConfig c = getColumnConfig();
/* 222 */     return (c != null) ? c.getLinkBeans() : super.getLinkBeans();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCRootPanel getRootPanel() {
/* 227 */     return MCCellUtil.getRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCRootPanel getNearestRootPanel() {
/* 232 */     return MCCellUtil.getNearestRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessageByLocale() {
/* 237 */     return getColumnConfig().getMessageByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLabelByLocale() {
/* 242 */     return getColumnConfig().getLabelByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterRequestFocus() {
/* 247 */     MCRootPanel bp = getBaseRootPanel();
/* 248 */     MCBeansUtil.afterRequestFocus(bp, getTable());
/* 249 */     MCBeansUtil.scrollRectToVisible(bp, (JComponent)this, getHorizontalAlignment());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 254 */     repaint();
/*     */   }
/*     */ 
/*     */   
/*     */   public void commitValue() {
/* 259 */     getColumnConfig().setValue(getRowIndex(), (Comparable<?>)getViewValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFocusOwner() {
/* 264 */     MCTable<?> t = getTable();
/* 265 */     return (t != null) ? (t.isRemoveNotifyProcessing() ? super.isFocusOwner() : false) : 
/* 266 */       super.isFocusOwner();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void transferFocus() {
/* 272 */     if (isAmPmField() && MCMode.isEnable((MCModeBeans)this) && 
/* 273 */       !MCStringUtil.isNull(getText()) && isValueChanged() && !isShowingAmPmComboList()) {
/* 274 */       showOrChangeAmPm();
/*     */       
/*     */       return;
/*     */     } 
/* 278 */     MCTable<?> t = getTable();
/* 279 */     t.transferFocus(getRowIndex(), t.getViewColumn(getColumnConfig()) + 1, false, 
/* 280 */         true, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setColumnConfig(MCColumnConfig column) {
/* 291 */     this._column = column;
/*     */   }
/*     */ 
/*     */   
/*     */   public final MCColumnConfig getColumnConfig() {
/* 296 */     return this._column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setTable(MCTable<?> table) {
/* 307 */     this._table = table;
/*     */   }
/*     */ 
/*     */   
/*     */   public final MCTable getTable() {
/* 312 */     return this._table;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getRowIndex() {
/* 318 */     return MCCellUtil.getRowIndex(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCList doListEvent() {
/* 323 */     return getColumnConfig().doListEvent();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean doVC() {
/* 328 */     return getColumnConfig().doVC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNC() {
/* 333 */     getColumnConfig().doNC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNE() {
/* 338 */     getColumnConfig().doNE();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNX() {
/* 343 */     getColumnConfig().doNX();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doLC() {
/* 348 */     getColumnConfig().doLC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doDC() {
/* 353 */     super.doDC();
/* 354 */     getColumnConfig().doDC();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCEventInfo getEventInfo() {
/* 359 */     return getColumnConfig().getEventInfo();
/*     */   }
/*     */ 
/*     */   
/*     */   public void focusGained() {
/* 364 */     setText((MCCalendarDate)getRowValue());
/* 365 */     focusGainedSelect();
/* 366 */     showCalenderIfFocusGained();
/* 367 */     this._suppressCalenderMPEvent = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void focusLost() {
/* 372 */     hideCalenderIfFocusLost();
/* 373 */     setText((MCCalendarDate)getRowValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRequestFocusEnabled() {
/* 378 */     return (MCCellUtil.isRequestFocusEnabled(this) && super.isRequestFocusEnabled());
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isMCRequestFocusEnabled() {
/* 383 */     return MCCellUtil.isFocusable(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public Border getBorder() {
/* 388 */     Border b = MCCellUtil.getBorder(this);
/* 389 */     return (b != null) ? b : super.getBorder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource(MCRootPanel panel) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doCheckValueError() {
/* 414 */     super.doCheckValueError();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCalendarEnabled() {
/* 419 */     return getColumnConfig().isCalendarEnabled();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCPopupConfig getPopupConfig() {
/* 424 */     MCTable<?> t = getTable();
/* 425 */     return (t != null) ? t.getPopupConfig() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCPopupMenu configurePopup(MCPopupMenu menu) {
/* 439 */     MCPopupConfig pc = getPopupConfig();
/* 440 */     return (pc != null) ? 
/* 441 */       pc.configurePopup(menu, getTable(), getRowIndex(), getColumnConfig()) : 
/* 442 */       menu;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void processKeyEvent(KeyEvent e) {
/* 447 */     MCCellUtil.beforeKeyEvent(e, this);
/* 448 */     super.processKeyEvent(e);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCTimestamp getInitCalendarFocus() {
/* 453 */     MCTimestamp v = MCCellUtil.getInitTimestampCalendarFocus(getRowIndex(), 
/* 454 */         getColumnConfig(), getTable());
/* 455 */     return (v != null) ? v : today();
/*     */   }
/*     */ 
/*     */   
/*     */   public Comparable<?> doListFormat(Comparable<?> value) {
/* 460 */     return getColumnConfig().doListFormat(getRowIndex(), value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getCalendarPanelID() {
/* 465 */     return MCCellUtil.getCalendarPanelID(getRowIndex(), getColumnConfig(), 
/* 466 */         getTable());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void execLink(MCRow row, boolean msg) {
/* 471 */     ((MCTableColumn)getColumnConfig()).execLink(getRowIndex(), row, msg);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCEditorTimestampField.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */