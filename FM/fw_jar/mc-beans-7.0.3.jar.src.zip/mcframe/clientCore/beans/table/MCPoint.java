/*    */ package mcframe.clientCore.beans.table;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MCPoint
/*    */ {
/*    */   private final MCTable<?> _table;
/*    */   private final int _index;
/*    */   private final MCColumnConfig _column;
/*    */   
/*    */   MCPoint(MCTable<?> table, int index, MCColumnConfig column) {
/* 46 */     this._table = table;
/* 47 */     this._index = index;
/* 48 */     this._column = column;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   final MCTable<?> getTable() {
/* 59 */     return this._table;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   final int getIndex() {
/* 70 */     return this._index;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   final MCColumnConfig getColumn() {
/* 81 */     return this._column;
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCPoint.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */