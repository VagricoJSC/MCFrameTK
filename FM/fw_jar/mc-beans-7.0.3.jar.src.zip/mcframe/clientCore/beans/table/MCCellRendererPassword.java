/*    */ package mcframe.clientCore.beans.table;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCCellRendererPassword
/*    */   extends MCCellRendererField
/*    */ {
/*    */   protected MCCellRendererPassword(MCColumnConfig column) {
/* 21 */     super(column);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void setValue(Object value) {
/* 26 */     if (value != null) {
/* 27 */       int cnt = value.toString().length();
/* 28 */       char echo = getColumnConfig().getEchoChar();
/* 29 */       StringBuilder builder = new StringBuilder();
/* 30 */       for (int i = 0; i < cnt; i++) {
/* 31 */         builder.append(echo);
/*    */       }
/* 33 */       value = builder.toString();
/*    */     } 
/* 35 */     super.setValue(value);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCCellRendererPassword.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */