/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.StringReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.BoxLayout;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.border.AbstractBorder;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.border.EmptyBorder;
/*     */ import javax.swing.table.TableCellRenderer;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.plaf.metal.MCTheme;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCMultiLineHeaderRenderer
/*     */   extends JPanel
/*     */   implements TableCellRenderer, MCHeaderRendererCommon
/*     */ {
/*     */   private JPanel _label;
/*     */   private JPanel _image;
/*     */   private JPanel _base;
/*     */   private JPanel _hAlignment;
/*  82 */   private final Insets _insets = MCTheme.getInsets("table.header.insets", new Insets(0, 0, 0, 0));
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   private List<LineLabel> _labelLabels = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  92 */   private List<JLabel> _imageLabels = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCMultiLineHeaderRenderer(TableCellRenderer def) {
/* 105 */     Border border = getHeaderBorder((MCTable<?>)null, false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 111 */     setName("TableHeader.multilineRenderer");
/*     */     
/* 113 */     setLayout(new BoxLayout(this, 0));
/* 114 */     setBorder(border);
/* 115 */     setOpaque(true);
/*     */ 
/*     */     
/* 118 */     this._hAlignment = new JPanel();
/* 119 */     this._hAlignment.setLayout(new BoxLayout(this._hAlignment, 1));
/* 120 */     this._hAlignment.setOpaque(false);
/*     */ 
/*     */     
/* 123 */     this._base = new JPanel();
/* 124 */     this._base.setLayout(new BoxLayout(this._base, 0));
/* 125 */     this._base.setOpaque(false);
/*     */ 
/*     */     
/* 128 */     Insets insets = (Insets)border.getBorderInsets(this).clone();
/* 129 */     insets.top *= -1;
/* 130 */     insets.left = 0;
/* 131 */     insets.right = 1;
/*     */ 
/*     */     
/* 134 */     this._image = new JPanel();
/* 135 */     this._image.setLayout(new BoxLayout(this._image, 0));
/* 136 */     this._image.setBorder(new EmptyBorder(insets));
/* 137 */     this._image.setOpaque(false);
/*     */ 
/*     */     
/* 140 */     this._label = new JPanel();
/* 141 */     this._label.setLayout(new BoxLayout(this._label, 1));
/* 142 */     this._label.setBorder(new EmptyBorder(insets));
/* 143 */     this._label.setOpaque(false);
/*     */     
/* 145 */     add(this._hAlignment);
/* 146 */     this._hAlignment.add(this._base);
/* 147 */     this._base.add(this._image);
/* 148 */     this._base.add(this._label);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
/* 167 */     return getRenderer((MCTable)table, (Comparable)value, isSelected, 
/* 168 */         hasFocus, row, column);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Component getRenderer(MCTable<?> table, Comparable<?> value, boolean selected, boolean focused, int row, int real) {
/* 186 */     MCColumnConfig column = table.getColumnFromReal(table, real);
/* 187 */     return getTableCellRendererComponent(table, value, selected, focused, row, real, 
/* 188 */         column);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Component getTableCellRendererComponent(MCTable<?> table, Comparable<?> value, boolean selected, boolean focused, int row, int real, MCColumnConfig column) {
/* 194 */     this._label.removeAll();
/* 195 */     this._image.removeAll();
/* 196 */     if (column == null) {
/* 197 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 203 */     selected = false;
/* 204 */     MCColumnConfig sel = table.getSelectedColumnConfig();
/* 205 */     if (sel == column)
/*     */     {
/*     */       
/* 208 */       if (table.getSelectedRowCount() > 0) {
/* 209 */         MCFixedColumnTable<?> fixed = table.getFixedColumnTable();
/* 210 */         if (!fixed.isInfraColumn(sel)) {
/* 211 */           selected = true;
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 218 */     if (column.isToolTipEnabled()) {
/* 219 */       String text = column.getMessageByLocale();
/* 220 */       if (text != null && text.length() != 0) {
/*     */         
/* 222 */         setToolTipText(text);
/*     */       } else {
/*     */         
/* 225 */         setToolTipText((String)null);
/*     */       } 
/*     */     } else {
/*     */       
/* 229 */       setToolTipText((String)null);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 234 */     if (isSynth())
/*     */     {
/* 236 */       setOpaque(selected);
/*     */     }
/* 238 */     Color bg = getHeaderBackground(column, table, selected);
/* 239 */     if (bg != null) {
/* 240 */       setBackground(bg);
/*     */     }
/* 242 */     setBorder(getHeaderBorder(table, selected));
/*     */     
/* 244 */     int alignment = column.getHeaderHorizontalAlignment();
/* 245 */     int height = 0;
/*     */ 
/*     */     
/* 248 */     Color fg = getHeaderForeground(column, table, selected);
/* 249 */     Font font = getHeaderFont(column, table);
/* 250 */     String str = column.getHeaderName();
/* 251 */     BufferedReader br = new BufferedReader(new StringReader(str));
/* 252 */     Insets insets = this._insets;
/*     */     
/* 254 */     int labelIndex = 0;
/*     */     try {
/*     */       String line;
/* 257 */       while ((line = br.readLine()) != null) {
/*     */         LineLabel label;
/* 259 */         if (this._labelLabels.size() > labelIndex) {
/*     */           
/* 261 */           label = this._labelLabels.get(labelIndex++);
/* 262 */           label.setPreferredSize((Dimension)null);
/*     */         } else {
/*     */           
/* 265 */           label = new LineLabel(this);
/* 266 */           label.setBorder(BorderFactory.createEmptyBorder(insets.top, insets.left, 
/* 267 */                 insets.bottom, insets.right));
/* 268 */           this._labelLabels.add(label);
/*     */         } 
/* 270 */         if (font != null) {
/* 271 */           label.setFont(font);
/*     */         }
/* 273 */         if (fg != null) {
/* 274 */           label.setForeground(fg);
/*     */         }
/* 276 */         switch (alignment) {
/*     */           case 2:
/* 278 */             label.setAlignmentX(0.0F);
/*     */             break;
/*     */           case 4:
/* 281 */             label.setAlignmentX(1.0F);
/*     */             break;
/*     */           
/*     */           default:
/* 285 */             label.setAlignmentX(0.5F); break;
/*     */         } 
/* 287 */         label.setText(line);
/*     */         
/* 289 */         this._label.add(label);
/* 290 */         height += (label.getPreferredSize()).height;
/*     */       }
/*     */     
/* 293 */     } catch (IOException ex) {
/* 294 */       String line; throw new MCException(line);
/*     */     } 
/* 296 */     if (this._label.getComponentCount() == 0) {
/*     */       LineLabel label;
/*     */       
/* 299 */       if (this._labelLabels.size() > labelIndex) {
/*     */         
/* 301 */         label = this._labelLabels.get(labelIndex);
/* 302 */         label.setPreferredSize((Dimension)null);
/*     */       } else {
/*     */         
/* 305 */         label = new LineLabel(this);
/* 306 */         label.setBorder(BorderFactory.createEmptyBorder(insets.top, insets.left, 
/* 307 */               insets.bottom, insets.right));
/* 308 */         this._labelLabels.add(label);
/*     */       } 
/*     */       
/* 311 */       if (font != null) {
/* 312 */         label.setFont(font);
/*     */       }
/* 314 */       label.setText("a");
/* 315 */       height += (label.getPreferredSize()).height;
/*     */     } 
/*     */ 
/*     */     
/* 319 */     Icon icon = getHeaderIcon(column);
/* 320 */     if (icon != null) {
/* 321 */       JLabel imlabel; int imageIndex = 0;
/*     */       
/* 323 */       if (this._imageLabels.size() > imageIndex) {
/*     */         
/* 325 */         imlabel = this._imageLabels.get(imageIndex);
/* 326 */         imlabel.setPreferredSize((Dimension)null);
/*     */       } else {
/*     */         
/* 329 */         imlabel = new JLabel();
/* 330 */         this._imageLabels.add(imlabel);
/*     */       } 
/* 332 */       ImageIcon image = null;
/* 333 */       if (MCBeansUtil.isAdjustSize(column) && 
/* 334 */         icon instanceof ImageIcon) {
/*     */         
/* 336 */         imlabel.setText("a");
/* 337 */         int imheight = (imlabel.getPreferredSize()).height;
/* 338 */         imlabel.setText((String)null);
/*     */         
/* 340 */         ImageIcon temp = (ImageIcon)icon;
/* 341 */         image = new ImageIcon(temp.getImage());
/* 342 */         Dimension size = getIconSize(image, imlabel, imheight);
/* 343 */         image.setImage(image.getImage().getScaledInstance(size.width, 
/* 344 */               size.height, 4));
/*     */       } 
/*     */       
/* 347 */       imlabel.setIcon(image);
/* 348 */       this._image.add(imlabel);
/*     */     } 
/*     */ 
/*     */     
/* 352 */     switch (alignment)
/*     */     { case 2:
/* 354 */         this._base.setAlignmentX(0.0F);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 365 */         width = column.getColumnWidth();
/* 366 */         this._hAlignment.setPreferredSize(new Dimension(width, height));
/* 367 */         setPreferredSize(new Dimension(width, height));
/*     */         
/* 369 */         return this;case 4: this._base.setAlignmentX(1.0F); width = column.getColumnWidth(); this._hAlignment.setPreferredSize(new Dimension(width, height)); setPreferredSize(new Dimension(width, height)); return this; }  this._base.setAlignmentX(0.5F); int width = column.getColumnWidth(); this._hAlignment.setPreferredSize(new Dimension(width, height)); setPreferredSize(new Dimension(width, height)); return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Dimension getIconSize(Icon icon, JLabel label, int height) {
/* 383 */     Insets insets = getBorderInsets(label);
/* 384 */     double iw = icon.getIconWidth();
/* 385 */     double ih = icon.getIconHeight();
/* 386 */     double mh = (height - insets.top - insets.bottom);
/* 387 */     double p = mh / ih;
/*     */     
/* 389 */     int h = (int)Math.max(ih * p, 1.0D);
/* 390 */     int w = (int)Math.max(iw * p, 1.0D);
/* 391 */     return new Dimension(w, h);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Insets getBorderInsets(JComponent c) {
/* 402 */     Border border = this._label.getBorder();
/* 403 */     if (border != null) {
/* 404 */       Insets insets = border.getBorderInsets(this);
/* 405 */       return new Insets(insets.top + 2, insets.left + 2, insets.bottom + 2, 
/* 406 */           insets.right + 2);
/*     */     } 
/*     */     
/* 409 */     return new Insets(2, 2, 2, 2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Icon getHeaderIcon(MCColumnConfig column) {
/* 423 */     return (column != null) ? column.getHeaderIcon() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Font getHeaderFont(MCColumnConfig column, MCTable<?> table) {
/* 438 */     Font result = null;
/* 439 */     if (column != null) {
/* 440 */       result = column.getHeaderFont();
/*     */     }
/* 442 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Color getHeaderForeground(MCColumnConfig column, MCTable<?> table, boolean selected) {
/* 459 */     if (column == null) {
/* 460 */       return null;
/*     */     }
/*     */     
/* 463 */     if (selected) {
/* 464 */       Color color = column.getSelectedHeaderForeground();
/* 465 */       if (color != null) {
/* 466 */         return color;
/*     */       }
/*     */     } 
/* 469 */     if (column.isFilteredColumn()) {
/* 470 */       Color color = column.getFilteredHeaderForeground();
/* 471 */       if (color != null) {
/* 472 */         return color;
/*     */       }
/*     */     } 
/* 475 */     Color c = column.getHeaderForeground();
/* 476 */     return (c != null) ? c : column.getModeInfo().getLabelForeground();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Color getHeaderBackground(MCColumnConfig column, MCTable<?> table, boolean selected) {
/* 493 */     if (column == null) {
/* 494 */       return null;
/*     */     }
/*     */     
/* 497 */     if (selected) {
/* 498 */       Color c = column.getSelectedHeaderBackground();
/* 499 */       if (c != null) {
/* 500 */         return c;
/*     */       }
/*     */     } 
/* 503 */     if (column.isFilteredColumn()) {
/* 504 */       Color c = column.getFilteredHeaderBackground();
/* 505 */       if (c != null) {
/* 506 */         return c;
/*     */       }
/*     */     } 
/* 509 */     return column.getHeaderBackground();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Border getHeaderBorder(MCTable<?> table, boolean selected) {
/* 522 */     if (table == null)
/*     */     {
/*     */       
/* 525 */       return BorderFactory.createEmptyBorder(1, 1, 1, 1);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 537 */     Border border = UIManager.getBorder("TableHeader.cellBorder");
/* 538 */     if (border == null)
/*     */     {
/*     */       
/* 541 */       border = BorderFactory.createEmptyBorder(1, 1, 1, 1);
/*     */     }
/* 543 */     return border;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isSynth() {
/* 570 */     return UIManager.getLookAndFeel() instanceof javax.swing.plaf.synth.SynthLookAndFeel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   class PlainBorder
/*     */     extends AbstractBorder
/*     */   {
/*     */     private Color lineColor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private int thick;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public PlainBorder(Color lineColor, int thick) {
/* 605 */       this.lineColor = (lineColor != null) ? lineColor : Color.black;
/* 606 */       this.thick = thick;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Insets getBorderInsets(Component c) {
/* 617 */       return new Insets(this.thick, this.thick, this.thick, this.thick);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Insets getBorderInsets(Component c, Insets insets) {
/* 629 */       insets.left = insets.top = insets.right = insets.bottom = this.thick;
/* 630 */       return insets;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
/* 648 */       Color oldColor = g.getColor();
/* 649 */       g.setColor(this.lineColor);
/*     */       
/* 651 */       for (int i = 1; i <= this.thick; i++) {
/* 652 */         int x_end = x + width - i;
/* 653 */         int y_end = y + height - i;
/* 654 */         g.drawLine(x_end, y, x_end, y_end);
/* 655 */         g.drawLine(x, y_end, x_end, y_end);
/*     */       } 
/*     */       
/* 658 */       g.setColor(oldColor);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class LineLabel
/*     */     extends JLabel
/*     */   {
/*     */     private MCMultiLineHeaderRenderer renderer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     LineLabel(MCMultiLineHeaderRenderer renderer) {
/* 686 */       this.renderer = renderer;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void paintComponent(Graphics g) {
/* 703 */       Dimension rp = this.renderer.getPreferredSize();
/* 704 */       Dimension ip = this.renderer._image.getPreferredSize();
/* 705 */       Dimension p = getPreferredSize();
/* 706 */       rp.width -= ip.width;
/* 707 */       if (p.width > rp.width) {
/* 708 */         p.width = rp.width;
/* 709 */         setPreferredSize(p);
/* 710 */         setSize(p);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 732 */       super.paintComponent(g);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCMultiLineHeaderRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */