/*    */ package mcframe.clientCore.beans.table;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import javax.swing.JTable;
/*    */ import javax.swing.JTextField;
/*    */ import mcframe.commonCore.lang.MCCalendarDate;
/*    */ import mcframe.commonCore.lang.MCTimestamp;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCCellEditorTimestamp
/*    */   extends MCCellEditor
/*    */ {
/*    */   protected MCCellEditorTimestamp(String name, MCColumnConfig column) {
/* 28 */     super((JTextField)new MCEditorTimestampField(name, column), column);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected MCEditorTimestampField getEditorComponent() {
/* 39 */     return (MCEditorTimestampField)this.editorComponent;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final Component getTableCellEditorComponent(JTable table, Object value, boolean selected, int index, int column) {
/* 57 */     return (Component)getEditor((MCTable)table, (MCTimestamp)value, index, getColumnConfig());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected MCEditorTimestampField getEditor(MCTable<?> table, MCTimestamp value, int index, MCColumnConfig column) {
/* 73 */     MCEditorTimestampField compo = getEditorComponent();
/* 74 */     compo.setText("");
/* 75 */     compo.setColumnInfo(index, column);
/* 76 */     compo.setText((MCCalendarDate)value);
/* 77 */     return compo;
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCCellEditorTimestamp.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */