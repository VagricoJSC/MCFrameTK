/*    */ package mcframe.clientCore.beans.table;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import javax.swing.JTable;
/*    */ import javax.swing.JTextField;
/*    */ import mcframe.commonCore.lang.MCNumber;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCCellEditorNumber
/*    */   extends MCCellEditor
/*    */ {
/*    */   protected MCCellEditorNumber(String name, MCColumnConfig column) {
/* 28 */     super((JTextField)new MCEditorNumberField(name, column), column);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected MCEditorNumberField getEditorComponent() {
/* 39 */     return (MCEditorNumberField)this.editorComponent;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final Component getTableCellEditorComponent(JTable table, Object value, boolean selected, int index, int column) {
/* 57 */     return (Component)getEditor((MCTable)table, (MCNumber)value, index, getColumnConfig());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected MCEditorNumberField getEditor(MCTable<?> table, MCNumber value, int index, MCColumnConfig column) {
/* 73 */     MCEditorNumberField compo = getEditorComponent();
/* 74 */     compo.setColumnInfo(index, column);
/* 75 */     compo.setText(value);
/* 76 */     return compo;
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCCellEditorNumber.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */