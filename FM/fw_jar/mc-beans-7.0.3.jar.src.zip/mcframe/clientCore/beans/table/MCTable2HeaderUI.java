/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.util.Enumeration;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.event.MouseInputListener;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicTableHeaderUI;
/*     */ import javax.swing.table.JTableHeader;
/*     */ import javax.swing.table.TableCellRenderer;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import mcframe.commonCore.util.MCCollectionUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCTable2HeaderUI
/*     */   extends BasicTableHeaderUI
/*     */ {
/*     */   public static ComponentUI createUI(JComponent h) {
/*  44 */     return new MCTable2HeaderUI();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCTable2Header getMCHeader() {
/*  56 */     return (MCTable2Header)this.header;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TableCellRenderer getHeaderRenderer(TableColumn col) {
/*  72 */     TableCellRenderer renderer = col.getHeaderRenderer();
/*  73 */     if (renderer == null)
/*     */     {
/*  75 */       renderer = this.header.getDefaultRenderer();
/*     */     }
/*  77 */     return renderer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MouseInputListener createMouseInputListener() {
/*  86 */     return new MCTable2MouseInputHandler();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class MCTable2MouseInputHandler
/*     */     extends BasicTableHeaderUI.MouseInputHandler
/*     */   {
/*     */     public void mouseDragged(MouseEvent e) {
/*  99 */       if (!SwingUtilities.isLeftMouseButton(e)) {
/* 100 */         MCTable2HeaderUI.this.header.setResizingColumn((TableColumn)null);
/* 101 */         MCTable2HeaderUI.this.header.setDraggedColumn((TableColumn)null);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 107 */       TableColumn resizingColumn = MCTable2HeaderUI.this.header.getResizingColumn();
/* 108 */       TableColumn draggedColumn = MCTable2HeaderUI.this.header.getDraggedColumn();
/*     */       
/* 110 */       if (MCTable2HeaderUI.this.header.isEnabled() && 
/* 111 */         resizingColumn == null && draggedColumn != null) {
/* 112 */         int oi = MCTable2HeaderUI.this.viewIndexForColumn(draggedColumn);
/*     */         
/*     */         while (true) {
/* 115 */           super.mouseDragged(e);
/*     */           
/* 117 */           int ni = MCTable2HeaderUI.this.viewIndexForColumn(draggedColumn);
/* 118 */           if (oi == ni) {
/*     */             break;
/*     */           }
/*     */           
/* 122 */           TableColumn c = MCTable2HeaderUI.this.header.getTable().getColumnModel().getColumn(oi);
/* 123 */           if (!(c instanceof MCTableColumn) || (
/* 124 */             (MCTableColumn)c).isViewColumn()) {
/*     */             break;
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 132 */           oi = ni;
/*     */         } 
/*     */       } else {
/*     */         
/* 136 */         super.mouseDragged(e);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 141 */       if (!MCTable2HeaderUI.this.header.isEnabled()) {
/*     */         return;
/*     */       }
/* 144 */       if (MCTable2HeaderUI.this.header.getDraggedColumn() != null)
/*     */       {
/* 146 */         MCTable2HeaderUI.this.getMCHeader().resizeAndRepaint();
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void mousePressed(MouseEvent e) {
/* 154 */       if (!SwingUtilities.isLeftMouseButton(e)) {
/* 155 */         MCTable2HeaderUI.this.header.setResizingColumn((TableColumn)null);
/* 156 */         MCTable2HeaderUI.this.header.setDraggedColumn((TableColumn)null);
/*     */         return;
/*     */       } 
/* 159 */       super.mousePressed(e);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getColumnHeight(MCTable<?> table, TableColumn column, int index) {
/* 176 */     TableCellRenderer renderer = getHeaderRenderer(column);
/* 177 */     Component comp = renderer.getTableCellRendererComponent(
/* 178 */         table, 
/* 179 */         column.getHeaderValue(), 
/* 180 */         false, false, -1, index);
/* 181 */     return (comp.getPreferredSize()).height;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getTierHeight(MCTable2<?> table, int tier) {
/* 194 */     int height = 0;
/*     */     
/* 196 */     MCTable2ColumnModel cm = table.getColumnModel();
/* 197 */     int[] se = cm.getTierColumnIndex(tier);
/* 198 */     MCTableColumn[] va = table.getViewTableColumns();
/* 199 */     for (int i = se[0]; i < se[1]; i++) {
/* 200 */       TableColumn column = cm.getColumn(i);
/*     */ 
/*     */       
/* 203 */       if (MCCollectionUtil.contains(column, (Object[])va)) {
/* 204 */         int cHeight = getColumnHeight(table, column, i);
/* 205 */         height = Math.max(height, cHeight);
/*     */       } 
/*     */     } 
/*     */     
/* 209 */     return height;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getFixedHeaderHeight() {
/* 220 */     MCTable<?> ft = getMCHeader().getMCTable().getFixedColumnTable();
/* 221 */     MCTableColumn[] ca = ft.getTableColumns();
/* 222 */     MCTableColumn[] va = ft.getViewTableColumns();
/* 223 */     int fh = 0;
/* 224 */     for (int i = 0; i < ca.length; i++) {
/*     */ 
/*     */       
/* 227 */       if (MCCollectionUtil.contains(ca[i], (Object[])va)) {
/* 228 */         fh = Math.max(fh, getColumnHeight(ft, ca[i], i));
/*     */       }
/*     */     } 
/* 231 */     return fh;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getHeaderHeight() {
/* 242 */     MCTable2Header mcheader = getMCHeader();
/* 243 */     MCTable<?> t = mcheader.getMCTable();
/* 244 */     MCTableColumn[] cols = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 249 */     MCTable<?> tf = t.getFixedColumnTable();
/* 250 */     cols = tf.getTableColumns();
/* 251 */     int fixHeight = getFixedHeaderHeight();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 263 */     int fixcnt = cols.length;
/* 264 */     int scrHeight = 0;
/* 265 */     int rHeight = 0;
/* 266 */     MCTable2<?> tb = (MCTable2)t.getBodyTable();
/* 267 */     MCTable2ColumnModel cm = tb.getColumnModel();
/* 268 */     int collen = cm.getColumnCount();
/* 269 */     int[] retpos = cm.getReturnPositions();
/* 270 */     int tier = 0;
/*     */     
/* 272 */     MCTableColumn[] va = tb.getViewTableColumns();
/* 273 */     for (int i = 0; i < collen; i++) {
/* 274 */       TableColumn column = cm.getColumn(i);
/*     */ 
/*     */       
/* 277 */       if (MCCollectionUtil.contains(column, (Object[])va)) {
/* 278 */         int cHeight = getColumnHeight(tb, column, i);
/* 279 */         rHeight = Math.max(rHeight, cHeight);
/*     */       } 
/* 281 */       if (i >= retpos[tier] - fixcnt) {
/* 282 */         scrHeight += rHeight;
/* 283 */         rHeight = 0;
/* 284 */         tier++;
/*     */       } 
/*     */     } 
/*     */     
/* 288 */     return Math.max(fixHeight, scrHeight);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Dimension createHeaderSize(long width) {
/* 300 */     if (width > 2147483647L) {
/* 301 */       width = 2147483647L;
/*     */     }
/* 303 */     return new Dimension((int)width, getHeaderHeight());
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getMinimumSize(JComponent c) {
/* 308 */     MCTable2Header mcheader = getMCHeader();
/* 309 */     MCTable<?> t = mcheader.getMCTable();
/* 310 */     long width = (t == t.getBaseTable()) ? 
/*     */       
/* 312 */       getScrollMinimumWidth() : 
/*     */       
/* 314 */       getFixedMinimumWidth();
/* 315 */     return createHeaderSize(width);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long getFixedMinimumWidth() {
/* 326 */     long width = 0L;
/* 327 */     Enumeration<TableColumn> enumeration = 
/* 328 */       this.header.getColumnModel().getColumns();
/* 329 */     while (enumeration.hasMoreElements()) {
/* 330 */       TableColumn aColumn = enumeration.nextElement();
/* 331 */       width += aColumn.getMinWidth();
/*     */     } 
/* 333 */     return width;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long getScrollMinimumWidth() {
/* 344 */     MCTable2ColumnModel cm = getMCHeader().getTable2ColumnModel();
/* 345 */     return cm.getMinimumWidth();
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getMaximumSize(JComponent c) {
/* 350 */     MCTable2Header mcheader = getMCHeader();
/* 351 */     MCTable<?> t = mcheader.getMCTable();
/* 352 */     long width = (t == t.getBaseTable()) ? 
/*     */       
/* 354 */       getScrollMaximumWidth() : 
/*     */       
/* 356 */       getFixedMaximumWidth();
/* 357 */     return createHeaderSize(width);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long getFixedMaximumWidth() {
/* 368 */     long width = 0L;
/* 369 */     Enumeration<TableColumn> enumeration = 
/* 370 */       this.header.getColumnModel().getColumns();
/* 371 */     while (enumeration.hasMoreElements()) {
/* 372 */       TableColumn aColumn = enumeration.nextElement();
/* 373 */       width += aColumn.getMaxWidth();
/*     */     } 
/* 375 */     return width;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long getScrollMaximumWidth() {
/* 386 */     MCTable2ColumnModel cm = getMCHeader().getTable2ColumnModel();
/* 387 */     return cm.getMaximumWidth();
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getPreferredSize(JComponent c) {
/* 392 */     MCTable2Header mcheader = getMCHeader();
/* 393 */     MCTable<?> t = mcheader.getMCTable();
/* 394 */     long width = (t == t.getBaseTable()) ? 
/*     */       
/* 396 */       getScrollPreferredWidth() : 
/*     */       
/* 398 */       getFixedPreferredWidth();
/* 399 */     return createHeaderSize(width);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long getFixedPreferredWidth() {
/* 410 */     long width = 0L;
/* 411 */     Enumeration<TableColumn> enumeration = 
/* 412 */       this.header.getColumnModel().getColumns();
/* 413 */     while (enumeration.hasMoreElements()) {
/* 414 */       TableColumn aColumn = enumeration.nextElement();
/* 415 */       width += aColumn.getPreferredWidth();
/*     */     } 
/* 417 */     return width;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long getScrollPreferredWidth() {
/* 428 */     MCTable2ColumnModel cm = getMCHeader().getTable2ColumnModel();
/* 429 */     return cm.getPreferredWidth();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paint(Graphics g, JComponent c) {
/* 437 */     MCTable2Header mcheader = getMCHeader();
/* 438 */     if (mcheader.getColumnModel() == null) {
/*     */       return;
/*     */     }
/*     */     
/* 442 */     MCTable<?> table = mcheader.getMCTable();
/* 443 */     if (table == table.getBaseTable()) {
/*     */       
/* 445 */       paintScroll(g, (MCTable2)table);
/*     */     }
/*     */     else {
/*     */       
/* 449 */       paintFixed(g, table);
/*     */     } 
/*     */ 
/*     */     
/* 453 */     paintDrag(g);
/*     */ 
/*     */     
/* 456 */     this.rendererPane.removeAll();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void paintDrag(Graphics g) {
/* 470 */     TableColumn draggedColumn = this.header.getDraggedColumn();
/* 471 */     if (draggedColumn == null) {
/*     */       return;
/*     */     }
/*     */     
/* 475 */     int draggedColumnIndex = viewIndexForColumn(draggedColumn);
/* 476 */     Rectangle draggedCellRect = this.header.getHeaderRect(draggedColumnIndex);
/*     */ 
/*     */     
/* 479 */     g.setColor(this.header.getParent().getBackground());
/* 480 */     g.fillRect(draggedCellRect.x, draggedCellRect.y, 
/* 481 */         draggedCellRect.width, draggedCellRect.height);
/*     */     
/* 483 */     draggedCellRect.x += this.header.getDraggedDistance();
/*     */ 
/*     */     
/* 486 */     g.setColor(this.header.getBackground());
/* 487 */     g.fillRect(draggedCellRect.x, draggedCellRect.y, 
/* 488 */         draggedCellRect.width, draggedCellRect.height);
/*     */     
/* 490 */     paintCell(g, draggedCellRect, draggedColumnIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int viewIndexForColumn(TableColumn aColumn) {
/* 504 */     TableColumnModel cm = this.header.getColumnModel();
/* 505 */     for (int column = 0; column < cm.getColumnCount(); column++) {
/* 506 */       if (cm.getColumn(column) == aColumn) {
/* 507 */         return column;
/*     */       }
/*     */     } 
/* 510 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void paintFixed(Graphics g, MCTable<?> table) {
/* 522 */     Rectangle clipBounds = g.getClipBounds();
/*     */     
/* 524 */     Rectangle cellRect = new Rectangle(0, 0, 0, 0);
/* 525 */     cellRect.height = (getPreferredSize(getMCHeader())).height;
/*     */     
/* 527 */     MCTableColumn[] cols = table.getTableColumns();
/* 528 */     for (int i = 0; i < cols.length; i++) {
/* 529 */       cellRect.width = cols[i].getWidth();
/* 530 */       if (cellRect.intersects(clipBounds))
/*     */       {
/* 532 */         paintCell(g, cellRect, i);
/*     */       }
/* 534 */       cellRect.x += cellRect.width;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void paintScroll(Graphics g, MCTable2<?> table) {
/* 547 */     Rectangle cellRect = new Rectangle(0, 0, 0, 0);
/* 548 */     Rectangle clipBounds = g.getClipBounds();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 554 */     int line_e = 0;
/*     */     
/* 556 */     MCTable2ColumnModel cm = table.getColumnModel();
/* 557 */     int fixedpos = cm.getFixedColumnCount() - 1;
/* 558 */     int[] retpos = cm.getReturnPositions();
/* 559 */     MCTableColumn[] cols = table.getTableColumns();
/* 560 */     int tier = 0;
/*     */     
/* 562 */     int maxtieridx = table.getTierInRow() - 1;
/* 563 */     int fixedh = getFixedHeaderHeight();
/* 564 */     int scrlh = 0;
/*     */     
/* 566 */     for (int i = 0; i < cols.length; ) {
/* 567 */       cellRect.height = getTierHeight(table, tier);
/* 568 */       scrlh += cellRect.height;
/*     */ 
/*     */ 
/*     */       
/* 572 */       if (tier == maxtieridx && 
/* 573 */         scrlh < fixedh) {
/* 574 */         cellRect.height += fixedh - scrlh;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 579 */       cellRect.x = 0;
/* 580 */       int tierscnt = retpos[tier] - fixedpos;
/* 581 */       for (; i < tierscnt; i++) {
/* 582 */         cellRect.width = cols[i].getWidth();
/* 583 */         if (cellRect.intersects(clipBounds))
/*     */         {
/* 585 */           paintCell(g, cellRect, i);
/*     */         }
/* 587 */         cellRect.x += cellRect.width;
/*     */       } 
/* 589 */       if (tier == 0)
/*     */       {
/* 591 */         line_e = cellRect.x - 1;
/*     */       }
/* 593 */       cellRect.y += cellRect.height;
/* 594 */       tier++;
/*     */     } 
/*     */ 
/*     */     
/* 598 */     int line_s = cellRect.x;
/*     */     
/* 600 */     int line_y = cellRect.y - 1;
/*     */     
/* 602 */     if (table.getRowCount() > 0 && line_s < line_e) {
/* 603 */       boolean isSynth = 
/* 604 */         UIManager.getLookAndFeel() instanceof javax.swing.plaf.synth.SynthLookAndFeel;
/* 605 */       if (isSynth) {
/* 606 */         g.setColor(UIManager.getColor("MCTable.gridColor"));
/*     */       } else {
/*     */         
/* 609 */         g.setColor(table.getGridColor());
/*     */       } 
/* 611 */       g.drawLine(line_s, line_y, line_e, line_y);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void paintCell(Graphics g, Rectangle cellRect, int columnIndex) {
/* 625 */     TableColumn aColumn = this.header.getColumnModel().getColumn(columnIndex);
/* 626 */     paintCell(g, cellRect, columnIndex, (MCTableColumn)aColumn);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void paintCell(Graphics g, Rectangle cellRect, int columnIndex, MCTableColumn aColumn) {
/* 644 */     MCHeaderRendererCommon renderer = 
/* 645 */       (MCHeaderRendererCommon)getHeaderRenderer(aColumn);
/* 646 */     Component component = renderer.getTableCellRendererComponent(
/* 647 */         getMCHeader().getMCTable(), 
/* 648 */         (Comparable)aColumn.getHeaderValue(), 
/* 649 */         false, false, -1, columnIndex, aColumn);
/*     */ 
/*     */ 
/*     */     
/* 653 */     this.rendererPane.paintComponent(g, component, this.header, 
/* 654 */         cellRect.x, cellRect.y, cellRect.width, cellRect.height, true);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCTable2HeaderUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */