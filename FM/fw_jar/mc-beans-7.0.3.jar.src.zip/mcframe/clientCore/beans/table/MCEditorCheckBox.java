/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.FocusListener;
/*     */ import java.awt.event.KeyEvent;
/*     */ import javax.swing.border.Border;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCCheckBox;
/*     */ import mcframe.clientCore.beans.MCMode;
/*     */ import mcframe.clientCore.beans.MCResourceBeans;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.action.MCKeyActionManager;
/*     */ import mcframe.clientCore.event.MCEventInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCEditorCheckBox
/*     */   extends MCCheckBox
/*     */   implements MCEditorBeans
/*     */ {
/*     */   private static final String TYPE = "table.column.check";
/*     */   private MCColumnConfig _column;
/*     */   private MCTable<?> _table;
/*     */   
/*     */   protected MCEditorCheckBox(String name, MCColumnConfig column) {
/*  64 */     super(name);
/*  65 */     setColumnConfig(column);
/*  66 */     setTable(column.getBaseTable());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRatio() {
/*  78 */     return getColumnConfig().getBaseTable().getRatio();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initBeans() {
/*  83 */     super.initBeans();
/*     */ 
/*     */     
/*  86 */     setOpaque(true);
/*     */ 
/*     */     
/*  89 */     setHorizontalAlignment(0);
/*     */ 
/*     */     
/*  92 */     setFocusTraversalKeysEnabled(false);
/*     */     
/*  94 */     setBorder(MCCellUtil.DEFAULT_BORDER); byte b;
/*     */     int i;
/*     */     FocusListener[] arrayOfFocusListener;
/*  97 */     for (i = (arrayOfFocusListener = getFocusListeners()).length, b = 0; b < i; ) { FocusListener l = arrayOfFocusListener[b];
/*  98 */       removeFocusListener(l);
/*     */       b++; }
/*     */   
/*     */   }
/*     */   
/*     */   protected MCCheckBox.MCCheckBoxModel createModel() {
/* 104 */     return new MCEditorCheckBoxModel();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initKeyAssign() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initResource() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getType() {
/* 129 */     return "table.column.check";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setColumnConfig(MCColumnConfig column) {
/* 140 */     this._column = column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCColumnConfig getColumnConfig() {
/* 152 */     return this._column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setTable(MCTable<?> table) {
/* 163 */     this._table = table;
/*     */   }
/*     */ 
/*     */   
/*     */   public final MCTable getTable() {
/* 168 */     return this._table;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getRowIndex() {
/* 174 */     return MCCellUtil.getRowIndex(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void transferFocus() {
/* 179 */     MCTable<?> t = getTable();
/* 180 */     t.transferFocus(getRowIndex(), t.getViewColumn(getColumnConfig()) + 1, false, 
/* 181 */         true, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCRootPanel getRootPanel() {
/* 186 */     return MCCellUtil.getRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCRootPanel getNearestRootPanel() {
/* 191 */     return MCCellUtil.getNearestRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessageByLocale() {
/* 196 */     return getColumnConfig().getMessageByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLabelByLocale() {
/* 201 */     return getColumnConfig().getLabelByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterRequestFocus() {
/* 206 */     MCBeansUtil.afterRequestFocus(getTable());
/*     */   }
/*     */ 
/*     */   
/*     */   public void commitValue() {
/* 211 */     getTable().commitValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public Border getDefaultBorder() {
/* 216 */     return MCCellUtil.DEFAULT_BORDER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setColumnInfo(int index, MCColumnConfig column) {
/* 229 */     setColumnConfig(column);
/* 230 */     MCTable<?> table = getTable();
/* 231 */     MCKeyActionManager.init((MCResourceBeans)this, getInputMap(), getActionMap());
/* 232 */     MCKeyActionManager.initScreen((MCResourceBeans)this, getInputMap(), getActionMap());
/* 233 */     MCMode mode = MCCellUtil.isCellEditable(index, column, table);
/* 234 */     setMode(mode);
/* 235 */     setForeground(MCCellUtil.getForeground(index, column, table, false, mode));
/* 236 */     setBackground(MCCellUtil.getBackground(index, column, table, false, mode));
/* 237 */     setFont(column.getFont());
/* 238 */     setMeta(column.getMeta());
/* 239 */     setIcon(column.getIcon());
/* 240 */     setSelectedIcon(column.getSelectedIcon());
/* 241 */     setPressedIcon(column.getPressedIcon());
/* 242 */     setDisabledIcon(column.getDisabledIcon());
/* 243 */     setDisabledSelectedIcon(column.getDisabledSelectedIcon());
/* 244 */     setRow(column.getTable().getRow(index), column.getRowColumnName());
/*     */     
/* 246 */     Border border = MCCellUtil.getEditorBorder(index, column, table);
/* 247 */     if (border != null) {
/* 248 */       setBorder(border);
/*     */     } else {
/*     */       
/* 251 */       setBorder(getDefaultBorder());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFocusOwner() {
/* 257 */     MCTable<?> t = getTable();
/* 258 */     return (t != null) ? (t.isRemoveNotifyProcessing() ? super.isFocusOwner() : false) : 
/* 259 */       super.isFocusOwner();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isMCFocusOwner() {
/* 264 */     MCTable<?> t = getTable();
/* 265 */     return (t != null) ? ((t.getMCEditorComponent() == this)) : isFocusOwner();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void fireActionPerformed(ActionEvent event) {
/*     */     try {
/* 272 */       MCTable.setEditingStoppedEnabled(false);
/* 273 */       super.fireActionPerformed(event);
/* 274 */       Component o = MCBeansUtil.getFocusOwner(getTable());
/* 275 */       if (o instanceof MCTable) {
/* 276 */         MCTable<?> t = (MCTable)o;
/* 277 */         if (t == getTable() && !t.hasFocus()) {
/* 278 */           t.requestFocus();
/*     */         }
/*     */       } 
/*     */     } finally {
/*     */       
/* 283 */       MCTable.setEditingStoppedEnabled(true);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValueChanged() {
/* 289 */     return isValueChanged(getRowValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValueChanged(Comparable<?> value) {
/* 303 */     return isValueChanged(Boolean.valueOf(getValue()), value);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isValueChanged(Comparable<?> view, Comparable<?> row) {
/* 308 */     return MCCellUtil.isValueChanged(this, view, row);
/*     */   }
/*     */ 
/*     */   
/*     */   public void valueCommited() {
/* 313 */     MCEventProxy.PROXY.setValue(getEventInfo(), getRowValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getText() {
/* 318 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean doVC() {
/* 323 */     return getColumnConfig().doVC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNC() {
/* 328 */     getColumnConfig().doNC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNE() {
/* 333 */     getColumnConfig().doNE();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNX() {
/* 338 */     getColumnConfig().doNX();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCEventInfo getEventInfo() {
/* 343 */     return getColumnConfig().getEventInfo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void focusGained() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void focusLost() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRequestFocusEnabled() {
/* 368 */     return (MCCellUtil.isRequestFocusEnabled(this) && super.isRequestFocusEnabled());
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isMCRequestFocusEnabled() {
/* 373 */     return MCCellUtil.isFocusable(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public Border getBorder() {
/* 378 */     Border b = MCCellUtil.getBorder(this);
/* 379 */     return (b != null) ? b : super.getBorder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource(MCRootPanel panel) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doCheckValueError() {
/* 405 */     super.doCheckValueError();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void processKeyEvent(KeyEvent e) {
/* 410 */     MCCellUtil.beforeKeyEvent(e, this);
/* 411 */     super.processKeyEvent(e);
/*     */   }
/*     */ 
/*     */   
/*     */   public Comparable<?> doListFormat(Comparable<?> value) {
/* 416 */     return getColumnConfig().doListFormat(getRowIndex(), value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class MCEditorCheckBoxModel
/*     */     extends MCCheckBox.MCCheckBoxModel
/*     */   {
/*     */     public MCEditorCheckBoxModel() {
/* 426 */       super(MCEditorCheckBox.this);
/*     */     }
/*     */     
/*     */     protected void _beforeSelectionChange(boolean selected) {
/* 430 */       MCEventInfo i = MCEditorCheckBox.this.getEventInfo();
/* 431 */       MCEventProxy.PROXY.setValue(i, Boolean.valueOf(isSelected()), Boolean.valueOf(selected));
/* 432 */       MCEventProxy.PROXY.setEventIndex(i, MCEditorCheckBox.this.getRowIndex());
/*     */       
/* 434 */       MCTable<?> t = MCEditorCheckBox.this.getTable();
/* 435 */       if (t != null) {
/* 436 */         i = t.getEventInfo();
/* 437 */         MCEventProxy.PROXY.setEventIndex(i, MCEditorCheckBox.this.getRowIndex());
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public final void focusGainedSelect() {}
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCEditorCheckBox.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */