/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.swing.JComponent;
/*     */ import mcframe.clientCore.beans.AbsMCPackageProxy;
/*     */ import mcframe.clientCore.beans.MCACBeans;
/*     */ import mcframe.clientCore.beans.MCBeans;
/*     */ import mcframe.clientCore.beans.MCCacheType;
/*     */ import mcframe.clientCore.beans.MCFrame;
/*     */ import mcframe.clientCore.beans.MCModeBeans;
/*     */ import mcframe.clientCore.beans.MCPropertyCache;
/*     */ import mcframe.clientCore.beans.MCResourceBeans;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.MCWriteType;
/*     */ import mcframe.clientCore.beans.action.MCFocusReservationInfo;
/*     */ import mcframe.clientCore.beans.list.MCLinkBeans;
/*     */ import mcframe.clientCore.beans.resource.MCPersonalizeGroupInfo;
/*     */ import mcframe.clientCore.event.MCEventInfo;
/*     */ import mcframe.clientCore.event.MCFDBeans;
/*     */ import mcframe.clientCore.event.MCFDListener;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCDataType;
/*     */ import mcframe.commonCore.lang.MCDateFieldType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MCBeansProxy
/*     */   extends AbsMCPackageProxy
/*     */ {
/*  46 */   static final MCBeansProxy PROXY = new MCBeansProxy();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected List<MCFocusReservationInfo> getFocusReservationList(MCRootPanel p) {
/*  60 */     return super.getFocusReservationList(p);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isInitFocusLaterEnd(MCRootPanel panel) {
/*  65 */     return super.isInitFocusLaterEnd(panel);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setFocusOwner(MCRootPanel panel, JComponent compo) {
/*  72 */     super.setFocusOwner(panel, compo);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addColumn(MCRow row, String name, MCDataType type, Comparable<?> value) {
/*  78 */     super.addColumn(row, name, type, value);
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCFrame[] getActiveFrame() {
/*  83 */     return super.getActiveFrame();
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCPropertyCache getPropertyCache(MCRootPanel panel, MCCacheType type) {
/*  88 */     return super.getPropertyCache(panel, type);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getBeansString(MCRootPanel panel, MCPropertyCache cache, String key) {
/*  94 */     return super.getBeansString(panel, cache, key);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected char getBeansCharacter(MCRootPanel panel, MCPropertyCache cache, String key, char def) {
/* 100 */     return super.getBeansCharacter(panel, cache, key, def);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean getBeansBoolean(MCRootPanel panel, MCPropertyCache cache, String key, boolean def) {
/* 107 */     return super.getBeansBoolean(panel, cache, key, def);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isEventEnabled() {
/* 112 */     return super.isEventEnabled();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setEventEnabled(boolean enabled) {
/* 117 */     super.setEventEnabled(enabled);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getLayoutKey(MCResourceBeans compo, String suffix) {
/* 122 */     return super.getLayoutKey(compo, suffix);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setPartsPanel(MCRootPanel panel, MCRootPanel parts) {
/* 127 */     super.setPartsPanel(panel, parts);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getBeansKey(MCResourceBeans compo, String prefix) {
/* 132 */     return super.getBeansKey(compo, prefix);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String getNameForMessage(MCBeans compo, String msg) {
/* 137 */     return super.getNameForMessage(compo, msg);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String trim(String value, String pattern) {
/* 142 */     return super.trim(value, pattern);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isACTypeDisable(MCACBeans compo) {
/* 147 */     return super.isACTypeDisable(compo);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Font getBeansFont(MCRootPanel panel, MCPropertyCache cache, String key) {
/* 152 */     return super.getBeansFont(panel, cache, key);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Color getBeansColor(MCRootPanel panel, MCPropertyCache cache, String key) {
/* 157 */     return super.getBeansColor(panel, cache, key);
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCDateFieldType[] getDateFieldTypeArray(String format) {
/* 162 */     return super.getDateFieldTypeArray(format);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String adjustMessageName(String name) {
/* 167 */     return super.adjustMessageName(name);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean haveLinkValuesNull(MCEventInfo e, MCLinkBeans b, Comparable<?> v, MCList<?> list, String key) {
/* 173 */     return super.haveLinkValuesNull(e, b, v, list, key);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String[] getPasswordDialogID(MCRootPanel panel) {
/* 178 */     return super.getPasswordDialogID(panel);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean checkPassword(MCACBeans compo) {
/* 183 */     return super.checkPassword(compo);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isDropEnable(MCBeans compo) {
/* 189 */     return super.isDropEnable(compo);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void fd(MCFDBeans fd, Map<String, List<MCFDListener>> map) {
/* 194 */     super.fd(fd, map);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setDndResourceInfo(MCFDBeans compo) {
/* 199 */     super.setDndResourceInfo(compo);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doCheckValueError(MCBeans compo) {
/* 206 */     super.doCheckValueError(compo);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doExcelInAction(MCRootPanel panel, MCTable<?> table) {
/* 211 */     super.doExcelInAction(panel, table);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doExcelOutAction(MCRootPanel panel, MCTable<?> table, MCWriteType type) {
/* 217 */     super.doExcelOutAction(panel, table, type);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void doExcelOpenAction(MCRootPanel panel, MCTable<?> table, MCWriteType type) {
/* 223 */     super.doExcelOpenAction(panel, table, type);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doCSVInAction(MCRootPanel panel, MCTable<?> table) {
/* 228 */     super.doCSVInAction(panel, table);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void doCSVOutAction(MCRootPanel panel, MCTable<?> table, MCWriteType type) {
/* 233 */     super.doCSVOutAction(panel, table, type);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setSrchRsltCountToStatusBar(MCTable t) {
/* 238 */     super.setSrchRsltCountToStatusBar(t);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setMessageToStatusBar(MCRootPanel p, String msg) {
/* 243 */     super.setMessageToStatusBar(p, msg);
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCPersonalizeGroupInfo getInitPersonalizeGroupInfo(MCRootPanel panel) {
/* 248 */     return super.getInitPersonalizeGroupInfo(panel);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String createGUIKey(MCModeBeans compo) {
/* 253 */     return super.createGUIKey(compo);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCBeansProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */