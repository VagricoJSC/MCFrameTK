package mcframe.clientCore.beans.table;

public interface MCColumnLayoutMember {
  String getName();
  
  int getWidth();
  
  int getMaxWidth();
  
  int getMinWidth();
  
  int getPreferredWidth();
  
  void setWidth(int paramInt);
  
  void setMaxWidth(int paramInt);
  
  void setMinWidth(int paramInt);
  
  void setPreferredWidth(int paramInt);
  
  void setDefault();
  
  boolean isVisible();
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCColumnLayoutMember.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */