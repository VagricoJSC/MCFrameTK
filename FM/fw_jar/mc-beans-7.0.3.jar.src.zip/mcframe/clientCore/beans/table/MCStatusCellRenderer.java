/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.table.DefaultTableCellRenderer;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCStatusCellRenderer
/*     */   extends DefaultTableCellRenderer
/*     */   implements MCInfraCellRenderer
/*     */ {
/*     */   private final MCColumnConfig _column;
/*     */   
/*     */   protected MCStatusCellRenderer(MCColumnConfig column) {
/*  38 */     this._column = column;
/*  39 */     setHorizontalAlignment(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCColumnConfig getColumnConfig() {
/*  50 */     return this._column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Component getTableCellRendererComponent(JTable table, Object value, boolean selected, boolean focused, int index, int column) {
/*  69 */     return getRenderer((MCTable)table, value, selected, focused, index, getColumnConfig());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Component getRenderer(MCTable<?> table, Object value, boolean selected, boolean focused, int index, MCColumnConfig column) {
/*     */     try {
/*  88 */       MCCellConfig conf = column.getCellConfig();
/*  89 */       MCRow.Status status = table.getRow(index).getStatus();
/*  90 */       MCTable<?> tbl = column.getTable();
/*  91 */       setForeground(conf.getStatusColumnForeground(
/*  92 */             index, column, tbl, selected, status));
/*  93 */       setBackground(conf.getStatusColumnBackground(
/*  94 */             index, column, tbl, selected, status));
/*  95 */       setValue(conf.getStatusColumnValue(
/*  96 */             index, column, tbl, selected, status));
/*  97 */       setFont(column.getFont());
/*     */     
/*     */     }
/* 100 */     catch (RuntimeException e) {
/* 101 */       MCCellUtil.preHandle(table, e);
/* 102 */       MCCellUtil.handle(table, e);
/*     */     } 
/* 104 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Comparable<?> getValue() {
/* 109 */     return getText();
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCStatusCellRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */