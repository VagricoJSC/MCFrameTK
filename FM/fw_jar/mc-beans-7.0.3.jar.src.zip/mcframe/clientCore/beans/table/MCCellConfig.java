/*      */ package mcframe.clientCore.beans.table;
/*      */ 
/*      */ import java.awt.Color;
/*      */ import java.math.RoundingMode;
/*      */ import javax.swing.BorderFactory;
/*      */ import javax.swing.Icon;
/*      */ import javax.swing.ImageIcon;
/*      */ import javax.swing.JComponent;
/*      */ import javax.swing.border.BevelBorder;
/*      */ import javax.swing.border.Border;
/*      */ import mcframe.clientCore.beans.MCCalendarField;
/*      */ import mcframe.clientCore.beans.MCMode;
/*      */ import mcframe.clientCore.beans.MCRootPanel;
/*      */ import mcframe.clientCore.beans.text.MCDateFormat;
/*      */ import mcframe.clientCore.beans.text.MCNumberFormat;
/*      */ import mcframe.clientCore.beans.text.MCTimestampFormat;
/*      */ import mcframe.clientCore.resource.MCConst;
/*      */ import mcframe.commonCore.container.MCRow;
/*      */ import mcframe.commonCore.lang.MCDate;
/*      */ import mcframe.commonCore.lang.MCNumber;
/*      */ import mcframe.commonCore.lang.MCStringUtil;
/*      */ import mcframe.commonCore.lang.MCTimestamp;
/*      */ import mcframe.commonCore.resource.MCFormatConst;
/*      */ import mcframe.commonCore.resource.ctrl.MCResource;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MCCellConfig
/*      */ {
/*      */   protected MCMode isCellEditable(int index, MCColumnConfig column, MCTable<?> table) {
/*  140 */     MCMode m = column.getMode();
/*  141 */     if (column.getModeInfo(m) == null) {
/*  142 */       return m;
/*      */     }
/*      */     
/*  145 */     if (column.getModeInfo(m).getStatus() != 1) {
/*  146 */       return m;
/*      */     }
/*  148 */     return table.getRow(index).isStatusDelete() ? MCMode.DISABLE : m;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MCNumberFormat getCellNumberFormat(int index, MCColumnConfig column, MCTable<?> table, MCMode mode) {
/*  172 */     return column.getNumberFormat();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MCDateFormat getCellDateFormat(int index, MCColumnConfig column, MCTable<?> table, MCMode mode) {
/*  196 */     return column.getDateFormat();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MCTimestampFormat getCellTimestampFormat(int index, MCColumnConfig column, MCTable<?> table, MCMode mode) {
/*  220 */     return column.getTimestampFormat();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MCNumberFormat getCellListNumberFormat(int index, MCColumnConfig column, MCTable<?> table) {
/*  242 */     return column.getListNumberFormat();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MCDateFormat getCellListDateFormat(int index, MCColumnConfig column, MCTable<?> table) {
/*  264 */     return column.getListDateFormat();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MCTimestampFormat getCellListTimestampFormat(int index, MCColumnConfig column, MCTable<?> table) {
/*  286 */     return column.getListTimestampFormat();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Color getCellBackground(int index, MCColumnConfig column, MCTable<?> table, boolean selected, MCMode mode) {
/*  316 */     return selected ? getSelectedRowBackground(index, column, table, mode) : (
/*  317 */       table.getRow(index).isStatusDelete() ? 
/*  318 */       getDeletedRowBackground(index, column, table, mode) : 
/*  319 */       getCellBackground(index, column, table, mode));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Color getCellBackground(int index, MCColumnConfig column, MCTable<?> table, MCMode mode) {
/*  348 */     return isOddRow(index, column, table, mode) ? 
/*  349 */       getOddCellBackground(column, table, mode) : 
/*  350 */       getEvenCellBackground(column, table, mode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Color getSelectedRowBackground(int index, MCColumnConfig column, MCTable<?> table, MCMode mode) {
/*      */     String key;
/*  378 */     MCRootPanel p = table.getBaseRootPanel();
/*  379 */     JComponent o = p.getFocusOwner();
/*  380 */     if (table.getBaseTable().equalsIgnoreCase(o)) {
/*  381 */       key = "selected.bg";
/*      */     } else {
/*      */       
/*  384 */       key = "selected.nofocus.bg";
/*      */     } 
/*  386 */     Color color = getCellBackground(index, column, table, mode);
/*  387 */     Color result = column.getModeColor(mode, key, color, true);
/*  388 */     if (result == null) {
/*  389 */       result = getColor(column, getColumnType(column), mode, key, color, true);
/*      */     }
/*  391 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Color getDeletedRowBackground(int index, MCColumnConfig column, MCTable<?> table, MCMode mode) {
/*  417 */     if (column.getModeInfo(mode) == null) {
/*  418 */       return getCellBackground(index, column, table, mode);
/*      */     }
/*      */     
/*  421 */     if (2 != column.getModeInfo(mode).getStatus()) {
/*  422 */       return getCellBackground(index, column, table, mode);
/*      */     }
/*      */ 
/*      */     
/*  426 */     String key = "deleted.bg";
/*  427 */     Color result = column.getModeColor(mode, key);
/*  428 */     if (result == null) {
/*  429 */       result = getColor(column, getColumnType(column), mode, key);
/*      */     }
/*  431 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Color getFocusedCellBackground(int index, MCColumnConfig column, MCTable<?> table, MCMode mode) {
/*  456 */     Color result = column.getFocusedCellBackground();
/*  457 */     if (result == null) {
/*  458 */       result = table.getFocusedCellBackground();
/*  459 */       if (result == null) {
/*  460 */         String key = "focused.bg";
/*  461 */         result = column.getModeColor(mode, key);
/*  462 */         if (result == null) {
/*  463 */           result = getColor(column, getColumnType(column), mode, key);
/*      */         }
/*      */       } 
/*      */     } 
/*  467 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Color getCellForeground(int index, MCColumnConfig column, MCTable<?> table, boolean selected, MCMode mode) {
/*  497 */     return selected ? getSelectedRowForeground(index, column, table, mode) : (
/*  498 */       table.getRow(index).isStatusDelete() ? 
/*  499 */       getDeletedRowForeground(index, column, table, mode) : 
/*  500 */       getCellForeground(index, column, table, mode));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Color getCellForeground(int index, MCColumnConfig column, MCTable<?> table, MCMode mode) {
/*  529 */     return isOddRow(index, column, table, mode) ? 
/*  530 */       getOddCellForeground(index, column, table, mode) : 
/*  531 */       getEvenCellForeground(index, column, table, mode);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Color getSelectedRowForeground(int index, MCColumnConfig column, MCTable<?> table, MCMode mode) {
/*      */     String key;
/*  560 */     MCRootPanel p = table.getBaseRootPanel();
/*  561 */     JComponent o = p.getFocusOwner();
/*  562 */     if (table.getBaseTable().equalsIgnoreCase(o)) {
/*  563 */       key = "selected.fg";
/*      */     } else {
/*      */       
/*  566 */       key = "selected.nofocus.fg";
/*      */     } 
/*  568 */     Color color = getCellForeground(index, column, table, mode);
/*  569 */     Color result = column.getModeColor(mode, key, color, false);
/*  570 */     if (result == null) {
/*  571 */       result = getColor(column, getColumnType(column), mode, key, color, false);
/*      */     }
/*  573 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Color getDeletedRowForeground(int index, MCColumnConfig column, MCTable<?> table, MCMode mode) {
/*  598 */     String key = "deleted.fg";
/*  599 */     Color result = column.getModeColor(mode, key);
/*  600 */     if (result == null) {
/*  601 */       result = getColor(column, getColumnType(column), mode, key);
/*      */     }
/*  603 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Color getFocusedCellForeground(int index, MCColumnConfig column, MCTable<?> table, MCMode mode) {
/*  628 */     Color result = column.getFocusedCellForeground();
/*  629 */     if (result == null) {
/*  630 */       result = table.getFocusedCellForeground();
/*  631 */       if (result == null) {
/*  632 */         String key = "focused.fg";
/*  633 */         result = column.getModeColor(mode, key);
/*  634 */         if (result == null) {
/*  635 */           result = getColor(column, getColumnType(column), mode, key);
/*      */         }
/*      */       } 
/*      */     } 
/*  639 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Color getCellCaretColor(int index, MCColumnConfig column, MCTable<?> table) {
/*  662 */     Color result = column.getCaretColor();
/*  663 */     return (result != null) ? result : 
/*  664 */       getColor(column, column.getType(), "caretcolor");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Color getCellSelectionColor(int index, MCColumnConfig column, MCTable<?> table) {
/*  687 */     Color result = column.getSelectionColor();
/*  688 */     return (result != null) ? result : 
/*  689 */       getColor(column, column.getType(), "selbg");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Color getCellSelectedTextColor(int index, MCColumnConfig column, MCTable<?> table) {
/*  712 */     Color result = column.getSelectedTextColor();
/*  713 */     return (result != null) ? result : 
/*  714 */       getColor(column, column.getType(), "selfg");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Border getColumnBorder(int index, MCColumnConfig column, MCTable<?> table) {
/*  740 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Border getEditorBorder(int index, MCColumnConfig column, MCTable<?> table) {
/*  766 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Color getRowNumberColumnForeground(int index, MCColumnConfig column, MCTable<?> table, boolean selected) {
/*  784 */     String k = "rownumber.fg";
/*  785 */     if (table.isFilterList()) {
/*  786 */       k = "rownumber.filtered.fg";
/*      */     }
/*  788 */     return getColor(column, table.getType(), k);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Color getRowNumberColumnBackground(int index, MCColumnConfig column, MCTable<?> table, boolean selected) {
/*  806 */     String k = "rownumber.bg";
/*  807 */     if (table.isFilterList()) {
/*  808 */       k = "rownumber.filtered.bg";
/*      */     }
/*  810 */     return getColor(column, table.getType(), k);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Border getRowNumberColumnBorder(int index, MCColumnConfig column, MCTable<?> table, boolean selected) {
/*  827 */     return selected ? BorderFactory.createLoweredBevelBorder() : 
/*  828 */       new BevelBorder(0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getRowNumberColumnValue(int index, MCColumnConfig column, MCTable<?> table, boolean selected) {
/*  845 */     return String.valueOf(index + 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Color getStatusColumnForeground(int index, MCColumnConfig column, MCTable<?> table, boolean selected, MCRow.Status status) {
/*  864 */     String type = table.getType();
/*  865 */     switch (status) {
/*      */       case DELETE:
/*  867 */         return getColor(column, type, "status.del.fg");
/*      */       case MODIFY:
/*  869 */         return getColor(column, type, "status.upd.fg");
/*      */       case null:
/*  871 */         return getColor(column, type, "status.ins.fg");
/*      */       case NONE:
/*      */       case GUICREATE:
/*  874 */         return getColor(column, type, "status.none.fg");
/*      */     } 
/*  876 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Color getStatusColumnBackground(int index, MCColumnConfig column, MCTable<?> table, boolean selected, MCRow.Status status) {
/*  896 */     String type = table.getType();
/*  897 */     switch (status) {
/*      */       case DELETE:
/*  899 */         return getColor(column, type, "status.del.bg");
/*      */       case MODIFY:
/*  901 */         return getColor(column, type, "status.upd.bg");
/*      */       case null:
/*  903 */         return getColor(column, type, "status.ins.bg");
/*      */       case NONE:
/*      */       case GUICREATE:
/*  906 */         return getColor(column, type, "status.none.bg");
/*      */     } 
/*  908 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Border getStatusColumnBorder(int index, MCColumnConfig column, MCTable<?> table, boolean selected, MCRow.Status status) {
/*  928 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getStatusColumnValue(int index, MCColumnConfig column, MCTable<?> table, boolean selected, MCRow.Status status) {
/*  946 */     String key = getStatusColumnValueDefault(column, table, status);
/*  947 */     if (key == null) {
/*  948 */       return null;
/*      */     }
/*  950 */     return key;
/*      */   }
/*      */ 
/*      */   
/*      */   String getStatusColumnValueDefault(MCColumnConfig column, MCTable<?> table, MCRow.Status status) {
/*  955 */     String key = null;
/*  956 */     switch (status) {
/*      */       case DELETE:
/*  958 */         key = "status.del.mark";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  972 */         return column.getString(table.getType(), key);case MODIFY: key = "status.upd.mark"; return column.getString(table.getType(), key);case null: key = "status.ins.mark"; return column.getString(table.getType(), key);case NONE: key = "status.none.mark"; return column.getString(table.getType(), key);
/*      */     } 
/*      */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ImageIcon getRowSignalColumnIcon(int index, MCColumnConfig column, MCTable<?> table, boolean selected, int signal) {
/*  989 */     return MCRowSignal.geIcon(signal);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getCellLength(int index, MCColumnConfig column, MCTable<?> table) {
/* 1009 */     return column.getLength();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getCellScale(int index, MCColumnConfig column, MCTable<?> table) {
/* 1029 */     return column.getScale();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isCellMinusEnable(int index, MCColumnConfig column, MCTable<?> table) {
/* 1050 */     return column.isMinusEnable();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Color getColor(MCColumnConfig column, String type, MCMode mode, String key) {
/* 1077 */     String temp = (column.getModeInfo(mode) == null || 
/* 1078 */       column.getModeInfo(mode).getStatus() == 1) ? 
/* 1079 */       "editable" : "non-editable";
/* 1080 */     return column.getColor(type, MCResource.createKey(new String[] { temp, key }));
/*      */   }
/*      */   
/*      */   private Color getColor(MCColumnConfig column, String type, String key) {
/* 1084 */     return column.getColor(type, key);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Color getOddCellBackground(MCColumnConfig column, MCTable<?> table, MCMode mode) {
/* 1107 */     if (column != null && table != null && mode != null) {
/* 1108 */       Color color = column.getBackground();
/* 1109 */       if (color == null) {
/* 1110 */         String key = "odd.bg";
/* 1111 */         color = column.getModeColor(mode, key);
/* 1112 */         if (color == null) {
/* 1113 */           color = getColor(column, getColumnType(column), mode, key);
/*      */         }
/*      */       } 
/* 1116 */       return color;
/*      */     } 
/* 1118 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Color getEvenCellBackground(MCColumnConfig column, MCTable<?> table, MCMode mode) {
/* 1141 */     if (column != null && table != null && mode != null) {
/* 1142 */       Color color = column.getBackground();
/* 1143 */       if (color == null) {
/* 1144 */         String key = "even.bg";
/* 1145 */         color = column.getModeColor(mode, key);
/* 1146 */         if (color == null) {
/* 1147 */           color = getColor(column, getColumnType(column), mode, key);
/*      */         }
/*      */       } 
/* 1150 */       return color;
/*      */     } 
/* 1152 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Color getOddCellForeground(int index, MCColumnConfig column, MCTable<?> table, MCMode mode) {
/* 1177 */     if (column != null && table != null && mode != null) {
/* 1178 */       Color color = column.getForeground();
/* 1179 */       if (color == null) {
/* 1180 */         color = getNumberCellForeground(index, column, table, mode);
/* 1181 */         if (color == null) {
/* 1182 */           String key = "odd.fg";
/* 1183 */           color = column.getModeColor(mode, key);
/* 1184 */           if (color == null) {
/* 1185 */             color = getColor(column, getColumnType(column), mode, key);
/*      */           }
/*      */         } 
/*      */       } 
/* 1189 */       return color;
/*      */     } 
/* 1191 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Color getEvenCellForeground(int index, MCColumnConfig column, MCTable<?> table, MCMode mode) {
/* 1216 */     if (column != null && table != null && mode != null) {
/* 1217 */       Color color = column.getForeground();
/* 1218 */       if (color == null) {
/* 1219 */         color = getNumberCellForeground(index, column, table, mode);
/* 1220 */         if (color == null) {
/* 1221 */           String key = "even.fg";
/* 1222 */           color = column.getModeColor(mode, key);
/* 1223 */           if (color == null) {
/* 1224 */             color = getColor(column, getColumnType(column), mode, key);
/*      */           }
/*      */         } 
/*      */       } 
/* 1228 */       return color;
/*      */     } 
/* 1230 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isOddRow(int index, MCColumnConfig column, MCTable<?> table, MCMode mode) {
/* 1246 */     return ((index + 1) % 2 != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Color getNumberCellForeground(int index, MCColumnConfig column, MCTable<?> table, MCMode mode) {
/* 1268 */     if (column != null) {
/* 1269 */       MCColumnType type = column.getColumnType();
/* 1270 */       if (type == MCColumnType.NUMBER || type == MCColumnType.NUMBER_COMBO || 
/* 1271 */         type == MCColumnType.NUMBER_COMBO_FREE || 
/* 1272 */         type == MCColumnType.NUMBER_COMBO_SELECT_ONLY) {
/* 1273 */         MCNumber value = (MCNumber)column.getValue(index);
/* 1274 */         MCNumberFormat format = column.getNumberFormat();
/* 1275 */         if (value != null && value.isNegative()) {
/* 1276 */           return format.getNegativeForeground();
/*      */         }
/* 1278 */         return format.getPositiveForeground();
/*      */       } 
/*      */     } 
/* 1281 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private Color getColor(MCColumnConfig column, String type, MCMode mode, String key, Color color, boolean darker) {
/* 1286 */     String temp = (column.getModeInfo(mode) == null || 
/* 1287 */       column.getModeInfo(mode).getStatus() == 1) ? 
/* 1288 */       "editable" : "non-editable";
/* 1289 */     return column.getColor(type, MCConst.createKey(new String[] { temp, key }, ), color, darker);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getButtonColumnValue(int index, MCColumnConfig column, MCTable<?> table, boolean selected) {
/* 1314 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Icon getButtonColumnIcon(int index, MCColumnConfig column, MCTable<?> table, boolean selected) {
/* 1340 */     return column.getIcon();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MCDate getInitDateCalendarFocus(int index, MCColumnConfig column, MCTable<?> table) {
/* 1372 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MCTimestamp getInitTimestampCalendarFocus(int index, MCColumnConfig column, MCTable<?> table) {
/* 1404 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getCellViewScale(int index, MCColumnConfig column, MCTable<?> table) {
/* 1424 */     int s = column.getViewScale();
/* 1425 */     if (s == -1) {
/* 1426 */       s = getCellScale(index, column, table);
/*      */     }
/* 1428 */     return s;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MCFormatConst.MCZeroType getCellViewZeroType(int index, MCColumnConfig column, MCTable<?> table) {
/* 1451 */     return ((MCTableColumn)column)._getViewZeroType(index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected RoundingMode getCellViewRoundingMode(int index, MCColumnConfig column, MCTable<?> table) {
/* 1473 */     return column.getViewRoundingMode();
/*      */   }
/*      */   
/*      */   private String getColumnType(MCColumnConfig column) {
/* 1477 */     MCColumnType c = column.getColumnType();
/* 1478 */     String t = null;
/* 1479 */     if (c != null) {
/* 1480 */       switch (c) {
/*      */         case TEXT:
/* 1482 */           t = "text";
/*      */           break;
/*      */         case NUMBER:
/* 1485 */           t = "number";
/*      */           break;
/*      */         case DATE:
/*      */         case TIMESTAMP:
/* 1489 */           t = "date";
/*      */           break;
/*      */         case CHECK:
/* 1492 */           t = "check";
/*      */           break;
/*      */         case TEXT_COMBO:
/*      */         case TEXT_COMBO_FREE:
/*      */         case TEXT_COMBO_SELECT_ONLY:
/* 1497 */           t = "combo";
/*      */           break;
/*      */         case PASSWORD:
/* 1500 */           t = "password";
/*      */           break;
/*      */         case IMAGE_VIEW:
/* 1503 */           t = "imageview";
/*      */           break;
/*      */         case null:
/* 1506 */           t = "button";
/*      */           break;
/*      */         case NUMBER_COMBO:
/*      */         case NUMBER_COMBO_FREE:
/*      */         case NUMBER_COMBO_SELECT_ONLY:
/* 1511 */           t = "combo-number";
/*      */           break;
/*      */         case DATE_COMBO:
/*      */         case DATE_COMBO_FREE:
/*      */         case DATE_COMBO_SELECT_ONLY:
/*      */         case TIMESTAMP_COMBO:
/*      */         case TIMESTAMP_COMBO_FREE:
/*      */         case TIMESTAMP_COMBO_SELECT_ONLY:
/* 1519 */           t = "combo-date";
/*      */           break;
/*      */       } 
/*      */ 
/*      */     
/*      */     }
/* 1525 */     if (t != null) {
/* 1526 */       return MCStringUtil.join(".", new String[] { column.getType(), t });
/*      */     }
/*      */     
/* 1529 */     return column.getType();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isSimplifiedRowNumberColumnAdjustWidth() {
/* 1544 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isSimplifiedStatusColumnAdjustWidth() {
/* 1558 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String[] getCalendarPanelID(int index, MCColumnConfig column, MCTable<?> table) {
/* 1571 */     String[] a = column.getCalendarPanelID();
/* 1572 */     if (a == null) {
/* 1573 */       MCColumnType y = column.getColumnType();
/* 1574 */       if (MCColumnType.DATE.equals(y)) {
/* 1575 */         MCDateFormat f = column.getDateFormat(index);
/* 1576 */         a = MCCalendarField.getEnableCalendarPopUpId(f.getInputPattern());
/*      */       }
/* 1578 */       else if (MCColumnType.TIMESTAMP.equals(y)) {
/* 1579 */         MCTimestampFormat f = column.getTimestampFormat(index);
/* 1580 */         a = MCCalendarField.getEnableCalendarPopUpId(f.getInputPattern());
/*      */       } 
/*      */     } 
/* 1583 */     return a;
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCCellConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */