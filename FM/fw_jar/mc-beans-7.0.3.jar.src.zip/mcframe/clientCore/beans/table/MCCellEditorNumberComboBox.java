/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import javax.swing.DefaultCellEditor;
/*     */ import javax.swing.InputVerifier;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextField;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCCellEditorNumberComboBox
/*     */   extends DefaultCellEditor
/*     */ {
/*     */   private final MCColumnConfig _column;
/*     */   
/*     */   protected MCCellEditorNumberComboBox(String name, MCColumnConfig column) {
/*  38 */     super(new JTextField());
/*     */     
/*  40 */     this.editorComponent = (JComponent)new MCEditorNumberComboBox(name, column);
/*  41 */     this._column = column;
/*  42 */     setClickCountToStart(1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCColumnConfig getColumnConfig() {
/*  53 */     return this._column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCEditorNumberComboBox getEditorComponent() {
/*  64 */     return (MCEditorNumberComboBox)this.editorComponent;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Component getTableCellEditorComponent(JTable table, Object value, boolean selected, int index, int column) {
/*  70 */     return (Component)getEditor((MCTable)table, value, index, getColumnConfig());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCEditorNumberComboBox getEditor(MCTable<?> table, Object value, int index, MCColumnConfig column) {
/*  86 */     MCEditorNumberComboBox c = getEditorComponent();
/*  87 */     c.setColumnInfo(index, column);
/*  88 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean stopCellEditing() {
/*  94 */     if (!(this._column.getBaseTable()).canRemoveEditor) {
/*  95 */       return false;
/*     */     }
/*  97 */     Component c = getComponent();
/*  98 */     JComponent j = null;
/*  99 */     boolean valid = true;
/*     */     
/* 101 */     if (c instanceof JComponent) {
/* 102 */       j = (JComponent)c;
/* 103 */       InputVerifier v = j.getInputVerifier();
/* 104 */       if (v != null) {
/* 105 */         valid = v.verify(j);
/*     */       }
/*     */     } 
/* 108 */     if (valid) {
/* 109 */       fireEditingStopped();
/*     */     } else {
/*     */       
/* 112 */       JTable jt = (JTable)j.getParent();
/* 113 */       int row = jt.getEditingRow();
/* 114 */       jt.getSelectionModel().setSelectionInterval(row, row);
/*     */     } 
/* 116 */     return valid;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCCellEditorNumberComboBox.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */