/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.util.Iterator;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.event.MouseInputListener;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicTableHeaderUI;
/*     */ import javax.swing.table.JTableHeader;
/*     */ import javax.swing.table.TableColumn;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCLayoutTableHeaderUI
/*     */   extends BasicTableHeaderUI
/*     */ {
/*     */   public static ComponentUI createUI(JComponent h) {
/*  40 */     return new MCLayoutTableHeaderUI();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class MCLayoutTableMouseInputHandler
/*     */     extends BasicTableHeaderUI.MouseInputHandler
/*     */   {
/*     */     private final int _resizeOverlap = -3;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public MCLayoutTableMouseInputHandler() {
/*  58 */       this._resizeOverlap = -3;
/*     */     }
/*     */ 
/*     */     
/*     */     public void mouseDragged(MouseEvent e) {
/*  63 */       if (!SwingUtilities.isLeftMouseButton(e)) {
/*  64 */         MCLayoutTableHeaderUI.this.header.setResizingColumn(null);
/*  65 */         MCLayoutTableHeaderUI.this.header.setDraggedColumn(null);
/*     */       } 
/*  67 */       super.mouseDragged(e);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void mousePressed(MouseEvent e) {
/*  73 */       MouseEvent ex = adjustMouseEventPoint(e);
/*     */       
/*  75 */       super.mousePressed(ex);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void mouseMoved(MouseEvent e) {
/*  81 */       MouseEvent ex = adjustMouseEventPoint(e);
/*     */       
/*  83 */       super.mouseMoved(ex);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private MouseEvent adjustMouseEventPoint(MouseEvent e) {
/* 104 */       Point p = e.getPoint();
/* 105 */       Point pAbs = e.getLocationOnScreen();
/*     */ 
/*     */ 
/*     */       
/* 109 */       int xdiff = adjustResizeOverlapX(p);
/* 110 */       p.x += xdiff;
/* 111 */       pAbs.x += xdiff;
/*     */ 
/*     */       
/* 114 */       int index = MCLayoutTableHeaderUI.this.header.columnAtPoint(p);
/* 115 */       if (index != -1) {
/* 116 */         TableColumn column = MCLayoutTableHeaderUI.this.header.getColumnModel().getColumn(index);
/* 117 */         if (!canResize(column, MCLayoutTableHeaderUI.this.header))
/*     */         {
/*     */           
/* 120 */           p = e.getPoint();
/* 121 */           pAbs = e.getLocationOnScreen();
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 126 */         p = e.getPoint();
/* 127 */         pAbs = e.getLocationOnScreen();
/*     */       } 
/*     */ 
/*     */       
/* 131 */       return new MouseEvent(
/* 132 */           e.getComponent(), 
/* 133 */           e.getID(), 
/* 134 */           e.getWhen(), 
/* 135 */           e.getModifiers(), 
/* 136 */           p.x, 
/* 137 */           p.y, 
/* 138 */           pAbs.x, 
/* 139 */           pAbs.y, 
/* 140 */           e.getClickCount(), 
/* 141 */           e.isPopupTrigger(), 
/* 142 */           e.getButton());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private int adjustResizeOverlapX(Point p) {
/* 162 */       int column = MCLayoutTableHeaderUI.this.header.columnAtPoint(p);
/* 163 */       if (column == -1) {
/* 164 */         return 0;
/*     */       }
/* 166 */       Rectangle r = MCLayoutTableHeaderUI.this.header.getHeaderRect(column);
/* 167 */       r.grow(-3, 0);
/* 168 */       if (r.contains(p)) {
/* 169 */         return 0;
/*     */       }
/* 171 */       int midPoint = r.x + r.width / 2;
/*     */ 
/*     */       
/* 174 */       return (p.x < midPoint) ? -3 : 0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean canResize(TableColumn column, JTableHeader header) {
/* 192 */       return (column != null && 
/* 193 */         header.getResizingAllowed() && 
/* 194 */         column.getResizable());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected MouseInputListener createMouseInputListener() {
/* 201 */     return new MCLayoutTableMouseInputHandler();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCLayoutTableHeader getMCHeader() {
/* 214 */     return (MCLayoutTableHeader)this.header;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCHeaderRendererCommon getHeaderRenderer(MCTableColumn col) {
/* 230 */     return getMCHeader().getHeaderRenderer(col);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getColumnHeight(MCTableColumn col) {
/* 246 */     return getMCHeader().getColumnHeight(col);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getHeaderHeight() {
/* 257 */     int height = 0;
/*     */     
/* 259 */     MCLayoutTableHeader mcheader = getMCHeader();
/* 260 */     MCTable<?> t = mcheader.getMCTable();
/* 261 */     MCTable[] tables = { t.getFixedColumnTable(), t.getBodyTable() }; byte b; int i; MCTable[] arrayOfMCTable1;
/* 262 */     for (i = (arrayOfMCTable1 = tables).length, b = 0; b < i; ) { MCTable<?> table = arrayOfMCTable1[b];
/*     */       
/* 264 */       mcheader = (MCLayoutTableHeader)table.getTableHeader();
/* 265 */       MCLayoutTableColumnModel model = mcheader.getColumnModel();
/* 266 */       Iterator<MCColumnLayoutMember> iterator = 
/* 267 */         model.createLayoutMemberIterator();
/* 268 */       while (iterator.hasNext()) {
/* 269 */         MCColumnLayoutMember member = iterator.next();
/* 270 */         if (member instanceof MCColumnLayout) {
/* 271 */           height = Math.max(
/* 272 */               height, (
/* 273 */               (MCColumnLayout)member).getHeaderHeight()); continue;
/*     */         } 
/* 275 */         if (member instanceof MCTableColumn) {
/* 276 */           MCTableColumn tc = (MCTableColumn)member;
/* 277 */           int h = getColumnHeight(tc);
/* 278 */           height = Math.max(height, h);
/*     */         } 
/*     */       } 
/*     */       b++; }
/*     */     
/* 283 */     return height;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Dimension createHeaderSize(long width) {
/* 295 */     MCLayoutTableColumnModel model = getMCHeader().getColumnModel();
/* 296 */     width += (model.getColumnMargin() * model.getColumnCount());
/* 297 */     if (width > 2147483647L) {
/* 298 */       width = 2147483647L;
/*     */     }
/* 300 */     return new Dimension((int)width, getHeaderHeight());
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getMaximumSize(JComponent c) {
/* 305 */     MCLayoutTableColumnModel model = getMCHeader().getColumnModel();
/* 306 */     long width = model.getMaximumWidth();
/* 307 */     return createHeaderSize(width);
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getMinimumSize(JComponent c) {
/* 312 */     MCLayoutTableColumnModel model = getMCHeader().getColumnModel();
/* 313 */     long width = model.getMinimumWidth();
/* 314 */     return createHeaderSize(width);
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getPreferredSize(JComponent c) {
/* 319 */     MCLayoutTableColumnModel model = getMCHeader().getColumnModel();
/* 320 */     long width = model.getPreferredWidth();
/* 321 */     return createHeaderSize(width);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paint(Graphics g, JComponent c) {
/* 330 */     if (this.header.getColumnModel().getColumnCount() <= 0) {
/*     */       return;
/*     */     }
/* 333 */     MCLayoutTableColumnModel model = getMCHeader().getColumnModel();
/*     */     
/* 335 */     Rectangle rect = new Rectangle(0, 0, 0, 0);
/* 336 */     Rectangle clipBounds = g.getClipBounds();
/* 337 */     int height = getHeaderHeight();
/*     */     
/* 339 */     int columnIndex = 0;
/* 340 */     Iterator<MCColumnLayoutMember> iterator = 
/* 341 */       model.createLayoutMemberIterator();
/* 342 */     while (iterator.hasNext()) {
/* 343 */       rect.height = height;
/* 344 */       MCColumnLayoutMember member = iterator.next();
/* 345 */       if (member instanceof MCColumnLayout) {
/*     */         
/* 347 */         MCColumnLayout layout = (MCColumnLayout)member;
/* 348 */         rect.width = layout.getWidth();
/* 349 */         if (rect.intersects(clipBounds))
/*     */         {
/* 351 */           paintLayout(g, rect, columnIndex, layout);
/*     */         }
/* 353 */         columnIndex += layout.getAllColumnCount();
/*     */       }
/* 355 */       else if (member instanceof MCTableColumn) {
/*     */         
/* 357 */         MCTableColumn col = (MCTableColumn)member;
/* 358 */         rect.width = col.getWidth();
/* 359 */         if (rect.intersects(clipBounds))
/*     */         {
/* 361 */           paintCell(g, rect, columnIndex, col);
/*     */         }
/* 363 */         columnIndex++;
/*     */       } 
/* 365 */       rect.x += rect.width;
/*     */     } 
/*     */ 
/*     */     
/* 369 */     this.rendererPane.removeAll();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void paintCell(Graphics g, Rectangle cellRect, int columnIndex, MCTableColumn aColumn) {
/* 390 */     MCHeaderRendererCommon renderer = getHeaderRenderer(aColumn);
/* 391 */     Component component = renderer.getTableCellRendererComponent(
/* 392 */         getMCHeader().getMCTable(), 
/* 393 */         (Comparable)aColumn.getHeaderValue(), 
/* 394 */         false, false, -1, columnIndex, aColumn);
/*     */ 
/*     */ 
/*     */     
/* 398 */     if (cellRect.height < 0)
/*     */     {
/* 400 */       cellRect.height = (component.getPreferredSize()).height;
/*     */     }
/* 402 */     this.rendererPane.paintComponent(g, component, this.header, 
/* 403 */         cellRect.x, cellRect.y, cellRect.width, cellRect.height, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void paintLayout(Graphics g, Rectangle rect, int columnIndex, MCColumnLayout layout) {
/* 420 */     if (layout.isVertical()) {
/* 421 */       paintLayoutVertical(g, rect, 
/* 422 */           columnIndex, (MCColumnLayoutVertical)layout);
/*     */     } else {
/*     */       
/* 425 */       paintLayoutHorizontal(g, rect, 
/* 426 */           columnIndex, (MCColumnLayoutHorizontal)layout);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void paintLayoutHorizontal(Graphics g, Rectangle rect, int columnIndex, MCColumnLayoutHorizontal layout) {
/* 442 */     Rectangle layoutRect = new Rectangle(rect);
/*     */     
/* 444 */     MCColumnLayoutMember[] members = layout.getVisibleMembers(); byte b; int i; MCColumnLayoutMember[] arrayOfMCColumnLayoutMember1;
/* 445 */     for (i = (arrayOfMCColumnLayoutMember1 = members).length, b = 0; b < i; ) { MCColumnLayoutMember member = arrayOfMCColumnLayoutMember1[b];
/* 446 */       layoutRect.width = member.getWidth();
/* 447 */       if (member instanceof MCTableColumn) {
/* 448 */         paintCell(g, layoutRect, columnIndex, (MCTableColumn)member);
/* 449 */         columnIndex++;
/*     */       }
/* 451 */       else if (member instanceof MCColumnLayout) {
/* 452 */         paintLayout(g, layoutRect, columnIndex, (MCColumnLayout)member);
/* 453 */         columnIndex += layout.getAllColumnCount();
/*     */       } 
/* 455 */       layoutRect.x += layoutRect.width;
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void paintLayoutVertical(Graphics g, Rectangle rect, int columnIndex, MCColumnLayoutVertical layout) {
/* 471 */     Rectangle layoutRect = new Rectangle(rect);
/* 472 */     int height = layoutRect.height;
/*     */     
/* 474 */     MCColumnLayoutMember[] members = layout.getVisibleMembers();
/* 475 */     int memberlen = members.length;
/* 476 */     for (int i = 0; i < memberlen; i++) {
/* 477 */       MCColumnLayoutMember member = members[i];
/* 478 */       if (member instanceof MCTableColumn) {
/* 479 */         MCTableColumn c = (MCTableColumn)member;
/* 480 */         layoutRect.height = (i != memberlen - 1) ? -1 : height;
/* 481 */         paintCell(g, layoutRect, columnIndex, c);
/* 482 */         columnIndex++;
/*     */       }
/* 484 */       else if (member instanceof MCColumnLayout) {
/* 485 */         MCColumnLayout l = (MCColumnLayout)member;
/* 486 */         layoutRect.height = (i != memberlen - 1) ? 
/* 487 */           l.getHeaderHeight() : 
/* 488 */           height;
/* 489 */         paintLayout(g, layoutRect, columnIndex, l);
/* 490 */         columnIndex += layout.getAllColumnCount();
/*     */       } 
/* 492 */       layoutRect.y += layoutRect.height;
/* 493 */       height -= layoutRect.height;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCLayoutTableHeaderUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */