/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.util.List;
/*     */ import javax.swing.SizeSequence;
/*     */ import javax.swing.table.JTableHeader;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.resource.MCColumnWidthData;
/*     */ import mcframe.clientCore.beans.resource.MCColumnWidthInfo;
/*     */ import mcframe.clientCore.beans.resource.MCColumnWidthResourceIO;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.clientCore.event.MCAPBeans;
/*     */ import mcframe.clientCore.event.MCEventInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCTable2<E extends MCConstRow>
/*     */   extends MCTable<E>
/*     */ {
/*     */   private static final String uiClassID = "MCTable2UI";
/*     */   private boolean _customRowHeight;
/*     */   
/*     */   public MCTable2(String name) {
/*  55 */     super(name);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 465 */     this._customRowHeight = false;
/*     */   } MCTable2<E> getBodyTable2() { return (MCTable2<E>)getBodyTable(); } MCFixedColumnTable2<E> getFixedColumnTable2() { return (MCFixedColumnTable2<E>)getFixedColumnTable(); } public MCColumnConfig[] removeAllReturnColumns() { return getColumnModel().removeAllReturnColumns(); } public void addReturnColumn(MCColumnConfig... cols) { getColumnModel().addReturnColumn(cols); } public boolean isReturnColumn(MCColumnConfig col) { return getColumnModel().isReturnColumn(col); }
/*     */   public MCColumnConfig[] getDefaultReturnColumns() { return getColumnModel().getDefaultReturnColumns(); }
/*     */   public int[] getReturnPositions() { return getColumnModel().getReturnPositions(); }
/*     */   public int getReturnCount() { return getColumnModel().getReturnCount(); }
/*     */   public String getUIClassID() {
/*     */     return "MCTable2UI";
/*     */   }
/*     */   protected MCFixedColumnTable<E> createFixedColumnTable(String name) {
/*     */     return new MCFixedColumnTable2<>(this, name);
/*     */   }
/*     */   protected JTableHeader createDefaultTableHeader() {
/*     */     return new MCTable2Header(getColumnModel());
/*     */   }
/*     */   public MCTable2Header getTableHeader() {
/*     */     return (MCTable2Header)super.getTableHeader();
/*     */   }
/* 482 */   boolean isSetCustomRowHeight() { return this._customRowHeight; } protected MCTable2ColumnModel createDefaultColumnModel() { return new MCTable2ColumnModel(this); }
/*     */   public MCTable2ColumnModel getColumnModel() { return (MCTable2ColumnModel)super.getColumnModel(); }
/*     */   protected void setRenderers() { getTableHeader().setDefaultRenderer(new MCMultiLineHeaderRenderer(getTableHeader().getDefaultRenderer())); }
/*     */   public void initialized() { super.initialized(); if (!isPartsTable()) { getColumnModel().setDefaultReturnPositions(); MCColumnConfig[] ra = removeAllReturnColumns(); MCColumnConfig[] a = getColumnConfigs(); byte b; int i; MCColumnConfig[] arrayOfMCColumnConfig1; for (i = (arrayOfMCColumnConfig1 = a).length, b = 0; b < i; ) { MCColumnConfig c = arrayOfMCColumnConfig1[b]; MCColumnWidthResourceIO cio = ((MCTableColumn)c).getColumnWidthResourceIO(); MCColumnWidthInfo ci = MCColumnWidthResourceIO.getInitInfo(cio.getInfoList()); if (ci != null) { List<MCColumnWidthData> dl = ci.getColumnWidthList(); if (dl.size() == 1) { MCColumnWidthData d = dl.get(0); Boolean rf = d.getReturnColumn(); if (rf != null)
/*     */               if (rf.booleanValue()) {
/*     */                 addReturnColumn(new MCColumnConfig[] { c });
/*     */               } else {
/*     */                 for (int j = 0; j < ra.length; j++) {
/*     */                   if (c == ra[j])
/*     */                     ra[j] = null; 
/*     */                 } 
/*     */               }   }
/*     */            }
/*     */          b++; }
/*     */        addReturnColumn(ra); }
/*     */      }
/*     */   public void doAPEvent(MCAPBeans compo, MCEventInfo info) { if (compo == getColumnWidthPanelMenuItem()) {
/*     */       MCRootPanel bp = getBaseRootPanel(); MCRootPanel p = bp.createPanel("FS", "FSBAP0100", MCRootPanel.SCREEN_MODAL, new Object[] { "T1", null, this }); bp.showChildPanel(p, MCRootPanel.MULTI, new Object[0]);
/*     */     } else {
/*     */       super.doAPEvent(compo, info);
/*     */     }  }
/*     */   public void _applyColumnWidthInfo(MCColumnWidthInfo info) { removeAllReturnColumns(); super._applyColumnWidthInfo(info); }
/* 504 */   public void setMCRowHeight(int index, int height) { if (!this._customRowHeight) {
/* 505 */       this._customRowHeight = (getRowHeight() != height);
/*     */     }
/* 507 */     super.setMCRowHeight(index, height); }
/*     */   
/*     */   void applyColumnWidthInfo(MCColumnConfig column, MCColumnWidthData data) {
/*     */     if (Boolean.TRUE.equals(data.getReturnColumn()))
/*     */       addReturnColumn(new MCColumnConfig[] { column }); 
/*     */     super.applyColumnWidthInfo(column, data);
/*     */   }
/*     */   int getTierInRow() {
/*     */     return getReturnCount();
/*     */   }
/*     */   public void setUnscrollColumn(MCColumnConfig column) {
/*     */     MCColumnConfig[] rets = removeAllReturnColumns();
/*     */     super.setUnscrollColumn(column);
/*     */     addReturnColumn(rets);
/*     */   }
/*     */   
/* 523 */   public void doLayout() { TableColumn resizingColumn = getResizingColumn();
/* 524 */     if (resizingColumn == null) {
/* 525 */       setWidthsFromPreferredWidths(false);
/*     */     } else {
/*     */       
/* 528 */       int columnIndex = viewIndexForColumn(resizingColumn);
/* 529 */       int delta = getWidth() - getColumnModel().getTotalColumnWidth();
/* 530 */       accommodateDelta(columnIndex, delta);
/* 531 */       delta = getWidth() - getColumnModel().getTotalColumnWidth();
/* 532 */       if (delta != 0) {
/* 533 */         resizingColumn.setWidth(resizingColumn.getWidth() + delta);
/*     */       }
/* 535 */       setWidthsFromPreferredWidths(true);
/*     */     } 
/*     */ 
/*     */     
/* 539 */     layout(); } public int tierAtPoint(Point point) { int row = rowAtPoint(point); if (row < 0)
/*     */       return -1;  int tiercnt = getReturnCount(); int y = 0; for (int i = 0; i < row; i++)
/*     */       y += getRowHeight(i) * tiercnt;  int distance = point.y - y; int h = getRowHeight(row); if (h == 0)
/*     */       return 0;  int tier = distance / h; return (tier < 0) ? 0 : tier; }
/*     */   public int rowAtPoint(Point point) { Point p = new Point(point); int tier = getReturnCount(); p.y /= tier; return super.rowAtPoint(p); }
/* 544 */   private TableColumn getResizingColumn() { return (this.tableHeader == null) ? 
/* 545 */       null : this.tableHeader.getResizingColumn(); }
/*     */   public int columnAtPoint(Point point) { int x = point.x; MCTable2ColumnModel cm = getColumnModel();
/*     */     int tier_w = 0;
/*     */     int tier = tierAtPoint(point);
/*     */     if (tier < 0)
/*     */       return -1; 
/*     */     int[] se = cm.getTierColumnIndex(tier);
/*     */     int i;
/*     */     for (i = se[0]; i < se[1]; i++)
/*     */       tier_w += cm.getColumn(i).getWidth(); 
/*     */     if (tier_w <= point.x)
/*     */       return -1; 
/*     */     for (i = 0; i < se[0]; i++)
/*     */       x += cm.getColumn(i).getWidth(); 
/* 559 */     return cm.getColumnIndexAtX(x); } private int viewIndexForColumn(TableColumn aColumn) { TableColumnModel cm = getColumnModel();
/* 560 */     for (int column = 0; column < cm.getColumnCount(); column++) {
/* 561 */       if (cm.getColumn(column) == aColumn) {
/* 562 */         return column;
/*     */       }
/*     */     } 
/* 565 */     return -1; }
/*     */   public Rectangle getCellRect(int row, int column, boolean includeSpacing) { MCTable2ColumnModel colmodel = getColumnModel(); Rectangle r = new Rectangle(); boolean valid = true; int[] retpos = colmodel.getReturnPositions(); if (row < 0) { valid = false; } else if (row >= getRowCount()) { r.y = getHeight(); valid = false; } else { r.height = getRowHeight(row); SizeSequence rowModel = getRowModel(); r.y = (rowModel == null) ? (row * r.height) : rowModel.getPosition(row); r.y *= retpos.length; }  if (column < 0) { valid = false; } else if (column >= colmodel.getColumnCount()) { r.x = getWidth(); valid = false; } else { int fixcnt = colmodel.getFixedColumnCount(); int tier = 0; for (int i = 0; i < column; i++) { if (i >= retpos[tier] - fixcnt) { tier++; r.x = 0; r.y += getRowHeightNE(row); } else { r.x += colmodel.getColumn(i).getWidth(); }  }
/*     */        r.width = colmodel.getColumn(column).getWidth(); }
/*     */      if (valid && !includeSpacing) { int rm = Math.min(getRowMargin(), r.height); int cm = Math.min(colmodel.getColumnMargin(), r.width); r.setBounds(r.x + cm / 2, r.y + rm / 2, r.width - cm, r.height - rm); }
/* 569 */      return r; } private void accommodateDelta(int resizingColumnIndex, int delta) { final MCTable2ColumnModel cm = getColumnModel();
/* 570 */     int from = resizingColumnIndex;
/* 571 */     int to = 0;
/* 572 */     int columnCount = 0;
/* 573 */     int[] retpos = cm.getReturnPositions();
/* 574 */     int fixcnt = cm.getFixedColumnCount();
/* 575 */     for (int tier = 0; tier < retpos.length; tier++) {
/* 576 */       columnCount = retpos[tier] + 1 - fixcnt;
/* 577 */       if (resizingColumnIndex < columnCount) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */     
/* 582 */     switch (this.autoResizeMode) {
/*     */       case 1:
/* 584 */         from++;
/* 585 */         to = Math.min(from + 1, columnCount);
/*     */         break;
/*     */       case 2:
/* 588 */         from++;
/* 589 */         to = columnCount;
/*     */         break;
/*     */       case 3:
/* 592 */         from = columnCount - 1;
/* 593 */         to = from + 1;
/*     */         break;
/*     */       case 4:
/* 596 */         from = 0;
/* 597 */         to = columnCount;
/*     */         break;
/*     */ 
/*     */       
/*     */       default:
/*     */         return;
/*     */     } 
/*     */     
/* 605 */     final int start = from;
/* 606 */     final int end = to;
/* 607 */     Resizable3 r = new Resizable3() {
/* 608 */         public int getElementCount() { return end - start; }
/* 609 */         public int getLowerBoundAt(int i) { return cm.getColumn(i + start).getMinWidth(); }
/* 610 */         public int getUpperBoundAt(int i) { return cm.getColumn(i + start).getMaxWidth(); }
/* 611 */         public int getMidPointAt(int i) { return cm.getColumn(i + start).getWidth(); } public void setSizeAt(int s, int i) {
/* 612 */           cm.getColumn(i + start).setWidth(s);
/*     */         }
/*     */       };
/* 615 */     int totalWidth = 0;
/* 616 */     for (int i = from; i < to; i++) {
/* 617 */       TableColumn aColumn = cm.getColumn(i);
/* 618 */       int input = aColumn.getWidth();
/* 619 */       totalWidth += input;
/*     */     } 
/*     */     
/* 622 */     adjustSizes((totalWidth + delta), r, false, start, end); }
/*     */ 
/*     */   
/*     */   private void setWidthsFromPreferredWidths(final boolean inverse) {
/* 626 */     final MCTable2ColumnModel cm = getColumnModel();
/* 627 */     Resizable3 r = new Resizable3() {
/* 628 */         public int getElementCount() { return cm.getColumnCount(); }
/* 629 */         public int getLowerBoundAt(int i) { return cm.getColumn(i).getMinWidth(); } public int getUpperBoundAt(int i) {
/* 630 */           return cm.getColumn(i).getMaxWidth();
/*     */         } public int getMidPointAt(int i) {
/* 632 */           if (!inverse) {
/* 633 */             return cm.getColumn(i).getPreferredWidth();
/*     */           }
/*     */           
/* 636 */           return cm.getColumn(i).getWidth();
/*     */         }
/*     */         
/*     */         public void setSizeAt(int s, int i) {
/* 640 */           if (!inverse) {
/* 641 */             cm.getColumn(i).setWidth(s);
/*     */           } else {
/*     */             
/* 644 */             cm.getColumn(i).setPreferredWidth(s);
/*     */           } 
/*     */         }
/*     */       };
/*     */     
/* 649 */     MCTableColumn[] cols = getTableColumns();
/* 650 */     int retcnt = cm.getReturnCount();
/* 651 */     for (int tier = 0; tier < retcnt; tier++) {
/* 652 */       int totalWidth = 0;
/* 653 */       int totalPreferred = 0;
/* 654 */       int[] se = cm.getTierColumnIndex(tier);
/* 655 */       for (int i = se[0]; i < se[1]; i++) {
/* 656 */         totalWidth += cols[i].getWidth();
/* 657 */         totalPreferred += cols[i].getPreferredWidth();
/*     */       } 
/* 659 */       int target = !inverse ? totalWidth : totalPreferred;
/*     */       
/* 661 */       adjustSizes(target, r, inverse, se[0], se[1]);
/*     */     } 
/*     */   }
/*     */   private void adjustSizes(long target, final Resizable3 r3, boolean inverse, int s, int e) {
/*     */     Resizable2 r2;
/* 666 */     MCTable2ColumnModel.WidthSupplier ws = new MCTable2ColumnModel.WidthSupplier()
/*     */       {
/*     */         public long width(MCTableColumn column) {
/* 669 */           int i = MCTable2.this.getRealColumn(column);
/* 670 */           return r3.getMidPointAt(i);
/*     */         }
/*     */       };
/* 673 */     long totalPreferred = getColumnModel().calcWidth(ws);
/*     */ 
/*     */     
/* 676 */     if (((target < totalPreferred) ? true : false) == (inverse ? false : true)) {
/* 677 */       r2 = new Resizable2() {
/* 678 */           public int getElementCount() { return r3.getElementCount(); }
/* 679 */           public int getLowerBoundAt(int i) { return r3.getLowerBoundAt(i); }
/* 680 */           public int getUpperBoundAt(int i) { return r3.getMidPointAt(i); } public void setSizeAt(int newSize, int i) {
/* 681 */             r3.setSizeAt(newSize, i);
/*     */           }
/*     */         };
/*     */     } else {
/* 685 */       r2 = new Resizable2() {
/* 686 */           public int getElementCount() { return r3.getElementCount(); }
/* 687 */           public int getLowerBoundAt(int i) { return r3.getMidPointAt(i); }
/* 688 */           public int getUpperBoundAt(int i) { return r3.getUpperBoundAt(i); }
/* 689 */           public void setSizeAt(int newSize, int i) { r3.setSizeAt(newSize, i); }
/*     */         };
/*     */     } 
/* 692 */     adjustSizes(target, r2, !inverse, s, e);
/*     */   }
/*     */   
/*     */   private void adjustSizes(long target, Resizable2 r, boolean limitToRange, int s, int e) {
/* 696 */     long totalLowerBound = 0L;
/* 697 */     long totalUpperBound = 0L;
/* 698 */     for (int i = s; i < e; i++) {
/* 699 */       totalLowerBound += r.getLowerBoundAt(i);
/* 700 */       totalUpperBound += r.getUpperBoundAt(i);
/*     */     } 
/*     */     
/* 703 */     long rTarget = limitToRange ? 
/* 704 */       Math.min(Math.max(totalLowerBound, target), totalUpperBound) : 
/* 705 */       target;
/*     */     
/* 707 */     for (int j = s; j < e; j++) {
/* 708 */       int newSize, lowerBound = r.getLowerBoundAt(j);
/* 709 */       int upperBound = r.getUpperBoundAt(j);
/*     */ 
/*     */       
/* 712 */       if (totalLowerBound == totalUpperBound) {
/* 713 */         newSize = lowerBound;
/*     */       } else {
/*     */         
/* 716 */         double f = (rTarget - totalLowerBound) / (totalUpperBound - totalLowerBound);
/* 717 */         newSize = (int)Math.round(lowerBound + f * (upperBound - lowerBound));
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 722 */       r.setSizeAt(newSize, j);
/* 723 */       rTarget -= newSize;
/* 724 */       totalLowerBound -= lowerBound;
/* 725 */       totalUpperBound -= upperBound;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static interface Resizable2 {
/*     */     int getElementCount();
/*     */     
/*     */     int getLowerBoundAt(int param1Int);
/*     */     
/*     */     int getUpperBoundAt(int param1Int);
/*     */     
/*     */     void setSizeAt(int param1Int1, int param1Int2);
/*     */   }
/*     */   
/*     */   private static interface Resizable3 extends Resizable2 {
/*     */     int getMidPointAt(int param1Int);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCTable2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */