/*    */ package mcframe.clientCore.beans.table;
/*    */ 
/*    */ import mcframe.commonCore.container.MCList;
/*    */ import mcframe.commonCore.container.MCRowFilter;
/*    */ import mcframe.commonCore.container.MCRowFilterList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbsMCPackageProxy
/*    */ {
/*    */   protected void nextRowSelectionChange(MCTable<?> table) {
/* 22 */     table.nextRowSelectionChange(table.getMCSelectedRow());
/*    */   }
/*    */   
/*    */   protected void previousRowSelectionChange(MCTable<?> table) {
/* 26 */     table.previousRowSelectionChange(table.getMCSelectedRow());
/*    */   }
/*    */   
/*    */   protected boolean commitEditor(MCTable<?> table) {
/* 30 */     return table.commitEditor();
/*    */   }
/*    */ 
/*    */   
/*    */   protected <E extends mcframe.clientCore.container.MCConstRow> MCList<E> getEnableList(MCTable<E> table, MCRowFilterList<MCRowFilter> list) {
/* 35 */     return table.getEnableList(list);
/*    */   }
/*    */   
/*    */   protected <E extends mcframe.clientCore.container.MCConstRow> void filterList(MCTable<?> table, MCList<E> enable) {
/* 39 */     table.filterList(enable);
/*    */   }
/*    */   
/*    */   protected void setUserSortPolicy(MCTable<?> table) {
/* 43 */     table.setUserSortPolicy();
/*    */   }
/*    */   
/*    */   protected void setUserRowSignal(MCTable<?> table) {
/* 47 */     table.setUserRowSignal();
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\AbsMCPackageProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */