/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.swing.table.JTableHeader;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.util.MCCollectionUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCColumnGroupTable<E extends MCConstRow>
/*     */   extends MCTable<E>
/*     */ {
/*     */   public MCColumnGroupTable(String name) {
/*  33 */     super(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addColumnGroup(MCColumnGroup cg) {
/*  44 */     cg.setTable(this);
/*  45 */     getColumnModel().addColumnGroup(cg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addColumnGroup(MCTable<? extends MCConstRow> table) {
/*  62 */     if (table instanceof MCColumnGroupTable) {
/*  63 */       MCColumnGroupTableColumnModel model = getColumnModel();
/*  64 */       MCColumnGroupTable<?> ptable = (MCColumnGroupTable)table;
/*  65 */       MCColumnGroupTableColumnModel pmodel = ptable.getColumnModel();
/*  66 */       MCColumnGroup[] cgs = pmodel.getColumnGroups(); byte b; int i; MCColumnGroup[] arrayOfMCColumnGroup1;
/*  67 */       for (i = (arrayOfMCColumnGroup1 = cgs).length, b = 0; b < i; ) { MCColumnGroup cg = arrayOfMCColumnGroup1[b];
/*  68 */         model.addColumnGroup(cg);
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCColumnGroup[] getAllColumnGroups() {
/*  84 */     MCFixedColumnGroupTable<E> fixed = getFixedColumnGroupTable();
/*  85 */     return (MCColumnGroup[])MCCollectionUtil.concat((Object[][])new MCColumnGroup[][] { fixed.getColumnModel().getAllColumnGroups(), 
/*  86 */           getColumnModel().getAllColumnGroups() });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCColumnGroupTable<E> getBodyColumnGroupTable() {
/*  97 */     return (MCColumnGroupTable<E>)getBodyTable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCFixedColumnGroupTable<E> getFixedColumnGroupTable() {
/* 108 */     return (MCFixedColumnGroupTable<E>)getFixedColumnTable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getColumnLabelByLocale(MCColumnConfig column) {
/* 134 */     MCColumnGroupTableColumnModel model = isFixedColumn(column) ? getFixedColumnGroupTable()
/* 135 */       .getColumnModel() : getColumnModel();
/* 136 */     return getColumnLabelByLocale((MCTableColumn)column, model);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getColumnLabelByLocale(final MCTableColumn column, MCColumnGroupTableColumnModel model) {
/* 151 */     return createColumnGroupString(new ColumnStringSupplier()
/*     */         {
/*     */           public String getString() {
/* 154 */             return column.getHeaderName();
/*     */           }
/*     */ 
/*     */           
/*     */           public String getString(MCColumnGroup cg) {
/* 159 */             return cg.getHeaderName();
/*     */           }
/*     */ 
/*     */           
/*     */           public TableColumn getColumn() {
/* 164 */             return column;
/*     */           }
/* 166 */         },  model, (String)null, (String)null, ".");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getColumnMessageByLocale(MCColumnConfig column) {
/* 193 */     MCColumnGroupTableColumnModel model = isFixedColumn(column) ? getFixedColumnGroupTable()
/* 194 */       .getColumnModel() : getColumnModel();
/* 195 */     return getColumnMessageByLocale((MCTableColumn)column, model);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getColumnMessageByLocale(final MCTableColumn column, MCColumnGroupTableColumnModel model) {
/* 210 */     return createColumnGroupString(new ColumnStringSupplier()
/*     */         {
/*     */           public String getString() {
/* 213 */             return column._getMessageByLocale();
/*     */           }
/*     */ 
/*     */           
/*     */           public String getString(MCColumnGroup cg) {
/* 218 */             return cg.getMessageByLocale();
/*     */           }
/*     */ 
/*     */           
/*     */           public TableColumn getColumn() {
/* 223 */             return column;
/*     */           }
/* 225 */         },  model, (String)null, (String)null, ".");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String createColumnGroupString(ColumnStringSupplier css, MCColumnGroupTableColumnModel model, String format, String groupformat, String separator) {
/* 313 */     if (css == null || css.getColumn() == null) {
/* 314 */       return null;
/*     */     }
/* 316 */     MCColumnGroup[] cgs = model.getColumnGroups(css.getColumn());
/* 317 */     if (cgs.length == 0)
/*     */     {
/* 319 */       return css.getString();
/*     */     }
/*     */ 
/*     */     
/* 323 */     separator = (separator != null) ? separator : "";
/*     */ 
/*     */     
/* 326 */     StringBuilder cgsb = new StringBuilder();
/* 327 */     if (groupformat == null) {
/*     */       byte b; int i; MCColumnGroup[] arrayOfMCColumnGroup;
/* 329 */       for (i = (arrayOfMCColumnGroup = cgs).length, b = 0; b < i; ) { MCColumnGroup cg = arrayOfMCColumnGroup[b];
/* 330 */         cgsb.append(css.getString(cg));
/* 331 */         cgsb.append(separator); b++; }
/*     */     
/*     */     } else {
/*     */       byte b; int i;
/*     */       MCColumnGroup[] arrayOfMCColumnGroup;
/* 336 */       for (i = (arrayOfMCColumnGroup = cgs).length, b = 0; b < i; ) { MCColumnGroup cg = arrayOfMCColumnGroup[b];
/* 337 */         cgsb.append(MCStringUtil.bind(groupformat, new Object[] { css.getString(cg) }));
/* 338 */         cgsb.append(separator); b++; }
/*     */     
/*     */     } 
/* 341 */     cgsb.setLength(cgsb.length() - separator.length());
/*     */ 
/*     */     
/* 344 */     String name = css.getString();
/* 345 */     name = (format != null) ? MCStringUtil.bind(format, new Object[] { cgsb, name }) : (String.valueOf(cgsb.toString()) + 
/* 346 */       separator + name);
/*     */ 
/*     */     
/* 349 */     return name.replaceAll("\n|\r", "");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCFixedColumnTable<E> createFixedColumnTable(String name) {
/* 357 */     return new MCFixedColumnGroupTable<>(this, name);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected JTableHeader createDefaultTableHeader() {
/* 363 */     return new MCColumnGroupTableHeader(getColumnModel());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MCColumnGroupTableHeader getTableHeader() {
/* 369 */     return (MCColumnGroupTableHeader)super.getTableHeader();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCColumnGroupTableColumnModel createDefaultColumnModel() {
/* 375 */     return new MCColumnGroupTableColumnModel();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MCColumnGroupTableColumnModel getColumnModel() {
/* 381 */     return (MCColumnGroupTableColumnModel)super.getColumnModel();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setRenderers() {
/* 387 */     getTableHeader().setDefaultRenderer(
/* 388 */         new MCMultiLineHeaderRenderer(getTableHeader().getDefaultRenderer()));
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateResource(MCRootPanel panel) {
/* 393 */     super.updateResource(panel);
/*     */ 
/*     */     
/* 396 */     if (panel != null && isBodyTable()) {
/* 397 */       MCColumnGroup[] cgs = getAllColumnGroups(); byte b; int i; MCColumnGroup[] arrayOfMCColumnGroup1;
/* 398 */       for (i = (arrayOfMCColumnGroup1 = cgs).length, b = 0; b < i; ) { MCColumnGroup cg = arrayOfMCColumnGroup1[b];
/* 399 */         cg.updateResource(panel);
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   }
/*     */   
/*     */   void updateColumnsFontSize(int fontratio, int widthratio, boolean check) {
/* 406 */     super.updateColumnsFontSize(fontratio, widthratio, check);
/*     */ 
/*     */     
/* 409 */     MCColumnGroup[] cgs = getAllColumnGroups(); byte b; int i; MCColumnGroup[] arrayOfMCColumnGroup1;
/* 410 */     for (i = (arrayOfMCColumnGroup1 = cgs).length, b = 0; b < i; ) { MCColumnGroup cg = arrayOfMCColumnGroup1[b];
/* 411 */       cg.getColumn().updateFontSize(fontratio, widthratio, check);
/*     */       b++; }
/*     */   
/*     */   }
/*     */   
/*     */   void initColumns() {
/* 417 */     super.initColumns();
/*     */ 
/*     */     
/* 420 */     MCColumnGroup[] cgs = getAllColumnGroups(); byte b; int i; MCColumnGroup[] arrayOfMCColumnGroup1;
/* 421 */     for (i = (arrayOfMCColumnGroup1 = cgs).length, b = 0; b < i; ) { MCColumnGroup cg = arrayOfMCColumnGroup1[b];
/* 422 */       cg.getColumn().initialized();
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void _setUserColumnOrder(Map<Integer, MCColumnConfig> m) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUnscrollColumn(MCColumnConfig column) {
/* 434 */     column = setUnscrollColumnGroup(column);
/*     */     
/* 436 */     super.setUnscrollColumn(column);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCColumnConfig setUnscrollColumnGroup(MCColumnConfig column) {
/* 454 */     boolean find = (column == null);
/* 455 */     MCColumnGroup belong = null;
/* 456 */     Set<MCColumnGroup> setf = new LinkedHashSet<>();
/* 457 */     Set<MCColumnGroup> sets = new LinkedHashSet<>();
/*     */     
/* 459 */     MCColumnGroupTableColumnModel[] models = {
/* 460 */         getFixedColumnGroupTable().getColumnModel(), getColumnModel() }; byte b; int i;
/*     */     MCColumnGroupTableColumnModel[] arrayOfMCColumnGroupTableColumnModel1;
/* 462 */     for (i = (arrayOfMCColumnGroupTableColumnModel1 = models).length, b = 0; b < i; ) { MCColumnGroupTableColumnModel model = arrayOfMCColumnGroupTableColumnModel1[b];
/* 463 */       int len = model.getColumnCount();
/* 464 */       for (int j = 0; j < len; j++) {
/* 465 */         TableColumn tc = model.getColumn(j);
/* 466 */         MCColumnGroup[] cgs = model.getColumnGroups(tc);
/* 467 */         if (cgs.length > 0)
/*     */         {
/* 469 */           if (find) {
/*     */             
/* 471 */             if (!setf.contains(cgs[0])) {
/* 472 */               sets.add(cgs[0]);
/*     */             }
/*     */           }
/*     */           else {
/*     */             
/* 477 */             setf.add(cgs[0]);
/*     */           } 
/*     */         }
/* 480 */         if (tc == column) {
/*     */           
/* 482 */           find = true;
/* 483 */           belong = (cgs.length > 0) ? cgs[0] : null;
/*     */         } 
/*     */       }  b++; }
/*     */     
/* 487 */     if (belong != null)
/*     */     {
/* 489 */       column = getLastGroupMember(belong);
/*     */     }
/*     */ 
/*     */     
/* 493 */     models[0].setAllColumnGroup(setf);
/* 494 */     models[1].setAllColumnGroup(sets);
/*     */     
/* 496 */     return column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCColumnConfig getLastGroupMember(MCColumnGroup cg) {
/* 508 */     MCColumnConfig c = null;
/* 509 */     MCColumnGroupMember[] gms = cg.getMembers();
/* 510 */     int size = gms.length;
/* 511 */     if (size > 0) {
/* 512 */       MCColumnGroupMember gm = gms[size - 1];
/* 513 */       if (gm instanceof MCColumnGroup) {
/* 514 */         c = getLastGroupMember((MCColumnGroup)gm);
/*     */       } else {
/*     */         
/* 517 */         c = (MCColumnConfig)gm;
/*     */       } 
/*     */     } 
/* 520 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void adjustWidth(MCTableColumn column) {
/* 527 */     super.adjustWidth(column);
/*     */     
/* 529 */     MCColumnGroupTableColumnModel[] models = {
/* 530 */         getFixedColumnGroupTable().getColumnModel(), getColumnModel() }; byte b; int i;
/*     */     MCColumnGroupTableColumnModel[] arrayOfMCColumnGroupTableColumnModel1;
/* 532 */     for (i = (arrayOfMCColumnGroupTableColumnModel1 = models).length, b = 0; b < i; ) { MCColumnGroupTableColumnModel model = arrayOfMCColumnGroupTableColumnModel1[b];
/* 533 */       MCColumnGroup[] cgs = model.getColumnGroups(column);
/* 534 */       if (cgs.length <= 0) {
/*     */         b++;
/*     */         
/*     */         continue;
/*     */       } 
/* 539 */       for (int cgpos = cgs.length - 1; cgpos >= 0; cgpos--) {
/* 540 */         MCColumnGroup cg = cgs[cgpos];
/* 541 */         MCTableColumn[] cols = cg.getAllColumns();
/* 542 */         int allwidth = 0;
/* 543 */         for (int colpos = cols.length - 1; colpos >= 0; colpos--) {
/* 544 */           MCTableColumn col = cols[colpos];
/* 545 */           if (col.isViewColumn()) {
/* 546 */             if (allwidth <= 0 && col != column) {
/*     */               break;
/*     */             }
/*     */             
/* 550 */             allwidth += col.getPreferredWidth();
/*     */           } 
/*     */         } 
/* 553 */         if (allwidth <= 0) {
/*     */           break;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 559 */         int cgwidth = cg.getColumn().getAdjustedWidth();
/* 560 */         if (cgwidth > allwidth) {
/*     */           
/* 562 */           int newwidth = column.getPreferredWidth() + cgwidth - allwidth;
/* 563 */           column.setPreferredWidth(newwidth);
/*     */         } 
/*     */       } 
/*     */       break; }
/*     */   
/*     */   }
/*     */   
/*     */   private static interface ColumnStringSupplier {
/*     */     String getString();
/*     */     
/*     */     String getString(MCColumnGroup param1MCColumnGroup);
/*     */     
/*     */     TableColumn getColumn();
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCColumnGroupTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */