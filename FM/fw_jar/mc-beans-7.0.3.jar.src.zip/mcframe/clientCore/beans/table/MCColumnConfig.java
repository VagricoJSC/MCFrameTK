/*      */ package mcframe.clientCore.beans.table;
/*      */ 
/*      */ import java.awt.Color;
/*      */ import java.awt.Font;
/*      */ import java.math.RoundingMode;
/*      */ import java.util.List;
/*      */ import java.util.regex.Pattern;
/*      */ import javax.swing.Icon;
/*      */ import javax.swing.border.Border;
/*      */ import mcframe.clientCore.beans.MCACBeans;
/*      */ import mcframe.clientCore.beans.MCMode;
/*      */ import mcframe.clientCore.beans.MCModeBeans;
/*      */ import mcframe.clientCore.beans.MCModeInfo;
/*      */ import mcframe.clientCore.beans.MCResourceBeans;
/*      */ import mcframe.clientCore.beans.action.MCActionBeans;
/*      */ import mcframe.clientCore.beans.combobox.MCComboListConfig;
/*      */ import mcframe.clientCore.beans.list.MCLinkBeans;
/*      */ import mcframe.clientCore.beans.list.MCLinkedBeans;
/*      */ import mcframe.clientCore.beans.popup.MCImagePanelInfo;
/*      */ import mcframe.clientCore.beans.text.MCCalendarPattern;
/*      */ import mcframe.clientCore.beans.text.MCCalendarValidator;
/*      */ import mcframe.clientCore.beans.text.MCDateFormat;
/*      */ import mcframe.clientCore.beans.text.MCInputMethodType;
/*      */ import mcframe.clientCore.beans.text.MCNumberFormat;
/*      */ import mcframe.clientCore.beans.text.MCNumberPattern;
/*      */ import mcframe.clientCore.beans.text.MCTimestampFormat;
/*      */ import mcframe.clientCore.event.MCAPBeans;
/*      */ import mcframe.clientCore.event.MCDCBeans;
/*      */ import mcframe.clientCore.event.MCEventInfo;
/*      */ import mcframe.clientCore.event.MCLCBeans;
/*      */ import mcframe.clientCore.event.MCNCBeans;
/*      */ import mcframe.clientCore.event.MCNEBeans;
/*      */ import mcframe.clientCore.event.MCNXBeans;
/*      */ import mcframe.clientCore.event.MCVCBeans;
/*      */ import mcframe.commonCore.container.MCList;
/*      */ import mcframe.commonCore.container.MCRow;
/*      */ import mcframe.commonCore.meta.MCMeta;
/*      */ import mcframe.commonCore.notice.MCMessageList;
/*      */ import mcframe.commonCore.resource.MCFormatConst;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public interface MCColumnConfig
/*      */   extends MCModeBeans, MCVCBeans, MCNCBeans, MCNEBeans, MCNXBeans, MCLCBeans, MCLinkBeans, MCLinkedBeans, MCDCBeans, MCResourceBeans, MCActionBeans, MCAPBeans, MCACBeans
/*      */ {
/*      */   public static final int RIGHT = 4;
/*      */   public static final int CENTER = 0;
/*      */   public static final int LEFT = 2;
/*      */   
/*      */   void setHeaderName(String paramString);
/*      */   
/*      */   String getBaseRowColumnName();
/*      */   
/*      */   String getRowColumnName(MCTable<?> paramMCTable);
/*      */   
/*      */   String getHeaderName();
/*      */   
/*      */   void adjustWidth();
/*      */   
/*      */   void setWidthForAdjustWidth(int paramInt);
/*      */   
/*      */   int getAdjustedWidth();
/*      */   
/*      */   void setLength(int paramInt);
/*      */   
/*      */   void setLength(int paramInt1, int paramInt2, boolean paramBoolean);
/*      */   
/*      */   void setScale(int paramInt);
/*      */   
/*      */   void setMinusEnable(boolean paramBoolean);
/*      */   
/*      */   int getLength();
/*      */   
/*      */   int getScale();
/*      */   
/*      */   boolean isMinusEnable();
/*      */   
/*      */   MCColumnType getColumnType();
/*      */   
/*      */   void setColumnWidth(int paramInt);
/*      */   
/*      */   int getColumnWidth();
/*      */   
/*      */   void setHorizontalAlignment(int paramInt);
/*      */   
/*      */   int getHorizontalAlignment();
/*      */   
/*      */   void setHeaderHorizontalAlignment(int paramInt);
/*      */   
/*      */   int getHeaderHorizontalAlignment();
/*      */   
/*      */   void setMeta(MCMeta paramMCMeta);
/*      */   
/*      */   MCMeta getMeta();
/*      */   
/*      */   Font getFont();
/*      */   
/*      */   void setFont(Font paramFont);
/*      */   
/*      */   Font getHeaderFont();
/*      */   
/*      */   void setHeaderFont(Font paramFont);
/*      */   
/*      */   void setForeground(Color paramColor);
/*      */   
/*      */   Color getForeground();
/*      */   
/*      */   void setBackground(Color paramColor);
/*      */   
/*      */   Color getBackground();
/*      */   
/*      */   void setCaretColor(Color paramColor);
/*      */   
/*      */   Color getCaretColor();
/*      */   
/*      */   void setSelectionColor(Color paramColor);
/*      */   
/*      */   Color getSelectionColor();
/*      */   
/*      */   void setSelectedTextColor(Color paramColor);
/*      */   
/*      */   Color getSelectedTextColor();
/*      */   
/*      */   void setHeaderForeground(Color paramColor);
/*      */   
/*      */   Color getHeaderForeground();
/*      */   
/*      */   void setHeaderBackground(Color paramColor);
/*      */   
/*      */   Color getHeaderBackground();
/*      */   
/*      */   void setSelectedHeaderForeground(Color paramColor);
/*      */   
/*      */   Color getSelectedHeaderForeground();
/*      */   
/*      */   void setSelectedHeaderBackground(Color paramColor);
/*      */   
/*      */   Color getSelectedHeaderBackground();
/*      */   
/*      */   void setFilteredHeaderForeground(Color paramColor);
/*      */   
/*      */   Color getFilteredHeaderForeground();
/*      */   
/*      */   void setFilteredHeaderBackground(Color paramColor);
/*      */   
/*      */   Color getFilteredHeaderBackground();
/*      */   
/*      */   void setAutoFocus(boolean paramBoolean);
/*      */   
/*      */   boolean isAutoFocus();
/*      */   
/*      */   void setFocusColumn(boolean paramBoolean);
/*      */   
/*      */   boolean isFocusColumn();
/*      */   
/*      */   void setColumnSize(int paramInt);
/*      */   
/*      */   int getColumnSize();
/*      */   
/*      */   void setSelectAll(boolean paramBoolean);
/*      */   
/*      */   boolean isSelectAll();
/*      */   
/*      */   boolean checkValue(Comparable<?> paramComparable);
/*      */   
/*      */   boolean checkValue(Comparable<?> paramComparable, int paramInt);
/*      */   
/*      */   boolean checkValue(Comparable<?> paramComparable, int paramInt, MCMessageList paramMCMessageList);
/*      */   
/*      */   boolean checkInputValue(Comparable<?> paramComparable, int paramInt);
/*      */   
/*      */   boolean checkInputValue(Comparable<?> paramComparable, int paramInt, MCMessageList paramMCMessageList);
/*      */   
/*      */   void setTurnDownText(boolean paramBoolean);
/*      */   
/*      */   boolean isTurnDownText();
/*      */   
/*      */   MCTable getTable();
/*      */   
/*      */   MCTable getBaseTable();
/*      */   
/*      */   MCMessageList setValue(int paramInt, Comparable<?> paramComparable);
/*      */   
/*      */   Comparable<?> getValue(int paramInt);
/*      */   
/*      */   void setFormat(MCDateFormat paramMCDateFormat);
/*      */   
/*      */   MCDateFormat getDateFormat();
/*      */   
/*      */   MCDateFormat getDateFormat(int paramInt);
/*      */   
/*      */   void setFormat(MCTimestampFormat paramMCTimestampFormat);
/*      */   
/*      */   MCTimestampFormat getTimestampFormat();
/*      */   
/*      */   MCTimestampFormat getTimestampFormat(int paramInt);
/*      */   
/*      */   void setFormatPattern(MCCalendarPattern paramMCCalendarPattern);
/*      */   
/*      */   void setFormat(MCNumberFormat paramMCNumberFormat);
/*      */   
/*      */   MCNumberFormat getNumberFormat();
/*      */   
/*      */   MCNumberFormat getNumberFormat(int paramInt);
/*      */   
/*      */   void setFormatPattern(MCNumberPattern paramMCNumberPattern);
/*      */   
/*      */   void setFormatID(String paramString);
/*      */   
/*      */   void setListFormat(MCDateFormat paramMCDateFormat);
/*      */   
/*      */   MCDateFormat getListDateFormat();
/*      */   
/*      */   void setListFormat(MCTimestampFormat paramMCTimestampFormat);
/*      */   
/*      */   MCTimestampFormat getListTimestampFormat();
/*      */   
/*      */   void setListFormatPattern(MCCalendarPattern paramMCCalendarPattern);
/*      */   
/*      */   void setListFormat(MCNumberFormat paramMCNumberFormat);
/*      */   
/*      */   MCNumberFormat getListNumberFormat();
/*      */   
/*      */   void setListFormatPattern(MCNumberPattern paramMCNumberPattern);
/*      */   
/*      */   void setListFormatID(String paramString);
/*      */   
/*      */   void setIcon(Icon paramIcon);
/*      */   
/*      */   Icon getIcon();
/*      */   
/*      */   void setSelectedIcon(Icon paramIcon);
/*      */   
/*      */   Icon getSelectedIcon();
/*      */   
/*      */   void setPressedIcon(Icon paramIcon);
/*      */   
/*      */   Icon getPressedIcon();
/*      */   
/*      */   void setDisabledIcon(Icon paramIcon);
/*      */   
/*      */   Icon getDisabledIcon();
/*      */   
/*      */   void setDisabledSelectedIcon(Icon paramIcon);
/*      */   
/*      */   Icon getDisabledSelectedIcon();
/*      */   
/*      */   MCEventInfo getEventInfo();
/*      */   
/*      */   Color getFocusedCellBackground();
/*      */   
/*      */   void setFocusedCellBackground(Color paramColor);
/*      */   
/*      */   Color getFocusedCellForeground();
/*      */   
/*      */   void setFocusedCellForeground(Color paramColor);
/*      */   
/*      */   void updateResource();
/*      */   
/*      */   void setListVisibleColumn(String... paramVarArgs);
/*      */   
/*      */   String[] getListVisibleColumn();
/*      */   
/*      */   void setEchoChar(char paramChar);
/*      */   
/*      */   char getEchoChar();
/*      */   
/*      */   void setHeaderIcon(Icon paramIcon);
/*      */   
/*      */   void setHeaderIcon(String paramString);
/*      */   
/*      */   void setHeaderIconPath(String paramString);
/*      */   
/*      */   Icon getHeaderIcon();
/*      */   
/*      */   void setTrimPattern(String paramString);
/*      */   
/*      */   String getTrimPattern();
/*      */   
/*      */   String getName();
/*      */   
/*      */   boolean isMinusEnable(int paramInt);
/*      */   
/*      */   int getLength(int paramInt);
/*      */   
/*      */   int getScale(int paramInt);
/*      */   
/*      */   MCCellConfig getCellConfig();
/*      */   
/*      */   MCMessageList setValue(Comparable<?> paramComparable);
/*      */   
/*      */   MCMessageList setValues(MCRow paramMCRow);
/*      */   
/*      */   void setSelectedRowValue(Comparable<?> paramComparable);
/*      */   
/*      */   Comparable<?> getSelectedRowValue();
/*      */   
/*      */   Comparable<?> getRowValue(int paramInt);
/*      */   
/*      */   int getInitWidth();
/*      */   
/*      */   void setInitWidth();
/*      */   
/*      */   void setVisible(boolean paramBoolean);
/*      */   
/*      */   void setVisibleFromUser(boolean paramBoolean);
/*      */   
/*      */   boolean isVisible();
/*      */   
/*      */   boolean isVisibleFromUser();
/*      */   
/*      */   void setCalendarValidator(MCCalendarValidator paramMCCalendarValidator);
/*      */   
/*      */   MCCalendarValidator getCalendarValidator();
/*      */   
/*      */   void setCalendarEnabled(boolean paramBoolean);
/*      */   
/*      */   boolean isCalendarEnabled();
/*      */   
/*      */   boolean haveLinkValuesNullWhenDupliKeyTyped();
/*      */   
/*      */   void haveLinkValuesNullWhenDupliKeyTyped(boolean paramBoolean);
/*      */   
/*      */   boolean doListEventWithNull();
/*      */   
/*      */   void setListEventWithNull(boolean paramBoolean);
/*      */   
/*      */   MCList doListEvent(String paramString, int paramInt);
/*      */   
/*      */   boolean isValueChanged(int paramInt, Comparable<?> paramComparable1, Comparable<?> paramComparable2);
/*      */   
/*      */   Border getDefaultBorder();
/*      */   
/*      */   Color getModeColor(MCMode paramMCMode, String paramString);
/*      */   
/*      */   Color getColor(String paramString1, String paramString2);
/*      */   
/*      */   String getString(String paramString1, String paramString2);
/*      */   
/*      */   void setAdjustWidth(boolean paramBoolean);
/*      */   
/*      */   boolean isAdjustWidth();
/*      */   
/*      */   void setDefault();
/*      */   
/*      */   void setToolTipEnabled(boolean paramBoolean);
/*      */   
/*      */   boolean isToolTipEnabled();
/*      */   
/*      */   void setSortable(boolean paramBoolean);
/*      */   
/*      */   boolean isSortable();
/*      */   
/*      */   void setIgnoreStatus(boolean paramBoolean);
/*      */   
/*      */   boolean isIgnoreStatus();
/*      */   
/*      */   int getWidthWhenOpen();
/*      */   
/*      */   void setImagePanelEnabled(boolean paramBoolean);
/*      */   
/*      */   boolean isImagePanelEnabled();
/*      */   
/*      */   void setImagePanel(String paramString1, String paramString2);
/*      */   
/*      */   String[] getImagePanelID();
/*      */   
/*      */   void setImagePanelInfo(MCImagePanelInfo paramMCImagePanelInfo);
/*      */   
/*      */   MCImagePanelInfo getImagePanelInfo();
/*      */   
/*      */   Color getModeColor(MCMode paramMCMode, String paramString, Color paramColor, boolean paramBoolean);
/*      */   
/*      */   Color getColor(String paramString1, String paramString2, Color paramColor, boolean paramBoolean);
/*      */   
/*      */   List<Pattern> getAcceptPattern();
/*      */   
/*      */   void setAcceptPattern(List<Pattern> paramList);
/*      */   
/*      */   void addAcceptPattern(String paramString);
/*      */   
/*      */   void addAcceptPattern(String paramString, int paramInt);
/*      */   
/*      */   List<Character> getExceptCharacter();
/*      */   
/*      */   void setExceptCharacter(List<Character> paramList);
/*      */   
/*      */   void setExceptCharacter(char[] paramArrayOfchar);
/*      */   
/*      */   void addExceptCharacter(char paramChar);
/*      */   
/*      */   MCModeInfo getModeInfo();
/*      */   
/*      */   void setHeaderMessage(String paramString);
/*      */   
/*      */   void setMessageName(String paramString);
/*      */   
/*      */   String getBaseTableColumnName();
/*      */   
/*      */   boolean isLinkRowColumn();
/*      */   
/*      */   void setIcon(String paramString);
/*      */   
/*      */   void setIconPath(String paramString);
/*      */   
/*      */   @Deprecated
/*      */   Comparable<?> doListFormat(Comparable<?> paramComparable);
/*      */   
/*      */   Comparable<?> doListFormat(int paramInt, Comparable<?> paramComparable);
/*      */   
/*      */   void setInputMethodType(MCInputMethodType paramMCInputMethodType);
/*      */   
/*      */   MCInputMethodType getInputMethodType();
/*      */   
/*      */   void setViewScale(int paramInt);
/*      */   
/*      */   int getViewScale();
/*      */   
/*      */   void setViewZeroType(MCFormatConst.MCZeroType paramMCZeroType);
/*      */   
/*      */   MCFormatConst.MCZeroType getViewZeroType();
/*      */   
/*      */   MCFormatConst.MCZeroType getViewZeroType(int paramInt);
/*      */   
/*      */   void setViewRoundingMode(RoundingMode paramRoundingMode);
/*      */   
/*      */   RoundingMode getViewRoundingMode();
/*      */   
/*      */   void setComboListConfig(MCComboListConfig paramMCComboListConfig);
/*      */   
/*      */   MCComboListConfig getComboListConfig();
/*      */   
/*      */   boolean isFilteredColumn();
/*      */   
/*      */   void setCalendarPanel(String paramString1, String paramString2);
/*      */   
/*      */   String[] getCalendarPanelID();
/*      */   
/*      */   default void setImageSize(int width, int height) {}
/*      */   
/*      */   default int getImageWidth() {
/* 2117 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   default int getImageHeight() {
/* 2129 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setRequiredColumn(boolean paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isRequiredColumn();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   default boolean isReadOnlyColumn() {
/* 2158 */     return false;
/*      */   }
/*      */   
/*      */   MCMode _getMode();
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCColumnConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */