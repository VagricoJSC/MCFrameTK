/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.net.URL;
/*     */ import javax.swing.DefaultCellEditor;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextField;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.requester.MCDownloader;
/*     */ import mcframe.commonCore.lang.MCBinary;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCCellEditorImageView
/*     */   extends DefaultCellEditor
/*     */ {
/*  32 */   private static final JTextField TEXT_FIELD = new JTextField();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final MCColumnConfig _column;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCCellEditorImageView(String name, MCColumnConfig column) {
/*  51 */     super(new JTextField());
/*     */     
/*  53 */     final MCEditorImageView compo = new MCEditorImageView(name, column);
/*  54 */     this.editorComponent = (JComponent)compo;
/*  55 */     this.delegate = new DefaultCellEditor.EditorDelegate(this) {
/*     */         public void setValue(Object value) {
/*  57 */           if (value instanceof Icon)
/*  58 */             compo.setIcon((Icon)value); 
/*     */         }
/*     */         
/*     */         public Object getCellEditorValue() {
/*  62 */           return compo.getIcon();
/*     */         }
/*     */       };
/*  65 */     compo.addActionListener(this.delegate);
/*     */     
/*  67 */     this._column = column;
/*  68 */     setClickCountToStart(1);
/*  69 */     getEditorComponent().setBorder(TEXT_FIELD.getBorder());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCColumnConfig getColumnConfig() {
/*  80 */     return this._column;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getCellEditorValue() {
/*  85 */     return ((MCEditorBeans)this.editorComponent).getViewValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCEditorImageView getEditorComponent() {
/*  96 */     return (MCEditorImageView)this.editorComponent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Component getTableCellEditorComponent(JTable table, Object value, boolean selected, int index, int column) {
/* 114 */     return (Component)getEditor((MCTable)table, value, index, getColumnConfig());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCEditorImageView getEditor(MCTable<?> table, Object value, int index, MCColumnConfig column) {
/* 130 */     MCEditorImageView compo = getEditorComponent();
/* 131 */     compo.setBorderPainted(true);
/* 132 */     compo.setColumnInfo(index, column);
/*     */     
/* 134 */     if (value != null) {
/* 135 */       if (value instanceof MCBinary) {
/* 136 */         URL u = null;
/*     */         try {
/* 138 */           u = MCDownloader.getBinaryURL((MCBinary)value);
/* 139 */         } catch (Exception e) {
/* 140 */           table.clear();
/* 141 */           MCBeansUtil.handle(table, e);
/*     */         } 
/* 143 */         if (u != null) {
/* 144 */           compo.setIcon(new ImageIcon(u));
/*     */         }
/*     */       } else {
/* 147 */         compo.setIcon(null);
/*     */       } 
/*     */     } else {
/* 150 */       compo.setIcon(null);
/*     */     } 
/*     */     
/* 153 */     return compo;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCCellEditorImageView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */