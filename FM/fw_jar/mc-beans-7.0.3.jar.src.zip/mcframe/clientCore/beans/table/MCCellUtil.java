/*      */ package mcframe.clientCore.beans.table;
/*      */ 
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.event.KeyEvent;
/*      */ import java.math.RoundingMode;
/*      */ import javax.swing.JComponent;
/*      */ import javax.swing.JTextField;
/*      */ import javax.swing.SwingUtilities;
/*      */ import javax.swing.border.Border;
/*      */ import mcframe.clientCore.beans.MCBeansUtil;
/*      */ import mcframe.clientCore.beans.MCFrame;
/*      */ import mcframe.clientCore.beans.MCMode;
/*      */ import mcframe.clientCore.beans.MCRootPanel;
/*      */ import mcframe.clientCore.beans.popup.MCCalendarPopup;
/*      */ import mcframe.clientCore.beans.popup.MCPopupMenu;
/*      */ import mcframe.clientCore.beans.text.MCDateFormat;
/*      */ import mcframe.clientCore.beans.text.MCNumberFormat;
/*      */ import mcframe.clientCore.beans.text.MCTimestampFormat;
/*      */ import mcframe.clientCore.container.MCConstRow;
/*      */ import mcframe.clientCore.event.MCEventInfo;
/*      */ import mcframe.commonCore.container.MCList;
/*      */ import mcframe.commonCore.lang.MCDate;
/*      */ import mcframe.commonCore.lang.MCTimestamp;
/*      */ import mcframe.commonCore.notice.MCLog;
/*      */ import mcframe.commonCore.resource.MCFormatConst;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class MCCellUtil
/*      */ {
/*   47 */   static final Border DEFAULT_BORDER = (new JTextField()).getBorder();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Color getForeground(int index, MCColumnConfig column, MCTable<?> table, boolean selected, MCMode mode) {
/*      */     try {
/*   75 */       return column.getCellConfig().getCellForeground(index, column, 
/*   76 */           column.getTable(), selected, mode);
/*      */     }
/*   78 */     catch (RuntimeException e) {
/*   79 */       if (preHandle(table, e)) {
/*   80 */         handle(table, e);
/*   81 */         return null;
/*      */       } 
/*      */       
/*      */       try {
/*   85 */         return column.getCellConfig().getCellForeground(index, column, 
/*   86 */             column.getTable(), selected, mode);
/*      */       }
/*   88 */       catch (RuntimeException e2) {
/*   89 */         table.clear();
/*   90 */         handle(table, e2);
/*   91 */         return null;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static MCMode isCellEditable(int index, MCColumnConfig column, MCTable<?> table) {
/*      */     try {
/*  113 */       return column.getCellConfig().isCellEditable(index, column, 
/*  114 */           column.getTable());
/*      */     }
/*  116 */     catch (RuntimeException e) {
/*  117 */       if (preHandle(table, e)) {
/*  118 */         handle(table, e);
/*  119 */         return null;
/*      */       } 
/*      */       
/*      */       try {
/*  123 */         return column.getCellConfig().isCellEditable(index, column, 
/*  124 */             column.getTable());
/*      */       }
/*  126 */       catch (RuntimeException e2) {
/*  127 */         table.clear();
/*  128 */         handle(table, e2);
/*  129 */         return null;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Color getBackground(int index, MCColumnConfig column, MCTable<?> table, boolean selected, MCMode mode) {
/*      */     try {
/*  156 */       return column.getCellConfig().getCellBackground(index, column, 
/*  157 */           column.getTable(), selected, mode);
/*      */     }
/*  159 */     catch (RuntimeException e) {
/*  160 */       if (preHandle(table, e)) {
/*  161 */         handle(table, e);
/*  162 */         return null;
/*      */       } 
/*      */       
/*      */       try {
/*  166 */         return column.getCellConfig().getCellBackground(index, column, 
/*  167 */             column.getTable(), selected, mode);
/*      */       }
/*  169 */       catch (RuntimeException e2) {
/*  170 */         table.clear();
/*  171 */         handle(table, e2);
/*  172 */         return null;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void setFGBGColor(Component compo, int index, MCColumnConfig column, MCTable<?> table, MCMode mode, boolean selected, boolean focused) {
/*      */     try {
/*  194 */       MCCellConfig config = column.getCellConfig();
/*  195 */       if (index == table.getMCSelectedRow()) {
/*  196 */         MCRootPanel bp = table.getBaseRootPanel();
/*  197 */         MCFrame f = bp.getFrame();
/*  198 */         if (f != null && !f.isActive()) {
/*  199 */           Component o = bp.getFocusOwner();
/*  200 */           if (table.equalsIgnoreCase(o) && 
/*  201 */             table.getSelectedColumnConfig() == column) {
/*  202 */             focused = true;
/*      */           }
/*      */         } 
/*      */         
/*  206 */         if (focused) {
/*  207 */           compo.setForeground(
/*  208 */               config.getFocusedCellForeground(index, column, table, mode));
/*  209 */           compo.setBackground(
/*  210 */               config.getFocusedCellBackground(index, column, table, mode));
/*      */           return;
/*      */         } 
/*      */       } 
/*  214 */       compo.setForeground(
/*  215 */           config.getCellForeground(index, column, table, selected, mode));
/*  216 */       compo.setBackground(
/*  217 */           config.getCellBackground(index, column, table, selected, mode));
/*      */     }
/*  219 */     catch (RuntimeException e) {
/*  220 */       table.clear();
/*  221 */       MCBeansUtil.handle(table, e);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   static void initRenderer(JComponent compo, int index, MCColumnConfig column, MCTable<?> table, boolean selected, boolean focused, Border def) {
/*      */     try {
/*  228 */       MCCellConfig conf = column.getCellConfig();
/*  229 */       MCTable<?> tbl = column.getTable();
/*  230 */       MCMode mode = column.getBaseTable().isCellEditable(index, column);
/*  231 */       if (compo instanceof MCCellRenderer) {
/*  232 */         ((MCCellRenderer)compo)._mode = mode;
/*      */       }
/*      */       
/*  235 */       Color fg = null;
/*  236 */       Color bg = null;
/*  237 */       Border border = null;
/*  238 */       if (index == table.getMCSelectedRow()) {
/*  239 */         MCRootPanel bp = table.getBaseRootPanel();
/*  240 */         MCFrame frame = bp.getFrame();
/*  241 */         if (frame != null && !frame.isActive()) {
/*  242 */           Component owner = bp.getFocusOwner();
/*  243 */           if (table.equalsIgnoreCase(owner) && 
/*  244 */             table.getSelectedColumnConfig() == column) {
/*  245 */             focused = true;
/*      */           }
/*      */         } 
/*      */         
/*  249 */         if (focused) {
/*  250 */           fg = conf.getFocusedCellForeground(index, column, tbl, mode);
/*  251 */           bg = conf.getFocusedCellBackground(index, column, tbl, mode);
/*      */         } 
/*      */       } 
/*  254 */       if (fg == null) {
/*  255 */         fg = conf.getCellForeground(index, column, tbl, selected, mode);
/*      */       }
/*  257 */       if (bg == null) {
/*  258 */         bg = conf.getCellBackground(index, column, tbl, selected, mode);
/*      */       }
/*      */       
/*  261 */       compo.setFont(column.getFont());
/*  262 */       compo.setForeground(fg);
/*  263 */       compo.setBackground(bg);
/*      */       
/*  265 */       if (column.getColumnType() != MCColumnType.BUTTON) {
/*  266 */         border = conf.getColumnBorder(index, column, tbl);
/*  267 */         if (border == null) {
/*  268 */           border = def;
/*      */         }
/*  270 */         compo.setBorder(border);
/*      */       }
/*      */     
/*  273 */     } catch (RuntimeException e) {
/*  274 */       preHandle(table, e);
/*  275 */       handle(table, e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Color getCaretColor(int index, MCColumnConfig column, MCTable<?> table) {
/*      */     try {
/*  295 */       return column.getCellConfig().getCellCaretColor(index, column, 
/*  296 */           column.getTable());
/*      */     }
/*  298 */     catch (RuntimeException e) {
/*  299 */       if (preHandle(table, e)) {
/*  300 */         handle(table, e);
/*  301 */         return null;
/*      */       } 
/*      */       
/*      */       try {
/*  305 */         return column.getCellConfig().getCellCaretColor(index, column, 
/*  306 */             column.getTable());
/*      */       }
/*  308 */       catch (RuntimeException e2) {
/*  309 */         table.clear();
/*  310 */         handle(table, e2);
/*  311 */         return null;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Color getSelectedTextColor(int index, MCColumnConfig column, MCTable<?> table) {
/*      */     try {
/*  334 */       return column.getCellConfig().getCellSelectedTextColor(index, column, 
/*  335 */           column.getTable());
/*      */     }
/*  337 */     catch (RuntimeException e) {
/*  338 */       if (preHandle(table, e)) {
/*  339 */         handle(table, e);
/*  340 */         return null;
/*      */       } 
/*      */       
/*      */       try {
/*  344 */         return column.getCellConfig().getCellSelectedTextColor(index, column, 
/*  345 */             column.getTable());
/*      */       }
/*  347 */       catch (RuntimeException e2) {
/*  348 */         table.clear();
/*  349 */         handle(table, e2);
/*  350 */         return null;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Color getSelectionColor(int index, MCColumnConfig column, MCTable<?> table) {
/*      */     try {
/*  373 */       return column.getCellConfig().getCellSelectionColor(index, column, 
/*  374 */           column.getTable());
/*      */     }
/*  376 */     catch (RuntimeException e) {
/*  377 */       if (preHandle(table, e)) {
/*  378 */         handle(table, e);
/*  379 */         return null;
/*      */       } 
/*      */       
/*      */       try {
/*  383 */         return column.getCellConfig().getCellSelectionColor(index, column, 
/*  384 */             column.getTable());
/*      */       }
/*  386 */       catch (RuntimeException e2) {
/*  387 */         table.clear();
/*  388 */         handle(table, e2);
/*  389 */         return null;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Border getColumnBorder(int index, MCColumnConfig column, MCTable<?> table) {
/*      */     try {
/*  411 */       return column.getCellConfig().getColumnBorder(index, column, 
/*  412 */           column.getTable());
/*      */     }
/*  414 */     catch (RuntimeException e) {
/*  415 */       if (preHandle(table, e)) {
/*  416 */         handle(table, e);
/*  417 */         return null;
/*      */       } 
/*      */       
/*      */       try {
/*  421 */         return column.getCellConfig().getColumnBorder(index, column, 
/*  422 */             column.getTable());
/*      */       }
/*  424 */       catch (RuntimeException e2) {
/*  425 */         table.clear();
/*  426 */         handle(table, e2);
/*  427 */         return null;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Border getEditorBorder(int index, MCColumnConfig column, MCTable<?> table) {
/*      */     try {
/*  449 */       return column.getCellConfig().getEditorBorder(index, column, 
/*  450 */           column.getTable());
/*      */     }
/*  452 */     catch (RuntimeException e) {
/*  453 */       if (preHandle(table, e)) {
/*  454 */         handle(table, e);
/*  455 */         return null;
/*      */       } 
/*      */       
/*      */       try {
/*  459 */         return column.getCellConfig().getEditorBorder(index, column, 
/*  460 */             column.getTable());
/*      */       }
/*  462 */       catch (RuntimeException e2) {
/*  463 */         table.clear();
/*  464 */         handle(table, e2);
/*  465 */         return null;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int getLength(int index, MCColumnConfig column, MCTable<?> table) {
/*      */     try {
/*  487 */       return column.getCellConfig().getCellLength(index, column, column.getTable());
/*      */     }
/*  489 */     catch (RuntimeException e) {
/*  490 */       if (preHandle(table, e)) {
/*  491 */         handle(table, e);
/*  492 */         return column.getLength();
/*      */       } 
/*      */       
/*      */       try {
/*  496 */         return column.getCellConfig().getCellLength(index, column, 
/*  497 */             column.getTable());
/*      */       }
/*  499 */       catch (RuntimeException e2) {
/*  500 */         table.clear();
/*  501 */         handle(table, e2);
/*  502 */         return column.getLength();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int getScale(int index, MCColumnConfig column, MCTable<?> table) {
/*      */     try {
/*  525 */       return column.getCellConfig().getCellScale(index, column, column.getTable());
/*      */     }
/*  527 */     catch (RuntimeException e) {
/*  528 */       if (preHandle(table, e)) {
/*  529 */         handle(table, e);
/*  530 */         return column.getScale();
/*      */       } 
/*      */       
/*      */       try {
/*  534 */         return column.getCellConfig().getCellScale(index, column, 
/*  535 */             column.getTable());
/*      */       }
/*  537 */       catch (RuntimeException e2) {
/*  538 */         table.clear();
/*  539 */         handle(table, e2);
/*  540 */         return column.getScale();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static boolean isMinusEnable(int index, MCColumnConfig column, MCTable<?> table) {
/*      */     try {
/*  562 */       return column.getCellConfig().isCellMinusEnable(index, column, 
/*  563 */           column.getTable());
/*      */     }
/*  565 */     catch (RuntimeException e) {
/*  566 */       if (preHandle(table, e)) {
/*  567 */         handle(table, e);
/*  568 */         return column.isMinusEnable();
/*      */       } 
/*      */       
/*      */       try {
/*  572 */         return column.getCellConfig().isCellMinusEnable(index, column, 
/*  573 */             column.getTable());
/*      */       }
/*  575 */       catch (RuntimeException e2) {
/*  576 */         table.clear();
/*  577 */         handle(table, e2);
/*  578 */         return column.isMinusEnable();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static MCRootPanel getRootPanel(MCEditorBeans compo) {
/*  598 */     MCColumnConfig column = compo.getColumnConfig();
/*  599 */     return (column != null) ? column.getRootPanel() : null;
/*      */   }
/*      */   
/*      */   static MCRootPanel getNearestRootPanel(MCEditorBeans compo) {
/*  603 */     MCColumnConfig c = compo.getColumnConfig();
/*  604 */     return (c != null) ? c.getNearestRootPanel() : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static boolean preHandle(MCTable<?> table, RuntimeException e) {
/*  622 */     boolean rtn = table.clear();
/*  623 */     if (!rtn) {
/*  624 */       MCEditorBeans eb = table.getEditorBeans();
/*  625 */       if (eb != null) {
/*  626 */         eb.setRowToViews();
/*      */ 
/*      */ 
/*      */         
/*  630 */         MCLog.write(e);
/*      */       } 
/*      */     } 
/*  633 */     return rtn;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void handle(final MCTable<?> table, final RuntimeException e) {
/*  646 */     MCRootPanel p = table.getBaseRootPanel();
/*  647 */     if (p != null) {
/*  648 */       MCFrame f = p.getFrame();
/*  649 */       if (f != null) {
/*  650 */         Graphics g = f.getGraphics();
/*  651 */         if (g != null) {
/*  652 */           f.update(g);
/*      */         }
/*      */       } else {
/*      */         
/*  656 */         Graphics g = p.getGraphics();
/*  657 */         if (g != null) {
/*  658 */           p.update(g);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  663 */     SwingUtilities.invokeLater(new Runnable()
/*      */         {
/*      */           public void run()
/*      */           {
/*      */             try {
/*  668 */               MCBeansUtil.handle(table, e);
/*      */             }
/*  670 */             catch (RuntimeException runtimeException) {}
/*      */           }
/*      */         });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static boolean isFocusable(MCEditorBeans editor) {
/*  680 */     MCPopupMenu.hideActivePopupMenu();
/*  681 */     JComponent compo = (JComponent)editor;
/*  682 */     if (compo != null && compo.isVisible()) {
/*      */       
/*  684 */       MCRootPanel p = editor.getBaseRootPanel();
/*  685 */       if (p != null) {
/*  686 */         if (!(p instanceof mcframe.clientCore.beans.popup.MCCalendarPanel)) {
/*  687 */           MCCalendarPopup.hideActivePopup();
/*      */         }
/*      */         
/*  690 */         MCFrame f = p.getFrame();
/*  691 */         if (f != null && !f.isActive() && !f.canActive()) {
/*  692 */           return false;
/*      */         }
/*      */         
/*  695 */         JComponent o = MCBeansUtil.getFocusOwner(compo);
/*  696 */         if (hasFocus(editor, o)) {
/*  697 */           return true;
/*      */         }
/*      */ 
/*      */         
/*  701 */         return MCBeansUtil.requestCommit(o) ? (
/*  702 */           (compo.isEnabled() && compo.isFocusable())) : false;
/*      */       } 
/*      */     } 
/*  705 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean hasFocus(MCEditorBeans compo, JComponent owner) {
/*  718 */     if (compo == owner) {
/*  719 */       return true;
/*      */     }
/*  721 */     if (compo.equalsIgnoreCase(owner)) {
/*  722 */       return true;
/*      */     }
/*  724 */     if (((JComponent)compo).hasFocus()) {
/*  725 */       return true;
/*      */     }
/*      */     
/*  728 */     if (owner instanceof MCTable) {
/*  729 */       MCTable<?> table = (MCTable)owner;
/*  730 */       Component editor = table.getMCEditorComponent();
/*  731 */       if (editor == compo) {
/*  732 */         return true;
/*      */       }
/*      */     } 
/*  735 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Border getBorder(MCEditorBeans compo) {
/*  752 */     MCColumnConfig c = compo.getColumnConfig();
/*  753 */     return (c != null) ? 
/*  754 */       c.getCellConfig().getEditorBorder(compo.getRowIndex(), c, c.getTable()) : 
/*  755 */       null;
/*      */   }
/*      */ 
/*      */   
/*      */   static boolean isRequestFocusEnabled(MCEditorBeans compo) {
/*  760 */     MCTable<?> t = compo.getTable();
/*  761 */     if (!t.equalsIgnoreCase(MCBeansUtil.getFocusOwner(t)) && 
/*  762 */       !t.isRequestFocusEnabled()) {
/*  763 */       return false;
/*      */     }
/*      */     
/*  766 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static int getRowIndex(MCEditorBeans compo) {
/*  778 */     MCTable<?> t = compo.getTable();
/*  779 */     if (t != null) {
/*  780 */       t = t.getBaseTable();
/*  781 */       MCList<?> l = t.getList();
/*  782 */       if (l != null) {
/*  783 */         MCConstRow c = compo.getBaseRow();
/*  784 */         if (c != null) {
/*  785 */           return l.indexOf(c);
/*      */         }
/*      */       } 
/*      */     } 
/*  789 */     return -1;
/*      */   }
/*      */   
/*      */   static void beforeKeyEvent(KeyEvent e, MCEditorBeans compo) {
/*  793 */     MCTable<?> t = compo.getTable();
/*  794 */     if (t != null) {
/*  795 */       beforeKeyEvent(e, t.getBaseTable());
/*      */     }
/*      */   }
/*      */   
/*      */   static void beforeKeyEvent(KeyEvent e, MCTable<?> table) {
/*  800 */     if (!e.isAltDown() && !e.isControlDown() && !e.isShiftDown()) {
/*  801 */       MCEventInfo i = table.getEventInfo();
/*  802 */       MCEventProxy.PROXY.setClickColumn(i, null);
/*  803 */       MCEventProxy.PROXY.setClickIndex(i, -1);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Color darker(Color color, double ratio) {
/*  817 */     if (color == null) {
/*  818 */       return null;
/*      */     }
/*      */     
/*  821 */     return new Color(Math.max((int)(color.getRed() * ratio), 0), 
/*  822 */         Math.max((int)(color.getGreen() * ratio), 0), 
/*  823 */         Math.max((int)(color.getBlue() * ratio), 0));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Color brighter(Color color, double ratio) {
/*  836 */     if (color == null) {
/*  837 */       return null;
/*      */     }
/*      */     
/*  840 */     int i = (int)(1.0D / (1.0D - ratio));
/*  841 */     int r = color.getRed();
/*  842 */     int g = color.getGreen();
/*  843 */     int b = color.getBlue();
/*  844 */     if (r == 0 && g == 0 && b == 0) {
/*  845 */       return new Color(i, i, i);
/*      */     }
/*  847 */     if (r >= 0 && r < i) {
/*  848 */       r = i;
/*      */     }
/*  850 */     if (g >= 0 && g < i) {
/*  851 */       g = i;
/*      */     }
/*  853 */     if (b >= 0 && b < i) {
/*  854 */       b = i;
/*      */     }
/*  856 */     return new Color((int)Math.min(r / ratio, 255.0D), (int)Math.min(g / ratio, 255.0D), 
/*  857 */         (int)Math.min(b / ratio, 255.0D));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static MCNumberFormat getNumberFormat(int index, MCColumnConfig column, MCTable<?> table, MCMode mode) {
/*      */     try {
/*  877 */       return column.getCellConfig().getCellNumberFormat(index, column, 
/*  878 */           column.getTable(), mode);
/*      */     }
/*  880 */     catch (RuntimeException e) {
/*  881 */       if (preHandle(table, e)) {
/*  882 */         handle(table, e);
/*  883 */         return null;
/*      */       } 
/*      */       
/*      */       try {
/*  887 */         return column.getCellConfig().getCellNumberFormat(index, column, 
/*  888 */             column.getTable(), mode);
/*      */       }
/*  890 */       catch (RuntimeException e2) {
/*  891 */         table.clear();
/*  892 */         handle(table, e2);
/*  893 */         return null;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static MCDateFormat getDateFormat(int index, MCColumnConfig column, MCTable<?> table, MCMode mode) {
/*      */     try {
/*  917 */       return column.getCellConfig().getCellDateFormat(index, column, 
/*  918 */           column.getTable(), mode);
/*      */     }
/*  920 */     catch (RuntimeException e) {
/*  921 */       if (preHandle(table, e)) {
/*  922 */         handle(table, e);
/*  923 */         return null;
/*      */       } 
/*      */       
/*      */       try {
/*  927 */         return column.getCellConfig().getCellDateFormat(index, column, 
/*  928 */             column.getTable(), mode);
/*      */       }
/*  930 */       catch (RuntimeException e2) {
/*  931 */         table.clear();
/*  932 */         handle(table, e2);
/*  933 */         return null;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static MCTimestampFormat getTimestampFormat(int index, MCColumnConfig column, MCTable<?> table, MCMode mode) {
/*      */     try {
/*  956 */       return column.getCellConfig().getCellTimestampFormat(index, column, 
/*  957 */           column.getTable(), mode);
/*      */     }
/*  959 */     catch (RuntimeException e) {
/*  960 */       if (preHandle(table, e)) {
/*  961 */         handle(table, e);
/*  962 */         return null;
/*      */       } 
/*      */       
/*      */       try {
/*  966 */         return column.getCellConfig().getCellTimestampFormat(index, column, 
/*  967 */             column.getTable(), mode);
/*      */       }
/*  969 */       catch (RuntimeException e2) {
/*  970 */         table.clear();
/*  971 */         handle(table, e2);
/*  972 */         return null;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static MCDate getInitDateCalendarFocus(int index, MCColumnConfig column, MCTable<?> table) {
/*  993 */     return column.getCellConfig().getInitDateCalendarFocus(index, column, 
/*  994 */         column.getTable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static MCTimestamp getInitTimestampCalendarFocus(int index, MCColumnConfig column, MCTable<?> table) {
/* 1012 */     return column.getCellConfig().getInitTimestampCalendarFocus(index, column, 
/* 1013 */         column.getTable());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static boolean hasFocus(MCTable<?> table, int row, int column) {
/* 1033 */     if (table.getSelectionModel().getLeadSelectionIndex() != row) {
/* 1034 */       return false;
/*      */     }
/* 1036 */     if (table.getColumnSelectionModel().getLeadSelectionIndex() != column) {
/* 1037 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1045 */     return table.equalsIgnoreCase(MCBeansUtil.getFocusOwner(table));
/*      */   }
/*      */   
/*      */   static int getViewScale(int index, MCColumnConfig column, MCTable<?> table) {
/*      */     try {
/* 1050 */       return column.getCellConfig().getCellViewScale(index, column, table);
/*      */     }
/* 1052 */     catch (RuntimeException e) {
/* 1053 */       if (preHandle(table, e)) {
/* 1054 */         handle(table, e);
/* 1055 */         return column.getViewScale();
/*      */       } 
/*      */       
/*      */       try {
/* 1059 */         return column.getCellConfig().getCellViewScale(index, column, table);
/*      */       }
/* 1061 */       catch (RuntimeException e2) {
/* 1062 */         table.clear();
/* 1063 */         handle(table, e2);
/* 1064 */         return column.getViewScale();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static MCFormatConst.MCZeroType getViewZeroType(int index, MCColumnConfig column, MCTable<?> table) {
/*      */     try {
/* 1073 */       return column.getCellConfig().getCellViewZeroType(index, column, table);
/*      */     }
/* 1075 */     catch (RuntimeException e) {
/* 1076 */       if (preHandle(table, e)) {
/* 1077 */         handle(table, e);
/* 1078 */         return column.getViewZeroType();
/*      */       } 
/*      */       
/*      */       try {
/* 1082 */         return column.getCellConfig().getCellViewZeroType(index, column, 
/* 1083 */             table);
/*      */       }
/* 1085 */       catch (RuntimeException e2) {
/* 1086 */         table.clear();
/* 1087 */         handle(table, e2);
/* 1088 */         return column.getViewZeroType();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static RoundingMode getViewRoundingMode(int index, MCColumnConfig column, MCTable<?> table) {
/*      */     try {
/* 1097 */       return column.getCellConfig().getCellViewRoundingMode(index, column, table);
/*      */     }
/* 1099 */     catch (RuntimeException e) {
/* 1100 */       if (preHandle(table, e)) {
/* 1101 */         handle(table, e);
/* 1102 */         return column.getViewRoundingMode();
/*      */       } 
/*      */       
/*      */       try {
/* 1106 */         return column.getCellConfig().getCellViewRoundingMode(index, column, 
/* 1107 */             table);
/*      */       }
/* 1109 */       catch (RuntimeException e2) {
/* 1110 */         table.clear();
/* 1111 */         handle(table, e2);
/* 1112 */         return column.getViewRoundingMode();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static String[] getCalendarPanelID(int index, MCColumnConfig column, MCTable<?> table) {
/*      */     try {
/* 1121 */       return column.getCellConfig().getCalendarPanelID(index, column, table);
/*      */     }
/* 1123 */     catch (RuntimeException e) {
/* 1124 */       if (preHandle(table, e)) {
/* 1125 */         handle(table, e);
/* 1126 */         return null;
/*      */       } 
/*      */       
/*      */       try {
/* 1130 */         return column.getCellConfig().getCalendarPanelID(index, column, 
/* 1131 */             table);
/*      */       }
/* 1133 */       catch (RuntimeException e2) {
/* 1134 */         table.clear();
/* 1135 */         handle(table, e2);
/* 1136 */         return null;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static boolean isValueChanged(MCEditorBeans compo, Comparable<?> view, Comparable<?> row) {
/* 1144 */     MCRootPanel p = compo.getRootPanel();
/* 1145 */     MCTable<?> t = compo.getTable();
/* 1146 */     MCColumnConfig c = compo.getColumnConfig();
/* 1147 */     int i = compo.getRowIndex();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1154 */     if (p == null || t == null || c == null || i < 0 || i >= t.getRowCount()) {
/* 1155 */       return false;
/*      */     }
/*      */     
/* 1158 */     return p.isValueChanged(i, c, view, row);
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCCellUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */