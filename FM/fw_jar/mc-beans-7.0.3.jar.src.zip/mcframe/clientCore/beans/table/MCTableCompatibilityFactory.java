/*    */ package mcframe.clientCore.beans.table;
/*    */ 
/*    */ import mcframe.clientCore.container.MCConstRow;
/*    */ 
/*    */ public class MCTableCompatibilityFactory {
/*    */   public static MCEditorButton createEditorButton(String name, MCColumnConfig column) {
/*  7 */     return new MCEditorButton(name, column);
/*    */   }
/*    */   public static <E extends MCConstRow> MCColumnGroupTable<E> createColumnGroupTable(String name) {
/* 10 */     return new MCColumnGroupTable<>(name);
/*    */   }
/*    */   public static MCEditorCheckBox createEditorCheckBox(String name, MCColumnConfig column) {
/* 13 */     return new MCEditorCheckBox(name, column);
/*    */   }
/*    */   public static MCEditorDateComboBox createEditorDateComboBox(String name, MCColumnConfig column) {
/* 16 */     return new MCEditorDateComboBox(name, column);
/*    */   }
/*    */   public static MCEditorDateField createEditorDateField(String name, MCColumnConfig column) {
/* 19 */     return new MCEditorDateField(name, column);
/*    */   }
/*    */   public static MCEditorImageView createEditorImageView(String name, MCColumnConfig column) {
/* 22 */     return new MCEditorImageView(name, column);
/*    */   }
/*    */   public static MCEditorNumberComboBox createEditorNumberComboBox(String name, MCColumnConfig column) {
/* 25 */     return new MCEditorNumberComboBox(name, column);
/*    */   }
/*    */   public static MCEditorNumberField createEditorNumberField(String name, MCColumnConfig column) {
/* 28 */     return new MCEditorNumberField(name, column);
/*    */   }
/*    */   public static MCEditorPasswordField createEditorPasswordField(String name, MCColumnConfig column) {
/* 31 */     return new MCEditorPasswordField(name, column);
/*    */   }
/*    */   public static MCEditorTextComboBox createEditorTextComboBox(String name, MCColumnConfig column) {
/* 34 */     return new MCEditorTextComboBox(name, column);
/*    */   }
/*    */   public static MCEditorTextField createEditorTextField(String name, MCColumnConfig column) {
/* 37 */     return new MCEditorTextField(name, column);
/*    */   }
/*    */   public static MCEditorTimestampComboBox createEditorTimestampComboBox(String name, MCColumnConfig column) {
/* 40 */     return new MCEditorTimestampComboBox(name, column);
/*    */   }
/*    */   public static MCEditorTimestampField createEditorTimestampField(String name, MCColumnConfig column) {
/* 43 */     return new MCEditorTimestampField(name, column);
/*    */   }
/*    */   public static MCFixedColumnTable createFixedColumnTable(MCTable<MCConstRow> table, String name) {
/* 46 */     return new MCFixedColumnTable<>(table, name);
/*    */   }
/*    */   public static <E extends MCConstRow> MCLayoutTable<E> createLayoutTable(String name) {
/* 49 */     return new MCLayoutTable<>(name);
/*    */   }
/*    */   public static <E extends MCConstRow> MCTable2<E> createTable2(String name) {
/* 52 */     return new MCTable2<>(name);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCTableCompatibilityFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */