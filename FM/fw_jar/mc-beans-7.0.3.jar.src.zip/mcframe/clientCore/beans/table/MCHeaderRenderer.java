/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Insets;
/*     */ import java.math.BigDecimal;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.table.DefaultTableCellRenderer;
/*     */ import javax.swing.table.TableCellRenderer;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCHeaderRenderer
/*     */   extends DefaultTableCellRenderer
/*     */   implements MCHeaderRendererCommon
/*     */ {
/*     */   private TableCellRenderer _default_cell_renderer;
/*     */   
/*     */   protected MCHeaderRenderer(TableCellRenderer def) {
/*  65 */     this._default_cell_renderer = def;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
/*  84 */     return getRenderer((MCTable)table, (Comparable)value, isSelected, 
/*  85 */         hasFocus, row, column);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Component getRenderer(MCTable<?> table, Comparable<?> value, boolean selected, boolean focused, int row, int real) {
/* 104 */     MCColumnConfig column = table.getColumnFromReal(table, real);
/* 105 */     return getTableCellRendererComponent(
/* 106 */         table, value, selected, focused, row, real, column);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Component getTableCellRendererComponent(MCTable<?> table, Comparable<?> value, boolean selected, boolean focused, int row, int real, MCColumnConfig column) {
/* 115 */     JLabel label = (JLabel)this._default_cell_renderer.getTableCellRendererComponent(
/* 116 */         table, value, selected, focused, row, real);
/* 117 */     if (column == null) {
/* 118 */       return label;
/*     */     }
/*     */     
/* 121 */     label.setText(column.getHeaderName());
/* 122 */     Font font = getHeaderFont(column, table);
/* 123 */     if (font != null) {
/* 124 */       label.setFont(font);
/*     */     }
/* 126 */     Color fg = getHeaderForeground(column, table);
/* 127 */     if (fg != null) {
/* 128 */       label.setForeground(fg);
/*     */     }
/* 130 */     Color bg = getHeaderBackground(column, table);
/* 131 */     if (bg != null) {
/* 132 */       label.setBackground(bg);
/*     */     }
/* 134 */     Icon icon = getHeaderIcon(column);
/* 135 */     ImageIcon image = null;
/* 136 */     if (MCBeansUtil.isAdjustSize(column) && 
/* 137 */       icon instanceof ImageIcon) {
/* 138 */       ImageIcon temp = (ImageIcon)icon;
/* 139 */       image = new ImageIcon(temp.getImage());
/* 140 */       Dimension size = getIconSize(
/* 141 */           (MCTableColumn)column, table, image);
/* 142 */       image.setImage(image.getImage().getScaledInstance(
/* 143 */             size.width, size.height, 4));
/*     */     } 
/*     */     
/* 146 */     label.setIcon(image);
/* 147 */     int alignment = column.getHeaderHorizontalAlignment();
/* 148 */     if (alignment != -1) {
/* 149 */       label.setHorizontalAlignment(alignment);
/*     */     }
/*     */ 
/*     */     
/* 153 */     if (column.isToolTipEnabled()) {
/* 154 */       String text = column.getMessageByLocale();
/*     */       
/* 156 */       if (text != null && text.length() != 0) {
/* 157 */         label.setToolTipText(text);
/*     */       } else {
/* 159 */         label.setToolTipText((String)null);
/*     */       } 
/*     */     } else {
/* 162 */       label.setToolTipText((String)null);
/*     */     } 
/*     */     
/* 165 */     int ratio = table.getRatio();
/*     */     
/* 167 */     int def = 21;
/* 168 */     int height = def * ratio / 100;
/* 169 */     int width = column.getColumnWidth();
/*     */     
/* 171 */     label.setSize(width, height);
/*     */ 
/*     */     
/* 174 */     Dimension s = label.getPreferredSize();
/* 175 */     label.setPreferredSize(
/* 176 */         new Dimension(s.width, getPreferredHeight(label, table)));
/*     */     
/* 178 */     return label;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Dimension getIconSize(MCTableColumn column, MCTable<?> table, Icon icon) {
/* 192 */     Insets insets = getBorderInsets();
/* 193 */     BigDecimal i_width = new BigDecimal(icon.getIconWidth());
/* 194 */     BigDecimal i_height = new BigDecimal(icon.getIconHeight());
/* 195 */     BigDecimal b_width = new BigDecimal(
/* 196 */         column.getWidth() - insets.left - insets.right);
/* 197 */     BigDecimal b_height = new BigDecimal(
/* 198 */         table.getTableHeader().getHeight() - insets.top - insets.bottom);
/* 199 */     BigDecimal width = b_width.divide(i_width, 3, 4);
/* 200 */     BigDecimal height = b_height.divide(i_height, 3, 4);
/* 201 */     int compare = width.compareTo(height);
/* 202 */     switch (compare) {
/*     */       case -1:
/*     */       case 0:
/* 205 */         return new Dimension(i_width.multiply(width).intValue(), 
/* 206 */             i_height.multiply(width).intValue());
/*     */       case 1:
/* 208 */         return new Dimension(i_width.multiply(height).intValue(), 
/* 209 */             i_height.multiply(height).intValue());
/*     */     } 
/* 211 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Insets getBorderInsets() {
/* 223 */     Border border = getBorder();
/* 224 */     if (border != null) {
/* 225 */       Insets insets = border.getBorderInsets(this);
/* 226 */       return new Insets(insets.top + 2, insets.left + 2, 
/* 227 */           insets.bottom + 2, insets.right + 2);
/*     */     } 
/* 229 */     return new Insets(2, 2, 2, 2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Font getHeaderFont(MCColumnConfig column, MCTable<?> table) {
/* 243 */     Font result = null;
/* 244 */     if (column != null) {
/* 245 */       result = column.getHeaderFont();
/*     */     }
/* 247 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Color getHeaderForeground(MCColumnConfig column, MCTable<?> table) {
/* 262 */     if (column == null) {
/* 263 */       return null;
/*     */     }
/*     */     
/* 266 */     Color c = null;
/* 267 */     if (column.isFilteredColumn()) {
/* 268 */       c = column.getFilteredHeaderForeground();
/*     */     }
/* 270 */     if (c == null) {
/* 271 */       c = column.getHeaderForeground();
/*     */     }
/* 273 */     if (c == null) {
/* 274 */       c = column.getModeInfo().getLabelForeground();
/*     */     }
/* 276 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Color getHeaderBackground(MCColumnConfig column, MCTable<?> table) {
/* 291 */     if (column == null) {
/* 292 */       return null;
/*     */     }
/*     */     
/* 295 */     Color c = null;
/* 296 */     if (column.isFilteredColumn()) {
/* 297 */       c = column.getFilteredHeaderBackground();
/*     */     }
/* 299 */     if (c == null) {
/* 300 */       c = column.getHeaderBackground();
/*     */     }
/* 302 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Icon getHeaderIcon(MCColumnConfig column) {
/* 316 */     return (column != null) ? column.getHeaderIcon() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private int getPreferredHeight(JLabel label, MCTable<?> table) {
/* 322 */     int h = 0;
/* 323 */     JLabel l = new JLabel();
/* 324 */     l.setFont(label.getFont()); byte b; int i; MCColumnConfig[] arrayOfMCColumnConfig;
/* 325 */     for (i = (arrayOfMCColumnConfig = table.getAllViewColumnConfigs()).length, b = 0; b < i; ) { MCColumnConfig c = arrayOfMCColumnConfig[b];
/* 326 */       l.setText(c.getHeaderName());
/* 327 */       h = Math.max(h, (l.getPreferredSize()).height); b++; }
/*     */     
/* 329 */     return h;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCHeaderRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */