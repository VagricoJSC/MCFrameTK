/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import javax.swing.table.TableColumn;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCTable2ColumnModel
/*     */   extends MCTableColumnModel
/*     */ {
/*     */   private MCTable2<?> _table;
/*     */   private WidthSupplier WS_PREFERREDWIDTH;
/*     */   private WidthSupplier WS_MAXWIDTH;
/*     */   private WidthSupplier WS_MINWIDTH;
/*     */   private int[] _retpos;
/*     */   private MCColumnConfig[] _retcol;
/*     */   private MCColumnConfig[] _d_retcol;
/*     */   
/*     */   protected void recalcWidthCache() {
/*     */     WidthSupplier ws = new WidthSupplier()
/*     */       {
/*     */         public long width(MCTableColumn column) {
/*     */           return column.getWidth();
/*     */         }
/*     */       };
/*     */     this.totalColumnWidth = calcWidth(ws);
/*     */   }
/*     */   
/*     */   public void addColumn(TableColumn column) {
/*     */     resetReturnPositions();
/*     */     super.addColumn(column);
/*     */   }
/*     */   
/*     */   public void moveColumn(int columnIndex, int newIndex) {
/*     */     resetReturnPositions();
/*     */     int ai = getSelectionModel().getAnchorSelectionIndex();
/*     */     TableColumn aoc = (ai < 0) ? null : getColumn(ai);
/*     */     int li = getSelectionModel().getLeadSelectionIndex();
/*     */     TableColumn loc = (li < 0) ? null : getColumn(li);
/*     */     super.moveColumn(columnIndex, newIndex);
/*     */     ai = getIndex(aoc);
/*     */     li = getIndex(loc);
/*     */     getSelectionModel().setAnchorSelectionIndex(ai);
/*     */     getSelectionModel().setLeadSelectionIndex(li);
/*     */   }
/*     */   
/*     */   protected MCTable2ColumnModel(MCTable2<?> table) {
/* 147 */     this.WS_PREFERREDWIDTH = new WidthSupplier()
/*     */       {
/*     */         public long width(MCTableColumn column) {
/* 150 */           return column.getPreferredWidth();
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 159 */     this.WS_MAXWIDTH = new WidthSupplier()
/*     */       {
/*     */         public long width(MCTableColumn column) {
/* 162 */           return column.getMaxWidth();
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 171 */     this.WS_MINWIDTH = new WidthSupplier()
/*     */       {
/*     */         public long width(MCTableColumn column) {
/* 174 */           return column.getMinWidth();
/*     */         }
/*     */       };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 284 */     this._retpos = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 296 */     this._retcol = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 303 */     this._d_retcol = null;
/*     */     this._table = table;
/*     */   }
/*     */   public void removeColumn(TableColumn column) { resetReturnPositions();
/*     */     removeReturnColumn((MCColumnConfig)column);
/*     */     super.removeColumn(column); }
/*     */   public MCTableColumn getColumn(int columnIndex) { return (MCTableColumn)this.tableColumns.elementAt(columnIndex); } public MCColumnConfig[] getAllTableColumns() {
/*     */     return this._table.getAllColumnConfigs();
/*     */   } int calcWidth(WidthSupplier ws) {
/*     */     int limit = getColumnCount();
/*     */     return calcWidth(ws, limit);
/* 314 */   } void setDefaultReturnPositions() { this._d_retcol = (this._retcol != null) ? 
/* 315 */       Arrays.<MCColumnConfig>copyOf(this._retcol, this._retcol.length) : 
/* 316 */       null; }
/*     */   int calcWidth(WidthSupplier ws, int limit) { long width = 0L; long rWidth = 0L; int fixcnt = getFixedColumnCount(); int colslen = getColumnCount(); limit = (limit > colslen) ? colslen : limit; int[] retpos = getReturnPositions(); int tier = 0; for (int i = 0; i < limit; i++) {
/*     */       MCTableColumn column = getColumn(i);
/*     */       rWidth += ws.width(column);
/*     */       if (i >= retpos[tier] - fixcnt) {
/*     */         width = Math.max(width, rWidth);
/*     */         rWidth = 0L;
/*     */         tier++;
/*     */       } 
/*     */     } 
/* 326 */     return (int)width; } private void resetReturnPositions() { this._retpos = null; }
/*     */    int getPreferredWidth() {
/*     */     return calcWidth(this.WS_PREFERREDWIDTH);
/*     */   }
/*     */   int getMaximumWidth() {
/*     */     return calcWidth(this.WS_MAXWIDTH);
/*     */   }
/*     */   int getMinimumWidth() {
/*     */     return calcWidth(this.WS_MINWIDTH);
/*     */   }
/*     */   public MCColumnConfig[] removeAllReturnColumns() {
/* 337 */     resetReturnPositions();
/*     */     
/* 339 */     MCColumnConfig[] all = this._retcol;
/* 340 */     this._retcol = null;
/* 341 */     return all;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void removeReturnColumn(MCColumnConfig column) {
/* 355 */     if (this._retcol == null || this._retcol.length == 0) {
/*     */       return;
/*     */     }
/*     */     
/* 359 */     for (int idx = this._retcol.length - 1; idx >= 0; idx--) {
/* 360 */       if (this._retcol[idx] == column) {
/*     */         
/* 362 */         if (this._retcol.length == 1) {
/*     */           
/* 364 */           this._retcol = null;
/*     */           break;
/*     */         } 
/* 367 */         MCColumnConfig[] buf = new MCColumnConfig[this._retcol.length - 1];
/* 368 */         System.arraycopy(this._retcol, 0, buf, 0, idx);
/* 369 */         if (idx < buf.length) {
/* 370 */           System.arraycopy(this._retcol, idx + 1, buf, idx, 
/* 371 */               buf.length - idx);
/*     */         }
/* 373 */         this._retcol = buf;
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addReturnColumn(MCColumnConfig... cols) {
/* 387 */     if (cols == null) {
/* 388 */       cols = new MCColumnConfig[0];
/*     */     }
/* 390 */     resetReturnPositions();
/*     */ 
/*     */     
/* 393 */     int bufpos = 0;
/* 394 */     MCColumnConfig[] bufcols = (this._retcol == null) ? 
/* 395 */       new MCColumnConfig[cols.length] : 
/* 396 */       new MCColumnConfig[cols.length + this._retcol.length];
/* 397 */     if (this._retcol != null) {
/* 398 */       bufpos = this._retcol.length;
/* 399 */       System.arraycopy(this._retcol, 0, bufcols, 0, bufpos);
/*     */     } 
/*     */     
/* 402 */     MCColumnConfig[] tcs = getAllTableColumns(); byte b;
/*     */     int i;
/*     */     MCColumnConfig[] arrayOfMCColumnConfig1;
/* 405 */     for (i = (arrayOfMCColumnConfig1 = cols).length, b = 0; b < i; ) { MCColumnConfig col = arrayOfMCColumnConfig1[b];
/*     */       
/* 407 */       if (col != null) {
/*     */ 
/*     */ 
/*     */         
/* 411 */         int exist = 0;
/* 412 */         for (; exist < bufpos && 
/* 413 */           bufcols[exist] != col; exist++);
/*     */ 
/*     */ 
/*     */         
/* 417 */         if (exist >= bufpos)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 423 */           for (int j = 0; j < tcs.length; j++) {
/* 424 */             if (tcs[j] == col) {
/* 425 */               bufcols[bufpos] = col;
/* 426 */               bufpos++;
/*     */             } 
/*     */           }  } 
/*     */       } 
/*     */       b++; }
/*     */     
/* 432 */     bufcols = Arrays.<MCColumnConfig>copyOf(bufcols, bufpos);
/*     */     
/* 434 */     this._retcol = bufcols;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReturnColumn(MCColumnConfig col) {
/* 446 */     if (this._retcol != null) {
/* 447 */       for (int i = 0; i < this._retcol.length; i++) {
/* 448 */         if (this._retcol[i] == col) {
/* 449 */           return true;
/*     */         }
/*     */       } 
/*     */     }
/* 453 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCColumnConfig[] getDefaultReturnColumns() {
/* 473 */     return (this._d_retcol != null) ? 
/* 474 */       Arrays.<MCColumnConfig>copyOf(this._d_retcol, this._d_retcol.length) : 
/* 475 */       new MCColumnConfig[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int[] getReturnPositions() {
/* 494 */     MCColumnConfig[] tcs = getAllTableColumns();
/* 495 */     if (this._retpos == null || this._retpos[this._retpos.length - 1] != tcs.length - 1) {
/* 496 */       if (this._retcol == null)
/*     */       {
/* 498 */         addReturnColumn(new MCColumnConfig[0]);
/*     */       }
/*     */ 
/*     */       
/* 502 */       int[] buf = new int[this._retcol.length + 1];
/* 503 */       int buflen = 0; byte b; int j;
/*     */       MCColumnConfig[] arrayOfMCColumnConfig;
/* 505 */       for (j = (arrayOfMCColumnConfig = this._retcol).length, b = 0; b < j; ) { MCColumnConfig col = arrayOfMCColumnConfig[b];
/*     */         
/* 507 */         for (int k = 0; k < tcs.length; k++) {
/* 508 */           if (tcs[k] == col) {
/* 509 */             buf[buflen] = k;
/* 510 */             buflen++;
/*     */           } 
/*     */         } 
/*     */         b++; }
/*     */       
/* 515 */       buf[buflen] = tcs.length - 1;
/* 516 */       buflen++;
/*     */       
/* 518 */       Arrays.sort(buf);
/* 519 */       if (buflen > 1 && buf[buflen - 1] == buf[buflen - 2]) {
/*     */         
/* 521 */         buflen--;
/* 522 */         buf = Arrays.copyOf(buf, buflen);
/*     */       } 
/*     */       
/* 525 */       this._retpos = buf;
/*     */     } 
/*     */ 
/*     */     
/* 529 */     int fixpos = getFixedColumnCount() - 1;
/* 530 */     for (int i = this._retpos.length - 1; i >= 0; i--) {
/* 531 */       if (this._retpos[i] <= fixpos) {
/*     */ 
/*     */ 
/*     */         
/* 535 */         int from = (i == this._retpos.length - 1) ? i : (i + 1);
/* 536 */         return Arrays.copyOfRange(this._retpos, from, this._retpos.length);
/*     */       } 
/*     */     } 
/* 539 */     return Arrays.copyOf(this._retpos, this._retpos.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getReturnCount() {
/* 551 */     if (this._retpos == null) {
/* 552 */       getReturnPositions();
/*     */     }
/*     */ 
/*     */     
/* 556 */     int fixpos = getFixedColumnCount() - 1;
/* 557 */     for (int i = this._retpos.length - 1; i >= 0; i--) {
/* 558 */       if (this._retpos[i] <= fixpos)
/*     */       {
/*     */ 
/*     */         
/* 562 */         return (i == this._retpos.length - 1) ? 1 : (this._retpos.length - i + 1);
/*     */       }
/*     */     } 
/* 565 */     return this._retpos.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int[] getTierColumnIndex(int tier) {
/* 587 */     int[] ret = new int[2];
/* 588 */     int[] retpos = getReturnPositions();
/* 589 */     int fixpos = getFixedColumnCount() - 1;
/* 590 */     ret[0] = (tier <= 0) ? 0 : (retpos[tier - 1] - fixpos);
/* 591 */     ret[1] = retpos[tier] - fixpos;
/* 592 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getFixedColumnCount() {
/* 603 */     return this._table.getFixedColumnTable().getColumnModel().getColumnCount();
/*     */   }
/*     */   
/*     */   private int getIndex(TableColumn c) {
/* 607 */     if (c == null) {
/* 608 */       return -1;
/*     */     }
/*     */     
/* 611 */     for (int i = 0; i < getColumnCount(); i++) {
/* 612 */       if (c == getColumn(i)) {
/* 613 */         return i;
/*     */       }
/*     */     } 
/* 616 */     return -1;
/*     */   }
/*     */   
/*     */   static interface WidthSupplier {
/*     */     long width(MCTableColumn param1MCTableColumn);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCTable2ColumnModel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */