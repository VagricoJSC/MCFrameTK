/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.event.KeyEvent;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.border.Border;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCMode;
/*     */ import mcframe.clientCore.beans.MCResourceBeans;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.action.MCKeyActionManager;
/*     */ import mcframe.clientCore.beans.combobox.AbsMCComboBox;
/*     */ import mcframe.clientCore.beans.combobox.MCCalendarComboBox;
/*     */ import mcframe.clientCore.beans.combobox.MCComboField;
/*     */ import mcframe.clientCore.beans.combobox.MCComboListModel;
/*     */ import mcframe.clientCore.beans.combobox.MCFieldComboBox;
/*     */ import mcframe.clientCore.beans.combobox.MCTimestampComboBox;
/*     */ import mcframe.clientCore.beans.list.MCLinkBeans;
/*     */ import mcframe.clientCore.beans.list.MCLinkedBeans;
/*     */ import mcframe.clientCore.beans.list.MCListConfig;
/*     */ import mcframe.clientCore.beans.list.MCListType;
/*     */ import mcframe.clientCore.beans.popup.MCPopupConfig;
/*     */ import mcframe.clientCore.beans.popup.MCPopupMenu;
/*     */ import mcframe.clientCore.event.MCEventInfo;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCCalendarDate;
/*     */ import mcframe.commonCore.lang.MCTimestamp;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCEditorTimestampComboBox
/*     */   extends MCTimestampComboBox
/*     */   implements MCEditorBeans
/*     */ {
/*  44 */   private MCTable<?> _table = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   private MCColumnConfig _column = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCEditorTimestampComboBox(String name, MCColumnConfig column) {
/*  64 */     super(name);
/*     */     
/*  66 */     setColumnConfig(column);
/*  67 */     setTable(column.getBaseTable());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getType() {
/*  72 */     return "table.column.combo-date";
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initBeans() {
/*  77 */     super.initBeans();
/*     */     
/*  79 */     setFocusTraversalKeysEnabled(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initKeyAssign() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initResource() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setTable(MCTable<?> table) {
/*  98 */     this._table = table;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCTable<?> getTable() {
/* 103 */     return this._table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setColumnConfig(MCColumnConfig column) {
/* 114 */     this._column = column;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCColumnConfig getColumnConfig() {
/* 119 */     return this._column;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getRowIndex() {
/* 124 */     return MCCellUtil.getRowIndex(this);
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCEditorComboField getComboField() {
/* 129 */     return (MCEditorComboField)super.getComboField();
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCEditorComboField createComboField() {
/* 134 */     return new MCEditorComboField();
/*     */   }
/*     */ 
/*     */   
/*     */   public void valueCommited() {
/* 139 */     MCTable<?> t = getTable();
/* 140 */     String o = getListConfig().getOpeType();
/*     */     
/* 142 */     MCTimestamp v = (MCTimestamp)getValue();
/* 143 */     if ("input".equals(o)) {
/* 144 */       setSelectedItem((Comparable)v);
/*     */     }
/* 146 */     else if ("list".equals(o) && 
/* 147 */       v == null) {
/* 148 */       setSelectedItem((Comparable)v);
/*     */     } 
/*     */ 
/*     */     
/* 152 */     MCRow row = getSelectedListRow();
/*     */     
/* 154 */     if ("input".equals(o)) {
/* 155 */       row = getListRow((Comparable)getValue());
/*     */     }
/* 157 */     if (row == null && 
/* 158 */       getListType() == MCListType.FREE) {
/* 159 */       row = MCRow.create();
/* 160 */       MCBeansProxy.PROXY.addColumn(row, getListNames()[0], getDataType(), 
/* 161 */           getViewValue());
/*     */     } 
/*     */     
/* 164 */     MCEventInfo e = getEventInfo();
/* 165 */     String key = getKeyColumnName();
/* 166 */     if (MCBeansProxy.PROXY.haveLinkValuesNull(e, (MCLinkBeans)this, (Comparable<?>)getValue(), getList(), key)) {
/* 167 */       MCRow r = row.clone();
/* 168 */       r.clear();
/* 169 */       r.setValue(key, e.getNewValue());
/* 170 */       ((MCTableColumn)getColumnConfig()).execLink(t.getMCEditingRow(), r, true);
/*     */     } else {
/*     */       
/* 173 */       ((MCTableColumn)getColumnConfig()).execLink(t.getMCEditingRow(), row, true);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Border getDefaultBorder() {
/* 179 */     return MCCellUtil.DEFAULT_BORDER;
/*     */   }
/*     */ 
/*     */   
/*     */   public void transferFocus() {
/* 184 */     MCTable<?> t = getTable();
/* 185 */     t.transferFocus(getRowIndex(), t.getViewColumn(getColumnConfig()) + 1, false, 
/* 186 */         true, true);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void execLink(MCRow row, boolean msg) {
/* 191 */     ((MCTableColumn)getColumnConfig()).execLink(getRowIndex(), row, msg);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canChange() {
/*     */     try {
/* 197 */       MCTable.setEditingStoppedEnabled(false);
/*     */ 
/*     */       
/* 200 */       MCEventInfo info = getTable().getEventInfo();
/* 201 */       MCEventProxy.PROXY.setIndex(info, getTable().getMCSelectedRow(), 
/* 202 */           info.getNewIndex());
/*     */       
/* 204 */       return super.canChange();
/*     */     } finally {
/*     */       
/* 207 */       MCTable.setEditingStoppedEnabled(true);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void setColumnInfo(int index, MCColumnConfig column) {
/* 212 */     setColumnConfig(column);
/* 213 */     MCTable<?> table = getTable();
/*     */     
/* 215 */     MCKeyActionManager.init((MCResourceBeans)this, getInputMap(1), 
/* 216 */         getActionMap());
/* 217 */     JComponent c = getComboField().getComponent();
/* 218 */     MCKeyActionManager.init((MCResourceBeans)this, c.getInputMap(), c.getActionMap());
/*     */     
/* 220 */     MCKeyActionManager.initScreen((MCResourceBeans)this, 
/* 221 */         getInputMap(1), getActionMap());
/* 222 */     MCKeyActionManager.initScreen((MCResourceBeans)this, c.getInputMap(), c.getActionMap());
/*     */     
/* 224 */     MCMode mode = MCCellUtil.isCellEditable(index, column, table);
/* 225 */     setMode(mode);
/* 226 */     setForeground(MCCellUtil.getForeground(index, column, table, false, mode));
/* 227 */     setBackground(MCCellUtil.getBackground(index, column, table, false, mode));
/* 228 */     setFont(column.getFont());
/* 229 */     setCaretColor(MCCellUtil.getCaretColor(index, column, table));
/* 230 */     setSelectionColor(MCCellUtil.getSelectionColor(index, column, table));
/* 231 */     setSelectedTextColor(MCCellUtil.getSelectedTextColor(index, column, table));
/* 232 */     setMeta(column.getMeta());
/* 233 */     setListVisibleColumn(column.getListVisibleColumn());
/* 234 */     setRow(column.getTable().getRow(index), column.getRowColumnName());
/* 235 */     setAutoFocus(column.isAutoFocus());
/* 236 */     setSelectAll(column.isSelectAll());
/* 237 */     MCListConfig lc = column.getListConfig();
/* 238 */     setListConfig(lc);
/* 239 */     setCalendarFormat(MCCellUtil.getTimestampFormat(index, column, table, mode));
/* 240 */     setCalendarValidator(column.getCalendarValidator());
/*     */     
/* 242 */     if (lc.getListType() == MCListType.SELECT_ONLY) {
/* 243 */       setDocumentEditable(false);
/*     */     }
/*     */     
/* 246 */     setComboListConfig(column.getComboListConfig());
/*     */     
/* 248 */     Border border = MCCellUtil.getEditorBorder(index, column, table);
/* 249 */     if (border != null) {
/* 250 */       setBorder(border);
/*     */     } else {
/*     */       
/* 253 */       setBorder(getDefaultBorder());
/*     */     } 
/* 255 */     MCPopupMenu menu = getComponentPopupMenu();
/* 256 */     if (menu != null) {
/* 257 */       menu.updateResource();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Border getBorder() {
/* 263 */     Border b = MCCellUtil.getBorder(this);
/* 264 */     return (b != null) ? b : super.getBorder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCRootPanel getRootPanel() {
/* 276 */     return MCCellUtil.getRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCRootPanel getNearestRootPanel() {
/* 281 */     return MCCellUtil.getNearestRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessageByLocale() {
/* 286 */     return getColumnConfig().getMessageByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLabelByLocale() {
/* 291 */     return getColumnConfig().getLabelByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterRequestFocus() {
/* 296 */     MCRootPanel bp = getBaseRootPanel();
/* 297 */     MCBeansUtil.afterRequestFocus(bp, getTable());
/* 298 */     MCBeansUtil.scrollRectToVisible(bp, (JComponent)this, 
/* 299 */         getComboField().getHorizontalAlignment());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 304 */     repaint();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFocusOwner() {
/* 309 */     MCTable<?> t = getTable();
/* 310 */     return (t != null) ? (t.isRemoveNotifyProcessing() ? super.isFocusOwner() : false) : 
/* 311 */       super.isFocusOwner();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValueChanged() {
/* 316 */     return isValueChanged((Comparable<?>)getRowValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValueChanged(Comparable<?> value) {
/* 321 */     adjustViewValue();
/*     */     try {
/* 323 */       return isValueChanged((Comparable<?>)getValue(), value);
/*     */     }
/* 325 */     catch (MCException mCException) {
/* 326 */       return true;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isValueChanged(Comparable<?> view, Comparable<?> row) {
/* 332 */     return MCCellUtil.isValueChanged(this, view, row);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasFocus() {
/* 337 */     MCTable<?> t = getTable();
/* 338 */     return (t != null) ? ((this == t.getMCEditorComponent())) : super.hasFocus();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isMCFocusOwner() {
/* 343 */     MCTable<?> t = getTable();
/* 344 */     return (t != null) ? ((t.getMCEditorComponent() == this)) : isFocusOwner();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCListType getListType() {
/* 349 */     MCColumnConfig c = getColumnConfig();
/* 350 */     return (c != null) ? c.getListType() : super.getListType();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCLinkedBeans[] getLinkBeans() {
/* 355 */     MCColumnConfig c = getColumnConfig();
/* 356 */     return (c != null) ? c.getLinkBeans() : super.getLinkBeans();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRowToViews() {
/* 361 */     boolean e = MCBeansProxy.PROXY.isEventEnabled();
/*     */     try {
/* 363 */       MCBeansProxy.PROXY.setEventEnabled(false);
/* 364 */       setRowToView();
/* 365 */       MCLinkedBeans[] cs = getLinkBeans(); byte b; int i; MCLinkedBeans[] arrayOfMCLinkedBeans1;
/* 366 */       for (i = (arrayOfMCLinkedBeans1 = cs).length, b = 0; b < i; ) { MCLinkedBeans c = arrayOfMCLinkedBeans1[b];
/* 367 */         if (c instanceof MCColumnConfig) {
/* 368 */           MCColumnConfig col = (MCColumnConfig)c;
/* 369 */           int j = getRowIndex();
/* 370 */           col.setValue(j, 
/* 371 */               getTable().getRow(j).getValue(col.getBaseRowColumnName()));
/*     */         } 
/*     */         b++; }
/*     */     
/*     */     } finally {
/* 376 */       MCBeansProxy.PROXY.setEventEnabled(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCList doListEventEx() {
/* 385 */     MCTableColumn c = (MCTableColumn)getColumnConfig();
/* 386 */     MCEventProxy.PROXY.setEventIndex(c.getEventInfo(), getRowIndex());
/* 387 */     return c.doListEventEx();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCList doListEvent() {
/*     */     try {
/* 393 */       MCColumnConfig c = getColumnConfig();
/* 394 */       MCEventProxy.PROXY.setEventIndex(c.getEventInfo(), getRowIndex());
/* 395 */       return c.doListEvent();
/*     */     }
/* 397 */     catch (MCException e) {
/* 398 */       handle((Throwable)e);
/*     */       
/* 400 */       setRowToViews();
/*     */       
/* 402 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean doListEventWithNull() {
/* 407 */     MCColumnConfig c = getColumnConfig();
/* 408 */     return (c != null) ? c.doListEventWithNull() : false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean haveLinkValuesNullWhenDupliKeyTyped() {
/* 413 */     MCColumnConfig c = getColumnConfig();
/* 414 */     return (c != null) ? c.haveLinkValuesNullWhenDupliKeyTyped() : false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean doVC() {
/* 419 */     return getColumnConfig().doVC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNC() {
/* 424 */     getColumnConfig().doNC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNE() {
/* 429 */     getColumnConfig().doNE();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNX() {
/* 434 */     getColumnConfig().doNX();
/*     */     
/* 436 */     getListConfig().setOpeType("input");
/*     */   }
/*     */ 
/*     */   
/*     */   public void doLC() {
/* 441 */     getColumnConfig().doLC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doDC() {
/* 446 */     getColumnConfig().doDC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void focusGained() {
/* 451 */     setText((MCCalendarDate)getRowValue());
/* 452 */     focusGainedSelect();
/*     */   }
/*     */ 
/*     */   
/*     */   public void focusLost() {
/* 457 */     setText((MCCalendarDate)getRowValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public MCEventInfo getEventInfo() {
/* 462 */     return getColumnConfig().getEventInfo();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource(MCRootPanel panel) {}
/*     */ 
/*     */   
/*     */   public void doCheckValueError() {
/* 475 */     super.doCheckValueError();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCPopupConfig getPopupConfig() {
/* 480 */     MCTable<?> t = getTable();
/* 481 */     return (t != null) ? t.getPopupConfig() : null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCPopupMenu configurePopup(MCPopupMenu menu) {
/* 486 */     MCPopupConfig pc = getPopupConfig();
/* 487 */     return (pc != null) ? 
/* 488 */       pc.configurePopup(menu, getTable(), getRowIndex(), getColumnConfig()) : 
/* 489 */       menu;
/*     */   }
/*     */ 
/*     */   
/*     */   public void processKeyEvent(KeyEvent e) {
/* 494 */     MCCellUtil.beforeKeyEvent(e, this);
/* 495 */     super.processKeyEvent(e);
/*     */   }
/*     */ 
/*     */   
/*     */   public Comparable<?> doListFormat(Comparable<?> value) {
/* 500 */     return getColumnConfig().doListFormat(getRowIndex(), value);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Color getListForeground(MCRow row, boolean selected) {
/* 505 */     MCColumnConfig c = getColumnConfig();
/* 506 */     return getComboListConfig().getRowForeground(c, getRowIndex(), c.getTable(), row, 
/* 507 */         selected);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Color getListBackground(MCRow row, boolean selected) {
/* 512 */     MCColumnConfig c = getColumnConfig();
/* 513 */     return getComboListConfig().getRowBackground(c, getRowIndex(), c.getTable(), row, 
/* 514 */         selected);
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCEditorComboListModel createModel() {
/* 519 */     return new MCEditorComboListModel(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected class MCEditorComboField
/*     */     extends MCTimestampComboBox.MCTimestampComboField
/*     */   {
/*     */     protected MCEditorComboField() {
/* 537 */       super(MCEditorTimestampComboBox.this);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void initBeans() {
/* 542 */       super.initBeans();
/*     */       
/* 544 */       setFocusTraversalKeysEnabled(false);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isRequestFocusEnabled() {
/* 550 */       MCTable<?> t = MCEditorTimestampComboBox.this.getTable();
/* 551 */       if (!t.equalsIgnoreCase(MCBeansUtil.getFocusOwner(t)) && 
/* 552 */         !t.isRequestFocusEnabled()) {
/* 553 */         return false;
/*     */       }
/*     */       
/* 556 */       return super.isRequestFocusEnabled();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isMCRequestFocusEnabled() {
/* 561 */       return MCCellUtil.isFocusable(MCEditorTimestampComboBox.this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected class MCEditorComboListModel
/*     */     extends MCComboListModel<MCTimestamp>
/*     */   {
/*     */     protected MCEditorComboListModel(MCEditorTimestampComboBox compo) {
/* 582 */       super((AbsMCComboBox)compo);
/*     */     }
/*     */ 
/*     */     
/*     */     protected MCEditorTimestampComboBox getComboBox() {
/* 587 */       return (MCEditorTimestampComboBox)super.getComboBox();
/*     */     }
/*     */ 
/*     */     
/*     */     protected int getNewListIndex() {
/* 592 */       MCEditorTimestampComboBox compo = getComboBox();
/* 593 */       int index = compo.getRowIndex();
/* 594 */       MCTableColumn column = (MCTableColumn)compo.getColumnConfig();
/* 595 */       return column.getNewListIndex(index);
/*     */     }
/*     */ 
/*     */     
/*     */     protected int getOldListIndex() {
/* 600 */       MCEditorTimestampComboBox compo = getComboBox();
/* 601 */       int index = compo.getRowIndex();
/* 602 */       MCTableColumn column = (MCTableColumn)compo.getColumnConfig();
/* 603 */       return column.getOldListIndex(index);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void setNewListIndex(int index) {
/* 608 */       MCEditorTimestampComboBox compo = getComboBox();
/* 609 */       int row = compo.getRowIndex();
/* 610 */       MCTableColumn column = (MCTableColumn)compo.getColumnConfig();
/* 611 */       column.setNewListIndex(row, Integer.valueOf(index));
/*     */     }
/*     */ 
/*     */     
/*     */     protected void setOldListIndex(int index) {
/* 616 */       MCEditorTimestampComboBox compo = getComboBox();
/* 617 */       int row = compo.getRowIndex();
/* 618 */       MCTableColumn column = (MCTableColumn)compo.getColumnConfig();
/* 619 */       column.setOldListIndex(row, Integer.valueOf(index));
/*     */     }
/*     */ 
/*     */     
/*     */     protected int getSelectedIndex() {
/* 624 */       MCEditorTimestampComboBox compo = getComboBox();
/* 625 */       int index = compo.getRowIndex();
/* 626 */       MCTableColumn column = (MCTableColumn)compo.getColumnConfig();
/* 627 */       return (column != null) ? column.getSelectedListIndex(index) : 
/* 628 */         super.getSelectedIndex();
/*     */     }
/*     */ 
/*     */     
/*     */     protected void setSelectedIndex(int index) {
/* 633 */       super.setSelectedIndex(index);
/* 634 */       MCEditorTimestampComboBox compo = getComboBox();
/* 635 */       int row = compo.getRowIndex();
/* 636 */       MCTableColumn column = (MCTableColumn)compo.getColumnConfig();
/* 637 */       if (column != null) {
/* 638 */         column.setSelectedListIndex(row, Integer.valueOf(index));
/*     */       } else {
/*     */         
/* 641 */         super.setSelectedIndex(index);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCEditorTimestampComboBox.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */