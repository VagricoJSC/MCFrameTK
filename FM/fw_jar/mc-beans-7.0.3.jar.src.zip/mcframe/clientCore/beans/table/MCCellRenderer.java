/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.font.FontRenderContext;
/*     */ import java.awt.font.GlyphMetrics;
/*     */ import java.awt.font.GlyphVector;
/*     */ import java.awt.geom.Point2D;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.table.DefaultTableCellRenderer;
/*     */ import mcframe.clientCore.beans.MCMode;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MCCellRenderer
/*     */   extends DefaultTableCellRenderer
/*     */ {
/*     */   private final MCColumnConfig _column;
/*  43 */   private Border _default_border = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   private int _idx = 0;
/*     */   
/*  54 */   protected MCMode _mode = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCCellRenderer(MCColumnConfig column) {
/*  64 */     setDoubleBuffered(true);
/*  65 */     this._column = column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCColumnConfig getColumnConfig() {
/*  76 */     return this._column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setDefaultBorder(Border border) {
/*  88 */     this._default_border = border;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Border getDefaultBorder() {
/* 104 */     return this._default_border;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Component getTableCellRendererComponent(JTable table, Object value, boolean selected, boolean focused, int index, int column) {
/* 123 */     MCTable<?> t = (MCTable)table;
/* 124 */     boolean f = focused ? focused : MCCellUtil.hasFocus(t, index, column);
/* 125 */     return getRenderer(t, value, selected, f, index, getColumnConfig());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Component getRenderer(MCTable<?> table, Object value, boolean selected, boolean focused, int index, MCColumnConfig column) {
/* 143 */     int horizontal = column.getHorizontalAlignment();
/* 144 */     if (horizontal == -1) {
/* 145 */       horizontal = 2;
/*     */     }
/* 147 */     setHorizontalAlignment(horizontal);
/* 148 */     Border def_border = getDefaultBorder();
/* 149 */     if (def_border == null) {
/* 150 */       setDefaultBorder(getBorder());
/*     */     }
/* 152 */     MCCellUtil.initRenderer(this, index, column, table, selected, focused, 
/* 153 */         getDefaultBorder());
/* 154 */     setValue(value);
/* 155 */     Color bg = getBackground();
/* 156 */     setOpaque(!(bg != null && bg.equals(table.getBackground()) && table.isOpaque()));
/* 157 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void paintComponent(Graphics g) {
/* 162 */     String str = getText();
/* 163 */     Graphics2D g2 = (Graphics2D)g;
/* 164 */     FontRenderContext frc = g2.getFontRenderContext();
/* 165 */     if (!getColumnConfig().isTurnDownText() || !isTurnDownText(str, getFont(), frc)) {
/* 166 */       super.paintComponent(g);
/*     */       return;
/*     */     } 
/* 169 */     setText("");
/* 170 */     super.paintComponent(g);
/* 171 */     setText(str);
/* 172 */     GlyphVector gvtext = null;
/* 173 */     int WRAPPING_WIDTH = getWidth() - (getInsets()).left - (getInsets()).right;
/* 174 */     gvtext = getWrappedGlyphVector(str, WRAPPING_WIDTH, getFont(), frc);
/* 175 */     g2.drawGlyphVector(gvtext, (getInsets()).left, (
/* 176 */         (getInsets()).top + getFont().getSize()));
/*     */   }
/*     */ 
/*     */   
/*     */   private GlyphVector getWrappedGlyphVector(String str, float Wrapping, Font font, FontRenderContext frc) {
/* 181 */     Point2D gmPos = new Point2D.Double(0.0D, 0.0D);
/* 182 */     GlyphVector gv = font.createGlyphVector(frc, str);
/* 183 */     double lineheight = gv.getLogicalBounds().getHeight();
/* 184 */     float xpos = 0.0F;
/* 185 */     float advance = 0.0F;
/* 186 */     int lineCount = 0;
/*     */     
/* 188 */     for (int i = 0; i < gv.getNumGlyphs(); i++) {
/* 189 */       GlyphMetrics gm = gv.getGlyphMetrics(i);
/* 190 */       advance = gm.getAdvance();
/* 191 */       if (xpos < Wrapping && Wrapping <= xpos + advance) {
/* 192 */         lineCount++;
/* 193 */         xpos = 0.0F;
/*     */       } 
/* 195 */       gmPos.setLocation(xpos, lineheight * lineCount);
/* 196 */       gv.setGlyphPosition(i, gmPos);
/* 197 */       xpos += advance;
/*     */     } 
/* 199 */     return gv;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean isTurnDownText(String str, Font font, FontRenderContext frc) {
/* 216 */     Point2D gmPos = new Point2D.Double(0.0D, 0.0D);
/* 217 */     GlyphVector gv = font.createGlyphVector(frc, str);
/* 218 */     double lineheight = gv.getLogicalBounds().getHeight();
/* 219 */     float xpos = 0.0F;
/* 220 */     float advance = 0.0F;
/* 221 */     int lineCount = 0;
/*     */     
/* 223 */     for (int i = 0; i < gv.getNumGlyphs(); i++) {
/* 224 */       GlyphMetrics gm = gv.getGlyphMetrics(i);
/* 225 */       advance = gm.getAdvance();
/* 226 */       gmPos.setLocation(xpos, lineheight * lineCount);
/* 227 */       gv.setGlyphPosition(i, gmPos);
/* 228 */       xpos += advance;
/*     */     } 
/*     */     
/* 231 */     if (getWidth() >= xpos + advance) {
/* 232 */       return false;
/*     */     }
/* 234 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setValue(Object value) {
/* 239 */     super.setValue(value);
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getRowIndex() {
/* 244 */     return this._idx;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setRowIndex(int index) {
/* 249 */     this._idx = index;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCCellRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */