/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.util.Iterator;
/*     */ import javax.swing.plaf.TableHeaderUI;
/*     */ import javax.swing.table.JTableHeader;
/*     */ import javax.swing.table.TableCellRenderer;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import mcframe.clientCore.beans.layout.MCHiresoManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCLayoutTableHeader
/*     */   extends JTableHeader
/*     */ {
/*     */   private static final String uiClassID = "MCLayoutTableHeaderUI";
/*     */   
/*     */   public MCLayoutTableHeader(MCLayoutTableColumnModel model) {
/*  43 */     super(model);
/*  44 */     setReorderingAllowed(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCTable<?> getMCTable() {
/*  58 */     return (MCTable)getTable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCHeaderRendererCommon getHeaderRenderer(MCTableColumn col) {
/*  74 */     TableCellRenderer renderer = col.getHeaderRenderer();
/*  75 */     if (renderer == null)
/*     */     {
/*  77 */       renderer = getDefaultRenderer();
/*     */     }
/*  79 */     return (MCHeaderRendererCommon)renderer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getColumnHeight(MCTableColumn col) {
/*  94 */     MCHeaderRendererCommon renderer = getHeaderRenderer(col);
/*  95 */     Component comp = renderer.getTableCellRendererComponent(
/*  96 */         getMCTable(), 
/*  97 */         (Comparable)col.getHeaderValue(), 
/*  98 */         false, false, -1, -1, col);
/*  99 */     return (comp.getPreferredSize()).height;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUIClassID() {
/* 105 */     return "MCLayoutTableHeaderUI";
/*     */   }
/*     */ 
/*     */   
/*     */   public MCLayoutTableHeaderUI getUI() {
/* 110 */     return (MCLayoutTableHeaderUI)this.ui;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setReorderingAllowed(boolean b) {
/* 116 */     this.reorderingAllowed = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCLayoutTableColumnModel getColumnModel() {
/* 121 */     return (MCLayoutTableColumnModel)super.getColumnModel();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getToolTipText(MouseEvent event) {
/* 134 */     String tip = null;
/* 135 */     Point p = event.getPoint();
/*     */     
/*     */     int column;
/* 138 */     if ((column = columnAtPoint(p)) != -1) {
/* 139 */       MCColumnConfig aColumn = 
/* 140 */         (MCColumnConfig)this.columnModel.getColumn(column);
/* 141 */       if (aColumn.isToolTipEnabled()) {
/* 142 */         tip = aColumn.getMessageByLocale();
/*     */       }
/*     */     } 
/*     */     
/* 146 */     if (tip == null) {
/* 147 */       tip = getToolTipText();
/*     */     }
/*     */ 
/*     */     
/* 151 */     tip = MCHiresoManager.getToolTipText(this, tip);
/*     */     
/* 153 */     return tip;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int columnAtPoint(Point point) {
/* 164 */     int x = 0;
/* 165 */     int pos = 0;
/* 166 */     int height = getHeight();
/*     */     
/* 168 */     MCLayoutTableColumnModel cm = getColumnModel();
/* 169 */     Iterator<MCColumnLayoutMember> iterator = 
/* 170 */       cm.createLayoutMemberIterator();
/* 171 */     while (iterator.hasNext()) {
/* 172 */       MCColumnLayoutMember member = iterator.next();
/* 173 */       if (member instanceof MCColumnLayout) {
/* 174 */         MCColumnLayout l = (MCColumnLayout)member;
/* 175 */         int lw = l.getWidth();
/* 176 */         if (x + lw > point.x) {
/*     */           
/* 178 */           Point p = point.getLocation();
/* 179 */           p.x -= x;
/* 180 */           pos += l.headerColumnAtPoint(p, height);
/*     */           break;
/*     */         } 
/* 183 */         x += lw;
/* 184 */         pos += l.getAllColumnCount(); continue;
/*     */       } 
/* 186 */       if (member instanceof MCTableColumn) {
/* 187 */         x += ((MCTableColumn)member).getWidth();
/* 188 */         if (x > point.x) {
/*     */           break;
/*     */         }
/*     */ 
/*     */         
/* 193 */         pos++;
/*     */       } 
/*     */     } 
/*     */     
/* 197 */     return (cm.getColumnCount() > pos) ? pos : -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Rectangle getHeaderRect(int column) {
/* 208 */     Rectangle r = new Rectangle();
/* 209 */     MCLayoutTableColumnModel cm = getColumnModel();
/*     */     
/* 211 */     r.height = getHeight();
/*     */     
/* 213 */     if (column >= 0)
/*     */     {
/* 215 */       if (column >= cm.getColumnCount()) {
/* 216 */         r.x = getWidth();
/*     */       } else {
/*     */         
/* 219 */         MCTableColumn c = cm.getColumn(column);
/* 220 */         Iterator<MCColumnLayoutMember> iterator = 
/* 221 */           cm.createLayoutMemberIterator();
/* 222 */         while (iterator.hasNext()) {
/* 223 */           MCColumnLayoutMember member = iterator.next();
/* 224 */           if (member instanceof MCColumnLayout) {
/* 225 */             MCColumnLayout l = (MCColumnLayout)member;
/* 226 */             r.width = l.getWidth();
/* 227 */             if (l.contains(c)) {
/* 228 */               r = l.getHeaderRect(r, c);
/*     */               break;
/*     */             } 
/* 231 */             r.x += r.width; continue;
/*     */           } 
/* 233 */           if (member instanceof MCTableColumn) {
/* 234 */             r.width = ((MCTableColumn)member).getWidth();
/* 235 */             if (member == c) {
/*     */               break;
/*     */             }
/* 238 */             r.x += r.width;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/* 243 */     return r;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCLayoutTableHeader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */