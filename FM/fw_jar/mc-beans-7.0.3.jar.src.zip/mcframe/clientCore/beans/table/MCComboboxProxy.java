/*    */ package mcframe.clientCore.beans.table;
/*    */ 
/*    */ import mcframe.clientCore.beans.combobox.AbsMCComboBox;
/*    */ import mcframe.clientCore.beans.combobox.AbsMCPackageProxy;
/*    */ 
/*    */ class MCComboboxProxy
/*    */   extends AbsMCPackageProxy {
/*  8 */   static final MCComboboxProxy PROXY = new MCComboboxProxy();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void adjustIconSize(AbsMCComboBox c, int ratio) {
/* 15 */     super.adjustIconSize(c, ratio);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCComboboxProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */