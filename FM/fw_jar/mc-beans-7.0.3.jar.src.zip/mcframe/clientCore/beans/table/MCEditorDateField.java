/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.event.KeyEvent;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.border.Border;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCDateField;
/*     */ import mcframe.clientCore.beans.MCMode;
/*     */ import mcframe.clientCore.beans.MCModeBeans;
/*     */ import mcframe.clientCore.beans.MCResourceBeans;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.action.MCKeyActionManager;
/*     */ import mcframe.clientCore.beans.list.MCLinkedBeans;
/*     */ import mcframe.clientCore.beans.list.MCListType;
/*     */ import mcframe.clientCore.beans.popup.MCPopupConfig;
/*     */ import mcframe.clientCore.beans.popup.MCPopupMenu;
/*     */ import mcframe.clientCore.event.MCEventInfo;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCCalendarDate;
/*     */ import mcframe.commonCore.lang.MCDate;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCEditorDateField
/*     */   extends MCDateField
/*     */   implements MCEditorBeans
/*     */ {
/*     */   private static final String TYPE = "table.column.date";
/*     */   private MCColumnConfig _column;
/*     */   private MCTable<?> _table;
/*     */   
/*     */   protected MCEditorDateField(String name, MCColumnConfig column) {
/*  69 */     super(name);
/*  70 */     setColumnConfig(column);
/*  71 */     setTable(column.getBaseTable());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getType() {
/*  76 */     return "table.column.date";
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initBeans() {
/*  81 */     super.initBeans();
/*     */     
/*  83 */     setFocusTraversalKeysEnabled(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initKeyAssign() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initResource() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setColumnConfig(MCColumnConfig column) {
/* 114 */     this._column = column;
/*     */   }
/*     */ 
/*     */   
/*     */   public final MCColumnConfig getColumnConfig() {
/* 119 */     return this._column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setTable(MCTable<?> table) {
/* 130 */     this._table = table;
/*     */   }
/*     */ 
/*     */   
/*     */   public final MCTable getTable() {
/* 135 */     return this._table;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getRowIndex() {
/* 141 */     return MCCellUtil.getRowIndex(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void transferFocus() {
/* 147 */     if (isAmPmField() && MCMode.isEnable((MCModeBeans)this) && 
/* 148 */       !MCStringUtil.isNull(getText()) && isValueChanged() && !isShowingAmPmComboList()) {
/* 149 */       showOrChangeAmPm();
/*     */       
/*     */       return;
/*     */     } 
/* 153 */     MCTable<?> t = getTable();
/* 154 */     t.transferFocus(getRowIndex(), t.getViewColumn(getColumnConfig()) + 1, false, 
/* 155 */         true, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public Border getDefaultBorder() {
/* 160 */     return MCCellUtil.DEFAULT_BORDER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setColumnInfo(int index, MCColumnConfig column) {
/* 172 */     setColumnConfig(column);
/* 173 */     MCTable<?> table = getTable();
/* 174 */     MCKeyActionManager.init((MCResourceBeans)this, getInputMap(), getActionMap());
/* 175 */     MCKeyActionManager.initScreen((MCResourceBeans)this, getInputMap(), getActionMap());
/* 176 */     MCMode mode = MCCellUtil.isCellEditable(index, column, table);
/* 177 */     setMode(mode);
/* 178 */     setForeground(MCCellUtil.getForeground(index, column, table, false, mode));
/* 179 */     setBackground(MCCellUtil.getBackground(index, column, table, false, mode));
/* 180 */     setFont(column.getFont());
/* 181 */     setCaretColor(MCCellUtil.getCaretColor(index, column, table));
/* 182 */     setSelectionColor(MCCellUtil.getSelectionColor(index, column, table));
/* 183 */     setSelectedTextColor(MCCellUtil.getSelectedTextColor(index, column, table));
/* 184 */     setMeta(column.getMeta());
/* 185 */     setAutoFocus(column.isAutoFocus());
/* 186 */     setSelectAll(column.isSelectAll());
/* 187 */     setListConfig(column.getListConfig());
/* 188 */     setCalendarFormat(MCCellUtil.getDateFormat(index, column, table, mode));
/*     */     
/* 190 */     setCalendarValidator(column.getCalendarValidator());
/* 191 */     setRow(column.getTable().getRow(index), column.getRowColumnName());
/*     */     
/* 193 */     Border border = MCCellUtil.getEditorBorder(index, column, table);
/* 194 */     if (border != null) {
/* 195 */       setBorder(border);
/*     */     } else {
/*     */       
/* 198 */       setBorder(getDefaultBorder());
/*     */     } 
/* 200 */     setListListener(column.getListListener());
/* 201 */     MCPopupMenu menu = getComponentPopupMenu();
/* 202 */     if (menu != null) {
/* 203 */       menu.updateResource();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public MCLinkedBeans[] getLinkBeans() {
/* 209 */     MCColumnConfig c = getColumnConfig();
/* 210 */     return (c != null) ? c.getLinkBeans() : super.getLinkBeans();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCRootPanel getRootPanel() {
/* 215 */     return MCCellUtil.getRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCRootPanel getNearestRootPanel() {
/* 220 */     return MCCellUtil.getNearestRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessageByLocale() {
/* 225 */     return getColumnConfig().getMessageByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLabelByLocale() {
/* 230 */     return getColumnConfig().getLabelByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterRequestFocus() {
/* 235 */     MCRootPanel bp = getBaseRootPanel();
/* 236 */     MCBeansUtil.afterRequestFocus(bp, getTable());
/* 237 */     MCBeansUtil.scrollRectToVisible(bp, (JComponent)this, getHorizontalAlignment());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 242 */     repaint();
/*     */   }
/*     */ 
/*     */   
/*     */   public void commitValue() {
/* 247 */     getColumnConfig().setValue(getRowIndex(), (Comparable<?>)getViewValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFocusOwner() {
/* 252 */     MCTable<?> t = getTable();
/* 253 */     return (t != null) ? (t.isRemoveNotifyProcessing() ? super.isFocusOwner() : false) : 
/* 254 */       super.isFocusOwner();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValueChanged() {
/* 259 */     return isValueChanged((Comparable<?>)getRowValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValueChanged(Comparable<?> value) {
/* 273 */     adjustViewValue();
/*     */     try {
/* 275 */       return isValueChanged((Comparable<?>)getValue(), value);
/*     */     }
/* 277 */     catch (MCException mCException) {
/* 278 */       return true;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isValueChanged(Comparable<?> view, Comparable<?> row) {
/* 284 */     return MCCellUtil.isValueChanged(this, view, row);
/*     */   }
/*     */ 
/*     */   
/*     */   public void valueCommited() {
/* 289 */     MCRow row = null;
/* 290 */     if ("input".equals(getListConfig().getOpeType())) {
/* 291 */       MCList<?> l = getList();
/* 292 */       if (l != null) {
/* 293 */         MCRow[] a = l.toArray();
/* 294 */         MCDate v = (MCDate)getValue();
/* 295 */         String n = getListNames()[0]; byte b; int i; MCRow[] arrayOfMCRow1;
/* 296 */         for (i = (arrayOfMCRow1 = a).length, b = 0; b < i; ) { MCRow r = arrayOfMCRow1[b];
/* 297 */           MCDate val = r.getDate(n);
/* 298 */           if (val != null && val.eq((MCCalendarDate)v, new mcframe.commonCore.lang.MCDateFieldType[0])) {
/* 299 */             row = r; break;
/*     */           } 
/*     */           b++; }
/*     */       
/*     */       } 
/*     */     } 
/* 305 */     if (row == null && 
/* 306 */       getListType() == MCListType.FREE) {
/* 307 */       row = MCRow.create();
/* 308 */       MCBeansProxy.PROXY.addColumn(row, getListNames()[0], getDataType(), 
/* 309 */           (Comparable<?>)getViewValue());
/*     */     } 
/*     */     
/* 312 */     ((MCTableColumn)getColumnConfig()).execLink(getTable().getMCEditingRow(), row, 
/* 313 */         true);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isMCFocusOwner() {
/* 318 */     MCTable<?> t = getTable();
/* 319 */     return (t != null) ? ((t.getMCEditorComponent() == this)) : isFocusOwner();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCList doListEvent() {
/* 324 */     return getColumnConfig().doListEvent();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doDC() {
/* 329 */     super.doDC();
/* 330 */     getColumnConfig().doDC();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean doVC() {
/* 335 */     return getColumnConfig().doVC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNC() {
/* 340 */     getColumnConfig().doNC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNE() {
/* 345 */     getColumnConfig().doNE();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNX() {
/* 350 */     getColumnConfig().doNX();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doLC() {
/* 355 */     getColumnConfig().doLC();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCEventInfo getEventInfo() {
/* 360 */     return getColumnConfig().getEventInfo();
/*     */   }
/*     */ 
/*     */   
/*     */   public void focusGained() {
/* 365 */     setText((MCCalendarDate)getRowValue());
/* 366 */     focusGainedSelect();
/* 367 */     showCalenderIfFocusGained();
/* 368 */     this._suppressCalenderMPEvent = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void focusLost() {
/* 373 */     hideCalenderIfFocusLost();
/* 374 */     setText((MCCalendarDate)getRowValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRequestFocusEnabled() {
/* 379 */     return (MCCellUtil.isRequestFocusEnabled(this) && super.isRequestFocusEnabled());
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isMCRequestFocusEnabled() {
/* 384 */     return MCCellUtil.isFocusable(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public Border getBorder() {
/* 389 */     Border b = MCCellUtil.getBorder(this);
/* 390 */     return (b != null) ? b : super.getBorder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource(MCRootPanel panel) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doCheckValueError() {
/* 415 */     super.doCheckValueError();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCalendarEnabled() {
/* 420 */     return getColumnConfig().isCalendarEnabled();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean requestCommit() {
/* 425 */     if (!isValueChanged()) {
/* 426 */       return true;
/*     */     }
/* 428 */     MCTable<?> t = getTable();
/* 429 */     if (t.canChange()) {
/* 430 */       t.commitValue();
/* 431 */       return true;
/*     */     } 
/* 433 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCPopupConfig getPopupConfig() {
/* 438 */     MCTable<?> t = getTable();
/* 439 */     return (t != null) ? t.getPopupConfig() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCPopupMenu configurePopup(MCPopupMenu menu) {
/* 453 */     MCPopupConfig pc = getPopupConfig();
/* 454 */     return (pc != null) ? 
/* 455 */       pc.configurePopup(menu, getTable(), getRowIndex(), getColumnConfig()) : 
/* 456 */       menu;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void processKeyEvent(KeyEvent e) {
/* 461 */     MCCellUtil.beforeKeyEvent(e, this);
/* 462 */     super.processKeyEvent(e);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCDate getInitCalendarFocus() {
/* 467 */     MCDate v = MCCellUtil.getInitDateCalendarFocus(getRowIndex(), getColumnConfig(), 
/* 468 */         getTable());
/* 469 */     return (v != null) ? v : today();
/*     */   }
/*     */ 
/*     */   
/*     */   public Comparable<?> doListFormat(Comparable<?> value) {
/* 474 */     return getColumnConfig().doListFormat(getRowIndex(), value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getCalendarPanelID() {
/* 479 */     return MCCellUtil.getCalendarPanelID(getRowIndex(), getColumnConfig(), 
/* 480 */         getTable());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void execLink(MCRow row, boolean msg) {
/* 485 */     ((MCTableColumn)getColumnConfig()).execLink(getRowIndex(), row, msg);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCEditorDateField.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */