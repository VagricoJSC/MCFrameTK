/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.event.KeyEvent;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.border.Border;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCMode;
/*     */ import mcframe.clientCore.beans.MCResourceBeans;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.action.MCKeyActionManager;
/*     */ import mcframe.clientCore.beans.combobox.AbsMCComboBox;
/*     */ import mcframe.clientCore.beans.combobox.MCCalendarComboBox;
/*     */ import mcframe.clientCore.beans.combobox.MCComboField;
/*     */ import mcframe.clientCore.beans.combobox.MCComboListModel;
/*     */ import mcframe.clientCore.beans.combobox.MCDateComboBox;
/*     */ import mcframe.clientCore.beans.combobox.MCFieldComboBox;
/*     */ import mcframe.clientCore.beans.list.MCLinkBeans;
/*     */ import mcframe.clientCore.beans.list.MCLinkedBeans;
/*     */ import mcframe.clientCore.beans.list.MCListConfig;
/*     */ import mcframe.clientCore.beans.list.MCListType;
/*     */ import mcframe.clientCore.beans.popup.MCPopupConfig;
/*     */ import mcframe.clientCore.beans.popup.MCPopupMenu;
/*     */ import mcframe.clientCore.event.MCEventInfo;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCCalendarDate;
/*     */ import mcframe.commonCore.lang.MCDate;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCEditorDateComboBox
/*     */   extends MCDateComboBox
/*     */   implements MCEditorBeans
/*     */ {
/*  43 */   private MCTable<?> _table = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   private MCColumnConfig _column = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCEditorDateComboBox(String name, MCColumnConfig column) {
/*  63 */     super(name);
/*     */     
/*  65 */     setColumnConfig(column);
/*  66 */     setTable(column.getBaseTable());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getType() {
/*  71 */     return "table.column.combo-date";
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initBeans() {
/*  76 */     super.initBeans();
/*     */     
/*  78 */     setFocusTraversalKeysEnabled(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initKeyAssign() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initResource() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setTable(MCTable<?> table) {
/*  97 */     this._table = table;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCTable<?> getTable() {
/* 102 */     return this._table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setColumnConfig(MCColumnConfig column) {
/* 113 */     this._column = column;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCColumnConfig getColumnConfig() {
/* 118 */     return this._column;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getRowIndex() {
/* 123 */     return MCCellUtil.getRowIndex(this);
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCEditorComboField getComboField() {
/* 128 */     return (MCEditorComboField)super.getComboField();
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCEditorComboField createComboField() {
/* 133 */     return new MCEditorComboField();
/*     */   }
/*     */ 
/*     */   
/*     */   public void valueCommited() {
/* 138 */     MCTable<?> t = getTable();
/* 139 */     String o = getListConfig().getOpeType();
/*     */     
/* 141 */     MCDate v = (MCDate)getValue();
/* 142 */     if ("input".equals(o)) {
/* 143 */       setSelectedItem((Comparable)v);
/*     */     }
/* 145 */     else if ("list".equals(o) && 
/* 146 */       v == null) {
/* 147 */       setSelectedItem((Comparable)v);
/*     */     } 
/*     */ 
/*     */     
/* 151 */     MCRow row = getSelectedListRow();
/*     */     
/* 153 */     if ("input".equals(o)) {
/* 154 */       row = getListRow((Comparable)getValue());
/*     */     }
/* 156 */     if (row == null && 
/* 157 */       getListType() == MCListType.FREE) {
/* 158 */       row = MCRow.create();
/* 159 */       MCBeansProxy.PROXY.addColumn(row, getListNames()[0], getDataType(), 
/* 160 */           getViewValue());
/*     */     } 
/*     */     
/* 163 */     MCEventInfo e = getEventInfo();
/* 164 */     String key = getKeyColumnName();
/* 165 */     if (MCBeansProxy.PROXY.haveLinkValuesNull(e, (MCLinkBeans)this, (Comparable<?>)getValue(), getList(), key)) {
/* 166 */       MCRow r = row.clone();
/* 167 */       r.clear();
/* 168 */       r.setValue(key, e.getNewValue());
/* 169 */       ((MCTableColumn)getColumnConfig()).execLink(t.getMCEditingRow(), r, true);
/*     */     } else {
/*     */       
/* 172 */       ((MCTableColumn)getColumnConfig()).execLink(t.getMCEditingRow(), row, true);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Border getDefaultBorder() {
/* 178 */     return MCCellUtil.DEFAULT_BORDER;
/*     */   }
/*     */ 
/*     */   
/*     */   public void transferFocus() {
/* 183 */     MCTable<?> t = getTable();
/* 184 */     t.transferFocus(getRowIndex(), t.getViewColumn(getColumnConfig()) + 1, false, 
/* 185 */         true, true);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void execLink(MCRow row, boolean msg) {
/* 190 */     ((MCTableColumn)getColumnConfig()).execLink(getRowIndex(), row, msg);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canChange() {
/*     */     try {
/* 196 */       MCTable.setEditingStoppedEnabled(false);
/*     */ 
/*     */       
/* 199 */       MCEventInfo info = getTable().getEventInfo();
/* 200 */       MCEventProxy.PROXY.setIndex(info, getTable().getMCSelectedRow(), 
/* 201 */           info.getNewIndex());
/*     */       
/* 203 */       return super.canChange();
/*     */     } finally {
/*     */       
/* 206 */       MCTable.setEditingStoppedEnabled(true);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void setColumnInfo(int index, MCColumnConfig column) {
/* 211 */     setColumnConfig(column);
/* 212 */     MCTable<?> table = getTable();
/*     */     
/* 214 */     MCKeyActionManager.init((MCResourceBeans)this, getInputMap(1), 
/* 215 */         getActionMap());
/* 216 */     JComponent c = getComboField().getComponent();
/* 217 */     MCKeyActionManager.init((MCResourceBeans)this, c.getInputMap(), c.getActionMap());
/*     */     
/* 219 */     MCKeyActionManager.initScreen((MCResourceBeans)this, 
/* 220 */         getInputMap(1), getActionMap());
/* 221 */     MCKeyActionManager.initScreen((MCResourceBeans)this, c.getInputMap(), c.getActionMap());
/*     */     
/* 223 */     MCMode mode = MCCellUtil.isCellEditable(index, column, table);
/* 224 */     setMode(mode);
/* 225 */     setForeground(MCCellUtil.getForeground(index, column, table, false, mode));
/* 226 */     setBackground(MCCellUtil.getBackground(index, column, table, false, mode));
/* 227 */     setFont(column.getFont());
/* 228 */     setCaretColor(MCCellUtil.getCaretColor(index, column, table));
/* 229 */     setSelectionColor(MCCellUtil.getSelectionColor(index, column, table));
/* 230 */     setSelectedTextColor(MCCellUtil.getSelectedTextColor(index, column, table));
/* 231 */     setMeta(column.getMeta());
/* 232 */     setListVisibleColumn(column.getListVisibleColumn());
/* 233 */     setRow(column.getTable().getRow(index), column.getRowColumnName());
/* 234 */     setAutoFocus(column.isAutoFocus());
/* 235 */     setSelectAll(column.isSelectAll());
/* 236 */     MCListConfig lc = column.getListConfig();
/* 237 */     setListConfig(lc);
/* 238 */     setCalendarFormat(MCCellUtil.getDateFormat(index, column, table, mode));
/* 239 */     setCalendarValidator(column.getCalendarValidator());
/*     */     
/* 241 */     if (lc.getListType() == MCListType.SELECT_ONLY) {
/* 242 */       setDocumentEditable(false);
/*     */     }
/*     */     
/* 245 */     setComboListConfig(column.getComboListConfig());
/*     */     
/* 247 */     Border border = MCCellUtil.getEditorBorder(index, column, table);
/* 248 */     if (border != null) {
/* 249 */       setBorder(border);
/*     */     } else {
/*     */       
/* 252 */       setBorder(getDefaultBorder());
/*     */     } 
/* 254 */     MCPopupMenu menu = getComponentPopupMenu();
/* 255 */     if (menu != null) {
/* 256 */       menu.updateResource();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Border getBorder() {
/* 262 */     Border b = MCCellUtil.getBorder(this);
/* 263 */     return (b != null) ? b : super.getBorder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCRootPanel getRootPanel() {
/* 275 */     return MCCellUtil.getRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCRootPanel getNearestRootPanel() {
/* 280 */     return MCCellUtil.getNearestRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessageByLocale() {
/* 285 */     return getColumnConfig().getMessageByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLabelByLocale() {
/* 290 */     return getColumnConfig().getLabelByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterRequestFocus() {
/* 295 */     MCRootPanel bp = getBaseRootPanel();
/* 296 */     MCBeansUtil.afterRequestFocus(bp, getTable());
/* 297 */     MCBeansUtil.scrollRectToVisible(bp, (JComponent)this, 
/* 298 */         getComboField().getHorizontalAlignment());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 303 */     repaint();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFocusOwner() {
/* 308 */     MCTable<?> t = getTable();
/* 309 */     return (t != null) ? (t.isRemoveNotifyProcessing() ? super.isFocusOwner() : false) : 
/* 310 */       super.isFocusOwner();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValueChanged() {
/* 315 */     return isValueChanged((Comparable<?>)getRowValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValueChanged(Comparable<?> value) {
/* 320 */     adjustViewValue();
/*     */     try {
/* 322 */       return isValueChanged((Comparable<?>)getValue(), value);
/*     */     }
/* 324 */     catch (MCException mCException) {
/* 325 */       return true;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isValueChanged(Comparable<?> view, Comparable<?> row) {
/* 331 */     return MCCellUtil.isValueChanged(this, view, row);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasFocus() {
/* 336 */     MCTable<?> t = getTable();
/* 337 */     return (t != null) ? ((this == t.getMCEditorComponent())) : super.hasFocus();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isMCFocusOwner() {
/* 342 */     MCTable<?> t = getTable();
/* 343 */     return (t != null) ? ((t.getMCEditorComponent() == this)) : isFocusOwner();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCListType getListType() {
/* 348 */     MCColumnConfig c = getColumnConfig();
/* 349 */     return (c != null) ? c.getListType() : super.getListType();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCLinkedBeans[] getLinkBeans() {
/* 354 */     MCColumnConfig c = getColumnConfig();
/* 355 */     return (c != null) ? c.getLinkBeans() : super.getLinkBeans();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRowToViews() {
/* 360 */     boolean e = MCBeansProxy.PROXY.isEventEnabled();
/*     */     try {
/* 362 */       MCBeansProxy.PROXY.setEventEnabled(false);
/* 363 */       setRowToView();
/* 364 */       MCLinkedBeans[] cs = getLinkBeans(); byte b; int i; MCLinkedBeans[] arrayOfMCLinkedBeans1;
/* 365 */       for (i = (arrayOfMCLinkedBeans1 = cs).length, b = 0; b < i; ) { MCLinkedBeans c = arrayOfMCLinkedBeans1[b];
/* 366 */         if (c instanceof MCColumnConfig) {
/* 367 */           MCColumnConfig col = (MCColumnConfig)c;
/* 368 */           int j = getRowIndex();
/* 369 */           col.setValue(j, 
/* 370 */               getTable().getRow(j).getValue(col.getBaseRowColumnName()));
/*     */         } 
/*     */         b++; }
/*     */     
/*     */     } finally {
/* 375 */       MCBeansProxy.PROXY.setEventEnabled(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCList doListEventEx() {
/* 384 */     MCTableColumn c = (MCTableColumn)getColumnConfig();
/* 385 */     MCEventProxy.PROXY.setEventIndex(c.getEventInfo(), getRowIndex());
/* 386 */     return c.doListEventEx();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCList doListEvent() {
/*     */     try {
/* 392 */       MCColumnConfig c = getColumnConfig();
/* 393 */       MCEventProxy.PROXY.setEventIndex(c.getEventInfo(), getRowIndex());
/* 394 */       return c.doListEvent();
/*     */     }
/* 396 */     catch (MCException e) {
/* 397 */       handle((Throwable)e);
/*     */       
/* 399 */       setRowToViews();
/*     */       
/* 401 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean doListEventWithNull() {
/* 406 */     MCColumnConfig c = getColumnConfig();
/* 407 */     return (c != null) ? c.doListEventWithNull() : false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean haveLinkValuesNullWhenDupliKeyTyped() {
/* 412 */     MCColumnConfig c = getColumnConfig();
/* 413 */     return (c != null) ? c.haveLinkValuesNullWhenDupliKeyTyped() : false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean doVC() {
/* 418 */     return getColumnConfig().doVC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNC() {
/* 423 */     getColumnConfig().doNC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNE() {
/* 428 */     getColumnConfig().doNE();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNX() {
/* 433 */     getColumnConfig().doNX();
/*     */     
/* 435 */     getListConfig().setOpeType("input");
/*     */   }
/*     */ 
/*     */   
/*     */   public void doLC() {
/* 440 */     getColumnConfig().doLC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doDC() {
/* 445 */     getColumnConfig().doDC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void focusGained() {
/* 450 */     setText((MCCalendarDate)getRowValue());
/* 451 */     focusGainedSelect();
/*     */   }
/*     */ 
/*     */   
/*     */   public void focusLost() {
/* 456 */     setText((MCCalendarDate)getRowValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public MCEventInfo getEventInfo() {
/* 461 */     return getColumnConfig().getEventInfo();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource(MCRootPanel panel) {}
/*     */ 
/*     */   
/*     */   public void doCheckValueError() {
/* 474 */     super.doCheckValueError();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCPopupConfig getPopupConfig() {
/* 479 */     MCTable<?> t = getTable();
/* 480 */     return (t != null) ? t.getPopupConfig() : null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCPopupMenu configurePopup(MCPopupMenu menu) {
/* 485 */     MCPopupConfig pc = getPopupConfig();
/* 486 */     return (pc != null) ? 
/* 487 */       pc.configurePopup(menu, getTable(), getRowIndex(), getColumnConfig()) : 
/* 488 */       menu;
/*     */   }
/*     */ 
/*     */   
/*     */   public void processKeyEvent(KeyEvent e) {
/* 493 */     MCCellUtil.beforeKeyEvent(e, this);
/* 494 */     super.processKeyEvent(e);
/*     */   }
/*     */ 
/*     */   
/*     */   public Comparable<?> doListFormat(Comparable<?> value) {
/* 499 */     return getColumnConfig().doListFormat(getRowIndex(), value);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Color getListForeground(MCRow row, boolean selected) {
/* 504 */     MCColumnConfig c = getColumnConfig();
/* 505 */     return getComboListConfig().getRowForeground(c, getRowIndex(), c.getTable(), row, 
/* 506 */         selected);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Color getListBackground(MCRow row, boolean selected) {
/* 511 */     MCColumnConfig c = getColumnConfig();
/* 512 */     return getComboListConfig().getRowBackground(c, getRowIndex(), c.getTable(), row, 
/* 513 */         selected);
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCEditorComboListModel createModel() {
/* 518 */     return new MCEditorComboListModel(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected class MCEditorComboField
/*     */     extends MCDateComboBox.MCDateComboField
/*     */   {
/*     */     protected MCEditorComboField() {
/* 536 */       super(MCEditorDateComboBox.this);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void initBeans() {
/* 541 */       super.initBeans();
/*     */       
/* 543 */       setFocusTraversalKeysEnabled(false);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isRequestFocusEnabled() {
/* 549 */       MCTable<?> t = MCEditorDateComboBox.this.getTable();
/* 550 */       if (!t.equalsIgnoreCase(MCBeansUtil.getFocusOwner(t)) && 
/* 551 */         !t.isRequestFocusEnabled()) {
/* 552 */         return false;
/*     */       }
/*     */       
/* 555 */       return super.isRequestFocusEnabled();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isMCRequestFocusEnabled() {
/* 560 */       return MCCellUtil.isFocusable(MCEditorDateComboBox.this);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected class MCEditorComboListModel
/*     */     extends MCComboListModel<MCDate>
/*     */   {
/*     */     protected MCEditorComboListModel(MCEditorDateComboBox compo) {
/* 581 */       super((AbsMCComboBox)compo);
/*     */     }
/*     */ 
/*     */     
/*     */     protected MCEditorDateComboBox getComboBox() {
/* 586 */       return (MCEditorDateComboBox)super.getComboBox();
/*     */     }
/*     */ 
/*     */     
/*     */     protected int getNewListIndex() {
/* 591 */       MCEditorDateComboBox compo = getComboBox();
/* 592 */       int index = compo.getRowIndex();
/* 593 */       MCTableColumn column = (MCTableColumn)compo.getColumnConfig();
/* 594 */       return column.getNewListIndex(index);
/*     */     }
/*     */ 
/*     */     
/*     */     protected int getOldListIndex() {
/* 599 */       MCEditorDateComboBox compo = getComboBox();
/* 600 */       int index = compo.getRowIndex();
/* 601 */       MCTableColumn column = (MCTableColumn)compo.getColumnConfig();
/* 602 */       return column.getOldListIndex(index);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void setNewListIndex(int index) {
/* 607 */       MCEditorDateComboBox compo = getComboBox();
/* 608 */       int row = compo.getRowIndex();
/* 609 */       MCTableColumn column = (MCTableColumn)compo.getColumnConfig();
/* 610 */       column.setNewListIndex(row, Integer.valueOf(index));
/*     */     }
/*     */ 
/*     */     
/*     */     protected void setOldListIndex(int index) {
/* 615 */       MCEditorDateComboBox compo = getComboBox();
/* 616 */       int row = compo.getRowIndex();
/* 617 */       MCTableColumn column = (MCTableColumn)compo.getColumnConfig();
/* 618 */       column.setOldListIndex(row, Integer.valueOf(index));
/*     */     }
/*     */ 
/*     */     
/*     */     protected int getSelectedIndex() {
/* 623 */       MCEditorDateComboBox compo = getComboBox();
/* 624 */       int index = compo.getRowIndex();
/* 625 */       MCTableColumn column = (MCTableColumn)compo.getColumnConfig();
/* 626 */       return (column != null) ? column.getSelectedListIndex(index) : 
/* 627 */         super.getSelectedIndex();
/*     */     }
/*     */ 
/*     */     
/*     */     protected void setSelectedIndex(int index) {
/* 632 */       super.setSelectedIndex(index);
/* 633 */       MCEditorDateComboBox compo = getComboBox();
/* 634 */       int row = compo.getRowIndex();
/* 635 */       MCTableColumn column = (MCTableColumn)compo.getColumnConfig();
/* 636 */       if (column != null) {
/* 637 */         column.setSelectedListIndex(row, Integer.valueOf(index));
/*     */       } else {
/*     */         
/* 640 */         super.setSelectedIndex(index);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCEditorDateComboBox.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */