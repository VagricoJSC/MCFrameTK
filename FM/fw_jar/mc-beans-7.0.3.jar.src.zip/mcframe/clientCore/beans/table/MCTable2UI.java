/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.util.Enumeration;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.table.TableCellRenderer;
/*     */ import javax.swing.table.TableColumn;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCTable2UI
/*     */   extends MCTableUI
/*     */ {
/*     */   public static ComponentUI createUI(JComponent h) {
/*  38 */     return new MCTable2UI();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCTable<?> getMCTable() {
/*  50 */     return (MCTable)this.table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getTableHeight() {
/*  64 */     int height = 0;
/*  65 */     int rowCount = this.table.getRowCount();
/*  66 */     if (rowCount > 0 && this.table.getColumnCount() > 0) {
/*  67 */       Rectangle r = this.table.getCellRect(
/*  68 */           rowCount - 1, this.table.getColumnCount() - 1, true);
/*  69 */       height = r.y + r.height;
/*     */     } 
/*  71 */     return height;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Dimension createTableSize(long width) {
/*  83 */     if (width > 2147483647L) {
/*  84 */       width = 2147483647L;
/*     */     }
/*  86 */     return new Dimension((int)width, getTableHeight());
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getMinimumSize(JComponent c) {
/*  91 */     MCTable<?> t = getMCTable();
/*  92 */     long width = (t == t.getBaseTable()) ? 
/*     */       
/*  94 */       getScrollMinimumWidth() : 
/*     */       
/*  96 */       getFixedMinimumWidth();
/*  97 */     return createTableSize(width);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long getFixedMinimumWidth() {
/* 108 */     long width = 0L;
/* 109 */     Enumeration<TableColumn> enumeration = 
/* 110 */       this.table.getColumnModel().getColumns();
/* 111 */     while (enumeration.hasMoreElements()) {
/* 112 */       TableColumn aColumn = enumeration.nextElement();
/* 113 */       width += aColumn.getMinWidth();
/*     */     } 
/* 115 */     return width;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long getScrollMinimumWidth() {
/* 126 */     MCTable2ColumnModel cm = ((MCTable2)this.table).getColumnModel();
/* 127 */     return cm.getMinimumWidth();
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getMaximumSize(JComponent c) {
/* 132 */     MCTable<?> t = getMCTable();
/* 133 */     long width = (t == t.getBaseTable()) ? 
/*     */       
/* 135 */       getScrollMaximumWidth() : 
/*     */       
/* 137 */       getFixedMaximumWidth();
/* 138 */     return createTableSize(width);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long getFixedMaximumWidth() {
/* 149 */     long width = 0L;
/* 150 */     Enumeration<TableColumn> enumeration = 
/* 151 */       this.table.getColumnModel().getColumns();
/* 152 */     while (enumeration.hasMoreElements()) {
/* 153 */       TableColumn aColumn = enumeration.nextElement();
/* 154 */       width += aColumn.getMaxWidth();
/*     */     } 
/* 156 */     return width;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long getScrollMaximumWidth() {
/* 167 */     MCTable2ColumnModel cm = ((MCTable2)this.table).getColumnModel();
/* 168 */     return cm.getMaximumWidth();
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getPreferredSize(JComponent c) {
/* 173 */     MCTable<?> t = getMCTable();
/* 174 */     long width = (t == t.getBaseTable()) ? 
/*     */       
/* 176 */       getScrollPreferredWidth() : 
/*     */       
/* 178 */       getFixedPreferredWidth();
/* 179 */     return createTableSize(width);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long getFixedPreferredWidth() {
/* 190 */     long width = 0L;
/* 191 */     Enumeration<TableColumn> enumeration = 
/* 192 */       this.table.getColumnModel().getColumns();
/* 193 */     while (enumeration.hasMoreElements()) {
/* 194 */       TableColumn aColumn = enumeration.nextElement();
/* 195 */       width += aColumn.getPreferredWidth();
/*     */     } 
/* 197 */     return width;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private long getScrollPreferredWidth() {
/* 208 */     MCTable2ColumnModel cm = ((MCTable2)this.table).getColumnModel();
/* 209 */     return cm.getPreferredWidth();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paint(Graphics g, JComponent c) {
/* 223 */     Rectangle clipBounds = g.getClipBounds();
/*     */ 
/*     */     
/* 226 */     Rectangle bounds = this.table.getBounds();
/* 227 */     bounds.x = bounds.y = 0;
/* 228 */     if (this.table.getRowCount() <= 0 || this.table.getColumnCount() <= 0 || 
/* 229 */       !bounds.intersects(clipBounds)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 236 */     boolean ltr = this.table.getComponentOrientation().isLeftToRight();
/* 237 */     Point upperLeft = clipBounds.getLocation();
/* 238 */     if (!ltr) {
/* 239 */       upperLeft.x++;
/*     */     }
/* 241 */     Point lowerRight = new Point(clipBounds.x + clipBounds.width - (ltr ? 1 : 0), 
/* 242 */         clipBounds.y + clipBounds.height);
/*     */ 
/*     */     
/* 245 */     int rMin = this.table.rowAtPoint(upperLeft);
/* 246 */     if (rMin == -1) {
/* 247 */       rMin = 0;
/*     */     }
/* 249 */     int rMax = this.table.rowAtPoint(lowerRight);
/* 250 */     if (rMax == -1) {
/* 251 */       rMax = this.table.getRowCount() - 1;
/*     */     }
/*     */ 
/*     */     
/* 255 */     for (int index = rMin; index <= rMax; index++) {
/* 256 */       paintRow(g, index);
/*     */     }
/*     */ 
/*     */     
/* 260 */     this.rendererPane.removeAll();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void paintRow(Graphics g, int row) {
/* 273 */     if (this.table.getRowHeight(row) <= 0) {
/*     */       return;
/*     */     }
/*     */     
/* 277 */     if (this.table instanceof MCTable2) {
/*     */       
/* 279 */       MCTable2<?> t2 = (MCTable2)this.table;
/* 280 */       MCTable2ColumnModel cm = t2.getColumnModel();
/* 281 */       int retcnt = t2.getReturnCount();
/* 282 */       for (int tier = 0; tier < retcnt; tier++) {
/* 283 */         int[] se = cm.getTierColumnIndex(tier);
/* 284 */         paintCells(g, row, se[0], se[1] - 1);
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 289 */       int colcnt = this.table.getColumnModel().getColumnCount();
/* 290 */       paintCells(g, row, 0, colcnt);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void paintCells(Graphics g, int row, int start, int end) {
/* 305 */     Rectangle clip = g.getClipBounds();
/* 306 */     for (int column = start; column <= end; column++) {
/*     */       
/* 308 */       if (column <= 0 || column >= this.table.getColumnCount() || 
/* 309 */         this.table.getColumnModel().getColumn(column).getWidth() > 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 315 */         Rectangle cellRect = this.table.getCellRect(row, column, true);
/* 316 */         if (cellRect.intersects(clip)) {
/* 317 */           paintCell(g, cellRect, row, column);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void paintCell(Graphics g, Rectangle cellRect, int row, int column) {
/* 333 */     paintGrid(g, cellRect, row);
/*     */     
/* 335 */     int spacingHeight = this.table.getRowMargin();
/* 336 */     int spacingWidth = this.table.getColumnModel().getColumnMargin();
/* 337 */     cellRect.setBounds(cellRect.x + spacingWidth / 2, 
/* 338 */         cellRect.y + spacingHeight / 2, 
/* 339 */         cellRect.width - spacingWidth, 
/* 340 */         cellRect.height - spacingHeight);
/*     */     
/* 342 */     if (this.table.isEditing() && 
/* 343 */       this.table.getEditingRow() == row && 
/* 344 */       this.table.getEditingColumn() == column) {
/* 345 */       Component component = this.table.getEditorComponent();
/* 346 */       component.setBounds(cellRect);
/* 347 */       component.validate();
/*     */     } else {
/*     */       
/* 350 */       TableCellRenderer renderer = this.table.getCellRenderer(row, column);
/* 351 */       Component component = this.table.prepareRenderer(renderer, row, column);
/* 352 */       this.rendererPane.paintComponent(g, component, this.table, 
/* 353 */           cellRect.x, cellRect.y, 
/* 354 */           cellRect.width, cellRect.height, 
/* 355 */           true);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void paintGrid(Graphics g, Rectangle cellRect, int row) {
/* 369 */     boolean isSynth = UIManager.getLookAndFeel() instanceof javax.swing.plaf.synth.SynthLookAndFeel;
/* 370 */     if (isSynth) {
/* 371 */       g.setColor(UIManager.getColor("MCTable.gridColor"));
/*     */     } else {
/*     */       
/* 374 */       g.setColor(this.table.getGridColor());
/*     */     } 
/*     */     
/* 377 */     if (isSynth ? UIManager.getBoolean("MCTable.ShowHorizontalLines") : 
/* 378 */       this.table.getShowHorizontalLines()) {
/*     */       
/* 380 */       int y = cellRect.y + cellRect.height - 1;
/* 381 */       g.drawLine(cellRect.x, y, cellRect.x + cellRect.width - 1, y);
/*     */ 
/*     */       
/* 384 */       int yh = cellRect.y - 1;
/* 385 */       g.drawLine(cellRect.x, yh, cellRect.x + cellRect.width - 1, yh);
/*     */     } 
/* 387 */     if (isSynth ? UIManager.getBoolean("MCTable.ShowVerticalLines") : 
/* 388 */       this.table.getShowVerticalLines()) {
/*     */       
/* 390 */       int x = cellRect.x + cellRect.width - 1;
/* 391 */       g.drawLine(x, cellRect.y, x, cellRect.y + cellRect.height - 1);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCTable2UI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */