/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Image;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.table.DefaultTableCellRenderer;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCDataType;
/*     */ import mcframe.commonCore.lang.MCDate;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCRowSignalCellRenderer
/*     */   extends DefaultTableCellRenderer
/*     */   implements MCInfraCellRenderer
/*     */ {
/*     */   public static final int COLUMN_WIDTH = 20;
/*     */   private final MCColumnConfig _column;
/*  46 */   private MCRowSignal _signal = new MCRowSignal();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCRowSignalCellRenderer(MCColumnConfig column) {
/*  57 */     this._column = column;
/*  58 */     setHorizontalAlignment(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCColumnConfig getColumnConfig() {
/*  69 */     return this._column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCRowSignal getRowSignal() {
/*  80 */     return this._signal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Component getTableCellRendererComponent(JTable table, Object value, boolean selected, boolean focused, int index, int column) {
/*  99 */     return getRenderer((MCTable)table, value, selected, focused, index, getColumnConfig());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Component getRenderer(MCTable<?> table, Object value, boolean selected, boolean focused, int index, MCColumnConfig column) {
/*     */     try {
/* 118 */       Icon icon = getRowSignalIcon(index, column, table, selected);
/* 119 */       setIcon(icon);
/*     */     }
/* 121 */     catch (RuntimeException e) {
/* 122 */       MCCellUtil.preHandle(table, e);
/* 123 */       MCCellUtil.handle(table, e);
/*     */     } 
/* 125 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Icon getRowSignalIcon(int index, MCColumnConfig column, MCTable<?> table, boolean selected) {
/* 142 */     MCRootPanel p = table.getBaseRootPanel();
/* 143 */     MCDate codate = (p != null) ? (MCDate)p.today(MCDataType.DATE) : null;
/*     */     
/* 145 */     MCRow row = (MCRow)table.getRow(index);
/* 146 */     int signal = this._signal.getSignal(row, (MCList)table.getList(), codate);
/* 147 */     MCCellConfig conf = column.getCellConfig();
/* 148 */     ImageIcon icon = conf.getRowSignalColumnIcon(
/* 149 */         index, column, table, selected, signal);
/* 150 */     if (icon == null) {
/* 151 */       return null;
/*     */     }
/* 153 */     Image image = icon.getImage().getScaledInstance(
/* 154 */         20, 20, 4);
/* 155 */     return new ImageIcon(image);
/*     */   }
/*     */ 
/*     */   
/*     */   public Comparable<?> getValue() {
/* 160 */     return getText();
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCRowSignalCellRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */