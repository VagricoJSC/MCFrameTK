/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextField;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCCellEditorPassword
/*     */   extends MCCellEditor
/*     */ {
/*     */   protected MCCellEditorPassword(String name, MCColumnConfig column) {
/*  28 */     super((JTextField)new MCEditorPasswordField(name, column), column);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCEditorPasswordField getEditorComponent() {
/*  39 */     return (MCEditorPasswordField)this.editorComponent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Component getTableCellEditorComponent(JTable table, Object value, boolean selected, int index, int column) {
/*  57 */     return (Component)getEditor((MCTable)table, (String)value, index, getColumnConfig());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCEditorPasswordField getEditor(MCTable<?> table, String value, int index, MCColumnConfig column) {
/*  73 */     MCEditorPasswordField compo = getEditorComponent();
/*  74 */     compo.setColumnInfo(index, column);
/*  75 */     compo.setText(value);
/*  76 */     return compo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Component getDummyTableCellEditorComponent(MCConstRow dummy) {
/*  88 */     return (Component)getDummyEditor(getColumnConfig(), dummy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCEditorPasswordField getDummyEditor(MCColumnConfig column, MCConstRow dummy) {
/* 101 */     MCEditorPasswordField compo = getEditorComponent();
/* 102 */     compo.setDummyColumnInfo(column, dummy);
/* 103 */     return compo;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCCellEditorPassword.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */