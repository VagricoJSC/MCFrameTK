/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.math.BigDecimal;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.border.Border;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCMode;
/*     */ import mcframe.clientCore.beans.MCNumberField;
/*     */ import mcframe.clientCore.beans.MCResourceBeans;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.action.MCKeyActionManager;
/*     */ import mcframe.clientCore.beans.list.MCLinkedBeans;
/*     */ import mcframe.clientCore.beans.list.MCListType;
/*     */ import mcframe.clientCore.beans.popup.MCPopupConfig;
/*     */ import mcframe.clientCore.beans.popup.MCPopupMenu;
/*     */ import mcframe.clientCore.beans.text.MCNumberDocument;
/*     */ import mcframe.clientCore.beans.text.MCNumberFormat;
/*     */ import mcframe.clientCore.event.MCEventInfo;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCEditorNumberField
/*     */   extends MCNumberField
/*     */   implements MCEditorBeans
/*     */ {
/*     */   private static final String TYPE = "table.column.number";
/*     */   private MCColumnConfig _column;
/*     */   private MCTable<?> _table;
/*     */   
/*     */   protected MCEditorNumberField(String name, MCColumnConfig column) {
/*  70 */     super(name);
/*  71 */     setColumnConfig(column);
/*  72 */     setTable(column.getBaseTable());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getType() {
/*  77 */     return "table.column.number";
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initBeans() {
/*  82 */     super.initBeans();
/*     */ 
/*     */     
/*  85 */     setFocusTraversalKeysEnabled(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initKeyAssign() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initResource() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setColumnConfig(MCColumnConfig column) {
/* 116 */     this._column = column;
/*     */   }
/*     */   
/*     */   public final MCColumnConfig getColumnConfig() {
/* 120 */     return this._column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setTable(MCTable<?> table) {
/* 131 */     this._table = table;
/*     */   }
/*     */   
/*     */   public final MCTable getTable() {
/* 135 */     return this._table;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getRowIndex() {
/* 140 */     return MCCellUtil.getRowIndex(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void transferFocus() {
/* 145 */     MCTable<?> t = getTable();
/* 146 */     t.transferFocus(getRowIndex(), t.getViewColumn(getColumnConfig()) + 1, false, 
/* 147 */         true, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public Border getDefaultBorder() {
/* 152 */     return MCCellUtil.DEFAULT_BORDER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setColumnInfo(int index, MCColumnConfig column) {
/* 164 */     setColumnConfig(column);
/* 165 */     MCTable<?> table = getTable();
/* 166 */     MCKeyActionManager.init((MCResourceBeans)this, getInputMap(), getActionMap());
/* 167 */     MCKeyActionManager.initScreen((MCResourceBeans)this, getInputMap(), getActionMap());
/* 168 */     MCMode mode = MCCellUtil.isCellEditable(index, column, table);
/* 169 */     setMode(mode);
/* 170 */     setForeground(MCCellUtil.getForeground(index, column, table, false, mode));
/* 171 */     setBackground(MCCellUtil.getBackground(index, column, table, false, mode));
/* 172 */     setFont(column.getFont());
/* 173 */     setCaretColor(MCCellUtil.getCaretColor(index, column, table));
/* 174 */     setSelectionColor(MCCellUtil.getSelectionColor(index, column, table));
/* 175 */     setSelectedTextColor(MCCellUtil.getSelectedTextColor(index, column, table));
/* 176 */     setMeta(column.getMeta());
/* 177 */     setLength(column.getLength(index), column.getScale(index), column
/* 178 */         .isMinusEnable(index));
/* 179 */     setNumberFormat(MCCellUtil.getNumberFormat(index, column, table, mode));
/*     */     
/* 181 */     setViewScale(MCCellUtil.getViewScale(index, column, table));
/* 182 */     setViewZeroType(MCCellUtil.getViewZeroType(index, column, table));
/* 183 */     setViewRoundingMode(MCCellUtil.getViewRoundingMode(
/* 184 */           index, column, table));
/*     */     
/* 186 */     setRow(column.getTable().getRow(index), column.getRowColumnName());
/*     */     
/* 188 */     setAutoFocus(column.isAutoFocus());
/* 189 */     setSelectAll(column.isSelectAll());
/* 190 */     setListConfig(column.getListConfig());
/* 191 */     Border border = MCCellUtil.getEditorBorder(index, column, table);
/* 192 */     if (border != null) {
/* 193 */       setBorder(border);
/*     */     } else {
/*     */       
/* 196 */       setBorder(getDefaultBorder());
/*     */     } 
/* 198 */     setListListener(column.getListListener());
/* 199 */     MCPopupMenu menu = getComponentPopupMenu();
/* 200 */     if (menu != null) {
/* 201 */       menu.updateResource();
/*     */     }
/*     */   }
/*     */   
/*     */   public Color getForeground() {
/* 206 */     Color c = null;
/* 207 */     int idx = getRowIndex();
/* 208 */     MCTable<?> table = getTable();
/* 209 */     if (table != null && idx >= 0) {
/* 210 */       MCMode mode = MCCellUtil.isCellEditable(idx, this._column, table);
/* 211 */       c = MCCellUtil.getForeground(idx, this._column, table, false, mode);
/*     */     } else {
/*     */       
/* 214 */       c = super.getForeground();
/*     */     } 
/* 216 */     return c;
/*     */   }
/*     */ 
/*     */   
/*     */   public Color getBackground() {
/* 221 */     Color c = null;
/* 222 */     int idx = getRowIndex();
/* 223 */     MCTable<?> table = getTable();
/* 224 */     if (table != null && idx >= 0) {
/* 225 */       MCMode mode = MCCellUtil.isCellEditable(idx, this._column, table);
/* 226 */       c = MCCellUtil.getBackground(idx, this._column, table, false, mode);
/*     */     } else {
/*     */       
/* 229 */       c = super.getBackground();
/*     */     } 
/* 231 */     return c;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCLinkedBeans[] getLinkBeans() {
/* 236 */     MCColumnConfig c = getColumnConfig();
/* 237 */     return (c != null) ? c.getLinkBeans() : super.getLinkBeans();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCRootPanel getRootPanel() {
/* 242 */     return MCCellUtil.getRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCRootPanel getNearestRootPanel() {
/* 247 */     return MCCellUtil.getNearestRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessageByLocale() {
/* 252 */     return getColumnConfig().getMessageByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLabelByLocale() {
/* 257 */     return getColumnConfig().getLabelByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterRequestFocus() {
/* 262 */     MCRootPanel bp = getBaseRootPanel();
/* 263 */     MCBeansUtil.afterRequestFocus(bp, getTable());
/* 264 */     MCBeansUtil.scrollRectToVisible(bp, (JComponent)this, getHorizontalAlignment());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 269 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void commitValue() {}
/*     */ 
/*     */   
/*     */   public boolean isFocusOwner() {
/* 278 */     MCTable<?> t = getTable();
/* 279 */     return (t != null) ? (t.isRemoveNotifyProcessing() ? super.isFocusOwner() : false) : 
/* 280 */       super.isFocusOwner();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValueChanged() {
/* 285 */     return isValueChanged((Comparable<?>)getRowValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValueChanged(Comparable<?> value) {
/* 299 */     return isValueChanged((Comparable<?>)getValue(), value);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isValueChanged(Comparable<?> view, Comparable<?> row) {
/* 304 */     return MCCellUtil.isValueChanged(this, view, row);
/*     */   }
/*     */   
/*     */   public void valueCommited() {
/* 308 */     MCRow row = null;
/* 309 */     if ("input".equals(getListConfig().getOpeType())) {
/* 310 */       MCList<?> l = getList();
/* 311 */       if (l != null) {
/* 312 */         MCRow[] a = l.toArray();
/* 313 */         MCNumber v = getValue();
/* 314 */         String n = getListNames()[0]; byte b; int i; MCRow[] arrayOfMCRow1;
/* 315 */         for (i = (arrayOfMCRow1 = a).length, b = 0; b < i; ) { MCRow r = arrayOfMCRow1[b];
/* 316 */           MCNumber val = r.getNumber(n);
/* 317 */           if (val != null && val.eq((BigDecimal)v)) {
/* 318 */             row = r; break;
/*     */           } 
/*     */           b++; }
/*     */       
/*     */       } 
/*     */     } 
/* 324 */     if (row == null && 
/* 325 */       getListType() == MCListType.FREE) {
/* 326 */       row = MCRow.create();
/* 327 */       MCBeansProxy.PROXY.addColumn(row, getListNames()[0], getDataType(), 
/* 328 */           (Comparable<?>)getViewValue());
/*     */     } 
/*     */     
/* 331 */     ((MCTableColumn)getColumnConfig()).execLink(getTable().getMCEditingRow(), row, 
/* 332 */         true);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isMCFocusOwner() {
/* 337 */     MCTable<?> t = getTable();
/* 338 */     return (t != null) ? ((t.getMCEditorComponent() == this)) : isFocusOwner();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void focusGained() {
/* 344 */     MCNumberDocument d = getDocument();
/* 345 */     boolean e = d.isValueCheck();
/* 346 */     d.setValueCheck(false);
/*     */     try {
/* 348 */       setText(getRowValue());
/* 349 */       focusGainedSelect();
/*     */     } finally {
/*     */       
/* 352 */       d.setValueCheck(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void focusLost() {
/* 358 */     MCNumberDocument d = getDocument();
/* 359 */     boolean e = d.isValueCheck();
/* 360 */     d.setValueCheck(false);
/*     */     try {
/* 362 */       setText(getRowValue());
/*     */     } finally {
/*     */       
/* 365 */       d.setValueCheck(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setText(MCNumber value) {
/* 371 */     super.setText(value);
/*     */   }
/*     */   
/*     */   public String doFormat(MCNumber value) {
/*     */     String rtn;
/* 376 */     MCNumberFormat f = getNumberFormat();
/* 377 */     int fieldScale = getScale();
/*     */     
/* 379 */     if (isMCFocusOwner()) {
/* 380 */       rtn = f.doInputFormat(value, fieldScale);
/*     */     } else {
/*     */       
/* 383 */       rtn = f.doOutputFormat(value, fieldScale);
/*     */     } 
/* 385 */     return rtn;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCList doListEvent() {
/* 390 */     return getColumnConfig().doListEvent();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean doVC() {
/* 395 */     return getColumnConfig().doVC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNC() {
/* 400 */     getColumnConfig().doNC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNE() {
/* 405 */     getColumnConfig().doNE();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNX() {
/* 410 */     getColumnConfig().doNX();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doLC() {
/* 415 */     getColumnConfig().doLC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doDC() {
/* 420 */     getColumnConfig().doDC();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCEventInfo getEventInfo() {
/* 425 */     return getColumnConfig().getEventInfo();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRequestFocusEnabled() {
/* 430 */     return (MCCellUtil.isRequestFocusEnabled(this) && super.isRequestFocusEnabled());
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isMCRequestFocusEnabled() {
/* 435 */     return MCCellUtil.isFocusable(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public Border getBorder() {
/* 440 */     Border b = MCCellUtil.getBorder(this);
/* 441 */     return (b != null) ? b : super.getBorder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource(MCRootPanel panel) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doCheckValueError() {
/* 466 */     super.doCheckValueError();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCPopupConfig getPopupConfig() {
/* 471 */     MCTable<?> t = getTable();
/* 472 */     return (t != null) ? t.getPopupConfig() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCPopupMenu configurePopup(MCPopupMenu menu) {
/* 486 */     MCPopupConfig pc = getPopupConfig();
/* 487 */     return (pc != null) ? pc.configurePopup(menu, getTable(), getRowIndex(), 
/* 488 */         getColumnConfig()) : menu;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void processKeyEvent(KeyEvent e) {
/* 493 */     MCCellUtil.beforeKeyEvent(e, this);
/* 494 */     super.processKeyEvent(e);
/*     */   }
/*     */ 
/*     */   
/*     */   public Comparable<?> doListFormat(Comparable<?> value) {
/* 499 */     return getColumnConfig().doListFormat(getRowIndex(), value);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void execLink(MCRow row, boolean msg) {
/* 504 */     ((MCTableColumn)getColumnConfig()).execLink(getRowIndex(), row, msg);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCEditorNumberField.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */