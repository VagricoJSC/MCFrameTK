/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextField;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCCellEditorText
/*     */   extends MCCellEditor
/*     */ {
/*     */   protected MCCellEditorText(String name, MCColumnConfig column) {
/*  28 */     super((JTextField)new MCEditorTextField(name, column), column);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCEditorTextField getEditorComponent() {
/*  39 */     return (MCEditorTextField)this.editorComponent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Component getTableCellEditorComponent(JTable table, Object value, boolean selected, int index, int column) {
/*  57 */     return (Component)getEditor((MCTable)table, (String)value, index, getColumnConfig());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCEditorTextField getEditor(MCTable<?> table, String value, int index, MCColumnConfig column) {
/*  72 */     MCEditorTextField compo = getEditorComponent();
/*  73 */     compo.setColumnInfo(index, column);
/*  74 */     compo.setText(value);
/*  75 */     return compo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Component getDummyTableCellEditorComponent(MCConstRow dummy) {
/*  88 */     return (Component)getDummyEditor(getColumnConfig(), dummy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCEditorTextField getDummyEditor(MCColumnConfig column, MCConstRow dummy) {
/* 101 */     MCEditorTextField compo = getEditorComponent();
/* 102 */     compo.setDummyColumnInfo(column, dummy);
/* 103 */     return compo;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCCellEditorText.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */