package mcframe.clientCore.beans.table;

public interface MCColumnGroupMember {
  int getWidth();
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCColumnGroupMember.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */