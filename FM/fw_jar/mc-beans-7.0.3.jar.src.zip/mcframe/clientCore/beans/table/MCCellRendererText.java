/*    */ package mcframe.clientCore.beans.table;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCCellRendererText
/*    */   extends MCCellRendererField
/*    */ {
/*    */   protected MCCellRendererText(MCColumnConfig column) {
/* 21 */     super(column);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCCellRendererText.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */