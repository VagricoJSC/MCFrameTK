/*    */ package mcframe.clientCore.beans.table;
/*    */ 
/*    */ import java.awt.Graphics;
/*    */ import mcframe.clientCore.beans.plaf.MCGraphicsUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCCellRendererField
/*    */   extends MCCellRenderer
/*    */ {
/*    */   protected MCCellRendererField(MCColumnConfig column) {
/* 27 */     super(column);
/*    */   }
/*    */ 
/*    */   
/*    */   public void paintComponent(Graphics g) {
/* 32 */     super.paintComponent(g);
/* 33 */     if (getColumnConfig().getRowValue(getRowIndex()) == null) {
/* 34 */       MCGraphicsUtil.drawLine(g, this, this._mode, MCGraphicsUtil.Corners.LEFT);
/* 35 */       MCGraphicsUtil.paintCornerMark(g, this, getVisibleRect(), "mode", this._mode, 
/* 36 */           MCGraphicsUtil.CornerMarkLocation.OUTER);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCCellRendererField.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */