/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import javax.swing.SizeSequence;
/*     */ import javax.swing.table.JTableHeader;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.clientCore.event.MCAPBeans;
/*     */ import mcframe.clientCore.event.MCEventInfo;
/*     */ import mcframe.commonCore.util.MCCollectionUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCLayoutTable<E extends MCConstRow>
/*     */   extends MCTable<E>
/*     */ {
/*     */   private static final String uiClassID = "MCLayoutTableUI";
/*     */   
/*     */   public MCLayoutTable(String name) {
/*  46 */     super(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addColumnLayout(MCColumnLayout layout) {
/*  58 */     getColumnModel().addColumnLayout(layout);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addColumnLayout(MCTable<? extends MCConstRow> table) {
/*  75 */     if (table instanceof MCLayoutTable) {
/*  76 */       MCLayoutTableColumnModel model = getColumnModel();
/*  77 */       MCLayoutTable<?> ptable = (MCLayoutTable)table;
/*  78 */       MCLayoutTableColumnModel pmodel = ptable.getColumnModel();
/*  79 */       MCColumnLayout[] cls = pmodel.getColumnLayouts(); byte b; int i; MCColumnLayout[] arrayOfMCColumnLayout1;
/*  80 */       for (i = (arrayOfMCColumnLayout1 = cls).length, b = 0; b < i; ) { MCColumnLayout cl = arrayOfMCColumnLayout1[b];
/*  81 */         model.addColumnLayout(cl);
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCColumnLayout[] getColumnLayouts() {
/* 100 */     return getColumnModel().getColumnLayouts();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTierCount() {
/* 112 */     MCFixedColumnLayoutTable<E> ft = getFixedColumnLayoutTable();
/* 113 */     return Math.max(_getTierCount(ft.getColumnModel()), 
/* 114 */         _getTierCount(getColumnModel()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int _getTierCount(MCLayoutTableColumnModel model) {
/* 126 */     int tier = 0;
/* 127 */     Iterator<MCColumnLayoutMember> ite = model.createLayoutMemberIterator();
/* 128 */     while (ite.hasNext()) {
/* 129 */       MCColumnLayoutMember member = ite.next();
/* 130 */       if (member instanceof MCColumnLayout) {
/* 131 */         MCColumnLayout layout = (MCColumnLayout)member;
/* 132 */         tier = Math.max(tier, layout.getTierCount()); continue;
/*     */       } 
/* 134 */       if (member instanceof MCTableColumn && 
/* 135 */         tier == 0) {
/* 136 */         tier = 1;
/*     */       }
/*     */     } 
/*     */     
/* 140 */     return tier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCLayoutTable<E> getBodyLayoutTable() {
/* 159 */     return (MCLayoutTable<E>)getBodyTable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCFixedColumnLayoutTable<E> getFixedColumnLayoutTable() {
/* 178 */     return (MCFixedColumnLayoutTable<E>)getFixedColumnTable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUIClassID() {
/* 189 */     return "MCLayoutTableUI";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCFixedColumnLayoutTable<E> createFixedColumnTable(String name) {
/* 195 */     return new MCFixedColumnLayoutTable<>(this, name);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCLayoutTableHeader createDefaultTableHeader() {
/* 201 */     return new MCLayoutTableHeader(getColumnModel());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MCLayoutTableHeader getTableHeader() {
/* 207 */     return (MCLayoutTableHeader)super.getTableHeader();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCLayoutTableColumnModel createDefaultColumnModel() {
/* 213 */     return new MCLayoutTableColumnModel();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MCLayoutTableColumnModel getColumnModel() {
/* 219 */     return (MCLayoutTableColumnModel)super.getColumnModel();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setRenderers() {
/* 225 */     getTableHeader().setDefaultRenderer(
/* 226 */         new MCMultiLineHeaderRenderer(
/* 227 */           getTableHeader().getDefaultRenderer()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void initColumns() {
/* 233 */     super.initColumns();
/*     */ 
/*     */     
/* 236 */     MCColumnLayout[] ls = getColumnModel().getColumnLayouts(); byte b; int i; MCColumnLayout[] arrayOfMCColumnLayout1;
/* 237 */     for (i = (arrayOfMCColumnLayout1 = ls).length, b = 0; b < i; ) { MCColumnLayout l = arrayOfMCColumnLayout1[b];
/* 238 */       l.initialized();
/*     */       b++; }
/*     */   
/*     */   }
/*     */   
/*     */   public void doAPEvent(MCAPBeans compo, MCEventInfo info) {
/* 244 */     if (compo == getColumnWidthPanelMenuItem()) {
/*     */       
/* 246 */       MCRootPanel bp = getBaseRootPanel();
/* 247 */       MCRootPanel p = bp.createPanel(
/* 248 */           "FS", "FSBAP0110", MCRootPanel.SCREEN_MODAL, new Object[] { "T1", null, this });
/* 249 */       bp.showChildPanel(p, MCRootPanel.MULTI, new Object[0]);
/*     */     } else {
/*     */       
/* 252 */       super.doAPEvent(compo, info);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getTierInRow() {
/* 262 */     return getTierCount();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUnscrollColumn(MCColumnConfig column) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCColumnConfig setUnscrollColumnLayout(MCColumnConfig column) {
/* 291 */     boolean find = (column == null);
/* 292 */     MCColumnConfig border = column;
/* 293 */     Set<MCColumnLayout> setf = new LinkedHashSet<>();
/* 294 */     Set<MCColumnLayout> sets = new LinkedHashSet<>();
/*     */     
/* 296 */     MCLayoutTableColumnModel[] models = {
/* 297 */         getFixedColumnLayoutTable().getColumnModel(), 
/* 298 */         getColumnModel() }; byte b; int i;
/*     */     MCLayoutTableColumnModel[] arrayOfMCLayoutTableColumnModel1;
/* 300 */     for (i = (arrayOfMCLayoutTableColumnModel1 = models).length, b = 0; b < i; ) { MCLayoutTableColumnModel model = arrayOfMCLayoutTableColumnModel1[b];
/* 301 */       Iterator<MCColumnLayoutMember> ite = 
/* 302 */         model.createLayoutMemberIterator();
/* 303 */       while (ite.hasNext()) {
/* 304 */         MCColumnLayoutMember member = ite.next();
/* 305 */         if (member instanceof MCColumnLayout) {
/*     */           
/* 307 */           MCColumnLayout l = (MCColumnLayout)member;
/* 308 */           if (find) {
/*     */             
/* 310 */             sets.add(l);
/*     */             
/*     */             continue;
/*     */           } 
/* 314 */           setf.add(l);
/* 315 */           find = l.contains(column);
/* 316 */           if (find) {
/*     */             
/* 318 */             MCColumnConfig[] ccs = l.getAllColumnConfigs();
/* 319 */             border = ccs[ccs.length - 1];
/*     */           } 
/*     */           continue;
/*     */         } 
/* 323 */         if (member instanceof MCTableColumn)
/*     */         {
/* 325 */           if (member == column)
/*     */           {
/* 327 */             find = true;
/*     */           }
/*     */         }
/*     */       } 
/*     */       
/*     */       b++; }
/*     */     
/* 334 */     models[0].setAllColumnLayout(setf);
/* 335 */     models[1].setAllColumnLayout(sets);
/*     */     
/* 337 */     return border;
/*     */   }
/*     */ 
/*     */   
/*     */   void updateColumnsFontSize(int fontratio, int widthratio, boolean check) {
/* 342 */     MCColumnLayout[] ls = (MCColumnLayout[])MCCollectionUtil.concat((Object[][])new MCColumnLayout[][] {
/* 343 */           getFixedColumnLayoutTable().getColumnModel().getColumnLayouts(), 
/* 344 */           getColumnModel().getColumnLayouts() }); byte b;
/*     */     int i;
/*     */     MCColumnLayout[] arrayOfMCColumnLayout1;
/* 347 */     for (i = (arrayOfMCColumnLayout1 = ls).length, b = 0; b < i; ) { MCColumnLayout l = arrayOfMCColumnLayout1[b];
/* 348 */       l.setRunningPropertyChangeEvent(true);
/* 349 */       l.invalidateWidthCache(true);
/* 350 */       l.invalidateMinWidthCache(true);
/* 351 */       l.invalidatePreferredWidthCache(true);
/*     */       b++; }
/*     */     
/* 354 */     super.updateColumnsFontSize(fontratio, widthratio, check);
/*     */     
/* 356 */     for (i = (arrayOfMCColumnLayout1 = ls).length, b = 0; b < i; ) { MCColumnLayout l = arrayOfMCColumnLayout1[b];
/* 357 */       l.cancelRunningPropertyChangeEvent(true);
/*     */       b++; }
/*     */   
/*     */   }
/*     */   
/*     */   void adjustWidth(boolean all) {
/* 363 */     boolean visible = getBaseTable().isAdjustWidthOnlyVisibleRow();
/* 364 */     int count = getBaseTable().getAdjustWidthRowCount();
/*     */ 
/*     */     
/* 367 */     getFixedColumnLayoutTable().getColumnModel().adjustWidth(
/* 368 */         all, visible, count);
/*     */     
/* 370 */     getColumnModel().adjustWidth(all, visible, count);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int rowAtPoint(Point point) {
/* 388 */     Point p = new Point(point);
/* 389 */     int tier = getTierCount();
/* 390 */     p.y /= tier;
/* 391 */     return super.rowAtPoint(p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int columnAtPoint(Point point) {
/* 402 */     int pos = 0;
/* 403 */     int x = 0;
/* 404 */     int y = 0;
/*     */     
/* 406 */     int row = rowAtPoint(point);
/* 407 */     if (row < 0) {
/* 408 */       return -1;
/*     */     }
/* 410 */     int tiercnt = getTierCount();
/* 411 */     for (int i = 0; i < row; i++) {
/* 412 */       y += getRowHeight(i) * tiercnt;
/*     */     }
/* 414 */     point.y -= y;
/* 415 */     if (point.y < 0) {
/* 416 */       point.y = 0;
/*     */     }
/*     */     
/* 419 */     int height = getRowHeight(row);
/*     */     
/* 421 */     MCLayoutTableColumnModel cm = getColumnModel();
/* 422 */     Iterator<MCColumnLayoutMember> iterator = 
/* 423 */       cm.createLayoutMemberIterator();
/* 424 */     while (iterator.hasNext()) {
/* 425 */       MCColumnLayoutMember member = iterator.next();
/* 426 */       if (member instanceof MCColumnLayout) {
/* 427 */         MCColumnLayout l = (MCColumnLayout)member;
/* 428 */         int lw = l.getWidth();
/* 429 */         if (x + lw > point.x) {
/*     */           
/* 431 */           Point p = point.getLocation();
/* 432 */           p.x -= x;
/* 433 */           pos += l.columnAtPoint(p, height * tiercnt, height);
/*     */           break;
/*     */         } 
/* 436 */         x += lw;
/* 437 */         pos += l.getAllColumnCount(); continue;
/*     */       } 
/* 439 */       if (member instanceof MCTableColumn) {
/* 440 */         x += ((MCTableColumn)member).getWidth();
/* 441 */         if (x > point.x) {
/*     */           break;
/*     */         }
/*     */ 
/*     */         
/* 446 */         pos++;
/*     */       } 
/*     */     } 
/*     */     
/* 450 */     return (cm.getColumnCount() > pos) ? pos : -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Rectangle getCellRect(int row, int column, boolean includeSpacing) {
/* 461 */     Rectangle r = new Rectangle();
/* 462 */     boolean valid = true;
/* 463 */     int tier = getTierCount();
/*     */     
/* 465 */     if (row < 0) {
/*     */       
/* 467 */       valid = false;
/*     */     }
/* 469 */     else if (row >= getRowCount()) {
/* 470 */       r.y = getHeight();
/* 471 */       valid = false;
/*     */     } else {
/*     */       
/* 474 */       r.height = getRowHeight(row) * tier;
/* 475 */       SizeSequence rowModel = getRowModel();
/* 476 */       r.y = (rowModel == null) ? (row * r.height) : rowModel.getPosition(row);
/* 477 */       r.y *= tier;
/*     */     } 
/*     */     
/* 480 */     if (column < 0) {
/*     */       
/* 482 */       valid = false;
/*     */     }
/* 484 */     else if (column >= getColumnModel().getColumnCount()) {
/* 485 */       r.x = getWidth();
/*     */       
/* 487 */       valid = false;
/*     */     } else {
/*     */       
/* 490 */       int pos = 0;
/* 491 */       MCLayoutTableColumnModel cm = getColumnModel();
/* 492 */       Iterator<MCColumnLayoutMember> iterator = 
/* 493 */         cm.createLayoutMemberIterator();
/* 494 */       while (iterator.hasNext()) {
/* 495 */         MCColumnLayoutMember member = iterator.next();
/* 496 */         if (member instanceof MCColumnLayout) {
/* 497 */           MCColumnLayout l = (MCColumnLayout)member;
/* 498 */           int cnt = l.getAllColumnCount();
/* 499 */           if (pos + cnt > column) {
/*     */             
/* 501 */             MCTableColumn col = cm.getColumn(column);
/* 502 */             r = l.getCellRect(r, col, getRowHeight());
/*     */             break;
/*     */           } 
/* 505 */           r.x += l.getWidth();
/* 506 */           pos += cnt; continue;
/*     */         } 
/* 508 */         if (member instanceof MCTableColumn) {
/* 509 */           int w = ((MCTableColumn)member).getWidth();
/* 510 */           if (pos == column) {
/*     */             
/* 512 */             r.width = w;
/*     */             break;
/*     */           } 
/* 515 */           r.x += w;
/* 516 */           pos++;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 521 */     if (valid && !includeSpacing) {
/* 522 */       int rm = Math.min(getRowMargin(), r.height);
/* 523 */       int cm = Math.min(getColumnModel().getColumnMargin(), r.width);
/* 524 */       r.setBounds(r.x + cm / 2, r.y + rm / 2, r.width - cm, r.height - rm);
/*     */     } 
/* 526 */     return r;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doLayout() {
/* 545 */     TableColumn resizingColumn = getResizingColumn();
/* 546 */     if (resizingColumn == null) {
/* 547 */       setWidthsFromPreferredWidths(false);
/*     */     } else {
/*     */       
/* 550 */       int columnIndex = viewIndexForColumn(resizingColumn);
/* 551 */       int delta = getWidth() - getColumnModel().getTotalColumnWidth();
/* 552 */       accommodateDelta(columnIndex, delta);
/* 553 */       delta = getWidth() - getColumnModel().getTotalColumnWidth();
/* 554 */       if (delta != 0) {
/* 555 */         resizingColumn.setWidth(resizingColumn.getWidth() + delta);
/*     */       }
/* 557 */       setWidthsFromPreferredWidths(true);
/*     */     } 
/*     */ 
/*     */     
/* 561 */     layout();
/*     */   }
/*     */ 
/*     */   
/*     */   private TableColumn getResizingColumn() {
/* 566 */     return (this.tableHeader == null) ? 
/* 567 */       null : this.tableHeader.getResizingColumn();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int viewIndexForColumn(TableColumn aColumn) {
/* 581 */     TableColumnModel cm = getColumnModel();
/* 582 */     for (int column = 0; column < cm.getColumnCount(); column++) {
/* 583 */       if (cm.getColumn(column) == aColumn) {
/* 584 */         return column;
/*     */       }
/*     */     } 
/* 587 */     return -1;
/*     */   }
/*     */   
/*     */   private void accommodateDelta(int resizingColumnIndex, int delta) {
/* 591 */     final MCColumnLayoutMember[] ms = 
/* 592 */       getColumnModel().getLayoutMemberArray();
/* 593 */     int columnCount = ms.length;
/* 594 */     int to = columnCount;
/* 595 */     int from = 0;
/* 596 */     MCTableColumn col = getColumnModel().getColumn(resizingColumnIndex);
/* 597 */     for (int i = 0; i < ms.length; i++) {
/* 598 */       MCColumnLayoutMember m = ms[i];
/* 599 */       if (m instanceof MCColumnLayout) {
/* 600 */         if (((MCColumnLayout)m).contains(col)) {
/* 601 */           from = i;
/*     */           
/*     */           break;
/*     */         } 
/* 605 */       } else if (m instanceof MCTable && 
/* 606 */         m == col) {
/* 607 */         from = i;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*     */     
/* 613 */     switch (this.autoResizeMode) {
/*     */       case 1:
/* 615 */         from++;
/* 616 */         to = Math.min(from + 1, columnCount);
/*     */         break;
/*     */       case 2:
/* 619 */         from++;
/* 620 */         to = columnCount;
/*     */         break;
/*     */       case 3:
/* 623 */         from = columnCount - 1;
/* 624 */         to = from + 1;
/*     */         break;
/*     */       case 4:
/* 627 */         from = 0;
/* 628 */         to = columnCount;
/*     */         break;
/*     */ 
/*     */       
/*     */       default:
/*     */         return;
/*     */     } 
/*     */     
/* 636 */     final int start = from;
/* 637 */     final int end = to;
/* 638 */     Resizable3 r = new Resizable3() { public int getElementCount() {
/* 639 */           return end - start;
/*     */         } public int getLowerBoundAt(int i) {
/* 641 */           MCColumnLayoutMember m = ms[i + start];
/* 642 */           return m.getMinWidth();
/*     */         }
/*     */         public int getUpperBoundAt(int i) {
/* 645 */           MCColumnLayoutMember m = ms[i + start];
/* 646 */           return m.getMaxWidth();
/*     */         }
/*     */         public int getMidPointAt(int i) {
/* 649 */           MCColumnLayoutMember m = ms[i + start];
/* 650 */           return m.getWidth();
/*     */         }
/*     */         public void setSizeAt(int s, int i) {
/* 653 */           MCColumnLayoutMember m = ms[i + start];
/* 654 */           m.setWidth(s);
/*     */         } }
/*     */       ;
/*     */     
/* 658 */     int totalWidth = 0;
/* 659 */     for (int j = start; j < end; j++) {
/* 660 */       totalWidth += ms[j].getWidth();
/*     */     }
/*     */     
/* 663 */     adjustSizes((totalWidth + delta), r, false);
/*     */   }
/*     */   
/*     */   private void setWidthsFromPreferredWidths(final boolean inverse) {
/* 667 */     int totalWidth = getWidth();
/* 668 */     int totalPreferred = (getPreferredSize()).width;
/* 669 */     int target = !inverse ? totalWidth : totalPreferred;
/*     */     
/* 671 */     final MCColumnLayoutMember[] ms = 
/* 672 */       getColumnModel().getLayoutMemberArray();
/* 673 */     Resizable3 r = new Resizable3() { public int getElementCount() {
/* 674 */           return ms.length;
/*     */         } public int getLowerBoundAt(int i) {
/* 676 */           MCColumnLayoutMember m = ms[i];
/* 677 */           return m.getMinWidth();
/*     */         }
/*     */         public int getUpperBoundAt(int i) {
/* 680 */           MCColumnLayoutMember m = ms[i];
/* 681 */           return m.getMaxWidth();
/*     */         }
/*     */         public int getMidPointAt(int i) {
/* 684 */           MCColumnLayoutMember m = ms[i];
/* 685 */           if (!inverse) {
/* 686 */             return m.getPreferredWidth();
/*     */           }
/*     */           
/* 689 */           return m.getWidth();
/*     */         }
/*     */         
/*     */         public void setSizeAt(int s, int i) {
/* 693 */           MCColumnLayoutMember m = ms[i];
/* 694 */           if (!inverse) {
/* 695 */             m.setWidth(s);
/*     */           } else {
/*     */             
/* 698 */             m.setPreferredWidth(s);
/*     */           } 
/*     */         } }
/*     */       ;
/*     */     
/* 703 */     adjustSizes(target, r, inverse);
/*     */   }
/*     */   private void adjustSizes(long target, final Resizable3 r3, boolean inverse) {
/*     */     Resizable2 r2;
/* 707 */     int N = r3.getElementCount();
/* 708 */     long totalPreferred = 0L;
/* 709 */     for (int i = 0; i < N; i++) {
/* 710 */       totalPreferred += r3.getMidPointAt(i);
/*     */     }
/*     */ 
/*     */     
/* 714 */     if (((target < totalPreferred) ? true : false) == (inverse ? false : true)) {
/* 715 */       r2 = new Resizable2() {
/* 716 */           public int getElementCount() { return r3.getElementCount(); }
/* 717 */           public int getLowerBoundAt(int i) { return r3.getLowerBoundAt(i); }
/* 718 */           public int getUpperBoundAt(int i) { return r3.getMidPointAt(i); } public void setSizeAt(int newSize, int i) {
/* 719 */             r3.setSizeAt(newSize, i);
/*     */           }
/*     */         };
/*     */     } else {
/* 723 */       r2 = new Resizable2() {
/* 724 */           public int getElementCount() { return r3.getElementCount(); }
/* 725 */           public int getLowerBoundAt(int i) { return r3.getMidPointAt(i); }
/* 726 */           public int getUpperBoundAt(int i) { return r3.getUpperBoundAt(i); }
/* 727 */           public void setSizeAt(int newSize, int i) { r3.setSizeAt(newSize, i); }
/*     */         };
/*     */     } 
/* 730 */     adjustSizes(target, r2, !inverse);
/*     */   }
/*     */   
/*     */   private void adjustSizes(long target, Resizable2 r, boolean limitToRange) {
/* 734 */     long totalLowerBound = 0L;
/* 735 */     long totalUpperBound = 0L; int i;
/* 736 */     for (i = 0; i < r.getElementCount(); i++) {
/* 737 */       totalLowerBound += r.getLowerBoundAt(i);
/* 738 */       totalUpperBound += r.getUpperBoundAt(i);
/*     */     } 
/*     */     
/* 741 */     if (limitToRange) {
/* 742 */       target = Math.min(Math.max(totalLowerBound, target), totalUpperBound);
/*     */     }
/*     */     
/* 745 */     for (i = 0; i < r.getElementCount(); i++) {
/* 746 */       int newSize, lowerBound = r.getLowerBoundAt(i);
/* 747 */       int upperBound = r.getUpperBoundAt(i);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 752 */       if (totalLowerBound == totalUpperBound) {
/* 753 */         newSize = lowerBound;
/*     */       } else {
/*     */         
/* 756 */         double f = (target - totalLowerBound) / (totalUpperBound - totalLowerBound);
/* 757 */         newSize = (int)Math.round(lowerBound + f * (upperBound - lowerBound));
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 762 */       r.setSizeAt(newSize, i);
/* 763 */       target -= newSize;
/* 764 */       totalLowerBound -= lowerBound;
/* 765 */       totalUpperBound -= upperBound;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static interface Resizable2 {
/*     */     int getElementCount();
/*     */     
/*     */     int getLowerBoundAt(int param1Int);
/*     */     
/*     */     int getUpperBoundAt(int param1Int);
/*     */     
/*     */     void setSizeAt(int param1Int1, int param1Int2);
/*     */   }
/*     */   
/*     */   private static interface Resizable3 extends Resizable2 {
/*     */     int getMidPointAt(int param1Int);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCLayoutTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */