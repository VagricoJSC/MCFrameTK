/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.event.FocusListener;
/*     */ import java.awt.event.KeyEvent;
/*     */ import javax.swing.border.Border;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCButton;
/*     */ import mcframe.clientCore.beans.MCMode;
/*     */ import mcframe.clientCore.beans.MCResourceBeans;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.action.MCKeyActionManager;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.clientCore.event.MCEventInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCEditorButton
/*     */   extends MCButton
/*     */   implements MCEditorBeans
/*     */ {
/*     */   private static final String TYPE = "table.column.button";
/*     */   private MCColumnConfig _column;
/*     */   private MCTable<?> _table;
/*  56 */   private int _index = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCEditorButton(String name, MCColumnConfig column) {
/*  69 */     super(name);
/*  70 */     setColumnConfig(column);
/*  71 */     setTable(column.getBaseTable());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initBeans() {
/*  76 */     super.initBeans();
/*  77 */     setHorizontalAlignment(0);
/*  78 */     setFocusTraversalKeysEnabled(false);
/*  79 */     setBorder(MCCellUtil.DEFAULT_BORDER); byte b; int i; FocusListener[] arrayOfFocusListener;
/*  80 */     for (i = (arrayOfFocusListener = getFocusListeners()).length, b = 0; b < i; ) { FocusListener l = arrayOfFocusListener[b];
/*  81 */       removeFocusListener(l);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initKeyAssign() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initResource() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getType() {
/* 105 */     return "table.column.button";
/*     */   }
/*     */ 
/*     */   
/*     */   public void transferFocus() {
/* 110 */     MCTable<?> t = getTable();
/* 111 */     t.transferFocus(getRowIndex(), t.getViewColumn(getColumnConfig()) + 1, 
/* 112 */         false, true, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCRootPanel getRootPanel() {
/* 117 */     return MCCellUtil.getRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCRootPanel getNearestRootPanel() {
/* 122 */     return MCCellUtil.getNearestRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessageByLocale() {
/* 127 */     return getColumnConfig().getMessageByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLabelByLocale() {
/* 132 */     return getColumnConfig().getLabelByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public Border getDefaultBorder() {
/* 137 */     return MCCellUtil.DEFAULT_BORDER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setRowIndex(int index) {
/* 146 */     this._index = index;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getRowIndex() {
/* 151 */     return this._index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void valueCommited() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setColumnConfig(MCColumnConfig column) {
/* 171 */     this._column = column;
/*     */   }
/*     */   
/*     */   public final MCColumnConfig getColumnConfig() {
/* 175 */     return this._column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setTable(MCTable<?> table) {
/* 186 */     this._table = table;
/*     */   }
/*     */   
/*     */   public final MCTable<?> getTable() {
/* 190 */     return this._table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doCheckValueError() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setColumnInfo(int index, MCColumnConfig column) {
/* 211 */     setColumnConfig(column);
/* 212 */     setRowIndex(index);
/* 213 */     MCTable<?> table = getTable();
/* 214 */     MCKeyActionManager.init((MCResourceBeans)this, getInputMap(), getActionMap());
/* 215 */     MCKeyActionManager.initScreen((MCResourceBeans)this, getInputMap(), getActionMap());
/* 216 */     MCMode mode = MCCellUtil.isCellEditable(index, column, table);
/* 217 */     setMode(mode);
/* 218 */     setForeground(MCCellUtil.getForeground(index, column, table, false, mode));
/* 219 */     setBackground(MCCellUtil.getBackground(index, column, table, false, mode));
/* 220 */     setFont(column.getFont());
/* 221 */     MCCellConfig conf = column.getCellConfig();
/* 222 */     setText(conf.getButtonColumnValue(index, column, table, false));
/* 223 */     setIcon(conf.getButtonColumnIcon(index, column, table, false));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFocusOwner() {
/* 228 */     MCTable<?> t = getTable();
/* 229 */     return (t != null) ? (
/* 230 */       t.isRemoveNotifyProcessing() ? super.isFocusOwner() : false) : 
/* 231 */       super.isFocusOwner();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isMCFocusOwner() {
/* 236 */     MCTable<?> t = getTable();
/* 237 */     return (t != null) ? ((t.getMCEditorComponent() == this)) : isFocusOwner();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCEventInfo getEventInfo() {
/* 242 */     return getColumnConfig().getEventInfo();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNE() {
/* 247 */     getColumnConfig().doNE();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNX() {
/* 252 */     getColumnConfig().doNX();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doAP() {
/* 257 */     getColumnConfig().doAP();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void focusGained() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void focusLost() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Border getBorder() {
/* 280 */     Border b = MCCellUtil.getBorder(this);
/* 281 */     return (b != null) ? b : super.getBorder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource(MCRootPanel panel) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterRequestFocus() {
/* 305 */     MCBeansUtil.afterRequestFocus(getTable());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void processKeyEvent(KeyEvent e) {
/* 310 */     MCCellUtil.beforeKeyEvent(e, this);
/* 311 */     super.processKeyEvent(e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCConstRow getBaseRow() {
/* 323 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCConstRow getRow() {
/* 335 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Comparable<?> getViewValue() {
/* 347 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValueChanged(Comparable<?> value) {
/* 359 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRowToView() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRowToViews() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean authorize() {
/* 382 */     MCColumnConfig c = getColumnConfig();
/* 383 */     return (c != null) ? c.authorize() : false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean checkAC() {
/* 388 */     MCColumnConfig c = getColumnConfig();
/* 389 */     return (c != null) ? c.checkAC() : false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean checkPassword() {
/* 394 */     MCColumnConfig c = getColumnConfig();
/* 395 */     return (c != null) ? c.checkPassword() : false;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getACType() {
/* 400 */     MCColumnConfig c = getColumnConfig();
/* 401 */     return (c != null) ? c.getACType() : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean needsPassword() {
/* 406 */     MCColumnConfig c = getColumnConfig();
/* 407 */     return (c != null) ? c.needsPassword() : false;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getAPMethodName() {
/* 412 */     MCColumnConfig c = getColumnConfig();
/* 413 */     return (c != null) ? c.getAPMethodName() : null;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public final void focusGainedSelect() {}
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCEditorButton.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */