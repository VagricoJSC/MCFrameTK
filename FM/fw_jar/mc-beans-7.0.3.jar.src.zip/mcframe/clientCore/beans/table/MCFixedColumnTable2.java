/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import javax.swing.SizeSequence;
/*     */ import javax.swing.table.JTableHeader;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCFixedColumnTable2<E extends MCConstRow>
/*     */   extends MCFixedColumnTable<E>
/*     */ {
/*     */   private static final String uiClassID = "MCTable2UI";
/*     */   
/*     */   public MCFixedColumnTable2(MCTable2<E> table, String name) {
/*  42 */     super(table, name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCTable2<E> getBodyTable2() {
/*  53 */     return (MCTable2<E>)getBodyTable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCFixedColumnTable2<E> getFixedColumnTable2() {
/*  64 */     return (MCFixedColumnTable2<E>)getFixedColumnTable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUIClassID() {
/*  72 */     return "MCTable2UI";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JTableHeader createDefaultTableHeader() {
/*  84 */     return new MCTable2Header(getColumnModel());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MCTable2Header getTableHeader() {
/*  90 */     return (MCTable2Header)super.getTableHeader();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setRenderers() {
/*  96 */     getTableHeader().setDefaultRenderer(
/*  97 */         new MCMultiLineHeaderRenderer(
/*  98 */           getTableHeader().getDefaultRenderer()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUnscrollColumn(MCColumnConfig column) {
/* 104 */     MCColumnConfig[] rets = getBodyTable2().removeAllReturnColumns();
/*     */     
/* 106 */     super.setUnscrollColumn(column);
/*     */ 
/*     */     
/* 109 */     getBodyTable2().addReturnColumn(rets);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int rowAtPoint(Point point) {
/* 122 */     Point p = new Point(point);
/* 123 */     int tier = getBodyTable2().getReturnCount();
/* 124 */     p.y /= tier;
/* 125 */     return super.rowAtPoint(p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Rectangle getCellRect(int row, int column, boolean includeSpacing) {
/* 136 */     TableColumnModel colmodel = getColumnModel();
/* 137 */     Rectangle r = new Rectangle();
/* 138 */     boolean valid = true;
/* 139 */     int retcnt = getBodyTable2().getReturnCount();
/*     */     
/* 141 */     if (row < 0) {
/*     */       
/* 143 */       valid = false;
/*     */     }
/* 145 */     else if (row >= getRowCount()) {
/* 146 */       r.y = getHeight();
/* 147 */       valid = false;
/*     */     } else {
/*     */       
/* 150 */       r.height = getRowHeight(row);
/* 151 */       r.height *= retcnt;
/* 152 */       SizeSequence rowModel = getRowModel();
/* 153 */       r.y = (rowModel == null) ? (row * r.height) : rowModel.getPosition(row);
/* 154 */       r.y *= retcnt;
/*     */     } 
/*     */     
/* 157 */     if (column < 0) {
/*     */       
/* 159 */       valid = false;
/*     */     }
/* 161 */     else if (column >= colmodel.getColumnCount()) {
/* 162 */       r.x = getWidth();
/*     */       
/* 164 */       valid = false;
/*     */     } else {
/*     */       
/* 167 */       for (int i = 0; i < column; i++) {
/* 168 */         r.x += colmodel.getColumn(i).getWidth();
/*     */       }
/* 170 */       r.width = colmodel.getColumn(column).getWidth();
/*     */     } 
/*     */     
/* 173 */     if (valid && !includeSpacing) {
/* 174 */       int rm = Math.min(getRowMargin(), r.height);
/* 175 */       int cm = Math.min(colmodel.getColumnMargin(), r.width);
/* 176 */       r.setBounds(r.x + cm / 2, r.y + rm / 2, r.width - cm, r.height - rm);
/*     */     } 
/* 178 */     return r;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCFixedColumnTable2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */