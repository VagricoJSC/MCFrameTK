/*    */ package mcframe.clientCore.beans.table;
/*    */ 
/*    */ import javax.swing.table.JTableHeader;
/*    */ import javax.swing.table.TableColumnModel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCColumnGroupTableHeader
/*    */   extends JTableHeader
/*    */ {
/*    */   private static final String uiClassID = "MCColumnGroupTableHeaderUI";
/*    */   
/*    */   public MCColumnGroupTableHeader(TableColumnModel model) {
/* 34 */     super(model);
/* 35 */     setReorderingAllowed(false);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getUIClassID() {
/* 44 */     return "MCColumnGroupTableHeaderUI";
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setReorderingAllowed(boolean b) {
/* 50 */     this.reorderingAllowed = false;
/*    */   }
/*    */ 
/*    */   
/*    */   public MCColumnGroupTableColumnModel getColumnModel() {
/* 55 */     return (MCColumnGroupTableColumnModel)super.getColumnModel();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MCTable<?> getMCTable() {
/* 69 */     return (MCTable)getTable();
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCColumnGroupTableHeader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */