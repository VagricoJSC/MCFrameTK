/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import javax.swing.table.TableColumn;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCColumnGroupTableColumnModel
/*     */   extends MCTableColumnModel
/*     */ {
/*  24 */   private List<MCColumnGroup> columnGroups = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addColumnGroup(MCColumnGroup g) {
/*  46 */     if (this.columnGroups == null) {
/*  47 */       this.columnGroups = new ArrayList<>();
/*     */     }
/*  49 */     this.columnGroups.add(g);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void addAllColumnGroup(Collection<MCColumnGroup> c) {
/*  62 */     if (this.columnGroups == null) {
/*  63 */       this.columnGroups = new ArrayList<>();
/*     */     }
/*  65 */     this.columnGroups.addAll(c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setAllColumnGroup(Collection<MCColumnGroup> c) {
/*  86 */     clearColumnGroup();
/*  87 */     addAllColumnGroup(c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   List<MCColumnGroup> clearColumnGroup() {
/*  98 */     List<MCColumnGroup> old = this.columnGroups;
/*  99 */     this.columnGroups = null;
/* 100 */     return old;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCColumnGroup[] getAllColumnGroups() {
/* 114 */     List<MCColumnGroup> g = new ArrayList<>();
/* 115 */     if (this.columnGroups != null) {
/* 116 */       int size = this.columnGroups.size();
/* 117 */       for (int i = 0; i < size; i++) {
/* 118 */         MCColumnGroup cg = this.columnGroups.get(i);
/* 119 */         g.add(cg);
/* 120 */         MCColumnGroup[] cgs = cg.getAllColumnGroups(); byte b; int j; MCColumnGroup[] arrayOfMCColumnGroup1;
/* 121 */         for (j = (arrayOfMCColumnGroup1 = cgs).length, b = 0; b < j; ) { MCColumnGroup c = arrayOfMCColumnGroup1[b];
/* 122 */           g.add(c); b++; }
/*     */       
/*     */       } 
/*     */     } 
/* 126 */     return g.<MCColumnGroup>toArray(new MCColumnGroup[g.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCColumnGroup[] getColumnGroups() {
/* 140 */     List<MCColumnGroup> g = new ArrayList<>();
/* 141 */     if (this.columnGroups != null) {
/* 142 */       int size = this.columnGroups.size();
/* 143 */       for (int i = 0; i < size; i++) {
/* 144 */         MCColumnGroup cg = this.columnGroups.get(i);
/* 145 */         g.add(cg);
/*     */       } 
/*     */     } 
/* 148 */     return g.<MCColumnGroup>toArray(new MCColumnGroup[g.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCColumnGroup[] getColumnGroups(TableColumn col) {
/* 161 */     if (this.columnGroups == null) {
/* 162 */       return new MCColumnGroup[0];
/*     */     }
/* 164 */     int size = this.columnGroups.size();
/* 165 */     for (int i = 0; i < size; i++) {
/* 166 */       MCColumnGroup cGroup = this.columnGroups.get(i);
/* 167 */       List<MCColumnGroup> ret = cGroup.getColumnGroups(col, null);
/* 168 */       if (ret != null) {
/* 169 */         return ret.<MCColumnGroup>toArray(new MCColumnGroup[ret.size()]);
/*     */       }
/*     */     } 
/* 172 */     return new MCColumnGroup[0];
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCColumnGroupTableColumnModel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */