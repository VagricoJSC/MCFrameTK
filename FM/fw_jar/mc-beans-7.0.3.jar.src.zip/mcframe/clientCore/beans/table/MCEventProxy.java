/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import mcframe.clientCore.event.AbsMCPackageProxy;
/*     */ import mcframe.clientCore.event.MCEventBeans;
/*     */ import mcframe.clientCore.event.MCEventInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MCEventProxy
/*     */   extends AbsMCPackageProxy
/*     */ {
/*  30 */   static final MCEventProxy PROXY = new MCEventProxy();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setValue(MCEventInfo info, Comparable<?> value) {
/*  41 */     setValue(info, value, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setValue(MCEventInfo info, Comparable<?> before, Comparable<?> after) {
/*  55 */     super.setValue(info, before, after);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setColumn(MCEventInfo info, MCColumnConfig column) {
/*  67 */     setColumn(info, column, column);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setColumn(MCEventInfo info, MCColumnConfig before, MCColumnConfig after) {
/*  82 */     super.setColumn(info, before, after);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setIndex(MCEventInfo info, int index) {
/*  94 */     setIndex(info, index, index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setIndex(MCEventInfo info, int before, int after) {
/* 108 */     super.setIndex(info, before, after);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setClickColumn(MCEventInfo info, MCColumnConfig column) {
/* 121 */     super.setClickColumn(info, column);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setEventIndex(MCEventInfo info, int index) {
/* 134 */     super.setEventIndex(info, index);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setComponent(MCEventInfo info, MCEventBeans compo) {
/* 147 */     super.setComponent(info, compo);
/*     */   }
/*     */   
/*     */   void setColumn(MCEventInfo from, MCEventInfo to) {
/* 151 */     setColumn(to, from.getOldColumn(), from.getNewColumn());
/*     */   }
/*     */   
/*     */   void setIndex(MCEventInfo from, MCEventInfo to) {
/* 155 */     setIndex(to, from.getOldIndex(), from.getNewIndex());
/*     */   }
/*     */   
/*     */   void setEventIndex(MCEventInfo from, MCEventInfo to) {
/* 159 */     setEventIndex(to, from.getEventIndex());
/*     */   }
/*     */   
/*     */   void setClickColumnInfo(MCEventInfo from, MCEventInfo to) {
/* 163 */     super.setClickColumn(to, from.getClickColumn());
/* 164 */     super.setClickIndex(to, from.getClickIndex());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setListIndex(MCEventInfo info, int index) {
/* 176 */     setListIndex(info, index, index);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setClickIndex(MCEventInfo info, int index) {
/* 181 */     super.setClickIndex(info, index);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCEventProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */