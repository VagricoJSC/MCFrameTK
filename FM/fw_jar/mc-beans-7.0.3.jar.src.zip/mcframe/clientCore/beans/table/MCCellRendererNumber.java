/*    */ package mcframe.clientCore.beans.table;
/*    */ 
/*    */ import java.math.RoundingMode;
/*    */ import mcframe.clientCore.beans.MCMode;
/*    */ import mcframe.clientCore.beans.text.MCNumberFormat;
/*    */ import mcframe.clientCore.beans.text.MCNumberPattern;
/*    */ import mcframe.commonCore.lang.MCNumber;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCCellRendererNumber
/*    */   extends MCCellRendererField
/*    */ {
/*    */   protected MCCellRendererNumber(MCColumnConfig column) {
/* 28 */     super(column);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void setValue(Object value) {
/* 33 */     MCColumnConfig col = getColumnConfig();
/*    */ 
/*    */     
/* 36 */     MCCellConfig cfg = col.getCellConfig();
/* 37 */     int index = getRowIndex();
/* 38 */     MCTable<?> table = col.getTable();
/* 39 */     MCMode mode = cfg.isCellEditable(index, col, table);
/*    */     
/* 41 */     int scale = cfg.getCellViewScale(index, col, table);
/*    */     
/* 43 */     MCNumberFormat cf = cfg.getCellNumberFormat(index, col, table, mode);
/*    */     
/* 45 */     MCNumber v = (MCNumber)value;
/* 46 */     if (v != null) {
/*    */       
/* 48 */       v = v.multiply(cf.getOutputMultiplier());
/* 49 */       int s = v.scale();
/* 50 */       if (s > scale) {
/* 51 */         RoundingMode m = cfg.getCellViewRoundingMode(index, col, table);
/* 52 */         if (m != null) {
/* 53 */           v = v.setScale(scale, m);
/*    */         }
/*    */       } 
/* 56 */       v = v.divide(cf.getOutputMultiplier());
/*    */     } 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 67 */     MCNumberPattern cp = cf.getNumberPattern();
/* 68 */     MCNumberPattern p = MCNumberPattern.create(cp.getID(), cp.getInputPattern(), 
/* 69 */         cp.getOutputPattern(), cp.getPositiveForeground(), 
/* 70 */         cp.getNegativeForeground(), cp.getDecimalSeparator(), 
/* 71 */         cp.getGroupingSeparator(), cfg.getCellViewZeroType(index, col, table));
/*    */     try {
/* 73 */       cf.setNumberPattern(p);
/* 74 */       super.setValue(cf.doOutputFormat(v, scale));
/*    */     } finally {
/*    */       
/* 77 */       cf.setNumberPattern(cp);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCCellRendererNumber.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */