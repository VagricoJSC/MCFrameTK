package mcframe.clientCore.beans.table;

import javax.swing.border.Border;
import mcframe.clientCore.beans.MCBeans;
import mcframe.clientCore.container.MCConstRow;

public interface MCEditorBeans extends MCBeans {
  boolean isValueChanged(Comparable<?> paramComparable);
  
  Comparable<?> getViewValue();
  
  MCTable getTable();
  
  MCColumnConfig getColumnConfig();
  
  int getRowIndex();
  
  void valueCommited();
  
  void setRowToView();
  
  void setRowToViews();
  
  MCConstRow getRow();
  
  MCConstRow getBaseRow();
  
  Border getDefaultBorder();
  
  void doCheckValueError();
  
  @Deprecated
  void focusGainedSelect();
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCEditorBeans.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */