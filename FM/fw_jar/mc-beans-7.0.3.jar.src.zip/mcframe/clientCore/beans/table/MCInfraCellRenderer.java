package mcframe.clientCore.beans.table;

import javax.swing.table.TableCellRenderer;

interface MCInfraCellRenderer extends TableCellRenderer {
  Comparable<?> getValue();
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCInfraCellRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */