/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import javax.swing.table.JTableHeader;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCFixedColumnGroupTable<E extends MCConstRow>
/*     */   extends MCFixedColumnTable<E>
/*     */ {
/*     */   public MCFixedColumnGroupTable(MCColumnGroupTable<E> table, String name) {
/*  29 */     super(table, name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCColumnGroup[] getAllColumnGroups() {
/*  44 */     return getColumnModel().getAllColumnGroups();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCColumnGroupTable<E> getBodyColumnGroupTable() {
/*  63 */     return (MCColumnGroupTable<E>)getBodyTable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCFixedColumnGroupTable<E> getFixedColumnGroupTable() {
/*  82 */     return (MCFixedColumnGroupTable<E>)getFixedColumnTable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getColumnLabelByLocale(MCColumnConfig column) {
/* 107 */     MCColumnGroupTable<E> body = getBodyColumnGroupTable();
/*     */     
/* 109 */     return body.getColumnLabelByLocale(column);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getColumnMessageByLocale(MCColumnConfig column) {
/* 135 */     MCColumnGroupTable<E> body = getBodyColumnGroupTable();
/*     */     
/* 137 */     return body.getColumnMessageByLocale(column);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JTableHeader createDefaultTableHeader() {
/* 152 */     return new MCColumnGroupTableHeader(getColumnModel());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MCColumnGroupTableHeader getTableHeader() {
/* 158 */     return (MCColumnGroupTableHeader)super.getTableHeader();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCColumnGroupTableColumnModel createDefaultColumnModel() {
/* 164 */     return new MCColumnGroupTableColumnModel();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MCColumnGroupTableColumnModel getColumnModel() {
/* 170 */     return (MCColumnGroupTableColumnModel)super.getColumnModel();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setRenderers() {
/* 176 */     getTableHeader().setDefaultRenderer(
/* 177 */         new MCMultiLineHeaderRenderer(
/* 178 */           getTableHeader().getDefaultRenderer()));
/*     */   }
/*     */ 
/*     */   
/*     */   void updateColumnsFontSize(int fontratio, int widthratio, boolean check) {
/* 183 */     super.updateColumnsFontSize(fontratio, widthratio, check);
/*     */ 
/*     */     
/* 186 */     MCColumnGroup[] cgs = getAllColumnGroups(); byte b; int i; MCColumnGroup[] arrayOfMCColumnGroup1;
/* 187 */     for (i = (arrayOfMCColumnGroup1 = cgs).length, b = 0; b < i; ) { MCColumnGroup cg = arrayOfMCColumnGroup1[b];
/* 188 */       cg.getColumn().updateFontSize(fontratio, widthratio, check);
/*     */       b++; }
/*     */   
/*     */   }
/*     */   
/*     */   void initColumns() {
/* 194 */     super.initColumns();
/*     */ 
/*     */     
/* 197 */     MCColumnGroup[] cgs = getAllColumnGroups(); byte b; int i; MCColumnGroup[] arrayOfMCColumnGroup1;
/* 198 */     for (i = (arrayOfMCColumnGroup1 = cgs).length, b = 0; b < i; ) { MCColumnGroup cg = arrayOfMCColumnGroup1[b];
/* 199 */       cg.getColumn().initialized();
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public void setUnscrollColumn(MCColumnConfig column) {
/* 206 */     column = getBodyColumnGroupTable().setUnscrollColumnGroup(column);
/*     */     
/* 208 */     super.setUnscrollColumn(column);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void adjustWidth(MCTableColumn column) {
/* 216 */     getBodyColumnGroupTable().adjustWidth(column);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCFixedColumnGroupTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */