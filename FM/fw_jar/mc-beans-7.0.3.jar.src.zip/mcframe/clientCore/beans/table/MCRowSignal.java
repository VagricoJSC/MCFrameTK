/*     */ package mcframe.clientCore.beans.table;
/*     */ import java.net.URL;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import javax.swing.ImageIcon;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.container.MCRowFilter;
/*     */ import mcframe.commonCore.container.MCRowFilterList;
/*     */ import mcframe.commonCore.lang.MCDate;
/*     */ 
/*     */ public class MCRowSignal {
/*     */   public static final int NONE = 0;
/*     */   public static final int SAFETY = 1;
/*     */   public static final int CAUTION = 2;
/*     */   public static final int DANGER = 3;
/*     */   public static final String EQUAL = "EQUAL";
/*     */   public static final String NOT_EQUAL = "NOT_EQUAL";
/*     */   public static final String GREATER_THAN = "GREATER_THAN";
/*     */   public static final String GREATER_THAN_EQUAL = "GREATER_THAN_EQUAL";
/*     */   public static final String LESS_THAN = "LESS_THAN";
/*     */   public static final String LESS_THAN_EQUAL = "LESS_THAN_EQUAL";
/*     */   public static final String CONTAINS = "CONTAINS";
/*     */   public static final String NOT_CONTAINS = "NOT_CONTAINS";
/*     */   public static final String START_WITH = "START_WITH";
/*     */   public static final String NOT_START_WITH = "NOT_START_WITH";
/*     */   public static final String END_WITH = "END_WITH";
/*     */   public static final String NOT_END_WITH = "NOT_END_WITH";
/*     */   public static final String AND = "AND";
/*     */   public static final String OR = "OR";
/*     */   
/*     */   public static ImageIcon geIcon(int signal) {
/*  34 */     String key = null;
/*  35 */     switch (signal) {
/*     */       case 3:
/*  37 */         key = "rowsignal.danger.icon";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  49 */         return getImageIcon(key);case 2: key = "rowsignal.caution.icon"; return getImageIcon(key);case 1: key = "rowsignal.safety.icon"; return getImageIcon(key);
/*     */     } 
/*     */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static ImageIcon getImageIcon(String key) {
/*  63 */     String reskey = MCConst.createKey(new String[] { "table", key });
/*  64 */     String path = MCConst.beans.getString(reskey);
/*  65 */     if (path == null) {
/*  66 */       return null;
/*     */     }
/*  68 */     URL url = MCRowSignal.class.getResource(path);
/*  69 */     if (url == null) {
/*  70 */       return null;
/*     */     }
/*  72 */     return new ImageIcon(url);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int[] signalArray() {
/* 115 */     return new int[] {
/* 116 */         0, 1, 2, 3
/*     */       };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 211 */   private MCRowFilterList<MCRowFilter> _safety = new MCRowFilterList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 218 */   private MCRowFilterList<MCRowFilter> _caution = new MCRowFilterList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 225 */   private MCRowFilterList<MCRowFilter> _danger = new MCRowFilterList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCRowFilter createCondition() {
/* 242 */     return new MCRowFilter();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isActive() {
/* 256 */     MCRowFilterList[] lists = {
/* 257 */         this._safety, this._caution, this._danger }; byte b; int i;
/*     */     MCRowFilterList[] arrayOfMCRowFilterList1;
/* 259 */     for (i = (arrayOfMCRowFilterList1 = lists).length, b = 0; b < i; ) { MCRowFilterList<?> list = arrayOfMCRowFilterList1[b];
/* 260 */       if (list.isEnabled())
/* 261 */         return true; 
/*     */       b++; }
/*     */     
/* 264 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 274 */     this._safety.clear();
/* 275 */     this._caution.clear();
/* 276 */     this._danger.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEmpty() {
/* 287 */     return (this._safety.isEmpty() && this._caution.isEmpty() && this._danger.isEmpty());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addAll(MCRowSignal signal) {
/* 298 */     this._safety.addAll((Collection)signal._safety);
/* 299 */     this._caution.addAll((Collection)signal._caution);
/* 300 */     this._danger.addAll((Collection)signal._danger);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean addCondition(int signal, MCRowFilter cond) {
/* 351 */     if (cond == null) {
/* 352 */       return false;
/*     */     }
/* 354 */     switch (signal) {
/*     */       case 1:
/* 356 */         this._safety.add(cond);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 367 */         return true;case 2: this._caution.add(cond); return true;case 3: this._danger.add(cond); return true;
/*     */     } 
/*     */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<MCRowFilter> getConditionList(int signal) {
/* 402 */     switch (signal) {
/*     */       case 3:
/* 404 */         return (List<MCRowFilter>)this._danger;
/*     */       case 2:
/* 406 */         return (List<MCRowFilter>)this._caution;
/*     */       case 1:
/* 408 */         return (List<MCRowFilter>)this._safety;
/*     */     } 
/*     */ 
/*     */     
/* 412 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSignal(MCRow row, MCList<? extends MCRow> aggregation, MCDate codate) {
/* 427 */     MCList<? extends MCRow> mCList = aggregation;
/*     */     
/* 429 */     this._danger.setCoDate(codate);
/* 430 */     this._danger.setAggregateList(mCList);
/* 431 */     if (this._danger.match(row)) {
/* 432 */       return 3;
/*     */     }
/* 434 */     this._caution.setCoDate(codate);
/* 435 */     this._caution.setAggregateList(mCList);
/* 436 */     if (this._caution.match(row)) {
/* 437 */       return 2;
/*     */     }
/* 439 */     this._safety.setCoDate(codate);
/* 440 */     this._safety.setAggregateList(mCList);
/* 441 */     if (this._safety.match(row)) {
/* 442 */       return 1;
/*     */     }
/* 444 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <E extends MCRow> MCList<E> subList(MCList<E> list, MCDate codate, int signal) {
/* 462 */     return subList(list, list, codate, signal);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <E extends MCRow> MCList<E> subList(MCList<E> list, MCList<E> aggregation, MCDate codate, int signal) {
/* 482 */     MCList<E> sl = list.createInstance();
/* 483 */     for (MCRow mCRow : list) {
/* 484 */       if (getSignal(mCRow, aggregation, codate) == signal) {
/* 485 */         sl.add(mCRow);
/*     */       }
/*     */     } 
/* 488 */     return sl;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCRowSignal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */