/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.table.TableCellRenderer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCCellRendererCheckBox
/*     */   extends JCheckBox
/*     */   implements TableCellRenderer
/*     */ {
/*     */   private final MCColumnConfig _column;
/*  36 */   private Border _default_border = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCCellRendererCheckBox(MCColumnConfig column) {
/*  47 */     this._column = column;
/*  48 */     setOpaque(true);
/*  49 */     setDoubleBuffered(true);
/*  50 */     setHorizontalAlignment(0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCColumnConfig getColumnConfig() {
/*  61 */     return this._column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setDefaultBorder(Border border) {
/*  73 */     this._default_border = border;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Border getDefaultBorder() {
/*  89 */     return this._default_border;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Component getTableCellRendererComponent(JTable table, Object value, boolean selected, boolean focused, int index, int column) {
/* 108 */     MCTable<?> t = (MCTable)table;
/* 109 */     boolean f = focused ? focused : MCCellUtil.hasFocus(t, index, column);
/* 110 */     return getRenderer(t, value, selected, f, index, getColumnConfig());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Component getRenderer(MCTable<?> table, Object value, boolean selected, boolean focused, int index, MCColumnConfig column) {
/* 128 */     int horizontal = column.getHorizontalAlignment();
/* 129 */     if (horizontal == -1) {
/* 130 */       horizontal = 0;
/*     */     }
/* 132 */     setHorizontalAlignment(horizontal);
/* 133 */     Border def_border = getDefaultBorder();
/* 134 */     if (def_border == null) {
/* 135 */       setDefaultBorder(getBorder());
/*     */     }
/* 137 */     MCCellUtil.initRenderer(this, index, column, table, selected, focused, 
/* 138 */         getDefaultBorder());
/*     */     
/* 140 */     setBorderPainted((getBorder() != null && getBorder() != getDefaultBorder()));
/* 141 */     setSelected(((Boolean)value).booleanValue());
/* 142 */     Color bg = getBackground();
/* 143 */     setOpaque(!(bg != null && bg.equals(table.getBackground()) && table.isOpaque()));
/* 144 */     setIcon(column.getIcon());
/* 145 */     setSelectedIcon(column.getSelectedIcon());
/* 146 */     setPressedIcon(column.getPressedIcon());
/* 147 */     setDisabledIcon(column.getDisabledIcon());
/* 148 */     setDisabledSelectedIcon(column.getDisabledSelectedIcon());
/* 149 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRatio() {
/* 160 */     return this._column.getBaseTable().getRatio();
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCCellRendererCheckBox.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */