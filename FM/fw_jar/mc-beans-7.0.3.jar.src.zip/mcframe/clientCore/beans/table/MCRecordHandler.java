/*      */ package mcframe.clientCore.beans.table;
/*      */ 
/*      */ import java.awt.Toolkit;
/*      */ import java.awt.datatransfer.StringSelection;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import javax.swing.event.ChangeEvent;
/*      */ import mcframe.clientCore.beans.MCBeansUtil;
/*      */ import mcframe.clientCore.container.MCConstRow;
/*      */ import mcframe.clientCore.event.MCEventInfo;
/*      */ import mcframe.commonCore.container.MCList;
/*      */ import mcframe.commonCore.container.MCRow;
/*      */ import mcframe.commonCore.lang.MCCalendarDate;
/*      */ import mcframe.commonCore.lang.MCNumber;
/*      */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MCRecordHandler
/*      */ {
/*      */   protected <E extends MCConstRow> E insertRow(MCTable<E> table) {
/*   51 */     return insertRow(table, getInsertIndex(table));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <E extends MCConstRow> E insertRow(MCTable<E> table, int index) {
/*   68 */     return insertRowToBaseTable(table, index, null, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <E extends MCConstRow> E insertRowLast(MCTable<E> table) {
/*   83 */     return (table != null) ? insertRow(table, table.getRowCount()) : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <E extends MCConstRow> E insertRowNoFocus(MCTable<E> table) {
/*   98 */     return insertRowNoFocus(table, getInsertIndex(table));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <E extends MCConstRow> E insertRowNoFocus(MCTable<E> table, int index) {
/*  114 */     return insertRowToBaseTable(table, index, null, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <E extends MCConstRow> E insertRowLastNoFocus(MCTable<E> table) {
/*  129 */     return (table != null) ? insertRowNoFocus(table, table.getRowCount()) : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <E extends MCConstRow> void insertRow(MCTable<E> table, E row) {
/*  145 */     insertRow(table, getInsertIndex(table), row);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <E extends MCConstRow> void insertRow(MCTable<E> table, int index, E row) {
/*  162 */     insertRowToBaseTable(table, index, row, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <E extends MCConstRow> void insertRowLast(MCTable<E> table, E row) {
/*  177 */     if (table != null) {
/*  178 */       insertRow(table, table.getRowCount(), row);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <E extends MCConstRow> void insertRowNoFocus(MCTable<E> table, E row) {
/*  194 */     insertRowNoFocus(table, getInsertIndex(table), row);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <E extends MCConstRow> void insertRowNoFocus(MCTable<E> table, int index, E row) {
/*  211 */     insertRowToBaseTable(table, index, row, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <E extends MCConstRow> void insertRowLastNoFocus(MCTable<E> table, E row) {
/*  226 */     if (table != null) {
/*  227 */       insertRowNoFocus(table, table.getRowCount(), row);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <E extends MCConstRow> E insertRowToBaseTable(MCTable<E> table, int index, E row, boolean focus) {
/*  250 */     if (table == null) {
/*  251 */       return null;
/*      */     }
/*  253 */     if (!checkInsertIndex(table, index)) {
/*  254 */       throw MCBeansUtil.createExForLog(table, Core_Msg_FW_A.FCBAC0123, new Object[] { Integer.valueOf(index), Integer.valueOf(table.getRowCount()) });
/*      */     }
/*  256 */     table.getModel()
/*  257 */       .insertRow(index, (row != null) ? row : table.getList().createRow());
/*  258 */     selectRow(table.getBaseTable(), index, focus);
/*  259 */     return table.getRow(index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <E extends MCConstRow> E deleteRow(MCTable<E> table) {
/*  292 */     if (table == null) {
/*  293 */       return null;
/*      */     }
/*  295 */     int i = getDeleteIndex(table);
/*  296 */     return (i != -1) ? deleteRow(table, i) : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <E extends MCConstRow> E deleteRow(MCTable<E> table, int index) {
/*  330 */     return deleteRowToBaseTable(table, index, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <E extends MCConstRow> E deleteRowLast(MCTable<E> table) {
/*  362 */     return deleteRow(table, table.getRowCount() - 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <E extends MCConstRow> E deleteRowNoFocus(MCTable<E> table) {
/*  395 */     if (table != null) {
/*  396 */       int i = getDeleteIndex(table);
/*  397 */       return (i != -1) ? deleteRowNoFocus(table, i) : null;
/*      */     } 
/*  399 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <E extends MCConstRow> E deleteRowNoFocus(MCTable<E> table, int index) {
/*  433 */     return deleteRowToBaseTable(table, index, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <E extends MCConstRow> E deleteRowLastNoFocus(MCTable<E> table) {
/*  465 */     return deleteRowNoFocus(table, table.getRowCount() - 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <E extends MCConstRow> E deleteRowToBaseTable(MCTable<E> table, int index, boolean focus) {
/*  528 */     if (table == null) {
/*  529 */       return null;
/*      */     }
/*  531 */     MCTable<? extends MCConstRow> bt = table.getBaseTable();
/*  532 */     MCList<? extends MCConstRow> l = bt.getList();
/*  533 */     if (l == null) {
/*  534 */       throw MCBeansUtil.createExForLog(table, Core_Msg_FW_A.FCBAC0126, new Object[0]);
/*      */     }
/*  536 */     if (!checkDeleteIndex(table, index)) {
/*  537 */       throw MCBeansUtil.createExForLog(table, Core_Msg_FW_A.FCBAC0125, new Object[] { Integer.valueOf(table.getRowCount()), Integer.valueOf(index) });
/*      */     }
/*  539 */     E e = table.getRow(index);
/*  540 */     int n = bt.getModel().deleteRow(index, (MCConstRow)l.get(index));
/*  541 */     int s = bt.getMCSelectedRow();
/*  542 */     E ne = table.getRow(index);
/*  543 */     if (bt.getRowCount() > 0) {
/*      */       
/*  545 */       if (s != n) {
/*  546 */         setEventIndex(table, s, n);
/*  547 */         selectRow(bt, n, focus);
/*      */ 
/*      */       
/*      */       }
/*  551 */       else if (e != ne) {
/*  552 */         setEventIndex(table, s, n);
/*  553 */         if (table.doVC()) {
/*  554 */           selectRow(bt, n, focus);
/*  555 */           table.doNC();
/*      */         } else {
/*      */           
/*  558 */           bt.mcRequestFocus();
/*      */         } 
/*      */       } else {
/*      */         
/*  562 */         selectRow(bt, n, focus);
/*      */       }
/*      */     
/*      */     }
/*  566 */     else if (focus) {
/*      */       
/*  568 */       if (s != n || e != ne) {
/*  569 */         setEventIndex(table, s, n);
/*  570 */         if (bt.doVC()) {
/*  571 */           bt.doNC();
/*      */         }
/*      */       } 
/*  574 */       bt.transferFocus();
/*      */     } 
/*  576 */     return e;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <E extends MCConstRow> MCList<E> deleteRows(MCTable<E> table) {
/*  608 */     return (table != null) ? deleteRows(table, table.getMCSelectedRows()) : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <E extends MCConstRow> MCList<E> deleteRows(MCTable<E> table, int... indexes) {
/*  654 */     return deleteRowsToBaseTable(table, indexes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <E extends MCConstRow> void deleteRows(MCTable<E> table, MCList<E> list) {
/*  698 */     deleteRowsToBaseTable(table, list);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <E extends MCConstRow> MCList<E> deleteRowsToBaseTable(MCTable<E> table, int... indexes) {
/*  744 */     if (table == null || indexes == null || indexes.length == 0) {
/*  745 */       return null;
/*      */     }
/*  747 */     MCList<E> list = table.getList().createInstance();
/*  748 */     int c = table.getRowCount(); byte b; int i, arrayOfInt[];
/*  749 */     for (i = (arrayOfInt = indexes).length, b = 0; b < i; ) { int j = arrayOfInt[b];
/*  750 */       if (j > -1 && j < c)
/*  751 */         list.add(table.getList().get(j)); 
/*      */       b++; }
/*      */     
/*  754 */     return deleteRowsToBaseTable(table, list);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <E extends MCConstRow> MCList<E> deleteRowsToBaseTable(MCTable<E> table, MCList<E> list) {
/*  804 */     if (table == null || list == null) {
/*  805 */       return null;
/*      */     }
/*  807 */     MCTable<? extends MCConstRow> bt = table.getBaseTable();
/*  808 */     if (bt.getList().size() == 0) {
/*  809 */       return null;
/*      */     }
/*  811 */     MCList<E> result = table.getList().createInstance();
/*  812 */     MCList del = bt.getList().createInstance();
/*  813 */     for (MCConstRow mCConstRow : list) {
/*  814 */       if (table.getList().contains(mCConstRow)) {
/*  815 */         result.add((MCRow)mCConstRow);
/*  816 */         del.add((MCRow)bt.getRow(mCConstRow.getGUIIndex()));
/*      */       } 
/*      */     } 
/*      */     
/*  820 */     int o = bt.getMCSelectedRow();
/*  821 */     MCRow oe = (MCRow)bt.getRow(o);
/*      */     
/*  823 */     int n = bt.getModel().deleteRows(del);
/*      */     
/*  825 */     MCRow ne = (MCRow)bt.getRow(n);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  830 */     setEventIndex(table, o, n);
/*      */ 
/*      */     
/*  833 */     if (bt.getViewRows().size() == 0) {
/*      */       
/*  835 */       if (bt.doVC()) {
/*  836 */         bt.doNC();
/*      */       }
/*  838 */       bt.transferFocus();
/*      */ 
/*      */     
/*      */     }
/*  842 */     else if (o != n) {
/*  843 */       bt.selectLeftmostColumn(n);
/*      */     }
/*  845 */     else if (oe != ne) {
/*  846 */       if (bt.doVC()) {
/*  847 */         bt.selectLeftmostColumn(n);
/*  848 */         bt.doNC();
/*      */       }
/*      */       else {
/*      */         
/*  852 */         bt.requestFocus();
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  858 */       bt.requestFocus();
/*      */     } 
/*      */ 
/*      */     
/*  862 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <E extends MCConstRow> E truncateRow(MCTable<E> table) {
/*  881 */     if (table == null) {
/*  882 */       return null;
/*      */     }
/*  884 */     int i = getDeleteIndex(table);
/*  885 */     return (i != -1) ? truncateRow(table, i) : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <E extends MCConstRow> E truncateRow(MCTable<E> table, int index) {
/*  905 */     return truncateRowToBaseTable(table, index, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <E extends MCConstRow> E truncateRowLast(MCTable<E> table) {
/*  923 */     return truncateRow(table, table.getRowCount() - 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <E extends MCConstRow> E truncateRowNoFocus(MCTable<E> table) {
/*  942 */     if (table == null) {
/*  943 */       return null;
/*      */     }
/*  945 */     int i = getDeleteIndex(table);
/*  946 */     return (i != -1) ? truncateRowNoFocus(table, i) : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <E extends MCConstRow> E truncateRowNoFocus(MCTable<E> table, int index) {
/*  966 */     return truncateRowToBaseTable(table, index, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <E extends MCConstRow> E truncateRowLastNoFocus(MCTable<E> table) {
/*  984 */     return truncateRowNoFocus(table, table.getRowCount() - 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <E extends MCConstRow> E truncateRowToBaseTable(MCTable<E> table, int index, boolean focus) {
/* 1017 */     if (table == null) {
/* 1018 */       return null;
/*      */     }
/* 1020 */     MCTable<? extends MCConstRow> bt = table.getBaseTable();
/* 1021 */     MCList<? extends MCConstRow> l = bt.getList();
/* 1022 */     if (l == null) {
/* 1023 */       throw MCBeansUtil.createExForLog(table, Core_Msg_FW_A.FCBAC0126, new Object[0]);
/*      */     }
/* 1025 */     if (!checkDeleteIndex(bt, index)) {
/* 1026 */       throw MCBeansUtil.createExForLog(table, Core_Msg_FW_A.FCBAC0125, new Object[] { Integer.valueOf(table.getRowCount()), Integer.valueOf(index) });
/*      */     }
/* 1028 */     E e = table.getRow(index);
/* 1029 */     bt.getModel().truncateRow(index);
/*      */ 
/*      */     
/* 1032 */     int cnt = bt.getViewRows().size();
/*      */ 
/*      */     
/* 1035 */     if (cnt > 0) {
/*      */       
/* 1037 */       int x = bt.getRowCount() - 1;
/* 1038 */       int n = Math.min(index, x);
/* 1039 */       boolean f = false;
/* 1040 */       while (n < x) {
/* 1041 */         if (bt.getRowHeight(n) > 0) {
/* 1042 */           f = true;
/*      */           break;
/*      */         } 
/* 1045 */         n++;
/*      */       } 
/* 1047 */       if (!f) {
/* 1048 */         n = Math.min(index, x);
/* 1049 */         while (n > -1) {
/* 1050 */           if (bt.getRowHeight(n) > 0) {
/* 1051 */             f = true;
/*      */             break;
/*      */           } 
/* 1054 */           n--;
/*      */         } 
/*      */       } 
/* 1057 */       if (!f) {
/* 1058 */         n = Math.min(index, x);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1065 */       setEventIndex(table, index, n);
/* 1066 */       if (bt.doVC()) {
/* 1067 */         selectRow(bt, n, focus);
/* 1068 */         bt.doNC();
/*      */       } 
/*      */     } else {
/*      */       
/* 1072 */       int n = -1;
/*      */       
/* 1074 */       if (index != n) {
/* 1075 */         setEventIndex(table, index, n);
/* 1076 */         if (bt.doVC()) {
/* 1077 */           bt.doNC();
/*      */         }
/*      */       } 
/* 1080 */       bt.transferFocus();
/*      */     } 
/* 1082 */     return e;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void selectRow(MCTable<? extends MCConstRow> table, int index) {
/* 1100 */     if (table == null) {
/*      */       return;
/*      */     }
/* 1103 */     table = table.getBaseTable();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1108 */     if (!checkSelectIndex(table, index)) {
/*      */       return;
/*      */     }
/* 1111 */     table.mcRequestFocus();
/* 1112 */     MCPoint point = table.getNextPoint(index);
/* 1113 */     if (point != null) {
/* 1114 */       table.focusCellAt(point.getIndex(), point.getColumn());
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */       
/* 1122 */       MCTable<? extends MCConstRow> e = table.getEditingTable();
/* 1123 */       if (e != null) {
/* 1124 */         e.editingStopped((ChangeEvent)null);
/* 1125 */         if (e.getMCEditorComponent() != null) {
/*      */           return;
/*      */         }
/*      */       } 
/*      */       
/* 1130 */       table._mcClearSelection();
/*      */       
/* 1132 */       table.setMCRowSelectionInterval(index);
/*      */ 
/*      */       
/* 1135 */       MCColumnConfig[] a = table.getViewColumnConfigs();
/* 1136 */       int real = 0;
/* 1137 */       if (a.length > 0) {
/* 1138 */         MCColumnConfig c = a[0];
/* 1139 */         table = table.getTable(c);
/* 1140 */         table.requestFocus();
/* 1141 */         real = table.getRealColumn(c);
/* 1142 */         table.setMCColumnSelectionInterval(table.getViewColumn(c), 
/* 1143 */             table.getViewColumn(c));
/*      */ 
/*      */ 
/*      */         
/* 1147 */         if (table.getTableHeader() != null) {
/* 1148 */           table.getTableHeader().repaint();
/*      */         }
/*      */       } 
/* 1151 */       table.scrollRectToVisible(index, real);
/* 1152 */       MCTable<?> at = table.isBodyTable() ? table.getFixedColumnTable() : table
/* 1153 */         .getBodyTable();
/* 1154 */       at.getColumnSelectionModel().setAnchorSelectionIndex(-1);
/* 1155 */       at.getColumnSelectionModel().setLeadSelectionIndex(-1);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void selectRowNoFocus(MCTable<? extends MCConstRow> table, int index) {
/* 1183 */     if (table == null) {
/*      */       return;
/*      */     }
/* 1186 */     table = table.getBaseTable();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1191 */     if (!checkSelectIndex(table, index)) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1197 */     MCTable<? extends MCConstRow> e = table.getEditingTable();
/* 1198 */     if (e != null) {
/* 1199 */       e.editingStopped((ChangeEvent)null);
/* 1200 */       if (e.getMCEditorComponent() != null) {
/*      */         return;
/*      */       }
/*      */     } 
/*      */     
/* 1205 */     table._mcClearSelection();
/*      */     
/* 1207 */     table.setMCRowSelectionInterval(index);
/*      */ 
/*      */     
/* 1210 */     int s = -1;
/* 1211 */     int v = -1;
/*      */     
/* 1213 */     MCColumnConfig c = table.getClickedColumnConfig();
/* 1214 */     if (c != null) {
/* 1215 */       table = table.getTable(c);
/* 1216 */       v = s = table.getRealColumn(c);
/*      */     } 
/*      */     
/* 1219 */     if (s == -1) {
/* 1220 */       c = table.getSelectedColumnConfig();
/* 1221 */       table = table.getTable(c);
/* 1222 */       v = s = table.getRealColumn(c);
/*      */     } 
/*      */     
/* 1225 */     if (s == -1) {
/* 1226 */       v = s = table.getModel().getInfraColumnCount();
/* 1227 */       c = table.getColumnFromView(v);
/* 1228 */       if (c != null)
/*      */       {
/* 1230 */         table = table.getTable(c);
/*      */       }
/* 1232 */       if (table.isBodyTable()) {
/* 1233 */         v = 0;
/*      */       }
/*      */     } 
/* 1236 */     table.setMCColumnSelectionInterval(s, s);
/* 1237 */     table.scrollRectToVisible(index, v);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void selectRowsNoFocus(MCTable<? extends MCConstRow> table, int[] indexes) {
/* 1252 */     if (table == null || indexes == null) {
/*      */       return;
/*      */     }
/* 1255 */     int count = indexes.length;
/* 1256 */     if (count == 0) {
/*      */       return;
/*      */     }
/* 1259 */     table = table.getBaseTable();
/*      */     
/* 1261 */     table._mcClearSelection();
/*      */     
/* 1263 */     int c_idx = table.getModel().getInfraColumnCount();
/*      */     
/* 1265 */     int idx = 0;
/*      */     
/* 1267 */     int cnt = table.getRowCount();
/* 1268 */     table.getRowHeight();
/* 1269 */     for (int i = 0; i < count; i++) {
/* 1270 */       int index = indexes[i];
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1275 */       if (index > -1 && index < cnt) {
/* 1276 */         if (idx++ == 0) {
/* 1277 */           table.setMCRowSelectionInterval(index);
/*      */         } else {
/*      */           
/* 1280 */           if (table.getRowHeight(index) == 0) {
/* 1281 */             table.filterList(table.getList());
/*      */           }
/*      */           
/* 1284 */           table.addMCRowSelectionInterval(index, index);
/*      */         } 
/* 1286 */         table.setMCColumnSelectionInterval(c_idx, c_idx);
/* 1287 */         if (i == count - 1) {
/* 1288 */           table.scrollRectToVisible(index, 0);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void selectLeftmostColumn(MCTable<?> table, int index) {
/* 1308 */     if (table == null) {
/*      */       return;
/*      */     }
/* 1311 */     table = table.getBaseTable();
/* 1312 */     if (!checkSelectIndex(table, index)) {
/*      */       return;
/*      */     }
/* 1315 */     MCColumnConfig[] a = table.getAllViewColumnConfigs();
/* 1316 */     if (a.length < 1) {
/*      */       return;
/*      */     }
/* 1319 */     table.focusCellAt(index, a[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void rowCopy(MCTable<?> table, int... indexes) {
/* 1333 */     if (table == null || indexes == null || indexes.length == 0) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 1338 */     table = table.getBaseTable();
/*      */ 
/*      */     
/* 1341 */     if (!table.checkAC()) {
/*      */       return;
/*      */     }
/*      */     
/* 1345 */     MCList<?> list = table.getList();
/* 1346 */     if (list == null) {
/*      */       return;
/*      */     }
/* 1349 */     int size = list.size();
/*      */     
/* 1351 */     MCColumnConfig[] cols = table.getViewColumnConfigs();
/* 1352 */     if (cols.length == 0) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 1357 */     List<MCColumnConfig> coll = new ArrayList<>(cols.length); byte b1; int j; MCColumnConfig[] arrayOfMCColumnConfig1;
/* 1358 */     for (j = (arrayOfMCColumnConfig1 = cols).length, b1 = 0; b1 < j; ) { MCColumnConfig cf = arrayOfMCColumnConfig1[b1];
/* 1359 */       if (cf.isLinkRowColumn())
/* 1360 */         coll.add(cf); 
/*      */       b1++; }
/*      */     
/* 1363 */     cols = coll.<MCColumnConfig>toArray(new MCColumnConfig[coll.size()]);
/*      */ 
/*      */     
/* 1366 */     String[] nms = new String[cols.length];
/* 1367 */     for (int i = 0; i < cols.length; i++) {
/* 1368 */       nms[i] = cols[i].getBaseRowColumnName();
/*      */     }
/*      */ 
/*      */     
/* 1372 */     int row_cnt = 0; byte b2; int k, arrayOfInt1[];
/* 1373 */     for (k = (arrayOfInt1 = indexes).length, b2 = 0; b2 < k; ) { int i1 = arrayOfInt1[b2];
/* 1374 */       if (i1 > -1 && i1 < size)
/* 1375 */         row_cnt++; 
/*      */       b2++; }
/*      */     
/* 1378 */     int[] idxes = new int[row_cnt];
/* 1379 */     int cnt = 0; byte b3; int m, arrayOfInt2[];
/* 1380 */     for (m = (arrayOfInt2 = indexes).length, b3 = 0; b3 < m; ) { int i1 = arrayOfInt2[b3];
/* 1381 */       if (i1 > -1 && i1 < size) {
/* 1382 */         idxes[cnt++] = i1;
/*      */       }
/*      */       
/*      */       b3++; }
/*      */     
/* 1387 */     StringBuilder data = new StringBuilder();
/*      */     
/* 1389 */     String col_sep = "\t";
/* 1390 */     String line_sep = "\n";
/*      */ 
/*      */     
/* 1393 */     for (int n = 0; n < idxes.length; n++) {
/* 1394 */       int idx = idxes[n];
/* 1395 */       MCRow e = list.get(idx);
/* 1396 */       StringBuilder sb = new StringBuilder();
/* 1397 */       for (int i1 = 0; i1 < nms.length; i1++) {
/* 1398 */         Comparable<?> v = e.getValue(nms[i1]);
/* 1399 */         String text = null;
/* 1400 */         if (v != null) {
/* 1401 */           MCColumnConfig col = cols[i1];
/* 1402 */           MCColumnType type = col.getColumnType();
/* 1403 */           if (type != null) {
/* 1404 */             switch (type) {
/*      */               case TEXT:
/*      */               case TEXT_COMBO:
/*      */               case TEXT_COMBO_FREE:
/*      */               case TEXT_COMBO_SELECT_ONLY:
/* 1409 */                 text = (String)v;
/*      */                 break;
/*      */               case NUMBER:
/*      */               case NUMBER_COMBO:
/*      */               case NUMBER_COMBO_FREE:
/*      */               case NUMBER_COMBO_SELECT_ONLY:
/* 1415 */                 text = col.getNumberFormat().doOutputFormat((MCNumber)v, 
/* 1416 */                     col.getScale(idx));
/*      */                 break;
/*      */               case DATE:
/*      */               case DATE_COMBO:
/*      */               case DATE_COMBO_FREE:
/*      */               case DATE_COMBO_SELECT_ONLY:
/* 1422 */                 text = col.getDateFormat().doOutputFormat((MCCalendarDate)v);
/*      */                 break;
/*      */               case TIMESTAMP:
/*      */               case TIMESTAMP_COMBO:
/*      */               case TIMESTAMP_COMBO_FREE:
/*      */               case TIMESTAMP_COMBO_SELECT_ONLY:
/* 1428 */                 text = col.getTimestampFormat().doOutputFormat(
/* 1429 */                     (MCCalendarDate)v);
/*      */                 break;
/*      */               case CHECK:
/* 1432 */                 text = v.toString();
/*      */                 break;
/*      */               default:
/* 1435 */                 sb.append(col_sep);
/*      */                 i1++;
/*      */                 continue;
/*      */             } 
/*      */           }
/*      */         } else {
/* 1441 */           text = "";
/*      */         } 
/*      */         
/* 1444 */         sb.append(text);
/* 1445 */         if (i1 != nms.length - 1) {
/* 1446 */           sb.append(col_sep);
/*      */         }
/*      */       } 
/* 1449 */       data.append(sb);
/* 1450 */       if (n != idxes.length - 1) {
/* 1451 */         data.append(line_sep);
/*      */       }
/*      */     } 
/*      */     
/* 1455 */     Toolkit.getDefaultToolkit().getSystemClipboard()
/* 1456 */       .setContents(new StringSelection(data.toString()), null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected <E extends MCConstRow> E copyRow(MCTable<E> table, int index) {
/* 1473 */     if (!checkInsertIndex(table, index)) {
/* 1474 */       return null;
/*      */     }
/* 1476 */     E e = table.getRow(index);
/* 1477 */     MCConstRow mCConstRow = (MCConstRow)table.getList().createRow();
/* 1478 */     if (!e.isEmpty()) {
/* 1479 */       MCConstRow.copyvalue((MCRow)mCConstRow, (MCRow)e);
/* 1480 */       mCConstRow.setStatus(MCRow.CREATE);
/*      */     } 
/* 1482 */     table.insertRow((E)mCConstRow);
/* 1483 */     return (E)mCConstRow;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getInsertIndex(MCTable<?> table) {
/* 1499 */     if (table == null) {
/* 1500 */       return -1;
/*      */     }
/* 1502 */     int i = table.getMCSelectedRow();
/* 1503 */     return (i != -1) ? (i + 1) : table.getRowCount();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getDeleteIndex(MCTable<?> table) {
/* 1519 */     if (table == null) {
/* 1520 */       return -1;
/*      */     }
/* 1522 */     int i = table.getMCSelectedRow();
/*      */     
/* 1524 */     if (i == -1) {
/* 1525 */       MCList<?> l = table.getViewRows();
/* 1526 */       if (l.size() > 0) {
/* 1527 */         i = l.get(l.size() - 1).getGUIIndex();
/*      */       }
/*      */     } 
/* 1530 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean checkInsertIndex(MCTable<?> table, int index) {
/* 1547 */     return (table != null) ? ((index > -1 && index <= table.getRowCount())) : false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean checkDeleteIndex(MCTable<?> table, int index) {
/* 1562 */     return (table != null) ? ((index > -1 && index < table.getRowCount())) : false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean checkSelectIndex(MCTable<?> table, int index) {
/* 1577 */     return (table != null) ? ((index > -1 && index < table.getRowCount())) : false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void selectRow(MCTable<?> table, int index, boolean focus) {
/* 1596 */     if (focus) {
/* 1597 */       table.selectLeftmostColumn(index);
/*      */     } else {
/*      */       
/* 1600 */       table.selectRowNoFocus(index);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setEventIndex(MCTable<?> table, int before, int after) {
/* 1614 */     MCEventInfo i = table.getEventInfo();
/* 1615 */     MCEventProxy.PROXY.setIndex(i, before, after);
/* 1616 */     MCEventProxy.PROXY.setEventIndex(i, after);
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCRecordHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */