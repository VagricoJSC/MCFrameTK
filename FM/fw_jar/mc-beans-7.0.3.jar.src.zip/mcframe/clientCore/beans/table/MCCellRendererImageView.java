/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.net.URL;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.table.TableCellRenderer;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.requester.MCDownloader;
/*     */ import mcframe.commonCore.lang.MCBinary;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCCellRendererImageView
/*     */   extends JButton
/*     */   implements TableCellRenderer
/*     */ {
/*     */   private final MCColumnConfig _column;
/*  41 */   private Border _default_border = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCCellRendererImageView(MCColumnConfig column) {
/*  51 */     this._column = column;
/*  52 */     setOpaque(false);
/*  53 */     setHorizontalAlignment(0);
/*  54 */     setBorder((Border)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCColumnConfig getColumnConfig() {
/*  65 */     return this._column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setDefaultBorder(Border border) {
/*  78 */     this._default_border = border;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Border getDefaultBorder() {
/*  94 */     return this._default_border;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Component getTableCellRendererComponent(JTable table, Object value, boolean selected, boolean focused, int index, int column) {
/* 112 */     MCTable<?> t = (MCTable)table;
/* 113 */     boolean f = focused ? focused : MCCellUtil.hasFocus(t, index, column);
/* 114 */     return getRenderer(t, value, selected, f, index, getColumnConfig());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Component getRenderer(MCTable<?> table, Object value, boolean selected, boolean focused, int index, MCColumnConfig column) {
/* 132 */     int horizontal = column.getHorizontalAlignment();
/* 133 */     if (horizontal == -1) {
/* 134 */       horizontal = 0;
/*     */     }
/* 136 */     setHorizontalAlignment(horizontal);
/* 137 */     MCCellUtil.initRenderer(this, index, column, table, selected, focused, 
/* 138 */         getDefaultBorder());
/*     */     
/* 140 */     if (value != null) {
/* 141 */       if (value instanceof MCBinary) {
/* 142 */         URL u = null;
/*     */         try {
/* 144 */           u = MCDownloader.getBinaryURL((MCBinary)value);
/*     */         }
/* 146 */         catch (Exception e) {
/* 147 */           table.clear();
/* 148 */           MCBeansUtil.handle(table, e);
/*     */         } 
/* 150 */         if (u != null) {
/* 151 */           if (this._column.getImageWidth() != -1 && this._column.getImageHeight() != -1) {
/* 152 */             ImageIcon icon = new ImageIcon(u);
/* 153 */             icon.setImage(icon.getImage().getScaledInstance(this._column.getImageWidth(), this._column.getImageHeight(), 4));
/* 154 */             setIcon(icon);
/*     */           } else {
/*     */             
/* 157 */             setIcon(new ImageIcon(u));
/*     */           } 
/*     */         }
/*     */       } else {
/*     */         
/* 162 */         setIcon((Icon)null);
/*     */       } 
/*     */     } else {
/*     */       
/* 166 */       setIcon((Icon)null);
/*     */     } 
/* 168 */     Color bg = getBackground();
/* 169 */     setOpaque(!(bg != null && bg.equals(table.getBackground()) && table.isOpaque()));
/* 170 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCCellRendererImageView.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */