/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicTableUI;
/*     */ import javax.swing.table.JTableHeader;
/*     */ import javax.swing.table.TableCellRenderer;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCTableUI
/*     */   extends BasicTableUI
/*     */ {
/*     */   public static ComponentUI createUI(JComponent compo) {
/*  30 */     return new MCTableUI();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paint(Graphics g, JComponent c) {
/*  44 */     Rectangle clip = g.getClipBounds();
/*     */     
/*  46 */     Rectangle bounds = this.table.getBounds();
/*     */ 
/*     */     
/*  49 */     bounds.x = bounds.y = 0;
/*     */     
/*  51 */     if (this.table.getRowCount() > 0 && this.table.getColumnCount() > 0)
/*     */     {
/*     */       
/*  54 */       if (bounds.intersects(clip)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  60 */         boolean ltr = this.table.getComponentOrientation().isLeftToRight();
/*     */         
/*  62 */         Point upperLeft = clip.getLocation();
/*  63 */         if (!ltr) {
/*  64 */           upperLeft.x++;
/*     */         }
/*     */         
/*  67 */         Point lowerRight = new Point(clip.x + clip.width - (ltr ? 1 : 0), 
/*  68 */             clip.y + clip.height);
/*     */         
/*  70 */         int rMin = this.table.rowAtPoint(upperLeft);
/*  71 */         int rMax = this.table.rowAtPoint(lowerRight);
/*     */ 
/*     */         
/*  74 */         if (rMin == -1) {
/*  75 */           rMin = 0;
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  81 */         if (rMax == -1) {
/*  82 */           rMax = this.table.getRowCount() - 1;
/*     */         }
/*     */         
/*  85 */         int cMin = this.table.columnAtPoint(ltr ? upperLeft : lowerRight);
/*  86 */         int cMax = this.table.columnAtPoint(ltr ? lowerRight : upperLeft);
/*     */         
/*  88 */         if (cMin == -1) {
/*  89 */           cMin = 0;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*  94 */         if (cMax == -1) {
/*  95 */           cMax = this.table.getColumnCount() - 1;
/*     */         }
/*     */ 
/*     */         
/*  99 */         paintGrid(g, rMin, rMax, cMin, cMax);
/*     */ 
/*     */         
/* 102 */         paintCells(g, rMin, rMax, cMin, cMax);
/*     */         return;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void paintGrid(Graphics g, int rMin, int rMax, int cMin, int cMax) {
/* 113 */     boolean isSynth = UIManager.getLookAndFeel() instanceof javax.swing.plaf.synth.SynthLookAndFeel;
/* 114 */     if (isSynth) {
/* 115 */       g.setColor(UIManager.getColor("MCTable.gridColor"));
/*     */     } else {
/*     */       
/* 118 */       g.setColor(this.table.getGridColor());
/*     */     } 
/*     */     
/* 121 */     Rectangle minCell = this.table.getCellRect(rMin, cMin, true);
/* 122 */     Rectangle maxCell = this.table.getCellRect(rMax, cMax, true);
/* 123 */     Rectangle damagedArea = minCell.union(maxCell);
/*     */     
/* 125 */     if (isSynth ? UIManager.getBoolean("MCTable.ShowHorizontalLines") : 
/* 126 */       this.table.getShowHorizontalLines()) {
/* 127 */       int tableWidth = damagedArea.x + damagedArea.width;
/* 128 */       int y = damagedArea.y;
/* 129 */       for (int row = rMin; row <= rMax; row++) {
/* 130 */         y += this.table.getRowHeight(row);
/* 131 */         g.drawLine(damagedArea.x, y - 1, tableWidth - 1, y - 1);
/*     */       } 
/*     */     } 
/* 134 */     if (isSynth ? UIManager.getBoolean("MCTable.ShowVerticalLines") : 
/* 135 */       this.table.getShowVerticalLines()) {
/* 136 */       TableColumnModel cm = this.table.getColumnModel();
/* 137 */       int tableHeight = damagedArea.y + damagedArea.height;
/*     */       
/* 139 */       if (this.table.getComponentOrientation().isLeftToRight()) {
/* 140 */         int x = damagedArea.x;
/* 141 */         for (int column = cMin; column <= cMax; column++) {
/* 142 */           int w = cm.getColumn(column).getWidth();
/* 143 */           x += w;
/* 144 */           g.drawLine(x - 1, 0, x - 1, tableHeight - 1);
/*     */         } 
/*     */       } else {
/* 147 */         int x = damagedArea.x;
/* 148 */         for (int column = cMax; column >= cMin; column--) {
/* 149 */           int w = cm.getColumn(column).getWidth();
/* 150 */           x += w;
/* 151 */           g.drawLine(x - 1, 0, x - 1, tableHeight - 1);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void paintCells(Graphics g, int rMin, int rMax, int cMin, int cMax) {
/* 158 */     JTableHeader header = this.table.getTableHeader();
/* 159 */     TableColumn draggedColumn = (header == null) ? null : header
/* 160 */       .getDraggedColumn();
/*     */     
/* 162 */     TableColumnModel cm = this.table.getColumnModel();
/* 163 */     int columnMargin = cm.getColumnMargin();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 168 */     if (this.table.getComponentOrientation().isLeftToRight())
/* 169 */     { for (int row = rMin; row <= rMax; row++) {
/*     */ 
/*     */         
/* 172 */         if (this.table.getRowHeight(row) != 0) {
/*     */ 
/*     */ 
/*     */           
/* 176 */           Rectangle cellRect = this.table.getCellRect(row, cMin, false);
/* 177 */           for (int column = cMin; column <= cMax; column++) {
/* 178 */             TableColumn aColumn = cm.getColumn(column);
/*     */             
/* 180 */             if (((MCTableColumn)aColumn).isViewColumn())
/*     */             
/*     */             { 
/* 183 */               int columnWidth = aColumn.getWidth();
/* 184 */               cellRect.width = columnWidth - columnMargin;
/* 185 */               if (aColumn != draggedColumn) {
/* 186 */                 paintCell(g, cellRect, row, column);
/*     */               }
/* 188 */               cellRect.x += columnWidth; } 
/*     */           } 
/*     */         } 
/*     */       }  }
/* 192 */     else { for (int row = rMin; row <= rMax; row++) {
/*     */ 
/*     */         
/* 195 */         if (this.table.getRowHeight(row) != 0) {
/*     */ 
/*     */ 
/*     */           
/* 199 */           Rectangle cellRect = this.table.getCellRect(row, cMin, false);
/* 200 */           TableColumn aColumn = cm.getColumn(cMin);
/* 201 */           if (aColumn != draggedColumn) {
/* 202 */             int columnWidth = aColumn.getWidth();
/* 203 */             cellRect.width = columnWidth - columnMargin;
/* 204 */             paintCell(g, cellRect, row, cMin);
/*     */           } 
/* 206 */           for (int column = cMin + 1; column <= cMax; column++) {
/* 207 */             aColumn = cm.getColumn(column);
/* 208 */             int columnWidth = aColumn.getWidth();
/* 209 */             cellRect.width = columnWidth - columnMargin;
/* 210 */             cellRect.x -= columnWidth;
/* 211 */             if (aColumn != draggedColumn) {
/* 212 */               paintCell(g, cellRect, row, column);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       }  }
/*     */ 
/*     */     
/* 219 */     if (draggedColumn != null) {
/* 220 */       paintDraggedArea(g, rMin, rMax, draggedColumn, 
/* 221 */           header.getDraggedDistance());
/*     */     }
/*     */ 
/*     */     
/* 225 */     this.rendererPane.removeAll();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void paintCell(Graphics g, Rectangle cellRect, int row, int column) {
/* 232 */     if (this.table.isEditing() && this.table.getEditingRow() == row && 
/* 233 */       this.table.getEditingColumn() == column) {
/* 234 */       Component component = this.table.getEditorComponent();
/* 235 */       component.setBounds(cellRect);
/* 236 */       component.validate();
/*     */     } else {
/* 238 */       TableCellRenderer renderer = this.table.getCellRenderer(row, column);
/* 239 */       Component component = this.table.prepareRenderer(renderer, row, column);
/* 240 */       this.rendererPane.paintComponent(g, component, this.table, cellRect.x, 
/* 241 */           cellRect.y, cellRect.width, cellRect.height, true);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void paintDraggedArea(Graphics g, int rMin, int rMax, TableColumn draggedColumn, int distance) {
/* 250 */     int draggedColumnIndex = viewIndexForColumn(draggedColumn);
/*     */     
/* 252 */     Rectangle minCell = this.table.getCellRect(rMin, draggedColumnIndex, true);
/* 253 */     Rectangle maxCell = this.table.getCellRect(rMax, draggedColumnIndex, true);
/*     */     
/* 255 */     Rectangle vacatedColumnRect = minCell.union(maxCell);
/*     */ 
/*     */     
/* 258 */     g.setColor(this.table.getParent().getBackground());
/* 259 */     g.fillRect(vacatedColumnRect.x, vacatedColumnRect.y, 
/* 260 */         vacatedColumnRect.width, vacatedColumnRect.height);
/*     */ 
/*     */     
/* 263 */     vacatedColumnRect.x += distance;
/*     */ 
/*     */     
/* 266 */     g.setColor(this.table.getBackground());
/* 267 */     g.fillRect(vacatedColumnRect.x, vacatedColumnRect.y, 
/* 268 */         vacatedColumnRect.width, vacatedColumnRect.height);
/*     */ 
/*     */     
/* 271 */     if (this.table.getShowVerticalLines()) {
/* 272 */       g.setColor(this.table.getGridColor());
/* 273 */       int x1 = vacatedColumnRect.x;
/* 274 */       int y1 = vacatedColumnRect.y;
/* 275 */       int x2 = x1 + vacatedColumnRect.width - 1;
/* 276 */       int y2 = y1 + vacatedColumnRect.height - 1;
/*     */       
/* 278 */       g.drawLine(x1 - 1, y1, x1 - 1, y2);
/*     */       
/* 280 */       g.drawLine(x2, y1, x2, y2);
/*     */     } 
/*     */     
/* 283 */     for (int row = rMin; row <= rMax; row++) {
/*     */       
/* 285 */       Rectangle r = this.table.getCellRect(row, draggedColumnIndex, false);
/* 286 */       r.x += distance;
/* 287 */       paintCell(g, r, row, draggedColumnIndex);
/*     */ 
/*     */       
/* 290 */       if (this.table.getShowHorizontalLines()) {
/* 291 */         g.setColor(this.table.getGridColor());
/* 292 */         Rectangle rcr = this.table
/* 293 */           .getCellRect(row, draggedColumnIndex, true);
/* 294 */         rcr.x += distance;
/* 295 */         int x1 = rcr.x;
/* 296 */         int y1 = rcr.y;
/* 297 */         int x2 = x1 + rcr.width - 1;
/* 298 */         int y2 = y1 + rcr.height - 1;
/* 299 */         g.drawLine(x1, y2, x2, y2);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int viewIndexForColumn(TableColumn aColumn) {
/* 308 */     TableColumnModel cm = this.table.getColumnModel();
/* 309 */     for (int column = 0; column < cm.getColumnCount(); column++) {
/* 310 */       if (cm.getColumn(column) == aColumn) {
/* 311 */         return column;
/*     */       }
/*     */     } 
/* 314 */     return -1;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCTableUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */