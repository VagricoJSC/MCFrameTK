/*    */ package mcframe.clientCore.beans.table;
/*    */ 
/*    */ import mcframe.clientCore.beans.popup.AbsMCPackageProxy;
/*    */ import mcframe.clientCore.beans.popup.MCMenu;
/*    */ import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MCPopupProxy
/*    */   extends AbsMCPackageProxy
/*    */ {
/* 22 */   static final MCPopupProxy PROXY = new MCPopupProxy();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void restoreVisible(MCTextPopupMenuItem... items) {
/* 34 */     super.restoreVisible(items);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void setVisible(boolean visible, MCTextPopupMenuItem... items) {
/* 39 */     super.setVisible(visible, items);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void restoreVisible(MCMenu... menus) {
/* 44 */     super.restoreVisible(menus);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void setVisible(boolean visible, MCMenu... menus) {
/* 49 */     super.setVisible(visible, menus);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCPopupProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */