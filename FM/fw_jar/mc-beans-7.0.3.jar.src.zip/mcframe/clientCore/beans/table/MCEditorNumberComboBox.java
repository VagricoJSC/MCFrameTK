/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.event.KeyEvent;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.text.Document;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCMode;
/*     */ import mcframe.clientCore.beans.MCResourceBeans;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.action.MCKeyActionManager;
/*     */ import mcframe.clientCore.beans.combobox.AbsMCComboBox;
/*     */ import mcframe.clientCore.beans.combobox.MCComboField;
/*     */ import mcframe.clientCore.beans.combobox.MCComboListModel;
/*     */ import mcframe.clientCore.beans.combobox.MCFieldComboBox;
/*     */ import mcframe.clientCore.beans.combobox.MCNumberComboBox;
/*     */ import mcframe.clientCore.beans.list.MCLinkBeans;
/*     */ import mcframe.clientCore.beans.list.MCLinkedBeans;
/*     */ import mcframe.clientCore.beans.list.MCListConfig;
/*     */ import mcframe.clientCore.beans.list.MCListType;
/*     */ import mcframe.clientCore.beans.popup.MCPopupConfig;
/*     */ import mcframe.clientCore.beans.popup.MCPopupMenu;
/*     */ import mcframe.clientCore.beans.text.MCNumberDocument;
/*     */ import mcframe.clientCore.beans.text.MCNumberFormat;
/*     */ import mcframe.clientCore.event.MCEventInfo;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCEditorNumberComboBox
/*     */   extends MCNumberComboBox
/*     */   implements MCEditorBeans
/*     */ {
/*  46 */   private MCTable<?> _table = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   private MCColumnConfig _column = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCEditorNumberComboBox(String name, MCColumnConfig column) {
/*  66 */     super(name);
/*     */     
/*  68 */     setColumnConfig(column);
/*  69 */     setTable(column.getBaseTable());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getType() {
/*  74 */     return "table.column.combo-number";
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initBeans() {
/*  79 */     super.initBeans();
/*     */     
/*  81 */     setFocusTraversalKeysEnabled(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initKeyAssign() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initResource() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setTable(MCTable<?> table) {
/* 100 */     this._table = table;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCTable<?> getTable() {
/* 105 */     return this._table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setColumnConfig(MCColumnConfig column) {
/* 116 */     this._column = column;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCColumnConfig getColumnConfig() {
/* 121 */     return this._column;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getRowIndex() {
/* 126 */     return MCCellUtil.getRowIndex(this);
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCEditorComboField getComboField() {
/* 131 */     return (MCEditorComboField)super.getComboField();
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCEditorComboField createComboField() {
/* 136 */     return new MCEditorComboField();
/*     */   }
/*     */ 
/*     */   
/*     */   public void valueCommited() {
/* 141 */     MCTable<?> t = getTable();
/* 142 */     String o = getListConfig().getOpeType();
/*     */     
/* 144 */     MCNumber v = getValue();
/* 145 */     if ("input".equals(o)) {
/* 146 */       setSelectedItem((Comparable)v);
/*     */     }
/* 148 */     else if ("list".equals(o) && 
/* 149 */       v == null) {
/* 150 */       setSelectedItem((Comparable)v);
/*     */     } 
/*     */ 
/*     */     
/* 154 */     MCRow row = getSelectedListRow();
/*     */     
/* 156 */     if ("input".equals(o)) {
/* 157 */       row = getListRow((Comparable)getValue());
/*     */     }
/* 159 */     if (row == null && 
/* 160 */       getListType() == MCListType.FREE) {
/* 161 */       row = MCRow.create();
/* 162 */       MCBeansProxy.PROXY.addColumn(row, getListNames()[0], getDataType(), 
/* 163 */           getViewValue());
/*     */     } 
/*     */     
/* 166 */     MCEventInfo e = getEventInfo();
/* 167 */     String key = getKeyColumnName();
/* 168 */     if (MCBeansProxy.PROXY.haveLinkValuesNull(e, (MCLinkBeans)this, (Comparable<?>)getValue(), getList(), key)) {
/* 169 */       MCRow r = row.clone();
/* 170 */       r.clear();
/* 171 */       r.setValue(key, e.getNewValue());
/* 172 */       ((MCTableColumn)getColumnConfig()).execLink(t.getMCEditingRow(), r, true);
/*     */     } else {
/*     */       
/* 175 */       ((MCTableColumn)getColumnConfig()).execLink(t.getMCEditingRow(), row, true);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Border getDefaultBorder() {
/* 181 */     return MCCellUtil.DEFAULT_BORDER;
/*     */   }
/*     */ 
/*     */   
/*     */   public void transferFocus() {
/* 186 */     MCTable<?> t = getTable();
/* 187 */     t.transferFocus(getRowIndex(), t.getViewColumn(getColumnConfig()) + 1, false, 
/* 188 */         true, true);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void execLink(MCRow row, boolean msg) {
/* 193 */     ((MCTableColumn)getColumnConfig()).execLink(getRowIndex(), row, msg);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canChange() {
/*     */     try {
/* 199 */       MCTable.setEditingStoppedEnabled(false);
/*     */ 
/*     */       
/* 202 */       MCEventInfo info = getTable().getEventInfo();
/* 203 */       MCEventProxy.PROXY.setIndex(info, getTable().getMCSelectedRow(), 
/* 204 */           info.getNewIndex());
/*     */       
/* 206 */       return super.canChange();
/*     */     } finally {
/*     */       
/* 209 */       MCTable.setEditingStoppedEnabled(true);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void setColumnInfo(int index, MCColumnConfig column) {
/* 214 */     setColumnConfig(column);
/* 215 */     MCTable<?> table = getTable();
/*     */     
/* 217 */     MCKeyActionManager.init((MCResourceBeans)this, getInputMap(1), 
/* 218 */         getActionMap());
/* 219 */     JComponent c = getComboField().getComponent();
/* 220 */     MCKeyActionManager.init((MCResourceBeans)this, c.getInputMap(), c.getActionMap());
/*     */     
/* 222 */     MCKeyActionManager.initScreen((MCResourceBeans)this, 
/* 223 */         getInputMap(1), getActionMap());
/* 224 */     MCKeyActionManager.initScreen((MCResourceBeans)this, c.getInputMap(), c.getActionMap());
/*     */     
/* 226 */     MCMode mode = MCCellUtil.isCellEditable(index, column, table);
/* 227 */     setMode(mode);
/* 228 */     setForeground(MCCellUtil.getForeground(index, column, table, false, mode));
/* 229 */     setBackground(MCCellUtil.getBackground(index, column, table, false, mode));
/* 230 */     setFont(column.getFont());
/* 231 */     setCaretColor(MCCellUtil.getCaretColor(index, column, table));
/* 232 */     setSelectionColor(MCCellUtil.getSelectionColor(index, column, table));
/* 233 */     setSelectedTextColor(MCCellUtil.getSelectedTextColor(index, column, table));
/* 234 */     setMeta(column.getMeta());
/* 235 */     setLength(column.getLength(index), column.getScale(index), 
/* 236 */         column.isMinusEnable(index));
/* 237 */     setNumberFormat(MCCellUtil.getNumberFormat(index, column, table, mode));
/*     */     
/* 239 */     setViewScale(MCCellUtil.getViewScale(index, column, table));
/* 240 */     setViewZeroType(MCCellUtil.getViewZeroType(index, column, table));
/* 241 */     setViewRoundingMode(MCCellUtil.getViewRoundingMode(index, column, table));
/*     */     
/* 243 */     setListVisibleColumn(column.getListVisibleColumn());
/* 244 */     setRow(column.getTable().getRow(index), column.getRowColumnName());
/* 245 */     setAutoFocus(column.isAutoFocus());
/* 246 */     setSelectAll(column.isSelectAll());
/* 247 */     MCListConfig lc = column.getListConfig();
/* 248 */     setListConfig(lc);
/* 249 */     if (lc.getListType() == MCListType.SELECT_ONLY) {
/* 250 */       setDocumentEditable(false);
/*     */     }
/* 252 */     setComboListConfig(column.getComboListConfig());
/*     */     
/* 254 */     Border border = MCCellUtil.getEditorBorder(index, column, table);
/* 255 */     if (border != null) {
/* 256 */       setBorder(border);
/*     */     } else {
/*     */       
/* 259 */       setBorder(getDefaultBorder());
/*     */     } 
/* 261 */     MCPopupMenu menu = getComponentPopupMenu();
/* 262 */     if (menu != null) {
/* 263 */       menu.updateResource();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Color getForeground() {
/* 269 */     Color c = null;
/* 270 */     int idx = getRowIndex();
/* 271 */     MCTable<?> table = getTable();
/* 272 */     if (table != null && idx >= 0) {
/* 273 */       MCMode mode = MCCellUtil.isCellEditable(idx, this._column, table);
/* 274 */       c = MCCellUtil.getForeground(idx, this._column, table, false, mode);
/*     */     } else {
/*     */       
/* 277 */       c = super.getForeground();
/*     */     } 
/* 279 */     return c;
/*     */   }
/*     */ 
/*     */   
/*     */   public Color getBackground() {
/* 284 */     Color c = null;
/* 285 */     int idx = getRowIndex();
/* 286 */     MCTable<?> table = getTable();
/* 287 */     if (table != null && idx >= 0) {
/* 288 */       MCMode mode = MCCellUtil.isCellEditable(idx, this._column, table);
/* 289 */       c = MCCellUtil.getBackground(idx, this._column, table, false, mode);
/*     */     } else {
/*     */       
/* 292 */       c = super.getBackground();
/*     */     } 
/* 294 */     return c;
/*     */   }
/*     */ 
/*     */   
/*     */   public Border getBorder() {
/* 299 */     Border b = MCCellUtil.getBorder(this);
/* 300 */     return (b != null) ? b : super.getBorder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCRootPanel getRootPanel() {
/* 312 */     return MCCellUtil.getRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCRootPanel getNearestRootPanel() {
/* 317 */     return MCCellUtil.getNearestRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessageByLocale() {
/* 322 */     return getColumnConfig().getMessageByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLabelByLocale() {
/* 327 */     return getColumnConfig().getLabelByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterRequestFocus() {
/* 332 */     MCRootPanel bp = getBaseRootPanel();
/* 333 */     MCBeansUtil.afterRequestFocus(bp, getTable());
/* 334 */     MCBeansUtil.scrollRectToVisible(bp, (JComponent)this, 
/* 335 */         getComboField().getHorizontalAlignment());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 340 */     repaint();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFocusOwner() {
/* 345 */     MCTable<?> t = getTable();
/* 346 */     return (t != null) ? (t.isRemoveNotifyProcessing() ? super.isFocusOwner() : false) : 
/* 347 */       super.isFocusOwner();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValueChanged() {
/* 352 */     return isValueChanged((Comparable<?>)getRowValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValueChanged(Comparable<?> value) {
/* 357 */     return isValueChanged((Comparable<?>)getValue(), value);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isValueChanged(Comparable<?> view, Comparable<?> row) {
/* 362 */     return MCCellUtil.isValueChanged(this, view, row);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasFocus() {
/* 367 */     MCTable<?> t = getTable();
/* 368 */     return (t != null) ? ((this == t.getMCEditorComponent())) : super.hasFocus();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isMCFocusOwner() {
/* 373 */     MCTable<?> t = getTable();
/* 374 */     return (t != null) ? ((t.getMCEditorComponent() == this)) : isFocusOwner();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCListType getListType() {
/* 379 */     MCColumnConfig c = getColumnConfig();
/* 380 */     return (c != null) ? c.getListType() : super.getListType();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCLinkedBeans[] getLinkBeans() {
/* 385 */     MCColumnConfig c = getColumnConfig();
/* 386 */     return (c != null) ? c.getLinkBeans() : super.getLinkBeans();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRowToViews() {
/* 391 */     boolean e = MCBeansProxy.PROXY.isEventEnabled();
/*     */     try {
/* 393 */       MCBeansProxy.PROXY.setEventEnabled(false);
/* 394 */       setRowToView();
/* 395 */       MCLinkedBeans[] cs = getLinkBeans(); byte b; int i; MCLinkedBeans[] arrayOfMCLinkedBeans1;
/* 396 */       for (i = (arrayOfMCLinkedBeans1 = cs).length, b = 0; b < i; ) { MCLinkedBeans c = arrayOfMCLinkedBeans1[b];
/* 397 */         if (c instanceof MCColumnConfig) {
/* 398 */           MCColumnConfig col = (MCColumnConfig)c;
/* 399 */           int j = getRowIndex();
/* 400 */           col.setValue(j, 
/* 401 */               getTable().getRow(j).getValue(col.getBaseRowColumnName()));
/*     */         } 
/*     */         b++; }
/*     */     
/*     */     } finally {
/* 406 */       MCBeansProxy.PROXY.setEventEnabled(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCList doListEventEx() {
/* 415 */     MCTableColumn c = (MCTableColumn)getColumnConfig();
/* 416 */     MCEventProxy.PROXY.setEventIndex(c.getEventInfo(), getRowIndex());
/* 417 */     return c.doListEventEx();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCList doListEvent() {
/*     */     try {
/* 423 */       MCColumnConfig c = getColumnConfig();
/* 424 */       MCEventProxy.PROXY.setEventIndex(c.getEventInfo(), getRowIndex());
/* 425 */       return c.doListEvent();
/*     */     }
/* 427 */     catch (MCException e) {
/* 428 */       handle((Throwable)e);
/*     */       
/* 430 */       setRowToViews();
/*     */       
/* 432 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean doListEventWithNull() {
/* 437 */     MCColumnConfig c = getColumnConfig();
/* 438 */     return (c != null) ? c.doListEventWithNull() : false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean haveLinkValuesNullWhenDupliKeyTyped() {
/* 443 */     MCColumnConfig c = getColumnConfig();
/* 444 */     return (c != null) ? c.haveLinkValuesNullWhenDupliKeyTyped() : false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean doVC() {
/* 449 */     return getColumnConfig().doVC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNC() {
/* 454 */     getColumnConfig().doNC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNE() {
/* 459 */     getColumnConfig().doNE();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNX() {
/* 464 */     getColumnConfig().doNX();
/*     */     
/* 466 */     getListConfig().setOpeType("input");
/*     */   }
/*     */ 
/*     */   
/*     */   public void doLC() {
/* 471 */     getColumnConfig().doLC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doDC() {
/* 476 */     getColumnConfig().doDC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void focusGained() {
/* 481 */     Document d = getDocument();
/* 482 */     if (d instanceof MCNumberDocument) {
/* 483 */       MCNumberDocument n = (MCNumberDocument)d;
/* 484 */       boolean e = n.isValueCheck();
/* 485 */       n.setValueCheck(false);
/*     */       try {
/* 487 */         setText(getRowValue());
/* 488 */         focusGainedSelect();
/*     */       } finally {
/*     */         
/* 491 */         n.setValueCheck(e);
/*     */       } 
/*     */     } else {
/*     */       
/* 495 */       setText(getRowValue());
/* 496 */       focusGainedSelect();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void focusLost() {
/* 502 */     Document d = getDocument();
/* 503 */     if (d instanceof MCNumberDocument) {
/* 504 */       MCNumberDocument n = (MCNumberDocument)d;
/* 505 */       boolean e = n.isValueCheck();
/* 506 */       n.setValueCheck(false);
/*     */       try {
/* 508 */         setText(getRowValue());
/*     */       } finally {
/*     */         
/* 511 */         n.setValueCheck(e);
/*     */       } 
/*     */     } else {
/*     */       
/* 515 */       setText(getRowValue());
/*     */     } 
/*     */   }
/*     */   
/*     */   public String doFormat(MCNumber value) {
/*     */     String rtn;
/* 521 */     MCNumberFormat f = getNumberFormat();
/* 522 */     int fieldScale = getScale();
/*     */     
/* 524 */     if (isMCFocusOwner()) {
/* 525 */       rtn = f.doInputFormat(value, fieldScale);
/*     */     } else {
/*     */       
/* 528 */       rtn = f.doOutputFormat(value, fieldScale);
/*     */     } 
/* 530 */     return rtn;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCEventInfo getEventInfo() {
/* 535 */     return getColumnConfig().getEventInfo();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource(MCRootPanel panel) {}
/*     */ 
/*     */   
/*     */   public void doCheckValueError() {
/* 548 */     super.doCheckValueError();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCPopupConfig getPopupConfig() {
/* 553 */     MCTable<?> t = getTable();
/* 554 */     return (t != null) ? t.getPopupConfig() : null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCPopupMenu configurePopup(MCPopupMenu menu) {
/* 559 */     MCPopupConfig pc = getPopupConfig();
/* 560 */     return (pc != null) ? 
/* 561 */       pc.configurePopup(menu, getTable(), getRowIndex(), getColumnConfig()) : 
/* 562 */       menu;
/*     */   }
/*     */ 
/*     */   
/*     */   public void processKeyEvent(KeyEvent e) {
/* 567 */     MCCellUtil.beforeKeyEvent(e, this);
/* 568 */     super.processKeyEvent(e);
/*     */   }
/*     */ 
/*     */   
/*     */   public Comparable<?> doListFormat(Comparable<?> value) {
/* 573 */     return getColumnConfig().doListFormat(getRowIndex(), value);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Color getListForeground(MCRow row, boolean selected) {
/* 578 */     MCColumnConfig c = getColumnConfig();
/* 579 */     return getComboListConfig().getRowForeground(c, getRowIndex(), c.getTable(), row, 
/* 580 */         selected);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Color getListBackground(MCRow row, boolean selected) {
/* 585 */     MCColumnConfig c = getColumnConfig();
/* 586 */     return getComboListConfig().getRowBackground(c, getRowIndex(), c.getTable(), row, 
/* 587 */         selected);
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCEditorComboListModel createModel() {
/* 592 */     return new MCEditorComboListModel(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected class MCEditorComboField
/*     */     extends MCNumberComboBox.MCNumberComboField
/*     */   {
/*     */     protected MCEditorComboField() {
/* 610 */       super(MCEditorNumberComboBox.this);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void initBeans() {
/* 615 */       super.initBeans();
/*     */       
/* 617 */       setFocusTraversalKeysEnabled(false);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isRequestFocusEnabled() {
/* 623 */       MCTable<?> t = MCEditorNumberComboBox.this.getTable();
/* 624 */       if (!t.equalsIgnoreCase(MCBeansUtil.getFocusOwner(t)) && 
/* 625 */         !t.isRequestFocusEnabled()) {
/* 626 */         return false;
/*     */       }
/*     */       
/* 629 */       return super.isRequestFocusEnabled();
/*     */     }
/*     */ 
/*     */     
/*     */     public boolean isMCRequestFocusEnabled() {
/* 634 */       return MCCellUtil.isFocusable(MCEditorNumberComboBox.this);
/*     */     }
/*     */ 
/*     */     
/*     */     public Color getForeground() {
/* 639 */       Color c = null;
/* 640 */       int idx = MCEditorNumberComboBox.this.getRowIndex();
/* 641 */       MCTable<?> table = MCEditorNumberComboBox.this.getTable();
/* 642 */       if (table != null && idx >= 0) {
/* 643 */         MCMode mode = MCCellUtil.isCellEditable(idx, MCEditorNumberComboBox.this._column, table);
/* 644 */         c = MCCellUtil.getForeground(idx, MCEditorNumberComboBox.this._column, table, false, mode);
/*     */       } else {
/*     */         
/* 647 */         c = super.getForeground();
/*     */       } 
/* 649 */       return c;
/*     */     }
/*     */ 
/*     */     
/*     */     public Color getBackground() {
/* 654 */       Color c = null;
/* 655 */       int idx = MCEditorNumberComboBox.this.getRowIndex();
/* 656 */       MCTable<?> table = MCEditorNumberComboBox.this.getTable();
/* 657 */       if (table != null && idx >= 0) {
/* 658 */         MCMode mode = MCCellUtil.isCellEditable(idx, MCEditorNumberComboBox.this._column, table);
/* 659 */         c = MCCellUtil.getBackground(idx, MCEditorNumberComboBox.this._column, table, false, mode);
/*     */       } else {
/*     */         
/* 662 */         c = super.getBackground();
/*     */       } 
/* 664 */       return c;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected class MCEditorComboListModel
/*     */     extends MCComboListModel<MCNumber>
/*     */   {
/*     */     protected MCEditorComboListModel(MCEditorNumberComboBox compo) {
/* 685 */       super((AbsMCComboBox)compo);
/*     */     }
/*     */ 
/*     */     
/*     */     protected MCEditorNumberComboBox getComboBox() {
/* 690 */       return (MCEditorNumberComboBox)super.getComboBox();
/*     */     }
/*     */ 
/*     */     
/*     */     protected int getNewListIndex() {
/* 695 */       MCEditorNumberComboBox compo = getComboBox();
/* 696 */       int index = compo.getRowIndex();
/* 697 */       MCTableColumn column = (MCTableColumn)compo.getColumnConfig();
/* 698 */       return column.getNewListIndex(index);
/*     */     }
/*     */ 
/*     */     
/*     */     protected int getOldListIndex() {
/* 703 */       MCEditorNumberComboBox compo = getComboBox();
/* 704 */       int index = compo.getRowIndex();
/* 705 */       MCTableColumn column = (MCTableColumn)compo.getColumnConfig();
/* 706 */       return column.getOldListIndex(index);
/*     */     }
/*     */ 
/*     */     
/*     */     protected void setNewListIndex(int index) {
/* 711 */       MCEditorNumberComboBox compo = getComboBox();
/* 712 */       int row = compo.getRowIndex();
/* 713 */       MCTableColumn column = (MCTableColumn)compo.getColumnConfig();
/* 714 */       column.setNewListIndex(row, Integer.valueOf(index));
/*     */     }
/*     */ 
/*     */     
/*     */     protected void setOldListIndex(int index) {
/* 719 */       MCEditorNumberComboBox compo = getComboBox();
/* 720 */       int row = compo.getRowIndex();
/* 721 */       MCTableColumn column = (MCTableColumn)compo.getColumnConfig();
/* 722 */       column.setOldListIndex(row, Integer.valueOf(index));
/*     */     }
/*     */ 
/*     */     
/*     */     protected int getSelectedIndex() {
/* 727 */       MCEditorNumberComboBox compo = getComboBox();
/* 728 */       int index = compo.getRowIndex();
/* 729 */       MCTableColumn column = (MCTableColumn)compo.getColumnConfig();
/* 730 */       return (column != null) ? column.getSelectedListIndex(index) : 
/* 731 */         super.getSelectedIndex();
/*     */     }
/*     */ 
/*     */     
/*     */     protected void setSelectedIndex(int index) {
/* 736 */       super.setSelectedIndex(index);
/* 737 */       MCEditorNumberComboBox compo = getComboBox();
/* 738 */       int row = compo.getRowIndex();
/* 739 */       MCTableColumn column = (MCTableColumn)compo.getColumnConfig();
/* 740 */       if (column != null) {
/* 741 */         column.setSelectedListIndex(row, Integer.valueOf(index));
/*     */       } else {
/*     */         
/* 744 */         super.setSelectedIndex(index);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCEditorNumberComboBox.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */