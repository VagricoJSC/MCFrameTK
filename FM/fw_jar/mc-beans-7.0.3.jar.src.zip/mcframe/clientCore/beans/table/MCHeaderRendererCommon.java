package mcframe.clientCore.beans.table;

import java.awt.Component;
import javax.swing.table.TableCellRenderer;

interface MCHeaderRendererCommon extends TableCellRenderer {
  Component getTableCellRendererComponent(MCTable<?> paramMCTable, Comparable<?> paramComparable, boolean paramBoolean1, boolean paramBoolean2, int paramInt1, int paramInt2, MCColumnConfig paramMCColumnConfig);
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCHeaderRendererCommon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */