/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.table.TableCellRenderer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCLayoutTableUI
/*     */   extends MCTableUI
/*     */ {
/*     */   public static ComponentUI createUI(JComponent h) {
/*  36 */     return new MCLayoutTableUI();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCLayoutTableColumnModel getColumnModel() {
/*  47 */     return (this.table instanceof MCLayoutTable) ? (
/*  48 */       (MCLayoutTable)this.table).getColumnModel() : (
/*  49 */       (MCFixedColumnLayoutTable)this.table).getColumnModel();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getTableHeight() {
/*  64 */     int height = 0;
/*  65 */     int rowCount = this.table.getRowCount();
/*  66 */     if (rowCount > 0 && this.table.getColumnCount() > 0) {
/*  67 */       Rectangle r = this.table.getCellRect(
/*  68 */           rowCount - 1, 
/*  69 */           this.table.getColumnCount() - 1, 
/*  70 */           true);
/*  71 */       height = r.y + r.height;
/*     */     } 
/*  73 */     return height;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Dimension createTableSize(long width) {
/*  85 */     if (width > 2147483647L) {
/*  86 */       width = 2147483647L;
/*     */     }
/*  88 */     return new Dimension((int)width, getTableHeight());
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getMaximumSize(JComponent c) {
/*  93 */     MCLayoutTableColumnModel model = getColumnModel();
/*  94 */     long width = model.getMaximumWidth();
/*  95 */     return createTableSize(width);
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getMinimumSize(JComponent c) {
/* 100 */     MCLayoutTableColumnModel model = getColumnModel();
/* 101 */     long width = model.getMinimumWidth();
/* 102 */     return createTableSize(width);
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getPreferredSize(JComponent c) {
/* 107 */     MCLayoutTableColumnModel model = getColumnModel();
/* 108 */     long width = model.getPreferredWidth();
/* 109 */     return createTableSize(width);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paint(Graphics g, JComponent c) {
/* 124 */     Rectangle clipBounds = g.getClipBounds();
/*     */ 
/*     */     
/* 127 */     Rectangle bounds = this.table.getBounds();
/* 128 */     bounds.x = bounds.y = 0;
/* 129 */     if (this.table.getRowCount() <= 0 || this.table.getColumnCount() <= 0 || 
/* 130 */       !bounds.intersects(clipBounds)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 137 */     boolean ltr = this.table.getComponentOrientation().isLeftToRight();
/* 138 */     Point upperLeft = clipBounds.getLocation();
/* 139 */     if (!ltr) {
/* 140 */       upperLeft.x++;
/*     */     }
/* 142 */     Point lowerRight = new Point(clipBounds.x + clipBounds.width - (ltr ? 1 : 0), 
/* 143 */         clipBounds.y + clipBounds.height);
/*     */ 
/*     */     
/* 146 */     int rMin = this.table.rowAtPoint(upperLeft);
/* 147 */     if (rMin == -1) {
/* 148 */       rMin = 0;
/*     */     }
/* 150 */     int rMax = this.table.rowAtPoint(lowerRight);
/* 151 */     if (rMax == -1) {
/* 152 */       rMax = this.table.getRowCount() - 1;
/*     */     }
/*     */ 
/*     */     
/* 156 */     for (int index = rMin; index <= rMax; index++) {
/* 157 */       paintRow(g, index);
/*     */     }
/*     */ 
/*     */     
/* 161 */     this.rendererPane.removeAll();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void paintRow(Graphics g, int row) {
/* 174 */     if (this.table.getRowHeight(row) <= 0) {
/*     */       return;
/*     */     }
/*     */     
/* 178 */     int colcnt = getColumnModel().getColumnCount();
/* 179 */     paintCells(g, row, 0, colcnt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void paintCells(Graphics g, int row, int start, int end) {
/* 193 */     Rectangle clip = g.getClipBounds();
/* 194 */     for (int column = start; column <= end; column++) {
/* 195 */       Rectangle cellRect = this.table.getCellRect(row, column, true);
/* 196 */       if (cellRect.intersects(clip)) {
/* 197 */         paintCell(g, cellRect, row, column);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void paintCell(Graphics g, Rectangle cellRect, int row, int column) {
/* 213 */     paintGrid(g, cellRect, row);
/*     */     
/* 215 */     int spacingHeight = this.table.getRowMargin();
/* 216 */     int spacingWidth = this.table.getColumnModel().getColumnMargin();
/* 217 */     cellRect.setBounds(cellRect.x + spacingWidth / 2, 
/* 218 */         cellRect.y + spacingHeight / 2, 
/* 219 */         cellRect.width - spacingWidth, 
/* 220 */         cellRect.height - spacingHeight);
/*     */     
/* 222 */     if (this.table.isEditing() && 
/* 223 */       this.table.getEditingRow() == row && 
/* 224 */       this.table.getEditingColumn() == column) {
/* 225 */       Component component = this.table.getEditorComponent();
/* 226 */       component.setBounds(cellRect);
/* 227 */       component.validate();
/*     */     } else {
/*     */       
/* 230 */       TableCellRenderer renderer = this.table.getCellRenderer(row, column);
/* 231 */       Component component = this.table.prepareRenderer(renderer, row, column);
/* 232 */       this.rendererPane.paintComponent(g, component, this.table, 
/* 233 */           cellRect.x, cellRect.y, 
/* 234 */           cellRect.width, cellRect.height, 
/* 235 */           true);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void paintGrid(Graphics g, Rectangle cellRect, int row) {
/* 249 */     boolean isSynth = UIManager.getLookAndFeel() instanceof javax.swing.plaf.synth.SynthLookAndFeel;
/* 250 */     if (isSynth) {
/* 251 */       g.setColor(UIManager.getColor("MCTable.gridColor"));
/*     */     } else {
/*     */       
/* 254 */       g.setColor(this.table.getGridColor());
/*     */     } 
/* 256 */     if (isSynth ? UIManager.getBoolean("MCTable.ShowHorizontalLines") : 
/* 257 */       this.table.getShowHorizontalLines()) {
/*     */       
/* 259 */       int y = cellRect.y + cellRect.height - 1;
/* 260 */       g.drawLine(cellRect.x, y, cellRect.x + cellRect.width - 1, y);
/*     */     } 
/* 262 */     if (isSynth ? UIManager.getBoolean("MCTable.ShowVerticalLines") : 
/* 263 */       this.table.getShowVerticalLines()) {
/*     */       
/* 265 */       int x = cellRect.x + cellRect.width - 1;
/* 266 */       g.drawLine(x, cellRect.y, x, cellRect.y + cellRect.height - 1);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCLayoutTableUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */