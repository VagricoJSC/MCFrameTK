/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.event.MouseInputListener;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicTableHeaderUI;
/*     */ import javax.swing.table.JTableHeader;
/*     */ import javax.swing.table.TableCellRenderer;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCColumnGroupTableHeaderUI
/*     */   extends BasicTableHeaderUI
/*     */ {
/*     */   public static ComponentUI createUI(JComponent h) {
/*  42 */     return new MCColumnGroupTableHeaderUI();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCColumnGroupTableHeader getMCHeader() {
/*  56 */     return (MCColumnGroupTableHeader)this.header;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private TableCellRenderer getHeaderRenderer(TableColumn col) {
/*  72 */     TableCellRenderer renderer = col.getHeaderRenderer();
/*  73 */     if (renderer == null)
/*     */     {
/*  75 */       renderer = this.header.getDefaultRenderer();
/*     */     }
/*  77 */     return renderer;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected MouseInputListener createMouseInputListener() {
/*  83 */     return new MCColumnGroupTableMouseInputHandler();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public class MCColumnGroupTableMouseInputHandler
/*     */     extends BasicTableHeaderUI.MouseInputHandler
/*     */   {
/*     */     public void mouseDragged(MouseEvent e) {
/*  96 */       if (!SwingUtilities.isLeftMouseButton(e)) {
/*  97 */         MCColumnGroupTableHeaderUI.this.header.setResizingColumn((TableColumn)null);
/*  98 */         MCColumnGroupTableHeaderUI.this.header.setDraggedColumn((TableColumn)null);
/*     */       } 
/* 100 */       super.mouseDragged(e);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getHeaderHeight() {
/* 115 */     int height = 0;
/*     */ 
/*     */     
/* 118 */     MCTable<?> t = getMCHeader().getMCTable();
/* 119 */     MCTable[] tables = { t.getFixedColumnTable(), t.getBodyTable() }; byte b; int i; MCTable[] arrayOfMCTable1;
/* 120 */     for (i = (arrayOfMCTable1 = tables).length, b = 0; b < i; ) { MCTable<?> table = arrayOfMCTable1[b];
/* 121 */       MCColumnGroupTableHeader mcheader = 
/* 122 */         (MCColumnGroupTableHeader)table.getTableHeader();
/* 123 */       MCColumnGroupTableColumnModel columnModel = 
/* 124 */         mcheader.getColumnModel();
/* 125 */       int size = columnModel.getColumnCount();
/* 126 */       for (int index = 0; index < size; index++) {
/* 127 */         TableColumn column = columnModel.getColumn(index);
/* 128 */         TableCellRenderer renderer = getHeaderRenderer(column);
/* 129 */         Component comp = renderer.getTableCellRendererComponent(
/* 130 */             table, 
/* 131 */             column.getHeaderValue(), 
/* 132 */             false, false, -1, index);
/* 133 */         int cHeight = (comp.getPreferredSize()).height;
/* 134 */         MCColumnGroup[] cGroups = columnModel.getColumnGroups(column); byte b1; int j; MCColumnGroup[] arrayOfMCColumnGroup1;
/* 135 */         for (j = (arrayOfMCColumnGroup1 = cGroups).length, b1 = 0; b1 < j; ) { MCColumnGroup cGroup = arrayOfMCColumnGroup1[b1];
/* 136 */           cHeight += (cGroup.getSize()).height; b1++; }
/*     */         
/* 138 */         height = Math.max(height, cHeight);
/*     */       } 
/*     */       b++; }
/*     */     
/* 142 */     return height;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Dimension createHeaderSize(long width) {
/* 154 */     TableColumnModel columnModel = this.header.getColumnModel();
/* 155 */     width += (columnModel.getColumnMargin() * columnModel.getColumnCount());
/* 156 */     if (width > 2147483647L) {
/* 157 */       width = 2147483647L;
/*     */     }
/* 159 */     return new Dimension((int)width, getHeaderHeight());
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getPreferredSize(JComponent c) {
/* 164 */     long width = 0L;
/* 165 */     Enumeration<TableColumn> enumeration = 
/* 166 */       this.header.getColumnModel().getColumns();
/* 167 */     while (enumeration.hasMoreElements()) {
/* 168 */       TableColumn aColumn = enumeration.nextElement();
/* 169 */       width += aColumn.getPreferredWidth();
/*     */     } 
/* 171 */     return createHeaderSize(width);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paint(Graphics g, JComponent c) {
/* 179 */     MCColumnGroupTableHeader mcheader = getMCHeader();
/* 180 */     MCColumnGroupTableColumnModel columnModel = mcheader.getColumnModel();
/* 181 */     if (columnModel == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 186 */     Map<MCColumnGroup, Rectangle> h = 
/* 187 */       new HashMap<>();
/*     */     
/* 189 */     Rectangle clipBounds = g.getClipBounds();
/*     */     
/* 191 */     Dimension size = mcheader.getSize();
/* 192 */     Rectangle cellRect = new Rectangle(0, 0, size.width, size.height);
/*     */     
/* 194 */     Enumeration<TableColumn> enumeration = columnModel.getColumns();
/* 195 */     for (int column = 0; enumeration.hasMoreElements(); column++) {
/* 196 */       TableColumn aColumn = enumeration.nextElement();
/*     */       
/* 198 */       if (((MCTableColumn)aColumn).isViewColumn()) {
/*     */ 
/*     */ 
/*     */         
/* 202 */         cellRect.height = size.height;
/* 203 */         cellRect.y = 0;
/* 204 */         cellRect.width = aColumn.getWidth();
/*     */ 
/*     */         
/* 207 */         int groupHeight = 0;
/* 208 */         MCColumnGroup[] cGroups = columnModel.getColumnGroups(aColumn); byte b; int i; MCColumnGroup[] arrayOfMCColumnGroup1;
/* 209 */         for (i = (arrayOfMCColumnGroup1 = cGroups).length, b = 0; b < i; ) { MCColumnGroup cGroup = arrayOfMCColumnGroup1[b];
/* 210 */           Rectangle groupRect = h.get(cGroup);
/* 211 */           if (groupRect == null) {
/* 212 */             groupRect = new Rectangle(cellRect);
/* 213 */             Dimension d = cGroup.getSize();
/* 214 */             groupRect.width = d.width;
/* 215 */             groupRect.height = d.height;
/* 216 */             h.put(cGroup, groupRect);
/*     */             
/* 218 */             paintCell(g, groupRect, cGroup);
/*     */           } 
/* 220 */           groupHeight += groupRect.height;
/* 221 */           cellRect.height = size.height - groupHeight;
/* 222 */           cellRect.y = groupHeight;
/*     */           
/*     */           b++; }
/*     */         
/* 226 */         if (cellRect.intersects(clipBounds))
/*     */         {
/* 228 */           paintCell(g, cellRect, column);
/*     */         }
/*     */         
/* 231 */         cellRect.x += cellRect.width;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void paintCell(Graphics g, Rectangle cellRect, MCColumnGroup cGroup) {
/* 246 */     MCTableColumn aColumn = cGroup.getColumn();
/* 247 */     paintCell(g, cellRect, -1, aColumn);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void paintCell(Graphics g, Rectangle cellRect, int columnIndex) {
/* 260 */     TableColumn aColumn = this.header.getColumnModel().getColumn(columnIndex);
/* 261 */     paintCell(g, cellRect, columnIndex, (MCTableColumn)aColumn);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void paintCell(Graphics g, Rectangle cellRect, int columnIndex, MCTableColumn aColumn) {
/* 279 */     MCHeaderRendererCommon renderer = 
/* 280 */       (MCHeaderRendererCommon)getHeaderRenderer(aColumn);
/* 281 */     Component component = renderer.getTableCellRendererComponent(
/* 282 */         getMCHeader().getMCTable(), 
/* 283 */         (Comparable)aColumn.getHeaderValue(), 
/* 284 */         false, false, -1, columnIndex, aColumn);
/*     */ 
/*     */ 
/*     */     
/* 288 */     this.rendererPane.paintComponent(g, component, this.header, 
/* 289 */         cellRect.x, cellRect.y, cellRect.width, cellRect.height, true);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCColumnGroupTableHeaderUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */