/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.AWTException;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.MouseInfo;
/*     */ import java.awt.Point;
/*     */ import java.awt.PointerInfo;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.Robot;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import javax.swing.JPopupMenu;
/*     */ import javax.swing.table.JTableHeader;
/*     */ import javax.swing.table.TableColumn;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.popup.MCPopupBeans;
/*     */ import mcframe.clientCore.beans.popup.MCPopupConfig;
/*     */ import mcframe.clientCore.beans.popup.MCPopupMenu;
/*     */ import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
/*     */ import mcframe.clientCore.event.MCAPBeans;
/*     */ import mcframe.clientCore.event.MCAPListener;
/*     */ import mcframe.clientCore.event.MCEventInfo;
/*     */ import mcframe.commonCore.resource.ctrl.MCResource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCTableHeaderPopup
/*     */   implements MCPopupBeans
/*     */ {
/*     */   private JTableHeader _tableHeader;
/*     */   private TableColumn _clickedColumn;
/*     */   private MCTextPopupMenuItem _invisibleItem;
/*     */   private MCTextPopupMenuItem _invisibleSettingsItem;
/*     */   private MCAPListener _popup_listener;
/*     */   private Point _clickedPoint;
/*     */   
/*     */   public MCTableHeaderPopup(JTableHeader th) {
/*  50 */     this._clickedColumn = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  77 */     this._invisibleItem = null;
/*  78 */     this._invisibleSettingsItem = null;
/*  79 */     this._popup_listener = null;
/*  80 */     this._clickedPoint = null; this._tableHeader = th;
/*     */     initMouseListener();
/*     */     initPopupMenu();
/*  83 */   } void initMouseListener() { this._tableHeader.addMouseListener(new MCHeaderMouseListener(null)); } protected MCTextPopupMenuItem getColumnInvisibleMenuItem() { if (this._invisibleItem == null) {
/*  84 */       this._invisibleItem = createPopupMenuItem("POPUP_COLUMN_INVISIBLE");
/*     */     }
/*  86 */     return this._invisibleItem; }
/*     */   private class MCHeaderMouseListener extends MouseAdapter {
/*     */     private MCHeaderMouseListener() {} public void mousePressed(MouseEvent e) { MCTableHeaderPopup.this._clickedColumn = null; if (3 == e.getButton()) { Point p = e.getPoint(); int index = MCTableHeaderPopup.this._tableHeader.columnAtPoint(p); if (index != -1)
/*     */           MCTableHeaderPopup.this._clickedColumn = MCTableHeaderPopup.this._tableHeader.getColumnModel().getColumn(index);  }
/*  90 */        super.mousePressed(e); } } protected MCTextPopupMenuItem getColumnInvisibleSettingsMenuItem() { if (this._invisibleSettingsItem == null) {
/*  91 */       this._invisibleSettingsItem = createPopupMenuItem("POPUP_COLUMN_INVISIBLE_SETTINGS");
/*     */     }
/*  93 */     return this._invisibleSettingsItem; }
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCTextPopupMenuItem createPopupMenuItem(String key) {
/*  98 */     MCTextPopupMenuItem item = new MCTextPopupMenuItem(MCResource.createKey(new String[] { getType(), key }));
/*  99 */     item.updateResource();
/* 100 */     return item;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initPopupMenu() {
/* 105 */     getColumnInvisibleMenuItem();
/* 106 */     getColumnInvisibleSettingsMenuItem();
/*     */     
/* 108 */     MCPopupMenu pm = new MCPopupMenu(this);
/*     */ 
/*     */     
/* 111 */     this._invisibleItem.addAPListener(getPopupActionListener());
/* 112 */     pm.add(this._invisibleItem);
/*     */     
/* 114 */     pm.addSeparator("settings");
/*     */ 
/*     */     
/* 117 */     this._invisibleSettingsItem.addAPListener(getPopupActionListener());
/* 118 */     pm.add(this._invisibleSettingsItem);
/*     */     
/* 120 */     this._tableHeader.setComponentPopupMenu((JPopupMenu)pm);
/*     */   }
/*     */   
/*     */   protected MCAPListener getPopupActionListener() {
/* 124 */     if (this._popup_listener == null) {
/* 125 */       this._popup_listener = createMCPopupActionListener();
/*     */     }
/* 127 */     return this._popup_listener;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCAPListener createMCPopupActionListener() {
/* 134 */     return new MCPopupActionListener();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public class MCPopupActionListener
/*     */     implements MCAPListener
/*     */   {
/*     */     public void doAPEvent(MCAPBeans compo, MCEventInfo info) {
/* 143 */       if (compo == MCTableHeaderPopup.this._invisibleSettingsItem) {
/*     */         
/* 145 */         MCRootPanel bp = MCTableHeaderPopup.this.getBaseRootPanel();
/* 146 */         MCRootPanel p = bp.createPanel("FS", "FSBAP0390", MCRootPanel.SCREEN_MODAL, new Object[] { "T1", null, 
/* 147 */               MCTableHeaderPopup.access$3(this.this$0), MCTableHeaderPopup.access$4(this.this$0) });
/* 148 */         bp.showChildPanel(p, MCRootPanel.MULTI, new Object[0]);
/*     */       
/*     */       }
/* 151 */       else if (compo == MCTableHeaderPopup.this._invisibleItem) {
/* 152 */         if (MCTableHeaderPopup.this._clickedColumn != null && MCTableHeaderPopup.this._clickedColumn instanceof MCTableColumn) {
/* 153 */           ((MCTableColumn)MCTableHeaderPopup.this._clickedColumn).setVisibleFromUser(false);
/*     */         }
/*     */ 
/*     */         
/*     */         try {
/* 158 */           if (MCTableHeaderPopup.this._clickedPoint != null) {
/* 159 */             Robot robot = new Robot();
/* 160 */             robot.mouseMove(MCTableHeaderPopup.this._clickedPoint.x, MCTableHeaderPopup.this._clickedPoint.y);
/* 161 */             MCTableHeaderPopup.this._clickedPoint = null;
/*     */           } 
/* 163 */         } catch (AWTException aWTException) {}
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getType() {
/* 174 */     return "table.table-header";
/*     */   }
/*     */ 
/*     */   
/*     */   public MCRootPanel getRootPanel() {
/* 179 */     if (getMCTable() != null) {
/* 180 */       return getMCTable().getRootPanel();
/*     */     }
/* 182 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCRootPanel getBaseRootPanel() {
/* 187 */     if (getMCTable() != null) {
/* 188 */       return getMCTable().getBaseRootPanel();
/*     */     }
/* 190 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCRootPanel getNearestRootPanel() {
/* 195 */     if (getMCTable() != null) {
/* 196 */       return getMCTable().getNearestRootPanel();
/*     */     }
/* 198 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void handle(Throwable t) {
/* 203 */     MCBeansUtil.handle(this._tableHeader, t);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCPopupMenu configurePopup() {
/* 208 */     MCPopupMenu m1 = getComponentPopupMenu();
/* 209 */     m1.updateResource();
/*     */     
/* 211 */     MCPopupMenu m = configurePopup(getComponentPopupMenu());
/* 212 */     if (m != null) {
/* 213 */       m.sort();
/*     */     }
/* 215 */     return m;
/*     */   }
/*     */   protected MCPopupMenu configurePopup(MCPopupMenu menu) {
/* 218 */     MCPopupConfig pc = getPopupConfig();
/* 219 */     return menu = (pc != null) ? pc.configurePopup(menu, this) : menu;
/*     */   }
/*     */   
/*     */   public void popupMenuWillBecomeVisible() {
/*     */     try {
/* 224 */       PointerInfo pi = MouseInfo.getPointerInfo();
/* 225 */       this._clickedPoint = pi.getLocation();
/* 226 */       Robot robot = new Robot();
/* 227 */       robot.mouseMove(this._clickedPoint.x + 5, this._clickedPoint.y + 5);
/* 228 */     } catch (AWTException aWTException) {}
/*     */   }
/*     */   public void popupMenuWillBecomeInvisible() {}
/*     */   public void setPopupConfig(MCPopupConfig config) {}
/*     */   
/*     */   public MCPopupConfig getPopupConfig() {
/* 234 */     if (getMCTable() != null) {
/* 235 */       return getMCTable().getPopupConfig();
/*     */     }
/* 237 */     return null;
/*     */   }
/*     */   public void setComponentPopupMenu(MCPopupMenu popup) {
/* 240 */     this._tableHeader.setComponentPopupMenu((JPopupMenu)popup);
/*     */   }
/*     */   public MCPopupMenu getComponentPopupMenu() {
/* 243 */     MCPopupMenu _popup = (MCPopupMenu)this._tableHeader.getComponentPopupMenu();
/* 244 */     return _popup;
/*     */   }
/*     */   public void removeComponentPopupMenu() {
/* 247 */     setComponentPopupMenu(null);
/*     */   }
/*     */   public void updateResource() {}
/*     */   public void updateResource(MCRootPanel panel) {}
/*     */   public void _setDefaultBounds() {}
/*     */   public void _cacheDefaultBounds(Rectangle bounds) {}
/*     */   
/*     */   public Rectangle getDefaultBounds() {
/* 255 */     return null;
/*     */   }
/*     */   public String getMessageByLocale() {
/* 258 */     return null;
/*     */   }
/*     */   public String getLabelByLocale() {
/* 261 */     return null;
/*     */   }
/*     */   public void localeChanged() {}
/*     */   public void added() {}
/*     */   public void removed() {}
/*     */   public boolean equalsIgnoreCase(Component compo) {
/* 267 */     return false;
/*     */   }
/*     */   public void initialized() {}
/*     */   public void addAliasName(String alias, MCRootPanel panel) {}
/*     */   public void setAliasName(String alias, MCRootPanel panel) {}
/*     */   public void removeAliasName(MCRootPanel panel) {}
/*     */   public void removeAliasNames() {}
/*     */   public String getAliasName(MCRootPanel panel) {
/* 275 */     return null;
/*     */   }
/*     */   public String[] getAliasNames() {
/* 278 */     return null;
/*     */   }
/*     */   public void updateBounds(int ratio) {}
/*     */   
/*     */   public void updateFontSize(int ratio) {}
/*     */   
/*     */   public Dimension getDefaultSize() {
/* 285 */     return null;
/*     */   }
/*     */   public void afterRequestFocus() {}
/*     */   public void setMessageName(String name) {}
/*     */   public String _getMessageName() {
/* 290 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setName(String name) {}
/*     */ 
/*     */   
/*     */   public String getName() {
/* 299 */     return this._tableHeader.getName();
/*     */   }
/*     */ 
/*     */   
/*     */   private MCTable<?> getMCTable() {
/* 304 */     if (this._tableHeader == null) {
/* 305 */       return null;
/*     */     }
/* 307 */     if (this._tableHeader instanceof MCTable2Header) {
/* 308 */       return ((MCTable2Header)this._tableHeader).getMCTable();
/*     */     }
/* 310 */     if (this._tableHeader instanceof MCColumnGroupTableHeader) {
/* 311 */       return ((MCColumnGroupTableHeader)this._tableHeader).getMCTable();
/*     */     }
/* 313 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCTableHeaderPopup.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */