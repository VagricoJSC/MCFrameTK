/*    */ package mcframe.clientCore.beans.table;
/*    */ 
/*    */ import mcframe.commonCore.container.AbsMCPackageProxy;
/*    */ import mcframe.commonCore.container.MCRow;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class MCContainerProxy
/*    */   extends AbsMCPackageProxy
/*    */ {
/* 21 */   public static final MCContainerProxy proxy = new MCContainerProxy();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean isGUICreated(MCRow row) {
/* 33 */     return super.isGUICreated(row);
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean isGUIModified(MCRow row) {
/* 38 */     return super.isGUIModified(row);
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean isGUIDeleted(MCRow row) {
/* 43 */     return super.isGUIDeleted(row);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void setGUICreated(MCRow row, boolean on) {
/* 48 */     super.setGUICreated(row, on);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void setGUIModified(MCRow row, boolean on) {
/* 53 */     super.setGUIModified(row, on);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void setGUIDeleted(MCRow row, boolean on) {
/* 58 */     super.setGUIDeleted(row, on);
/*    */   }
/*    */   
/*    */   protected void setGUIStatus(MCRow from, MCRow to) {
/* 62 */     setGUICreated(to, isGUICreated(from));
/* 63 */     setGUIModified(to, isGUIModified(from));
/* 64 */     setGUIDeleted(to, isGUIDeleted(from));
/*    */   }
/*    */ 
/*    */   
/*    */   protected void setGUIVisible(MCRow row, boolean visible) {
/* 69 */     super.setGUIVisible(row, visible);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCContainerProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */