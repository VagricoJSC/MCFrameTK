/*      */ package mcframe.clientCore.beans.table;
/*      */ 
/*      */ import java.awt.Component;
/*      */ import java.awt.Point;
/*      */ import java.awt.Rectangle;
/*      */ import java.beans.PropertyChangeEvent;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.List;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class MCColumnLayout
/*      */   implements MCColumnLayoutMember
/*      */ {
/*      */   static final int SIZE_INVALID = -1;
/*   44 */   int _width = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   51 */   int _maxWidth = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   58 */   int _minWidth = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   65 */   int _preferredWidth = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   74 */   int _headerHeight = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   83 */   private List<MCColumnLayoutMember> members = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   90 */   private String _name = null;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _evtrun;
/*      */ 
/*      */ 
/*      */   
/*      */   private MCTableColumn _evtsrc;
/*      */ 
/*      */   
/*      */   private long _evtamount;
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  106 */     return String.valueOf(this._name) + " [" + (
/*  107 */       isVertical() ? "vertical" : "horizontal") + ", " + 
/*  108 */       "width:" + this._width + 
/*  109 */       "]";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getName() {
/*  121 */     return this._name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void initialized() {
/*  133 */     invalidateSizePropertyCache();
/*      */ 
/*      */     
/*  136 */     MCColumnLayout[] ls = getColumnLayouts(); byte b; int i; MCColumnLayout[] arrayOfMCColumnLayout1;
/*  137 */     for (i = (arrayOfMCColumnLayout1 = ls).length, b = 0; b < i; ) { MCColumnLayout l = arrayOfMCColumnLayout1[b];
/*  138 */       l.initialized();
/*      */       b++; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MCColumnLayout(String name) {
/*  173 */     this._evtrun = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  181 */     this._evtsrc = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  189 */     this._evtamount = 0L;
/*      */     this._name = name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setRunningPropertyChangeEvent(PropertyChangeEvent evt) {
/*  211 */     this._evtrun = true;
/*      */     
/*  213 */     if (evt != null) {
/*      */       
/*  215 */       this._evtsrc = (MCTableColumn)evt.getSource();
/*      */ 
/*      */       
/*  218 */       int newval = ((Integer)evt.getNewValue()).intValue();
/*  219 */       int oldval = ((Integer)evt.getOldValue()).intValue();
/*  220 */       this._evtamount = ((this._evtsrc != null && this._evtsrc.isVisible()) ? (
/*  221 */         newval - oldval) : 0L);
/*      */ 
/*      */       
/*  224 */       if (this._evtsrc != null) {
/*  225 */         MCColumnLayout[] ls = getColumnLayouts(); byte b; int i; MCColumnLayout[] arrayOfMCColumnLayout1;
/*  226 */         for (i = (arrayOfMCColumnLayout1 = ls).length, b = 0; b < i; ) { MCColumnLayout l = arrayOfMCColumnLayout1[b];
/*  227 */           if (l.contains(this._evtsrc)) {
/*  228 */             l.setRunningPropertyChangeEvent(evt);
/*      */             break;
/*      */           } 
/*      */           b++; }
/*      */       
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void cancelRunningPropertyChangeEvent() {
/*  251 */     if (this._evtsrc != null) {
/*  252 */       MCColumnLayout[] ls = getColumnLayouts(); byte b; int i; MCColumnLayout[] arrayOfMCColumnLayout1;
/*  253 */       for (i = (arrayOfMCColumnLayout1 = ls).length, b = 0; b < i; ) { MCColumnLayout l = arrayOfMCColumnLayout1[b];
/*  254 */         if (l.contains(this._evtsrc)) {
/*  255 */           l.cancelRunningPropertyChangeEvent();
/*      */           break;
/*      */         } 
/*      */         b++; }
/*      */     
/*      */     } 
/*  261 */     this._evtamount = 0L;
/*  262 */     this._evtsrc = null;
/*  263 */     this._evtrun = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setRunningPropertyChangeEvent(boolean cascade) {
/*  281 */     this._evtrun = true;
/*  282 */     this._evtsrc = null;
/*  283 */     this._evtamount = 0L;
/*      */     
/*  285 */     if (cascade) {
/*  286 */       MCColumnLayout[] ls = getColumnLayouts(); byte b; int i; MCColumnLayout[] arrayOfMCColumnLayout1;
/*  287 */       for (i = (arrayOfMCColumnLayout1 = ls).length, b = 0; b < i; ) { MCColumnLayout l = arrayOfMCColumnLayout1[b];
/*  288 */         l.setRunningPropertyChangeEvent(cascade);
/*      */         b++; }
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void cancelRunningPropertyChangeEvent(boolean cascade) {
/*  301 */     if (cascade) {
/*  302 */       MCColumnLayout[] ls = getColumnLayouts(); byte b; int i; MCColumnLayout[] arrayOfMCColumnLayout1;
/*  303 */       for (i = (arrayOfMCColumnLayout1 = ls).length, b = 0; b < i; ) { MCColumnLayout l = arrayOfMCColumnLayout1[b];
/*  304 */         l.cancelRunningPropertyChangeEvent(cascade);
/*      */         b++; }
/*      */     
/*      */     } 
/*  308 */     this._evtamount = 0L;
/*  309 */     this._evtsrc = null;
/*  310 */     this._evtrun = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isRunningPropertyChangeEvent() {
/*  321 */     return this._evtrun;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   MCTableColumn getPropertyChangeSource() {
/*  332 */     return this._evtsrc;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   long getPropertyChangeAmount() {
/*  343 */     return this._evtamount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void invalidateWidthCache(MCTableColumn src) {
/*  358 */     this._width = -1;
/*      */ 
/*      */     
/*  361 */     if (src != null) {
/*  362 */       MCColumnLayout[] ls = getColumnLayouts(); byte b; int i; MCColumnLayout[] arrayOfMCColumnLayout1;
/*  363 */       for (i = (arrayOfMCColumnLayout1 = ls).length, b = 0; b < i; ) { MCColumnLayout l = arrayOfMCColumnLayout1[b];
/*  364 */         if (l.contains(src)) {
/*  365 */           l.invalidateWidthCache(src);
/*      */           break;
/*      */         } 
/*      */         b++; }
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void invalidateMaxWidthCache(MCTableColumn src) {
/*  380 */     this._maxWidth = -1;
/*      */ 
/*      */     
/*  383 */     if (src != null) {
/*  384 */       MCColumnLayout[] ls = getColumnLayouts(); byte b; int i; MCColumnLayout[] arrayOfMCColumnLayout1;
/*  385 */       for (i = (arrayOfMCColumnLayout1 = ls).length, b = 0; b < i; ) { MCColumnLayout l = arrayOfMCColumnLayout1[b];
/*  386 */         if (l.contains(src)) {
/*  387 */           l.invalidateMaxWidthCache(src);
/*      */           break;
/*      */         } 
/*      */         b++; }
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void invalidateMinWidthCache(MCTableColumn src) {
/*  402 */     this._minWidth = -1;
/*      */ 
/*      */     
/*  405 */     if (src != null) {
/*  406 */       MCColumnLayout[] ls = getColumnLayouts(); byte b; int i; MCColumnLayout[] arrayOfMCColumnLayout1;
/*  407 */       for (i = (arrayOfMCColumnLayout1 = ls).length, b = 0; b < i; ) { MCColumnLayout l = arrayOfMCColumnLayout1[b];
/*  408 */         if (l.contains(src)) {
/*  409 */           l.invalidateMinWidthCache(src);
/*      */           break;
/*      */         } 
/*      */         b++; }
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void invalidatePreferredWidthCache(MCTableColumn src) {
/*  424 */     this._preferredWidth = -1;
/*      */ 
/*      */     
/*  427 */     if (src != null) {
/*  428 */       MCColumnLayout[] ls = getColumnLayouts(); byte b; int i; MCColumnLayout[] arrayOfMCColumnLayout1;
/*  429 */       for (i = (arrayOfMCColumnLayout1 = ls).length, b = 0; b < i; ) { MCColumnLayout l = arrayOfMCColumnLayout1[b];
/*  430 */         if (l.contains(src)) {
/*  431 */           l.invalidatePreferredWidthCache(src);
/*      */           break;
/*      */         } 
/*      */         b++; }
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void invalidateHeaderHeightCache(MCTableColumn src) {
/*  446 */     this._headerHeight = -1;
/*      */ 
/*      */     
/*  449 */     if (src != null) {
/*  450 */       MCColumnLayout[] ls = getColumnLayouts(); byte b; int i; MCColumnLayout[] arrayOfMCColumnLayout1;
/*  451 */       for (i = (arrayOfMCColumnLayout1 = ls).length, b = 0; b < i; ) { MCColumnLayout l = arrayOfMCColumnLayout1[b];
/*  452 */         if (l.contains(src)) {
/*  453 */           l.invalidateHeaderHeightCache(src);
/*      */           break;
/*      */         } 
/*      */         b++; }
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void invalidateSizePropertyCache() {
/*  467 */     invalidateWidthCache((MCTableColumn)null);
/*  468 */     invalidateMaxWidthCache((MCTableColumn)null);
/*  469 */     invalidateMinWidthCache((MCTableColumn)null);
/*  470 */     invalidatePreferredWidthCache((MCTableColumn)null);
/*  471 */     invalidateHeaderHeightCache((MCTableColumn)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void invalidateWidthCache(boolean cascade) {
/*  482 */     this._width = -1;
/*      */     
/*  484 */     if (cascade) {
/*  485 */       MCColumnLayout[] ls = getColumnLayouts(); byte b; int i; MCColumnLayout[] arrayOfMCColumnLayout1;
/*  486 */       for (i = (arrayOfMCColumnLayout1 = ls).length, b = 0; b < i; ) { MCColumnLayout l = arrayOfMCColumnLayout1[b];
/*  487 */         l.invalidateWidthCache(cascade);
/*      */         b++; }
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void invalidateMaxWidthCache(boolean cascade) {
/*  500 */     this._maxWidth = -1;
/*      */     
/*  502 */     if (cascade) {
/*  503 */       MCColumnLayout[] ls = getColumnLayouts(); byte b; int i; MCColumnLayout[] arrayOfMCColumnLayout1;
/*  504 */       for (i = (arrayOfMCColumnLayout1 = ls).length, b = 0; b < i; ) { MCColumnLayout l = arrayOfMCColumnLayout1[b];
/*  505 */         l.invalidateMaxWidthCache(cascade);
/*      */         b++; }
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void invalidateMinWidthCache(boolean cascade) {
/*  518 */     this._minWidth = -1;
/*      */     
/*  520 */     if (cascade) {
/*  521 */       MCColumnLayout[] ls = getColumnLayouts(); byte b; int i; MCColumnLayout[] arrayOfMCColumnLayout1;
/*  522 */       for (i = (arrayOfMCColumnLayout1 = ls).length, b = 0; b < i; ) { MCColumnLayout l = arrayOfMCColumnLayout1[b];
/*  523 */         l.invalidateMinWidthCache(cascade);
/*      */         b++; }
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void invalidatePreferredWidthCache(boolean cascade) {
/*  536 */     this._preferredWidth = -1;
/*      */     
/*  538 */     if (cascade) {
/*  539 */       MCColumnLayout[] ls = getColumnLayouts(); byte b; int i; MCColumnLayout[] arrayOfMCColumnLayout1;
/*  540 */       for (i = (arrayOfMCColumnLayout1 = ls).length, b = 0; b < i; ) { MCColumnLayout l = arrayOfMCColumnLayout1[b];
/*  541 */         l.invalidatePreferredWidthCache(cascade);
/*      */         b++; }
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void invalidateHeaderHeightCache(boolean cascade) {
/*  554 */     this._headerHeight = -1;
/*      */     
/*  556 */     if (cascade) {
/*  557 */       MCColumnLayout[] ls = getColumnLayouts(); byte b; int i; MCColumnLayout[] arrayOfMCColumnLayout1;
/*  558 */       for (i = (arrayOfMCColumnLayout1 = ls).length, b = 0; b < i; ) { MCColumnLayout l = arrayOfMCColumnLayout1[b];
/*  559 */         l.invalidateHeaderHeightCache(cascade);
/*      */         b++; }
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  611 */   static final WidthIO IO_WIDTH = new WidthIO()
/*      */     {
/*      */       public String propertyName() {
/*  614 */         return "width";
/*      */       }
/*      */       
/*      */       public int width(MCColumnLayoutMember member) {
/*  618 */         return member.getWidth();
/*      */       }
/*      */       
/*      */       public void width(MCColumnLayoutMember member, int width) {
/*  622 */         member.setWidth(width);
/*      */       }
/*      */     };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  631 */   static final WidthIO IO_MAXWIDTH = new WidthIO()
/*      */     {
/*      */       public String propertyName() {
/*  634 */         return "maxWidth";
/*      */       }
/*      */       
/*      */       public int width(MCColumnLayoutMember member) {
/*  638 */         return member.getMaxWidth();
/*      */       }
/*      */       
/*      */       public void width(MCColumnLayoutMember member, int width) {
/*  642 */         member.setMaxWidth(width);
/*      */       }
/*      */     };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  651 */   static final WidthIO IO_MINWIDTH = new WidthIO()
/*      */     {
/*      */       public String propertyName() {
/*  654 */         return "minWidth";
/*      */       }
/*      */       
/*      */       public int width(MCColumnLayoutMember member) {
/*  658 */         return member.getMinWidth();
/*      */       }
/*      */       
/*      */       public void width(MCColumnLayoutMember member, int width) {
/*  662 */         member.setMinWidth(width);
/*      */       }
/*      */     };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  671 */   static final WidthIO IO_PREFERREDWIDTH = new WidthIO()
/*      */     {
/*      */       public String propertyName() {
/*  674 */         return "preferredWidth";
/*      */       }
/*      */       
/*      */       public int width(MCColumnLayoutMember member) {
/*  678 */         return member.getPreferredWidth();
/*      */       }
/*      */       
/*      */       public void width(MCColumnLayoutMember member, int width) {
/*  682 */         member.setPreferredWidth(width);
/*      */       }
/*      */     };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getWidth() {
/*  701 */     if (this._width == -1) {
/*  702 */       int width = calcWidth(IO_WIDTH);
/*  703 */       IO_WIDTH.width(this, width);
/*      */     } 
/*  705 */     return this._width;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMaxWidth() {
/*  710 */     if (this._maxWidth == -1) {
/*  711 */       int width = calcWidth(IO_MAXWIDTH);
/*  712 */       IO_MAXWIDTH.width(this, width);
/*      */     } 
/*  714 */     return this._maxWidth;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getMinWidth() {
/*  719 */     if (this._minWidth == -1) {
/*  720 */       int width = calcWidth(IO_MINWIDTH);
/*  721 */       IO_MINWIDTH.width(this, width);
/*      */     } 
/*  723 */     return this._minWidth;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getPreferredWidth() {
/*  728 */     if (this._preferredWidth == -1) {
/*  729 */       int width = calcWidth(IO_PREFERREDWIDTH);
/*  730 */       IO_PREFERREDWIDTH.width(this, width);
/*      */     } 
/*  732 */     return this._preferredWidth;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setWidth(int width) {
/*  750 */     if (this._width == width) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  758 */     width = setMemberWidth(IO_WIDTH, this._width, width);
/*  759 */     this._width = width;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMaxWidth(int width) {
/*  775 */     this._maxWidth = width;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMinWidth(int width) {
/*  791 */     this._minWidth = width;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setPreferredWidth(int width) {
/*  796 */     if (this._preferredWidth == width) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  804 */     width = setMemberWidth(IO_PREFERREDWIDTH, this._preferredWidth, width);
/*  805 */     this._preferredWidth = width;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDefault() {
/*  819 */     setRunningPropertyChangeEvent((PropertyChangeEvent)null);
/*      */ 
/*      */     
/*  822 */     invalidateWidthCache((MCTableColumn)null);
/*  823 */     invalidatePreferredWidthCache((MCTableColumn)null);
/*      */ 
/*      */     
/*  826 */     for (MCColumnLayoutMember m : this.members) {
/*  827 */       m.setDefault();
/*      */     }
/*      */ 
/*      */     
/*  831 */     cancelRunningPropertyChangeEvent();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MCHeaderRendererCommon getHeaderRenderer(MCTableColumn col) {
/*  851 */     MCLayoutTableHeader h = 
/*  852 */       (MCLayoutTableHeader)col.getTable().getTableHeader();
/*  853 */     return h.getHeaderRenderer(col);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getHeaderColumnHeight(MCTableColumn column) {
/*  870 */     MCHeaderRendererCommon renderer = getHeaderRenderer(column);
/*      */     
/*  872 */     Component comp = renderer.getTableCellRendererComponent(
/*  873 */         column.getBaseTable(), 
/*  874 */         (Comparable)column.getHeaderValue(), 
/*  875 */         false, false, -1, -1, column);
/*  876 */     return (comp.getPreferredSize()).height;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void add(MCColumnConfig col) {
/*  976 */     addMember((MCTableColumn)col);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void add(MCColumnLayout layout) {
/*  989 */     if (layout == this) {
/*      */       return;
/*      */     }
/*  992 */     addMember(layout);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean addMember(MCColumnLayoutMember obj) {
/* 1004 */     if (obj == null) {
/* 1005 */       return false;
/*      */     }
/* 1007 */     if (this.members.add(obj)) {
/* 1008 */       invalidateSizePropertyCache();
/* 1009 */       return true;
/*      */     } 
/* 1011 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getMemberCount() {
/* 1022 */     return this.members.size();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MCColumnLayoutMember[] getMembers() {
/* 1036 */     return this.members.<MCColumnLayoutMember>toArray(new MCColumnLayoutMember[this.members.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getVisibleMemberCount() {
/* 1047 */     int visibles = 0;
/* 1048 */     for (MCColumnLayoutMember m : this.members) {
/* 1049 */       if (m.isVisible()) {
/* 1050 */         visibles++;
/*      */       }
/*      */     } 
/* 1053 */     return visibles;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MCColumnLayoutMember[] getVisibleMembers() {
/* 1067 */     MCColumnLayoutMember[] visibles = 
/* 1068 */       new MCColumnLayoutMember[this.members.size()];
/* 1069 */     int cnt = 0;
/* 1070 */     for (MCColumnLayoutMember m : this.members) {
/* 1071 */       if (m.isVisible()) {
/* 1072 */         visibles[cnt++] = m;
/*      */       }
/*      */     } 
/* 1075 */     return Arrays.<MCColumnLayoutMember>copyOf(visibles, cnt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MCColumnLayoutMember getLastVisibleMember() {
/* 1088 */     int pos = this.members.size() - 1;
/* 1089 */     for (int i = pos; i >= 0; i--) {
/* 1090 */       MCColumnLayoutMember m = this.members.get(i);
/* 1091 */       if (m.isVisible()) {
/* 1092 */         return m;
/*      */       }
/*      */     } 
/* 1095 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCColumnLayout[] getColumnLayouts() {
/* 1108 */     MCColumnLayout[] ls = new MCColumnLayout[this.members.size()];
/* 1109 */     int size = 0;
/* 1110 */     for (MCColumnLayoutMember m : this.members) {
/* 1111 */       if (m instanceof MCColumnLayout) {
/* 1112 */         ls[size++] = (MCColumnLayout)m;
/*      */       }
/*      */     } 
/* 1115 */     return Arrays.<MCColumnLayout>copyOf(ls, size);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCColumnLayout getColumnLayout(MCColumnConfig col) {
/* 1131 */     MCColumnLayout belong = null;
/* 1132 */     for (MCColumnLayoutMember m : this.members) {
/* 1133 */       if (m instanceof MCColumnLayout) {
/* 1134 */         belong = ((MCColumnLayout)m).getColumnLayout(col);
/* 1135 */         if (belong != null)
/*      */           break; 
/*      */         continue;
/*      */       } 
/* 1139 */       if (m == col) {
/* 1140 */         belong = this;
/*      */         break;
/*      */       } 
/*      */     } 
/* 1144 */     return belong;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MCColumnConfig[] getAllColumnConfigs() {
/* 1163 */     return (MCColumnConfig[])getAllColumns();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MCTableColumn[] getAllColumns() {
/* 1182 */     List<MCTableColumn> l = new ArrayList<>();
/* 1183 */     for (MCColumnLayoutMember m : this.members) {
/* 1184 */       if (m instanceof MCColumnLayout) {
/* 1185 */         MCTableColumn[] cs = ((MCColumnLayout)m).getAllColumns(); byte b; int i; MCTableColumn[] arrayOfMCTableColumn1;
/* 1186 */         for (i = (arrayOfMCTableColumn1 = cs).length, b = 0; b < i; ) { MCTableColumn c = arrayOfMCTableColumn1[b];
/* 1187 */           l.add(c); b++; }
/*      */          continue;
/*      */       } 
/* 1190 */       if (m instanceof MCTableColumn) {
/* 1191 */         l.add((MCTableColumn)m);
/*      */       }
/*      */     } 
/* 1194 */     return l.<MCTableColumn>toArray(new MCTableColumn[l.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getAllColumnCount() {
/* 1208 */     int cnt = 0;
/* 1209 */     for (MCColumnLayoutMember m : this.members) {
/* 1210 */       if (m instanceof MCColumnLayout) {
/* 1211 */         cnt += ((MCColumnLayout)m).getAllColumnCount(); continue;
/*      */       } 
/* 1213 */       if (m instanceof MCColumnConfig) {
/* 1214 */         cnt++;
/*      */       }
/*      */     } 
/* 1217 */     return cnt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean contains(MCColumnConfig col) {
/* 1231 */     for (MCColumnLayoutMember m : this.members) {
/* 1232 */       if (m instanceof MCColumnLayout) {
/* 1233 */         if (((MCColumnLayout)m).contains(col))
/* 1234 */           return true; 
/*      */         continue;
/*      */       } 
/* 1237 */       if (m == col) {
/* 1238 */         return true;
/*      */       }
/*      */     } 
/* 1241 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isVisible() {
/* 1253 */     for (MCColumnLayoutMember m : this.members) {
/* 1254 */       if (m.isVisible()) {
/* 1255 */         return true;
/*      */       }
/*      */     } 
/* 1258 */     return false;
/*      */   }
/*      */   
/*      */   public abstract boolean isVertical();
/*      */   
/*      */   public abstract int getTierCount();
/*      */   
/*      */   abstract int calcWidth(WidthIO paramWidthIO);
/*      */   
/*      */   abstract int setMemberWidth(WidthIO paramWidthIO, int paramInt1, int paramInt2);
/*      */   
/*      */   public abstract int getHeaderHeight();
/*      */   
/*      */   abstract int headerColumnAtPoint(Point paramPoint, int paramInt);
/*      */   
/*      */   abstract Rectangle getHeaderRect(Rectangle paramRectangle, MCTableColumn paramMCTableColumn);
/*      */   
/*      */   abstract int columnAtPoint(Point paramPoint, int paramInt1, int paramInt2);
/*      */   
/*      */   abstract Rectangle getCellRect(Rectangle paramRectangle, MCTableColumn paramMCTableColumn, int paramInt);
/*      */   
/*      */   static interface WidthIO {
/*      */     String propertyName();
/*      */     
/*      */     int width(MCColumnLayoutMember param1MCColumnLayoutMember);
/*      */     
/*      */     void width(MCColumnLayoutMember param1MCColumnLayoutMember, int param1Int);
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCColumnLayout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */