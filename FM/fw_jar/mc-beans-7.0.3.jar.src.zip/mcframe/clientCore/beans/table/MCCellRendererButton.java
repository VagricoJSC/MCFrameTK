/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.table.TableCellRenderer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCCellRendererButton
/*     */   extends JButton
/*     */   implements TableCellRenderer
/*     */ {
/*     */   private final MCColumnConfig _column;
/*  38 */   private Border _default_border = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   private MCEditorButton _temp = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCCellRendererButton(MCColumnConfig column) {
/*  56 */     this._column = column;
/*  57 */     setOpaque(true);
/*  58 */     setHorizontalAlignment(4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCColumnConfig getColumnConfig() {
/*  69 */     return this._column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setDefaultBorder(Border border) {
/*  81 */     this._default_border = border;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Border getDefaultBorder() {
/*  97 */     return this._default_border;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Component getTableCellRendererComponent(JTable table, Object value, boolean selected, boolean focused, int index, int column) {
/* 115 */     MCTable<?> t = (MCTable)table;
/* 116 */     boolean f = focused ? focused : MCCellUtil.hasFocus(t, index, column);
/* 117 */     return getRenderer(t, value, selected, f, index, getColumnConfig());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Component getRenderer(MCTable<?> table, Object value, boolean selected, boolean focused, int index, MCColumnConfig column) {
/* 135 */     int horizontal = column.getHorizontalAlignment();
/* 136 */     if (horizontal == -1) {
/* 137 */       horizontal = 4;
/*     */     }
/* 139 */     setHorizontalAlignment(horizontal);
/* 140 */     Border def_border = getDefaultBorder();
/* 141 */     if (def_border == null) {
/* 142 */       setDefaultBorder(getBorder());
/*     */     }
/* 144 */     MCCellUtil.initRenderer(this, index, column, table, selected, focused, 
/* 145 */         getDefaultBorder());
/*     */     
/* 147 */     MCCellConfig conf = column.getCellConfig();
/* 148 */     setText(conf.getButtonColumnValue(index, column, table, selected));
/*     */     
/* 150 */     Icon icon = conf.getButtonColumnIcon(index, column, table, selected);
/* 151 */     icon = adjustIconSize(icon, index, table);
/* 152 */     setIcon(icon);
/*     */     
/* 154 */     Color bg = getBackground();
/* 155 */     setOpaque(!(bg != null && bg.equals(table.getBackground()) && table.isOpaque()));
/* 156 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Icon adjustIconSize(Icon icon, int index, MCTable<?> table) {
/* 174 */     MCColumnConfig c = getColumnConfig();
/* 175 */     if (!c.isVisible()) {
/* 176 */       return icon;
/*     */     }
/* 178 */     if (!(icon instanceof javax.swing.ImageIcon)) {
/* 179 */       return icon;
/*     */     }
/* 181 */     if (this._temp == null) {
/* 182 */       this._temp = MCTableCompatibilityFactory.createEditorButton(c.getName(), c);
/*     */     }
/* 184 */     this._temp.setIcon(icon);
/* 185 */     Dimension d = new Dimension(c.getColumnWidth() - table.getColumnMargin(), table
/* 186 */         .getRowHeight(index) - 
/* 187 */         table.getRowMargin());
/* 188 */     this._temp.setSize(d);
/* 189 */     this._temp.setPreferredSize(d);
/* 190 */     return this._temp.getIcon();
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCCellRendererButton.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */