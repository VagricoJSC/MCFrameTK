/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import javax.swing.DefaultCellEditor;
/*     */ import javax.swing.InputVerifier;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextField;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MCCellEditor
/*     */   extends DefaultCellEditor
/*     */ {
/*     */   private final MCColumnConfig _column;
/*     */   
/*     */   protected MCCellEditor(JTextField compo, MCColumnConfig column) {
/*  40 */     super(compo);
/*  41 */     setClickCountToStart(1);
/*  42 */     this._column = column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCCellEditor(JComboBox<?> compo, MCColumnConfig column) {
/*  54 */     super(compo);
/*  55 */     setClickCountToStart(1);
/*  56 */     this._column = column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCCellEditor(JCheckBox compo, MCColumnConfig column) {
/*  68 */     super(compo);
/*  69 */     setClickCountToStart(1);
/*  70 */     this._column = column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCColumnConfig getColumnConfig() {
/*  81 */     return this._column;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getCellEditorValue() {
/*  86 */     return ((MCEditorBeans)this.editorComponent).getViewValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean stopCellEditing() {
/*  93 */     if (!(this._column.getBaseTable()).canRemoveEditor) {
/*  94 */       return false;
/*     */     }
/*  96 */     Component c = getComponent();
/*  97 */     JComponent j = null;
/*  98 */     boolean valid = true;
/*     */     
/* 100 */     if (c instanceof JComponent) {
/* 101 */       j = (JComponent)c;
/* 102 */       InputVerifier v = j.getInputVerifier();
/* 103 */       if (v != null) {
/* 104 */         valid = v.verify(j);
/*     */       }
/*     */     } 
/* 107 */     if (valid) {
/* 108 */       fireEditingStopped();
/*     */     } else {
/*     */       
/* 111 */       JTable jt = (JTable)j.getParent();
/* 112 */       int row = jt.getEditingRow();
/* 113 */       jt.getSelectionModel().setSelectionInterval(row, row);
/*     */     } 
/* 115 */     return valid;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCCellEditor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */