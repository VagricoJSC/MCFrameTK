/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.MouseEvent;
/*     */ import javax.swing.plaf.TableHeaderUI;
/*     */ import javax.swing.table.JTableHeader;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import mcframe.clientCore.beans.layout.MCHiresoManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCTable2Header
/*     */   extends JTableHeader
/*     */ {
/*     */   private static final String uiClassID = "MCTable2HeaderUI";
/*     */   
/*     */   public MCTable2Header(TableColumnModel model) {
/*  39 */     super(model);
/*  40 */     setReorderingAllowed(true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUIClassID() {
/*  48 */     return "MCTable2HeaderUI";
/*     */   }
/*     */ 
/*     */   
/*     */   public MCTable2HeaderUI getUI() {
/*  53 */     return (MCTable2HeaderUI)this.ui;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCTable2ColumnModel getTable2ColumnModel() {
/*  68 */     return (MCTable2ColumnModel)getColumnModel();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCTable<?> getMCTable() {
/*  81 */     return (MCTable)getTable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getToolTipText(MouseEvent event) {
/*  95 */     String tip = null;
/*  96 */     Point p = event.getPoint();
/*     */     
/*     */     int column;
/*  99 */     if ((column = columnAtPoint(p)) != -1) {
/* 100 */       MCColumnConfig aColumn = 
/* 101 */         (MCColumnConfig)this.columnModel.getColumn(column);
/* 102 */       if (aColumn.isToolTipEnabled()) {
/* 103 */         tip = aColumn.getMessageByLocale();
/*     */       }
/*     */     } 
/*     */     
/* 107 */     if (tip == null) {
/* 108 */       tip = getToolTipText();
/*     */     }
/*     */ 
/*     */     
/* 112 */     tip = MCHiresoManager.getToolTipText(this, tip);
/* 113 */     return tip;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int columnAtPoint(Point point) {
/* 119 */     MCTable<?> t = getMCTable();
/* 120 */     return (t instanceof MCTable2) ? 
/*     */       
/* 122 */       scrollColumnAtPoint((MCTable2)t, point) : 
/*     */       
/* 124 */       super.columnAtPoint(point);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int scrollColumnAtPoint(MCTable2<?> table, Point point) {
/* 145 */     int x = point.x;
/* 146 */     MCTable2ColumnModel cm = getTable2ColumnModel();
/*     */ 
/*     */     
/* 149 */     int tier_w = 0;
/* 150 */     int tier = tierAtPoint(table, point);
/* 151 */     if (tier < 0)
/*     */     {
/* 153 */       return -1;
/*     */     }
/* 155 */     int[] se = cm.getTierColumnIndex(tier); int i;
/* 156 */     for (i = se[0]; i < se[1]; i++) {
/* 157 */       tier_w += cm.getColumn(i).getWidth();
/*     */     }
/* 159 */     if (tier_w <= point.x)
/*     */     {
/* 161 */       return -1;
/*     */     }
/*     */ 
/*     */     
/* 165 */     for (i = 0; i < se[0]; i++) {
/* 166 */       x += cm.getColumn(i).getWidth();
/*     */     }
/* 168 */     return getColumnModel().getColumnIndexAtX(x);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int tierAtPoint(MCTable2<?> table, Point point) {
/* 183 */     int y = point.y;
/* 184 */     MCTable2HeaderUI ui = getUI();
/* 185 */     int cnt = getTable2ColumnModel().getReturnCount();
/* 186 */     for (int i = 0; i < cnt; i++) {
/* 187 */       y -= ui.getTierHeight(table, i);
/* 188 */       if (y < 0) {
/* 189 */         return i;
/*     */       }
/*     */     } 
/* 192 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Rectangle getHeaderRect(int column) {
/* 198 */     return (this.table instanceof MCTable2) ? 
/*     */       
/* 200 */       getScrollHeaderRect(column) : 
/*     */       
/* 202 */       super.getHeaderRect(column);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Rectangle getScrollHeaderRect(int column) {
/* 220 */     Rectangle r = new Rectangle();
/* 221 */     MCTable2ColumnModel cm = getTable2ColumnModel();
/*     */     
/* 223 */     if (column >= 0)
/*     */     {
/*     */       
/* 226 */       if (column >= cm.getColumnCount()) {
/* 227 */         r.x = getWidth();
/*     */       } else {
/*     */         
/* 230 */         int fixcnt = cm.getFixedColumnCount();
/* 231 */         int[] retpos = cm.getReturnPositions();
/* 232 */         int tier = 0;
/* 233 */         int allcolumn = column + fixcnt;
/* 234 */         MCTable2<?> t = (MCTable2)getMCTable();
/* 235 */         MCTable2HeaderUI ui = getUI();
/*     */ 
/*     */         
/* 238 */         for (tier = 0; retpos[tier] < allcolumn; tier++) {
/* 239 */           r.y += ui.getTierHeight(t, tier);
/*     */         }
/*     */         
/* 242 */         int[] se = cm.getTierColumnIndex(tier);
/* 243 */         for (int i = se[0]; i < column; i++) {
/* 244 */           r.x += cm.getColumn(i).getWidth();
/*     */         }
/*     */         
/* 247 */         r.width = cm.getColumn(column).getWidth();
/* 248 */         r.height = ui.getTierHeight(t, tier);
/*     */       }  } 
/* 250 */     return r;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCTable2Header.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */