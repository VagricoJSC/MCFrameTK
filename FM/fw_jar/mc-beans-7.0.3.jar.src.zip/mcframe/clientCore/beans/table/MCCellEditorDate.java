/*    */ package mcframe.clientCore.beans.table;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import javax.swing.JTable;
/*    */ import javax.swing.JTextField;
/*    */ import mcframe.commonCore.lang.MCCalendarDate;
/*    */ import mcframe.commonCore.lang.MCDate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCCellEditorDate
/*    */   extends MCCellEditor
/*    */ {
/*    */   protected MCCellEditorDate(String name, MCColumnConfig column) {
/* 28 */     super((JTextField)new MCEditorDateField(name, column), column);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected MCEditorDateField getEditorComponent() {
/* 39 */     return (MCEditorDateField)this.editorComponent;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public final Component getTableCellEditorComponent(JTable table, Object value, boolean selected, int index, int column) {
/* 57 */     return (Component)getEditor((MCTable)table, (MCDate)value, index, getColumnConfig());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected MCEditorDateField getEditor(MCTable<?> table, MCDate value, int index, MCColumnConfig column) {
/* 73 */     MCEditorDateField compo = getEditorComponent();
/* 74 */     compo.setText("");
/* 75 */     compo.setColumnInfo(index, column);
/* 76 */     compo.setText((MCCalendarDate)value);
/* 77 */     return compo;
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCCellEditorDate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */