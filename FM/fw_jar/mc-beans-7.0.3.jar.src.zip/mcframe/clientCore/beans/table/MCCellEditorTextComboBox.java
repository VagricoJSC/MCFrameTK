/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import javax.swing.DefaultCellEditor;
/*     */ import javax.swing.InputVerifier;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextField;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCCellEditorTextComboBox
/*     */   extends DefaultCellEditor
/*     */ {
/*     */   private final MCColumnConfig _column;
/*     */   
/*     */   protected MCCellEditorTextComboBox(String name, MCColumnConfig column) {
/*  40 */     super(new JTextField());
/*     */     
/*  42 */     this.editorComponent = (JComponent)new MCEditorTextComboBox(name, column);
/*  43 */     this._column = column;
/*  44 */     setClickCountToStart(1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCColumnConfig getColumnConfig() {
/*  55 */     return this._column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCEditorTextComboBox getEditorComponent() {
/*  66 */     return (MCEditorTextComboBox)this.editorComponent;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Component getTableCellEditorComponent(JTable table, Object value, boolean selected, int index, int column) {
/*  72 */     return (Component)getEditor((MCTable)table, value, index, getColumnConfig());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCEditorTextComboBox getEditor(MCTable<?> table, Object value, int index, MCColumnConfig column) {
/*  88 */     MCEditorTextComboBox c = getEditorComponent();
/*  89 */     c.setColumnInfo(index, column);
/*  90 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Component getDummyTableCellEditorComponent(MCConstRow dummy) {
/* 102 */     return (Component)getDummyEditor(getColumnConfig(), dummy);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCEditorTextComboBox getDummyEditor(MCColumnConfig column, MCConstRow dummy) {
/* 115 */     MCEditorTextComboBox compo = getEditorComponent();
/* 116 */     compo.setDummyColumnInfo(column, dummy);
/* 117 */     return compo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean stopCellEditing() {
/* 124 */     if (!(this._column.getBaseTable()).canRemoveEditor) {
/* 125 */       return false;
/*     */     }
/* 127 */     Component c = getComponent();
/* 128 */     JComponent j = null;
/* 129 */     boolean valid = true;
/*     */     
/* 131 */     if (c instanceof JComponent) {
/* 132 */       j = (JComponent)c;
/* 133 */       InputVerifier v = j.getInputVerifier();
/* 134 */       if (v != null) {
/* 135 */         valid = v.verify(j);
/*     */       }
/*     */     } 
/* 138 */     if (valid) {
/* 139 */       fireEditingStopped();
/*     */     } else {
/*     */       
/* 142 */       JTable jt = (JTable)j.getParent();
/* 143 */       int row = jt.getEditingRow();
/* 144 */       jt.getSelectionModel().setSelectionInterval(row, row);
/*     */     } 
/* 146 */     return valid;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCCellEditorTextComboBox.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */