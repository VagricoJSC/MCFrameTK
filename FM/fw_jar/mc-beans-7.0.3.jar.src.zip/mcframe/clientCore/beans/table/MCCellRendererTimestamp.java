/*    */ package mcframe.clientCore.beans.table;
/*    */ 
/*    */ import mcframe.clientCore.beans.MCMode;
/*    */ import mcframe.commonCore.lang.MCCalendarDate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCCellRendererTimestamp
/*    */   extends MCCellRendererField
/*    */ {
/*    */   protected MCCellRendererTimestamp(MCColumnConfig column) {
/* 24 */     super(column);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void setValue(Object value) {
/* 29 */     MCColumnConfig col = getColumnConfig();
/* 30 */     MCCellConfig cfg = col.getCellConfig();
/* 31 */     int index = getRowIndex();
/* 32 */     MCTable<?> table = col.getTable();
/* 33 */     MCMode mode = cfg.isCellEditable(index, col, table);
/* 34 */     super.setValue(cfg.getCellTimestampFormat(index, col, table, mode)
/* 35 */         .doOutputFormat((MCCalendarDate)value));
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCCellRendererTimestamp.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */