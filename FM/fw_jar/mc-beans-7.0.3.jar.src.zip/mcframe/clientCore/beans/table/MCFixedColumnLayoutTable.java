/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.util.Iterator;
/*     */ import javax.swing.SizeSequence;
/*     */ import javax.swing.table.JTableHeader;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCFixedColumnLayoutTable<E extends MCConstRow>
/*     */   extends MCFixedColumnTable<E>
/*     */ {
/*     */   private static final String uiClassID = "MCLayoutTableUI";
/*     */   
/*     */   public MCFixedColumnLayoutTable(MCLayoutTable<E> table, String name) {
/*  44 */     super(table, name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTierCount() {
/*  56 */     MCLayoutTable<E> bt = getBodyLayoutTable();
/*  57 */     return bt.getTierCount();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCLayoutTable<E> getBodyLayoutTable() {
/*  76 */     return (MCLayoutTable<E>)getBodyTable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCFixedColumnLayoutTable<E> getFixedColumnLayoutTable() {
/*  95 */     return (MCFixedColumnLayoutTable<E>)getFixedColumnTable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUIClassID() {
/* 104 */     return "MCLayoutTableUI";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JTableHeader createDefaultTableHeader() {
/* 116 */     return new MCLayoutTableHeader(
/* 117 */         getColumnModel());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MCLayoutTableHeader getTableHeader() {
/* 123 */     return (MCLayoutTableHeader)super.getTableHeader();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCLayoutTableColumnModel createDefaultColumnModel() {
/* 129 */     return new MCLayoutTableColumnModel();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MCLayoutTableColumnModel getColumnModel() {
/* 135 */     return (MCLayoutTableColumnModel)super.getColumnModel();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setRenderers() {
/* 141 */     getTableHeader().setDefaultRenderer(
/* 142 */         new MCMultiLineHeaderRenderer(
/* 143 */           getTableHeader().getDefaultRenderer()));
/*     */   }
/*     */ 
/*     */   
/*     */   void initColumns() {
/* 148 */     super.initColumns();
/*     */ 
/*     */     
/* 151 */     MCColumnLayout[] ls = getColumnModel().getColumnLayouts(); byte b; int i; MCColumnLayout[] arrayOfMCColumnLayout1;
/* 152 */     for (i = (arrayOfMCColumnLayout1 = ls).length, b = 0; b < i; ) { MCColumnLayout l = arrayOfMCColumnLayout1[b];
/* 153 */       l.initialized();
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUnscrollColumn(MCColumnConfig column) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void updateColumnsFontSize(int fontratio, int widthratio, boolean check) {
/* 170 */     MCColumnLayout[] ls = getColumnModel().getColumnLayouts(); byte b; int i; MCColumnLayout[] arrayOfMCColumnLayout1;
/* 171 */     for (i = (arrayOfMCColumnLayout1 = ls).length, b = 0; b < i; ) { MCColumnLayout l = arrayOfMCColumnLayout1[b];
/* 172 */       l.setRunningPropertyChangeEvent((PropertyChangeEvent)null);
/* 173 */       l.invalidateWidthCache((MCTableColumn)null);
/* 174 */       l.invalidateMinWidthCache((MCTableColumn)null);
/* 175 */       l.invalidatePreferredWidthCache((MCTableColumn)null);
/*     */       b++; }
/*     */     
/* 178 */     super.updateColumnsFontSize(fontratio, widthratio, check);
/*     */     
/* 180 */     for (i = (arrayOfMCColumnLayout1 = ls).length, b = 0; b < i; ) { MCColumnLayout l = arrayOfMCColumnLayout1[b];
/* 181 */       l.cancelRunningPropertyChangeEvent();
/*     */       b++; }
/*     */   
/*     */   }
/*     */   
/*     */   void adjustWidth(boolean all) {
/* 187 */     getBaseTable().adjustWidth(all);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int rowAtPoint(Point point) {
/* 205 */     Point p = new Point(point);
/* 206 */     int tier = getTierCount();
/* 207 */     p.y /= tier;
/* 208 */     return super.rowAtPoint(p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int columnAtPoint(Point point) {
/* 219 */     int pos = 0;
/* 220 */     int x = 0;
/* 221 */     int y = 0;
/*     */     
/* 223 */     int row = rowAtPoint(point);
/* 224 */     if (row < 0) {
/* 225 */       return -1;
/*     */     }
/* 227 */     int tiercnt = getTierCount();
/* 228 */     for (int i = 0; i < row; i++) {
/* 229 */       y += getRowHeight(i) * tiercnt;
/*     */     }
/* 231 */     point.y -= y;
/* 232 */     if (point.y < 0) {
/* 233 */       point.y = 0;
/*     */     }
/*     */     
/* 236 */     int height = getRowHeight(row);
/*     */     
/* 238 */     MCLayoutTableColumnModel cm = getColumnModel();
/* 239 */     Iterator<MCColumnLayoutMember> iterator = 
/* 240 */       cm.createLayoutMemberIterator();
/* 241 */     while (iterator.hasNext()) {
/* 242 */       MCColumnLayoutMember member = iterator.next();
/* 243 */       if (member instanceof MCColumnLayout) {
/* 244 */         MCColumnLayout l = (MCColumnLayout)member;
/* 245 */         int lw = l.getWidth();
/* 246 */         if (x + lw > point.x) {
/*     */           
/* 248 */           Point p = point.getLocation();
/* 249 */           p.x -= x;
/* 250 */           pos += l.columnAtPoint(p, height * tiercnt, height);
/*     */           break;
/*     */         } 
/* 253 */         x += lw;
/* 254 */         pos += l.getAllColumnCount(); continue;
/*     */       } 
/* 256 */       if (member instanceof MCTableColumn) {
/* 257 */         x += ((MCTableColumn)member).getWidth();
/* 258 */         if (x > point.x) {
/*     */           break;
/*     */         }
/*     */ 
/*     */         
/* 263 */         pos++;
/*     */       } 
/*     */     } 
/*     */     
/* 267 */     return (cm.getColumnCount() > pos) ? pos : -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Rectangle getCellRect(int row, int column, boolean includeSpacing) {
/* 278 */     Rectangle r = new Rectangle();
/* 279 */     boolean valid = true;
/* 280 */     int tier = getTierCount();
/*     */     
/* 282 */     if (row < 0) {
/*     */       
/* 284 */       valid = false;
/*     */     }
/* 286 */     else if (row >= getRowCount()) {
/* 287 */       r.y = getHeight();
/* 288 */       valid = false;
/*     */     } else {
/*     */       
/* 291 */       r.height = getRowHeight(row) * tier;
/* 292 */       SizeSequence rowModel = getRowModel();
/* 293 */       r.y = (rowModel == null) ? (row * r.height) : rowModel.getPosition(row);
/* 294 */       r.y *= tier;
/*     */     } 
/*     */     
/* 297 */     if (column < 0) {
/*     */       
/* 299 */       valid = false;
/*     */     }
/* 301 */     else if (column >= getColumnModel().getColumnCount()) {
/* 302 */       r.x = getWidth();
/*     */       
/* 304 */       valid = false;
/*     */     } else {
/*     */       
/* 307 */       int pos = 0;
/* 308 */       MCLayoutTableColumnModel cm = getColumnModel();
/* 309 */       Iterator<MCColumnLayoutMember> iterator = 
/* 310 */         cm.createLayoutMemberIterator();
/* 311 */       while (iterator.hasNext()) {
/* 312 */         MCColumnLayoutMember member = iterator.next();
/* 313 */         if (member instanceof MCColumnLayout) {
/* 314 */           MCColumnLayout l = (MCColumnLayout)member;
/* 315 */           int cnt = l.getAllColumnCount();
/* 316 */           if (pos + cnt > column) {
/*     */             
/* 318 */             MCTableColumn col = cm.getColumn(column);
/* 319 */             r = l.getCellRect(r, col, getRowHeight());
/*     */             break;
/*     */           } 
/* 322 */           r.x += l.getWidth();
/* 323 */           pos += cnt; continue;
/*     */         } 
/* 325 */         if (member instanceof MCTableColumn) {
/* 326 */           int w = ((MCTableColumn)member).getWidth();
/* 327 */           if (pos == column) {
/*     */             
/* 329 */             r.width = w;
/*     */             break;
/*     */           } 
/* 332 */           r.x += w;
/* 333 */           pos++;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 338 */     if (valid && !includeSpacing) {
/* 339 */       int rm = Math.min(getRowMargin(), r.height);
/* 340 */       int cm = Math.min(getColumnModel().getColumnMargin(), r.width);
/* 341 */       r.setBounds(r.x + cm / 2, r.y + rm / 2, r.width - cm, r.height - rm);
/*     */     } 
/* 343 */     return r;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doLayout() {
/* 362 */     TableColumn resizingColumn = getResizingColumn();
/* 363 */     if (resizingColumn == null) {
/* 364 */       setWidthsFromPreferredWidths(false);
/*     */     } else {
/*     */       
/* 367 */       int columnIndex = viewIndexForColumn(resizingColumn);
/* 368 */       int delta = getWidth() - getColumnModel().getTotalColumnWidth();
/* 369 */       accommodateDelta(columnIndex, delta);
/* 370 */       delta = getWidth() - getColumnModel().getTotalColumnWidth();
/* 371 */       if (delta != 0) {
/* 372 */         resizingColumn.setWidth(resizingColumn.getWidth() + delta);
/*     */       }
/* 374 */       setWidthsFromPreferredWidths(true);
/*     */     } 
/*     */ 
/*     */     
/* 378 */     layout();
/*     */   }
/*     */ 
/*     */   
/*     */   private TableColumn getResizingColumn() {
/* 383 */     return (this.tableHeader == null) ? 
/* 384 */       null : this.tableHeader.getResizingColumn();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int viewIndexForColumn(TableColumn aColumn) {
/* 398 */     TableColumnModel cm = getColumnModel();
/* 399 */     for (int column = 0; column < cm.getColumnCount(); column++) {
/* 400 */       if (cm.getColumn(column) == aColumn) {
/* 401 */         return column;
/*     */       }
/*     */     } 
/* 404 */     return -1;
/*     */   }
/*     */   
/*     */   private void accommodateDelta(int resizingColumnIndex, int delta) {
/* 408 */     final MCColumnLayoutMember[] ms = 
/* 409 */       getColumnModel().getLayoutMemberArray();
/* 410 */     int columnCount = ms.length;
/* 411 */     int to = columnCount;
/* 412 */     int from = 0;
/* 413 */     MCTableColumn col = getColumnModel().getColumn(resizingColumnIndex);
/* 414 */     for (int i = 0; i < ms.length; i++) {
/* 415 */       MCColumnLayoutMember m = ms[i];
/* 416 */       if (m instanceof MCColumnLayout) {
/* 417 */         if (((MCColumnLayout)m).contains(col)) {
/* 418 */           from = i;
/*     */           
/*     */           break;
/*     */         } 
/* 422 */       } else if (m instanceof MCTable && 
/* 423 */         m == col) {
/* 424 */         from = i;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*     */     
/* 430 */     switch (this.autoResizeMode) {
/*     */       case 1:
/* 432 */         from++;
/* 433 */         to = Math.min(from + 1, columnCount);
/*     */         break;
/*     */       case 2:
/* 436 */         from++;
/* 437 */         to = columnCount;
/*     */         break;
/*     */       case 3:
/* 440 */         from = columnCount - 1;
/* 441 */         to = from + 1;
/*     */         break;
/*     */       case 4:
/* 444 */         from = 0;
/* 445 */         to = columnCount;
/*     */         break;
/*     */ 
/*     */       
/*     */       default:
/*     */         return;
/*     */     } 
/*     */     
/* 453 */     final int start = from;
/* 454 */     final int end = to;
/* 455 */     Resizable3 r = new Resizable3() { public int getElementCount() {
/* 456 */           return end - start;
/*     */         } public int getLowerBoundAt(int i) {
/* 458 */           MCColumnLayoutMember m = ms[i + start];
/* 459 */           return m.getMinWidth();
/*     */         }
/*     */         public int getUpperBoundAt(int i) {
/* 462 */           MCColumnLayoutMember m = ms[i + start];
/* 463 */           return m.getMaxWidth();
/*     */         }
/*     */         public int getMidPointAt(int i) {
/* 466 */           MCColumnLayoutMember m = ms[i + start];
/* 467 */           return m.getWidth();
/*     */         }
/*     */         public void setSizeAt(int s, int i) {
/* 470 */           MCColumnLayoutMember m = ms[i + start];
/* 471 */           m.setWidth(s);
/*     */         } }
/*     */       ;
/*     */     
/* 475 */     int totalWidth = 0;
/* 476 */     for (int j = start; j < end; j++) {
/* 477 */       totalWidth += ms[j].getWidth();
/*     */     }
/*     */     
/* 480 */     adjustSizes((totalWidth + delta), r, false);
/*     */   }
/*     */   
/*     */   private void setWidthsFromPreferredWidths(final boolean inverse) {
/* 484 */     int totalWidth = getWidth();
/* 485 */     int totalPreferred = (getPreferredSize()).width;
/* 486 */     int target = !inverse ? totalWidth : totalPreferred;
/*     */     
/* 488 */     final MCColumnLayoutMember[] ms = 
/* 489 */       getColumnModel().getLayoutMemberArray();
/* 490 */     Resizable3 r = new Resizable3() { public int getElementCount() {
/* 491 */           return ms.length;
/*     */         } public int getLowerBoundAt(int i) {
/* 493 */           MCColumnLayoutMember m = ms[i];
/* 494 */           return m.getMinWidth();
/*     */         }
/*     */         public int getUpperBoundAt(int i) {
/* 497 */           MCColumnLayoutMember m = ms[i];
/* 498 */           return m.getMaxWidth();
/*     */         }
/*     */         public int getMidPointAt(int i) {
/* 501 */           MCColumnLayoutMember m = ms[i];
/* 502 */           if (!inverse) {
/* 503 */             return m.getPreferredWidth();
/*     */           }
/*     */           
/* 506 */           return m.getWidth();
/*     */         }
/*     */         
/*     */         public void setSizeAt(int s, int i) {
/* 510 */           MCColumnLayoutMember m = ms[i];
/* 511 */           if (!inverse) {
/* 512 */             m.setWidth(s);
/*     */           } else {
/*     */             
/* 515 */             m.setPreferredWidth(s);
/*     */           } 
/*     */         } }
/*     */       ;
/*     */     
/* 520 */     adjustSizes(target, r, inverse);
/*     */   }
/*     */   private void adjustSizes(long target, final Resizable3 r3, boolean inverse) {
/*     */     Resizable2 r2;
/* 524 */     int N = r3.getElementCount();
/* 525 */     long totalPreferred = 0L;
/* 526 */     for (int i = 0; i < N; i++) {
/* 527 */       totalPreferred += r3.getMidPointAt(i);
/*     */     }
/*     */ 
/*     */     
/* 531 */     if (((target < totalPreferred) ? true : false) == (inverse ? false : true)) {
/* 532 */       r2 = new Resizable2() {
/* 533 */           public int getElementCount() { return r3.getElementCount(); }
/* 534 */           public int getLowerBoundAt(int i) { return r3.getLowerBoundAt(i); }
/* 535 */           public int getUpperBoundAt(int i) { return r3.getMidPointAt(i); } public void setSizeAt(int newSize, int i) {
/* 536 */             r3.setSizeAt(newSize, i);
/*     */           }
/*     */         };
/*     */     } else {
/* 540 */       r2 = new Resizable2() {
/* 541 */           public int getElementCount() { return r3.getElementCount(); }
/* 542 */           public int getLowerBoundAt(int i) { return r3.getMidPointAt(i); }
/* 543 */           public int getUpperBoundAt(int i) { return r3.getUpperBoundAt(i); }
/* 544 */           public void setSizeAt(int newSize, int i) { r3.setSizeAt(newSize, i); }
/*     */         };
/*     */     } 
/* 547 */     adjustSizes(target, r2, !inverse);
/*     */   }
/*     */   
/*     */   private void adjustSizes(long target, Resizable2 r, boolean limitToRange) {
/* 551 */     long totalLowerBound = 0L;
/* 552 */     long totalUpperBound = 0L; int i;
/* 553 */     for (i = 0; i < r.getElementCount(); i++) {
/* 554 */       totalLowerBound += r.getLowerBoundAt(i);
/* 555 */       totalUpperBound += r.getUpperBoundAt(i);
/*     */     } 
/*     */     
/* 558 */     if (limitToRange) {
/* 559 */       target = Math.min(Math.max(totalLowerBound, target), totalUpperBound);
/*     */     }
/*     */     
/* 562 */     for (i = 0; i < r.getElementCount(); i++) {
/* 563 */       int newSize, lowerBound = r.getLowerBoundAt(i);
/* 564 */       int upperBound = r.getUpperBoundAt(i);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 569 */       if (totalLowerBound == totalUpperBound) {
/* 570 */         newSize = lowerBound;
/*     */       } else {
/*     */         
/* 573 */         double f = (target - totalLowerBound) / (totalUpperBound - totalLowerBound);
/* 574 */         newSize = (int)Math.round(lowerBound + f * (upperBound - lowerBound));
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 579 */       r.setSizeAt(newSize, i);
/* 580 */       target -= newSize;
/* 581 */       totalLowerBound -= lowerBound;
/* 582 */       totalUpperBound -= upperBound;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static interface Resizable2 {
/*     */     int getElementCount();
/*     */     
/*     */     int getLowerBoundAt(int param1Int);
/*     */     
/*     */     int getUpperBoundAt(int param1Int);
/*     */     
/*     */     void setSizeAt(int param1Int1, int param1Int2);
/*     */   }
/*     */   
/*     */   private static interface Resizable3 extends Resizable2 {
/*     */     int getMidPointAt(int param1Int);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCFixedColumnLayoutTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */