/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.util.HashMap;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.resource.ctrl.MCResource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MCColumnModeInfo
/*     */ {
/*     */   private final String _name;
/*     */   private final MCColumnConfig _column;
/*  43 */   private final HashMap<String, Color> _map = new HashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String _key;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   private String _gui = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCColumnModeInfo(MCColumnConfig column, String name) {
/*  70 */     this._column = column;
/*  71 */     this._name = name;
/*  72 */     this._key = MCResource.createKey(new String[] { "mode", name });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCColumnConfig getComponent() {
/*  83 */     return this._column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final String getName() {
/*  94 */     return this._name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String getModeKey() {
/* 105 */     if (this._gui == null) {
/* 106 */       this._gui = MCResource.createKey(new String[] { getComponent().getTable().getType(), this._key });
/*     */     }
/* 108 */     return this._gui;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Color getColor(String key) {
/* 121 */     if (!MCStringUtil.isNull(key)) {
/* 122 */       MCColumnConfig column = getComponent();
/* 123 */       HashMap<String, Color> map = this._map;
/* 124 */       if (map.containsKey(key)) {
/* 125 */         return map.get(key);
/*     */       }
/* 127 */       Color result = null;
/* 128 */       String temp = MCBeansProxy.PROXY.getBeansKey(column, 
/* 129 */           MCResource.createKey(new String[] { getModeKey(), key }));
/* 130 */       if (!MCStringUtil.isNull(temp)) {
/* 131 */         result = MCConst.beans.getColor(temp);
/*     */       }
/* 133 */       map.put(key, result);
/* 134 */       return result;
/*     */     } 
/* 136 */     return null;
/*     */   }
/*     */   
/*     */   final Color getColor(String key, Color color, boolean darker) {
/* 140 */     MCColumnConfig column = getComponent();
/* 141 */     HashMap<String, Color> map = this._map;
/* 142 */     if (map.containsKey(key)) {
/* 143 */       return map.get(key);
/*     */     }
/* 145 */     Color result = null;
/* 146 */     String temp = MCBeansProxy.PROXY.getBeansKey(
/* 147 */         column, MCConst.createKey(new String[] { getModeKey(), key }));
/* 148 */     if (MCStringUtil.isNull(temp)) {
/* 149 */       return null;
/*     */     }
/*     */     try {
/* 152 */       result = MCConst.beans.getColor(temp);
/* 153 */     } catch (MCException e) {
/*     */       try {
/* 155 */         MCNumber value = MCConst.beans.getNumber(temp);
/* 156 */         double dv = value.doubleValue();
/* 157 */         return darker ? MCCellUtil.darker(color, dv) : MCCellUtil.brighter(color, dv);
/* 158 */       } catch (MCException mCException) {
/* 159 */         throw e;
/*     */       } 
/*     */     } 
/* 162 */     map.put(key, result);
/* 163 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCColumnModeInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */