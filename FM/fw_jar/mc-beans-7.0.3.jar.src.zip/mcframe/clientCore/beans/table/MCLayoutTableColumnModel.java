/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.swing.table.TableColumn;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCLayoutTableColumnModel
/*     */   extends MCTableColumnModel
/*     */ {
/*     */   private class LayoutMemberIterator
/*     */     implements Iterator<MCColumnLayoutMember>
/*     */   {
/*  52 */     private int col_pos = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  59 */     private MCColumnLayout[] lays = MCLayoutTableColumnModel.this.getColumnLayouts();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  65 */     private int lay_idx = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  72 */     private MCTableColumn[] lay_cols = getLayoutColumns(this.lay_idx);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private MCTableColumn[] getLayoutColumns(int idx) {
/*  84 */       return (idx < this.lays.length) ? 
/*  85 */         this.lays[idx].getAllColumns() : null;
/*     */     }
/*     */     
/*     */     public boolean hasNext() {
/*  89 */       return (this.col_pos < MCLayoutTableColumnModel.this.getColumnCount());
/*     */     }
/*     */     
/*     */     public MCColumnLayoutMember next() {
/*  93 */       MCTableColumn tc = MCLayoutTableColumnModel.this.getColumn(this.col_pos);
/*  94 */       if (this.lay_cols != null && this.lay_cols.length > 0 && 
/*  95 */         this.lay_cols[0] == tc) {
/*     */         
/*  97 */         MCColumnLayout layout = this.lays[this.lay_idx];
/*  98 */         this.col_pos += this.lay_cols.length;
/*  99 */         this.lay_cols = getLayoutColumns(++this.lay_idx);
/* 100 */         return layout;
/*     */       } 
/*     */ 
/*     */       
/* 104 */       this.col_pos++;
/* 105 */       return tc;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void remove() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private LayoutMemberIterator() {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<MCColumnLayoutMember> createLayoutMemberIterator() {
/* 125 */     return new LayoutMemberIterator(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCColumnLayoutMember[] getLayoutMemberArray() {
/* 140 */     MCColumnLayoutMember[] buf = new MCColumnLayoutMember[getColumnCount()];
/* 141 */     int size = 0;
/* 142 */     Iterator<MCColumnLayoutMember> ite = createLayoutMemberIterator();
/* 143 */     while (ite.hasNext()) {
/* 144 */       buf[size++] = ite.next();
/*     */     }
/* 146 */     return Arrays.<MCColumnLayoutMember>copyOf(buf, size);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 169 */   private WidthSupplier WS_WIDTH = new WidthSupplier()
/*     */     {
/*     */       public long width(MCColumnLayoutMember member) {
/* 172 */         return member.getWidth();
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 181 */   private WidthSupplier WS_MAXWIDTH = new WidthSupplier()
/*     */     {
/*     */       public long width(MCColumnLayoutMember member) {
/* 184 */         return member.getMaxWidth();
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 193 */   private WidthSupplier WS_MINWIDTH = new WidthSupplier()
/*     */     {
/*     */       public long width(MCColumnLayoutMember member) {
/* 196 */         return member.getMinWidth();
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 205 */   private WidthSupplier WS_PREFERREDWIDTH = new WidthSupplier()
/*     */     {
/*     */       public long width(MCColumnLayoutMember member) {
/* 208 */         return member.getPreferredWidth();
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long calcWidth(WidthSupplier ws) {
/* 221 */     long width = 0L;
/*     */     
/* 223 */     Iterator<MCColumnLayoutMember> iterator = createLayoutMemberIterator();
/* 224 */     while (iterator.hasNext()) {
/* 225 */       MCColumnLayoutMember member = iterator.next();
/* 226 */       width += ws.width(member);
/*     */     } 
/*     */     
/* 229 */     return width;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long getMaximumWidth() {
/* 243 */     return calcWidth(this.WS_MAXWIDTH);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long getMinimumWidth() {
/* 256 */     return calcWidth(this.WS_MINWIDTH);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long getPreferredWidth() {
/* 269 */     return calcWidth(this.WS_PREFERREDWIDTH);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void propertyChange(PropertyChangeEvent evt) {
/* 276 */     Object src = evt.getSource();
/* 277 */     if (src instanceof MCTableColumn) {
/* 278 */       MCTableColumn col = (MCTableColumn)src;
/* 279 */       MCColumnLayout[] ls = getColumnLayouts(); byte b; int i; MCColumnLayout[] arrayOfMCColumnLayout1;
/* 280 */       for (i = (arrayOfMCColumnLayout1 = ls).length, b = 0; b < i; ) { MCColumnLayout l = arrayOfMCColumnLayout1[b];
/* 281 */         if (l.contains(col)) {
/* 282 */           if (l.isRunningPropertyChangeEvent()) {
/*     */             return;
/*     */           }
/*     */ 
/*     */           
/* 287 */           String name = evt.getPropertyName();
/* 288 */           if (name == "width") {
/* 289 */             l.setRunningPropertyChangeEvent(evt);
/* 290 */             l.invalidateWidthCache(col);
/* 291 */             l.getWidth();
/* 292 */             l.cancelRunningPropertyChangeEvent(); break;
/*     */           } 
/* 294 */           if (name == "maxWidth") {
/* 295 */             l.setRunningPropertyChangeEvent(evt);
/* 296 */             l.invalidateMaxWidthCache(col);
/* 297 */             l.getMaxWidth();
/* 298 */             l.cancelRunningPropertyChangeEvent(); break;
/*     */           } 
/* 300 */           if (name == "minWidth") {
/* 301 */             l.setRunningPropertyChangeEvent(evt);
/* 302 */             l.invalidateMinWidthCache(col);
/* 303 */             l.getMinWidth();
/* 304 */             l.cancelRunningPropertyChangeEvent(); break;
/*     */           } 
/* 306 */           if (name == "preferredWidth") {
/* 307 */             l.setRunningPropertyChangeEvent(evt);
/* 308 */             l.invalidatePreferredWidthCache(col);
/* 309 */             l.getPreferredWidth();
/* 310 */             l.cancelRunningPropertyChangeEvent();
/*     */           } 
/*     */           
/*     */           break;
/*     */         } 
/*     */         
/*     */         b++; }
/*     */     
/*     */     } 
/* 319 */     super.propertyChange(evt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addColumn(TableColumn column) {
/* 325 */     super.addColumn(column);
/*     */   }
/*     */ 
/*     */   
/*     */   public void removeColumn(TableColumn column) {
/* 330 */     super.removeColumn(column);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCTableColumn getColumn(int columnIndex) {
/* 341 */     return (MCTableColumn)this.tableColumns.elementAt(columnIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void recalcWidthCache() {
/* 352 */     this.totalColumnWidth = (int)calcWidth(this.WS_WIDTH);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void invalidateWidthCache() {
/* 365 */     this.totalColumnWidth = -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void adjustWidth(boolean all, boolean visible, int count) {
/* 382 */     MCColumnLayout[] ls = getColumnLayouts();
/* 383 */     int ls_idx = 0;
/* 384 */     MCColumnLayout l = (ls.length > ls_idx) ? ls[ls_idx] : null;
/* 385 */     int l_cnt = 0;
/*     */     
/* 387 */     int size = getColumnCount();
/* 388 */     for (int i = 0; i < size; i++) {
/* 389 */       MCTableColumn c = getColumn(i);
/*     */ 
/*     */       
/* 392 */       if (l_cnt == 0 && l != null) {
/* 393 */         if (l.contains(c)) {
/*     */ 
/*     */           
/* 396 */           l.setRunningPropertyChangeEvent(true);
/*     */           
/* 398 */           l.invalidateWidthCache(true);
/* 399 */           l.invalidatePreferredWidthCache(true);
/*     */           
/* 401 */           l_cnt = l.getAllColumnCount();
/*     */         } 
/*     */       } else {
/*     */         
/* 405 */         l_cnt--;
/* 406 */         if (l_cnt == 0) {
/*     */ 
/*     */           
/* 409 */           l.cancelRunningPropertyChangeEvent(true);
/* 410 */           ls_idx++;
/*     */           
/* 412 */           l = (ls.length > ls_idx) ? ls[ls_idx] : null;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 417 */       if (all || c.isAdjustWidth())
/*     */       {
/*     */ 
/*     */         
/* 421 */         if (c.getWidth() >= 0 && 
/* 422 */           c.getModeInfo().getStatus() != 3) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 429 */           boolean tv = c.isAdjustWidthOnlyVisibleRow();
/* 430 */           int tc = c.getAdjustWidthRowCount();
/*     */           try {
/* 432 */             c.setAdjustWidthOnlyVisibleRow(visible);
/* 433 */             c.setAdjustWidthRowCount(count);
/* 434 */             c.adjustWidth();
/*     */           } finally {
/*     */             
/* 437 */             c.setAdjustWidthOnlyVisibleRow(tv);
/* 438 */             c.setAdjustWidthRowCount(tc);
/*     */           } 
/*     */         }  } 
/*     */     } 
/* 442 */     if (l_cnt > 0)
/*     */     {
/* 444 */       l.cancelRunningPropertyChangeEvent(true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 457 */   private List<MCColumnLayout> _layouts = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   List<MCColumnLayout> clearColumnLayout() {
/* 467 */     List<MCColumnLayout> old = this._layouts;
/* 468 */     this._layouts = null;
/* 469 */     invalidateWidthCache();
/* 470 */     return old;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setAllColumnLayout(Collection<MCColumnLayout> c) {
/* 484 */     clearColumnLayout();
/* 485 */     addAllColumnLayout(c);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void addAllColumnLayout(Collection<MCColumnLayout> c) {
/* 498 */     if (this._layouts == null) {
/* 499 */       this._layouts = new ArrayList<>();
/*     */     }
/* 501 */     this._layouts.addAll(c);
/* 502 */     invalidateWidthCache();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void addColumnLayout(MCColumnLayout layout) {
/* 513 */     if (this._layouts == null) {
/* 514 */       this._layouts = new ArrayList<>();
/*     */     }
/* 516 */     this._layouts.add(layout);
/* 517 */     invalidateWidthCache();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCColumnLayout[] getColumnLayouts() {
/* 534 */     return (this._layouts != null) ? 
/* 535 */       this._layouts.<MCColumnLayout>toArray(new MCColumnLayout[this._layouts.size()]) : 
/* 536 */       new MCColumnLayout[0];
/*     */   }
/*     */   
/*     */   static interface WidthSupplier {
/*     */     long width(MCColumnLayoutMember param1MCColumnLayoutMember);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCLayoutTableColumnModel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */