/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import javax.swing.DefaultCellEditor;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextField;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCCellEditorButton
/*     */   extends DefaultCellEditor
/*     */ {
/*     */   private final MCColumnConfig _column;
/*     */   
/*     */   protected MCCellEditorButton(String name, MCColumnConfig column) {
/*  36 */     super(new JTextField());
/*     */     
/*  38 */     MCEditorButton compo = new MCEditorButton(name, column);
/*  39 */     this.editorComponent = (JComponent)compo;
/*  40 */     this._column = column;
/*  41 */     setClickCountToStart(1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCColumnConfig getColumnConfig() {
/*  52 */     return this._column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCEditorButton getEditorComponent() {
/*  63 */     return (MCEditorButton)this.editorComponent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Component getTableCellEditorComponent(JTable table, Object value, boolean selected, int index, int column) {
/*  81 */     return (Component)getEditor((MCTable)table, value, index, getColumnConfig());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCEditorButton getEditor(MCTable<?> table, Object value, int index, MCColumnConfig column) {
/*  97 */     MCEditorButton compo = getEditorComponent();
/*  98 */     compo.setBorderPainted(true);
/*  99 */     compo.setColumnInfo(index, column);
/* 100 */     return compo;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCCellEditorButton.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */