/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCColumnLayoutVertical
/*     */   extends MCColumnLayout
/*     */ {
/*     */   public MCColumnLayoutVertical(String name) {
/*  24 */     super(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isVertical() {
/*  29 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTierCount() {
/*  34 */     int tier = 0;
/*  35 */     MCColumnLayoutMember[] ms = getVisibleMembers(); byte b; int i; MCColumnLayoutMember[] arrayOfMCColumnLayoutMember1;
/*  36 */     for (i = (arrayOfMCColumnLayoutMember1 = ms).length, b = 0; b < i; ) { MCColumnLayoutMember m = arrayOfMCColumnLayoutMember1[b];
/*  37 */       if (m instanceof MCColumnLayout) {
/*  38 */         tier += ((MCColumnLayout)m).getTierCount();
/*     */       } else {
/*     */         
/*  41 */         tier++;
/*     */       }  b++; }
/*     */     
/*  44 */     return tier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int calcWidth(MCColumnLayout.WidthIO wio) {
/*  72 */     Calc calc = null;
/*  73 */     long width = 0L;
/*  74 */     if (wio.propertyName() == "minWidth") {
/*     */       
/*  76 */       calc = new Calc() {
/*     */           public long exec(long a, long b) {
/*  78 */             return Math.max(a, b);
/*     */           }
/*     */         };
/*  81 */       width = 0L;
/*     */     }
/*  83 */     else if (wio.propertyName() == "maxWidth") {
/*     */       
/*  85 */       calc = new Calc() {
/*     */           public long exec(long a, long b) {
/*  87 */             return Math.min(a, b);
/*     */           }
/*     */         };
/*  90 */       width = 2147483647L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 101 */     else if (isRunningPropertyChangeEvent() && getPropertyChangeAmount() < 0L) {
/*     */       
/* 103 */       calc = new Calc() {
/*     */           public long exec(long a, long b) {
/* 105 */             return Math.min(a, b);
/*     */           }
/*     */         };
/* 108 */       width = 2147483647L;
/*     */     }
/*     */     else {
/*     */       
/* 112 */       calc = new Calc() {
/*     */           public long exec(long a, long b) {
/* 114 */             return Math.max(a, b);
/*     */           }
/*     */         };
/* 117 */       width = 0L;
/*     */     } 
/*     */ 
/*     */     
/* 121 */     MCColumnLayoutMember[] members = getVisibleMembers();
/* 122 */     if (members.length > 0) {
/*     */       byte b; int i; MCColumnLayoutMember[] arrayOfMCColumnLayoutMember;
/* 124 */       for (i = (arrayOfMCColumnLayoutMember = members).length, b = 0; b < i; ) { MCColumnLayoutMember member = arrayOfMCColumnLayoutMember[b];
/* 125 */         width = calc.exec(width, wio.width(member));
/*     */         
/*     */         b++; }
/*     */     
/*     */     } else {
/* 130 */       width = 0L;
/*     */     } 
/* 132 */     width = Math.min(width, 2147483647L);
/* 133 */     return (int)width;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int setMemberWidth(MCColumnLayout.WidthIO wio, int oldw, int neww) {
/* 143 */     int result = neww;
/*     */     
/* 145 */     MCColumnLayoutMember[] members = getVisibleMembers(); byte b; int i; MCColumnLayoutMember[] arrayOfMCColumnLayoutMember1;
/* 146 */     for (i = (arrayOfMCColumnLayoutMember1 = members).length, b = 0; b < i; ) { MCColumnLayoutMember member = arrayOfMCColumnLayoutMember1[b];
/* 147 */       wio.width(member, neww);
/* 148 */       result = wio.width(member);
/* 149 */       if (result != neww)
/*     */       {
/* 151 */         return setMemberWidth(wio, oldw, result);
/*     */       }
/*     */       b++; }
/*     */     
/* 155 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getHeaderHeight() {
/* 167 */     int height = 0;
/* 168 */     MCColumnLayoutMember[] ms = getVisibleMembers(); byte b; int i; MCColumnLayoutMember[] arrayOfMCColumnLayoutMember1;
/* 169 */     for (i = (arrayOfMCColumnLayoutMember1 = ms).length, b = 0; b < i; ) { MCColumnLayoutMember m = arrayOfMCColumnLayoutMember1[b];
/* 170 */       if (m instanceof MCColumnLayout) {
/* 171 */         height += ((MCColumnLayout)m).getHeaderHeight();
/*     */       }
/* 173 */       else if (m instanceof MCColumnConfig) {
/* 174 */         height += getHeaderColumnHeight((MCTableColumn)m);
/*     */       }  b++; }
/*     */     
/* 177 */     this._headerHeight = height;
/*     */ 
/*     */ 
/*     */     
/* 181 */     return this._headerHeight;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int headerColumnAtPoint(Point point, int height) {
/* 190 */     int y = 0;
/* 191 */     int pos = 0;
/*     */     
/* 193 */     MCColumnLayoutMember[] members = getMembers();
/* 194 */     MCColumnLayoutMember last = getLastVisibleMember(); byte b; int i; MCColumnLayoutMember[] arrayOfMCColumnLayoutMember1;
/* 195 */     for (i = (arrayOfMCColumnLayoutMember1 = members).length, b = 0; b < i; ) { MCColumnLayoutMember member = arrayOfMCColumnLayoutMember1[b];
/* 196 */       if (member instanceof MCColumnLayout) {
/* 197 */         MCColumnLayout l = (MCColumnLayout)member;
/* 198 */         int h = (l != last) ? l.getHeaderHeight() : height;
/* 199 */         if (y + h > point.y) {
/*     */           
/* 201 */           Point p = point.getLocation();
/* 202 */           p.y -= y;
/* 203 */           pos += l.headerColumnAtPoint(p, h);
/*     */           break;
/*     */         } 
/* 206 */         y += h;
/* 207 */         height -= h;
/* 208 */         pos += l.getAllColumnCount();
/*     */       }
/* 210 */       else if (member instanceof MCTableColumn) {
/* 211 */         MCTableColumn c = (MCTableColumn)member;
/* 212 */         if (c.isVisible()) {
/* 213 */           int h = (c != last) ? getHeaderColumnHeight(c) : height;
/* 214 */           y += h;
/* 215 */           if (y > point.y) {
/*     */             break;
/*     */           }
/*     */           
/* 219 */           height -= h;
/*     */         } 
/* 221 */         pos++;
/*     */       } 
/*     */       b++; }
/*     */     
/* 225 */     return pos;
/*     */   }
/*     */ 
/*     */   
/*     */   Rectangle getHeaderRect(Rectangle rect, MCTableColumn col) {
/* 230 */     Rectangle r = new Rectangle();
/* 231 */     int x = rect.x;
/* 232 */     int y = rect.y;
/* 233 */     int height = rect.height;
/*     */     
/* 235 */     MCColumnLayoutMember[] members = getVisibleMembers();
/* 236 */     int memberlen = members.length;
/* 237 */     for (int i = 0; i < memberlen; i++) {
/* 238 */       MCColumnLayoutMember member = members[i];
/* 239 */       if (member instanceof MCColumnLayout) {
/* 240 */         MCColumnLayout l = (MCColumnLayout)member;
/* 241 */         int h = (i != memberlen - 1) ? l.getHeaderHeight() : height;
/* 242 */         if (l.contains(col)) {
/* 243 */           r.x = x;
/* 244 */           r.y = y;
/* 245 */           r.height = h;
/* 246 */           r = l.getHeaderRect(r, col);
/*     */           break;
/*     */         } 
/* 249 */         y += h;
/* 250 */         height -= h;
/*     */       }
/* 252 */       else if (member instanceof MCTableColumn) {
/* 253 */         int h = (i != memberlen - 1) ? 
/* 254 */           getHeaderColumnHeight((MCTableColumn)member) : 
/* 255 */           height;
/* 256 */         if (member == col) {
/* 257 */           r.x = x;
/* 258 */           r.y = y;
/* 259 */           r.height = h;
/* 260 */           r.width = col.getWidth();
/*     */           break;
/*     */         } 
/* 263 */         y += h;
/* 264 */         height -= h;
/*     */       } 
/*     */     } 
/*     */     
/* 268 */     return r;
/*     */   }
/*     */ 
/*     */   
/*     */   int columnAtPoint(Point point, int height, int colheight) {
/* 273 */     int y = 0;
/* 274 */     int pos = 0;
/*     */     
/* 276 */     MCColumnLayoutMember[] members = getMembers();
/* 277 */     MCColumnLayoutMember last = getLastVisibleMember(); byte b; int i; MCColumnLayoutMember[] arrayOfMCColumnLayoutMember1;
/* 278 */     for (i = (arrayOfMCColumnLayoutMember1 = members).length, b = 0; b < i; ) { MCColumnLayoutMember member = arrayOfMCColumnLayoutMember1[b];
/* 279 */       if (member instanceof MCColumnLayout) {
/* 280 */         MCColumnLayout l = (MCColumnLayout)member;
/* 281 */         int h = (l != last) ? (colheight * l.getTierCount()) : height;
/* 282 */         if (y + h > point.y) {
/*     */           
/* 284 */           Point p = point.getLocation();
/* 285 */           p.y -= y;
/* 286 */           pos += l.columnAtPoint(p, h, colheight);
/*     */           break;
/*     */         } 
/* 289 */         y += h;
/* 290 */         height -= h;
/* 291 */         pos += l.getAllColumnCount();
/*     */       }
/* 293 */       else if (member instanceof MCTableColumn) {
/* 294 */         MCTableColumn c = (MCTableColumn)member;
/* 295 */         if (c.isVisible()) {
/* 296 */           int h = (c != last) ? colheight : height;
/* 297 */           y += h;
/* 298 */           if (y > point.y) {
/*     */             break;
/*     */           }
/*     */           
/* 302 */           height -= h;
/*     */         } 
/* 304 */         pos++;
/*     */       } 
/*     */       b++; }
/*     */     
/* 308 */     return pos;
/*     */   }
/*     */ 
/*     */   
/*     */   Rectangle getCellRect(Rectangle rect, MCTableColumn col, int colheight) {
/* 313 */     Rectangle r = new Rectangle();
/* 314 */     int x = rect.x;
/* 315 */     int y = rect.y;
/* 316 */     int height = rect.height;
/*     */     
/* 318 */     MCColumnLayoutMember last = getLastVisibleMember();
/* 319 */     MCColumnLayoutMember[] members = getMembers(); byte b; int i; MCColumnLayoutMember[] arrayOfMCColumnLayoutMember1;
/* 320 */     for (i = (arrayOfMCColumnLayoutMember1 = members).length, b = 0; b < i; ) { MCColumnLayoutMember member = arrayOfMCColumnLayoutMember1[b];
/* 321 */       if (member instanceof MCColumnLayout) {
/* 322 */         MCColumnLayout l = (MCColumnLayout)member;
/* 323 */         int h = (member != last) ? (
/* 324 */           colheight * l.getTierCount()) : height;
/* 325 */         if (l.contains(col)) {
/* 326 */           r.x = x;
/* 327 */           r.y = y;
/* 328 */           r.height = h;
/* 329 */           r = l.getCellRect(r, col, colheight);
/*     */           break;
/*     */         } 
/* 332 */         y += h;
/* 333 */         height -= h;
/*     */       }
/* 335 */       else if (member instanceof MCTableColumn) {
/* 336 */         int h = member.isVisible() ? (
/* 337 */           (member != last) ? colheight : height) : 
/* 338 */           0;
/* 339 */         if (member == col) {
/* 340 */           r.x = x;
/* 341 */           r.y = y;
/* 342 */           r.height = h;
/* 343 */           r.width = col.getWidth();
/*     */           break;
/*     */         } 
/* 346 */         y += h;
/* 347 */         height -= h;
/*     */       } 
/*     */       b++; }
/*     */     
/* 351 */     return r;
/*     */   }
/*     */   
/*     */   private static interface Calc {
/*     */     long exec(long param1Long1, long param1Long2);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCColumnLayoutVertical.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */