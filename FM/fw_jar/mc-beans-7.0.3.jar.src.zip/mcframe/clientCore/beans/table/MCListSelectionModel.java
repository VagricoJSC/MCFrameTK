/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import javax.swing.DefaultListSelectionModel;
/*     */ import mcframe.clientCore.event.MCEventInfo;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCListSelectionModel
/*     */   extends DefaultListSelectionModel
/*     */ {
/*     */   private final MCTable<?> _table;
/*     */   
/*     */   private enum TYPE
/*     */   {
/*  40 */     ADD,
/*     */     
/*  42 */     SET,
/*     */     
/*  44 */     CLEAR,
/*     */     
/*  46 */     REMOVE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCListSelectionModel(MCTable<?> table) {
/*  59 */     if (table != null) {
/*  60 */       this._table = table;
/*     */     } else {
/*     */       
/*  63 */       throw new MCException(Core_Msg_FW_A.FCBAC0112, new Object[0]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCTable<?> getTable() {
/*  75 */     return this._table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSelectionInterval(int index0, int index1) {
/*  93 */     selectionInterval(TYPE.SET, index0, index1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addSelectionInterval(int index0, int index1) {
/* 111 */     selectionInterval(TYPE.ADD, index0, index1);
/*     */   }
/*     */   
/*     */   void addSelectionInterval(Integer[] indexes) {
/* 115 */     selectionInternal(TYPE.ADD, indexes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean clearSelection(boolean mcf) {
/* 130 */     if (mcf) {
/* 131 */       return selectionInterval(TYPE.CLEAR, -1, -1);
/*     */     }
/*     */     
/* 134 */     clearSelection();
/* 135 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearSelection() {
/* 151 */     super.clearSelection();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void removeSelectionInterval(int index0, int index1, boolean mcf) {
/* 166 */     if (mcf) {
/* 167 */       removeInterval(index0, index1);
/*     */     } else {
/*     */       
/* 170 */       removeSelectionInterval(index0, index1);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeSelectionInterval(int index0, int index1) {
/* 189 */     super.removeSelectionInterval(index0, index1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean selectionInterval(TYPE type, int index0, int index1) {
/* 217 */     MCTable<?> t = getTable();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 226 */     if (t.isFixedColumnTable()) {
/* 227 */       MCFixedColumnTable ft = (MCFixedColumnTable)t;
/* 228 */       if (!ft._dragging) {
/* 229 */         _selectionInterval(type, index0, index1);
/* 230 */         return true;
/*     */       } 
/* 232 */       ft._dragging = false;
/*     */     } 
/*     */     
/* 235 */     int o = t.getMCSelectedRow();
/* 236 */     if (o != index1) {
/* 237 */       MCEventInfo i = t.getEventInfo();
/* 238 */       MCEventProxy.PROXY.setIndex(i, o, index1);
/* 239 */       MCEventProxy.PROXY.setEventIndex(i, index1);
/*     */       
/* 241 */       if (!t.doVC()) {
/* 242 */         return false;
/*     */       }
/* 244 */       _mcSelectionInterval(type, index0, index1);
/*     */       
/* 246 */       t.doNC();
/* 247 */       MCEventProxy.PROXY.setIndex(i, index0);
/*     */     } else {
/*     */       
/* 250 */       _selectionInterval(type, index0, index1);
/*     */     } 
/* 252 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private void selectionInternal(TYPE type, Integer[] indexes) {
/* 257 */     List<Integer[]> l = (List)new ArrayList<>();
/* 258 */     Integer[] a = { Integer.valueOf(-1), Integer.valueOf(-1) };
/* 259 */     int b = -1;
/*     */     
/* 261 */     for (int i = 0; i < indexes.length; i++) {
/* 262 */       int v = indexes[i].intValue();
/* 263 */       if (a[0].intValue() == -1) {
/* 264 */         a[0] = Integer.valueOf(v);
/*     */       
/*     */       }
/* 267 */       else if (v != b + 1) {
/* 268 */         a[1] = Integer.valueOf(b);
/* 269 */         l.add(a);
/* 270 */         a = new Integer[] { Integer.valueOf(-1), Integer.valueOf(-1) };
/* 271 */         a[0] = Integer.valueOf(v);
/*     */       } 
/*     */       
/* 274 */       if (i == indexes.length - 1) {
/* 275 */         a[1] = Integer.valueOf(v);
/* 276 */         l.add(a);
/*     */       } 
/* 278 */       b = v;
/*     */     } 
/*     */     
/* 281 */     MCTable<?> t = getTable();
/* 282 */     if (t.isFixedColumnTable()) {
/* 283 */       for (Integer[] arrayOfInteger : l) {
/* 284 */         _addSelectionInterval(arrayOfInteger[0].intValue(), arrayOfInteger[1].intValue());
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/* 289 */     int o = t.getMCSelectedRow();
/* 290 */     int lead = indexes[indexes.length - 1].intValue();
/* 291 */     if (o != lead) {
/* 292 */       MCEventInfo f = t.getEventInfo();
/* 293 */       MCEventProxy.PROXY.setIndex(f, o, lead);
/* 294 */       MCEventProxy.PROXY.setEventIndex(f, lead);
/*     */       
/* 296 */       if (!t.doVC()) {
/*     */         return;
/*     */       }
/*     */       
/* 300 */       for (Integer[] arrayOfInteger : l) {
/* 301 */         _addSelectionInterval(arrayOfInteger[0].intValue(), arrayOfInteger[1].intValue());
/*     */       }
/*     */       
/* 304 */       t.doNC();
/* 305 */       MCEventProxy.PROXY.setIndex(f, lead);
/*     */     } else {
/*     */       
/* 308 */       for (Integer[] arrayOfInteger : l) {
/* 309 */         _addSelectionInterval(arrayOfInteger[0].intValue(), arrayOfInteger[1].intValue());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void removeInterval(int index0, int index1) {
/* 325 */     MCTable<?> t = getTable();
/*     */     
/* 327 */     if (t.isFixedColumnTable()) {
/* 328 */       _selectionInterval(TYPE.REMOVE, index0, index1);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 333 */     int n = -1;
/* 334 */     int[] a = t.getMCSelectedRows();
/* 335 */     if (a.length > 1) {
/* 336 */       Arrays.sort(a);
/* 337 */       for (int i = 0; i < a.length; i++) {
/* 338 */         if (a[i] == index1) {
/* 339 */           n = (i != a.length - 1) ? a[i + 1] : a[i - 1];
/*     */           break;
/*     */         } 
/* 342 */         if (a[i] > index1) {
/* 343 */           n = a[i];
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 349 */     int o = t.getMCSelectedRow();
/*     */ 
/*     */     
/* 352 */     if (o == index1) {
/* 353 */       MCEventInfo i = t.getEventInfo();
/* 354 */       MCEventProxy.PROXY.setIndex(i, o, n);
/* 355 */       MCEventProxy.PROXY.setEventIndex(i, index1);
/*     */       
/* 357 */       if (!t.doVC()) {
/*     */         return;
/*     */       }
/* 360 */       _mcSelectionInterval(TYPE.REMOVE, index0, index1);
/*     */ 
/*     */ 
/*     */       
/* 364 */       if (n != -1) {
/* 365 */         addMCSelectionInterval(n, n);
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 370 */         MCTable<?> c = t.getFixedColumnTable();
/* 371 */         c.getSelectionModel().setAnchorSelectionIndex(-1);
/* 372 */         c.getSelectionModel().setLeadSelectionIndex(-1);
/* 373 */         c = t.getBodyTable();
/* 374 */         c.getSelectionModel().setAnchorSelectionIndex(-1);
/* 375 */         c.getSelectionModel().setLeadSelectionIndex(-1);
/*     */       } 
/* 377 */       t.doNC();
/* 378 */       MCEventProxy.PROXY.setIndex(i, n);
/*     */     } else {
/*     */       
/* 381 */       _selectionInterval(TYPE.REMOVE, index0, index1);
/*     */ 
/*     */ 
/*     */       
/* 385 */       if (n != -1) {
/* 386 */         addMCSelectionInterval(n, n);
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 391 */         MCTable<?> c = t.getFixedColumnTable();
/* 392 */         c.getSelectionModel().setAnchorSelectionIndex(-1);
/* 393 */         c.getSelectionModel().setLeadSelectionIndex(-1);
/* 394 */         c = t.getBodyTable();
/* 395 */         c.getSelectionModel().setAnchorSelectionIndex(-1);
/* 396 */         c.getSelectionModel().setLeadSelectionIndex(-1);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void _selectionInterval(TYPE type, int index0, int index1) {
/* 433 */     boolean e = isLeadAnchorNotificationEnabled();
/* 434 */     switch (type) {
/*     */       case null:
/* 436 */         _addSelectionInterval(index0, index1);
/*     */         break;
/*     */       case SET:
/* 439 */         _setSelectionInterval(index0, index1);
/*     */         break;
/*     */       case CLEAR:
/* 442 */         _clearSelection();
/*     */         
/*     */         try {
/* 445 */           setLeadAnchorNotificationEnabled(false);
/* 446 */           setAnchorSelectionIndex(-1);
/* 447 */           setLeadSelectionIndex(-1);
/*     */         } finally {
/*     */           
/* 450 */           setLeadAnchorNotificationEnabled(e);
/*     */         } 
/*     */         break;
/*     */       
/*     */       case REMOVE:
/*     */         try {
/* 456 */           setLeadAnchorNotificationEnabled(false);
/* 457 */           _removeSelectionInterval(index0, index1);
/*     */         } finally {
/*     */           
/* 460 */           setLeadAnchorNotificationEnabled(e);
/*     */         } 
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void _mcSelectionInterval(TYPE type, int index0, int index1) {
/* 499 */     switch (type) {
/*     */       case null:
/* 501 */         addMCSelectionInterval(index0, index1);
/*     */         break;
/*     */       case SET:
/* 504 */         setMCSelectionInterval(index0, index1);
/*     */         break;
/*     */       case CLEAR:
/* 507 */         mcClearSelection();
/*     */         
/* 509 */         setAnchorSelectionIndex(-1);
/* 510 */         setLeadSelectionIndex(-1);
/*     */         break;
/*     */       
/*     */       case REMOVE:
/* 514 */         removeMCSelectionInterval(index0, index1);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setMCSelectionInterval(int index0, int index1) {
/* 536 */     MCTable<?> t = getTable().getFixedColumnTable();
/* 537 */     if (t != null) {
/* 538 */       t.getSelectionModel()._setSelectionInterval(index0, index1);
/*     */     }
/* 540 */     t = getTable().getBodyTable();
/* 541 */     if (t != null) {
/* 542 */       t.getSelectionModel()._setSelectionInterval(index0, index1);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void addMCSelectionInterval(int index0, int index1) {
/* 561 */     MCTable<?> t = getTable().getFixedColumnTable();
/* 562 */     if (t != null) {
/* 563 */       t.getSelectionModel()._addSelectionInterval(index0, index1);
/*     */     }
/* 565 */     t = getTable().getBodyTable();
/* 566 */     if (t != null) {
/* 567 */       t.getSelectionModel()._addSelectionInterval(index0, index1);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void mcClearSelection() {
/* 584 */     MCTable<?> t = getTable().getFixedColumnTable();
/* 585 */     if (t != null) {
/* 586 */       t.getSelectionModel()._clearSelection();
/*     */     }
/* 588 */     t = getTable().getBodyTable();
/* 589 */     if (t != null) {
/* 590 */       t.getSelectionModel()._clearSelection();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void removeMCSelectionInterval(int index0, int index1) {
/* 609 */     MCTable<?> t = getTable().getFixedColumnTable();
/* 610 */     if (t != null) {
/* 611 */       t.getSelectionModel()._removeSelectionInterval(index0, index1);
/*     */     }
/* 613 */     t = getTable().getBodyTable();
/* 614 */     if (t != null) {
/* 615 */       t.getSelectionModel()._removeSelectionInterval(index0, index1);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void _setSelectionInterval(int index0, int index1) {
/* 631 */     if (index0 == index1) {
/* 632 */       MCTable<?> t = getTable();
/* 633 */       int h = t.getRowHeight(index0);
/* 634 */       if (h == 0) {
/* 635 */         t.filterList((MCList)t.getList());
/*     */       }
/*     */     } 
/*     */     
/* 639 */     super.setSelectionInterval(index0, index1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void _addSelectionInterval(int index0, int index1) {
/* 653 */     super.addSelectionInterval(index0, index1);
/*     */   }
/*     */   
/*     */   private void _clearSelection() {
/* 657 */     super.clearSelection();
/*     */   }
/*     */   
/*     */   private void _removeSelectionInterval(int index0, int index1) {
/* 661 */     super.removeSelectionInterval(index0, index1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxSelectionIndex() {
/* 667 */     return Math.min(
/* 668 */         getTable().getRowCount() - 1, super.getMaxSelectionIndex());
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCListSelectionModel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */