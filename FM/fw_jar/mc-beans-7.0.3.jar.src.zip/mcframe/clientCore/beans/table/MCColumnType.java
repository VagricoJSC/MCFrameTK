/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum MCColumnType
/*     */ {
/*  13 */   TEXT
/*     */   {
/*     */     
/*     */     @Deprecated
/*     */     public Class<?> getEditorClass()
/*     */     {
/*  19 */       return MCEditorTextField.class;
/*     */     }
/*     */   },
/*     */ 
/*     */   
/*  24 */   NUMBER
/*     */   {
/*     */     
/*     */     @Deprecated
/*     */     public Class<?> getEditorClass()
/*     */     {
/*  30 */       return MCEditorNumberField.class;
/*     */     }
/*     */   },
/*     */ 
/*     */   
/*  35 */   DATE
/*     */   {
/*     */     
/*     */     @Deprecated
/*     */     public Class<?> getEditorClass()
/*     */     {
/*  41 */       return MCEditorDateField.class;
/*     */     }
/*     */   },
/*     */ 
/*     */   
/*  46 */   TIMESTAMP
/*     */   {
/*     */     
/*     */     @Deprecated
/*     */     public Class<?> getEditorClass()
/*     */     {
/*  52 */       return MCEditorTimestampField.class;
/*     */     }
/*     */   },
/*     */ 
/*     */   
/*  57 */   CHECK
/*     */   {
/*     */     
/*     */     @Deprecated
/*     */     public Class<?> getEditorClass()
/*     */     {
/*  63 */       return MCEditorCheckBox.class;
/*     */     }
/*     */   },
/*     */ 
/*     */   
/*  68 */   TEXT_COMBO
/*     */   {
/*     */     
/*     */     @Deprecated
/*     */     public Class<?> getEditorClass()
/*     */     {
/*  74 */       return MCEditorTextComboBox.class;
/*     */     }
/*     */   },
/*     */ 
/*     */   
/*  79 */   TEXT_COMBO_FREE
/*     */   {
/*     */     
/*     */     @Deprecated
/*     */     public Class<?> getEditorClass()
/*     */     {
/*  85 */       return MCEditorTextComboBox.class;
/*     */     }
/*     */   },
/*     */ 
/*     */   
/*  90 */   TEXT_COMBO_SELECT_ONLY
/*     */   {
/*     */     
/*     */     @Deprecated
/*     */     public Class<?> getEditorClass()
/*     */     {
/*  96 */       return MCEditorTextComboBox.class;
/*     */     }
/*     */   },
/*     */ 
/*     */   
/* 101 */   NUMBER_COMBO
/*     */   {
/*     */     
/*     */     @Deprecated
/*     */     public Class<?> getEditorClass()
/*     */     {
/* 107 */       return MCEditorNumberComboBox.class;
/*     */     }
/*     */   },
/*     */ 
/*     */   
/* 112 */   NUMBER_COMBO_FREE
/*     */   {
/*     */     
/*     */     @Deprecated
/*     */     public Class<?> getEditorClass()
/*     */     {
/* 118 */       return MCEditorNumberComboBox.class;
/*     */     }
/*     */   },
/*     */ 
/*     */   
/* 123 */   NUMBER_COMBO_SELECT_ONLY
/*     */   {
/*     */     
/*     */     @Deprecated
/*     */     public Class<?> getEditorClass()
/*     */     {
/* 129 */       return MCEditorNumberComboBox.class;
/*     */     }
/*     */   },
/*     */ 
/*     */   
/* 134 */   DATE_COMBO
/*     */   {
/*     */     
/*     */     @Deprecated
/*     */     public Class<?> getEditorClass()
/*     */     {
/* 140 */       return MCEditorDateComboBox.class;
/*     */     }
/*     */   },
/*     */ 
/*     */   
/* 145 */   DATE_COMBO_FREE
/*     */   {
/*     */     
/*     */     @Deprecated
/*     */     public Class<?> getEditorClass()
/*     */     {
/* 151 */       return MCEditorDateComboBox.class;
/*     */     }
/*     */   },
/*     */ 
/*     */   
/* 156 */   DATE_COMBO_SELECT_ONLY
/*     */   {
/*     */     
/*     */     @Deprecated
/*     */     public Class<?> getEditorClass()
/*     */     {
/* 162 */       return MCEditorDateComboBox.class;
/*     */     }
/*     */   },
/*     */ 
/*     */   
/* 167 */   TIMESTAMP_COMBO
/*     */   {
/*     */     
/*     */     @Deprecated
/*     */     public Class<?> getEditorClass()
/*     */     {
/* 173 */       return MCEditorTimestampComboBox.class;
/*     */     }
/*     */   },
/*     */ 
/*     */   
/* 178 */   TIMESTAMP_COMBO_FREE
/*     */   {
/*     */     
/*     */     @Deprecated
/*     */     public Class<?> getEditorClass()
/*     */     {
/* 184 */       return MCEditorTimestampComboBox.class;
/*     */     }
/*     */   },
/*     */ 
/*     */   
/* 189 */   TIMESTAMP_COMBO_SELECT_ONLY
/*     */   {
/*     */     
/*     */     @Deprecated
/*     */     public Class<?> getEditorClass()
/*     */     {
/* 195 */       return MCEditorTimestampComboBox.class;
/*     */     }
/*     */   },
/*     */ 
/*     */   
/* 200 */   PASSWORD
/*     */   {
/*     */     
/*     */     @Deprecated
/*     */     public Class<?> getEditorClass()
/*     */     {
/* 206 */       return MCEditorPasswordField.class;
/*     */     }
/*     */   },
/*     */ 
/*     */   
/* 211 */   IMAGE_VIEW
/*     */   {
/*     */     
/*     */     @Deprecated
/*     */     public Class<?> getEditorClass()
/*     */     {
/* 217 */       return MCEditorImageView.class;
/*     */     }
/*     */   },
/*     */ 
/*     */   
/* 222 */   BUTTON
/*     */   {
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public Class<?> getEditorClass()
/*     */     {
/* 231 */       return MCEditorButton.class;
/*     */     }
/*     */   },
/*     */ 
/*     */   
/* 236 */   NULL
/*     */   {
/*     */ 
/*     */     
/*     */     @Deprecated
/*     */     public Class<?> getEditorClass()
/*     */     {
/* 243 */       return null;
/*     */     }
/*     */   };
/*     */   
/*     */   @Deprecated
/*     */   public abstract Class<?> getEditorClass();
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCColumnType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */