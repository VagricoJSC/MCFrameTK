/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCColumnLayoutHorizontal
/*     */   extends MCColumnLayout
/*     */ {
/*     */   public MCColumnLayoutHorizontal(String name) {
/*  24 */     super(name);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isVertical() {
/*  29 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTierCount() {
/*  34 */     int tier = 0;
/*  35 */     MCColumnLayoutMember[] ms = getVisibleMembers();
/*  36 */     if (ms.length > 0) {
/*  37 */       tier = 1; byte b; int i; MCColumnLayoutMember[] arrayOfMCColumnLayoutMember;
/*  38 */       for (i = (arrayOfMCColumnLayoutMember = ms).length, b = 0; b < i; ) { MCColumnLayoutMember m = arrayOfMCColumnLayoutMember[b];
/*  39 */         if (m instanceof MCColumnLayout)
/*  40 */           tier = Math.max(tier, (
/*  41 */               (MCColumnLayout)m).getTierCount()); 
/*     */         b++; }
/*     */     
/*     */     } 
/*  45 */     return tier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int calcWidth(MCColumnLayout.WidthIO wio) {
/*  54 */     long width = 0L;
/*  55 */     MCColumnLayoutMember[] members = getMembers(); byte b; int i; MCColumnLayoutMember[] arrayOfMCColumnLayoutMember1;
/*  56 */     for (i = (arrayOfMCColumnLayoutMember1 = members).length, b = 0; b < i; ) { MCColumnLayoutMember member = arrayOfMCColumnLayoutMember1[b];
/*  57 */       width += wio.width(member); b++; }
/*     */     
/*  59 */     width = Math.min(width, 2147483647L);
/*  60 */     return (int)width;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int setMemberWidth(MCColumnLayout.WidthIO wio, int oldw, int neww) {
/*  71 */     MCColumnLayoutMember[] members = getVisibleMembers();
/*     */ 
/*     */     
/*  74 */     int last = members.length - 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  80 */     long width = ((neww < Integer.MAX_VALUE) ? neww : (neww * members.length));
/*     */ 
/*     */     
/*  83 */     for (int i = 0; i < last; i++) {
/*  84 */       width -= wio.width(members[i]);
/*     */     }
/*     */ 
/*     */     
/*  88 */     int result = neww;
/*  89 */     if (last >= 0) {
/*  90 */       int w = (int)Math.min(width, 2147483647L);
/*  91 */       int rw = w;
/*  92 */       MCColumnLayoutMember member = members[last];
/*  93 */       wio.width(member, w);
/*  94 */       rw = wio.width(member);
/*     */       
/*  96 */       if (rw != w) {
/*  97 */         int diff = rw - w;
/*  98 */         result = neww + diff;
/*     */       } 
/*     */     } 
/*     */     
/* 102 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getHeaderHeight() {
/* 114 */     int height = 0;
/* 115 */     MCColumnLayoutMember[] ms = getVisibleMembers(); byte b; int i; MCColumnLayoutMember[] arrayOfMCColumnLayoutMember1;
/* 116 */     for (i = (arrayOfMCColumnLayoutMember1 = ms).length, b = 0; b < i; ) { MCColumnLayoutMember m = arrayOfMCColumnLayoutMember1[b];
/* 117 */       int h = 0;
/* 118 */       if (m instanceof MCColumnLayout) {
/* 119 */         h = ((MCColumnLayout)m).getHeaderHeight();
/*     */       }
/* 121 */       else if (m instanceof MCColumnConfig) {
/* 122 */         h = getHeaderColumnHeight((MCTableColumn)m);
/*     */       } 
/* 124 */       height = Math.max(height, h); b++; }
/*     */     
/* 126 */     this._headerHeight = height;
/*     */ 
/*     */ 
/*     */     
/* 130 */     return this._headerHeight;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int headerColumnAtPoint(Point point, int height) {
/* 139 */     int x = 0;
/* 140 */     int pos = 0;
/*     */     
/* 142 */     MCColumnLayoutMember[] members = getMembers(); byte b; int i; MCColumnLayoutMember[] arrayOfMCColumnLayoutMember1;
/* 143 */     for (i = (arrayOfMCColumnLayoutMember1 = members).length, b = 0; b < i; ) { MCColumnLayoutMember member = arrayOfMCColumnLayoutMember1[b];
/* 144 */       if (member instanceof MCColumnLayout) {
/* 145 */         MCColumnLayout l = (MCColumnLayout)member;
/* 146 */         int w = l.getWidth();
/* 147 */         if (x + w > point.x) {
/*     */           
/* 149 */           Point p = point.getLocation();
/* 150 */           p.x -= x;
/* 151 */           pos += l.headerColumnAtPoint(p, height);
/*     */           break;
/*     */         } 
/* 154 */         x += w;
/* 155 */         pos += l.getAllColumnCount();
/*     */       }
/* 157 */       else if (member instanceof MCTableColumn) {
/* 158 */         x += ((MCTableColumn)member).getWidth();
/* 159 */         if (x > point.x) {
/*     */           break;
/*     */         }
/*     */         
/* 163 */         pos++;
/*     */       } 
/*     */       b++; }
/*     */     
/* 167 */     return pos;
/*     */   }
/*     */ 
/*     */   
/*     */   Rectangle getHeaderRect(Rectangle rect, MCTableColumn col) {
/* 172 */     Rectangle r = new Rectangle();
/* 173 */     int x = rect.x;
/* 174 */     int y = rect.y;
/* 175 */     int height = rect.height;
/*     */     
/* 177 */     MCColumnLayoutMember[] members = getMembers(); byte b; int i; MCColumnLayoutMember[] arrayOfMCColumnLayoutMember1;
/* 178 */     for (i = (arrayOfMCColumnLayoutMember1 = members).length, b = 0; b < i; ) { MCColumnLayoutMember member = arrayOfMCColumnLayoutMember1[b];
/* 179 */       if (member instanceof MCColumnLayout) {
/* 180 */         MCColumnLayout l = (MCColumnLayout)member;
/* 181 */         if (l.contains(col)) {
/* 182 */           r.x = x;
/* 183 */           r.y = y;
/* 184 */           r.height = height;
/* 185 */           r = l.getHeaderRect(r, col);
/*     */           break;
/*     */         } 
/* 188 */         x += l.getWidth();
/*     */       }
/* 190 */       else if (member instanceof MCTableColumn) {
/* 191 */         int w = ((MCTableColumn)member).getWidth();
/* 192 */         if (member == col) {
/* 193 */           r.x = x;
/* 194 */           r.y = y;
/* 195 */           r.height = height;
/* 196 */           r.width = w;
/*     */           break;
/*     */         } 
/* 199 */         x += w;
/*     */       } 
/*     */       b++; }
/*     */     
/* 203 */     return r;
/*     */   }
/*     */ 
/*     */   
/*     */   int columnAtPoint(Point point, int height, int colheight) {
/* 208 */     int x = 0;
/* 209 */     int pos = 0;
/*     */     
/* 211 */     MCColumnLayoutMember[] members = getMembers(); byte b; int i; MCColumnLayoutMember[] arrayOfMCColumnLayoutMember1;
/* 212 */     for (i = (arrayOfMCColumnLayoutMember1 = members).length, b = 0; b < i; ) { MCColumnLayoutMember member = arrayOfMCColumnLayoutMember1[b];
/* 213 */       if (member instanceof MCColumnLayout) {
/* 214 */         MCColumnLayout l = (MCColumnLayout)member;
/* 215 */         int w = l.getWidth();
/* 216 */         if (x + w > point.x) {
/*     */           
/* 218 */           Point p = point.getLocation();
/* 219 */           p.x -= x;
/* 220 */           pos += l.columnAtPoint(p, height, colheight);
/*     */           break;
/*     */         } 
/* 223 */         x += w;
/* 224 */         pos += l.getAllColumnCount();
/*     */       }
/* 226 */       else if (member instanceof MCTableColumn) {
/* 227 */         x += ((MCTableColumn)member).getWidth();
/* 228 */         if (x > point.x) {
/*     */           break;
/*     */         }
/*     */         
/* 232 */         pos++;
/*     */       } 
/*     */       b++; }
/*     */     
/* 236 */     return pos;
/*     */   }
/*     */ 
/*     */   
/*     */   Rectangle getCellRect(Rectangle rect, MCTableColumn col, int colheight) {
/* 241 */     Rectangle r = new Rectangle();
/* 242 */     int x = rect.x;
/* 243 */     int y = rect.y;
/* 244 */     int height = rect.height;
/*     */     
/* 246 */     MCColumnLayoutMember[] members = getMembers();
/* 247 */     int memberlen = members.length;
/* 248 */     for (int i = 0; i < memberlen; i++) {
/* 249 */       MCColumnLayoutMember member = members[i];
/* 250 */       if (member instanceof MCColumnLayout) {
/* 251 */         MCColumnLayout l = (MCColumnLayout)member;
/* 252 */         if (l.contains(col)) {
/* 253 */           r.x = x;
/* 254 */           r.y = y;
/* 255 */           r.height = height;
/* 256 */           r = l.getCellRect(r, col, colheight);
/*     */           break;
/*     */         } 
/* 259 */         x += l.getWidth();
/*     */       }
/* 261 */       else if (member instanceof MCTableColumn) {
/* 262 */         int w = ((MCTableColumn)member).getWidth();
/* 263 */         if (member == col) {
/* 264 */           r.x = x;
/* 265 */           r.y = y;
/* 266 */           r.height = height;
/* 267 */           r.width = w;
/*     */           break;
/*     */         } 
/* 270 */         x += w;
/*     */       } 
/*     */     } 
/*     */     
/* 274 */     return r;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCColumnLayoutHorizontal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */