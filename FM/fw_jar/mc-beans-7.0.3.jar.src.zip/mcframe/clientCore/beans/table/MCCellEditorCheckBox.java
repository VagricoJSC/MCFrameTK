/*    */ package mcframe.clientCore.beans.table;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import javax.swing.JCheckBox;
/*    */ import javax.swing.JTable;
/*    */ import javax.swing.JTextField;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCCellEditorCheckBox
/*    */   extends MCCellEditor
/*    */ {
/* 24 */   private static final JTextField TEXT_FIELD = new JTextField();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected MCCellEditorCheckBox(String name, MCColumnConfig column) {
/* 35 */     super((JCheckBox)new MCEditorCheckBox(name, column), column);
/* 36 */     getEditorComponent().setBorder(TEXT_FIELD.getBorder());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected MCEditorCheckBox getEditorComponent() {
/* 47 */     return (MCEditorCheckBox)this.editorComponent;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Component getTableCellEditorComponent(JTable table, Object value, boolean selected, int index, int column) {
/* 65 */     return (Component)getEditor((MCTable)table, (Boolean)value, index, getColumnConfig());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected MCEditorCheckBox getEditor(MCTable<?> table, Boolean value, int index, MCColumnConfig column) {
/* 82 */     MCEditorCheckBox compo = getEditorComponent();
/* 83 */     compo.setBorderPainted(true);
/* 84 */     compo.setColumnInfo(index, column);
/* 85 */     compo.setSelected((value != null) ? value.booleanValue() : false);
/* 86 */     return compo;
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCCellEditorCheckBox.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */