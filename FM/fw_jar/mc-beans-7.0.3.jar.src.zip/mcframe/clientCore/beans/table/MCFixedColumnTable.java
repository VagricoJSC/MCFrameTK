/*     */ package mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Point;
/*     */ import java.awt.event.MouseEvent;
/*     */ import javax.swing.table.TableColumn;
/*     */ import mcframe.clientCore.beans.MCMode;
/*     */ import mcframe.clientCore.beans.MCModeInfo;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCFixedColumnTable<E extends MCConstRow>
/*     */   extends MCTable<E>
/*     */ {
/*     */   static final String NAME_ROW_NUMBER = "row number";
/*     */   static final String NAME_ROW_STATUS = "row status";
/*     */   static final String NAME_ROW_SIGNAL = "row signal";
/*     */   static final int INFRA_COLUMN_COUNT = 3;
/*     */   
/*     */   private static MCInfraCellRenderer getRowNumberCellRenderer(MCColumnConfig column) {
/*  42 */     String type = MCConst.beans.getString(MCConst.createKey(new String[] {
/*     */             
/*  44 */             "table", "rownumber", "type" }));
/*  45 */     if ("plain".equals(type)) {
/*  46 */       return new MCPlainRowNumberCellRenderer(column);
/*     */     }
/*  48 */     return new MCRowNumberCellRenderer(column);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   final MCTableColumn number = new MCTableColumn("row number", MCColumnType.NULL);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final MCTableColumn status;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final MCTableColumn signal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean _dragging;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCFixedColumnTable(MCTable<E> table, String name) {
/* 109 */     super(table, name);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     this.number.setHeaderValue(" ");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     this.number.setCellRenderer(getRowNumberCellRenderer(this.number));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     this.number.setCellEditor(null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     this.number.setToolTipEnabled(false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     this.status = new MCTableColumn("row status", MCColumnType.NULL);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     this.status.setHeaderValue(" ");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     this.status.setCellRenderer(new MCStatusCellRenderer(this.status));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     this.status.setCellEditor(null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     this.status.setToolTipEnabled(false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     this.signal = new MCTableColumn("row signal", MCColumnType.NULL);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     this.signal.setHeaderValue(" ");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     this.signal.setCellRenderer(new MCRowSignalCellRenderer(this.signal));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     this.signal.setCellEditor(null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     this.signal.setToolTipEnabled(false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 277 */     this._dragging = false; this._fixed = this;
/*     */     this._body = table;
/*     */     setModel(table.getModel());
/*     */     setSelectionModel(new MCListSelectionModel(this));
/* 281 */     getTableHeader().setReorderingAllowed(false); } protected void processMouseMotionEvent(MouseEvent e) { if (e.getID() == 506) {
/* 282 */       this._dragging = true;
/* 283 */       Point p = e.getPoint();
/* 284 */       int idx = columnAtPoint(p);
/* 285 */       if (idx >= 0) {
/* 286 */         super.processMouseMotionEvent(e);
/*     */       }
/*     */     } else {
/*     */       
/* 290 */       super.processMouseMotionEvent(e);
/*     */     }  }
/*     */ 
/*     */   
/*     */   boolean isInfraColumn(MCColumnConfig column) {
/*     */     return !(column != this.number && column != this.status && column != this.signal);
/*     */   }
/*     */   
/*     */   public MCRowSignal getRowSignal() {
/*     */     return ((MCRowSignalCellRenderer)this.signal.getCellRenderer()).getRowSignal();
/*     */   }
/*     */   
/*     */   boolean isFixedColumnTable() {
/*     */     return true;
/*     */   }
/*     */   
/*     */   void addColumn(MCTableColumn c) {
/*     */     super.addColumn(c);
/*     */     adjustTableWidth();
/*     */   }
/*     */   
/*     */   public void addColumn(TableColumn c) {
/*     */     super.addColumn(c);
/*     */     adjustTableWidth();
/*     */   }
/*     */   
/*     */   void adjustTableWidth() {
/*     */     int w = getColumnModel().getTotalColumnWidth();
/*     */     setPreferredScrollableViewportSize(new Dimension(w, (getSize()).height));
/*     */   }
/*     */   
/*     */   MCTableColumn[] getAppTableColumns() {
/*     */     getColumns();
/*     */     int cnt = getColumnCount() - getModel().getInfraColumnCount();
/*     */     if (cnt < 0)
/*     */       cnt = 0; 
/*     */     MCTableColumn[] a = new MCTableColumn[cnt];
/*     */     int i = 0;
/*     */     byte b;
/*     */     int j;
/*     */     MCTableColumn[] arrayOfMCTableColumn1;
/*     */     for (j = (arrayOfMCTableColumn1 = getTableColumns()).length, b = 0; b < j; ) {
/*     */       MCTableColumn c = arrayOfMCTableColumn1[b];
/*     */       if (!isInfraColumn(c))
/*     */         a[i++] = c; 
/*     */       b++;
/*     */     } 
/*     */     return a;
/*     */   }
/*     */   
/*     */   MCTableColumn[] getTableColumns() {
/*     */     return super.getTableColumns();
/*     */   }
/*     */   
/*     */   boolean isBodyTable() {
/*     */     return false;
/*     */   }
/*     */   
/*     */   public Comparable<?> getValue(int index, MCColumnConfig column) {
/*     */     if (!isInfraColumn(column))
/*     */       return super.getValue(index, column); 
/*     */     int v = getViewColumn(column);
/*     */     return ((MCInfraCellRenderer)getCellRenderer(index, v)).getValue();
/*     */   }
/*     */   
/*     */   public MCMode isCellEditable(int index, MCColumnConfig column) {
/*     */     return !isInfraColumn(column) ? super.isCellEditable(index, column) : MCMode.DISABLE;
/*     */   }
/*     */   
/*     */   public MCCellConfig getCellConfig() {
/*     */     return getBodyTable().getCellConfig();
/*     */   }
/*     */   
/*     */   public boolean isEnabled() {
/*     */     MCTable<E> t = getBodyTable();
/*     */     return (t != null && t != this) ? t.isEnabled() : super.isEnabled();
/*     */   }
/*     */   
/*     */   public boolean isVisible() {
/*     */     MCTable<E> t = getBodyTable();
/*     */     return (t != null && t != this) ? t.isVisible() : super.isVisible();
/*     */   }
/*     */   
/*     */   public boolean isFocusable() {
/*     */     MCTable<E> t = getBodyTable();
/*     */     return (t != null && t != this) ? t.isFocusable() : super.isFocusable();
/*     */   }
/*     */   
/*     */   public MCMode getMode() {
/*     */     MCTable<E> t = getBodyTable();
/*     */     return (t != null && t != this) ? t.getMode() : super.getMode();
/*     */   }
/*     */   
/*     */   public MCModeInfo getModeInfo() {
/*     */     MCTable<E> t = getBodyTable();
/*     */     return (t != null && t != this) ? t.getModeInfo() : super.getModeInfo();
/*     */   }
/*     */   
/*     */   public MCModeInfo getModeInfo(MCMode mode) {
/*     */     MCTable<E> t = getBodyTable();
/*     */     return (t != null && t != this) ? t.getModeInfo(mode) : super.getModeInfo(mode);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCFixedColumnTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */