/*    */ package mcframe.clientCore.beans.table;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import mcframe.commonCore.lang.MCStringUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCColumnModeInfoList
/*    */ {
/* 23 */   private final List<MCColumnModeInfo> _list = new ArrayList<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private final MCColumnConfig _column;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected MCColumnModeInfoList(MCColumnConfig column) {
/* 41 */     this._column = column;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MCColumnModeInfo getModeInfo(String name) {
/* 56 */     if (!MCStringUtil.isNull(name)) {
/* 57 */       MCColumnModeInfo[] infos = this._list.<MCColumnModeInfo>toArray(new MCColumnModeInfo[this._list.size()]); byte b; int i; MCColumnModeInfo[] arrayOfMCColumnModeInfo1;
/* 58 */       for (i = (arrayOfMCColumnModeInfo1 = infos).length, b = 0; b < i; ) { MCColumnModeInfo mCColumnModeInfo = arrayOfMCColumnModeInfo1[b];
/* 59 */         if (name.equals(mCColumnModeInfo.getName()))
/* 60 */           return mCColumnModeInfo; 
/*    */         b++; }
/*    */       
/* 63 */       MCColumnModeInfo info = new MCColumnModeInfo(this._column, name);
/* 64 */       this._list.add(info);
/* 65 */       return info;
/*    */     } 
/* 67 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void removeAll() {
/* 77 */     this._list.clear();
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCColumnModeInfoList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */