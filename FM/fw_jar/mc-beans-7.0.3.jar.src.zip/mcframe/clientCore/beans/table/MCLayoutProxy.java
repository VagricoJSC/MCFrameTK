/*    */ package mcframe.clientCore.beans.table;
/*    */ 
/*    */ import java.util.Map;
/*    */ import mcframe.clientCore.beans.layout.AbsMCPackageProxy;
/*    */ import mcframe.clientCore.beans.layout.MCAutoLayout;
/*    */ 
/*    */ final class MCLayoutProxy
/*    */   extends AbsMCPackageProxy {
/*  9 */   static final MCLayoutProxy PROXY = new MCLayoutProxy();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected Map<String, Boolean> getSystemInvisibleInfo(MCAutoLayout layout, MCTable<?> table) {
/* 17 */     return super.getSystemInvisibleInfo(layout, table);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\table\MCLayoutProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */