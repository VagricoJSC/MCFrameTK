/*      */ package mcframe.clientCore.beans.layout;
/*      */ 
/*      */ import java.awt.AlphaComposite;
/*      */ import java.awt.BorderLayout;
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.Container;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Font;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.Graphics2D;
/*      */ import java.awt.Image;
/*      */ import java.awt.Insets;
/*      */ import java.awt.LayoutManager;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.Shape;
/*      */ import java.awt.Toolkit;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.ActionListener;
/*      */ import java.awt.event.ComponentAdapter;
/*      */ import java.awt.event.ComponentEvent;
/*      */ import java.awt.geom.Ellipse2D;
/*      */ import java.awt.geom.Path2D;
/*      */ import java.awt.geom.Rectangle2D;
/*      */ import java.awt.image.BufferedImage;
/*      */ import java.awt.image.ImageObserver;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.HashMap;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Objects;
/*      */ import javax.imageio.ImageIO;
/*      */ import javax.swing.AbstractAction;
/*      */ import javax.swing.ActionMap;
/*      */ import javax.swing.BorderFactory;
/*      */ import javax.swing.Box;
/*      */ import javax.swing.BoxLayout;
/*      */ import javax.swing.Icon;
/*      */ import javax.swing.ImageIcon;
/*      */ import javax.swing.InputMap;
/*      */ import javax.swing.JComponent;
/*      */ import javax.swing.JMenuItem;
/*      */ import javax.swing.JPanel;
/*      */ import javax.swing.JScrollPane;
/*      */ import javax.swing.JSplitPane;
/*      */ import javax.swing.JTabbedPane;
/*      */ import javax.swing.KeyStroke;
/*      */ import javax.swing.SwingUtilities;
/*      */ import javax.swing.border.Border;
/*      */ import javax.swing.border.EmptyBorder;
/*      */ import mcframe.clientCore.beans.MCBeans;
/*      */ import mcframe.clientCore.beans.MCBeansCompatibilityFactory;
/*      */ import mcframe.clientCore.beans.MCBeansUtil;
/*      */ import mcframe.clientCore.beans.MCButton;
/*      */ import mcframe.clientCore.beans.MCFrame;
/*      */ import mcframe.clientCore.beans.MCMode;
/*      */ import mcframe.clientCore.beans.MCModeBeans;
/*      */ import mcframe.clientCore.beans.MCPanel;
/*      */ import mcframe.clientCore.beans.MCResourceBeans;
/*      */ import mcframe.clientCore.beans.MCRootPanel;
/*      */ import mcframe.clientCore.beans.MCScrollPane;
/*      */ import mcframe.clientCore.beans.MCSplitPane;
/*      */ import mcframe.clientCore.beans.MCTabOrderBeans;
/*      */ import mcframe.clientCore.beans.MCTabbedPane;
/*      */ import mcframe.clientCore.beans.action.MCKeyAction;
/*      */ import mcframe.clientCore.beans.menu.MCMenuItem;
/*      */ import mcframe.clientCore.beans.menu.MCMenuItemListener;
/*      */ import mcframe.clientCore.beans.plaf.MCGraphicsUtil;
/*      */ import mcframe.clientCore.beans.popup.MCPopupMenu;
/*      */ import mcframe.clientCore.beans.statusbar.MCStatusBar;
/*      */ import mcframe.clientCore.beans.table.MCTable;
/*      */ import mcframe.clientCore.event.MCAPBeans;
/*      */ import mcframe.clientCore.event.MCEventInfo;
/*      */ import mcframe.clientCore.requester.MCDownloader;
/*      */ import mcframe.clientCore.resource.MCConst;
/*      */ import mcframe.clientCore.resource.MCIconSupplier;
/*      */ import mcframe.clientCore.resource.MCMenuItemModel;
/*      */ import mcframe.clientCore.resource.MCMenuModel;
/*      */ import mcframe.clientCore.sys.MCSys;
/*      */ import mcframe.commonCore.lang.MCBinary;
/*      */ import mcframe.commonCore.lang.MCStringUtil;
/*      */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*      */ import mcframe.commonCore.notice.MCException;
/*      */ import mcframe.commonCore.notice.MCLog;
/*      */ import mcframe.commonCore.resource.ctrl.MCResource;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MCGeneralLayout
/*      */   implements MCLayout
/*      */ {
/*  110 */   protected MCPanel _headerBar = null;
/*      */ 
/*      */   
/*      */   protected MCPanel _westbar;
/*      */ 
/*      */   
/*      */   protected MCPanel _eastbar;
/*      */ 
/*      */   
/*  119 */   MCStatusBar _statusBar = null; private MCMarginManager _margin_manager; protected static final String BOX_X = "BOX_X"; protected static final String SPLIT_T = "SPLIT_T"; protected static final String SPLIT_B = "SPLIT_B"; protected static final String SPLIT_L = "SPLIT_L"; protected static final String SPLIT_R = "SPLIT_R"; public static final String DEFAULT_POSITION = "N"; public static final String LP_C = "C"; public static final String LP_N = "N"; public static final String LP_S = "S"; public static final String LP_E = "E"; public static final String LP_W = "W"; public static final String LP_BOX_X = "X"; public static final String LP_SP_T = "T"; public static final String LP_SP_B = "B"; public static final String LP_SP_L = "L"; public static final String LP_SP_R = "R"; public static final String LP_RECURSIVE_MARK = "+";
/*      */   protected static final int TBL_MIN_HEIGHT = 60;
/*      */   
/*  122 */   private enum BarType { HEADERBAR
/*      */     {
/*      */       String getResourceString() {
/*  125 */         return "headerbar";
/*      */       }
/*      */     },
/*  128 */     STATUSBAR
/*      */     {
/*      */       String getResourceString() {
/*  131 */         return "statusbar";
/*      */       }
/*      */     };
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     abstract String getResourceString(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final class MCMarginManager
/*      */   {
/*  146 */     private static final String key = MCConst.createKey(new String[] { "panel", "layouter", "root", 
/*  147 */           "margin" });
/*      */ 
/*      */     
/*  150 */     private static final int _def_top = MCConst.beans
/*  151 */       .getInteger(MCConst.createKey(new String[] { key, "top" }, ), 5);
/*      */     
/*  153 */     private static final int _def_left = MCConst.beans
/*  154 */       .getInteger(MCConst.createKey(new String[] { key, "left" }, ), 20);
/*      */     
/*  156 */     private static final int _def_bottm = MCConst.beans
/*  157 */       .getInteger(MCConst.createKey(new String[] { key, "bottom" }, ), 5);
/*      */     
/*  159 */     private static final int _def_right = MCConst.beans
/*  160 */       .getInteger(MCConst.createKey(new String[] { key, "right" }, ), 20);
/*      */ 
/*      */     
/*      */     private static Color _margin_color;
/*      */ 
/*      */     
/*      */     private final MCPanel _layouterRoot;
/*      */ 
/*      */     
/*  169 */     private Insets _margin = new Insets(_def_top, _def_left, _def_bottm, _def_right);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     MCMarginManager(MCPanel layouterRoot) {
/*  178 */       this._layouterRoot = Objects.<MCPanel>requireNonNull(layouterRoot);
/*  179 */       _margin_color = MCConst.beans.getColor(MCConst.createKey(new String[] { key, "color" }));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void reset() {
/*  186 */       this._margin.top = _def_top;
/*  187 */       this._margin.left = _def_left;
/*  188 */       this._margin.bottom = _def_bottm;
/*  189 */       this._margin.right = _def_right;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     boolean update() {
/*  197 */       MCRootPanel p = this._layouterRoot.getRootPanel();
/*  198 */       if (p != null && p.getFrame() != null) {
/*      */ 
/*      */         
/*  201 */         this._layouterRoot.setBorder(new MCEmptyBorder(this, p, this._margin.top, this._margin.left, 
/*  202 */               this._margin.bottom, this._margin.right)
/*      */             {
/*      */ 
/*      */ 
/*      */               
/*      */               public void paintBorder(Component c, Graphics g, int x, int y, int width, int height)
/*      */               {
/*  209 */                 if (g instanceof Graphics2D) {
/*  210 */                   if (MCGeneralLayout.MCMarginManager._margin_color == null) {
/*      */                     return;
/*      */                   }
/*      */                   
/*  214 */                   Graphics2D g2d = (Graphics2D)g;
/*  215 */                   Color oldColor = g2d.getColor();
/*  216 */                   g2d.setColor(MCGeneralLayout.MCMarginManager._margin_color);
/*      */                   
/*  218 */                   int _left = this.left;
/*  219 */                   int _top = this.top;
/*  220 */                   int _right = this.right;
/*  221 */                   int _bottom = this.bottom;
/*      */                   
/*  223 */                   if (this._rp != null) {
/*  224 */                     int ratio = this._rp.getLayoutRatio();
/*  225 */                     if (ratio == 0) {
/*  226 */                       ratio = 100;
/*      */                     }
/*  228 */                     _left = this.left * ratio / 100;
/*  229 */                     _top = this.top * ratio / 100;
/*  230 */                     _right = this.right * ratio / 100;
/*  231 */                     _bottom = this.bottom * ratio / 100;
/*      */                   } 
/*      */ 
/*      */                   
/*  235 */                   Shape outer = new Rectangle2D.Float(x, y, width, height);
/*      */ 
/*      */                   
/*  238 */                   Shape inner = new Rectangle2D.Float((x + _left), (y + _top), (
/*  239 */                       width - _left - _right), (height - _top - _bottom));
/*      */                   
/*  241 */                   Path2D path = new Path2D.Float(0);
/*  242 */                   path.append(outer, false);
/*  243 */                   path.append(inner, false);
/*  244 */                   g2d.fill(path);
/*  245 */                   g2d.setColor(oldColor);
/*      */                 } 
/*      */               }
/*      */ 
/*      */               
/*      */               public boolean isBorderOpaque() {
/*  251 */                 return (MCGeneralLayout.MCMarginManager._margin_color != null);
/*      */               }
/*      */             });
/*      */         
/*  255 */         return true;
/*      */       } 
/*  257 */       return false;
/*      */     }
/*      */     
/*      */     protected class MCEmptyBorder
/*      */       extends EmptyBorder {
/*  262 */       MCRootPanel _rp = MCGeneralLayout.MCMarginManager.this._layouterRoot.getRootPanel();
/*      */       
/*      */       public MCEmptyBorder(MCRootPanel rp, int top, int left, int bottom, int right) {
/*  265 */         super(top, left, bottom, right);
/*      */       }
/*      */ 
/*      */       
/*      */       public Insets getBorderInsets(Component c, Insets insets) {
/*  270 */         if (this._rp != null) {
/*  271 */           int ratio = this._rp.getLayoutRatio();
/*  272 */           if (ratio == 0) {
/*  273 */             ratio = 100;
/*      */           }
/*  275 */           insets.left = this.left * ratio / 100;
/*  276 */           insets.top = this.top * ratio / 100;
/*  277 */           insets.right = this.right * ratio / 100;
/*  278 */           insets.bottom = this.bottom * ratio / 100;
/*      */         } else {
/*  280 */           insets.left = this.left;
/*  281 */           insets.top = this.top;
/*  282 */           insets.right = this.right;
/*  283 */           insets.bottom = this.bottom;
/*      */         } 
/*  285 */         return insets;
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void margin(Insets m) {
/*  293 */       this._margin.top = m.top;
/*  294 */       this._margin.left = m.left;
/*  295 */       this._margin.bottom = m.bottom;
/*  296 */       this._margin.right = m.right;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     Insets margin() {
/*  304 */       return new Insets(this._margin.top, this._margin.left, this._margin.bottom, this._margin.right);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  419 */   private int _temp_panel_counter = 0;
/*      */   
/*  421 */   private int _temp_panel_counter_save = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final MCRootPanel panel;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*  439 */   private Map<String, String[]> _layoutPositionArrayMap = (Map)new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  444 */   protected final MCPanel _root = createTempPanel("layouterRoot");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  451 */   protected final MCPanel _rootSub = createRootSubTempPanel("layoutSub");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  456 */   protected final MCPanel _rootSubMain = createTempPanel("layoutMain");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  462 */   protected int _panelsForZoomPointer = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  467 */   private List<MCPanel> _panelsForZoom = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  472 */   private MCPanel[] _allMCPanel = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  477 */   private Map<MCPanel, Dimension[]> _orgDim = (Map)new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  482 */   private Map<MCSplitPane, Object[]> _orgSplitInfo = (Map)new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  487 */   private Map<String, Boolean> _fontRatioChangeMenuVisible = new HashMap<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  493 */   protected Container _oldParent = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  499 */   protected Object _oldConstraints = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _hasForHeader = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  509 */   protected Map<String, HashMap<String, Integer>> _layoutBorderInsetsMap = new HashMap<>();
/*      */   
/*      */   MCButton _XATitle;
/*      */   
/*      */   private boolean _initFlg;
/*      */   
/*      */   protected int _headerIndex;
/*      */   
/*      */   protected static final String _headerbarName = "_headerbar";
/*      */   
/*      */   protected LinkedHashMap<String, Rectangle> _defaultBoundsMap;
/*      */   
/*      */   private static final String PUSH_VIEW_NAME_E = "_hbar_e";
/*      */   
/*      */   private static final String PUSH_VIEW_NAME_I = "_hbar_i";
/*      */   
/*      */   protected boolean isSupportBasePanel;
/*      */ 
/*      */   
/*      */   public static void tracePosition(MCRootPanel _panel) {
/*  529 */     tracePosition((JComponent)_panel, "", 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void tracePosition(JComponent compo, String position, int depth) {
/*  543 */     Dimension m = compo.getMinimumSize();
/*      */     
/*  545 */     Object a1 = compo.getName();
/*  546 */     Object a2 = String.valueOf(depth);
/*  547 */     Object a3 = position;
/*  548 */     Object a4 = Integer.valueOf(compo.getX());
/*  549 */     Object a5 = Integer.valueOf(compo.getWidth());
/*  550 */     Object a6 = Integer.valueOf(compo.getY());
/*  551 */     Object a7 = Integer.valueOf(compo.getHeight());
/*  552 */     Object a8 = Double.valueOf(m.getWidth());
/*  553 */     Object a9 = Double.valueOf(m.getHeight());
/*      */     
/*  555 */     MCLog.write(Core_Msg_FW_A.FCBAC0315, new Object[] { a1, a2, a3, a4, a5, a6, a7, a8, a9 });
/*      */     
/*  557 */     depth++; byte b; int i;
/*      */     Component[] arrayOfComponent;
/*  559 */     for (i = (arrayOfComponent = compo.getComponents()).length, b = 0; b < i; ) { Component c = arrayOfComponent[b];
/*  560 */       if (c instanceof MCPanel) {
/*  561 */         MCPanel p = (MCPanel)c;
/*  562 */         tracePosition((JComponent)p, p.getLayoutPosition(), depth);
/*      */       } 
/*      */       b++; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void trace(String traceId, JPanel _panel) {
/*  576 */     Object a1 = _panel.getName();
/*  577 */     Object a2 = (_panel instanceof MCPanel) ? ((MCPanel)_panel).getLayoutPosition() : 
/*  578 */       "";
/*  579 */     Object a3 = toString(_panel.getPreferredSize());
/*  580 */     Object a4 = toString(_panel.getMinimumSize());
/*  581 */     Object a5 = toString(_panel.getSize());
/*  582 */     Object a6 = traceId;
/*      */     
/*  584 */     MCLog.write(Core_Msg_FW_A.FCBAC0314, new Object[] { a1, a2, a3, a4, a5, a6 });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String toString(Dimension dim) {
/*  595 */     return MCStringUtil.join(",", new String[] { String.valueOf(dim.width), 
/*  596 */           String.valueOf(dim.height) });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getLayoutPosition(MCPanel _panel, int begin, int end) {
/*  610 */     String[] a = getLayoutPositionArray(_panel);
/*  611 */     StringBuilder sb = new StringBuilder();
/*  612 */     if (a.length > end) {
/*  613 */       for (int i = begin; i < end; i++) {
/*  614 */         sb.append(a[i]);
/*      */       }
/*      */     } else {
/*      */       int i;
/*  618 */       for (i = begin; i < a.length; i++) {
/*  619 */         sb.append(a[i]);
/*      */       }
/*  621 */       for (i = a.length; i < end; i++) {
/*  622 */         sb.append("N");
/*      */       }
/*      */     } 
/*  625 */     return sb.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String[] getLayoutPositionArray(MCPanel _panel) {
/*  635 */     String p = _panel.getLayoutPosition();
/*  636 */     String[] a = this._layoutPositionArrayMap.get(p);
/*  637 */     if (a != null) {
/*  638 */       return a;
/*      */     }
/*  640 */     String k = null;
/*  641 */     String[] v = null;
/*  642 */     if (!MCStringUtil.isNull(p)) {
/*  643 */       k = p;
/*  644 */       v = checkLayoutPosition(_panel);
/*      */     } else {
/*      */       
/*  647 */       k = "";
/*  648 */       v = new String[0];
/*      */     } 
/*  650 */     this._layoutPositionArrayMap.put(k, v);
/*  651 */     return v;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void purgeCache() {
/*  658 */     this._layoutPositionArrayMap = (Map)new HashMap<>();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String[] checkLayoutPosition(MCPanel _panel) {
/*  676 */     List<String> l = new ArrayList<>();
/*  677 */     String p = _panel.getLayoutPosition();
/*  678 */     char[] a = p.toCharArray();
/*  679 */     for (int i = 0; i < a.length; i++) {
/*  680 */       String s = String.valueOf(a[i]);
/*  681 */       if ("+".equals(s)) {
/*  682 */         if (i != a.length - 1) {
/*  683 */           throw new MCException(Core_Msg_FW_A.FCBAC0316, new Object[] { "+", this.panel.getName(), 
/*  684 */                 p });
/*      */         
/*      */         }
/*      */       }
/*  688 */       else if ("N".equals(s) || "C".equals(s) || "S".equals(s) || "E".equals(s) || 
/*  689 */         "W".equals(s)) {
/*  690 */         l.add(s);
/*      */       }
/*  692 */       else if ("B".equals(s) || "T".equals(s) || "R".equals(s) || 
/*  693 */         "L".equals(s)) {
/*  694 */         l.add(s);
/*      */       }
/*  696 */       else if ("X".equals(s)) {
/*  697 */         l.add(s);
/*      */       } else {
/*      */         
/*  700 */         throw new MCException(Core_Msg_FW_A.FCBAC0317, new Object[] { this.panel.getName(), p, s });
/*      */       } 
/*      */     } 
/*  703 */     return l.<String>toArray(new String[l.size()]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MCPanel createTempPanel(String position) {
/*  714 */     MCPanel p = new MCPanel(getTempPanelName());
/*      */ 
/*      */     
/*  717 */     p.setLayoutPosition(position);
/*  718 */     return p;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MCPanel createRootSubTempPanel(String position) {
/*  725 */     MCPanel p = new MCPanel(getTempPanelName())
/*      */       {
/*      */         public String getUIClassID() {
/*  728 */           return "MCTempPanelUI";
/*      */         }
/*      */       };
/*      */ 
/*      */     
/*  733 */     p.setLayoutPosition(position);
/*  734 */     return p;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getTempPanelName() {
/*  745 */     String n1 = "_layouter";
/*  746 */     String n2 = String.valueOf(++this._temp_panel_counter);
/*      */     
/*  748 */     if (this.panel != null)
/*      */     {
/*  750 */       return MCStringUtil.join("_", new String[] { n1, this.panel.getModuleID(), this.panel.getScreenID(), 
/*  751 */             this.panel.getName(), n2 });
/*      */     }
/*      */     
/*  754 */     return MCStringUtil.join("_", new String[] { n1, n2 });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String toBLPositionStr(String pstn) {
/*  765 */     if ("C".equals(pstn)) {
/*  766 */       return "Center";
/*      */     }
/*  768 */     if ("N".equals(pstn)) {
/*  769 */       return "North";
/*      */     }
/*  771 */     if ("S".equals(pstn)) {
/*  772 */       return "South";
/*      */     }
/*  774 */     if ("E".equals(pstn)) {
/*  775 */       return "East";
/*      */     }
/*  777 */     if ("W".equals(pstn)) {
/*  778 */       return "West";
/*      */     }
/*  780 */     if ("X".equals(pstn)) {
/*  781 */       return "BOX_X";
/*      */     }
/*  783 */     if ("T".equals(pstn)) {
/*  784 */       return "SPLIT_T";
/*      */     }
/*  786 */     if ("B".equals(pstn)) {
/*  787 */       return "SPLIT_B";
/*      */     }
/*  789 */     if ("L".equals(pstn)) {
/*  790 */       return "SPLIT_L";
/*      */     }
/*  792 */     if ("R".equals(pstn)) {
/*  793 */       return "SPLIT_R";
/*      */     }
/*      */     
/*  796 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MCBorderLayout createMCBorderLayout() {
/*  807 */     return new MCBorderLayout(this);
/*      */   }
/*      */ 
/*      */   
/*      */   public final Insets getMargin() {
/*  812 */     if (this._margin_manager != null) {
/*  813 */       return this._margin_manager.margin();
/*      */     }
/*  815 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean updateMargin() {
/*  820 */     if (this._margin_manager != null) {
/*  821 */       return this._margin_manager.update();
/*      */     }
/*  823 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setMargin(Insets m) {
/*  828 */     if (this._margin_manager != null) {
/*  829 */       this._margin_manager.margin(m);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public final void resetMargin() {
/*  835 */     if (this._margin_manager != null)
/*  836 */       this._margin_manager.reset();  } protected MCButton getXATitle() { if (this._XATitle != null) return this._XATitle;  MCButton l = createHeaderButton("mc_title"); l.setMode(MCMode.READ_ONLY); l.setIcon("HBAR_PRODUCT"); l.setDisabledIcon(l.getIcon()); this._XATitle = l; return this._XATitle; } private boolean canUseMenuModelInHeaderBar() { return (MCMenuModel.isLoad() && !(this.panel instanceof mcframe.clientCore.login.MCLoginPanel)); } protected void initRelayout(MCRootPanel c) { byte b; int i; Component[] arrayOfComponent; for (i = (arrayOfComponent = c.getComponents()).length, b = 0; b < i; ) { Component c2 = arrayOfComponent[b]; if (c2 instanceof JPanel) { initRelayout2((JPanel)c2); } else if (c2 instanceof JScrollPane) { initRelayout4((JScrollPane)c2, (Container)c); } else if (c2 instanceof JSplitPane) { initRelayout3((JSplitPane)c2); }  b++; }  } protected void initRelayout(MCPanel c) { byte b; int i; Component[] arrayOfComponent; for (i = (arrayOfComponent = c.getComponents()).length, b = 0; b < i; ) { Component c2 = arrayOfComponent[b]; if (c2 instanceof JPanel) { initRelayout2((JPanel)c2); } else if (c2 instanceof JScrollPane) { initRelayout4((JScrollPane)c2, (Container)c); } else if (c2 instanceof JSplitPane) { initRelayout3((JSplitPane)c2); } else if (c2 instanceof JTabbedPane) { initRelayout2((JTabbedPane)c2); }  b++; }  } protected void initRelayout2(JComponent c) { String n1 = "_layouter"; boolean b = true; if ("_layouter_1".equals(c.getName()) || "_layouter_2".equals(c.getName()) || "_layouter_3".equals(c.getName())) b = false;  if (c.getName().startsWith(n1) && b) { Container c4 = c.getParent(); c4.remove(c); int x = c.getX(); int y = c.getY(); byte b1; int i; Component[] arrayOfComponent; for (i = (arrayOfComponent = c.getComponents()).length, b1 = 0; b1 < i; ) { Component c2 = arrayOfComponent[b1]; int x2 = c2.getX(); int y2 = c2.getY(); c.remove(c2); if (c2 instanceof JScrollPane) { initRelayout4((JScrollPane)c2, c4); } else { if (c4 instanceof JSplitPane) { int x4 = c4.getX(); int y4 = c4.getY(); c2.setLocation(x2 + x4 + x, y2 + y4 + y); Container c5 = getParentPanel(c4); if (c5 != null) { c5.add(c2); } else { c4.getParent().add(c2); }  } else { c2.setLocation(x2 + x, y2 + y); c4.add(c2); }  if (c2 instanceof JPanel) { initRelayout2((JPanel)c2); } else if (c2 instanceof JScrollPane) { initRelayout4((JScrollPane)c2, c4); } else if (c2 instanceof JSplitPane) { initRelayout3((JSplitPane)c2); } else if (c2 instanceof JTabbedPane) { initRelayout2((JTabbedPane)c2); }  }  b1++; }  } else { byte b1; int i; Component[] arrayOfComponent; for (i = (arrayOfComponent = c.getComponents()).length, b1 = 0; b1 < i; ) { Component c3 = arrayOfComponent[b1]; if (c3 instanceof JPanel) { initRelayout2((JPanel)c3); } else if (c3 instanceof JScrollPane) { Container c4 = c.getParent(); initRelayout4((JScrollPane)c3, c4); } else if (c3 instanceof JSplitPane) { initRelayout3((JSplitPane)c3); } else if (c3 instanceof JTabbedPane) { initRelayout2((JTabbedPane)c3); }  b1++; }  }  } protected void initRelayout3(JSplitPane c) { Component left = c.getLeftComponent(); Component right = c.getRightComponent(); if (left instanceof JPanel) initRelayout2((JPanel)left);  if (right instanceof JPanel) initRelayout2((JPanel)right);  c.getParent().remove(c); } protected void initRelayout4(JScrollPane c2, Container c4) { Component c3 = c2.getViewport().getView(); if (c3 == null) return;  if (c3 instanceof MCTable) return;  Container c6 = getParentPanel(c4); if (c6 != null && !c2.getName().endsWith(".scroll")) if (!(c3 instanceof mcframe.clientCore.beans.MCTextArea) && !(c3 instanceof mcframe.clientCore.beans.MCImageView)) { MCRootPanel mCRootPanel; if (c6 == this.panel) this._hasForHeader = true;  if (this._hasForHeader) { c6 = getParentPanel(c2); Container c7 = c2.getParent(); if (c7 != null) c7.remove(c2);  if (c6 == c2) mCRootPanel = this.panel;  }  mCRootPanel.add(c3); }   if (c3 instanceof JPanel) { initRelayout2((JPanel)c3); } else if (c3 instanceof JTabbedPane) { initRelayout2((JTabbedPane)c3); }  } protected Container getParentPanel(Container c) { String n1 = "_layouter"; Container c1 = c.getParent(); while (c1 != null) { if (c1.getName() == null) return c;  if (c1 instanceof MCScrollPane) { c1 = c1.getParent(); continue; }  if (!c1.getName().startsWith(n1)) return c1;  if (c1 instanceof MCPanel) { MCPanel p = (MCPanel)c1; if (p.getLayoutPosition() != null && p.getLayoutPosition().equals("layoutMain")) return c1;  }  c1 = c1.getParent(); }  return c; } private void setInitFlg(MCRootPanel panel, boolean flg) { MCBeansProxy.PROXY.setLayoutInitialized(panel, flg); this._initFlg = flg; } protected final boolean getInitFlg() { return this._initFlg; } protected void removeTabOrder2(MCPanel _headerbar) { MCPanel mCPanel = _headerbar; MCTabOrderBeans prev = mCPanel.getPreviousBeans(); MCTabOrderBeans next = mCPanel.getNextBeans(); if (prev != null) prev.setNextBeans(next);  if (next != null) next.setPreviousBeans(prev);  mCPanel.setNextBeans(null); mCPanel.setPreviousBeans(null); } public void beforeRelayout() {} public void layout() { relayout(false); } protected void relayout(boolean useLayoutLocationForSortPolicy) { if (this.panel.isShowing()) saveDividerLocation(this.panel);  if (!this.panel.isPartsPanel()) if (!(this.panel instanceof mcframe.clientCore.beans.message.MCProgressPanel)) { this._margin_manager = new MCMarginManager(this._root); if (!this.panel.hasMarginManager()) setMargin(new Insets(0, 0, 0, 0));  }   MCAutoLayout autoLayout = new MCAutoLayout(); autoLayout.setupTargetPanel(this.panel); autoLayout.useLayoutLocationForSortPolicy = useLayoutLocationForSortPolicy; if (!getInitFlg()) { this.panel.setLayoutDepth(); this.panel.resetAutoLayoutParameter(); loadResourceForAutoLayout(); loadResourceForLocalize(); this._temp_panel_counter_save = this._temp_panel_counter; MCPanel[] a = MCBeansUtil.getPanels(this.panel); this._rootSub.setLayout(createMCBorderLayout()); this._rootSub.add((Component)this._rootSubMain, "Center"); this._root.setLayout(createMCBorderLayout()); this._root.add((Component)this._rootSub, "Center"); this.panel.setLayout(createMCBorderLayout()); this.panel.add((Component)this._root, "Center"); autoLayout.beforeLayout(false); layout((JPanel)this._rootSubMain, new ArrayList<>(Arrays.asList(a)), 0, false); setPanelLimitWidth(new ArrayList<>(Arrays.asList(a)), autoLayout); addScrollOPaneIntoTabbedPane(this.panel, autoLayout); } else { this._temp_panel_counter = this._temp_panel_counter_save; if (this._headerBar != null && Arrays.<Component>asList(this.panel.getComponents()).contains(this._headerBar)) { removeTabOrder2(this._eastbar); removeTabOrder2(this._westbar); int j = 0; this._headerIndex = (this.panel.getComponents()).length - 1; removeTabOrder2(this._westbar); removeTabOrder2(this._eastbar); byte b1; int k; Component[] arrayOfComponent; for (k = (arrayOfComponent = this.panel.getComponents()).length, b1 = 0; b1 < k; ) { Component co = arrayOfComponent[b1]; if (co == this._headerBar) this._headerIndex = j - 1;  j++; b1++; }  }  this.panel.setDisableLayoutInit(true); autoLayout.beforeLayout(true); if (this.panel.isRelayout()) { this._defaultBoundsMap = new LinkedHashMap<>(1000); MCPanel[] list = (MCPanel[])MCBeansUtil.getAllComponents(MCPanel.class, (Container)this.panel); byte b1; int j; MCPanel[] arrayOfMCPanel1; for (j = (arrayOfMCPanel1 = list).length, b1 = 0; b1 < j; ) { MCPanel p = arrayOfMCPanel1[b1]; this._defaultBoundsMap.put(p.getName(), p.getDefaultRatioBounds()); b1++; }  }  this._hasForHeader = false; initRelayout(this._rootSubMain); List<MCPanel> panels = getAllPanel((Container)this._rootSubMain); List<MCPanel> panels2 = getAllPanel((Container)this.panel); panels.addAll(panels2); layout((JPanel)this._rootSubMain, panels, 0, false); if (this._hasForHeader) { LayoutManager panelLayout = this.panel.getLayout(); if (panelLayout instanceof MCBorderLayout) if (((MCBorderLayout)panelLayout).getLayoutComponent("Center") == null) ((MCBorderLayout)panelLayout).addLayoutComponent((Component)this._root, "Center");   }  if (this.panel.isRelayout()) { MCPanel[] list2 = (MCPanel[])MCBeansUtil.getAllComponents(MCPanel.class, (Container)this.panel); byte b1; int j; MCPanel[] arrayOfMCPanel1; for (j = (arrayOfMCPanel1 = list2).length, b1 = 0; b1 < j; ) { MCPanel p = arrayOfMCPanel1[b1]; if (p.getName().startsWith("_layouter") && p.getDefaultRatioBounds() == null) p.setDefaultRatioSize(this._defaultBoundsMap.get(p.getName()));  b1++; }  this._defaultBoundsMap = null; }  addScrollOPaneIntoTabbedPaneForRelayout(this.panel, autoLayout); this.panel.layoutInit(); this.panel.setDisableLayoutInit(false); }  copySize((Component)this._root, (Component)this._rootSubMain); if (this._rootSubMain.getParent().getParent() == this._root) copySize(this._rootSubMain.getParent(), (Component)this._rootSubMain);  if (this.panel.getBaseRootPanel() == this.panel) { copyPreferredSize((Component)this.panel, (Component)this._root); copyMaximumSize((Component)this.panel, (Component)this._root); copyMinimumSize((Component)this.panel, (Component)this._root); }  byte b; int i; MCRootPanel[] arrayOfMCRootPanel; for (i = (arrayOfMCRootPanel = this.panel.getPartsPanels()).length, b = 0; b < i; ) { MCRootPanel pp = arrayOfMCRootPanel[b]; MCLayout o = pp.getMCLayout(); if (o instanceof MCGeneralLayout) { List<MCPanel> l = ((MCGeneralLayout)o).panelsForZoom(); if (l != null) for (MCPanel p : l) addPanelForZoom(p);   }  b++; }  if (this.panel.getBaseRootPanel() == this.panel) { Dimension d = this._root.getMinimumSize(); this.panel.setPreferredSize(new Dimension(d.width, d.height)); trace("104", (JPanel)this.panel); }  MCFrame f = this.panel.getFrame(); sortPanelForZoom(this.panel); if (!getInitFlg()) if (!this.panel.isPartsPanel()) if (f != null) { Dimension d1 = this.panel.getParent().getParent().getPreferredSize(); Dimension d2 = this.panel.getSize(); Dimension d3 = new Dimension(d2.width, d1.height); this.panel.getParent().getParent().setPreferredSize(d3); f.pack(); }    if (!this.panel.isPartsPanel()) if (!getInitFlg()) { String[][] ids = this.panel.getModuleAndScreenIDs(); if (isAvailable(ids, BarType.HEADERBAR)) if (this.panel.hasHeaderBar()) addHeaderBar();   if (isAvailable(ids, BarType.STATUSBAR)) { if (getInitFlg()) MCBeansUtil.removeStatusBar(this.panel, this);  if (this.panel.hasStatusBar()) MCBeansUtil.addStatusBar(this.panel, this);  }  } else if (this.panel.isRelayout()) { String[][] ids = this.panel.getModuleAndScreenIDs(); if (isAvailable(ids, BarType.HEADERBAR)) updateToolBarTabOrder();  if (isAvailable(ids, BarType.STATUSBAR)) { MCBeansUtil.removeStatusBar(this.panel, this); if (this.panel.hasStatusBar()) MCBeansUtil.addStatusBar(this.panel, this);  }  }   if (this.panel.isShowing()) restoreDividerLocation(this.panel);  autoLayout.afterLayout(); if (this.panel == this.panel.getBaseRootPanel()) tracePosition(this.panel);  setInitFlg(this.panel, true); } protected void updateToolBarTabOrder() {} protected List<MCPanel> getAllPanel(Container p) { List<MCPanel> panels = new ArrayList<>(); _getAllPanel(p, panels); return panels; } protected void _getAllPanel(Container p, List<MCPanel> panels) { byte b; int i; Component[] arrayOfComponent; for (i = (arrayOfComponent = p.getComponents()).length, b = 0; b < i; ) { Component c = arrayOfComponent[b]; if (!c.getName().equals("_headerbar")) if (!c.getName().startsWith("_layouter_")) if (c instanceof MCPanel) panels.add((MCPanel)c);    b++; }  } private boolean isAvailable(String[][] ids, BarType typ) { byte b; int i; String[][] arrayOfString; for (i = (arrayOfString = ids).length, b = 0; b < i; ) { String[] id = arrayOfString[b]; String k = MCConst.createKey(new String[] { id[0], id[1], typ.getResourceString() }); String s = MCConst.beans.getString(k); if (s != null) return Boolean.valueOf(s).booleanValue();  b++; }  return true; } private void addHeaderBar() { if (!this.panel.isPartsPanel() && !this.panel.isPartsFlag() && !(this.panel instanceof mcframe.clientCore.beans.message.MCProgressPanel)) if (!MCConst.screen.getBoolean(MCConst.createKey(new String[] { this.panel.getModuleID(), this.panel.getScreenID(), "parts" }, ), false)) { this._headerBar = new MCPanel("_headerbar") { Color _b = MCConst.beans.getColor("headerbar.bg"); Color _f = MCConst.beans.getColor("headerbar.fg"); public Color getBackground() { return this._b; } public Color getForeground() { return this._f; } }
/*      */           ; this._headerBar.setLayout(new BorderLayout()); this._headerBar.setPreferredSize(null); this._headerBar.setOpaque(true); this._headerBar.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2)); this._westbar = createHeaderBarWest(); this._headerBar.add((Component)this._westbar, "West"); addToHeaderBarTabOrder(this._westbar); if (canUseMenuModelInHeaderBar()) { this._eastbar = createHeaderBarEast(); this._headerBar.add((Component)this._eastbar, "East"); addToHeaderBarTabOrder(this._eastbar); }  if (getInitFlg()) { this.panel.add((Component)this._headerBar, "North", this._headerIndex); } else { this.panel.add((Component)this._headerBar, "North"); MCFrame f2 = this.panel.getFrame(); MCBeansProxy.PROXY.convFrameHeight(f2, (JComponent)this._headerBar, null); }  }   } protected void addToHeaderBarTabOrder(MCPanel p) { List<MCTabOrderBeans> tabList = this.panel.getTabOrderBeans(); if (tabList != null && tabList.size() > 0) this.panel.setLastBeans((MCTabOrderBeans)p);  } private final void menuActive() { MCRootPanel p = MCBeansUtil.getRootPanel(MCConst.menu.getMenuModuleID(), MCConst.menu.getMenuScreenID()); if (p != null) p.moveToFront();  } protected MCPanel createHeaderBarWest() { MCHeaderBarPanel westbar = new MCHeaderBarPanel(String.valueOf(this._headerBar.getName()) + "_west"); westbar.setHeaderBar(true); westbar.setOpaque(false); westbar.setBorder(BorderFactory.createEmptyBorder()); westbar.setLayout(new BoxLayout((Container)westbar, 2)); westbar.setPreferredSize(null); MCRootPanel bp = this.panel.getBaseRootPanel(); Integer ratio = Integer.valueOf(bp.getLayoutRatio()); westbar.add(bp._createRigidArea(this._margin_manager._margin.left, 5, ratio.intValue(), null)); MCButton mCButton = getXATitle(); westbar.add((Component)mCButton); boolean isMainMenu = (MCConst.menu.getMenuModuleID().equals(bp.getModuleID()) && MCConst.menu.getMenuScreenID().equals(bp.getScreenID())); if (!isMainMenu && mCButton instanceof MCButton) { MCButton xab = mCButton; if (canUseMenuModelInHeaderBar() && !(this.panel.getFrame() instanceof mcframe.clientCore.beans.MCModalFrame)) { xab.setMode(MCMode.ENABLE); xab.addAPListener((c, i) -> SwingUtilities.invokeLater(())); setBarTabOrder(westbar, (MCTabOrderBeans)xab); }  }  return westbar; } public MCPanel getHeaderBarWest() { if (this._headerBar != null) { byte b; int i; Component[] arrayOfComponent; for (i = (arrayOfComponent = this._headerBar.getComponents()).length, b = 0; b < i; ) { Component co = arrayOfComponent[b]; if (co instanceof MCPanel && co.getName().startsWith("_headerbar_west")) return (MCPanel)co;  b++; }  }  return null; } public MCPanel getHeaderBarEast() { if (this._headerBar != null) { byte b; int i; Component[] arrayOfComponent; for (i = (arrayOfComponent = this._headerBar.getComponents()).length, b = 0; b < i; ) { Component co = arrayOfComponent[b]; if (co instanceof MCPanel && co.getName().startsWith("_headerbar_east")) return (MCPanel)co;  b++; }  }  return null; } private static class PushIconSupplier implements MCIconSupplier {
/*      */     private final String _push_signal_typ; public PushIconSupplier(String push_signal_typ) { this._push_signal_typ = push_signal_typ; } public ImageIcon createIcon(Image i) { return new ImageIcon(i) { private Image _defimg; private Image _defgrayimg; public synchronized void paintIcon(Component c, Graphics g, int x, int y) { if (this._defimg == null) this._defimg = getImage();  boolean glayicon = false; String str; switch ((str = MCGeneralLayout.PushIconSupplier.this._push_signal_typ).hashCode()) { case 1484442864: if (!str.equals("_hbar_e")) break;  if (MCBeansProxy.PROXY.getUnreadPushCountE() <= 0) glayicon = true;  break;case 1484442868: if (!str.equals("_hbar_i")) break;  if (MCBeansProxy.PROXY.getUnreadPushCountI() <= 0) glayicon = true;  break; }  if (glayicon) { if (this._defgrayimg == null) this._defgrayimg = Toolkit.getDefaultToolkit().createImage(MCGraphicsUtil.createMonoIconFilltered(this._defimg));  if (getImage() != this._defgrayimg) setImage(this._defgrayimg);  } else if (getImage() != this._defimg) { setImage(this._defimg); }  super.paintIcon(c, g, x, y); } }
/*      */         ; } } protected MCPanel createHeaderBarEast() { MCMenuItemModel root = MCMenuModel.defultModel().getRootModel(); MCMenuItemModel lo = root.childModel("LOGOUT", true); MCMenuItemModel si = root.childModel("SYSTEM_EXIT", true); MCMenuItemModel co = root.childModel("EXTATTR_CHANGE", true); MCMenuItemModel mod = root.childModel("MOD_SELECT", true); MCMenuItemModel close = root.childModel("CLOSEALL", true); MCMenuItemModel ver = root.childModel("FSBEP0040", true); MCMenuItemModel conf = root.childModel("FSBBP0010", true); MCMenuItemModel pushscr = root.childModel("FSBGP0120", true); MCHeaderBarPanel eastbar = new MCHeaderBarPanel(String.valueOf(this._headerBar.getName()) + "_east"); eastbar.setHeaderBar(true); eastbar.setOpaque(false); eastbar.setBorder(BorderFactory.createEmptyBorder()); eastbar.setLayout(new BoxLayout((Container)eastbar, 2)); eastbar.setPreferredSize(null); if (pushscr != null && isPushBtnAvailable()) { addPushToEastbar(eastbar, "_hbar_e", MCBeansProxy.PROXY.getUnreadPushCountE(), "icon.PUSH_E", pushscr); addPushToEastbar(eastbar, "_hbar_i", MCBeansProxy.PROXY.getUnreadPushCountI(), "icon.PUSH_I", pushscr); eastbar.add(Box.createHorizontalStrut(10)); }  if (ver != null || conf != null) { MCButton l = createHeaderButton("_conf"); l.setIcon("HBAR_CONF"); if (this.panel.getFrame() instanceof mcframe.clientCore.beans.MCModalFrame) { l.setDisabledIcon(l.getIcon()); l.setMode(MCMode.READ_ONLY); }  if (MCMode.isEnable((MCModeBeans)l)) { MCPopupMenu popupMenu = l.getComponentPopupMenu(); addMenuItm(l, popupMenu, ver, null); addMenuItm(l, popupMenu, conf, null); l.addAPListener((c, i) -> (new MCPopupAction(null)).showPopup((JComponent)paramMCButton)); }  eastbar.add((Component)l); setBarTabOrder(eastbar, (MCTabOrderBeans)l); }  if (lo != null || si != null || co != null || mod != null || close != null) { MCButton l = createHeaderButton("_exit"); MCBinary img = MCSys.user.image(); if (img == null) { ImageIcon ii = (ImageIcon)MCBeansUtil.get((MCResourceBeans)l, "HBAR_USER"); BufferedImage bi = createBufferedImage(ii.getImage()); ImageIcon i = new ImageIcon(getRoundImage(bi)); l.setIcon(i); } else { ImageIcon i = new ImageIcon(getRoundImage(img)); int xh = getXATitle().getIcon().getIconHeight(); if (i.getIconHeight() != xh) { MCBeansUtil.adjustIconSize(i, new Dimension(xh, xh)); l.setIcon(i); }  }  Icon oi = l.getIcon(); if (oi instanceof ImageIcon) { ImageIcon i = (ImageIcon)oi; int h = (this._headerBar.getPreferredSize()).height - (this._headerBar.getInsets()).top - (this._headerBar.getInsets()).bottom; if (h == 0) h = 1;  i.setImage(i.getImage().getScaledInstance(h, h, 16)); }  if (this.panel.getFrame() instanceof mcframe.clientCore.beans.MCModalFrame) { l.setDisabledIcon(l.getIcon()); l.setMode(MCMode.READ_ONLY); }  l.setFunctionKey(MCActionProxy.PROXY.getF10()); l.setText(MCSys.user.name()); int fm = MCConst.beans.getInteger("headerbar.user.fonts_minus", 0); if (fm != 0) { Font f = l.getFont(); l.setFont(f.deriveFont(f.getSize2D() - fm)); }  l.setForeground(Color.white); if (MCMode.isEnable((MCModeBeans)l)) { MCPopupMenu popupMenu = l.getComponentPopupMenu(); addMenuItm(l, popupMenu, close, null); addMenuItm(l, popupMenu, co, null); addMenuItm(l, popupMenu, mod, null); addMenuItm(l, popupMenu, lo, null); addMenuItm(l, popupMenu, si, null); l.addAPListener((c, i) -> (new MCPopupAction(null)).showPopup((JComponent)paramMCButton)); }  eastbar.add((Component)l); setBarTabOrder(eastbar, (MCTabOrderBeans)l); }  MCRootPanel bp = this.panel.getBaseRootPanel(); Integer ratio = Integer.valueOf(bp.getLayoutRatio()); eastbar.add(bp._createRigidArea(this._margin_manager._margin.right, 5, ratio.intValue(), null)); return eastbar; } private BufferedImage createBufferedImage(Image img) { BufferedImage bi = new BufferedImage(img.getWidth(null), img.getHeight(null), 3); Graphics2D gr = bi.createGraphics(); gr.drawImage(img, 0, 0, (ImageObserver)null); gr.dispose(); return bi; } private Image getRoundImage(MCBinary img) { BufferedImage bi = null; try { bi = ImageIO.read(MCDownloader.getBinaryURL(img)); return getRoundImage(bi); } catch (Exception e) { throw new MCException(e); }  } private Image getRoundImage(BufferedImage bi) { BufferedImage bi2 = new BufferedImage(bi.getWidth(), bi.getHeight(), 2); Graphics2D gr = bi2.createGraphics(); Ellipse2D rr = new Ellipse2D.Double(0.0D, 0.0D, bi.getWidth(), bi.getHeight()); gr.fill(rr); gr.setComposite(AlphaComposite.SrcIn); gr.drawImage(bi, 0, 0, (ImageObserver)null); gr.dispose(); return bi2; } private boolean isPushBtnAvailable() { return !("FS".equals(this.panel.getModuleID()) && "FSBGP0120".equals(this.panel.getScreenID())); } private void addPushToEastbar(MCPanel eastbar, String pushtyp, int cnt, String pushtypRes, MCMenuItemModel pushscr) { MCButton i = createHeaderButton(pushtyp); setPushIcon(i, pushtyp, pushtypRes); i.setMCBorder(new EmptyBorder(0, 0, 0, 0)); i.addActionListener(a -> execMenuAction(paramMCButton, a, paramMCMenuItemModel)); eastbar.add((Component)i); setBarTabOrder(eastbar, (MCTabOrderBeans)i); repaintPushCntImpl(i, cnt); } private void setPushIcon(MCButton b, String signalTyp, String signalTypRes) { PushIconSupplier eisup = new PushIconSupplier(signalTyp); ImageIcon icon = MCBeansUtil.getIcon((MCResourceBeans)b, eisup, new String[] { signalTypRes }); b.setIconSupplier(eisup); b.setIcon(icon); } private void execMenuAction(MCButton b, ActionEvent e, MCMenuItemModel im) { if (b.isEnabled()) (new MCMenuItemListener(null, im)).actionPerformed(e);  } void repaintPushCnt() { if (this._headerBar == null) return;  MCButton[] ls = (MCButton[])MCBeansUtil.getAllComponents(MCButton.class, (Container)this._headerBar); byte b; int i; MCButton[] arrayOfMCButton1; for (i = (arrayOfMCButton1 = ls).length, b = 0; b < i; ) { MCButton l = arrayOfMCButton1[b]; if ("_hbar_e".equals(l.getName())) { repaintPushCntImpl(l, MCBeansProxy.PROXY.getUnreadPushCountE()); } else if ("_hbar_i".equals(l.getName())) { repaintPushCntImpl(l, MCBeansProxy.PROXY.getUnreadPushCountI()); }  b++; }  } private void repaintPushCntImpl(MCButton b, int cnt) { b.setText(String.valueOf(cnt)); b.setVisible((cnt > 0)); } private class MCPopupAction extends MCKeyAction {
/*  840 */     private MCPopupAction() {} protected void showPopup(JComponent compo) { super.showPopup(compo); } } public static MCButton createHeaderButton(String name) { MCButton b = MCBeansCompatibilityFactory.createButton(name, "headerbar"); b.setMaximumSize(new Dimension(32767, 32767)); b.setContentAreaFilled(false); return b; } protected void setBarTabOrder(MCPanel eastbar, MCTabOrderBeans l) { if (eastbar.getFirstBeans() == null) { eastbar.setFirstBeans(l); } else { MCTabOrderBeans last = eastbar.getLastBeans(); last.setNextBeans(l); }  } private void addMenuItm(MCButton b, MCPopupMenu m, MCMenuItemModel im, Icon i) { if (im != null) { MCMenuItem mi = new MCMenuItem(); mi.menuItemModel(im); final MCMenuItemListener mil = new MCMenuItemListener(null, im); mi.addActionListener((ActionListener)mil); mi.setHorizontalTextPosition(10); if (i != null) mi.setIcon(i);  m.add((JMenuItem)mi); KeyStroke ks = mi.getKeyStroke(); if (ks != null) { InputMap inpt = b.getInputMap(2); ActionMap a = b.getActionMap(); String k = ks.toString(); if (inpt.get(ks) == null) { inpt.put(ks, k); a.put(k, new AbstractAction() { public void actionPerformed(ActionEvent e) { mil.actionPerformed(e); } }); }  }  }  } protected void copySize(Component dest, Component src) { Dimension d = src.getSize(); dest.setSize(new Dimension(d.width, d.height)); copyPreferredSize(dest, src); copyMaximumSize(dest, src); copyMinimumSize(dest, src); } private void copyPreferredSize(Component dest, Component src) { Dimension d = src.getPreferredSize(); dest.setPreferredSize(new Dimension(d.width, d.height)); } private void copyMaximumSize(Component dest, Component src) { Dimension d = src.getMaximumSize(); dest.setMaximumSize(new Dimension(d.width, d.height)); } private void copyMinimumSize(Component dest, Component src) { Dimension d = src.getMinimumSize(); dest.setMinimumSize(new Dimension(d.width, d.height)); } protected void layout(JPanel panel, List<MCPanel> panels, int depth, boolean isRecursiveLayout) { Map<String, List<MCPanel>> m = new HashMap<>(); for (Container p : panels) { if (p instanceof MCPanel) { String lp = getLayoutPosition((MCPanel)p, depth, depth + 1); String k = toBLPositionStr(lp); if (k == null) throw new MCException(Core_Msg_FW_A.FCBAC0321, new Object[] { lp, Integer.valueOf(depth), p.getName() });  List<MCPanel> l = m.get(k); if (l == null) { l = new ArrayList<>(); m.put(k, l); }  l.add((MCPanel)p); }  }  List<JPanel> list = layoutByGeneralLayouter(panel, m, depth, isRecursiveLayout); checkOvelapPanels(list); } protected void setDefaultSize(Component p, Rectangle r) { setDefaultSize(p, r.getSize()); } public MCGeneralLayout(MCRootPanel panel) { this._XATitle = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1076 */     this._initFlg = false;
/*      */     
/* 1078 */     this._headerIndex = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1133 */     this._defaultBoundsMap = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2918 */     this.isSupportBasePanel = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5490 */     this._panelHeightMap = null;
/* 5491 */     this._invalidPanelList = null;
/* 5492 */     this._frameOffsetH = Integer.valueOf(0); this.panel = panel; }
/*      */   protected void setDefaultSize(Component p, Dimension dim) { MCAutoLayout autoLayout = new MCAutoLayout(); autoLayout.setupTargetPanel(this.panel); autoLayout._setDefaultLocation(p, p.getLocation(), dim); }
/*      */   protected Rectangle _getBounds(Component comp) { return comp.getBounds(); }
/*      */   protected void checkOvelapPanels(List<JPanel> panels) { boolean f = true; while (f) { f = false; for (int n = 1; n < panels.size(); n++) { JPanel p1 = panels.get(n - 1); JPanel p2 = panels.get(n); if (p2 instanceof MCPanel) { Rectangle r1 = p1.getBounds(); Rectangle r2 = p2.getBounds(); if (r1.getY() != r2.getY() && r1.intersects(r2)) { int d = r1.y + r1.height - r2.y; p2.setLocation(p2.getX(), p2.getY() + d); setDefaultSize(p2, r2.getSize()); f = true; break; }  }  }  }  } protected class ContainerComparator implements Comparator<Container> {
/* 5496 */     public int compare(Container p1, Container p2) { if (p1.getY() < p2.getY()) return -1;  if (p1.getY() > p2.getY()) return 1;  if (p1.getX() < p2.getX()) return -1;  if (p1.getX() > p2.getX()) return 1;  return 0; } } private boolean isLayoutSplitPane(Map<String, List<MCPanel>> map) { String[] a = (String[])map.keySet().toArray((Object[])new String[map.size()]); byte b; int i; String[] arrayOfString1; for (i = (arrayOfString1 = a).length, b = 0; b < i; ) { String s = arrayOfString1[b]; if ("SPLIT_L".equals(s) || "SPLIT_R".equals(s) || "SPLIT_T".equals(s) || "SPLIT_B".equals(s)) return true;  b++; }  return false; } private void throwLayoutPositionEx(String id, List<MCPanel> list, int depth) { if (list.size() > 0) { MCPanel p = list.get(0); throw new MCException(id, new Object[] { p.getName(), p.getLayoutPosition(), Integer.valueOf(depth) }); }  } private void checkSplitPaneLayoutPosition(Map<String, List<MCPanel>> map, int depth) { if (map.containsKey("SPLIT_L")) { if (map.containsKey("SPLIT_R")) { for (Map.Entry<String, List<MCPanel>> e : map.entrySet()) { String k = e.getKey(); if (!"SPLIT_L".equals(k) && !"SPLIT_R".equals(k)) throwLayoutPositionEx(Core_Msg_FW_A.FCBAC0309, e.getValue(), depth);  }  } else { throwLayoutPositionEx(Core_Msg_FW_A.FCBAC0310, map.get("SPLIT_L"), depth); }  } else if (map.containsKey("SPLIT_R")) { throwLayoutPositionEx(Core_Msg_FW_A.FCBAC0311, map.get("SPLIT_R"), depth); } else if (map.containsKey("SPLIT_T")) { if (map.containsKey("SPLIT_B")) { for (Map.Entry<String, List<MCPanel>> e : map.entrySet()) { String k = e.getKey(); if (!"SPLIT_T".equals(k) && !"SPLIT_B".equals(k)) throwLayoutPositionEx(Core_Msg_FW_A.FCBAC0309, e.getValue(), depth);  }  } else { throwLayoutPositionEx(Core_Msg_FW_A.FCBAC0312, map.get("SPLIT_T"), depth); }  } else if (map.containsKey("SPLIT_B")) { throwLayoutPositionEx(Core_Msg_FW_A.FCBAC0313, map.get("SPLIT_B"), depth); }  } private JPanel layoutSplitPane(JPanel panel, Map<String, List<MCPanel>> map, int depth, boolean isRecursiveLayout) { if (map.containsKey("SPLIT_L")) return layoutHorizontalSplitPane(panel, map, depth, isRecursiveLayout);  return layoutVerticalSplitPane(panel, map, depth, isRecursiveLayout); } private JPanel layoutVerticalSplitPane(JPanel _panel, Map<String, List<MCPanel>> map, int depth, boolean isRecursiveLayout) { MCPanel top = createTempPanel("SPP_T"); top.setLayout(createMCBorderLayout()); JPanel topRet = layoutSub((JPanel)top, "Center", map.get("SPLIT_T"), depth, isRecursiveLayout); MCPanel bottom = createTempPanel("SPP_B"); bottom.setLayout(createMCBorderLayout()); JPanel bottomRet = layoutSub((JPanel)bottom, "Center", map.get("SPLIT_B"), depth, isRecursiveLayout); MCSplitPane sp = createMCSplitPane(top, bottom); sp.setLocation(0, 0); sp.setOrientation(0); top.setMinimumSize(new Dimension(minWidth(topRet), 0)); bottom.setMinimumSize(new Dimension(minWidth(bottomRet), 0)); sp.setTopComponent((Component)top); sp.setBottomComponent((Component)bottom); sp.setPreferredSize(new Dimension(max(new int[] { prefWidth((JPanel)top), prefWidth((JPanel)bottom) }, ), prefHeight((JPanel)top) + prefHeight((JPanel)bottom))); sp.setMinimumSize(new Dimension(max(new int[] { minWidth((JPanel)top), minWidth((JPanel)bottom) }, ), minHeight((JPanel)top) + minHeight((JPanel)bottom))); if (!this.panel.isRelayout()) { int n = prefHeight((JPanel)top) + (sp.getInsets()).top; sp.setDividerLocationWithRatio(n); }  _panel.setLayout(createMCBorderLayout()); _panel.add((Component)sp, "Center"); _panel.add((Component)sp); return _panel; } private JPanel layoutHorizontalSplitPane(JPanel panel, Map<String, List<MCPanel>> map, int depth, boolean layoutHorizontalSplitPane) { MCPanel left = createTempPanel("SPP_L"); left.setLayout(createMCBorderLayout()); JPanel leftRet = layoutSub((JPanel)left, "Center", map.get("SPLIT_L"), depth, layoutHorizontalSplitPane); MCPanel right = createTempPanel("SPP_R"); right.setLayout(createMCBorderLayout()); JPanel rightRet = layoutSub((JPanel)right, "Center", map.get("SPLIT_R"), depth, layoutHorizontalSplitPane); MCSplitPane sp = createMCSplitPane(left, right); sp.setLocation(0, 0); sp.setOrientation(1); left.setMinimumSize(new Dimension(10, minHeight(leftRet))); right.setMinimumSize(new Dimension(10, minHeight(rightRet))); sp.setLeftComponent((Component)left); sp.setRightComponent((Component)right); sp.setPreferredSize(new Dimension(prefWidth((JPanel)left) + prefWidth((JPanel)right), max(new int[] { prefHeight((JPanel)left), prefHeight((JPanel)right) }))); sp.setMinimumSize(new Dimension(minWidth((JPanel)left) + minWidth((JPanel)right), max(new int[] { minHeight((JPanel)left), minHeight((JPanel)right) }))); sp.setDividerLocationWithRatio(prefWidth(leftRet) + (sp.getInsets()).left); panel.setLayout(createMCBorderLayout()); panel.add((Component)sp, "Center"); return panel; } private MCSplitPane createMCSplitPane(MCPanel p1, MCPanel p2) { return MCBeansCompatibilityFactory.createSplitPane(getSplitPaneName(new JPanel[] { (JPanel)p1, (JPanel)p2 })); } protected List<JPanel> layoutByGeneralLayouter(JPanel panel, Map<String, List<MCPanel>> map, int depth, boolean isRecursiveLayout) { List<JPanel> list = new ArrayList<>(); if (isLayoutSplitPane(map)) { checkSplitPaneLayoutPosition(map, depth); list.add(layoutSplitPane(panel, map, depth, isRecursiveLayout)); return list; }  panel.setLayout(createMCBorderLayout()); JPanel np = null; JPanel cp = null; JPanel sp = null; JPanel ep = null; JPanel wp = null; JPanel bxp = null; for (Map.Entry<String, List<MCPanel>> e : map.entrySet()) { String k = e.getKey(); JPanel s = layoutSub(panel, k, e.getValue(), depth, isRecursiveLayout); if ("North".equals(k)) { np = s; } else if ("South".equals(k)) { sp = s; } else if ("Center".equals(k)) { cp = s; } else if ("East".equals(k)) { ep = s; } else if ("West".equals(k)) { wp = s; } else if ("BOX_X".equals(k)) { bxp = s; } else { np = s; }  list.add(s); }  int pw = max(new int[] { prefWidth(np), prefWidth(sp), prefWidth(wp) + prefWidth(ep) + prefWidth(cp) }); pw += prefWidth(bxp); int mw = max(new int[] { minWidth(np), minWidth(sp), prefWidth(wp) + prefWidth(ep) + minWidth(cp) }); mw += minWidth(bxp); int ph = prefHeight(np) + prefHeight(sp) + max(new int[] { prefHeight(ep), prefHeight(wp), prefHeight(cp) }); ph = max(new int[] { ph, prefHeight(bxp) }); int mh = prefHeight(np) + prefHeight(sp) + max(new int[] { minHeight(ep), minHeight(wp), minHeight(cp) }); mh = max(new int[] { mh, minHeight(bxp) }); Border b = panel.getBorder(); if (b != null) { Insets i = b.getBorderInsets(panel); pw += i.right + i.left; ph += i.top + i.bottom; mw += i.right + i.left; mh += i.top + i.bottom; }  panel.setSize(new Dimension(pw, ph)); panel.setPreferredSize(new Dimension(pw, ph)); panel.setMinimumSize(new Dimension(mw, mh)); if (panel instanceof MCPanel && ((MCPanel)panel).getDefaultBounds() != null) { Rectangle r1 = ((MCPanel)panel).getDefaultBounds(); int n = this.panel.getLayoutRatio(); if (n == 100) { Rectangle r2 = new Rectangle(r1.x, r1.y, pw, ph); ((MCPanel)panel).setDefaultRatioSize(r2); } else { Rectangle r3 = new Rectangle(r1.x, r1.y, pw * 100 / n, ph * 100 / n); ((MCPanel)panel).setDefaultRatioSize(r3); }  }  trace("228", panel); return list; } private String getSplitPaneName(JPanel... panels) { List<String> l = new ArrayList<>(); byte b; int i; JPanel[] arrayOfJPanel; for (i = (arrayOfJPanel = panels).length, b = 0; b < i; ) { JPanel p = arrayOfJPanel[b]; l.add(p.getName()); b++; }  String[] a = l.<String>toArray(new String[l.size()]); return MCStringUtil.join("_", a); } protected Dimension calcMinDimX_AXIS(JPanel p1, JPanel p2) { int w = minWidth(p1) + minWidth(p2); int h = max(new int[] { minHeight(p1), minHeight(p2) }); return new Dimension(w, h); } protected Dimension calcPrefDimX_AXIS(JPanel p1, JPanel p2) { int w = prefWidth(p1) + prefWidth(p2); int h = max(new int[] { prefHeight(p1), prefHeight(p2) }); return new Dimension(w, h); } protected int minHeight(JPanel panel) { return (panel == null) ? 0 : (panel.getMinimumSize()).height; } protected int maxHeight(JPanel panel) { return (panel == null) ? 0 : (panel.getMaximumSize()).height; } protected int prefHeight(JPanel panel) { return (panel == null) ? 0 : (panel.getPreferredSize()).height; } protected int minWidth(JPanel panel) { return (panel == null) ? 0 : (panel.getMinimumSize()).width; } protected int maxWidth(JPanel panel) { return (panel == null) ? 0 : (panel.getMaximumSize()).width; } protected int prefWidth(JPanel panel) { return (panel == null) ? 0 : (panel.getPreferredSize()).width; } private boolean _hasTablePanel(Container comp) { if (comp == null) return false;  if ((comp.getComponents()).length == 1 && comp.getComponents()[0] instanceof MCScrollPane) { MCScrollPane sc = (MCScrollPane)comp.getComponents()[0]; Component c = sc.getViewport().getView(); if (c instanceof MCTable) return true;  }  return false; } protected int max(int... nums) { if (nums == null || nums.length == 0) return 0;  Arrays.sort(nums); return nums[nums.length - 1]; } protected JPanel layoutSub(JPanel _panel, String position, List<MCPanel> panels, int depth, boolean isRecursiveLayout) { if (panels == null || panels.size() == 0) return null;  if (panels.size() == 1) { MCPanel p = panels.get(0); if (this.panel.isRelayout()) p.setPreferredSize(new Dimension(p.getSize()));  add(_panel, p, position); return (JPanel)p; }  List<MCPanel> panels2 = new ArrayList<>(); panels2.addAll(panels); Collections.sort(panels2, new ContainerComparator()); MCPanel ans = null; String lp = getLayoutPosition(panels2.get(0), 0, depth + 1); MCPanel byp = createTempPanel(lp); int ph = 0; int pw = 0; int mh = 0; int mw = 0; byp.setLayout(new BoxLayout((Container)byp, 1)); List<MCPanel> deeper = null; List<MCPanel> boxX = null; for (MCPanel p : panels2) { String[] a = getLayoutPositionArray(p); if (a != null && a.length > depth + 1) { String pos = toBLPositionStr(getLayoutPosition(p, depth + 1, depth + 2)); if ("BOX_X".equals(pos)) { if (boxX == null) boxX = new ArrayList<>();  boxX.add(p); continue; }  if (deeper == null) deeper = new ArrayList<>();  if (!p.isVisible()) { if ("SPLIT_T".equals(pos) || "SPLIT_B".equals(pos) || "SPLIT_L".equals(pos) || "SPLIT_R".equals(pos)) { p.setSize(0, 0); deeper.add(p); }  continue; }  deeper.add(p); continue; }  add((JPanel)byp, p, null); if (p.isVisible()) { pw = max(new int[] { pw, prefWidth((JPanel)p) }); ph += prefHeight((JPanel)p); mw = max(new int[] { mw, minWidth((JPanel)p) }); mh += minHeight((JPanel)p); }  }  if (deeper != null) { MCPanel p = createTempPanel(lp); layout((JPanel)p, deeper, depth + 1, isRecursiveLayout); add((JPanel)byp, p, null); pw = max(new int[] { pw, prefWidth((JPanel)p) }); ph += prefHeight((JPanel)p); mw = max(new int[] { mw, minWidth((JPanel)p) }); mh += minHeight((JPanel)p); }  byp.setSize(new Dimension(pw, ph)); byp.setPreferredSize(new Dimension(pw, ph)); byp.setMinimumSize(new Dimension(mw, mh)); trace("337", (JPanel)byp); ans = byp; if (boxX != null) { MCPanel bxp = createTempPanel(lp); bxp.setLayout(new BoxLayout((Container)bxp, 0)); add((JPanel)bxp, byp, "BOX_X"); MCPanel brp = createTempPanel(lp); layout((JPanel)brp, boxX, depth + 2, isRecursiveLayout); Dimension ps = calcPrefDimX_AXIS((JPanel)byp, (JPanel)brp); Dimension ms = calcMinDimX_AXIS((JPanel)byp, (JPanel)brp); add((JPanel)bxp, brp, "BOX_X"); bxp.setSize(new Dimension(ps.width, ps.height)); bxp.setPreferredSize(new Dimension(ps.width, ps.height)); bxp.setMinimumSize(new Dimension(ms.width, ms.height)); ans = bxp; }  add(_panel, ans, position); return (JPanel)ans; } protected boolean isNeedsRecursiveLayout(MCPanel panel) { if (this.isSupportBasePanel && panel.getName().endsWith(".base")) return true;  String p = panel.getLayoutPosition(); return (p != null) ? p.endsWith("+") : false; } protected void callRecursiveLayout(MCPanel panel, boolean useTabbedPane) { Component[] a = panel.getComponents(); List<MCRootPanel> rl = new ArrayList<>(); List<MCPanel> pl = new ArrayList<>(); byte b; int i; Component[] arrayOfComponent1; for (i = (arrayOfComponent1 = a).length, b = 0; b < i; ) { Component c = arrayOfComponent1[b]; if (c instanceof MCRootPanel) { rl.add((MCRootPanel)c); } else if (c instanceof MCPanel) { pl.add((MCPanel)c); } else if (c instanceof MCScrollPane) { Component c2 = ((MCScrollPane)c).getViewport().getView(); if (c2 instanceof MCPanel) { callRecursiveLayout((MCPanel)c2, useTabbedPane); } else if (c2 instanceof MCTabbedPane) { callRecursiveLayoutTab(panel, (MCTabbedPane)c2, useTabbedPane, a); }  if (c instanceof MCScrollPane && "Fold.scroll".equals(c.getName())) { Dimension dim = new Dimension((c.getSize()).width, (c2.getSize()).height); c.setSize(dim); c.getParent().setSize(dim); }  } else if (c instanceof MCTabbedPane) { callRecursiveLayoutTab(panel, (MCTabbedPane)c, useTabbedPane, a); } else if (!useTabbedPane) { throw new MCException(Core_Msg_FW_A.FCBAC0318, new Object[] { panel.getName(), c.getClass().getName() }); }  b++; }  if (rl.size() == a.length) { callRecursiveLayoutForPartsPanel(panel, rl); } else if (pl.size() == a.length) { callRecursiveLayoutForMCPanel(panel, pl); }  } protected void callRecursiveLayoutTab(MCPanel p, MCTabbedPane tp, boolean useTabbedPane, Component[] a) { Component[] a1 = tp.getComponents(); int h1 = 0; byte b; int i; Component[] arrayOfComponent1; for (i = (arrayOfComponent1 = a1).length, b = 0; b < i; ) { Component c1 = arrayOfComponent1[b]; h1 = Math.max(h1, c1.getHeight()); b++; }  int h2 = 0; Component[] arrayOfComponent2; for (int j = (arrayOfComponent2 = a1).length; i < j; ) { Component c2 = arrayOfComponent2[i]; if (c2 instanceof MCPanel) callRecursiveLayout((MCPanel)c2, true);  h2 = Math.max(h2, c2.getHeight()); i++; }  int h5 = 0; Insets insets = tp.getDefaultContentBorderInsets(); h5 = insets.top + insets.bottom; int d = h2 - h1 + h5; if (d != 0) { Dimension dim = new Dimension(tp.getWidth(), tp.getHeight() + d); tp.setSize(dim); tp.setPreferredSize(dim); setDefaultSize((Component)tp, dim); Container c2 = tp.getParent(); if (c2 instanceof MCPanel) { MCPanel p1 = (MCPanel)c2; if ((p1.getComponents()).length == 1) { Dimension dim2 = new Dimension(p1.getWidth(), p1.getHeight() + d); p1.setSize(dim2); p1.setPreferredSize(dim2); setDefaultSize((Component)p1, dim2); }  }  }  if (a.length == 1 && p.getLayoutPosition() != null && !p.getLayoutPosition().equals("")) { MCBorderLayout bl; String str; switch ((str = p.getLayoutPosition()).hashCode()) { case 67: if (!str.equals("C")) break;  bl = createMCBorderLayout(); p.setLayout(bl); bl.addLayoutComponent((Component)tp, "Center"); break; }  }  } protected void callRecursiveLayoutForPartsPanel(MCPanel panel, List<MCRootPanel> panels) { if (panels == null || panels.size() == 0) return;  if (panels.size() == 1) { setResizable(panel, (Container)panels.get(0)); } else { throw new MCException(Core_Msg_FW_A.FCBAC0320, new Object[] { panel.getName() }); }  } protected void callRecursiveLayoutForMCPanel(MCPanel panel, List<MCPanel> panels) { if (panels == null || panels.size() == 0) return;  layout((JPanel)panel, panels, 0, true); } private MCScrollPane getScrollPane(MCPanel panel) { Component[] a = panel.getComponents(); if (a.length == 1 && a[0] instanceof MCScrollPane) return (MCScrollPane)a[0];  return null; } private void panelAdded(MCPanel panel, MCScrollPane pane) { setResizable(panel, (Container)pane); } private MCTabbedPane getTabbedPane(MCPanel panel) { Component[] a = panel.getComponents(); if (a.length == 1 && a[0] instanceof MCTabbedPane) return (MCTabbedPane)a[0];  return null; } private void panelAdded(MCPanel panel, MCTabbedPane pane) { int ph = (pane.getPreferredSize()).height; int pw = (pane.getPreferredSize()).width; byte b; int i; Component[] arrayOfComponent; for (i = (arrayOfComponent = pane.getComponents()).length, b = 0; b < i; ) { Component c = arrayOfComponent[b]; if (c instanceof MCPanel) { MCPanel p = (MCPanel)c; Component[] a = p.getComponents(); if (a.length == 1 && a[0] instanceof MCScrollPane) { setResizable(p, (Container)a[0]); } else if (isNeedsRecursiveLayout(p)) { callRecursiveLayout(p, true); }  ph = max(new int[] { ph, (p.getPreferredSize()).height }); pw = max(new int[] { pw, (p.getPreferredSize()).width }); }  b++; }  if (ph > 0) { pane.setMinimumSize(new Dimension(Math.min(pw, (pane.getMinimumSize()).width), Math.min(ph, (pane.getMinimumSize()).height))); pane.setPreferredSize(new Dimension(pw, ph)); }  setResizable(panel, (Container)pane); trace("571", (JPanel)panel); } protected void add(JPanel parent, MCPanel panel, String position) { if (isNeedsRecursiveLayout(panel)) callRecursiveLayout(panel, false);  if (position == null) { parent.add((Component)panel); } else if ("BOX_X".equals(position)) { parent.add((Component)panel); } else { parent.add((Component)panel, position); }  MCScrollPane sp = getScrollPane(panel); if (sp != null) { panelAdded(panel, sp); if (panel.getBaseRootPanel() != null && panel.getBaseRootPanel().isRelayout()) callRecursiveLayout(panel, false);  return; }  MCTabbedPane tp = getTabbedPane(panel); if (tp != null) { panelAdded(panel, tp); return; }  panel.setPreferredSize(panel.getPreferredSize()); trace("364", (JPanel)panel); } private void addMarginPanel(String position, MCPanel panel, int margin) { int _margin = margin; if (this._layoutBorderInsetsMap == null) this._layoutBorderInsetsMap = new HashMap<>();  if (panel.getBaseRootPanel() != null) if (!panel.getBaseRootPanel().isRelayout()) { MCRootPanel mCRootPanel = panel.getBaseRootPanel(); Container c2 = getParentPanel((Container)panel); String k1 = String.valueOf(mCRootPanel.getName()) + "." + c2.getName() + "." + panel.getName(); if (this._layoutBorderInsetsMap.containsKey(k1)) { HashMap<String, Integer> m = this._layoutBorderInsetsMap.get(k1); m.put(position, Integer.valueOf(_margin)); } else { HashMap<String, Integer> m = new HashMap<>(); m.put(position, Integer.valueOf(_margin)); this._layoutBorderInsetsMap.put(k1, m); }  } else { MCRootPanel mCRootPanel = panel.getBaseRootPanel(); Container c2 = getParentPanel((Container)panel); String k1 = String.valueOf(mCRootPanel.getName()) + "." + c2.getName() + "." + panel.getName(); if (this._layoutBorderInsetsMap.containsKey(k1)) { HashMap<String, Integer> m = this._layoutBorderInsetsMap.get(k1); _margin = ((Integer)m.get(position)).intValue(); }  }   if (_margin <= 0) return;  String s = toBLPositionStr(position); int w = 0; int h = 0; if ("West".equals(s) || "East".equals(s)) { w += _margin; } else if ("North".equals(s) || "South".equals(s)) { h += _margin; } else { return; }  MCPanel p = createTempPanel(position); p.setPreferredSize(new Dimension(w, h)); panel.add((Component)p, s); MCLog.write(Core_Msg_FW_A.FCBAC0329, new Object[] { String.valueOf(panel.getName()) + " / " + panel.getLayoutPosition(), s, p }); } protected void setResizable(MCPanel _panel, Container cont) { _panel.setLayout(createMCBorderLayout()); _panel.add(cont, "Center"); Rectangle contRect = cont.getBounds(); int contRectX = (int)contRect.getX(); int contRectY = (int)contRect.getY(); int tbm = 0; int bbm = 0; int rbm = 0; int lbm = 0; MCAutoLayout autoLayout = new MCAutoLayout(); Rectangle r = autoLayout._getDefaultBounds(cont); if (!_hasTabbedPanel((Container)_panel) && r != null) { Border b = _panel.getBorder(); if (b != null) { Insets i = b.getBorderInsets((Component)_panel); tbm += i.top; bbm += i.bottom; rbm += i.right; lbm += i.left; }  int w = _panel.getWidth(); int h = _panel.getHeight(); int w2 = cont.getWidth(); int h2 = cont.getHeight(); if (this.panel.isRelayout()) { w = (int)autoLayout._getDefaultBounds((Component)_panel).getWidth(); h = (int)autoLayout._getDefaultBounds((Component)_panel).getHeight(); w2 = (int)r.getWidth(); h2 = (int)r.getHeight(); Rectangle contRect2 = autoLayout._getDefaultBounds(cont); contRectX = (int)contRect2.getX(); contRectY = (int)contRect2.getY(); }  int tm = contRectY - tbm; addMarginPanel("N", _panel, tm); int lm = contRectX - lbm; addMarginPanel("W", _panel, lm); int rm = w - contRectX - w2 - rbm; addMarginPanel("E", _panel, rm); int bm = h - contRectY - h2 - bbm; addMarginPanel("S", _panel, bm); }  if (isResizableContainer(cont)) { int mw = (_panel.getMinimumSize()).width; int mh = 60 + tbm + bbm; mh += contRect.y; _panel.setMinimumSize(new Dimension(mw, mh)); Dimension d = _panel.getSize(); _panel.setPreferredSize(new Dimension(d.width, d.height)); boolean hasTable = _hasTablePanel((Container)_panel); if (!hasTable) _panel.setPreferredSize(new Dimension(d.width, d.height));  trace("601", (JPanel)_panel); if (isLayoutPositionCenter(_panel)) addPanelForZoom(_panel);  } else { Dimension d1 = _panel.getPreferredSize(); _panel.setPreferredSize(new Dimension(d1.width, d1.height)); Dimension d2 = _panel.getMinimumSize(); _panel.setMinimumSize(new Dimension(d2.width, d2.height)); trace("607", (JPanel)_panel); }  } protected boolean _hasTabbedPanel(Container c) { Container p = c; while (p != null) { if (p instanceof MCTabbedPane) return true;  p = p.getParent(); }  return false; } protected boolean isResizableContainer(Container cont) { return cont instanceof MCScrollPane; } protected boolean isLayoutPositionCenter(MCPanel panel) { if (panel == null) return false;  String p = panel.getLayoutPosition(); if (p == null) return false;  p = p.replace("+", ""); return p.endsWith("C"); } protected boolean isNotZoom() { return (this._panelsForZoomPointer == -1); } protected void addPanelForZoom(MCPanel panel) { if (this._panelsForZoom == null) this._panelsForZoom = new ArrayList<>();  if (canZoom(panel) && !this._panelsForZoom.contains(panel)) this._panelsForZoom.add(panel);  } protected void sortPanelForZoom(MCRootPanel panel) { List<MCPanel> o = panelsForZoom(); if (o == null || o.size() == 0) return;  List<MCPanel> n = new ArrayList<>(); for (MCTabOrderBeans c : panel.getTabOrderBeans()) { if (c instanceof Component) { MCPanel p = MCBeansUtil.getPanel((Component)c); for (int i = 0; i < o.size(); i++) { if (p == o.get(i)) n.add(p);  }  }  }  o.removeAll(n); n.addAll(o); this._panelsForZoom = n; } public List<MCPanel> panelsForZoom() { return this._panelsForZoom; } public List<MCPanel> getZoomablePanels() { List<MCPanel> l = new ArrayList<>(); List<MCPanel> z = panelsForZoom(); if (z == null) return l;  for (MCPanel p : z) { if (canZoom(p)) l.add(p);  }  return l; } private boolean canZoom(MCPanel panel) { byte b; int i; MCScrollPane[] arrayOfMCScrollPane; for (i = (arrayOfMCScrollPane = (MCScrollPane[])MCBeansUtil.getAllComponents(MCScrollPane.class, (Container)panel)).length, b = 0; b < i; ) { MCScrollPane sp = arrayOfMCScrollPane[b]; Component o = sp.getViewport().getView(); if (o instanceof MCTable && ((MCTable)o).isPartsTable()) return false;  b++; }  for (i = (arrayOfMCScrollPane = (MCScrollPane[])MCBeansUtil.getAllComponents(MCScrollPane.class, (Container)panel)).length, b = 0; b < i; ) { MCScrollPane sp = arrayOfMCScrollPane[b]; Component o = sp.getViewport().getView(); if (o instanceof MCPanel) { MCTable[] list = (MCTable[])MCBeansUtil.getAllComponents(MCTable.class, (Container)o); if (list.length == 0) return false;  }  b++; }  if (!isVisibleComponent((Component)panel) || !isTabEnable((Component)panel)) return false;  MCModeBeans[] a = (MCModeBeans[])MCBeansUtil.getComponents(MCModeBeans.class, (Container)panel); MCModeBeans[] arrayOfMCModeBeans1; for (int j = (arrayOfMCModeBeans1 = a).length; i < j; ) { MCModeBeans c = arrayOfMCModeBeans1[i]; if (c.getModeInfo() != null) if (((Component)c).isVisible()) return true;   i++; }  return false; } @Deprecated public Integer getFrameOffsetH() { return this._frameOffsetH; } protected MCPanel getNextZoomPanel(MCLayoutEventInfo info) { List<MCPanel> l = panelsForZoom(); if (l == null) return null;  if (isNotZoom()) { MCBeans b = info.getComponent(); if (b instanceof Component) { Component c = (Component)b; while (c != null) { for (int i = 0; i < l.size(); i++) { MCPanel p = l.get(i); if (p == c) { this._panelsForZoomPointer = i; return p; }  }  c = c.getParent(); }  }  }  do { this._panelsForZoomPointer++; if (this._panelsForZoomPointer >= l.size()) { this._panelsForZoomPointer = -1; return null; }  MCPanel p = l.get(this._panelsForZoomPointer); if (canZoom(p)) return p;  } while (this._panelsForZoomPointer < l.size()); return null; } private boolean isTabEnable(Component compo) { Container p = compo.getParent(); if (p instanceof MCTabbedPane) { MCTabbedPane tp = (MCTabbedPane)p; for (int i = 0; i < tp.getTabCount(); i++) { if (compo == tp.getComponentAt(i)) { if (!tp.isEnabledAt(i)) return false;  break; }  }  }  return (p != null) ? isTabEnable(p) : true; } protected boolean isVisibleComponent(Component compo) { if (compo instanceof MCFrame) return true;  if (!(compo instanceof MCPanel) && !compo.isVisible()) return false;  Container cont = compo.getParent(); return (cont == null) ? true : isVisibleComponent(cont); } protected MCPanel[] getAllMCPanel() { return (this._allMCPanel != null) ? this._allMCPanel : (this._allMCPanel = getAllMCPanel((JPanel)this.panel)); } protected MCPanel[] getAllMCPanel(JPanel panel) { if (panel == null) return new MCPanel[0];  List<MCPanel> l = new ArrayList<>(); byte b; int i; Component[] arrayOfComponent; for (i = (arrayOfComponent = panel.getComponents()).length, b = 0; b < i; ) { Component c = arrayOfComponent[b]; if (c instanceof MCPanel) { MCPanel p = (MCPanel)c; l.add(p); l.addAll(Arrays.asList(getAllMCPanel((JPanel)p))); }  b++; }  return l.<MCPanel>toArray(new MCPanel[l.size()]); } protected Map<MCPanel, Dimension[]> orgDim() { return this._orgDim; } protected void clearOrgDim() { orgDim().clear(); } protected void putOrgDim(MCPanel panel) { Dimension[] a = { (Dimension)panel.getSize().clone(), (Dimension)panel.getPreferredSize().clone(), (Dimension)panel.getMinimumSize().clone() }; orgDim().put(panel, a); } private Map<MCSplitPane, Object[]> orgSplitInfo() { return this._orgSplitInfo; } private void clearOrgSplitInfo() { orgSplitInfo().clear(); } private void putOrgSplitInfo(MCSplitPane split) { Object[] a = { Integer.valueOf(split.getDividerLocationWithRatio()) }; orgSplitInfo().put(split, a); } protected void saveLayout() { clearOrgDim(); clearOrgSplitInfo(); byte b; int i; MCPanel[] arrayOfMCPanel; for (i = (arrayOfMCPanel = getAllMCPanel()).length, b = 0; b < i; ) { MCPanel p = arrayOfMCPanel[b]; if (!p.getName().startsWith("_headerbar") && !p.getName().startsWith("_tbar")) putOrgDim(p);  b++; }  for (MCPanel p : panelsForZoom()) { if (!orgDim().containsKey(p)) putOrgDim(p);  }  MCSplitPane[] arrayOfMCSplitPane; for (i = (arrayOfMCSplitPane = (MCSplitPane[])MCBeansUtil.getAllComponents(MCSplitPane.class, (Container)this.panel)).length, b = 0; b < i; ) { MCSplitPane sp = arrayOfMCSplitPane[b]; putOrgSplitInfo(sp); b++; }  } protected void hideAllPanels() { byte b; int i; MCPanel[] arrayOfMCPanel; for (i = (arrayOfMCPanel = getAllMCPanel()).length, b = 0; b < i; ) { MCPanel p = arrayOfMCPanel[b]; if (!p.getName().startsWith("_headerbar") && !p.getName().startsWith("_tbar")) { setTabOrderEnabled(p, false); p.setSize(new Dimension(0, 0)); p.setPreferredSize(new Dimension(0, 0)); p.setMinimumSize(new Dimension(0, 0)); trace("497", (JPanel)p); }  b++; }  } protected void setSavedLayout() { for (MCPanel p : orgDim().keySet()) { setTabOrderEnabled(p, true); final Dimension[] a = orgDim().get(p); p.setSize(new Dimension((a[0]).width, (a[0]).height)); p.setPreferredSize(new Dimension((a[1]).width, (a[1]).height)); p.setMinimumSize(new Dimension((a[2]).width, (a[2]).height)); trace("514", (JPanel)p); }  for (MCSplitPane sp : orgSplitInfo().keySet()) { final Object[] a = orgSplitInfo().get(sp); sp.addComponentListener(new ComponentAdapter() { public void componentResized(ComponentEvent e) { sp.setDividerLocationWithoutRatio(((Integer)a[0]).intValue()); sp.removeComponentListener(this); } }
/*      */         ); }  } protected void zoom(MCPanel panel) { Dimension d = this._root.getSize(); panel.setSize(new Dimension(d.width, d.height)); d = this._root.getPreferredSize(); panel.setPreferredSize(new Dimension(d.width, d.height)); d = this._root.getMinimumSize(); panel.setMinimumSize(new Dimension(d.width, d.height)); panel.setVisible(true); trace("562", (JPanel)panel); } protected Object getConstraints(Container parent, Container cont) { LayoutManager m = parent.getLayout(); if (m instanceof BorderLayout) return ((BorderLayout)m).getConstraints(cont);  if (m instanceof BoxLayout) return new ArrayList(Arrays.asList((Object[])parent.getComponents()));  if (m instanceof javax.swing.plaf.basic.BasicTabbedPaneUI.TabbedPaneLayout && parent instanceof JTabbedPane) return new TabbedPaneInfo((JTabbedPane)parent, null);  throw new MCException(Core_Msg_FW_A.FCBAC0322, new Object[] { m.getClass().getName() }); } protected void set(Container parent, Object info, Component compo) { LayoutManager m = parent.getLayout(); if (m instanceof BorderLayout) { parent.add(compo, info); } else if (m instanceof BoxLayout) { for (Component c : info) parent.add(c);  } else if (m instanceof javax.swing.plaf.basic.BasicTabbedPaneUI.TabbedPaneLayout) { if (parent instanceof JTabbedPane) { TabbedPaneInfo i = (TabbedPaneInfo)info; i.setupTab((JTabbedPane)parent); }  } else { throw new MCException(Core_Msg_FW_A.FCBAC0322, new Object[] { m.getClass().getName() }); }  } public void tableSizeChange(MCLayoutEventInfo info) { boolean def = isNotZoom(); MCPanel np = getNextZoomPanel(info); if (np == null) { if (def) return;  backToOriginalPosition(); moveFromBuffer(); setSavedLayout(); setSavedFontRatioChangeMenuVisible(); } else if (def) { saveLayout(); moveToBuffer(); hideFontRatioChangeMenuVisible(); backToOriginalPosition(); moveToDispPosition(np); hideAllPanels(); zoom(np); setTabOrderEnabled(np, true); } else { if (!isNotZoom()) { backToOriginalPosition(); setSavedLayout(); setSavedFontRatioChangeMenuVisible(); }  hideFontRatioChangeMenuVisible(); moveToDispPosition(np); hideAllPanels(); zoom(np); setTabOrderEnabled(np, true); }  this._root.updateUI(); trace("689", (JPanel)this.panel); } protected void setTabOrderEnabled(MCPanel panel, boolean enabled) { if (panel == null) return;  panel.setTabOrderEnabled(enabled); byte b; int i; MCTabOrderBeans[] arrayOfMCTabOrderBeans; for (i = (arrayOfMCTabOrderBeans = (MCTabOrderBeans[])MCBeansUtil.getAllComponents(MCTabOrderBeans.class, (Container)panel)).length, b = 0; b < i; ) { MCTabOrderBeans c = arrayOfMCTabOrderBeans[b]; c.setTabOrderEnabled(enabled); b++; }  } protected void saveFontRatioChangeMenuVisible() { MCRootPanel[] a = (MCRootPanel[])MCBeansUtil.getAllComponents(MCRootPanel.class, (Container)this.panel); byte b; int i; MCRootPanel[] arrayOfMCRootPanel1; for (i = (arrayOfMCRootPanel1 = a).length, b = 0; b < i; ) { MCRootPanel p = arrayOfMCRootPanel1[b]; String str = MCConst.createKey(new String[] { p.getModuleID(), p.getScreenID(), p.getName() }); this._fontRatioChangeMenuVisible.put(str, Boolean.valueOf(p.getFontRatioChangeMenuItem().isVisible())); b++; }  String k = MCConst.createKey(new String[] { this.panel.getModuleID(), this.panel.getScreenID(), this.panel.getName() }); this._fontRatioChangeMenuVisible.put(k, Boolean.valueOf(this.panel.getFontRatioChangeMenuItem().isVisible())); } protected void hideFontRatioChangeMenuVisible() { if (this._fontRatioChangeMenuVisible.size() == 0) saveFontRatioChangeMenuVisible();  MCRootPanel[] a = (MCRootPanel[])MCBeansUtil.getAllComponents(MCRootPanel.class, (Container)this.panel); byte b; int i; MCRootPanel[] arrayOfMCRootPanel1; for (i = (arrayOfMCRootPanel1 = a).length, b = 0; b < i; ) { MCRootPanel p = arrayOfMCRootPanel1[b]; p.getFontRatioChangeMenuItem().setVisible(false); b++; }  this.panel.getFontRatioChangeMenuItem().setVisible(false); } protected void setSavedFontRatioChangeMenuVisible() { MCRootPanel[] a = (MCRootPanel[])MCBeansUtil.getAllComponents(MCRootPanel.class, (Container)this.panel); byte b; int i; MCRootPanel[] arrayOfMCRootPanel1; for (i = (arrayOfMCRootPanel1 = a).length, b = 0; b < i; ) { MCRootPanel p = arrayOfMCRootPanel1[b]; String str = MCConst.createKey(new String[] { p.getModuleID(), p.getScreenID(), p.getName() }); Boolean bool = this._fontRatioChangeMenuVisible.get(str); if (bool != null) p.getFontRatioChangeMenuItem().setVisible(bool.booleanValue());  b++; }  String k = MCConst.createKey(new String[] { this.panel.getModuleID(), this.panel.getScreenID(), this.panel.getName() }); Boolean v = this._fontRatioChangeMenuVisible.get(k); if (v != null) this.panel.getFontRatioChangeMenuItem().setVisible(v.booleanValue());  } protected void moveToBuffer() { BorderLayout b = (BorderLayout)this._rootSub.getLayout(); Component n = b.getLayoutComponent("Center"); this._rootSub.add(n, "North"); n.setVisible(false); this._oldParent = null; this._oldConstraints = null; } protected void moveFromBuffer() { BorderLayout b = (BorderLayout)this._rootSub.getLayout(); Component comp = b.getLayoutComponent("North"); if (comp != null) { this._rootSub.add(comp, "Center"); comp.setVisible(true); }  this._oldParent = null; this._oldConstraints = null; } protected void backToOriginalPosition() { if (this._oldParent != null) { BorderLayout b = (BorderLayout)this._rootSub.getLayout(); set(this._oldParent, this._oldConstraints, b.getLayoutComponent("Center")); }  } protected void moveToDispPosition(MCPanel panel) { this._oldParent = panel.getParent(); this._oldConstraints = getConstraints(this._oldParent, (Container)panel); this._rootSub.add((Component)panel, "Center"); } public void tableSizeDefault() { if (!isNotZoom()) { backToOriginalPosition(); moveFromBuffer(); setSavedLayout(); setSavedFontRatioChangeMenuVisible(); this._panelsForZoomPointer = -1; }  } public void sizeChanged() {} public void fontRatioChange(MCLayoutEventInfo info) { MCBeansUtil.fontRatioChange(this.panel, info.getPanelOldFontRatio(), info.getPanelNewFontRatio()); } private static class TabbedPaneInfo {
/*      */     private final Component[] compos; private final String[] title; private final String[] toolTipText; private final Icon[] icon; private final Component selected; private TabbedPaneInfo(JTabbedPane pane) { int cnt = pane.getTabCount(); this.compos = pane.getComponents(); this.title = new String[cnt]; this.toolTipText = new String[cnt]; this.icon = new Icon[cnt]; this.selected = pane.getSelectedComponent(); for (int i = 0; i < cnt; i++) { this.title[i] = pane.getTitleAt(i); this.toolTipText[i] = pane.getToolTipTextAt(i); this.icon[i] = pane.getIconAt(i); }  } private void setupTab(JTabbedPane pane) { Map<Component, Boolean> m = new HashMap<>(); for (int i = 0; i < pane.getTabCount(); i++) m.put(pane.getComponentAt(i), Boolean.valueOf(pane.isEnabledAt(i)));  pane.removeAll(); boolean c = false; for (int j = 0; j < this.compos.length; j++) { if (this.selected == this.compos[j]) c = true;  pane.insertTab(this.title[j], this.icon[j], this.compos[j], this.toolTipText[j], j); if (m.containsKey(this.compos[j])) pane.setEnabledAt(j, ((Boolean)m.get(this.compos[j])).booleanValue());  }  if (c) pane.setSelectedComponent(this.selected);  } } public void initialized() { MCRootPanel p = this.panel; Dimension d = p.getSize(); MCAutoLayout autoLayout = new MCAutoLayout(); autoLayout.setupTargetPanel(p); autoLayout.setupPanelList(); Integer prefWidth = autoLayout.panelPrefWidth(p); Integer prefHeight = autoLayout.panelPrefHeight(p); if (prefWidth != null) d.width = prefWidth.intValue();  if (prefHeight != null) d.height = prefHeight.intValue();  if (usePrefSize(p)) { int w = autoLayout.getMinPreferredWidth(p); if (w > 0) { int margin = this._margin_manager._margin.right; prefWidth = Integer.valueOf(w + margin); }  }  if (useAdjustHeight(p)) { int h = autoLayout.getMinPreferredHeight(p); if (h > 0) prefHeight = Integer.valueOf(h);  }  if (useChangeScreenHeight()) { int h = getFrameOffsetH().intValue(); if (h > 0) { p.setSavePreferredSize(p.getPreferredSize()); p.setPreferredSize(new Dimension(d.width, d.height + h)); }  }  Dimension d2 = p.getPreferredSize(); boolean b2 = false; if (prefWidth != null) { d2.width = prefWidth.intValue(); b2 = true; }  if (prefHeight != null) { d2.height = prefHeight.intValue(); b2 = true; }  if (b2) p.setPreferredSize(new Dimension(d2.width, d2.height));  if (prefWidth != null || prefHeight != null) { boolean f = false; Dimension ps = p.getPreferredSize(); if (prefWidth != null && ps.width != prefWidth.intValue()) { ps.width = prefWidth.intValue(); f = true; }  if (prefHeight != null && ps.height != prefHeight.intValue()) { ps.height = prefHeight.intValue(); f = true; }  if (f) p.setPreferredSize(ps);  }  } private static final String[] _keyList = new String[] { "useLayoutDebugMode", "useAutoLayout", "useGrid", "gridSize", "spaceLabelAndField", "spaceButtonAndButton", "useAlignRight", "useCR", "useUpdateLabelSize", "useFitLabelSize", "useAlignNoLabelField", "useAlignLabelLocation", "useFloorGrid", "screenWidth", "lineGrid", "useInvisibleForMode", "useCompressPanel", "useUpdateTabOrder", "panelWidth", "panelHeight", "screenHeight", "panelPrefWidth", "panelPrefHeight" }; protected HashMap<MCPanel, Integer> _panelHeightMap; protected List<List<MCPanel>> _invalidPanelList; protected Integer _frameOffsetH; protected void loadLayoutResourceForAutoLayout() { String[] keys = new String[2]; keys[0] = "autoLayout"; byte b; int i; String[] arrayOfString1; for (i = (arrayOfString1 = _keyList).length, b = 0; b < i; ) { String k3 = arrayOfString1[b]; keys[1] = k3; String k = MCResource.createKey(keys); if (MCConst.layout.containsKey(k)) setResourceForAutoLayout(true, k3, MCConst.layout.getString(k));  b++; }  } protected void loadResourceForAutoLayout() { loadLayoutResourceForAutoLayout(); MCRootPanel bp = this.panel; String[][] msa = bp.getModuleAndScreenIDs(); String[] keys = new String[4]; keys[2] = "autoLayout"; byte b; int i; String[] arrayOfString1; for (i = (arrayOfString1 = _keyList).length, b = 0; b < i; ) { String k3 = arrayOfString1[b]; keys[3] = k3; byte b1; int j; String[][] arrayOfString; for (j = (arrayOfString = msa).length, b1 = 0; b1 < j; ) { String[] element = arrayOfString[b1]; keys[0] = element[0]; keys[1] = element[1]; String k = MCResource.createKey(keys); if (MCConst.layout.containsKey(k)) { setResourceForAutoLayout(false, k3, MCConst.layout.getString(k)); break; }  b1++; }  b++; }  } protected void setResourceForAutoLayout(boolean all, String key, String val) { if (all) { if ("useLayoutDebugMode".equals(key)) { MCAutoLayoutParam.setUseLayoutDebugMode(Boolean.valueOf(val).booleanValue()); } else if ("useAutoLayout".equals(key)) { MCAutoLayoutParam.setUseAutoLayout(Boolean.valueOf(val).booleanValue()); } else if ("useGrid".equals(key)) { MCAutoLayoutParam.setUseGrid(Boolean.valueOf(val).booleanValue()); } else if ("gridSize".equals(key)) { MCAutoLayoutParam.setGridSize(Integer.valueOf(val).intValue()); } else if ("spaceLabelAndField".equals(key)) { MCAutoLayoutParam.setSpaceLabelAndField(Integer.valueOf(val).intValue()); } else if ("spaceButtonAndButton".equals(key)) { MCAutoLayoutParam.setSpaceButtonAndButton(Integer.valueOf(val).intValue()); } else if ("useAlignRight".equals(key)) { MCAutoLayoutParam.setUseAlignRight(Boolean.valueOf(val).booleanValue()); } else if ("useCR".equals(key)) { MCAutoLayoutParam.setUseCR(Boolean.valueOf(val).booleanValue()); } else if ("useUpdateLabelSize".equals(key)) { MCAutoLayoutParam.setUseUpdateLabelSize(Boolean.valueOf(val).booleanValue()); } else if ("useFitLabelSize".equals(key)) { MCAutoLayoutParam.setUseFitLabelSize(Boolean.valueOf(val).booleanValue()); } else if ("useAlignNoLabelField".equals(key)) { MCAutoLayoutParam.setUseAlignNoLabelField(Boolean.valueOf(val).booleanValue()); } else if ("useAlignLabelLocation".equals(key)) { MCAutoLayoutParam.setUseAlignLabelLocation(Boolean.valueOf(val).booleanValue()); } else if ("useFloorGrid".equals(key)) { MCAutoLayoutParam.setUseFloorGrid(Boolean.valueOf(val).booleanValue()); } else if ("lineGrid".equals(key)) { MCAutoLayoutParam.setLineGrid(Integer.valueOf(val).intValue()); } else if ("useInvisibleForMode".equals(key)) { MCAutoLayoutParam.setUseInvisibleForMode(Boolean.valueOf(val).booleanValue()); } else if ("useCompressPanel".equals(key)) { MCAutoLayoutParam.setUseCompressPanel(Boolean.valueOf(val).booleanValue()); } else if ("useUpdateTabOrder".equals(key)) { MCAutoLayoutParam.setUseUpdateTabOrder(Boolean.valueOf(val).booleanValue()); } else if ("screenWidth".equals(key)) { MCAutoLayoutParam.setScreenWidth(Integer.valueOf(val)); } else if ("screenHeight".equals(key)) { MCAutoLayoutParam.setScreenHeight(Integer.valueOf(val)); } else if ("panelWidth".equals(key)) { MCAutoLayoutParam.setPanelWidth(Integer.valueOf(val)); } else if ("panelHeight".equals(key)) { MCAutoLayoutParam.setPanelHeight(Integer.valueOf(val)); } else if ("panelPrefWidth".equals(key)) { MCAutoLayoutParam.setPanelPrefWidth(Integer.valueOf(val)); } else if ("panelPrefHeight".equals(key)) { MCAutoLayoutParam.setPanelPrefHeight(Integer.valueOf(val)); }  } else if ("useLayoutDebugMode".equals(key)) { MCBeansProxy.PROXY.setAutoLayoutUseLayoutDebugMode(this.panel, Boolean.valueOf(val).booleanValue()); } else if ("useAutoLayout".equals(key)) { MCBeansProxy.PROXY.setAutoLayoutUseAutoLayout(this.panel, Boolean.valueOf(val).booleanValue()); } else if ("gridSize".equals(key)) { MCBeansProxy.PROXY.setAutoLayoutGridSize(this.panel, Integer.valueOf(val).intValue()); } else if ("spaceLabelAndField".equals(key)) { MCBeansProxy.PROXY.setAutolayoutSpaceLabelAndField(this.panel, Integer.valueOf(val).intValue()); } else if ("spaceButtonAndButton".equals(key)) { MCBeansProxy.PROXY.setAutolayoutSpaceButtonAndButton(this.panel, Integer.valueOf(val).intValue()); } else if ("useAlignRight".equals(key)) { MCBeansProxy.PROXY.setAutolayoutUseAlignRight(this.panel, Boolean.valueOf(val).booleanValue()); } else if ("useCR".equals(key)) { MCBeansProxy.PROXY.setAutolayoutUseCR(this.panel, Boolean.valueOf(val).booleanValue()); } else if ("useUpdateLabelSize".equals(key)) { MCBeansProxy.PROXY.setAutolayoutUseUpdateLabelSize(this.panel, Boolean.valueOf(val).booleanValue()); } else if ("useFitLabelSize".equals(key)) { MCBeansProxy.PROXY.setAutolayoutUseFitLabelSize(this.panel, Boolean.valueOf(val).booleanValue()); } else if ("useFloorGrid".equals(key)) { MCBeansProxy.PROXY.setAutolayoutUseFloorGrid(this.panel, Boolean.valueOf(val).booleanValue()); } else if ("lineGrid".equals(key)) { MCBeansProxy.PROXY.setAutolayoutLineGrid(this.panel, Integer.valueOf(val).intValue()); } else if ("useInvisibleForMode".equals(key)) { MCBeansProxy.PROXY.setAutolayoutUseInvisibleForMode(this.panel, Boolean.valueOf(val).booleanValue()); } else if ("useCompressPanel".equals(key)) { MCBeansProxy.PROXY.setAutolayoutUseCompressPanel(this.panel, Boolean.valueOf(val).booleanValue()); } else if ("useUpdateTabOrder".equals(key)) { MCBeansProxy.PROXY.setAutolayoutUseUpdateTabOrder(this.panel, Boolean.valueOf(val).booleanValue()); } else if ("panelWidth".equals(key)) { MCBeansProxy.PROXY.setAutolayoutPanelWidth(this.panel, Integer.valueOf(val).intValue()); } else if ("panelHeight".equals(key)) { MCBeansProxy.PROXY.setAutolayoutPanelHeight(this.panel, Integer.valueOf(val).intValue()); } else if ("screenWidth".equals(key)) { MCBeansProxy.PROXY.setAutolayoutScreenWidth(this.panel, Integer.valueOf(val).intValue()); } else if ("screenHeight".equals(key)) { MCBeansProxy.PROXY.setAutolayoutScreenHeight(this.panel, Integer.valueOf(val).intValue()); } else if ("panelPrefWidth".equals(key)) { MCBeansProxy.PROXY.setAutolayoutPanelPrefWidth(this.panel, Integer.valueOf(val).intValue()); } else if ("panelPrefHeight".equals(key)) { MCBeansProxy.PROXY.setAutolayoutPanelPrefHeight(this.panel, Integer.valueOf(val).intValue()); }  } @Deprecated protected void setAnytimeFAction(MCButton b) { MCBeansProxy.PROXY.setAnytimeFAction(b, true); } public static boolean isUseLayoutDebugMode() { return MCAutoLayoutParam.isUseLayoutDebugMode(); } public static void setUseLayoutDebugMode(boolean useLayoutDebugMode) { MCAutoLayoutParam.setUseLayoutDebugMode(useLayoutDebugMode); } public static boolean isUseAutoLayout() { return MCAutoLayoutParam.isUseAutoLayout(); } public static void setUseAutoLayout(boolean useAutoLayout) { MCAutoLayoutParam.setUseAutoLayout(useAutoLayout); } public static boolean isUseGrid() { return MCAutoLayoutParam.isUseGrid(); } public static void setUseGrid(boolean useGrid) { MCAutoLayoutParam.setUseGrid(useGrid); } public static boolean isUseAlignRight() { return MCAutoLayoutParam.isUseAlignRight(); } public static void setUseAlignRight(boolean useAlignRight) { MCAutoLayoutParam.setUseAlignRight(useAlignRight); } public static boolean isUseCR() { return MCAutoLayoutParam.isUseCR(); } public static void setUseCR(boolean useCR) { MCAutoLayoutParam.setUseCR(useCR); } public static boolean isUseUpdateLabelSize() { return MCAutoLayoutParam.isUseUpdateLabelSize(); } public static void setUseUpdateLabelSize(boolean useUpdateLabelSize) { MCAutoLayoutParam.setUseUpdateLabelSize(useUpdateLabelSize); } public static boolean isUseFitLabelSize() { return MCAutoLayoutParam.isUseFitLabelSize(); } public static void setUseFitLabelSize(boolean useFitLabelSize) { MCAutoLayoutParam.setUseFitLabelSize(useFitLabelSize); } public static boolean isUseAlignNoLabelField() { return MCAutoLayoutParam.isUseAlignNoLabelField(); } public static void setUseAlignNoLabelField(boolean useAlignNoLabelField) { MCAutoLayoutParam.setUseAlignNoLabelField(useAlignNoLabelField); } public static boolean isUseAlignLabelLocation() { return MCAutoLayoutParam.isUseAlignLabelLocation(); } public static void setUseAlignLabelLocation(boolean useAlignLabelLocation) { MCAutoLayoutParam.setUseAlignLabelLocation(useAlignLabelLocation); } public static boolean isUseFloorGrid() { return MCAutoLayoutParam.isUseFloorGrid(); } public static void setUseFloorGrid(boolean useFloorGrid) { MCAutoLayoutParam.setUseFloorGrid(useFloorGrid); } public static boolean isUseInvisibleForMode() { return MCAutoLayoutParam.isUseInvisibleForMode(); } public static void setUseInvisibleForMode(boolean useInvisibleForMode) { MCAutoLayoutParam.setUseInvisibleForMode(useInvisibleForMode); } public static boolean isUseCompressPanel() { return MCAutoLayoutParam.isUseCompressPanel(); } public static void setUseCompressPanel(boolean useCompressPanel) { MCAutoLayoutParam.setUseCompressPanel(useCompressPanel); } public static boolean isUseUpdateTabOrder() { return MCAutoLayoutParam.isUseUpdateTabOrder(); } public static void setUseUpdateTabOrder(boolean useUpdateTabOrder) { MCAutoLayoutParam.setUseUpdateTabOrder(useUpdateTabOrder); } public static boolean isUseDebugPanel() { return MCAutoLayoutParam.isUseDebugPanel(); } public static void setUseDebugPanel(boolean useDebugPanel) { MCAutoLayoutParam.setUseDebugPanel(useDebugPanel); } public static int getGridSize() { return MCAutoLayoutParam.getGridSize(); } public static void setGridSize(int gridSize) { MCAutoLayoutParam.setGridSize(gridSize); } public static int getSpaceLabelAndField() { return MCAutoLayoutParam.getSpaceLabelAndField(); } public static void setSpaceLabelAndField(int spaceLabelAndField) { MCAutoLayoutParam.setSpaceLabelAndField(spaceLabelAndField); } public static int getSpaceButtonAndButton() { return MCAutoLayoutParam.getSpaceButtonAndButton(); } public static void setSpaceButtonAndButton(int spaceButtonAndButton) { MCAutoLayoutParam.setSpaceButtonAndButton(spaceButtonAndButton); } public static int getScreenWidth() { return MCAutoLayoutParam.getScreenWidth().intValue(); } public static void setScreenWidth(int screenWidth) { MCAutoLayoutParam.setScreenWidth(Integer.valueOf(screenWidth)); } public static int getLineGrid() { return MCAutoLayoutParam.getLineGrid(); } public static void setLineGrid(int lineGrid) { MCAutoLayoutParam.setLineGrid(lineGrid); } public static void relayout(MCRootPanel rootPanel, boolean repaint) { rootPanel.setRelayout(true); if (rootPanel.isShowing()) saveDividerLocation(rootPanel);  MCAutoLayout autoLayout = new MCAutoLayout(); autoLayout.setupTargetPanel(rootPanel); Map<String, MCLayoutLocationR> saveLocationMap = rootPanel.getLocationMap(); Map<String, MCLayoutPanelR> savePanelMap = rootPanel.getPanelMap(); List<MCLocationSortR> saveSortList = rootPanel.getPersonalizeSortList(); resetLayout(autoLayout, rootPanel); rootPanel.setLocationMap(saveLocationMap); rootPanel.setPanelMap(savePanelMap); rootPanel.setPersonalizeSortList(saveSortList); autoLayout.relayout(); if (repaint) autoLayout.repaintTopPanel(rootPanel);  rootPanel.setRelayout(false); if (rootPanel.isShowing()) restoreDividerLocation(rootPanel);  } public static void relayoutForRootPanel(MCRootPanel rootPanel) { rootPanel.setRelayout(true); MCBeansUtil.loadLocationResource(rootPanel); MCAutoLayout autoLayout = new MCAutoLayout(); autoLayout.setupTargetPanel(rootPanel); autoLayout.relayout(); rootPanel.setRelayout(false); } public static void resetLayout(MCRootPanel rootPanel) { rootPanel.setRelayout(true); saveDividerLocation(rootPanel); MCAutoLayout autoLayout = new MCAutoLayout(); autoLayout.setupTargetPanel(rootPanel); resetLayout(autoLayout, rootPanel); autoLayout.repaintTopPanel(rootPanel); rootPanel.setRelayout(false); } public static void saveDividerLocation(MCRootPanel rootPanel) { rootPanel.setDividerLocationForRelayout(new HashMap<>()); MCSplitPane[] components = (MCSplitPane[])MCBeansUtil.getAllComponents(MCSplitPane.class, (Container)rootPanel); byte b; int i; MCSplitPane[] arrayOfMCSplitPane1; for (i = (arrayOfMCSplitPane1 = components).length, b = 0; b < i; ) { MCSplitPane c = arrayOfMCSplitPane1[b]; Integer n = Integer.valueOf(c.getDividerLocation()); rootPanel.getDividerLocationForRelayout().put(c.getName(), n); b++; }  } public static void restoreDividerLocation(MCRootPanel rootPanel) { HashMap<String, Integer> map = rootPanel.getDividerLocationForRelayout(); MCSplitPane[] components = (MCSplitPane[])MCBeansUtil.getAllComponents(MCSplitPane.class, (Container)rootPanel); byte b; int i; MCSplitPane[] arrayOfMCSplitPane1; for (i = (arrayOfMCSplitPane1 = components).length, b = 0; b < i; ) { MCSplitPane c = arrayOfMCSplitPane1[b]; String key = c.getName(); if (map.containsKey(key)) { Integer n = map.get(key); int layoutRatio = c.getBaseRootPanel().getLayoutRatio(); c.setDividerSize(MCBeansProxy.PROXY.getDefaultDividerSize(c).intValue() * layoutRatio / 100); c.setDividerLocationWithoutRatio(n.intValue()); }  b++; }  } public static void resetLayout(MCAutoLayout autoLayout, MCRootPanel rootPanel) { if (rootPanel.isDisableLayoutInit()) return;  List<MCLocationSortR> saveSortList = new ArrayList<>(rootPanel.getPersonalizeSortList()); autoLayout.initPersonalizeData(rootPanel); Map<String, MCLayoutLocationR> map0 = rootPanel.getDefaultLocationMap(); Map<String, MCLayoutPanelR> map1 = rootPanel.getDefaultPanelMap(); Map<String, MCLayoutLocationR> map2 = new LinkedHashMap<>(); Map<String, MCLayoutPanelR> map3 = new LinkedHashMap<>(); List<MCLocationSortR> list4 = new ArrayList<>(); map0.entrySet().forEach(e -> {  }); map1.entrySet().forEach(e -> {  }); rootPanel.setLocationMap(map2); rootPanel.setPanelMap(map3); rootPanel.setPersonalizeSortList(list4); autoLayout.beforeRelayout(); autoLayout.relayout2(true); rootPanel.setPersonalizeSortList(saveSortList); } public static MCButton getOpenTbarButton(MCRootPanel rp) { MCRootPanel mCRootPanel = rp; while (mCRootPanel != null) { if (mCRootPanel.getName() != null && !mCRootPanel.getName().startsWith("_")) { LayoutManager l = mCRootPanel.getLayout(); if (l instanceof MCBorderLayout) { MCBorderLayout bl = (MCBorderLayout)l; MCLayout gl = bl.getLayout(); if (gl instanceof MCGeneralLayout) return ((MCGeneralLayout)gl).getOpenTbarButton();  return null; }  }  Container container = mCRootPanel.getParent(); }  return null; } public MCButton getOpenTbarButton() { return null; } protected List<List<MCPanel>> checkInvalidPanel() { ArrayList<List<MCPanel>> xlist = new ArrayList<>(); MCPanel[] plist = (MCPanel[])MCBeansUtil.getAllComponents(MCPanel.class, (Container)this.panel); byte b; int i; MCPanel[] arrayOfMCPanel1; for (i = (arrayOfMCPanel1 = plist).length, b = 0; b < i; ) { MCPanel p = arrayOfMCPanel1[b]; if (p.isVisible()) if (p.getName() == null || !p.getName().startsWith("_layouter_")) if (countX(p) > 0) { List<MCPanel> plist2 = getXList(p); if (plist2.size() != 0) { Collections.sort(plist2, new MCPanelComparator(null)); boolean bool = false; for (List<MCPanel> plist3 : xlist) { if (plist3.size() == plist2.size()) { boolean b1 = true; for (int j = 0; j < plist2.size(); j++) { if (plist2.get(j) != plist3.get(j)) { b1 = false; break; }  }  if (b1) bool = true;  }  }  if (!bool) xlist.add(plist2);  }  }    b++; }  for (i = (arrayOfMCPanel1 = plist).length, b = 0; b < i; ) { MCPanel p = arrayOfMCPanel1[b]; String pos = p.getLayoutPosition(); if (pos != null && pos.length() > 0) { Component[] clist = p.getComponents(); boolean b0 = false; HashMap<String, ArrayList<MCPanel>> map1 = new HashMap<>(); byte b1; int j; Component[] arrayOfComponent1; for (j = (arrayOfComponent1 = clist).length, b1 = 0; b1 < j; ) { Component c = arrayOfComponent1[b1]; if (c instanceof MCPanel && p.getName() != null && !c.getName().startsWith("_layouter_")) { MCPanel p2 = (MCPanel)c; String pos2 = p2.getLayoutPosition(); if (pos2 != null && pos2.length() >= 2) { ArrayList<MCPanel> plist3; String pos3 = pos2.substring(0, pos2.length() - 1); String pos4 = pos2.substring(pos2.length() - 1, pos2.length()); if (map1.containsKey(pos3)) { plist3 = map1.get(pos3); } else { plist3 = new ArrayList<>(); map1.put(pos3, plist3); }  if (pos4.endsWith("E") || pos4.endsWith("C") || pos4.endsWith("W")) plist3.add(p2);  }  }  b1++; }  for (ArrayList<MCPanel> plist4 : map1.values()) { ArrayList<MCPanel> plist2 = new ArrayList<>(); for (MCPanel p4 : plist4) { String pos2 = p4.getLayoutPosition(); String pos4 = pos2.substring(1, 2); if (pos4.endsWith("E") || pos4.endsWith("C") || pos4.endsWith("W")) plist2.add(p4);  if (pos4.endsWith("E") || pos4.endsWith("W")) b0 = true;  }  if (b0 && plist2.size() > 1) { Collections.sort(plist2, new MCPanelComparator(null)); boolean bool = false; for (List<MCPanel> plist3 : xlist) { if (plist3.size() == plist2.size()) { boolean bool1 = true; for (int k = 0; k < plist2.size(); k++) { if (plist2.get(k) != plist3.get(k)) { bool1 = false; break; }  }  if (bool1) bool = true;  }  }  if (!bool) xlist.add(plist2);  }  }  }  b++; }  for (i = (arrayOfMCPanel1 = plist).length, b = 0; b < i; ) { MCPanel p = arrayOfMCPanel1[b]; if (p.getName() == null || !p.getName().startsWith("_layouter_")) { List<MCPanel> plist4 = getYList(p); if (plist4.size() > 1) { Collections.sort(plist4, new MCPanelComparator(null)); boolean bool = false; for (List<MCPanel> plist3 : xlist) { if (plist3.size() == plist4.size()) { boolean b1 = true; for (int j = 0; j < plist4.size(); j++) { if (plist4.get(j) != plist3.get(j)) { b1 = false; break; }  }  if (b1) bool = true;  }  }  if (!bool) xlist.add(plist4);  }  }  b++; }  return xlist; } protected List<MCPanel> getXList(MCPanel p) { ArrayList<MCPanel> result = new ArrayList<>(); if (!p.isVisible()) return result;  String pos = p.getLayoutPosition(); if (pos != null) { int n = countX(p); if (n > 0) { MCPanel mCPanel = p; boolean b = true; boolean f = false; while (b) { container = mCPanel.getParent(); if (container instanceof MCPanel) { if (countX((MCPanel)container) == 0) { f = true; b = false; }  continue; }  b = false; }  if (!f) return result;  Container container = container.getParent(); MCPanel[] plist2 = (MCPanel[])MCBeansUtil.getAllComponents(MCPanel.class, container); byte b1; int i; MCPanel[] arrayOfMCPanel1; for (i = (arrayOfMCPanel1 = plist2).length, b1 = 0; b1 < i; ) { MCPanel p2 = arrayOfMCPanel1[b1]; if (p2.isVisible() && p2.getName() != null && !p2.getName().startsWith("_layouter_")) result.add(p2);  b1++; }  }  }  result.size(); return result; } protected List<MCPanel> getYList(MCPanel p) { ArrayList<MCPanel> result = new ArrayList<>(); if (!p.isVisible()) return result;  int y1 = p.getY(); String pos1 = p.getLayoutPosition(); Container c1 = p.getParent(); if (c1 instanceof MCTabbedPane) return result;  if (pos1 != null) { MCPanel[] plist2 = (MCPanel[])MCBeansUtil.getAllComponents(MCPanel.class, p.getParent()); byte b; int i; MCPanel[] arrayOfMCPanel1; for (i = (arrayOfMCPanel1 = plist2).length, b = 0; b < i; ) { MCPanel p2 = arrayOfMCPanel1[b]; Container c2 = p2.getParent(); if (c1 == c2) if (!(c2 instanceof MCTabbedPane)) if (c2.isVisible()) if (p2.getName() == null || !p2.getName().startsWith("_layouter_")) { int y2 = p2.getY(); String pos2 = p2.getLayoutPosition(); if (pos2 != null) if (y1 == y2 && pos1.equals(pos2)) result.add(p2);   }     b++; }  }  result.size(); return result; } protected int countX(MCPanel p) { String pos = p.getLayoutPosition(); if (pos == null) return 0;  int count = 0; byte b; int i; char[] arrayOfChar; for (i = (arrayOfChar = pos.toCharArray()).length, b = 0; b < i; ) { char x = arrayOfChar[b]; if (x == 'X') count++;  b++; }  return count; } private class MCPanelComparator implements Comparator<MCPanel> {
/*      */     private MCPanelComparator() {} public int compare(MCPanel a, MCPanel b) { int n = Integer.valueOf(b.getWidth()).compareTo(Integer.valueOf(a.getWidth())); if (n == 0) return Integer.valueOf(b.hashCode()).compareTo(Integer.valueOf(a.hashCode()));  return n; } } private class MCPanelComparator2 implements Comparator<MCPanel> {
/*      */     private Container c; public MCPanelComparator2(Container c) { this.c = c; } public int compare(MCPanel a, MCPanel b) { Integer xa = Integer.valueOf(MCGeneralLayout.this._getXOnPanel((Component)a, this.c)); Integer xb = Integer.valueOf(MCGeneralLayout.this._getXOnPanel((Component)b, this.c)); int n = xa.compareTo(xb); return n; } }
/* 5501 */   void setPanelLimitWidth(List<MCPanel> plist, MCAutoLayout autoLayout) { boolean usePanelLimitWidth = isUsePanelLimitWidth();
/* 5502 */     if (!usePanelLimitWidth) {
/*      */       return;
/*      */     }
/*      */     
/* 5506 */     this._invalidPanelList = checkInvalidPanel();
/* 5507 */     if (this._invalidPanelList.size() > 0) {
/*      */       
/* 5509 */       this.panel.validate();
/*      */ 
/*      */       
/* 5512 */       this._panelHeightMap = new HashMap<>();
/* 5513 */       for (List<MCPanel> result1 : this._invalidPanelList) {
/* 5514 */         for (MCPanel p : result1) {
/* 5515 */           this._panelHeightMap.put(p, Integer.valueOf((p.getPreferredSize()).height));
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 5520 */       Integer screenWidth = this.panel.getAutolayoutPanelWidth();
/* 5521 */       if (screenWidth == null) {
/* 5522 */         screenWidth = Integer.valueOf(this.panel.getDefaultPanelWidth());
/*      */       }
/*      */       
/* 5525 */       boolean relayout = false;
/*      */       
/* 5527 */       for (List<MCPanel> _result : this._invalidPanelList) {
/*      */         
/* 5529 */         ArrayList<MCPanel> result4 = new ArrayList<>();
/* 5530 */         for (MCPanel p : _result) {
/* 5531 */           if (autoLayout._isFitPanel((Container)p)) {
/* 5532 */             result4.add(p);
/*      */           }
/*      */         } 
/*      */         
/* 5536 */         boolean b1 = false;
/*      */         
/* 5538 */         if (result4.size() == 2) {
/* 5539 */           MCPanel c1 = result4.get(0);
/* 5540 */           MCPanel c2 = result4.get(1);
/* 5541 */           MCPanel c3 = null;
/*      */           
/* 5543 */           int n = 2;
/* 5544 */           int s1 = (c1.getPreferredSize()).width;
/* 5545 */           int s2 = (c2.getPreferredSize()).width;
/* 5546 */           if (s1 > 0 && s2 > 0) {
/* 5547 */             if (s1 > 0 && s2 > 0 && s1 > s2) {
/* 5548 */               if (s1 / s2 >= n) {
/* 5549 */                 c3 = c1;
/*      */               }
/* 5551 */             } else if (s2 > s1 && 
/* 5552 */               s2 / s1 >= n) {
/* 5553 */               c3 = c2;
/*      */             } 
/*      */           }
/*      */ 
/*      */           
/* 5558 */           if (c3 != null) {
/* 5559 */             Container c = (Container)result4.get(0);
/*      */             
/* 5561 */             c = c.getParent();
/*      */             
/* 5563 */             List<MCPanel> result3 = new ArrayList<>(result4);
/* 5564 */             Collections.sort(result3, new MCPanelComparator2(c));
/*      */             
/* 5566 */             MCPanel p1 = result3.get(0);
/* 5567 */             int right = _getXOnPanel((Component)p1, c);
/*      */             
/* 5569 */             for (MCPanel p2 : result3) {
/* 5570 */               right += (p2.getPreferredSize()).width;
/*      */             }
/*      */             
/* 5573 */             int delta = right - screenWidth.intValue();
/* 5574 */             if (delta > 0) {
/* 5575 */               b1 = true;
/* 5576 */               MCPanel p3 = c3;
/*      */               
/* 5578 */               int margin = p3._getRightMargin();
/* 5579 */               int w = (p3.getPreferredSize()).width - delta - margin;
/*      */ 
/*      */               
/* 5582 */               p3.setLimitWidth(Integer.valueOf(w));
/* 5583 */               relayout = true;
/*      */             } 
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/* 5589 */         if (!b1 && result4.size() == 2) {
/* 5590 */           MCPanel c1 = result4.get(0);
/* 5591 */           MCPanel c2 = result4.get(1);
/* 5592 */           MCPanel c3 = null;
/*      */           
/* 5594 */           int n = 3;
/* 5595 */           int s1 = (c1.getPreferredSize()).width;
/* 5596 */           int s2 = (c2.getPreferredSize()).width;
/* 5597 */           if (s1 > 0 && s2 > 0) {
/* 5598 */             if (s1 > s2) {
/* 5599 */               if (s1 / s2 >= n) {
/* 5600 */                 c3 = c1;
/*      */               }
/* 5602 */             } else if (s2 > s1 && 
/* 5603 */               s2 / s1 >= n) {
/* 5604 */               c3 = c2;
/*      */             } 
/*      */           }
/*      */ 
/*      */           
/* 5609 */           if (c3 != null) {
/* 5610 */             Container c = (Container)result4.get(0);
/* 5611 */             boolean b = true;
/* 5612 */             boolean f = false;
/* 5613 */             while (b) {
/* 5614 */               c = c.getParent();
/* 5615 */               if (c instanceof MCPanel) {
/* 5616 */                 if (countX((MCPanel)c) == 0) {
/* 5617 */                   f = true;
/* 5618 */                   b = false;
/*      */                 }  continue;
/*      */               } 
/* 5621 */               b = false;
/*      */             } 
/*      */             
/* 5624 */             if (f) {
/* 5625 */               b1 = true;
/*      */               
/* 5627 */               c = c.getParent();
/*      */               
/* 5629 */               List<MCPanel> result3 = new ArrayList<>(_result);
/* 5630 */               Collections.sort(result3, new MCPanelComparator2(c));
/*      */               
/* 5632 */               MCPanel p1 = result3.get(0);
/* 5633 */               int right = _getXOnPanel((Component)p1, c);
/*      */               
/* 5635 */               for (MCPanel p2 : result3) {
/* 5636 */                 right += (p2.getPreferredSize()).width;
/*      */               }
/*      */               
/* 5639 */               int delta = right - screenWidth.intValue();
/* 5640 */               if (delta > 0) {
/* 5641 */                 MCPanel p2 = c3;
/* 5642 */                 if (isFitPanel(p2)) {
/* 5643 */                   int margin = p2._getRightMargin();
/* 5644 */                   int w = (p2.getPreferredSize()).width - delta - margin;
/* 5645 */                   p2.setLimitWidth(Integer.valueOf(w));
/* 5646 */                   relayout = true;
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 5655 */         boolean b2 = false;
/* 5656 */         if (b2 && !b1 && result4.size() == 3) {
/* 5657 */           int size = result4.size();
/* 5658 */           MCPanel c4 = null;
/*      */ 
/*      */           
/* 5661 */           int[] v = new int[size];
/* 5662 */           for (int i = 0; i < size; i++) {
/* 5663 */             v[i] = (((MCPanel)result4.get(i)).getPreferredSize()).width;
/*      */           }
/* 5665 */           double std = getStdValue(v);
/* 5666 */           if (std > 1.4D) {
/* 5667 */             int max = v[0]; int j;
/* 5668 */             for (j = 1; j < size; j++) {
/* 5669 */               max = Math.max(max, v[j]);
/*      */             }
/* 5671 */             for (j = 0; j < size; j++) {
/* 5672 */               if (max == v[j]) {
/* 5673 */                 c4 = result4.get(j);
/*      */               }
/*      */             } 
/*      */           } 
/*      */           
/* 5678 */           if (c4 != null) {
/* 5679 */             Container c = (Container)result4.get(0);
/* 5680 */             boolean b = true;
/* 5681 */             boolean f = false;
/* 5682 */             while (b) {
/* 5683 */               c = c.getParent();
/* 5684 */               if (c instanceof MCPanel) {
/* 5685 */                 if (countX((MCPanel)c) == 0) {
/* 5686 */                   f = true;
/* 5687 */                   b = false;
/*      */                 }  continue;
/*      */               } 
/* 5690 */               b = false;
/*      */             } 
/*      */ 
/*      */             
/* 5694 */             if (f) {
/* 5695 */               b1 = true;
/*      */               
/* 5697 */               c = c.getParent();
/*      */               
/* 5699 */               List<MCPanel> result3 = new ArrayList<>(result4);
/* 5700 */               Collections.sort(result3, new MCPanelComparator2(c));
/*      */               
/* 5702 */               MCPanel p1 = result3.get(0);
/* 5703 */               int right = _getXOnPanel((Component)p1, c);
/*      */               
/* 5705 */               for (MCPanel p2 : result3) {
/* 5706 */                 right += (p2.getPreferredSize()).width;
/*      */               }
/*      */               
/* 5709 */               int delta = right - screenWidth.intValue();
/* 5710 */               if (delta > 0) {
/* 5711 */                 MCPanel p2 = c4;
/* 5712 */                 int margin = p2._getRightMargin();
/* 5713 */                 int w = (p2.getPreferredSize()).width - delta - margin;
/* 5714 */                 p2.setLimitWidth(Integer.valueOf(w));
/* 5715 */                 relayout = true;
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */         
/* 5721 */         if (!b1) {
/* 5722 */           ArrayList<MCPanel> _limitPanel = new ArrayList<>();
/* 5723 */           int d = 0;
/*      */           
/* 5725 */           Container c = (Container)_result.get(0);
/* 5726 */           boolean b = true;
/* 5727 */           boolean f = false;
/* 5728 */           while (b) {
/* 5729 */             c = c.getParent();
/* 5730 */             if (c instanceof MCPanel) {
/* 5731 */               if (countX((MCPanel)c) == 0) {
/* 5732 */                 f = true;
/* 5733 */                 b = false;
/*      */               }  continue;
/*      */             } 
/* 5736 */             b = false;
/*      */           } 
/*      */ 
/*      */           
/* 5740 */           if (f) {
/* 5741 */             c = c.getParent();
/*      */             
/* 5743 */             List<MCPanel> result3 = new ArrayList<>(_result);
/* 5744 */             Collections.sort(result3, new MCPanelComparator2(c));
/*      */             
/* 5746 */             MCPanel p1 = result3.get(0);
/* 5747 */             int right = _getXOnPanel((Component)p1, c);
/*      */ 
/*      */             
/* 5750 */             int w2 = 0;
/* 5751 */             for (MCPanel p2 : result3) {
/* 5752 */               right += (p2.getPreferredSize()).width;
/*      */               
/* 5754 */               boolean fit = isFitPanel(p2);
/* 5755 */               if (fit) {
/* 5756 */                 w2 += (p2.getPreferredSize()).width;
/*      */               }
/*      */             } 
/*      */             
/* 5760 */             int delta = right - screenWidth.intValue();
/* 5761 */             if (delta > 0) {
/* 5762 */               for (MCPanel p2 : result3) {
/* 5763 */                 boolean fit = MCBeansUtil.getFit((MCResourceBeans)p2);
/* 5764 */                 if (fit) {
/* 5765 */                   int margin = p2._getRightMargin();
/* 5766 */                   int d1 = 
/* 5767 */                     (int)Math.ceil(delta * (p2.getPreferredSize()).width / w2);
/* 5768 */                   int w = (p2.getPreferredSize()).width - d1 - margin;
/*      */ 
/*      */                   
/* 5771 */                   p2.setLimitWidth(Integer.valueOf(w));
/* 5772 */                   relayout = true;
/*      */                   
/* 5774 */                   int limitWidth = p2._getTitlteBorderWidth();
/* 5775 */                   if (limitWidth > w) {
/* 5776 */                     _limitPanel.add(p2);
/* 5777 */                     d += limitWidth - w;
/* 5778 */                     w = limitWidth - w;
/*      */                   } 
/*      */                 } 
/*      */               } 
/*      */ 
/*      */               
/* 5784 */               int s = _limitPanel.size();
/* 5785 */               if (s > 0) {
/* 5786 */                 if (_result.size() > s) {
/* 5787 */                   int s1 = _result.size() - s;
/* 5788 */                   for (MCPanel p2 : _result) {
/* 5789 */                     if (!_limitPanel.contains(p2)) {
/* 5790 */                       int w3 = p2.getLimitWidth().intValue();
/* 5791 */                       if (w3 <= 0) {
/* 5792 */                         if (this.panel.getAutolayoutPanelWidth() != null) {
/* 5793 */                           w3 = this.panel.getAutolayoutPanelWidth().intValue();
/*      */                         } else {
/* 5795 */                           w3 = this.panel.getDefaultPanelWidth();
/*      */                         } 
/*      */                       }
/* 5798 */                       int w = w3 - d / s1;
/* 5799 */                       p2.setLimitWidth(Integer.valueOf(w));
/*      */                     } 
/*      */                   }  continue;
/*      */                 } 
/* 5803 */                 for (MCPanel p2 : _result) {
/* 5804 */                   int margin = p2._getRightMargin();
/* 5805 */                   int w = (p2.getPreferredSize()).width - delta / _result.size() + margin;
/*      */ 
/*      */                   
/* 5808 */                   p2.setLimitWidth(Integer.valueOf(w));
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 5817 */       if (relayout) {
/*      */ 
/*      */ 
/*      */         
/* 5821 */         MCPanel[] panels3 = (MCPanel[])MCBeansUtil.getAllComponents(MCPanel.class, (Container)this.panel); byte b; int i; MCPanel[] arrayOfMCPanel1;
/* 5822 */         for (i = (arrayOfMCPanel1 = panels3).length, b = 0; b < i; ) { MCPanel t = arrayOfMCPanel1[b];
/* 5823 */           t.setMinimumSize(null);
/*      */           
/*      */           b++; }
/*      */         
/* 5827 */         this._temp_panel_counter = this._temp_panel_counter_save;
/*      */         
/* 5829 */         this.panel.setDisableLayoutInit(true);
/*      */ 
/*      */         
/* 5832 */         initRelayout(this._rootSubMain);
/*      */ 
/*      */         
/* 5835 */         autoLayout.beforeLayout(true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5848 */         List<MCPanel> panels = getAllPanel((Container)this._rootSubMain);
/* 5849 */         List<MCPanel> panels2 = getAllPanel((Container)this.panel);
/* 5850 */         panels.addAll(panels2);
/* 5851 */         layout((JPanel)this._rootSubMain, panels, 0, false);
/*      */ 
/*      */ 
/*      */         
/* 5855 */         this.panel.setDisableLayoutInit(false);
/*      */ 
/*      */         
/* 5858 */         this.panel.validate();
/*      */         
/* 5860 */         this._frameOffsetH = Integer.valueOf(0);
/* 5861 */         for (List<MCPanel> result1 : this._invalidPanelList) {
/* 5862 */           int h = 0;
/* 5863 */           for (MCPanel p : result1) {
/* 5864 */             int h1 = ((Integer)this._panelHeightMap.get(p)).intValue();
/* 5865 */             int h2 = (p.getPreferredSize()).height;
/*      */             
/* 5867 */             h = Math.max(h, h2 - h1);
/*      */           } 
/* 5869 */           if (h > 0) {
/* 5870 */             this._frameOffsetH = Integer.valueOf(this._frameOffsetH.intValue() + h);
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 5876 */     this._panelHeightMap = null;
/* 5877 */     this._invalidPanelList = null; }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   double getStdValue(int[] n) {
/* 5883 */     double sum = 0.0D;
/* 5884 */     double vars = 0.0D;
/* 5885 */     double[] data = { 1.0D, 2.0D, 3.0D, 4.0D, 5.0D };
/* 5886 */     for (int i = 0; i < data.length; i++) {
/* 5887 */       sum += data[i];
/*      */     }
/* 5889 */     double ave = sum / data.length;
/* 5890 */     for (int j = 0; j < data.length; j++) {
/* 5891 */       vars += (data[j] - ave) * (data[j] - ave);
/*      */     }
/* 5893 */     double std = Math.sqrt(vars / data.length);
/* 5894 */     return std;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isFitPanel(MCPanel p) {
/* 5900 */     boolean fit = MCBeansUtil.getFit((MCResourceBeans)p);
/* 5901 */     return fit;
/*      */   }
/*      */ 
/*      */   
/*      */   int _getXOnPanel(Component c, Container p) {
/* 5906 */     Container parent = p;
/*      */     
/* 5908 */     int pt2x = c.getX();
/* 5909 */     Container c2 = c.getParent();
/* 5910 */     if (c2 == parent) {
/* 5911 */       pt2x += c2.getX();
/* 5912 */       return pt2x;
/*      */     } 
/*      */     
/* 5915 */     while (c2 != null && c2 != parent) {
/* 5916 */       pt2x += c2.getX();
/* 5917 */       c2 = c2.getParent();
/*      */     } 
/* 5919 */     return pt2x;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isUsePanelLimitWidth() {
/* 5926 */     String[] keys = new String[2];
/* 5927 */     keys[0] = "autoLayout";
/* 5928 */     keys[1] = "usePanelLimitWidth";
/* 5929 */     String k = MCResource.createKey(keys);
/* 5930 */     if (MCConst.layout.containsKey(k)) {
/* 5931 */       String s = MCConst.layout.getString(k);
/* 5932 */       if ("true".equals(s))
/* 5933 */         return true; 
/* 5934 */       if ("false".equals(s)) {
/* 5935 */         return false;
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5943 */     if (MCSys.user.locale().getLanguage().equals(Locale.JAPANESE.getLanguage())) {
/* 5944 */       return false;
/*      */     }
/* 5946 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isUseAdjustFrameSize() {
/* 5953 */     String[] keys = new String[2];
/* 5954 */     keys[0] = "autoLayout";
/* 5955 */     keys[1] = "useAdjustFrameSize";
/* 5956 */     String k = MCResource.createKey(keys);
/* 5957 */     if (MCConst.layout.containsKey(k)) {
/* 5958 */       String s = MCConst.layout.getString(k);
/* 5959 */       if ("true".equals(s))
/* 5960 */         return true; 
/* 5961 */       if ("false".equals(s)) {
/* 5962 */         return false;
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5970 */     if (MCSys.user.locale().getLanguage().equals(Locale.JAPANESE.getLanguage())) {
/* 5971 */       return false;
/*      */     }
/* 5973 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isUseAdjustExpandPanelSize() {
/* 5981 */     String[] keys = new String[2];
/* 5982 */     keys[0] = "autoLayout";
/* 5983 */     keys[1] = "useAdjustExpandPanelSize";
/* 5984 */     String k = MCResource.createKey(keys);
/* 5985 */     if (MCConst.layout.containsKey(k)) {
/* 5986 */       String s = MCConst.layout.getString(k);
/* 5987 */       if ("true".equals(s))
/* 5988 */         return true; 
/* 5989 */       if ("false".equals(s)) {
/* 5990 */         return false;
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5998 */     if (MCSys.user.locale().getLanguage().equals(Locale.JAPANESE.getLanguage())) {
/* 5999 */       return false;
/*      */     }
/* 6001 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean useChangeScreenHeight() {
/* 6010 */     String[] keys = new String[2];
/* 6011 */     keys[0] = "autoLayout";
/* 6012 */     keys[1] = "useChangeScreenHeight";
/* 6013 */     String k = MCResource.createKey(keys);
/* 6014 */     if (MCConst.layout.containsKey(k)) {
/* 6015 */       String s = MCConst.layout.getString(k);
/* 6016 */       if ("true".equals(s))
/* 6017 */         return true; 
/* 6018 */       if ("false".equals(s)) {
/* 6019 */         return false;
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6027 */     if (MCSys.user.locale().getLanguage().equals(Locale.JAPANESE.getLanguage())) {
/* 6028 */       return false;
/*      */     }
/* 6030 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean useShrinkLabelWidth() {
/* 6037 */     String[] keys = new String[2];
/* 6038 */     keys[0] = "autoLayout";
/* 6039 */     keys[1] = "useShrinkLabelWidth";
/* 6040 */     String k = MCResource.createKey(keys);
/* 6041 */     if (MCConst.layout.containsKey(k)) {
/* 6042 */       String s = MCConst.layout.getString(k);
/* 6043 */       if ("true".equals(s))
/* 6044 */         return true; 
/* 6045 */       if ("false".equals(s)) {
/* 6046 */         return false;
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6054 */     if (MCSys.user.locale().getLanguage().equals(Locale.JAPANESE.getLanguage())) {
/* 6055 */       return false;
/*      */     }
/* 6057 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void addScrollOPaneIntoTabbedPane(MCRootPanel rp, MCAutoLayout autoLayout) {
/* 6066 */     if (!useScrollPane(rp)) {
/*      */       return;
/*      */     }
/*      */     
/* 6070 */     MCTabbedPane[] tabs = (MCTabbedPane[])MCBeansUtil.getAllComponents(MCTabbedPane.class, (Container)rp); byte b; int i; MCTabbedPane[] arrayOfMCTabbedPane1;
/* 6071 */     for (i = (arrayOfMCTabbedPane1 = tabs).length, b = 0; b < i; ) { MCTabbedPane t = arrayOfMCTabbedPane1[b];
/* 6072 */       if (t.getParent() instanceof MCPanel) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 6078 */         Boolean bool = autoLayout.getLocalizedTabbedPane(rp, t);
/* 6079 */         if (bool != null && bool.booleanValue()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 6125 */           MCScrollPane sc = new MCScrollPane(String.valueOf(t.getName()) + ".scroll");
/* 6126 */           sc.setLocation(t.getLocation());
/* 6127 */           t.setLocation(0, 0);
/* 6128 */           sc.setPreferredSize(t.getPreferredSize());
/* 6129 */           sc.setSize(t.getSize());
/* 6130 */           sc.setMinimumSize(t.getMinimumSize());
/* 6131 */           sc.setMaximumSize(t.getMaximumSize());
/*      */           
/* 6133 */           Container p = t.getParent();
/* 6134 */           p.remove((Component)t);
/* 6135 */           sc.setViewportView((Component)t);
/* 6136 */           p.add((Component)sc);
/*      */         } 
/*      */       } 
/*      */       b++; }
/*      */   
/*      */   }
/*      */ 
/*      */   
/*      */   void addScrollOPaneIntoTabbedPaneForRelayout(MCRootPanel rp, MCAutoLayout autoLayout) {
/* 6145 */     if (!useScrollPane(rp)) {
/*      */       return;
/*      */     }
/*      */     
/* 6149 */     MCTabbedPane[] tabs = (MCTabbedPane[])MCBeansUtil.getAllComponents(MCTabbedPane.class, (Container)rp); byte b; int i; MCTabbedPane[] arrayOfMCTabbedPane1;
/* 6150 */     for (i = (arrayOfMCTabbedPane1 = tabs).length, b = 0; b < i; ) { MCTabbedPane t = arrayOfMCTabbedPane1[b];
/* 6151 */       if (t.getParent() instanceof javax.swing.JViewport) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 6157 */         Boolean bool = autoLayout.getLocalizedTabbedPane(rp, t);
/* 6158 */         if (bool != null && bool.booleanValue()) {
/*      */ 
/*      */ 
/*      */           
/* 6162 */           MCScrollPane sc = (MCScrollPane)t.getParent().getParent();
/*      */           
/* 6164 */           if (sc.getParent().getLayout() instanceof MCBorderLayout) {
/* 6165 */             MCBorderLayout bd = (MCBorderLayout)sc.getParent().getLayout();
/* 6166 */             bd.addLayoutComponent((Component)sc, "Center");
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       b++; }
/*      */   
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   void _addScrollOPaneIntoTabbedPane(MCRootPanel rp) {
/* 6177 */     if (!useScrollPane(rp)) {
/*      */       return;
/*      */     }
/*      */     
/* 6181 */     MCTabbedPane[] tabs = (MCTabbedPane[])MCBeansUtil.getAllComponents(MCTabbedPane.class, (Container)rp); byte b; int i; MCTabbedPane[] arrayOfMCTabbedPane1;
/* 6182 */     for (i = (arrayOfMCTabbedPane1 = tabs).length, b = 0; b < i; ) { MCTabbedPane t = arrayOfMCTabbedPane1[b];
/* 6183 */       if (t.getParent() instanceof MCPanel)
/*      */       {
/*      */         
/* 6186 */         if (!(t.getParent().getParent() instanceof javax.swing.JViewport)) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 6191 */           int count = t.getTabCount();
/* 6192 */           int h = 0;
/* 6193 */           for (int j = 0; j < count; j++) {
/* 6194 */             int h1 = (t.getComponentAt(j).getPreferredSize()).height;
/* 6195 */             h = Math.max(h, h1);
/*      */           } 
/*      */           
/* 6198 */           Container c2 = t.getParent();
/* 6199 */           LayoutManager lm = c2.getLayout();
/* 6200 */           if (lm instanceof MCBorderLayout) {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 6205 */             MCBorderLayout bl = (MCBorderLayout)lm;
/* 6206 */             String cons = null;
/* 6207 */             if (bl.getLayoutComponent("Center") == t) {
/* 6208 */               cons = "Center";
/* 6209 */             } else if (bl.getLayoutComponent("North") == t) {
/* 6210 */               cons = "North";
/* 6211 */             } else if (bl.getLayoutComponent("South") == t) {
/* 6212 */               cons = "South";
/* 6213 */             } else if (bl.getLayoutComponent("East") == t) {
/* 6214 */               cons = "East";
/* 6215 */             } else if (bl.getLayoutComponent("West") == t) {
/* 6216 */               cons = "West";
/*      */             } 
/*      */             
/* 6219 */             c2.remove((Component)t);
/* 6220 */             MCScrollPane sc = new MCScrollPane(String.valueOf(t.getName()) + ".scroll");
/* 6221 */             sc.setLocation(t.getLocation());
/* 6222 */             t.setLocation(0, 0);
/* 6223 */             sc.setViewportView((Component)t);
/* 6224 */             c2.add((Component)sc, cons);
/*      */           } 
/*      */         }  } 
/*      */       b++; }
/*      */   
/*      */   }
/*      */   boolean useScrollPane(MCRootPanel rp) {
/* 6231 */     boolean b = (new MCAutoLayout()).useScrollPane(rp);
/* 6232 */     return b;
/*      */   }
/*      */ 
/*      */   
/*      */   boolean usePrefSize(MCRootPanel rp) {
/* 6237 */     boolean b = (new MCAutoLayout()).usePrefSize(rp);
/* 6238 */     return b;
/*      */   }
/*      */ 
/*      */   
/*      */   boolean useAdjustHeight(MCRootPanel rp) {
/* 6243 */     boolean b = (new MCAutoLayout()).useAdjustHeight(rp);
/* 6244 */     return b;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void loadResourceForLocalize() {
/* 6250 */     MCLayoutSettingsR r = (new MCAutoLayout()).getPersonalizeSettings(this.panel);
/* 6251 */     if (r != null) {
/* 6252 */       Integer screenWidth = r.screenWidth();
/* 6253 */       if (screenWidth != null) {
/* 6254 */         MCBeansProxy.PROXY.setAutolayoutScreenWidth(this.panel, screenWidth.intValue());
/*      */       }
/* 6256 */       Integer screenHeight = r.screenHeight();
/* 6257 */       if (screenHeight != null) {
/* 6258 */         MCBeansProxy.PROXY.setAutolayoutScreenHeight(this.panel, screenHeight.intValue());
/*      */       }
/* 6260 */       Integer panelWidth = r.panelWidth();
/* 6261 */       if (panelWidth != null) {
/* 6262 */         MCBeansProxy.PROXY.setAutolayoutPanelWidth(this.panel, panelWidth.intValue());
/*      */       }
/* 6264 */       Integer panelHeight = r.panelHeight();
/* 6265 */       if (panelHeight != null) {
/* 6266 */         MCBeansProxy.PROXY.setAutolayoutPanelHeight(this.panel, panelHeight.intValue());
/*      */       }
/* 6268 */       Integer panelPrefWidth = r.panelPrefWidth();
/* 6269 */       if (panelPrefWidth != null) {
/* 6270 */         MCBeansProxy.PROXY.setAutolayoutPanelPrefWidth(this.panel, panelPrefWidth.intValue());
/*      */       }
/* 6272 */       Integer panelPrefHeight = r.panelPrefHeight();
/* 6273 */       if (panelPrefHeight != null)
/* 6274 */         MCBeansProxy.PROXY.setAutolayoutPanelPrefHeight(this.panel, panelPrefHeight.intValue()); 
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\layout\MCGeneralLayout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */