/*    */ package mcframe.clientCore.beans.layout;
/*    */ 
/*    */ import java.awt.BorderLayout;
/*    */ import java.awt.Container;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCBorderLayout
/*    */   extends BorderLayout
/*    */ {
/*    */   private final MCLayout _layout;
/*    */   
/*    */   public MCBorderLayout(MCLayout layout) {
/* 42 */     this._layout = layout;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MCBorderLayout(MCLayout layout, int hgap, int vgap) {
/* 55 */     super(hgap, vgap);
/* 56 */     this._layout = layout;
/*    */   }
/*    */ 
/*    */   
/*    */   public void layoutContainer(Container target) {
/* 61 */     super.layoutContainer(target);
/* 62 */     if (target instanceof mcframe.clientCore.beans.MCRootPanel) {
/* 63 */       this._layout.sizeChanged();
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void relayout(boolean useLayoutLocationForSortPolicy) {
/* 76 */     if (this._layout instanceof MCGeneralLayout) {
/* 77 */       ((MCGeneralLayout)this._layout).relayout(useLayoutLocationForSortPolicy);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void beforeRelayout() {
/* 87 */     if (this._layout instanceof MCGeneralLayout) {
/* 88 */       ((MCGeneralLayout)this._layout).beforeRelayout();
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MCLayout getLayout() {
/* 98 */     return this._layout;
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\layout\MCBorderLayout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */