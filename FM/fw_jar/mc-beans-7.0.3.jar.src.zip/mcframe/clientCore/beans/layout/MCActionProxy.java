/*    */ package mcframe.clientCore.beans.layout;
/*    */ 
/*    */ import mcframe.clientCore.beans.action.AbsMCPackageProxy;
/*    */ import mcframe.clientCore.beans.action.MCFunctionKey;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCActionProxy
/*    */   extends AbsMCPackageProxy
/*    */ {
/* 14 */   static final MCActionProxy PROXY = new MCActionProxy();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected MCFunctionKey getF10() {
/* 21 */     return super.getF10();
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\layout\MCActionProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */