/*     */ package mcframe.clientCore.beans.layout;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.File;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Paths;
/*     */ import java.util.Arrays;
/*     */ import javax.swing.JViewport;
/*     */ import mcframe.clientCore.beans.MCPanel;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.sys.MCSys;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCLayoutDump
/*     */ {
/*  28 */   public static String dir = "c:\\temp\\layout_dump2";
/*     */   
/*     */   private StringBuilder buf;
/*     */   
/*     */   public void doDump(MCRootPanel rp) {
/*  33 */     rp.validate();
/*     */     
/*  35 */     String moduleid = rp.getModuleID();
/*  36 */     String screenid = rp.getScreenID();
/*  37 */     String localeID = MCSys.user.locale().toString();
/*     */     
/*  39 */     String d = String.valueOf(dir) + "\\" + localeID;
/*  40 */     if (!(new File(d)).exists()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  45 */     String f = String.valueOf(dir) + "\\" + localeID + "\\" + moduleid + "_" + screenid + "_dump.txt";
/*  46 */     dumpRootPanel(rp, String.valueOf(moduleid) + "." + screenid, f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean doCompare(MCRootPanel rp) {
/*  54 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean fileCompare(String fileA, String fileB) {
/*  94 */     boolean bRet = false;
/*     */     try {
/*  96 */       if ((new File(fileA)).length() != (new File(fileA)).length()) {
/*  97 */         return bRet;
/*     */       }
/*  99 */       byte[] byteA = Files.readAllBytes(Paths.get(fileA, new String[0]));
/* 100 */       byte[] byteB = Files.readAllBytes(Paths.get(fileB, new String[0]));
/* 101 */       bRet = Arrays.equals(byteA, byteB);
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 106 */     catch (IOException iOException) {}
/*     */     
/* 108 */     return bRet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dumpRootPanel(MCRootPanel rp, String lbl, String f) {
/* 115 */     this.buf = new StringBuilder();
/* 116 */     this.buf.append(System.lineSeparator());
/* 117 */     this.buf.append(lbl);
/* 118 */     this.buf.append(System.lineSeparator());
/* 119 */     _debugPrint(lbl, (Container)rp, 0);
/*     */ 
/*     */     
/*     */     try {
/* 123 */       FileWriter file = new FileWriter(f);
/*     */       
/* 125 */       PrintWriter pw = new PrintWriter(new BufferedWriter(file));
/*     */ 
/*     */       
/* 128 */       pw.println(this.buf.toString());
/*     */ 
/*     */       
/* 131 */       pw.close();
/* 132 */     } catch (IOException e) {
/* 133 */       e.printStackTrace();
/*     */     } 
/*     */     
/* 136 */     this.buf = null;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean _showBounds = true;
/*     */   
/*     */   private boolean _showPrefSize = false;
/*     */   
/*     */   private void _debugPrint(String lbl, Container p, int lvl) {
/* 145 */     if (p == null) {
/*     */       return;
/*     */     }
/*     */     
/* 149 */     if ("_headerbar".equals(p.getName())) {
/*     */       return;
/*     */     }
/* 152 */     if ("FCBEBBASE".equals(p.getName())) {
/*     */       return;
/*     */     }
/* 155 */     if ("_tbarScroll".equals(p.getName())) {
/*     */       return;
/*     */     }
/*     */     
/* 159 */     String s = "";
/* 160 */     for (int n = 0; n < lvl; n++) {
/* 161 */       this.buf.append(" ");
/*     */     }
/*     */     
/* 164 */     if (p instanceof MCPanel) {
/* 165 */       String pos = "";
/* 166 */       if (p.getLayout() instanceof javax.swing.BoxLayout) {
/* 167 */         pos = p.getLayout().getClass().getName();
/* 168 */       } else if (p.getLayout() == null) {
/* 169 */         pos = "null";
/*     */       } else {
/* 171 */         pos = p.getLayout().toString();
/*     */       } 
/* 173 */       this.buf.append(String.valueOf(s) + lvl + " " + p.getName());
/* 174 */       if (this._showBounds) {
/* 175 */         if (this._showPrefSize) {
/* 176 */           this.buf.append(" (" + p.getX() + "," + p.getY() + "," + p.getWidth() + "," + p.getHeight() + "," + 
/* 177 */               p.getPreferredSize().getWidth() + "," + p.getPreferredSize().getHeight() + ")");
/*     */         } else {
/* 179 */           this.buf.append(" (" + p.getX() + "," + p.getY() + "," + p.getWidth() + "," + p.getHeight() + ")");
/*     */         } 
/*     */       }
/* 182 */       this.buf.append(" " + ((MCPanel)p).getLayoutPosition() + " " + pos + " MCPanel");
/* 183 */       this.buf.append(" " + p.isVisible());
/* 184 */       this.buf.append(System.lineSeparator());
/* 185 */     } else if (p instanceof MCRootPanel) {
/* 186 */       String pos = "";
/* 187 */       if (p.getLayout() instanceof javax.swing.BoxLayout) {
/* 188 */         pos = p.getLayout().getClass().getName();
/* 189 */       } else if (p.getLayout() == null) {
/* 190 */         pos = "null";
/*     */       } else {
/* 192 */         pos = p.getLayout().toString();
/*     */       } 
/* 194 */       this.buf.append(String.valueOf(s) + lvl + " " + p.getName());
/* 195 */       if (this._showBounds) {
/* 196 */         if (this._showPrefSize) {
/* 197 */           this.buf.append(" (" + p.getX() + "," + p.getY() + "," + p.getWidth() + "," + p.getHeight() + "," + 
/* 198 */               p.getPreferredSize().getWidth() + "," + p.getPreferredSize().getHeight() + ")");
/*     */         } else {
/* 200 */           this.buf.append(" (" + p.getX() + "," + p.getY() + "," + p.getWidth() + "," + p.getHeight() + ")");
/*     */         } 
/*     */       }
/* 203 */       this.buf.append(" " + pos + " MCRootPanel");
/* 204 */       this.buf.append(" " + p.isVisible());
/* 205 */       this.buf.append(System.lineSeparator());
/*     */     } else {
/* 207 */       this.buf.append(String.valueOf(s) + lvl + " " + p.getName());
/* 208 */       if (this._showBounds) {
/* 209 */         if (this._showPrefSize) {
/* 210 */           this.buf.append(" (" + p.getX() + "," + p.getY() + "," + p.getWidth() + "," + p.getHeight() + "," + 
/* 211 */               p.getPreferredSize().getWidth() + "," + p.getPreferredSize().getHeight() + ")");
/*     */         } else {
/* 213 */           this.buf.append(" (" + p.getX() + "," + p.getY() + "," + p.getWidth() + "," + p.getHeight() + ")");
/*     */         } 
/*     */       }
/* 216 */       this.buf.append(" " + p.getClass().getName());
/* 217 */       this.buf.append(" " + p.isVisible());
/* 218 */       this.buf.append(System.lineSeparator());
/*     */     }  byte b; int i;
/*     */     Component[] arrayOfComponent;
/* 221 */     for (i = (arrayOfComponent = p.getComponents()).length, b = 0; b < i; ) { Component c = arrayOfComponent[b];
/* 222 */       if (c instanceof MCPanel) {
/* 223 */         _debugPrint(lbl, (Container)c, lvl + 1);
/* 224 */       } else if (c instanceof MCRootPanel) {
/* 225 */         _debugPrint(lbl, (Container)c, lvl + 1);
/* 226 */       } else if (c instanceof mcframe.clientCore.beans.MCSplitPane) {
/* 227 */         _debugPrint(lbl, (Container)c, lvl + 1);
/* 228 */       } else if (c instanceof mcframe.clientCore.beans.MCTabbedPane) {
/* 229 */         _debugPrint(lbl, (Container)c, lvl + 1);
/* 230 */       } else if (c instanceof mcframe.clientCore.beans.MCScrollPane) {
/* 231 */         _debugPrint(lbl, (Container)c, lvl + 1);
/* 232 */       } else if (c instanceof mcframe.clientCore.beans.tree.MCTree64) {
/* 233 */         _debugPrint(lbl, (Container)c, lvl + 1);
/* 234 */       } else if (c instanceof JViewport) {
/* 235 */         _debugPrint(lbl, (JViewport)c, lvl + 1);
/*     */       } 
/*     */       b++; }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\layout\MCLayoutDump.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */