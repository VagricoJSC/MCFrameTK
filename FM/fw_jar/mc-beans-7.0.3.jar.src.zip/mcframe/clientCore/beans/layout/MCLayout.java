package mcframe.clientCore.beans.layout;

import java.awt.Insets;
import java.util.List;
import mcframe.clientCore.beans.MCPanel;

public interface MCLayout {
  void layout();
  
  void sizeChanged();
  
  void fontRatioChange(MCLayoutEventInfo paramMCLayoutEventInfo);
  
  void initialized();
  
  void tableSizeChange(MCLayoutEventInfo paramMCLayoutEventInfo);
  
  void tableSizeDefault();
  
  List<MCPanel> getZoomablePanels();
  
  boolean updateMargin();
  
  Insets getMargin();
  
  void setMargin(Insets paramInsets);
  
  void resetMargin();
  
  void beforeRelayout();
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\layout\MCLayout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */