/*    */ package mcframe.clientCore.beans.layout;
/*    */ 
/*    */ import java.awt.Rectangle;
/*    */ import mcframe.clientCore.beans.MCPanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCHeaderBarPanel
/*    */   extends MCPanel
/*    */ {
/*    */   private boolean _is_headerbar;
/*    */   private int _ratio;
/*    */   
/*    */   public MCHeaderBarPanel(String name) {
/* 20 */     super(name);
/*    */ 
/*    */     
/* 23 */     this._is_headerbar = false;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 50 */     this._ratio = 100;
/*    */   }
/*    */   public void setHeaderBar(boolean b) {
/*    */     this._is_headerbar = b;
/* 54 */   } public void updateBounds(int ratio) { if (isShowing()) {
/* 55 */       updateDefaultBounds(this._ratio);
/*    */     }
/*    */     
/* 58 */     this._ratio = ratio;
/* 59 */     super.updateBounds(ratio);
/* 60 */     updateDefaultBounds(ratio);
/*    */     
/* 62 */     updatePreferredSize(); }
/*    */   public void setBounds(int x, int y, int width, int height) { super.setBounds(x, y, width, height); if (isShowing())
/*    */       updateDefaultBounds(this._ratio); 
/*    */     updatePreferredSize(); }
/* 66 */   public void setDefaultRatioSize(Rectangle r) { super.setDefaultRatioSize(r); } protected void updatePreferredSize() { if (getLayout() instanceof javax.swing.BoxLayout) {
/* 67 */       if (this._is_headerbar) {
/* 68 */         setPreferredSize(null);
/*    */       } else {
/* 70 */         setPreferredSize(getSize());
/*    */       } 
/*    */     } else {
/* 73 */       setPreferredSize(null);
/*    */     }  }
/*    */ 
/*    */   
/*    */   protected void updateDefaultBounds(int ratio) {
/* 78 */     Rectangle r1 = getBounds();
/* 79 */     Rectangle r2 = new Rectangle(r1);
/* 80 */     r2.x = (int)Math.ceil(r2.x * 100.0D / ratio);
/* 81 */     r2.y = (int)Math.ceil(r2.y * 100.0D / ratio);
/* 82 */     r2.width = (int)Math.ceil(r2.width * 100.0D / ratio);
/* 83 */     r2.height = (int)Math.ceil(r2.height * 100.0D / ratio);
/* 84 */     setDefaultRatioSize(r2);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\layout\MCHeaderBarPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */