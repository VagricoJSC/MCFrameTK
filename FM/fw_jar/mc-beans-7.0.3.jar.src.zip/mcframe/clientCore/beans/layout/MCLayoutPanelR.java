/*     */ package mcframe.clientCore.beans.layout;
/*     */ 
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCLayoutPanelR
/*     */ {
/*     */   public String panelID;
/*     */   public String layoutPosition;
/*     */   public int sequence;
/*     */   public int layoutY;
/*     */   public String parentPanelID;
/*     */   public String rootPanelID;
/*     */   protected Integer limitWidth;
/*     */   protected boolean isLimitWidth;
/*     */   protected Boolean localeFit;
/*     */   protected boolean isLocaleFit;
/*     */   
/*     */   public String panelID() {
/*  35 */     return this.panelID;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void panelID(String string) {
/*  43 */     this.panelID = string;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String layoutPosition() {
/*  51 */     return this.layoutPosition;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void layoutPosition(String string) {
/*  59 */     this.layoutPosition = string;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer sequence() {
/*  67 */     return Integer.valueOf(this.sequence);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sequence(Integer number) {
/*  75 */     this.sequence = number.intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sequence(MCNumber number) {
/*  83 */     if (number == null) {
/*  84 */       this.sequence = 0;
/*     */     } else {
/*     */       
/*  87 */       this.sequence = number.intValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String parentPanelID() {
/*  96 */     if (this.parentPanelID == null) {
/*  97 */       return "";
/*     */     }
/*  99 */     return this.parentPanelID;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void parentPanelID(String string) {
/* 107 */     this.parentPanelID = string;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String rootPanelID() {
/* 115 */     if (this.rootPanelID == null) {
/* 116 */       return "";
/*     */     }
/* 118 */     return this.rootPanelID;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rootPanelID(String string) {
/* 126 */     this.rootPanelID = string;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer layoutY() {
/* 134 */     return Integer.valueOf(this.layoutY);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void layoutY(Integer number) {
/* 142 */     this.layoutY = number.intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void layoutY(MCNumber number) {
/* 150 */     if (number == null) {
/* 151 */       this.layoutY = 0;
/*     */     } else {
/*     */       
/* 154 */       this.layoutY = number.intValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCLayoutPanelR clone() {
/* 162 */     MCLayoutPanelR clone = new MCLayoutPanelR();
/* 163 */     clone.panelID = panelID();
/* 164 */     clone.layoutPosition = layoutPosition();
/* 165 */     clone.sequence = sequence().intValue();
/* 166 */     clone.layoutY = layoutY().intValue();
/* 167 */     clone.parentPanelID = parentPanelID();
/* 168 */     clone.rootPanelID = rootPanelID();
/*     */ 
/*     */     
/* 171 */     clone.limitWidth = limitWidth();
/* 172 */     clone.isLimitWidth = isLimitWidth();
/* 173 */     clone.localeFit = localeFit();
/* 174 */     clone.isLocaleFit = isLocaleFit();
/*     */ 
/*     */     
/* 177 */     return clone;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 182 */     return this.panelID + "," + this.layoutPosition + "," + this.sequence + "," + this.layoutY + "," + 
/* 183 */       this.parentPanelID + "," + this.rootPanelID + 
/*     */       
/* 185 */       "," + this.limitWidth + 
/* 186 */       "," + this.localeFit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equalsID(MCLayoutPanelR r) {
/* 196 */     if (!r.panelID().equals(panelID())) {
/* 197 */       return false;
/*     */     }
/* 199 */     if (!r.parentPanelID().equals(parentPanelID())) {
/* 200 */       return false;
/*     */     }
/* 202 */     if (!r.rootPanelID().equals(rootPanelID())) {
/* 203 */       return false;
/*     */     }
/* 205 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer limitWidth() {
/* 227 */     return this.limitWidth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void limitWidth(Integer n) {
/* 235 */     this.limitWidth = n;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean localeFit() {
/* 244 */     return this.localeFit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void localeFit(Boolean n) {
/* 252 */     this.localeFit = n;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLimitWidth() {
/* 261 */     return this.isLimitWidth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void isLimitWidth(boolean b) {
/* 269 */     this.isLimitWidth = b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLocaleFit() {
/* 278 */     return this.isLocaleFit;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void isLocaleFit(boolean b) {
/* 286 */     this.isLocaleFit = b;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\layout\MCLayoutPanelR.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */