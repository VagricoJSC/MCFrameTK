/*     */ package mcframe.clientCore.beans.layout;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCLayoutSettingsR
/*     */ {
/*     */   protected Integer screenWidth;
/*     */   protected Integer screenHeight;
/*     */   protected Integer panelWidth;
/*     */   protected Integer panelHeight;
/*     */   protected Integer panelPrefWidth;
/*     */   protected Integer panelPrefHeight;
/*     */   protected Boolean useScrollButton;
/*     */   protected Boolean useScrollPane;
/*     */   protected Boolean usePrefSize;
/*     */   protected Boolean useAdjustHeight;
/*     */   
/*     */   public Integer screenWidth() {
/*  52 */     return this.screenWidth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void screenWidth(Integer number) {
/*  60 */     this.screenWidth = number;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer screenHeight() {
/*  69 */     return this.screenHeight;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void screenHeight(Integer number) {
/*  77 */     this.screenHeight = number;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer panelWidth() {
/*  86 */     return this.panelWidth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void panelWidth(Integer number) {
/*  94 */     this.panelWidth = number;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer panelHeight() {
/* 103 */     return this.panelHeight;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void panelHeight(Integer number) {
/* 111 */     this.panelHeight = number;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer panelPrefWidth() {
/* 120 */     return this.panelPrefWidth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void panelPrefWidth(Integer number) {
/* 128 */     this.panelPrefWidth = number;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer panelPrefHeight() {
/* 137 */     return this.panelPrefHeight;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void panelPrefHeight(Integer number) {
/* 145 */     this.panelPrefHeight = number;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean useScrollButton() {
/* 154 */     return this.useScrollButton;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void useScrollButton(Boolean b) {
/* 162 */     this.useScrollButton = b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean useScrollPane() {
/* 171 */     return this.useScrollPane;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void useScrollPane(Boolean b) {
/* 179 */     this.useScrollPane = b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean usePrefSize() {
/* 188 */     return this.usePrefSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void usePrefSize(Boolean b) {
/* 196 */     this.usePrefSize = b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean useAdjustHeight() {
/* 205 */     return this.useAdjustHeight;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void useAdjustHeight(Boolean b) {
/* 213 */     this.useAdjustHeight = b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCLayoutSettingsR clone() {
/* 221 */     MCLayoutSettingsR clone = new MCLayoutSettingsR();
/* 222 */     clone.screenWidth = screenWidth();
/* 223 */     clone.screenHeight = screenHeight();
/* 224 */     clone.panelWidth = panelWidth();
/* 225 */     clone.panelHeight = panelHeight();
/* 226 */     clone.panelPrefWidth = panelPrefWidth();
/* 227 */     clone.panelPrefHeight = panelPrefHeight();
/* 228 */     clone.useScrollButton = useScrollButton();
/*     */     
/* 230 */     clone.usePrefSize = usePrefSize();
/* 231 */     clone.useAdjustHeight = useAdjustHeight();
/* 232 */     return clone;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\layout\MCLayoutSettingsR.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */