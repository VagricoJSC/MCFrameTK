/*      */ package mcframe.clientCore.beans.layout;
/*      */ 
/*      */ import java.awt.Component;
/*      */ import java.awt.Container;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Font;
/*      */ import java.awt.Insets;
/*      */ import java.awt.LayoutManager;
/*      */ import java.awt.Point;
/*      */ import java.awt.Rectangle;
/*      */ import java.io.File;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.Comparator;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import javax.swing.Icon;
/*      */ import javax.swing.JViewport;
/*      */ import javax.swing.border.Border;
/*      */ import mcframe.clientCore.acl.MCACLManager;
/*      */ import mcframe.clientCore.beans.MCBeansCompatibilityFactory;
/*      */ import mcframe.clientCore.beans.MCBeansUtil;
/*      */ import mcframe.clientCore.beans.MCButton;
/*      */ import mcframe.clientCore.beans.MCButtonGroup;
/*      */ import mcframe.clientCore.beans.MCCalendarField;
/*      */ import mcframe.clientCore.beans.MCCanvas;
/*      */ import mcframe.clientCore.beans.MCCheckBox;
/*      */ import mcframe.clientCore.beans.MCField;
/*      */ import mcframe.clientCore.beans.MCImageView;
/*      */ import mcframe.clientCore.beans.MCLabel;
/*      */ import mcframe.clientCore.beans.MCLayouter;
/*      */ import mcframe.clientCore.beans.MCModeBeans;
/*      */ import mcframe.clientCore.beans.MCPanel;
/*      */ import mcframe.clientCore.beans.MCPasswordField;
/*      */ import mcframe.clientCore.beans.MCProgressBar;
/*      */ import mcframe.clientCore.beans.MCRadioButton;
/*      */ import mcframe.clientCore.beans.MCResourceBeans;
/*      */ import mcframe.clientCore.beans.MCRootPanel;
/*      */ import mcframe.clientCore.beans.MCScrollPane;
/*      */ import mcframe.clientCore.beans.MCSplitPane;
/*      */ import mcframe.clientCore.beans.MCTabOrderBeans;
/*      */ import mcframe.clientCore.beans.MCTabbedPane;
/*      */ import mcframe.clientCore.beans.MCTextArea;
/*      */ import mcframe.clientCore.beans.MCTitledBorder;
/*      */ import mcframe.clientCore.beans.combobox.AbsMCComboBox;
/*      */ import mcframe.clientCore.beans.combobox.MCFieldComboBox;
/*      */ import mcframe.clientCore.beans.resource.MCPersonalizeGroupInfo;
/*      */ import mcframe.clientCore.beans.table.MCColumnConfig;
/*      */ import mcframe.clientCore.beans.table.MCTable;
/*      */ import mcframe.clientCore.beans.text.MCCalendarFormat;
/*      */ import mcframe.clientCore.resource.MCConfig;
/*      */ import mcframe.clientCore.resource.MCConst;
/*      */ import mcframe.clientCore.resource.ctrl.MCGeneralPersonalizeResource;
/*      */ import mcframe.clientCore.sys.MCSys;
/*      */ import mcframe.commonCore.lang.MCCalendarDate;
/*      */ import mcframe.commonCore.lang.MCDate;
/*      */ import mcframe.commonCore.lang.MCStringUtil;
/*      */ import mcframe.commonCore.resource.ctrl.MCCustomResource;
/*      */ import mcframe.commonCore.resource.ctrl.MCResourceLayerType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MCAutoLayout
/*      */ {
/*      */   public static final String textComboFieldName = "mcframe.clientCore.beans.combobox.MCTextComboBox$MCTextComboField";
/*      */   public static final String numberComboFieldName = "mcframe.clientCore.beans.combobox.MCNumberComboBox$MCNumberComboField";
/*      */   public static final String dateComboFieldName = "mcframe.clientCore.beans.combobox.MCDateComboBox$MCDateComboField";
/*      */   public static final String timestampComboFieldName = "mcframe.clientCore.beans.combobox.MCTimestampComboBox$MCTimestampComboField";
/*      */   public static final String comboButtonName = "mcframe.clientCore.beans.combobox.MCComboButton";
/*      */   private static final String _topPanelName = "_";
/*      */   private static final String _inputContainerPanelName = "_input_container_is";
/*      */   private static final String _input_btn_is = "_imput_btn_is";
/*      */   protected static final int _spacerWidth_2 = 10;
/*      */   protected static final int _spacerWidth_4 = 5;
/*      */   protected static final int _spacerWidth_5 = 5;
/*      */   protected static final int _topOffsetY = 7;
/*      */   protected static final int _buttonPanelHeight = 21;
/*      */   protected static final int _minStepY3 = 44;
/*      */   protected static final int _minStepY4 = 23;
/*      */   protected static final int _bottomTableOffsetY = 15;
/*      */   protected static final int _tabHeight = 39;
/*      */   protected static final int _embeddedOffset = 3;
/*      */   protected static final int _titledBorderOffset = 31;
/*      */   protected static final int _lineGridOffset = 3;
/*  159 */   protected MCRootPanel _targetPanel = null;
/*      */ 
/*      */   
/*  162 */   private List<Container> _panelList = new ArrayList<>();
/*      */ 
/*      */   
/*  165 */   private List<Container> _fitPanelList = new ArrayList<>();
/*      */ 
/*      */   
/*  168 */   private List<List<Component>> _groupList = new ArrayList<>();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _useImageView = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean useLayoutLocationForSortPolicy = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isUseLayoutLocationForSortPolicy() {
/*  191 */     return this.useLayoutLocationForSortPolicy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUseLayoutLocationForSortPolicy(boolean useLayoutLocationForSortPolicy) {
/*  200 */     this.useLayoutLocationForSortPolicy = useLayoutLocationForSortPolicy;
/*      */   }
/*      */ 
/*      */   
/*  204 */   protected LinkedHashMap<Component, Rectangle> _boundsMap = null;
/*      */ 
/*      */   
/*  207 */   protected LinkedHashMap<Component, Dimension> _prefSizeMap = null; private HashSet<MCTabbedPane> _includeMerginForTabbedPane; protected boolean useLabelGroup; protected static final String labelSuffix = "_Label"; private Map<Container, List<Component>> compomentsCache; private Map<Container, List<MCPanel>> panelListCache; private Map<Container, List<Container>> panelListCache2; private static final int _times = 4; private HashMap<Container, List<Component>> compomentsCache2; private HashMap<Container, List<MCPanel>> tabPanelCache;
/*      */   private static final String PERSONALIZE_0_SCR = "_0_SCR_";
/*      */   private static final String PERSONALIZE_LOCATION = "personalize_location";
/*      */   private static final String PERSONALIZE_SORT = "personalize_location_sort";
/*      */   protected static final String systemLocationID = "System";
/*      */   protected static final String SYSTEM_LOCATION2 = "system_location2";
/*      */   public static final String systemLocationID3 = "System";
/*      */   public static final String SYSTEM_LOCATION3 = "system_location3";
/*      */   private HashMap<MCRootPanel, MCLayoutSettingsR> _layoutSettings;
/*      */   protected int _embeddedX;
/*      */   private static final boolean checkWidthForDyamic = false;
/*      */   private boolean _useFitPanel;
/*      */   protected boolean _debugUseUpdateTabOrder;
/*      */   
/*      */   public void setupTargetPanel(MCRootPanel p) {
/*  222 */     this._targetPanel = p;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCRootPanel getTargetPanel() {
/*  231 */     return this._targetPanel;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void beforeLayout(boolean isRelayout) {
/*  250 */     _beforeLayout(isRelayout);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void _beforeLayout(boolean isRelayout) {
/*  255 */     if (this._targetPanel == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  260 */     boolean debug = this._targetPanel.isAutoLayoutUseLayoutDebugMode();
/*  261 */     if (debug) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  267 */     initTabbedPane();
/*      */ 
/*      */     
/*  270 */     String key = this._targetPanel.getAutoLayoutType();
/*  271 */     if (key == null || !key.equals("G")) {
/*      */       
/*  273 */       setupPanelList();
/*      */ 
/*      */       
/*  276 */       updateLabelSize();
/*      */ 
/*      */       
/*  279 */       updateLocaleWidth();
/*      */ 
/*      */       
/*  282 */       if (this._targetPanel.isAutoLayoutUseAutoLayout()) {
/*  283 */         fitLabelSize();
/*  284 */         fitButtonLabelSize();
/*      */       } 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  290 */     setupPanelList();
/*      */ 
/*      */     
/*  293 */     setupGroupList();
/*      */ 
/*      */     
/*  296 */     initTablePanel();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  304 */     Map<String, MCLayoutLocationR> map0 = locationMap();
/*  305 */     Map<String, MCLayoutPanelR> map1 = panelMap();
/*  306 */     List<MCLocationSortR> list2 = sortList();
/*      */ 
/*      */ 
/*      */     
/*  310 */     mergeSystemLocation2(map0);
/*  311 */     mergeSystemLocationPanel2(map1);
/*      */ 
/*      */ 
/*      */     
/*  315 */     mergeSystemLocation(map0);
/*      */     
/*  317 */     this._boundsMap = new LinkedHashMap<>(1000);
/*  318 */     this._prefSizeMap = new LinkedHashMap<>(1000);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  323 */     this.panelListCache2 = null;
/*  324 */     this.compomentsCache2 = null;
/*  325 */     this.tabPanelCache = null;
/*      */ 
/*      */     
/*  328 */     List<String> keys = new ArrayList<>();
/*  329 */     map0.entrySet().forEach(e1 -> paramList.add(e1.getKey()));
/*      */ 
/*      */ 
/*      */     
/*  333 */     if (map0.size() > 0 && map1.size() > 0) {
/*  334 */       layoutSub(map0, map1, list2, isRelayout);
/*  335 */       _applyLayout();
/*      */     } 
/*      */     
/*  338 */     this._boundsMap = null;
/*  339 */     this._prefSizeMap = null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void _applyLayout() {
/*  345 */     this._boundsMap.entrySet().forEach(e1 -> {
/*      */           if (e1 != null) {
/*      */             MCScrollPane mCScrollPane;
/*      */ 
/*      */ 
/*      */             
/*      */             Component c = e1.getKey();
/*      */ 
/*      */ 
/*      */             
/*      */             Rectangle r = e1.getValue();
/*      */ 
/*      */ 
/*      */             
/*      */             if (c instanceof MCTextArea) {
/*      */               mCScrollPane = ((MCTextArea)c).getScrollPaneForLayout();
/*      */ 
/*      */ 
/*      */               
/*      */               r = this._boundsMap.get(mCScrollPane);
/*      */             } 
/*      */ 
/*      */             
/*      */             if (r != null) {
/*      */               Rectangle r2 = mCScrollPane.getBounds();
/*      */ 
/*      */               
/*      */               if (!r.equals(r2)) {
/*      */                 if (mCScrollPane != this._targetPanel) {
/*      */                   int n = this._targetPanel.getBaseRootPanel().getLayoutRatio();
/*      */ 
/*      */                   
/*      */                   mCScrollPane.setBounds(r.x * n / 100, r.y * n / 100, r.width * n / 100, r.height * n / 100);
/*      */                 } 
/*      */ 
/*      */                 
/*      */                 if (mCScrollPane instanceof MCPanel) {
/*      */                   ((MCPanel)mCScrollPane).setDefaultRatioSize(r);
/*      */                 } else if (mCScrollPane instanceof MCRootPanel) {
/*      */                   ((MCRootPanel)mCScrollPane).setDefaultRatioSize(r);
/*      */                 } else if (mCScrollPane instanceof MCScrollPane) {
/*      */                   MCTextArea ta = getTextArea((Component)mCScrollPane);
/*      */ 
/*      */                   
/*      */                   if (ta != null) {
/*      */                     setDefaultRatioSize((Component)mCScrollPane, null);
/*      */                   } else {
/*      */                     mCScrollPane.setDefaultRatioSize(r);
/*      */                   } 
/*      */                 } else if (mCScrollPane instanceof MCSplitPane) {
/*      */                   ((MCSplitPane)mCScrollPane).setDefaultRatioSize(r);
/*      */                 } else if (mCScrollPane instanceof MCTabbedPane) {
/*      */                   ((MCTabbedPane)mCScrollPane).setDefaultRatioSize(r);
/*      */                 } else if (this._targetPanel.isRelayout()) {
/*      */                   setDefaultRatioSize((Component)mCScrollPane, r);
/*      */                 } else {
/*      */                   setDefaultRatioSize((Component)mCScrollPane, null);
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         });
/*      */ 
/*      */     
/*  409 */     this._prefSizeMap.entrySet().forEach(e1 -> {
/*      */           if (e1 != null) {
/*      */             Component c = e1.getKey();
/*      */             
/*      */             Dimension d = e1.getValue();
/*      */             
/*      */             if (d != null) {
/*      */               Dimension d2 = c.getPreferredSize();
/*      */               if (!d.equals(d2)) {
/*      */                 c.setPreferredSize(new Dimension(d.width, d.height));
/*      */               }
/*      */             } 
/*      */           } 
/*      */         });
/*  423 */     if (this._targetPanel.getFontRatio() != 100) {
/*  424 */       MCLayouter.fontRatioChange(this._targetPanel, this._targetPanel.getFontRatio());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void afterLayout() {
/*  433 */     if (this._targetPanel == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  438 */     if (this._targetPanel.isAutolayoutUseUpdateTabOrder()) {
/*  439 */       updateTabOrder(this._targetPanel, true);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean updateVisibleComponent(Container parentPanel) {
/*  450 */     if (parentPanel == null) {
/*  451 */       return true;
/*      */     }
/*      */ 
/*      */     
/*  455 */     boolean isVis = false;
/*  456 */     Component[] list = getAllComponents4(parentPanel); byte b; int i;
/*      */     Component[] arrayOfComponent1;
/*  458 */     for (i = (arrayOfComponent1 = list).length, b = 0; b < i; ) { Component c = arrayOfComponent1[b];
/*  459 */       if (c instanceof MCPanel) {
/*  460 */         boolean isVis2 = updateVisibleComponent((Container)c);
/*  461 */         if (isVis2) {
/*  462 */           isVis = true;
/*      */         }
/*  464 */       } else if (c instanceof MCRootPanel) {
/*  465 */         boolean isVis2 = updateVisibleComponent((Container)c);
/*  466 */         if (isVis2) {
/*  467 */           isVis = true;
/*      */         }
/*  469 */       } else if (c instanceof MCScrollPane) {
/*  470 */         JViewport vp = ((MCScrollPane)c).getViewport();
/*  471 */         Container c2 = (Container)vp.getView();
/*  472 */         if (c2 instanceof MCRootPanel || c2 instanceof MCPanel || c2 instanceof MCTabbedPane || 
/*  473 */           c2 instanceof MCScrollPane) {
/*  474 */           boolean isVis2 = updateVisibleComponent((Container)vp.getView());
/*  475 */           if (isVis2) {
/*  476 */             isVis = true;
/*      */           }
/*      */         } else {
/*  479 */           isVis = true;
/*      */         } 
/*  481 */       } else if (c instanceof MCSplitPane) {
/*  482 */         MCSplitPane p = (MCSplitPane)c;
/*  483 */         Component left = p.getLeftComponent();
/*  484 */         Component right = p.getRightComponent();
/*      */         
/*  486 */         boolean isVis2 = updateVisibleComponent((Container)left);
/*  487 */         if (isVis2) {
/*  488 */           isVis = true;
/*      */         }
/*  490 */         boolean isVis3 = updateVisibleComponent((Container)right);
/*  491 */         if (isVis3) {
/*  492 */           isVis = true;
/*      */         }
/*  494 */       } else if (c instanceof MCTabbedPane) {
/*  495 */         boolean isVis2 = updateVisibleComponent((Container)c);
/*  496 */         if (isVis2) {
/*  497 */           isVis = true;
/*      */         }
/*      */       } 
/*  500 */       if (c.isVisible()) {
/*  501 */         isVis = true;
/*      */       }
/*      */       b++; }
/*      */     
/*  505 */     int size = list.length;
/*  506 */     if (size > 0)
/*      */     {
/*  508 */       if (!isVis && 
/*  509 */         parentPanel.isVisible()) {
/*  510 */         parentPanel.setVisible(false);
/*      */ 
/*      */         
/*  513 */         if (parentPanel instanceof MCPanel) {
/*  514 */           ((MCPanel)parentPanel).setVisibleForAutoLayout(true);
/*  515 */         } else if (parentPanel instanceof MCRootPanel) {
/*  516 */           ((MCRootPanel)parentPanel).setVisibleForAutoLayout(true);
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/*  521 */     return isVis;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void initPanelVisible(boolean isRelayout) {
/*  530 */     _initPanelVisible((Container)this._targetPanel, isRelayout);
/*      */   }
/*      */   
/*      */   protected void _initPanelVisible(Container parentPanel, boolean isRelayout) {
/*  534 */     if (parentPanel == null) {
/*      */       return;
/*      */     }
/*      */     
/*  538 */     Component[] list = getAllComponents4(parentPanel); byte b; int i;
/*      */     Component[] arrayOfComponent1;
/*  540 */     for (i = (arrayOfComponent1 = list).length, b = 0; b < i; ) { Component c = arrayOfComponent1[b];
/*  541 */       if (c instanceof MCPanel) {
/*  542 */         _initPanelVisible((Container)c, isRelayout);
/*  543 */         MCPanel p = (MCPanel)c;
/*  544 */         if (!p.isVisible() && 
/*  545 */           p.isVisibleForAutoLayout())
/*      */         {
/*  547 */           p.setVisible(true);
/*  548 */           p.setVisibleForAutoLayout(false);
/*      */         }
/*      */       
/*  551 */       } else if (c instanceof MCRootPanel) {
/*  552 */         _initPanelVisible((Container)c, isRelayout);
/*  553 */         MCRootPanel rp = (MCRootPanel)c;
/*  554 */         if (!rp.isVisible() && 
/*  555 */           rp.isVisibleForAutoLayout())
/*      */         {
/*  557 */           rp.setVisible(true);
/*  558 */           rp.setVisibleForAutoLayout(false);
/*      */         }
/*      */       
/*  561 */       } else if (c instanceof MCScrollPane) {
/*  562 */         JViewport vp = ((MCScrollPane)c).getViewport();
/*  563 */         Container c2 = (Container)vp.getView();
/*  564 */         if (c2 instanceof MCRootPanel || c2 instanceof MCPanel || c2 instanceof MCTabbedPane || 
/*  565 */           c2 instanceof MCScrollPane) {
/*  566 */           _initPanelVisible((Container)vp.getView(), isRelayout);
/*      */           
/*  568 */           if (c2 instanceof MCRootPanel) {
/*  569 */             MCRootPanel p = (MCRootPanel)c2;
/*  570 */             if (!p.isVisible() && 
/*  571 */               p.isVisibleForAutoLayout())
/*      */             {
/*  573 */               p.setVisible(true);
/*  574 */               p.setVisibleForAutoLayout(false);
/*      */             }
/*      */           
/*      */           }
/*  578 */           else if (c2 instanceof MCPanel) {
/*  579 */             MCPanel p = (MCPanel)c2;
/*  580 */             if (!p.isVisible() && 
/*  581 */               p.isVisibleForAutoLayout())
/*      */             {
/*  583 */               p.setVisible(true);
/*  584 */               p.setVisibleForAutoLayout(false);
/*      */             }
/*      */           
/*      */           }
/*      */         
/*      */         } 
/*  590 */       } else if (c instanceof MCSplitPane) {
/*  591 */         MCSplitPane p = (MCSplitPane)c;
/*  592 */         Component left = p.getLeftComponent();
/*  593 */         Component right = p.getRightComponent();
/*      */         
/*  595 */         _initPanelVisible((Container)left, isRelayout);
/*  596 */         _initPanelVisible((Container)right, isRelayout);
/*  597 */       } else if (c instanceof MCTabbedPane) {
/*  598 */         _initPanelVisible((Container)c, isRelayout);
/*      */       } 
/*      */       b++; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean compressPanel(Container parentPanel, Map<String, MCLayoutLocationR> map0) {
/*  615 */     boolean flag = false;
/*      */ 
/*      */     
/*  618 */     if (this._includeMerginForTabbedPane == null) {
/*  619 */       this._includeMerginForTabbedPane = new HashSet<>();
/*      */     }
/*      */     
/*  622 */     boolean isTabbedPane = isTabbedPane(parentPanel);
/*  623 */     if (isTabbedPane) {
/*      */ 
/*      */       
/*  626 */       boolean isUseAdjustExpandPanelSize = MCGeneralLayout.isUseAdjustExpandPanelSize();
/*      */       
/*  628 */       int h = 0;
/*      */       
/*  630 */       List<MCPanel> subPanelList = getTabPanelList((MCPanel)parentPanel);
/*  631 */       for (MCPanel p3 : subPanelList) {
/*      */ 
/*      */         
/*  634 */         if (compressPanel((Container)p3, map0)) {
/*  635 */           flag = true;
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*  640 */         if (compressPanelSub2((Container)p3, map0)) {
/*  641 */           flag = true;
/*      */         }
/*      */ 
/*      */         
/*  645 */         if (compressPanelSub3((Container)p3)) {
/*  646 */           flag = true;
/*      */         }
/*      */         
/*  649 */         if (compressPanelSub1((Container)p3, null, false)) {
/*  650 */           flag = true;
/*      */         }
/*      */ 
/*      */         
/*  654 */         h = Math.max(h, _getHeight((Component)p3));
/*      */       } 
/*      */       
/*  657 */       if (flag) {
/*      */         
/*  659 */         for (MCPanel p4 : subPanelList) {
/*  660 */           _setSize((Component)p4, _getWidth((Component)p4), h, false);
/*  661 */           _setPreferredSize((Component)p4, _getWidth((Component)p4), h, false);
/*      */ 
/*      */           
/*  664 */           _setDefaultLocation((Component)p4, _getLocation((Component)p4), new Dimension(_getWidth((Component)p4), h));
/*      */         } 
/*      */ 
/*      */         
/*  668 */         int dh = getMinStepY4() + getTopOffsetY();
/*  669 */         int h2 = h + dh;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  676 */         MCTabbedPane tp = getTabbedPane(parentPanel);
/*  677 */         if (tp != null) {
/*      */ 
/*      */           
/*  680 */           Dimension d = tp.getBaseRootPanel().getDefaultSize();
/*  681 */           int maxWidth = d.width;
/*      */ 
/*      */ 
/*      */           
/*  685 */           int w1 = Math.min((_getPreferredSize((Component)tp)).width, maxWidth);
/*      */ 
/*      */           
/*  688 */           if (!this._includeMerginForTabbedPane.contains(tp)) {
/*      */ 
/*      */             
/*  691 */             if (isUseAdjustExpandPanelSize) {
/*  692 */               this._includeMerginForTabbedPane.add(tp);
/*      */             }
/*      */             
/*  695 */             Insets insets = tp.getDefaultContentBorderInsets();
/*  696 */             w1 += insets.left + insets.right;
/*  697 */             h2 += insets.top + insets.bottom;
/*      */           } 
/*      */           
/*  700 */           _setSize((Component)tp, w1, h2, false);
/*      */           
/*  702 */           _setPreferredSize((Component)tp, w1, h2, false);
/*  703 */           _setDefaultLocation((Component)tp, _getLocation((Component)tp), new Dimension(w1, h2));
/*      */           
/*  705 */           Container p2 = tp.getParent();
/*      */ 
/*      */           
/*  708 */           int w2 = Math.min((_getPreferredSize(p2)).width, maxWidth);
/*  709 */           _setSize(p2, w2, h2, false);
/*      */           
/*  711 */           _setPreferredSize(p2, w2, h2, false);
/*  712 */           _setDefaultLocation(p2, _getLocation(p2), new Dimension(w2, h2));
/*      */         } 
/*      */       } 
/*      */     } else {
/*  716 */       List<Container> subPanelList = getPanels(parentPanel, true);
/*      */ 
/*      */       
/*  719 */       for (Container p3 : subPanelList) {
/*  720 */         if (compressPanel(p3, map0)) {
/*  721 */           flag = true;
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/*  726 */       if (compressPanelSub2(parentPanel, map0)) {
/*  727 */         flag = true;
/*      */       }
/*      */ 
/*      */       
/*  731 */       compressPanelSub3(parentPanel);
/*      */       
/*  733 */       if (compressPanelSub1(parentPanel, null, false)) {
/*  734 */         flag = true;
/*      */       }
/*      */     } 
/*      */     
/*  738 */     return flag;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean compressPanelSub3(Container parentPanel) {
/*  749 */     boolean flag = false;
/*      */     
/*  751 */     List<Container> list1 = getPanels(parentPanel, true);
/*      */     
/*  753 */     for (Container c : list1) {
/*  754 */       if (isEmbeddedPanel1(c, false)) {
/*  755 */         if (c instanceof MCRootPanel) {
/*  756 */           if (compressPanelSub3(c))
/*  757 */             flag = true; 
/*      */           continue;
/*      */         } 
/*  760 */         if (compressPanelSub1(c, parentPanel, true)) {
/*  761 */           flag = true;
/*      */         }
/*      */         
/*      */         continue;
/*      */       } 
/*  766 */       if (compressPanelSub3(c)) {
/*  767 */         flag = true;
/*      */       }
/*      */       
/*  770 */       if (c instanceof MCPanel) {
/*  771 */         boolean _hasTitledBoder = _hasTitledBorder(c);
/*  772 */         if (_hasTitledBoder && 
/*  773 */           compressPanelSub1(c, parentPanel, false)) {
/*  774 */           flag = true;
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  782 */     if (parentPanel instanceof MCRootPanel && 
/*  783 */       compressPanelSub1(parentPanel, null, false)) {
/*  784 */       flag = true;
/*      */     }
/*      */ 
/*      */     
/*  788 */     return flag;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean compressPanelSub2(Container parentPanel, Map<String, MCLayoutLocationR> map0) {
/*  800 */     boolean isEmbeddedPanel1 = isEmbeddedPanel1(parentPanel, false);
/*  801 */     if (isEmbeddedPanel1) {
/*  802 */       return false;
/*      */     }
/*      */ 
/*      */     
/*  806 */     Map<Integer, List<Component>> yMap = new HashMap<>();
/*      */ 
/*      */     
/*  809 */     List<Component> list = getAllComponents2(parentPanel);
/*      */ 
/*      */     
/*  812 */     Point parentLocation = _getXYOnScreen(parentPanel);
/*      */ 
/*      */     
/*  815 */     boolean hasMenuButton = hasMenuButton(list);
/*  816 */     if (hasMenuButton) {
/*  817 */       return false;
/*      */     }
/*      */     
/*  820 */     boolean flag = false;
/*      */     
/*  822 */     List<Component> list1 = new ArrayList<>();
/*  823 */     for (Component c : list) {
/*  824 */       if (canMoveComponent2(c, false, true, true, true) && 
/*  825 */         isVisibleComponent(c)) {
/*  826 */         list1.add(c);
/*      */       }
/*      */     } 
/*      */     
/*  830 */     if (list1.size() == 0) {
/*  831 */       return flag;
/*      */     }
/*      */     
/*  834 */     for (Component comp : list1) {
/*  835 */       int locationY = _getYOnPanel(comp, parentPanel);
/*  836 */       int n = _getBaseline(comp);
/*  837 */       if (comp instanceof MCPanel) {
/*      */         
/*  839 */         n = 0;
/*  840 */         boolean isEmbeddedPanel2 = isEmbeddedPanel1((Container)comp, false);
/*  841 */         if (isEmbeddedPanel2) {
/*      */           continue;
/*      */         }
/*      */       } 
/*  845 */       int y = locationY + n;
/*      */       
/*  847 */       List<Component> list2 = yMap.get(Integer.valueOf(y));
/*  848 */       if (list2 == null) {
/*  849 */         list2 = new ArrayList<>();
/*      */       }
/*  851 */       list2.add(comp);
/*  852 */       yMap.put(Integer.valueOf(y), list2);
/*      */     } 
/*      */     
/*  855 */     int lineGrid = this._targetPanel.getAutolayoutLineGrid();
/*      */ 
/*      */     
/*  858 */     List<Integer> ySet = new ArrayList<>(yMap.keySet());
/*  859 */     Map<Integer, Integer> yStepMap = new HashMap<>();
/*  860 */     Map<Integer, Integer> lineGridMap = new HashMap<>();
/*      */     
/*  862 */     List<Integer> _yList = new ArrayList<>();
/*  863 */     List<Integer> _ySetList = new ArrayList<>(ySet);
/*  864 */     Collections.sort(_ySetList);
/*  865 */     if (_ySetList.size() > 0) {
/*      */ 
/*      */       
/*  868 */       boolean isTabbedPane = isTabbedPane(parentPanel);
/*  869 */       if (isTabbedPane) {
/*  870 */         if (((Integer)_ySetList.get(0)).intValue() > getMinStepY3()) {
/*  871 */           int dy3 = getMinStepY3() + getTopOffsetY();
/*  872 */           if (moveComponent(dy3, map0, list1)) {
/*  873 */             flag = true;
/*      */           }
/*      */         } 
/*      */       } else {
/*      */         
/*  878 */         boolean _hasTable = _hasTable(list);
/*  879 */         if (!_hasTable) {
/*      */           
/*  881 */           int _miniStepY2 = lineGrid + getTopOffsetY();
/*  882 */           if (((Integer)_ySetList.get(0)).intValue() > _miniStepY2) {
/*  883 */             int dy3 = lineGrid;
/*  884 */             if (moveComponent(dy3, map0, list1)) {
/*  885 */               flag = true;
/*      */             }
/*      */           }
/*      */         
/*      */         } else {
/*      */           
/*  891 */           List<Rectangle> _tableSizeList = _getTableSizeList(list);
/*      */           
/*  893 */           int _miniStepY2 = lineGrid + getTopOffsetY();
/*  894 */           int dy3 = lineGrid;
/*  895 */           int _miniStepY5 = getBottomTableOffsetY();
/*  896 */           for (Rectangle r : _tableSizeList) {
/*  897 */             if (r.y - parentLocation.y < ((Integer)_ySetList.get(0)).intValue() && 
/*  898 */               _miniStepY2 < r.y - parentLocation.y + r.height) {
/*  899 */               _miniStepY2 = r.y - parentLocation.y + r.height + _miniStepY5;
/*  900 */               dy3 = ((Integer)_ySetList.get(0)).intValue() - _miniStepY2;
/*      */             } 
/*      */           } 
/*      */ 
/*      */           
/*  905 */           if (((Integer)_ySetList.get(0)).intValue() > _miniStepY2 && 
/*  906 */             moveComponent(dy3, map0, list1)) {
/*  907 */             flag = true;
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  915 */     for (int i = 0; i < _ySetList.size() - 1; i++) {
/*  916 */       int y1 = ((Integer)_ySetList.get(i)).intValue();
/*  917 */       int y2 = ((Integer)_ySetList.get(i + 1)).intValue();
/*  918 */       int offsetY = 0;
/*  919 */       List<Component> list2 = yMap.get(Integer.valueOf(y1));
/*  920 */       boolean hasTitledBorder = _hasTitledBorder(list2);
/*  921 */       if (hasTitledBorder)
/*      */       {
/*  923 */         offsetY = getTopOffsetY();
/*      */       }
/*      */       
/*  926 */       int lineGrid2 = lineGrid;
/*      */       
/*  928 */       for (Component c : list2) {
/*  929 */         int h = _getHeight(c) + getLineGridOffset();
/*  930 */         if (lineGrid < h) {
/*  931 */           lineGrid2 = h;
/*      */         }
/*      */       } 
/*      */       
/*  935 */       if (y2 - y1 > lineGrid2 + offsetY) {
/*  936 */         yStepMap.put(Integer.valueOf(y1), Integer.valueOf(y2 - y1));
/*  937 */         int d = y2 - y1 - lineGrid2 + offsetY;
/*  938 */         lineGridMap.put(Integer.valueOf(y1), Integer.valueOf(d));
/*  939 */         _yList.add(Integer.valueOf(y1));
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  945 */     boolean b = true;
/*  946 */     if (_yList.size() > 0 && b) {
/*  947 */       Collections.sort(_yList, new YComparator(null));
/*  948 */       for (Iterator<Integer> iterator = _yList.iterator(); iterator.hasNext(); ) { int y3 = ((Integer)iterator.next()).intValue();
/*  949 */         int dy3 = ((Integer)lineGridMap.get(Integer.valueOf(y3))).intValue();
/*  950 */         if (dy3 != 0) {
/*  951 */           List<Component> list2 = new ArrayList<>();
/*  952 */           for (Component c : list1) {
/*      */             
/*  954 */             int y = _getYOnPanel(c, null);
/*  955 */             if (y > y3) {
/*  956 */               list2.add(c);
/*      */             }
/*      */           } 
/*  959 */           if (moveComponent3(dy3, map0, list2)) {
/*  960 */             flag = true;
/*      */           }
/*      */         }  }
/*      */     
/*      */     } 
/*      */     
/*  966 */     return flag;
/*      */   }
/*      */   private class YComparator implements Comparator<Integer> { private YComparator() {}
/*      */     
/*      */     public int compare(Integer a, Integer b) {
/*  971 */       return b.compareTo(a);
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean compressPanelSub4() {
/*  985 */     boolean flag = false;
/*      */     
/*  987 */     for (int i1 = 0; i1 < this._panelList.size() - 1; i1++) {
/*  988 */       Container p1 = this._panelList.get(i1);
/*  989 */       Container parent1 = p1.getParent();
/*  990 */       if (!(parent1 instanceof MCTabbedPane)) {
/*      */ 
/*      */         
/*  993 */         Rectangle r1 = getDefaultBounds(p1);
/*  994 */         for (int i2 = i1 + 1; i2 < this._panelList.size(); i2++) {
/*  995 */           Container p2 = this._panelList.get(i2);
/*  996 */           if (p1 != p2) {
/*      */ 
/*      */             
/*  999 */             Container parent2 = p2.getParent();
/* 1000 */             if (!(parent2 instanceof MCTabbedPane)) {
/*      */ 
/*      */ 
/*      */               
/* 1004 */               Rectangle r2 = getDefaultBounds(p2);
/* 1005 */               if (parent1 == parent2) {
/*      */ 
/*      */ 
/*      */                 
/* 1009 */                 if (r1.intersects(r2)) {
/* 1010 */                   int dy = 0;
/* 1011 */                   if (r1.y < r2.y) {
/* 1012 */                     dy = r1.y + r1.height - r2.y;
/* 1013 */                     if (dy > 0) {
/* 1014 */                       r2.y += dy;
/* 1015 */                       setDefaultBounds(p2, r2);
/* 1016 */                       flag = true;
/*      */                     } 
/*      */                   } 
/*      */                 } 
/* 1020 */                 if (r1.intersects(r2) && 
/* 1021 */                   r1.x < r2.x) {
/* 1022 */                   int dx = 0;
/* 1023 */                   dx = r1.x + r1.width - r2.x;
/* 1024 */                   if (dx > 0) {
/* 1025 */                     r2.x += dx;
/* 1026 */                     setDefaultBounds(p2, r2);
/* 1027 */                     flag = true;
/*      */                   } 
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/* 1035 */     }  return flag;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean moveComponent(int dy3, Map<String, MCLayoutLocationR> map0, List<Component> list1) {
/* 1041 */     boolean result = false;
/* 1042 */     Map<Rectangle, List<Component>> rectMap = getComponentMap(list1);
/* 1043 */     List<Component> moved = new ArrayList<>();
/* 1044 */     for (Component c : list1) {
/* 1045 */       if (moved.contains(c)) {
/*      */         continue;
/*      */       }
/* 1048 */       MCLayoutLocationR findR = getLocationR(c, map0);
/* 1049 */       Point pt = new Point(_getXOnPanel(c, null), _getYOnPanel(c, null) - dy3);
/* 1050 */       if (moveComponent2(c, pt, findR)) {
/* 1051 */         result = true;
/*      */       }
/* 1053 */       moved.add(c);
/*      */       
/* 1055 */       for (List<Component> list2 : rectMap.values()) {
/* 1056 */         if (list2.contains(c)) {
/* 1057 */           for (Component c3 : list2) {
/* 1058 */             if (c3 != c) {
/* 1059 */               if (moveComponent2(c, pt, findR)) {
/* 1060 */                 result = true;
/*      */               }
/* 1062 */               moved.add(c3);
/*      */             } 
/*      */           } 
/*      */           break;
/*      */         } 
/*      */       } 
/*      */     } 
/* 1069 */     return result;
/*      */   }
/*      */   
/*      */   protected boolean moveComponent3(int dy3, Map<String, MCLayoutLocationR> map0, List<Component> list1) {
/* 1073 */     boolean result = false;
/* 1074 */     for (Component c : list1) {
/* 1075 */       MCLayoutLocationR findR = getLocationR(c, map0);
/* 1076 */       Point pt = new Point(_getXOnPanel(c, null), _getYOnPanel(c, null) - dy3);
/* 1077 */       if (moveComponent2(c, pt, findR)) {
/* 1078 */         result = true;
/*      */       }
/*      */     } 
/* 1081 */     return result;
/*      */   }
/*      */   
/*      */   protected List<Rectangle> _getTableSizeList(List<Component> list) {
/* 1085 */     List<Rectangle> result = new ArrayList<>();
/* 1086 */     for (Component c : list) {
/* 1087 */       if (c instanceof MCTable) {
/* 1088 */         MCScrollPane s = ((MCTable)c).getScrollPane();
/*      */ 
/*      */         
/* 1091 */         Point xy = _getXYOnScreen((Component)s);
/* 1092 */         result.add(new Rectangle(xy.x, xy.y, _getWidth((Component)s), _getHeight((Component)s)));
/*      */       } 
/*      */     } 
/* 1095 */     return result;
/*      */   }
/*      */   
/*      */   protected boolean _hasTable(List<Component> list) {
/* 1099 */     for (Component c : list) {
/* 1100 */       if (c instanceof MCTable) {
/* 1101 */         return true;
/*      */       }
/*      */     } 
/* 1104 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean isTabbedPane(Container p) {
/* 1109 */     if (!(p instanceof MCPanel)) {
/* 1110 */       return false;
/*      */     }
/*      */     
/* 1113 */     LayoutManager layout = p.getLayout();
/* 1114 */     if (layout == null) {
/*      */       
/* 1116 */       Component[] arrayOfComponent = getAllComponents4(p);
/* 1117 */       if (arrayOfComponent.length == 1) {
/* 1118 */         Component c = arrayOfComponent[0];
/* 1119 */         if (c instanceof MCTabbedPane) {
/* 1120 */           return true;
/*      */         }
/*      */       } 
/* 1123 */     } else if (layout instanceof MCBorderLayout) {
/*      */       
/* 1125 */       MCBorderLayout bl = (MCBorderLayout)layout;
/* 1126 */       Component c = bl.getLayoutComponent("Center");
/* 1127 */       if (c instanceof MCTabbedPane) {
/* 1128 */         return true;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1137 */       boolean bool = true;
/* 1138 */       if (bool && 
/* 1139 */         c instanceof MCScrollPane) {
/* 1140 */         Container p3 = ((MCScrollPane)c).getViewport();
/* 1141 */         Component[] comps3 = getAllComponents4(p3);
/* 1142 */         if (comps3.length == 1) {
/* 1143 */           Component c4 = comps3[0];
/* 1144 */           if (c4 instanceof MCTabbedPane) {
/* 1145 */             return true;
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1153 */     Component[] components = getAllComponents4(p); byte b; int i; Component[] arrayOfComponent1;
/* 1154 */     for (i = (arrayOfComponent1 = components).length, b = 0; b < i; ) { Component c2 = arrayOfComponent1[b];
/* 1155 */       if (c2 instanceof MCScrollPane) {
/* 1156 */         Container p2 = ((MCScrollPane)c2).getViewport();
/* 1157 */         Component[] comps2 = getAllComponents4(p2);
/* 1158 */         if (comps2.length == 1) {
/* 1159 */           Component c3 = comps2[0];
/* 1160 */           if (c3 instanceof MCPanel) {
/* 1161 */             Component[] comps3 = getAllComponents4((Container)c3); byte b1; int j; Component[] arrayOfComponent2;
/* 1162 */             for (j = (arrayOfComponent2 = comps3).length, b1 = 0; b1 < j; ) { Component comp = arrayOfComponent2[b1];
/* 1163 */               if (comp instanceof MCTabbedPane)
/* 1164 */                 return true; 
/*      */               b1++; }
/*      */           
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       b++; }
/*      */     
/* 1172 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   protected MCTabbedPane getTabbedPane(Container p) {
/* 1177 */     if (!(p instanceof MCPanel)) {
/* 1178 */       return null;
/*      */     }
/*      */     
/* 1181 */     LayoutManager layout = p.getLayout();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1205 */     if (layout instanceof MCBorderLayout) {
/*      */       
/* 1207 */       MCBorderLayout bl = (MCBorderLayout)layout;
/* 1208 */       Component c = bl.getLayoutComponent("Center");
/* 1209 */       if (c instanceof MCTabbedPane) {
/* 1210 */         return (MCTabbedPane)c;
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1218 */     Component[] components = getAllComponents4(p);
/* 1219 */     if (components.length == 1) {
/* 1220 */       Component c = components[0];
/* 1221 */       if (c instanceof MCTabbedPane)
/* 1222 */         return (MCTabbedPane)c; 
/* 1223 */       if (c instanceof MCScrollPane) {
/* 1224 */         MCScrollPane sp = (MCScrollPane)c;
/* 1225 */         Component v = sp.getViewport().getView();
/* 1226 */         if (v instanceof MCPanel) {
/* 1227 */           MCPanel mp = (MCPanel)v;
/* 1228 */           Component[] components2 = getAllComponents4((Container)mp);
/* 1229 */           if (components2.length == 1) {
/* 1230 */             Component c2 = components2[0];
/* 1231 */             if (c2 instanceof MCTabbedPane) {
/* 1232 */               return (MCTabbedPane)c2;
/*      */             }
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1240 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean _hasTitledBorder(List<Component> list) {
/* 1245 */     for (Component c : list) {
/* 1246 */       if (_hasTitledBorder(c)) {
/* 1247 */         return true;
/*      */       }
/*      */     } 
/* 1250 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean _hasTitledBorder(Component c) {
/* 1255 */     if (c instanceof MCPanel) {
/* 1256 */       Border b = ((MCPanel)c).getBorder();
/* 1257 */       if (b instanceof MCTitledBorder) {
/* 1258 */         return true;
/*      */       }
/*      */     } 
/* 1261 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   protected MCPanel getTitledBorderPanel(MCPanel c) {
/* 1266 */     Border b = c.getBorder();
/* 1267 */     if (b instanceof MCTitledBorder) {
/* 1268 */       return c;
/*      */     }
/*      */     
/* 1271 */     MCPanel p1 = null;
/* 1272 */     MCPanel mCPanel1 = c;
/* 1273 */     Container container = mCPanel1.getParent();
/* 1274 */     while (container != null) {
/* 1275 */       b = c.getBorder();
/* 1276 */       if (b instanceof MCTitledBorder) {
/* 1277 */         return c;
/*      */       }
/* 1279 */       if (container instanceof MCPanel && container.getName() != null && !container.getName().startsWith("_")) {
/* 1280 */         p1 = (MCPanel)container;
/*      */       }
/* 1282 */       container = container.getParent();
/*      */     } 
/*      */     
/* 1285 */     return p1;
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean hasMenuButton(List<Component> list) {
/* 1290 */     boolean hasMenuButton = false;
/* 1291 */     for (Component comp : list) {
/* 1292 */       if (comp.getClass().getName().indexOf("MCMenuButton") != -1) {
/* 1293 */         hasMenuButton = true;
/*      */         break;
/*      */       } 
/*      */     } 
/* 1297 */     return hasMenuButton;
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean isButtonPanel(int y, List<Component> list) {
/* 1302 */     for (Component c : list) {
/* 1303 */       int y2 = _getYOnPanel(c, null) + _getBaseline(c);
/* 1304 */       if (y2 == y) {
/* 1305 */         if (isButton(c)) {
/* 1306 */           return true;
/*      */         }
/* 1308 */         return false;
/*      */       } 
/* 1310 */       if (y2 > y) {
/* 1311 */         return false;
/*      */       }
/*      */     } 
/*      */     
/* 1315 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean _hasTabbedPanel(Container c) {
/* 1320 */     Container p = c;
/* 1321 */     while (p != null) {
/* 1322 */       if (p instanceof MCTabbedPane) {
/* 1323 */         return true;
/*      */       }
/* 1325 */       p = p.getParent();
/*      */     } 
/*      */     
/* 1328 */     return false;
/*      */   }
/*      */   
/*      */   protected boolean compressPanelSub1(Container aPanel, Container parentPanel, boolean checkEmbedded) {
/*      */     Rectangle r1;
/* 1333 */     boolean isEmbeddedPanel1 = isEmbeddedPanel1(aPanel, false);
/* 1334 */     if (checkEmbedded)
/*      */     {
/*      */       
/* 1337 */       if (!isEmbeddedPanel1) {
/* 1338 */         return false;
/*      */       }
/*      */     }
/*      */ 
/*      */     
/* 1343 */     if (_getHeight(aPanel) == 0) {
/* 1344 */       return false;
/*      */     }
/*      */     
/* 1347 */     boolean isTabbedPane = isTabbedPane(aPanel);
/* 1348 */     boolean isTablePanel = isTablePanel(aPanel);
/* 1349 */     boolean hasTitledBorderPanel = hasTitledBorderPanel(aPanel);
/*      */     
/* 1351 */     boolean f = false;
/* 1352 */     HashMap<Container, Rectangle> unionRectMap = new HashMap<>();
/* 1353 */     if (parentPanel != null) {
/* 1354 */       f = setComponentUnionBounds(aPanel, unionRectMap, false);
/*      */     }
/* 1356 */     else if (isTablePanel) {
/*      */       
/* 1358 */       if (hasTitledBorderPanel) {
/*      */         
/* 1360 */         f = setComponentUnionBounds(aPanel, unionRectMap, true);
/*      */       } else {
/* 1362 */         f = setComponentUnionBounds(aPanel, unionRectMap, false);
/*      */       } 
/*      */     } else {
/* 1365 */       f = setComponentUnionBounds(aPanel, unionRectMap, true);
/*      */     } 
/*      */     
/* 1368 */     if (!f) {
/* 1369 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1375 */     Rectangle unionRect1 = unionRectMap.get(aPanel);
/* 1376 */     if (unionRect1 != null) {
/* 1377 */       r1 = (Rectangle)unionRect1.clone();
/*      */     } else {
/* 1379 */       r1 = (Rectangle)_getBounds(aPanel).clone();
/*      */     } 
/*      */ 
/*      */     
/* 1383 */     Point pt1 = new Point(_getXOnPanel(aPanel, null), _getYOnPanel(aPanel, null));
/*      */     
/* 1385 */     Rectangle r2 = (Rectangle)_getBounds(aPanel).clone();
/* 1386 */     r2.setLocation(pt1);
/*      */ 
/*      */     
/* 1389 */     if (aPanel instanceof MCPanel) {
/* 1390 */       if (!hasTitledBorderPanel && !isEmbeddedPanel1) {
/*      */         
/* 1392 */         ((MCPanel)aPanel)._setMaxPrefRight(Integer.valueOf(r2.x + r2.width));
/*      */       } else {
/* 1394 */         ((MCPanel)aPanel)._setMaxPrefRight(null);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1400 */     int x = r1.x;
/* 1401 */     int y = r1.y;
/* 1402 */     if (aPanel instanceof MCRootPanel && isEmbeddedPanel1) {
/*      */       
/* 1404 */       x = r1.x + pt1.x;
/* 1405 */       y = r1.y + pt1.y;
/*      */     } 
/* 1407 */     if (!isEmbeddedPanel1) {
/*      */       
/* 1409 */       r1.setLocation(r2.x, r2.y);
/*      */ 
/*      */       
/* 1412 */       if (!isTabbedPane && 
/* 1413 */         !hasTitledBorderPanel && (
/* 1414 */         r2.height != getButtonPanelHeight() || r2.y != getTopOffsetY()))
/*      */       {
/*      */ 
/*      */ 
/*      */         
/* 1419 */         r1.setSize(r1.width, r1.height + getTopOffsetY());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1425 */       if (aPanel instanceof MCPanel && hasTitledBorderPanel) {
/*      */         
/* 1427 */         int w = ((MCPanel)aPanel)._getTitlteBorderWidth();
/* 1428 */         if (w > r1.width) {
/* 1429 */           r1.width = w;
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 1434 */       r2 = r1;
/*      */     } else {
/* 1436 */       r1.setLocation(x, y);
/*      */     } 
/*      */ 
/*      */     
/* 1440 */     Rectangle r = r1;
/*      */     
/* 1442 */     Dimension dim = new Dimension(r.width, r.height);
/* 1443 */     Point pt = new Point(r.x - r2.x, r.y - r2.y);
/*      */     
/* 1445 */     boolean flag = false;
/* 1446 */     if (!dim.equals(_getSize(aPanel))) {
/* 1447 */       _setSize(aPanel, dim.width, dim.height, true);
/* 1448 */       _setPreferredSize(aPanel, dim.width, dim.height, false);
/* 1449 */       _setDefaultLocation(aPanel, _getLocation(aPanel), dim);
/*      */       
/* 1451 */       boolean isEmbeddedPanel = isEmbeddedPanel(aPanel);
/* 1452 */       if (isEmbeddedPanel && aPanel.getParent() instanceof MCRootPanel)
/*      */       {
/* 1454 */         if (this._targetPanel != aPanel.getParent()) {
/* 1455 */           _setSize(aPanel.getParent(), dim.width, dim.height, false);
/* 1456 */           _setPreferredSize(aPanel.getParent(), dim.width, dim.height, false);
/* 1457 */           _setDefaultLocation(aPanel.getParent(), _getLocation(aPanel.getParent()), dim);
/*      */         } 
/*      */       }
/*      */       
/* 1461 */       if (isTabbedPane) {
/*      */ 
/*      */         
/* 1464 */         MCPanel p1 = (MCPanel)aPanel;
/*      */         
/* 1466 */         LayoutManager layout = p1.getLayout();
/* 1467 */         if (layout instanceof MCBorderLayout) {
/* 1468 */           MCBorderLayout bl = (MCBorderLayout)layout;
/* 1469 */           Component c = bl.getLayoutComponent("Center");
/* 1470 */           if (c instanceof MCTabbedPane) {
/* 1471 */             _setSize(c, dim.width, dim.height, false);
/* 1472 */             _setPreferredSize(c, dim.width, dim.height, false);
/* 1473 */             _setDefaultLocation(c, _getLocation(c.getParent()), dim);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/* 1478 */       flag = true;
/*      */     } 
/*      */     
/* 1481 */     if (isEmbeddedPanel1) {
/* 1482 */       Point pt2 = _getLocation(aPanel.getParent());
/* 1483 */       Point pt3 = _getLocation(aPanel.getParent());
/* 1484 */       pt2 = new Point(pt.x + pt2.x, pt.y + pt2.y);
/*      */       
/* 1486 */       if (!pt3.equals(pt2)) {
/*      */         
/* 1488 */         int dx = _getX(aPanel.getParent()) - pt2.x;
/* 1489 */         int dy = _getY(aPanel.getParent()) - pt2.y;
/* 1490 */         _setLocation(aPanel.getParent(), pt2);
/* 1491 */         _setDefaultLocation(aPanel.getParent(), pt2, null);
/* 1492 */         moveSubComponents(aPanel, dx, dy);
/* 1493 */         flag = true;
/*      */       } 
/*      */     } else {
/* 1496 */       Point pt2 = _getLocation(aPanel);
/* 1497 */       pt2 = new Point(pt.x + pt2.x, pt.y + pt2.y);
/*      */       
/* 1499 */       if (!_getLocation(aPanel).equals(pt2)) {
/* 1500 */         _setLocation(aPanel, pt2);
/* 1501 */         _setDefaultLocation(aPanel, pt2, null);
/* 1502 */         flag = true;
/*      */       } 
/*      */     } 
/*      */     
/* 1506 */     return flag;
/*      */   } protected void moveSubComponents(Container c, int offsetX, int offsetY) {
/*      */     byte b;
/*      */     int i;
/*      */     Component[] arrayOfComponent;
/* 1511 */     for (i = (arrayOfComponent = getAllComponents4(c)).length, b = 0; b < i; ) { Component c1 = arrayOfComponent[b];
/* 1512 */       _setLocation(c1, new Point(_getX(c1) + offsetX, _getY(c1) + offsetY));
/* 1513 */       _setDefaultLocation(c1, _getLocation(c1), null);
/*      */       b++; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean setComponentUnionBounds(Container parentPanel, HashMap<Container, Rectangle> unionRectMap, boolean hasMargin) {
/* 1527 */     int originX = 0;
/* 1528 */     int originY = 0;
/*      */     
/* 1530 */     Point origin = new Point(originX, originY);
/* 1531 */     Rectangle r = null;
/*      */     
/* 1533 */     r = getComponentUnionBoundsSub(parentPanel, r, unionRectMap);
/*      */     
/* 1535 */     if (r == null) {
/* 1536 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 1540 */     boolean isEmbeddedPanel = isEmbeddedPanel1(parentPanel, false);
/*      */ 
/*      */     
/* 1543 */     int offsetX = 0;
/* 1544 */     int offsetY = 0;
/* 1545 */     int offsetW = 0;
/* 1546 */     int offsetH = 0;
/* 1547 */     if (parentPanel instanceof MCPanel) {
/* 1548 */       boolean isTablePanel = isTablePanel(parentPanel);
/* 1549 */       Border b = ((MCPanel)parentPanel).getBorder();
/* 1550 */       if (!(b instanceof MCTitledBorder) || isTablePanel)
/*      */       {
/* 1552 */         if (b == null) {
/* 1553 */           if (!hasMargin) {
/* 1554 */             offsetX = 0;
/* 1555 */             offsetY = 0;
/* 1556 */             offsetW = 0;
/* 1557 */             offsetH = 0;
/*      */           }
/* 1559 */           else if (!hasTitledBorderPanel(parentPanel)) {
/* 1560 */             offsetX = 0;
/* 1561 */             offsetY = 0;
/* 1562 */             offsetW = 0;
/* 1563 */             offsetH = 0;
/*      */           } else {
/* 1565 */             offsetX = 0;
/* 1566 */             offsetY = 0;
/* 1567 */             offsetW = 12;
/* 1568 */             offsetH = 3;
/*      */           }
/*      */         
/*      */         }
/*      */       }
/* 1573 */     } else if (parentPanel instanceof MCTabbedPane) {
/* 1574 */       offsetX = 0;
/* 1575 */       offsetY = 0;
/* 1576 */       offsetW = 0;
/* 1577 */       offsetH = 0;
/*      */     } 
/*      */     
/* 1580 */     int w = r.width + offsetW;
/*      */     
/* 1582 */     if (!this._targetPanel.isAutoLayoutUseAutoLayout()) {
/*      */       
/* 1584 */       if (!_isFitPanel(parentPanel)) {
/* 1585 */         w = _getWidth(parentPanel);
/*      */       } else {
/*      */         
/* 1588 */         w = r.width + offsetW;
/*      */       } 
/*      */     } else {
/*      */       
/* 1592 */       boolean usePrefSize = usePrefSize(this._targetPanel);
/* 1593 */       boolean useScrollPane = useScrollPane(this._targetPanel);
/*      */ 
/*      */       
/* 1596 */       if (isEmbeddedPanel) {
/* 1597 */         w = r.width + offsetW;
/*      */ 
/*      */       
/*      */       }
/* 1601 */       else if (!_isFitPanel(parentPanel)) {
/*      */ 
/*      */         
/* 1604 */         if (!usePrefSize && !useScrollPane) {
/* 1605 */           w = _getWidth(parentPanel);
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1612 */         w = r.width + offsetW + 10;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1621 */       if (!usePrefSize && !useScrollPane) {
/* 1622 */         Dimension dim = _getPreferredSize((Component)this._targetPanel);
/* 1623 */         if (dim.width > 0 && w > dim.width) {
/* 1624 */           w = dim.width;
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 1629 */     int h = r.height + offsetH;
/* 1630 */     r.setLocation(r.x - origin.x + offsetX, r.y - origin.y + offsetY);
/* 1631 */     r.setSize(w, h);
/*      */     
/* 1633 */     unionRectMap.put(parentPanel, r);
/* 1634 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean isVisibleComponent(Component c) {
/* 1639 */     if (!isVisibleForMode(c)) {
/* 1640 */       return false;
/*      */     }
/* 1642 */     if (!isVisibleForPersonalize(c)) {
/* 1643 */       return false;
/*      */     }
/* 1645 */     if (_getHeight(c) == 0 || _getWidth(c) == 0) {
/* 1646 */       return false;
/*      */     }
/* 1648 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected Rectangle getComponentUnionBoundsSub(Container parentPanel, Rectangle r, HashMap<Container, Rectangle> unionRectMap) {
/* 1654 */     if (parentPanel.getLayout() instanceof javax.swing.BoxLayout) {
/* 1655 */       return null;
/*      */     }
/*      */     
/* 1658 */     Rectangle r1 = r;
/*      */     
/* 1660 */     boolean isTabbedPane = isTabbedPane(parentPanel);
/* 1661 */     boolean _hasTitledBorder = _hasTitledBorder(parentPanel);
/*      */     
/* 1663 */     Component[] comps = getAllComponents4(parentPanel); byte b; int i; Component[] arrayOfComponent1;
/* 1664 */     for (i = (arrayOfComponent1 = comps).length, b = 0; b < i; ) { Component comp = arrayOfComponent1[b];
/* 1665 */       if (isTabbedPane || isVisibleComponent(comp))
/*      */       {
/*      */ 
/*      */         
/* 1669 */         if (!(comp instanceof javafx.embed.swing.JFXPanel))
/*      */         {
/*      */ 
/*      */ 
/*      */           
/* 1674 */           if (comp instanceof MCPanel || 
/* 1675 */             comp instanceof MCRootPanel || 
/* 1676 */             comp instanceof MCTabbedPane || 
/* 1677 */             comp instanceof MCScrollPane || 
/* 1678 */             comp instanceof JViewport) {
/*      */ 
/*      */             
/* 1681 */             if (!isTablePanel((Container)comp)) {
/*      */ 
/*      */ 
/*      */               
/* 1685 */               Rectangle r2 = getComponentUnionBoundsSub((Container)comp, null, unionRectMap);
/* 1686 */               if (r2 != null) {
/* 1687 */                 r2.setLocation(new Point(_getX(comp), _getY(comp)));
/*      */                 
/* 1689 */                 unionRectMap.put((Container)comp, r2);
/* 1690 */                 if (r1 == null)
/* 1691 */                 { r1 = r2; }
/*      */                 else
/* 1693 */                 { r1 = r1.union(r2); } 
/*      */               } 
/*      */             } 
/* 1696 */           } else if (!isComboBoxClassName(comp)) {
/*      */ 
/*      */             
/* 1699 */             if (!(comp instanceof javax.swing.Box)) {
/* 1700 */               Point pt = new Point(_getXOnPanel(comp, null), _getYOnPanel(comp, null));
/* 1701 */               int w = _getWidth(comp);
/* 1702 */               int h = _getHeight(comp);
/* 1703 */               if (comp instanceof MCCheckBox || comp instanceof MCRadioButton) {
/* 1704 */                 w += getSpacerWidth2();
/*      */               }
/*      */               
/* 1707 */               if (r1 == null) {
/* 1708 */                 r1 = new Rectangle(pt.x, pt.y, w, h);
/*      */               } else {
/* 1710 */                 Rectangle br = new Rectangle(pt.x, pt.y, w, h);
/* 1711 */                 r1 = r1.union(br);
/*      */               } 
/*      */             } 
/*      */           }  }  } 
/*      */       b++; }
/*      */     
/* 1717 */     if (r1 != null)
/*      */     {
/* 1719 */       if (isTabbedPane) {
/* 1720 */         r1.setSize(r1.width, r1.height + getTabHeight());
/* 1721 */       } else if (!_hasTitledBorder) {
/*      */         
/* 1723 */         if (!isEmbeddedPanel(parentPanel))
/*      */         {
/* 1725 */           r1.setSize(r1.width + getEmbeddedOffset(), r1.height);
/*      */         }
/* 1727 */       } else if (_hasTitledBorder) {
/*      */         
/* 1729 */         int margin = 8;
/* 1730 */         r1.x = _getX(parentPanel);
/* 1731 */         r1.y = _getY(parentPanel);
/* 1732 */         r1.setSize(r1.width + margin, r1.height + getTitledBorderOffset());
/*      */       } 
/*      */     }
/*      */     
/* 1736 */     return r1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isComboBoxClassName(Component comp) {
/* 1746 */     return isComboBoxClassName(comp.getClass().getName());
/*      */   }
/*      */   protected static boolean isComboBoxClassName(String clsName) {
/*      */     String str;
/* 1750 */     switch ((str = clsName).hashCode()) { case -1652600262: if (!str.equals("mcframe.clientCore.beans.combobox.MCNumberComboBox$MCNumberComboField")) {
/*      */           break;
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1756 */         return true;case -1264261908: if (!str.equals("mcframe.clientCore.beans.combobox.MCTimestampComboBox$MCTimestampComboField")) break;  return true;case 591245265: if (!str.equals("mcframe.clientCore.beans.combobox.MCComboButton")) break;  return true;case 805693722: if (!str.equals("mcframe.clientCore.beans.combobox.MCDateComboBox$MCDateComboField")) break;  return true;case 962474810: if (!str.equals("mcframe.clientCore.beans.combobox.MCTextComboBox$MCTextComboField")) break;  return true; }
/*      */     
/* 1758 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   protected Container getParentPanel1(Component c) {
/*      */     Container p;
/* 1764 */     if (c instanceof MCTextArea) {
/* 1765 */       MCScrollPane mCScrollPane = ((MCTextArea)c).getScrollPaneForLayout();
/*      */     } else {
/* 1767 */       p = c.getParent();
/*      */     } 
/* 1769 */     return p;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Container getParentPanel(Component comp) {
/* 1779 */     Container c = getParentPanel1(comp);
/* 1780 */     return getParentPanel2(c);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected Container getParentPanel2(Container container) {
/* 1786 */     Container c = container;
/* 1787 */     Container find = container;
/* 1788 */     while (c != null) {
/* 1789 */       if (c instanceof MCRootPanel) {
/* 1790 */         if (((MCRootPanel)c).getUnderPanel() != null) {
/* 1791 */           c = c.getParent();
/* 1792 */           find = c;
/*      */           continue;
/*      */         } 
/* 1795 */         return c;
/* 1796 */       }  if (c instanceof MCPanel) {
/*      */ 
/*      */         
/* 1799 */         if (c.getName() != null) {
/* 1800 */           int n = this._panelList.indexOf(c);
/* 1801 */           if (n != -1) {
/* 1802 */             return c;
/*      */           }
/*      */           
/* 1805 */           Border b = ((MCPanel)c).getBorder();
/* 1806 */           if (b != null && b instanceof MCTitledBorder) {
/* 1807 */             return find;
/*      */           }
/*      */         } 
/* 1810 */         find = c;
/*      */       } 
/* 1812 */       c = c.getParent();
/*      */     } 
/* 1814 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isTablePanel(Container comp) {
/* 1820 */     for (Component c : getAllComponents(comp)) {
/* 1821 */       if (c instanceof MCTable) {
/* 1822 */         return true;
/*      */       }
/*      */     } 
/* 1825 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEmbeddedPanel(Container comp) {
/* 1836 */     if (comp instanceof MCPanel && ((MCPanel)comp).getLayoutPosition() != null)
/*      */     {
/*      */       
/* 1839 */       return false; }  byte b;
/*      */     int i;
/*      */     Component[] arrayOfComponent;
/* 1842 */     for (i = (arrayOfComponent = getAllComponents4(comp)).length, b = 0; b < i; ) { Component component = arrayOfComponent[b];
/* 1843 */       if (component instanceof MCTable) {
/* 1844 */         return false;
/*      */       }
/*      */       b++; }
/*      */     
/* 1848 */     Container c = getParentPanel1(comp);
/* 1849 */     while (c != null) {
/* 1850 */       if (c instanceof MCRootPanel) {
/* 1851 */         if (((MCRootPanel)c).getUnderPanel() != null) {
/* 1852 */           return true;
/*      */         }
/* 1854 */       } else if (c instanceof MCPanel) {
/*      */         
/* 1856 */         if (c.getName().startsWith("_")) {
/* 1857 */           return false;
/*      */         }
/* 1859 */         if (!MCBeansProxy.PROXY.isEnableAutoLayout((MCPanel)c)) {
/* 1860 */           return false;
/*      */         }
/*      */       } 
/* 1863 */       c = c.getParent();
/*      */     } 
/* 1865 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEmbeddedPanel3(Container comp) {
/* 1875 */     boolean b1 = isEmbeddedPanel(comp);
/* 1876 */     if (b1)
/*      */     {
/* 1878 */       if (comp.getParent() instanceof MCRootPanel) {
/* 1879 */         return true;
/*      */       }
/*      */     }
/*      */     
/* 1883 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isEmbeddedPanel1(Container comp, boolean useTabOrder) {
/* 1895 */     if (comp instanceof MCPanel && ((MCPanel)comp).getLayoutPosition() != null)
/*      */     {
/* 1897 */       return false; }  byte b;
/*      */     int i;
/*      */     Component[] arrayOfComponent;
/* 1900 */     for (i = (arrayOfComponent = getAllComponents4(comp)).length, b = 0; b < i; ) { Component component = arrayOfComponent[b];
/* 1901 */       if (component instanceof MCTable) {
/* 1902 */         return false;
/*      */       }
/*      */       b++; }
/*      */     
/* 1906 */     Container c = comp;
/* 1907 */     while (c != null) {
/* 1908 */       if (c instanceof MCRootPanel) {
/* 1909 */         if (((MCRootPanel)c).getUnderPanel() != null) {
/* 1910 */           return true;
/*      */         }
/* 1912 */       } else if (c instanceof MCPanel) {
/*      */         
/* 1914 */         if (useTabOrder && ((MCPanel)c).isTabOrderChildPanel())
/*      */         {
/* 1916 */           return true;
/*      */         }
/*      */         
/* 1919 */         if (c.getName().startsWith("_")) {
/* 1920 */           if (c.getName().startsWith("_tbar")) {
/* 1921 */             return true;
/*      */           }
/* 1923 */           return false;
/*      */         } 
/*      */         
/* 1926 */         if (!MCBeansProxy.PROXY.isEnableAutoLayout((MCPanel)c)) {
/* 1927 */           return false;
/*      */         }
/*      */       } 
/* 1930 */       c = c.getParent();
/*      */     } 
/* 1932 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Container getTopPanel(Container p) {
/* 1943 */     Container p1 = getTopPanel2(p);
/* 1944 */     if (p1 != null) {
/* 1945 */       return p1;
/*      */     }
/* 1947 */     return p;
/*      */   }
/*      */ 
/*      */   
/*      */   protected Container getTopPanel2(Container p) {
/* 1952 */     List<Container> pList = new ArrayList<>();
/* 1953 */     getTopPanel3(p, pList);
/*      */     
/* 1955 */     int findIdx = -1;
/* 1956 */     for (Container p1 : this._panelList) {
/* 1957 */       if (p1 != p) {
/* 1958 */         int idx = pList.indexOf(p1);
/* 1959 */         if (idx > findIdx) {
/* 1960 */           findIdx = idx;
/*      */         }
/*      */       } 
/*      */     } 
/* 1964 */     if (findIdx >= 0) {
/* 1965 */       return pList.get(findIdx);
/*      */     }
/* 1967 */     return null;
/*      */   }
/*      */   
/*      */   protected void getTopPanel3(Container p, List<Container> pList) {
/* 1971 */     if (p == null) {
/*      */       return;
/*      */     }
/*      */     
/* 1975 */     Container parent = p.getParent();
/* 1976 */     if (parent == null) {
/*      */       return;
/*      */     }
/* 1979 */     pList.add(parent);
/* 1980 */     getTopPanel3(parent, pList);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Component> getGroupList(Component comp) {
/* 1990 */     for (List<Component> list : this._groupList) {
/* 1991 */       if (list.contains(comp)) {
/* 1992 */         return list;
/*      */       }
/*      */     } 
/* 1995 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void setParentPanelComponents(Container comp, List<Component> list, boolean allComponents) {
/* 2000 */     setParentPanelComponents2(comp, list, allComponents);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void setParentPanelComponents2(Container comp, List<Component> list, boolean allComponents) {
/* 2005 */     Component[] components = getAllComponents4(comp); byte b; int i;
/*      */     Component[] arrayOfComponent1;
/* 2007 */     for (i = (arrayOfComponent1 = components).length, b = 0; b < i; ) { Component c = arrayOfComponent1[b];
/* 2008 */       if (canMoveComponent1(c, false, true, true, false)) {
/* 2009 */         list.add(c);
/*      */       }
/* 2011 */       if (c instanceof MCPanel && 
/* 2012 */         !this._panelList.contains(c)) {
/* 2013 */         setParentPanelComponents2((Container)c, list, allComponents);
/*      */       }
/*      */       b++; }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setupPanelList() {
/* 2025 */     this._panelList = new ArrayList<>();
/* 2026 */     this._fitPanelList = new ArrayList<>();
/*      */ 
/*      */     
/* 2029 */     List<MCPanel> list = getAllPanels((Container)this._targetPanel);
/*      */     
/* 2031 */     for (MCPanel p1 : list) {
/* 2032 */       if (isComboBoxClassName((Component)p1)) {
/*      */         continue;
/*      */       }
/*      */       
/* 2036 */       if (MCBeansProxy.PROXY.isEnableAutoLayout(p1) && 
/* 2037 */         p1.getName() != null && !p1.getName().substring(0, 1).equals("_")) {
/* 2038 */         boolean _hasTitledBorder = _hasTitledBorder((Component)p1);
/* 2039 */         if (_hasTitledBorder) {
/* 2040 */           if (this._panelList.indexOf(p1) == -1) {
/* 2041 */             this._panelList.add(p1);
/*      */           }
/* 2043 */         } else if (isTabbedPane((Container)p1)) {
/* 2044 */           if (this._panelList.indexOf(p1) == -1) {
/* 2045 */             List<MCPanel> subPanelList = getTabPanelList(p1);
/* 2046 */             this._panelList.add(p1);
/* 2047 */             for (MCPanel p2 : subPanelList) {
/* 2048 */               if (this._panelList.indexOf(p2) == -1) {
/* 2049 */                 this._panelList.add(p2);
/*      */               }
/*      */             }
/*      */           
/*      */           }
/*      */         
/* 2055 */         } else if (p1.getLayoutPosition() != null && 
/* 2056 */           this._panelList.indexOf(p1) == -1) {
/* 2057 */           this._panelList.add(p1);
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2065 */       boolean b = false;
/* 2066 */       MCPanel mCPanel1 = p1;
/* 2067 */       while (mCPanel1 != null) {
/* 2068 */         if (mCPanel1 instanceof MCResourceBeans) {
/* 2069 */           boolean b2 = MCBeansUtil.getFit((MCResourceBeans)mCPanel1);
/* 2070 */           if (b2) {
/* 2071 */             b = true;
/*      */             break;
/*      */           } 
/*      */         } 
/* 2075 */         Container container = mCPanel1.getParent();
/*      */       } 
/*      */ 
/*      */       
/* 2079 */       if (b) {
/* 2080 */         this._fitPanelList.add(p1);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<Container> getPanelList() {
/* 2091 */     return this._panelList;
/*      */   }
/*      */   public void setupGroupList() { this._groupList = new ArrayList<>(); List<Component> list = getAllComponents((Container)this._targetPanel); if (this.useLabelGroup) { Comparator<Component> comparator; int idx = 0; if (this.useLayoutLocationForSortPolicy) { comparator = new ComponentComparatorXY2(null); } else { comparator = new ComponentComparatorXY((Container)this._targetPanel, false, null); }  while (idx < list.size()) { Component c = list.get(idx); Component comp = c; if (canMoveComponent2(c, false, true, false, false)) { Container p = getParentPanel1(comp); List<Component> list2 = getAllComponents3(p); if (this.useLayoutLocationForSortPolicy) { Collections.sort(list2, comparator); } else { Collections.sort(list2, comparator); }  List<Component> pair = new ArrayList<>(); MCLabel lbl = getLabelComponent(comp, list2); if (lbl != null) { Component component; boolean lblFlg = false; boolean first = true; boolean second = false; MCLabel mCLabel = lbl; while (first || lblFlg || isGroupComponent((Component)mCLabel)) { lblFlg = false; if (first) lblFlg = true;  first = false; if (isComboBoxClassName((Component)mCLabel) || !canMoveComponent2(c, false, true, false, false) || mCLabel instanceof mcframe.clientCore.beans.combobox.MCComboButton) { if (idx < list.size() - 1) { idx++; component = list.get(idx); continue; }  break; }  if (lbl != component && !second) { if (!isGroupLabelComponent(component)) break;  second = true; }  pair.add(component); if (idx < list.size() - 1) { idx++; component = list.get(idx); continue; }  break; }  if (pair.size() > 1) this._groupList.add(pair);  if (component instanceof MCLabel && lbl != component) continue;  }  }  idx++; }  } else { Comparator<Component> comparator; HashSet<Component> set = new HashSet<>(); if (this.useLayoutLocationForSortPolicy) { comparator = new ComponentComparatorXY2(null); } else { comparator = new ComponentComparatorXY((Container)this._targetPanel, false, null); }  for (Component c : list) { if (set.contains(c)) continue;  Component comp = c; if (canMoveComponent2(c, false, true, false, false)) { Container p = getParentPanel1(comp); List<Component> list2 = getAllComponents3(p); if (this.useLayoutLocationForSortPolicy) { Collections.sort(list2, comparator); } else { Collections.sort(list2, comparator); }  List<Component> pair = new ArrayList<>(); MCLabel lbl = getLabelComponent(comp, list2); if (lbl != null) { pair.add(lbl); Component codeField = getCodeField((Component)lbl, list2); if (codeField != null) { pair.add(codeField); Component nameField = getNameField(codeField, list2); if (nameField != null) { pair.add(nameField); } else { Component timeField = getTimeField(codeField, list2); if (timeField != null) pair.add(timeField);  }  } else { Component checkField = getCheckField((Component)lbl, list2); if (checkField != null) { pair.add(checkField); codeField = getCodeField((Component)lbl, list2); if (codeField != null) { pair.add(codeField); Component nameField = getNameField(codeField, list2); if (nameField != null) { pair.add(nameField); } else { Component timeField = getTimeField(codeField, list2); if (timeField != null) pair.add(timeField);  }  }  }  }  if (pair.size() > 1) { for (Component c2 : pair) set.add(c2);  this._groupList.add(pair); }  }  }  }  }  }
/*      */   protected boolean isGroupLabelComponent(Component comp) { if (comp instanceof MCLabel) return false;  if (comp instanceof MCPanel) return false;  if (comp instanceof MCRootPanel) return false;  if (comp instanceof MCTabbedPane) return false;  if (comp instanceof MCSplitPane) return false;  if (comp instanceof MCScrollPane) { MCTextArea ta = getTextArea(comp); if (ta != null) return true;  return false; }  if (comp instanceof MCRadioButton) return true;  return true; }
/* 2095 */   protected boolean isGroupComponent(Component comp) { if (comp instanceof MCLabel) return false;  if (comp instanceof MCField) return true;  if (comp instanceof MCPasswordField) return true;  if (comp instanceof MCTextArea) return true;  if (comp instanceof MCImageView && this._useImageView) return true;  if (comp instanceof MCFieldComboBox) return true;  if (comp instanceof mcframe.clientCore.beans.combobox.MCComboField) return true;  if (comp instanceof mcframe.clientCore.beans.combobox.MCComboButton) return true;  if (comp instanceof MCCheckBox) { MCCheckBox cb = (MCCheckBox)comp; String lbl = cb.getLabelByLocale(); Icon icn = cb.getIcon(); if (lbl != null && lbl.length() > 0) return false;  if (icn != null) return false;  return true; }  return false; } protected MCLabel getLabel(String aCompName, List<Component> aList) { String compName = String.valueOf(aCompName) + "_Label"; for (Component c : aList) { if (c instanceof MCLabel && c.getName().equals(compName)) return (MCLabel)c;  }  return null; } protected MCLabel getLabelComponent(Component comp, List<Component> aList) { if (comp instanceof MCLabel) return (MCLabel)comp;  if (comp instanceof MCButton) return null;  if (comp instanceof MCField) { MCLabel lbl = ((MCField)comp).getLabel(); return lbl; }  if (comp instanceof MCPasswordField) { MCLabel lbl = ((MCPasswordField)comp).getLabel(); return lbl; }  if (comp instanceof MCTextArea) { MCLabel lbl = ((MCTextArea)comp).getLabel(); return lbl; }  if (comp instanceof MCImageView && this._useImageView) { MCLabel lbl = getLabel(comp.getName(), aList); return lbl; }  if (comp instanceof mcframe.clientCore.beans.combobox.MCComboField) { MCLabel lbl = getLabel(comp.getName(), aList); return lbl; }  if (comp instanceof MCCheckBox) return null;  if (comp instanceof MCFieldComboBox) { MCLabel lbl = ((MCFieldComboBox)comp).getLabel(); return lbl; }  if (comp instanceof mcframe.clientCore.beans.combobox.MCTextComboBox) { MCLabel lbl = getLabel(comp.getName(), aList); return lbl; }  if (comp instanceof mcframe.clientCore.beans.combobox.MCNumberComboBox) { MCLabel lbl = getLabel(comp.getName(), aList); return lbl; }  if (comp instanceof mcframe.clientCore.beans.combobox.MCDateComboBox) { MCLabel lbl = getLabel(comp.getName(), aList); return lbl; }  if (comp instanceof mcframe.clientCore.beans.combobox.MCTimestampComboBox) { MCLabel lbl = getLabel(comp.getName(), aList); return lbl; }  if (comp instanceof MCRadioButton) return null;  return null; } protected Component getCodeField(Component comp, List<Component> aList) { if (comp instanceof MCLabel) { int idx = aList.indexOf(comp); if (idx == -1) return null;  if (aList.size() <= idx + 1) return null;  idx++; Component c2 = aList.get(idx); if (c2 instanceof MCScrollPane) { MCTextArea ta = getTextArea(c2); if (ta != null) return (Component)ta;  } else if (canUseNameComponent(c2)) { return c2; }  }  return null; } protected MCTextArea getTextArea(Component c) { if (c instanceof MCScrollPane) { MCScrollPane sc = (MCScrollPane)c; Component p = sc.getViewport().getView(); if (p instanceof MCTextArea) return (MCTextArea)p;  }  return null; } protected Component getNameField(Component comp, List<Component> aList) { int idx = aList.indexOf(comp); if (idx == -1) return null;  if (aList.size() <= idx + 1) return null;  idx++; Component c2 = aList.get(idx); if (canUseNameComponent(c2)) return c2;  return null; } protected boolean canUseNameComponent(Component c) { if (c instanceof mcframe.clientCore.beans.MCTextField || c instanceof mcframe.clientCore.beans.MCNumberField || c instanceof MCPasswordField || c instanceof mcframe.clientCore.beans.combobox.MCComboField || c instanceof mcframe.clientCore.beans.MCDateField || c instanceof mcframe.clientCore.beans.MCTimestampField || c instanceof mcframe.clientCore.beans.combobox.MCTextComboBox || c instanceof mcframe.clientCore.beans.combobox.MCNumberComboBox || c instanceof mcframe.clientCore.beans.combobox.MCDateComboBox || c instanceof mcframe.clientCore.beans.combobox.MCTimestampComboBox || c instanceof MCTextArea) return true;  return false; } protected Component getTimeField(Component comp, List<Component> aList) { if (comp instanceof mcframe.clientCore.beans.MCDateField || comp instanceof mcframe.clientCore.beans.MCTimestampField) { int idx = aList.indexOf(comp); if (idx == -1) return null;  if (aList.size() <= idx + 1) return null;  idx++; Component c2 = aList.get(idx); if (c2 instanceof mcframe.clientCore.beans.MCDateField || c2 instanceof mcframe.clientCore.beans.MCTimestampField) return c2;  }  return null; } protected Component getCheckField(Component comp, List<Component> aList) { int idx = aList.indexOf(comp); if (idx == -1) return null;  if (aList.size() <= idx + 1) return null;  idx++; Component c2 = aList.get(idx); if (c2 instanceof MCCheckBox) { MCCheckBox cb = (MCCheckBox)c2; String lbl = cb.getLabelByLocale(); Icon icn = cb.getIcon(); if (lbl != null && lbl.length() > 0) return null;  if (icn != null) return null;  return c2; }  return null; } public boolean canMoveComponent1(Component comp, boolean usePanel, boolean allComponents, boolean hasInputContainer, boolean useAllPanel) { if (!isShowing(comp)) return false;  return canMoveComponent2(comp, usePanel, allComponents, hasInputContainer, useAllPanel); } public boolean canMoveComponent2(Component comp, boolean usePanel, boolean allComponents, boolean hasInputContainer, boolean useAllPanel) { MCTextArea mCTextArea; Component comp2 = comp; if (isTextArea(comp)) mCTextArea = getTextArea(comp);  if (!(mCTextArea instanceof MCResourceBeans)) return false;  if (mCTextArea instanceof MCPanel && isInputContainerPanel((Component)mCTextArea)) return true;  String clsName = mCTextArea.getClass().getName(); if (isComboBoxClassName(clsName)) return false;  if (clsName.indexOf("MCMenuButton") != -1) return false;  if (mCTextArea instanceof MCPanel) { if (useAllPanel) return true;  if (usePanel) for (Container panel : this._panelList) { if (panel == mCTextArea) return true;  }   return false; }  if (canUseComponent((Component)mCTextArea)) { if (hasInputContainer && hasInputContainerComponent((Component)mCTextArea)) return false;  if (isInputBtn((Component)mCTextArea)) return false;  Container findPanel = null; for (Container panel : this._panelList) { List<Component> list; if (allComponents) { list = getAllComponents(panel); } else { list = new ArrayList<>(); setParentPanelComponents(panel, list, false); }  if (list.contains(mCTextArea)) { findPanel = panel; break; }  }  if (findPanel == null) return false;  return true; }  return false; } public boolean canUseComponent(Component c) { if (c instanceof MCLabel || c instanceof MCButton || c instanceof mcframe.clientCore.beans.MCTextField || c instanceof mcframe.clientCore.beans.MCNumberField || c instanceof MCPasswordField || c instanceof mcframe.clientCore.beans.MCDateField || c instanceof mcframe.clientCore.beans.MCTimestampField || c instanceof mcframe.clientCore.beans.combobox.MCComboField || c instanceof mcframe.clientCore.beans.combobox.MCTextComboBox || c instanceof mcframe.clientCore.beans.combobox.MCNumberComboBox || c instanceof mcframe.clientCore.beans.combobox.MCDateComboBox || c instanceof mcframe.clientCore.beans.combobox.MCTimestampComboBox || c instanceof MCTextArea || (c instanceof MCImageView && this._useImageView) || c instanceof MCRadioButton || c instanceof MCCheckBox) return true;  return false; } protected boolean hasTitledBorderPanel(Container p) { if (!(p instanceof MCPanel)) return false;  Border b = ((MCPanel)p).getBorder(); if (b instanceof MCTitledBorder) return true;  return false; } public boolean hasInputContainerComponent(Component c) { Container p = getParentPanel1(c); while (p != null) { if (p instanceof MCPanel) return isInputContainerPanel(p);  p = p.getParent(); }  return false; } protected boolean isInputBtn(Component c) { if (c instanceof MCButton && "_imput_btn_is".equals(c.getName())) return true;  return false; } protected Map<String, MCLayoutLocationR> locationMap() { return (this._targetPanel != null) ? this._targetPanel.getLocationMap() : new LinkedHashMap<>(); } protected Map<String, MCLayoutPanelR> panelMap() { return (this._targetPanel != null) ? this._targetPanel.getPanelMap() : new LinkedHashMap<>(); } protected Map<String, MCLayoutLocationR> systemLocationMap() { return (this._targetPanel != null) ? this._targetPanel.getSystemLocationMap() : new LinkedHashMap<>(); } protected Map<String, MCLayoutLocationR> systemLocationMap2() { return (this._targetPanel != null) ? this._targetPanel.getSystemLocationMap2() : new LinkedHashMap<>(); } protected Map<String, MCLayoutPanelR> panelMap2() { return (this._targetPanel != null) ? this._targetPanel.getPanelMap2() : new LinkedHashMap<>(); } protected Map<String, MCLayoutLocationR> defaultLocationMap() { return (this._targetPanel != null) ? this._targetPanel.getDefaultLocationMap() : new LinkedHashMap<>(); } protected List<MCLocationSortR> sortList() { return (this._targetPanel != null) ? this._targetPanel.getPersonalizeSortList() : new ArrayList<>(); } protected List<Component> getAllComponents(Container c) { if (this.compomentsCache == null) this.compomentsCache = new HashMap<>();  if (this.compomentsCache.containsKey(c)) return this.compomentsCache.get(c);  Component[] comps = getAllComponents4(c); List<Component> compList = new ArrayList<>(); byte b; int i; Component[] arrayOfComponent1; for (i = (arrayOfComponent1 = comps).length, b = 0; b < i; ) { Component comp = arrayOfComponent1[b]; compList.add(comp); if (comp instanceof Container) compList.addAll(getAllComponents((Container)comp));  b++; }  this.compomentsCache.put(c, compList); return compList; } private List<MCPanel> getAllPanels(Container c) { if (this.panelListCache == null) this.panelListCache = new HashMap<>();  if (this.panelListCache.containsKey(c)) return this.panelListCache.get(c);  List<MCPanel> compList = new ArrayList<>(); _getAllPanels(c, compList); this.panelListCache.put(c, compList); return compList; } private void _getAllPanels(Container c, List<MCPanel> compList) { Component[] comps = getAllComponents4(c); byte b; int i; Component[] arrayOfComponent1; for (i = (arrayOfComponent1 = comps).length, b = 0; b < i; ) { Component comp = arrayOfComponent1[b]; if (comp instanceof MCPanel) compList.add((MCPanel)comp);  if (comp instanceof Container) _getAllPanels((Container)comp, compList);  b++; }  } protected List<Container> getPanels(Container c, boolean useScrollPane) { if (this.panelListCache2 == null) this.panelListCache2 = new HashMap<>();  if (this.panelListCache2.containsKey(c)) return this.panelListCache2.get(c);  List<Container> compList = new ArrayList<>(); _getPanels(c, compList, useScrollPane); this.panelListCache2.put(c, compList); return compList; } private void _getPanels(Container c, List<Container> compList, boolean useScrollPane) { Component[] comps = getAllComponents4(c); if (useScrollPane) { byte b; int i; Component[] arrayOfComponent; for (i = (arrayOfComponent = comps).length, b = 0; b < i; ) { Component c2 = arrayOfComponent[b]; if (c2 instanceof MCScrollPane) { Container p = ((MCScrollPane)c2).getViewport(); Component[] comps2 = getAllComponents4(p); if (comps2.length == 1) { Component c3 = comps2[0]; if (c3 instanceof MCPanel) { Component[] comps3 = getAllComponents4((Container)c3); addLayoutPanel(compList, comps3); }  }  }  b++; }  }  addLayoutPanel(compList, comps); } private void addLayoutPanel(List<Container> compList, Component... comps) { byte b; int i; Component[] arrayOfComponent; for (i = (arrayOfComponent = comps).length, b = 0; b < i; ) { Component comp = arrayOfComponent[b]; if (comp instanceof MCPanel) { compList.add((Container)comp); } else if (comp instanceof MCRootPanel) { compList.add((Container)comp); } else if (comp instanceof MCTabbedPane) { compList.add((Container)comp); } else if (comp instanceof MCSplitPane) { compList.add((Container)comp); }  b++; }  } private MCPanel getInputContainer(Component comp) { Container c = getParentPanel1(comp); while (c != null) { if (c instanceof MCPanel) { if (isInputContainerPanel(c)) return (MCPanel)c;  return null; }  c = c.getParent(); }  return null; } public boolean isInputContainerPanel(Component p) { return "_input_container_is".equals(p.getName()); } public Map<String, MCLayoutLocationR> mergeSystemLocation(Map<String, MCLayoutLocationR> map) { Map<String, MCLayoutLocationR> map2 = new LinkedHashMap<>(); Map<String, MCLayoutLocationR> map3 = systemLocationMap(); if (!map3.isEmpty()) { map3.entrySet().forEach(e1 -> { MCLayoutLocationR r3 = (MCLayoutLocationR)paramMap.get(e1.getKey()); if (r3 == null) paramMap.put(e1.getKey(), e1.getValue());  }); map.entrySet().forEach(e1 -> { MCLayoutLocationR r2 = (MCLayoutLocationR)paramMap1.get(e1.getKey()); if (r2 != null) { MCLayoutLocationR r1 = e1.getValue(); boolean f = false; if (!r2.isVisible()) { r1.systemInvisible(true); f = true; }  if (!r1.userHasCr() && r2.userHasCr()) { r1.userHasCr(true); f = true; }  if (!r1.localeHasCr() && r2.localeHasCr()) { r1.localeHasCr(true); f = true; }  if (!r1.localeNoCr() && r2.localeNoCr()) { r1.localeNoCr(true); f = true; }  if (r2.isSystemVisible() && r1.isVisible() != r2.isVisible()) { r1.isVisible(r2.isVisible()); f = true; }  if (r2.isLocaleNoCr() && r1.localeNoCr() != r2.localeNoCr()) { r1.localeNoCr(r2.localeNoCr()); f = true; }  if (f) paramMap2.put(e1.getKey(), r1);  }  }); }  MCModeBeans[] mba = (MCModeBeans[])MCBeansUtil.getAllComponents(MCModeBeans.class, (Container)this._targetPanel); List<MCButtonGroup> gL = new ArrayList<>(); byte b; int i; MCModeBeans[] arrayOfMCModeBeans1; for (i = (arrayOfMCModeBeans1 = mba).length, b = 0; b < i; ) { MCModeBeans mb = arrayOfMCModeBeans1[b]; if (mb instanceof MCRadioButton) { MCButtonGroup g = ((MCRadioButton)mb).getGroup(); if (!gL.contains(g)) { String itemid = MCBeansProxy.PROXY.createGUIKey((MCModeBeans)g); if (MCACLManager.isInvisible(this._targetPanel.getModuleID(), this._targetPanel.getScreenID(), itemid)) { byte b1; int j; MCRadioButton[] arrayOfMCRadioButton; for (j = (arrayOfMCRadioButton = g.getRadioButtons()).length, b1 = 0; b1 < j; ) { MCRadioButton rb = arrayOfMCRadioButton[b1]; setSystemInvisibleLayoutLocationR((Component)rb, map); b1++; }  } else { byte b1; int j; MCRadioButton[] arrayOfMCRadioButton; for (j = (arrayOfMCRadioButton = g.getRadioButtons()).length, b1 = 0; b1 < j; ) { MCRadioButton rb = arrayOfMCRadioButton[b1]; String itemid2 = MCBeansProxy.PROXY.createGUIKey((MCModeBeans)rb); if (MCACLManager.isInvisible(this._targetPanel.getModuleID(), this._targetPanel.getScreenID(), itemid2)) setSystemInvisibleLayoutLocationR((Component)rb, map);  b1++; }  }  gL.add(g); }  } else if (mb instanceof Component) { Component c = (Component)mb; String itemid = MCBeansProxy.PROXY.createGUIKey(mb); if (MCACLManager.isInvisible(this._targetPanel.getModuleID(), this._targetPanel.getScreenID(), itemid)) { setSystemInvisibleLayoutLocationR(c, map); MCLabel l = getMCLabel(c); if (l != null) setSystemInvisibleLayoutLocationR((Component)l, map);  }  }  b++; }  return map2; } private void setSystemInvisibleLayoutLocationR(Component compo, Map<String, MCLayoutLocationR> map) { MCLayoutLocationR r = new MCLayoutLocationR(); r.rootPanelID(getRootPanel(compo).getName()); r.panelID(getParentPanel(compo).getName()); r.componentID(compo.getName()); r.systemInvisible(true); r.isVisible(false); String k = getLocationRKey(r); if (!map.containsKey(k)) { map.put(k, r); } else { r = map.get(k); r.systemInvisible(true); r.isVisible(false); }  } private MCLabel getMCLabel(Component compo) { if (compo instanceof MCField) return ((MCField)compo).getLabel();  if (compo instanceof AbsMCComboBox) return ((AbsMCComboBox)compo).getLabel();  if (compo instanceof MCTextArea) return ((MCTextArea)compo).getLabel();  if (compo instanceof MCPasswordField) return ((MCPasswordField)compo).getLabel();  if (compo instanceof MCImageView) return ((MCImageView)compo).getMCLabel();  return null; } public Map<String, MCLayoutLocationR> mergeSystemLocation2(Map<String, MCLayoutLocationR> map) { Map<String, MCLayoutLocationR> map2 = new LinkedHashMap<>(); Map<String, MCLayoutLocationR> map3 = systemLocationMap2(); if (map3.isEmpty()) return map2;  map3.entrySet().forEach(e1 -> { MCLayoutLocationR r3 = (MCLayoutLocationR)paramMap.get(e1.getKey()); if (r3 == null) paramMap.put(e1.getKey(), e1.getValue());  }); map.entrySet().forEach(e1 -> { MCLayoutLocationR r2 = (MCLayoutLocationR)paramMap1.get(e1.getKey()); if (r2 != null) { MCLayoutLocationR r1 = e1.getValue(); boolean f = false; if (!r1.localeHasCr() && r2.localeHasCr()) { r1.localeHasCr(true); f = true; }  if (!r1.localeNoCr() && r2.localeNoCr()) { r1.localeNoCr(true); f = true; }  if (r1.localeWidth() == null && r2.localeWidth() != null) { r1.localeWidth(r2.localeWidth()); f = true; }  if (f) paramMap2.put(e1.getKey(), r1);  }  }); return map2; } public Map<String, MCLayoutPanelR> mergeSystemLocationPanel2(Map<String, MCLayoutPanelR> map) { Map<String, MCLayoutPanelR> map2 = new LinkedHashMap<>(); Map<String, MCLayoutPanelR> map3 = panelMap2(); if (map3.isEmpty()) return map2;  map3.entrySet().forEach(e1 -> { MCLayoutPanelR r3 = (MCLayoutPanelR)paramMap.get(e1.getKey()); if (r3 == null) paramMap.put(e1.getKey(), e1.getValue());  }); map.entrySet().forEach(e1 -> { MCLayoutPanelR r2 = (MCLayoutPanelR)paramMap1.get(e1.getKey()); if (r2 != null) { MCLayoutPanelR r1 = e1.getValue(); boolean f = false; if (!nullToBoolean(r1.localeFit()) && nullToBoolean(r2.localeFit())) { r1.localeFit(Boolean.valueOf(true)); f = true; }  if (f) paramMap2.put(e1.getKey(), r1);  }  }); return map2; } private boolean nullToBoolean(Boolean b) { if (b == null) return false;  return b.booleanValue(); } private void layoutSub(Map<String, MCLayoutLocationR> map0, Map<String, MCLayoutPanelR> map1, List<MCLocationSortR> list2, boolean isRelayout) { mergeFitPanel(map1); updateLabelSize(); updateLocaleWidth(); if (this._targetPanel.isAutoLayoutUseAutoLayout()) { fitLabelSize(); fitButtonLabelSize(); }  boolean debugFlag1 = false; if (!debugFlag1) for (int n = 0; n < 4 && layoutSub2(map0); n++);  boolean debugFlag2 = false; if (!debugFlag2) if (this._targetPanel.isAutoLayoutUseAutoLayout()) { setCRComponentList(map0, false); List<MCLayoutLocationR> systemLocationList = getSystemLocationComponent(this._targetPanel); List<MCLocationSortR> sortList = list2; for (Container p : this._panelList) autoLayout((MCPanel)p, map0, systemLocationList, sortList);  }   boolean debugFlag3 = false; if (!debugFlag3) { initPanelVisible(isRelayout); updateVisibleComponent((Container)this._targetPanel); if (this._targetPanel.isAutolayoutUseCompressPanel()) { Set<Container> set = new HashSet<>(); for (Container p : this._panelList) { Container p2 = getTopPanel(p); if (!set.contains(p2)) { set.add(p2); compressPanel(p2, map0); }  }  boolean b = compressPanelSub4(); if (b) { set = new HashSet<>(); for (Container p : this._panelList) { Container p2 = getTopPanel(p); if (!set.contains(p2)) { set.add(p2); compressPanel(p2, map0); }  }  }  }  }  } public void relayout() { if (this._targetPanel.isDisableLayoutInit()) return;  if (!this._targetPanel.isEnableDynamicLayout()) return;  MCBorderLayout l = getBorderLayout((Container)this._targetPanel); if (l != null) { l.beforeRelayout(); l.relayout(false); }  if (this._targetPanel.isShowing()) MCBeansUtil.setInitSplitPane(this._targetPanel);  } public void relayout2(boolean _useLayoutLocationForSortPolicy) { MCBorderLayout l = getBorderLayout((Container)this._targetPanel); if (l != null) l.relayout(_useLayoutLocationForSortPolicy);  } public void beforeRelayout() { MCBorderLayout l = getBorderLayout((Container)this._targetPanel); if (l != null) l.beforeRelayout();  } public MCAutoLayout() { this.useLabelGroup = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5591 */     this._layoutSettings = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6020 */     this._embeddedX = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6790 */     this._useFitPanel = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 7917 */     this._debugUseUpdateTabOrder = true; }
/*      */   private MCBorderLayout getBorderLayout(Container c) { while (c != null) { if (c.getName() != null && !c.getName().startsWith("_")) { LayoutManager l = c.getLayout(); if (l instanceof MCBorderLayout) return (MCBorderLayout)l;  }  c = c.getParent(); }  return null; }
/*      */   private boolean layoutSub2(Map<String, MCLayoutLocationR> map0) { List<MCPanel> subPanelList = new ArrayList<>(); boolean moveFlag = false; for (Container p1 : this._panelList) { boolean isEmbeddedPanel = isEmbeddedPanel(p1); if (isEmbeddedPanel) continue;  boolean isTabbedPane = isTabbedPane(p1); if (isTabbedPane) continue;  subPanelList = new ArrayList<>(); subPanelList.add((MCPanel)p1); for (MCPanel p2 : subPanelList) { Set<Integer> _yList = new HashSet<>(); List<Component> components = getAllComponents2((Container)p2); Map<Rectangle, List<Component>> rectMap = getComponentMap(components); List<Component> moved = new ArrayList<>(); for (Component comp : components) { if (moved.contains(comp)) continue;  String clsName = comp.getClass().getName(); if (isComboBoxClassName(comp)) continue;  if (canUseComponent(comp)) { if (setComponentLocation(comp, map0, _yList)) moveFlag = true;  moved.add(comp); for (List<Component> list : rectMap.values()) { if (list.contains(comp)) { for (Component c3 : list) { if (c3 != comp) { if (setComponentLocation(c3, map0, _yList)) moveFlag = true;  moved.add(c3); }  }  break; }  }  continue; }  if (comp instanceof javax.swing.JButton) { if (!clsName.equals("mcframe.clientCore.beans.combobox.MCComboButton")) if (!(comp instanceof mcframe.clientCore.beans.plaf.metal.MCMetalScrollButton)) if (setComponentLocation(comp, map0, _yList)) moveFlag = true;    moved.add(comp); for (List<Component> list : rectMap.values()) { if (list.contains(comp)) { for (Component c3 : list) { if (c3 != comp) { if (setComponentLocation(c3, map0, _yList)) moveFlag = true;  moved.add(c3); }  }  break; }  }  }  }  boolean _hasTitledBorder = _hasTitledBorder((Component)p2); if (!this._targetPanel.isAutoLayoutUseAutoLayout()) if (_yList.size() > 0) for (Iterator<Integer> iterator = _yList.iterator(); iterator.hasNext(); ) { int y = ((Integer)iterator.next()).intValue(); List<Component> list2 = new ArrayList<>(); for (Component c0 : components) { if (canMoveComponent2(c0, false, true, false, false) && c0.isVisible()) { int ly = _getYOnPanel(c0, null) + _getBaseline(c0); if (ly == y) list2.add(c0);  }  }  Collections.sort(list2, new ComponentComparatorX()); int x = 0; if (_hasTitledBorder) { x = getSpacerWidth2(); } else { boolean isButtonPanel = isButtonPanel(y, list2); if (!isButtonPanel) x = getSpacerWidth2();  }  rectMap = getComponentMap(list2); moved = new ArrayList<>(); for (Component c2 : list2) { MCScrollPane mCScrollPane; MCPanel mCPanel; if (moved.contains(c2)) continue;  Component c3 = c2; if (c3 instanceof MCTextArea) { mCScrollPane = ((MCTextArea)c3).getScrollPaneForLayout(); } else if (hasInputContainerComponent((Component)mCScrollPane)) { mCPanel = getInputContainer((Component)mCScrollPane); }  Point pt = new Point(x, _getYOnPanel((Component)mCPanel, null)); if (_getXOnPanel((Component)mCPanel, null) != pt.x || _getYOnPanel((Component)mCPanel, null) != pt.y) { moveFlag = true; MCLayoutLocationR findR = getLocationR((Component)mCPanel, map0); moveComponent2((Component)mCPanel, pt, findR); moved.add(c2); for (List<Component> list : rectMap.values()) { if (list.contains(c2)) { for (Component c4 : list) { if (c4 != c2) { MCScrollPane mCScrollPane1; Component component = c4; if (component instanceof MCTextArea) { mCScrollPane1 = ((MCTextArea)component).getScrollPaneForLayout(); } else if (hasInputContainerComponent((Component)mCScrollPane1)) { mCPanel = getInputContainer((Component)mCScrollPane1); }  moveComponent2((Component)mCPanel, pt, findR); moved.add(c4); }  }  break; }  }  } else { for (List<Component> list : rectMap.values()) { if (list.contains(c2)) { moved.addAll(list); break; }  }  }  x = x + _getWidth((Component)mCPanel) + getSpacerWidth4(); }  }    }  }  return moveFlag; }
/*      */   private Map<Rectangle, List<Component>> getComponentMap(List<Component> list) { Map<Rectangle, List<Component>> map = new LinkedHashMap<>(); for (Component comp : list) { if (comp instanceof MCResourceBeans) { Component comp2 = getComponentForLayout(comp); Rectangle rect = MCBeansUtil.getResourceLayout((MCResourceBeans)comp2); int x = (rect.x != -1) ? rect.x : comp2.getX(); int y = (rect.y != -1) ? rect.y : comp2.getY(); int w = (rect.width != -1) ? rect.width : comp2.getWidth(); int h = (rect.height != -1) ? rect.height : comp2.getHeight(); Container p1 = getParentPanel(comp); Container p = comp.getParent(); boolean b = true; while (b) { if (p instanceof MCResourceBeans) { Rectangle rect2 = MCBeansUtil.getResourceLayout((MCResourceBeans)p); int x2 = (rect2.x != -1) ? rect2.x : p.getX(); int y2 = (rect2.y != -1) ? rect2.y : p.getY(); x += x2; y += y2; } else { if (p == null) { b = false; continue; }  int x1 = p.getX(); int y1 = p.getY(); x += x1; y += y1; }  if (p == p1) { b = false; continue; }  p = p.getParent(); if (p == null) b = false;  }  rect = new Rectangle(x, y, w, h); List<Component> l = map.get(rect); if (l == null) { l = new ArrayList<>(); map.put(rect, l); }  l.add(comp); }  }  return map; }
/*      */   private Component getComponentForLayout(Component c) { if (c instanceof MCTextArea) return (Component)((MCTextArea)c).getScrollPaneForLayout();  return c; }
/*      */   private List<Component> getAllComponents2(Container c) { if (this.compomentsCache2 == null) this.compomentsCache2 = new HashMap<>();  if (this.compomentsCache2.containsKey(c)) return this.compomentsCache2.get(c);  List<Component> compList = new ArrayList<>(); Component[] comps = getAllComponents4(c); byte b; int i; Component[] arrayOfComponent1; for (i = (arrayOfComponent1 = comps).length, b = 0; b < i; ) { Component comp = arrayOfComponent1[b]; compList.add(comp); if (comp instanceof Container && !this._panelList.contains(comp)) compList.addAll(getAllComponents2((Container)comp));  b++; }  this.compomentsCache2.put(c, compList); return compList; }
/*      */   private List<Component> getAllComponents3(Container c) { Component[] comps = c.getComponents(); List<Component> compList = Arrays.asList(comps); return compList; }
/*      */   private Component[] getAllComponents4(Container c) { Component[] comps = c.getComponents(); return comps; }
/*      */   private List<MCPanel> getTabPanelList(MCPanel p) { if (this.tabPanelCache == null) this.tabPanelCache = new HashMap<>();  if (this.tabPanelCache.containsKey(p)) return this.tabPanelCache.get(p);  List<MCPanel> tabPanelList = new ArrayList<>(); Component[] components = MCBeansUtil.getAllComponents((Container)p); MCTabbedPane tabbedPane = null; byte b; int i; Component[] arrayOfComponent1; for (i = (arrayOfComponent1 = components).length, b = 0; b < i; ) { Component c = arrayOfComponent1[b]; if (c instanceof MCTabbedPane) { tabbedPane = (MCTabbedPane)c; break; }  b++; }  for (i = (arrayOfComponent1 = components).length, b = 0; b < i; ) { Component c = arrayOfComponent1[b]; if (c instanceof MCPanel && c.getParent() == tabbedPane) tabPanelList.add((MCPanel)c);  b++; }  this.tabPanelCache.put(p, tabPanelList); return tabPanelList; }
/*      */   public int _getYOnPanel(Component c, Container p, boolean useDefaultBounds) { Container parent = p; Component c1 = getComponentForLayout(c); if (parent == null) parent = getParentPanel(c);  int pt2y = _getY(c1, useDefaultBounds); Container c2 = getParentPanel1(c1); while (c2 != null && c2 != parent) { pt2y += _getY(c2, useDefaultBounds); c2 = c2.getParent(); }  return pt2y; } protected int _getXOnPanel(Component c, Container p) { return _getXOnPanel(c, p, true); } protected int _getYOnPanel(Component c, Container p) { return _getYOnPanel(c, p, true); } protected int _getXOnPanel(Component c, Container p, boolean useDefaultBounds) { Container parent = p; Component c1 = getComponentForLayout(c); if (parent == null) parent = getParentPanel(c);  int pt2x = _getX(c1, useDefaultBounds); Container c2 = getParentPanel1(c1); while (c2 != null && c2 != parent) { pt2x += _getX(c2, useDefaultBounds); c2 = c2.getParent(); }  return pt2x; } public int _getXOnPanel2(Component c, Container p) { Container parent = p; Component c1 = getComponentForLayout(c); if (parent == null) parent = getParentPanel(c);  int pt2x = c1.getX(); Container c2 = getParentPanel1(c1); while (c2 != null && c2 != parent) { pt2x += c2.getX(); c2 = c2.getParent(); }  return pt2x; } public int _getYOnPanel2(Component c, Container p) { Container parent = p; Component c1 = getComponentForLayout(c); if (parent == null) parent = getParentPanel(c);  int pt2y = c1.getY(); Container c2 = getParentPanel1(c1); while (c2 != null && c2 != parent) { pt2y += c2.getY(); c2 = c2.getParent(); }  return pt2y; } protected int getYOnPanel(Component c, Container p) { Container parent = p; Component c1 = getComponentForLayout(c); if (parent == null) parent = getParentPanel(c);  int pt2y = c1.getY(); Container c2 = getParentPanel1(c1); while (c2 != null && c2 != parent) { pt2y += c2.getY(); c2 = c2.getParent(); }  return pt2y; } public Point getXYOnPanel(Component c, Container p) { Container parent = p; Component c1 = getComponentForLayout(c); if (parent == null) parent = getParentPanel(c);  int pt2x = c1.getX(); int pt2y = c1.getY(); Container c2 = getParentPanel1(c1); while (c2 != null && c2 != parent) { pt2x += c2.getX(); pt2y += c2.getY(); c2 = c2.getParent(); }  return new Point(pt2x, pt2y); } protected class ComponentComparatorX implements Comparator<Component> {
/* 7927 */     public int compare(Component p1, Component p2) { int x1 = MCAutoLayout.this._getXOnPanel(p1, null); int x2 = MCAutoLayout.this._getXOnPanel(p2, null); if (x1 < x2) return -1;  if (x1 > x2) return 1;  return 0; } } private boolean setComponentLocation(Component comp, Map<String, MCLayoutLocationR> map, Set<Integer> _yList) { MCPanel mCPanel; Component comp1 = comp; Component comp2 = comp; if (comp instanceof MCTextArea) { MCScrollPane mCScrollPane = ((MCTextArea)comp).getScrollPaneForLayout(); } else if (hasInputContainerComponent(comp)) { mCPanel = getInputContainer(comp); }  boolean flag = false; Container parent = getParentPanel((Component)mCPanel); String panelID = parent.getName(); if (panelID == null) return false;  String componentID = comp.getName(); if (componentID == null) return false;  MCRootPanel rp = getRootPanel(comp); String rootPanelID = rp.getName(); if (rootPanelID == null) return false;  MCLayoutLocationR findR = getLocationR(comp, map); if (findR == null) { int ly = _getYOnPanel(comp1, null) + _getBaseline(comp); _yList.add(Integer.valueOf(ly)); return false; }  if (findR.systemInvisible() || !findR.isVisible()) { if (comp1.isVisible()) setVisibleForLayout(comp1, false);  if (setVisibleForPersonalize(comp1, false)) flag = true;  } else { if (!comp1.isVisible() && isVisibleComponent(comp1)) { setVisibleForLayout(comp1, true); _yList.add(Integer.valueOf(findR.locationY() + _getBaseline(comp))); }  if (setVisibleForPersonalize(comp1, true)) flag = true;  _yList.add(Integer.valueOf(findR.locationY() + _getBaseline(comp))); }  return flag; } protected boolean isTopPanel(Component comp) { Container parent = getParentPanel1(comp); if (parent.getName().startsWith("_")) { if (isInputContainerPanel(parent)) return false;  return true; }  return false; } public boolean setVisibleForPersonalize(Component comp, boolean b) { boolean flag = false; if (getParentPanel1(comp).getName() == null) return false;  if (isTopPanel(comp)) return false;  String clsName = comp.getClass().getName(); if (isComboBoxClassName(comp)) return false;  if (clsName.indexOf("MCMenuButton") != -1) return false;  if (canUseComponent(comp)) { if (!containsPanelList(comp)) return false;  if (comp instanceof MCLabel) { if (((MCLabel)comp).isVisibleForPersonalize() != b) { ((MCLabel)comp).setVisibleForPersonalize(b); flag = true; }  } else if (comp instanceof MCButton) { if (((MCButton)comp).isVisibleForPersonalize() != b) { ((MCButton)comp).setVisibleForPersonalize(b); flag = true; }  } else if (comp instanceof MCField) { if (((MCField)comp).isVisibleForPersonalize() != b) { ((MCField)comp).setVisibleForPersonalize(b); flag = true; }  } else if (comp instanceof MCPasswordField) { if (((MCPasswordField)comp).isVisibleForPersonalize() != b) { ((MCPasswordField)comp).setVisibleForPersonalize(b); flag = true; }  } else if (comp instanceof MCTextArea) { if (((MCTextArea)comp).isVisibleForPersonalize() != b) { ((MCTextArea)comp).setVisibleForPersonalize(b); if (comp.getParent() instanceof JViewport && comp.getParent().getParent() instanceof MCScrollPane) ((MCScrollPane)comp.getParent().getParent()).setVisible(b);  flag = true; }  } else if (comp instanceof MCImageView) { if (((MCImageView)comp).isVisibleForPersonalize() != b) { ((MCImageView)comp).setVisibleForPersonalize(b); flag = true; }  } else if (comp instanceof MCCheckBox) { if (((MCCheckBox)comp).isVisibleForPersonalize() != b) { ((MCCheckBox)comp).setVisibleForPersonalize(b); flag = true; }  } else if (comp instanceof MCFieldComboBox) { if (((MCFieldComboBox)comp).isVisibleForPersonalize() != b) { ((MCFieldComboBox)comp).setVisibleForPersonalize(b); flag = true; }  } else if (comp instanceof MCRadioButton) { if (((MCRadioButton)comp).isVisibleForPersonalize() != b) { ((MCRadioButton)comp).setVisibleForPersonalize(b); flag = true; }  } else if (comp instanceof MCPanel) { ((MCPanel)comp).setVisibleForPersonalize(b); if (((MCPanel)comp).isVisibleForPersonalize() != b) { ((MCPanel)comp).setVisibleForPersonalize(b); flag = true; }  }  }  return flag; } private boolean setVisibleForLayout(Component comp, boolean b) { boolean flag = false; if (getParentPanel1(comp).getName() == null) return false;  if (isTopPanel(comp)) return false;  String clsName = comp.getClass().getName(); if (isComboBoxClassName(comp)) return false;  if (clsName.indexOf("MCMenuButton") != -1) return false;  if (canUseComponent(comp)) { if (!containsPanelList(comp)) return false;  if (comp instanceof MCLabel) { ((MCLabel)comp).setVisibleForLayout(b); flag = true; } else if (comp instanceof MCButton) { ((MCButton)comp).setVisibleForLayout(b); flag = true; } else if (comp instanceof MCField) { ((MCField)comp).setVisibleForLayout(b); flag = true; } else if (comp instanceof MCPasswordField) { ((MCPasswordField)comp).setVisibleForLayout(b); flag = true; } else if (comp instanceof MCTextArea) { ((MCTextArea)comp).setVisibleForLayout(b); if (comp.getParent() instanceof JViewport && comp.getParent().getParent() instanceof MCScrollPane) ((MCScrollPane)comp.getParent().getParent()).setVisible(b);  flag = true; } else if (comp instanceof MCImageView) { ((MCImageView)comp).setVisibleForLayout(b); flag = true; } else if (comp instanceof MCCheckBox) { ((MCCheckBox)comp).setVisibleForLayout(b); flag = true; } else if (comp instanceof MCFieldComboBox) { ((MCFieldComboBox)comp).setVisibleForLayout(b); flag = true; } else if (comp instanceof MCRadioButton) { ((MCRadioButton)comp).setVisibleForLayout(b); flag = true; } else if (comp instanceof MCPanel) { ((MCPanel)comp).setVisibleForLayout(b); flag = true; }  }  return flag; } private boolean containsPanelList(Component comp) { Container findPanel = null; for (Container panel : this._panelList) { List<Component> list = getAllComponents(panel); if (list.contains(comp)) { findPanel = panel; break; }  }  if (findPanel == null) return false;  return true; } private Point getLocationOnLocal(Component c, Point pt) { Container parent = getParentPanel(c); int pt2x = pt.x; int pt2y = pt.y; Container c2 = getParentPanel1(c); while (c2 != null && c2 != parent) { pt2x -= _getX(c2); pt2y -= _getY(c2); c2 = c2.getParent(); }  return new Point(pt2x, pt2y); } protected boolean moveComponent2(Component comp, Point pt, MCLayoutLocationR r) { Component comp2 = getComponentForLayout(comp); Point pt2 = getLocationOnLocal(comp2, pt); if (!pt2.equals(_getLocation(comp2))) { _setLocation(comp2, pt2); _setDefaultLocation(comp2, pt2, null); if (r != null) { r.locationX(pt.x); r.locationY(pt.y); }  return true; }  return false; } protected void setDefaultBounds(Component comp, Rectangle r) { if (r == null) return;  if (this._boundsMap == null) this._boundsMap = new LinkedHashMap<>();  this._boundsMap.put(comp, new Rectangle(r)); } protected Rectangle getDefaultBounds(Component comp) { if (this._boundsMap != null) { Rectangle rectangle = this._boundsMap.get(comp); if (rectangle != null) return new Rectangle(rectangle);  rectangle = _getDefaultBounds(comp); if (rectangle != null) setDefaultBounds(comp, rectangle);  return rectangle; }  Rectangle r = _getDefaultBounds(comp); return r; } public void setDefaultRatioSize(Component comp, Rectangle r) { if (comp instanceof AbsMCComboBox) { ((AbsMCComboBox)comp).setDefaultRatioSize(r); } else if (comp instanceof MCButton) { ((MCButton)comp).setDefaultRatioSize(r); } else if (comp instanceof MCCanvas) { ((MCCanvas)comp).setDefaultRatioSize(r); } else if (comp instanceof MCCheckBox) { ((MCCheckBox)comp).setDefaultRatioSize(r); } else if (comp instanceof MCField) { ((MCField)comp).setDefaultRatioSize(r); } else if (comp instanceof MCImageView) { ((MCImageView)comp).setDefaultRatioSize(r); } else if (comp instanceof MCLabel) { ((MCLabel)comp).setDefaultRatioSize(r); } else if (comp instanceof MCPanel) { ((MCPanel)comp).setDefaultRatioSize(r); } else if (comp instanceof MCPasswordField) { ((MCPasswordField)comp).setDefaultRatioSize(r); } else if (comp instanceof MCProgressBar) { ((MCProgressBar)comp).setDefaultRatioSize(r); } else if (comp instanceof MCRadioButton) { ((MCRadioButton)comp).setDefaultRatioSize(r); } else if (comp instanceof MCRootPanel) { ((MCRootPanel)comp).setDefaultRatioSize(r); } else if (comp instanceof MCScrollPane) { ((MCScrollPane)comp).setDefaultRatioSize(r); } else if (comp instanceof MCSplitPane) { ((MCSplitPane)comp).setDefaultRatioSize(r); } else if (comp instanceof MCTabbedPane) { ((MCTabbedPane)comp).setDefaultRatioSize(r); } else if (comp instanceof MCTextArea) { MCScrollPane scrollPane = ((MCTextArea)comp).getScrollPaneForLayout(); scrollPane.setDefaultRatioSize(r); }  } public void _setDefaultBounds(Component comp, Rectangle r) { if (comp instanceof AbsMCComboBox) { ((AbsMCComboBox)comp)._setDefaultBounds(r); } else if (comp instanceof MCButton) { ((MCButton)comp)._setDefaultBounds(r); } else if (comp instanceof MCCanvas) { ((MCCanvas)comp)._setDefaultBounds(r); } else if (comp instanceof MCCheckBox) { ((MCCheckBox)comp)._setDefaultBounds(r); } else if (comp instanceof MCField) { ((MCField)comp)._setDefaultBounds(r); } else if (comp instanceof MCImageView) { ((MCImageView)comp)._setDefaultBounds(r); } else if (comp instanceof MCLabel) { ((MCLabel)comp)._setDefaultBounds(r); } else if (comp instanceof MCPanel) { ((MCPanel)comp)._setDefaultBounds(r); } else if (comp instanceof MCPasswordField) { ((MCPasswordField)comp)._setDefaultBounds(r); } else if (comp instanceof MCProgressBar) { ((MCProgressBar)comp)._setDefaultBounds(r); } else if (comp instanceof MCRadioButton) { ((MCRadioButton)comp)._setDefaultBounds(r); } else if (comp instanceof MCRootPanel) { ((MCRootPanel)comp)._setDefaultBounds(r); } else if (comp instanceof MCScrollPane) { ((MCScrollPane)comp)._setDefaultBounds(r); } else if (comp instanceof MCSplitPane) { ((MCSplitPane)comp)._setDefaultBounds(r); } else if (comp instanceof MCTabbedPane) { ((MCTabbedPane)comp)._setDefaultBounds(r); } else if (comp instanceof MCTextArea) { MCScrollPane scrollPane = ((MCTextArea)comp).getScrollPaneForLayout(); scrollPane._setDefaultBounds(r); }  } public Rectangle _getDefaultBounds(Component comp) { if (comp instanceof AbsMCComboBox) return ((AbsMCComboBox)comp)._getDefaultBounds();  if (comp instanceof MCButton) return ((MCButton)comp)._getDefaultBounds();  if (comp instanceof MCCanvas) return ((MCCanvas)comp)._getDefaultBounds();  if (comp instanceof MCCheckBox) return ((MCCheckBox)comp)._getDefaultBounds();  if (comp instanceof MCField) return ((MCField)comp)._getDefaultBounds();  if (comp instanceof MCImageView) return ((MCImageView)comp)._getDefaultBounds();  if (comp instanceof MCLabel) return ((MCLabel)comp)._getDefaultBounds();  if (comp instanceof MCPanel) return ((MCPanel)comp)._getDefaultBounds();  if (comp instanceof MCPasswordField) return ((MCPasswordField)comp)._getDefaultBounds();  if (comp instanceof MCProgressBar) return ((MCProgressBar)comp)._getDefaultBounds();  if (comp instanceof MCRadioButton) return ((MCRadioButton)comp)._getDefaultBounds();  if (comp instanceof MCRootPanel) return ((MCRootPanel)comp)._getDefaultBounds();  if (comp instanceof MCScrollPane) return ((MCScrollPane)comp)._getDefaultBounds();  if (comp instanceof MCSplitPane) return ((MCSplitPane)comp)._getDefaultBounds();  if (comp instanceof MCTabbedPane) return ((MCTabbedPane)comp)._getDefaultBounds();  if (comp instanceof MCTextArea) { MCScrollPane scrollPane = ((MCTextArea)comp).getScrollPaneForLayout(); return scrollPane._getDefaultBounds(); }  if (comp instanceof mcframe.clientCore.beans.combobox.MCComboButton) return null;  return comp.getBounds(); } protected Point _getXYOnScreen(Component c) { if (!(c instanceof MCResourceBeans)) return new Point(0, 0);  Rectangle r2 = ((MCResourceBeans)c).getDefaultBounds(); if (r2 == null) return new Point(0, 0);  int x = r2.x; int y = r2.y; Container p = getParentPanel1(c); while (p != null && p instanceof MCResourceBeans) { Rectangle r = ((MCResourceBeans)p).getDefaultBounds(); if (r != null) { x += r.x; y += r.y; }  p = p.getParent(); }  return new Point(x, y); } private void _setDefaultSize(Component comp, Dimension d) { Rectangle r1 = getDefaultBounds(comp); if (r1 == null) return;  Rectangle r2 = new Rectangle(r1.x, r1.y, d.width, d.height); setDefaultBounds(comp, r2); setDefaultRatioSize(comp, r2); } protected void _setDefaultLocation(Component comp, Point pt, Dimension size) { Rectangle r1 = getDefaultBounds(comp); if (r1 != null) if (size != null) { Rectangle r2 = new Rectangle(pt.x, pt.y, size.width, size.height); setDefaultBounds(comp, r2); setDefaultRatioSize(comp, r2); } else { Rectangle r3 = new Rectangle(pt.x, pt.y, r1.width, r1.height); setDefaultBounds(comp, r3); setDefaultRatioSize(comp, r3); }   } private void _setLocation(Component c, Point pt) { Point pt2 = _getLocation(c); if (!pt.equals(pt2)) _setDefaultLocation(c, pt, null);  } private void _setSize(Component c, int w, int h, boolean updateSize) { Dimension d = new Dimension(w, h); Dimension d2 = _getSize(c); if (!d.equals(d2)) _setDefaultSize(c, d);  if (updateSize) c.setSize(w, h);  } private void _setPreferredSize(Component c, int w, int h, boolean updateSize) { Dimension dim = new Dimension(w, h); this._prefSizeMap.put(c, dim); if (updateSize) c.setPreferredSize(new Dimension(w, h));  } private boolean _canLayoutComponent(Component c) { if (c instanceof MCSplitPane) return true;  if (c instanceof MCScrollPane) return true;  if (c instanceof MCPanel && c.getName().startsWith("_")) return true;  if (c.getName() == null) return true;  if (c.getName().startsWith("dashboard_")) return true;  return false; } private Point _getLocation(Component c, boolean useDefaultBounds) { Rectangle r = getDefaultBounds(c); if (r == null) { if (_canLayoutComponent(c) || !useDefaultBounds) return c.getLocation();  return c.getLocation(); }  return r.getLocation(); } private Dimension _getSize(Component c, boolean useDefaultBounds) { Rectangle r = getDefaultBounds(c); if (r == null) { if (_canLayoutComponent(c) || !useDefaultBounds) return c.getSize();  return c.getSize(); }  return r.getSize(); } public Rectangle _getBounds(Component c, boolean useDefaultBounds) { Rectangle r = getDefaultBounds(c); if (r == null) { if (_canLayoutComponent(c) || !useDefaultBounds) return c.getBounds();  return c.getBounds(); }  return r; } private int _getX(Component c, boolean useDefaultBounds) { if (getDefaultBounds(c) == null) { if (_canLayoutComponent(c) || !useDefaultBounds) return c.getX();  return c.getX(); }  return (getDefaultBounds(c)).x; } private int _getY(Component c, boolean useDefaultBounds) { if (getDefaultBounds(c) == null) { if (_canLayoutComponent(c) || !useDefaultBounds) return c.getY();  return c.getY(); }  return (getDefaultBounds(c)).y; } private int _getWidth(Component c, boolean useDefaultBounds) { if (getDefaultBounds(c) == null) { if (_canLayoutComponent(c) || !useDefaultBounds) return c.getWidth();  return c.getWidth(); }  return (getDefaultBounds(c)).width; } public void updateTabOrder(MCRootPanel rp, boolean init) { boolean f = this._debugUseUpdateTabOrder;
/* 7928 */     if (!f) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 7933 */     _updateTabOrder(rp, (Container)rp, init); } private int _getHeight(Component c, boolean useDefaultBounds) { if (getDefaultBounds(c) == null) { if (_canLayoutComponent(c) || !useDefaultBounds) return c.getHeight();  return c.getHeight(); }  return (getDefaultBounds(c)).height; } private Dimension _getPreferredSize(Component c, boolean useDefaultBounds) { if (this._prefSizeMap == null) return c.getPreferredSize();  Dimension dim = this._prefSizeMap.get(c); if (dim != null) return new Dimension(dim);  Rectangle r = getDefaultBounds(c); if (r == null) { dim = c.getPreferredSize(); this._prefSizeMap.put(c, dim); return dim; }  Dimension d1 = new Dimension(r.width, r.height); Dimension d2 = c.getPreferredSize(); d2.equals(d1); this._prefSizeMap.put(c, d1); return d1; } private Point _getLocation(Component c) { return _getLocation(c, true); } private Dimension _getSize(Component c) { return _getSize(c, true); } public Rectangle _getBounds(Component c) { return _getBounds(c, true); } private int _getX(Component c) { return _getX(c, true); } private int _getY(Component c) { return _getY(c, true); } private int _getWidth(Component c) { return _getWidth(c, true); } private int _getHeight(Component c) { return _getHeight(c, true); } private Dimension _getPreferredSize(Component c) { return _getPreferredSize(c, true); } private int _getBaseline(Component c) { return _getBaseline(c, true); } private int _getBaseline(Component c, boolean useDefaultBounds) { if (c instanceof MCTextArea) return 10;  if (c instanceof MCImageView) return 10;  return _getHeight(c, useDefaultBounds) / 2; } private boolean isShowing(Component c) { boolean isShowing = c.isShowing(); return isShowing; } protected String createResourceKey(String moduleID, String screenID) { return MCConst.createKey(new String[] { moduleID, screenID, "personalize_location" }); } protected String createListResourceKey(String moduleID, String screenID, String aLocationID, MCResourceLayerType type) { if (MCResourceLayerType.BARCODE.equals(type)) return MCConst.createKey(new String[] { "_0_SCR_", moduleID, screenID, "barcode", "personalize_location", "list", aLocationID });  return MCConst.createKey(new String[] { "_0_SCR_", moduleID, screenID, "personalize_location", "list", aLocationID }); } protected static String createInitResourceKey(String moduleID, String screenID, MCResourceLayerType type) { if (MCResourceLayerType.BARCODE.equals(type)) return MCConst.createKey(new String[] { "_0_SCR_", moduleID, screenID, "barcode", "personalize_location" });  return MCConst.createKey(new String[] { "_0_SCR_", moduleID, screenID, "personalize_location" }); } protected String createListResourceKey(String moduleID, String screenID, MCResourceLayerType type) { if (MCResourceLayerType.BARCODE.equals(type)) return MCConst.createKey(new String[] { "_0_SCR_", moduleID, screenID, "barcode", "personalize_location", "list" });  return MCConst.createKey(new String[] { "_0_SCR_", moduleID, screenID, "personalize_location", "list" }); } protected String createPanelListResourceKey(String moduleID, String screenID, String aLocationID, MCResourceLayerType type) { if (MCResourceLayerType.BARCODE.equals(type)) return MCConst.createKey(new String[] { "_0_SCR_", moduleID, screenID, "barcode", "personalize_location", "panel_list", aLocationID });  return MCConst.createKey(new String[] { "_0_SCR_", moduleID, screenID, "personalize_location", "panel_list", aLocationID }); } protected String createSortResourceKey(String moduleID, String screenID, String aLocationID, MCResourceLayerType type) { if (MCResourceLayerType.BARCODE.equals(type)) return MCConst.createKey(new String[] { "_0_SCR_", moduleID, screenID, "barcode", "personalize_location_sort", "list", aLocationID });  return MCConst.createKey(new String[] { "_0_SCR_", moduleID, screenID, "personalize_location_sort", "list", aLocationID }); } protected MCGeneralPersonalizeResource getAppResource() { return (MCGeneralPersonalizeResource)MCConst.app; } public static boolean isUseAppResource() { return true; } public static MCGeneralPersonalizeResource getSystemLocationResource() { if (isUseAppResource()) return (MCGeneralPersonalizeResource)MCConst.app;  return (MCGeneralPersonalizeResource)MCConst.systemlocation; } public Map<String, MCLayoutLocationR> loadPersonalizeComponent(String moduleID, String screenID, String aLocationID, MCResourceLayerType type) { List<MCLayoutLocationR> list = new ArrayList<>(); String listKey = createListResourceKey(moduleID, screenID, aLocationID, type); String[] baseKeys1 = getAppResource().findPattern(type, MCConst.createKey(new String[] { listKey, "*" })); String itemKey = String.valueOf(listKey) + ".item"; byte b; int i; String[] arrayOfString1; for (i = (arrayOfString1 = baseKeys1).length, b = 0; b < i; ) { String key1 = arrayOfString1[b]; if (key1.contains(itemKey)) { String str = getAppResource().getString(key1); String[] token = MCStringUtil.split(",", str); if (token.length >= 9) { MCLayoutLocationR r = new MCLayoutLocationR(); r.sequence(Integer.valueOf(token[0]).intValue()); r.componentID(token[1]); r.panelID(token[2]); r.rootPanelID(token[3]); r.isVisible(Boolean.valueOf(token[4]).booleanValue()); r.locationX(Double.valueOf(token[5]).intValue()); r.locationY(Double.valueOf(token[6]).intValue()); r.userHasCr(Boolean.valueOf(token[7]).booleanValue()); r.hasCr(Boolean.valueOf(token[8]).booleanValue()); list.add(r); }  }  b++; }  Collections.sort(list, new LocationComparator()); Map<String, MCLayoutLocationR> map = new LinkedHashMap<>(); list.forEach(r -> {  }); return map; } public List<MCLocationSortR> loadPersonalizeSort(String moduleID, String screenID, String aLocationID, MCResourceLayerType type) { List<MCLocationSortR> list = new ArrayList<>(); String listKey = createSortResourceKey(moduleID, screenID, aLocationID, type); String[] baseKeys1 = getAppResource().findPattern(type, MCConst.createKey(new String[] { listKey, "*" })); String itemKey = String.valueOf(listKey) + ".item"; byte b; int i; String[] arrayOfString1; for (i = (arrayOfString1 = baseKeys1).length, b = 0; b < i; ) { String key1 = arrayOfString1[b]; if (key1.contains(itemKey)) { String str = getAppResource().getString(key1); String[] token = MCStringUtil.split(",", str); MCLocationSortR r = new MCLocationSortR(); r.sequence(Integer.valueOf(token[0]).intValue()); r.componentID(token[1]); r.prevComponentID(token[2]); list.add(r); }  b++; }  Collections.sort(list, new LocationSortComparator()); return list; } protected class LocationComparator implements Comparator<MCLayoutLocationR> {
/*      */     public int compare(MCLayoutLocationR p1, MCLayoutLocationR p2) { int y1 = p1.locationY(); int y2 = p2.locationY(); if (y1 < y2) return -1;  if (y1 > y2) return 1;  int x1 = p1.locationX(); int x2 = p2.locationX(); if (x1 < x2) return -1;  if (x1 > x2) return 1;  return 0; } } protected class LocationSortComparator implements Comparator<MCLocationSortR> {
/*      */     public int compare(MCLocationSortR p1, MCLocationSortR p2) { int s1 = p1.sequence(); int s2 = p2.sequence(); if (s1 < s2) return -1;  if (s1 > s2) return 1;  return 0; } } public Map<String, MCLayoutPanelR> loadPersonalizePanel(String moduleID, String screenID, String aLocationID, MCResourceLayerType type) { List<MCLayoutPanelR> list = new ArrayList<>(); String listKey = createPanelListResourceKey(moduleID, screenID, aLocationID, type); String[] baseKeys1 = getAppResource().findPattern(type, MCConst.createKey(new String[] { listKey, "*" })); String itemKey = String.valueOf(listKey) + ".item"; byte b; int i; String[] arrayOfString1; for (i = (arrayOfString1 = baseKeys1).length, b = 0; b < i; ) { String key1 = arrayOfString1[b]; if (key1.contains(itemKey)) { String str = getAppResource().getString(key1); String[] token = MCStringUtil.split(",", str); MCLayoutPanelR r = new MCLayoutPanelR(); if (token.length == 6) { r.sequence(Integer.valueOf(token[0])); r.panelID(token[1]); r.parentPanelID(token[2]); r.rootPanelID(token[3]); r.layoutPosition(token[4]); r.layoutY(Integer.valueOf(Double.valueOf(token[5]).intValue())); }  list.add(r); }  b++; }  Collections.sort(list, new PanelComparator(null)); Map<String, MCLayoutPanelR> map = new LinkedHashMap<>(); list.forEach(r -> {  }); return map; } private final class PanelComparator implements Comparator<MCLayoutPanelR> {
/*      */     private PanelComparator() {} public int compare(MCLayoutPanelR a1, MCLayoutPanelR a2) { if (a1.sequence() == null || a2.sequence() == null) return 0;  int i = a1.sequence().compareTo(a2.sequence()); return i; } } public List<MCLayoutColumnR> loadPersonalizeTable2(String moduleID, String screenID, MCResourceLayerType type) { String[] baseKeys1; ArrayList<MCLayoutColumnR> list = new ArrayList<>(); String listKey = createTableListResourceKey2("System", moduleID, screenID); if (!isUseAppResource()) { if (getCustomResource() == null) loadResource();  baseKeys1 = getCustomResource().findPattern(MCConst.createKey(new String[] { listKey, "*" })); } else { MCGeneralPersonalizeResource resource = getSystemLocationResource(); baseKeys1 = resource.findPattern(type, MCConst.createKey(new String[] { listKey, "*" })); }  String itemKey = String.valueOf(listKey) + ".item"; byte b; int i; String[] arrayOfString1; for (i = (arrayOfString1 = baseKeys1).length, b = 0; b < i; ) { String key1 = arrayOfString1[b]; if (key1.contains(itemKey)) { String str; MCLayoutColumnR r = new MCLayoutColumnR(); if (!isUseAppResource()) { str = getCustomResource().getString(key1); } else { str = getSystemLocationResource().getString(key1); }  String[] token = str.split(","); if (token.length >= 5) { r.rootPanelID(token[0]); r.panelID(token[1]); r.tableID(token[2]); r.columnID(token[3]); r.isVisible(token[4].equals("true")); if (token.length >= 6) if (token[5].equals("null")) { r.columnID(null); } else { r.columnID(token[5]); }   list.add(r); }  }  b++; }  return list; } public void savePersonalize(String aModuleID, String aScreenID, String aLocationID, String aLocationNM, MCResourceLayerType type, Map<String, MCLayoutLocationR> map, Map<String, MCLayoutPanelR> map2, List<MCLocationSortR> list, boolean initFlag, String remark) { String listKey = createListResourceKey(aModuleID, aScreenID, aLocationID, type); String[] ka = getAppResource().findPattern(type, String.valueOf(listKey) + ".**"); getAppResource().remove(type, ka); getAppResource().setString(type, String.valueOf(listKey) + ".locationID", aLocationID); getAppResource().setString(type, String.valueOf(listKey) + ".locationNM", aLocationNM); getAppResource().setString(type, String.valueOf(listKey) + ".remark", remark); String initKey = createInitResourceKey(aModuleID, aScreenID, type); if (initFlag) { getAppResource().setString(type, String.valueOf(initKey) + ".initLocationID", aLocationID); } else { String initID = MCStringUtil.nullToBlank(getAppResource().getString(type, String.valueOf(initKey) + ".initLocationID")); if (initID.equals(aLocationID)) getAppResource().remove(type, String.valueOf(initKey) + ".initLocationID");  }  int idx = 0; for (MCLayoutLocationR r : map.values()) { String resItemKey = String.valueOf(listKey) + ".item" + idx; String str = MCStringUtil.join(",", new String[] { MCStringUtil.nullToBlank(Integer.toString(r.sequence())), MCStringUtil.nullToBlank(r.componentID()), MCStringUtil.nullToBlank(r.panelID()), MCStringUtil.nullToBlank(r.rootPanelID()), MCStringUtil.nullToBlank(Boolean.toString(r.isVisible())), MCStringUtil.nullToBlank(Integer.toString(r.locationX())), MCStringUtil.nullToBlank(Integer.toString(r.locationY())), MCStringUtil.nullToBlank(Boolean.toString(r.userHasCr())), MCStringUtil.nullToBlank(Boolean.toString(r.hasCr())) }); getAppResource().setString(type, resItemKey, str); idx++; }  String listKey2 = createPanelListResourceKey(aModuleID, aScreenID, aLocationID, type); String[] ka2 = getAppResource().findPattern(type, String.valueOf(listKey2) + ".**"); getAppResource().remove(type, ka2); int idx2 = 0; for (MCLayoutPanelR r : map2.values()) { String resItemKey = String.valueOf(listKey2) + ".item" + idx2; String str = ""; str = MCStringUtil.join(str, new String[] { MCStringUtil.nullToBlank(Integer.toString(r.sequence().intValue())) }); str = MCStringUtil.join(",", new String[] { str, MCStringUtil.nullToBlank(r.panelID()) }); str = MCStringUtil.join(",", new String[] { str, MCStringUtil.nullToBlank(r.parentPanelID()) }); str = MCStringUtil.join(",", new String[] { str, MCStringUtil.nullToBlank(r.rootPanelID()) }); str = MCStringUtil.join(",", new String[] { str, MCStringUtil.nullToBlank(r.layoutPosition()) }); str = MCStringUtil.join(",", new String[] { str, MCStringUtil.nullToBlank(Integer.toString(r.layoutY().intValue())) }); getAppResource().setString(type, resItemKey, str); idx2++; }  if (list != null) { String listKey3 = createSortResourceKey(aModuleID, aScreenID, aLocationID, type); String[] ka3 = getAppResource().findPattern(type, String.valueOf(listKey3) + ".**"); getAppResource().remove(type, ka3); int idx3 = 0; for (MCLocationSortR r : list) { String resItemKey = String.valueOf(listKey3) + ".item" + idx3; String str = MCStringUtil.join(",", new String[] { MCStringUtil.nullToBlank(Integer.toString(r.sequence())), MCStringUtil.nullToBlank(r.componentID()), MCStringUtil.nullToBlank(r.prevComponentID()) }); getAppResource().setString(type, resItemKey, str); idx3++; }  }  MCConst.saveResource(); } public void removePersonalize(String moduleID, String screenID, String aLocationID, MCResourceLayerType type) { String listKey = createListResourceKey(moduleID, screenID, aLocationID, type); String[] ka = getAppResource().findPattern(type, String.valueOf(listKey) + ".**"); getAppResource().remove(type, ka); String listKey2 = createPanelListResourceKey(moduleID, screenID, aLocationID, type); String[] ka2 = getAppResource().findPattern(type, String.valueOf(listKey2) + ".**"); getAppResource().remove(type, ka2); String listKey3 = createSortResourceKey(moduleID, screenID, aLocationID, type); String[] ka3 = getAppResource().findPattern(type, String.valueOf(listKey3) + ".**"); getAppResource().remove(type, ka3); MCConst.saveResource(); } protected String createListResourceKey2(String locationID, String moduleID, String screenID) { return MCConst.createKey(new String[] { "system_location2", locationID, moduleID, screenID, "list" }); } protected String createTableListResourceKey2(String locationID, String moduleID, String screenID) { return MCConst.createKey(new String[] { "system_location2", locationID, moduleID, screenID, "table_list" }); } public static String createListResourceKey3(String locationID, String moduleID, String screenID, String localeID) { return MCConst.createKey(new String[] { "system_location3", locationID, moduleID, screenID, localeID, "list" }); } public static String createPanelListResourceKey3(String locationID, String moduleID, String screenID, String localeID) { return MCConst.createKey(new String[] { "system_location3", locationID, moduleID, screenID, localeID, "panel_list" }); } public static String createDividerListResourceKey3(String locationID, String moduleID, String screenID, String localeID) { return MCConst.createKey(new String[] { "system_location3", locationID, moduleID, screenID, localeID, "divider_list" }); } public static String createSettingsListResourceKey3(String locationID, String moduleID, String screenID, String localeID) { return MCConst.createKey(new String[] { "system_location3", locationID, moduleID, screenID, localeID, "settings_list" }); } public static String createTabbedPaneListResourceKey3(String locationID, String moduleID, String screenID, String localeID) { return MCConst.createKey(new String[] { "system_location3", locationID, moduleID, screenID, localeID, "tabbedpane_list" }); }
/*      */   public Map<String, MCLayoutLocationR> loadSystemLocationComponent(MCRootPanel rootPanel) { String baseKeys2[], moduleID = rootPanel.getModuleID(); String screenID = rootPanel.getScreenID(); List<MCLayoutLocationR> list = new ArrayList<>(); String listKey2 = createListResourceKey2("System", moduleID, screenID); if (!isUseAppResource()) { if (_customResource == null) loadResource();  baseKeys2 = getCustomResource().findPattern(MCConst.createKey(new String[] { listKey2, "*" })); } else { MCResourceLayerType type = MCResourceLayerType.SYS; MCGeneralPersonalizeResource resource = getSystemLocationResource(); baseKeys2 = resource.findPattern(type, MCConst.createKey(new String[] { listKey2, "*" })); }  String itemKey2 = String.valueOf(listKey2) + ".item"; byte b; int i; String[] arrayOfString1; for (i = (arrayOfString1 = baseKeys2).length, b = 0; b < i; ) { String key1 = arrayOfString1[b]; if (key1.contains(itemKey2)) { String str; MCLayoutLocationR r = new MCLayoutLocationR(); if (!isUseAppResource()) { str = getCustomResource().getString(key1); } else { MCGeneralPersonalizeResource resource = getSystemLocationResource(); str = resource.getString(key1); }  String[] token = str.split(","); if (token.length >= 5) { r.rootPanelID(token[0]); r.panelID(token[1]); r.componentID(token[2]); r.userHasCr(token[3].equals("true")); r.isVisible(token[4].equals("true")); if (token.length > 5); list.add(r); }  }  b++; }  List<MCLayoutLocationR> list1 = new ArrayList<>(); List<MCLayoutLocationR> list2 = getSystemLocationComponent(rootPanel); for (MCLayoutLocationR r2 : list2) { boolean find = false; for (MCLayoutLocationR r1 : list) { if (r1.equalsID(r2)) { if (r1.isVisible() && !r2.isVisible()) r1.isVisible(false);  list1.add(r1); find = true; break; }  }  if (!find) list1.add(r2);  }  for (MCLayoutLocationR r : list) { boolean find = false; for (MCLayoutLocationR r1 : list1) { if (r1.equalsID(r)) { find = true; break; }  }  if (!find) if (!r.isVisible() || r.userHasCr()) list1.add(r);   }  Collections.sort(list1, new LocationComparator()); Map<String, MCLayoutLocationR> map1 = new LinkedHashMap<>(); list1.forEach(r1 -> {  }); return map1; }
/*      */   public Map<String, MCLayoutLocationR> loadSystemLocationComponent2(MCRootPanel rootPanel) { String baseKeys2[], moduleID = rootPanel.getModuleID(); String screenID = rootPanel.getScreenID(); List<MCLayoutLocationR> list = new ArrayList<>(); String localeID = MCSys.user.locale().toString(); String listKey3 = createListResourceKey3("System", moduleID, screenID, localeID); if (!isUseAppResource()) { if (_customResource == null) loadResource();  baseKeys2 = getCustomResource().findPattern(MCConst.createKey(new String[] { listKey3, "*" })); } else { MCResourceLayerType type = MCResourceLayerType.SYS; MCGeneralPersonalizeResource resource = getSystemLocationResource(); baseKeys2 = resource.findPattern(type, MCConst.createKey(new String[] { listKey3, "*" })); }  String itemKey2 = String.valueOf(listKey3) + ".item"; byte b; int i; String[] arrayOfString1; for (i = (arrayOfString1 = baseKeys2).length, b = 0; b < i; ) { String key1 = arrayOfString1[b]; if (key1.contains(itemKey2)) { String str; MCLayoutLocationR r = new MCLayoutLocationR(); if (!isUseAppResource()) { str = getCustomResource().getString(key1); } else { MCGeneralPersonalizeResource resource = getSystemLocationResource(); str = resource.getString(key1); }  String[] token = str.split(","); if (token.length >= 5) { r.rootPanelID(token[0]); r.panelID(token[1]); r.componentID(token[2]); r.localeHasCr("true".equals(token[3])); r.localeNoCr("true".equals(token[4])); if (token.length >= 6) if (token[5].length() > 0) { r.localeWidth(Integer.valueOf(token[5])); } else { r.localeWidth(null); }   list.add(r); }  }  b++; }  Collections.sort(list, new LocationComparator()); Map<String, MCLayoutLocationR> map1 = new LinkedHashMap<>(); list.forEach(r1 -> {  }); return map1; }
/*      */   public Map<String, MCLayoutPanelR> loadSystemLocationPanel2(MCRootPanel rootPanel) { String baseKeys2[], moduleID = rootPanel.getModuleID(); String screenID = rootPanel.getScreenID(); List<MCLayoutPanelR> list = new ArrayList<>(); String localeID = MCSys.user.locale().toString(); String listKey3 = createPanelListResourceKey3("System", moduleID, screenID, localeID); if (!isUseAppResource()) { if (_customResource == null) loadResource();  baseKeys2 = getCustomResource().findPattern(MCConst.createKey(new String[] { listKey3, "*" })); } else { MCResourceLayerType type = MCResourceLayerType.SYS; MCGeneralPersonalizeResource resource = getSystemLocationResource(); baseKeys2 = resource.findPattern(type, MCConst.createKey(new String[] { listKey3, "*" })); }  String itemKey2 = String.valueOf(listKey3) + ".item"; byte b; int i; String[] arrayOfString1; for (i = (arrayOfString1 = baseKeys2).length, b = 0; b < i; ) { String key1 = arrayOfString1[b]; if (key1.contains(itemKey2)) { String str; MCLayoutPanelR r = new MCLayoutPanelR(); if (!isUseAppResource()) { str = getCustomResource().getString(key1); } else { MCGeneralPersonalizeResource resource = getSystemLocationResource(); str = resource.getString(key1); }  String[] token = str.split(","); if (token.length >= 5) { r.rootPanelID(token[0]); r.parentPanelID(token[1]); r.panelID(token[2]); if (token[3].length() > 0) r.limitWidth(Integer.valueOf(Integer.parseInt(token[3])));  if (token[4].length() > 0) r.localeFit(Boolean.valueOf("true".equals(token[4])));  list.add(r); }  }  b++; }  Map<String, MCLayoutPanelR> map1 = new LinkedHashMap<>(); list.forEach(r1 -> {  }); return map1; }
/*      */   public Integer getLocalizedDividerLocation(MCRootPanel rootPanel, MCSplitPane sp) { String baseKeys2[], moduleID = rootPanel.getModuleID(); String screenID = rootPanel.getScreenID(); String localeID = MCSys.user.locale().toString(); String listKey3 = createDividerListResourceKey3("System", moduleID, screenID, localeID); if (!isUseAppResource()) { if (_customResource == null) loadResource();  baseKeys2 = getCustomResource().findPattern(MCConst.createKey(new String[] { listKey3, "*" })); } else { MCResourceLayerType type = MCResourceLayerType.SYS; MCGeneralPersonalizeResource resource = getSystemLocationResource(); baseKeys2 = resource.findPattern(type, MCConst.createKey(new String[] { listKey3, "*" })); }  String itemKey2 = String.valueOf(listKey3) + ".item"; byte b; int i; String[] arrayOfString1; for (i = (arrayOfString1 = baseKeys2).length, b = 0; b < i; ) { String key1 = arrayOfString1[b]; if (key1.contains(itemKey2)) { String str; if (!isUseAppResource()) { str = getCustomResource().getString(key1); } else { MCGeneralPersonalizeResource resource = getSystemLocationResource(); str = resource.getString(key1); }  String[] token = str.split(","); if (token.length >= 4) { String rootPanelID = token[0]; String parentPanelID = token[1]; String panelID = token[2]; Integer n = null; if (token.length >= 4 && token[3].length() > 0) { n = Integer.valueOf(Integer.parseInt(token[3])); MCPanel p = getPanel(rootPanel, rootPanelID, parentPanelID, panelID); if (p != null) { Component up = sp.getTopComponent(); Component bottom = sp.getBottomComponent(); if (up instanceof MCPanel) { Component up1 = ((MCPanel)up).getComponents()[0]; if (up1 == p) return n;  }  if (bottom instanceof MCPanel) { Component bottom1 = ((MCPanel)bottom).getComponents()[0]; if (bottom1 == p) return n;  }  }  }  }  }  b++; }  return null; }
/* 7941 */   protected void _updateTabOrder(MCRootPanel rp, Container c, boolean init) { List<MCTabOrderBeans> tabOrderBeans = rp.getTabOrderBeans(true);
/* 7942 */     List<MCTabOrderBeans> tabOrderContainer = rp.getTabOrderContainer();
/* 7943 */     List<MCTabOrderBeans> list2 = new ArrayList<>(rp.getTabOrderBeans(init));
/*      */ 
/*      */ 
/*      */     
/* 7947 */     if (list2.size() > 0)
/*      */     
/* 7949 */     { List<MCTabOrderBeans> list5 = new ArrayList<>(list2);
/* 7950 */       List<MCTabOrderBeans> list6 = new ArrayList<>();
/* 7951 */       for (MCTabOrderBeans b5 : list5) {
/* 7952 */         int np5 = _getTabOrderParent(b5, tabOrderBeans, tabOrderContainer);
/* 7953 */         if (np5 == -1) {
/* 7954 */           list2.remove(b5);
/* 7955 */           list6.add(b5);
/*      */         } 
/*      */       } 
/*      */       
/* 7959 */       Collections.sort(list2, new TabOrderComparator(rp, tabOrderBeans, tabOrderContainer, true));
/* 7960 */       list2.addAll(list6);
/*      */       
/* 7962 */       rp.updateTabOrderBeans(list2); }  } public Boolean getLocalizedTabbedPane(MCRootPanel rootPanel, MCTabbedPane tp) { String baseKeys2[], moduleID = rootPanel.getModuleID(); String screenID = rootPanel.getScreenID(); String localeID = MCSys.user.locale().toString(); String listKey3 = createTabbedPaneListResourceKey3("System", moduleID, screenID, localeID); if (!isUseAppResource()) { if (_customResource == null) loadResource();  baseKeys2 = getCustomResource().findPattern(MCConst.createKey(new String[] { listKey3, "*" })); } else { MCResourceLayerType type = MCResourceLayerType.SYS; MCGeneralPersonalizeResource resource = getSystemLocationResource(); baseKeys2 = resource.findPattern(type, MCConst.createKey(new String[] { listKey3, "*" })); }  String itemKey2 = String.valueOf(listKey3) + ".item"; byte b; int i; String[] arrayOfString1; for (i = (arrayOfString1 = baseKeys2).length, b = 0; b < i; ) { String key1 = arrayOfString1[b]; if (key1.contains(itemKey2)) { String str; if (!isUseAppResource()) { str = getCustomResource().getString(key1); } else { MCGeneralPersonalizeResource resource = getSystemLocationResource(); str = resource.getString(key1); }  String[] token = str.split(","); if (token.length >= 4) { String rootPanelID = token[0]; String parentPanelID = token[1]; String componentID = token[2]; Boolean bool = null; if (token.length >= 4 && token[3].length() > 0) { bool = Boolean.valueOf("true".equals(token[3])); MCTabbedPane mCTabbedPane = getTabbedPane(rootPanel, rootPanelID, parentPanelID, componentID); if (mCTabbedPane != null) if (mCTabbedPane == tp) return bool;   }  }  }  b++; }  return null; } protected MCPanel getPanel(MCRootPanel rootPanel, String rootPanelID, String parentPanelID, String panelID) { MCPanel[] p = (MCPanel[])MCBeansUtil.getAllComponents(MCPanel.class, (Container)rootPanel); byte b; int i; MCPanel[] arrayOfMCPanel1; for (i = (arrayOfMCPanel1 = p).length, b = 0; b < i; ) { MCPanel p1 = arrayOfMCPanel1[b]; String _panelID = p1.getName(); String _parentPanelID = getParentPanel((Component)p1).getName(); String _rootPanelID = getRootPanel((Component)p1).getName(); if (MCStringUtil.eq(panelID, _panelID) && MCStringUtil.eq(parentPanelID, _parentPanelID) && MCStringUtil.eq(rootPanelID, _rootPanelID)) return p1;  b++; }  return null; } protected MCTabbedPane getTabbedPane(MCRootPanel rootPanel, String rootPanelID, String parentPanelID, String tabbedPaneID) { MCTabbedPane[] p = (MCTabbedPane[])MCBeansUtil.getAllComponents(MCTabbedPane.class, (Container)rootPanel); byte b; int i; MCTabbedPane[] arrayOfMCTabbedPane1; for (i = (arrayOfMCTabbedPane1 = p).length, b = 0; b < i; ) { MCTabbedPane p1 = arrayOfMCTabbedPane1[b]; String _panelID = p1.getName(); String _parentPanelID = getParentPanel((Component)p1).getName(); String _rootPanelID = getRootPanel((Component)p1).getName(); if (MCStringUtil.eq(tabbedPaneID, _panelID) && MCStringUtil.eq(parentPanelID, _parentPanelID) && MCStringUtil.eq(rootPanelID, _rootPanelID)) return p1;  b++; }  return null; } public MCLayoutSettingsR getPersonalizeSettings(MCRootPanel rootPanel) { String[] baseKeys2; if (this._layoutSettings == null) this._layoutSettings = new HashMap<>();  if (this._layoutSettings.containsKey(rootPanel)) return this._layoutSettings.get(rootPanel);  String moduleID = rootPanel.getModuleID(); String screenID = rootPanel.getScreenID(); String localeID = MCSys.user.locale().toString(); String listKey3 = createSettingsListResourceKey3("System", moduleID, screenID, localeID); if (!isUseAppResource()) { if (_customResource == null) loadResource();  baseKeys2 = getCustomResource().findPattern(MCConst.createKey(new String[] { listKey3, "*" })); } else { MCResourceLayerType type = MCResourceLayerType.SYS; MCGeneralPersonalizeResource resource = getSystemLocationResource(); baseKeys2 = resource.findPattern(type, MCConst.createKey(new String[] { listKey3, "*" })); }  MCLayoutSettingsR r = new MCLayoutSettingsR(); String itemKey2 = String.valueOf(listKey3) + ".item"; byte b; int i; String[] arrayOfString1; for (i = (arrayOfString1 = baseKeys2).length, b = 0; b < i; ) { String key1 = arrayOfString1[b]; if (key1.contains(itemKey2)) { String str; if (!isUseAppResource()) { str = getCustomResource().getString(key1); } else { MCGeneralPersonalizeResource resource = getSystemLocationResource(); str = resource.getString(key1); }  String[] token = str.split(","); if (token.length >= 1) { Integer n = toInteger(token[0]); if (n != null) r.screenWidth(n);  }  if (token.length >= 2) { Integer n = toInteger(token[1]); if (n != null) r.screenHeight(n);  }  if (token.length >= 3) { Integer n = toInteger(token[2]); if (n != null) r.panelWidth(n);  }  if (token.length >= 4) { Integer n = toInteger(token[3]); if (n != null) r.panelHeight(n);  }  if (token.length >= 5) r.useScrollButton(Boolean.valueOf(token[4]));  if (token.length >= 6) r.useScrollPane(Boolean.valueOf(token[5]));  if (token.length >= 7) r.usePrefSize(Boolean.valueOf(token[6]));  if (token.length >= 8) r.useAdjustHeight(Boolean.valueOf(token[7]));  if (token.length >= 9) { Integer n = toInteger(token[8]); if (n != null) r.panelPrefWidth(n);  }  if (token.length >= 10) { Integer n = toInteger(token[9]); if (n != null) r.panelPrefHeight(n);  }  }  b++; }  this._layoutSettings.put(rootPanel, r); return r; } private Integer toInteger(String s) { if (s == null) return null;  if (s.length() == 0) return null;  return Integer.valueOf(s); } private List<MCLayoutLocationR> getSystemLocationComponent(MCRootPanel rootPanel) { List<MCLayoutLocationR> list = rootPanel.getSystemLocationComponent(); return list; } public void initPersonalizeData(MCRootPanel rootPanel) { String key = rootPanel.getAutoLayoutType(); if (key == null || !key.equals("G")) return;  Map<String, MCLayoutLocationR> map = rootPanel.getDefaultLocationMap(); if (map.size() == 0) { Map<String, MCLayoutLocationR> map1 = new LinkedHashMap<>(); Map<String, MCLayoutPanelR> map3 = new LinkedHashMap<>(); setupComponentList(rootPanel, map1, map1, false); setCRComponentList(map1, true); setupPanelList(rootPanel, map3, map3, false); rootPanel.setDefaultLocationMap(map1); rootPanel.setDefaultPanelMap(map3); }  List<MCLocationSortR> list = new ArrayList<>(); rootPanel.setPersonalizeSortList(list); }
/*      */   public void setupComponentList(MCRootPanel rootPanel, Map<String, MCLayoutLocationR> map, Map<String, MCLayoutLocationR> defaultMap, boolean isMergeComponent) { List<Component> components = getAllComponents((Container)rootPanel); for (Component c : components) { if (canMoveComponent2(c, false, true, false, false)) { MCTextArea mCTextArea; Component comp = c; if (isComboBoxClassName(comp)) { comp = comp.getParent(); continue; }  if (isTextArea(comp)) mCTextArea = getTextArea(comp);  Container parentPanel = getParentPanel((Component)mCTextArea); if (parentPanel == rootPanel) continue;  if (isInputBtn((Component)mCTextArea)) continue;  if (canUseComponent((Component)mCTextArea)) { MCLayoutLocationR findR = getLocationR((Component)mCTextArea, map); MCLayoutLocationR r0 = null; if (findR != null) { r0 = findR; if (getComponentVisible((Component)mCTextArea) && isMergeComponent) r0.isVisible(true);  } else { r0 = new MCLayoutLocationR(); r0.isVisible(true); }  r0.componentID(mCTextArea.getName()); r0.panelID(parentPanel.getName()); MCRootPanel rp = getRootPanel((Component)mCTextArea); r0.rootPanelID(rp.getName()); if (isMergeComponent || findR == null) { r0.systemInvisible(false); if (r0.isVisible()) { r0.locationX(_getXOnPanel((Component)mCTextArea, (Container)rp.getBaseRootPanel())); r0.locationY(_getYOnPanel((Component)mCTextArea, (Container)rp.getBaseRootPanel())); } else if (findR != null) { r0.locationX(findR.locationX()); r0.locationY(findR.locationY()); } else { MCLayoutLocationR findR2 = getLocationR((Component)mCTextArea, defaultMap); if (findR2 != null) { r0.locationX(findR2.locationX()); r0.locationY(findR2.locationY()); } else { r0.locationX(0); r0.locationY(0); }  }  }  if (mCTextArea instanceof MCLabel || mCTextArea instanceof MCCheckBox || mCTextArea instanceof MCRadioButton) { r0.labelWidth(_getWidth((Component)mCTextArea)); r0.labelHeight(_getHeight((Component)mCTextArea)); }  r0.componentName(getComponentName((Component)mCTextArea, components)); r0.componentType(getComponentTypeName((Component)mCTextArea)); r0.hasCr(false); Component comp2 = getComponentForLayout((Component)mCTextArea); if (comp2 instanceof MCResourceBeans) { boolean b = MCBeansUtil.getNewLine((MCResourceBeans)comp2); r0.hasNewLine(b); }  if (findR == null) map.put(getLocationRKey(r0), r0);  }  }  }  int n = 1; for (MCLayoutLocationR r : map.values()) r.sequence(n++);  if (defaultLocationMap().size() > 0) setDefaultHasCrList(map, defaultLocationMap());  }
/*      */   private boolean getComponentVisible(Component comp) { MCPanel mCPanel; if (comp == null) return false;  if (hasInputContainerComponent(comp)) mCPanel = getInputContainer(comp);  if (mCPanel.isVisible()) return true;  return false; }
/*      */   public void setupPanelList(MCRootPanel rootPanel, Map<String, MCLayoutPanelR> map, Map<String, MCLayoutPanelR> defaultMap, boolean isMergeComponent) { map.clear(); List<Container> panelList = getPanelList(); for (Container c : panelList) { if (panelList.contains(c)) { MCPanel panel = (MCPanel)c; MCLayoutPanelR findR = getPanelR(c, map); MCLayoutPanelR r0 = null; if (findR != null) { r0 = findR; } else { r0 = new MCLayoutPanelR(); }  Component parentPanel = getParentPanel(c); r0.parentPanelID(parentPanel.getName()); r0.panelID(c.getName()); MCRootPanel rp = getRootPanel(c); r0.rootPanelID(rp.getName()); r0.layoutY(Integer.valueOf(_getY(c))); if (isMergeComponent || findR == null) { MCLayoutPanelR findR2 = getPanelR(c, defaultMap); if (findR2 != null) { r0.layoutPosition(findR2.layoutPosition()); r0.localeFit(findR2.localeFit()); } else { r0.layoutPosition(panel.getLayoutPosition()); r0.localeFit(Boolean.valueOf(MCBeansUtil.getFit((MCResourceBeans)panel))); }  }  if (findR == null) map.put(getPanelRKey(r0), r0);  }  }  int n = 1; for (MCLayoutPanelR r : map.values()) r.sequence(Integer.valueOf(n++));  }
/*      */   public void setupSortList(MCRootPanel rootPanel, List<MCLocationSortR> list, List<MCLocationSortR> defaultList, boolean isMergeComponent) {}
/*      */   protected void autoLayout(MCPanel p1, Map<String, MCLayoutLocationR> map0, List<MCLayoutLocationR> systemLocationList, List<MCLocationSortR> sortList) { Comparator<Component> comparator; boolean isEmbeddedPanel = isEmbeddedPanel((Container)p1); if (isEmbeddedPanel) return;  boolean isTabbedPane = isTabbedPane((Container)p1); if (isTabbedPane) return;  List<Component> list = getAllComponents2((Container)p1); if (list.size() == 0) return;  boolean hasMenuButton = hasMenuButton(list); if (hasMenuButton) return;  List<Component> list1 = new ArrayList<>(); for (Component c : list) { boolean f = false; MCLayoutLocationR r = getLocationR(c, map0); if (r != null) { for (MCLayoutLocationR r2 : systemLocationList) { if (r.equalsID(r2)) { f = true; break; }  }  if (f) continue;  }  if (canMoveComponent2(c, false, true, true, false)) { if (isTextArea(c)) { list1.add(getTextArea(c)); continue; }  list1.add(c); }  }  if (list1.size() == 0) return;  if (this.useLayoutLocationForSortPolicy) { comparator = new ComponentComparatorXY2(null); } else { comparator = new ComponentComparatorXY((Container)this._targetPanel, true, null); }  Collections.sort(list1, comparator); List<Component> list3 = new ArrayList<>(list1); sortComponentListWithPersonalize(list1, map0, sortList); List<Component> crList = getCRComponentList(list1, map0); List<Component> list2 = new ArrayList<>(list1); int y = _getYOnPanel(list3.get(0), null); int idx = 0; HashSet<Component> set = new HashSet<>(); int checkCR = -1; this._embeddedX = 0; int x = 0; Component c0 = list.get(0); Container parent = getParentPanel(c0); boolean _hasTitledBorder = _hasTitledBorder(parent); boolean _hasTabbedPanel = _hasTabbedPanel(getParentPanel1(c0)); if (_hasTitledBorder || _hasTabbedPanel || !isEmbeddedPanel) { x = getSpacerWidth2(); this._embeddedX = x; }  int lineGrid = this._targetPanel.getAutolayoutLineGrid(); boolean loop = true; while (loop) { Component c = list2.get(idx); if (!set.contains(c) && this._targetPanel.isAutolayoutUseInvisibleForMode() && isVisibleComponent(c)) { if (checkCR != -1) { Component c3 = list2.get(checkCR); if (checkCr(parent, c3, map0, false)) { x = this._embeddedX; Point pt2 = new Point(x, y + lineGrid); y = pt2.y; lineGrid = this._targetPanel.getAutolayoutLineGrid(); }  }  Component c2 = c; Point pt = new Point(x, y); AutoLayoutComponent alc = autoLayoutComponent(idx, c, set, x, y, map0, list2, lineGrid); idx = alc._idx; x = alc._x; y = alc._y; c2 = alc._c; lineGrid = alc._lineGrid; checkCR = alc._checkCR; if (pt.y == y && crList.contains(c2)) { x = 0; y += lineGrid; lineGrid = this._targetPanel.getAutolayoutLineGrid(); }  }  idx++; if (idx >= list2.size()) loop = false;  }  }
/*      */   protected void sortComponentListWithPersonalize(List<Component> list, Map<String, MCLayoutLocationR> map0, List<MCLocationSortR> sortList) { for (MCLocationSortR r : sortList) { String prev = r.prevComponentID(); Component comp = null; for (Component c : list) { String fullKey = MCStringUtil.join("/", new String[] { getRootPanel(c).getName(), getParentPanel(c).getName(), c.getName() }); if (r.fullComponentID().equals(fullKey)) { comp = c; break; }  }  if (comp != null) { Component prevComp = null; for (Component c : list) { String fullKey = MCStringUtil.join("/", new String[] { getRootPanel(c).getName(), getParentPanel(c).getName(), c.getName() }); if (prev != null && prev.equals(fullKey)) { prevComp = c; break; }  }  if (prevComp != null) { List<Component> list2 = getGroupList(comp); if (prev != null && prev.length() > 0) { int prevIdx = 0; if (list2 == null) { list2 = new ArrayList<>(); list2.add(comp); }  boolean b = false; for (Component c : list) { if (list2.contains(c)) continue;  String fullKey = MCStringUtil.join("/", new String[] { getRootPanel(c).getName(), getParentPanel(c).getName(), c.getName() }); if (prev.equals(fullKey)) { b = true; break; }  }  if (b) { list.removeAll(list2); for (Component c : list) { String fullKey = MCStringUtil.join("/", new String[] { getRootPanel(c).getName(), getParentPanel(c).getName(), c.getName() }); if (prev.equals(fullKey)) { for (Component c2 : list2) { list.add(prevIdx + 1, c2); prevIdx++; }  break; }  prevIdx++; }  }  }  }  }  }  }
/*      */   protected static final class AutoLayoutComponent {
/*      */     private final int _x; private final int _y; private final int _idx; private final Component _c; private final int _lineGrid; private final int _checkCR;
/*      */     private AutoLayoutComponent(int idx, int x, int y, Component c, int lineGrid, int checkCR) { this._idx = idx; this._x = x; this._y = y; this._c = c; this._lineGrid = lineGrid; this._checkCR = checkCR; } }
/*      */   private int getLimitWidth(Container p) { Integer w = this._targetPanel.getAutolayoutScreenWidth(); if (w == null) w = Integer.valueOf(this._targetPanel.getDefaultScreenWidth());  if (p instanceof MCPanel) { Rectangle r = _getDefaultBounds(p); boolean _hasTitledBorder = _hasTitledBorder(p); if (_hasTitledBorder) { Border border = ((MCPanel)p).getBorder(); int _edge = 0; if (border instanceof MCTitledBorder) _edge = ((MCTitledBorder)border).getEdge(p);  return Math.min(w.intValue(), r.width - _edge); }  return Math.min(w.intValue(), r.width + 0); }  if (p instanceof MCRootPanel) { Rectangle r = _getDefaultBounds(p); return Math.min(w.intValue(), r.width); }  if (p instanceof MCTabbedPane) { Rectangle r = _getDefaultBounds(p); return Math.min(w.intValue(), r.width); }  return w.intValue(); }
/*      */   protected boolean checkWidth(Point pt, int offsetX, Container p, Component c, Map<String, MCLayoutLocationR> map, boolean useFitPanel) { boolean usePanelLimitWidth = MCGeneralLayout.isUsePanelLimitWidth(); if (!usePanelLimitWidth) { boolean ret = _checkWidth(pt, offsetX, p, c, map, useFitPanel); return ret; }  if (!this._targetPanel.isAutolayoutUseCR()) return true;  boolean _usePrefSize = usePrefSize(((MCPanel)p).getBaseRootPanel()); if (_usePrefSize && !_isFitPanel(p)) return true;  boolean f = false; if (f && pt.x + offsetX > getLimitWidth(p)) return false;  boolean _hasTabbedPanel = _hasTabbedPanel(p); if (_hasTabbedPanel) { int w = _getWidth(p); if (p instanceof MCPanel) { w = _getWidth(p); MCRootPanel rp = ((MCPanel)p).getBaseRootPanel(); int w2 = _getWidth((Component)rp); boolean isFit = _isFitPanel(p); if (isFit) { int w3 = ((MCPanel)p).getLimitWidth().intValue(); if (w3 > 0) { w = w3; } else { Integer w4 = this._targetPanel.getAutolayoutPanelWidth(); if (w4 == null) { if (w < this._targetPanel.getDefaultPanelWidth()) { w = this._targetPanel.getDefaultPanelWidth(); } else { w = Math.min(w, this._targetPanel.getDefaultPanelWidth()); }  } else { w = w4.intValue(); }  }  } else { Integer w4 = ((MCPanel)p).getLimitWidth(); if (w4 != null && w4.intValue() > 0) { w = w4.intValue(); } else if (w2 > 0) { w = Math.min(w, w2); }  }  }  if (pt.x + offsetX > w) return false;  return true; }  if (useFitPanel && _isFitPanel(p)) { Integer w = this._targetPanel.getAutolayoutScreenWidth(); if (w == null) w = Integer.valueOf(this._targetPanel.getDefaultScreenWidth());  if (p instanceof MCPanel) { int w1 = ((MCPanel)p).getLimitWidth().intValue(); if (w1 > 0) w = Integer.valueOf(w1);  }  if (!f && pt.x + offsetX > w.intValue()) return false;  return true; }  if (!useFitPanel && _isFitPanel(p)) { MCLayoutLocationR findR = getLocationR(c, map); if (findR != null) { if (findR.defaultHasCr()) { if (findR.localeNoCr()) return true;  return false; }  return true; }  }  if (!f && pt.x + offsetX > getLimitWidth(p)) return false;  return true; }
/*      */   protected boolean _checkWidth(Point pt, int offsetX, Container p, Component c, Map<String, MCLayoutLocationR> map, boolean useFitPanel) { if (!this._targetPanel.isAutolayoutUseCR()) return true;  boolean f = false; if (f && pt.x + offsetX > getLimitWidth(p)) return false;  boolean _hasTabbedPanel = _hasTabbedPanel(p); if (_hasTabbedPanel) { int w = _getWidth(p); if (p instanceof MCPanel) { w = _getWidth(p); MCRootPanel rp = ((MCPanel)p).getBaseRootPanel(); int w2 = _getWidth((Component)rp); if (w2 > 0) w = Math.min(w, w2);  }  if (pt.x + offsetX > w) return false;  return true; }  if (useFitPanel && this._fitPanelList.contains(p)) return true;  if (!useFitPanel && this._fitPanelList.contains(p)) { MCLayoutLocationR findR = getLocationR(c, map); if (findR != null) { if (findR.defaultHasCr()) return false;  return true; }  }  if (!f && pt.x + offsetX > getLimitWidth(p)) return false;  return true; }
/*      */   protected boolean checkCr(Container p, Component c, Map<String, MCLayoutLocationR> map, boolean isButton) { MCTextArea mCTextArea; if (!this._targetPanel.isAutolayoutUseCR()) return false;  Component c1 = c; if (isTextArea(c)) mCTextArea = getTextArea(c);  MCLayoutLocationR findR = getLocationR((Component)mCTextArea, map); if (findR != null) { boolean _hasTabbedPanel = _hasTabbedPanel(p); boolean _hasTitledBorder = _hasTitledBorder(p); if (!_hasTabbedPanel && !_hasTitledBorder && !isButton) { if (findR.localeNoCr() || _isFitPanel(p)); if (this._fitPanelList.contains(p)); }  if (findR.localeNoCr()) return false;  if (findR.hasNewLine()) return true;  if (findR.userHasCr()) return true;  if (findR.localeHasCr()) return true;  }  return false; }
/*      */   public void setCRComponentList(Map<String, MCLayoutLocationR> map, boolean init) { Comparator<Component> comparator; map.values().forEach(r -> { r.hasCr(false); r.defaultHasCr(false); }); Map<String, MCLayoutLocationR> defaultMap = defaultLocationMap(); if (this.useLayoutLocationForSortPolicy) { comparator = new ComponentComparatorXY2(null); } else { comparator = new ComponentComparatorXY((Container)this._targetPanel, true, null); }  for (Container p : this._panelList) { List<Component> list1 = getAllComponents(p); Collections.sort(list1, comparator); int oy = 0; MCLayoutLocationR findR1 = null; int def_oy = 0; MCLayoutLocationR def_findR1 = null; for (Component c : list1) { Container p1 = getParentPanel(c); MCLayoutLocationR findR = getLocationR(c, map); if (findR != null) { int n = _getBaseline(c); int locationY = findR.locationY(); int y = locationY + n; if (findR1 != null && oy != y) findR1.hasCr(true);  oy = y; findR1 = findR; if (p == p1) { if (init) { locationY = findR.locationY(); } else { MCLayoutLocationR findR2 = getLocationR(c, defaultMap); if (findR2 == null) continue;  locationY = findR2.locationY(); }  y = locationY + n; if (def_findR1 != null && def_oy != y) def_findR1.defaultHasCr(true);  def_oy = y; def_findR1 = findR; }  }  }  }  }
/*      */   protected List<Component> getCRComponentList(List<Component> list1, Map<String, MCLayoutLocationR> map0) { List<Component> list = new ArrayList<>(); if (this._targetPanel.isAutolayoutUseCR()) { for (Component c1 : list1) { Component c2 = getComponentForLayout(c1); if (c2 instanceof MCResourceBeans) { boolean b = MCBeansUtil.getNewLine((MCResourceBeans)c2); MCLayoutLocationR findR = getLocationR(c2, map0); if (findR != null) findR.hasNewLine(b);  }  }  return list; }  for (Component c1 : list1) { MCLayoutLocationR r = map0.get(getLocationRKey(c1)); if (r != null && r.hasCr()) { list.add(c1); continue; }  Component c2 = getComponentForLayout(c1); if (c2 instanceof MCResourceBeans) { boolean b = MCBeansUtil.getNewLine((MCResourceBeans)c2); if (b) list.add(c1);  }  }  return list; }
/*      */   protected void setDefaultHasCrList(Map<String, MCLayoutLocationR> map, Map<String, MCLayoutLocationR> defaultMap) { map.entrySet().forEach(e1 -> { MCLayoutLocationR r2 = (MCLayoutLocationR)paramMap.get(e1.getKey()); if (r2 != null) ((MCLayoutLocationR)e1.getValue()).defaultHasCr(r2.defaultHasCr());  }); }
/*      */   protected AutoLayoutComponent autoLayoutComponent(int idx, Component c, HashSet<Component> set, int x0, int y0, Map<String, MCLayoutLocationR> map0, List<Component> list2, int lineGrid) { Component c0 = c; if (set.contains(c)) return new AutoLayoutComponent(idx, x0, y0, c0, lineGrid, -1, null);  int x = x0; int y = y0; boolean isButton = false; List<Component> buttonList = null; if (isButton(c)) { List<Component> buttonList1 = getButtonList(c, list2); buttonList = new ArrayList<>(); Map<Rectangle, List<Component>> rectMap = getComponentMap(buttonList1); for (Component c2 : buttonList1) { if (canMoveComponent2(c2, false, true, true, true)) { if (isVisibleComponent(c2)) { buttonList.add(c2); continue; }  boolean b = false; for (List<Component> list : rectMap.values()) { if (list.size() > 1 && list.contains(c2)) { b = true; break; }  }  if (b) buttonList.add(c2);  }  }  if (buttonList.size() >= 1) isButton = true;  }  Container parent = getParentPanel(c); boolean _hasTitledBorder = _hasTitledBorder(parent); Container cp = getParentPanel1(c); boolean _hasTabbedPanel = _hasTabbedPanel(cp); boolean isEmbeddedPanel = isEmbeddedPanel(cp); boolean isEmbeddedPanel3 = isEmbeddedPanel3(cp); boolean setLeftX = !(!_hasTitledBorder && !_hasTabbedPanel && isEmbeddedPanel); if (isEmbeddedPanel3) setLeftX = true;  if (parent instanceof MCPanel) { MCPanel parent2 = getTitledBorderPanel((MCPanel)parent); if (parent2 != null) setLeftX = true;  }  int leftX = 0; if (setLeftX) leftX = this._embeddedX;  boolean leftSide = false; if (x <= leftX) leftSide = true;  if (isButton) { if (leftSide) if (buttonList.get(0) instanceof MCButton) { if (setLeftX) { if (_hasTitledBorder) { leftX = this._embeddedX; } else { x = 0; }  } else { leftX = this._embeddedX; }  } else { leftX = this._embeddedX; }   Map<Rectangle, List<Component>> rectMap = getComponentMap(buttonList); List<Component> calced = new ArrayList<>(); int w = 0; for (Component c2 : buttonList) { if (calced.contains(c2)) continue;  for (List<Component> list : rectMap.values()) { if (list.contains(c2)) { calced.addAll(list); break; }  }  if (!calced.contains(c2)) calced.add(c2);  int w2 = _getWidth(c2); if (buttonList.get(buttonList.size() - 1) != c2) { w += w2 + this._targetPanel.getAutolayoutSpaceButtonAndButton(); continue; }  w += w2; }  Point pt = new Point(x, y); if (!leftSide && !checkWidth(pt, w, parent, buttonList.get(buttonList.size() - 1), map0, true)) { if (buttonList.get(0) instanceof MCButton) { if (_hasTitledBorder) { x = leftX; } else { x = 0; }  } else if (setLeftX) { x = leftX; } else { x = 0; }  pt = new Point(x, pt.y + lineGrid); y = pt.y; lineGrid = this._targetPanel.getAutolayoutLineGrid(); }  List<Component> moved = new ArrayList<>(); int checkCR = list2.indexOf(c0); for (Component c3 : buttonList) { if (moved.contains(c3)) continue;  pt = new Point(x, y); int w3 = _getWidth(c3); if (!checkWidth(pt, w3, parent, c3, map0, true)) { if (buttonList.get(0) instanceof MCButton) { if (_hasTitledBorder) { x = leftX; } else { x = 0; }  } else if (setLeftX) { x = leftX; } else { x = 0; }  pt = new Point(x, pt.y + lineGrid); y = pt.y; lineGrid = this._targetPanel.getAutolayoutLineGrid(); checkCR = -1; } else { checkCR = list2.indexOf(c3); }  autoLayoutMoveComponent(c3, pt, map0); set.add(c3); int h = _getHeight(c3) + getLineGridOffset(); if (h > lineGrid) lineGrid = h;  x = pt.x + w3; moved.add(c3); c0 = c3; for (List<Component> list : rectMap.values()) { if (list.contains(c3)) { for (Component c4 : list) { if (c4 != c3) { autoLayoutMoveComponent(c4, pt, map0); set.add(c4); moved.add(c4); c0 = c4; }  }  break; }  }  if (buttonList.get(buttonList.size() - 1) != c3) x += this._targetPanel.getAutolayoutSpaceButtonAndButton();  if (buttonList.size() > 1) { Point pt2 = new Point(x, y); if (checkCr(parent, c3, map0, true)) { if (buttonList.get(0) instanceof MCButton) { if (_hasTitledBorder) { x = leftX; } else { x = 0; }  } else if (setLeftX) { x = leftX; } else { x = 0; }  pt2 = new Point(x, pt2.y + lineGrid); y = pt2.y; lineGrid = this._targetPanel.getAutolayoutLineGrid(); checkCR = -1; continue; }  checkCR = list2.indexOf(c0); }  }  if (checkCR != -1) x += getSpacerWidth2();  return new AutoLayoutComponent(idx, x, y, c0, lineGrid, checkCR, null); }  List<Component> list5 = getGroupList(c); if (list5 == null) { list5 = new ArrayList<>(); list5.add(c); }  List<Component> list6 = new ArrayList<>(); for (Component c5 : list5) { if (isVisibleComponent(c5)) list6.add(c5);  }  Component c1 = list6.get(0); if (c1 instanceof MCLabel) setLabelAlign(c1);  x = convertGridX(x, 0); if (leftSide && setLeftX) x = leftX;  int y1 = y; Point pt1 = new Point(x, y1); if ((this._targetPanel.isAutolayoutUseCR() & (leftSide ? 0 : 1)) != 0) { int w = 0; for (Component c6 : list6) { if (isVisibleComponent(c6)) { if (c6 == c1) { w = _getWidth(c1); continue; }  w = w + this._targetPanel.getAutolayoutSpaceLabelAndField() + _getWidth(c6); }  }  if (!checkWidth(pt1, w, parent, list6.get(list6.size() - 1), map0, true)) { x = leftX; pt1 = new Point(x, pt1.y + lineGrid); y = pt1.y; lineGrid = this._targetPanel.getAutolayoutLineGrid(); }  }  for (Component c6 : list6) { pt1 = new Point(x, pt1.y); y = pt1.y; if (c1 == c6) { if (x == getSpacerWidth2() && list6.size() == 1 && !_hasTabbedPanel && !(c1 instanceof MCRadioButton) && !(c1 instanceof mcframe.clientCore.beans.MCTextField) && !(c1 instanceof mcframe.clientCore.beans.MCNumberField) && !(c1 instanceof mcframe.clientCore.beans.MCTimestampField) && !(c1 instanceof MCImageView)) { x = 0; pt1 = new Point(x, pt1.y); }  autoLayoutMoveComponent(c1, pt1, map0); if (getTextArea(c1) != null) set.add(getTextArea(c1));  set.add(c1); int h1 = _getHeight(c1) + getLineGridOffset(); if (h1 > lineGrid)
/*      */           lineGrid = h1;  int w1 = _getWidth(c1); x = pt1.x + w1; if (w1 != 0 && list6.size() > 1)
/*      */           x += this._targetPanel.getAutolayoutSpaceLabelAndField();  } else { autoLayoutMoveComponent(c6, pt1, map0); if (getTextArea(c6) != null)
/*      */           set.add(getTextArea(c6));  set.add(c6); int h6 = _getHeight(c6) + getLineGridOffset(); if (h6 > lineGrid)
/*      */           lineGrid = h6;  int w6 = _getWidth(c6); x = pt1.x + w6; if (c6 != list6.get(list6.size() - 1))
/*      */           x += getSpacerWidth5();  }  if (isTextArea(c6)) { if (checkCr(parent, c0, map0, false)) { if (setLeftX) { x = leftX; } else { x = 0; }  pt1 = new Point(x, y + lineGrid); lineGrid = this._targetPanel.getAutolayoutLineGrid(); continue; }  if (checkCr(parent, c6, map0, false)) { x = 0; pt1 = new Point(x, y + lineGrid); y = pt1.y; lineGrid = this._targetPanel.getAutolayoutLineGrid(); }  continue; }  if (isImageView(c6)) { if (checkCr(parent, c0, map0, false)) { if (setLeftX) { x = leftX; } else { x = 0; }  pt1 = new Point(x, y + lineGrid); lineGrid = this._targetPanel.getAutolayoutLineGrid(); continue; }  if (checkCr(parent, c6, map0, false)) { x = 0; pt1 = new Point(x, y + lineGrid); y = pt1.y; lineGrid = this._targetPanel.getAutolayoutLineGrid(); }  continue; }  if (!this._useFitPanel) { if (!checkWidth(pt1, 0, parent, c6, map0, this._useFitPanel)) { x = 0; pt1 = new Point(x, pt1.y + lineGrid); y = pt1.y; lineGrid = this._targetPanel.getAutolayoutLineGrid(); continue; }  MCLayoutLocationR findR = getLocationR(c6, map0); if (findR != null && findR.localeHasCr()) { x = 0; pt1 = new Point(x, pt1.y + lineGrid); y = pt1.y; lineGrid = this._targetPanel.getAutolayoutLineGrid(); }  }  }  c0 = list6.get(list6.size() - 1); x += getSpacerWidth2(); int idx2 = list2.indexOf(c0); return new AutoLayoutComponent(idx, x, y, c0, lineGrid, idx2, null); }
/*      */   public boolean isTextArea(Component c) { if (c instanceof MCScrollPane) { MCScrollPane sc = (MCScrollPane)c; JViewport c2 = sc.getViewport(); if (c2.getView() instanceof MCTextArea)
/*      */         return true;  }  return false; }
/*      */   private boolean isImageView(Component c) { if (c instanceof MCImageView)
/*      */       return true;  return false; }
/*      */   protected void autoLayoutMoveComponent(Component c, Point pt, Map<String, MCLayoutLocationR> map0) { int x = pt.x; int y = pt.y; Point pt2 = new Point(x, y); MCLayoutLocationR findR = getLocationR(c, map0); moveComponent2(c, pt2, findR); }
/*      */   public MCLayoutLocationR getLocationR(Component c, Map<String, MCLayoutLocationR> map0) { return map0.get(getLocationRKey(c)); }
/*      */   private String getLocationRKey(Component c) { String cname = ""; String pname = ""; String rname = ""; if (c == null)
/*      */       return "";  cname = MCStringUtil.nullToBlank(c.getName()); Container p = getParentPanel(c); if (p != null)
/*      */       pname = MCStringUtil.nullToBlank(p.getName());  MCRootPanel mCRootPanel = getRootPanel(c); if (mCRootPanel != null)
/*      */       rname = MCStringUtil.nullToBlank(mCRootPanel.getName());  return MCStringUtil.join(" ", new String[] { cname, pname, rname }); }
/*      */   public static String getLocationRKey(MCLayoutLocationR r) { return MCStringUtil.join(" ", new String[] { r.componentID(), r.panelID(), r.rootPanelID() }); }
/*      */   private MCLayoutPanelR getPanelR(Component c, Map<String, MCLayoutPanelR> map0) { return map0.get(getPanelRKey(c)); }
/*      */   public static String getPanelRKey(MCLayoutPanelR r) { return MCStringUtil.join(" ", new String[] { r.panelID(), r.parentPanelID(), r.rootPanelID() }); }
/*      */   private String getPanelRKey(Component c) { return MCStringUtil.join(" ", new String[] { c.getName(), getParentPanel(c).getName(), getRootPanel(c).getName() }); }
/*      */   private void setLabelAlign(Component c) { if (c instanceof MCLabel)
/*      */       if (this._targetPanel.isAutolayoutUseAlignRight()) { ((MCLabel)c).setHorizontalAlignment(4); } else { ((MCLabel)c).setHorizontalAlignment(2); }   }
/*      */   private boolean isButton(Component comp) { if (comp instanceof MCButton)
/*      */       return true;  if (comp instanceof MCCheckBox)
/*      */       return true;  if (comp instanceof MCRadioButton)
/*      */       return true;  return false; }
/*      */   protected boolean isNoLabelField(Component c) { boolean f = false; if (c instanceof MCField) { f = true; } else if (c instanceof mcframe.clientCore.beans.combobox.MCComboField) { f = true; } else if (c instanceof mcframe.clientCore.beans.combobox.MCTextComboBox) { f = true; } else if (c instanceof mcframe.clientCore.beans.combobox.MCNumberComboBox) { f = true; } else if (c instanceof mcframe.clientCore.beans.combobox.MCDateComboBox) { f = true; } else if (c instanceof mcframe.clientCore.beans.combobox.MCTimestampComboBox) { f = true; }  if (!f)
/*      */       return false;  List<Component> list1 = getGroupList(c); if (list1 == null)
/*      */       return true;  if (list1.size() == 1)
/*      */       return true;  return false; }
/*      */   private List<Component> getButtonList(Component comp, List<Component> list) { List<Component> list0 = new ArrayList<>(list); List<Component> list1 = new ArrayList<>(); Class<?> cls = comp.getClass(); boolean isCheckBox = comp instanceof MCCheckBox; boolean f = false; int y = _getYOnPanel(comp, null) + _getBaseline(comp); for (Component c : list0) { if (f) { int y2 = _getYOnPanel(c, null) + _getBaseline(c); if (!isCheckBox) { if (y2 != y || cls != c.getClass())
/*      */             break;  list1.add(c); continue; }  if (cls != c.getClass())
/*      */           break;  list1.add(c); continue; }  if (c == comp) { list1.add(c); f = true; }  }  for (Component c : new ArrayList(list1)) { List<Component> list2 = getGroupList(c); if (list2 != null)
/*      */         list1.remove(c);  }  if (list1.indexOf(comp) == -1)
/*      */       return new ArrayList<>();  return list1; }
/*      */   protected final class ComponentComparatorXY implements Comparator<Component> {
/*      */     private final Container p3; private boolean _useDefaultBounds = true;
/*      */     private ComponentComparatorXY(Container parent, boolean useDefaultBounds) { this.p3 = parent; this._useDefaultBounds = useDefaultBounds; }
/*      */     public int compare(Component p1, Component p2) { int y1 = MCAutoLayout.this._getYOnPanel(p1, this.p3, this._useDefaultBounds) + MCAutoLayout.this._getBaseline(p1, this._useDefaultBounds); int y2 = MCAutoLayout.this._getYOnPanel(p2, this.p3, this._useDefaultBounds) + MCAutoLayout.this._getBaseline(p2, this._useDefaultBounds); if (y1 < y2)
/*      */         return -1;  if (y1 > y2)
/*      */         return 1;  int x1 = MCAutoLayout.this._getXOnPanel(p1, this.p3, this._useDefaultBounds); int x2 = MCAutoLayout.this._getXOnPanel(p2, this.p3, this._useDefaultBounds); if (x1 < x2)
/*      */         return -1;  if (x1 > x2)
/*      */         return 1;  return 0; } }
/*      */   protected final class ComponentComparatorXY2 implements Comparator<Component> {
/*      */     private final Map<String, MCLayoutLocationR> map0 = MCAutoLayout.this.locationMap();
/*      */     public int compare(Component p1, Component p2) { MCLayoutLocationR findR1 = MCAutoLayout.this.getLocationR(p1, this.map0); MCLayoutLocationR findR2 = MCAutoLayout.this.getLocationR(p2, this.map0); if (findR1 == null || findR2 == null) { if (findR1 == null && findR2 != null)
/*      */           return 1;  if (findR1 != null && findR2 == null)
/*      */           return -1;  return 0; }  int y1 = findR1.locationY(); int y2 = findR2.locationY(); if (y1 < y2)
/*      */         return -1;  if (y1 > y2)
/*      */         return 1;  int x1 = findR1.locationX(); int x2 = findR2.locationX(); if (x1 < x2)
/*      */         return -1;  if (x1 > x2)
/*      */         return 1;  return 0; }
/*      */     private ComponentComparatorXY2() {} }
/*      */   private int convertGridX(int _x, int _offsetX) { double x = _x; double offsetX = _offsetX; if (this._targetPanel.isAutolayoutUseFloorGrid()) { double d = Math.floor((x - offsetX) / this._targetPanel.getAutoLayoutGridSize()); d = d * this._targetPanel.getAutoLayoutGridSize() + offsetX; return (new Double(d)).intValue(); }  double gx = Math.ceil((x - offsetX) / this._targetPanel.getAutoLayoutGridSize()); gx = gx * this._targetPanel.getAutoLayoutGridSize() + offsetX; return (new Double(gx)).intValue(); }
/*      */   public void updateLabelSize() { if (!this._targetPanel.isAutolayoutUseUpdateLabelSize())
/*      */       return;  boolean useShrinkLabelWidth = MCGeneralLayout.useShrinkLabelWidth(); MCLabel label = null; MCCheckBox check = null; MCRadioButton radio = null; MCButton button = null; for (Container p : this._panelList) { if (isEmbeddedPanel(p))
/*      */         continue;  List<Component> components = getAllComponents2(p); for (Component comp : components) { if (isComboBoxClassName(comp))
/*      */           continue;  if (comp instanceof MCLabel) { int w = _getWidth(comp); int h = _getHeight(comp); if (label == null) { label = new MCLabel(comp.getName()); } else { label.setName(comp.getName()); }  label.setText(((MCLabel)comp).getLabelByLocale()); label.setIcon(((MCLabel)comp).getDefIcon()); Font font = ((MCLabel)comp).getDefaultFont(); if (font == null)
/*      */             font = ((MCLabel)comp).getFont();  label.setFont(font); label.updateFontSize(100); int w1 = (label.getPreferredSize()).width; if (useShrinkLabelWidth) { if (_getWidth(comp) < w1 || _getWidth(comp) > w1)
/*      */               w += w1 - _getWidth(comp);  } else if (_getWidth(comp) < w1) { w += w1 - _getWidth(comp); }  _setSize(comp, w, h, true); _setDefaultLocation(comp, _getLocation(comp), new Dimension(w, h)); continue; }  if (comp instanceof MCCheckBox) { int w = _getWidth(comp); int h = _getHeight(comp); if (check == null) { check = MCBeansCompatibilityFactory.createCheckBox(comp.getName()); } else { check.setName(comp.getName()); }  check.setText(((MCCheckBox)comp).getLabelByLocale()); check.setIcon(((MCCheckBox)comp).getIcon()); Font font = ((MCCheckBox)comp).getDefaultFont(); if (font == null)
/*      */             font = ((MCCheckBox)comp).getFont();  check.setFont(font); check.updateFontSize(100); int w1 = (check.getPreferredSize()).width; if (useShrinkLabelWidth) { if (_getWidth(comp) < w1 || _getWidth(comp) > w1)
/*      */               w += w1 - _getWidth(comp);  } else if (_getWidth(comp) < w1) { w += w1 - _getWidth(comp); }  _setSize(comp, w, h, true); _setDefaultLocation(comp, _getLocation(comp), new Dimension(w, h)); continue; }  if (comp instanceof MCRadioButton) { int w = _getWidth(comp); int h = _getHeight(comp); if (radio == null) { radio = MCBeansCompatibilityFactory.createRadioButton(comp.getName()); } else { radio.setName(comp.getName()); }  radio.setText(((MCRadioButton)comp).getLabelByLocale()); radio.setIcon(((MCRadioButton)comp).getIcon()); Font font = ((MCRadioButton)comp).getDefaultFont(); if (font == null)
/*      */             font = ((MCRadioButton)comp).getFont();  radio.setFont(font); radio.updateFontSize(100); int w1 = (radio.getPreferredSize()).width; if (useShrinkLabelWidth) { if (_getWidth(comp) < w1 || _getWidth(comp) > w1)
/*      */               w += w1 - _getWidth(comp);  } else if (_getWidth(comp) < w1) { w += w1 - _getWidth(comp); }  _setSize(comp, w, h, true); _setDefaultLocation(comp, _getLocation(comp), new Dimension(w, h)); continue; }  if (comp instanceof MCButton) { int w = _getWidth(comp); int h = _getHeight(comp); if (button == null) { button = MCBeansCompatibilityFactory.createButton(comp.getName()); } else { button.setName(comp.getName()); }  button.setText(((MCButton)comp).getLabelByLocale()); button.setIcon(((MCButton)comp).getDefIcon()); Font font = ((MCButton)comp).getDefaultFont(); if (font == null)
/*      */             font = ((MCButton)comp).getFont();  button.setFont(font); button.updateFontSize(100); int w1 = (button.getPreferredSize()).width + 2; if (_getWidth(comp) < w1)
/*      */             w += w1 - _getWidth(comp);  _setSize(comp, w, h, true); _setDefaultLocation(comp, _getLocation(comp), new Dimension(w, h)); }  }  }  }
/*      */   public void updateLocaleWidth() { Map<String, MCLayoutLocationR> _map = this._targetPanel.getSystemLocationMap2(); Map<String, MCLayoutPanelR> _map2 = this._targetPanel.getPanelMap2(); for (Container p : this._panelList) { if (isEmbeddedPanel(p))
/*      */         continue;  List<Component> components = getAllComponents2(p); for (Component comp : components) { if (comp instanceof MCButton || comp instanceof MCField || comp instanceof MCPasswordField || comp instanceof MCFieldComboBox) { int h = _getHeight(comp); MCLayoutLocationR findR = getLocationR(comp, _map); if (findR != null) { Integer w2 = findR.localeWidth(); if (w2 != null) { _setSize(comp, w2.intValue(), h, true); _setDefaultLocation(comp, _getLocation(comp), new Dimension(w2.intValue(), h)); }  continue; }  if (comp instanceof MCCalendarField && ((MCCalendarField)comp).isAmPmField()) { MCCalendarFormat<?> format = ((MCCalendarField)comp).getCalendarFormat(); int w3 = getStringWidth(format); _setSize(comp, w3, h, true); comp.setPreferredSize(new Dimension(w3, h)); _setDefaultLocation(comp, _getLocation(comp), new Dimension(w3, h)); }  continue; }  if (comp instanceof MCTextArea) { int h = _getHeight(comp); MCLayoutLocationR findR = getLocationR(comp, _map); if (findR != null) { Integer w2 = findR.localeWidth(); if (w2 != null) { _setSize(comp, w2.intValue(), h, true); _setDefaultLocation(comp, _getLocation(comp), new Dimension(w2.intValue(), h)); MCScrollPane sc = ((MCTextArea)comp).getScrollPaneForLayout(); if (sc != null) { _setSize((Component)sc, w2.intValue(), h, true); _setDefaultLocation((Component)sc, _getLocation(comp), new Dimension(w2.intValue(), h)); }  }  }  continue; }  if (comp instanceof MCImageView) { int h = _getHeight(comp); MCLayoutLocationR findR = getLocationR(comp, _map); if (findR != null) { Integer w2 = findR.localeWidth(); if (w2 != null) { _setSize(comp, w2.intValue(), h, true); _setDefaultLocation(comp, _getLocation(comp), new Dimension(w2.intValue(), h)); }  }  }  }  if (p instanceof MCPanel) { MCLayoutPanelR findR = getPanelR(p, _map2); if (findR != null) { Integer w2 = findR.limitWidth(); if (w2 != null && w2.intValue() > 0)
/*      */             ((MCPanel)p).setLimitWidth(w2);  }  }  }  }
/*      */   static int getStringWidth(MCCalendarFormat<?> format) { int perByte = 8; int x_margin = 5; int olen = format.doOutputFormat((MCCalendarDate)MCDate.today()).length(); int ilen = format.doInputFormat((MCCalendarDate)MCDate.today()).length(); if (olen - ilen < 6)
/*      */       olen = ilen + 6;  return perByte * (olen - 1) + x_margin; }
/*      */   private void fitLabelSize() { if (!this._targetPanel.isAutolayoutUseFitLabelSize()) { for (Container p : this._panelList) { List<Component> components = getAllComponents2(p); for (Component comp : components) { if (comp instanceof MCLabel) { int w = _getWidth(comp); int h = _getHeight(comp); int w1 = (((MCLabel)comp).getDefaultBounds()).width; if (w != w1) { _setSize(comp, w1, h, true); _setDefaultLocation(comp, _getLocation(comp), new Dimension(w1, h)); }  }  }  }  } else { for (Container p : this._panelList) { List<Component> components = getAllComponents2(p); for (Component comp : components) { if (comp instanceof MCLabel) { int w = _getWidth(comp); int h = _getHeight(comp); MCLabel lbl = new MCLabel(comp.getName()); lbl.setText(((MCLabel)comp).getLabelByLocale()); lbl.setIcon(((MCLabel)comp).getDefIcon()); Font font = ((MCLabel)comp).getDefaultFont(); if (font == null)
/*      */               font = ((MCLabel)comp).getFont();  lbl.setFont(font); lbl.updateFontSize(100); int w1 = (lbl.getPreferredSize()).width; if (w != w1) { _setSize(comp, w1, h, true); _setDefaultLocation(comp, _getLocation(comp), new Dimension(w1, h)); }  }  }  }  }  }
/*      */   protected void fitButtonLabelSize() {}
/* 8053 */   public void sortTabOrderBeans(MCRootPanel bp) { List<MCTabOrderBeans> list2 = bp.getTabOrderBeans(false);
/* 8054 */     Collections.sort(list2, new TabOrderComparator(bp, bp.getTabOrderBeans(), bp.getTabOrderContainer(), false));
/* 8055 */     bp.updateTabOrderBeans(list2); }
/*      */ 
/*      */ 
/*      */   
/*      */   protected class TabOrderComparator
/*      */     implements Comparator<MCTabOrderBeans>
/*      */   {
/*      */     private boolean _useLocation;
/*      */     
/*      */     private MCRootPanel _rootPanel;
/*      */     
/*      */     private List<MCTabOrderBeans> _tabOrderBeans;
/*      */     
/*      */     private List<MCTabOrderBeans> _tabOrderContainer;
/*      */ 
/*      */     
/*      */     public TabOrderComparator(MCRootPanel rp, List<MCTabOrderBeans> _tabOrderBeans, List<MCTabOrderBeans> _tabOrderContainer, boolean _useLocation) {
/* 8072 */       this._useLocation = _useLocation;
/* 8073 */       this._rootPanel = rp;
/* 8074 */       this._tabOrderContainer = _tabOrderContainer;
/* 8075 */       this._tabOrderBeans = _tabOrderBeans;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int compare(MCTabOrderBeans a, MCTabOrderBeans b) {
/* 8082 */       int np1 = MCAutoLayout.this._getTabOrderParent(a, this._tabOrderBeans, this._tabOrderContainer);
/* 8083 */       int np2 = MCAutoLayout.this._getTabOrderParent(b, this._tabOrderBeans, this._tabOrderContainer);
/*      */ 
/*      */       
/* 8086 */       if (np1 == -2 || np2 == -2) {
/* 8087 */         int i = this._tabOrderBeans.indexOf(a);
/* 8088 */         int j = this._tabOrderBeans.indexOf(b);
/* 8089 */         if (i < j) {
/* 8090 */           return -1;
/*      */         }
/* 8092 */         if (i > j) {
/* 8093 */           return 1;
/*      */         }
/* 8095 */         return 0;
/*      */       } 
/*      */       
/* 8098 */       if (np1 >= 0 && np2 >= 0) {
/* 8099 */         if (np1 < np2)
/* 8100 */           return -1; 
/* 8101 */         if (np1 > np2) {
/* 8102 */           return 1;
/*      */         }
/*      */       } 
/*      */       
/* 8106 */       if (this._useLocation) {
/* 8107 */         Point pt1 = MCAutoLayout.this.getXYOnPanel((Component)a, (Container)this._rootPanel);
/* 8108 */         Point pt2 = MCAutoLayout.this.getXYOnPanel((Component)b, (Container)this._rootPanel);
/* 8109 */         int x1 = pt1.x;
/* 8110 */         int x2 = pt2.x;
/* 8111 */         int y1 = pt1.y;
/* 8112 */         int y2 = pt2.y;
/* 8113 */         if (MCAutoLayout.this.isBaseLineTabOrderBeans(a)) {
/* 8114 */           y1 += MCAutoLayout.this._getBaseline((Component)a);
/*      */         }
/* 8116 */         if (MCAutoLayout.this.isBaseLineTabOrderBeans(b)) {
/* 8117 */           y2 += MCAutoLayout.this._getBaseline((Component)b);
/*      */         }
/*      */         
/* 8120 */         if (y1 < y2)
/* 8121 */           return -1; 
/* 8122 */         if (y1 > y2) {
/* 8123 */           return 1;
/*      */         }
/* 8125 */         if (x1 < x2)
/* 8126 */           return -1; 
/* 8127 */         if (x1 > x2) {
/* 8128 */           return 1;
/*      */         }
/*      */         
/* 8131 */         int i = this._tabOrderBeans.indexOf(a);
/* 8132 */         int j = this._tabOrderBeans.indexOf(b);
/* 8133 */         if (i < j)
/* 8134 */           return -1; 
/* 8135 */         if (i > j) {
/* 8136 */           return 1;
/*      */         }
/* 8138 */         return 0;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 8143 */       int n1 = this._tabOrderBeans.indexOf(a);
/* 8144 */       int n2 = this._tabOrderBeans.indexOf(b);
/* 8145 */       if (n1 < n2)
/* 8146 */         return -1; 
/* 8147 */       if (n1 > n2) {
/* 8148 */         return 1;
/*      */       }
/* 8150 */       return 0;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int _getTabOrderParent(MCTabOrderBeans c, List<MCTabOrderBeans> tabOrderBeans, List<MCTabOrderBeans> tabOrderContainer) {
/* 8166 */     Container p = null;
/* 8167 */     if (!(c instanceof Container)) {
/* 8168 */       p = ((Component)c).getParent();
/* 8169 */       if (p == null) {
/* 8170 */         return -2;
/*      */       }
/*      */     } else {
/* 8173 */       p = (Container)c;
/* 8174 */       if (p.getParent() == null) {
/* 8175 */         return -2;
/*      */       }
/*      */     } 
/* 8178 */     boolean b = true;
/* 8179 */     int n2 = -1;
/* 8180 */     while (b) {
/* 8181 */       if (p instanceof MCLabel || p instanceof MCButton || p instanceof mcframe.clientCore.beans.MCTextField || 
/* 8182 */         p instanceof mcframe.clientCore.beans.MCNumberField || p instanceof MCPasswordField || p instanceof mcframe.clientCore.beans.MCDateField || 
/* 8183 */         p instanceof mcframe.clientCore.beans.MCTimestampField || p instanceof mcframe.clientCore.beans.combobox.MCComboField || p instanceof mcframe.clientCore.beans.combobox.MCTextComboBox || 
/* 8184 */         p instanceof mcframe.clientCore.beans.combobox.MCNumberComboBox || p instanceof mcframe.clientCore.beans.combobox.MCDateComboBox || 
/* 8185 */         p instanceof mcframe.clientCore.beans.combobox.MCTimestampComboBox || p instanceof MCTextArea || p instanceof MCRadioButton || 
/* 8186 */         p instanceof MCCheckBox || 
/* 8187 */         p instanceof MCTable || p instanceof MCSplitPane || 
/* 8188 */         p instanceof mcframe.clientCore.beans.tree.MCTree64 || p instanceof mcframe.clientCore.beans.tree.MCTree || 
/* 8189 */         p instanceof mcframe.clientCore.beans.listview.MCListView) {
/* 8190 */         p = p.getParent();
/* 8191 */         if (p == null) {
/* 8192 */           b = false; continue;
/* 8193 */         }  if (p instanceof javax.swing.JFrame) {
/* 8194 */           b = false;
/*      */         }
/*      */         
/*      */         continue;
/*      */       } 
/* 8199 */       int n1 = tabOrderContainer.indexOf(p);
/* 8200 */       if (n1 >= 0) {
/* 8201 */         n2 = n1;
/*      */       }
/*      */       
/* 8204 */       boolean isEmbeddedPanel = isEmbeddedPanel1(p, true);
/* 8205 */       if (!isEmbeddedPanel) {
/* 8206 */         int n = tabOrderContainer.indexOf(p);
/* 8207 */         if (n >= 0) {
/* 8208 */           return n;
/*      */         }
/*      */       } 
/* 8211 */       p = p.getParent();
/* 8212 */       if (p == null) {
/* 8213 */         b = false; continue;
/* 8214 */       }  if (p instanceof javax.swing.JFrame) {
/* 8215 */         b = false;
/*      */       }
/*      */     } 
/*      */     
/* 8219 */     return n2;
/*      */   }
/*      */ 
/*      */   
/*      */   protected boolean isBaseLineTabOrderBeans(MCTabOrderBeans c) {
/* 8224 */     if (c instanceof MCLabel || c instanceof MCButton || c instanceof mcframe.clientCore.beans.MCTextField || 
/* 8225 */       c instanceof mcframe.clientCore.beans.MCNumberField || c instanceof MCPasswordField || c instanceof mcframe.clientCore.beans.MCDateField || 
/* 8226 */       c instanceof mcframe.clientCore.beans.MCTimestampField || c instanceof mcframe.clientCore.beans.combobox.MCComboField || c instanceof mcframe.clientCore.beans.combobox.MCTextComboBox || 
/* 8227 */       c instanceof mcframe.clientCore.beans.combobox.MCNumberComboBox || c instanceof mcframe.clientCore.beans.combobox.MCDateComboBox || 
/* 8228 */       c instanceof mcframe.clientCore.beans.combobox.MCTimestampComboBox || c instanceof MCTextArea || c instanceof MCRadioButton || 
/* 8229 */       c instanceof MCCheckBox) {
/* 8230 */       return true;
/*      */     }
/* 8232 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<List<Component>> getGroupList() {
/* 8242 */     if (this._groupList == null) {
/* 8243 */       this._groupList = new ArrayList<>();
/*      */     }
/* 8245 */     return this._groupList;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canMoveComponent(List<Container> aPanelList, Component aComponent, boolean usePanel) {
/* 8259 */     if (!canMoveComponent1(aComponent, usePanel, true, false, false)) {
/* 8260 */       return false;
/*      */     }
/*      */     
/* 8263 */     if (usePanel)
/*      */     {
/* 8265 */       for (Container panel : aPanelList) {
/* 8266 */         if (panel == aComponent) {
/* 8267 */           return true;
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/* 8272 */     for (Container panel : aPanelList) {
/* 8273 */       List<Component> list = getAllComponents(panel);
/* 8274 */       if (list.contains(aComponent)) {
/* 8275 */         return true;
/*      */       }
/*      */     } 
/* 8278 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean isVisibleForMode(Component comp) {
/* 8283 */     if (comp instanceof MCLabel)
/* 8284 */       return ((MCLabel)comp).isVisibleForMode(); 
/* 8285 */     if (comp instanceof MCButton)
/* 8286 */       return ((MCButton)comp).isVisibleForMode(); 
/* 8287 */     if (comp instanceof MCField)
/* 8288 */       return ((MCField)comp).isVisibleForMode(); 
/* 8289 */     if (comp instanceof MCPasswordField)
/* 8290 */       return ((MCPasswordField)comp).isVisibleForMode(); 
/* 8291 */     if (comp instanceof MCTextArea)
/* 8292 */       return ((MCTextArea)comp).isVisibleForMode(); 
/* 8293 */     if (comp instanceof MCImageView)
/* 8294 */       return ((MCImageView)comp).isVisibleForMode(); 
/* 8295 */     if (comp instanceof MCCheckBox)
/* 8296 */       return ((MCCheckBox)comp).isVisibleForMode(); 
/* 8297 */     if (comp instanceof MCFieldComboBox)
/* 8298 */       return ((MCFieldComboBox)comp).isVisibleForMode(); 
/* 8299 */     if (comp instanceof MCRadioButton)
/* 8300 */       return ((MCRadioButton)comp).isVisibleForMode(); 
/* 8301 */     if (comp instanceof MCPanel) {
/* 8302 */       return ((MCPanel)comp).isVisibleForMode();
/*      */     }
/* 8304 */     return comp.isVisible();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isVisibleForPersonalize(Component comp) {
/* 8315 */     if (comp instanceof MCLabel)
/* 8316 */       return ((MCLabel)comp).isVisibleForPersonalize(); 
/* 8317 */     if (comp instanceof MCButton)
/* 8318 */       return ((MCButton)comp).isVisibleForPersonalize(); 
/* 8319 */     if (comp instanceof MCField)
/* 8320 */       return ((MCField)comp).isVisibleForPersonalize(); 
/* 8321 */     if (comp instanceof MCPasswordField)
/* 8322 */       return ((MCPasswordField)comp).isVisibleForPersonalize(); 
/* 8323 */     if (comp instanceof MCTextArea)
/* 8324 */       return ((MCTextArea)comp).isVisibleForPersonalize(); 
/* 8325 */     if (comp instanceof MCImageView)
/* 8326 */       return ((MCImageView)comp).isVisibleForPersonalize(); 
/* 8327 */     if (comp instanceof MCCheckBox)
/* 8328 */       return ((MCCheckBox)comp).isVisibleForPersonalize(); 
/* 8329 */     if (comp instanceof MCFieldComboBox)
/* 8330 */       return ((MCFieldComboBox)comp).isVisibleForPersonalize(); 
/* 8331 */     if (comp instanceof MCRadioButton)
/* 8332 */       return ((MCRadioButton)comp).isVisibleForPersonalize(); 
/* 8333 */     if (comp instanceof MCPanel) {
/* 8334 */       return ((MCPanel)comp).isVisibleForPersonalize();
/*      */     }
/* 8336 */     return comp.isVisible();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCRootPanel getRootPanel(Component c) {
/* 8347 */     Container p = getParentPanel1(c);
/* 8348 */     while (p != null) {
/* 8349 */       if (p instanceof MCRootPanel) {
/* 8350 */         return (MCRootPanel)p;
/*      */       }
/* 8352 */       p = p.getParent();
/*      */     } 
/* 8354 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getComponentName(Component comp, List<Component> aList) {
/* 8367 */     String str = "";
/*      */     
/* 8369 */     if (comp instanceof MCLabel) {
/* 8370 */       str = ((MCLabel)comp).getLabelByLocale();
/* 8371 */       if (MCStringUtil.isNull(str)) {
/* 8372 */         return ((MCLabel)comp).getMessageByLocale();
/*      */       }
/* 8374 */       return str;
/* 8375 */     }  if (comp instanceof MCField)
/* 8376 */       return ((MCField)comp).getMessageByLocale(); 
/* 8377 */     if (comp instanceof MCPasswordField)
/* 8378 */       return ((MCPasswordField)comp).getMessageByLocale(); 
/* 8379 */     if (comp instanceof MCFieldComboBox) {
/* 8380 */       str = ((MCFieldComboBox)comp).getLabelByLocale();
/* 8381 */       if (MCStringUtil.isNull(str)) {
/* 8382 */         return ((MCFieldComboBox)comp).getMessageByLocale();
/*      */       }
/* 8384 */       return str;
/* 8385 */     }  if (comp instanceof mcframe.clientCore.beans.combobox.MCComboField) {
/* 8386 */       MCLabel lbl = getLabel(comp.getName(), aList);
/* 8387 */       if (lbl != null) {
/* 8388 */         str = lbl.getLabelByLocale();
/* 8389 */         if (MCStringUtil.isNull(str)) {
/* 8390 */           return ((MCLabel)comp).getMessageByLocale();
/*      */         }
/* 8392 */         return str;
/*      */       } 
/*      */       
/* 8395 */       return "";
/* 8396 */     }  if (comp instanceof MCButton) {
/* 8397 */       str = ((MCButton)comp).getLabelByLocale();
/* 8398 */       if (MCStringUtil.isNull(str)) {
/* 8399 */         return ((MCButton)comp).getMessageByLocale();
/*      */       }
/* 8401 */       return str;
/* 8402 */     }  if (comp instanceof MCCheckBox) {
/* 8403 */       str = ((MCCheckBox)comp).getLabelByLocale();
/* 8404 */       if (MCStringUtil.isNull(str)) {
/* 8405 */         return ((MCCheckBox)comp).getMessageByLocale();
/*      */       }
/* 8407 */       return str;
/* 8408 */     }  if (comp instanceof MCRadioButton) {
/* 8409 */       str = ((MCRadioButton)comp).getLabelByLocale();
/* 8410 */       if (MCStringUtil.isNull(str)) {
/* 8411 */         return ((MCRadioButton)comp).getMessageByLocale();
/*      */       }
/* 8413 */       return str;
/*      */     } 
/*      */     
/* 8416 */     if (comp instanceof MCTextArea) {
/* 8417 */       str = ((MCTextArea)comp).getLabelByLocale();
/* 8418 */       if (MCStringUtil.isNull(str)) {
/* 8419 */         return ((MCTextArea)comp).getMessageByLocale();
/*      */       }
/* 8421 */       return str;
/* 8422 */     }  if (comp instanceof MCImageView) {
/* 8423 */       str = ((MCImageView)comp).getLabelByLocale();
/* 8424 */       if (MCStringUtil.isNull(str)) {
/* 8425 */         return ((MCImageView)comp).getMessageByLocale();
/*      */       }
/* 8427 */       return str;
/*      */     } 
/*      */ 
/*      */     
/* 8431 */     return "";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getComponentTypeName(Component comp) {
/* 8442 */     if (comp instanceof MCLabel)
/* 8443 */       return "Label"; 
/* 8444 */     if (comp instanceof MCButton)
/* 8445 */       return "Button"; 
/* 8446 */     if (comp instanceof mcframe.clientCore.beans.MCTextField)
/* 8447 */       return "Text Field"; 
/* 8448 */     if (comp instanceof mcframe.clientCore.beans.MCDateField)
/* 8449 */       return "Date Field"; 
/* 8450 */     if (comp instanceof mcframe.clientCore.beans.MCTimestampField)
/* 8451 */       return "Timestamp Field"; 
/* 8452 */     if (comp instanceof mcframe.clientCore.beans.MCNumberField)
/* 8453 */       return "Number Field"; 
/* 8454 */     if (comp instanceof MCPasswordField)
/* 8455 */       return "Password Field"; 
/* 8456 */     if (comp instanceof MCTextArea)
/* 8457 */       return "Text Area"; 
/* 8458 */     if (comp instanceof MCImageView)
/* 8459 */       return "Image View"; 
/* 8460 */     if (comp instanceof mcframe.clientCore.beans.combobox.MCComboField)
/* 8461 */       return "Combobox"; 
/* 8462 */     if (comp instanceof mcframe.clientCore.beans.combobox.MCTextComboBox)
/* 8463 */       return "Text Combobox"; 
/* 8464 */     if (comp instanceof mcframe.clientCore.beans.combobox.MCNumberComboBox)
/* 8465 */       return "Number Combobox"; 
/* 8466 */     if (comp instanceof mcframe.clientCore.beans.combobox.MCDateComboBox)
/* 8467 */       return "Date Combobox"; 
/* 8468 */     if (comp instanceof mcframe.clientCore.beans.combobox.MCTimestampComboBox)
/* 8469 */       return "Timestamp Combobox"; 
/* 8470 */     if (comp instanceof MCCheckBox)
/* 8471 */       return "Check Box"; 
/* 8472 */     if (comp instanceof MCRadioButton) {
/* 8473 */       return "Radio Button";
/*      */     }
/*      */     
/* 8476 */     return comp.getClass().getName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Map<String, Boolean> getSystemInvisibleInfo(MCRootPanel panel, MCTable<?> table) {
/* 8489 */     Map<String, Boolean> result = new HashMap<>();
/* 8490 */     String listKey2 = createTableListResourceKey2("System", 
/* 8491 */         panel.getModuleID(), panel.getScreenID());
/*      */     
/* 8493 */     String[] baseKeys1 = getSystemLocationResource()
/* 8494 */       .findPattern(MCResourceLayerType.SYS, MCConst.createKey(new String[] { listKey2, "*" }));
/* 8495 */     String itemKey2 = String.valueOf(listKey2) + ".item"; byte b; int i; String[] arrayOfString1;
/* 8496 */     for (i = (arrayOfString1 = baseKeys1).length, b = 0; b < i; ) { String key1 = arrayOfString1[b];
/* 8497 */       if (key1.contains(itemKey2)) {
/* 8498 */         String str = getSystemLocationResource().getString(key1);
/* 8499 */         String[] token = str.split(",");
/* 8500 */         if (token.length >= 5) {
/* 8501 */           String tableID = token[2];
/* 8502 */           if (table.getName().equals(tableID)) {
/* 8503 */             if (token.length >= 6) {
/* 8504 */               String baseColumnID = token[5];
/* 8505 */               result.put(baseColumnID, Boolean.valueOf(token[4].equals("true")));
/*      */             } else {
/*      */               
/* 8508 */               String columnID = token[3];
/* 8509 */               result.put(columnID, Boolean.valueOf(token[4].equals("true")));
/*      */             } 
/*      */           }
/*      */         } 
/*      */       } 
/*      */       b++; }
/*      */     
/*      */     MCColumnConfig[] arrayOfMCColumnConfig;
/* 8517 */     for (i = (arrayOfMCColumnConfig = table.getColumnConfigs()).length, b = 0; b < i; ) { MCColumnConfig col = arrayOfMCColumnConfig[b];
/* 8518 */       String itemid = MCBeansProxy.PROXY.createGUIKey((MCModeBeans)col);
/* 8519 */       if (MCACLManager.isInvisible(panel.getModuleID(), panel.getScreenID(), 
/* 8520 */           itemid)) {
/* 8521 */         result.put(col.getBaseTableColumnName(), Boolean.valueOf(false));
/* 8522 */         result.put(col.getName(), Boolean.valueOf(false));
/*      */       } 
/*      */       b++; }
/*      */     
/* 8526 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void checkOverrap(MCRootPanel p) {
/* 8537 */     p.debugPrint("checkOverrap");
/*      */     
/* 8539 */     boolean b = MCConfig.common.getBoolean("log.devlog_layout");
/* 8540 */     if (!b) {
/*      */       return;
/*      */     }
/* 8543 */     if (!p.isShowing()) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 8548 */     MCRootPanel rp = p.getBaseRootPanel();
/*      */ 
/*      */ 
/*      */     
/* 8552 */     boolean ok = true;
/*      */     
/* 8554 */     MCAutoLayout autoLayout = new MCAutoLayout();
/*      */     
/* 8556 */     List<Component> list = autoLayout.getAllComponents((Container)rp);
/*      */ 
/*      */     
/* 8559 */     for (int i1 = 0; i1 < list.size() - 1; i1++) {
/* 8560 */       Component c1 = list.get(i1);
/*      */       
/* 8562 */       for (int i2 = i1 + 1; i2 < list.size() - 1; i2++) {
/* 8563 */         Component c2 = list.get(i2);
/* 8564 */         if (c1 != c2)
/*      */         {
/*      */           
/* 8567 */           if (c1.isVisible() && c2.isVisible())
/*      */           {
/*      */             
/* 8570 */             if (c1.isShowing() && c2.isShowing())
/*      */             {
/*      */               
/* 8573 */               if (autoLayout.canUseComponent(c1))
/*      */               {
/*      */                 
/* 8576 */                 if (autoLayout.canUseComponent(c2)) {
/*      */ 
/*      */ 
/*      */                   
/* 8580 */                   String clsName1 = c1.getClass().getName();
/* 8581 */                   if (!isComboBoxClassName(clsName1)) {
/*      */ 
/*      */                     
/* 8584 */                     String clsName2 = c2.getClass().getName();
/* 8585 */                     if (!isComboBoxClassName(clsName2)) {
/*      */ 
/*      */ 
/*      */                       
/* 8589 */                       Point p1 = c1.getLocationOnScreen();
/* 8590 */                       Point p2 = c2.getLocationOnScreen();
/* 8591 */                       Rectangle r1 = new Rectangle(p1.x, p1.y, c1.getWidth(), c1.getHeight());
/* 8592 */                       Rectangle r2 = new Rectangle(p2.x, p2.y, c2.getWidth(), c2.getHeight());
/* 8593 */                       if (r1.intersects(r2))
/* 8594 */                       { MCRootPanel rp1 = autoLayout.getRootPanel(c1);
/* 8595 */                         MCRootPanel rp2 = autoLayout.getRootPanel(c2);
/* 8596 */                         Container pt1 = c1.getParent();
/* 8597 */                         Container pt2 = c2.getParent();
/*      */ 
/*      */                         
/* 8600 */                         printError(String.valueOf(rp1.getName()) + " " + pt1.getName() + " " + c1.getName() + " と " + rp2.getName() + " " + 
/* 8601 */                             pt2.getName() + " " + c2.getName() + " の画面配置が重なっています。 ");
/* 8602 */                         ok = false; } 
/*      */                     } 
/*      */                   } 
/*      */                 }  }  }  }  } 
/*      */       } 
/* 8607 */     }  if (ok) {
/*      */       
/* 8609 */       printError("レイアウトチェック OK : " + rp.getModuleID() + "." + rp.getScreenID());
/*      */     } else {
/*      */       
/* 8612 */       printError("レイアウトチェック NG : " + rp.getModuleID() + "." + rp.getScreenID());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void printError(String x) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void P(String x) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void repaintTopPanel(MCRootPanel p) {
/* 8635 */     if (p == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 8640 */     MCBeansUtil.pauseStatusBar(p, true);
/* 8641 */     p.validate();
/* 8642 */     p.repaint();
/* 8643 */     MCBeansUtil.pauseStatusBar(p, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getInitLocationID(String moduleID, String screenID, MCResourceLayerType type) {
/* 8657 */     String initKey = createInitResourceKey(moduleID, screenID, type);
/* 8658 */     String initID = MCStringUtil.nullToBlank(MCConst.app.getString(type, String.valueOf(initKey) + ".initLocationID"));
/* 8659 */     return initID;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static List<String> getInitLocationID(MCRootPanel panel) {
/* 8676 */     List<String> result = getInitLocationID(panel.getModuleID(), 
/* 8677 */         panel.getScreenID());
/* 8678 */     if (result != null) {
/* 8679 */       return result;
/*      */     }
/*      */     
/* 8682 */     MCPersonalizeGroupInfo info = MCBeansProxy.PROXY.getInitPersonalizeGroupInfo(panel);
/* 8683 */     if (info != null) {
/* 8684 */       String id = info.getLocationSettingID();
/* 8685 */       if (id != null) {
/* 8686 */         MCResourceLayerType[] types = {
/* 8687 */             MCResourceLayerType.USER, MCResourceLayerType.EXT, 
/* 8688 */             MCResourceLayerType.SYS }; byte b; int i;
/*      */         MCResourceLayerType[] arrayOfMCResourceLayerType1;
/* 8690 */         for (i = (arrayOfMCResourceLayerType1 = types).length, b = 0; b < i; ) { MCResourceLayerType type = arrayOfMCResourceLayerType1[b];
/* 8691 */           String initKey = createInitResourceKey(panel.getModuleID(), 
/* 8692 */               panel.getScreenID(), type);
/* 8693 */           result = getInitLocationID(type, initKey, id);
/* 8694 */           if (result != null) {
/* 8695 */             return result;
/*      */           }
/*      */           b++; }
/*      */       
/*      */       } 
/*      */     } 
/* 8701 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static List<String> getInitLocationID(String moduleID, String screenID) {
/* 8713 */     MCResourceLayerType[] types = {
/* 8714 */         MCResourceLayerType.USER, MCResourceLayerType.EXT, MCResourceLayerType.SYS }; byte b; int i;
/*      */     MCResourceLayerType[] arrayOfMCResourceLayerType1;
/* 8716 */     for (i = (arrayOfMCResourceLayerType1 = types).length, b = 0; b < i; ) { MCResourceLayerType type = arrayOfMCResourceLayerType1[b];
/* 8717 */       String initKey = createInitResourceKey(moduleID, screenID, type);
/* 8718 */       String initID = MCStringUtil.nullToBlank(
/* 8719 */           MCConst.app.getString(type, String.valueOf(initKey) + ".initLocationID"));
/* 8720 */       if (initID.length() > 0) {
/* 8721 */         List<String> result = getInitLocationID(type, initKey, initID);
/* 8722 */         if (result != null)
/* 8723 */           return result; 
/*      */       } 
/*      */       b++; }
/*      */     
/* 8727 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   private static List<String> getInitLocationID(MCResourceLayerType type, String initKey, String initID) {
/* 8732 */     String _initID = MCStringUtil.nullToBlank(
/* 8733 */         MCConst.app.getString(type, String.valueOf(initKey) + ".list." + initID + ".locationID"));
/*      */     
/* 8735 */     if (_initID.length() > 0) {
/* 8736 */       String initNM = MCStringUtil.nullToBlank(MCConst.app.getString(type, 
/* 8737 */             String.valueOf(initKey) + ".list." + initID + ".locationNM"));
/*      */       
/* 8739 */       ArrayList<String> result = new ArrayList<>();
/* 8740 */       result.add(initID);
/* 8741 */       result.add(initNM);
/* 8742 */       result.add(type.toString());
/* 8743 */       return result;
/*      */     } 
/* 8745 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8751 */   private static String system_location_dir = "./system_location";
/*      */   
/*      */   protected static final String base = "MCSystemLocation";
/*      */   
/*      */   protected static final String project = "RT";
/*      */   private static MCCustomResource _customResource;
/*      */   
/*      */   public static String getSystem_location_dir() {
/* 8759 */     return system_location_dir;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setSystem_location_dir(String system_location_dir) {
/* 8768 */     MCAutoLayout.system_location_dir = system_location_dir;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void convertResourceToFile() {
/* 8782 */     String path = MCConst.plugin.getString("system_location.screenshot_dir", system_location_dir);
/* 8783 */     String path2 = (new File(path)).getAbsolutePath();
/*      */ 
/*      */ 
/*      */     
/* 8787 */     Locale locale = Locale.getDefault();
/*      */     
/* 8789 */     MCCustomResource saver = new MCCustomResource("MCSystemLocation");
/* 8790 */     loadSystemLocation(saver);
/* 8791 */     saver.saveUser(path2, "RT", locale);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static MCCustomResource getCustomResource() {
/* 8807 */     return _customResource;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void loadResource() {
/* 8824 */     if (_customResource != null) {
/*      */       return;
/*      */     }
/*      */     
/* 8828 */     String path = MCConst.plugin.getString("system_location.screenshot_dir", system_location_dir);
/* 8829 */     String path2 = (new File(path)).getAbsolutePath();
/*      */ 
/*      */ 
/*      */     
/* 8833 */     Locale locale = Locale.getDefault();
/*      */     
/* 8835 */     _customResource = new MCCustomResource("MCSystemLocation");
/* 8836 */     _customResource.loadUser(path2, "RT", locale);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void loadSystemLocation(MCCustomResource saveResource)
/*      */   {
/* 8844 */     MCResourceLayerType type = MCResourceLayerType.SYS;
/* 8845 */     MCGeneralPersonalizeResource resource = getSystemLocationResource();
/*      */     
/* 8847 */     String key1 = "system_location2";
/* 8848 */     String[] baseKeys2 = resource.findPattern(type, MCConst.createKey(new String[] { key1, "*" })); byte b; int i; String[] arrayOfString1;
/* 8849 */     for (i = (arrayOfString1 = baseKeys2).length, b = 0; b < i; ) { String key2 = arrayOfString1[b];
/* 8850 */       String[] baseKeys3 = resource.findPattern(type, MCConst.createKey(new String[] { key2, "*" })); byte b1; int j; String[] arrayOfString2;
/* 8851 */       for (j = (arrayOfString2 = baseKeys3).length, b1 = 0; b1 < j; ) { String key3 = arrayOfString2[b1];
/* 8852 */         String[] baseKeys4 = resource.findPattern(type, MCConst.createKey(new String[] { key3, "*" })); byte b2; int k; String[] arrayOfString3;
/* 8853 */         for (k = (arrayOfString3 = baseKeys4).length, b2 = 0; b2 < k; ) { String key4 = arrayOfString3[b2];
/* 8854 */           String[] baseKeys5 = resource.findPattern(type, MCConst.createKey(new String[] { key4, "*" })); byte b3; int m; String[] arrayOfString4;
/* 8855 */           for (m = (arrayOfString4 = baseKeys5).length, b3 = 0; b3 < m; ) { String key5 = arrayOfString4[b3];
/* 8856 */             String[] baseKeys6 = resource.findPattern(type, MCConst.createKey(new String[] { key5, "*" })); byte b4; int n; String[] arrayOfString5;
/* 8857 */             for (n = (arrayOfString5 = baseKeys6).length, b4 = 0; b4 < n; ) { String key6 = arrayOfString5[b4];
/* 8858 */               String str = resource.getString(key6);
/* 8859 */               saveResource.setString(key6, str); b4++; }
/*      */             
/*      */             b3++; }
/*      */           
/*      */           b2++; }
/*      */         
/*      */         b1++; }
/*      */       
/*      */       b++; }
/* 8868 */      } protected int getSpacerWidth2() { return 10; }
/*      */ 
/*      */   
/*      */   protected int getSpacerWidth4() {
/* 8872 */     return 5;
/*      */   }
/*      */   
/*      */   protected int getSpacerWidth5() {
/* 8876 */     return 5;
/*      */   }
/*      */   
/*      */   protected int getTopOffsetY() {
/* 8880 */     return 7;
/*      */   }
/*      */   
/*      */   protected int getButtonPanelHeight() {
/* 8884 */     return 21;
/*      */   }
/*      */   
/*      */   protected int getMinStepY3() {
/* 8888 */     return 44;
/*      */   }
/*      */   
/*      */   protected int getMinStepY4() {
/* 8892 */     return 23;
/*      */   }
/*      */   
/*      */   protected int getBottomTableOffsetY() {
/* 8896 */     return 15;
/*      */   }
/*      */   
/*      */   protected int getTabHeight() {
/* 8900 */     return 39;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   protected int getEmbeddedOffset() {
/* 8905 */     return 3;
/*      */   }
/*      */   
/*      */   protected int getTitledBorderOffset() {
/* 8909 */     return 31;
/*      */   }
/*      */   
/*      */   protected int getLineGridOffset() {
/* 8913 */     return 3;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean _isFitPanel(Container p) {
/* 8924 */     if (this._fitPanelList == null) {
/* 8925 */       if (p instanceof MCResourceBeans) {
/* 8926 */         boolean bool = MCBeansUtil.getFit((MCResourceBeans)p);
/* 8927 */         return bool;
/*      */       } 
/* 8929 */       return false;
/*      */     } 
/*      */     
/* 8932 */     boolean b = this._fitPanelList.contains(p);
/* 8933 */     return b;
/*      */   }
/*      */ 
/*      */   
/*      */   protected void mergeFitPanel(Map<String, MCLayoutPanelR> map1) {
/* 8938 */     if (this._fitPanelList != null && map1.size() > 0) {
/* 8939 */       for (Container p : this._panelList) {
/* 8940 */         MCLayoutPanelR findR = getPanelR(p, map1);
/* 8941 */         if (findR != null && 
/* 8942 */           nullToBoolean(findR.localeFit()) && 
/* 8943 */           !this._fitPanelList.contains(p)) {
/* 8944 */           this._fitPanelList.add(p);
/*      */         }
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean useScrollButton(MCRootPanel rp) {
/* 8959 */     MCLayoutSettingsR r = getPersonalizeSettings(rp);
/* 8960 */     if (r == null) {
/* 8961 */       return false;
/*      */     }
/* 8963 */     Boolean b = r.useScrollButton();
/* 8964 */     if (b == null) {
/* 8965 */       return false;
/*      */     }
/* 8967 */     return b.booleanValue();
/*      */   }
/*      */ 
/*      */   
/*      */   protected void initTabbedPane() {
/* 8972 */     boolean useScrollButton = useScrollButton(this._targetPanel);
/* 8973 */     if (useScrollButton) {
/* 8974 */       MCTabbedPane[] tlist = (MCTabbedPane[])MCBeansUtil.getAllComponents(MCTabbedPane.class, (Container)this._targetPanel); byte b; int i; MCTabbedPane[] arrayOfMCTabbedPane1;
/* 8975 */       for (i = (arrayOfMCTabbedPane1 = tlist).length, b = 0; b < i; ) { MCTabbedPane tabbedPane = arrayOfMCTabbedPane1[b];
/* 8976 */         tabbedPane.setTabLayoutPolicy(1);
/*      */         b++; }
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean useScrollPane(MCRootPanel rp) {
/* 8988 */     MCLayoutSettingsR r = getPersonalizeSettings(rp);
/* 8989 */     if (r == null) {
/* 8990 */       return false;
/*      */     }
/* 8992 */     Boolean b = r.useScrollPane();
/* 8993 */     if (b == null) {
/* 8994 */       return false;
/*      */     }
/* 8996 */     return b.booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean usePrefSize(MCRootPanel rp) {
/* 9006 */     MCLayoutSettingsR r = getPersonalizeSettings(rp);
/* 9007 */     if (r == null) {
/* 9008 */       return false;
/*      */     }
/* 9010 */     Boolean b = r.usePrefSize();
/* 9011 */     if (b == null) {
/* 9012 */       return false;
/*      */     }
/* 9014 */     return b.booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean useAdjustHeight(MCRootPanel rp) {
/* 9024 */     MCLayoutSettingsR r = getPersonalizeSettings(rp);
/* 9025 */     if (r == null) {
/* 9026 */       return false;
/*      */     }
/* 9028 */     Boolean b = r.useAdjustHeight();
/* 9029 */     if (b == null) {
/* 9030 */       return false;
/*      */     }
/* 9032 */     return b.booleanValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Integer panelPrefWidth(MCRootPanel rp) {
/* 9043 */     MCLayoutSettingsR r = getPersonalizeSettings(rp);
/* 9044 */     if (r == null) {
/* 9045 */       return null;
/*      */     }
/* 9047 */     Integer w = r.panelPrefWidth();
/* 9048 */     return w;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Integer panelPrefHeight(MCRootPanel rp) {
/* 9058 */     MCLayoutSettingsR r = getPersonalizeSettings(rp);
/* 9059 */     if (r == null) {
/* 9060 */       return null;
/*      */     }
/* 9062 */     Integer h = r.panelPrefHeight();
/* 9063 */     return h;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getMinPreferredWidth(MCRootPanel rootPanel) {
/* 9070 */     int width = 0;
/* 9071 */     for (Container p : getPanelList()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 9078 */       boolean hasTablePanel = hasTablePanel(p);
/* 9079 */       if (hasTablePanel) {
/*      */         continue;
/*      */       }
/* 9082 */       int x = _getXOnRootPanel(p, rootPanel);
/* 9083 */       int w = (p.getPreferredSize()).width;
/*      */ 
/*      */       
/* 9086 */       if (p instanceof MCPanel) {
/* 9087 */         Integer right = ((MCPanel)p)._getMaxPrefRight();
/* 9088 */         if (right != null) {
/* 9089 */           w = right.intValue();
/*      */         }
/*      */       } 
/*      */       
/* 9093 */       width = Math.max(width, x + w);
/*      */     } 
/*      */     
/* 9096 */     return width;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getMinPreferredHeight(MCRootPanel rootPanel) {
/* 9103 */     MCPanel center = null;
/* 9104 */     for (Container p : getPanelList()) {
/* 9105 */       if (p instanceof MCPanel && "_layouter_3".equals(p.getParent().getName()) && 
/* 9106 */         p.getParent().getParent().getParent().getParent() == ((MCPanel)p).getBaseRootPanel())
/*      */       {
/* 9108 */         if ("C".equals(((MCPanel)p).getLayoutPosition())) {
/* 9109 */           center = (MCPanel)p;
/*      */           
/*      */           break;
/*      */         } 
/*      */       }
/*      */     } 
/* 9115 */     if (center == null) {
/* 9116 */       return 0;
/*      */     }
/*      */ 
/*      */     
/* 9120 */     boolean hasTablePanel = hasTablePanel((Container)center);
/* 9121 */     if (hasTablePanel) {
/* 9122 */       return 0;
/*      */     }
/*      */     
/* 9125 */     int h1 = (center.getPreferredSize()).height;
/* 9126 */     int h2 = (center.getSize()).height;
/* 9127 */     if (h1 > h2) {
/* 9128 */       return h1;
/*      */     }
/* 9130 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   private int _getXOnRootPanel(Container c, MCRootPanel rp) {
/* 9135 */     int pt2x = c.getX();
/* 9136 */     Container c2 = c.getParent();
/* 9137 */     while (c2 != null && c2 != rp && 
/* 9138 */       rp != c2.getParent()) {
/*      */ 
/*      */       
/* 9141 */       pt2x += c2.getX();
/* 9142 */       c2 = c2.getParent();
/*      */     } 
/* 9144 */     return pt2x;
/*      */   }
/*      */ 
/*      */   
/*      */   private int _getYOnRootPanel(Container c, MCRootPanel rp) {
/* 9149 */     int pt2y = c.getY();
/* 9150 */     Container c2 = c.getParent();
/* 9151 */     while (c2 != null && c2 != rp && 
/* 9152 */       rp != c2.getParent()) {
/*      */ 
/*      */       
/* 9155 */       pt2y += c2.getY();
/* 9156 */       c2 = c2.getParent();
/*      */     } 
/* 9158 */     return pt2y;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean hasTablePanel(Container comp) {
/* 9163 */     if ((comp.getComponents()).length == 1 && comp.getComponents()[0] instanceof MCScrollPane) {
/* 9164 */       MCScrollPane sc = (MCScrollPane)comp.getComponents()[0];
/* 9165 */       Component c = sc.getViewport().getView();
/* 9166 */       if (c instanceof MCTable) {
/* 9167 */         return true;
/*      */       }
/*      */     } 
/* 9170 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void initTablePanel() {
/* 9176 */     char sp_l = "L".charAt(0);
/* 9177 */     char sp_r = "R".charAt(0);
/*      */     
/* 9179 */     for (Container p : getPanelList()) {
/*      */       
/* 9181 */       boolean hasTablePanel = hasTablePanel(p);
/* 9182 */       if (hasTablePanel) {
/* 9183 */         boolean isZeroWidth = false;
/* 9184 */         if (p instanceof MCPanel && p.getParent() instanceof MCPanel) {
/* 9185 */           MCPanel p1 = (MCPanel)p;
/* 9186 */           MCPanel p2 = (MCPanel)p.getParent();
/* 9187 */           String lp1 = p1.getLayoutPosition();
/* 9188 */           String lp2 = p2.getLayoutPosition();
/* 9189 */           if (lp2 != null) {
/*      */             
/* 9191 */             int count = 0;
/* 9192 */             for (int i = 0; i < lp1.length(); i++) {
/* 9193 */               if (lp1.charAt(i) == sp_l || lp1.charAt(i) == sp_r) {
/* 9194 */                 count++;
/*      */               }
/*      */             } 
/* 9197 */             if (count <= 1)
/*      */             {
/*      */               
/* 9200 */               if (lp2.contains("R")) {
/* 9201 */                 isZeroWidth = true;
/*      */               }
/*      */             }
/*      */           } 
/*      */         } 
/*      */         
/* 9207 */         if (isZeroWidth) {
/*      */ 
/*      */           
/* 9210 */           Dimension d = p.getPreferredSize();
/* 9211 */           p.setPreferredSize(new Dimension(0, d.height));
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\layout\MCAutoLayout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */