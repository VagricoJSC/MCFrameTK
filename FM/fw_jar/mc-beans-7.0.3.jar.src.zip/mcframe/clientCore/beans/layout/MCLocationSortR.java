/*     */ package mcframe.clientCore.beans.layout;
/*     */ 
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCLocationSortR
/*     */ {
/*     */   protected String componentID;
/*     */   protected int sequence;
/*     */   protected String prevComponentID;
/*     */   
/*     */   public int sequence() {
/*  34 */     return this.sequence;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sequence(int intValue) {
/*  42 */     this.sequence = intValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sequence(MCNumber number) {
/*  50 */     if (number == null) {
/*  51 */       this.sequence = 0;
/*     */     } else {
/*     */       
/*  54 */       this.sequence = number.intValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String componentID() {
/*  63 */     return this.componentID;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void componentID(String string) {
/*  71 */     this.componentID = string;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String prevComponentID() {
/*  79 */     return this.prevComponentID;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void prevComponentID(String string) {
/*  87 */     this.prevComponentID = string;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCLocationSortR clone() {
/*  94 */     MCLocationSortR clone = new MCLocationSortR();
/*  95 */     clone.componentID = componentID();
/*  96 */     clone.sequence = sequence();
/*  97 */     clone.prevComponentID = prevComponentID();
/*  98 */     return clone;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 103 */     return MCStringUtil.join(",", new String[] { Integer.toString(this.sequence), this.componentID, 
/* 104 */           this.prevComponentID });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equalsID(MCLocationSortR r) {
/* 113 */     if (!MCStringUtil.nullToBlank(r.componentID()).equals(MCStringUtil.nullToBlank(componentID()))) {
/* 114 */       return false;
/*     */     }
/*     */     
/* 117 */     if (!MCStringUtil.nullToBlank(r.prevComponentID()).equals(MCStringUtil.nullToBlank(prevComponentID()))) {
/* 118 */       return false;
/*     */     }
/* 120 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String fullComponentID() {
/* 128 */     return this.componentID;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\layout\MCLocationSortR.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */