/*     */ package mcframe.clientCore.beans.layout;
/*     */ 
/*     */ public final class MCAutoLayoutParam
/*     */ {
/*     */   private boolean useLayoutDebugMode = false;
/*     */   private boolean useAutoLayout = false;
/*     */   private boolean useGrid = true;
/*   8 */   private int gridSize = 10;
/*   9 */   private int spaceLabelAndField = 10;
/*  10 */   private int spaceButtonAndButton = 5;
/*     */   
/*     */   private boolean useAlignRight = false;
/*     */   private boolean useCR = false;
/*     */   private boolean useUpdateLabelSize = true;
/*     */   private boolean useFitLabelSize = true;
/*     */   private boolean useAlignNoLabelField = true;
/*     */   private boolean useAlignLabelLocation = false;
/*     */   private boolean useFloorGrid = false;
/*  19 */   private int lineGrid = 24;
/*     */   
/*     */   private boolean useInvisibleForMode = true;
/*     */   
/*     */   private boolean useCompressPanel = true;
/*     */   private boolean useUpdateTabOrder = false;
/*     */   private boolean useDebugPanel = false;
/*  26 */   private Integer panelWidth = null;
/*  27 */   private Integer panelHeight = null;
/*  28 */   private Integer screenWidth = null;
/*  29 */   private Integer screenHeight = null;
/*  30 */   private Integer panelPrefWidth = null;
/*  31 */   private Integer panelPrefHeight = null;
/*     */   
/*  33 */   private static final MCAutoLayoutParam AUTO_LAYOUT_PARAM = new MCAutoLayoutParam();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static MCAutoLayoutParam getAutoLayoutParam() {
/*  40 */     return AUTO_LAYOUT_PARAM;
/*     */   }
/*     */   
/*     */   public static boolean isUseLayoutDebugMode() {
/*  44 */     return (getAutoLayoutParam()).useLayoutDebugMode;
/*     */   }
/*     */   
/*     */   public static void setUseLayoutDebugMode(boolean useLayoutDebugMode) {
/*  48 */     (getAutoLayoutParam()).useLayoutDebugMode = useLayoutDebugMode;
/*     */   }
/*     */   
/*     */   public static boolean isUseAutoLayout() {
/*  52 */     return (getAutoLayoutParam()).useAutoLayout;
/*     */   }
/*     */   
/*     */   public static void setUseAutoLayout(boolean useAutoLayout) {
/*  56 */     (getAutoLayoutParam()).useAutoLayout = useAutoLayout;
/*     */   }
/*     */   
/*     */   public static boolean isUseGrid() {
/*  60 */     return (getAutoLayoutParam()).useGrid;
/*     */   }
/*     */   
/*     */   public static void setUseGrid(boolean useGrid) {
/*  64 */     (getAutoLayoutParam()).useGrid = useGrid;
/*     */   }
/*     */   
/*     */   public static boolean isUseAlignRight() {
/*  68 */     return (getAutoLayoutParam()).useAlignRight;
/*     */   }
/*     */   
/*     */   public static void setUseAlignRight(boolean useAlignRight) {
/*  72 */     (getAutoLayoutParam()).useAlignRight = useAlignRight;
/*     */   }
/*     */   
/*     */   public static boolean isUseCR() {
/*  76 */     return (getAutoLayoutParam()).useCR;
/*     */   }
/*     */   
/*     */   public static void setUseCR(boolean useCR) {
/*  80 */     (getAutoLayoutParam()).useCR = useCR;
/*     */   }
/*     */   
/*     */   public static boolean isUseUpdateLabelSize() {
/*  84 */     return (getAutoLayoutParam()).useUpdateLabelSize;
/*     */   }
/*     */   
/*     */   public static void setUseUpdateLabelSize(boolean useUpdateLabelSize) {
/*  88 */     (getAutoLayoutParam()).useUpdateLabelSize = useUpdateLabelSize;
/*     */   }
/*     */   
/*     */   public static boolean isUseFitLabelSize() {
/*  92 */     return (getAutoLayoutParam()).useFitLabelSize;
/*     */   }
/*     */   
/*     */   public static void setUseFitLabelSize(boolean useFitLabelSize) {
/*  96 */     (getAutoLayoutParam()).useFitLabelSize = useFitLabelSize;
/*     */   }
/*     */   
/*     */   public static boolean isUseAlignNoLabelField() {
/* 100 */     return (getAutoLayoutParam()).useAlignNoLabelField;
/*     */   }
/*     */   
/*     */   public static void setUseAlignNoLabelField(boolean useAlignNoLabelField) {
/* 104 */     (getAutoLayoutParam()).useAlignNoLabelField = useAlignNoLabelField;
/*     */   }
/*     */   
/*     */   public static boolean isUseAlignLabelLocation() {
/* 108 */     return (getAutoLayoutParam()).useAlignLabelLocation;
/*     */   }
/*     */   
/*     */   public static void setUseAlignLabelLocation(boolean useAlignLabelLocation) {
/* 112 */     (getAutoLayoutParam()).useAlignLabelLocation = useAlignLabelLocation;
/*     */   }
/*     */   
/*     */   public static boolean isUseFloorGrid() {
/* 116 */     return (getAutoLayoutParam()).useFloorGrid;
/*     */   }
/*     */   
/*     */   public static void setUseFloorGrid(boolean useFloorGrid) {
/* 120 */     (getAutoLayoutParam()).useFloorGrid = useFloorGrid;
/*     */   }
/*     */   
/*     */   public static boolean isUseInvisibleForMode() {
/* 124 */     return (getAutoLayoutParam()).useInvisibleForMode;
/*     */   }
/*     */   
/*     */   public static void setUseInvisibleForMode(boolean useInvisibleForMode) {
/* 128 */     (getAutoLayoutParam()).useInvisibleForMode = useInvisibleForMode;
/*     */   }
/*     */   
/*     */   public static boolean isUseCompressPanel() {
/* 132 */     return (getAutoLayoutParam()).useCompressPanel;
/*     */   }
/*     */   
/*     */   public static void setUseCompressPanel(boolean useCompressPanel) {
/* 136 */     (getAutoLayoutParam()).useCompressPanel = useCompressPanel;
/*     */   }
/*     */   
/*     */   public static boolean isUseUpdateTabOrder() {
/* 140 */     return (getAutoLayoutParam()).useUpdateTabOrder;
/*     */   }
/*     */   
/*     */   public static void setUseUpdateTabOrder(boolean useUpdateTabOrder) {
/* 144 */     (getAutoLayoutParam()).useUpdateTabOrder = useUpdateTabOrder;
/*     */   }
/*     */   
/*     */   public static boolean isUseDebugPanel() {
/* 148 */     return (getAutoLayoutParam()).useDebugPanel;
/*     */   }
/*     */   
/*     */   public static void setUseDebugPanel(boolean useDebugPanel) {
/* 152 */     (getAutoLayoutParam()).useDebugPanel = useDebugPanel;
/*     */   }
/*     */ 
/*     */   
/*     */   public static int getGridSize() {
/* 157 */     return (getAutoLayoutParam()).gridSize;
/*     */   }
/*     */   
/*     */   public static void setGridSize(int gridSize) {
/* 161 */     (getAutoLayoutParam()).gridSize = gridSize;
/*     */   }
/*     */   
/*     */   public static int getSpaceLabelAndField() {
/* 165 */     return (getAutoLayoutParam()).spaceLabelAndField;
/*     */   }
/*     */   
/*     */   public static void setSpaceLabelAndField(int spaceLabelAndField) {
/* 169 */     (getAutoLayoutParam()).spaceLabelAndField = spaceLabelAndField;
/*     */   }
/*     */   
/*     */   public static int getSpaceButtonAndButton() {
/* 173 */     return (getAutoLayoutParam()).spaceButtonAndButton;
/*     */   }
/*     */   
/*     */   public static void setSpaceButtonAndButton(int spaceButtonAndButton) {
/* 177 */     (getAutoLayoutParam()).spaceButtonAndButton = spaceButtonAndButton;
/*     */   }
/*     */   
/*     */   public static int getLineGrid() {
/* 181 */     return (getAutoLayoutParam()).lineGrid;
/*     */   }
/*     */   
/*     */   public static void setLineGrid(int lineGrid) {
/* 185 */     (getAutoLayoutParam()).lineGrid = lineGrid;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Integer getScreenWidth() {
/* 190 */     return (getAutoLayoutParam()).screenWidth;
/*     */   }
/*     */   public static void setScreenWidth(Integer screenWidth) {
/* 193 */     (getAutoLayoutParam()).screenWidth = screenWidth;
/*     */   }
/*     */   
/*     */   public static Integer getScreenHeight() {
/* 197 */     return (getAutoLayoutParam()).screenHeight;
/*     */   }
/*     */   public static void setScreenHeight(Integer screenHeight) {
/* 200 */     (getAutoLayoutParam()).screenHeight = screenHeight;
/*     */   }
/*     */   
/*     */   public static Integer getPanelWidth() {
/* 204 */     return (getAutoLayoutParam()).panelWidth;
/*     */   }
/*     */   public static void setPanelWidth(Integer panelWidth) {
/* 207 */     (getAutoLayoutParam()).panelWidth = panelWidth;
/*     */   }
/*     */   
/*     */   public static Integer getPanelHeight() {
/* 211 */     return (getAutoLayoutParam()).panelHeight;
/*     */   }
/*     */   
/*     */   public static void setPanelHeight(Integer panelHeight) {
/* 215 */     (getAutoLayoutParam()).panelHeight = panelHeight;
/*     */   }
/*     */   
/*     */   public static Integer getPanelPrefHeight() {
/* 219 */     return (getAutoLayoutParam()).panelPrefHeight;
/*     */   }
/*     */   
/*     */   public static void setPanelPrefHeight(Integer panelPrefHeight) {
/* 223 */     (getAutoLayoutParam()).panelPrefHeight = panelPrefHeight;
/*     */   }
/*     */   
/*     */   public static Integer getPanelPrefWidth() {
/* 227 */     return (getAutoLayoutParam()).panelPrefWidth;
/*     */   }
/*     */   
/*     */   public static void setPanelPrefWidth(Integer panelPrefWidth) {
/* 231 */     (getAutoLayoutParam()).panelPrefWidth = panelPrefWidth;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\layout\MCAutoLayoutParam.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */