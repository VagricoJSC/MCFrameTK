/*    */ package mcframe.clientCore.beans.layout;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCLayoutColumnR
/*    */ {
/*    */   public String tableID;
/*    */   public String columnID;
/*    */   public String panelID;
/*    */   public String rootPanelID;
/*    */   public boolean isVisible;
/*    */   
/*    */   public String panelID() {
/* 15 */     if (this.panelID == null) {
/* 16 */       return "";
/*    */     }
/* 18 */     return this.panelID;
/*    */   }
/*    */   
/*    */   public void panelID(String string) {
/* 22 */     this.panelID = string;
/*    */   }
/*    */   
/*    */   public String rootPanelID() {
/* 26 */     if (this.rootPanelID == null) {
/* 27 */       return "";
/*    */     }
/* 29 */     return this.rootPanelID;
/*    */   }
/*    */   
/*    */   public void rootPanelID(String string) {
/* 33 */     this.rootPanelID = string;
/*    */   }
/*    */   
/*    */   public String tableID() {
/* 37 */     return this.tableID;
/*    */   }
/*    */   
/*    */   public void tableID(String string) {
/* 41 */     this.tableID = string;
/*    */   }
/*    */   
/*    */   public String columnID() {
/* 45 */     return this.columnID;
/*    */   }
/*    */   
/*    */   public void columnID(String string) {
/* 49 */     this.columnID = string;
/*    */   }
/*    */   
/*    */   public boolean isVisible() {
/* 53 */     return this.isVisible;
/*    */   }
/*    */   
/*    */   public void isVisible(boolean f) {
/* 57 */     this.isVisible = f;
/*    */   }
/*    */ 
/*    */   
/*    */   public MCLayoutColumnR clone() {
/* 62 */     MCLayoutColumnR clone = new MCLayoutColumnR();
/* 63 */     clone.tableID = tableID();
/* 64 */     clone.columnID = columnID();
/* 65 */     clone.isVisible = isVisible();
/* 66 */     clone.panelID = panelID();
/* 67 */     clone.rootPanelID = rootPanelID();
/* 68 */     return clone;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 73 */     return this.tableID + "," + this.columnID + "," + this.isVisible + "," + this.panelID + "," + 
/* 74 */       this.rootPanelID;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equalsID(MCLayoutColumnR r) {
/* 79 */     if (!r.tableID().equals(tableID())) {
/* 80 */       return false;
/*    */     }
/* 82 */     if (!r.columnID().equals(columnID())) {
/* 83 */       return false;
/*    */     }
/* 85 */     if (!r.panelID().equals(panelID())) {
/* 86 */       return false;
/*    */     }
/* 88 */     if (!r.rootPanelID().equals(rootPanelID())) {
/* 89 */       return false;
/*    */     }
/* 91 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\layout\MCLayoutColumnR.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */