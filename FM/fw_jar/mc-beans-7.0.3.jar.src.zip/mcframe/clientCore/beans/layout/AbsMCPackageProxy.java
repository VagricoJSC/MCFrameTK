/*    */ package mcframe.clientCore.beans.layout;
/*    */ 
/*    */ import java.awt.Rectangle;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import mcframe.clientCore.beans.MCResourceBeans;
/*    */ import mcframe.clientCore.beans.MCRootPanel;
/*    */ import mcframe.clientCore.beans.statusbar.MCStatusBar;
/*    */ import mcframe.clientCore.beans.table.MCTable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbsMCPackageProxy
/*    */ {
/*    */   protected Rectangle layout(MCResourceBeans compo, Rectangle rect) {
/* 25 */     MCHeaderLayoutInfo info = new MCHeaderLayoutInfo();
/* 26 */     info.setComponent(compo);
/* 27 */     info.setBounds(rect.x, rect.y, rect.width, rect.height);
/* 28 */     return MCHeaderLayout.getInstance().layout(info);
/*    */   }
/*    */   
/*    */   protected void setStatusBar(MCGeneralLayout g, MCStatusBar b) {
/* 32 */     g._statusBar = b;
/*    */   }
/*    */   
/*    */   protected MCStatusBar getStatusBar(MCGeneralLayout g) {
/* 36 */     return g._statusBar;
/*    */   }
/*    */   
/*    */   protected void setMessageToStatusBar(MCGeneralLayout g, String msg) {
/* 40 */     if (g._statusBar != null) {
/* 41 */       g._statusBar.setText(msg);
/*    */     }
/*    */   }
/*    */   
/*    */   protected void repaintPushCnt(MCGeneralLayout g) {
/* 46 */     g.repaintPushCnt();
/*    */   }
/*    */   
/*    */   protected boolean getInitFlg(MCGeneralLayout g) {
/* 50 */     return g.getInitFlg();
/*    */   }
/*    */   
/*    */   protected Map<String, Boolean> getSystemInvisibleInfo(MCAutoLayout layout, MCTable<?> table) {
/* 54 */     return layout.getSystemInvisibleInfo(table.getBaseRootPanel(), table);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected List<String> getInitLocationID(MCRootPanel panel) {
/* 63 */     return MCAutoLayout.getInitLocationID(panel);
/*    */   }
/*    */   
/*    */   protected boolean isNotZoom(MCGeneralLayout g) {
/* 67 */     return g.isNotZoom();
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\layout\AbsMCPackageProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */