/*     */ package mcframe.clientCore.beans.layout;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.concurrent.Semaphore;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import javafx.application.Platform;
/*     */ import javafx.stage.Screen;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.FontUIResource;
/*     */ import mcframe.clientCore.beans.MCBeans;
/*     */ import mcframe.clientCore.beans.MCFileChooser;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.popup.MCPopupMenu;
/*     */ import mcframe.clientCore.beans.table.MCColumnGroupTableHeader;
/*     */ import mcframe.clientCore.beans.table.MCLayoutTableHeader;
/*     */ import mcframe.clientCore.beans.table.MCTable2Header;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.resource.ctrl.MCResource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCHiresoManager
/*     */ {
/*  43 */   private static Integer _default = null;
/*     */   
/*  45 */   private static Double _dpi = null;
/*  46 */   private static Dimension _resolution = null;
/*  47 */   private static double _dpiScale = 1.5D;
/*  48 */   private static double _displaySize = 15.0D;
/*     */   
/*  50 */   private static Dimension _minResolution = new Dimension(1920, 1080);
/*     */ 
/*     */   
/*  53 */   private static Dimension _maxFrameSize = new Dimension(1360, 768);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int _font_rate_100 = 100;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getFontRatio() {
/*  67 */     initFontRatio();
/*  68 */     return _default.intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int initFontRatio() {
/*  78 */     _default = Integer.valueOf(_getFontRatio());
/*  79 */     return _default.intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected static int _getFontRatio() {
/*  85 */     if (!isEnableHighResolution()) {
/*  86 */       return 100;
/*     */     }
/*     */     
/*  89 */     String mode = getMode();
/*  90 */     if ("dot".equals(mode)) {
/*  91 */       Integer r = _getDefaultFontRatio();
/*  92 */       if (r == null) {
/*  93 */         return 100;
/*     */       }
/*  95 */       return r.intValue();
/*  96 */     }  if ("dpi".equals(mode)) {
/*  97 */       if (_resolution == null) {
/*  98 */         _getWinodwsDpi();
/*     */       }
/* 100 */       if (_resolution == null) {
/* 101 */         return 100;
/*     */       }
/* 103 */       Integer res_dpi = _getResourceDpi();
/* 104 */       if (res_dpi == null || res_dpi.intValue() == 0) {
/* 105 */         return 100;
/*     */       }
/* 107 */       if (_dpi == null) {
/* 108 */         return 100;
/*     */       }
/*     */ 
/*     */       
/* 112 */       int ratio = 100;
/* 113 */       if (_resolution.width <= _minResolution.width && _resolution.height <= _minResolution.height)
/* 114 */         return 100; 
/* 115 */       if (_dpi.doubleValue() > 108.0D) {
/* 116 */         ratio = (int)(_dpi.doubleValue() * 100.0D / res_dpi.intValue() * _dpiScale);
/*     */         
/* 118 */         Dimension d = new Dimension(_maxFrameSize.width * ratio / 100, _maxFrameSize.height * ratio / 100);
/* 119 */         if (_resolution.width < d.width || _resolution.height < d.height) {
/* 120 */           double s = Math.min(d.width / _resolution.width, d.height / _resolution.height);
/* 121 */           ratio = (int)(ratio * s);
/*     */         } 
/*     */         
/* 124 */         return ratio;
/*     */       } 
/* 126 */       return 100;
/* 127 */     }  if ("resolution".equals(mode)) {
/*     */       
/* 129 */       if (_resolution == null) {
/* 130 */         _getWinodwsDpi();
/*     */       }
/* 132 */       if (_resolution == null) {
/* 133 */         return 100;
/*     */       }
/* 135 */       if (_resolution_list == null) {
/* 136 */         _initFontRatio();
/*     */       }
/* 138 */       Integer r = _getFontRatio(_resolution);
/* 139 */       if (r == null) {
/* 140 */         return 100;
/*     */       }
/* 142 */       return r.intValue();
/*     */     } 
/*     */     
/* 145 */     return 100;
/*     */   }
/*     */ 
/*     */   
/*     */   protected static Double _getResourceDpiScale() {
/* 150 */     if (isEnableHighResolution()) {
/* 151 */       MCNumber dpi_scale = MCConst.beans.getNumber(MCResource.createKey(new String[] { "high_resolution.dpi_scale" }));
/* 152 */       if (dpi_scale != null) {
/* 153 */         return Double.valueOf(dpi_scale.doubleValue());
/*     */       }
/*     */     } 
/* 156 */     return Double.valueOf(1.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   protected static Double _getResourceDisplaySize() {
/* 161 */     if (isEnableHighResolution()) {
/* 162 */       MCNumber display_size = MCConst.beans.getNumber(MCResource.createKey(new String[] { "high_resolution.display_size" }));
/* 163 */       if (display_size != null) {
/* 164 */         return Double.valueOf(display_size.doubleValue());
/*     */       }
/*     */     } 
/* 167 */     return Double.valueOf(1.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   protected static Dimension _getResourceMinResolution() {
/* 172 */     if (isEnableHighResolution()) {
/* 173 */       String min_resolution = MCConst.beans.getString(MCResource.createKey(new String[] { "high_resolution.min_resolution" }));
/* 174 */       if (min_resolution != null) {
/* 175 */         String[] s = MCStringUtil.split(",", min_resolution);
/* 176 */         int s0 = Integer.valueOf(s[0]).intValue();
/* 177 */         int s1 = Integer.valueOf(s[1]).intValue();
/* 178 */         return new Dimension(s0, s1);
/*     */       } 
/*     */     } 
/* 181 */     return new Dimension(1920, 1080);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static Integer _getResourceDpi() {
/* 191 */     if (isEnableHighResolution()) {
/* 192 */       MCNumber dpi = MCConst.beans.getNumber(MCResource.createKey(new String[] { "high_resolution.dpi" }));
/* 193 */       if (dpi != null) {
/* 194 */         return Integer.valueOf(dpi.intValue());
/*     */       }
/*     */     } 
/* 197 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected static Double _getWinodwsDpi() {
/* 203 */     _dpiScale = _getResourceDpiScale().doubleValue();
/* 204 */     _displaySize = _getResourceDisplaySize().doubleValue();
/* 205 */     _minResolution = _getResourceMinResolution();
/*     */ 
/*     */     
/*     */     try {
/* 209 */       final Semaphore lock = new Semaphore(0);
/*     */ 
/*     */       
/* 212 */       Platform.runLater(new Runnable()
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             public void run()
/*     */             {
/* 227 */               Screen s = Screen.getPrimary();
/*     */               
/* 229 */               MCHiresoManager._dpi = Double.valueOf(s.getDpi());
/* 230 */               double w = s.getBounds().getWidth();
/* 231 */               double h = s.getBounds().getHeight();
/* 232 */               MCHiresoManager._resolution = new Dimension((int)w, (int)h);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 259 */               double d = Math.sqrt(Math.pow(MCHiresoManager._resolution.width, 2.0D) + Math.pow(MCHiresoManager._resolution.height, 2.0D));
/* 260 */               double displaySize = d / MCHiresoManager._dpi.doubleValue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 268 */               if (displaySize < MCHiresoManager._displaySize) {
/* 269 */                 MCHiresoManager._dpi = Double.valueOf(MCHiresoManager._dpi.doubleValue() * displaySize / MCHiresoManager._displaySize);
/*     */               }
/*     */               
/* 272 */               lock.release();
/*     */             }
/*     */           });
/*     */ 
/*     */       
/*     */       try {
/* 278 */         lock.tryAcquire(1000L, TimeUnit.MILLISECONDS);
/* 279 */       } catch (InterruptedException ex) {
/* 280 */         ex.printStackTrace();
/*     */       } 
/*     */ 
/*     */       
/* 284 */       return _dpi;
/*     */     }
/* 286 */     catch (Throwable ex) {
/* 287 */       ex.printStackTrace();
/*     */ 
/*     */       
/* 290 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isEnableHighResolution() {
/* 300 */     Boolean b = Boolean.valueOf(MCConst.beans.getBoolean(MCResource.createKey(new String[] { "high_resolution.enable" })));
/* 301 */     return b.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean _initUIManager = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void initUIManager() {
/* 313 */     if (!_initUIManager) {
/* 314 */       _initUIManager = true;
/* 315 */       String f = MCConst.beans.getString(MCResource.createKey(new String[] { "high_resolution.tooltip", "use-uimanager" }));
/* 316 */       if (!MCStringUtil.isNull(f) && "true".equalsIgnoreCase(f)) {
/*     */ 
/*     */ 
/*     */         
/* 320 */         Font fnt = MCConst.beans.getFont(MCResource.createKey(new String[] { "high_resolution.tooltip.font" }));
/* 321 */         if (fnt != null) {
/* 322 */           UIManager.put("ToolTip.font", new FontUIResource(fnt));
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getToolTipText(JComponent c, String s) {
/* 346 */     initUIManager();
/*     */     
/* 348 */     if (MCStringUtil.isNull(s))
/* 349 */       return null; 
/* 350 */     if (isEnableHighResolution()) {
/*     */       
/* 352 */       int fontRatio = getFontRatio();
/*     */ 
/*     */ 
/*     */       
/* 356 */       if (c instanceof MCColumnGroupTableHeader) {
/* 357 */         fontRatio = ((MCColumnGroupTableHeader)c).getMCTable().getRatio();
/*     */       }
/* 359 */       else if (c instanceof MCLayoutTableHeader) {
/* 360 */         fontRatio = ((MCLayoutTableHeader)c).getMCTable().getRatio();
/*     */       }
/* 362 */       else if (c instanceof MCTable2Header) {
/* 363 */         fontRatio = ((MCTable2Header)c).getMCTable().getRatio();
/*     */       } 
/*     */ 
/*     */       
/* 367 */       if (c != null && c instanceof MCBeans) {
/* 368 */         MCRootPanel rp2 = ((MCBeans)c).getBaseRootPanel();
/* 369 */         if (rp2 != null) {
/* 370 */           fontRatio = rp2.getFontRatio();
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 375 */       String s2 = toHTMLText(s, fontRatio);
/* 376 */       return s2;
/*     */     } 
/* 378 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getTooltipFontSize() {
/* 384 */     String f = MCConst.beans.getString("high_resolution.tooltip.font");
/* 385 */     if (MCStringUtil.isNull(f)) {
/* 386 */       f = "name,style,24";
/*     */     }
/* 388 */     String[] nameStyleSize = f.split(",");
/* 389 */     return nameStyleSize[2];
/*     */   }
/*     */ 
/*     */   
/*     */   protected static String toHTMLText(String text, int ratio) {
/* 394 */     StringBuilder sb = new StringBuilder();
/* 395 */     if (!text.startsWith("<html>")) {
/* 396 */       sb.append("<html>");
/*     */ 
/*     */ 
/*     */       
/* 400 */       String fontFamily = MCConst.beans.getString(MCResource.createKey(new String[] { "high_resolution.tooltip", "font-family" }));
/* 401 */       String fontStyle = MCConst.beans.getString(MCResource.createKey(new String[] { "high_resolution.tooltip", "font-style" }));
/* 402 */       String fontColor = MCConst.beans.getString(MCResource.createKey(new String[] { "high_resolution.tooltip", "font-color" }));
/* 403 */       String fontSize = MCConst.beans.getString(MCResource.createKey(new String[] { "high_resolution.tooltip", "font-size" }));
/* 404 */       if (MCStringUtil.isNull(fontSize)) {
/* 405 */         fontSize = getTooltipFontSize();
/*     */       }
/*     */ 
/*     */       
/* 409 */       MCNumber n = MCNumber.valueOf(fontSize).multiply(ratio).divide(100);
/* 410 */       String fontSize2 = String.valueOf(n.intValue());
/*     */       
/* 412 */       sb.append("<font color=");
/* 413 */       sb.append(fontColor);
/* 414 */       sb.append(">");
/*     */       
/* 416 */       sb.append("<p style=\"");
/*     */       
/* 418 */       sb.append("font-size: ");
/* 419 */       sb.append(fontSize2);
/* 420 */       sb.append("px; ");
/*     */       
/* 422 */       if (!_initUIManager) {
/* 423 */         sb.append("font-family: ");
/* 424 */         sb.append(fontFamily);
/* 425 */         sb.append("; ");
/* 426 */         sb.append("font-weight: ");
/* 427 */         sb.append(fontStyle);
/* 428 */         sb.append("; ");
/*     */       } 
/*     */       
/* 431 */       sb.append("\">");
/*     */       
/* 433 */       sb.append(MCStringUtil.convertToLF(text).replaceAll("\n", "<br>"));
/*     */       
/* 435 */       sb.append("</p>");
/*     */       
/* 437 */       sb.append("</font>");
/*     */     } else {
/* 439 */       sb.append(MCStringUtil.convertToLF(text).replaceAll("\n", "<br>"));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 444 */     if (!text.endsWith("</html>")) {
/* 445 */       sb.append("</html>");
/*     */     }
/*     */     
/* 448 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   protected static String toHtmlColor(Color col) {
/* 453 */     if (col == null) {
/* 454 */       return "#FFFFFF";
/*     */     }
/* 456 */     StringBuilder sb = new StringBuilder();
/* 457 */     sb.append("#");
/*     */ 
/*     */     
/* 460 */     String colCode = Integer.toHexString(col.getRed());
/* 461 */     sb.append((colCode.length() == 1) ? ("0" + colCode) : colCode);
/*     */ 
/*     */     
/* 464 */     colCode = Integer.toHexString(col.getGreen());
/* 465 */     sb.append((colCode.length() == 1) ? ("0" + colCode) : colCode);
/*     */ 
/*     */     
/* 468 */     colCode = Integer.toHexString(col.getBlue());
/* 469 */     sb.append((colCode.length() == 1) ? ("0" + colCode) : colCode);
/*     */     
/* 471 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Integer getFileChooserFontRatio(MCFileChooser fc, MCRootPanel rp) {
/* 488 */     if (isEnableHighResolution()) {
/* 489 */       String fontratioKey = MCResource.createKey(new String[] { "high_resolution.filechooser_fontratio" });
/* 490 */       if (MCConst.beans.containsKey(fontratioKey)) {
/* 491 */         int fontratio = MCConst.beans.getInteger(fontratioKey);
/* 492 */         return Integer.valueOf(fontratio);
/*     */       } 
/*     */ 
/*     */       
/* 496 */       if (rp != null) {
/* 497 */         MCRootPanel rp2 = rp.getBaseRootPanel();
/* 498 */         if (rp2 != null) {
/* 499 */           return Integer.valueOf(rp2.getFontRatio());
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 504 */       return Integer.valueOf(getFontRatio());
/*     */     } 
/*     */     
/* 507 */     return Integer.valueOf(100);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static Integer _getDefaultFontRatio() {
/* 517 */     if (isEnableHighResolution()) {
/* 518 */       String fontratioKey = MCResource.createKey(new String[] { "high_resolution.default_fontratio" });
/* 519 */       if (MCConst.beans.containsKey(fontratioKey)) {
/* 520 */         int fontratio = MCConst.beans.getInteger(fontratioKey);
/* 521 */         return Integer.valueOf(fontratio);
/*     */       } 
/*     */     } 
/* 524 */     return Integer.valueOf(100);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Font getPopupFont(String name, int style, int size) {
/* 537 */     Font def = new Font(name, style, size);
/*     */     
/* 539 */     String key = "popup.font";
/* 540 */     Font font = MCConst.beans.getFont(key, def);
/*     */     
/* 542 */     if (MCConst.beans.getBoolean(MCResource.createKey(new String[] { "high_resolution.enable" }))) {
/* 543 */       String f1 = font.getName();
/* 544 */       int f2 = font.getStyle();
/* 545 */       int f3 = font.getSize();
/* 546 */       int ratio = getFontRatio();
/* 547 */       f3 = Integer.valueOf(f3 * ratio / 100).intValue();
/* 548 */       font = new Font(f1, f2, f3);
/* 549 */       return font;
/*     */     } 
/*     */     
/* 552 */     return font;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Font getPopupFont(MCRootPanel rp, Font def) {
/* 563 */     Font font = def;
/*     */     
/* 565 */     if (MCConst.beans.getBoolean(MCResource.createKey(new String[] { "high_resolution.enable" }))) {
/* 566 */       String key = "popup.font";
/* 567 */       font = MCConst.beans.getFont(key, def);
/* 568 */       font = new Font(font.getName(), font.getStyle(), font.getSize());
/*     */       
/* 570 */       String f1 = font.getName();
/* 571 */       int f2 = font.getStyle();
/* 572 */       int f3 = font.getSize();
/* 573 */       int ratio = getFontRatio();
/* 574 */       if (rp != null) {
/* 575 */         ratio = rp.getFontRatio();
/*     */       }
/* 577 */       f3 = Integer.valueOf(f3 * ratio / 100).intValue();
/* 578 */       font = new Font(f1, f2, f3);
/* 579 */       return font;
/*     */     } 
/*     */     
/* 582 */     return font;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void updateMenuFont(MCRootPanel bp, MCPopupMenu menu) {
/* 592 */     if (isEnableHighResolution()) {
/* 593 */       _updateMenuFont(bp, (Container)menu);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static void _updateMenuFont(MCRootPanel bp, Container menu) {
/* 599 */     Font f = getPopupFont(bp, menu.getFont());
/* 600 */     menu.setFont(f);
/*     */     
/* 602 */     Component[] cs = menu.getComponents(); byte b; int i; Component[] arrayOfComponent1;
/* 603 */     for (i = (arrayOfComponent1 = cs).length, b = 0; b < i; ) { Component c = arrayOfComponent1[b];
/* 604 */       if (c instanceof Container) {
/* 605 */         _updateMenuFont(bp, (Container)c);
/*     */       }
/* 607 */       if (c instanceof JMenu) {
/* 608 */         _updateMenuFont(bp, (JMenu)c);
/*     */       }
/*     */       b++; }
/*     */   
/*     */   }
/*     */   
/*     */   private static void _updateMenuFont(MCRootPanel bp, JMenu menu) {
/* 615 */     Font f = getPopupFont(bp, menu.getFont());
/* 616 */     menu.setFont(f);
/*     */     
/* 618 */     Component[] cs = menu.getMenuComponents(); byte b; int i; Component[] arrayOfComponent1;
/* 619 */     for (i = (arrayOfComponent1 = cs).length, b = 0; b < i; ) { Component c = arrayOfComponent1[b];
/* 620 */       if (c instanceof Container) {
/* 621 */         _updateMenuFont(bp, (Container)c);
/*     */       }
/* 623 */       if (c instanceof JMenu) {
/* 624 */         _updateMenuFont(bp, (JMenu)c);
/*     */       }
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static String getMode() {
/* 642 */     if (isEnableHighResolution()) {
/* 643 */       String modeKey = MCResource.createKey(new String[] { "high_resolution.mode" });
/* 644 */       if (MCConst.beans.containsKey(modeKey)) {
/* 645 */         String s = MCConst.beans.getString(modeKey);
/* 646 */         return s;
/*     */       } 
/*     */     } 
/* 649 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static Integer getDpi() {
/* 660 */     if (isEnableHighResolution()) {
/* 661 */       String modeKey = MCResource.createKey(new String[] { "high_resolution.dpi" });
/* 662 */       if (MCConst.beans.containsKey(modeKey)) {
/* 663 */         int s = MCConst.beans.getInteger(modeKey);
/* 664 */         return Integer.valueOf(s);
/*     */       } 
/*     */     } 
/* 667 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 695 */   private static Integer _max_fontratio = Integer.valueOf(100);
/* 696 */   private static Integer _default_fontratio = Integer.valueOf(100);
/*     */ 
/*     */ 
/*     */   
/*     */   private static ArrayList<MCHiresoManagerResolution> _resolution_list;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static Integer _getFontRatio(Dimension resolution) {
/* 706 */     if (_resolution_list.size() == 0) {
/* 707 */       return _default_fontratio;
/*     */     }
/*     */     
/* 710 */     for (MCHiresoManagerResolution r : _resolution_list) {
/* 711 */       if (r.resolution() < resolution.width) {
/*     */         continue;
/*     */       }
/* 714 */       return Integer.valueOf(r.fontratio());
/*     */     } 
/*     */     
/* 717 */     return _max_fontratio;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void _initFontRatio() {
/* 725 */     if (isEnableHighResolution()) {
/*     */       
/* 727 */       _resolution_list = new ArrayList<>();
/*     */       
/* 729 */       String pattern = MCConst.createKey(new String[] { "high_resolution.resolution_table", "resolution*" });
/* 730 */       String[] ka = MCConst.beans.findPattern(pattern); byte b; int i; String[] arrayOfString1;
/* 731 */       for (i = (arrayOfString1 = ka).length, b = 0; b < i; ) { String k = arrayOfString1[b];
/* 732 */         String v = MCConst.beans.getString(k);
/* 733 */         String[] s = MCStringUtil.split(",", v);
/* 734 */         int s0 = Integer.valueOf(s[0]).intValue();
/* 735 */         int s1 = Integer.valueOf(s[1]).intValue();
/* 736 */         _resolution_list.add(new MCHiresoManagerResolution(s0, s1)); b++; }
/*     */       
/* 738 */       Collections.sort(_resolution_list, new Comparator<MCHiresoManagerResolution>()
/*     */           {
/*     */             public int compare(MCHiresoManagerResolution p1, MCHiresoManagerResolution p2) {
/* 741 */               if (p1.resolution() == p2.resolution()) {
/* 742 */                 return 0;
/*     */               }
/* 744 */               return (p1.resolution() < p2.resolution()) ? -1 : 1;
/*     */             }
/*     */           });
/*     */       
/* 748 */       String defaultKey = MCConst.createKey(new String[] { "high_resolution.resolution_table.default" });
/* 749 */       if (MCConst.beans.containsKey(defaultKey)) {
/* 750 */         Integer def = Integer.valueOf(MCConst.beans.getInteger(defaultKey));
/* 751 */         _default_fontratio = def;
/*     */       } 
/*     */       
/* 754 */       String maxKey = MCConst.createKey(new String[] { "high_resolution.resolution_table.max_resolution" });
/* 755 */       if (MCConst.beans.containsKey(defaultKey)) {
/* 756 */         Integer max = Integer.valueOf(MCConst.beans.getInteger(maxKey));
/* 757 */         _max_fontratio = max;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isEnableGraphWheel() {
/* 768 */     if (isEnableHighResolution()) {
/* 769 */       Boolean b = Boolean.valueOf(MCConst.beans.getBoolean(MCResource.createKey(new String[] { "high_resolution.useGraphWheel" })));
/* 770 */       if (b != null) {
/* 771 */         return b.booleanValue();
/*     */       }
/*     */     } 
/* 774 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isEnableWebViewZoom() {
/* 783 */     if (isEnableHighResolution()) {
/* 784 */       boolean b = MCConst.beans.getBoolean(MCResource.createKey(new String[] { "high_resolution.useWebViewZoom" }, ), true);
/* 785 */       return b;
/*     */     } 
/* 787 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\layout\MCHiresoManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */