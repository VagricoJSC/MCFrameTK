/*     */ package mcframe.clientCore.beans.layout;
/*     */ 
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCLayoutLocationR
/*     */ {
/*     */   protected boolean isVisible;
/*     */   protected String componentID;
/*     */   protected String componentName;
/*     */   protected String componentType;
/*     */   protected String panelID;
/*     */   protected int locationX;
/*     */   protected int locationY;
/*     */   protected int labelWidth;
/*     */   protected int labelHeight;
/*     */   protected int sequence;
/*     */   protected boolean systemInvisible;
/*     */   protected String rootPanelID;
/*     */   protected boolean hasCr;
/*     */   protected boolean userHasCr;
/*     */   protected boolean userNoCr;
/*     */   protected boolean hasNewLine;
/*     */   protected boolean defaultHasCr;
/*     */   protected boolean isSystemVisible;
/*     */   protected boolean isUserHasCr;
/*     */   protected boolean isUserNoCr;
/*     */   public static final boolean _debug3 = true;
/*     */   public static final boolean _debug4 = true;
/*     */   protected boolean localeNoCr;
/*     */   protected boolean localeHasCr;
/*     */   protected Integer localeWidth;
/*     */   protected boolean isLocaleNoCr;
/*     */   protected boolean isLocaleHasCr;
/*     */   protected boolean isLocaleWidth;
/*     */   
/*     */   public int locationY() {
/*  71 */     return this.locationY;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void locationY(int d) {
/*  79 */     this.locationY = d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void locationY(MCNumber number) {
/*  87 */     if (number == null) {
/*  88 */       this.locationY = 0;
/*     */     } else {
/*  90 */       this.locationY = number.intValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int locationX() {
/*  99 */     return this.locationX;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void locationX(int d) {
/* 107 */     this.locationX = d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void locationX(MCNumber number) {
/* 115 */     if (number == null) {
/* 116 */       this.locationX = 0;
/*     */     } else {
/* 118 */       this.locationX = number.intValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int labelWidth() {
/* 127 */     return this.labelWidth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void labelWidth(int d) {
/* 135 */     this.labelWidth = d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void labelWidth(MCNumber number) {
/* 143 */     if (number == null) {
/* 144 */       this.labelWidth = 0;
/*     */     } else {
/* 146 */       this.labelWidth = number.intValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int labelHeight() {
/* 155 */     return this.labelHeight;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void labelHeight(int d) {
/* 163 */     this.labelHeight = d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void labelHeight(MCNumber number) {
/* 171 */     if (number == null) {
/* 172 */       this.labelHeight = 0;
/*     */     } else {
/* 174 */       this.labelHeight = number.intValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int sequence() {
/* 183 */     return this.sequence;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sequence(int intValue) {
/* 191 */     this.sequence = intValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void sequence(MCNumber number) {
/* 199 */     if (number == null) {
/* 200 */       this.sequence = 0;
/*     */     } else {
/* 202 */       this.sequence = number.intValue();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String panelID() {
/* 211 */     if (this.panelID == null) {
/* 212 */       return "";
/*     */     }
/* 214 */     return this.panelID;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void panelID(String string) {
/* 222 */     this.panelID = string;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String rootPanelID() {
/* 230 */     if (this.rootPanelID == null) {
/* 231 */       return "";
/*     */     }
/* 233 */     return this.rootPanelID;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rootPanelID(String string) {
/* 241 */     this.rootPanelID = string;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isVisible() {
/* 249 */     return this.isVisible;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void isVisible(boolean b) {
/* 257 */     this.isVisible = b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String componentName() {
/* 265 */     return this.componentName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void componentName(String string) {
/* 273 */     this.componentName = string;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String componentType() {
/* 281 */     return this.componentType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void componentType(String string) {
/* 289 */     this.componentType = string;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String componentID() {
/* 297 */     return this.componentID;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void componentID(String string) {
/* 305 */     this.componentID = string;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean systemInvisible() {
/* 313 */     return this.systemInvisible;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void systemInvisible(boolean b) {
/* 321 */     this.systemInvisible = b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSystemVisible() {
/* 329 */     return this.isSystemVisible;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void isSystemVisible(boolean b) {
/* 337 */     this.isSystemVisible = b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUserHasCr() {
/* 345 */     return this.isUserHasCr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void isUserHasCr(boolean b) {
/* 353 */     this.isUserHasCr = b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUserNoCr() {
/* 361 */     return this.isUserNoCr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void isUserNoCr(boolean b) {
/* 369 */     this.isUserNoCr = b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasCr() {
/* 377 */     return this.hasCr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void hasCr(boolean b) {
/* 385 */     this.hasCr = b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean userHasCr() {
/* 393 */     return this.userHasCr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void userHasCr(boolean b) {
/* 401 */     this.userHasCr = b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean userNoCr() {
/* 409 */     return this.userNoCr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void userNoCr(boolean b) {
/* 417 */     this.userNoCr = b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasNewLine() {
/* 425 */     return this.hasNewLine;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void hasNewLine(boolean b) {
/* 433 */     this.hasNewLine = b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean defaultHasCr() {
/* 441 */     return this.defaultHasCr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void defaultHasCr(boolean b) {
/* 449 */     this.defaultHasCr = b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCLayoutLocationR clone() {
/* 456 */     MCLayoutLocationR clone = new MCLayoutLocationR();
/* 457 */     clone.isVisible = isVisible();
/* 458 */     clone.componentID = componentID();
/* 459 */     clone.componentName = componentName();
/* 460 */     clone.componentType = componentType();
/* 461 */     clone.panelID = panelID();
/* 462 */     clone.locationX = locationX();
/* 463 */     clone.locationY = locationY();
/* 464 */     clone.labelWidth = labelWidth();
/* 465 */     clone.labelHeight = labelHeight();
/* 466 */     clone.sequence = sequence();
/* 467 */     clone.systemInvisible = systemInvisible();
/* 468 */     clone.rootPanelID = rootPanelID();
/* 469 */     clone.userHasCr = userHasCr();
/* 470 */     clone.userNoCr = userNoCr();
/* 471 */     clone.hasCr = hasCr();
/* 472 */     clone.hasNewLine = hasNewLine();
/* 473 */     clone.defaultHasCr = defaultHasCr();
/* 474 */     clone.isSystemVisible = isSystemVisible();
/* 475 */     clone.isUserHasCr = isUserHasCr();
/* 476 */     clone.isUserNoCr = isUserNoCr();
/*     */ 
/*     */     
/* 479 */     clone.localeHasCr = localeHasCr();
/* 480 */     clone.localeNoCr = localeNoCr();
/* 481 */     clone.localeWidth = localeWidth();
/* 482 */     clone.isLocaleHasCr = isLocaleHasCr();
/* 483 */     clone.isLocaleNoCr = isLocaleNoCr();
/* 484 */     clone.isLocaleWidth = isLocaleWidth();
/*     */ 
/*     */     
/* 487 */     return clone;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 492 */     return String.valueOf(Boolean.toString(this.isVisible)) + "," + this.componentID + "," + this.componentName + "," + 
/* 493 */       this.componentType + "," + this.panelID + "," + Integer.toString(this.locationX) + "," + 
/* 494 */       Integer.toString(this.locationY) + "," + Integer.toString(this.labelWidth) + "," + 
/* 495 */       Integer.toString(this.labelHeight) + "," + Integer.toString(this.sequence) + "," + 
/* 496 */       Boolean.toString(this.systemInvisible) + "," + this.rootPanelID + "," + 
/* 497 */       Boolean.toString(this.userHasCr) + "," + Boolean.toString(this.hasCr) + "," + 
/* 498 */       Boolean.toString(this.hasNewLine) + "," + Boolean.toString(this.defaultHasCr) + 
/* 499 */       "," + Boolean.toString(this.isSystemVisible) + "," + 
/* 500 */       Boolean.toString(this.userNoCr) + 
/*     */ 
/*     */       
/* 503 */       "," + Boolean.toString(this.localeHasCr) + "," + Boolean.toString(this.localeNoCr) + 
/* 504 */       Integer.toString(this.localeWidth.intValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equalsID(MCLayoutLocationR r) {
/* 514 */     if (!r.componentID().equals(componentID())) {
/* 515 */       return false;
/*     */     }
/* 517 */     if (!r.panelID().equals(panelID())) {
/* 518 */       return false;
/*     */     }
/* 520 */     if (!r.rootPanelID().equals(rootPanelID())) {
/* 521 */       return false;
/*     */     }
/* 523 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String fullComponentID() {
/* 531 */     return this.rootPanelID + "/" + this.panelID + "/" + this.componentID;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean localeHasCr() {
/* 556 */     return this.localeHasCr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void localeHasCr(boolean b) {
/* 564 */     this.localeHasCr = b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean localeNoCr() {
/* 572 */     return this.localeNoCr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void localeNoCr(boolean b) {
/* 580 */     this.localeNoCr = b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer localeWidth() {
/* 588 */     return this.localeWidth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void localeWidth(Integer n) {
/* 596 */     this.localeWidth = n;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLocaleHasCr() {
/* 601 */     return this.isLocaleHasCr;
/*     */   }
/*     */   public void isLocaleHasCr(boolean b) {
/* 604 */     this.isLocaleHasCr = b;
/*     */   }
/*     */   public boolean isLocaleNoCr() {
/* 607 */     return this.isLocaleNoCr;
/*     */   }
/*     */   public void isLocaleNoCr(boolean b) {
/* 610 */     this.isLocaleNoCr = b;
/*     */   }
/*     */   public boolean isLocaleWidth() {
/* 613 */     return this.isLocaleWidth;
/*     */   }
/*     */   public void isLocaleWidth(boolean b) {
/* 616 */     this.isLocaleWidth = b;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\layout\MCLayoutLocationR.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */