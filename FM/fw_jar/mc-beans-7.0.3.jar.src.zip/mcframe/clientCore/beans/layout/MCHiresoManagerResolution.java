/*    */ package mcframe.clientCore.beans.layout;
/*    */ 
/*    */ public class MCHiresoManagerResolution
/*    */ {
/*    */   private int _resolution;
/*    */   private int _fontratio;
/*    */   
/*    */   public MCHiresoManagerResolution(int resolution, int fontratio) {
/*  9 */     this._resolution = resolution;
/* 10 */     this._fontratio = fontratio;
/*    */   }
/*    */   public int resolution() {
/* 13 */     return this._resolution;
/*    */   }
/*    */   public int fontratio() {
/* 16 */     return this._fontratio;
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\layout\MCHiresoManagerResolution.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */