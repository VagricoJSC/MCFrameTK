/*     */ package mcframe.clientCore.beans.layout;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JComponent;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCButton;
/*     */ import mcframe.clientCore.beans.MCField;
/*     */ import mcframe.clientCore.beans.MCImageView;
/*     */ import mcframe.clientCore.beans.MCLabel;
/*     */ import mcframe.clientCore.beans.MCPanel;
/*     */ import mcframe.clientCore.beans.MCResourceBeans;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.MCScrollPane;
/*     */ import mcframe.clientCore.beans.MCTextArea;
/*     */ import mcframe.clientCore.beans.action.MCFunctionKey;
/*     */ import mcframe.clientCore.beans.combobox.AbsMCComboBox;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MCHeaderLayout
/*     */ {
/*     */   private static final String INVISIBLE_WIDTH = "auto_layout.invisible_w.";
/*  58 */   private static MCHeaderLayout INSTANCE = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static MCHeaderLayout getInstance() {
/*  77 */     return (INSTANCE != null) ? INSTANCE : (INSTANCE = new MCHeaderLayout());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Rectangle layout(MCHeaderLayoutInfo info) {
/*  89 */     return isAutoLayout(info) ? doLayout(info) : info.getBounds();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isAutoLayout(MCHeaderLayoutInfo info) {
/* 101 */     MCResourceBeans c = info.getComponent();
/*     */ 
/*     */     
/* 104 */     if (!MCBeansProxy.PROXY.isAutoLayout(c.getRootPanel())) {
/* 105 */       return false;
/*     */     }
/* 107 */     if (c instanceof mcframe.clientCore.beans.MCTabbedPane || c instanceof mcframe.clientCore.beans.MCSplitPane) {
/* 108 */       return false;
/*     */     }
/* 110 */     if (c instanceof MCScrollPane) {
/* 111 */       Component v = ((MCScrollPane)c).getViewport().getView();
/* 112 */       if (v instanceof mcframe.clientCore.beans.table.MCTable || v instanceof mcframe.clientCore.beans.tree.MCTree) {
/* 113 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 117 */     return MCBeansProxy.PROXY.isAutoLayout(c, c.getRootPanel(), true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Rectangle doLayout(MCHeaderLayoutInfo info) {
/* 137 */     Rectangle ret = info.getBounds();
/* 138 */     JComponent beans = (JComponent)info.getComponent();
/*     */ 
/*     */     
/* 141 */     JComponent prev = getLeftPreviousComponent(beans, info.getBounds());
/* 142 */     if (prev != null) {
/* 143 */       if (beans instanceof MCButton || (
/* 144 */         MCConst.beans.getBoolean("SCR_COMP.ABS_BUTTON.B_LAYOUT", false) && beans instanceof AbstractButton)) {
/* 145 */         ret.setLocation(doLayout((AbstractButton)beans, info.getBounds()));
/*     */       }
/*     */       else {
/*     */         
/* 149 */         JComponent head = getLeftHeaderComponent(beans, info.getBounds());
/* 150 */         int head_margin = (head != null) ? head.getX() : 5;
/* 151 */         int margin = ((prev.getSize()).width <= getInvisibleWidth(prev)) ? 0 : 
/* 152 */           getBeansInteger("SCR_COMP.BEANS.X_MARGIN", 5);
/* 153 */         int grid_x = gridPoint(prev.getX() + getWidth(prev) + margin, head_margin);
/* 154 */         grid_x = setRowHeadPosition(grid_x, beans, head_margin);
/* 155 */         ret.setLocation(grid_x, (int)ret.getY());
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 160 */     if (containsLabel(beans)) {
/*     */       
/* 162 */       Dimension tempPre = beans.getPreferredSize();
/* 163 */       beans.setPreferredSize((Dimension)null);
/*     */       
/* 165 */       if (beans instanceof MCButton) {
/* 166 */         ret.setSize((int)getWidth((MCButton)beans, info.getBounds()), 
/* 167 */             (int)ret.getHeight());
/*     */       
/*     */       }
/* 170 */       else if (ret.getWidth() > getInvisibleWidth(beans)) {
/*     */ 
/*     */ 
/*     */         
/* 174 */         ret.setSize((int)beans.getPreferredSize().getWidth(), 
/* 175 */             (int)ret.getHeight());
/*     */       } else {
/*     */         
/* 178 */         ret.setSize((int)ret.getWidth(), (int)ret.getHeight());
/*     */       } 
/*     */ 
/*     */       
/* 182 */       beans.setPreferredSize(tempPre);
/*     */     
/*     */     }
/* 185 */     else if (beans instanceof MCPanel) {
/* 186 */       if (beans.getParent() instanceof MCRootPanel) {
/* 187 */         MCRootPanel p = (MCRootPanel)beans.getParent();
/* 188 */         if (p.isPartsPanel())
/*     */         {
/* 190 */           if (((MCPanel)beans).getBorder() == null)
/*     */           {
/* 192 */             ret.width = getFitWidth((MCPanel)beans, p);
/*     */           
/*     */           }
/*     */         
/*     */         }
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/* 202 */     else if (beans instanceof MCRootPanel) {
/* 203 */       MCRootPanel p = (MCRootPanel)beans;
/* 204 */       if (p.isPartsPanel()) {
/*     */ 
/*     */         
/* 207 */         int availPanel = 0;
/* 208 */         Component lastAvail = null; byte b; int i; Component[] arrayOfComponent;
/* 209 */         for (i = (arrayOfComponent = beans.getComponents()).length, b = 0; b < i; ) { Component comp = arrayOfComponent[b];
/*     */ 
/*     */           
/* 212 */           if (isAutoLayout(comp, p))
/*     */           {
/*     */             
/* 215 */             if (comp.getHeight() > 0 || comp.getWidth() > getInvisibleWidth(comp)) {
/* 216 */               availPanel++;
/* 217 */               lastAvail = comp;
/*     */             }  }  b++; }
/*     */         
/* 220 */         if (availPanel == 1 && lastAvail instanceof MCPanel)
/*     */         {
/* 222 */           ret.width = lastAvail.getWidth();
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 229 */     return ret;
/*     */   }
/*     */   
/*     */   private int getFitWidth(MCPanel p, MCRootPanel base) {
/* 233 */     int maxW = 0; byte b; int i; Component[] arrayOfComponent;
/* 234 */     for (i = (arrayOfComponent = p.getComponents()).length, b = 0; b < i; ) { Component comp = arrayOfComponent[b];
/*     */ 
/*     */       
/* 237 */       if (isAutoLayout(comp, base))
/*     */       {
/*     */         
/* 240 */         if (comp.getHeight() > 0 && comp.getWidth() > getInvisibleWidth(comp)) {
/* 241 */           int rightX = comp.getX() + comp.getWidth();
/* 242 */           maxW = (maxW >= rightX) ? maxW : rightX;
/*     */         } 
/*     */       }
/*     */       b++; }
/*     */     
/* 247 */     return (p.getWidth() > 0) ? maxW : p.getWidth();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isAutoLayout(Component compo, MCRootPanel base) {
/* 266 */     if (compo instanceof MCResourceBeans) {
/* 267 */       return MCBeansProxy.PROXY.isAutoLayout((MCResourceBeans)compo, base, 
/* 268 */           MCBeansProxy.PROXY.isAutoLayout(base));
/*     */     }
/* 270 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double getWidth(MCButton btn, Rectangle rect) {
/* 283 */     Icon icon = btn.getIcon();
/* 284 */     String label = btn.getLabelByLocale();
/*     */ 
/*     */     
/* 287 */     int buttonWidthMin = -1;
/*     */     
/* 289 */     if (icon != null && (label == null || label.length() == 0)) {
/*     */       
/* 291 */       buttonWidthMin = getBeansInteger("SCR_COMP.BUTTON.X_STATIC_ICON_BUTTON", 21);
/*     */     }
/*     */     else {
/*     */       
/* 295 */       buttonWidthMin = getBeansInteger("SCR_COMP.BUTTON.X_STATIC", 98);
/*     */     } 
/*     */     
/* 298 */     int buttonWidth = -1;
/*     */     try {
/* 300 */       if (icon != null) {
/* 301 */         btn.setIcon(null);
/*     */       }
/* 303 */       if (label != null && label.length() != 0) {
/* 304 */         btn.setPreferredSize(null);
/*     */ 
/*     */         
/* 307 */         int x_margin = getBeansInteger("SCR_COMP.BUTTON.X_MARGIN", 4);
/* 308 */         if (rect.width >= buttonWidthMin) {
/* 309 */           x_margin = getBeansInteger("SCR_COMP.BUTTON.X_MARGIN_L", 16);
/*     */         }
/*     */         
/* 312 */         buttonWidth = (int)btn.getPreferredSize().getWidth() + x_margin;
/*     */       } else {
/*     */         
/* 315 */         buttonWidth = 0;
/*     */       } 
/*     */     } finally {
/*     */       
/* 319 */       if (icon != null) {
/* 320 */         btn.setIcon(icon);
/*     */       }
/*     */     } 
/* 323 */     if (icon != null) {
/* 324 */       buttonWidth += getBeansInteger("SCR_COMP.CHAR.X_PER_ICON", 16);
/*     */     }
/*     */     
/* 327 */     if (buttonWidthMin > 0) {
/* 328 */       if (icon != null && (label == null || label.length() == 0)) {
/* 329 */         buttonWidth = buttonWidthMin;
/*     */       }
/* 331 */       else if (buttonWidth < buttonWidthMin && rect.width >= buttonWidthMin) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 336 */         buttonWidth = buttonWidthMin;
/*     */       } 
/*     */     }
/*     */     
/* 340 */     return buttonWidth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getBeansInteger(String key, int def) {
/* 353 */     return MCConst.beans.getInteger(key, def);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Point doLayout(AbstractButton btn, Rectangle rect) {
/* 367 */     JComponent zPrev = getPreviousComponent(btn);
/* 368 */     int b_mar = ((zPrev.getSize()).width <= getInvisibleWidth(zPrev)) ? 0 : 
/* 369 */       getBeansInteger("SCR_COMP.BEANS.X_MARGIN", 5);
/*     */     
/* 371 */     if (zPrev instanceof MCButton && 
/* 372 */       btn instanceof MCButton) {
/* 373 */       MCButton mb = (MCButton)btn;
/* 374 */       Icon icon = btn.getIcon();
/* 375 */       String label = mb.getLabelByLocale();
/*     */ 
/*     */       
/* 378 */       if ((icon != null || (label != null && !label.equals("")) || mb
/* 379 */         .getFunctionKey() != null) && 
/* 380 */         isIconLabelFuncEqual(mb, (MCButton)zPrev)) {
/* 381 */         return new Point(zPrev.getX(), zPrev.getY());
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 386 */     return new Point(zPrev.getX() + getWidth(zPrev) + b_mar, (int)rect.getY());
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isIconLabelFuncEqual(MCButton a, MCButton b) {
/* 391 */     String icon_a = a.getIconKey();
/* 392 */     String icon_b = b.getIconKey();
/* 393 */     if (icon_a != null || icon_b != null)
/*     */     {
/* 395 */       if (icon_a != null && icon_b != null) {
/* 396 */         if (!icon_a.equals(icon_b)) {
/* 397 */           return false;
/*     */         }
/*     */       }
/*     */       else {
/*     */         
/* 402 */         return false;
/*     */       } 
/*     */     }
/*     */     
/* 406 */     String lab_a = a.getLabelByLocale();
/* 407 */     String lab_b = b.getLabelByLocale();
/* 408 */     if (lab_a != null || lab_b != null)
/*     */     {
/* 410 */       if (lab_a != null && lab_b != null) {
/* 411 */         if (!lab_a.equals(lab_b)) {
/* 412 */           return false;
/*     */         }
/*     */       }
/*     */       else {
/*     */         
/* 417 */         return false;
/*     */       } 
/*     */     }
/*     */     
/* 421 */     MCFunctionKey fk_a = a.getFunctionKey();
/* 422 */     MCFunctionKey fk_b = b.getFunctionKey();
/* 423 */     if (fk_a != null || fk_b != null)
/*     */     {
/* 425 */       if (fk_a != null && fk_b != null) {
/* 426 */         if (!fk_a.equals(fk_b)) {
/* 427 */           return false;
/*     */         }
/*     */       }
/*     */       else {
/*     */         
/* 432 */         return false;
/*     */       }  } 
/* 434 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int gridPoint(int start, int h_margin) {
/* 447 */     int span = getBeansInteger("SCR_COMP.GRID_SPAN", 20);
/*     */ 
/*     */     
/* 450 */     if (span <= 0) return start;
/*     */     
/* 452 */     int b_mar = getBeansInteger("SCR_COMP.BEANS.X_MARGIN", 5);
/* 453 */     if (start == h_margin) b_mar = 0;
/*     */     
/* 455 */     if ((start - h_margin - b_mar) % span == 0) return start; 
/* 456 */     return ((start - h_margin - b_mar) / span + 1) * span + h_margin + b_mar;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int setRowHeadPosition(int tempX, JComponent comp, int p_x_mar) {
/* 470 */     int rHeadCx = getBeansInteger("SCR_COMP.ROW_HEAD_TEXT_COMPONENT_X", 65);
/*     */     
/* 472 */     if (rHeadCx >= 0) {
/* 473 */       MCLabel headLabel = null;
/* 474 */       if (comp instanceof MCField) {
/* 475 */         headLabel = ((MCField)comp).getLabel();
/*     */       }
/* 477 */       else if (comp instanceof AbsMCComboBox) {
/* 478 */         headLabel = ((AbsMCComboBox)comp).getLabel();
/*     */       }
/* 480 */       else if (comp instanceof MCTextArea) {
/* 481 */         headLabel = ((MCTextArea)comp).getLabel();
/*     */       }
/* 483 */       else if (comp instanceof MCImageView) {
/* 484 */         headLabel = ((MCImageView)comp).getMCLabel();
/*     */       } 
/* 486 */       if (headLabel != null && headLabel.getX() <= 10)
/*     */       {
/* 488 */         if (tempX < rHeadCx) {
/* 489 */           return rHeadCx + p_x_mar;
/*     */         }
/*     */       }
/*     */     } 
/*     */     
/* 494 */     return tempX;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean containsLabel(JComponent comp) {
/* 506 */     if (comp == null) {
/* 507 */       return false;
/*     */     }
/* 509 */     return !(!(comp instanceof MCLabel) && !(comp instanceof mcframe.clientCore.beans.MCRadioButton) && 
/* 510 */       !(comp instanceof mcframe.clientCore.beans.MCCheckBox) && !(comp instanceof MCButton));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getInvisibleWidth(Component comp) {
/* 521 */     if (comp instanceof MCField) {
/* 522 */       return MCConst.layout.getInteger("auto_layout.invisible_w.text", 0);
/*     */     }
/* 524 */     if (comp instanceof AbsMCComboBox) {
/* 525 */       return MCConst.layout.getInteger("auto_layout.invisible_w.combo", 0);
/*     */     }
/* 527 */     if (comp instanceof mcframe.clientCore.beans.MCRadioButton) {
/* 528 */       return MCConst.layout.getInteger("auto_layout.invisible_w.radio", 0);
/*     */     }
/* 530 */     if (comp instanceof mcframe.clientCore.beans.MCCheckBox) {
/* 531 */       return MCConst.layout.getInteger("auto_layout.invisible_w.check", 0);
/*     */     }
/* 533 */     if (comp instanceof mcframe.clientCore.beans.MCPasswordField) {
/* 534 */       return MCConst.layout.getInteger("auto_layout.invisible_w.text", 0);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 544 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   private int getWidth(Component comp) {
/* 549 */     int iw = getInvisibleWidth(comp);
/* 550 */     int cw = comp.getWidth();
/* 551 */     if (cw <= iw) {
/* 552 */       return 0;
/*     */     }
/* 554 */     return cw;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JComponent getLeftPreviousComponent(JComponent comp, Rectangle rect) {
/* 567 */     JComponent zPrev = getPreviousComponent(comp);
/* 568 */     if (zPrev == null) {
/* 569 */       return null;
/*     */     }
/* 571 */     if (y_overlap(zPrev, rect)) {
/* 572 */       return zPrev;
/*     */     }
/* 574 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean y_overlap(JComponent prev, Rectangle self) {
/* 587 */     int prevH = (prev.getHeight() != 0) ? prev.getHeight() : 5;
/* 588 */     double selfH = (self.getHeight() != 0.0D) ? self.getHeight() : 5.0D;
/* 589 */     boolean b1 = (prev.getY() <= self.getY() && self.getY() <= (prev.getY() + prevH));
/* 590 */     if (b1) return true;
/*     */ 
/*     */     
/* 593 */     boolean b2 = (prev.getY() <= self.getY() + selfH && 
/* 594 */       self.getY() + selfH <= (prev.getY() + prevH));
/* 595 */     if (b2) return true;
/*     */ 
/*     */     
/* 598 */     boolean b3 = (self.getY() <= prev.getY() && prev.getY() <= self.getY() + selfH);
/* 599 */     return b3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JComponent getPreviousComponent(JComponent comp) {
/* 615 */     if (comp == null) {
/* 616 */       return null;
/*     */     }
/*     */     
/* 619 */     MCRootPanel p = MCBeansUtil.getRootPanel(comp.getParent());
/* 620 */     if (p == null) {
/* 621 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 627 */     Map<Container, Map<Integer, List<Object[]>>> am = MCBeansProxy.PROXY
/* 628 */       .getLayoutMap(p);
/* 629 */     Map<Integer, List<Object[]>> m = am.get(comp.getParent());
/* 630 */     if (m == null) {
/* 631 */       return null;
/*     */     }
/*     */     
/* 634 */     for (Map.Entry<Integer, List<Object[]>> e : m.entrySet()) {
/* 635 */       List<Object[]> l = e.getValue();
/* 636 */       JComponent bc = null;
/* 637 */       for (int i = 0; i < l.size(); i++) {
/* 638 */         Component c = (Component)((Object[])l.get(i))[0];
/* 639 */         if (comp.equals(c)) {
/* 640 */           if (i == 0) {
/* 641 */             return null;
/*     */           }
/* 643 */           return bc;
/*     */         } 
/*     */ 
/*     */         
/* 647 */         if (isAutoLayout(c, p) && c instanceof JComponent) {
/* 648 */           bc = (JComponent)c;
/*     */         }
/*     */       } 
/*     */     } 
/* 652 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JComponent getLeftHeaderComponent(JComponent comp, Rectangle rect) {
/* 694 */     if (comp == null) {
/* 695 */       return null;
/*     */     }
/*     */     
/* 698 */     MCRootPanel p = MCBeansUtil.getRootPanel(comp.getParent());
/* 699 */     if (p == null) {
/* 700 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 706 */     Map<Container, Map<Integer, List<Object[]>>> am = MCBeansProxy.PROXY
/* 707 */       .getLayoutMap(p);
/* 708 */     Map<Integer, List<Object[]>> m = am.get(comp.getParent());
/* 709 */     if (m == null) {
/* 710 */       return null;
/*     */     }
/*     */     
/* 713 */     for (Map.Entry<Integer, List<Object[]>> e : m.entrySet()) {
/* 714 */       List<Object[]> l = e.getValue();
/* 715 */       JComponent bc = null;
/* 716 */       for (Object[] a : l) {
/* 717 */         Component c = (Component)a[0];
/*     */         
/* 719 */         if (bc == null && c instanceof JComponent && isAutoLayout(c, p)) {
/* 720 */           bc = (JComponent)c;
/*     */         }
/* 722 */         if (comp.equals(c)) {
/* 723 */           return bc;
/*     */         }
/*     */       } 
/*     */     } 
/* 727 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\layout\MCHeaderLayout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */