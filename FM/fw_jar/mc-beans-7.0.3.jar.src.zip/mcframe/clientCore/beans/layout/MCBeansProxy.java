/*     */ package mcframe.clientCore.beans.layout;
/*     */ 
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.swing.JComponent;
/*     */ import mcframe.clientCore.beans.AbsMCPackageProxy;
/*     */ import mcframe.clientCore.beans.MCButton;
/*     */ import mcframe.clientCore.beans.MCFrame;
/*     */ import mcframe.clientCore.beans.MCModeBeans;
/*     */ import mcframe.clientCore.beans.MCPanel;
/*     */ import mcframe.clientCore.beans.MCResourceBeans;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.MCSplitPane;
/*     */ import mcframe.clientCore.beans.resource.MCPersonalizeGroupInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class MCBeansProxy
/*     */   extends AbsMCPackageProxy
/*     */ {
/*  27 */   static final MCBeansProxy PROXY = new MCBeansProxy();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isAutoLayout(MCRootPanel panel) {
/*  40 */     return super.isAutoLayout(panel);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isAutoLayout(MCResourceBeans compo, MCRootPanel base, boolean def) {
/*  45 */     return super.isAutoLayout(compo, base, def);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Map<Container, Map<Integer, List<Object[]>>> getLayoutMap(MCRootPanel panel) {
/*  51 */     return super.getLayoutMap(panel);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void convFrameHeight(MCFrame f, JComponent addc, Dimension pd) {
/*  56 */     super.convFrameHeight(f, addc, pd);
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getUnreadPushCountE() {
/*  61 */     return super.getUnreadPushCountE();
/*     */   }
/*     */ 
/*     */   
/*     */   protected int getUnreadPushCountI() {
/*  66 */     return super.getUnreadPushCountI();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isEnableAutoLayout(MCPanel p) {
/*  71 */     return super.isEnableAutoLayout(p);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setAnytimeFAction(MCButton b, boolean f) {
/*  76 */     super.setAnytimeFAction(b, f);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setLayoutInitialized(MCRootPanel panel, boolean flg) {
/*  81 */     super.setLayoutInitialized(panel, flg);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setAutoLayoutUseLayoutDebugMode(MCRootPanel panel, boolean flg) {
/*  86 */     super.setAutoLayoutUseLayoutDebugMode(panel, flg);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setAutoLayoutUseAutoLayout(MCRootPanel panel, boolean flg) {
/*  91 */     super.setAutoLayoutUseAutoLayout(panel, flg);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setAutoLayoutGridSize(MCRootPanel panel, int val) {
/*  96 */     super.setAutoLayoutGridSize(panel, val);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setAutolayoutSpaceLabelAndField(MCRootPanel panel, int val) {
/* 101 */     super.setAutolayoutSpaceLabelAndField(panel, val);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setAutolayoutSpaceButtonAndButton(MCRootPanel panel, int val) {
/* 106 */     super.setAutolayoutSpaceButtonAndButton(panel, val);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setAutolayoutUseAlignRight(MCRootPanel panel, boolean flg) {
/* 111 */     super.setAutolayoutUseAlignRight(panel, flg);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setAutolayoutUseCR(MCRootPanel panel, boolean flg) {
/* 116 */     super.setAutolayoutUseCR(panel, flg);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setAutolayoutUseUpdateLabelSize(MCRootPanel panel, boolean flg) {
/* 121 */     super.setAutolayoutUseUpdateLabelSize(panel, flg);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setAutolayoutUseFitLabelSize(MCRootPanel panel, boolean flg) {
/* 126 */     super.setAutolayoutUseFitLabelSize(panel, flg);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setAutolayoutUseFloorGrid(MCRootPanel panel, boolean flg) {
/* 131 */     super.setAutolayoutUseFloorGrid(panel, flg);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setAutolayoutLineGrid(MCRootPanel panel, int val) {
/* 136 */     super.setAutolayoutLineGrid(panel, val);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setAutolayoutUseInvisibleForMode(MCRootPanel panel, boolean flg) {
/* 141 */     super.setAutolayoutUseInvisibleForMode(panel, flg);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setAutolayoutUseCompressPanel(MCRootPanel panel, boolean flg) {
/* 146 */     super.setAutolayoutUseCompressPanel(panel, flg);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setAutolayoutUseUpdateTabOrder(MCRootPanel panel, boolean flg) {
/* 151 */     super.setAutolayoutUseUpdateTabOrder(panel, flg);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setAutolayoutScreenWidth(MCRootPanel panel, int val) {
/* 157 */     super.setAutolayoutScreenWidth(panel, val);
/*     */   }
/*     */   
/*     */   protected void setAutolayoutScreenHeight(MCRootPanel panel, int val) {
/* 161 */     super.setAutolayoutScreenHeight(panel, val);
/*     */   }
/*     */   
/*     */   protected void setAutolayoutPanelWidth(MCRootPanel panel, int val) {
/* 165 */     super.setAutolayoutPanelWidth(panel, val);
/*     */   }
/*     */   
/*     */   protected void setAutolayoutPanelHeight(MCRootPanel panel, int val) {
/* 169 */     super.setAutolayoutPanelHeight(panel, val);
/*     */   }
/*     */   
/*     */   protected void setAutolayoutPanelPrefWidth(MCRootPanel panel, int val) {
/* 173 */     super.setAutolayoutPanelPrefWidth(panel, val);
/*     */   }
/*     */   
/*     */   protected void setAutolayoutPanelPrefHeight(MCRootPanel panel, int val) {
/* 177 */     super.setAutolayoutPanelPrefHeight(panel, val);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected Integer getDefaultDividerSize(MCSplitPane sp) {
/* 183 */     return super.getDefaultDividerSize(sp);
/*     */   }
/*     */   
/*     */   protected MCPersonalizeGroupInfo getInitPersonalizeGroupInfo(MCRootPanel panel) {
/* 187 */     return super.getInitPersonalizeGroupInfo(panel);
/*     */   }
/*     */ 
/*     */   
/*     */   protected String createGUIKey(MCModeBeans compo) {
/* 192 */     return super.createGUIKey(compo);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\layout\MCBeansProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */