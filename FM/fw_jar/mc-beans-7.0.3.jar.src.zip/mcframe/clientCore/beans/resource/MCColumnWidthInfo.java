/*    */ package mcframe.clientCore.beans.resource;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCColumnWidthInfo
/*    */   extends MCPersonalizeInfo
/*    */ {
/*    */   private List<MCColumnWidthData> _column_info_list;
/*    */   
/*    */   public static MCColumnWidthInfo create() {
/* 23 */     return new MCColumnWidthInfo();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setInitFlg(boolean flg) {
/* 45 */     super.setInitFlg(flg);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean getInitFlg() {
/* 50 */     return super.getInitFlg();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setColumnWidthList(List<MCColumnWidthData> list) {
/* 61 */     this._column_info_list = list;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<MCColumnWidthData> getColumnWidthList() {
/* 72 */     return (this._column_info_list != null) ? this._column_info_list : (
/* 73 */       this._column_info_list = new ArrayList<>());
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\resource\MCColumnWidthInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */