/*    */ package mcframe.clientCore.beans.resource;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import mcframe.clientCore.beans.MCRootPanel;
/*    */ import mcframe.clientCore.resource.MCConst;
/*    */ import mcframe.commonCore.resource.ctrl.MCResourceLayerType;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MCPersonalizeGroupResourceIO
/*    */ {
/*    */   public static List<MCPersonalizeGroupInfo> read(MCRootPanel p) {
/* 17 */     List<MCPersonalizeGroupInfo> result = new ArrayList<>();
/*    */     
/* 19 */     String prefix = MCConst.createKey(new String[] { "_0_SCR_", p.getModuleID(), 
/* 20 */           p.getScreenID(), "personalize_group", "list" });
/*    */     
/* 22 */     read(result, MCResourceLayerType.USER, prefix);
/* 23 */     read(result, MCResourceLayerType.EXT, prefix);
/* 24 */     read(result, MCResourceLayerType.SYS, prefix);
/*    */     
/* 26 */     return result;
/*    */   }
/*    */ 
/*    */   
/*    */   private static void read(List<MCPersonalizeGroupInfo> list, MCResourceLayerType type, String prefix) {
/* 31 */     String[] ids = MCConst.app.findPattern(type, String.valueOf(prefix) + ".*"); byte b; int i; String[] arrayOfString1;
/* 32 */     for (i = (arrayOfString1 = ids).length, b = 0; b < i; ) { String id = arrayOfString1[b];
/* 33 */       MCPersonalizeGroupInfo mCPersonalizeGroupInfo = new MCPersonalizeGroupInfo();
/*    */       
/* 35 */       mCPersonalizeGroupInfo.setSettingUnitType(type.toString());
/* 36 */       mCPersonalizeGroupInfo.setSettingInfoID(MCConst.app.getString(MCConst.createKey(new String[] { id, "perGrpID" })));
/* 37 */       mCPersonalizeGroupInfo.setSettingInfoName(
/* 38 */           MCConst.app.getString(MCConst.createKey(new String[] { id, "perGrpNM" })));
/* 39 */       mCPersonalizeGroupInfo.setRemark(MCConst.app.getString(MCConst.createKey(new String[] { id, "remark" })));
/* 40 */       mCPersonalizeGroupInfo.setSearchSettingID(
/* 41 */           MCConst.app.getString(MCConst.createKey(new String[] { id, "searchSettingsID" })));
/* 42 */       mCPersonalizeGroupInfo.setLocationSettingID(
/* 43 */           MCConst.app.getString(MCConst.createKey(new String[] { id, "locationSettingsID" })));
/*    */       
/* 45 */       String[] items = MCConst.app.findPattern(type, String.valueOf(id) + ".*"); byte b1; int j; String[] arrayOfString2;
/* 46 */       for (j = (arrayOfString2 = items).length, b1 = 0; b1 < j; ) { String item = arrayOfString2[b1];
/* 47 */         if (item.startsWith(MCConst.createKey(new String[] { id, "item" }))) {
/* 48 */           String table_id = MCConst.app
/* 49 */             .getString(MCConst.createKey(new String[] { item, "tableID" }));
/* 50 */           mCPersonalizeGroupInfo.setColumnOrderID(table_id, MCConst.app
/* 51 */               .getString(MCConst.createKey(new String[] { item, "columnOrderID" })));
/* 52 */           mCPersonalizeGroupInfo.setSortOrderID(table_id, 
/* 53 */               MCConst.app.getString(MCConst.createKey(new String[] { item, "sortID" })));
/* 54 */           mCPersonalizeGroupInfo.setFilterID(table_id, 
/* 55 */               MCConst.app.getString(MCConst.createKey(new String[] { item, "filterID" })));
/* 56 */           mCPersonalizeGroupInfo.setSignalID(table_id, 
/* 57 */               MCConst.app.getString(MCConst.createKey(new String[] { item, "signalID" })));
/*    */         } 
/*    */         b1++; }
/*    */       
/* 61 */       list.add(mCPersonalizeGroupInfo);
/*    */       b++; }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\resource\MCPersonalizeGroupResourceIO.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */