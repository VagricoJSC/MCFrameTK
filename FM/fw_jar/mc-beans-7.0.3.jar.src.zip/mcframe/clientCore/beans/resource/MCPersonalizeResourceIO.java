/*     */ package mcframe.clientCore.beans.resource;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ import mcframe.clientCore.resource.ctrl.MCGeneralPersonalizeResource;
/*     */ import mcframe.clientCore.resource.ctrl.MCPersonalizeResource;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.resource.ctrl.MCResourceLayerType;
/*     */ import mcframe.commonCore.resource.ctrl.MCWritableResource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MCPersonalizeResourceIO<T extends MCPersonalizeInfo>
/*     */ {
/*     */   static final String PATTERN = "PATTERN";
/*     */   private static final String USER_SETTING_INFO_ID_PREFIX = "user_";
/*     */   private static final String EXT_SETTING_INFO_ID_PREFIX = "ext_";
/*     */   private static final String SYS_SETTING_INFO_ID_PREFIX = "sys_";
/*     */   private static final String BARCODE_SETTING_INFO_ID_PREFIX = "barcode_";
/*     */   public static final String SETTING_INFO_NO_KEY = "setting_info_no";
/*     */   private static final String INFO_KEY = "info";
/*     */   private static final String ORDER_PREFIX = "order_";
/*  99 */   private final List<T> _setting_info_list = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void clearInfo() {
/* 117 */     this._setting_info_list.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void addInfo(T info) {
/* 128 */     this._setting_info_list.add(info);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final List<T> getInfoList() {
/* 139 */     return this._setting_info_list;
/*     */   }
/*     */   
/*     */   public Map<String, Integer> readSettingInfoNOMap(String prefix) {
/* 143 */     return readSettingInfoNOMap(prefix, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public Map<String, Integer> readSettingInfoNOMap(String prefix, String prefixForBarcode) {
/* 148 */     if (prefixForBarcode == null) {
/* 149 */       String str = MCConst.createKey(new String[] { "_0_SCR_", prefix, 
/* 150 */             "setting_info_no" });
/*     */       
/* 152 */       Map<String, Integer> map = new HashMap<>();
/* 153 */       MCResourceLayerType[] arrayOfMCResourceLayerType2 = {
/* 154 */           MCResourceLayerType.USER, MCResourceLayerType.EXT, MCResourceLayerType.SYS }; byte b1; int j;
/*     */       MCResourceLayerType[] arrayOfMCResourceLayerType3;
/* 156 */       for (j = (arrayOfMCResourceLayerType3 = arrayOfMCResourceLayerType2).length, b1 = 0; b1 < j; ) { MCResourceLayerType y = arrayOfMCResourceLayerType3[b1];
/* 157 */         if (containsKey(y, str))
/* 158 */           map.put(y.name(), Integer.valueOf(getString(y, str))); 
/*     */         b1++; }
/*     */       
/* 161 */       return map;
/*     */     } 
/* 163 */     String k = MCConst.createKey(new String[] { "_0_SCR_", prefix, 
/* 164 */           "setting_info_no" });
/*     */     
/* 166 */     String k2 = MCConst.createKey(new String[] { "_0_SCR_", prefixForBarcode, 
/* 167 */           "setting_info_no" });
/*     */     
/* 169 */     Map<String, Integer> m = new HashMap<>();
/* 170 */     MCResourceLayerType[] ya = {
/* 171 */         MCResourceLayerType.USER, MCResourceLayerType.EXT, MCResourceLayerType.SYS, 
/* 172 */         MCResourceLayerType.BARCODE }; byte b; int i;
/*     */     MCResourceLayerType[] arrayOfMCResourceLayerType1;
/* 174 */     for (i = (arrayOfMCResourceLayerType1 = ya).length, b = 0; b < i; ) { MCResourceLayerType y = arrayOfMCResourceLayerType1[b];
/* 175 */       if (MCResourceLayerType.BARCODE.equals(y)) {
/* 176 */         if (containsKey(y, k2)) {
/* 177 */           m.put(y.name(), Integer.valueOf(getString(y, k2)));
/*     */         }
/*     */       }
/* 180 */       else if (containsKey(y, k)) {
/* 181 */         m.put(y.name(), Integer.valueOf(getString(y, k)));
/*     */       } 
/*     */       b++; }
/*     */     
/* 185 */     return m;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void write(String prefix, Map<String, Integer> map) {
/* 198 */     writeImpl(prefix, map, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void writeNoSave(String prefix, Map<String, Integer> map) {
/* 210 */     writeImpl(prefix, map, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void writeImpl(String prefix, Map<String, Integer> map, boolean isSave) {
/* 225 */     boolean save = false;
/*     */     
/* 227 */     List<T> l = getInfoList();
/*     */     
/* 229 */     String y = null;
/* 230 */     String is = null;
/* 231 */     for (MCPersonalizeInfo mCPersonalizeInfo : l) {
/* 232 */       writeResource(prefix, (T)mCPersonalizeInfo);
/* 233 */       if (mCPersonalizeInfo.getInitFlg()) {
/* 234 */         y = mCPersonalizeInfo.getSettingUnitType();
/* 235 */         is = mCPersonalizeInfo.getSettingInfoID();
/*     */       } 
/* 237 */       save = true;
/*     */     } 
/*     */ 
/*     */     
/* 241 */     if (is != null) {
/* 242 */       String k = MCConst.createKey(new String[] { "_0_SCR_", 
/* 243 */             prefix, "init" });
/* 244 */       setString(toResourceLayerType(y), k, is);
/* 245 */       save = true;
/*     */     } 
/*     */     
/* 248 */     if (map != null) {
/* 249 */       String k = MCConst.createKey(new String[] { "_0_SCR_", 
/* 250 */             prefix, "setting_info_no" });
/* 251 */       for (Map.Entry<String, Integer> e : map.entrySet()) {
/* 252 */         setString(toResourceLayerType(e.getKey()), k, ((Integer)e.getValue()).toString());
/*     */       }
/* 254 */       save = true;
/*     */     } 
/*     */     
/* 257 */     if (save && isSave) {
/* 258 */       MCConst.saveResource();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void writeResource(String prefix, T info) {
/* 272 */     String k = MCConst.createKey(new String[] { "_0_SCR_", prefix, 
/* 273 */           info.getSettingInfoID(), "info" });
/* 274 */     String[] va = getSettingInfo(info).<String>toArray(new String[0]);
/* 275 */     setStringArray(toResourceLayerType(info.getSettingUnitType()), k, va);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   List<String> getSettingInfo(T info) {
/* 287 */     List<String> l = new ArrayList<>();
/* 288 */     l.add(info.getSettingInfoName());
/* 289 */     l.add(info.getRemark());
/* 290 */     return l;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String createSettingInfoID(String type, int order) {
/* 303 */     return createSettingInfoID(toResourceLayerType(type), order);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String createSettingInfoID(MCResourceLayerType type, int order) {
/* 316 */     return String.valueOf(getSettingInfoIDPrefix(type)) + String.valueOf(order + 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getSettingInfoIDPrefix(MCResourceLayerType type) {
/* 328 */     if (type == null) {
/* 329 */       return "user_";
/*     */     }
/* 331 */     switch (type) {
/*     */       case USER:
/* 333 */         return "user_";
/*     */       case EXT:
/* 335 */         return "ext_";
/*     */       case SYS:
/* 337 */         return "sys_";
/*     */       case null:
/* 339 */         return "barcode_";
/*     */     } 
/* 341 */     return "user_";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String createOrderKey(int index) {
/* 354 */     return "order_" + String.valueOf(index + 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void read(String prefix) {
/* 371 */     clearInfo();
/*     */     
/* 373 */     setInfo(MCResourceLayerType.USER, getPattern(MCResourceLayerType.USER, prefix), 
/* 374 */         prefix);
/* 375 */     setInfo(MCResourceLayerType.EXT, getPattern(MCResourceLayerType.EXT, prefix), 
/* 376 */         prefix);
/* 377 */     setInfo(MCResourceLayerType.SYS, getPattern(MCResourceLayerType.SYS, prefix), 
/* 378 */         prefix);
/* 379 */     setInfo(MCResourceLayerType.BARCODE, getPattern(MCResourceLayerType.BARCODE, prefix), 
/* 380 */         prefix);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getPattern(MCResourceLayerType type, String prefix) {
/* 393 */     String k = MCConst.createKey(new String[] { "_0_SCR_", prefix, 
/* 394 */           "setting_info_no" });
/* 395 */     if (containsKey(type, k)) {
/* 396 */       return "PATTERN";
/*     */     }
/* 398 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isMatched(String pattern, String[] values) {
/* 411 */     if ("PATTERN".equals(pattern)) {
/* 412 */       return (values != null && values.length == 2);
/*     */     }
/* 414 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setInfo(MCResourceLayerType type, String pattern, String prefix) {
/* 427 */     if ("PATTERN".equals(pattern)) {
/* 428 */       String ik = MCConst.createKey(new String[] { "_0_SCR_", 
/* 429 */             prefix, "init" });
/* 430 */       String iv = getString(type, ik);
/*     */       
/* 432 */       List<String> idl = new ArrayList<>();
/*     */       
/* 434 */       String pfx = MCConst.createKey(new String[] { "_0_SCR_", 
/* 435 */             prefix }); byte b; int i; String[] arrayOfString;
/* 436 */       for (i = (arrayOfString = findPattern(type, String.valueOf(pfx) + ".*")).length, b = 0; b < i; ) { String p = arrayOfString[b];
/* 437 */         String id = p.substring(pfx.length() + 1);
/* 438 */         int v1 = getSettingInfoNO(type, id);
/* 439 */         if (v1 != -1) {
/* 440 */           int j = 0;
/* 441 */           for (; j < idl.size(); j++) {
/* 442 */             int v2 = getSettingInfoNO(type, idl.get(j));
/* 443 */             if (v2 > v1) {
/*     */               break;
/*     */             }
/*     */           } 
/* 447 */           idl.add(j, id);
/*     */         } 
/*     */         b++; }
/*     */       
/* 451 */       for (String id : idl) {
/* 452 */         T f = readInfo(type, pattern, prefix, id);
/* 453 */         if (f == null) {
/*     */           break;
/*     */         }
/* 456 */         f.setInitFlg(id.equals(iv));
/* 457 */         addInfo(f);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   T readInfo(MCResourceLayerType type, String pattern, String prefix, String id) {
/* 474 */     String pk = MCConst.createKey(new String[] { "_0_SCR_", prefix, 
/* 475 */           id });
/* 476 */     String k = MCConst.createKey(new String[] { pk, "info" });
/* 477 */     String[] a = getStringArray(type, k);
/* 478 */     if (isMatched(pattern, a)) {
/* 479 */       T f = createInfo();
/* 480 */       f.setPrefix(pk);
/* 481 */       f.setSettingUnitType(type.toString());
/* 482 */       f.setSettingInfoID(id);
/*     */       
/* 484 */       setSettingInfo(pattern, f, a);
/* 485 */       return f;
/*     */     } 
/* 487 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setSettingInfo(String pattern, T info, String[] values) {
/* 500 */     info.setSettingInfoName(values[0]);
/* 501 */     info.setRemark(values[1]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static <T extends MCPersonalizeInfo> T _getInitInfo(List<T> list) {
/*     */     MCPersonalizeInfo mCPersonalizeInfo1, mCPersonalizeInfo2, mCPersonalizeInfo3;
/* 513 */     T e = null;
/* 514 */     T s = null;
/* 515 */     T b = null;
/* 516 */     for (MCPersonalizeInfo mCPersonalizeInfo : list) {
/* 517 */       if (mCPersonalizeInfo.getInitFlg()) {
/* 518 */         MCResourceLayerType y = toResourceLayerType(mCPersonalizeInfo.getSettingUnitType());
/* 519 */         switch (y) {
/*     */           case USER:
/* 521 */             return (T)mCPersonalizeInfo;
/*     */           case EXT:
/* 523 */             mCPersonalizeInfo1 = mCPersonalizeInfo;
/*     */           
/*     */           case SYS:
/* 526 */             mCPersonalizeInfo2 = mCPersonalizeInfo;
/*     */           
/*     */           case null:
/* 529 */             mCPersonalizeInfo3 = mCPersonalizeInfo;
/*     */         } 
/*     */ 
/*     */ 
/*     */       
/*     */       } 
/*     */     } 
/* 536 */     return (mCPersonalizeInfo1 != null) ? (T)mCPersonalizeInfo1 : ((mCPersonalizeInfo2 != null) ? (T)mCPersonalizeInfo2 : (T)mCPersonalizeInfo3);
/*     */   }
/*     */ 
/*     */   
/*     */   static <T extends MCPersonalizeInfo> T _getInfo(String type, String id, List<T> list) {
/* 541 */     for (MCPersonalizeInfo mCPersonalizeInfo : list) {
/* 542 */       if (type.equals(mCPersonalizeInfo.getSettingUnitType()) && id.equals(mCPersonalizeInfo.getSettingInfoID())) {
/* 543 */         return (T)mCPersonalizeInfo;
/*     */       }
/*     */     } 
/* 546 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCResourceLayerType toResourceLayerType(String type) {
/*     */     byte b;
/*     */     int i;
/*     */     MCResourceLayerType[] arrayOfMCResourceLayerType;
/* 624 */     for (i = (arrayOfMCResourceLayerType = MCResourceLayerType.values()).length, b = 0; b < i; ) { MCResourceLayerType v = arrayOfMCResourceLayerType[b];
/* 625 */       if (v.name().equals(type))
/* 626 */         return v; 
/*     */       b++; }
/*     */     
/* 629 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getSettingInfoNO(String type, String id) {
/* 642 */     return getSettingInfoNO(toResourceLayerType(type), id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getSettingInfoNO(MCResourceLayerType type, String id) {
/* 655 */     if (MCStringUtil.isNull(id)) {
/* 656 */       return -1;
/*     */     }
/* 658 */     String setting_info_id_prefix = getSettingInfoIDPrefix(type);
/* 659 */     if (id.startsWith(setting_info_id_prefix)) {
/* 660 */       return Integer.valueOf(id.substring(setting_info_id_prefix.length())).intValue();
/*     */     }
/* 662 */     if (id.startsWith("user_"))
/*     */     {
/* 664 */       return Integer.valueOf(id.substring("user_".length())).intValue();
/*     */     }
/* 666 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void remove(MCWritableResource wresource, String type, String prefix) {
/* 678 */     MCResourceLayerType y = toResourceLayerType(type);
/* 679 */     if (y != null) {
/* 680 */       remove(wresource, y, prefix, true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void removeNoSave(MCWritableResource wresource, String type, String prefix) {
/* 693 */     MCResourceLayerType y = toResourceLayerType(type);
/* 694 */     if (y != null) {
/* 695 */       remove(wresource, y, prefix, false);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void removeNoSaveById(MCWritableResource wresource, String type, String prefix, String setting_info_id) {
/* 709 */     MCResourceLayerType y = toResourceLayerType(type);
/* 710 */     if (y != null) {
/* 711 */       removeById(wresource, y, prefix, false, setting_info_id);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void remove(MCWritableResource wresource, MCResourceLayerType type, String prefix, boolean doSave) {
/* 727 */     String a[], ka[], pk = MCConst.createKey(new String[] { "_0_SCR_", prefix });
/* 728 */     switch (type) {
/*     */       case USER:
/* 730 */         _remove(wresource, type, new String[] { pk });
/* 731 */         a = _findPattern(wresource, type, String.valueOf(pk) + ".**");
/* 732 */         _remove(wresource, type, a);
/*     */ 
/*     */         
/* 735 */         if (MCResourceLayerType.USER.equals(type)) {
/* 736 */           _remove(wresource, type, new String[] { prefix });
/* 737 */           a = _findPattern(wresource, type, String.valueOf(prefix) + ".**");
/* 738 */           _remove(wresource, type, a);
/*     */         } 
/* 740 */         if (doSave) {
/* 741 */           MCConst.saveResource();
/*     */         }
/*     */         break;
/*     */       case EXT:
/*     */       case SYS:
/*     */       case null:
/* 747 */         if (doSave) {
/* 748 */           _removeExtSysResource(wresource, type, pk);
/*     */           break;
/*     */         } 
/* 751 */         _remove(wresource, type, new String[] { pk });
/* 752 */         ka = _findPattern(wresource, type, String.valueOf(pk) + ".**");
/* 753 */         _remove(wresource, type, ka);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void removeById(MCWritableResource wresource, MCResourceLayerType type, String prefix, boolean doSave, String setting_info_id) {
/* 774 */     String a[], ka[], pk = MCConst.createKey(new String[] { "_0_SCR_", prefix });
/* 775 */     switch (type) {
/*     */       case USER:
/* 777 */         _remove(wresource, type, new String[] { pk });
/* 778 */         a = _findPattern(wresource, type, String.valueOf(pk) + "." + setting_info_id + ".**");
/* 779 */         _remove(wresource, type, a);
/*     */ 
/*     */         
/* 782 */         if (MCResourceLayerType.USER.equals(type)) {
/* 783 */           _remove(wresource, type, new String[] { prefix });
/* 784 */           a = _findPattern(wresource, type, String.valueOf(prefix) + "." + setting_info_id + ".**");
/* 785 */           _remove(wresource, type, a);
/*     */         } 
/* 787 */         if (doSave) {
/* 788 */           MCConst.saveResource();
/*     */         }
/*     */         break;
/*     */       case EXT:
/*     */       case SYS:
/*     */       case null:
/* 794 */         if (doSave) {
/* 795 */           _removeExtSysResource(wresource, type, pk);
/*     */           break;
/*     */         } 
/* 798 */         _remove(wresource, type, new String[] { pk });
/* 799 */         ka = _findPattern(wresource, type, String.valueOf(pk) + ".**");
/* 800 */         _remove(wresource, type, ka);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void removeInitResourceById(MCWritableResource wresource, String stype, String prefix, String setting_info_id) {
/* 820 */     String initk = MCConst.createKey(new String[] { "_0_SCR_", 
/* 821 */           prefix, "init" });
/* 822 */     MCResourceLayerType type = toResourceLayerType(stype);
/* 823 */     if (type != null) {
/* 824 */       String initv = getString(type, initk);
/* 825 */       if (initv != null && initv.equals(setting_info_id)) {
/* 826 */         _remove(wresource, type, new String[] { initk });
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void saveResource() {
/*     */     try {
/* 839 */       MCConst.saveResource();
/*     */     }
/* 841 */     catch (Exception e) {
/* 842 */       MCConst.commitResource();
/* 843 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void _remove(MCWritableResource wresource, MCResourceLayerType type, String... keys) {
/* 849 */     if (wresource instanceof MCGeneralPersonalizeResource) {
/* 850 */       ((MCGeneralPersonalizeResource)wresource).remove(type, keys);
/*     */     }
/* 852 */     else if (wresource instanceof MCPersonalizeResource) {
/* 853 */       ((MCPersonalizeResource)wresource).remove(type, keys);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static String[] _findPattern(MCWritableResource wresource, MCResourceLayerType type, String pattern) {
/* 859 */     if (wresource instanceof MCGeneralPersonalizeResource) {
/* 860 */       return ((MCGeneralPersonalizeResource)wresource).findPattern(type, pattern);
/*     */     }
/* 862 */     if (wresource instanceof MCPersonalizeResource) {
/* 863 */       return ((MCPersonalizeResource)wresource).findPattern(type, pattern);
/*     */     }
/* 865 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private static void _removeExtSysResource(MCWritableResource wresource, MCResourceLayerType type, String pk) {
/* 870 */     if (wresource instanceof MCGeneralPersonalizeResource) {
/* 871 */       MCConst.removeResource((MCGeneralPersonalizeResource)wresource, type, pk);
/*     */     }
/* 873 */     else if (wresource instanceof MCPersonalizeResource) {
/* 874 */       MCConst.removeResource((MCPersonalizeResource)wresource, type, pk);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getPersonalizedKeyPrefix(MCRootPanel p, String key) {
/* 888 */     return MCConst.createKey(new String[] { p.getModuleID(), p.getScreenID(), key });
/*     */   }
/*     */   
/*     */   abstract T createInfo();
/*     */   
/*     */   abstract boolean containsKey(MCResourceLayerType paramMCResourceLayerType, String paramString);
/*     */   
/*     */   abstract String getString(MCResourceLayerType paramMCResourceLayerType, String paramString);
/*     */   
/*     */   abstract String[] getStringArray(MCResourceLayerType paramMCResourceLayerType, String paramString);
/*     */   
/*     */   abstract void setString(MCResourceLayerType paramMCResourceLayerType, String paramString1, String paramString2);
/*     */   
/*     */   abstract void setStringArray(MCResourceLayerType paramMCResourceLayerType, String paramString, String[] paramArrayOfString);
/*     */   
/*     */   abstract String[] findPattern(MCResourceLayerType paramMCResourceLayerType, String paramString);
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\resource\MCPersonalizeResourceIO.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */