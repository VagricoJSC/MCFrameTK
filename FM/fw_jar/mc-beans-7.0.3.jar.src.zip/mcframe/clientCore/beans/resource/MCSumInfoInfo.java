/*    */ package mcframe.clientCore.beans.resource;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCSumInfoInfo
/*    */   extends MCPersonalizeInfo
/*    */ {
/*    */   private List<MCSumInfoData> _sum_info_list;
/*    */   
/*    */   public static MCSumInfoInfo create() {
/* 23 */     return new MCSumInfoInfo();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setInitFlg(boolean flg) {
/* 45 */     super.setInitFlg(flg);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean getInitFlg() {
/* 50 */     return super.getInitFlg();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setSumInfoList(List<MCSumInfoData> list) {
/* 61 */     this._sum_info_list = list;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<MCSumInfoData> getSumInfoList() {
/* 72 */     return (this._sum_info_list != null) ? this._sum_info_list : (
/* 73 */       this._sum_info_list = new ArrayList<>());
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\resource\MCSumInfoInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */