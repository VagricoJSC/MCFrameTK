/*     */ package mcframe.clientCore.beans.resource;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import mcframe.clientCore.beans.table.MCTable;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ import mcframe.commonCore.lang.MCDataType;
/*     */ import mcframe.commonCore.resource.ctrl.MCResourceLayerType;
/*     */ import mcframe.commonCore.resource.ctrl.MCWritableResource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MCRowFilterResourceIO
/*     */   extends MCPersonalizeResourceIO<MCRowFilterInfo>
/*     */ {
/*     */   MCRowFilterInfo createInfo() {
/*  45 */     return MCRowFilterInfo.create();
/*     */   }
/*     */ 
/*     */   
/*     */   boolean containsKey(MCResourceLayerType type, String key) {
/*  50 */     return MCConst.beans.containsKey(type, key);
/*     */   }
/*     */ 
/*     */   
/*     */   String getString(MCResourceLayerType type, String key) {
/*  55 */     return MCConst.beans.getString(type, key);
/*     */   }
/*     */ 
/*     */   
/*     */   String[] getStringArray(MCResourceLayerType type, String key) {
/*  60 */     return MCConst.beans.getStringArray(type, key);
/*     */   }
/*     */ 
/*     */   
/*     */   void setString(MCResourceLayerType type, String key, String value) {
/*  65 */     MCConst.beans.setString(type, key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   void setStringArray(MCResourceLayerType type, String key, String[] value) {
/*  70 */     MCConst.beans.setStringArray(type, key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   String[] findPattern(MCResourceLayerType type, String pattern) {
/*  75 */     return MCConst.beans.findPattern(type, pattern);
/*     */   }
/*     */ 
/*     */   
/*     */   public void read(String prefix) {
/*  80 */     super.read(prefix);
/*     */   }
/*     */ 
/*     */   
/*     */   void setInfo(MCResourceLayerType type, String pattern, String prefix) {
/*  85 */     super.setInfo(type, pattern, prefix);
/*     */     
/*  87 */     if ("PATTERN".equals(pattern)) {
/*  88 */       List<MCRowFilterInfo> l = getInfoList();
/*  89 */       if (l.size() == 0) {
/*     */         return;
/*     */       }
/*  92 */       for (MCRowFilterInfo f : l) {
/*  93 */         if (!type.equals(toResourceLayerType(f.getSettingUnitType()))) {
/*     */           continue;
/*     */         }
/*     */         
/*  97 */         List<MCRowFilterData> dl = new ArrayList<>();
/*  98 */         int i = 0;
/*     */         while (true) {
/* 100 */           String k = MCConst.createKey(new String[] { f.getPrefix(), createOrderKey(i++) });
/* 101 */           String[] a = getStringArray(type, k);
/* 102 */           if (a == null || a.length != 6) {
/*     */             break;
/*     */           }
/* 105 */           MCRowFilterData d = new MCRowFilterData();
/* 106 */           d.setColumnName(a[0]);
/* 107 */           d.setDataType(MCDataType.valueOf(a[1]));
/* 108 */           d.setConditionValue(a[2]);
/* 109 */           d.setRelativeOperator(a[3]);
/* 110 */           d.setLogicOperator(a[4]);
/* 111 */           d.setDisable(Boolean.valueOf(a[5]).booleanValue());
/* 112 */           dl.add(d);
/*     */         } 
/* 114 */         f.setRowFilterList(dl);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void writeResource(String prefix, MCRowFilterInfo info) {
/* 121 */     super.writeResource(prefix, info);
/*     */     
/* 123 */     List<MCRowFilterData> l = info.getRowFilterList();
/*     */ 
/*     */ 
/*     */     
/* 127 */     if (l == null) {
/*     */       return;
/*     */     }
/*     */     
/* 131 */     String pk = MCConst.createKey(new String[] { "_0_SCR_", prefix, 
/* 132 */           info.getSettingInfoID() });
/* 133 */     for (int i = 0; i < l.size(); i++) {
/* 134 */       String k = MCConst.createKey(new String[] { pk, createOrderKey(i) });
/*     */       
/* 136 */       MCRowFilterData f = l.get(i);
/* 137 */       String v1 = f.getColumnName();
/* 138 */       String v2 = f.getDataType().name();
/* 139 */       String v3 = f.getConditionValue();
/* 140 */       String v4 = f.getRelativeOperator();
/* 141 */       String v5 = f.getLogicOperator();
/* 142 */       String v6 = String.valueOf(f.isDisable());
/*     */       
/* 144 */       String[] va = {
/* 145 */           v1, v2, (v3 != null) ? v3 : "", (v4 != null) ? v4 : "", 
/* 146 */           (v5 != null) ? v5 : "", v6
/*     */         };
/* 148 */       setStringArray(toResourceLayerType(info.getSettingUnitType()), k, va);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void remove(String type, String prefix) {
/* 161 */     remove((MCWritableResource)MCConst.beans, type, prefix);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removeNoSave(String type, String prefix) {
/* 173 */     removeNoSave((MCWritableResource)MCConst.beans, type, prefix);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removeNoSaveById(String type, String prefix, String setting_info_id) {
/* 186 */     removeNoSaveById((MCWritableResource)MCConst.beans, type, prefix, setting_info_id);
/*     */   }
/*     */   
/*     */   public static boolean isSearchedProgram(String type, String pgmid) {
/* 190 */     return MCConst.beans.isSearchedProgram(toResourceLayerType(type), pgmid);
/*     */   }
/*     */ 
/*     */   
/*     */   public static MCRowFilterInfo getInfo(String type, String id, List<MCRowFilterInfo> list) {
/* 195 */     return _getInfo(type, id, list);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String createPrefix(String module_id, String screen_id, String table_nm) {
/* 210 */     return MCTable.getPersonalizedKeyPrefix(module_id, screen_id, table_nm, 
/* 211 */         "ROW_FILTER_PANEL", null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCRowFilterInfo readInfo(String module_id, String screen_id, String table_nm, String id) {
/* 225 */     String prefix = createPrefix(module_id, screen_id, table_nm);
/* 226 */     MCRowFilterResourceIO cio = new MCRowFilterResourceIO(); byte b; int i; MCResourceLayerType[] arrayOfMCResourceLayerType;
/* 227 */     for (i = (arrayOfMCResourceLayerType = MCResourceLayerType.values()).length, b = 0; b < i; ) { MCResourceLayerType type = arrayOfMCResourceLayerType[b];
/* 228 */       String pattern = cio.getPattern(type, prefix);
/* 229 */       MCRowFilterInfo info = cio.readInfo(type, pattern, prefix, id);
/* 230 */       if (info != null)
/* 231 */         return info; 
/*     */       b++; }
/*     */     
/* 234 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<MCRowFilterInfo> readInfo(String module_id, String screen_id, String table_nm) {
/* 247 */     MCRowFilterResourceIO cio = new MCRowFilterResourceIO();
/* 248 */     cio.read(createPrefix(module_id, screen_id, table_nm));
/* 249 */     return cio.getInfoList();
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\resource\MCRowFilterResourceIO.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */