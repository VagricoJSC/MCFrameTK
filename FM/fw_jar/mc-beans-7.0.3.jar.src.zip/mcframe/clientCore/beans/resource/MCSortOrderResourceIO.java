/*     */ package mcframe.clientCore.beans.resource;
/*     */ 
/*     */ import java.util.List;
/*     */ import mcframe.clientCore.beans.table.MCTable;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCSortPolicy;
/*     */ import mcframe.commonCore.resource.ctrl.MCResourceLayerType;
/*     */ import mcframe.commonCore.resource.ctrl.MCWritableResource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MCSortOrderResourceIO
/*     */   extends MCPersonalizeResourceIO<MCSortOrderInfo>
/*     */ {
/*     */   MCSortOrderInfo createInfo() {
/*  45 */     return MCSortOrderInfo.create();
/*     */   }
/*     */ 
/*     */   
/*     */   boolean containsKey(MCResourceLayerType type, String key) {
/*  50 */     return MCConst.beans.containsKey(type, key);
/*     */   }
/*     */ 
/*     */   
/*     */   String getString(MCResourceLayerType type, String key) {
/*  55 */     return MCConst.beans.getString(type, key);
/*     */   }
/*     */ 
/*     */   
/*     */   String[] getStringArray(MCResourceLayerType type, String key) {
/*  60 */     return MCConst.beans.getStringArray(type, key);
/*     */   }
/*     */ 
/*     */   
/*     */   void setString(MCResourceLayerType type, String key, String value) {
/*  65 */     MCConst.beans.setString(type, key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   void setStringArray(MCResourceLayerType type, String key, String[] value) {
/*  70 */     MCConst.beans.setStringArray(type, key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   String[] findPattern(MCResourceLayerType type, String pattern) {
/*  75 */     return MCConst.beans.findPattern(type, pattern);
/*     */   }
/*     */ 
/*     */   
/*     */   public void read(String prefix) {
/*  80 */     super.read(prefix);
/*     */   }
/*     */ 
/*     */   
/*     */   void setInfo(MCResourceLayerType type, String pattern, String prefix) {
/*  85 */     super.setInfo(type, pattern, prefix);
/*     */     
/*  87 */     if ("PATTERN".equals(pattern)) {
/*  88 */       List<MCSortOrderInfo> l = getInfoList();
/*  89 */       if (l.size() == 0) {
/*     */         return;
/*     */       }
/*  92 */       for (MCSortOrderInfo f : l) {
/*  93 */         if (!type.equals(toResourceLayerType(f.getSettingUnitType()))) {
/*     */           continue;
/*     */         }
/*     */         
/*  97 */         int i = 0;
/*  98 */         MCSortPolicy sp = new MCSortPolicy();
/*     */         while (true) {
/* 100 */           String k = MCConst.createKey(new String[] { f.getPrefix(), createOrderKey(i++) });
/* 101 */           String[] a = getStringArray(type, k);
/* 102 */           if (a == null || a.length != 2) {
/*     */             break;
/*     */           }
/* 105 */           sp.add(MCList.SortType.valueOf(a[1]), a[0]);
/*     */         } 
/* 107 */         f.setSortPolicy(sp);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void writeResource(String prefix, MCSortOrderInfo info) {
/* 114 */     super.writeResource(prefix, info);
/*     */ 
/*     */ 
/*     */     
/* 118 */     MCSortPolicy p = info.getSortPolicy();
/* 119 */     if (p == null) {
/*     */       return;
/*     */     }
/*     */     
/* 123 */     String[] na = p.nameArray();
/* 124 */     MCList.SortType[] ya = p.typeArray();
/* 125 */     for (int i = 0; i < na.length; i++) {
/* 126 */       String k = MCConst.createKey(new String[] { "_0_SCR_", 
/* 127 */             prefix, info.getSettingInfoID(), createOrderKey(i) });
/* 128 */       String[] va = {
/* 129 */           na[i], String.valueOf(ya[i])
/*     */         };
/* 131 */       setStringArray(toResourceLayerType(info.getSettingUnitType()), k, va);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void remove(String type, String prefix) {
/* 144 */     remove((MCWritableResource)MCConst.beans, type, prefix);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removeNoSave(String type, String prefix) {
/* 156 */     removeNoSave((MCWritableResource)MCConst.beans, type, prefix);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removeNoSaveById(String type, String prefix, String setting_info_id) {
/* 169 */     removeNoSaveById((MCWritableResource)MCConst.beans, type, prefix, setting_info_id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeInitResourceById(String type, String prefix, String setting_info_id) {
/* 182 */     removeInitResourceById((MCWritableResource)MCConst.beans, type, prefix, setting_info_id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCSortOrderInfo getInitInfo(List<MCSortOrderInfo> list) {
/* 194 */     return _getInitInfo(list);
/*     */   }
/*     */   
/*     */   public static boolean isSearchedProgram(String type, String pgmid) {
/* 198 */     return MCConst.beans.isSearchedProgram(toResourceLayerType(type), pgmid);
/*     */   }
/*     */ 
/*     */   
/*     */   public static MCSortOrderInfo getInfo(String type, String id, List<MCSortOrderInfo> list) {
/* 203 */     return _getInfo(type, id, list);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String createPrefix(String module_id, String screen_id, String table_nm) {
/* 218 */     return MCTable.getPersonalizedKeyPrefix(module_id, screen_id, table_nm, 
/* 219 */         "SORT_ORDER_PANEL", null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCSortOrderInfo readInfo(String module_id, String screen_id, String table_nm, String id) {
/* 233 */     String prefix = createPrefix(module_id, screen_id, table_nm);
/* 234 */     MCSortOrderResourceIO cio = new MCSortOrderResourceIO(); byte b; int i; MCResourceLayerType[] arrayOfMCResourceLayerType;
/* 235 */     for (i = (arrayOfMCResourceLayerType = MCResourceLayerType.values()).length, b = 0; b < i; ) { MCResourceLayerType type = arrayOfMCResourceLayerType[b];
/* 236 */       String pattern = cio.getPattern(type, prefix);
/* 237 */       MCSortOrderInfo info = cio.readInfo(type, pattern, prefix, id);
/* 238 */       if (info != null)
/* 239 */         return info; 
/*     */       b++; }
/*     */     
/* 242 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<MCSortOrderInfo> readInfo(String module_id, String screen_id, String table_nm) {
/* 255 */     MCSortOrderResourceIO cio = new MCSortOrderResourceIO();
/* 256 */     cio.read(createPrefix(module_id, screen_id, table_nm));
/* 257 */     return cio.getInfoList();
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\resource\MCSortOrderResourceIO.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */