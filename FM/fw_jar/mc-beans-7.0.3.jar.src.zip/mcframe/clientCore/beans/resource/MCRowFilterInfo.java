/*    */ package mcframe.clientCore.beans.resource;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCRowFilterInfo
/*    */   extends MCPersonalizeInfo
/*    */ {
/*    */   private List<MCRowFilterData> _row_filter_list;
/*    */   
/*    */   public static MCRowFilterInfo create() {
/* 23 */     return new MCRowFilterInfo();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setRowFilterList(List<MCRowFilterData> list) {
/* 51 */     this._row_filter_list = list;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<MCRowFilterData> getRowFilterList() {
/* 62 */     return (this._row_filter_list != null) ? this._row_filter_list : (
/* 63 */       this._row_filter_list = new ArrayList<>());
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\resource\MCRowFilterInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */