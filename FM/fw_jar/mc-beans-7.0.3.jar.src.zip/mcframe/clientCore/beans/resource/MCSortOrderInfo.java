/*    */ package mcframe.clientCore.beans.resource;
/*    */ 
/*    */ import mcframe.commonCore.container.MCSortPolicy;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCSortOrderInfo
/*    */   extends MCPersonalizeInfo
/*    */ {
/*    */   private MCSortPolicy _sort_policy;
/*    */   
/*    */   public static MCSortOrderInfo create() {
/* 22 */     return new MCSortOrderInfo();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setInitFlg(boolean flg) {
/* 43 */     super.setInitFlg(flg);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean getInitFlg() {
/* 48 */     return super.getInitFlg();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setSortPolicy(MCSortPolicy policy) {
/* 59 */     this._sort_policy = policy;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MCSortPolicy getSortPolicy() {
/* 70 */     return this._sort_policy;
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\resource\MCSortOrderInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */