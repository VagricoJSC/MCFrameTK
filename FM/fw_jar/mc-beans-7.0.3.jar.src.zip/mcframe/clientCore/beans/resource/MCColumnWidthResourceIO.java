/*     */ package mcframe.clientCore.beans.resource;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import mcframe.clientCore.beans.table.MCTable;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.resource.ctrl.MCResourceLayerType;
/*     */ import mcframe.commonCore.resource.ctrl.MCWritableResource;
/*     */ import mcframe.commonCore.util.MCCollectionUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MCColumnWidthResourceIO
/*     */   extends MCPersonalizeResourceIO<MCColumnWidthInfo>
/*     */ {
/*     */   public static final String TYPE_ORDER = "order";
/*     */   public static final String TYPE_WIDTH = "width";
/*     */   public static final String TYPE_VISIBLE = "visible";
/*     */   public static final String TYPE_ADJUSTWIDTH = "adjustwidth";
/*     */   public static final String TYPE_UNSCROLL = "unscroll";
/*     */   public static final String TYPE_RETURN = "return";
/*     */   public static final String TYPE_FOCUS = "focus";
/*     */   public static final String TYPE_SIZE = "size";
/*     */   
/*     */   MCColumnWidthInfo createInfo() {
/* 108 */     return MCColumnWidthInfo.create();
/*     */   }
/*     */ 
/*     */   
/*     */   boolean containsKey(MCResourceLayerType type, String key) {
/* 113 */     return MCConst.layout.containsKey(type, key);
/*     */   }
/*     */ 
/*     */   
/*     */   String getString(MCResourceLayerType type, String key) {
/* 118 */     return MCConst.layout.getString(type, key);
/*     */   }
/*     */ 
/*     */   
/*     */   String[] getStringArray(MCResourceLayerType type, String key) {
/* 123 */     return MCConst.layout.getStringArray(type, key);
/*     */   }
/*     */ 
/*     */   
/*     */   void setString(MCResourceLayerType type, String key, String value) {
/* 128 */     MCConst.layout.setString(type, key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   void setStringArray(MCResourceLayerType type, String key, String[] value) {
/* 133 */     MCConst.layout.setStringArray(type, key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   String[] findPattern(MCResourceLayerType type, String pattern) {
/* 138 */     return MCConst.layout.findPattern(type, pattern);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String createPrefix(String module_id, String screen_id, String table_nm, MCResourceLayerType rtype) {
/* 154 */     return MCTable.getPersonalizedKeyPrefix(module_id, screen_id, table_nm, 
/* 155 */         "COLUMN_WIDTH_PANEL", rtype);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCColumnWidthInfo readInfo(String module_id, String screen_id, String table_nm, String id) {
/* 169 */     MCColumnWidthResourceIO cio = new MCColumnWidthResourceIO(); byte b; int i;
/*     */     MCResourceLayerType[] arrayOfMCResourceLayerType;
/* 171 */     for (i = (arrayOfMCResourceLayerType = MCResourceLayerType.values()).length, b = 0; b < i; ) { MCResourceLayerType type = arrayOfMCResourceLayerType[b];
/* 172 */       String prefix = createPrefix(module_id, screen_id, table_nm, type);
/* 173 */       String pattern = cio.getPattern(type, prefix);
/* 174 */       MCColumnWidthInfo info = cio.readInfo(type, pattern, prefix, id);
/* 175 */       if (info != null)
/* 176 */         return info; 
/*     */       b++; }
/*     */     
/* 179 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<MCColumnWidthInfo> readInfo(String module_id, String screen_id, String table_nm) {
/* 192 */     MCColumnWidthResourceIO cio = new MCColumnWidthResourceIO();
/* 193 */     cio.read(createPrefix(module_id, screen_id, table_nm, (MCResourceLayerType)null));
/* 194 */     List<MCColumnWidthInfo> list1 = cio.getInfoList();
/*     */     
/* 196 */     MCColumnWidthResourceIO cio2 = new MCColumnWidthResourceIO();
/* 197 */     cio2.read(createPrefix(module_id, screen_id, table_nm, MCResourceLayerType.BARCODE));
/* 198 */     List<MCColumnWidthInfo> list2 = cio2.getInfoList();
/*     */     
/* 200 */     list1.addAll(list2);
/* 201 */     return list1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void read(String prefix, String... names) {
/* 213 */     clearInfo();
/*     */     
/* 215 */     setInfo(MCResourceLayerType.USER, getPattern(MCResourceLayerType.USER, prefix), 
/* 216 */         prefix, names);
/* 217 */     setInfo(MCResourceLayerType.EXT, getPattern(MCResourceLayerType.EXT, prefix), 
/* 218 */         prefix, names);
/* 219 */     setInfo(MCResourceLayerType.SYS, getPattern(MCResourceLayerType.SYS, prefix), 
/* 220 */         prefix, names);
/* 221 */     setInfo(MCResourceLayerType.BARCODE, getPattern(MCResourceLayerType.BARCODE, prefix), 
/* 222 */         prefix, names);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setInfo(MCResourceLayerType type, String pattern, String prefix, String... names) {
/* 237 */     setInfo(type, pattern, prefix);
/*     */     
/* 239 */     if ("PATTERN".equals(pattern)) {
/* 240 */       List<MCColumnWidthInfo> l = getInfoList();
/* 241 */       if (l.size() == 0) {
/*     */         return;
/*     */       }
/* 244 */       for (MCColumnWidthInfo f : l) {
/* 245 */         if (!type.equals(toResourceLayerType(f.getSettingUnitType()))) {
/*     */           continue;
/*     */         }
/*     */         
/* 249 */         int i = -1;
/* 250 */         List<MCColumnWidthData> dl = new ArrayList<>();
/*     */         while (true) {
/* 252 */           String k = MCConst.createKey(new String[] { f.getPrefix(), createOrderKey(++i) });
/* 253 */           String[] a = getStringArray(type, k);
/* 254 */           if (a == null) {
/*     */             break;
/*     */           }
/*     */           
/* 258 */           if (!MCCollectionUtil.contains(a[0], (Object[])names)) {
/*     */             continue;
/*     */           }
/*     */           
/* 262 */           MCColumnWidthData d = new MCColumnWidthData();
/* 263 */           d.setColumnOrder(i);
/* 264 */           d.setColumnName(a[0]);
/* 265 */           if (!MCStringUtil.isNull(a[1])) {
/* 266 */             d.setColumnWidth(Integer.valueOf(a[1]).intValue());
/*     */           }
/* 268 */           if (!MCStringUtil.isNull(a[2])) {
/* 269 */             d.setColumnVisible(Boolean.valueOf(a[2]).booleanValue());
/*     */           }
/* 271 */           if (!MCStringUtil.isNull(a[3])) {
/* 272 */             d.setColumnAdjustWidth(Boolean.valueOf(a[3]).booleanValue());
/*     */           }
/* 274 */           if (!MCStringUtil.isNull(a[4])) {
/* 275 */             d.setUnscrollColumn(Boolean.valueOf(a[4]).booleanValue());
/*     */           }
/* 277 */           if (!MCStringUtil.isNull(a[5])) {
/* 278 */             d.setReturnColumn(Boolean.valueOf(a[5]).booleanValue());
/*     */           }
/*     */           
/* 281 */           if (a.length >= 7) {
/* 282 */             if (!MCStringUtil.isNull(a[6])) {
/* 283 */               d.setFocusColumn(Boolean.valueOf(a[6]).booleanValue());
/*     */             }
/* 285 */             if (a.length >= 8 && 
/* 286 */               !MCStringUtil.isNull(a[7])) {
/* 287 */               d.setColumnSize(Integer.valueOf(a[7]).intValue());
/*     */             }
/*     */ 
/*     */             
/* 291 */             if (a.length >= 9 && 
/* 292 */               !MCStringUtil.isNull(a[8])) {
/* 293 */               d.setRequiredColumn(Boolean.valueOf(a[8]).booleanValue());
/*     */             }
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 299 */           dl.add(d);
/*     */         } 
/*     */         
/* 302 */         if (dl.size() > 0) {
/* 303 */           f.setColumnWidthList(dl);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void writeResource(String prefix, MCColumnWidthInfo info) {
/* 311 */     super.writeResource(prefix, info);
/*     */     
/* 313 */     List<MCColumnWidthData> l = info.getColumnWidthList();
/* 314 */     if (l == null) {
/*     */       return;
/*     */     }
/*     */     
/* 318 */     for (MCColumnWidthData d : l) {
/* 319 */       String k = MCConst.createKey(new String[] { "_0_SCR_", 
/* 320 */             prefix, info.getSettingInfoID(), createOrderKey(d.getColumnOrder().intValue()) });
/* 321 */       String v1 = d.getColumnName();
/* 322 */       Integer w = d.getColumnWidth();
/* 323 */       String v2 = (w != null) ? String.valueOf(w.intValue()) : "";
/* 324 */       Boolean v = d.getColumnVisible();
/* 325 */       String v3 = (v != null) ? String.valueOf(v.booleanValue()) : "";
/* 326 */       Boolean a = d.getColumnAdjustWidth();
/* 327 */       String v4 = (a != null) ? String.valueOf(a.booleanValue()) : "";
/* 328 */       Boolean u = d.getUnscrollColumn();
/* 329 */       String v5 = (u != null) ? String.valueOf(u.booleanValue()) : "";
/* 330 */       Boolean r = d.getReturnColumn();
/* 331 */       String v6 = (r != null) ? String.valueOf(r.booleanValue()) : "";
/*     */       
/* 333 */       Boolean f = d.getFocusColumn();
/* 334 */       String v7 = (f != null) ? String.valueOf(f.booleanValue()) : "";
/* 335 */       Integer s = Integer.valueOf(d.getColumnSize());
/* 336 */       String v8 = (s != null) ? String.valueOf(s.intValue()) : "";
/*     */ 
/*     */ 
/*     */       
/* 340 */       Boolean rc = d.getRequiredColumn();
/* 341 */       String v9 = (rc != null) ? String.valueOf(rc.booleanValue()) : "";
/*     */       
/* 343 */       String[] va = {
/* 344 */           v1, v2, v3, v4, v5, v6, v7, v8, v9
/*     */         };
/*     */ 
/*     */       
/* 348 */       setStringArray(toResourceLayerType(info.getSettingUnitType()), k, va);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void remove(String type, String prefix) {
/* 361 */     remove((MCWritableResource)MCConst.layout, type, prefix);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removeNoSave(String type, String prefix) {
/* 373 */     removeNoSave((MCWritableResource)MCConst.layout, type, prefix);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removeNoSaveById(String type, String prefix, String setting_info_id) {
/* 386 */     removeNoSaveById((MCWritableResource)MCConst.layout, type, prefix, setting_info_id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeInitResourceById(String type, String prefix, String setting_info_id) {
/* 400 */     removeInitResourceById((MCWritableResource)MCConst.layout, type, prefix, setting_info_id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCColumnWidthInfo getInitInfo(List<MCColumnWidthInfo> list) {
/* 412 */     return _getInitInfo(list);
/*     */   }
/*     */   
/*     */   public static boolean isSearchedProgram(String type, String pgmid) {
/* 416 */     return MCConst.layout.isSearchedProgram(toResourceLayerType(type), pgmid);
/*     */   }
/*     */ 
/*     */   
/*     */   public static MCColumnWidthInfo getInfo(String type, String id, List<MCColumnWidthInfo> list) {
/* 421 */     return _getInfo(type, id, list);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\resource\MCColumnWidthResourceIO.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */