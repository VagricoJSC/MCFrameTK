/*     */ package mcframe.clientCore.beans.resource;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MCPersonalizeGroupInfo
/*     */   extends MCPersonalizeInfo
/*     */ {
/*     */   private String _search_setting_id;
/*     */   private String _location_setting_id;
/*     */   private Map<String, MCPersonalizeGroupTableInfo> _table_info_map;
/*     */   
/*     */   void setSearchSettingID(String id) {
/*  34 */     this._search_setting_id = id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSearchSettingID() {
/*  45 */     return this._search_setting_id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setLocationSettingID(String id) {
/*  56 */     this._location_setting_id = id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getLocationSettingID() {
/*  67 */     return this._location_setting_id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, MCPersonalizeGroupTableInfo> getTableInfoMap() {
/*  78 */     return (this._table_info_map != null) ? this._table_info_map : (
/*  79 */       this._table_info_map = new HashMap<>());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setColumnOrderID(String table_id, String id) {
/*  91 */     MCPersonalizeGroupTableInfo i = getTableInfoMap().get(table_id);
/*  92 */     if (i == null) {
/*  93 */       getTableInfoMap().put(table_id, i = new MCPersonalizeGroupTableInfo(null));
/*     */     }
/*  95 */     i.setColumnOrderID(id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getColumnOrderID(String table_id) {
/* 107 */     MCPersonalizeGroupTableInfo i = getTableInfoMap().get(table_id);
/* 108 */     return (i != null) ? i.getColumnOrderID() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setSortOrderID(String table_id, String id) {
/* 120 */     MCPersonalizeGroupTableInfo i = getTableInfoMap().get(table_id);
/* 121 */     if (i == null) {
/* 122 */       getTableInfoMap().put(table_id, i = new MCPersonalizeGroupTableInfo(null));
/*     */     }
/* 124 */     i.setSortOrderID(id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSortOrderID(String table_id) {
/* 136 */     MCPersonalizeGroupTableInfo i = getTableInfoMap().get(table_id);
/* 137 */     return (i != null) ? i.getSortOrderID() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setFilterID(String table_id, String id) {
/* 149 */     MCPersonalizeGroupTableInfo i = getTableInfoMap().get(table_id);
/* 150 */     if (i == null) {
/* 151 */       getTableInfoMap().put(table_id, i = new MCPersonalizeGroupTableInfo(null));
/*     */     }
/* 153 */     i.setFilterID(id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFilterID(String table_id) {
/* 165 */     MCPersonalizeGroupTableInfo i = getTableInfoMap().get(table_id);
/* 166 */     return (i != null) ? i.getFilterID() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setSignalID(String table_id, String id) {
/* 178 */     MCPersonalizeGroupTableInfo i = getTableInfoMap().get(table_id);
/* 179 */     if (i == null) {
/* 180 */       getTableInfoMap().put(table_id, i = new MCPersonalizeGroupTableInfo(null));
/*     */     }
/* 182 */     i.setSignalID(id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSignalID(String table_id) {
/* 194 */     MCPersonalizeGroupTableInfo i = getTableInfoMap().get(table_id);
/* 195 */     return (i != null) ? i.getSignalID() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final class MCPersonalizeGroupTableInfo
/*     */   {
/*     */     private String _column_order_id;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String _sort_order_id;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String _filter_id;
/*     */ 
/*     */ 
/*     */     
/*     */     private String _signal_id;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private MCPersonalizeGroupTableInfo() {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void setColumnOrderID(String id) {
/* 229 */       this._column_order_id = id;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getColumnOrderID() {
/* 240 */       return this._column_order_id;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void setSortOrderID(String id) {
/* 251 */       this._sort_order_id = id;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getSortOrderID() {
/* 262 */       return this._sort_order_id;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void setFilterID(String id) {
/* 273 */       this._filter_id = id;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getFilterID() {
/* 284 */       return this._filter_id;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void setSignalID(String id) {
/* 295 */       this._signal_id = id;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getSignalID() {
/* 306 */       return this._signal_id;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\resource\MCPersonalizeGroupInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */