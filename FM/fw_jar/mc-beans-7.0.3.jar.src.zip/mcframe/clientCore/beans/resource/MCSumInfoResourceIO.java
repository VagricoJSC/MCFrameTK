/*     */ package mcframe.clientCore.beans.resource;
/*     */ 
/*     */ import java.util.List;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ import mcframe.commonCore.lang.MCDataType;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.lang.MCTimestamp;
/*     */ import mcframe.commonCore.resource.ctrl.MCResourceLayerType;
/*     */ import mcframe.commonCore.resource.ctrl.MCWritableResource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MCSumInfoResourceIO
/*     */   extends MCPersonalizeResourceIO<MCSumInfoInfo>
/*     */ {
/*     */   MCSumInfoInfo createInfo() {
/*  45 */     return MCSumInfoInfo.create();
/*     */   }
/*     */ 
/*     */   
/*     */   boolean containsKey(MCResourceLayerType type, String key) {
/*  50 */     return MCConst.app.containsKey(type, key);
/*     */   }
/*     */ 
/*     */   
/*     */   String getString(MCResourceLayerType type, String key) {
/*  55 */     return MCConst.app.getString(type, key);
/*     */   }
/*     */ 
/*     */   
/*     */   String[] getStringArray(MCResourceLayerType type, String key) {
/*  60 */     return MCConst.app.getStringArray(type, key);
/*     */   }
/*     */ 
/*     */   
/*     */   void setString(MCResourceLayerType type, String key, String value) {
/*  65 */     MCConst.app.setString(type, key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   void setStringArray(MCResourceLayerType type, String key, String[] value) {
/*  70 */     MCConst.app.setStringArray(type, key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   String[] findPattern(MCResourceLayerType type, String pattern) {
/*  75 */     return MCConst.app.findPattern(type, pattern);
/*     */   }
/*     */ 
/*     */   
/*     */   public void read(String prefix) {
/*  80 */     super.read(prefix);
/*     */   }
/*     */ 
/*     */   
/*     */   void setInfo(MCResourceLayerType type, String pattern, String prefix) {
/*  85 */     super.setInfo(type, pattern, prefix);
/*     */     
/*  87 */     if ("PATTERN".equals(pattern)) {
/*  88 */       List<MCSumInfoInfo> l = getInfoList();
/*  89 */       if (l.size() == 0) {
/*     */         return;
/*     */       }
/*  92 */       for (MCSumInfoInfo f : l) {
/*  93 */         if (!type.equals(toResourceLayerType(f.getSettingUnitType()))) {
/*     */           continue;
/*     */         }
/*  96 */         List<MCSumInfoData> dl = f.getSumInfoList();
/*  97 */         int i = 0;
/*     */         while (true) {
/*  99 */           String k = MCConst.createKey(new String[] { f.getPrefix(), createOrderKey(i++) });
/* 100 */           String[] a = getStringArray(type, k);
/* 101 */           if (a == null || a.length == 0) {
/*     */             break;
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 112 */           String[] va = new String[20];
/* 113 */           for (int j = 0; j < va.length; j++) {
/* 114 */             va[j] = (j < a.length) ? (
/* 115 */               !MCStringUtil.isNull(a[j]) ? 
/* 116 */               a[j] : null) : 
/* 117 */               null;
/*     */           }
/*     */           
/* 120 */           MCSumInfoData d = new MCSumInfoData();
/* 121 */           d.setColumnName(va[0]);
/* 122 */           d.setSumInfoType(va[1]);
/* 123 */           d.setDecPlace(MCNumber.valueOf(va[2]));
/* 124 */           d.setRoundingModeType(va[3]);
/* 125 */           d.setDisable(Boolean.parseBoolean(va[4]));
/* 126 */           d.setSortOrder(MCNumber.valueOf(va[5]));
/* 127 */           d.setSortType(va[6]);
/* 128 */           d.setRowLabel(Boolean.parseBoolean(va[7]));
/* 129 */           d.setChartType(MCNumber.valueOf(va[8]));
/* 130 */           d.setChartColor(va[9]);
/* 131 */           d.setDateFormat(va[10]);
/* 132 */           d.setFormula(va[11]);
/* 133 */           d.setSumCondName(va[12]);
/* 134 */           d.setRank(Boolean.parseBoolean(va[13]));
/* 135 */           d.setRankType(va[14]);
/* 136 */           d.setRankSize(MCNumber.valueOf(va[15]));
/* 137 */           d.setFillDate(Boolean.parseBoolean(va[16]));
/* 138 */           d.setFillDateFrom(MCTimestamp.valueOf(va[17], "yyyyMMddHHmmssSSS"));
/* 139 */           d.setFillDateTo(MCTimestamp.valueOf(va[18], "yyyyMMddHHmmssSSS"));
/* 140 */           d.setNullToZero(Boolean.parseBoolean(va[19]));
/*     */ 
/*     */           
/* 143 */           setSumCond(d, type, k);
/*     */           
/* 145 */           dl.add(d);
/*     */         } 
/* 147 */         f.setSumInfoList(dl);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setSumCond(MCSumInfoData data, MCResourceLayerType type, String order_key) {
/* 162 */     List<MCRowFilterData> list = data.getSumCondList();
/* 163 */     list.clear();
/*     */     
/* 165 */     int i = 0;
/*     */     while (true) {
/* 167 */       String k = createCondKey(order_key, i++);
/* 168 */       String[] a = getStringArray(type, k);
/* 169 */       if (a == null || a.length == 0) {
/*     */         break;
/*     */       }
/*     */       
/* 173 */       MCRowFilterData cond = new MCRowFilterData();
/* 174 */       cond.setColumnName(a[0]);
/* 175 */       cond.setDataType(MCDataType.valueOf(a[1]));
/* 176 */       cond.setConditionValue(a[2]);
/* 177 */       cond.setRelativeOperator(a[3]);
/* 178 */       cond.setLogicOperator(a[4]);
/* 179 */       cond.setDisable(Boolean.parseBoolean(a[5]));
/* 180 */       list.add(cond);
/*     */     } 
/* 182 */     data.setSumCondList(list);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String createCondKey(String order_key, int index) {
/* 193 */     return String.valueOf(order_key) + "_cond_" + String.valueOf(index + 1);
/*     */   }
/*     */ 
/*     */   
/*     */   void writeResource(String prefix, MCSumInfoInfo info) {
/* 198 */     super.writeResource(prefix, info);
/*     */     
/* 200 */     List<MCSumInfoData> l = info.getSumInfoList();
/* 201 */     if (l == null) {
/*     */       return;
/*     */     }
/*     */     
/* 205 */     String pk = MCConst.createKey(new String[] { "_0_SCR_", prefix, 
/* 206 */           info.getSettingInfoID() });
/* 207 */     for (int i = 0; i < l.size(); i++) {
/* 208 */       String k = MCConst.createKey(new String[] { pk, createOrderKey(i) });
/*     */       
/* 210 */       MCSumInfoData d = l.get(i);
/*     */       
/* 212 */       MCNumber dp = d.getDecPlace();
/* 213 */       MCNumber so = d.getSortOrder();
/* 214 */       MCNumber ct = d.getChartType();
/* 215 */       MCNumber rs = d.getRankSize();
/* 216 */       MCTimestamp ff = d.getFillDateFrom();
/* 217 */       MCTimestamp ft = d.getFillDateTo();
/* 218 */       String[] va = { 
/* 219 */           d.getColumnName(), 
/* 220 */           d.getSumInfoType(), 
/* 221 */           (dp != null) ? String.valueOf(dp) : null, 
/* 222 */           d.getRoundingModeType(), 
/* 223 */           String.valueOf(d.isDisable()), 
/* 224 */           (so != null) ? String.valueOf(so) : null, 
/* 225 */           d.getSortType(), 
/* 226 */           String.valueOf(d.isRowLabel()), 
/* 227 */           (ct != null) ? String.valueOf(ct) : null, 
/* 228 */           d.getChartColor(), 
/* 229 */           d.getDateFormat(), 
/* 230 */           d.getFormula(), 
/* 231 */           d.getSumCondName(), 
/* 232 */           String.valueOf(d.isRank()), 
/* 233 */           d.getRankType(), 
/* 234 */           (rs != null) ? String.valueOf(rs) : null, 
/* 235 */           String.valueOf(d.isFillDate()), 
/* 236 */           (ff != null) ? String.valueOf(ff.toString()) : null, 
/* 237 */           (ft != null) ? String.valueOf(ft.toString()) : null, 
/* 238 */           String.valueOf(d.isNullToZero()) };
/*     */       
/* 240 */       MCResourceLayerType type = toResourceLayerType(info.getSettingUnitType());
/* 241 */       setStringArray(type, k, va);
/*     */ 
/*     */       
/* 244 */       writeSumCond(d, type, k);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeSumCond(MCSumInfoData data, MCResourceLayerType type, String order_key) {
/* 258 */     List<MCRowFilterData> list = data.getSumCondList();
/* 259 */     for (int i = 0; i < list.size(); i++) {
/* 260 */       MCRowFilterData cond = list.get(i);
/* 261 */       String v1 = cond.getColumnName();
/* 262 */       String v2 = cond.getDataType().name();
/* 263 */       String v3 = cond.getConditionValue();
/* 264 */       String v4 = cond.getRelativeOperator();
/* 265 */       String v5 = cond.getLogicOperator();
/* 266 */       String v6 = String.valueOf(cond.isDisable());
/*     */       
/* 268 */       String[] va = {
/* 269 */           v1, v2, (v3 != null) ? v3 : "", (v4 != null) ? v4 : "", 
/* 270 */           (v5 != null) ? v5 : "", v6
/*     */         };
/*     */       
/* 273 */       String k = createCondKey(order_key, i);
/* 274 */       setStringArray(type, k, va);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void remove(String type, String prefix) {
/* 287 */     remove((MCWritableResource)MCConst.app, type, prefix);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removeNoSave(String type, String prefix) {
/* 299 */     removeNoSave((MCWritableResource)MCConst.app, type, prefix);
/*     */   }
/*     */   
/*     */   public static boolean isSearchedProgram(String type, String pgmid) {
/* 303 */     return MCConst.app.isSearchedProgram(toResourceLayerType(type), pgmid);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\resource\MCSumInfoResourceIO.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */