/*     */ package mcframe.clientCore.beans.resource;
/*     */ 
/*     */ import java.util.List;
/*     */ import mcframe.clientCore.beans.table.MCRowSignal;
/*     */ import mcframe.clientCore.beans.table.MCTable;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ import mcframe.commonCore.lang.MCDataType;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.resource.ctrl.MCResourceLayerType;
/*     */ import mcframe.commonCore.resource.ctrl.MCWritableResource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MCRowSignalResourceIO
/*     */   extends MCPersonalizeResourceIO<MCRowSignalInfo>
/*     */ {
/*     */   MCRowSignalInfo createInfo() {
/*  49 */     return MCRowSignalInfo.create();
/*     */   }
/*     */ 
/*     */   
/*     */   boolean containsKey(MCResourceLayerType type, String key) {
/*  54 */     return MCConst.beans.containsKey(type, key);
/*     */   }
/*     */ 
/*     */   
/*     */   String getString(MCResourceLayerType type, String key) {
/*  59 */     return MCConst.beans.getString(type, key);
/*     */   }
/*     */ 
/*     */   
/*     */   String[] getStringArray(MCResourceLayerType type, String key) {
/*  64 */     return MCConst.beans.getStringArray(type, key);
/*     */   }
/*     */ 
/*     */   
/*     */   void setString(MCResourceLayerType type, String key, String value) {
/*  69 */     MCConst.beans.setString(type, key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   void setStringArray(MCResourceLayerType type, String key, String[] value) {
/*  74 */     MCConst.beans.setStringArray(type, key, value);
/*     */   }
/*     */ 
/*     */   
/*     */   String[] findPattern(MCResourceLayerType type, String pattern) {
/*  79 */     return MCConst.beans.findPattern(type, pattern);
/*     */   }
/*     */ 
/*     */   
/*     */   public void read(String prefix) {
/*  84 */     super.read(prefix);
/*     */   }
/*     */ 
/*     */   
/*     */   void setInfo(MCResourceLayerType type, String pattern, String prefix) {
/*  89 */     super.setInfo(type, pattern, prefix);
/*     */     
/*  91 */     if ("PATTERN".equals(pattern)) {
/*  92 */       List<MCRowSignalInfo> l = getInfoList();
/*  93 */       if (l.size() == 0) {
/*     */         return;
/*     */       }
/*  96 */       for (MCRowSignalInfo f : l) {
/*  97 */         if (!type.equals(toResourceLayerType(f.getSettingUnitType()))) {
/*     */           continue;
/*     */         }
/*     */         
/* 101 */         List<MCRowFilterData> sl = f.getConditionList(1);
/* 102 */         List<MCRowFilterData> cl = f.getConditionList(2);
/* 103 */         List<MCRowFilterData> dl = f.getConditionList(3);
/* 104 */         int i = 0;
/*     */         while (true) {
/* 106 */           String k = MCConst.createKey(new String[] { f.getPrefix(), createOrderKey(i++) });
/* 107 */           String[] a = getStringArray(type, k);
/* 108 */           if (a == null || a.length == 0) {
/*     */             break;
/*     */           }
/*     */           
/* 112 */           String[] va = new String[7];
/* 113 */           for (int j = 0; j < va.length; j++) {
/* 114 */             va[j] = (j < a.length) ? (!MCStringUtil.isNull(a[j]) ? a[j] : null) : 
/* 115 */               null;
/*     */           }
/* 117 */           if (va[0] == null) {
/*     */             continue;
/*     */           }
/*     */           
/* 121 */           int signal = Integer.parseInt(va[0]);
/* 122 */           List<MCRowFilterData> fl = null;
/* 123 */           switch (signal) {
/*     */             case 1:
/* 125 */               fl = sl;
/*     */               break;
/*     */             case 2:
/* 128 */               fl = cl;
/*     */               break;
/*     */             case 3:
/* 131 */               fl = dl;
/*     */               break;
/*     */           } 
/* 134 */           if (fl == null) {
/*     */             continue;
/*     */           }
/*     */           
/* 138 */           MCRowFilterData d = new MCRowFilterData();
/* 139 */           d.setColumnName(a[1]);
/* 140 */           d.setDataType(MCDataType.valueOf(a[2]));
/* 141 */           d.setConditionValue(a[3]);
/* 142 */           d.setRelativeOperator(a[4]);
/* 143 */           d.setLogicOperator(a[5]);
/* 144 */           d.setDisable(Boolean.parseBoolean(a[6]));
/*     */           
/* 146 */           fl.add(d);
/*     */         } 
/* 148 */         f.setConditionList(1, sl);
/* 149 */         f.setConditionList(2, cl);
/* 150 */         f.setConditionList(3, dl);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void writeResource(String prefix, MCRowSignalInfo info) {
/* 157 */     super.writeResource(prefix, info);
/*     */     
/* 159 */     String pk = MCConst.createKey(new String[] { "_0_SCR_", prefix, 
/* 160 */           info.getSettingInfoID() });
/* 161 */     int order = 0; byte b; int i, arrayOfInt[];
/* 162 */     for (i = (arrayOfInt = MCRowSignal.signalArray()).length, b = 0; b < i; ) { int signal = arrayOfInt[b];
/* 163 */       List<MCRowFilterData> conds = info.getConditionList(signal);
/* 164 */       if (conds != null)
/*     */       {
/*     */         
/* 167 */         for (int j = 0; j < conds.size(); j++, order++) {
/* 168 */           String k = MCConst.createKey(new String[] { pk, createOrderKey(order) });
/*     */           
/* 170 */           MCRowFilterData cond = conds.get(j);
/* 171 */           String v1 = String.valueOf(signal);
/* 172 */           String v2 = cond.getColumnName();
/* 173 */           String v3 = cond.getDataType().name();
/* 174 */           String v4 = cond.getConditionValue();
/* 175 */           String v5 = cond.getRelativeOperator();
/* 176 */           String v6 = cond.getLogicOperator();
/* 177 */           String v7 = String.valueOf(cond.isDisable());
/*     */           
/* 179 */           String[] va = {
/* 180 */               v1, v2, v3, (v4 != null) ? v4 : "", (v5 != null) ? v5 : "", 
/* 181 */               (v6 != null) ? v6 : "", v7
/*     */             };
/* 183 */           setStringArray(toResourceLayerType(info.getSettingUnitType()), k, va);
/*     */         } 
/*     */       }
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void remove(String type, String prefix) {
/* 258 */     remove((MCWritableResource)MCConst.beans, type, prefix);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removeNoSave(String type, String prefix) {
/* 270 */     removeNoSave((MCWritableResource)MCConst.beans, type, prefix);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removeNoSaveById(String type, String prefix, String setting_info_id) {
/* 283 */     removeNoSaveById((MCWritableResource)MCConst.beans, type, prefix, setting_info_id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeInitResourceById(String type, String prefix, String setting_info_id) {
/* 296 */     removeInitResourceById((MCWritableResource)MCConst.beans, type, prefix, setting_info_id);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCRowSignalInfo getInitInfo(List<MCRowSignalInfo> list) {
/* 308 */     return _getInitInfo(list);
/*     */   }
/*     */   
/*     */   public static boolean isSearchedProgram(String type, String pgmid) {
/* 312 */     return MCConst.beans.isSearchedProgram(toResourceLayerType(type), pgmid);
/*     */   }
/*     */ 
/*     */   
/*     */   public static MCRowSignalInfo getInfo(String type, String id, List<MCRowSignalInfo> list) {
/* 317 */     return _getInfo(type, id, list);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<MCRowSignalInfo> readInfo(String module_id, String screen_id, String table_nm) {
/* 330 */     MCRowSignalResourceIO sio = new MCRowSignalResourceIO();
/* 331 */     sio.read(createPrefix(module_id, screen_id, table_nm));
/* 332 */     return sio.getInfoList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCRowSignalInfo readInfo(String module_id, String screen_id, String table_nm, String id) {
/* 346 */     String prefix = createPrefix(module_id, screen_id, table_nm);
/* 347 */     MCRowSignalResourceIO sio = new MCRowSignalResourceIO(); byte b; int i; MCResourceLayerType[] arrayOfMCResourceLayerType;
/* 348 */     for (i = (arrayOfMCResourceLayerType = MCResourceLayerType.values()).length, b = 0; b < i; ) { MCResourceLayerType type = arrayOfMCResourceLayerType[b];
/* 349 */       String pattern = sio.getPattern(type, prefix);
/* 350 */       MCRowSignalInfo info = sio.readInfo(type, pattern, prefix, id);
/* 351 */       if (info != null)
/* 352 */         return info; 
/*     */       b++; }
/*     */     
/* 355 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String createPrefix(String module_id, String screen_id, String table_nm) {
/* 368 */     return MCTable.getPersonalizedKeyPrefix(module_id, screen_id, table_nm, 
/* 369 */         "ROW_SIGNAL_PANEL", null);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\resource\MCRowSignalResourceIO.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */