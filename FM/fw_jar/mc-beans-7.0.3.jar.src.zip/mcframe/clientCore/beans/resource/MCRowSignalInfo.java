/*     */ package mcframe.clientCore.beans.resource;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCRowSignalInfo
/*     */   extends MCPersonalizeInfo
/*     */ {
/*     */   private List<MCRowFilterData> _safety_list;
/*     */   private List<MCRowFilterData> _caution_list;
/*     */   private List<MCRowFilterData> _danger_list;
/*     */   
/*     */   public static MCRowSignalInfo create() {
/*  26 */     return new MCRowSignalInfo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInitFlg(boolean flg) {
/*  60 */     super.setInitFlg(flg);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getInitFlg() {
/*  65 */     return super.getInitFlg();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConditionList(int signal, List<MCRowFilterData> filter) {
/*  77 */     switch (signal) {
/*     */       case 1:
/*  79 */         this._safety_list = filter;
/*     */         break;
/*     */       case 2:
/*  82 */         this._caution_list = filter;
/*     */         break;
/*     */       case 3:
/*  85 */         this._danger_list = filter;
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<MCRowFilterData> getConditionList(int signal) {
/* 102 */     switch (signal) {
/*     */       case 1:
/* 104 */         return (this._safety_list != null) ? this._safety_list : (
/* 105 */           this._safety_list = new ArrayList<>());
/*     */       case 2:
/* 107 */         return (this._caution_list != null) ? this._caution_list : (
/* 108 */           this._caution_list = new ArrayList<>());
/*     */       case 3:
/* 110 */         return (this._danger_list != null) ? this._danger_list : (
/* 111 */           this._danger_list = new ArrayList<>());
/*     */     } 
/* 113 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\resource\MCRowSignalInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */