/*     */ package mcframe.clientCore.beans.resource;
/*     */ 
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MCFontRatioResourceIO
/*     */ {
/*     */   private static final String TYPE_P_FONT_RATIO = "p_font_ratio";
/*     */   private String _last_read_prefix;
/*     */   private Integer _font_ratio;
/*     */   private Boolean _adjust_screen_size;
/*     */   
/*     */   public void setFontRatio(int ratio) {
/*  86 */     this._font_ratio = Integer.valueOf(ratio);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getFontRatio() {
/*  98 */     return this._font_ratio;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAdjustScreenSize(boolean adjust) {
/* 109 */     this._adjust_screen_size = Boolean.valueOf(adjust);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean getAdjustScreenSize() {
/* 121 */     return this._adjust_screen_size;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void read(String prefix) {
/* 132 */     Integer o = null;
/* 133 */     Boolean a = null;
/*     */ 
/*     */     
/* 136 */     String k = MCConst.createKey(new String[] { prefix, "p_font_ratio" });
/* 137 */     if (MCConst.beans.containsKey(k)) {
/* 138 */       String[] va = MCConst.beans.getStringArray(k);
/* 139 */       if (va != null && va.length != 0) {
/*     */         
/* 141 */         int i = 0;
/* 142 */         if (!MCStringUtil.isNull(va[i])) {
/* 143 */           o = Integer.valueOf(va[i]);
/*     */         }
/* 145 */         if (va.length > ++i && !MCStringUtil.isNull(va[i])) {
/* 146 */           a = Boolean.valueOf(va[i]);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 152 */     this._font_ratio = o;
/* 153 */     this._adjust_screen_size = a;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(String prefix) {
/* 164 */     writeNoSave(prefix);
/* 165 */     MCConst.saveUser();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeNoSave(String prefix) {
/* 179 */     Object[] a = {
/* 180 */         this._font_ratio, 
/* 181 */         this._adjust_screen_size
/*     */       };
/*     */ 
/*     */     
/* 185 */     String[] va = new String[a.length];
/* 186 */     for (int i = 0; i < a.length; i++) {
/* 187 */       va[i] = (a[i] != null) ? String.valueOf(a[i]) : "";
/*     */     }
/*     */ 
/*     */     
/* 191 */     String k = MCConst.createKey(new String[] { prefix, "p_font_ratio" });
/* 192 */     MCConst.beans.setStringArray(k, va);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void remove(String prefix) {
/* 204 */     removeNoSave(prefix);
/* 205 */     MCConst.saveUser();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removeNoSave(String prefix) {
/* 217 */     MCConst.beans.remove(MCConst.createKey(new String[] { prefix, "p_font_ratio" }));
/*     */   }
/*     */   
/*     */   boolean isLastReaded(String prefix) {
/* 221 */     return (this._last_read_prefix != null && this._last_read_prefix.equals(prefix));
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\resource\MCFontRatioResourceIO.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */