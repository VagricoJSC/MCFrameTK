/*     */ package mcframe.clientCore.beans.resource;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Point;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MCPanelBoundsResourceIO
/*     */ {
/*     */   private static final String TYPE_P_PANEL_BOUNDS = "p_panel_bounds";
/*     */   private static final String TYPE_P_SPLITPANE_DIVIDER_LOCATION = "p_splitpane.divider_location";
/*     */   private String _last_read_prefix;
/*     */   private Integer _frame_x;
/*     */   private Integer _frame_y;
/*     */   private Integer _frame_width;
/*     */   private Integer _frame_height;
/*     */   private Integer _panel_min_width;
/*  73 */   private DataVer _ver = DataVer.VER1;
/*     */   private Integer _panel_min_height;
/*     */   private Integer _panel_pre_width;
/*     */   private Integer _panel_pre_height;
/*     */   private Map<String, Integer> _splitpane_divider_map;
/*     */   private MCRootPanel _panel;
/*     */   
/*  80 */   private enum DataVer { VER0
/*     */     {
/*     */ 
/*     */       
/*     */       boolean isRatioCons()
/*     */       {
/*  86 */         return false;
/*     */       }
/*     */ 
/*     */       
/*     */       Integer getValue() {
/*  91 */         return Integer.valueOf(0);
/*     */       }
/*     */ 
/*     */       
/*     */       boolean is(Integer v) {
/*  96 */         if (v == null) {
/*  97 */           return true;
/*     */         }
/*  99 */         if (v.equals(VER0.getValue())) {
/* 100 */           return true;
/*     */         }
/* 102 */         return false;
/*     */       }
/*     */     },
/* 105 */     VER1
/*     */     {
/*     */ 
/*     */       
/*     */       Integer getValue()
/*     */       {
/* 111 */         return Integer.valueOf(1);
/*     */       }
/*     */       
/*     */       boolean is(Integer v) {
/* 115 */         return getValue().equals(v);
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean isRatioCons() {
/* 146 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     abstract Integer getValue();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     abstract boolean is(Integer param1Integer); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCPanelBoundsResourceIO(MCRootPanel rp) {
/* 259 */     this._panel = rp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFrameLocation(Point location) {
/* 271 */     if (location != null) {
/* 272 */       this._frame_x = Integer.valueOf(location.x);
/* 273 */       this._frame_y = Integer.valueOf(location.y);
/*     */     } else {
/*     */       
/* 276 */       this._frame_x = null;
/* 277 */       this._frame_y = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRatioConsiderationMode() {
/* 289 */     return this._ver.isRatioCons();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Point getFrameLocation() {
/* 303 */     return (this._frame_x != null && this._frame_y != null) ? new Point(this._frame_x.intValue(), this._frame_y.intValue()) : 
/* 304 */       null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFrameSize(Dimension size) {
/* 316 */     Insets fi = new Insets(0, 0, 0, 0);
/* 317 */     if (this._panel.getFrame() != null) {
/* 318 */       fi = this._panel.getFrame().getInsets();
/*     */     }
/* 320 */     int extraW = fi.left + fi.right;
/* 321 */     int extraH = fi.top + fi.bottom;
/*     */     
/* 323 */     if (size != null) {
/* 324 */       this._frame_width = to100(Integer.valueOf(size.width - extraW));
/* 325 */       this._frame_height = to100(Integer.valueOf(size.height - extraH));
/*     */     } else {
/*     */       
/* 328 */       this._frame_width = null;
/* 329 */       this._frame_height = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private Integer to100(Integer len) {
/* 334 */     if (len == null) {
/* 335 */       return null;
/*     */     }
/* 337 */     if (isRatioConsiderationMode()) {
/* 338 */       return Integer.valueOf(MCBeansUtil.adjust(len.intValue(), this._panel.getLayoutRatio(), 100));
/*     */     }
/* 340 */     return len;
/*     */   }
/*     */   private Integer toRatio(Integer len) {
/* 343 */     if (len == null) {
/* 344 */       return null;
/*     */     }
/* 346 */     if (isRatioConsiderationMode()) {
/* 347 */       return Integer.valueOf(MCBeansUtil.adjust(len.intValue(), 100, this._panel.getLayoutRatio()));
/*     */     }
/* 349 */     return len;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension getFrameSize() {
/* 363 */     Dimension d = (this._frame_width != null && this._frame_height != null) ? 
/* 364 */       new Dimension(toRatio(this._frame_width).intValue(), toRatio(this._frame_height).intValue()) : null;
/*     */     
/* 366 */     if (d == null) {
/* 367 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 371 */     Insets fi = new Insets(0, 0, 0, 0);
/* 372 */     if (isRatioConsiderationMode() && this._panel.getFrame() != null) {
/* 373 */       fi = this._panel.getFrame().getInsets();
/*     */     }
/* 375 */     int extraW = fi.left + fi.right;
/* 376 */     int extraH = fi.top + fi.bottom;
/*     */     
/* 378 */     d.width += extraW;
/* 379 */     d.height += extraH;
/* 380 */     return d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPanelMinimumSize(Dimension size) {
/* 392 */     if (size != null) {
/* 393 */       this._panel_min_width = to100(Integer.valueOf(size.width));
/* 394 */       this._panel_min_height = to100(Integer.valueOf(size.height));
/*     */     } else {
/*     */       
/* 397 */       this._panel_min_width = null;
/* 398 */       this._panel_min_height = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension getPanelMinimumSize() {
/* 413 */     return (this._panel_min_width != null && this._panel_min_height != null) ? 
/* 414 */       new Dimension(toRatio(this._panel_min_width).intValue(), toRatio(this._panel_min_height).intValue()) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPanelPreferredSize(Dimension size) {
/* 425 */     if (size != null) {
/* 426 */       this._panel_pre_width = to100(Integer.valueOf(size.width));
/* 427 */       this._panel_pre_height = to100(Integer.valueOf(size.height));
/*     */     } else {
/*     */       
/* 430 */       this._panel_pre_width = null;
/* 431 */       this._panel_pre_height = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension getPanelPreferredSize() {
/* 446 */     return (this._panel_pre_width != null && this._panel_pre_height != null) ? 
/* 447 */       new Dimension(toRatio(this._panel_pre_width).intValue(), toRatio(this._panel_pre_height).intValue()) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, Integer> getSplitPaneDividerMap() {
/* 458 */     return (this._splitpane_divider_map != null) ? this._splitpane_divider_map : (
/* 459 */       this._splitpane_divider_map = new HashMap<>());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getSplitPaneNameArray() {
/* 471 */     Set<String> ks = getSplitPaneDividerMap().keySet();
/* 472 */     return ks.<String>toArray(new String[ks.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSplitPaneDividerLocation(String name, int location) {
/* 484 */     getSplitPaneDividerMap().put(name, to100(Integer.valueOf(location)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getSplitPaneDividerLocation(String name) {
/* 497 */     return toRatio(getSplitPaneDividerMap().get(name));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void read(String prefix) {
/* 508 */     Integer[] ba = new Integer[9];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 521 */     String k = MCConst.createKey(new String[] { prefix, "p_panel_bounds" });
/* 522 */     if (MCConst.layout.containsKey(k)) {
/* 523 */       String[] va = MCConst.layout.getStringArray(k);
/* 524 */       if (va != null && va.length != 0)
/*     */       {
/* 526 */         for (int i = 0; i < ba.length && 
/* 527 */           va.length > i; i++) {
/* 528 */           if (!MCStringUtil.isNull(va[i])) {
/* 529 */             ba[i] = Integer.valueOf(va[i]);
/*     */           }
/*     */         } 
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 540 */     this._frame_x = ba[0];
/* 541 */     this._frame_y = ba[1];
/* 542 */     this._frame_width = ba[2];
/* 543 */     this._frame_height = ba[3];
/* 544 */     this._panel_min_width = ba[4];
/* 545 */     this._panel_min_height = ba[5];
/* 546 */     this._panel_pre_width = ba[6];
/* 547 */     this._panel_pre_height = ba[7];
/* 548 */     this._ver = DataVer.valueOf(ba[8]);
/*     */     
/* 550 */     Map<String, Integer> m = new HashMap<>();
/*     */ 
/*     */     
/* 553 */     k = MCConst.createKey(new String[] { prefix, "p_splitpane.divider_location" });
/* 554 */     String[] ka = MCConst.layout.findPattern(String.valueOf(k) + ".**");
/*     */ 
/*     */     
/* 557 */     if (ka.length > 0) {
/* 558 */       int b = k.length() + 1; byte b1; int i; String[] arrayOfString;
/* 559 */       for (i = (arrayOfString = ka).length, b1 = 0; b1 < i; ) { String s = arrayOfString[b1];
/* 560 */         String n = s.substring(b);
/* 561 */         String v = MCConst.layout.getString(s);
/* 562 */         if (!MCStringUtil.isNull(v))
/*     */         {
/*     */           
/* 565 */           m.put(n, Integer.valueOf(v));
/*     */         }
/*     */         b1++; }
/*     */     
/*     */     } 
/* 570 */     this._splitpane_divider_map = m;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(String prefix) {
/* 581 */     writeNoSave(prefix);
/* 582 */     MCConst.saveUser();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeNoSave(String prefix) {
/* 595 */     if (DataVer.VER0 == this._ver) {
/* 596 */       this._ver = DataVer.VER1;
/*     */ 
/*     */       
/* 599 */       this._frame_width = to100(this._frame_width);
/* 600 */       this._frame_height = to100(this._frame_height);
/* 601 */       this._panel_min_width = to100(this._panel_min_width);
/* 602 */       this._panel_min_height = to100(this._panel_min_height);
/* 603 */       this._panel_pre_width = to100(this._panel_pre_width);
/* 604 */       this._panel_pre_height = to100(this._panel_pre_height);
/*     */       
/* 606 */       Map<String, Integer> map = getSplitPaneDividerMap();
/* 607 */       String[] arrayOfString2 = getSplitPaneNameArray(); byte b1; int n; String[] arrayOfString3;
/* 608 */       for (n = (arrayOfString3 = arrayOfString2).length, b1 = 0; b1 < n; ) { String str = arrayOfString3[b1];
/* 609 */         Integer integer = map.get(str);
/* 610 */         if (integer != null) {
/* 611 */           map.put(str, to100(Integer.valueOf(integer.intValue())));
/*     */         }
/*     */         
/*     */         b1++; }
/*     */     
/*     */     } 
/* 617 */     Comparable[] a = {
/* 618 */         this._frame_x, 
/* 619 */         this._frame_y, 
/* 620 */         this._frame_width, 
/* 621 */         this._frame_height, 
/* 622 */         this._panel_min_width, 
/* 623 */         this._panel_min_height, 
/* 624 */         this._panel_pre_width, 
/* 625 */         this._panel_pre_height, 
/* 626 */         this._ver.getValue()
/*     */       };
/*     */ 
/*     */     
/* 630 */     String[] va = new String[a.length];
/* 631 */     for (int i = 0; i < a.length; i++) {
/* 632 */       va[i] = (a[i] != null) ? String.valueOf(a[i]) : "";
/*     */     }
/*     */ 
/*     */     
/* 636 */     String k = MCConst.createKey(new String[] { prefix, "p_panel_bounds" });
/* 637 */     MCConst.layout.setStringArray(k, va);
/*     */ 
/*     */     
/* 640 */     Map<String, Integer> m = getSplitPaneDividerMap();
/* 641 */     String[] na = getSplitPaneNameArray(); byte b; int j; String[] arrayOfString1;
/* 642 */     for (j = (arrayOfString1 = na).length, b = 0; b < j; ) { String n = arrayOfString1[b];
/* 643 */       k = MCConst.createKey(new String[] { prefix, "p_splitpane.divider_location", n });
/* 644 */       Integer integer = m.get(n);
/* 645 */       MCConst.layout.setInteger(k, integer.intValue());
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void remove(String prefix) {
/* 658 */     removeNoSave(prefix);
/* 659 */     MCConst.saveUser();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removeNoSave(String prefix) {
/* 671 */     MCConst.layout.remove(MCConst.createKey(new String[] { prefix, "p_panel_bounds" }));
/*     */ 
/*     */     
/* 674 */     String k = MCConst.createKey(new String[] { prefix, "p_splitpane.divider_location" });
/* 675 */     String[] ka = MCConst.layout.findPattern(String.valueOf(k) + ".**");
/* 676 */     MCConst.layout.remove(ka);
/*     */   }
/*     */   
/*     */   boolean isLastReaded(String prefix) {
/* 680 */     return (this._last_read_prefix != null && this._last_read_prefix.equals(prefix));
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\resource\MCPanelBoundsResourceIO.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */