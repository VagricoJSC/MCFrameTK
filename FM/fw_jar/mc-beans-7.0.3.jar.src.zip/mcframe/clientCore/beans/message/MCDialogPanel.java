package mcframe.clientCore.beans.message;

public interface MCDialogPanel {
  void setMessage(MCDialogInfo paramMCDialogInfo);
  
  int getResultOption();
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\message\MCDialogPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */