/*    */ package mcframe.clientCore.beans.message;
/*    */ 
/*    */ import mcframe.clientCore.beans.MCButton;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface MCProgressPanel
/*    */ {
/*    */   void setDialogInfo(MCProgressInfo paramMCProgressInfo);
/*    */   
/*    */   int getResultOption();
/*    */   
/*    */   void requestCloseWindow();
/*    */   
/*    */   MCButton getEnableCancelButton();
/*    */   
/*    */   default int getDelay() {
/* 47 */     return 0;
/*    */   }
/*    */   
/*    */   void pack();
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\message\MCProgressPanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */