package mcframe.clientCore.beans.message;

import mcframe.commonCore.notice.MCMessageList;

public interface MCMessagePanel {
  void setMessageList(MCMessageList paramMCMessageList);
  
  void setVisibleId(boolean paramBoolean);
  
  void setVisibleLv(boolean paramBoolean);
  
  void setHeaderEnd(String paramString);
  
  void setMessageGroupName(String paramString);
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\message\MCMessagePanel.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */