/*    */ package mcframe.clientCore.beans.message;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCPasswordDialogInfo
/*    */ {
/*    */   private boolean _check_user_id = false;
/*    */   private boolean _result = false;
/*    */   
/*    */   public void setCheckUserID(boolean check) {
/* 37 */     this._check_user_id = check;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isCheckUserID() {
/* 48 */     return this._check_user_id;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setResult(boolean result) {
/* 59 */     this._result = result;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean getResult() {
/* 70 */     return this._result;
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\message\MCPasswordDialogInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */