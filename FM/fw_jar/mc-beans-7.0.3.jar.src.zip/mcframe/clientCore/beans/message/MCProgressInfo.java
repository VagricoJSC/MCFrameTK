/*     */ package mcframe.clientCore.beans.message;
/*     */ 
/*     */ import javax.swing.Icon;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCFrame;
/*     */ import mcframe.clientCore.beans.MCFrameType;
/*     */ import mcframe.clientCore.beans.MCMessageBox;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCMessage;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCProgressInfo
/*     */   extends MCDialogInfo
/*     */ {
/*  31 */   private MCProgressThread _action = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final MCRootPanel _panel;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  41 */   private String _modId = "FS";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  49 */   private String _scrId = "FSBAP0230";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean _undecoratedFrame = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean _showprogressbar = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean _forceProgressDisplay = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean forceProgressDisplay() {
/*  83 */     return this._forceProgressDisplay;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setForceProgressDisplay(boolean b) {
/*  95 */     this._forceProgressDisplay = b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isProgessBarAvailable() {
/* 108 */     if (getAction() != null && !getAction().doMultiThread()) {
/* 109 */       return false;
/*     */     }
/* 111 */     return this._showprogressbar;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void showProgessBar(boolean b) {
/* 122 */     this._showprogressbar = b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 131 */   private static MCMessage _defaultMessage = new MCMessage(Core_Msg_FW_A.FCBAC0374, new Object[0]);
/*     */ 
/*     */   
/*     */   public MCProgressInfo(MCRootPanel panel) {
/* 135 */     setDialogType(-9999);
/* 136 */     setMessage(_defaultMessage);
/* 137 */     setIcon(MCMessageBox.getDialogIcon(getMessage().getLevel()));
/* 138 */     this._panel = panel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setProgressId(String moduleId, String screenId) {
/* 150 */     this._modId = moduleId;
/* 151 */     this._scrId = screenId;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCProgressPanel getProgressPanel(MCRootPanel srcPanel) {
/* 165 */     MCRootPanel p = MCBeansUtil.createPanel(srcPanel, this._modId, this._scrId, 
/* 166 */         MCFrameType.SYSTEM_MODAL, new Object[0]);
/* 167 */     if (p instanceof MCProgressPanel) {
/* 168 */       MCProgressPanel pp = (MCProgressPanel)p;
/* 169 */       pp.setDialogInfo(this);
/* 170 */       return pp;
/*     */     } 
/* 172 */     throw new MCException(Core_Msg_FW_A.FCBAC0348, new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCProgressPanel getProgressPanelModeless(MCRootPanel srcPanel) {
/* 185 */     MCFrameType ft = MCFrameType.MODELESS;
/* 186 */     MCFrame[] fs = MCBeansUtil.getAllFramesWithZOrder();
/* 187 */     if (fs != null && fs.length > 1 && 
/* 188 */       fs[0].getFrameType() == MCFrameType.SYSTEM_MODAL) {
/* 189 */       ft = MCFrameType.SYSTEM_MODAL;
/*     */     }
/*     */     
/* 192 */     MCRootPanel p = MCBeansUtil.createPanel(srcPanel, this._modId, this._scrId, ft, new Object[0]);
/* 193 */     if (p instanceof MCProgressPanel) {
/* 194 */       MCProgressPanel pp = (MCProgressPanel)p;
/* 195 */       pp.setDialogInfo(this);
/* 196 */       return pp;
/*     */     } 
/* 198 */     throw new MCException(Core_Msg_FW_A.FCBAC0348, new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCProgressPanel getProgressPanelOnly(MCRootPanel srcPanel) {
/* 212 */     MCRootPanel p = MCBeansUtil.createPanelOnly(null, this._modId, this._scrId, new Object[0]);
/* 213 */     if (p instanceof MCProgressPanel) {
/* 214 */       MCProgressPanel pp = (MCProgressPanel)p;
/* 215 */       pp.setDialogInfo(this);
/* 216 */       return pp;
/*     */     } 
/* 218 */     throw new MCException(Core_Msg_FW_A.FCBAC0348, new Object[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDialogType(int type) {
/* 237 */     super.setDialogType(type);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAction(MCProgressThread t) {
/* 249 */     this._action = t;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCProgressThread getAction() {
/* 264 */     return this._action;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUndecoratedFrame() {
/* 277 */     return this._undecoratedFrame;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUndecoreatedFrame(boolean isUndecoreated) {
/* 290 */     this._undecoratedFrame = isUndecoreated;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCMessage getMessage() {
/* 304 */     return super.getMessage();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Icon getIcon() {
/* 318 */     return super.getIcon();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public String getDevelopMessage() {
/* 328 */     return super.getDevelopMessage();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public void setDevelopMessage(String msg) {
/* 338 */     super.setDevelopMessage(msg);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\message\MCProgressInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */