/*    */ package mcframe.clientCore.beans.menu;
/*    */ 
/*    */ import mcframe.clientCore.beans.AbsMCPackageProxy;
/*    */ import mcframe.clientCore.beans.MCFrameType;
/*    */ import mcframe.clientCore.beans.MCRootPanel;
/*    */ import mcframe.clientCore.event.MCMainWindowCloseType;
/*    */ import mcframe.clientCore.resource.MCMenuItemModel;
/*    */ 
/*    */ final class MCBeansProxy
/*    */   extends AbsMCPackageProxy {
/* 11 */   static final MCBeansProxy PROXY = new MCBeansProxy();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean doExit(MCMainWindowCloseType type) {
/* 18 */     return super.doExit(type);
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean doExtAttrChange() {
/* 23 */     return super.doExtAttrChange();
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean doModSelect() {
/* 28 */     return super.doModSelect();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void doCloseAll() {
/* 33 */     super.doCloseAll();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected MCRootPanel createPanelM(MCMenuItemModel menu, MCRootPanel panel, String module, String screen, MCFrameType type, Object... params) {
/* 39 */     return super.createPanelM(menu, panel, module, screen, type, params);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\menu\MCBeansProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */