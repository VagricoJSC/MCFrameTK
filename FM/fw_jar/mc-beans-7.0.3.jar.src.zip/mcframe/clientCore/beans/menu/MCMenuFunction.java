/*     */ package mcframe.clientCore.beans.menu;
/*     */ 
/*     */ import java.awt.Desktop;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.Arrays;
/*     */ import mcframe.clientCore.event.MCMainWindowCloseType;
/*     */ import mcframe.clientCore.resource.MCConfig;
/*     */ import mcframe.clientCore.sys.MCSys;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.sys.MCExec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCMenuFunction
/*     */ {
/*     */   private static boolean event = false;
/*     */   
/*     */   public final void doLogout() {
/*  36 */     if (!event) {
/*  37 */       event = true;
/*  38 */       MCBeansProxy.PROXY.doExit(MCMainWindowCloseType.LOGIN);
/*  39 */       event = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void doExtAttrChange() {
/*  50 */     if (!event) {
/*  51 */       event = true;
/*  52 */       MCBeansProxy.PROXY.doExtAttrChange();
/*  53 */       event = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void doSystemExit() {
/*  64 */     if (!event) {
/*  65 */       event = true;
/*  66 */       MCBeansProxy.PROXY.doExit(MCMainWindowCloseType.CLOSE);
/*  67 */       event = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void doModSelect() {
/*  79 */     if (!event) {
/*  80 */       event = true;
/*  81 */       MCBeansProxy.PROXY.doModSelect();
/*  82 */       event = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void execTimeline() {
/*  94 */     openCommunication("agent/timeline");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void execKnowledge() {
/* 105 */     openCommunication("agent/knowledge");
/*     */   }
/*     */   
/*     */   private final void openCommunication(String urlpath) {
/* 109 */     String url = getCommunicationURL();
/* 110 */     if (url == null) {
/*     */       return;
/*     */     }
/* 113 */     url = String.valueOf(url) + urlpath;
/* 114 */     String browser = MCConfig.client.getCommunicationBrowserFilePath();
/* 115 */     if (MCConfig.client.getBoolean("communication.priorselectedbrowser", true) && 
/* 116 */       browser != null) {
/*     */       MCExec web;
/* 118 */       String[] bschemes = MCConfig.client.getStringArray("communication.browserschemes", 
/* 119 */           new String[] { "microsoft-edge:" });
/* 120 */       Arrays.sort((Object[])bschemes);
/* 121 */       if (Arrays.binarySearch((Object[])bschemes, browser) >= 0) {
/* 122 */         web = new MCExec(new String[] { "cmd", "/c", "start", String.valueOf(browser) + url });
/*     */       } else {
/*     */         
/* 125 */         web = new MCExec(new String[] { browser, url });
/*     */       } 
/* 127 */       web.setWait(false);
/* 128 */       web.execute();
/*     */     } else {
/*     */       
/* 131 */       Desktop desktop = Desktop.getDesktop();
/*     */       
/*     */       try {
/* 134 */         URI uri = new URI(url);
/* 135 */         desktop.browse(uri);
/*     */       }
/* 137 */       catch (URISyntaxException|java.io.IOException e) {
/* 138 */         throw new MCException(e);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 145 */   private static final String KEY_TYPE = MCConfig.createKey(new String[] { "communication", "type" });
/*     */   private final String getCommunicationURL() {
/* 147 */     String result = null;
/* 148 */     String type = MCConfig.common.getString(KEY_TYPE);
/*     */     
/* 150 */     if ("1".equals(type)) {
/* 151 */       result = MCConfig.common
/* 152 */         .getString(MCConfig.createKey(new String[] { "communication", "url" }));
/*     */     }
/* 154 */     else if ("2".equals(type)) {
/* 155 */       result = MCConfig.common.getString(
/* 156 */           MCConfig.createKey(new String[] { "communication", MCSys.user.coCD(), "url" }));
/*     */     } 
/*     */     
/* 159 */     if (result != null && !result.endsWith("/")) {
/* 160 */       result = String.valueOf(result) + "/";
/*     */     }
/* 162 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void doCloseAll() {
/* 172 */     MCBeansProxy.PROXY.doCloseAll();
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\menu\MCMenuFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */