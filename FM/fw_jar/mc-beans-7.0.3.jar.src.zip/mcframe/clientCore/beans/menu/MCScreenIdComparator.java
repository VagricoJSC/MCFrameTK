/*    */ package mcframe.clientCore.beans.menu;
/*    */ 
/*    */ import java.util.Comparator;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCScreenIdComparator
/*    */   implements Comparator<String[]>
/*    */ {
/*    */   public int compare(String[] s1, String[] s2) {
/* 27 */     String s11 = null;
/* 28 */     String s21 = null;
/* 29 */     if (s1 != null && s1.length > 2) {
/* 30 */       s11 = String.valueOf(s1[1]) + s1[0];
/*    */     }
/* 32 */     if (s2 != null && s2.length > 2) {
/* 33 */       s21 = String.valueOf(s2[1]) + s2[0];
/*    */     }
/*    */     
/* 36 */     if (s11 == null) {
/* 37 */       if (s21 == null) {
/* 38 */         return 0;
/*    */       }
/* 40 */       return -1;
/*    */     } 
/* 42 */     if (s21 == null) {
/* 43 */       return 1;
/*    */     }
/*    */     
/* 46 */     return s11.compareTo(s21);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\menu\MCScreenIdComparator.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */