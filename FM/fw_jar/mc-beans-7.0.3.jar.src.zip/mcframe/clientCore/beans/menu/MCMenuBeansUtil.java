/*     */ package mcframe.clientCore.beans.menu;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import javax.swing.ImageIcon;
/*     */ import mcframe.clientCore.acl.MCACLManager;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCFrame;
/*     */ import mcframe.clientCore.beans.MCFrameType;
/*     */ import mcframe.clientCore.beans.MCPanelType;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.menu.requester.MenuR;
/*     */ import mcframe.clientCore.beans.menu.requester.PDef;
/*     */ import mcframe.clientCore.requester.MCCaller;
/*     */ import mcframe.clientCore.requester.MCDownloader;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ import mcframe.clientCore.resource.MCMenuItemModel;
/*     */ import mcframe.clientCore.resource.MCMenuModel;
/*     */ import mcframe.commonCore.container.MCContainer;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCBinary;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ import mcframe.commonCore.param.MCDef;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCMenuBeansUtil
/*     */ {
/*  54 */   private static ImageIcon _defIcon = MCBeansUtil.getIcon(MCConst.beans.getString("icon.MENU_DEF"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   private static Dimension _defIconSize = new Dimension(_defIcon.getIconWidth(), 
/*  62 */       _defIcon.getIconHeight());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean checkACL(MCMenuItemModel model) {
/*  88 */     if (!model.isItemTag() && !model.isExecTag())
/*     */     {
/*  90 */       return true;
/*     */     }
/*  92 */     if (!model.enable())
/*     */     {
/*  94 */       return false;
/*     */     }
/*  96 */     if (model.isExecTag()) {
/*  97 */       return _checkClassACL(model);
/*     */     }
/*  99 */     return _checkScreenACL(model);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean _checkScreenACL(MCMenuItemModel model) {
/*     */     boolean auth;
/* 123 */     String moduleid = model.moduleId();
/* 124 */     String screenid = model.screenId();
/* 125 */     String rpc = MCConst.screen.getClassName(moduleid, screenid);
/*     */     
/* 127 */     if (rpc == null) {
/*     */       
/* 129 */       MCLog.write(Core_Msg_FW_A.FCBAC0298, new Object[] { moduleid, screenid });
/* 130 */       return false;
/*     */     } 
/* 132 */     String rpcid = MCConst.screen.getClassID(moduleid, screenid);
/* 133 */     if (rpcid == null) {
/*     */       
/* 135 */       MCLog.write(Core_Msg_FW_A.FCBAC0298, new Object[] { moduleid, screenid });
/* 136 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 150 */     boolean admin = false;
/* 151 */     for (String[] a : MCACLManager.getClientAdmin()) {
/* 152 */       if (moduleid.equals(a[0]) && screenid.equals(a[1])) {
/* 153 */         admin = true;
/*     */         break;
/*     */       } 
/*     */     } 
/* 157 */     String actype = MCConst.actype.getType(new String[] { MCConst.createKey(new String[] { moduleid, rpcid }) });
/*     */     
/* 159 */     if (admin) {
/*     */       
/* 161 */       auth = MCACLManager.authorize(moduleid, rpcid, actype, null);
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 166 */       boolean ignore = MCACLManager.ignoreMenu(moduleid, model.menuId(), 
/* 167 */           "menu_item");
/* 168 */       if (ignore) {
/* 169 */         auth = false;
/*     */       }
/*     */       else {
/*     */         
/* 173 */         auth = MCACLManager.authorizeMenu(moduleid, rpcid, model.menuId(), actype, 
/* 174 */             "menu_item");
/* 175 */         if (!auth)
/*     */         {
/* 177 */           auth = MCACLManager.authorize(moduleid, rpcid, actype, null);
/*     */         }
/*     */       } 
/*     */     } 
/* 181 */     return auth;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean _checkClassACL(MCMenuItemModel model) {
/* 208 */     String moduleid = null;
/* 209 */     String screenid = null;
/* 210 */     String rpc = null;
/* 211 */     String rpcid = null;
/* 212 */     String method = null;
/*     */     
/* 214 */     if (model.getExecType() == MCMenuItemModel.MCMenuExecType.SCREEN) {
/* 215 */       moduleid = model.moduleId();
/* 216 */       screenid = model.screenId();
/* 217 */       rpc = MCConst.screen.getClassName(moduleid, screenid);
/*     */       
/* 219 */       if (rpc == null) {
/*     */         
/* 221 */         MCLog.write(Core_Msg_FW_A.FCBAC0298, new Object[] { moduleid, screenid });
/* 222 */         return false;
/*     */       } 
/* 224 */       rpcid = MCConst.screen.getClassID(moduleid, screenid);
/* 225 */       if (rpcid == null)
/*     */       {
/* 227 */         MCLog.write(Core_Msg_FW_A.FCBAC0298, new Object[] { moduleid, screenid });
/* 228 */         return false;
/*     */       }
/*     */     
/*     */     }
/* 232 */     else if (model.getExecType() == MCMenuItemModel.MCMenuExecType.CLASS) {
/* 233 */       moduleid = model.moduleId();
/* 234 */       rpc = model.className();
/* 235 */       rpcid = model.classId();
/*     */     }
/*     */     else {
/*     */       
/* 239 */       MCLog.write(Core_Msg_FW_A.FCBAC0294, new Object[] { "EXEC", "CALSS" });
/* 240 */       return false;
/*     */     } 
/* 242 */     method = model.methodName();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 254 */     String actype = MCConst.actype
/* 255 */       .getType(new String[] { MCConst.createKey(new String[] { moduleid, rpcid, method }) });
/*     */     
/* 257 */     return MCACLManager.authorize(moduleid, rpcid, actype, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void setACLAll() {
/* 267 */     if (initCreate()) {
/* 268 */       MCMenuItemModel root = MCMenuModel.defultModel().getRootModel();
/*     */       
/* 270 */       List<MCMenuItemModel> list = root.childModels();
/* 271 */       for (int i = 0; i < list.size(); i++) {
/* 272 */         setACLAll(list.get(i));
/*     */       }
/* 274 */       MCMenuModel.defultModel().setACL(root);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final void setACLAll(MCMenuItemModel model) {
/* 287 */     if (model.isItemTag() || model.isExecTag()) {
/* 288 */       model.authority(checkACL(model));
/*     */     }
/* 290 */     else if (model.isMenuTag()) {
/* 291 */       List<MCMenuItemModel> list = model.childModels();
/* 292 */       boolean boo = false;
/* 293 */       for (int i = 0; i < list.size(); i++) {
/* 294 */         MCMenuItemModel child = list.get(i);
/* 295 */         if (child.isMenuTag() || child.isItemTag() || child.isExecTag()) {
/* 296 */           setACLAll(child);
/* 297 */           if (child.isView()) {
/* 298 */             boo = true;
/*     */           }
/*     */         } 
/*     */       } 
/* 302 */       if (model.isWindowMenu() || model.isBookMarkRoot()) {
/* 303 */         model.enable(true);
/*     */       } else {
/*     */         
/* 306 */         model.enable(boo);
/*     */       } 
/* 308 */       model.authority(true);
/* 309 */       MCMenuModel.defultModel().setACL(model);
/*     */     }
/* 311 */     else if (model.isSepTag()) {
/* 312 */       model.enable(true);
/* 313 */       model.authority(true);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void setACLChilden(MCMenuItemModel model) {
/* 327 */     if (!initCreate() && model.isMenuTag() && 
/* 328 */       !MCMenuModel.defultModel().isSetACL(model)) {
/* 329 */       List<MCMenuItemModel> list = model.childModels();
/* 330 */       for (int i = 0; i < list.size(); i++) {
/* 331 */         MCMenuItemModel child = list.get(i);
/* 332 */         if (child.isItemTag() || child.isExecTag()) {
/* 333 */           child.authority(checkACL(child));
/*     */         } else {
/*     */           
/* 336 */           child.enable(true);
/* 337 */           child.authority(true);
/*     */         } 
/*     */       } 
/* 340 */       model.enable(true);
/* 341 */       model.authority(true);
/* 342 */       MCMenuModel.defultModel().setACL(model);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<String[]> screenList() {
/* 361 */     if (MCMenuModel.defultModel() == null) {
/* 362 */       return null;
/*     */     }
/* 364 */     List<String[]> rtn = screenList(MCMenuModel.defultModel().getRootModel(), false);
/* 365 */     MCScreenIdComparator cm = new MCScreenIdComparator();
/* 366 */     String[][] ls = rtn.<String[]>toArray(new String[rtn.size()][2]);
/* 367 */     Arrays.sort(ls, cm);
/* 368 */     rtn.clear();
/* 369 */     rtn.addAll(Arrays.asList((String[])ls));
/* 370 */     return rtn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<String[]> screenListACL() {
/* 389 */     if (MCMenuModel.defultModel() == null) {
/* 390 */       return null;
/*     */     }
/* 392 */     List<String[]> rtn = screenList(MCMenuModel.defultModel().getRootModel(), true);
/* 393 */     MCScreenIdComparator cm = new MCScreenIdComparator();
/* 394 */     String[][] ls = rtn.<String[]>toArray(new String[rtn.size()][2]);
/* 395 */     Arrays.sort(ls, cm);
/* 396 */     rtn.clear();
/* 397 */     rtn.addAll(Arrays.asList((String[])ls));
/* 398 */     return rtn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static List<String[]> screenList(MCMenuItemModel root, boolean acl) {
/* 416 */     if (acl) {
/* 417 */       setACLChilden(root);
/*     */     }
/* 419 */     List<String[]> rtn = (List)new ArrayList<>();
/* 420 */     List<MCMenuItemModel> mls = root.childModels();
/* 421 */     int size = mls.size();
/* 422 */     for (int i = 0; i < size; i++) {
/* 423 */       MCMenuItemModel model = mls.get(i);
/* 424 */       if (!acl || model.isView())
/*     */       {
/*     */ 
/*     */         
/* 428 */         if (model.isItemTag()) {
/* 429 */           addItemTag(model, rtn);
/*     */         }
/* 431 */         else if (model.isMenuTag()) {
/* 432 */           List<String[]> temp = screenList(model, acl);
/* 433 */           int s = temp.size();
/* 434 */           for (int j = 0; j < s; j++) {
/* 435 */             if (!screenListContains(rtn, temp.get(j)))
/* 436 */               rtn.add(temp.get(j)); 
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/* 441 */     return rtn;
/*     */   }
/*     */   
/*     */   private static void addItemTag(MCMenuItemModel model, List<String[]> list) {
/* 445 */     if (!model.isLogOutMenu()) {
/* 446 */       String[] info = {
/* 447 */           model.screenId(), model.moduleId(), model.menuName()
/*     */         };
/* 449 */       if (!screenListContains(list, info)) {
/* 450 */         list.add(info);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean screenListContains(List<String[]> ls, String[] info) {
/* 467 */     int size = ls.size();
/* 468 */     for (int i = 0; i < size; i++) {
/* 469 */       if (((String[])ls.get(i))[0].equals(info[0]) && ((String[])ls.get(i))[1].equals(info[1]) && (
/* 470 */         (String[])ls.get(i))[2].equals(info[2])) {
/* 471 */         return true;
/*     */       }
/*     */     } 
/* 474 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<MCMenuItemModel> childModelsIsMenu(MCMenuItemModel root, String[] disable) {
/* 494 */     setACLChilden(root);
/* 495 */     List<MCMenuItemModel> list = root.childModels();
/* 496 */     List<MCMenuItemModel> rtn = new ArrayList<>();
/*     */     
/* 498 */     for (int i = 0; i < list.size(); i++) {
/* 499 */       MCMenuItemModel model = list.get(i);
/* 500 */       if (!model.isSepTag() && model.isView() && 
/* 501 */         disable != null) {
/* 502 */         String path = model.menuIdPath(".");
/* 503 */         boolean boo = false;
/* 504 */         for (int j = 0; j < disable.length; j++) {
/* 505 */           if (disable[j].equalsIgnoreCase(path)) {
/* 506 */             boo = true;
/*     */             break;
/*     */           } 
/*     */         } 
/* 510 */         if (boo) {
/*     */           continue;
/*     */         }
/*     */       } 
/*     */       
/* 515 */       rtn.add(model); continue;
/*     */     } 
/* 517 */     return rtn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean initCreate() {
/* 529 */     return MCConst.menu.initCreate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void showPanel(String mid, String sid) {
/* 548 */     if (sid == null) {
/* 549 */       throw new MCException(Core_Msg_FW_A.FCBAC0342, new Object[0]);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 555 */     MCMenuItemModel m = MCMenuModel.getItemModel(mid, sid);
/* 556 */     if (m == null) {
/* 557 */       throw new MCException(Core_Msg_FW_A.FCBAC0341, new Object[] { mid, sid });
/*     */     }
/* 559 */     showPanel(m);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void showPanel(MCMenuItemModel m) {
/* 572 */     if (!MCBeansUtil.checkMenuACLEx(null, m, "menu_item")) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 577 */     MCRootPanel panel = createPanel(m);
/*     */     
/* 579 */     MCFrame f = panel.getFrame();
/* 580 */     if (f != null) {
/* 581 */       f.setMenuModel(m);
/*     */     }
/* 583 */     MCBeansUtil.showPanel(panel, getPanelType(m), m.argsValues());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static MCFrameType getFrameType(MCMenuItemModel model) {
/* 595 */     MCFrame[] fs = MCBeansUtil.getAllFramesWithZOrder();
/* 596 */     if (fs != null && fs.length > 1 && 
/* 597 */       fs[0].getFrameType() == MCFrameType.SYSTEM_MODAL) {
/* 598 */       return MCFrameType.SYSTEM_MODAL;
/*     */     }
/*     */ 
/*     */     
/* 602 */     return (model.frameType() == MCMenuItemModel.MCMenuItemFrame.MODELESS) ? MCFrameType.MODELESS : 
/* 603 */       MCFrameType.SYSTEM_MODAL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static MCPanelType getPanelType(MCMenuItemModel model) {
/* 615 */     return (model.panelType() == MCMenuItemModel.MCMenuItemMode.MULTI) ? MCPanelType.MULTI : 
/* 616 */       MCPanelType.SINGLE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static MCRootPanel createPanel(MCMenuItemModel model) {
/* 628 */     MCFrameType ft = getFrameType(model);
/* 629 */     Object[] param = model.argsValues();
/* 630 */     MCRootPanel panel = MCBeansProxy.PROXY.createPanelM(model, null, 
/* 631 */         model.moduleId(), model.screenId(), ft, param);
/* 632 */     return panel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void updateMenuIndex(MCMenuItemModel... modeles) {
/* 645 */     MCList<MenuR> up0 = MCList.create(MenuR.class);
/* 646 */     for (int i = 0; i < modeles.length; i++) {
/* 647 */       MenuR r = MenuR.create();
/* 648 */       if (modeles[i].bookmarkID() == null) {
/*     */         
/* 650 */         r.parent_menu_id(modeles[i].parentMenuId());
/* 651 */         r.menu_id(modeles[i].menuId());
/* 652 */         r.menu_order(modeles[i].order());
/* 653 */         r.co_cd(modeles[i].coCd());
/* 654 */         r.ext_attr1(modeles[i].extAttr1());
/* 655 */         r.ext_attr2(modeles[i].extAttr2());
/* 656 */         r.ext_attr3(modeles[i].extAttr3());
/* 657 */         up0.add((MCRow)r);
/*     */       }
/*     */       else {
/*     */         
/* 661 */         r.parent_menu_id("BOOKMARK");
/* 662 */         r.bookmark(true);
/* 663 */         up0.add((MCRow)r);
/*     */       } 
/*     */     } 
/* 666 */     MCList<MenuR> dw0 = MCList.create(MenuR.class);
/* 667 */     updateMenuIndex(up0, dw0);
/*     */     
/* 669 */     for (int j = 0; j < modeles.length; j++) {
/* 670 */       modeles[j].menuIndex(((MenuR)dw0.get(j)).menu_index());
/* 671 */       if (modeles[j].bookmarkID() != null) {
/* 672 */         MCConst.menu.addBookMark(modeles[j]);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MenuR updateMenuIndex(MenuR up) {
/* 687 */     MCList<MenuR> upls = MCList.create(MenuR.class);
/* 688 */     upls.add((MCRow)up);
/* 689 */     MCList<MenuR> dwls = MCList.create(MenuR.class);
/* 690 */     updateMenuIndex(upls, dwls);
/*     */     
/* 692 */     if (dwls.size() > 0) {
/* 693 */       return (MenuR)dwls.get(0);
/*     */     }
/* 695 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void updateMenuIndex(MCList<MenuR> up, MCList<MenuR> dw) {
/* 710 */     MCParam p = new MCParam("FC", "FCBAL0010", "UpdateIndex", "000000");
/* 711 */     p.setDef((MCDef)new PDef());
/* 712 */     p.addUpBlock((MCContainer)up);
/* 713 */     p.addDownBlock((MCContainer)dw);
/*     */     
/* 715 */     MCCaller c = new MCCaller(p);
/* 716 */     c.exec();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void resetBookMarkACL() {
/* 726 */     setACLAll(MCConst.menu.getBookmarkModel());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static ImageIcon getMenuIcon(MCBinary b) {
/* 739 */     if (b != null) {
/* 740 */       URL u = MCDownloader.getBinaryURL(b);
/* 741 */       ImageIcon i = new ImageIcon(u);
/* 742 */       if (isDiffIconSize(i, _defIconSize)) {
/* 743 */         return MCBeansUtil.adjustIconSize(i, _defIconSize);
/*     */       }
/* 745 */       return i;
/*     */     } 
/* 747 */     return _defIcon;
/*     */   }
/*     */   
/*     */   private static boolean isDiffIconSize(ImageIcon i, Dimension size) {
/* 751 */     return !(i.getIconWidth() == size.width && i.getIconHeight() == size.height);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImageIcon getMenuIcon(String clsPath) {
/* 764 */     ImageIcon i = MCBeansUtil.getIcon(clsPath);
/* 765 */     if (i != null) {
/* 766 */       if (isDiffIconSize(i, _defIconSize)) {
/* 767 */         return MCBeansUtil.adjustIconSize(i, _defIconSize);
/*     */       }
/* 769 */       return i;
/*     */     } 
/* 771 */     return _defIcon;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ImageIcon getMenuIcon(MCMenuItemModel model) {
/* 783 */     if (model != null) {
/* 784 */       MCBinary b = model.menuImage();
/* 785 */       if (b != null) {
/* 786 */         return getMenuIcon(b);
/*     */       }
/* 788 */       String s = MCConst.menu.getString("img." + model.menuId());
/* 789 */       return getMenuIcon(s);
/*     */     } 
/* 791 */     return _defIcon;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\menu\MCMenuBeansUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */