/*     */ package mcframe.clientCore.beans.menu;
/*     */ 
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.SwingUtilities;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.resource.MCMenuItemModel;
/*     */ import mcframe.clientCore.resource.MCMenuModel;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.sys.MCFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCMenuItemListener
/*     */   implements ActionListener
/*     */ {
/*  35 */   private static final Object lockObj = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  40 */   private MCMenuItemModel model = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  45 */   private MCMenuItem item = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCMenuItemListener(MCMenuItem item, MCMenuItemModel model) {
/*  70 */     this.model = model;
/*  71 */     this.item = item;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void actionPerformed(ActionEvent e) {
/*  97 */     if (this.model.isExecTag()) {
/*  98 */       Runnable runner = new ExecMaker(e, null);
/*  99 */       SwingUtilities.invokeLater(runner);
/* 100 */     } else if (this.model.isItemTag()) {
/*     */       
/* 102 */       Runnable runner = new ScreenMaker(e, null);
/* 103 */       SwingUtilities.invokeLater(runner);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isLogoutModel(MCMenuItemModel model) {
/* 115 */     return (model.moduleId().equals("FS") && 
/* 116 */       model.screenId().equals("FSBHP0020"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isEnable() {
/*     */     boolean ret;
/* 133 */     synchronized (lockObj) {
/* 134 */       ret = (MCBeansUtil.getRootPanel(this.model.moduleId(), 
/* 135 */           this.model.screenId()) != null);
/*     */     } 
/* 137 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void modelActive() {
/* 150 */     MCRootPanel p = MCBeansUtil.getRootPanel(this.model.moduleId(), 
/* 151 */         this.model.screenId());
/* 152 */     if (p != null) {
/* 153 */       p.moveToFront();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void modelActiveSerial() {
/* 165 */     if (this.item != null) {
/* 166 */       MCRootPanel p = MCBeansUtil.getRootPanel(this.model.moduleId(), 
/* 167 */           this.model.screenId(), 
/* 168 */           this.item.screenSerial());
/* 169 */       if (p != null) {
/* 170 */         p.moveToFront();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCMenuItemListener() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final class ScreenMaker
/*     */     implements Runnable
/*     */   {
/*     */     private ScreenMaker(ActionEvent e) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void run() {
/*     */       try {
/* 205 */         if (MCMenuItemListener.this.item != null && MCMenuItemListener.this.item.screenSerial() >= 0) {
/* 206 */           MCMenuItemListener.this.modelActiveSerial();
/*     */         }
/* 208 */         else if (MCMenuItemListener.this.model.isSingle() && MCMenuItemListener.this.isEnable()) {
/*     */ 
/*     */           
/* 211 */           MCMenuItemListener.this.modelActive();
/*     */ 
/*     */         
/*     */         }
/* 215 */         else if (MCMenuItemListener.this.model.bookmarkID() == null) {
/* 216 */           MCMenuBeansUtil.showPanel(MCMenuItemListener.this.model);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         }
/*     */         else {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 227 */           MCMenuItemListener.this.model.perGrpId(null);
/*     */ 
/*     */           
/* 230 */           if (!MCStringUtil.isNull(MCMenuItemListener.this.model.methodName()) || 
/* 231 */             !MCStringUtil.isNull(MCMenuItemListener.this.model.className())) {
/* 232 */             MCMenuBeansUtil.showPanel(MCMenuItemListener.this.model);
/*     */           
/*     */           }
/*     */           else {
/*     */             
/* 237 */             MCMenuItemModel bm = MCMenuItemListener.this.model.clone();
/* 238 */             MCMenuItemModel sm = MCMenuModel.getSrcMenuItemModel(bm);
/*     */             
/* 240 */             if (sm != null) {
/*     */               
/* 242 */               String id = sm.perGrpId();
/* 243 */               if (!MCStringUtil.isNull(id)) {
/* 244 */                 bm.className(id);
/*     */               }
/*     */             } 
/* 247 */             MCMenuBeansUtil.showPanel(bm);
/*     */           }
/*     */         
/*     */         }
/*     */       
/*     */       }
/* 253 */       catch (Throwable ex) {
/* 254 */         MCBeansUtil.handle(null, ex);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final class ExecMaker
/*     */     implements Runnable
/*     */   {
/*     */     private ExecMaker(ActionEvent e) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void run() {
/*     */       try {
/* 291 */         Object ob = null;
/* 292 */         if (MCMenuItemListener.this.model.getExecType() == MCMenuItemModel.MCMenuExecType.SCREEN) {
/* 293 */           ob = MCMenuBeansUtil.createPanel(MCMenuItemListener.this.model);
/* 294 */         } else if (MCMenuItemListener.this.model.getExecType() == MCMenuItemModel.MCMenuExecType.CLASS) {
/* 295 */           ob = MCFactory.create(Object.class, MCMenuItemListener.this.model.className());
/*     */         } 
/* 297 */         if (ob == null) {
/* 298 */           MCBeansUtil.handle(null, (Throwable)new MCException(Core_Msg_FW_A.FCBAC0326, new Object[0]));
/*     */           
/*     */           return;
/*     */         } 
/* 302 */         MCFactory.invoke(ob, MCMenuItemListener.this.model.methodName(), 
/* 303 */             MCMenuItemListener.this.model.argsClasses(), MCMenuItemListener.this.model.argsValues());
/*     */       }
/* 305 */       catch (Throwable ex) {
/* 306 */         MCBeansUtil.handle(null, ex);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\menu\MCMenuItemListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */