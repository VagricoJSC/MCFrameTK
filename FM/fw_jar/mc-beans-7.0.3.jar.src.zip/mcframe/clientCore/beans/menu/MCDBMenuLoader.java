/*     */ package mcframe.clientCore.beans.menu;
/*     */ 
/*     */ import mcframe.clientCore.beans.menu.requester.CndR;
/*     */ import mcframe.clientCore.beans.menu.requester.MenuArgsR;
/*     */ import mcframe.clientCore.beans.menu.requester.MenuR;
/*     */ import mcframe.clientCore.beans.menu.requester.PDef;
/*     */ import mcframe.clientCore.requester.MCCaller;
/*     */ import mcframe.clientCore.resource.MCMenuItemModel;
/*     */ import mcframe.clientCore.resource.MCMenuLoader;
/*     */ import mcframe.clientCore.resource.MCMenuModel;
/*     */ import mcframe.commonCore.container.MCContainer;
/*     */ import mcframe.commonCore.container.MCIndexKey;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.param.MCDef;
/*     */ import mcframe.commonCore.param.MCParam;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCDBMenuLoader
/*     */   implements MCMenuLoader
/*     */ {
/*     */   public MCMenuModel load() {
/*  32 */     MCList<MenuR> dw0 = MCList.create(MenuR.class);
/*     */     
/*  34 */     MCList<MenuArgsR> dw1 = MCList.create(MenuArgsR.class);
/*     */     
/*  36 */     MCMenuModel rtn = MCMenuModel.createNewDocument("a", "i", null);
/*     */     
/*  38 */     MCParam p = new MCParam("FC", "FCBAL0010", "Select", "000000");
/*  39 */     p.setDef((MCDef)new PDef());
/*  40 */     CndR r = CndR.create();
/*  41 */     r.select_mode("1");
/*  42 */     p.addUpBlock((MCContainer)r);
/*  43 */     p.addDownBlock((MCContainer)dw0);
/*  44 */     p.addDownBlock((MCContainer)dw1);
/*  45 */     p.setLimitDLSize(new MCNumber(-1));
/*     */     
/*  47 */     MCCaller c = new MCCaller(p);
/*  48 */     c.exec();
/*     */     
/*  50 */     MCIndexKey k0 = dw0.createIndex(new String[] { "parent_menu_id" });
/*  51 */     MCIndexKey k1 = dw1.createIndex(new String[] { "parent_menu_id", "menu_id" });
/*     */ 
/*     */     
/*  54 */     addMenus(rtn.getRootModel(), "MCF", dw0, k0, dw1, k1);
/*     */     
/*  56 */     return rtn;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addMenus(MCMenuItemModel p, String parentMenuIdWithMenuId, MCList<MenuR> dw0, MCIndexKey k0, MCList<MenuArgsR> dw1, MCIndexKey k1) {
/*  74 */     MCList<MenuR> rootLs = dw0.subList(k0, new Comparable[] { parentMenuIdWithMenuId });
/*  75 */     rootLs.forEach(rr -> {
/*     */           MCList<MenuArgsR> args = paramMCList1.subList(paramMCIndexKey1, new Comparable[] { rr.parent_menu_id(), rr.menu_id() });
/*     */           MCMenuItemModel add = addMenu(paramMCMenuItemModel, rr, args);
/*     */           addMenus(add, add.parentMenuIdWithMenuId(), paramMCList2, paramMCIndexKey2, paramMCList1, paramMCIndexKey1);
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCMenuItemModel addMenu(MCMenuItemModel p, MenuR r, MCList<MenuArgsR> args) {
/*  94 */     MCMenuItemModel m = new MCMenuItemModel(p, MCMenuItemModel.MCMenuType.getMenuType(r.menu_type()));
/*     */     
/*  96 */     m.parentMenuId(r.parent_menu_id());
/*  97 */     m.menuId(r.menu_id());
/*  98 */     m.order(r.menu_order());
/*  99 */     m.title(r.menu_title());
/* 100 */     m.masterTitle(r.menu_master_title());
/* 101 */     m.moduleId(r.module_id());
/* 102 */     m.screenId(r.screen_id());
/* 103 */     m.panelType(r.screen_mode());
/* 104 */     m.frameType(r.frame_type());
/* 105 */     m.perGrpId(r.per_grp_id());
/* 106 */     m.classId(r.menu_class_id());
/* 107 */     m.className(r.menu_classname());
/* 108 */     m.methodName(r.menu_method());
/* 109 */     m.acceleratorKey(r.accesskey());
/* 110 */     m.shortCutKey(r.shortcutkey());
/* 111 */     m.maskKey(r.maskkey());
/* 112 */     m.acType(r.ac());
/* 113 */     m.coCd(r.co_cd());
/* 114 */     m.extAttr1(r.ext_attr1());
/* 115 */     m.extAttr2(r.ext_attr2());
/* 116 */     m.extAttr3(r.ext_attr3());
/* 117 */     m.visible(r.menu_visible());
/* 118 */     m.coreMenu(r.core_menu());
/* 119 */     m.menuImage(r.menu_image());
/* 120 */     m.menuIndex(r.menu_index());
/*     */     
/* 122 */     if (!args.isEmpty()) {
/* 123 */       args.sort(new String[] { "args_order" });
/* 124 */       args.forEach(ar -> {
/*     */             MCMenuItemModel arg = paramMCMenuItemModel.addItemModel(MCMenuItemModel.MCMenuType.ARGS);
/*     */             
/*     */             arg.parentMenuId(ar.parent_menu_id());
/*     */             arg.menuId(ar.menu_id());
/*     */             arg.order(ar.args_order());
/*     */             arg.argsName(ar.args_nm());
/*     */             arg.dataType(ar.args_type());
/*     */             arg.argsVale(ar.args_value());
/*     */           });
/*     */     } 
/* 135 */     p.addChilderen(m);
/*     */     
/* 137 */     return m;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLoadErrMsg() {
/* 142 */     return Core_Msg_FW_A.FCBAC0356;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isDbType() {
/* 147 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\menu\MCDBMenuLoader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */