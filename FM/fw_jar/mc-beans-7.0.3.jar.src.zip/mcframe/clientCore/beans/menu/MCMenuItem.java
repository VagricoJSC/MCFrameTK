/*     */ package mcframe.clientCore.beans.menu;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.MouseEvent;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.KeyStroke;
/*     */ import javax.swing.MenuElement;
/*     */ import mcframe.clientCore.beans.MCPanelType;
/*     */ import mcframe.clientCore.beans.layout.MCHiresoManager;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ import mcframe.clientCore.resource.MCMenuItemModel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MCMenuItem
/*     */   extends JMenuItem
/*     */   implements MenuElement
/*     */ {
/*  41 */   private MCMenuItemModel _model = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   private int _srcSerial = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean _isWindow = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String screenId() {
/*  66 */     return (this._model == null) ? null : this._model.screenId();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String moduleId() {
/*  77 */     return (this._model == null) ? null : this._model.moduleId();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String methodName() {
/*  88 */     return (this._model == null) ? null : this._model.methodName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String className() {
/*  99 */     return (this._model == null) ? null : this._model.className();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCPanelType panelType() {
/* 110 */     return (this._model != null && 
/* 111 */       this._model.panelType().equals(MCMenuItemModel.MCMenuItemMode.SINGLE)) ? 
/* 112 */       MCPanelType.SINGLE : 
/* 113 */       MCPanelType.MULTI;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void menuItemModel(MCMenuItemModel model) {
/* 125 */     this._model = model;
/* 126 */     updateMenuItemModel();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCMenuItemModel getMenuItemModel() {
/* 138 */     return this._model;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setEnabled(boolean boo) {
/* 150 */     if (this._model == null) {
/* 151 */       super.setEnabled(boo);
/*     */       return;
/*     */     } 
/* 154 */     if (!this._model.enable() && 
/* 155 */       boo)
/*     */       return; 
/* 157 */     super.setEnabled(boo);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateMenuItemModel() {
/* 167 */     setText(this._model.menuName());
/* 168 */     setMnemonicItem();
/* 169 */     setAccelaratorKey();
/* 170 */     setEnabled(this._model.isView());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setText(String text) {
/* 182 */     if (this._model.acceleratorKey() != null && 
/* 183 */       !this._model.acceleratorKey().equals("")) {
/* 184 */       char c = this._model.acceleratorKey().charAt(0);
/* 185 */       if (this._model.menuName().indexOf(c) == -1) {
/* 186 */         text = String.valueOf(text) + "(" + c + ")";
/*     */       }
/*     */     } 
/* 189 */     super.setText(text);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void setAccelaratorKey() {
/* 201 */     if (this._model.shortCutKey() != null && 
/* 202 */       !this._model.shortCutKey().equals("")) {
/* 203 */       KeyStroke ks = getKeyStroke();
/* 204 */       if (ks != null) {
/* 205 */         setAccelerator(ks);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public KeyStroke getKeyStroke() {
/* 219 */     KeyStroke ks = null;
/*     */     
/* 221 */     if (this._model.maskKey().equals("SHIFT_MASK")) {
/* 222 */       ks = KeyStroke.getKeyStroke(this._model.shortCutKey().charAt(0), 
/* 223 */           1);
/* 224 */     } else if (this._model.maskKey().equals("CTRL_MASK")) {
/* 225 */       ks = KeyStroke.getKeyStroke(this._model.shortCutKey().charAt(0), 
/* 226 */           2);
/* 227 */     } else if (this._model.maskKey().equals("META_MASK")) {
/* 228 */       ks = KeyStroke.getKeyStroke(this._model.shortCutKey().charAt(0), 
/* 229 */           4);
/* 230 */     } else if (this._model.maskKey().equals("ALT_MASK")) {
/* 231 */       ks = KeyStroke.getKeyStroke(this._model.shortCutKey().charAt(0), 
/* 232 */           8);
/*     */     } 
/* 234 */     return ks;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void setMnemonicItem() {
/* 245 */     if (this._model.acceleratorKey() != null && 
/* 246 */       !this._model.acceleratorKey().equals("")) {
/* 247 */       setMnemonic(this._model.acceleratorKey().charAt(0));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getToolTipText(MouseEvent event) {
/* 254 */     String tip = getToolTipText();
/* 255 */     tip = MCHiresoManager.getToolTipText(this, tip);
/* 256 */     return tip;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCMenuItem() {
/* 270 */     setForeground();
/* 271 */     setBackground();
/* 272 */     setFont();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setForeground() {
/* 283 */     String key = MCConst.createKey(new String[] { "popup", "fg" });
/* 284 */     Color fg = MCConst.beans.getColor(key);
/* 285 */     if (fg != null) {
/* 286 */       setForeground(fg);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setBackground() {
/* 298 */     String key = MCConst.createKey(new String[] { "popup", "bg" });
/* 299 */     Color fg = MCConst.beans.getColor(key);
/* 300 */     if (fg != null) {
/* 301 */       setBackground(fg);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setFont() {
/* 313 */     String key = MCConst.createKey(new String[] { "popup", "font" });
/* 314 */     Font font = MCConst.beans.getFont(key);
/* 315 */     if (font != null) {
/* 316 */       setFont(font);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int screenSerial() {
/* 328 */     return this._srcSerial;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void screenSerial(int srcSerial) {
/* 339 */     this._srcSerial = srcSerial;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void windowItem(boolean boo) {
/* 351 */     this._isWindow = boo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isWindowItem() {
/* 362 */     return this._isWindow;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\menu\MCMenuItem.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */