/*     */ package mcframe.clientCore.beans.menu.requester;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.clientCore.container.MCKeyList;
/*     */ import mcframe.commonCore.container.MCExtMap;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class CndR_FW_A
/*     */   extends MCConstRow
/*     */ {
/*     */   public static final String $select_mode = "select_mode";
/*  32 */   public static final MCMeta select_mode_META = createStringMeta("select_mode");
/*     */   
/*  34 */   protected static final MCRow.ConstMetaList<CndR> constMetas = new MCRow.ConstMetaList(
/*  35 */       MCConstRow.constMetas, 
/*  36 */       new MCMeta[] {
/*  37 */         select_mode_META
/*     */       },
/*  39 */       new String[][] { {}, {} });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  50 */   protected static final MCKeyList KEYS = new MCKeyList(
/*  51 */       null, 
/*  52 */       new String[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   protected static final MCExtMap EXTMAP = new MCExtMap(
/*  61 */       null, new MCExtMap.Entry[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] colnames() {
/*  73 */     return constMetas.toNameArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMeta[] colmetas() {
/*  85 */     return constMetas.toMetaArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  91 */   private static final int offset = constMetas.offset();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCKeyList getKeys() {
/*  97 */     return KEYS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getExtMap(String aGroup) {
/* 104 */     if (aGroup == null) return null; 
/* 105 */     return (Map<String, String>)EXTMAP.get(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCKeyList getKeys(String aGroup) {
/* 112 */     if (aGroup == null) return null; 
/* 113 */     return new MCKeyList(EXTMAP.getKeyList(aGroup));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExtGroups() {
/* 120 */     Set<String> ret = EXTMAP.keySet();
/* 121 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected CndR_FW_A(MCRow.ConstMetaList<? extends CndR> metas) {
/* 128 */     super(metas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CndR clone() {
/* 135 */     return (CndR)super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CndR createInstance() {
/* 142 */     return (CndR)super.createInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CndR getValues(String... names) {
/* 149 */     return (CndR)super.getValues(names);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String select_mode() {
/* 155 */     return getConstString(offset + 0, "select_mode");
/*     */   }
/*     */   
/*     */   public void select_mode(String value) {
/* 159 */     setConstString(offset + 0, "select_mode", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString(String name) {
/* 164 */     if ("select_mode".equalsIgnoreCase(name)) {
/* 165 */       return select_mode();
/*     */     }
/* 167 */     return super.getString(name);
/*     */   }
/*     */   
/*     */   public String getStringNE(String name) {
/* 171 */     if ("select_mode".equalsIgnoreCase(name)) {
/* 172 */       return select_mode();
/*     */     }
/* 174 */     return super.getStringNE(name);
/*     */   }
/*     */   
/*     */   public void setString(String name, String value) {
/* 178 */     if ("select_mode".equalsIgnoreCase(name)) {
/* 179 */       select_mode(value);
/*     */       return;
/*     */     } 
/* 182 */     super.setString(name, value);
/*     */   }
/*     */   
/*     */   public void setStringNE(String name, String value) {
/* 186 */     if ("select_mode".equalsIgnoreCase(name)) {
/* 187 */       select_mode(value);
/*     */       return;
/*     */     } 
/* 190 */     super.setStringNE(name, value);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\menu\requester\CndR_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */