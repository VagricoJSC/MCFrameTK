/*     */ package mcframe.clientCore.beans.menu.requester;
/*     */ 
/*     */ import mcframe.commonCore.param.MCBlockDef;
/*     */ import mcframe.commonCore.param.MCContainerDef;
/*     */ import mcframe.commonCore.param.MCDef;
/*     */ import mcframe.commonCore.param.MCGeneralContainerDef;
/*     */ import mcframe.commonCore.param.MCItemDef;
/*     */ import mcframe.commonCore.param.MCOperationInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PDef_FW_A
/*     */   extends MCDef
/*     */ {
/*     */   public MCContainerDef getCustomDef(String id) {
/*  19 */     if (id == null) {
/*  20 */       return null;
/*     */     }
/*     */     
/*  23 */     if (id.equals("FC.FCBAL0010.Select.UP.BLOCK0")) {
/*  24 */       return FC_FCBAL0010_Select_UP_BLOCK0();
/*     */     }
/*  26 */     if (id.equals("FC.FCBAL0010.Select.DOWN.BLOCK0")) {
/*  27 */       return FC_FCBAL0010_Select_DOWN_BLOCK0();
/*     */     }
/*  29 */     if (id.equals("FC.FCBAL0010.Select.DOWN.BLOCK1")) {
/*  30 */       return FC_FCBAL0010_Select_DOWN_BLOCK1();
/*     */     }
/*  32 */     if (id.equals("FC.FCBAL0010.UpdateIndex.UP.BLOCK0")) {
/*  33 */       return FC_FCBAL0010_UpdateIndex_UP_BLOCK0();
/*     */     }
/*  35 */     if (id.equals("FC.FCBAL0010.UpdateIndex.DOWN.BLOCK0")) {
/*  36 */       return FC_FCBAL0010_UpdateIndex_DOWN_BLOCK0();
/*     */     }
/*     */ 
/*     */     
/*  40 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   static final MCOperationInfo FC_FCBAL0010_Select_INFO = new MCOperationInfo("FC", "FCBAL0010", "Select", "0", new PDef());
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBAL0010_Select_UP_BLOCK0() {
/*  50 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBAL0010", "Select", 
/*  51 */         new MCItemDef[] {
/*  52 */           MCItemDef.create("select_mode", "select_mode")
/*     */ 
/*     */         
/*  55 */         }MCBlockDef.create("Cnd"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBAL0010_Select_DOWN_BLOCK0() {
/*  62 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBAL0010", "Select", 
/*  63 */         new MCItemDef[] { 
/*  64 */           MCItemDef.create("parent_menu_id", "parent_menu_id"), 
/*  65 */           MCItemDef.create("menu_id", "menu_id"), 
/*  66 */           MCItemDef.create("menu_order", "menu_order"), 
/*  67 */           MCItemDef.create("menu_type", "menu_type"), 
/*  68 */           MCItemDef.create("menu_title", "menu_title"), 
/*  69 */           MCItemDef.create("menu_master_title", "menu_master_title"), 
/*  70 */           MCItemDef.create("module_id", "module_id"), 
/*  71 */           MCItemDef.create("screen_id", "screen_id"), 
/*  72 */           MCItemDef.create("screen_mode", "screen_mode"), 
/*  73 */           MCItemDef.create("frame_type", "frame_type"), 
/*  74 */           MCItemDef.create("per_grp_id", "per_grp_id"), 
/*  75 */           MCItemDef.create("menu_class_id", "menu_class_id"), 
/*  76 */           MCItemDef.create("menu_classname", "menu_classname"), 
/*  77 */           MCItemDef.create("menu_method", "menu_method"), 
/*  78 */           MCItemDef.create("accesskey", "accesskey"), 
/*  79 */           MCItemDef.create("shortcutkey", "shortcutkey"), 
/*  80 */           MCItemDef.create("maskkey", "maskkey"), 
/*  81 */           MCItemDef.create("ac", "ac"), 
/*  82 */           MCItemDef.create("co_cd", "co_cd"), 
/*  83 */           MCItemDef.create("ext_attr1", "ext_attr1"), 
/*  84 */           MCItemDef.create("ext_attr2", "ext_attr2"), 
/*  85 */           MCItemDef.create("ext_attr3", "ext_attr3"), 
/*  86 */           MCItemDef.create("menu_visible", "menu_visible"), 
/*  87 */           MCItemDef.create("core_menu", "core_menu"), 
/*  88 */           MCItemDef.create("menu_image", "menu_image"), 
/*  89 */           MCItemDef.create("menu_index", "menu_index"), 
/*  90 */           MCItemDef.IGNORE_ITEM("bookmark")
/*     */ 
/*     */         
/*  93 */         }MCBlockDef.create("Menu"));
/*     */   }
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBAL0010_Select_DOWN_BLOCK1() {
/*  98 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBAL0010", "Select", 
/*  99 */         new MCItemDef[] {
/* 100 */           MCItemDef.create("parent_menu_id", "parent_menu_id"), 
/* 101 */           MCItemDef.create("menu_id", "menu_id"), 
/* 102 */           MCItemDef.create("args_nm", "args_nm"), 
/* 103 */           MCItemDef.create("args_order", "args_order"), 
/* 104 */           MCItemDef.create("args_type", "args_type"), 
/* 105 */           MCItemDef.create("args_value", "args_value"), 
/* 106 */           MCItemDef.create("co_cd", "co_cd"), 
/* 107 */           MCItemDef.create("ext_attr1", "ext_attr1"), 
/* 108 */           MCItemDef.create("ext_attr2", "ext_attr2"), 
/* 109 */           MCItemDef.create("ext_attr3", "ext_attr3")
/*     */ 
/*     */         
/* 112 */         }MCBlockDef.create("MenuArgs"));
/*     */   }
/*     */ 
/*     */   
/* 116 */   static final MCOperationInfo FC_FCBAL0010_UpdateIndex_INFO = new MCOperationInfo("FC", "FCBAL0010", "UpdateIndex", "000000", new PDef());
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBAL0010_UpdateIndex_UP_BLOCK0() {
/* 120 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBAL0010", "UpdateIndex", 
/* 121 */         new MCItemDef[] {
/* 122 */           MCItemDef.create("parent_menu_id", "parent_menu_id"), 
/* 123 */           MCItemDef.create("menu_id", "menu_id"), 
/* 124 */           MCItemDef.create("menu_order", "menu_order"), 
/* 125 */           MCItemDef.create("co_cd", "co_cd"), 
/* 126 */           MCItemDef.create("ext_attr1", "ext_attr1"), 
/* 127 */           MCItemDef.create("ext_attr2", "ext_attr2"), 
/* 128 */           MCItemDef.create("ext_attr3", "ext_attr3"), 
/* 129 */           MCItemDef.create("bookmark", "bookmark")
/*     */ 
/*     */         
/* 132 */         }MCBlockDef.create("Menu"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCContainerDef FC_FCBAL0010_UpdateIndex_DOWN_BLOCK0() {
/* 139 */     return (MCContainerDef)new MCGeneralContainerDef("FC", "FCBAL0010", "UpdateIndex", 
/* 140 */         new MCItemDef[] {
/* 141 */           MCItemDef.create("menu_index", "menu_index")
/*     */ 
/*     */         
/* 144 */         }MCBlockDef.create("Menu"));
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\menu\requester\PDef_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */