/*     */ package mcframe.clientCore.beans.menu.requester;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.clientCore.container.MCKeyList;
/*     */ import mcframe.commonCore.container.MCExtMap;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCBinary;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ import mcframe.commonCore.meta.M_META;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class MenuR_FW_A
/*     */   extends MCConstRow
/*     */ {
/*     */   public static final String $parent_menu_id = "parent_menu_id";
/*     */   public static final String $menu_id = "menu_id";
/*     */   public static final String $menu_order = "menu_order";
/*     */   public static final String $menu_type = "menu_type";
/*     */   public static final String $menu_title = "menu_title";
/*     */   public static final String $menu_master_title = "menu_master_title";
/*     */   public static final String $module_id = "module_id";
/*     */   public static final String $screen_id = "screen_id";
/*     */   public static final String $screen_mode = "screen_mode";
/*     */   public static final String $frame_type = "frame_type";
/*     */   public static final String $per_grp_id = "per_grp_id";
/*     */   public static final String $menu_class_id = "menu_class_id";
/*     */   public static final String $menu_classname = "menu_classname";
/*     */   public static final String $menu_method = "menu_method";
/*     */   public static final String $accesskey = "accesskey";
/*     */   public static final String $shortcutkey = "shortcutkey";
/*     */   public static final String $maskkey = "maskkey";
/*     */   public static final String $ac = "ac";
/*     */   public static final String $co_cd = "co_cd";
/*     */   public static final String $ext_attr1 = "ext_attr1";
/*     */   public static final String $ext_attr2 = "ext_attr2";
/*     */   public static final String $ext_attr3 = "ext_attr3";
/*     */   public static final String $menu_visible = "menu_visible";
/*     */   public static final String $core_menu = "core_menu";
/*     */   public static final String $bookmark = "bookmark";
/*     */   public static final String $menu_image = "menu_image";
/*     */   public static final String $menu_index = "menu_index";
/*  58 */   public static final MCMeta parent_menu_id_META = createCommonMeta("parent_menu_id", M_META.PARENT_MENU_ID);
/*  59 */   public static final MCMeta menu_id_META = createCommonMeta("menu_id", M_META.MENU_ID);
/*  60 */   public static final MCMeta menu_order_META = createCommonMeta("menu_order", M_META.INT);
/*  61 */   public static final MCMeta menu_type_META = createCommonMeta("menu_type", M_META.MENU_TYPE);
/*  62 */   public static final MCMeta menu_title_META = createCommonMeta("menu_title", M_META.MENU_TITLE);
/*  63 */   public static final MCMeta menu_master_title_META = createCommonMeta("menu_master_title", M_META.MENU_TITLE);
/*  64 */   public static final MCMeta module_id_META = createCommonMeta("module_id", M_META.MODULE_ID);
/*  65 */   public static final MCMeta screen_id_META = createCommonMeta("screen_id", M_META.SCREEN_ID);
/*  66 */   public static final MCMeta screen_mode_META = createCommonMeta("screen_mode", M_META.SCREEN_MODE);
/*  67 */   public static final MCMeta frame_type_META = createCommonMeta("frame_type", M_META.FRAME_TYPE);
/*  68 */   public static final MCMeta per_grp_id_META = createCommonMeta("per_grp_id", M_META.RES_KEY);
/*  69 */   public static final MCMeta menu_class_id_META = createCommonMeta("menu_class_id", M_META.MENU_CLASS_ID);
/*  70 */   public static final MCMeta menu_classname_META = createCommonMeta("menu_classname", M_META.MENU_CLASSNAME);
/*  71 */   public static final MCMeta menu_method_META = createCommonMeta("menu_method", M_META.MENU_METHOD);
/*  72 */   public static final MCMeta accesskey_META = createCommonMeta("accesskey", M_META.ACCESSKEY);
/*  73 */   public static final MCMeta shortcutkey_META = createCommonMeta("shortcutkey", M_META.SHORTCUTKEY);
/*  74 */   public static final MCMeta maskkey_META = createCommonMeta("maskkey", M_META.MASKKEY);
/*  75 */   public static final MCMeta ac_META = createCommonMeta("ac", M_META.AC);
/*  76 */   public static final MCMeta co_cd_META = createCommonMeta("co_cd", M_META.CO_CD);
/*  77 */   public static final MCMeta ext_attr1_META = createCommonMeta("ext_attr1", M_META.USR_EXT_ATTR);
/*  78 */   public static final MCMeta ext_attr2_META = createCommonMeta("ext_attr2", M_META.USR_EXT_ATTR);
/*  79 */   public static final MCMeta ext_attr3_META = createCommonMeta("ext_attr3", M_META.USR_EXT_ATTR);
/*  80 */   public static final MCMeta menu_visible_META = createCommonMeta("menu_visible", M_META.FLG);
/*  81 */   public static final MCMeta core_menu_META = createCommonMeta("core_menu", M_META.FLG);
/*  82 */   public static final MCMeta bookmark_META = createCommonMeta("bookmark", M_META.FLG);
/*  83 */   public static final MCMeta menu_image_META = createCommonMeta("menu_image", M_META.BIN);
/*  84 */   public static final MCMeta menu_index_META = createCommonMeta("menu_index", M_META.NUM_STR);
/*     */   
/*  86 */   protected static final MCRow.ConstMetaList<MenuR> constMetas = new MCRow.ConstMetaList(
/*  87 */       MCConstRow.constMetas, 
/*  88 */       new MCMeta[] { 
/*  89 */         parent_menu_id_META, 
/*  90 */         menu_id_META, 
/*  91 */         menu_order_META, 
/*  92 */         menu_type_META, 
/*  93 */         menu_title_META, 
/*  94 */         menu_master_title_META, 
/*  95 */         module_id_META, 
/*  96 */         screen_id_META, 
/*  97 */         screen_mode_META, 
/*  98 */         frame_type_META, 
/*  99 */         per_grp_id_META, 
/* 100 */         menu_class_id_META, 
/* 101 */         menu_classname_META, 
/* 102 */         menu_method_META, 
/* 103 */         accesskey_META, 
/* 104 */         shortcutkey_META, 
/* 105 */         maskkey_META, 
/* 106 */         ac_META, 
/* 107 */         co_cd_META, 
/* 108 */         ext_attr1_META, 
/* 109 */         ext_attr2_META, 
/* 110 */         ext_attr3_META, 
/* 111 */         menu_visible_META, 
/* 112 */         core_menu_META, 
/* 113 */         bookmark_META, 
/* 114 */         menu_image_META, 
/* 115 */         menu_index_META
/*     */       },
/* 117 */       new String[][] { {}, {} });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 128 */   protected static final MCKeyList KEYS = new MCKeyList(
/* 129 */       null, 
/* 130 */       new String[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 138 */   protected static final MCExtMap EXTMAP = new MCExtMap(
/* 139 */       null, new MCExtMap.Entry[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] colnames() {
/* 151 */     return constMetas.toNameArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMeta[] colmetas() {
/* 163 */     return constMetas.toMetaArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 169 */   private static final int offset = constMetas.offset();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCKeyList getKeys() {
/* 175 */     return KEYS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getExtMap(String aGroup) {
/* 182 */     if (aGroup == null) return null; 
/* 183 */     return (Map<String, String>)EXTMAP.get(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCKeyList getKeys(String aGroup) {
/* 190 */     if (aGroup == null) return null; 
/* 191 */     return new MCKeyList(EXTMAP.getKeyList(aGroup));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExtGroups() {
/* 198 */     Set<String> ret = EXTMAP.keySet();
/* 199 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MenuR_FW_A(MCRow.ConstMetaList<? extends MenuR> metas) {
/* 206 */     super(metas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MenuR clone() {
/* 213 */     return (MenuR)super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MenuR createInstance() {
/* 220 */     return (MenuR)super.createInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MenuR getValues(String... names) {
/* 227 */     return (MenuR)super.getValues(names);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String parent_menu_id() {
/* 233 */     return getConstString(offset + 0, "parent_menu_id");
/*     */   }
/*     */   
/*     */   public void parent_menu_id(String value) {
/* 237 */     setConstString(offset + 0, "parent_menu_id", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String menu_id() {
/* 242 */     return getConstString(offset + 1, "menu_id");
/*     */   }
/*     */   
/*     */   public void menu_id(String value) {
/* 246 */     setConstString(offset + 1, "menu_id", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCNumber menu_order() {
/* 251 */     return getConstNumber(offset + 2, "menu_order");
/*     */   }
/*     */   
/*     */   public void menu_order(MCNumber value) {
/* 255 */     setConstNumber(offset + 2, "menu_order", value);
/*     */   }
/*     */   
/*     */   public void menu_order(int value) {
/* 259 */     setConstNumber(offset + 2, "menu_order", value);
/*     */   }
/*     */   
/*     */   public void menu_order(long value) {
/* 263 */     setConstNumber(offset + 2, "menu_order", value);
/*     */   }
/*     */   
/*     */   public void menu_order(float value) {
/* 267 */     setConstNumber(offset + 2, "menu_order", value);
/*     */   }
/*     */   
/*     */   public void menu_order(double value) {
/* 271 */     setConstNumber(offset + 2, "menu_order", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String menu_type() {
/* 276 */     return getConstString(offset + 3, "menu_type");
/*     */   }
/*     */   
/*     */   public void menu_type(String value) {
/* 280 */     setConstString(offset + 3, "menu_type", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String menu_title() {
/* 285 */     return getConstString(offset + 4, "menu_title");
/*     */   }
/*     */   
/*     */   public void menu_title(String value) {
/* 289 */     setConstString(offset + 4, "menu_title", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String menu_master_title() {
/* 294 */     return getConstString(offset + 5, "menu_master_title");
/*     */   }
/*     */   
/*     */   public void menu_master_title(String value) {
/* 298 */     setConstString(offset + 5, "menu_master_title", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String module_id() {
/* 303 */     return getConstString(offset + 6, "module_id");
/*     */   }
/*     */   
/*     */   public void module_id(String value) {
/* 307 */     setConstString(offset + 6, "module_id", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String screen_id() {
/* 312 */     return getConstString(offset + 7, "screen_id");
/*     */   }
/*     */   
/*     */   public void screen_id(String value) {
/* 316 */     setConstString(offset + 7, "screen_id", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String screen_mode() {
/* 321 */     return getConstString(offset + 8, "screen_mode");
/*     */   }
/*     */   
/*     */   public void screen_mode(String value) {
/* 325 */     setConstString(offset + 8, "screen_mode", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String frame_type() {
/* 330 */     return getConstString(offset + 9, "frame_type");
/*     */   }
/*     */   
/*     */   public void frame_type(String value) {
/* 334 */     setConstString(offset + 9, "frame_type", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String per_grp_id() {
/* 339 */     return getConstString(offset + 10, "per_grp_id");
/*     */   }
/*     */   
/*     */   public void per_grp_id(String value) {
/* 343 */     setConstString(offset + 10, "per_grp_id", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String menu_class_id() {
/* 348 */     return getConstString(offset + 11, "menu_class_id");
/*     */   }
/*     */   
/*     */   public void menu_class_id(String value) {
/* 352 */     setConstString(offset + 11, "menu_class_id", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String menu_classname() {
/* 357 */     return getConstString(offset + 12, "menu_classname");
/*     */   }
/*     */   
/*     */   public void menu_classname(String value) {
/* 361 */     setConstString(offset + 12, "menu_classname", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String menu_method() {
/* 366 */     return getConstString(offset + 13, "menu_method");
/*     */   }
/*     */   
/*     */   public void menu_method(String value) {
/* 370 */     setConstString(offset + 13, "menu_method", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String accesskey() {
/* 375 */     return getConstString(offset + 14, "accesskey");
/*     */   }
/*     */   
/*     */   public void accesskey(String value) {
/* 379 */     setConstString(offset + 14, "accesskey", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String shortcutkey() {
/* 384 */     return getConstString(offset + 15, "shortcutkey");
/*     */   }
/*     */   
/*     */   public void shortcutkey(String value) {
/* 388 */     setConstString(offset + 15, "shortcutkey", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String maskkey() {
/* 393 */     return getConstString(offset + 16, "maskkey");
/*     */   }
/*     */   
/*     */   public void maskkey(String value) {
/* 397 */     setConstString(offset + 16, "maskkey", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String ac() {
/* 402 */     return getConstString(offset + 17, "ac");
/*     */   }
/*     */   
/*     */   public void ac(String value) {
/* 406 */     setConstString(offset + 17, "ac", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String co_cd() {
/* 411 */     return getConstString(offset + 18, "co_cd");
/*     */   }
/*     */   
/*     */   public void co_cd(String value) {
/* 415 */     setConstString(offset + 18, "co_cd", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String ext_attr1() {
/* 420 */     return getConstString(offset + 19, "ext_attr1");
/*     */   }
/*     */   
/*     */   public void ext_attr1(String value) {
/* 424 */     setConstString(offset + 19, "ext_attr1", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String ext_attr2() {
/* 429 */     return getConstString(offset + 20, "ext_attr2");
/*     */   }
/*     */   
/*     */   public void ext_attr2(String value) {
/* 433 */     setConstString(offset + 20, "ext_attr2", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String ext_attr3() {
/* 438 */     return getConstString(offset + 21, "ext_attr3");
/*     */   }
/*     */   
/*     */   public void ext_attr3(String value) {
/* 442 */     setConstString(offset + 21, "ext_attr3", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean menu_visible() {
/* 447 */     return getConstBoolean(offset + 22, "menu_visible");
/*     */   }
/*     */   
/*     */   public void menu_visible(boolean value) {
/* 451 */     setConstBoolean(offset + 22, "menu_visible", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean core_menu() {
/* 456 */     return getConstBoolean(offset + 23, "core_menu");
/*     */   }
/*     */   
/*     */   public void core_menu(boolean value) {
/* 460 */     setConstBoolean(offset + 23, "core_menu", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean bookmark() {
/* 465 */     return getConstBoolean(offset + 24, "bookmark");
/*     */   }
/*     */   
/*     */   public void bookmark(boolean value) {
/* 469 */     setConstBoolean(offset + 24, "bookmark", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCBinary menu_image() {
/* 474 */     return getConstBinary(offset + 25, "menu_image");
/*     */   }
/*     */   
/*     */   public void menu_image(MCBinary value) {
/* 478 */     setConstBinary(offset + 25, "menu_image", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String menu_index() {
/* 483 */     return getConstString(offset + 26, "menu_index");
/*     */   }
/*     */   
/*     */   public void menu_index(String value) {
/* 487 */     setConstString(offset + 26, "menu_index", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString(String name) {
/* 492 */     if ("parent_menu_id".equalsIgnoreCase(name)) {
/* 493 */       return parent_menu_id();
/*     */     }
/* 495 */     if ("menu_id".equalsIgnoreCase(name)) {
/* 496 */       return menu_id();
/*     */     }
/* 498 */     if ("menu_type".equalsIgnoreCase(name)) {
/* 499 */       return menu_type();
/*     */     }
/* 501 */     if ("menu_title".equalsIgnoreCase(name)) {
/* 502 */       return menu_title();
/*     */     }
/* 504 */     if ("menu_master_title".equalsIgnoreCase(name)) {
/* 505 */       return menu_master_title();
/*     */     }
/* 507 */     if ("module_id".equalsIgnoreCase(name)) {
/* 508 */       return module_id();
/*     */     }
/* 510 */     if ("screen_id".equalsIgnoreCase(name)) {
/* 511 */       return screen_id();
/*     */     }
/* 513 */     if ("screen_mode".equalsIgnoreCase(name)) {
/* 514 */       return screen_mode();
/*     */     }
/* 516 */     if ("frame_type".equalsIgnoreCase(name)) {
/* 517 */       return frame_type();
/*     */     }
/* 519 */     if ("per_grp_id".equalsIgnoreCase(name)) {
/* 520 */       return per_grp_id();
/*     */     }
/* 522 */     if ("menu_class_id".equalsIgnoreCase(name)) {
/* 523 */       return menu_class_id();
/*     */     }
/* 525 */     if ("menu_classname".equalsIgnoreCase(name)) {
/* 526 */       return menu_classname();
/*     */     }
/* 528 */     if ("menu_method".equalsIgnoreCase(name)) {
/* 529 */       return menu_method();
/*     */     }
/* 531 */     if ("accesskey".equalsIgnoreCase(name)) {
/* 532 */       return accesskey();
/*     */     }
/* 534 */     if ("shortcutkey".equalsIgnoreCase(name)) {
/* 535 */       return shortcutkey();
/*     */     }
/* 537 */     if ("maskkey".equalsIgnoreCase(name)) {
/* 538 */       return maskkey();
/*     */     }
/* 540 */     if ("ac".equalsIgnoreCase(name)) {
/* 541 */       return ac();
/*     */     }
/* 543 */     if ("co_cd".equalsIgnoreCase(name)) {
/* 544 */       return co_cd();
/*     */     }
/* 546 */     if ("ext_attr1".equalsIgnoreCase(name)) {
/* 547 */       return ext_attr1();
/*     */     }
/* 549 */     if ("ext_attr2".equalsIgnoreCase(name)) {
/* 550 */       return ext_attr2();
/*     */     }
/* 552 */     if ("ext_attr3".equalsIgnoreCase(name)) {
/* 553 */       return ext_attr3();
/*     */     }
/* 555 */     if ("menu_index".equalsIgnoreCase(name)) {
/* 556 */       return menu_index();
/*     */     }
/* 558 */     return super.getString(name);
/*     */   }
/*     */   public MCNumber getNumber(String name) {
/* 561 */     if ("menu_order".equalsIgnoreCase(name)) {
/* 562 */       return menu_order();
/*     */     }
/* 564 */     return super.getNumber(name);
/*     */   }
/*     */   public boolean getBoolean(String name) {
/* 567 */     if ("menu_visible".equalsIgnoreCase(name)) {
/* 568 */       return menu_visible();
/*     */     }
/* 570 */     if ("core_menu".equalsIgnoreCase(name)) {
/* 571 */       return core_menu();
/*     */     }
/* 573 */     if ("bookmark".equalsIgnoreCase(name)) {
/* 574 */       return bookmark();
/*     */     }
/* 576 */     return super.getBoolean(name);
/*     */   }
/*     */   public MCBinary getBinary(String name) {
/* 579 */     if ("menu_image".equalsIgnoreCase(name)) {
/* 580 */       return menu_image();
/*     */     }
/* 582 */     return super.getBinary(name);
/*     */   }
/*     */   
/*     */   public String getStringNE(String name) {
/* 586 */     if ("parent_menu_id".equalsIgnoreCase(name)) {
/* 587 */       return parent_menu_id();
/*     */     }
/* 589 */     if ("menu_id".equalsIgnoreCase(name)) {
/* 590 */       return menu_id();
/*     */     }
/* 592 */     if ("menu_type".equalsIgnoreCase(name)) {
/* 593 */       return menu_type();
/*     */     }
/* 595 */     if ("menu_title".equalsIgnoreCase(name)) {
/* 596 */       return menu_title();
/*     */     }
/* 598 */     if ("menu_master_title".equalsIgnoreCase(name)) {
/* 599 */       return menu_master_title();
/*     */     }
/* 601 */     if ("module_id".equalsIgnoreCase(name)) {
/* 602 */       return module_id();
/*     */     }
/* 604 */     if ("screen_id".equalsIgnoreCase(name)) {
/* 605 */       return screen_id();
/*     */     }
/* 607 */     if ("screen_mode".equalsIgnoreCase(name)) {
/* 608 */       return screen_mode();
/*     */     }
/* 610 */     if ("frame_type".equalsIgnoreCase(name)) {
/* 611 */       return frame_type();
/*     */     }
/* 613 */     if ("per_grp_id".equalsIgnoreCase(name)) {
/* 614 */       return per_grp_id();
/*     */     }
/* 616 */     if ("menu_class_id".equalsIgnoreCase(name)) {
/* 617 */       return menu_class_id();
/*     */     }
/* 619 */     if ("menu_classname".equalsIgnoreCase(name)) {
/* 620 */       return menu_classname();
/*     */     }
/* 622 */     if ("menu_method".equalsIgnoreCase(name)) {
/* 623 */       return menu_method();
/*     */     }
/* 625 */     if ("accesskey".equalsIgnoreCase(name)) {
/* 626 */       return accesskey();
/*     */     }
/* 628 */     if ("shortcutkey".equalsIgnoreCase(name)) {
/* 629 */       return shortcutkey();
/*     */     }
/* 631 */     if ("maskkey".equalsIgnoreCase(name)) {
/* 632 */       return maskkey();
/*     */     }
/* 634 */     if ("ac".equalsIgnoreCase(name)) {
/* 635 */       return ac();
/*     */     }
/* 637 */     if ("co_cd".equalsIgnoreCase(name)) {
/* 638 */       return co_cd();
/*     */     }
/* 640 */     if ("ext_attr1".equalsIgnoreCase(name)) {
/* 641 */       return ext_attr1();
/*     */     }
/* 643 */     if ("ext_attr2".equalsIgnoreCase(name)) {
/* 644 */       return ext_attr2();
/*     */     }
/* 646 */     if ("ext_attr3".equalsIgnoreCase(name)) {
/* 647 */       return ext_attr3();
/*     */     }
/* 649 */     if ("menu_index".equalsIgnoreCase(name)) {
/* 650 */       return menu_index();
/*     */     }
/* 652 */     return super.getStringNE(name);
/*     */   }
/*     */   public MCNumber getNumberNE(String name) {
/* 655 */     if ("menu_order".equalsIgnoreCase(name)) {
/* 656 */       return menu_order();
/*     */     }
/* 658 */     return super.getNumberNE(name);
/*     */   }
/*     */   public boolean getBooleanNE(String name) {
/* 661 */     if ("menu_visible".equalsIgnoreCase(name)) {
/* 662 */       return menu_visible();
/*     */     }
/* 664 */     if ("core_menu".equalsIgnoreCase(name)) {
/* 665 */       return core_menu();
/*     */     }
/* 667 */     if ("bookmark".equalsIgnoreCase(name)) {
/* 668 */       return bookmark();
/*     */     }
/* 670 */     return super.getBooleanNE(name);
/*     */   }
/*     */   public MCBinary getBinaryNE(String name) {
/* 673 */     if ("menu_image".equalsIgnoreCase(name)) {
/* 674 */       return menu_image();
/*     */     }
/* 676 */     return super.getBinaryNE(name);
/*     */   }
/*     */   
/*     */   public void setString(String name, String value) {
/* 680 */     if ("parent_menu_id".equalsIgnoreCase(name)) {
/* 681 */       parent_menu_id(value);
/*     */       return;
/*     */     } 
/* 684 */     if ("menu_id".equalsIgnoreCase(name)) {
/* 685 */       menu_id(value);
/*     */       return;
/*     */     } 
/* 688 */     if ("menu_type".equalsIgnoreCase(name)) {
/* 689 */       menu_type(value);
/*     */       return;
/*     */     } 
/* 692 */     if ("menu_title".equalsIgnoreCase(name)) {
/* 693 */       menu_title(value);
/*     */       return;
/*     */     } 
/* 696 */     if ("menu_master_title".equalsIgnoreCase(name)) {
/* 697 */       menu_master_title(value);
/*     */       return;
/*     */     } 
/* 700 */     if ("module_id".equalsIgnoreCase(name)) {
/* 701 */       module_id(value);
/*     */       return;
/*     */     } 
/* 704 */     if ("screen_id".equalsIgnoreCase(name)) {
/* 705 */       screen_id(value);
/*     */       return;
/*     */     } 
/* 708 */     if ("screen_mode".equalsIgnoreCase(name)) {
/* 709 */       screen_mode(value);
/*     */       return;
/*     */     } 
/* 712 */     if ("frame_type".equalsIgnoreCase(name)) {
/* 713 */       frame_type(value);
/*     */       return;
/*     */     } 
/* 716 */     if ("per_grp_id".equalsIgnoreCase(name)) {
/* 717 */       per_grp_id(value);
/*     */       return;
/*     */     } 
/* 720 */     if ("menu_class_id".equalsIgnoreCase(name)) {
/* 721 */       menu_class_id(value);
/*     */       return;
/*     */     } 
/* 724 */     if ("menu_classname".equalsIgnoreCase(name)) {
/* 725 */       menu_classname(value);
/*     */       return;
/*     */     } 
/* 728 */     if ("menu_method".equalsIgnoreCase(name)) {
/* 729 */       menu_method(value);
/*     */       return;
/*     */     } 
/* 732 */     if ("accesskey".equalsIgnoreCase(name)) {
/* 733 */       accesskey(value);
/*     */       return;
/*     */     } 
/* 736 */     if ("shortcutkey".equalsIgnoreCase(name)) {
/* 737 */       shortcutkey(value);
/*     */       return;
/*     */     } 
/* 740 */     if ("maskkey".equalsIgnoreCase(name)) {
/* 741 */       maskkey(value);
/*     */       return;
/*     */     } 
/* 744 */     if ("ac".equalsIgnoreCase(name)) {
/* 745 */       ac(value);
/*     */       return;
/*     */     } 
/* 748 */     if ("co_cd".equalsIgnoreCase(name)) {
/* 749 */       co_cd(value);
/*     */       return;
/*     */     } 
/* 752 */     if ("ext_attr1".equalsIgnoreCase(name)) {
/* 753 */       ext_attr1(value);
/*     */       return;
/*     */     } 
/* 756 */     if ("ext_attr2".equalsIgnoreCase(name)) {
/* 757 */       ext_attr2(value);
/*     */       return;
/*     */     } 
/* 760 */     if ("ext_attr3".equalsIgnoreCase(name)) {
/* 761 */       ext_attr3(value);
/*     */       return;
/*     */     } 
/* 764 */     if ("menu_index".equalsIgnoreCase(name)) {
/* 765 */       menu_index(value);
/*     */       return;
/*     */     } 
/* 768 */     super.setString(name, value);
/*     */   }
/*     */   public void setNumber(String name, MCNumber value) {
/* 771 */     if ("menu_order".equalsIgnoreCase(name)) {
/* 772 */       menu_order(value);
/*     */       return;
/*     */     } 
/* 775 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, int value) {
/* 778 */     if ("menu_order".equalsIgnoreCase(name)) {
/* 779 */       menu_order(value);
/*     */       return;
/*     */     } 
/* 782 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, long value) {
/* 785 */     if ("menu_order".equalsIgnoreCase(name)) {
/* 786 */       menu_order(value);
/*     */       return;
/*     */     } 
/* 789 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, float value) {
/* 792 */     if ("menu_order".equalsIgnoreCase(name)) {
/* 793 */       menu_order(value);
/*     */       return;
/*     */     } 
/* 796 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, double value) {
/* 799 */     if ("menu_order".equalsIgnoreCase(name)) {
/* 800 */       menu_order(value);
/*     */       return;
/*     */     } 
/* 803 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setBoolean(String name, boolean value) {
/* 806 */     if ("menu_visible".equalsIgnoreCase(name)) {
/* 807 */       menu_visible(value);
/*     */       return;
/*     */     } 
/* 810 */     if ("core_menu".equalsIgnoreCase(name)) {
/* 811 */       core_menu(value);
/*     */       return;
/*     */     } 
/* 814 */     if ("bookmark".equalsIgnoreCase(name)) {
/* 815 */       bookmark(value);
/*     */       return;
/*     */     } 
/* 818 */     super.setBoolean(name, value);
/*     */   }
/*     */   public void setBinary(String name, MCBinary value) {
/* 821 */     if ("menu_image".equalsIgnoreCase(name)) {
/* 822 */       menu_image(value);
/*     */       return;
/*     */     } 
/* 825 */     super.setBinary(name, value);
/*     */   }
/*     */   
/*     */   public void setStringNE(String name, String value) {
/* 829 */     if ("parent_menu_id".equalsIgnoreCase(name)) {
/* 830 */       parent_menu_id(value);
/*     */       return;
/*     */     } 
/* 833 */     if ("menu_id".equalsIgnoreCase(name)) {
/* 834 */       menu_id(value);
/*     */       return;
/*     */     } 
/* 837 */     if ("menu_type".equalsIgnoreCase(name)) {
/* 838 */       menu_type(value);
/*     */       return;
/*     */     } 
/* 841 */     if ("menu_title".equalsIgnoreCase(name)) {
/* 842 */       menu_title(value);
/*     */       return;
/*     */     } 
/* 845 */     if ("menu_master_title".equalsIgnoreCase(name)) {
/* 846 */       menu_master_title(value);
/*     */       return;
/*     */     } 
/* 849 */     if ("module_id".equalsIgnoreCase(name)) {
/* 850 */       module_id(value);
/*     */       return;
/*     */     } 
/* 853 */     if ("screen_id".equalsIgnoreCase(name)) {
/* 854 */       screen_id(value);
/*     */       return;
/*     */     } 
/* 857 */     if ("screen_mode".equalsIgnoreCase(name)) {
/* 858 */       screen_mode(value);
/*     */       return;
/*     */     } 
/* 861 */     if ("frame_type".equalsIgnoreCase(name)) {
/* 862 */       frame_type(value);
/*     */       return;
/*     */     } 
/* 865 */     if ("per_grp_id".equalsIgnoreCase(name)) {
/* 866 */       per_grp_id(value);
/*     */       return;
/*     */     } 
/* 869 */     if ("menu_class_id".equalsIgnoreCase(name)) {
/* 870 */       menu_class_id(value);
/*     */       return;
/*     */     } 
/* 873 */     if ("menu_classname".equalsIgnoreCase(name)) {
/* 874 */       menu_classname(value);
/*     */       return;
/*     */     } 
/* 877 */     if ("menu_method".equalsIgnoreCase(name)) {
/* 878 */       menu_method(value);
/*     */       return;
/*     */     } 
/* 881 */     if ("accesskey".equalsIgnoreCase(name)) {
/* 882 */       accesskey(value);
/*     */       return;
/*     */     } 
/* 885 */     if ("shortcutkey".equalsIgnoreCase(name)) {
/* 886 */       shortcutkey(value);
/*     */       return;
/*     */     } 
/* 889 */     if ("maskkey".equalsIgnoreCase(name)) {
/* 890 */       maskkey(value);
/*     */       return;
/*     */     } 
/* 893 */     if ("ac".equalsIgnoreCase(name)) {
/* 894 */       ac(value);
/*     */       return;
/*     */     } 
/* 897 */     if ("co_cd".equalsIgnoreCase(name)) {
/* 898 */       co_cd(value);
/*     */       return;
/*     */     } 
/* 901 */     if ("ext_attr1".equalsIgnoreCase(name)) {
/* 902 */       ext_attr1(value);
/*     */       return;
/*     */     } 
/* 905 */     if ("ext_attr2".equalsIgnoreCase(name)) {
/* 906 */       ext_attr2(value);
/*     */       return;
/*     */     } 
/* 909 */     if ("ext_attr3".equalsIgnoreCase(name)) {
/* 910 */       ext_attr3(value);
/*     */       return;
/*     */     } 
/* 913 */     if ("menu_index".equalsIgnoreCase(name)) {
/* 914 */       menu_index(value);
/*     */       return;
/*     */     } 
/* 917 */     super.setStringNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, MCNumber value) {
/* 920 */     if ("menu_order".equalsIgnoreCase(name)) {
/* 921 */       menu_order(value);
/*     */       return;
/*     */     } 
/* 924 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, int value) {
/* 927 */     if ("menu_order".equalsIgnoreCase(name)) {
/* 928 */       menu_order(value);
/*     */       return;
/*     */     } 
/* 931 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, long value) {
/* 934 */     if ("menu_order".equalsIgnoreCase(name)) {
/* 935 */       menu_order(value);
/*     */       return;
/*     */     } 
/* 938 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, float value) {
/* 941 */     if ("menu_order".equalsIgnoreCase(name)) {
/* 942 */       menu_order(value);
/*     */       return;
/*     */     } 
/* 945 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, double value) {
/* 948 */     if ("menu_order".equalsIgnoreCase(name)) {
/* 949 */       menu_order(value);
/*     */       return;
/*     */     } 
/* 952 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setBooleanNE(String name, boolean value) {
/* 955 */     if ("menu_visible".equalsIgnoreCase(name)) {
/* 956 */       menu_visible(value);
/*     */       return;
/*     */     } 
/* 959 */     if ("core_menu".equalsIgnoreCase(name)) {
/* 960 */       core_menu(value);
/*     */       return;
/*     */     } 
/* 963 */     if ("bookmark".equalsIgnoreCase(name)) {
/* 964 */       bookmark(value);
/*     */       return;
/*     */     } 
/* 967 */     super.setBooleanNE(name, value);
/*     */   }
/*     */   public void setBinaryNE(String name, MCBinary value) {
/* 970 */     if ("menu_image".equalsIgnoreCase(name)) {
/* 971 */       menu_image(value);
/*     */       return;
/*     */     } 
/* 974 */     super.setBinaryNE(name, value);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\menu\requester\MenuR_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */