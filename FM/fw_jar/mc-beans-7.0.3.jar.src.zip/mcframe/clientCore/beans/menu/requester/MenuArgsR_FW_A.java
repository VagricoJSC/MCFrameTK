/*     */ package mcframe.clientCore.beans.menu.requester;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.clientCore.container.MCKeyList;
/*     */ import mcframe.commonCore.container.MCExtMap;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ import mcframe.commonCore.meta.M_META;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class MenuArgsR_FW_A
/*     */   extends MCConstRow
/*     */ {
/*     */   public static final String $parent_menu_id = "parent_menu_id";
/*     */   public static final String $menu_id = "menu_id";
/*     */   public static final String $args_nm = "args_nm";
/*     */   public static final String $args_order = "args_order";
/*     */   public static final String $args_type = "args_type";
/*     */   public static final String $args_value = "args_value";
/*     */   public static final String $co_cd = "co_cd";
/*     */   public static final String $ext_attr1 = "ext_attr1";
/*     */   public static final String $ext_attr2 = "ext_attr2";
/*     */   public static final String $ext_attr3 = "ext_attr3";
/*  41 */   public static final MCMeta parent_menu_id_META = createCommonMeta("parent_menu_id", M_META.SCREEN_ID);
/*  42 */   public static final MCMeta menu_id_META = createCommonMeta("menu_id", M_META.SCREEN_NAME);
/*  43 */   public static final MCMeta args_nm_META = createCommonMeta("args_nm", M_META.MENU_ARGS_NM);
/*  44 */   public static final MCMeta args_order_META = createCommonMeta("args_order", M_META.INT);
/*  45 */   public static final MCMeta args_type_META = createCommonMeta("args_type", M_META.MENU_ARGS_TYPE);
/*  46 */   public static final MCMeta args_value_META = createCommonMeta("args_value", M_META.TEXT_LINE);
/*  47 */   public static final MCMeta co_cd_META = createCommonMeta("co_cd", M_META.CO_CD);
/*  48 */   public static final MCMeta ext_attr1_META = createCommonMeta("ext_attr1", M_META.USR_EXT_ATTR);
/*  49 */   public static final MCMeta ext_attr2_META = createCommonMeta("ext_attr2", M_META.USR_EXT_ATTR);
/*  50 */   public static final MCMeta ext_attr3_META = createCommonMeta("ext_attr3", M_META.USR_EXT_ATTR);
/*     */   
/*  52 */   protected static final MCRow.ConstMetaList<MenuArgsR> constMetas = new MCRow.ConstMetaList(
/*  53 */       MCConstRow.constMetas, 
/*  54 */       new MCMeta[] {
/*  55 */         parent_menu_id_META, 
/*  56 */         menu_id_META, 
/*  57 */         args_nm_META, 
/*  58 */         args_order_META, 
/*  59 */         args_type_META, 
/*  60 */         args_value_META, 
/*  61 */         co_cd_META, 
/*  62 */         ext_attr1_META, 
/*  63 */         ext_attr2_META, 
/*  64 */         ext_attr3_META
/*     */       },
/*  66 */       new String[][] { {}, {} });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  77 */   protected static final MCKeyList KEYS = new MCKeyList(
/*  78 */       null, 
/*  79 */       new String[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   protected static final MCExtMap EXTMAP = new MCExtMap(
/*  88 */       null, new MCExtMap.Entry[0]);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] colnames() {
/* 100 */     return constMetas.toNameArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCMeta[] colmetas() {
/* 112 */     return constMetas.toMetaArray();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 118 */   private static final int offset = constMetas.offset();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCKeyList getKeys() {
/* 124 */     return KEYS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> getExtMap(String aGroup) {
/* 131 */     if (aGroup == null) return null; 
/* 132 */     return (Map<String, String>)EXTMAP.get(aGroup);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCKeyList getKeys(String aGroup) {
/* 139 */     if (aGroup == null) return null; 
/* 140 */     return new MCKeyList(EXTMAP.getKeyList(aGroup));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Set<String> getExtGroups() {
/* 147 */     Set<String> ret = EXTMAP.keySet();
/* 148 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MenuArgsR_FW_A(MCRow.ConstMetaList<? extends MenuArgsR> metas) {
/* 155 */     super(metas);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MenuArgsR clone() {
/* 162 */     return (MenuArgsR)super.clone();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MenuArgsR createInstance() {
/* 169 */     return (MenuArgsR)super.createInstance();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MenuArgsR getValues(String... names) {
/* 176 */     return (MenuArgsR)super.getValues(names);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String parent_menu_id() {
/* 182 */     return getConstString(offset + 0, "parent_menu_id");
/*     */   }
/*     */   
/*     */   public void parent_menu_id(String value) {
/* 186 */     setConstString(offset + 0, "parent_menu_id", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String menu_id() {
/* 191 */     return getConstString(offset + 1, "menu_id");
/*     */   }
/*     */   
/*     */   public void menu_id(String value) {
/* 195 */     setConstString(offset + 1, "menu_id", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String args_nm() {
/* 200 */     return getConstString(offset + 2, "args_nm");
/*     */   }
/*     */   
/*     */   public void args_nm(String value) {
/* 204 */     setConstString(offset + 2, "args_nm", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCNumber args_order() {
/* 209 */     return getConstNumber(offset + 3, "args_order");
/*     */   }
/*     */   
/*     */   public void args_order(MCNumber value) {
/* 213 */     setConstNumber(offset + 3, "args_order", value);
/*     */   }
/*     */   
/*     */   public void args_order(int value) {
/* 217 */     setConstNumber(offset + 3, "args_order", value);
/*     */   }
/*     */   
/*     */   public void args_order(long value) {
/* 221 */     setConstNumber(offset + 3, "args_order", value);
/*     */   }
/*     */   
/*     */   public void args_order(float value) {
/* 225 */     setConstNumber(offset + 3, "args_order", value);
/*     */   }
/*     */   
/*     */   public void args_order(double value) {
/* 229 */     setConstNumber(offset + 3, "args_order", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String args_type() {
/* 234 */     return getConstString(offset + 4, "args_type");
/*     */   }
/*     */   
/*     */   public void args_type(String value) {
/* 238 */     setConstString(offset + 4, "args_type", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String args_value() {
/* 243 */     return getConstString(offset + 5, "args_value");
/*     */   }
/*     */   
/*     */   public void args_value(String value) {
/* 247 */     setConstString(offset + 5, "args_value", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String co_cd() {
/* 252 */     return getConstString(offset + 6, "co_cd");
/*     */   }
/*     */   
/*     */   public void co_cd(String value) {
/* 256 */     setConstString(offset + 6, "co_cd", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String ext_attr1() {
/* 261 */     return getConstString(offset + 7, "ext_attr1");
/*     */   }
/*     */   
/*     */   public void ext_attr1(String value) {
/* 265 */     setConstString(offset + 7, "ext_attr1", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String ext_attr2() {
/* 270 */     return getConstString(offset + 8, "ext_attr2");
/*     */   }
/*     */   
/*     */   public void ext_attr2(String value) {
/* 274 */     setConstString(offset + 8, "ext_attr2", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String ext_attr3() {
/* 279 */     return getConstString(offset + 9, "ext_attr3");
/*     */   }
/*     */   
/*     */   public void ext_attr3(String value) {
/* 283 */     setConstString(offset + 9, "ext_attr3", value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getString(String name) {
/* 288 */     if ("parent_menu_id".equalsIgnoreCase(name)) {
/* 289 */       return parent_menu_id();
/*     */     }
/* 291 */     if ("menu_id".equalsIgnoreCase(name)) {
/* 292 */       return menu_id();
/*     */     }
/* 294 */     if ("args_nm".equalsIgnoreCase(name)) {
/* 295 */       return args_nm();
/*     */     }
/* 297 */     if ("args_type".equalsIgnoreCase(name)) {
/* 298 */       return args_type();
/*     */     }
/* 300 */     if ("args_value".equalsIgnoreCase(name)) {
/* 301 */       return args_value();
/*     */     }
/* 303 */     if ("co_cd".equalsIgnoreCase(name)) {
/* 304 */       return co_cd();
/*     */     }
/* 306 */     if ("ext_attr1".equalsIgnoreCase(name)) {
/* 307 */       return ext_attr1();
/*     */     }
/* 309 */     if ("ext_attr2".equalsIgnoreCase(name)) {
/* 310 */       return ext_attr2();
/*     */     }
/* 312 */     if ("ext_attr3".equalsIgnoreCase(name)) {
/* 313 */       return ext_attr3();
/*     */     }
/* 315 */     return super.getString(name);
/*     */   }
/*     */   public MCNumber getNumber(String name) {
/* 318 */     if ("args_order".equalsIgnoreCase(name)) {
/* 319 */       return args_order();
/*     */     }
/* 321 */     return super.getNumber(name);
/*     */   }
/*     */   
/*     */   public String getStringNE(String name) {
/* 325 */     if ("parent_menu_id".equalsIgnoreCase(name)) {
/* 326 */       return parent_menu_id();
/*     */     }
/* 328 */     if ("menu_id".equalsIgnoreCase(name)) {
/* 329 */       return menu_id();
/*     */     }
/* 331 */     if ("args_nm".equalsIgnoreCase(name)) {
/* 332 */       return args_nm();
/*     */     }
/* 334 */     if ("args_type".equalsIgnoreCase(name)) {
/* 335 */       return args_type();
/*     */     }
/* 337 */     if ("args_value".equalsIgnoreCase(name)) {
/* 338 */       return args_value();
/*     */     }
/* 340 */     if ("co_cd".equalsIgnoreCase(name)) {
/* 341 */       return co_cd();
/*     */     }
/* 343 */     if ("ext_attr1".equalsIgnoreCase(name)) {
/* 344 */       return ext_attr1();
/*     */     }
/* 346 */     if ("ext_attr2".equalsIgnoreCase(name)) {
/* 347 */       return ext_attr2();
/*     */     }
/* 349 */     if ("ext_attr3".equalsIgnoreCase(name)) {
/* 350 */       return ext_attr3();
/*     */     }
/* 352 */     return super.getStringNE(name);
/*     */   }
/*     */   public MCNumber getNumberNE(String name) {
/* 355 */     if ("args_order".equalsIgnoreCase(name)) {
/* 356 */       return args_order();
/*     */     }
/* 358 */     return super.getNumberNE(name);
/*     */   }
/*     */   
/*     */   public void setString(String name, String value) {
/* 362 */     if ("parent_menu_id".equalsIgnoreCase(name)) {
/* 363 */       parent_menu_id(value);
/*     */       return;
/*     */     } 
/* 366 */     if ("menu_id".equalsIgnoreCase(name)) {
/* 367 */       menu_id(value);
/*     */       return;
/*     */     } 
/* 370 */     if ("args_nm".equalsIgnoreCase(name)) {
/* 371 */       args_nm(value);
/*     */       return;
/*     */     } 
/* 374 */     if ("args_type".equalsIgnoreCase(name)) {
/* 375 */       args_type(value);
/*     */       return;
/*     */     } 
/* 378 */     if ("args_value".equalsIgnoreCase(name)) {
/* 379 */       args_value(value);
/*     */       return;
/*     */     } 
/* 382 */     if ("co_cd".equalsIgnoreCase(name)) {
/* 383 */       co_cd(value);
/*     */       return;
/*     */     } 
/* 386 */     if ("ext_attr1".equalsIgnoreCase(name)) {
/* 387 */       ext_attr1(value);
/*     */       return;
/*     */     } 
/* 390 */     if ("ext_attr2".equalsIgnoreCase(name)) {
/* 391 */       ext_attr2(value);
/*     */       return;
/*     */     } 
/* 394 */     if ("ext_attr3".equalsIgnoreCase(name)) {
/* 395 */       ext_attr3(value);
/*     */       return;
/*     */     } 
/* 398 */     super.setString(name, value);
/*     */   }
/*     */   public void setNumber(String name, MCNumber value) {
/* 401 */     if ("args_order".equalsIgnoreCase(name)) {
/* 402 */       args_order(value);
/*     */       return;
/*     */     } 
/* 405 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, int value) {
/* 408 */     if ("args_order".equalsIgnoreCase(name)) {
/* 409 */       args_order(value);
/*     */       return;
/*     */     } 
/* 412 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, long value) {
/* 415 */     if ("args_order".equalsIgnoreCase(name)) {
/* 416 */       args_order(value);
/*     */       return;
/*     */     } 
/* 419 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, float value) {
/* 422 */     if ("args_order".equalsIgnoreCase(name)) {
/* 423 */       args_order(value);
/*     */       return;
/*     */     } 
/* 426 */     super.setNumber(name, value);
/*     */   }
/*     */   public void setNumber(String name, double value) {
/* 429 */     if ("args_order".equalsIgnoreCase(name)) {
/* 430 */       args_order(value);
/*     */       return;
/*     */     } 
/* 433 */     super.setNumber(name, value);
/*     */   }
/*     */   
/*     */   public void setStringNE(String name, String value) {
/* 437 */     if ("parent_menu_id".equalsIgnoreCase(name)) {
/* 438 */       parent_menu_id(value);
/*     */       return;
/*     */     } 
/* 441 */     if ("menu_id".equalsIgnoreCase(name)) {
/* 442 */       menu_id(value);
/*     */       return;
/*     */     } 
/* 445 */     if ("args_nm".equalsIgnoreCase(name)) {
/* 446 */       args_nm(value);
/*     */       return;
/*     */     } 
/* 449 */     if ("args_type".equalsIgnoreCase(name)) {
/* 450 */       args_type(value);
/*     */       return;
/*     */     } 
/* 453 */     if ("args_value".equalsIgnoreCase(name)) {
/* 454 */       args_value(value);
/*     */       return;
/*     */     } 
/* 457 */     if ("co_cd".equalsIgnoreCase(name)) {
/* 458 */       co_cd(value);
/*     */       return;
/*     */     } 
/* 461 */     if ("ext_attr1".equalsIgnoreCase(name)) {
/* 462 */       ext_attr1(value);
/*     */       return;
/*     */     } 
/* 465 */     if ("ext_attr2".equalsIgnoreCase(name)) {
/* 466 */       ext_attr2(value);
/*     */       return;
/*     */     } 
/* 469 */     if ("ext_attr3".equalsIgnoreCase(name)) {
/* 470 */       ext_attr3(value);
/*     */       return;
/*     */     } 
/* 473 */     super.setStringNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, MCNumber value) {
/* 476 */     if ("args_order".equalsIgnoreCase(name)) {
/* 477 */       args_order(value);
/*     */       return;
/*     */     } 
/* 480 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, int value) {
/* 483 */     if ("args_order".equalsIgnoreCase(name)) {
/* 484 */       args_order(value);
/*     */       return;
/*     */     } 
/* 487 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, long value) {
/* 490 */     if ("args_order".equalsIgnoreCase(name)) {
/* 491 */       args_order(value);
/*     */       return;
/*     */     } 
/* 494 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, float value) {
/* 497 */     if ("args_order".equalsIgnoreCase(name)) {
/* 498 */       args_order(value);
/*     */       return;
/*     */     } 
/* 501 */     super.setNumberNE(name, value);
/*     */   }
/*     */   public void setNumberNE(String name, double value) {
/* 504 */     if ("args_order".equalsIgnoreCase(name)) {
/* 505 */       args_order(value);
/*     */       return;
/*     */     } 
/* 508 */     super.setNumberNE(name, value);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\menu\requester\MenuArgsR_FW_A.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */