/*    */ package mcframe.clientCore.beans.list;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MCListScreenCache2
/*    */   extends MCListCache2
/*    */ {
/*    */   private final String module;
/*    */   private final String screen;
/*    */   private final int serial;
/*    */   
/*    */   MCListScreenCache2(String module, String screen, int serial) {
/* 47 */     this.module = module;
/* 48 */     this.screen = screen;
/* 49 */     this.serial = serial;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private String getModuleID() {
/* 60 */     return this.module;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private String getScreenID() {
/* 71 */     return this.screen;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private int getSerial() {
/* 82 */     return this.serial;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   boolean equals(String module, String screen, int serial) {
/* 96 */     return (getModuleID().equals(module) && 
/* 97 */       getScreenID().equals(screen) && getSerial() == serial);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\list\MCListScreenCache2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */