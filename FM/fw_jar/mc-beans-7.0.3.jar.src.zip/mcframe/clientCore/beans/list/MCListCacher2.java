/*     */ package mcframe.clientCore.beans.list;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import mcframe.clientCore.beans.MCCacheType;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ import mcframe.clientCore.sys.MCSys;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MCListCacher2
/*     */ {
/*     */   public static final String $CACHE_TYP = "cache_typ";
/*     */   
/*  42 */   private static final List<MCListCache2> SCREEN = new ArrayList<MCListCache2>()
/*     */     {
/*     */       public void clear()
/*     */       {
/*  46 */         for (MCListCache2 c : this) {
/*  47 */           c.clear();
/*     */         }
/*  49 */         super.clear();
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean _useclonedmap = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  67 */   private static final MCListCache2 LOGIN = new MCListCache2()
/*     */     {
/*     */       protected boolean canCache()
/*     */       {
/*  71 */         return MCSys.user.isLogin();
/*     */       }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   private static final MCListCache2 SYSTEM = new MCListCache2();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void useClonedMap(boolean b) {
/* 103 */     if (!MCConst.beans.getBoolean("list_cache.useclonedmap")) {
/*     */       return;
/*     */     }
/*     */     
/* 107 */     _useclonedmap = b;
/* 108 */     if (!b) {
/* 109 */       MCListScreenCache2[] a = SCREEN
/* 110 */         .<MCListScreenCache2>toArray(new MCListScreenCache2[SCREEN.size()]); byte b1; int i; MCListScreenCache2[] arrayOfMCListScreenCache21;
/* 111 */       for (i = (arrayOfMCListScreenCache21 = a).length, b1 = 0; b1 < i; ) { MCListScreenCache2 c = arrayOfMCListScreenCache21[b1];
/* 112 */         c.deleteClonedMap(); b1++; }
/*     */       
/* 114 */       LOGIN.deleteClonedMap();
/* 115 */       SYSTEM.deleteClonedMap();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCList<MCRow> getList(MCCacheType type, String module, String screen, int serial, String id, MCRow condition, String opeType) {
/* 140 */     MCList<MCRow> rtn = null;
/* 141 */     if (type != null) {
/* 142 */       MCListScreenCache2 c; switch (type) {
/*     */         case SCREEN:
/* 144 */           c = getScreenCache(module, screen, serial);
/* 145 */           rtn = (c != null) ? c.getList(getCacheId(id, opeType, condition)) : 
/* 146 */             null;
/*     */           break;
/*     */         case null:
/* 149 */           rtn = LOGIN.getList(getCacheId(id, opeType, condition));
/*     */           break;
/*     */         case SYSTEM:
/* 152 */           rtn = SYSTEM.getList(getCacheId(id, opeType, condition));
/*     */           break;
/*     */         default:
/* 155 */           return null;
/*     */       } 
/*     */     } 
/* 158 */     return (rtn != null) ? rtn.shallowClone() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCRow getRow(MCCacheType type, String module, String screen, int serial, String id, MCRow condition, String opeType) {
/* 183 */     if (type != null) {
/* 184 */       MCListScreenCache2 c; switch (type) {
/*     */         case SCREEN:
/* 186 */           c = getScreenCache(module, screen, serial);
/* 187 */           return (c != null) ? c.getRow(getCacheId(id, opeType, condition)) : 
/* 188 */             null;
/*     */         case null:
/* 190 */           return LOGIN.getRow(getCacheId(id, opeType, condition));
/*     */         case SYSTEM:
/* 192 */           return SYSTEM.getRow(getCacheId(id, opeType, condition));
/*     */       } 
/* 194 */       return null;
/*     */     } 
/*     */     
/* 197 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void cache(MCCacheType type, String module, String screen, int serial, String id, MCRow condition, MCList<MCRow> list, String opeType) {
/*     */     MCListScreenCache2 c;
/* 216 */     if (type == null) {
/* 217 */       type = MCCacheType.NONE;
/*     */     }
/* 219 */     if (list == null) {
/*     */       return;
/*     */     }
/* 222 */     switch (type) {
/*     */       case SCREEN:
/* 224 */         c = getScreenCache(module, screen, serial);
/* 225 */         if (c != null) {
/* 226 */           c.add(getCacheId(id, opeType, condition), cacheList(list));
/*     */           
/*     */           break;
/*     */         } 
/* 230 */         c = new MCListScreenCache2(module, screen, serial);
/* 231 */         c.add(getCacheId(id, opeType, condition), cacheList(list));
/* 232 */         SCREEN.add(c);
/*     */         break;
/*     */ 
/*     */       
/*     */       case SYSTEM:
/* 237 */         SYSTEM.add(getCacheId(id, opeType, condition), cacheList(list));
/*     */         break;
/*     */       
/*     */       case null:
/* 241 */         LOGIN.add(getCacheId(id, opeType, condition), cacheList(list));
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static MCList<MCRow> cacheList(MCList<MCRow> list) {
/* 256 */     if (list != null) {
/* 257 */       list = list.shallowClone();
/*     */     }
/* 259 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static MCRow cacheRow(MCRow r) {
/* 270 */     return r;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void cache(MCCacheType type, String module, String screen, int serial, String id, MCRow condition, MCRow row, String opeType) {
/*     */     MCListScreenCache2 c;
/* 289 */     if (type == null) {
/* 290 */       type = MCCacheType.NONE;
/*     */     }
/* 292 */     switch (type) {
/*     */       case SCREEN:
/* 294 */         c = getScreenCache(module, screen, serial);
/* 295 */         if (c != null) {
/* 296 */           c.add(getCacheId(id, opeType, condition), cacheRow(row));
/*     */           
/*     */           break;
/*     */         } 
/* 300 */         c = new MCListScreenCache2(module, screen, serial);
/* 301 */         c.add(getCacheId(id, opeType, condition), cacheRow(row));
/*     */         
/* 303 */         SCREEN.add(c);
/*     */         break;
/*     */       
/*     */       case SYSTEM:
/* 307 */         SYSTEM.add(getCacheId(id, opeType, condition), cacheRow(row));
/*     */         break;
/*     */       
/*     */       case null:
/* 311 */         LOGIN.add(getCacheId(id, opeType, condition), cacheRow(row));
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getCacheId(String id, String opeType, MCRow condition) {
/* 325 */     StringBuilder rtn = (new StringBuilder(id)).append("#").append(opeType);
/* 326 */     if (condition != null) {
/* 327 */       rtn.append("#");
/* 328 */       String[] names = condition.getNameArray();
/* 329 */       for (int i = 0; i < names.length; i++) {
/* 330 */         String n = names[i];
/* 331 */         Comparable<?> val = condition.getValue(n);
/* 332 */         String str = (val != null) ? val.toString() : "";
/* 333 */         rtn.append("\r").append(n).append("\r").append(str);
/*     */       } 
/*     */     } 
/* 336 */     return rtn.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void clear(MCCacheType type) {
/* 347 */     if (type != null) {
/* 348 */       switch (type) {
/*     */         case SCREEN:
/* 350 */           SCREEN.clear();
/*     */           break;
/*     */         case null:
/* 353 */           LOGIN.clear();
/*     */           break;
/*     */         case SYSTEM:
/* 356 */           SYSTEM.clear();
/*     */           break;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void clear() {
/* 371 */     SCREEN.clear();
/* 372 */     LOGIN.clear();
/* 373 */     SYSTEM.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void clear(String module, String screen, int serial) {
/* 386 */     MCListScreenCache2 c = getScreenCache(module, screen, serial);
/* 387 */     if (c != null) {
/* 388 */       c.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void clear(MCRootPanel panel) {
/* 400 */     if (panel != null) {
/* 401 */       clear(panel.getModuleID(), panel.getScreenID(), panel.getSerial());
/* 402 */       MCRootPanel[] a = panel.getPartsPanels(); byte b; int i; MCRootPanel[] arrayOfMCRootPanel1;
/* 403 */       for (i = (arrayOfMCRootPanel1 = a).length, b = 0; b < i; ) { MCRootPanel p = arrayOfMCRootPanel1[b];
/* 404 */         clear(p);
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static MCListScreenCache2 getScreenCache(String module, String screen, int serial) {
/* 424 */     MCListScreenCache2[] a = SCREEN.<MCListScreenCache2>toArray(new MCListScreenCache2[SCREEN.size()]); byte b; int i; MCListScreenCache2[] arrayOfMCListScreenCache21;
/* 425 */     for (i = (arrayOfMCListScreenCache21 = a).length, b = 0; b < i; ) { MCListScreenCache2 c = arrayOfMCListScreenCache21[b];
/* 426 */       if (c.equals(module, screen, serial))
/* 427 */         return c; 
/*     */       b++; }
/*     */     
/* 430 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\list\MCListCacher2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */