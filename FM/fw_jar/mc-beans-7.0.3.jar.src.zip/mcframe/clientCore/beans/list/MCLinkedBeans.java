package mcframe.clientCore.beans.list;

import mcframe.clientCore.beans.MCBeans;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.notice.MCMessageList;

public interface MCLinkedBeans extends MCBeans, MCFormatBeans {
  MCMessageList setViewValue(int paramInt, Comparable<?> paramComparable);
  
  void setViewValue(int paramInt, Comparable<?> paramComparable, MCMessageList paramMCMessageList);
  
  MCMessageList setViewValue(Comparable<?> paramComparable);
  
  void setViewValue(Comparable<?> paramComparable, MCMessageList paramMCMessageList);
  
  Comparable<?> getViewValue(int paramInt);
  
  MCDataType getDataType();
  
  String getRowColumnName();
  
  String getBaseRowColumnName();
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\list\MCLinkedBeans.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */