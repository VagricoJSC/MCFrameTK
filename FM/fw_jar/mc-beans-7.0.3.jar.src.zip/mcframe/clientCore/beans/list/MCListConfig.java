/*     */ package mcframe.clientCore.beans.list;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import mcframe.clientCore.beans.MCListLogic;
/*     */ import mcframe.clientCore.beans.table.MCColumnConfig;
/*     */ import mcframe.clientCore.beans.table.MCColumnType;
/*     */ import mcframe.clientCore.beans.text.MCCalendarPattern;
/*     */ import mcframe.clientCore.beans.text.MCDateFormat;
/*     */ import mcframe.clientCore.beans.text.MCNumberFormat;
/*     */ import mcframe.clientCore.beans.text.MCNumberPattern;
/*     */ import mcframe.clientCore.beans.text.MCTimestampFormat;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCCalendarDate;
/*     */ import mcframe.commonCore.lang.MCDataType;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCListConfig
/*     */ {
/*     */   public static final String INPUT = "input";
/*     */   public static final String LIST = "list";
/*  54 */   private final List<MCLinkedBeans> _links = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   private MCListPutter _list_putter = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   private MCListPutter _input_putter = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   private String _ope_type = "input";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  86 */   private MCListType _list_type = MCListType.STRICT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  94 */   private MCListListener _listener = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final MCLinkBeans _compo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   private final List<MCLinkBeans> _ignore_list_beans = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCListConfig(MCLinkBeans compo) {
/* 120 */     this._compo = compo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCLinkedBeans[] getLinkBeans() {
/* 131 */     List<MCLinkedBeans> l = new ArrayList<>();
/* 132 */     for (MCLinkedBeans c : this._links) {
/* 133 */       l.add(c);
/*     */     }
/* 135 */     return l.<MCLinkedBeans>toArray(new MCLinkedBeans[l.size()]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void addLinkBeans(MCLinkedBeans... compos) {
/* 149 */     if (compos == null)
/*     */       return;  byte b; int i;
/*     */     MCLinkedBeans[] arrayOfMCLinkedBeans;
/* 152 */     for (i = (arrayOfMCLinkedBeans = compos).length, b = 0; b < i; ) { MCLinkedBeans c = arrayOfMCLinkedBeans[b];
/* 153 */       if (c != null && !this._links.contains(c)) {
/* 154 */         this._links.add(c);
/*     */       }
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setLinkBeans(MCLinkedBeans... compos) {
/* 171 */     this._links.clear();
/* 172 */     addLinkBeans(compos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void removeLinkBeans(MCLinkedBeans... compos) {
/* 184 */     if (compos == null)
/*     */       return;  byte b; int i;
/*     */     MCLinkedBeans[] arrayOfMCLinkedBeans;
/* 187 */     for (i = (arrayOfMCLinkedBeans = compos).length, b = 0; b < i; ) { MCLinkedBeans c = arrayOfMCLinkedBeans[b];
/* 188 */       this._links.remove(c);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setListListener(MCListListener listener) {
/* 200 */     this._listener = listener;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCListListener getListListener() {
/* 212 */     return this._listener;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setPutter(MCListPutter putter) {
/* 224 */     setListPutter(putter);
/* 225 */     setInputPutter(putter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setListPutter(MCListPutter putter) {
/* 236 */     this._list_putter = putter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCListPutter getListPutter() {
/* 248 */     return this._list_putter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setInputPutter(MCListPutter putter) {
/* 259 */     this._input_putter = putter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCListPutter getInputPutter() {
/* 271 */     return this._input_putter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCListPutter getPutter() {
/* 283 */     String o = getOpeType();
/* 284 */     if ("input".equals(o)) {
/* 285 */       return getInputPutter();
/*     */     }
/* 287 */     if ("list".equals(o)) {
/* 288 */       return getListPutter();
/*     */     }
/* 290 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setOpeType(String type) {
/* 306 */     this._ope_type = type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String getOpeType() {
/* 317 */     return this._ope_type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setListType(MCListType type) {
/* 329 */     if (type != null) {
/* 330 */       this._list_type = type;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCListType getListType() {
/* 342 */     return this._list_type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <E extends MCRow> MCList<E> addViewColumn(MCList<E> list, String... columns) {
/* 361 */     if (list == null || columns == null)
/* 362 */       return list;  byte b; int i;
/*     */     MCRow[] arrayOfMCRow;
/* 364 */     for (i = (arrayOfMCRow = list.toArray()).length, b = 0; b < i; ) { MCRow o = arrayOfMCRow[b];
/* 365 */       String v = format(o, columns);
/* 366 */       if (v != null)
/* 367 */         o.setValueNE(MCListLogic.getViewColumnName(), v); 
/*     */       b++; }
/*     */     
/* 370 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String format(MCRow row, String... columns) {
/* 387 */     if (row == null || columns == null) {
/* 388 */       return null;
/*     */     }
/* 390 */     List<String> l = new ArrayList<>();
/*     */     
/* 392 */     List<String> e = new ArrayList<>(); byte b; int i;
/*     */     String[] arrayOfString;
/* 394 */     for (i = (arrayOfString = columns).length, b = 0; b < i; ) { String n = arrayOfString[b];
/* 395 */       if (!row.contains(n)) {
/* 396 */         e.add(n);
/*     */       }
/*     */       else {
/*     */         
/* 400 */         Comparable<?> v = row.getValue(n);
/* 401 */         l.add((v != null) ? v.toString() : "");
/*     */       }  b++; }
/*     */     
/* 404 */     if (e.size() > 0) {
/* 405 */       String m = MCStringUtil.join(
/* 406 */           ",", e.<String>toArray(new String[e.size()]));
/* 407 */       throw new MCException(Core_Msg_FW_A.FCBAC0360, new Object[] { m });
/*     */     } 
/*     */     
/* 410 */     return MCStringUtil.join(
/* 411 */         getListDelimiter(), l.<String>toArray(new String[l.size()]));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCList<?> addViewColumn(MCLinkBeans compo, MCList<?> list, String... columns) {
/* 428 */     if (compo == null || list == null || columns == null)
/* 429 */       return list;  byte b; int i;
/*     */     MCRow[] arrayOfMCRow;
/* 431 */     for (i = (arrayOfMCRow = list.toArray()).length, b = 0; b < i; ) { MCRow o = arrayOfMCRow[b];
/* 432 */       Object v = format(compo, o, columns);
/* 433 */       if (v instanceof Comparable)
/* 434 */         o.setValueNE(
/* 435 */             MCListLogic.getViewColumnName(), (Comparable)v); 
/*     */       b++; }
/*     */     
/* 438 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCList<?> addViewColumn(MCLinkBeans compo, MCList<?> list, String[] columns, MCListColumnInfo colInfo) {
/* 457 */     if (compo == null || list == null || columns == null)
/* 458 */       return list;  byte b; int i;
/*     */     MCRow[] arrayOfMCRow;
/* 460 */     for (i = (arrayOfMCRow = list.toArray()).length, b = 0; b < i; ) { MCRow o = arrayOfMCRow[b];
/* 461 */       Object v = format(compo, o, columns, colInfo);
/* 462 */       if (v instanceof Comparable)
/* 463 */         o.setValueNE(
/* 464 */             MCListLogic.getViewColumnName(), (Comparable)v); 
/*     */       b++; }
/*     */     
/* 467 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object format(MCLinkBeans compo, MCRow row, String... columns) {
/* 482 */     MCListColumnInfo colInfo = null;
/* 483 */     return format(compo, row, columns, colInfo);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Object format(MCLinkBeans compo, MCRow row, String[] columns, MCListColumnInfo colInfo) {
/* 489 */     if (compo == null || row == null || columns == null)
/* 490 */       return null; 
/*     */     class Util
/*     */     {
/*     */       final MCListColumnInfo _colInfo;
/*     */       
/*     */       Util(MCListColumnInfo colInfo) {
/* 496 */         this._colInfo = colInfo;
/*     */       }
/*     */       
/*     */       String format(MCRow row, String column) {
/* 500 */         if (this._colInfo != null) {
/* 501 */           MCDataType type = row.getDataType(column);
/* 502 */           if (type == MCDataType.DATE) {
/* 503 */             MCDateFormat f = getDateFormat(column);
/* 504 */             if (f == null) {
/* 505 */               return null;
/*     */             }
/* 507 */             return f.doOutputFormat((MCCalendarDate)row.getDate(column));
/*     */           } 
/* 509 */           if (type == MCDataType.TIMESTAMP) {
/* 510 */             MCTimestampFormat f = getTimestampFormat(column);
/* 511 */             if (f == null) {
/* 512 */               return null;
/*     */             }
/* 514 */             return f.doOutputFormat((MCCalendarDate)row.getTimestamp(column));
/*     */           } 
/* 516 */           if (type == MCDataType.NUMBER) {
/* 517 */             MCNumberFormat f = getNumberFormat(column);
/* 518 */             if (f == null) {
/* 519 */               return null;
/*     */             }
/*     */             
/* 522 */             int scale = scale(column);
/* 523 */             return f.doOutputFormat(row.getNumber(column), scale);
/*     */           } 
/*     */         } 
/* 526 */         return null;
/*     */       }
/*     */ 
/*     */       
/*     */       private MCTimestampFormat getTimestampFormat(String column) {
/* 531 */         String id = id(column);
/* 532 */         if (id == null) {
/* 533 */           return null;
/*     */         }
/* 535 */         MCCalendarPattern cp = MCCalendarPattern.create(id);
/* 536 */         MCTimestampFormat df = new MCTimestampFormat();
/* 537 */         df.setCalendarPattern(cp);
/* 538 */         return df;
/*     */       }
/*     */       private MCDateFormat getDateFormat(String column) {
/* 541 */         String id = id(column);
/* 542 */         if (id == null) {
/* 543 */           return null;
/*     */         }
/* 545 */         MCCalendarPattern cp = MCCalendarPattern.create(id);
/* 546 */         MCDateFormat df = new MCDateFormat();
/* 547 */         df.setCalendarPattern(cp);
/* 548 */         return df;
/*     */       }
/*     */       private MCNumberFormat getNumberFormat(String column) {
/* 551 */         String id = id(column);
/* 552 */         if (id == null) {
/* 553 */           return null;
/*     */         }
/*     */         
/* 556 */         MCNumberPattern np = MCNumberPattern.create(id);
/* 557 */         MCNumberFormat nf = new MCNumberFormat();
/* 558 */         nf.setNumberPattern(np);
/* 559 */         return nf;
/*     */       }
/*     */       private int scale(String column) {
/* 562 */         if (this._colInfo == null) {
/* 563 */           return 0;
/*     */         }
/* 565 */         return this._colInfo.scale(column);
/*     */       }
/*     */       private String id(String column) {
/* 568 */         if (this._colInfo == null) {
/* 569 */           return null;
/*     */         }
/* 571 */         return this._colInfo.id(column);
/*     */       }
/*     */     };
/*     */     
/* 575 */     Util util = new Util(colInfo);
/* 576 */     String[] compoListNames = compo.getListNames();
/* 577 */     MCLinkedBeans[] compoLinkBeans = compo.getLinkBeans();
/* 578 */     List<String> formattedValues = new ArrayList<>();
/*     */     
/* 580 */     List<String> errorColumns = new ArrayList<>(); byte b;
/*     */     int i;
/*     */     String[] arrayOfString1;
/* 583 */     for (i = (arrayOfString1 = columns).length, b = 0; b < i; ) { String n = arrayOfString1[b];
/* 584 */       if (MCStringUtil.eq(compoListNames[0], n)) {
/* 585 */         if (!row.contains(n)) {
/* 586 */           errorColumns.add(n);
/*     */         } else {
/*     */           
/* 589 */           Comparable<?> v = util.format(row, n);
/* 590 */           if (v == null) {
/* 591 */             v = doFormat(compo, row, n);
/*     */           }
/* 593 */           formattedValues.add((v != null) ? v.toString() : "");
/*     */         }  continue;
/*     */       } 
/* 596 */       for (int j = 1; j < compoListNames.length; j++) {
/* 597 */         if (MCStringUtil.eq(compoListNames[j], n)) {
/* 598 */           Comparable<?> v; if (!row.contains(n)) {
/* 599 */             errorColumns.add(n);
/*     */             
/*     */             // Byte code: goto -> 479
/*     */           } 
/*     */           
/* 604 */           if (compoLinkBeans.length > j - 1) {
/* 605 */             MCLinkedBeans c = compoLinkBeans[j - 1];
/* 606 */             v = util.format(row, n);
/* 607 */             if (v == null) {
/* 608 */               v = doFormat(c, row, n);
/*     */             }
/*     */           } else {
/*     */             
/* 612 */             v = row.getValue(n);
/*     */           } 
/* 614 */           formattedValues.add((v != null) ? v.toString() : "");
/*     */           // Byte code: goto -> 479
/*     */         } 
/*     */       } 
/* 618 */       if (MCStringUtil.eq(MCListLogic.getViewColumnName(), n)) {
/* 619 */         if (!row.contains(n)) {
/* 620 */           errorColumns.add(n);
/*     */           
/*     */           continue;
/*     */         } 
/* 624 */         Comparable<?> v = util.format(row, n);
/* 625 */         if (v != null) {
/* 626 */           formattedValues.add((v != null) ? v.toString() : "");
/*     */           continue;
/*     */         } 
/* 629 */         if (row.getDataType(n) == compo.getDataType()) {
/* 630 */           v = doFormat(compo, row, n);
/* 631 */           formattedValues.add((v != null) ? v.toString() : "");
/*     */           continue;
/*     */         } 
/*     */       } 
/* 635 */       if (row.contains(n)) {
/* 636 */         Comparable<?> v = util.format(row, n);
/* 637 */         if (v == null) {
/* 638 */           v = row.getValue(n);
/*     */         }
/* 640 */         formattedValues.add((v != null) ? v.toString() : "");
/*     */       }  continue;
/*     */       b++; }
/*     */     
/* 644 */     if (errorColumns.size() > 0) {
/* 645 */       String m = MCStringUtil.join(
/* 646 */           ",", errorColumns.<String>toArray(new String[errorColumns.size()]));
/* 647 */       throw new MCException(Core_Msg_FW_A.FCBAC0360, new Object[] { m });
/*     */     } 
/*     */     
/* 650 */     return MCStringUtil.join(
/* 651 */         getListDelimiter(), formattedValues.<String>toArray(new String[formattedValues.size()]));
/*     */   }
/*     */   private Comparable<?> doFormat(MCFormatBeans c, MCRow row, String n) {
/* 654 */     if (c instanceof MCColumnConfig) {
/* 655 */       MCColumnConfig o = (MCColumnConfig)c;
/* 656 */       int x = o.getEventInfo().getEventIndex();
/* 657 */       if (x != -1) {
/* 658 */         return o.doListFormat(x, row.getValue(n));
/*     */       }
/*     */       
/* 661 */       return o.doListFormat(row.getValue(n));
/*     */     } 
/*     */ 
/*     */     
/* 665 */     return c.doListFormat(row.getValue(n));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getListDelimiter() {
/* 678 */     String sfx = "list.delimiter";
/* 679 */     String key = null;
/* 680 */     if (this._compo != null) {
/* 681 */       String k = null;
/* 682 */       if (this._compo instanceof MCColumnConfig) {
/* 683 */         switch (((MCColumnConfig)this._compo).getColumnType()) {
/*     */           case TEXT_COMBO:
/*     */           case TEXT_COMBO_FREE:
/*     */           case TEXT_COMBO_SELECT_ONLY:
/* 687 */             k = MCConst.createKey(new String[] { "table.column.combo", sfx });
/*     */             break;
/*     */           case DATE_COMBO:
/*     */           case DATE_COMBO_FREE:
/*     */           case DATE_COMBO_SELECT_ONLY:
/*     */           case TIMESTAMP_COMBO:
/*     */           case TIMESTAMP_COMBO_FREE:
/*     */           case TIMESTAMP_COMBO_SELECT_ONLY:
/* 695 */             k = MCConst.createKey(new String[] { "table.column.combo-date", sfx });
/*     */             break;
/*     */           case NUMBER_COMBO:
/*     */           case NUMBER_COMBO_FREE:
/*     */           case NUMBER_COMBO_SELECT_ONLY:
/* 700 */             k = MCConst.createKey(new String[] { "table.column.combo-number", sfx });
/*     */             break;
/*     */         } 
/*     */ 
/*     */ 
/*     */       
/*     */       } else {
/* 707 */         k = MCConst.createKey(new String[] { this._compo.getType(), sfx });
/*     */       } 
/*     */       
/* 710 */       if (MCConst.beans.containsKey(k)) {
/* 711 */         key = k;
/*     */       }
/*     */     } 
/* 714 */     if (key == null) {
/* 715 */       key = "combo.list.delimiter";
/*     */     }
/*     */     
/* 718 */     String d = MCConst.beans.getStringNoTrim(key);
/* 719 */     return (d != null) ? d : "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setIgnoreListBeans(MCLinkBeans... compos) {
/* 730 */     this._ignore_list_beans.clear();
/* 731 */     addIgnoreListBeans(compos);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addIgnoreListBeans(MCLinkBeans... compos) {
/*     */     byte b;
/*     */     int i;
/*     */     MCLinkBeans[] arrayOfMCLinkBeans;
/* 742 */     for (i = (arrayOfMCLinkBeans = compos).length, b = 0; b < i; ) { MCLinkBeans compo = arrayOfMCLinkBeans[b];
/* 743 */       if (!this._ignore_list_beans.contains(compo)) {
/* 744 */         this._ignore_list_beans.add(compo);
/*     */       }
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCLinkBeans[] getIgnoreListBeans() {
/* 757 */     return this._ignore_list_beans.<MCLinkBeans>toArray(new MCLinkBeans[0]);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\list\MCListConfig.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */