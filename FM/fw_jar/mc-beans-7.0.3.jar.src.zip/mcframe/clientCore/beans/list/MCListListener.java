package mcframe.clientCore.beans.list;

import mcframe.clientCore.event.MCEventBeans;
import mcframe.clientCore.event.MCEventInfo;
import mcframe.commonCore.container.MCList;
import mcframe.commonCore.container.MCRow;

public interface MCListListener {
  MCList getList(MCEventBeans paramMCEventBeans, MCRow paramMCRow, MCEventInfo paramMCEventInfo);
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\list\MCListListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */