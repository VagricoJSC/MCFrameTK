/*     */ package mcframe.clientCore.beans.list;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.MCRowBeans;
/*     */ import mcframe.clientCore.beans.table.MCColumnConfig;
/*     */ import mcframe.clientCore.beans.table.MCTable;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.commonCore.container.MCContainer;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCDataType;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCMessageList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCListPutter
/*     */ {
/*  38 */   private String _listlogicId = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   private String[] _columns = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final MCLinkBeans _compo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private LinkedHashMap<String, Object> _bindMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCListPutter(MCLinkBeans compo, String... columns) {
/*  71 */     if (compo != null) {
/*  72 */       this._compo = compo;
/*  73 */       setColumns(columns);
/*     */     } else {
/*     */       
/*  76 */       throw new MCException(Core_Msg_FW_A.FCBAC0198, new Object[0]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setColumns(String... columns) {
/*  95 */     if (columns != null && columns.length != 0) {
/*  96 */       this._columns = columns;
/*     */     } else {
/*     */       
/*  99 */       throw new MCException(Core_Msg_FW_A.FCBAC0197, new Object[0]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setColumns(LinkedHashMap<String, String> beansColToListColumn) {
/* 117 */     setColumnsImpl(beansColToListColumn, getLinkBeans().getRootPanel(), false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setColumns(LinkedHashMap<String, String> beansColToListColumn, MCRootPanel p) {
/* 136 */     setColumnsImpl(beansColToListColumn, p, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void setColumnsEx(LinkedHashMap<String, String> beansColToListColumn, MCRootPanel p) {
/* 153 */     setColumnsImpl(beansColToListColumn, p, true);
/*     */   }
/*     */ 
/*     */   
/*     */   private final void setColumnsImpl(LinkedHashMap<String, String> beansColToListColumn, MCRootPanel p, boolean throwex) {
/* 158 */     if (beansColToListColumn.size() == 0) {
/* 159 */       if (!throwex) {
/*     */         return;
/*     */       }
/* 162 */       throw new MCException(Core_Msg_FW_A.FCBAC0197, new Object[0]);
/*     */     } 
/*     */     
/* 165 */     MCLinkBeans thisCompo = getLinkBeans();
/* 166 */     int mapSize = beansColToListColumn.size();
/* 167 */     String[] guiCols = (String[])beansColToListColumn.keySet().toArray((Object[])new String[mapSize]);
/*     */     
/* 169 */     MCLinkedBeans[] linkedBeans = new MCLinkedBeans[mapSize - 1];
/* 170 */     String[] listCols = new String[mapSize];
/* 171 */     if (thisCompo instanceof MCRowBeans) {
/*     */ 
/*     */ 
/*     */       
/* 175 */       MCRow pr = getTargetRow(p, thisCompo);
/* 176 */       if (pr == null) {
/* 177 */         if (!throwex) {
/*     */           return;
/*     */         }
/* 180 */         throw new MCException(Core_Msg_FW_A.FCBAC0062, new Object[] { String.valueOf(p.getModuleID()) + p.getScreenID(), 
/* 181 */               thisCompo.getName() });
/*     */       } 
/* 183 */       MCRowBeans[] rbs = (MCRowBeans[])MCBeansUtil.getAllComponents(MCRowBeans.class, (Container)p);
/*     */       
/* 185 */       if (getRowBeansFromRowName(pr, guiCols[0], rbs) != thisCompo) {
/* 186 */         if (!throwex) {
/*     */           return;
/*     */         }
/* 189 */         throw new MCException(Core_Msg_FW_A.FCBAC0064, new Object[] { guiCols[0], thisCompo.getName() });
/*     */       } 
/*     */ 
/*     */       
/* 193 */       for (int i = 0; i < guiCols.length; i++) {
/* 194 */         String gc = guiCols[i];
/* 195 */         if (i > 0) {
/* 196 */           MCLinkedBeans lb = (MCLinkedBeans)getRowBeansFromRowName(pr, gc, 
/* 197 */               rbs);
/* 198 */           if (lb == null) {
/*     */             continue;
/*     */           }
/* 201 */           linkedBeans[i - 1] = lb;
/*     */         } 
/* 203 */         listCols[i] = beansColToListColumn.get(gc);
/*     */         
/*     */         continue;
/*     */       } 
/* 207 */     } else if (thisCompo instanceof MCColumnConfig) {
/*     */       
/* 209 */       MCTable<?> pt = getTargetTable(p, (MCColumnConfig)thisCompo);
/* 210 */       if (pt == null) {
/* 211 */         if (!throwex) {
/*     */           return;
/*     */         }
/* 214 */         throw new MCException(Core_Msg_FW_A.FCBAC0063, new Object[] { String.valueOf(p.getModuleID()) + p.getScreenID(), 
/* 215 */               thisCompo.getName() });
/*     */       } 
/* 217 */       MCColumnConfig[] cs = pt.getColumnConfigs();
/*     */ 
/*     */       
/* 220 */       MCColumnConfig c = getColumnFromRowName(pt, guiCols[0], cs);
/* 221 */       if (c != thisCompo) {
/* 222 */         if (!throwex) {
/*     */           return;
/*     */         }
/* 225 */         throw new MCException(Core_Msg_FW_A.FCBAC0064, new Object[] { guiCols[0], thisCompo.getName() });
/*     */       } 
/*     */       
/* 228 */       for (int i = 0; i < guiCols.length; i++) {
/* 229 */         String gc = guiCols[i];
/* 230 */         if (i > 0) {
/* 231 */           MCColumnConfig lb = getColumnFromRowName(pt, gc, cs);
/* 232 */           if (lb == null) {
/*     */             continue;
/*     */           }
/* 235 */           linkedBeans[i - 1] = (MCLinkedBeans)lb;
/*     */         } 
/* 237 */         listCols[i] = beansColToListColumn.get(gc);
/*     */         
/*     */         continue;
/*     */       } 
/*     */     } 
/* 242 */     thisCompo.setLinkBeans(linkedBeans);
/* 243 */     this._columns = listCols;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCRow getTargetRow(MCRootPanel p, MCLinkBeans thisCompo) {
/* 256 */     MCRowBeans rb = (MCRowBeans)thisCompo;
/*     */     
/* 258 */     MCConstRow mCConstRow = rb.getRow();
/* 259 */     List<MCContainer> l = p.getContainers();
/* 260 */     while (mCConstRow != null) {
/* 261 */       for (MCContainer c : l) {
/* 262 */         if (mCConstRow == c) {
/* 263 */           return (MCRow)mCConstRow;
/*     */         }
/*     */       } 
/* 266 */       MCRow mCRow = mCConstRow.getParentRow();
/*     */     } 
/* 268 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCTable<?> getTargetTable(MCRootPanel p, MCColumnConfig thisCompo) {
/* 281 */     for (MCContainer c : p.getContainers()) {
/* 282 */       if (c instanceof MCList) {
/* 283 */         MCList l = (MCList)c;
/* 284 */         Component lc = p.getComponent(l);
/* 285 */         if (lc instanceof MCTable) {
/* 286 */           MCTable<?> t = (MCTable)lc;
/* 287 */           if (t.getColumnIndex(thisCompo) >= 0) {
/* 288 */             return t;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 293 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCColumnConfig getColumnFromRowName(MCTable<?> t, String colname, MCColumnConfig[] cs) {
/* 308 */     MCList<?> l = t.getList();
/* 309 */     MCRow r = null;
/* 310 */     if (l.size() > 0) {
/* 311 */       r = l.get(0);
/*     */     } else {
/*     */       
/* 314 */       r = l.createRow();
/*     */     } 
/*     */     
/* 317 */     String rn = r.getRealColumnPath(colname);
/* 318 */     if (rn != null) {
/* 319 */       byte b; int i; MCColumnConfig[] arrayOfMCColumnConfig; for (i = (arrayOfMCColumnConfig = cs).length, b = 0; b < i; ) { MCColumnConfig c = arrayOfMCColumnConfig[b];
/* 320 */         if (c != null && 
/* 321 */           rn.equals(c.getRowColumnName(t))) {
/* 322 */           return c;
/*     */         }
/*     */         b++; }
/*     */     
/*     */     } 
/* 327 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCRowBeans getRowBeansFromRowName(MCRow r, String colname, MCRowBeans[] rbs) {
/* 342 */     String rn = r.getRealColumnPath(colname);
/* 343 */     if (rn != null) {
/* 344 */       byte b; int i; MCRowBeans[] arrayOfMCRowBeans; for (i = (arrayOfMCRowBeans = rbs).length, b = 0; b < i; ) { MCRowBeans rb = arrayOfMCRowBeans[b];
/* 345 */         if (rb != null && rn.equals(rb.getRowColumnName(r)))
/* 346 */           return rb; 
/*     */         b++; }
/*     */     
/*     */     } 
/* 350 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String[] getColumns() {
/* 362 */     return this._columns;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCMessageList setValues(int index, MCRow row) {
/* 379 */     MCLinkBeans compo = getLinkBeans();
/* 380 */     if (row != null)
/*     */     {
/* 382 */       return compo.setValues(index, createPanelRow(compo, index, row));
/*     */     }
/* 384 */     return compo.setValues(index, (MCRow)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCRow createPanelRow(MCLinkBeans compo, int index, MCRow row) {
/* 396 */     MCRow temp = MCRow.create();
/* 397 */     String[] names = compo.getListNames();
/* 398 */     int count = (compo.getLinkBeans()).length + 1;
/* 399 */     String[] listcolumns = getColumns();
/* 400 */     for (int i = 0; i < count; i++) {
/* 401 */       String name = names[i];
/* 402 */       String column = listcolumns[i];
/* 403 */       MCDataType type = row.getDataType(column);
/* 404 */       if (type == null) {
/* 405 */         if (i == 0) {
/* 406 */           type = compo.getDataType();
/*     */         } else {
/*     */           
/* 409 */           type = compo.getLinkBeans()[i - 1].getDataType();
/*     */         } 
/*     */       }
/*     */       try {
/* 413 */         switch (type) {
/*     */           case STRING:
/* 415 */             temp.addStringColumn(name, row.getStringNE(column));
/*     */             break;
/*     */           case DATE:
/* 418 */             temp.addDateColumn(name, row.getDateNE(column));
/*     */             break;
/*     */           case TIMESTAMP:
/* 421 */             temp.addTimestampColumn(name, row.getTimestampNE(column));
/*     */             break;
/*     */           case NUMBER:
/* 424 */             temp.addNumberColumn(name, row.getNumberNE(column));
/*     */             break;
/*     */           case BOOLEAN:
/* 427 */             temp.addBooleanColumn(name, row.getBooleanNE(column));
/*     */             break;
/*     */           case null:
/* 430 */             temp.addBinaryColumn(name, row.getBinaryNE(column));
/*     */             break;
/*     */         } 
/*     */ 
/*     */ 
/*     */       
/* 436 */       } catch (Exception exception) {}
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 441 */     return temp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCLinkBeans getLinkBeans() {
/* 452 */     return this._compo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCMessageList setValuesByList(int index, MCList<?> ls) {
/* 467 */     MCLinkBeans compo = getLinkBeans();
/*     */     
/* 469 */     if (ls != null && ls.size() > 0) {
/* 470 */       if (ls.size() > 1) {
/* 471 */         MCRow row = ls.createRow();
/* 472 */         String[] ar = new String[ls.size()];
/* 473 */         for (int i = 0; i < ar.length; i++) {
/* 474 */           MCRow tr = ls.get(i);
/* 475 */           ar[i] = tr.getStringNE(getColumns()[0]);
/*     */         } 
/* 477 */         row.setValueNE(getColumns()[0], MCStringUtil.arrayValueJoin(ar));
/* 478 */         return compo.setValues(index, createPanelRow(compo, index, row));
/*     */       } 
/*     */       
/* 481 */       MCRow r = ls.get(0);
/* 482 */       r.setValueNE(getColumns()[0], 
/* 483 */           MCStringUtil.arrayValueJoin(new String[] { r.getStringNE(getColumns()[0]) }));
/* 484 */       return compo.setValues(index, createPanelRow(compo, index, r));
/*     */     } 
/*     */     
/* 487 */     return compo.setValues(index, (MCRow)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, Object> getBindMap() {
/* 503 */     return this._bindMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putBind(String bindName, Object obj) {
/* 517 */     if (this._bindMap == null) {
/* 518 */       this._bindMap = new LinkedHashMap<>();
/*     */     }
/* 520 */     this._bindMap.put(bindName, obj);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCRow getBindRow(int eventIndex) {
/* 532 */     return getBindRowImpl(eventIndex, true);
/*     */   }
/*     */ 
/*     */   
/*     */   private MCRow getBindRowImpl(int eventIndex, boolean useViewValue) {
/* 537 */     Map<String, Object> bindMap = getBindMap();
/* 538 */     if (bindMap == null) {
/* 539 */       return MCRow.create();
/*     */     }
/* 541 */     MCRow bind = MCRow.create();
/*     */     
/* 543 */     for (Map.Entry<String, Object> e : bindMap.entrySet()) {
/* 544 */       Object obj = e.getValue();
/* 545 */       if (obj == null) {
/* 546 */         bind.setValueNE(e.getKey(), null); continue;
/*     */       } 
/* 548 */       if (obj instanceof MCRowBeans) {
/* 549 */         MCRowBeans beans = (MCRowBeans)obj;
/* 550 */         Comparable<?> val = useViewValue ? beans.getViewValue() : 
/* 551 */           beans.getRowValue();
/* 552 */         bind.addValueColumn(e.getKey(), beans.getDataType(), val); continue;
/*     */       } 
/* 554 */       if (obj instanceof MCColumnConfig) {
/* 555 */         MCColumnConfig config = (MCColumnConfig)obj;
/* 556 */         Comparable<?> val = useViewValue ? config.getViewValue(eventIndex) : 
/* 557 */           config.getBaseTable().getValue(eventIndex, config);
/* 558 */         bind.addValueColumn(e.getKey(), config.getDataType(), val); continue;
/*     */       } 
/* 560 */       if (obj instanceof Comparable) {
/* 561 */         Comparable<?> comp = (Comparable)obj;
/* 562 */         bind.setValueNE(e.getKey(), comp);
/*     */         continue;
/*     */       } 
/* 565 */       String s = obj.getClass().getName();
/* 566 */       throw new MCException(Core_Msg_FW_A.FCBAC0065, new Object[] { s });
/*     */     } 
/*     */     
/* 569 */     return bind;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setListLogicId(String id) {
/* 580 */     this._listlogicId = id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getListLogicId() {
/* 591 */     return this._listlogicId;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\list\MCListPutter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */