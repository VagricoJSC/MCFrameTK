/*     */ package mcframe.clientCore.beans.list;
/*     */ 
/*     */ import java.lang.ref.SoftReference;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.Timer;
/*     */ import java.util.TimerTask;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.notice.Core_Msg;
/*     */ import mcframe.commonCore.notice.MCLog;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class MCListCache2
/*     */ {
/*     */   class ClonableMap<V>
/*     */   {
/*  39 */     private ConcurrentHashMap<String, SoftReference<V>> _cur = new ConcurrentHashMap<>();
/*     */     
/*  41 */     private ConcurrentHashMap<String, SoftReference<V>> _old = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     Map<String, SoftReference<V>> m() {
/*  47 */       if (MCListCacher2._useclonedmap) {
/*  48 */         if (this._old == null) {
/*  49 */           this._old = this._cur;
/*  50 */           this._cur = new ConcurrentHashMap<>(
/*  51 */               this._old.size() * 4 / 3);
/*  52 */           this._cur.putAll(this._old);
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/*  57 */         deleteClonedMap();
/*     */       } 
/*  59 */       return this._cur;
/*     */     }
/*     */     void deleteClonedMap() {
/*  62 */       if (this._old != null) {
/*  63 */         this._cur = this._old;
/*  64 */         this._old = null;
/*     */       } 
/*     */     }
/*     */     
/*     */     void clear() {
/*  69 */       deleteClonedMap();
/*  70 */       this._cur.clear();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     void removeDisused() {
/*  78 */       StringBuilder rmvkeys = new StringBuilder();
/*  79 */       removeDisusedMain(this._cur, rmvkeys);
/*  80 */       removeDisusedMain(this._old, rmvkeys);
/*  81 */       if (rmvkeys.length() > 0) {
/*  82 */         MCLog.write(Core_Msg.FCBAC0423, new Object[] { rmvkeys.toString() });
/*     */       }
/*     */     }
/*     */     
/*     */     private void removeDisusedMain(Map<String, SoftReference<V>> m, StringBuilder rmvkeys) {
/*  87 */       if (m != null) {
/*  88 */         Set<String> s = m.keySet();
/*  89 */         Iterator<String> i = s.iterator();
/*  90 */         while (i.hasNext()) {
/*  91 */           String key = i.next();
/*  92 */           SoftReference<V> l = m.get(key);
/*  93 */           if (l != null && l.get() == null) {
/*  94 */             rmvkeys.append(String.valueOf(key) + "\n");
/*  95 */             i.remove();
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   private final ClonableMap<MCList<MCRow>> _list = new ClonableMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 116 */   private final ClonableMap<MCRow> _row = new ClonableMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Timer _rmvKeyTimer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void deleteClonedMap() {
/* 135 */     this._list.deleteClonedMap();
/* 136 */     this._row.deleteClonedMap();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void clear() {
/* 146 */     this._list.clear();
/* 147 */     this._row.clear();
/* 148 */     cancelRmvKeyTimer();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCList<MCRow> getList(String key) {
/* 165 */     return getMapValue(this._list.m(), key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCRow getRow(String key) {
/* 182 */     return getMapValue(this._row.m(), key);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(String key, MCList<MCRow> list) {
/* 193 */     if (!canCache()) {
/*     */       return;
/*     */     }
/* 196 */     putSoftReference(this._list.m(), key, list);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(String key, MCRow row) {
/* 209 */     if (!canCache()) {
/*     */       return;
/*     */     }
/*     */     
/* 213 */     putSoftReference(this._row.m(), key, row);
/*     */   }
/*     */   private void cancelRmvKeyTimer() {
/* 216 */     if (this._rmvKeyTimer != null) {
/* 217 */       this._rmvKeyTimer.cancel();
/* 218 */       this._rmvKeyTimer = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void startRmvKeyTimer() {
/* 239 */     if (this._rmvKeyTimer == null) {
/* 240 */       int min = MCConst.beans.getInteger("list_cache.unwntdrmvmin", 0);
/* 241 */       if (min > 0) {
/* 242 */         this._rmvKeyTimer = new Timer();
/* 243 */         this._rmvKeyTimer.schedule(new TimerTask()
/*     */             {
/*     */               public void run() {
/* 246 */                 MCListCache2.this._list.removeDisused();
/* 247 */                 MCListCache2.this._row.removeDisused();
/*     */               }
/* 249 */             },  (60000 * min), (60000 * min));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean canCache() {
/* 261 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private <T> T getMapValue(Map<String, SoftReference<T>> m, String key) {
/* 266 */     if (key == null) {
/* 267 */       MCLog.write(Core_Msg.FCBAC0421, new Object[] { key });
/* 268 */       return null;
/*     */     } 
/* 270 */     SoftReference<T> s = m.get(key);
/* 271 */     if (s != null) {
/* 272 */       T v = s.get();
/* 273 */       if (v == null) {
/* 274 */         MCLog.write(Core_Msg.FCBAC0420, new Object[] { key });
/*     */       }
/* 276 */       MCLog.write(Core_Msg.FCBAC0419, new Object[] { key });
/* 277 */       return v;
/*     */     } 
/*     */     
/* 280 */     MCLog.write(Core_Msg.FCBAC0421, new Object[] { key });
/* 281 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private <T> SoftReference<T> putSoftReference(Map<String, SoftReference<T>> m, String key, T val) {
/* 286 */     if (key == null || val == null) {
/* 287 */       MCLog.write(Core_Msg.FCBAC0424, new Object[] { key });
/* 288 */       return null;
/*     */     } 
/* 290 */     MCLog.write(Core_Msg.FCBAC0422, new Object[] { key });
/* 291 */     startRmvKeyTimer();
/* 292 */     return m.put(key, new SoftReference<>(val));
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\list\MCListCache2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */