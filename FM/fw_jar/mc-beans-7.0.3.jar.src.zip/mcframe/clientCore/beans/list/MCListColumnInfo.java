/*     */ package mcframe.clientCore.beans.list;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCListColumnInfo
/*     */ {
/*  13 */   Map<String, Info> m = new HashMap<>();
/*     */   
/*     */   class Info {
/*     */     final String _formatId;
/*     */     final int _scale;
/*     */     
/*     */     Info(String formatId, int scale) {
/*  20 */       this._formatId = formatId;
/*  21 */       this._scale = scale;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MCListColumnInfo create() {
/*  44 */     return new MCListColumnInfo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putCalendarFormat(String column, String id) {
/*  55 */     this.m.put(column, new Info(id, -1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putNumberFormat(String column, String id, int scale) {
/*  67 */     this.m.put(column, new Info(id, scale));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void putNumberFormat(String column, String id) {
/*  79 */     putNumberFormat(column, id, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String id(String column) {
/*  88 */     Info v = this.m.get(column);
/*  89 */     if (v != null) {
/*  90 */       return v._formatId;
/*     */     }
/*  92 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int scale(String column) {
/* 103 */     Info v = this.m.get(column);
/* 104 */     if (v != null) {
/* 105 */       return v._scale;
/*     */     }
/* 107 */     return 0;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\list\MCListColumnInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */