package mcframe.clientCore.beans.list;

public interface MCFormatBeans {
  Comparable<?> doListFormat(Comparable<?> paramComparable);
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\list\MCFormatBeans.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */