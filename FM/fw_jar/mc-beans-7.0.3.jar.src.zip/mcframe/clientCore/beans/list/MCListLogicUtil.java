package mcframe.clientCore.beans.list;

import mcframe.commonCore.util.MCListLogicUtil;

public class MCListLogicUtil extends MCListLogicUtil {}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\list\MCListLogicUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */