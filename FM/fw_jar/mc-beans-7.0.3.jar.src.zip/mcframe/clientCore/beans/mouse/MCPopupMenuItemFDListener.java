/*    */ package mcframe.clientCore.beans.mouse;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import java.awt.Container;
/*    */ import mcframe.clientCore.beans.MCBeans;
/*    */ import mcframe.clientCore.beans.popup.MCMenu;
/*    */ import mcframe.clientCore.beans.popup.MCPopupBeans;
/*    */ import mcframe.clientCore.beans.popup.MCPopupMenu;
/*    */ import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
/*    */ import mcframe.commonCore.util.MCCollectionUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCPopupMenuItemFDListener
/*    */   extends MCDefaultFDListener
/*    */ {
/*    */   private final Component _compo;
/*    */   private final MCTextPopupMenuItem _item;
/*    */   
/*    */   public MCPopupMenuItemFDListener(Component compo, MCTextPopupMenuItem item, String msgid) {
/* 27 */     super(msgid);
/* 28 */     this._compo = compo;
/* 29 */     this._item = item;
/*    */   }
/*    */   
/*    */   public MCPopupMenuItemFDListener(Component compo, MCTextPopupMenuItem item) {
/* 33 */     this._compo = compo;
/* 34 */     this._item = item;
/*    */   }
/*    */ 
/*    */   
/*    */   public MCPopupBeans getActionBeans() {
/* 39 */     return (MCPopupBeans)this._compo;
/*    */   }
/*    */ 
/*    */   
/*    */   public void doFDEvent() {
/* 44 */     this._item.doAP();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean canFDEvent() {
/* 49 */     MCPopupMenu m = getActionBeans().getComponentPopupMenu();
/* 50 */     if (m == null) {
/* 51 */       return false;
/*    */     }
/*    */     
/* 54 */     if (!contains(m.getComponents(), (Component)this._item)) {
/* 55 */       return false;
/*    */     }
/*    */     
/* 58 */     return (this._item.isVisible() && this._item.isEnabled());
/*    */   }
/*    */   
/*    */   private boolean contains(Component[] compos, Component compo) {
/* 62 */     if (MCCollectionUtil.contains(compo, (Object[])compos))
/* 63 */       return true;  byte b;
/*    */     int i;
/*    */     Component[] arrayOfComponent;
/* 66 */     for (i = (arrayOfComponent = compos).length, b = 0; b < i; ) { Component c = arrayOfComponent[b];
/* 67 */       if (c instanceof MCMenu) {
/* 68 */         MCMenu m = (MCMenu)c;
/* 69 */         if (contains(m.getMenuComponents(), compo)) {
/* 70 */           return true;
/*    */         }
/*    */       }
/* 73 */       else if (c instanceof Container) {
/* 74 */         Container o = (Container)c;
/* 75 */         if (contains(o.getComponents(), compo))
/* 76 */           return true; 
/*    */       } 
/*    */       b++; }
/*    */     
/* 80 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isFocusToBeans() {
/* 85 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\mouse\MCPopupMenuItemFDListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */