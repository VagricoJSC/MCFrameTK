/*    */ package mcframe.clientCore.beans.mouse;
/*    */ 
/*    */ import mcframe.clientCore.event.AbsMCPackageProxy;
/*    */ import mcframe.clientCore.event.MCEventInfo;
/*    */ 
/*    */ final class MCEventProxy
/*    */   extends AbsMCPackageProxy {
/*  8 */   static final MCEventProxy PROXY = new MCEventProxy();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void setOldValue(MCEventInfo info, Comparable<?> value) {
/* 15 */     super.setOldValue(info, value);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\mouse\MCEventProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */