/*    */ package mcframe.clientCore.beans.mouse;
/*    */ 
/*    */ import mcframe.clientCore.event.MCFDListener;
/*    */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*    */ 
/*    */ abstract class MCDefaultFDListener
/*    */   implements MCFDListener
/*    */ {
/*    */   private final String _msgid;
/*    */   
/*    */   MCDefaultFDListener() {
/* 12 */     this._msgid = Core_Msg_FW_A.FCBAC0431;
/*    */   }
/*    */   
/*    */   MCDefaultFDListener(String msgid) {
/* 16 */     this._msgid = msgid;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getConfirmMsgID() {
/* 21 */     return this._msgid;
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\mouse\MCDefaultFDListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */