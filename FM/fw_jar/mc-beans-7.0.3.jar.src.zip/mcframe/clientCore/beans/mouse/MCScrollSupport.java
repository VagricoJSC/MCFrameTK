/*     */ package mcframe.clientCore.beans.mouse;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Cursor;
/*     */ import java.awt.Point;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.awt.event.MouseMotionListener;
/*     */ import java.util.Objects;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JViewport;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.Timer;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCScrollPane;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Deprecated
/*     */ public abstract class MCScrollSupport
/*     */ {
/*     */   public static final String RES_DRAG_MOVE = "DRAG_MOVE";
/*  56 */   private final PreScrollAdapter _preadapter = new PreScrollAdapter(null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  63 */   private final PostScrollAdapter _postadapter = new PostScrollAdapter(null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   private Point _pressedPos = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean _doEvent = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final MCScrollPane _sp;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCScrollSupport() {
/*  95 */     this._sp = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCScrollSupport(MCScrollPane sp) {
/* 106 */     this._sp = sp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final class PreScrollAdapter
/*     */     extends MouseAdapter
/*     */   {
/* 121 */     private final Cursor arrow = null;
/*     */     
/* 123 */     private final Cursor hand = Cursor.getPredefinedCursor(12);
/*     */ 
/*     */     
/*     */     public void mousePressed(MouseEvent e) {
/* 127 */       super.mousePressed(e);
/* 128 */       if (MCScrollSupport.this.canAction(e)) {
/* 129 */         Container c; JComponent jc = (JComponent)e.getSource();
/* 130 */         setHandCursor(jc);
/*     */         
/* 132 */         if (MCScrollSupport.this._sp != null) {
/* 133 */           c = MCScrollSupport.this._sp.getViewport();
/*     */         } else {
/*     */           
/* 136 */           c = jc.getParent();
/*     */         } 
/*     */         
/* 139 */         if (c instanceof JViewport) {
/* 140 */           JViewport vport = (JViewport)c;
/*     */ 
/*     */           
/* 143 */           MCScrollSupport.this._pressedPos = vport.getViewPosition();
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void mouseDragged(MouseEvent e) {
/* 150 */       super.mouseDragged(e);
/* 151 */       if (MCScrollSupport.this.canAction(e)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 160 */         MCBeansUtil.suppressAfter(true);
/* 161 */         SwingUtilities.invokeLater(new Runnable()
/*     */             {
/*     */               public void run() {
/* 164 */                 MCBeansUtil.suppressAfter(false);
/*     */               }
/*     */             });
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void mouseReleased(MouseEvent e) {
/* 172 */       super.mouseReleased(e);
/* 173 */       setArrowCursor((JComponent)e.getSource());
/*     */     }
/*     */ 
/*     */     
/*     */     public void mouseExited(MouseEvent e) {
/* 178 */       super.mouseExited(e);
/* 179 */       setArrowCursor((JComponent)e.getSource());
/*     */     }
/*     */     
/*     */     private void setHandCursor(JComponent c) {
/* 183 */       if (c != null)
/* 184 */       { Cursor bef = c.getCursor();
/* 185 */         if (!Objects.equals(this.arrow, bef))
/* 186 */         { if (Objects.equals(
/* 187 */               Cursor.getDefaultCursor(), bef))
/* 188 */           { c.setCursor(this.hand); return; }  return; }  } else { return; }  c.setCursor(this.hand);
/*     */     }
/*     */ 
/*     */     
/*     */     private void setArrowCursor(Component c) {
/* 193 */       if (c != null) {
/* 194 */         Cursor bef = c.getCursor();
/* 195 */         if (Objects.equals(this.hand, bef)) {
/* 196 */           c.setCursor(this.arrow);
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private PreScrollAdapter() {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private final class PostScrollAdapter
/*     */     extends MouseAdapter
/*     */   {
/* 212 */     private final int _timerDelay = 20;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 217 */     private final long _timerActivatedTimeLag = 100L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 223 */     private final double _acceleration = MCConst.beans.getNumber("mouse.drag_move.acceleration", 
/* 224 */         new MCNumber(-0.1D)).doubleValue();
/*     */ 
/*     */     
/* 227 */     private Point _oldPoint = null;
/* 228 */     private long _oldTime = 0L;
/* 229 */     private double _distanceX = 0.0D;
/* 230 */     private double _distanceY = 0.0D;
/* 231 */     private long _perTime = 0L;
/* 232 */     Timer _timer = null;
/*     */ 
/*     */ 
/*     */     
/*     */     public void mousePressed(MouseEvent e) {
/* 237 */       super.mousePressed(e);
/* 238 */       if (this._timer != null && this._timer.isRunning()) {
/* 239 */         this._timer.stop();
/*     */       }
/* 241 */       if (MCScrollSupport.this.canAction(e)) {
/* 242 */         Container c; JComponent jc = (JComponent)e.getSource();
/*     */ 
/*     */         
/* 245 */         if (MCScrollSupport.this._sp != null) {
/* 246 */           c = MCScrollSupport.this._sp.getViewport();
/*     */         } else {
/*     */           
/* 249 */           c = jc.getParent();
/*     */         } 
/*     */         
/* 252 */         Point cp = e.getPoint();
/* 253 */         if (c instanceof JViewport) {
/* 254 */           JViewport vport = (JViewport)c;
/* 255 */           Point cvp = vport.getViewPosition();
/* 256 */           cp.translate(
/* 257 */               cvp.x - MCScrollSupport.this._pressedPos.x, 
/* 258 */               cvp.y - MCScrollSupport.this._pressedPos.y);
/*     */         } 
/* 260 */         cp = SwingUtilities.convertPoint(jc, cp, c);
/* 261 */         this._oldPoint = cp;
/* 262 */         this._oldTime = e.getWhen();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void mouseDragged(MouseEvent e) {
/* 268 */       super.mouseDragged(e);
/* 269 */       JComponent jc = (JComponent)e.getSource();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 274 */       if (this._oldPoint != null && MCScrollSupport.this.canAction(e)) {
/*     */         Component destination;
/* 276 */         if (MCScrollSupport.this._sp != null) {
/* 277 */           destination = MCScrollSupport.this._sp.getViewport();
/*     */         } else {
/*     */           
/* 280 */           destination = jc.getParent();
/*     */         } 
/* 282 */         Point cp = SwingUtilities.convertPoint(jc, e.getPoint(), destination);
/*     */         
/* 284 */         MCScrollSupport.this.move(e, this._oldPoint, cp);
/* 285 */         this._distanceX = cp.getX() - this._oldPoint.getX();
/* 286 */         this._distanceY = cp.getY() - this._oldPoint.getY();
/* 287 */         this._perTime = e.getWhen() - this._oldTime;
/* 288 */         this._oldPoint = cp;
/* 289 */         this._oldTime = e.getWhen();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public void mouseReleased(final MouseEvent mouseEvent) {
/* 296 */       super.mouseReleased(mouseEvent);
/*     */ 
/*     */ 
/*     */       
/* 300 */       if (this._oldPoint != null && 
/* 301 */         MCScrollSupport.this.canAction(mouseEvent) && 
/* 302 */         mouseEvent.getWhen() - this._oldTime < 100L && 
/* 303 */         this._perTime > 0L) {
/* 304 */         Component destination; JComponent jc = (JComponent)mouseEvent.getSource();
/*     */ 
/*     */         
/* 307 */         if (MCScrollSupport.this._sp != null) {
/* 308 */           destination = MCScrollSupport.this._sp.getViewport();
/*     */         } else {
/*     */           
/* 311 */           destination = jc.getParent();
/*     */         } 
/* 313 */         Point op = SwingUtilities.convertPoint(jc, mouseEvent.getPoint(), destination);
/*     */         
/* 315 */         this._timer = new Timer(20, new ActionListener(op)
/*     */             {
/*     */               private Point _op;
/*     */               
/*     */               private double _absx;
/*     */               private double _absy;
/*     */               private double _absXRatio;
/*     */               private double _absYRatio;
/*     */               
/*     */               public void actionPerformed(ActionEvent e) {
/* 325 */                 if (!(MCScrollSupport.PostScrollAdapter.access$8(MCScrollSupport.PostScrollAdapter.this))._doEvent) {
/* 326 */                   MCScrollSupport.PostScrollAdapter.this._timer.stop();
/*     */                 } else {
/*     */                   
/* 329 */                   MCScrollSupport.PostScrollAdapter.this._distanceX = MCScrollSupport.PostScrollAdapter.this.getNewDistance(MCScrollSupport.PostScrollAdapter.this._distanceX, this._absXRatio * 
/* 330 */                       MCScrollSupport.PostScrollAdapter.this._acceleration);
/* 331 */                   MCScrollSupport.PostScrollAdapter.this._distanceY = MCScrollSupport.PostScrollAdapter.this.getNewDistance(MCScrollSupport.PostScrollAdapter.this._distanceY, this._absYRatio * 
/* 332 */                       MCScrollSupport.PostScrollAdapter.this._acceleration);
/* 333 */                   MCScrollSupport.PostScrollAdapter.this._perTime = 20L;
/*     */ 
/*     */                   
/* 336 */                   Point np = new Point();
/* 337 */                   np.setLocation(this._op.getX() + MCScrollSupport.PostScrollAdapter.this._distanceX, this._op.getY() + 
/* 338 */                       MCScrollSupport.PostScrollAdapter.this._distanceY);
/* 339 */                   if (this._op.equals(np)) {
/* 340 */                     MCScrollSupport.PostScrollAdapter.this._timer.stop();
/*     */                   
/*     */                   }
/*     */                   else {
/*     */                     
/* 345 */                     if (!MCScrollSupport.PostScrollAdapter.access$8(MCScrollSupport.PostScrollAdapter.this).move(mouseEvent, this._op, np)) {
/* 346 */                       MCScrollSupport.PostScrollAdapter.this._timer.stop();
/*     */                     }
/*     */                     
/* 349 */                     this._op = np;
/*     */                   } 
/*     */                 } 
/*     */               }
/*     */             });
/* 354 */         this._timer.start();
/*     */       } 
/*     */ 
/*     */       
/* 358 */       this._oldPoint = null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private double getNewDistance(double distance, double a) {
/* 375 */       double pn = distance / Math.abs(distance);
/*     */       
/* 377 */       double speed = Math.abs(distance) / this._perTime;
/* 378 */       double newSpeed = speed + a;
/* 379 */       if (speed * newSpeed < 0.0D) {
/* 380 */         newSpeed = 0.0D;
/*     */       }
/* 382 */       double nd = pn * newSpeed * 20.0D;
/* 383 */       if (Double.isNaN(nd)) {
/* 384 */         nd = 0.0D;
/*     */       }
/* 386 */       return nd;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private PostScrollAdapter() {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addTo(JComponent c) {
/* 399 */     removeFrom(c);
/*     */ 
/*     */     
/* 402 */     MouseListener[] ml = c.getMouseListeners(); byte b; int i; MouseListener[] arrayOfMouseListener1;
/* 403 */     for (i = (arrayOfMouseListener1 = ml).length, b = 0; b < i; ) { MouseListener l = arrayOfMouseListener1[b];
/* 404 */       c.removeMouseListener(l); b++; }
/*     */     
/* 406 */     c.addMouseListener(this._preadapter);
/* 407 */     for (i = (arrayOfMouseListener1 = ml).length, b = 0; b < i; ) { MouseListener l = arrayOfMouseListener1[b];
/* 408 */       c.addMouseListener(l); b++; }
/*     */     
/* 410 */     c.addMouseListener(this._postadapter);
/*     */     
/* 412 */     MouseMotionListener[] mml = c.getMouseMotionListeners(); int j; MouseMotionListener[] arrayOfMouseMotionListener1;
/* 413 */     for (j = (arrayOfMouseMotionListener1 = mml).length, i = 0; i < j; ) { MouseMotionListener l = arrayOfMouseMotionListener1[i];
/* 414 */       c.removeMouseMotionListener(l); i++; }
/*     */     
/* 416 */     c.addMouseMotionListener(this._preadapter);
/* 417 */     for (j = (arrayOfMouseMotionListener1 = mml).length, i = 0; i < j; ) { MouseMotionListener l = arrayOfMouseMotionListener1[i];
/* 418 */       c.addMouseMotionListener(l); i++; }
/*     */     
/* 420 */     c.addMouseMotionListener(this._postadapter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void removeFrom(JComponent c) {
/* 430 */     c.removeMouseListener(this._preadapter);
/* 431 */     c.removeMouseMotionListener(this._preadapter);
/* 432 */     c.removeMouseListener(this._postadapter);
/* 433 */     c.removeMouseMotionListener(this._postadapter);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnabled(boolean b) {
/* 445 */     this._doEvent = b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEnabled() {
/* 454 */     return this._doEvent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isExecMouseButton(MouseEvent e) {
/* 469 */     return SwingUtilities.isLeftMouseButton(e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean canAction(MouseEvent e) {
/* 478 */     return (this._doEvent && isExecMouseButton(e));
/*     */   }
/*     */   
/*     */   protected abstract boolean move(MouseEvent paramMouseEvent, Point paramPoint1, Point paramPoint2);
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\mouse\MCScrollSupport.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */