/*    */ package mcframe.clientCore.beans.mouse;
/*    */ 
/*    */ import java.io.File;
/*    */ import javax.swing.text.JTextComponent;
/*    */ import mcframe.clientCore.beans.MCBeans;
/*    */ import mcframe.clientCore.beans.MCMode;
/*    */ import mcframe.clientCore.beans.MCModeBeans;
/*    */ import mcframe.clientCore.event.MCFDListener;
/*    */ 
/*    */ public abstract class MCFieldFDListener<T extends JTextComponent>
/*    */   implements MCFDListener
/*    */ {
/*    */   private final T _compo;
/*    */   
/*    */   protected MCFieldFDListener(T compo) {
/* 16 */     this._compo = compo;
/*    */   }
/*    */ 
/*    */   
/*    */   public MCModeBeans getActionBeans() {
/* 21 */     return (MCModeBeans)this._compo;
/*    */   }
/*    */ 
/*    */   
/*    */   public void doFDEvent() {
/* 26 */     File file = MCBeansProxy.PROXY
/* 27 */       .getDroppedFile(getActionBeans().getBaseRootPanel());
/* 28 */     doFDEventSub(file);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean canFDEvent() {
/* 35 */     return MCMode.isEnable(getActionBeans());
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isFocusToBeans() {
/* 40 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getConfirmMsgID() {
/* 45 */     return null;
/*    */   }
/*    */   
/*    */   protected abstract void doFDEventSub(File paramFile);
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\mouse\MCFieldFDListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */