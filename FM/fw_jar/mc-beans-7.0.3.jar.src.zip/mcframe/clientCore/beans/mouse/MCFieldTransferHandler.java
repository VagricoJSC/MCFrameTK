/*     */ package mcframe.clientCore.beans.mouse;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.datatransfer.Clipboard;
/*     */ import java.awt.datatransfer.DataFlavor;
/*     */ import java.awt.datatransfer.StringSelection;
/*     */ import java.awt.datatransfer.Transferable;
/*     */ import java.awt.datatransfer.UnsupportedFlavorException;
/*     */ import java.awt.im.InputContext;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.TransferHandler;
/*     */ import javax.swing.text.BadLocationException;
/*     */ import javax.swing.text.Document;
/*     */ import javax.swing.text.JTextComponent;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCFrame;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.MCRowBeans;
/*     */ import mcframe.clientCore.beans.table.MCTable;
/*     */ import mcframe.clientCore.event.MCNCReceiver;
/*     */ import mcframe.clientCore.event.MCVCReceiver;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class MCFieldTransferHandler<T extends JTextComponent>
/*     */   extends TransferHandler
/*     */ {
/*     */   private final T _compo;
/*     */   
/*     */   protected MCFieldTransferHandler(T compo) {
/*  51 */     this._compo = compo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCRowBeans getRowBeans() {
/*  62 */     return (MCRowBeans)this._compo;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean importData(TransferHandler.TransferSupport support) {
/*  67 */     if (!support.isDrop()) {
/*     */       
/*  69 */       if (support.isDataFlavorSupported(DataFlavor.stringFlavor)) {
/*  70 */         InputContext ic = this._compo.getInputContext();
/*  71 */         if (ic != null) {
/*  72 */           ic.endComposition();
/*     */         }
/*     */         try {
/*  75 */           Transferable t = support.getTransferable();
/*  76 */           String data = (String)t.getTransferData(DataFlavor.stringFlavor);
/*     */           
/*  78 */           this._compo.replaceSelection(data);
/*  79 */           return true;
/*     */         }
/*  81 */         catch (UnsupportedFlavorException unsupportedFlavorException) {
/*     */         
/*  83 */         } catch (IOException iOException) {}
/*     */       } 
/*     */       
/*  86 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  92 */       final MCRootPanel panel = getRowBeans().getBaseRootPanel();
/*  93 */       MCFrame frame = panel.getFrame();
/*  94 */       if (frame != null && !frame.isActive()) {
/*  95 */         return false;
/*     */       }
/*     */ 
/*     */       
/*  99 */       JComponent owner = MCBeansUtil.getFocusOwner(panel);
/* 100 */       if (!getRowBeans().equalsIgnoreCase(owner)) {
/* 101 */         boolean focus = false;
/* 102 */         if (owner instanceof MCTable) {
/* 103 */           MCTable<?> t = (MCTable)owner;
/* 104 */           Component c = t.getMCEditorComponent();
/* 105 */           if (getRowBeans().equalsIgnoreCase(c)) {
/* 106 */             focus = true;
/*     */           }
/*     */         } 
/* 109 */         if (!focus) {
/* 110 */           if (owner instanceof MCVCReceiver) {
/* 111 */             if (((MCVCReceiver)owner).isValueChanged()) {
/* 112 */               return false;
/*     */             }
/*     */           }
/* 115 */           else if (owner instanceof MCNCReceiver && (
/* 116 */             (MCNCReceiver)owner).isValueChanged()) {
/* 117 */             return false;
/*     */           } 
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 123 */       final File file = getImportFile(support);
/*     */ 
/*     */       
/* 126 */       SwingUtilities.invokeLater(new Runnable()
/*     */           {
/*     */             public void run() {
/*     */               try {
/* 130 */                 MCBeansProxy.PROXY.setDroppedFile(panel, file);
/* 131 */                 MCFieldTransferHandler.this.doFD();
/*     */               }
/* 133 */               catch (Exception e) {
/* 134 */                 MCFieldTransferHandler.this.handle(e);
/*     */               } finally {
/*     */                 
/* 137 */                 MCBeansProxy.PROXY.setDroppedFile(panel, null);
/*     */               } 
/*     */             }
/*     */           });
/* 141 */       return true;
/*     */     }
/* 143 */     catch (Exception e) {
/* 144 */       SwingUtilities.invokeLater(new Runnable()
/*     */           {
/*     */             public void run() {
/* 147 */               MCFieldTransferHandler.this.handle(e);
/*     */             }
/*     */           });
/* 150 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canImport(TransferHandler.TransferSupport support) {
/* 159 */     if (!support.isDrop())
/*     */     {
/* 161 */       if (!this._compo.isEditable() || !this._compo.isEnabled()) {
/* 162 */         return false;
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 168 */     support.setShowDropLocation(false);
/*     */     
/*     */     try {
/* 171 */       if (!support.isDataFlavorSupported(DataFlavor.javaFileListFlavor) || 
/* 172 */         !canFD(support)) {
/* 173 */         return false;
/*     */       }
/* 175 */       return true;
/*     */     }
/* 177 */     catch (Exception e) {
/* 178 */       SwingUtilities.invokeLater(new Runnable()
/*     */           {
/*     */             public void run() {
/* 181 */               MCFieldTransferHandler.this.handle(e);
/*     */             }
/*     */           });
/* 184 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void handle(Exception e) {
/* 198 */     MCEventProxy.PROXY.setOldValue(getRowBeans().getEventInfo(), getRowBeans()
/* 199 */         .getRowValue());
/* 200 */     getRowBeans().handle(e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private File getImportFile(TransferHandler.TransferSupport support) {
/*     */     try {
/* 214 */       Transferable t = support.getTransferable();
/* 215 */       List<File> l = (List<File>)t.getTransferData(DataFlavor.javaFileListFlavor);
/*     */       
/* 217 */       if (l.isEmpty()) {
/* 218 */         return null;
/*     */       }
/*     */       
/* 221 */       if (l.size() > 1) {
/* 222 */         throw new MCException(Core_Msg_FW_A.FCBAC0427, new Object[0]);
/*     */       }
/*     */       
/* 225 */       return l.get(0);
/*     */     }
/* 227 */     catch (IOException|UnsupportedFlavorException e) {
/* 228 */       throw new MCException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void exportToClipboard(JComponent comp, Clipboard clipboard, int action) throws IllegalStateException {
/* 255 */     if (comp instanceof JTextComponent) {
/* 256 */       JTextComponent text = (JTextComponent)comp;
/* 257 */       int p0 = text.getSelectionStart();
/* 258 */       int p1 = text.getSelectionEnd();
/* 259 */       if (p0 != p1) {
/*     */         try {
/* 261 */           Document doc = text.getDocument();
/* 262 */           String srcData = doc.getText(p0, p1 - p0);
/* 263 */           StringSelection contents = new StringSelection(srcData);
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 268 */           clipboard.setContents(contents, null);
/*     */           
/* 270 */           if (action == 2) {
/* 271 */             doc.remove(p0, p1 - p0);
/*     */           }
/*     */         }
/* 274 */         catch (BadLocationException badLocationException) {}
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSourceActions(JComponent c) {
/* 284 */     return 0;
/*     */   }
/*     */   
/*     */   protected abstract boolean canFD(TransferHandler.TransferSupport paramTransferSupport);
/*     */   
/*     */   protected abstract void doFD();
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\mouse\MCFieldTransferHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */