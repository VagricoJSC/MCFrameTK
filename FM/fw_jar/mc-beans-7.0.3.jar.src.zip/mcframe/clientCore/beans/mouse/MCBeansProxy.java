/*    */ package mcframe.clientCore.beans.mouse;
/*    */ 
/*    */ import java.io.File;
/*    */ import mcframe.clientCore.beans.AbsMCPackageProxy;
/*    */ import mcframe.clientCore.beans.MCRootPanel;
/*    */ 
/*    */ final class MCBeansProxy
/*    */   extends AbsMCPackageProxy
/*    */ {
/* 10 */   static final MCBeansProxy PROXY = new MCBeansProxy();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected void setDroppedFile(MCRootPanel panel, File file) {
/* 17 */     super.setDroppedFile(panel, file);
/*    */   }
/*    */ 
/*    */   
/*    */   protected File getDroppedFile(MCRootPanel panel) {
/* 22 */     return super.getDroppedFile(panel);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\mouse\MCBeansProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */