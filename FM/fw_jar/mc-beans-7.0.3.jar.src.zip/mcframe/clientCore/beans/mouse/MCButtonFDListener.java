/*    */ package mcframe.clientCore.beans.mouse;
/*    */ 
/*    */ import mcframe.clientCore.beans.MCBeans;
/*    */ import mcframe.clientCore.beans.MCButton;
/*    */ import mcframe.clientCore.beans.MCMode;
/*    */ import mcframe.clientCore.beans.MCModeBeans;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MCButtonFDListener
/*    */   extends MCDefaultFDListener
/*    */ {
/*    */   private final MCButton _compo;
/*    */   
/*    */   public MCButtonFDListener(MCButton compo, String msgid) {
/* 18 */     super(msgid);
/* 19 */     this._compo = compo;
/*    */   }
/*    */   
/*    */   public MCButtonFDListener(MCButton compo) {
/* 23 */     this._compo = compo;
/*    */   }
/*    */ 
/*    */   
/*    */   public MCButton getActionBeans() {
/* 28 */     return this._compo;
/*    */   }
/*    */ 
/*    */   
/*    */   public void doFDEvent() {
/* 33 */     this._compo.doAP();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean canFDEvent() {
/* 38 */     return MCMode.isEnable((MCModeBeans)this._compo);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isFocusToBeans() {
/* 43 */     return true;
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\mouse\MCButtonFDListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */