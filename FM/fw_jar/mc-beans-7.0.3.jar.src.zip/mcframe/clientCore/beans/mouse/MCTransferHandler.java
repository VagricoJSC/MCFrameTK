/*     */ package mcframe.clientCore.beans.mouse;
/*     */ 
/*     */ import java.awt.datatransfer.DataFlavor;
/*     */ import java.awt.datatransfer.Transferable;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.TransferHandler;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCFrame;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.MCRowBeans;
/*     */ import mcframe.clientCore.event.MCFDBeans;
/*     */ import mcframe.clientCore.event.MCNCReceiver;
/*     */ import mcframe.clientCore.event.MCVCReceiver;
/*     */ import mcframe.commonCore.notice.Core_Msg_FW_A;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MCTransferHandler
/*     */   extends TransferHandler
/*     */ {
/*     */   private final MCFDBeans _compo;
/*     */   
/*     */   public MCTransferHandler(MCFDBeans compo) {
/*  37 */     this._compo = compo;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean importData(TransferHandler.TransferSupport support) {
/*  42 */     if (!support.isDrop()) {
/*  43 */       return super.importData(support);
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/*  48 */       final MCRootPanel panel = this._compo.getBaseRootPanel();
/*  49 */       MCFrame frame = panel.getFrame();
/*  50 */       if (frame != null && !frame.isActive()) {
/*  51 */         return false;
/*     */       }
/*     */ 
/*     */       
/*  55 */       JComponent owner = MCBeansUtil.getFocusOwner(panel);
/*  56 */       if (owner instanceof MCVCReceiver) {
/*  57 */         if (((MCVCReceiver)owner).isValueChanged()) {
/*  58 */           return false;
/*     */         }
/*     */       }
/*  61 */       else if (owner instanceof MCNCReceiver && (
/*  62 */         (MCNCReceiver)owner).isValueChanged()) {
/*  63 */         return false;
/*     */       } 
/*     */ 
/*     */       
/*  67 */       final File file = getImportFile(support);
/*     */ 
/*     */       
/*  70 */       SwingUtilities.invokeLater(new Runnable()
/*     */           {
/*     */             public void run() {
/*     */               try {
/*  74 */                 MCBeansProxy.PROXY.setDroppedFile(panel, file);
/*  75 */                 MCTransferHandler.this._compo.doFD();
/*     */               }
/*  77 */               catch (Exception e) {
/*  78 */                 MCTransferHandler.this.handle(e);
/*     */               } finally {
/*     */                 
/*  81 */                 MCBeansProxy.PROXY.setDroppedFile(panel, null);
/*     */               } 
/*     */             }
/*     */           });
/*  85 */       return true;
/*     */     }
/*  87 */     catch (Exception e) {
/*     */ 
/*     */ 
/*     */       
/*  91 */       SwingUtilities.invokeLater(new Runnable()
/*     */           {
/*     */             public void run() {
/*  94 */               MCTransferHandler.this.handle(e);
/*     */             }
/*     */           });
/*  97 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean canImport(TransferHandler.TransferSupport support) {
/* 106 */     if (!support.isDrop()) {
/* 107 */       return super.canImport(support);
/*     */     }
/*     */ 
/*     */     
/* 111 */     support.setShowDropLocation(false);
/*     */     
/*     */     try {
/* 114 */       if (!support.isDataFlavorSupported(DataFlavor.javaFileListFlavor) || 
/* 115 */         !this._compo.canFD(support)) {
/* 116 */         return false;
/*     */       }
/* 118 */       return true;
/*     */     }
/* 120 */     catch (Exception e) {
/* 121 */       SwingUtilities.invokeLater(new Runnable()
/*     */           {
/*     */             public void run() {
/* 124 */               MCTransferHandler.this.handle(e);
/*     */             }
/*     */           });
/* 127 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void handle(Exception e) {
/* 139 */     if (this._compo instanceof MCRowBeans) {
/*     */ 
/*     */       
/* 142 */       MCRowBeans compo = (MCRowBeans)this._compo;
/* 143 */       MCEventProxy.PROXY.setOldValue(compo.getEventInfo(), compo.getRowValue());
/* 144 */       compo.handle(e);
/*     */     } else {
/*     */       
/* 147 */       this._compo.handle(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private File getImportFile(TransferHandler.TransferSupport support) {
/*     */     try {
/* 162 */       Transferable t = support.getTransferable();
/* 163 */       List<File> l = (List<File>)t.getTransferData(DataFlavor.javaFileListFlavor);
/*     */       
/* 165 */       if (l.isEmpty()) {
/* 166 */         return null;
/*     */       }
/*     */       
/* 169 */       if (l.size() > 1) {
/* 170 */         throw new MCException(Core_Msg_FW_A.FCBAC0427, new Object[0]);
/*     */       }
/*     */       
/* 173 */       return l.get(0);
/*     */     }
/* 175 */     catch (IOException|java.awt.datatransfer.UnsupportedFlavorException e) {
/* 176 */       throw new MCException(e);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\mcframe\clientCore\beans\mouse\MCTransferHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */