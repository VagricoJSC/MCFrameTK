/*    */ package META-INF.versions.21.mcframe.clientCore.beans.table;
/*    */ import mcframe.clientCore.beans.table.MCColumnConfig;
/*    */ 
/*    */ class MCEditorNumberField21 extends MCEditorNumberField {
/*    */   public MCEditorNumberField21(String name, MCColumnConfig column) {
/*  6 */     super(name, column);
/*    */   }
/*    */ 
/*    */   
/*    */   public void requestFocus(FocusEvent.Cause cause) {
/* 11 */     doFocus(false);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\table\MCEditorNumberField21.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */