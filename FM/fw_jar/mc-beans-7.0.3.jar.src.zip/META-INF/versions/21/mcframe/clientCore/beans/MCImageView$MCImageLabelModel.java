package META-INF.versions.21.mcframe.clientCore.beans;

import javax.swing.JToggleButton;
import mcframe.clientCore.beans.MCImageView;

public class MCImageLabelModel extends JToggleButton.ToggleButtonModel {
  public void setPressed(boolean b) {}
  
  public void setArmed(boolean b) {}
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\MCImageView$MCImageLabelModel.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */