/*    */ package META-INF.versions.21.mcframe.clientCore.beans.table;
/*    */ import java.awt.event.FocusEvent;
/*    */ import mcframe.clientCore.beans.table.MCFixedColumnTable;
/*    */ import mcframe.clientCore.beans.table.MCTable;
/*    */ 
/*    */ class MCFixedColumnTable21<E extends MCConstRow> extends MCFixedColumnTable<E> {
/*    */   public MCFixedColumnTable21(MCTable table, String name) {
/*  8 */     super(table, name);
/*    */   }
/*    */ 
/*    */   
/*    */   public void requestFocus(FocusEvent.Cause cause) {
/* 13 */     doFocus(false);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\table\MCFixedColumnTable21.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */