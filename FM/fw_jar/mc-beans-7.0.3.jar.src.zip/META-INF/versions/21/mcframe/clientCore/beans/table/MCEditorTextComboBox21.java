/*    */ package META-INF.versions.21.mcframe.clientCore.beans.table;
/*    */ import mcframe.clientCore.beans.table.MCEditorTextComboBox;
/*    */ 
/*    */ class MCEditorTextComboBox21 extends MCEditorTextComboBox {
/*    */   public MCEditorTextComboBox21(String name, MCColumnConfig column) {
/*  6 */     super(name, column);
/*    */   }
/*    */ 
/*    */   
/*    */   public void requestFocus(FocusEvent.Cause cause) {
/* 11 */     MCEditorTextComboBox.MCEditorComboField mCEditorComboField = getComboField();
/* 12 */     if (mCEditorComboField != null) {
/* 13 */       mCEditorComboField.requestFocus(cause);
/*    */     }
/* 15 */     super.requestFocus(cause);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\table\MCEditorTextComboBox21.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */