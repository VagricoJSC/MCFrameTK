/*      */ package META-INF.versions.21.mcframe.clientCore.beans;
/*      */ 
/*      */ import java.awt.AWTEvent;
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Font;
/*      */ import java.awt.Insets;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.FocusListener;
/*      */ import java.awt.event.MouseEvent;
/*      */ import javax.swing.ButtonModel;
/*      */ import javax.swing.InputVerifier;
/*      */ import javax.swing.JComponent;
/*      */ import javax.swing.JPopupMenu;
/*      */ import javax.swing.JRadioButton;
/*      */ import javax.swing.SwingUtilities;
/*      */ import javax.swing.border.Border;
/*      */ import mcframe.clientCore.acl.MCACLManager;
/*      */ import mcframe.clientCore.beans.MCBeans;
/*      */ import mcframe.clientCore.beans.MCBeansDelegate;
/*      */ import mcframe.clientCore.beans.MCBeansFocusListener;
/*      */ import mcframe.clientCore.beans.MCBeansUtil;
/*      */ import mcframe.clientCore.beans.MCButtonGroup;
/*      */ import mcframe.clientCore.beans.MCCacheType;
/*      */ import mcframe.clientCore.beans.MCEventProxy;
/*      */ import mcframe.clientCore.beans.MCLabelBeans;
/*      */ import mcframe.clientCore.beans.MCMode;
/*      */ import mcframe.clientCore.beans.MCModeBeans;
/*      */ import mcframe.clientCore.beans.MCModeInfo;
/*      */ import mcframe.clientCore.beans.MCPropertyCache;
/*      */ import mcframe.clientCore.beans.MCResourceBeans;
/*      */ import mcframe.clientCore.beans.MCRootPanel;
/*      */ import mcframe.clientCore.beans.MCTabOrderBeans;
/*      */ import mcframe.clientCore.beans.action.MCActionBeans;
/*      */ import mcframe.clientCore.beans.action.MCFunction;
/*      */ import mcframe.clientCore.beans.action.MCFunctionKey;
/*      */ import mcframe.clientCore.beans.action.MCKeyActionManager;
/*      */ import mcframe.clientCore.beans.layout.MCHiresoManager;
/*      */ import mcframe.clientCore.beans.text.MCInputVerifier;
/*      */ import mcframe.clientCore.event.MCEventBeans;
/*      */ import mcframe.clientCore.event.MCEventInfo;
/*      */ import mcframe.clientCore.event.MCEventList;
/*      */ import mcframe.clientCore.event.MCEventListener;
/*      */ import mcframe.clientCore.event.MCFunctionBeans;
/*      */ import mcframe.clientCore.event.MCNCBeans;
/*      */ import mcframe.clientCore.event.MCNCListener;
/*      */ import mcframe.clientCore.event.MCNEBeans;
/*      */ import mcframe.clientCore.event.MCNEListener;
/*      */ import mcframe.clientCore.event.MCNEReceiver;
/*      */ import mcframe.clientCore.event.MCNXBeans;
/*      */ import mcframe.clientCore.event.MCNXListener;
/*      */ import mcframe.clientCore.event.MCNXReceiver;
/*      */ import mcframe.clientCore.event.MCVCBeans;
/*      */ import mcframe.clientCore.event.MCVCListener;
/*      */ import mcframe.clientCore.resource.MCConst;
/*      */ import mcframe.commonCore.lang.MCStringUtil;
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MCRadioButton
/*      */   extends JRadioButton
/*      */   implements MCTabOrderBeans, MCModeBeans, MCVCBeans, MCNCBeans, MCNEBeans, MCNXBeans, MCNEReceiver, MCNXReceiver, MCLabelBeans, MCActionBeans, MCFunctionBeans
/*      */ {
/*   66 */   private static Border DEFAULT_BORDER = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   74 */   private MCBeansDelegate _delegate = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   82 */   private MCMode _mode = MCMode.NULL;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   90 */   private final MCEventList _event_list = new MCEventList();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   98 */   private MCRootPanel _panel = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  106 */   private MCRootPanel _init_panel = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  114 */   private String _message_name_resource = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  122 */   private String _message_name = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  130 */   private String _label_name = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  138 */   private Rectangle _default_ratio_bounds = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  146 */   private Font _default_font = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  154 */   private int _ratio = 100;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  162 */   private MCFunction _function = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  170 */   private String _function_text = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  178 */   private String _function_tooltip = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  186 */   private String _function_abbreviation = null;
/*      */ 
/*      */   
/*      */   private boolean _read_only_flg;
/*      */ 
/*      */   
/*      */   private Rectangle _default_bounds;
/*      */ 
/*      */   
/*      */   private String _label_name_program;
/*      */ 
/*      */   
/*      */   private MCBeansUtil.HTMLTextInfo _html_text_info;
/*      */ 
/*      */   
/*      */   private Font _font;
/*      */   
/*      */   private Font _multiline_font;
/*      */   
/*      */   protected boolean _isVisibleForMode;
/*      */   
/*      */   protected boolean _isVisibleForPersonalize;
/*      */ 
/*      */   
/*      */   protected String getFontKey() {
/*  211 */     return MCConst.createKey(new String[] { getType(), "font" });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getMultilineFontKey() {
/*  222 */     return MCConst.createKey(new String[] { getType(), "multiline_font" });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getTextMarginTopKey() {
/*  233 */     return MCConst.createKey(new String[] { getType(), "text_margin_top" });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getTextMarginBottomKey() {
/*  244 */     return MCConst.createKey(new String[] { getType(), "text_margin_bottom" });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void init() {
/*  254 */     initBeans();
/*  255 */     initResource();
/*  256 */     initKeyAssign();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initBeans() {
/*  266 */     setModel(new MCRadioButtonModel(this));
/*  267 */     setOpaque(false);
/*  268 */     enableInputMethods(false);
/*  269 */     addFocusListener((FocusListener)MCBeansFocusListener.getInstance());
/*  270 */     setHorizontalAlignment(4);
/*      */     
/*  272 */     if (DEFAULT_BORDER == null) {
/*  273 */       DEFAULT_BORDER = getBorder();
/*      */     }
/*  275 */     setInputVerifier((InputVerifier)new MCInputVerifier());
/*      */ 
/*      */     
/*  278 */     setComponentPopupMenu((JPopupMenu)new Object(this));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initKeyAssign() {
/*  298 */     MCKeyActionManager.init((MCResourceBeans)this, getInputMap(), getActionMap());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initResource() {
/*  309 */     Font f = MCConst.beans.getFont(getFontKey());
/*  310 */     if (f != null) {
/*  311 */       setFont(f);
/*      */     }
/*      */     
/*  314 */     Font mlf = MCConst.beans.getFont(getMultilineFontKey());
/*  315 */     if (mlf != null) {
/*  316 */       setMultilineFont(mlf);
/*      */     }
/*      */     
/*  319 */     getHTMLTextInfo().setMarginTop(MCConst.beans.getInteger(getTextMarginTopKey(), 
/*  320 */           getHTMLTextInfo().getMarginTop()));
/*      */     
/*  322 */     getHTMLTextInfo().setMarginBottom(MCConst.beans.getInteger(
/*  323 */           getTextMarginBottomKey(), getHTMLTextInfo().getMarginBottom()));
/*      */ 
/*      */     
/*  326 */     String m = MCBeansUtil.getLabelMsg(getName());
/*  327 */     if (m != null) {
/*  328 */       this._message_name_resource = m;
/*      */     }
/*      */ 
/*      */     
/*  332 */     String l = MCBeansUtil.getLabel(getName());
/*  333 */     if (l != null) {
/*  334 */       this._label_name = l;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setName(String name) {
/*  351 */     setName(name, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void setName(String name, boolean init) {
/*  366 */     MCBeansUtil.checkName(name);
/*  367 */     super.setName(name);
/*  368 */     if (init) {
/*  369 */       updateResource();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public String getType() {
/*  375 */     return "radio";
/*      */   }
/*      */ 
/*      */   
/*      */   public void localeChanged() {
/*  380 */     updateResource();
/*      */   }
/*      */   @Deprecated
/*  383 */   public MCRadioButton(String name) { this._read_only_flg = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  921 */     this._default_bounds = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1576 */     this._label_name_program = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1717 */     this._isVisibleForMode = true;
/* 1718 */     this._isVisibleForPersonalize = true; setName(name, false); init(); }
/*      */   private void setReadOnlyFlg(boolean flg) { this._read_only_flg = flg; setMode(this._mode); }
/*      */   private boolean getReadOnlyFlg() { return this._read_only_flg; }
/* 1721 */   public final void setMode(MCMode mode) { if (MCMode.isNull(mode)) return;  MCMode m = mode; if (getModeInfo(m).getStatus() == 1 && getReadOnlyFlg()) m = MCMode.READ_ONLY;  if (MCBeansUtil.setMode(this, m)) { if (this._mode != mode) this._mode = mode;  fgChanged(); }  } public MCMode getMode() { MCMode m = this._mode; MCModeInfo i = getModeInfo(m); if (i != null && i.getStatus() == 1 && getReadOnlyFlg()) m = MCMode.READ_ONLY;  return m; } public void addAllListener(MCEventListener listener) { addNCListener((MCNCListener)listener); addNEListener((MCNEListener)listener); addNXListener((MCNXListener)listener); addVCListener((MCVCListener)listener); } public void setAllListener(MCEventListener listener) { setNCListener((MCNCListener)listener); setNEListener((MCNEListener)listener); setNXListener((MCNXListener)listener); setVCListener((MCVCListener)listener); } public final void addVCListener(MCVCListener listener) { this._event_list.add(listener); } public final void setVCListener(MCVCListener listener) { this._event_list.set(listener); } public final void removeVCListener(MCVCListener listener) { this._event_list.remove(listener); } public final MCVCListener[] getVCListeners() { return this._event_list.vc(); } public boolean doVC() { MCEventProxy.PROXY.setComponent(getEventInfo(), (MCEventBeans)this); return MCBeansUtil.vc(this); } public final void addNCListener(MCNCListener listener) { this._event_list.add(listener); } public final void setNCListener(MCNCListener listener) { this._event_list.set(listener); } public final void removeNCListener(MCNCListener listener) { this._event_list.remove(listener); } public final MCNCListener[] getNCListeners() { return this._event_list.nc(); } public void doNC() { MCEventProxy.PROXY.setComponent(getEventInfo(), (MCEventBeans)this); MCBeansUtil.nc(this); } public final void addNEListener(MCNEListener listener) { this._event_list.add(listener); } public final void setNEListener(MCNEListener listener) { this._event_list.set(listener); } public final void removeNEListener(MCNEListener listener) { this._event_list.remove(listener); } public final MCNEListener[] getNEListeners() { return this._event_list.ne(); } public void doNE() { MCEventProxy.PROXY.setComponent(getEventInfo(), (MCEventBeans)this); MCBeansUtil.ne(this); } public void focusGained() { MCButtonGroup g = getGroup(); JComponent o = MCBeansUtil.getOldFocusOwner(this); if (!(o instanceof mcframe.clientCore.beans.MCRadioButton)) { g.doNE(); } else { mcframe.clientCore.beans.MCRadioButton c = (mcframe.clientCore.beans.MCRadioButton)o; MCButtonGroup og = c.getGroup(); if (g != og) g.doNE();  }  doNE(); } public final void addNXListener(MCNXListener listener) { this._event_list.add(listener); } public final void setNXListener(MCNXListener listener) { this._event_list.set(listener); } public final void removeNXListener(MCNXListener listener) { this._event_list.remove(listener); } public final MCNXListener[] getNXListeners() { return this._event_list.nx(); } public void doNX() { MCEventProxy.PROXY.setComponent(getEventInfo(), (MCEventBeans)this); MCBeansUtil.nx(this); } public void focusLost() { MCButtonGroup g = getGroup(); doNX(); JComponent o = MCBeansUtil.getFocusOwner(this); if (!(o instanceof mcframe.clientCore.beans.MCRadioButton)) { g.doNX(); } else { mcframe.clientCore.beans.MCRadioButton c = (mcframe.clientCore.beans.MCRadioButton)o; MCButtonGroup ng = c.getGroup(); if (ng != g) g.doNX();  }  } public MCEventInfo getEventInfo() { MCButtonGroup g = getGroup(); return (g != null) ? g.getEventInfo() : null; } public boolean isRequestFocusEnabled() { return (super.isRequestFocusEnabled() && isMCRequestFocusEnabled()); } protected boolean isMCRequestFocusEnabled() { return MCBeansUtil.isFocusable(this); } public final void mcRequestFocus() { MCBeansUtil.focus(this); } @Deprecated public final void grabFocus() { super.grabFocus(); } @Deprecated public final void requestFocus() { doFocus(false); } @Deprecated public final boolean requestFocus(boolean temporary) { return doFocus(temporary); } protected boolean doFocus(boolean temporary) { if (super.requestFocus(temporary)) { if (!temporary) afterRequestFocus();  return true; }  return false; } @Deprecated public final boolean requestFocusInWindow() { return super.requestFocusInWindow(); } @Deprecated protected final boolean requestFocusInWindow(boolean temporary) { return super.requestFocusInWindow(temporary); } public void afterRequestFocus() { MCRootPanel bp = getBaseRootPanel(); MCBeansUtil.afterRequestFocus(bp, this); MCBeansUtil.scrollRectToVisible(bp, this, getHorizontalAlignment()); } public String getMessageByLocale() { String m = this._message_name; if (m == null) m = this._message_name_resource;  return MCBeansUtil.getNameForMessage((MCBeans)this, m); } public String getLabelByLocale() { return this._label_name_program; } @Deprecated public final void setSelected(boolean selected) { super.setSelected(selected); } public final MCButtonGroup getGroup() { return getMCModel().getGroup(); } public MCRadioButtonModel getMCModel() { ButtonModel m = getModel(); return (m instanceof MCRadioButtonModel) ? (MCRadioButtonModel)m : null; } public final void setModel(MCRadioButtonModel model) { if (model != null) super.setModel((ButtonModel)model);  } @Deprecated public void setModel(ButtonModel model) { super.setModel(model); } public MCRootPanel getRootPanel() { if (this._init_panel != null) return this._init_panel;  return getNearestRootPanel(); } public MCRootPanel getBaseRootPanel() { MCRootPanel p = getNearestRootPanel(); return (p != null) ? p.getBaseRootPanel() : null; } public MCRootPanel getNearestRootPanel() { if (this._panel == null) this._panel = MCBeansUtil.getNearestRootPanel(this);  return this._panel; } protected void setBounds() { MCBeansUtil.setBounds((MCResourceBeans)this); } @Deprecated public void _cacheDefaultBounds(Rectangle bounds) { this._default_bounds = bounds; } @Deprecated public void _setDefaultBounds() { if (this._default_bounds != null) setBounds(this._default_bounds);  } public Rectangle _getDefaultBounds() { return this._default_bounds; } public void _setDefaultBounds(Rectangle r) { this._default_bounds = r; } public void added() { this._panel = MCBeansUtil.getNearestRootPanel(this); if (MCMode.isNull(getMode())) setMode(MCMode.ENABLE);  } public void removed() { this._panel = MCBeansUtil.getNearestRootPanel(this); } public void updateResource() { updateResource(getBaseRootPanel()); } public void updateResource(MCRootPanel panel) { if (panel != null) { if (!panel.isPartsFlag()) MCKeyActionManager.initScreen((MCResourceBeans)this, getInputMap(), getActionMap());  MCPropertyCache p = panel.getPropertyCache(MCCacheType.SCREEN); Font f = MCBeansUtil.getBeansFont(panel, p, getFontKey()); if (f != null) setFont(f);  Font mlf = MCBeansUtil.getBeansFont(panel, p, getMultilineFontKey()); if (mlf != null) setMultilineFont(mlf);  getHTMLTextInfo().setMarginTop(MCBeansUtil.getBeansInteger(panel, p, getTextMarginTopKey(), getHTMLTextInfo().getMarginTop())); getHTMLTextInfo().setMarginBottom(MCBeansUtil.getBeansInteger(panel, p, getTextMarginBottomKey(), getHTMLTextInfo().getMarginBottom())); setLabelText(); String m = MCBeansUtil.getMessageName((MCResourceBeans)this); if (m != null) this._message_name_resource = m;  setMCToolTipText((this._message_name != null) ? this._message_name : this._message_name_resource); setBounds(); }  } protected void setLabelText() { String l = MCBeansUtil.getLabel((MCBeans)this); if (l != null) this._label_name = l;  String t = this._label_name; if (t != null && !t.equals(getLabelByLocale())) setText(t);  } protected void processEvent(AWTEvent e) { try { super.processEvent(e); } catch (Throwable t) { handle(t); }  } @Deprecated public void handle(Throwable t) { MCBeansUtil.handle(this, t); } public boolean equalsIgnoreCase(Component compo) { return equals(compo); } public boolean isVisibleForPersonalize() { return this._isVisibleForPersonalize; }
/*      */   public final MCModeInfo getModeInfo() { return getModeInfo(getMode()); }
/*      */   public final MCModeInfo getModeInfo(MCMode mode) { return getDelegate().getModeInfo(this, mode); }
/*      */   public void initialized() { if (this._default_ratio_bounds == null) this._default_ratio_bounds = getBounds();  if (this._default_font == null) this._default_font = getFont();  this._init_panel = MCBeansUtil.getRootPanel(this); MCRootPanel bp = getBaseRootPanel(); if (bp != null) { MCButtonGroup g = getGroup(); boolean ro = false; if (g != null) { String itemid = MCBeansUtil.createGUIKey((MCModeBeans)g); ro = MCACLManager.isReadOnly(bp.getModuleID(), bp.getScreenID(), itemid); }  if (!ro) { String itemid = MCBeansUtil.createGUIKey(this); ro = MCACLManager.isReadOnly(bp.getModuleID(), bp.getScreenID(), itemid); }  setReadOnlyFlg(ro); }  }
/* 1725 */   public boolean doAction() { return false; } private MCBeansDelegate getDelegate() { if (this._delegate == null) this._delegate = new MCBeansDelegate();  return this._delegate; } public final void addAliasName(String alias, MCRootPanel panel) { getDelegate().addAliasName(alias, panel); } public final void setAliasName(String alias, MCRootPanel panel) { getDelegate().setAliasName(alias, panel); } public final void removeAliasName(MCRootPanel panel) { getDelegate().removeAliasName(panel); } public final void removeAliasNames() { getDelegate().removeAliasNames(); } public String getAliasName(MCRootPanel panel) { return getDelegate().getAliasName(panel); } public String[] getAliasNames() { return getDelegate().getAliasNames(); } public final void enableInputMethods(boolean enable) { super.enableInputMethods(false); } protected boolean isMCFocusOwner() { JComponent c = MCBeansUtil.getFocusOwner(this); return (c != null) ? ((c == this)) : isFocusOwner(); } public void updateBounds(int ratio) { MCBeansUtil.updateBounds(this, ratio, this._default_ratio_bounds); } public void updateFontSize(int ratio) { if (MCBeansUtil.isEnableMultilineFont(this._multiline_font, this._label_name_program)) { MCBeansUtil.updateFontSize(this, ratio, this._multiline_font); } else { MCBeansUtil.updateFontSize(this, ratio, this._default_font); }  this._ratio = ratio; String p = this._label_name_program; if (!MCStringUtil.isNull(p) && MCStringUtil.convertToLF(p).contains("\n")) { Color fg = (getModeInfo() != null) ? getModeInfo().getLabelForeground() : getForeground(); super.setText(MCBeansUtil.toHTMLText((MCBeans)this, p, fg, ratio, getHTMLTextInfo())); }  } public Border getDefaultBorder() { return DEFAULT_BORDER; } public final MCTabOrderBeans getNextBeans() { return getDelegate().getNextBeans(); } public final void setNextBeans(MCTabOrderBeans compo, int updateType) { getDelegate().setNextBeans(this, compo, updateType); } public final void setNextBeans(MCTabOrderBeans compo) { getDelegate().setNextBeans(this, compo, 0); } public final void insertNextBeans(MCTabOrderBeans compo, int updateType) { getDelegate().insertNextBeans(this, compo, updateType); } public final void insertNextBeans(MCTabOrderBeans compo) { getDelegate().insertNextBeans(this, compo, 0); } public final void insertPreviousBeans(MCTabOrderBeans compo, int updateType) { getDelegate().insertPreviousBeans(this, compo, updateType); } public final void insertPreviousBeans(MCTabOrderBeans compo) { getDelegate().insertPreviousBeans(this, compo, 0); } public final MCTabOrderBeans getPreviousBeans() { return getDelegate().getPreviousBeans(); } @Deprecated public final void setPreviousBeans(MCTabOrderBeans compo) { getDelegate().setPreviousBeans(this, compo); } @Deprecated public boolean isFocusableByKeybord() { return (isVisible() && isEnabled() && isFocusable()); } public MCMode getMode(MCRootPanel panel, String status) { return getDelegate().getMode(panel, status); } public String[] getStatuses(MCRootPanel panel) { return getDelegate().getStatuses(panel); } public void putMode(MCRootPanel panel, String status, MCMode mode) { getDelegate().putMode(panel, status, mode); } public void setMode(MCRootPanel panel, String status) { setMode(getMode(panel, status)); } protected void fireActionPerformed(ActionEvent event) { super.fireActionPerformed(event); SwingUtilities.invokeLater((Runnable)new Object(this)); } public int getIconTextGap() { int i = super.getIconTextGap(); i = i * getRatio() / 100; return i; } public int getRatio() { return this._ratio; } public Insets getInsets() { Insets i = super.getInsets(); int a = getRatio(); i.top = i.top * a / 100; i.bottom = i.bottom * a / 100; i.left = i.left * a / 100; i.right = i.right * a / 100; return i; } public final boolean isTabOrderEnabled() { return getDelegate().isTabOrderEnabled(); } @Deprecated public final void setTabOrderEnabled(boolean enabled) { getDelegate().setTabOrderEnabled(enabled); } public Dimension getDefaultSize() { Rectangle a = this._default_ratio_bounds; int w = (a != null) ? a.width : getWidth(); int h = (a != null) ? a.height : getHeight(); return new Dimension(w, h); } public Rectangle getDefaultBounds() { Rectangle a = this._default_ratio_bounds; return (a != null) ? a : bounds(); } public void setDefaultRatioSize(Rectangle r) { this._default_ratio_bounds = r; } @Deprecated public JComponent getTargetComponent() { return this; } public void setMessageName(String name) { this._message_name = MCBeansUtil.adjustMessageName(name); setMCToolTipText((this._message_name != null) ? this._message_name : this._message_name_resource); } @Deprecated public String _getMessageName() { return this._message_name; } public void action(MCFunction function) { if (!isRequestFocusEnabled()) return;  requestFocus(); doClick(); } public MCFunction getFunction() { return this._function; } public MCFunctionKey getFunctionKey() { return (this._function != null) ? this._function.getKey() : null; } public void setFunction(MCFunction function) { this._function = function; this._function_text = null; this._function_tooltip = null; this._function_abbreviation = null; String m = (this._message_name != null) ? this._message_name : this._message_name_resource; if (m != null) setMCToolTipText(m);  MCRootPanel p = getRootPanel(); if (p != null) p.setFunction(this);  } public void setFunctionKey(MCFunctionKey key) { MCFunction f = (key != null) ? new MCFunction(key, this, 2) : null; setFunction(f); } protected String getFunctionKeyText() { if (this._function_text == null) { MCFunctionKey fk = getFunctionKey(); if (fk != null) { String kt = fk.getKeyText().toLowerCase(); String key = MCConst.createKey(new String[] { "function.text", kt }); if (MCConst.beans.containsKey(key)) this._function_text = MCConst.beans.getString(key);  }  }  return this._function_text; } protected String getFunctionKeyTooltipText() { if (this._function_tooltip == null) { MCFunctionKey fk = getFunctionKey(); if (fk != null) { String kt = fk.getKeyText().toLowerCase(); String key = MCConst.createKey(new String[] { "function.tooltip", kt }); if (MCConst.beans.containsKey(key)) this._function_tooltip = MCConst.beans.getString(key);  }  }  return this._function_tooltip; } public String getFunctionKeyAbbreviation() { return (this._function_abbreviation != null) ? this._function_abbreviation : (this._function_abbreviation = MCBeansUtil.getFunctionKeyAbbreviation(this)); } protected void setMCToolTipText(String text) { String s = text; if (s == null) s = "";  String function = getFunctionKeyTooltipText(); if (function != null) s = s + s;  if (s.length() == 0) s = null;  setToolTipText(s); } public String getToolTipText(MouseEvent event) { String tip = getToolTipText(); tip = MCHiresoManager.getToolTipText(this, tip); return tip; } public void setFocusable(boolean focusable) { super.setFocusable(focusable); MCBeansUtil.setFocusableAfter(this, focusable); } public void setText(String text) { if (MCStringUtil.isNull(text) || !MCStringUtil.convertToLF(text).contains("\n")) { this._label_name_program = text; super.setText(text); } else { this._label_name_program = text; Color fg = (getModeInfo() != null) ? getModeInfo().getLabelForeground() : getForeground(); super.setText(MCBeansUtil.toHTMLText((MCBeans)this, text, fg, getHTMLTextInfo())); }  adjustFont(); } @Deprecated public String getText() { return super.getText(); } public Font getDefaultFont() { return this._default_font; } public void setForeground(Color color) { super.setForeground(color); fgChanged(); } private void fgChanged() { String p = this._label_name_program; if (!MCStringUtil.isNull(p) && MCStringUtil.convertToLF(p).contains("\n")) { Color fg = (getModeInfo() != null) ? getModeInfo().getLabelForeground() : getForeground(); super.setText(MCBeansUtil.toHTMLText((MCBeans)this, this._label_name_program, fg, getHTMLTextInfo())); }  } private MCBeansUtil.HTMLTextInfo getHTMLTextInfo() { return (this._html_text_info != null) ? this._html_text_info : (this._html_text_info = new MCBeansUtil.HTMLTextInfo()); } public void setFont(Font font) { if (MCBeansUtil.isEnableMultilineFont(this._multiline_font, this._label_name_program)) { super.setFont(this._multiline_font); } else { super.setFont(font); }  this._font = font; } public void setMultilineFont(Font font) { this._multiline_font = font; } private void adjustFont() { Font f = this._font; if (MCBeansUtil.isEnableMultilineFont(this._multiline_font, this._label_name_program)) f = this._multiline_font;  if (f != null) { MCRootPanel p = getBaseRootPanel(); if (p != null) { MCBeansUtil.updateFontSize(this, p.getFontRatio(), f); } else { _setFont(f); }  }  } void _setFont(Font font) { super.setFont(font); } public boolean isVisibleForMode() { return this._isVisibleForMode; }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setVisibleForLayout(boolean b) {
/* 1730 */     super.setVisible(b);
/*      */   }
/*      */   
/*      */   public void setVisibleForPersonalize(boolean b) {
/* 1734 */     this._isVisibleForPersonalize = b;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setVisible(boolean flag) {
/* 1739 */     this._isVisibleForMode = flag;
/* 1740 */     if (!this._isVisibleForPersonalize) {
/* 1741 */       super.setVisible(false);
/*      */     } else {
/*      */       
/* 1744 */       super.setVisible(flag);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isAnytimeFAction() {
/* 1750 */     return false;
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\MCRadioButton.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */