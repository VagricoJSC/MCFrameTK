/*   */ package META-INF.versions.21.mcframe.clientCore.beans;
/*   */ import java.awt.Dimension;
/*   */ import mcframe.clientCore.beans.MCButton21;
/*   */ 
/*   */ class null extends MCButton21 {
/*   */   null(String $anonymous0) {
/* 7 */     super($anonymous0);
/*   */   }
/*   */   
/*   */   public void setPreferredSize(Dimension preferredSize) {}
/*   */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\MCBeansCompatibilityUtil$1.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */