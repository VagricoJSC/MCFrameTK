/*      */ package META-INF.versions.21.mcframe.clientCore.beans.listview;
/*      */ 
/*      */ import java.awt.AWTEvent;
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.Container;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Font;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.event.KeyListener;
/*      */ import java.awt.event.MouseListener;
/*      */ import java.awt.event.MouseMotionListener;
/*      */ import javax.swing.JComponent;
/*      */ import javax.swing.JList;
/*      */ import javax.swing.JPopupMenu;
/*      */ import javax.swing.ListCellRenderer;
/*      */ import javax.swing.ListModel;
/*      */ import javax.swing.event.ListSelectionListener;
/*      */ import mcframe.clientCore.beans.MCBeans;
/*      */ import mcframe.clientCore.beans.MCBeansDelegate;
/*      */ import mcframe.clientCore.beans.MCBeansUtil;
/*      */ import mcframe.clientCore.beans.MCMode;
/*      */ import mcframe.clientCore.beans.MCModeBeans;
/*      */ import mcframe.clientCore.beans.MCModeInfo;
/*      */ import mcframe.clientCore.beans.MCResourceBeans;
/*      */ import mcframe.clientCore.beans.MCRootPanel;
/*      */ import mcframe.clientCore.beans.MCScrollPane;
/*      */ import mcframe.clientCore.beans.MCTabOrderBeans;
/*      */ import mcframe.clientCore.beans.action.MCKeyActionManager;
/*      */ import mcframe.clientCore.beans.listview.MCBeansProxy;
/*      */ import mcframe.clientCore.beans.listview.MCEventProxy;
/*      */ import mcframe.clientCore.beans.listview.MCListViewCellRenderer;
/*      */ import mcframe.clientCore.beans.popup.MCPopupBeans;
/*      */ import mcframe.clientCore.beans.popup.MCPopupConfig;
/*      */ import mcframe.clientCore.beans.popup.MCPopupMenu;
/*      */ import mcframe.clientCore.container.MCConstRow;
/*      */ import mcframe.clientCore.event.MCDCBeans;
/*      */ import mcframe.clientCore.event.MCDCListener;
/*      */ import mcframe.clientCore.event.MCEventBeans;
/*      */ import mcframe.clientCore.event.MCEventInfo;
/*      */ import mcframe.clientCore.event.MCEventList;
/*      */ import mcframe.clientCore.event.MCEventListener;
/*      */ import mcframe.clientCore.event.MCNCBeans;
/*      */ import mcframe.clientCore.event.MCNCListener;
/*      */ import mcframe.clientCore.resource.MCConst;
/*      */ import mcframe.commonCore.container.MCList;
/*      */ import mcframe.commonCore.container.MCRowMatcher;
/*      */ import mcframe.commonCore.lang.MCStringUtil;
/*      */ import mcframe.commonCore.notice.Core_Msg;
/*      */ import mcframe.commonCore.notice.MCException;
/*      */ import mcframe.commonCore.resource.ctrl.MCResource;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MCListView<P extends MCConstRow>
/*      */   extends JList<P>
/*      */   implements MCNCBeans, MCDCBeans, MCTabOrderBeans, MCModeBeans, MCPopupBeans
/*      */ {
/*   86 */   private MCRowMatcher<P> _filter = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   93 */   private String _check_col = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _slide_action = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int _drag_action;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  113 */   private P _drag = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  119 */   private int _dragstart = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  125 */   private int _dragsize = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  139 */   private Font _default_font = null;
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String TYPE = "listview";
/*      */ 
/*      */ 
/*      */   
/*      */   private String _message_name_resource;
/*      */ 
/*      */ 
/*      */   
/*      */   private String _message_name;
/*      */ 
/*      */ 
/*      */   
/*      */   private MCRootPanel _panel;
/*      */ 
/*      */ 
/*      */   
/*      */   private MCRootPanel _init_panel;
/*      */ 
/*      */ 
/*      */   
/*      */   private MCMode _mode;
/*      */ 
/*      */ 
/*      */   
/*      */   private MCPopupConfig _popup_config;
/*      */ 
/*      */   
/*      */   private MCBeansDelegate _beans_delegate;
/*      */ 
/*      */   
/*      */   private final MCEventList _event_list;
/*      */ 
/*      */   
/*      */   private MCEventInfo _event_info;
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setName(String name) {
/*  181 */     MCBeansUtil.checkName(name);
/*  182 */     super.setName(name);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setModel(ListModel<P> model) {
/*  187 */     if (!(model instanceof MCListViewModel))
/*      */     {
/*  189 */       throw new MCException(Core_Msg.FCBAC0451, new Object[] { getName() });
/*      */     }
/*  191 */     super.setModel(model);
/*  192 */     ((MCListViewModel)getModel()).setMatcher(this._filter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setList(MCList<P> list) {
/*  203 */     setModel((ListModel<P>)new MCListViewModel(this, list));
/*      */   }
/*      */ 
/*      */   
/*      */   public void setCellRenderer(ListCellRenderer<? super P> cellRenderer) {
/*  208 */     if (cellRenderer instanceof MCListViewCellRenderer) {
/*      */       
/*  210 */       MCListViewCellRenderer<? super P> mccr = 
/*  211 */         (MCListViewCellRenderer<? super P>)cellRenderer;
/*  212 */       mccr.setCheckColumn(this._check_col);
/*      */     } 
/*  214 */     ListCellRenderer<? super P> old = getCellRenderer();
/*  215 */     if (old instanceof MCListViewCellRenderer) {
/*      */       
/*  217 */       MCListViewCellRenderer<? super P> mccr = 
/*  218 */         (MCListViewCellRenderer<? super P>)old;
/*  219 */       mccr.setCheckColumn(null);
/*      */     } 
/*      */     
/*  222 */     super.setCellRenderer(cellRenderer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCheckColumn(String col) {
/*  236 */     this._check_col = col;
/*      */     
/*  238 */     ListCellRenderer<? super P> cr = getCellRenderer();
/*  239 */     if (cr instanceof MCListViewCellRenderer) {
/*      */       
/*  241 */       MCListViewCellRenderer<? super P> mccr = 
/*  242 */         (MCListViewCellRenderer<? super P>)cr;
/*  243 */       mccr.setCheckColumn(this._check_col);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCheckColumn() {
/*  255 */     return this._check_col;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFilter(MCRowMatcher<P> filter) {
/*  268 */     this._filter = filter;
/*  269 */     ((MCListViewModel)getModel()).setMatcher(this._filter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setEnableSlide(boolean enable) {
/*  280 */     this._slide_action = enable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isEnableSlide() {
/*  291 */     return this._slide_action;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public P getSlideRow() {
/*  302 */     return this._drag;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getSlideSize() {
/*  313 */     return this._dragsize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void filter(boolean on) {
/*  324 */     int index = getSelectedIndex();
/*  325 */     getListViewModel().filter(on);
/*  326 */     int size = getListViewModel().getSize();
/*  327 */     if (size > 0 && size - 1 < index) {
/*  328 */       setSelectedIndex(0);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void changeCheckedValue(P row) {
/*  341 */     ListCellRenderer<? super P> cr = 
/*  342 */       getCellRenderer();
/*  343 */     if (cr instanceof MCListViewCellRenderer) {
/*  344 */       MCListViewCellRenderer<? super P> renderer = 
/*  345 */         (MCListViewCellRenderer<? super P>)cr;
/*  346 */       if (renderer.isCheckEnabled()) {
/*  347 */         String check = renderer.getCheckColumn();
/*  348 */         row.setBoolean(check, !row.getBoolean(check));
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setDefaultListener() {
/*  361 */     MouseMotionListener[] motions = getMouseMotionListeners(); byte b; int i; MouseMotionListener[] arrayOfMouseMotionListener1;
/*  362 */     for (i = (arrayOfMouseMotionListener1 = motions).length, b = 0; b < i; ) { MouseMotionListener motion = arrayOfMouseMotionListener1[b];
/*  363 */       removeMouseMotionListener(motion);
/*      */       b++; }
/*      */     
/*  366 */     Object object = new Object(this);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  462 */     addMouseListener((MouseListener)object);
/*  463 */     addMouseMotionListener((MouseMotionListener)object);
/*      */ 
/*      */     
/*  466 */     addListSelectionListener((ListSelectionListener)new Object(this));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  474 */     addKeyListener((KeyListener)new Object(this));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void processEvent(AWTEvent e) {
/*      */     try {
/*  497 */       super.processEvent(e);
/*      */     }
/*  499 */     catch (Throwable t) {
/*  500 */       handle(t);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void layoutComponent(Component comp) {
/*  514 */     comp.doLayout();
/*  515 */     if (comp instanceof Container) {
/*  516 */       Container cont = (Container)comp; byte b; int i; Component[] arrayOfComponent;
/*  517 */       for (i = (arrayOfComponent = cont.getComponents()).length, b = 0; b < i; ) { Component child = arrayOfComponent[b];
/*  518 */         layoutComponent(child);
/*      */         b++; }
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isRequestFocusEnabled() {
/*  552 */     return (super.isRequestFocusEnabled() && isMCRequestFocusEnabled());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isMCRequestFocusEnabled() {
/*  571 */     return MCBeansUtil.isFocusable(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void mcRequestFocus() {
/*  588 */     MCBeansUtil.focus(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void grabFocus() {
/*  601 */     super.grabFocus();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void requestFocus() {
/*  614 */     doFocus(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public boolean requestFocus(boolean temporary) {
/*  629 */     return doFocus(temporary);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean doFocus(boolean temporary) {
/*  658 */     if (super.requestFocus(temporary)) {
/*  659 */       if (!temporary) {
/*  660 */         afterRequestFocus();
/*      */       }
/*  662 */       return true;
/*      */     } 
/*  664 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public boolean requestFocusInWindow() {
/*  678 */     return super.requestFocusInWindow();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected boolean requestFocusInWindow(boolean temporary) {
/*  693 */     return super.requestFocusInWindow(temporary);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MCListViewModel getListViewModel() {
/*  706 */     return (MCListViewModel)getModel();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getType() {
/*      */     return "listview";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getMessageByLocale() {
/*      */     String m = this._message_name;
/*      */     if (m == null) {
/*      */       m = this._message_name_resource;
/*      */     }
/*      */     return MCBeansProxy.PROXY.getNameForMessage((MCBeans)this, m);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getLabelByLocale() {
/*      */     return MCBeansUtil.getLabel((MCBeans)this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCRootPanel getRootPanel() {
/*      */     if (this._init_panel != null) {
/*      */       return this._init_panel;
/*      */     }
/*      */     return getNearestRootPanel();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCRootPanel getBaseRootPanel() {
/*      */     MCRootPanel p = getNearestRootPanel();
/*      */     return (p != null) ? p.getBaseRootPanel() : null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCRootPanel getNearestRootPanel() {
/*      */     if (this._panel == null) {
/*      */       this._panel = MCBeansUtil.getNearestRootPanel(this);
/*      */     }
/*      */     return this._panel;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void localeChanged() {
/*      */     updateResource();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void added() {
/*      */     this._panel = MCBeansUtil.getNearestRootPanel(this);
/*      */     if (MCMode.isNull(getMode())) {
/*      */       setMode(MCMode.ENABLE);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removed() {
/*      */     this._panel = MCBeansUtil.getNearestRootPanel(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equalsIgnoreCase(Component compo) {
/*      */     return equals(compo);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void initialized() {
/*      */     if (this._default_font == null) {
/*      */       this._default_font = getFont();
/*      */     }
/*      */     this._init_panel = MCBeansUtil.getRootPanel(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MCBeansDelegate getDelegate() {
/*      */     if (this._beans_delegate == null) {
/*      */       this._beans_delegate = new MCBeansDelegate();
/*      */     }
/*      */     return this._beans_delegate;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addAliasName(String alias, MCRootPanel panel) {
/*      */     getDelegate().addAliasName(alias, panel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAliasName(String alias, MCRootPanel panel) {
/*      */     getDelegate().setAliasName(alias, panel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeAliasName(MCRootPanel panel) {
/*      */     getDelegate().removeAliasName(panel);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeAliasNames() {
/*      */     getDelegate().removeAliasNames();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public MCListView(String name) {
/*  891 */     this._message_name_resource = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  898 */     this._message_name = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  905 */     this._panel = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  912 */     this._init_panel = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  919 */     this._mode = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  934 */     this._popup_config = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  941 */     this._beans_delegate = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1450 */     this._event_list = new MCEventList();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1458 */     this._event_info = null; setName(name); setDefaultListener(); setList(null); setComponentPopupMenu(new MCPopupMenu(this)); setSelectionMode(0); this._drag_action = MCConst.app.getInteger("FS.FSBGP0120.list.item.slide.amount", 50);
/*      */   } public String getAliasName(MCRootPanel panel) { return getDelegate().getAliasName(panel); } public String[] getAliasNames() { return getDelegate().getAliasNames(); } @Deprecated public void updateBounds(int ratio) { int h = 0; ListCellRenderer<? super P> cr = getCellRenderer(); ListModel<P> model = getModel(); int size = model.getSize(); for (int i = 0; i < size; i++) { MCConstRow mCConstRow = (MCConstRow)model.getElementAt(i); Component c = cr.getListCellRendererComponent(this, (P)mCConstRow, i, true, true); layoutComponent(c); h += (c.getSize()).height; }  Rectangle r = getBounds(); r.height = h; setBounds(r); } public void updateFontSize(int ratio) { MCBeansProxy.PROXY.updateFontSize(this, ratio, this._default_font); } public Dimension getDefaultSize() { return getSize(); } public void afterRequestFocus() { MCRootPanel bp = getBaseRootPanel(); MCBeansUtil.afterRequestFocus(bp, this); MCBeansUtil.scrollRectToVisible(bp, this); } @Deprecated public void handle(Throwable t) { MCBeansUtil.handle(this, t); } public void setMessageName(String name) { this._message_name = MCBeansProxy.PROXY.adjustMessageName(name); } @Deprecated public String _getMessageName() { return this._message_name; } public void setNextBeans(MCTabOrderBeans compo) { getDelegate().setNextBeans(this, compo, 1); } public MCTabOrderBeans getNextBeans() { return getDelegate().getNextBeans(); } @Deprecated public boolean isFocusableByKeybord() { return (isVisible() && isEnabled() && isFocusable()); }
/*      */   public void insertNextBeans(MCTabOrderBeans compo) { getDelegate().insertNextBeans(this, compo, 1); }
/*      */   public void insertPreviousBeans(MCTabOrderBeans compo) { getDelegate().insertPreviousBeans(this, compo, 1); }
/*      */   @Deprecated public void setPreviousBeans(MCTabOrderBeans compo) { getDelegate().setPreviousBeans(this, compo); }
/* 1463 */   public MCEventInfo getEventInfo() { if (this._event_info == null) {
/* 1464 */       this._event_info = new MCEventInfo();
/* 1465 */       MCEventProxy.PROXY.setComponent(this._event_info, (MCEventBeans)this);
/*      */     } 
/* 1467 */     return this._event_info; }
/*      */   public MCTabOrderBeans getPreviousBeans() { return getDelegate().getPreviousBeans(); }
/*      */   public void setNextBeans(MCTabOrderBeans compo, int updateType) {
/*      */     getDelegate().setNextBeans(this, compo, updateType);
/*      */   } public void insertNextBeans(MCTabOrderBeans compo, int updateType) {
/*      */     getDelegate().insertNextBeans(this, compo, updateType);
/*      */   } public void insertPreviousBeans(MCTabOrderBeans compo, int updateType) {
/*      */     getDelegate().insertPreviousBeans(this, compo, updateType);
/*      */   } @Deprecated
/*      */   public void setTabOrderEnabled(boolean enabled) {
/*      */     getDelegate().setTabOrderEnabled(enabled);
/*      */   } public boolean isTabOrderEnabled() {
/*      */     return getDelegate().isTabOrderEnabled();
/*      */   } @Deprecated
/*      */   public JComponent getTargetComponent() {
/*      */     return this;
/*      */   } public void updateResource() {
/*      */     updateResource(getBaseRootPanel());
/* 1485 */   } public final void addAllListener(MCEventListener listener) { addNCListener((MCNCListener)listener);
/*      */ 
/*      */ 
/*      */     
/* 1489 */     addDCListener((MCDCListener)listener); }
/*      */   public void updateResource(MCRootPanel panel) { if (!panel.isPartsFlag()) { MCKeyActionManager.initScreen((MCResourceBeans)this, getInputMap(1), getActionMap()); MCKeyActionManager.initScreen((MCResourceBeans)this, getInputMap(), getActionMap()); }  setFont(); this._panel.updateResource(panel); String m = MCBeansUtil.getMessageName((MCResourceBeans)this); if (m != null) this._message_name_resource = m;  }
/*      */   protected void setFont() { String key = MCBeansProxy.PROXY.getBeansKey((MCResourceBeans)this, MCResource.createKey(new String[] { getType(), "font" })); if (!MCStringUtil.isNull(key)) { Font temp = getFont(); Font font = MCConst.beans.getFont(key, temp); if (temp != font) setFont(font);  }  }
/*      */   @Deprecated public void _setDefaultBounds() {}
/*      */   @Deprecated public void _cacheDefaultBounds(Rectangle bounds) {}
/*      */   public Rectangle getDefaultBounds() { return null; }
/*      */   public void setMode(MCMode mode) { if (!MCMode.isNull(mode)) { MCRootPanel bp = getBaseRootPanel(); MCBeansUtil.log(bp, (MCBeans)this, Core_Msg.FCBAC0013, new Object[] { mode.getName() }); this._mode = mode; MCModeInfo mi = getModeInfo(); int s = mi.getStatus(); MCScrollPane sp = getScrollPane(); switch (s) { case 1: setVisible(true); setEnabled(true); setFocusable(true); sp.setVisible(true); break;case 2: setVisible(true); setEnabled(true); setFocusable(false); sp.setVisible(true); break;case 3: setVisible(false); sp.setVisible(false); break; }  setForeground(mi.getForeground()); Color bg = mi.getBackground(); sp.setMCBackground(bg); setBackground(bg); MCBeansUtil.log(bp, (MCBeans)this, Core_Msg.FCBAC0014, new Object[] { mode.getName() }); }  }
/*      */   public MCScrollPane getScrollPane() { return MCBeansUtil.getScrollPane(this); }
/*      */   public MCMode getMode() { return this._mode; }
/*      */   public MCModeInfo getModeInfo() { return getModeInfo(getMode()); }
/*      */   public MCModeInfo getModeInfo(MCMode mode) { return getDelegate().getModeInfo(this, mode); }
/*      */   public void putMode(MCRootPanel panel, String status, MCMode mode) { getDelegate().putMode(panel, status, mode); }
/*      */   public void setMode(MCRootPanel panel, String status) { setMode(getMode(panel, status)); }
/*      */   public MCMode getMode(MCRootPanel panel, String status) { return getDelegate().getMode(panel, status); }
/*      */   public String[] getStatuses(MCRootPanel panel) { return getDelegate().getStatuses(panel); }
/*      */   public MCPopupMenu configurePopup() { MCPopupMenu m = configurePopup(getComponentPopupMenu()); if (m != null) m.sort();  return m; }
/*      */   protected MCPopupMenu configurePopup(MCPopupMenu menu) { MCPopupConfig pc = getPopupConfig(); return (pc != null) ? pc.configurePopup(menu, this) : menu; }
/*      */   public void popupMenuWillBecomeVisible() {}
/* 1507 */   public void popupMenuWillBecomeInvisible() {} public void setPopupConfig(MCPopupConfig config) { this._popup_config = config; } public MCPopupConfig getPopupConfig() { return this._popup_config; } public void setComponentPopupMenu(MCPopupMenu popup) { super.setComponentPopupMenu((JPopupMenu)popup); } @Deprecated public final void setComponentPopupMenu(JPopupMenu popup) { super.setComponentPopupMenu(popup); } public final MCPopupMenu getComponentPopupMenu() { return (MCPopupMenu)super.getComponentPopupMenu(); } public void removeComponentPopupMenu() { setComponentPopupMenu(null); } public final void setAllListener(MCEventListener listener) { setNCListener((MCNCListener)listener);
/*      */ 
/*      */ 
/*      */     
/* 1511 */     setDCListener((MCDCListener)listener); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addNCListener(MCNCListener listener) {
/* 1519 */     this._event_list.add(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setNCListener(MCNCListener listener) {
/* 1524 */     this._event_list.set(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeNCListener(MCNCListener listener) {
/* 1529 */     this._event_list.remove(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public MCNCListener[] getNCListeners() {
/* 1534 */     return this._event_list.nc();
/*      */   }
/*      */ 
/*      */   
/*      */   public void doNC() {
/* 1539 */     MCBeansUtil.nc(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addDCListener(MCDCListener listener) {
/* 1546 */     this._event_list.add(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setDCListener(MCDCListener listener) {
/* 1551 */     this._event_list.set(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeDCListener(MCDCListener listener) {
/* 1556 */     this._event_list.remove(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public MCDCListener[] getDCListeners() {
/* 1561 */     return this._event_list.dc();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void doDC() {
/* 1568 */     MCBeansUtil.dc(this);
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\listview\MCListView.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */