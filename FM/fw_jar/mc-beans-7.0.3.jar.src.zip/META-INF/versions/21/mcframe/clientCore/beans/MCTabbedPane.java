/*      */ package META-INF.versions.21.mcframe.clientCore.beans;
/*      */ 
/*      */ import java.awt.AWTEvent;
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.Container;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Font;
/*      */ import java.awt.Insets;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.event.ContainerEvent;
/*      */ import java.awt.event.ContainerListener;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import javax.swing.Icon;
/*      */ import javax.swing.ImageIcon;
/*      */ import javax.swing.JComponent;
/*      */ import javax.swing.JTabbedPane;
/*      */ import javax.swing.SingleSelectionModel;
/*      */ import mcframe.clientCore.beans.MCBeans;
/*      */ import mcframe.clientCore.beans.MCBeansDelegate;
/*      */ import mcframe.clientCore.beans.MCBeansReader;
/*      */ import mcframe.clientCore.beans.MCBeansUtil;
/*      */ import mcframe.clientCore.beans.MCBeansWriter;
/*      */ import mcframe.clientCore.beans.MCBlockBeans;
/*      */ import mcframe.clientCore.beans.MCCacheType;
/*      */ import mcframe.clientCore.beans.MCEventProxy;
/*      */ import mcframe.clientCore.beans.MCFileIOBeans;
/*      */ import mcframe.clientCore.beans.MCFrame;
/*      */ import mcframe.clientCore.beans.MCListBeans;
/*      */ import mcframe.clientCore.beans.MCMode;
/*      */ import mcframe.clientCore.beans.MCModeBeans;
/*      */ import mcframe.clientCore.beans.MCModeInfo;
/*      */ import mcframe.clientCore.beans.MCPlafMetalProxy;
/*      */ import mcframe.clientCore.beans.MCPropertyCache;
/*      */ import mcframe.clientCore.beans.MCResourceBeans;
/*      */ import mcframe.clientCore.beans.MCRootPanel;
/*      */ import mcframe.clientCore.beans.MCScrollPane;
/*      */ import mcframe.clientCore.beans.MCTabOrderBasis;
/*      */ import mcframe.clientCore.beans.MCTabOrderBeans;
/*      */ import mcframe.clientCore.beans.action.MCActionBeans;
/*      */ import mcframe.clientCore.beans.action.MCKeyActionManager;
/*      */ import mcframe.clientCore.beans.mouse.MCScrollSupport;
/*      */ import mcframe.clientCore.beans.plaf.metal.MCMetalTabbedPaneUI;
/*      */ import mcframe.clientCore.event.MCEventBeans;
/*      */ import mcframe.clientCore.event.MCEventInfo;
/*      */ import mcframe.clientCore.event.MCEventList;
/*      */ import mcframe.clientCore.event.MCEventListener;
/*      */ import mcframe.clientCore.event.MCNCBeans;
/*      */ import mcframe.clientCore.event.MCNCListener;
/*      */ import mcframe.clientCore.event.MCNEBeans;
/*      */ import mcframe.clientCore.event.MCNEListener;
/*      */ import mcframe.clientCore.event.MCNEReceiver;
/*      */ import mcframe.clientCore.event.MCNXBeans;
/*      */ import mcframe.clientCore.event.MCNXListener;
/*      */ import mcframe.clientCore.event.MCNXReceiver;
/*      */ import mcframe.clientCore.event.MCVCBeans;
/*      */ import mcframe.clientCore.event.MCVCListener;
/*      */ import mcframe.clientCore.resource.MCConst;
/*      */ import mcframe.clientCore.resource.MCIconSupplier;
/*      */ import mcframe.commonCore.lang.MCStringUtil;
/*      */ import mcframe.commonCore.notice.Core_Msg;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MCTabbedPane
/*      */   extends JTabbedPane
/*      */   implements MCModeBeans, MCNCBeans, MCVCBeans, MCBlockBeans, MCNEBeans, MCNXBeans, ContainerListener, MCResourceBeans, MCFileIOBeans, MCActionBeans, MCTabOrderBasis, MCNEReceiver, MCNXReceiver
/*      */ {
/*      */   private boolean _value_check = true;
/*   75 */   private MCMode _mode = MCMode.NULL;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   83 */   private MCBeansDelegate _delegate = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   91 */   private final MCEventList _event_list = new MCEventList();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   99 */   private MCEventInfo _event_info = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  107 */   private MCBeansWriter _beans_writer = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  115 */   private MCBeansReader _beans_reader = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  123 */   private MCRootPanel _panel = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  131 */   private MCRootPanel _init_panel = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  139 */   private Rectangle _default_ratio_bounds = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  147 */   private Font _default_font = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  155 */   private Map<String, String> _message_names = new HashMap<>();
/*      */ 
/*      */ 
/*      */   
/*      */   private Map<Integer, Icon> _defSizeIcons;
/*      */ 
/*      */ 
/*      */   
/*      */   private Rectangle _default_bounds;
/*      */ 
/*      */ 
/*      */   
/*      */   private MCScrollSupport _sp;
/*      */ 
/*      */ 
/*      */   
/*      */   private ArrayList<ImageIcon> _iconList1;
/*      */ 
/*      */ 
/*      */   
/*      */   private ArrayList<ImageIcon> _iconList2;
/*      */ 
/*      */ 
/*      */   
/*      */   private ArrayList<String> _iconSizeList;
/*      */ 
/*      */ 
/*      */   
/*      */   protected Dimension _scrollButtonSize;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getFontKey() {
/*  189 */     return MCConst.createKey(new String[] { getType(), "font" });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setName(String name) {
/*  205 */     setName(name, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void setName(String name, boolean init) {
/*  221 */     MCBeansUtil.checkName(name);
/*  222 */     super.setName(name);
/*  223 */     if (init) {
/*  224 */       updateResource();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String getName() {
/*  238 */     return super.getName();
/*      */   }
/*      */ 
/*      */   
/*      */   public String getType() {
/*  243 */     return "tabbedpane";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void init() {
/*  264 */     initBeans();
/*  265 */     initResource();
/*  266 */     initKeyAssign();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initBeans() {
/*  276 */     this._defSizeIcons = new HashMap<>();
/*  277 */     setModel((SingleSelectionModel)new MCTabbedPaneModel(this));
/*  278 */     setFocusable(true);
/*  279 */     addContainerListener(this);
/*      */     
/*  281 */     enableEvents(16L);
/*      */ 
/*      */     
/*  284 */     setInheritsPopupMenu(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initKeyAssign() {
/*  294 */     MCKeyActionManager.init(this, getInputMap(), getActionMap());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initResource() {
/*  305 */     Font f = MCConst.beans.getFont(getFontKey());
/*  306 */     if (f != null) {
/*  307 */       setFont(f);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void localeChanged() {
/*  320 */     updateResource();
/*  321 */     MCBeansUtil.localeChanged(this);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setMode(MCMode mode) {
/*  326 */     MCRootPanel bp = getBaseRootPanel();
/*  327 */     if (!MCMode.isNull(mode)) {
/*  328 */       MCBeansUtil.log(bp, (MCBeans)this, Core_Msg.FCBAC0013, new Object[] { mode.getName() });
/*  329 */       this._mode = mode;
/*  330 */       MCModeInfo mi = getModeInfo();
/*  331 */       int s = mi.getStatus();
/*  332 */       switch (s) {
/*      */         case 1:
/*  334 */           setVisible(true);
/*  335 */           setEnabled(true);
/*  336 */           setFocusable(true);
/*      */           break;
/*      */         case 2:
/*  339 */           setVisible(true);
/*  340 */           setEnabled(false);
/*  341 */           setFocusable(false);
/*      */           break;
/*      */         case 3:
/*  344 */           setVisible(false);
/*      */           break;
/*      */       } 
/*      */ 
/*      */       
/*  349 */       Color c = mi.getForeground();
/*  350 */       if (c != null) {
/*  351 */         setForeground(c);
/*      */       }
/*  353 */       c = mi.getBackground();
/*  354 */       if (c != null) {
/*  355 */         setBackground(c);
/*      */       }
/*  357 */       MCBeansUtil.log(bp, (MCBeans)this, Core_Msg.FCBAC0014, new Object[] { mode.getName() });
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public MCMode getMode() {
/*  363 */     return this._mode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void addAllListener(MCEventListener listener) {
/*  388 */     addNCListener((MCNCListener)listener);
/*  389 */     addNEListener((MCNEListener)listener);
/*  390 */     addNXListener((MCNXListener)listener);
/*  391 */     addVCListener((MCVCListener)listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setAllListener(MCEventListener listener) {
/*  416 */     setNCListener((MCNCListener)listener);
/*  417 */     setNEListener((MCNEListener)listener);
/*  418 */     setNXListener((MCNXListener)listener);
/*  419 */     setVCListener((MCVCListener)listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void addVCListener(MCVCListener listener) {
/*  424 */     this._event_list.add(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setVCListener(MCVCListener listener) {
/*  429 */     this._event_list.set(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void removeVCListener(MCVCListener listener) {
/*  434 */     this._event_list.remove(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public final MCVCListener[] getVCListeners() {
/*  439 */     return this._event_list.vc();
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean doVC() {
/*  444 */     return MCBeansUtil.vc(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean canChange() {
/*  471 */     return doVC();
/*      */   }
/*      */ 
/*      */   
/*      */   public final void addNCListener(MCNCListener listener) {
/*  476 */     this._event_list.add(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNCListener(MCNCListener listener) {
/*  481 */     this._event_list.set(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void removeNCListener(MCNCListener listener) {
/*  486 */     this._event_list.remove(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public final MCNCListener[] getNCListeners() {
/*  491 */     return this._event_list.nc();
/*      */   }
/*      */ 
/*      */   
/*      */   public void doNC() {
/*  496 */     MCBeansUtil.nc(this);
/*      */   }
/*      */   
/*      */   public void commitValue() {
/*  500 */     doNC();
/*      */   }
/*      */ 
/*      */   
/*      */   public final void addNEListener(MCNEListener listener) {
/*  505 */     this._event_list.add(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNEListener(MCNEListener listener) {
/*  510 */     this._event_list.set(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void removeNEListener(MCNEListener listener) {
/*  515 */     this._event_list.remove(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public final MCNEListener[] getNEListeners() {
/*  520 */     return this._event_list.ne();
/*      */   }
/*      */ 
/*      */   
/*      */   public void doNE() {
/*  525 */     MCBeansUtil.ne(this);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void addNXListener(MCNXListener listener) {
/*  530 */     this._event_list.add(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNXListener(MCNXListener listener) {
/*  535 */     this._event_list.set(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void removeNXListener(MCNXListener listener) {
/*  540 */     this._event_list.remove(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public final MCNXListener[] getNXListeners() {
/*  545 */     return this._event_list.nx();
/*      */   }
/*      */ 
/*      */   
/*      */   public void doNX() {
/*  550 */     MCBeansUtil.nx(this);
/*      */   }
/*      */ 
/*      */   
/*      */   public MCEventInfo getEventInfo() {
/*  555 */     if (this._event_info == null) {
/*  556 */       this._event_info = new MCEventInfo();
/*  557 */       MCEventProxy.PROXY.setComponent(this._event_info, (MCEventBeans)this);
/*      */     } 
/*  559 */     return this._event_info;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isRequestFocusEnabled() {
/*  590 */     return (super.isRequestFocusEnabled() && isMCRequestFocusEnabled());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isMCRequestFocusEnabled() {
/*  610 */     return MCBeansUtil.isFocusable(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void mcRequestFocus() {
/*  620 */     MCBeansUtil.focus(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final void grabFocus() {
/*  629 */     super.grabFocus();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final void requestFocus() {
/*  638 */     doFocus(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final boolean requestFocus(boolean t) {
/*  647 */     return doFocus(t);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean doFocus(boolean temporary) {
/*  659 */     if (super.requestFocus(temporary)) {
/*  660 */       if (!temporary) {
/*  661 */         afterRequestFocus();
/*      */       }
/*  663 */       return true;
/*      */     } 
/*  665 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final boolean requestFocusInWindow() {
/*  674 */     return super.requestFocusInWindow();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected final boolean requestFocusInWindow(boolean temporary) {
/*  683 */     return super.requestFocusInWindow(temporary);
/*      */   }
/*      */ 
/*      */   
/*      */   public void afterRequestFocus() {
/*  688 */     MCRootPanel bp = getBaseRootPanel();
/*  689 */     MCBeansUtil.afterRequestFocus(bp, this);
/*  690 */     MCBeansUtil.scrollRectToVisible(bp, this, 2);
/*      */   }
/*      */ 
/*      */   
/*      */   public MCRootPanel getRootPanel() {
/*  695 */     if (this._init_panel != null) {
/*  696 */       return this._init_panel;
/*      */     }
/*  698 */     return getNearestRootPanel();
/*      */   }
/*      */ 
/*      */   
/*      */   public MCRootPanel getBaseRootPanel() {
/*  703 */     MCRootPanel p = getNearestRootPanel();
/*  704 */     return (p != null) ? p.getBaseRootPanel() : null;
/*      */   }
/*      */ 
/*      */   
/*      */   public MCRootPanel getNearestRootPanel() {
/*  709 */     if (this._panel == null) {
/*  710 */       this._panel = MCBeansUtil.getNearestRootPanel(this);
/*      */     }
/*  712 */     return this._panel;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getMessageByLocale() {
/*  717 */     int idx = getSelectedIndex();
/*  718 */     int count = getTabCount();
/*  719 */     if (idx > -1 && idx < count) {
/*  720 */       Component c = getComponentAt(idx);
/*  721 */       String n = c.getName();
/*  722 */       if (this._message_names.containsKey(n)) {
/*  723 */         return this._message_names.get(n);
/*      */       }
/*      */     } 
/*  726 */     return getMessageAt(getSelectedIndex());
/*      */   }
/*      */ 
/*      */   
/*      */   public String getLabelByLocale() {
/*  731 */     int index = getSelectedIndex();
/*  732 */     return (index < 0) ? MCBeansUtil.getLabel((MCBeans)this) : getTitleAt(index);
/*      */   }
/*      */ 
/*      */   
/*      */   public void setValueCheck(boolean check) {
/*  737 */     this._value_check = check;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isValueCheck() {
/*  742 */     return this._value_check;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isChanged() {
/*  747 */     return isChanged(true);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isChanged(boolean check) {
/*  752 */     return (check && !isValueCheck()) ? false : MCBeansUtil.isChanged(this, check);
/*      */   }
/*      */ 
/*      */   
/*      */   public void componentAdded(ContainerEvent e) {
/*  757 */     if (e != null) {
/*  758 */       Component compo = e.getChild();
/*  759 */       MCBeansUtil.added(this, compo);
/*  760 */       if (compo instanceof MCBeans) {
/*  761 */         ((MCBeans)compo).added();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void componentRemoved(ContainerEvent e) {
/*  768 */     if (e != null) {
/*  769 */       Component compo = e.getChild();
/*  770 */       MCBeansUtil.removed(this, compo);
/*  771 */       if (compo instanceof MCBeans) {
/*  772 */         ((MCBeans)compo).removed();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void insertTab(String title, Icon icon, Component component, String tip, int index) {
/*  780 */     super.insertTab(title, icon, component, tip, index);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setBounds() {
/*  790 */     MCBeansUtil.setBounds(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public MCTabbedPane(String name) {
/*  799 */     this._default_bounds = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1519 */     this._iconList1 = null;
/* 1520 */     this._iconList2 = null;
/* 1521 */     this._iconSizeList = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1597 */     this._scrollButtonSize = new Dimension(16, 16);
/*      */     setName(name, false);
/*      */     init();
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateScrollButton(int ratio) {
/* 1604 */     Component[] clist = getComponents(); byte b; int i; Component[] arrayOfComponent1;
/* 1605 */     for (i = (arrayOfComponent1 = clist).length, b = 0; b < i; ) { Component c = arrayOfComponent1[b];
/* 1606 */       if (c instanceof javax.swing.plaf.basic.BasicArrowButton) {
/* 1607 */         c.setSize(new Dimension(this._scrollButtonSize.width * ratio / 100, this._scrollButtonSize.height * ratio / 100));
/* 1608 */         c.setPreferredSize(
/* 1609 */             new Dimension(this._scrollButtonSize.width * ratio / 100, this._scrollButtonSize.height * ratio / 100));
/*      */       } 
/*      */       b++; }
/*      */   
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public void _cacheDefaultBounds(Rectangle bounds) {
/*      */     this._default_bounds = bounds;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public void _setDefaultBounds() {
/*      */     if (this._default_bounds != null)
/*      */       setBounds(this._default_bounds); 
/*      */   }
/*      */   
/*      */   public Rectangle _getDefaultBounds() {
/*      */     return this._default_bounds;
/*      */   }
/*      */   
/*      */   public void _setDefaultBounds(Rectangle r) {
/*      */     this._default_bounds = r;
/*      */   }
/*      */   
/*      */   protected void processEvent(AWTEvent e) {
/*      */     try {
/*      */       super.processEvent(e);
/*      */     } catch (Throwable t) {
/*      */       handle(t);
/*      */     } 
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public void handle(Throwable t) {
/*      */     MCBeansUtil.handle(this, t);
/*      */   }
/*      */   
/*      */   public void added() {
/*      */     this._panel = MCBeansUtil.getNearestRootPanel(this);
/*      */     if (MCMode.isNull(this._mode))
/*      */       setMode(MCMode.ENABLE); 
/*      */     MCBeansUtil.added(this);
/*      */     this._sp = null;
/*      */     MCScrollPane sp = MCBeansUtil.getScrollPane(this);
/*      */     if (sp != null) {
/*      */       this._sp = sp.getScrollSupport();
/*      */       this._sp.addTo(this);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void removed() {
/*      */     this._panel = MCBeansUtil.getNearestRootPanel(this);
/*      */     MCBeansUtil.removed(this);
/*      */     if (this._sp != null) {
/*      */       this._sp.removeFrom(this);
/*      */       this._sp = null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void updateResource() {
/*      */     updateResource(getBaseRootPanel());
/*      */   }
/*      */   
/*      */   public void updateResource(MCRootPanel panel) {
/*      */     if (panel != null) {
/*      */       if (!panel.isPartsFlag())
/*      */         MCKeyActionManager.initScreen(this, getInputMap(), getActionMap()); 
/*      */       MCPropertyCache cache = panel.getPropertyCache(MCCacheType.SCREEN);
/*      */       Font font = MCBeansUtil.getBeansFont(panel, cache, getFontKey());
/*      */       if (font != null)
/*      */         setFont(font); 
/*      */       setBounds();
/*      */       for (int i = 0; i < getTabCount(); i++) {
/*      */         String k = getTitleAt(i);
/*      */         String v = MCBeansUtil.getLabel((MCBeans)this, k);
/*      */         if (v != null)
/*      */           setTitleAt(i, v); 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   protected String getMessageAt(int index) {
/*      */     return MCBeansUtil.getMessageName(this, getTitleAt(index));
/*      */   }
/*      */   
/*      */   public final void setBeansWriter(MCBeansWriter writer) {
/*      */     this._beans_writer = writer;
/*      */   }
/*      */   
/*      */   public MCBeansWriter getBeansWriter() {
/*      */     return this._beans_writer;
/*      */   }
/*      */   
/*      */   public final void setBeansReader(MCBeansReader reader) {
/*      */     this._beans_reader = reader;
/*      */   }
/*      */   
/*      */   public MCBeansReader getBeansReader() {
/*      */     return this._beans_reader;
/*      */   }
/*      */   
/*      */   public boolean equalsIgnoreCase(Component compo) {
/*      */     return equals(compo);
/*      */   }
/*      */   
/*      */   public final MCModeInfo getModeInfo() {
/*      */     return getModeInfo(getMode());
/*      */   }
/*      */   
/*      */   public final MCModeInfo getModeInfo(MCMode mode) {
/*      */     return getDelegate().getModeInfo(this, mode);
/*      */   }
/*      */   
/*      */   public void initialized() {
/*      */     if (this._default_ratio_bounds == null)
/*      */       this._default_ratio_bounds = getBounds(); 
/*      */     if (this._default_font == null)
/*      */       this._default_font = getFont(); 
/*      */     this._init_panel = MCBeansUtil.getRootPanel(this);
/*      */     MCBeansUtil.initialized(this);
/*      */   }
/*      */   
/*      */   public boolean doAction() {
/*      */     return false;
/*      */   }
/*      */   
/*      */   private MCBeansDelegate getDelegate() {
/*      */     if (this._delegate == null)
/*      */       this._delegate = new MCBeansDelegate(); 
/*      */     return this._delegate;
/*      */   }
/*      */   
/*      */   public final void addAliasName(String alias, MCRootPanel panel) {
/*      */     getDelegate().addAliasName(alias, panel);
/*      */   }
/*      */   
/*      */   public final void setAliasName(String alias, MCRootPanel panel) {
/*      */     getDelegate().setAliasName(alias, panel);
/*      */   }
/*      */   
/*      */   public final void removeAliasName(MCRootPanel panel) {
/*      */     getDelegate().removeAliasName(panel);
/*      */   }
/*      */   
/*      */   public final void removeAliasNames() {
/*      */     getDelegate().removeAliasNames();
/*      */   }
/*      */   
/*      */   public final String getAliasName(MCRootPanel panel) {
/*      */     return getDelegate().getAliasName(panel);
/*      */   }
/*      */   
/*      */   public final String[] getAliasNames() {
/*      */     return getDelegate().getAliasNames();
/*      */   }
/*      */   
/*      */   public void setMCIconAt(int index, Icon icon) {
/*      */     super.setIconAt(index, icon);
/*      */     this._defSizeIcons.put(Integer.valueOf(index), icon);
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public void setIconAt(int index, Icon icon) {
/*      */     super.setIconAt(index, icon);
/*      */   }
/*      */   
/*      */   public void updateBounds(int ratio) {
/*      */     MCBeansUtil.updateBounds(this, ratio, this._default_ratio_bounds);
/*      */     adjustImageIcon(ratio);
/*      */     MCBeansUtil.adjustTabbedPane(getRootPanel(), this, ratio);
/*      */   }
/*      */   
/*      */   private void adjustImageIcon(int ratio) {
/*      */     for (Map.Entry<Integer, Icon> m : this._defSizeIcons.entrySet()) {
/*      */       Icon i = m.getValue();
/*      */       if (i != null && i instanceof ImageIcon) {
/*      */         ImageIcon c = (ImageIcon)i;
/*      */         if (ratio != 100) {
/*      */           int h = c.getIconHeight() * ratio / 100;
/*      */           int w = c.getIconWidth() * ratio / 100;
/*      */           c = MCBeansUtil.adjustIconSize(c, new Dimension(w, h));
/*      */         } 
/*      */         super.setIconAt(((Integer)m.getKey()).intValue(), c);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public void updateFontSize(int ratio) {
/*      */     MCBeansUtil.updateFontSize(this, ratio, this._default_font);
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public boolean isFocusableByKeybord() {
/*      */     return (isVisible() && isEnabled() && isFocusable());
/*      */   }
/*      */   
/*      */   public final void createTabOrderList(MCRootPanel bp, MCTabOrderBeans compo) {
/*      */     getDelegate().createTabOrderList(bp, compo);
/*      */   }
/*      */   
/*      */   public final boolean _createTabOrderList(MCRootPanel bp, int depth) {
/*      */     return getDelegate()._createTabOrderList(bp, depth);
/*      */   }
/*      */   
/*      */   public final List<MCTabOrderBeans> getTabOrderBeans() {
/*      */     return getDelegate().getTabOrderBeans();
/*      */   }
/*      */   
/*      */   public final List<MCTabOrderBeans> getTabOrderContainer() {
/*      */     return getDelegate().getTabOrderContainer();
/*      */   }
/*      */   
/*      */   public final List<MCTabOrderBeans> getTabOrderBeans(boolean init) {
/*      */     return getDelegate().getTabOrderBeans(init);
/*      */   }
/*      */   
/*      */   public final void setFirstBeans(MCTabOrderBeans compo) {
/*      */     getDelegate().setFirstBeans(this, compo, 0);
/*      */   }
/*      */   
/*      */   public final void setFirstBeans(MCTabOrderBeans compo, int updateType) {
/*      */     getDelegate().setFirstBeans(this, compo, updateType);
/*      */   }
/*      */   
/*      */   public final MCTabOrderBeans getFirstBeans() {
/*      */     return getDelegate().getFirstBeans();
/*      */   }
/*      */   
/*      */   public MCTabOrderBeans getLastBeans(int updateType) {
/*      */     return getDelegate().getLastBeans(this, updateType);
/*      */   }
/*      */   
/*      */   public MCTabOrderBeans getLastBeans() {
/*      */     return getDelegate().getLastBeans(this, 0);
/*      */   }
/*      */   
/*      */   public void setLastBeans(MCTabOrderBeans compo, int updateType) {
/*      */     getDelegate().setLastBeans(this, compo, updateType);
/*      */   }
/*      */   
/*      */   public void setLastBeans(MCTabOrderBeans compo) {
/*      */     getDelegate().setLastBeans(this, compo, 0);
/*      */   }
/*      */   
/*      */   public final MCTabOrderBeans getNextBeans() {
/*      */     return getDelegate().getNextBeans();
/*      */   }
/*      */   
/*      */   public final void setNextBeans(MCTabOrderBeans compo, int updateType) {
/*      */     getDelegate().setNextBeans((MCTabOrderBeans)this, compo, updateType);
/*      */   }
/*      */   
/*      */   public final void setNextBeans(MCTabOrderBeans compo) {
/*      */     getDelegate().setNextBeans((MCTabOrderBeans)this, compo, 0);
/*      */   }
/*      */   
/*      */   public final void insertNextBeans(MCTabOrderBeans compo, int updateType) {
/*      */     getDelegate().insertNextBeans((MCTabOrderBeans)this, compo, updateType);
/*      */   }
/*      */   
/*      */   public final void insertNextBeans(MCTabOrderBeans compo) {
/*      */     getDelegate().insertNextBeans((MCTabOrderBeans)this, compo, 0);
/*      */   }
/*      */   
/*      */   public final void insertPreviousBeans(MCTabOrderBeans compo, int updateType) {
/*      */     getDelegate().insertPreviousBeans((MCTabOrderBeans)this, compo, updateType);
/*      */   }
/*      */   
/*      */   public final void insertPreviousBeans(MCTabOrderBeans compo) {
/*      */     getDelegate().insertPreviousBeans((MCTabOrderBeans)this, compo, 0);
/*      */   }
/*      */   
/*      */   public final MCTabOrderBeans getPreviousBeans() {
/*      */     return getDelegate().getPreviousBeans();
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public final void setPreviousBeans(MCTabOrderBeans compo) {
/*      */     getDelegate().setPreviousBeans((MCTabOrderBeans)this, compo);
/*      */   }
/*      */   
/*      */   public MCMode getMode(MCRootPanel panel, String status) {
/*      */     return getDelegate().getMode(panel, status);
/*      */   }
/*      */   
/*      */   public String[] getStatuses(MCRootPanel panel) {
/*      */     return getDelegate().getStatuses(panel);
/*      */   }
/*      */   
/*      */   public void putMode(MCRootPanel panel, String status, MCMode mode) {
/*      */     getDelegate().putMode(panel, status, mode);
/*      */   }
/*      */   
/*      */   public void setMode(MCRootPanel panel, String status) {
/*      */     setMode(getMode(panel, status));
/*      */   }
/*      */   
/*      */   public void focusGained() {
/*      */     doNE();
/*      */   }
/*      */   
/*      */   public void focusLost() {
/*      */     doNX();
/*      */   }
/*      */   
/*      */   public final boolean isTabOrderEnabled() {
/*      */     return getDelegate().isTabOrderEnabled();
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public final void setTabOrderEnabled(boolean enabled) {
/*      */     getDelegate().setTabOrderEnabled(enabled);
/*      */   }
/*      */   
/*      */   public Dimension getDefaultSize() {
/*      */     Rectangle a = this._default_ratio_bounds;
/*      */     int w = (a != null) ? a.width : getWidth();
/*      */     int h = (a != null) ? a.height : getHeight();
/*      */     return new Dimension(w, h);
/*      */   }
/*      */   
/*      */   public Rectangle getDefaultBounds() {
/*      */     Rectangle a = this._default_ratio_bounds;
/*      */     return (a != null) ? a : bounds();
/*      */   }
/*      */   
/*      */   public void setDefaultRatioSize(Rectangle r) {
/*      */     this._default_ratio_bounds = r;
/*      */   }
/*      */   
/*      */   public boolean focusActiveFirstComponent() {
/*      */     Component c = getSelectedComponent();
/*      */     if (c instanceof Container) {
/*      */       MCRootPanel p = getBaseRootPanel();
/*      */       if (p == null)
/*      */         return false; 
/*      */       Component f = p.getFocusTraversalPolicy().getFirstComponent((Container)c);
/*      */       if (f instanceof mcframe.clientCore.beans.MCTabbedPane)
/*      */         return ((mcframe.clientCore.beans.MCTabbedPane)f).focusActiveFirstComponent(); 
/*      */       if (f instanceof MCListBeans)
/*      */         ((MCListBeans)f).setCellFocusPattern(1000); 
/*      */       return MCBeansUtil.focus((JComponent)f);
/*      */     } 
/*      */     return false;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public JComponent getTargetComponent() {
/*      */     return this;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public void setMessageName(String name) {}
/*      */   
/*      */   public void setMessageName(String panel, String name) {
/*      */     if (MCStringUtil.isNull(panel))
/*      */       return; 
/*      */     int count = getTabCount();
/*      */     for (int i = 0; i < count; i++) {
/*      */       Component c = getComponentAt(i);
/*      */       if (MCStringUtil.eq(panel, c.getName())) {
/*      */         this._message_names.put(panel, MCBeansUtil.adjustMessageName(name));
/*      */         return;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public String _getMessageName() {
/*      */     return null;
/*      */   }
/*      */   
/*      */   public String _getMessageName(String panel) {
/*      */     if (this._message_names.containsKey(panel))
/*      */       return this._message_names.get(panel); 
/*      */     return null;
/*      */   }
/*      */   
/*      */   public void convFrameWidthIfLeftOrRightTab() {
/*      */     if (getTabPlacement() == 2 || getTabPlacement() == 4) {
/*      */       int w = MCPlafMetalProxy.PROXY.calculateMaxTabWidth(this, getTabPlacement());
/*      */       MCFrame f = getBaseRootPanel().getFrame();
/*      */       if (f != null) {
/*      */         Rectangle r = f.getBounds();
/*      */         r.width += w;
/*      */         f.setBounds(r);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public void setFocusable(boolean focusable) {
/*      */     super.setFocusable(focusable);
/*      */     MCBeansUtil.setFocusableAfter((MCTabOrderBeans)this, focusable);
/*      */   }
/*      */   
/*      */   public void setPreferredSize(Dimension preferredSize) {
/*      */     super.setPreferredSize(preferredSize);
/*      */   }
/*      */   
/*      */   public void setSize(Dimension size) {
/*      */     super.setSize(size);
/*      */   }
/*      */   
/*      */   public void resize(int width, int height) {
/*      */     if (width != getWidth() || height != getHeight())
/*      */       super.resize(width, height); 
/*      */   }
/*      */   
/*      */   public void setLocation(int x, int y) {
/*      */     super.setLocation(x, y);
/*      */   }
/*      */   
/*      */   public void setBounds(int x, int y, int width, int height) {
/*      */     super.setBounds(x, y, width, height);
/*      */   }
/*      */   
/*      */   public Insets getDefaultContentBorderInsets() {
/*      */     return ((MCMetalTabbedPaneUI)this.ui).getDefaultContentBorderInsets(0);
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public ImageIcon _adjustIconSize(ImageIcon icon, Dimension size, MCIconSupplier s) {
/*      */     String _sizeKey = "" + size.width + "," + size.width;
/*      */     if (this._iconList1 == null)
/*      */       this._iconList1 = new ArrayList<>(); 
/*      */     if (this._iconList2 == null)
/*      */       this._iconList2 = new ArrayList<>(); 
/*      */     if (this._iconSizeList == null)
/*      */       this._iconSizeList = new ArrayList<>(); 
/*      */     int idx = -1;
/*      */     for (int n = 0; n < this._iconList1.size(); n++) {
/*      */       if (this._iconList1.get(n) == icon) {
/*      */         idx = n;
/*      */         break;
/*      */       } 
/*      */     } 
/*      */     if (idx >= 0) {
/*      */       String _size = this._iconSizeList.get(idx);
/*      */       if (_size.equals(_sizeKey)) {
/*      */         ImageIcon _icon = this._iconList2.get(idx);
/*      */         if (_icon != null)
/*      */           return _icon; 
/*      */       } 
/*      */     } 
/*      */     if (icon != null && size != null) {
/*      */       int width = size.width;
/*      */       int height = size.height;
/*      */       if (width > 0 && height > 0) {
/*      */         ImageIcon result = null;
/*      */         if (s == null) {
/*      */           result = new ImageIcon(icon.getImage());
/*      */         } else {
/*      */           result = s.createIcon(icon.getImage());
/*      */         } 
/*      */         result.setImage(result.getImage().getScaledInstance(width, height, 4));
/*      */         if (idx == -1) {
/*      */           this._iconList1.add(icon);
/*      */           this._iconList2.add(result);
/*      */           this._iconSizeList.add(_sizeKey);
/*      */         } else {
/*      */           this._iconList2.set(idx, result);
/*      */           this._iconSizeList.set(idx, _sizeKey);
/*      */         } 
/*      */         return result;
/*      */       } 
/*      */     } 
/*      */     return icon;
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\MCTabbedPane.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */