/*     */ package META-INF.versions.21.mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.event.KeyEvent;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.text.Document;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCMode;
/*     */ import mcframe.clientCore.beans.MCResourceBeans;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.action.MCKeyActionManager;
/*     */ import mcframe.clientCore.beans.combobox.MCComboField;
/*     */ import mcframe.clientCore.beans.combobox.MCComboListModel;
/*     */ import mcframe.clientCore.beans.combobox.MCFieldComboBox;
/*     */ import mcframe.clientCore.beans.combobox.MCNumberComboBox;
/*     */ import mcframe.clientCore.beans.list.MCLinkBeans;
/*     */ import mcframe.clientCore.beans.list.MCLinkedBeans;
/*     */ import mcframe.clientCore.beans.list.MCListConfig;
/*     */ import mcframe.clientCore.beans.list.MCListType;
/*     */ import mcframe.clientCore.beans.popup.MCPopupConfig;
/*     */ import mcframe.clientCore.beans.popup.MCPopupMenu;
/*     */ import mcframe.clientCore.beans.table.MCBeansProxy;
/*     */ import mcframe.clientCore.beans.table.MCCellUtil;
/*     */ import mcframe.clientCore.beans.table.MCColumnConfig;
/*     */ import mcframe.clientCore.beans.table.MCEditorBeans;
/*     */ import mcframe.clientCore.beans.table.MCEventProxy;
/*     */ import mcframe.clientCore.beans.table.MCTable;
/*     */ import mcframe.clientCore.beans.table.MCTableColumn;
/*     */ import mcframe.clientCore.beans.text.MCNumberDocument;
/*     */ import mcframe.clientCore.beans.text.MCNumberFormat;
/*     */ import mcframe.clientCore.event.MCEventInfo;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCEditorNumberComboBox
/*     */   extends MCNumberComboBox
/*     */   implements MCEditorBeans
/*     */ {
/*  46 */   private MCTable<?> _table = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   private MCColumnConfig _column = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected MCEditorNumberComboBox(String name, MCColumnConfig column) {
/*  67 */     super(name);
/*     */     
/*  69 */     setColumnConfig(column);
/*  70 */     setTable(column.getBaseTable());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getType() {
/*  75 */     return "table.column.combo-number";
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initBeans() {
/*  80 */     super.initBeans();
/*     */     
/*  82 */     setFocusTraversalKeysEnabled(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initKeyAssign() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initResource() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setTable(MCTable<?> table) {
/* 101 */     this._table = table;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCTable<?> getTable() {
/* 106 */     return this._table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setColumnConfig(MCColumnConfig column) {
/* 117 */     this._column = column;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCColumnConfig getColumnConfig() {
/* 122 */     return this._column;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getRowIndex() {
/* 127 */     return MCCellUtil.getRowIndex(this);
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCEditorComboField getComboField() {
/* 132 */     return (MCEditorComboField)super.getComboField();
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCEditorComboField createComboField() {
/* 137 */     return new MCEditorComboField(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void valueCommited() {
/* 142 */     MCTable<?> t = getTable();
/* 143 */     String o = getListConfig().getOpeType();
/*     */     
/* 145 */     MCNumber v = getValue();
/* 146 */     if ("input".equals(o)) {
/* 147 */       setSelectedItem((Comparable)v);
/*     */     }
/* 149 */     else if ("list".equals(o) && 
/* 150 */       v == null) {
/* 151 */       setSelectedItem((Comparable)v);
/*     */     } 
/*     */ 
/*     */     
/* 155 */     MCRow row = getSelectedListRow();
/*     */     
/* 157 */     if ("input".equals(o)) {
/* 158 */       row = getListRow((Comparable)getValue());
/*     */     }
/* 160 */     if (row == null && 
/* 161 */       getListType() == MCListType.FREE) {
/* 162 */       row = MCRow.create();
/* 163 */       MCBeansProxy.PROXY.addColumn(row, getListNames()[0], getDataType(), 
/* 164 */           getViewValue());
/*     */     } 
/*     */     
/* 167 */     MCEventInfo e = getEventInfo();
/* 168 */     String key = getKeyColumnName();
/* 169 */     if (MCBeansProxy.PROXY.haveLinkValuesNull(e, (MCLinkBeans)this, (Comparable)getValue(), getList(), key)) {
/* 170 */       MCRow r = row.clone();
/* 171 */       r.clear();
/* 172 */       r.setValue(key, e.getNewValue());
/* 173 */       ((MCTableColumn)getColumnConfig()).execLink(t.getMCEditingRow(), r, true);
/*     */     } else {
/*     */       
/* 176 */       ((MCTableColumn)getColumnConfig()).execLink(t.getMCEditingRow(), row, true);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Border getDefaultBorder() {
/* 182 */     return MCCellUtil.DEFAULT_BORDER;
/*     */   }
/*     */ 
/*     */   
/*     */   public void transferFocus() {
/* 187 */     MCTable<?> t = getTable();
/* 188 */     t.transferFocus(getRowIndex(), t.getViewColumn(getColumnConfig()) + 1, false, 
/* 189 */         true, true);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void execLink(MCRow row, boolean msg) {
/* 194 */     ((MCTableColumn)getColumnConfig()).execLink(getRowIndex(), row, msg);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canChange() {
/*     */     try {
/* 200 */       MCTable.setEditingStoppedEnabled(false);
/*     */ 
/*     */       
/* 203 */       MCEventInfo info = getTable().getEventInfo();
/* 204 */       MCEventProxy.PROXY.setIndex(info, getTable().getMCSelectedRow(), 
/* 205 */           info.getNewIndex());
/*     */       
/* 207 */       return super.canChange();
/*     */     } finally {
/*     */       
/* 210 */       MCTable.setEditingStoppedEnabled(true);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void setColumnInfo(int index, MCColumnConfig column) {
/* 215 */     setColumnConfig(column);
/* 216 */     MCTable<?> table = getTable();
/*     */     
/* 218 */     MCKeyActionManager.init((MCResourceBeans)this, getInputMap(1), 
/* 219 */         getActionMap());
/* 220 */     JComponent c = getComboField().getComponent();
/* 221 */     MCKeyActionManager.init((MCResourceBeans)this, c.getInputMap(), c.getActionMap());
/*     */     
/* 223 */     MCKeyActionManager.initScreen((MCResourceBeans)this, 
/* 224 */         getInputMap(1), getActionMap());
/* 225 */     MCKeyActionManager.initScreen((MCResourceBeans)this, c.getInputMap(), c.getActionMap());
/*     */     
/* 227 */     MCMode mode = MCCellUtil.isCellEditable(index, column, table);
/* 228 */     setMode(mode);
/* 229 */     setForeground(MCCellUtil.getForeground(index, column, table, false, mode));
/* 230 */     setBackground(MCCellUtil.getBackground(index, column, table, false, mode));
/* 231 */     setFont(column.getFont());
/* 232 */     setCaretColor(MCCellUtil.getCaretColor(index, column, table));
/* 233 */     setSelectionColor(MCCellUtil.getSelectionColor(index, column, table));
/* 234 */     setSelectedTextColor(MCCellUtil.getSelectedTextColor(index, column, table));
/* 235 */     setMeta(column.getMeta());
/* 236 */     setLength(column.getLength(index), column.getScale(index), 
/* 237 */         column.isMinusEnable(index));
/* 238 */     setNumberFormat(MCCellUtil.getNumberFormat(index, column, table, mode));
/*     */     
/* 240 */     setViewScale(MCCellUtil.getViewScale(index, column, table));
/* 241 */     setViewZeroType(MCCellUtil.getViewZeroType(index, column, table));
/* 242 */     setViewRoundingMode(MCCellUtil.getViewRoundingMode(index, column, table));
/*     */     
/* 244 */     setListVisibleColumn(column.getListVisibleColumn());
/* 245 */     setRow(column.getTable().getRow(index), column.getRowColumnName());
/* 246 */     setAutoFocus(column.isAutoFocus());
/* 247 */     setSelectAll(column.isSelectAll());
/* 248 */     MCListConfig lc = column.getListConfig();
/* 249 */     setListConfig(lc);
/* 250 */     if (lc.getListType() == MCListType.SELECT_ONLY) {
/* 251 */       setDocumentEditable(false);
/*     */     }
/* 253 */     setComboListConfig(column.getComboListConfig());
/*     */     
/* 255 */     Border border = MCCellUtil.getEditorBorder(index, column, table);
/* 256 */     if (border != null) {
/* 257 */       setBorder(border);
/*     */     } else {
/*     */       
/* 260 */       setBorder(getDefaultBorder());
/*     */     } 
/* 262 */     MCPopupMenu menu = getComponentPopupMenu();
/* 263 */     if (menu != null) {
/* 264 */       menu.updateResource();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Color getForeground() {
/* 270 */     Color c = null;
/* 271 */     int idx = getRowIndex();
/* 272 */     MCTable<?> table = getTable();
/* 273 */     if (table != null && idx >= 0) {
/* 274 */       MCMode mode = MCCellUtil.isCellEditable(idx, this._column, table);
/* 275 */       c = MCCellUtil.getForeground(idx, this._column, table, false, mode);
/*     */     } else {
/*     */       
/* 278 */       c = super.getForeground();
/*     */     } 
/* 280 */     return c;
/*     */   }
/*     */ 
/*     */   
/*     */   public Color getBackground() {
/* 285 */     Color c = null;
/* 286 */     int idx = getRowIndex();
/* 287 */     MCTable<?> table = getTable();
/* 288 */     if (table != null && idx >= 0) {
/* 289 */       MCMode mode = MCCellUtil.isCellEditable(idx, this._column, table);
/* 290 */       c = MCCellUtil.getBackground(idx, this._column, table, false, mode);
/*     */     } else {
/*     */       
/* 293 */       c = super.getBackground();
/*     */     } 
/* 295 */     return c;
/*     */   }
/*     */ 
/*     */   
/*     */   public Border getBorder() {
/* 300 */     Border b = MCCellUtil.getBorder(this);
/* 301 */     return (b != null) ? b : super.getBorder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCRootPanel getRootPanel() {
/* 313 */     return MCCellUtil.getRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCRootPanel getNearestRootPanel() {
/* 318 */     return MCCellUtil.getNearestRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessageByLocale() {
/* 323 */     return getColumnConfig().getMessageByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLabelByLocale() {
/* 328 */     return getColumnConfig().getLabelByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterRequestFocus() {
/* 333 */     MCRootPanel bp = getBaseRootPanel();
/* 334 */     MCBeansUtil.afterRequestFocus(bp, (JComponent)getTable());
/* 335 */     MCBeansUtil.scrollRectToVisible(bp, (JComponent)this, 
/* 336 */         getComboField().getHorizontalAlignment());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 341 */     repaint();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFocusOwner() {
/* 346 */     MCTable<?> t = getTable();
/* 347 */     return (t != null) ? (t.isRemoveNotifyProcessing() ? super.isFocusOwner() : false) : 
/* 348 */       super.isFocusOwner();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValueChanged() {
/* 353 */     return isValueChanged((Comparable<?>)getRowValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValueChanged(Comparable<?> value) {
/* 358 */     return isValueChanged((Comparable<?>)getValue(), value);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isValueChanged(Comparable<?> view, Comparable<?> row) {
/* 363 */     return MCCellUtil.isValueChanged(this, view, row);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasFocus() {
/* 368 */     MCTable<?> t = getTable();
/* 369 */     return (t != null) ? ((this == t.getMCEditorComponent())) : super.hasFocus();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isMCFocusOwner() {
/* 374 */     MCTable<?> t = getTable();
/* 375 */     return (t != null) ? ((t.getMCEditorComponent() == this)) : isFocusOwner();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCListType getListType() {
/* 380 */     MCColumnConfig c = getColumnConfig();
/* 381 */     return (c != null) ? c.getListType() : super.getListType();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCLinkedBeans[] getLinkBeans() {
/* 386 */     MCColumnConfig c = getColumnConfig();
/* 387 */     return (c != null) ? c.getLinkBeans() : super.getLinkBeans();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRowToViews() {
/* 392 */     boolean e = MCBeansProxy.PROXY.isEventEnabled();
/*     */     try {
/* 394 */       MCBeansProxy.PROXY.setEventEnabled(false);
/* 395 */       setRowToView();
/* 396 */       MCLinkedBeans[] cs = getLinkBeans(); byte b; int i; MCLinkedBeans[] arrayOfMCLinkedBeans1;
/* 397 */       for (i = (arrayOfMCLinkedBeans1 = cs).length, b = 0; b < i; ) { MCLinkedBeans c = arrayOfMCLinkedBeans1[b];
/* 398 */         if (c instanceof MCColumnConfig) {
/* 399 */           MCColumnConfig col = (MCColumnConfig)c;
/* 400 */           int j = getRowIndex();
/* 401 */           col.setValue(j, 
/* 402 */               getTable().getRow(j).getValue(col.getBaseRowColumnName()));
/*     */         } 
/*     */         b++; }
/*     */     
/*     */     } finally {
/* 407 */       MCBeansProxy.PROXY.setEventEnabled(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCList doListEventEx() {
/* 416 */     MCTableColumn c = (MCTableColumn)getColumnConfig();
/* 417 */     MCEventProxy.PROXY.setEventIndex(c.getEventInfo(), getRowIndex());
/* 418 */     return c.doListEventEx();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCList doListEvent() {
/*     */     try {
/* 424 */       MCColumnConfig c = getColumnConfig();
/* 425 */       MCEventProxy.PROXY.setEventIndex(c.getEventInfo(), getRowIndex());
/* 426 */       return c.doListEvent();
/*     */     }
/* 428 */     catch (MCException e) {
/* 429 */       handle((Throwable)e);
/*     */       
/* 431 */       setRowToViews();
/*     */       
/* 433 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean doListEventWithNull() {
/* 438 */     MCColumnConfig c = getColumnConfig();
/* 439 */     return (c != null) ? c.doListEventWithNull() : false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean haveLinkValuesNullWhenDupliKeyTyped() {
/* 444 */     MCColumnConfig c = getColumnConfig();
/* 445 */     return (c != null) ? c.haveLinkValuesNullWhenDupliKeyTyped() : false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean doVC() {
/* 450 */     return getColumnConfig().doVC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNC() {
/* 455 */     getColumnConfig().doNC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNE() {
/* 460 */     getColumnConfig().doNE();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNX() {
/* 465 */     getColumnConfig().doNX();
/*     */     
/* 467 */     getListConfig().setOpeType("input");
/*     */   }
/*     */ 
/*     */   
/*     */   public void doLC() {
/* 472 */     getColumnConfig().doLC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doDC() {
/* 477 */     getColumnConfig().doDC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void focusGained() {
/* 482 */     Document d = getDocument();
/* 483 */     if (d instanceof MCNumberDocument) {
/* 484 */       MCNumberDocument n = (MCNumberDocument)d;
/* 485 */       boolean e = n.isValueCheck();
/* 486 */       n.setValueCheck(false);
/*     */       try {
/* 488 */         setText(getRowValue());
/* 489 */         focusGainedSelect();
/*     */       } finally {
/*     */         
/* 492 */         n.setValueCheck(e);
/*     */       } 
/*     */     } else {
/*     */       
/* 496 */       setText(getRowValue());
/* 497 */       focusGainedSelect();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void focusLost() {
/* 503 */     Document d = getDocument();
/* 504 */     if (d instanceof MCNumberDocument) {
/* 505 */       MCNumberDocument n = (MCNumberDocument)d;
/* 506 */       boolean e = n.isValueCheck();
/* 507 */       n.setValueCheck(false);
/*     */       try {
/* 509 */         setText(getRowValue());
/*     */       } finally {
/*     */         
/* 512 */         n.setValueCheck(e);
/*     */       } 
/*     */     } else {
/*     */       
/* 516 */       setText(getRowValue());
/*     */     } 
/*     */   }
/*     */   
/*     */   public String doFormat(MCNumber value) {
/*     */     String rtn;
/* 522 */     MCNumberFormat f = getNumberFormat();
/* 523 */     int fieldScale = getScale();
/*     */     
/* 525 */     if (isMCFocusOwner()) {
/* 526 */       rtn = f.doInputFormat(value, fieldScale);
/*     */     } else {
/*     */       
/* 529 */       rtn = f.doOutputFormat(value, fieldScale);
/*     */     } 
/* 531 */     return rtn;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCEventInfo getEventInfo() {
/* 536 */     return getColumnConfig().getEventInfo();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource(MCRootPanel panel) {}
/*     */ 
/*     */   
/*     */   public void doCheckValueError() {
/* 549 */     super.doCheckValueError();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCPopupConfig getPopupConfig() {
/* 554 */     MCTable<?> t = getTable();
/* 555 */     return (t != null) ? t.getPopupConfig() : null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCPopupMenu configurePopup(MCPopupMenu menu) {
/* 560 */     MCPopupConfig pc = getPopupConfig();
/* 561 */     return (pc != null) ? 
/* 562 */       pc.configurePopup(menu, getTable(), getRowIndex(), getColumnConfig()) : 
/* 563 */       menu;
/*     */   }
/*     */ 
/*     */   
/*     */   public void processKeyEvent(KeyEvent e) {
/* 568 */     MCCellUtil.beforeKeyEvent(e, this);
/* 569 */     super.processKeyEvent(e);
/*     */   }
/*     */ 
/*     */   
/*     */   public Comparable<?> doListFormat(Comparable<?> value) {
/* 574 */     return getColumnConfig().doListFormat(getRowIndex(), value);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Color getListForeground(MCRow row, boolean selected) {
/* 579 */     MCColumnConfig c = getColumnConfig();
/* 580 */     return getComboListConfig().getRowForeground(c, getRowIndex(), c.getTable(), row, 
/* 581 */         selected);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Color getListBackground(MCRow row, boolean selected) {
/* 586 */     MCColumnConfig c = getColumnConfig();
/* 587 */     return getComboListConfig().getRowBackground(c, getRowIndex(), c.getTable(), row, 
/* 588 */         selected);
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCEditorComboListModel createModel() {
/* 593 */     return new MCEditorComboListModel(this, this);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\table\MCEditorNumberComboBox.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */