/*    */ package META-INF.versions.21.mcframe.clientCore.beans.tree;
/*    */ import mcframe.clientCore.beans.tree.MCTree;
/*    */ import mcframe.clientCore.beans.tree.MCTree64;
/*    */ 
/*    */ public class MCTreeCompatibilityFactory {
/*    */   public static <E extends mcframe.clientCore.container.MCConstRow> MCTree<E> createTree(String name) {
/*  7 */     return (MCTree<E>)new MCTree21(name);
/*    */   }
/*    */   public static <E extends mcframe.clientCore.container.MCConstRow> MCTree64<E> createTree64(String name, boolean enable) {
/* 10 */     return (MCTree64<E>)new MCTree6421(name, enable);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\tree\MCTreeCompatibilityFactory.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */