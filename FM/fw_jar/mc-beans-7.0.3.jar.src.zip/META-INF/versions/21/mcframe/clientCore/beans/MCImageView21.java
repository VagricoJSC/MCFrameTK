/*    */ package META-INF.versions.21.mcframe.clientCore.beans;
/*    */ import mcframe.clientCore.beans.MCImageView;
/*    */ 
/*    */ class MCImageView21 extends MCImageView {
/*    */   public MCImageView21(String name) {
/*  6 */     super(name);
/*    */   }
/*    */ 
/*    */   
/*    */   public void requestFocus(FocusEvent.Cause cause) {
/* 11 */     doFocus(false);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\MCImageView21.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */