/*    */ package META-INF.versions.21.mcframe.clientCore.beans;
/*    */ 
/*    */ public class MCBeansCompatibilityFactory {
/*    */   public static MCButton createButton(String name) {
/*  5 */     return (MCButton)new MCButton21(name);
/*    */   }
/*    */   public static MCButton createButton(String name, String group) {
/*  8 */     return (MCButton)new MCButton21(name, group);
/*    */   }
/*    */   public static MCCheckBox createCheckBox(String name) {
/* 11 */     return (MCCheckBox)new MCCheckBox21(name);
/*    */   }
/*    */   public static MCDateField createDateField(String name) {
/* 14 */     return (MCDateField)new MCDateField21(name);
/*    */   }
/*    */   public static MCImageView createImageView(String name) {
/* 17 */     return (MCImageView)new MCImageView21(name);
/*    */   }
/*    */   public static MCNumberField createNumberField(String name) {
/* 20 */     return (MCNumberField)new MCNumberField21(name);
/*    */   }
/*    */   public static MCPasswordField createPasswordField(String name) {
/* 23 */     return (MCPasswordField)new MCPasswordField21(name);
/*    */   }
/*    */   public static MCRadioButton createRadioButton(String name) {
/* 26 */     return (MCRadioButton)new MCRadioButton21(name);
/*    */   }
/*    */   public static MCSplitPane createSplitPane(String name) {
/* 29 */     return (MCSplitPane)new MCSplitPane21(name);
/*    */   }
/*    */   public static MCTabbedPane createTabbedPane(String name) {
/* 32 */     return (MCTabbedPane)new MCTabbedPane21(name);
/*    */   }
/*    */   public static MCTextArea createTextArea(String name) {
/* 35 */     return (MCTextArea)new MCTextArea21(name);
/*    */   }
/*    */   public static MCTextField createTextField(String name) {
/* 38 */     return (MCTextField)new MCTextField21(name);
/*    */   }
/*    */   public static MCTimestampField createTimestampField(String name) {
/* 41 */     return (MCTimestampField)new MCTimestampField21(name);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\MCBeansCompatibilityFactory.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */