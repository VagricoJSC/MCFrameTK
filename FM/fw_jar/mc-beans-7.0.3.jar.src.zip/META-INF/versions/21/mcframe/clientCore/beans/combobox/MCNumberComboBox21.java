/*    */ package META-INF.versions.21.mcframe.clientCore.beans.combobox;
/*    */ import mcframe.clientCore.beans.combobox.MCNumberComboBox;
/*    */ 
/*    */ class MCNumberComboBox21 extends MCNumberComboBox {
/*    */   public MCNumberComboBox21(String name) {
/*  6 */     super(name);
/*    */   }
/*    */ 
/*    */   
/*    */   public void requestFocus(FocusEvent.Cause cause) {
/* 11 */     MCNumberComboBox.MCNumberComboField mCNumberComboField = getComboField();
/* 12 */     if (mCNumberComboField != null) {
/* 13 */       mCNumberComboField.requestFocus(cause);
/*    */     }
/* 15 */     super.requestFocus(cause);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\combobox\MCNumberComboBox21.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */