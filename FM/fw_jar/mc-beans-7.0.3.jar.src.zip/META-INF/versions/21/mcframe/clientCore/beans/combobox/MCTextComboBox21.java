/*    */ package META-INF.versions.21.mcframe.clientCore.beans.combobox;
/*    */ import mcframe.clientCore.beans.combobox.MCTextComboBox;
/*    */ 
/*    */ class MCTextComboBox21 extends MCTextComboBox {
/*    */   public MCTextComboBox21(String name) {
/*  6 */     super(name);
/*    */   }
/*    */ 
/*    */   
/*    */   public void requestFocus(FocusEvent.Cause cause) {
/* 11 */     MCTextComboBox.MCTextComboField mCTextComboField = getComboField();
/* 12 */     if (mCTextComboField != null) {
/* 13 */       mCTextComboField.requestFocus(cause);
/*    */     }
/* 15 */     super.requestFocus(cause);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\combobox\MCTextComboBox21.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */