/*     */ package META-INF.versions.21.mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.FocusListener;
/*     */ import java.awt.event.KeyEvent;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.border.Border;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCCheckBox;
/*     */ import mcframe.clientCore.beans.MCMode;
/*     */ import mcframe.clientCore.beans.MCResourceBeans;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.action.MCKeyActionManager;
/*     */ import mcframe.clientCore.beans.table.MCCellUtil;
/*     */ import mcframe.clientCore.beans.table.MCColumnConfig;
/*     */ import mcframe.clientCore.beans.table.MCEditorBeans;
/*     */ import mcframe.clientCore.beans.table.MCEventProxy;
/*     */ import mcframe.clientCore.beans.table.MCTable;
/*     */ import mcframe.clientCore.event.MCEventInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCEditorCheckBox
/*     */   extends MCCheckBox
/*     */   implements MCEditorBeans
/*     */ {
/*     */   private static final String TYPE = "table.column.check";
/*     */   private MCColumnConfig _column;
/*     */   private MCTable<?> _table;
/*     */   
/*     */   @Deprecated
/*     */   protected MCEditorCheckBox(String name, MCColumnConfig column) {
/*  65 */     super(name);
/*  66 */     setColumnConfig(column);
/*  67 */     setTable(column.getBaseTable());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getRatio() {
/*  79 */     return getColumnConfig().getBaseTable().getRatio();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initBeans() {
/*  84 */     super.initBeans();
/*     */ 
/*     */     
/*  87 */     setOpaque(true);
/*     */ 
/*     */     
/*  90 */     setHorizontalAlignment(0);
/*     */ 
/*     */     
/*  93 */     setFocusTraversalKeysEnabled(false);
/*     */     
/*  95 */     setBorder(MCCellUtil.DEFAULT_BORDER); byte b;
/*     */     int i;
/*     */     FocusListener[] arrayOfFocusListener;
/*  98 */     for (i = (arrayOfFocusListener = getFocusListeners()).length, b = 0; b < i; ) { FocusListener l = arrayOfFocusListener[b];
/*  99 */       removeFocusListener(l);
/*     */       b++; }
/*     */   
/*     */   }
/*     */   
/*     */   protected MCCheckBox.MCCheckBoxModel createModel() {
/* 105 */     return (MCCheckBox.MCCheckBoxModel)new MCEditorCheckBoxModel(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initKeyAssign() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initResource() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getType() {
/* 130 */     return "table.column.check";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setColumnConfig(MCColumnConfig column) {
/* 141 */     this._column = column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCColumnConfig getColumnConfig() {
/* 153 */     return this._column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setTable(MCTable<?> table) {
/* 164 */     this._table = table;
/*     */   }
/*     */ 
/*     */   
/*     */   public final MCTable getTable() {
/* 169 */     return this._table;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getRowIndex() {
/* 175 */     return MCCellUtil.getRowIndex(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void transferFocus() {
/* 180 */     MCTable<?> t = getTable();
/* 181 */     t.transferFocus(getRowIndex(), t.getViewColumn(getColumnConfig()) + 1, false, 
/* 182 */         true, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCRootPanel getRootPanel() {
/* 187 */     return MCCellUtil.getRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCRootPanel getNearestRootPanel() {
/* 192 */     return MCCellUtil.getNearestRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessageByLocale() {
/* 197 */     return getColumnConfig().getMessageByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLabelByLocale() {
/* 202 */     return getColumnConfig().getLabelByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterRequestFocus() {
/* 207 */     MCBeansUtil.afterRequestFocus((JComponent)getTable());
/*     */   }
/*     */ 
/*     */   
/*     */   public void commitValue() {
/* 212 */     getTable().commitValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public Border getDefaultBorder() {
/* 217 */     return MCCellUtil.DEFAULT_BORDER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setColumnInfo(int index, MCColumnConfig column) {
/* 230 */     setColumnConfig(column);
/* 231 */     MCTable<?> table = getTable();
/* 232 */     MCKeyActionManager.init((MCResourceBeans)this, getInputMap(), getActionMap());
/* 233 */     MCKeyActionManager.initScreen((MCResourceBeans)this, getInputMap(), getActionMap());
/* 234 */     MCMode mode = MCCellUtil.isCellEditable(index, column, table);
/* 235 */     setMode(mode);
/* 236 */     setForeground(MCCellUtil.getForeground(index, column, table, false, mode));
/* 237 */     setBackground(MCCellUtil.getBackground(index, column, table, false, mode));
/* 238 */     setFont(column.getFont());
/* 239 */     setMeta(column.getMeta());
/* 240 */     setIcon(column.getIcon());
/* 241 */     setSelectedIcon(column.getSelectedIcon());
/* 242 */     setPressedIcon(column.getPressedIcon());
/* 243 */     setDisabledIcon(column.getDisabledIcon());
/* 244 */     setDisabledSelectedIcon(column.getDisabledSelectedIcon());
/* 245 */     setRow(column.getTable().getRow(index), column.getRowColumnName());
/*     */     
/* 247 */     Border border = MCCellUtil.getEditorBorder(index, column, table);
/* 248 */     if (border != null) {
/* 249 */       setBorder(border);
/*     */     } else {
/*     */       
/* 252 */       setBorder(getDefaultBorder());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFocusOwner() {
/* 258 */     MCTable<?> t = getTable();
/* 259 */     return (t != null) ? (t.isRemoveNotifyProcessing() ? super.isFocusOwner() : false) : 
/* 260 */       super.isFocusOwner();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isMCFocusOwner() {
/* 265 */     MCTable<?> t = getTable();
/* 266 */     return (t != null) ? ((t.getMCEditorComponent() == this)) : isFocusOwner();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void fireActionPerformed(ActionEvent event) {
/*     */     try {
/* 273 */       MCTable.setEditingStoppedEnabled(false);
/* 274 */       super.fireActionPerformed(event);
/* 275 */       Component o = MCBeansUtil.getFocusOwner((Component)getTable());
/* 276 */       if (o instanceof MCTable) {
/* 277 */         MCTable<?> t = (MCTable)o;
/* 278 */         if (t == getTable() && !t.hasFocus()) {
/* 279 */           t.requestFocus();
/*     */         }
/*     */       } 
/*     */     } finally {
/*     */       
/* 284 */       MCTable.setEditingStoppedEnabled(true);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValueChanged() {
/* 290 */     return isValueChanged(getRowValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValueChanged(Comparable<?> value) {
/* 304 */     return isValueChanged(Boolean.valueOf(getValue()), value);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isValueChanged(Comparable<?> view, Comparable<?> row) {
/* 309 */     return MCCellUtil.isValueChanged(this, view, row);
/*     */   }
/*     */ 
/*     */   
/*     */   public void valueCommited() {
/* 314 */     MCEventProxy.PROXY.setValue(getEventInfo(), getRowValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getText() {
/* 319 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean doVC() {
/* 324 */     return getColumnConfig().doVC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNC() {
/* 329 */     getColumnConfig().doNC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNE() {
/* 334 */     getColumnConfig().doNE();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNX() {
/* 339 */     getColumnConfig().doNX();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCEventInfo getEventInfo() {
/* 344 */     return getColumnConfig().getEventInfo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void focusGained() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void focusLost() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRequestFocusEnabled() {
/* 369 */     return (MCCellUtil.isRequestFocusEnabled(this) && super.isRequestFocusEnabled());
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isMCRequestFocusEnabled() {
/* 374 */     return MCCellUtil.isFocusable(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public Border getBorder() {
/* 379 */     Border b = MCCellUtil.getBorder(this);
/* 380 */     return (b != null) ? b : super.getBorder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource(MCRootPanel panel) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doCheckValueError() {
/* 406 */     super.doCheckValueError();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void processKeyEvent(KeyEvent e) {
/* 411 */     MCCellUtil.beforeKeyEvent(e, this);
/* 412 */     super.processKeyEvent(e);
/*     */   }
/*     */ 
/*     */   
/*     */   public Comparable<?> doListFormat(Comparable<?> value) {
/* 417 */     return getColumnConfig().doListFormat(getRowIndex(), value);
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public final void focusGainedSelect() {}
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\table\MCEditorCheckBox.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */