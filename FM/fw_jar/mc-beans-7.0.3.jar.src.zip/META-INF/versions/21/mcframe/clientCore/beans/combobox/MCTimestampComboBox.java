/*     */ package META-INF.versions.21.mcframe.clientCore.beans.combobox;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import javax.swing.SwingUtilities;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.MCRowBeans;
/*     */ import mcframe.clientCore.beans.combobox.MCBeansProxy;
/*     */ import mcframe.clientCore.beans.combobox.MCCalendarComboBox;
/*     */ import mcframe.clientCore.beans.combobox.MCComboField;
/*     */ import mcframe.clientCore.beans.combobox.MCFieldComboBox;
/*     */ import mcframe.clientCore.beans.text.MCCalendarDocumentBeans;
/*     */ import mcframe.clientCore.beans.text.MCCalendarFormat;
/*     */ import mcframe.clientCore.beans.text.MCTimestampFormat;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.lang.MCCalendarDate;
/*     */ import mcframe.commonCore.lang.MCDataType;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.lang.MCTimestamp;
/*     */ import mcframe.commonCore.notice.Core_Msg;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCMessageList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCTimestampComboBox
/*     */   extends MCCalendarComboBox<MCTimestamp>
/*     */   implements MCCalendarDocumentBeans<MCTimestamp>
/*     */ {
/*     */   @Deprecated
/*     */   public MCTimestampComboBox(String name) {
/*  43 */     super(name);
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCTimestampComboField getComboField() {
/*  48 */     return (MCTimestampComboField)super.getComboField();
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCTimestampComboField createComboField() {
/*  53 */     return new MCTimestampComboField(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCalendarFormat(MCTimestampFormat format) {
/*  64 */     setCalendarFormat((MCCalendarFormat)format);
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCCalendarFormat<MCTimestamp> createCalendarFormat() {
/*  69 */     return (MCCalendarFormat<MCTimestamp>)new MCTimestampFormat();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCTimestampFormat getCalendarFormat() {
/*  74 */     return (MCTimestampFormat)super.getCalendarFormat();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setListCalendarFormat(MCTimestampFormat format) {
/*  85 */     setListCalendarFormat((MCCalendarFormat)format);
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCCalendarFormat<MCTimestamp> createListCalendarFormat() {
/*  90 */     return (MCCalendarFormat<MCTimestamp>)new MCTimestampFormat();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCTimestampFormat getListCalendarFormat() {
/*  95 */     return (MCTimestampFormat)super.getListCalendarFormat();
/*     */   }
/*     */ 
/*     */   
/*     */   public Comparable<?> doListFormat(Comparable<?> value) {
/*     */     MCTimestamp v;
/* 101 */     if (value == null || "".equals(value)) {
/* 102 */       v = null;
/*     */     }
/* 104 */     else if (value instanceof MCTimestamp) {
/* 105 */       v = (MCTimestamp)value;
/*     */     } else {
/*     */       
/* 108 */       throw new MCException(MCBeansUtil.createMsg(this, Core_Msg.FCBAC0352, new Object[] { value }));
/*     */     } 
/* 110 */     return getListCalendarFormat().doOutputFormat((MCCalendarDate)v);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean checkInputValue(Comparable<?> value, MCMessageList list) {
/* 115 */     MCMessageList l = getValueChecker().checkInputValue(this, value);
/* 116 */     if (l.size() == 0) {
/* 117 */       return true;
/*     */     }
/* 119 */     if (list != null) {
/* 120 */       list.addAll((Collection)l);
/*     */     }
/* 122 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCMessageList checkValue(Comparable<?> value) {
/* 127 */     return getValueChecker().checkValue(this, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCTimestamp getRowValue() {
/* 132 */     MCConstRow c = getBaseRow();
/* 133 */     String n = getBaseRowColumnName();
/* 134 */     return !MCBeansUtil.isNull(c, n) ? c.getTimestamp(n) : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setViewValue(Comparable<?> value, MCMessageList list) {
/* 139 */     if (list == null) {
/* 140 */       list = new MCMessageList();
/*     */     }
/* 142 */     if (value != null) {
/* 143 */       if (value instanceof MCTimestamp) {
/* 144 */         setValue(value, list);
/*     */       } else {
/*     */         
/* 147 */         list.add(MCBeansUtil.createCauseMsg((MCRowBeans)this, Core_Msg.FCBAC0087, new Object[0]));
/*     */       } 
/*     */     } else {
/*     */       
/* 151 */       setValue(null, list);
/*     */     } 
/*     */   }
/*     */   
/*     */   public MCTimestamp today() {
/*     */     MCTimestamp v;
/* 157 */     MCRootPanel p = getRootPanel();
/* 158 */     if (p == null) {
/* 159 */       return MCTimestamp.today();
/*     */     }
/*     */     
/*     */     try {
/* 163 */       v = (MCTimestamp)p.today(MCDataType.TIMESTAMP);
/*     */     }
/* 165 */     catch (Exception exception) {
/* 166 */       v = null;
/*     */     } 
/* 168 */     return (v != null) ? v : MCTimestamp.today();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doAfterInsert() {
/* 173 */     if (!isPopupVisible()) {
/*     */       return;
/*     */     }
/*     */     
/* 177 */     SwingUtilities.invokeLater((Runnable)new Object(this));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean doIncrementalSearch() {
/* 210 */     String v = getText();
/* 211 */     if (MCStringUtil.isNull(v)) {
/* 212 */       return false;
/*     */     }
/*     */     
/* 215 */     MCList<?> l = getList();
/* 216 */     if (l == null) {
/* 217 */       return false;
/*     */     }
/*     */     
/* 220 */     boolean e = MCBeansProxy.PROXY.isEventEnabled();
/*     */     
/* 222 */     try { MCBeansProxy.PROXY.setEventEnabled(false);
/* 223 */       String n = getKeyColumnName();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */        }
/*     */     
/*     */     finally
/*     */     
/*     */     { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 248 */       MCBeansProxy.PROXY.setEventEnabled(e); }  MCBeansProxy.PROXY.setEventEnabled(e);
/*     */     
/* 250 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public Comparable<?> _adjustValueByFormat(Comparable<?> value) {
/* 255 */     if (value instanceof MCTimestamp) {
/* 256 */       return (Comparable<?>)MCBeansProxy.PROXY.adjustValueByFormat(
/* 257 */           (MCCalendarDate)value, getCalendarFormat().getInputPattern());
/*     */     }
/* 259 */     return value;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\combobox\MCTimestampComboBox.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */