/*     */ package META-INF.versions.21.mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.util.List;
/*     */ import javax.swing.SizeSequence;
/*     */ import javax.swing.table.JTableHeader;
/*     */ import javax.swing.table.TableCellRenderer;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.resource.MCColumnWidthData;
/*     */ import mcframe.clientCore.beans.resource.MCColumnWidthInfo;
/*     */ import mcframe.clientCore.beans.resource.MCColumnWidthResourceIO;
/*     */ import mcframe.clientCore.beans.table.MCColumnConfig;
/*     */ import mcframe.clientCore.beans.table.MCFixedColumnTable;
/*     */ import mcframe.clientCore.beans.table.MCFixedColumnTable2;
/*     */ import mcframe.clientCore.beans.table.MCMultiLineHeaderRenderer;
/*     */ import mcframe.clientCore.beans.table.MCTable;
/*     */ import mcframe.clientCore.beans.table.MCTable2ColumnModel;
/*     */ import mcframe.clientCore.beans.table.MCTable2Header;
/*     */ import mcframe.clientCore.beans.table.MCTableColumn;
/*     */ import mcframe.clientCore.beans.table.MCTableColumnModel;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.clientCore.event.MCAPBeans;
/*     */ import mcframe.clientCore.event.MCEventInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCTable2<E extends MCConstRow>
/*     */   extends MCTable<E>
/*     */ {
/*     */   private static final String uiClassID = "MCTable2UI";
/*     */   private boolean _customRowHeight;
/*     */   
/*     */   @Deprecated
/*     */   public MCTable2(String name) {
/*  56 */     super(name);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 466 */     this._customRowHeight = false;
/*     */   } mcframe.clientCore.beans.table.MCTable2<E> getBodyTable2() { return (mcframe.clientCore.beans.table.MCTable2<E>)getBodyTable(); } MCFixedColumnTable2<E> getFixedColumnTable2() { return (MCFixedColumnTable2<E>)getFixedColumnTable(); } public MCColumnConfig[] removeAllReturnColumns() { return getColumnModel().removeAllReturnColumns(); } public void addReturnColumn(MCColumnConfig... cols) { getColumnModel().addReturnColumn(cols); } public boolean isReturnColumn(MCColumnConfig col) { return getColumnModel().isReturnColumn(col); }
/*     */   public MCColumnConfig[] getDefaultReturnColumns() { return getColumnModel().getDefaultReturnColumns(); }
/*     */   public int[] getReturnPositions() { return getColumnModel().getReturnPositions(); }
/*     */   public int getReturnCount() { return getColumnModel().getReturnCount(); }
/*     */   public String getUIClassID() {
/*     */     return "MCTable2UI";
/*     */   }
/*     */   protected MCFixedColumnTable<E> createFixedColumnTable(String name) {
/*     */     return (MCFixedColumnTable<E>)new MCFixedColumnTable2(this, name);
/*     */   }
/*     */   protected JTableHeader createDefaultTableHeader() {
/*     */     return (JTableHeader)new MCTable2Header((TableColumnModel)getColumnModel());
/*     */   }
/*     */   public MCTable2Header getTableHeader() {
/*     */     return (MCTable2Header)super.getTableHeader();
/*     */   }
/* 483 */   boolean isSetCustomRowHeight() { return this._customRowHeight; } protected MCTable2ColumnModel createDefaultColumnModel() { return new MCTable2ColumnModel(this); }
/*     */   public MCTable2ColumnModel getColumnModel() { return (MCTable2ColumnModel)super.getColumnModel(); }
/*     */   protected void setRenderers() { getTableHeader().setDefaultRenderer((TableCellRenderer)new MCMultiLineHeaderRenderer(getTableHeader().getDefaultRenderer())); }
/*     */   public void initialized() { super.initialized(); if (!isPartsTable()) { getColumnModel().setDefaultReturnPositions(); MCColumnConfig[] ra = removeAllReturnColumns(); MCColumnConfig[] a = getColumnConfigs(); byte b; int i; MCColumnConfig[] arrayOfMCColumnConfig1; for (i = (arrayOfMCColumnConfig1 = a).length, b = 0; b < i; ) { MCColumnConfig c = arrayOfMCColumnConfig1[b]; MCColumnWidthResourceIO cio = ((MCTableColumn)c).getColumnWidthResourceIO(); MCColumnWidthInfo ci = MCColumnWidthResourceIO.getInitInfo(cio.getInfoList()); if (ci != null) { List<MCColumnWidthData> dl = ci.getColumnWidthList(); if (dl.size() == 1) { MCColumnWidthData d = dl.get(0); Boolean rf = d.getReturnColumn(); if (rf != null)
/*     */               if (rf.booleanValue()) {
/*     */                 addReturnColumn(new MCColumnConfig[] { c });
/*     */               } else {
/*     */                 for (int j = 0; j < ra.length; j++) {
/*     */                   if (c == ra[j])
/*     */                     ra[j] = null; 
/*     */                 } 
/*     */               }   }
/*     */            }
/*     */          b++; }
/*     */        addReturnColumn(ra); }
/*     */      }
/*     */   public void doAPEvent(MCAPBeans compo, MCEventInfo info) { if (compo == getColumnWidthPanelMenuItem()) {
/*     */       MCRootPanel bp = getBaseRootPanel(); MCRootPanel p = bp.createPanel("FS", "FSBAP0100", MCRootPanel.SCREEN_MODAL, new Object[] { "T1", null, this }); bp.showChildPanel(p, MCRootPanel.MULTI, new Object[0]);
/*     */     } else {
/*     */       super.doAPEvent(compo, info);
/*     */     }  }
/*     */   public void _applyColumnWidthInfo(MCColumnWidthInfo info) { removeAllReturnColumns(); super._applyColumnWidthInfo(info); }
/* 505 */   public void setMCRowHeight(int index, int height) { if (!this._customRowHeight) {
/* 506 */       this._customRowHeight = (getRowHeight() != height);
/*     */     }
/* 508 */     super.setMCRowHeight(index, height); }
/*     */   
/*     */   void applyColumnWidthInfo(MCColumnConfig column, MCColumnWidthData data) {
/*     */     if (Boolean.TRUE.equals(data.getReturnColumn()))
/*     */       addReturnColumn(new MCColumnConfig[] { column }); 
/*     */     super.applyColumnWidthInfo(column, data);
/*     */   }
/*     */   int getTierInRow() {
/*     */     return getReturnCount();
/*     */   }
/*     */   public void setUnscrollColumn(MCColumnConfig column) {
/*     */     MCColumnConfig[] rets = removeAllReturnColumns();
/*     */     super.setUnscrollColumn(column);
/*     */     addReturnColumn(rets);
/*     */   }
/*     */   
/* 524 */   public void doLayout() { TableColumn resizingColumn = getResizingColumn();
/* 525 */     if (resizingColumn == null) {
/* 526 */       setWidthsFromPreferredWidths(false);
/*     */     } else {
/*     */       
/* 529 */       int columnIndex = viewIndexForColumn(resizingColumn);
/* 530 */       int delta = getWidth() - getColumnModel().getTotalColumnWidth();
/* 531 */       accommodateDelta(columnIndex, delta);
/* 532 */       delta = getWidth() - getColumnModel().getTotalColumnWidth();
/* 533 */       if (delta != 0) {
/* 534 */         resizingColumn.setWidth(resizingColumn.getWidth() + delta);
/*     */       }
/* 536 */       setWidthsFromPreferredWidths(true);
/*     */     } 
/*     */ 
/*     */     
/* 540 */     layout(); } public int tierAtPoint(Point point) { int row = rowAtPoint(point); if (row < 0)
/*     */       return -1;  int tiercnt = getReturnCount(); int y = 0; for (int i = 0; i < row; i++)
/*     */       y += getRowHeight(i) * tiercnt;  int distance = point.y - y; int h = getRowHeight(row); if (h == 0)
/*     */       return 0;  int tier = distance / h; return (tier < 0) ? 0 : tier; }
/*     */   public int rowAtPoint(Point point) { Point p = new Point(point); int tier = getReturnCount(); p.y /= tier; return super.rowAtPoint(p); }
/* 545 */   private TableColumn getResizingColumn() { return (this.tableHeader == null) ? 
/* 546 */       null : this.tableHeader.getResizingColumn(); }
/*     */   public int columnAtPoint(Point point) { int x = point.x; MCTable2ColumnModel cm = getColumnModel();
/*     */     int tier_w = 0;
/*     */     int tier = tierAtPoint(point);
/*     */     if (tier < 0)
/*     */       return -1; 
/*     */     int[] se = cm.getTierColumnIndex(tier);
/*     */     int i;
/*     */     for (i = se[0]; i < se[1]; i++)
/*     */       tier_w += cm.getColumn(i).getWidth(); 
/*     */     if (tier_w <= point.x)
/*     */       return -1; 
/*     */     for (i = 0; i < se[0]; i++)
/*     */       x += cm.getColumn(i).getWidth(); 
/* 560 */     return cm.getColumnIndexAtX(x); } private int viewIndexForColumn(TableColumn aColumn) { MCTable2ColumnModel mCTable2ColumnModel = getColumnModel();
/* 561 */     for (int column = 0; column < mCTable2ColumnModel.getColumnCount(); column++) {
/* 562 */       if (mCTable2ColumnModel.getColumn(column) == aColumn) {
/* 563 */         return column;
/*     */       }
/*     */     } 
/* 566 */     return -1; }
/*     */   public Rectangle getCellRect(int row, int column, boolean includeSpacing) { MCTable2ColumnModel colmodel = getColumnModel(); Rectangle r = new Rectangle(); boolean valid = true; int[] retpos = colmodel.getReturnPositions(); if (row < 0) { valid = false; } else if (row >= getRowCount()) { r.y = getHeight(); valid = false; } else { r.height = getRowHeight(row); SizeSequence rowModel = getRowModel(); r.y = (rowModel == null) ? (row * r.height) : rowModel.getPosition(row); r.y *= retpos.length; }  if (column < 0) { valid = false; } else if (column >= colmodel.getColumnCount()) { r.x = getWidth(); valid = false; } else { int fixcnt = colmodel.getFixedColumnCount(); int tier = 0; for (int i = 0; i < column; i++) { if (i >= retpos[tier] - fixcnt) { tier++; r.x = 0; r.y += getRowHeightNE(row); } else { r.x += colmodel.getColumn(i).getWidth(); }  }
/*     */        r.width = colmodel.getColumn(column).getWidth(); }
/*     */      if (valid && !includeSpacing) { int rm = Math.min(getRowMargin(), r.height); int cm = Math.min(colmodel.getColumnMargin(), r.width); r.setBounds(r.x + cm / 2, r.y + rm / 2, r.width - cm, r.height - rm); }
/* 570 */      return r; } private void accommodateDelta(int resizingColumnIndex, int delta) { MCTable2ColumnModel cm = getColumnModel();
/* 571 */     int from = resizingColumnIndex;
/* 572 */     int to = 0;
/* 573 */     int columnCount = 0;
/* 574 */     int[] retpos = cm.getReturnPositions();
/* 575 */     int fixcnt = cm.getFixedColumnCount();
/* 576 */     for (int tier = 0; tier < retpos.length; tier++) {
/* 577 */       columnCount = retpos[tier] + 1 - fixcnt;
/* 578 */       if (resizingColumnIndex < columnCount) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */     
/* 583 */     switch (this.autoResizeMode) {
/*     */       case 1:
/* 585 */         from++;
/* 586 */         to = Math.min(from + 1, columnCount);
/*     */         break;
/*     */       case 2:
/* 589 */         from++;
/* 590 */         to = columnCount;
/*     */         break;
/*     */       case 3:
/* 593 */         from = columnCount - 1;
/* 594 */         to = from + 1;
/*     */         break;
/*     */       case 4:
/* 597 */         from = 0;
/* 598 */         to = columnCount;
/*     */         break;
/*     */ 
/*     */       
/*     */       default:
/*     */         return;
/*     */     } 
/*     */     
/* 606 */     int start = from;
/* 607 */     int end = to;
/* 608 */     Object object = new Object(this, end, start, cm);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 616 */     int totalWidth = 0;
/* 617 */     for (int i = from; i < to; i++) {
/* 618 */       MCTableColumn mCTableColumn = cm.getColumn(i);
/* 619 */       int input = mCTableColumn.getWidth();
/* 620 */       totalWidth += input;
/*     */     } 
/*     */     
/* 623 */     adjustSizes((totalWidth + delta), (Resizable3)object, false, start, end); }
/*     */ 
/*     */   
/*     */   private void setWidthsFromPreferredWidths(boolean inverse) {
/* 627 */     MCTable2ColumnModel cm = getColumnModel();
/* 628 */     Object object = new Object(this, cm, inverse);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 650 */     MCTableColumn[] cols = getTableColumns();
/* 651 */     int retcnt = cm.getReturnCount();
/* 652 */     for (int tier = 0; tier < retcnt; tier++) {
/* 653 */       int totalWidth = 0;
/* 654 */       int totalPreferred = 0;
/* 655 */       int[] se = cm.getTierColumnIndex(tier);
/* 656 */       for (int i = se[0]; i < se[1]; i++) {
/* 657 */         totalWidth += cols[i].getWidth();
/* 658 */         totalPreferred += cols[i].getPreferredWidth();
/*     */       } 
/* 660 */       int target = !inverse ? totalWidth : totalPreferred;
/*     */       
/* 662 */       adjustSizes(target, (Resizable3)object, inverse, se[0], se[1]);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void adjustSizes(long target, Resizable3 r3, boolean inverse, int s, int e) {
/* 667 */     Object object2, object1 = new Object(this, r3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 674 */     long totalPreferred = getColumnModel().calcWidth((MCTable2ColumnModel.WidthSupplier)object1);
/*     */ 
/*     */     
/* 677 */     if (((target < totalPreferred) ? true : false) == (inverse ? false : true)) {
/* 678 */       object2 = new Object(this, r3);
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */       
/* 686 */       object2 = new Object(this, r3);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 693 */     adjustSizes(target, (Resizable2)object2, !inverse, s, e);
/*     */   }
/*     */   
/*     */   private void adjustSizes(long target, Resizable2 r, boolean limitToRange, int s, int e) {
/* 697 */     long totalLowerBound = 0L;
/* 698 */     long totalUpperBound = 0L;
/* 699 */     for (int i = s; i < e; i++) {
/* 700 */       totalLowerBound += r.getLowerBoundAt(i);
/* 701 */       totalUpperBound += r.getUpperBoundAt(i);
/*     */     } 
/*     */     
/* 704 */     long rTarget = limitToRange ? 
/* 705 */       Math.min(Math.max(totalLowerBound, target), totalUpperBound) : 
/* 706 */       target;
/*     */     
/* 708 */     for (int j = s; j < e; j++) {
/* 709 */       int newSize, lowerBound = r.getLowerBoundAt(j);
/* 710 */       int upperBound = r.getUpperBoundAt(j);
/*     */ 
/*     */       
/* 713 */       if (totalLowerBound == totalUpperBound) {
/* 714 */         newSize = lowerBound;
/*     */       } else {
/*     */         
/* 717 */         double f = (rTarget - totalLowerBound) / (totalUpperBound - totalLowerBound);
/* 718 */         newSize = (int)Math.round(lowerBound + f * (upperBound - lowerBound));
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 723 */       r.setSizeAt(newSize, j);
/* 724 */       rTarget -= newSize;
/* 725 */       totalLowerBound -= lowerBound;
/* 726 */       totalUpperBound -= upperBound;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\table\MCTable2.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */