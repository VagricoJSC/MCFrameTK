/*     */ package META-INF.versions.21.mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.util.List;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.border.Border;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCMode;
/*     */ import mcframe.clientCore.beans.MCPasswordField;
/*     */ import mcframe.clientCore.beans.MCResourceBeans;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.action.MCKeyActionManager;
/*     */ import mcframe.clientCore.beans.popup.MCPopupConfig;
/*     */ import mcframe.clientCore.beans.popup.MCPopupMenu;
/*     */ import mcframe.clientCore.beans.table.MCCellUtil;
/*     */ import mcframe.clientCore.beans.table.MCColumnConfig;
/*     */ import mcframe.clientCore.beans.table.MCEditorBeans;
/*     */ import mcframe.clientCore.beans.table.MCTable;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.clientCore.event.MCEventInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCEditorPasswordField
/*     */   extends MCPasswordField
/*     */   implements MCEditorBeans
/*     */ {
/*     */   private static final String TYPE = "table.column.password";
/*     */   private MCColumnConfig _column;
/*     */   private MCTable<?> _table;
/*     */   
/*     */   @Deprecated
/*     */   protected MCEditorPasswordField(String name, MCColumnConfig column) {
/*  65 */     super(name);
/*  66 */     setColumnConfig(column);
/*  67 */     setTable(column.getBaseTable());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getType() {
/*  72 */     return "table.column.password";
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initBeans() {
/*  77 */     super.initBeans();
/*     */ 
/*     */     
/*  80 */     setFocusTraversalKeysEnabled(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initKeyAssign() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initResource() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setColumnConfig(MCColumnConfig column) {
/* 111 */     this._column = column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCColumnConfig getColumnConfig() {
/* 123 */     return this._column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setTable(MCTable<?> table) {
/* 134 */     this._table = table;
/*     */   }
/*     */ 
/*     */   
/*     */   public final MCTable getTable() {
/* 139 */     return this._table;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getRowIndex() {
/* 145 */     return MCCellUtil.getRowIndex(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void transferFocus() {
/* 150 */     MCTable<?> t = getTable();
/* 151 */     t.transferFocus(getRowIndex(), t.getViewColumn(getColumnConfig()) + 1, false, 
/* 152 */         true, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public Border getDefaultBorder() {
/* 157 */     return MCCellUtil.DEFAULT_BORDER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setColumnInfo(int index, MCColumnConfig column) {
/* 169 */     setColumnConfig(column);
/* 170 */     MCTable<?> table = getTable();
/* 171 */     MCKeyActionManager.init((MCResourceBeans)this, getInputMap(), getActionMap());
/* 172 */     MCKeyActionManager.initScreen((MCResourceBeans)this, getInputMap(), getActionMap());
/* 173 */     MCMode mode = MCCellUtil.isCellEditable(index, column, table);
/* 174 */     setMode(mode);
/* 175 */     setForeground(MCCellUtil.getForeground(index, column, table, false, mode));
/* 176 */     setBackground(MCCellUtil.getBackground(index, column, table, false, mode));
/* 177 */     setFont(column.getFont());
/* 178 */     setCaretColor(MCCellUtil.getCaretColor(index, column, table));
/* 179 */     setSelectionColor(MCCellUtil.getSelectionColor(index, column, table));
/* 180 */     setSelectedTextColor(MCCellUtil.getSelectedTextColor(index, column, table));
/* 181 */     setMeta(column.getMeta());
/* 182 */     setLength(column.getLength(index));
/* 183 */     setEchoChar(column.getEchoChar());
/* 184 */     setRow(column.getTable().getRow(index), column.getRowColumnName());
/*     */     
/* 186 */     setAutoFocus(column.isAutoFocus());
/* 187 */     setSelectAll(column.isSelectAll());
/* 188 */     setTrimPattern(column.getTrimPattern());
/* 189 */     Border border = MCCellUtil.getEditorBorder(index, column, table);
/* 190 */     if (border != null) {
/* 191 */       setBorder(border);
/*     */     } else {
/*     */       
/* 194 */       setBorder(getDefaultBorder());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setDummyColumnInfo(MCColumnConfig column, MCConstRow dummy) {
/* 205 */     setColumnConfig(column);
/* 206 */     MCKeyActionManager.init((MCResourceBeans)this, getInputMap(), getActionMap());
/* 207 */     MCKeyActionManager.initScreen((MCResourceBeans)this, getInputMap(), getActionMap());
/* 208 */     setMeta(column.getMeta());
/* 209 */     setLength(column.getLength());
/*     */     
/* 211 */     if (dummy.contains(column.getBaseRowColumnName())) {
/* 212 */       setRow(dummy, column.getBaseRowColumnName());
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 219 */       setRow((MCConstRow)column.getTable().getList().createRow(), 
/* 220 */           column.getRowColumnName());
/*     */     } 
/*     */     
/* 223 */     setAutoFocus(false);
/* 224 */     setSelectAll(false);
/* 225 */     setTrimPattern(column.getTrimPattern());
/*     */   }
/*     */   
/*     */   public MCRootPanel getRootPanel() {
/* 229 */     return MCCellUtil.getRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCRootPanel getNearestRootPanel() {
/* 234 */     return MCCellUtil.getNearestRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessageByLocale() {
/* 239 */     return getColumnConfig().getMessageByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLabelByLocale() {
/* 244 */     return getColumnConfig().getLabelByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterRequestFocus() {
/* 249 */     MCRootPanel bp = getBaseRootPanel();
/* 250 */     MCBeansUtil.afterRequestFocus(bp, (JComponent)getTable());
/* 251 */     MCBeansUtil.scrollRectToVisible(bp, (JComponent)this, getHorizontalAlignment());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 256 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void commitValue() {}
/*     */ 
/*     */   
/*     */   public boolean isFocusOwner() {
/* 265 */     MCTable<?> t = getTable();
/* 266 */     return (t != null) ? (t.isRemoveNotifyProcessing() ? super.isFocusOwner() : false) : 
/* 267 */       super.isFocusOwner();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValueChanged() {
/* 272 */     return isValueChanged(getRowValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValueChanged(Comparable<?> value) {
/* 286 */     return isValueChanged(getValue(), value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isValueChanged(Comparable<?> view, Comparable<?> row) {
/* 292 */     if (isInputMethodEditing()) {
/* 293 */       return true;
/*     */     }
/*     */     
/* 296 */     return MCCellUtil.isValueChanged(this, view, row);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void valueCommited() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean doVC() {
/* 306 */     return getColumnConfig().doVC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNC() {
/* 311 */     getColumnConfig().doNC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNE() {
/* 316 */     getColumnConfig().doNE();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNX() {
/* 321 */     getColumnConfig().doNX();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doDC() {
/* 326 */     getColumnConfig().doDC();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isMCFocusOwner() {
/* 331 */     MCTable<?> t = getTable();
/* 332 */     return (t != null) ? ((t.getMCEditorComponent() == this)) : isFocusOwner();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCEventInfo getEventInfo() {
/* 337 */     return getColumnConfig().getEventInfo();
/*     */   }
/*     */ 
/*     */   
/*     */   public void focusGained() {
/* 342 */     focusGainedSelect();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void focusLost() {}
/*     */ 
/*     */   
/*     */   public boolean isRequestFocusEnabled() {
/* 351 */     return (MCCellUtil.isRequestFocusEnabled(this) && super.isRequestFocusEnabled());
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isMCRequestFocusEnabled() {
/* 356 */     return MCCellUtil.isFocusable(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public Border getBorder() {
/* 361 */     Border b = MCCellUtil.getBorder(this);
/* 362 */     return (b != null) ? b : super.getBorder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource(MCRootPanel panel) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doCheckValueError() {
/* 387 */     super.doCheckValueError();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCPopupConfig getPopupConfig() {
/* 392 */     MCTable<?> t = getTable();
/* 393 */     return (t != null) ? t.getPopupConfig() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCPopupMenu configurePopup(MCPopupMenu menu) {
/* 407 */     MCPopupConfig pc = getPopupConfig();
/* 408 */     return (pc != null) ? 
/* 409 */       pc.configurePopup(menu, getTable(), getRowIndex(), getColumnConfig()) : 
/* 410 */       menu;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void processKeyEvent(KeyEvent e) {
/* 415 */     MCCellUtil.beforeKeyEvent(e, this);
/* 416 */     super.processKeyEvent(e);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Pattern> getAcceptPattern() {
/* 421 */     return getColumnConfig().getAcceptPattern();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Character> getExceptCharacter() {
/* 426 */     return getColumnConfig().getExceptCharacter();
/*     */   }
/*     */ 
/*     */   
/*     */   public Comparable<?> doListFormat(Comparable<?> value) {
/* 431 */     return getColumnConfig().doListFormat(getRowIndex(), value);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\table\MCEditorPasswordField.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */