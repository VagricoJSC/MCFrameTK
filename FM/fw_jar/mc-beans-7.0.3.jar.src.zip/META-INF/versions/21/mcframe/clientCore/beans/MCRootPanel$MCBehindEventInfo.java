package META-INF.versions.21.mcframe.clientCore.beans;

import mcframe.clientCore.beans.MCRootPanel;

public abstract class MCBehindEventInfo {
  protected abstract void doBehindEvent();
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\MCRootPanel$MCBehindEventInfo.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */