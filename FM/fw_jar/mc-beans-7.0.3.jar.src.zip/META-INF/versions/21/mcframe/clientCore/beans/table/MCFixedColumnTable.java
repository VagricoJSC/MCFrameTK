/*     */ package META-INF.versions.21.mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Point;
/*     */ import java.awt.event.MouseEvent;
/*     */ import javax.swing.ListSelectionModel;
/*     */ import javax.swing.table.TableCellRenderer;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableModel;
/*     */ import mcframe.clientCore.beans.MCMode;
/*     */ import mcframe.clientCore.beans.MCModeInfo;
/*     */ import mcframe.clientCore.beans.table.MCCellConfig;
/*     */ import mcframe.clientCore.beans.table.MCColumnConfig;
/*     */ import mcframe.clientCore.beans.table.MCColumnType;
/*     */ import mcframe.clientCore.beans.table.MCInfraCellRenderer;
/*     */ import mcframe.clientCore.beans.table.MCListSelectionModel;
/*     */ import mcframe.clientCore.beans.table.MCPlainRowNumberCellRenderer;
/*     */ import mcframe.clientCore.beans.table.MCRowNumberCellRenderer;
/*     */ import mcframe.clientCore.beans.table.MCRowSignal;
/*     */ import mcframe.clientCore.beans.table.MCRowSignalCellRenderer;
/*     */ import mcframe.clientCore.beans.table.MCStatusCellRenderer;
/*     */ import mcframe.clientCore.beans.table.MCTable;
/*     */ import mcframe.clientCore.beans.table.MCTableColumn;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCFixedColumnTable<E extends MCConstRow>
/*     */   extends MCTable<E>
/*     */ {
/*     */   static final String NAME_ROW_NUMBER = "row number";
/*     */   static final String NAME_ROW_STATUS = "row status";
/*     */   static final String NAME_ROW_SIGNAL = "row signal";
/*     */   static final int INFRA_COLUMN_COUNT = 3;
/*     */   
/*     */   private static MCInfraCellRenderer getRowNumberCellRenderer(MCColumnConfig column) {
/*  42 */     String type = MCConst.beans.getString(MCConst.createKey(new String[] {
/*     */             
/*  44 */             "table", "rownumber", "type" }));
/*  45 */     if ("plain".equals(type)) {
/*  46 */       return (MCInfraCellRenderer)new MCPlainRowNumberCellRenderer(column);
/*     */     }
/*  48 */     return (MCInfraCellRenderer)new MCRowNumberCellRenderer(column);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  59 */   final MCTableColumn number = new MCTableColumn("row number", MCColumnType.NULL);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final MCTableColumn status;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final MCTableColumn signal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean _dragging;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   MCFixedColumnTable(MCTable<E> table, String name) {
/* 110 */     super(table, name);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     this.number.setHeaderValue(" ");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     this.number.setCellRenderer((TableCellRenderer)getRowNumberCellRenderer((MCColumnConfig)this.number));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     this.number.setCellEditor(null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     this.number.setToolTipEnabled(false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     this.status = new MCTableColumn("row status", MCColumnType.NULL);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     this.status.setHeaderValue(" ");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     this.status.setCellRenderer((TableCellRenderer)new MCStatusCellRenderer((MCColumnConfig)this.status));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     this.status.setCellEditor(null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     this.status.setToolTipEnabled(false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     this.signal = new MCTableColumn("row signal", MCColumnType.NULL);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     this.signal.setHeaderValue(" ");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     this.signal.setCellRenderer((TableCellRenderer)new MCRowSignalCellRenderer((MCColumnConfig)this.signal));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     this.signal.setCellEditor(null);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     this.signal.setToolTipEnabled(false);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 278 */     this._dragging = false; this._fixed = this;
/*     */     this._body = table;
/*     */     setModel((TableModel)table.getModel());
/*     */     setSelectionModel((ListSelectionModel)new MCListSelectionModel(this));
/* 282 */     getTableHeader().setReorderingAllowed(false); } protected void processMouseMotionEvent(MouseEvent e) { if (e.getID() == 506) {
/* 283 */       this._dragging = true;
/* 284 */       Point p = e.getPoint();
/* 285 */       int idx = columnAtPoint(p);
/* 286 */       if (idx >= 0) {
/* 287 */         super.processMouseMotionEvent(e);
/*     */       }
/*     */     } else {
/*     */       
/* 291 */       super.processMouseMotionEvent(e);
/*     */     }  }
/*     */ 
/*     */   
/*     */   boolean isInfraColumn(MCColumnConfig column) {
/*     */     return !(column != this.number && column != this.status && column != this.signal);
/*     */   }
/*     */   
/*     */   public MCRowSignal getRowSignal() {
/*     */     return ((MCRowSignalCellRenderer)this.signal.getCellRenderer()).getRowSignal();
/*     */   }
/*     */   
/*     */   boolean isFixedColumnTable() {
/*     */     return true;
/*     */   }
/*     */   
/*     */   void addColumn(MCTableColumn c) {
/*     */     super.addColumn(c);
/*     */     adjustTableWidth();
/*     */   }
/*     */   
/*     */   public void addColumn(TableColumn c) {
/*     */     super.addColumn(c);
/*     */     adjustTableWidth();
/*     */   }
/*     */   
/*     */   void adjustTableWidth() {
/*     */     int w = getColumnModel().getTotalColumnWidth();
/*     */     setPreferredScrollableViewportSize(new Dimension(w, (getSize()).height));
/*     */   }
/*     */   
/*     */   MCTableColumn[] getAppTableColumns() {
/*     */     getColumns();
/*     */     int cnt = getColumnCount() - getModel().getInfraColumnCount();
/*     */     if (cnt < 0)
/*     */       cnt = 0; 
/*     */     MCTableColumn[] a = new MCTableColumn[cnt];
/*     */     int i = 0;
/*     */     byte b;
/*     */     int j;
/*     */     MCTableColumn[] arrayOfMCTableColumn1;
/*     */     for (j = (arrayOfMCTableColumn1 = getTableColumns()).length, b = 0; b < j; ) {
/*     */       MCTableColumn c = arrayOfMCTableColumn1[b];
/*     */       if (!isInfraColumn((MCColumnConfig)c))
/*     */         a[i++] = c; 
/*     */       b++;
/*     */     } 
/*     */     return a;
/*     */   }
/*     */   
/*     */   MCTableColumn[] getTableColumns() {
/*     */     return super.getTableColumns();
/*     */   }
/*     */   
/*     */   boolean isBodyTable() {
/*     */     return false;
/*     */   }
/*     */   
/*     */   public Comparable<?> getValue(int index, MCColumnConfig column) {
/*     */     if (!isInfraColumn(column))
/*     */       return super.getValue(index, column); 
/*     */     int v = getViewColumn(column);
/*     */     return ((MCInfraCellRenderer)getCellRenderer(index, v)).getValue();
/*     */   }
/*     */   
/*     */   public MCMode isCellEditable(int index, MCColumnConfig column) {
/*     */     return !isInfraColumn(column) ? super.isCellEditable(index, column) : MCMode.DISABLE;
/*     */   }
/*     */   
/*     */   public MCCellConfig getCellConfig() {
/*     */     return getBodyTable().getCellConfig();
/*     */   }
/*     */   
/*     */   public boolean isEnabled() {
/*     */     MCTable<E> t = getBodyTable();
/*     */     return (t != null && t != this) ? t.isEnabled() : super.isEnabled();
/*     */   }
/*     */   
/*     */   public boolean isVisible() {
/*     */     MCTable<E> t = getBodyTable();
/*     */     return (t != null && t != this) ? t.isVisible() : super.isVisible();
/*     */   }
/*     */   
/*     */   public boolean isFocusable() {
/*     */     MCTable<E> t = getBodyTable();
/*     */     return (t != null && t != this) ? t.isFocusable() : super.isFocusable();
/*     */   }
/*     */   
/*     */   public MCMode getMode() {
/*     */     MCTable<E> t = getBodyTable();
/*     */     return (t != null && t != this) ? t.getMode() : super.getMode();
/*     */   }
/*     */   
/*     */   public MCModeInfo getModeInfo() {
/*     */     MCTable<E> t = getBodyTable();
/*     */     return (t != null && t != this) ? t.getModeInfo() : super.getModeInfo();
/*     */   }
/*     */   
/*     */   public MCModeInfo getModeInfo(MCMode mode) {
/*     */     MCTable<E> t = getBodyTable();
/*     */     return (t != null && t != this) ? t.getModeInfo(mode) : super.getModeInfo(mode);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\table\MCFixedColumnTable.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */