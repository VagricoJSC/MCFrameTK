/*     */ package META-INF.versions.21.mcframe.clientCore.beans.combobox;
/*     */ 
/*     */ import mcframe.clientCore.beans.combobox.MCTimestampComboBox;
/*     */ import mcframe.clientCore.beans.text.MCTimestampFormat;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCCalendarDate;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.lang.MCTimestamp;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class null
/*     */   implements Runnable
/*     */ {
/*     */   public void run() {
/* 181 */     if (!"list".equals(MCTimestampComboBox.this.getListConfig().getOpeType())) {
/*     */       return;
/*     */     }
/* 184 */     MCRow o = MCTimestampComboBox.this.getModel().getSelectedRow();
/* 185 */     if (o != null) {
/* 186 */       MCTimestampFormat f = MCTimestampComboBox.this.getCalendarFormat();
/* 187 */       String m = f.doInputFormat((MCCalendarDate)o.getTimestamp(MCTimestampComboBox.this.getKeyColumnName()));
/*     */       
/* 189 */       MCTimestamp ts = null;
/*     */       try {
/* 191 */         ts = (MCTimestamp)MCTimestampComboBox.this.getValue();
/*     */       }
/* 193 */       catch (MCException mCException) {
/* 194 */         MCTimestampComboBox.this.doIncrementalSearch();
/*     */         return;
/*     */       } 
/* 197 */       String v = f.doInputFormat((MCCalendarDate)ts);
/*     */ 
/*     */       
/* 200 */       if (MCStringUtil.eq(m, v)) {
/*     */         return;
/*     */       }
/*     */     } 
/* 204 */     MCTimestampComboBox.this.doIncrementalSearch();
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\combobox\MCTimestampComboBox$1.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */