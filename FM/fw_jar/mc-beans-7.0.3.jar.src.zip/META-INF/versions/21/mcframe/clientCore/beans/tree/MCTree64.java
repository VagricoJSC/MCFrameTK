/*     */ package META-INF.versions.21.mcframe.clientCore.beans.tree;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Cursor;
/*     */ import java.awt.Point;
/*     */ import java.awt.datatransfer.DataFlavor;
/*     */ import java.awt.datatransfer.Transferable;
/*     */ import java.awt.datatransfer.UnsupportedFlavorException;
/*     */ import java.awt.dnd.DragGestureEvent;
/*     */ import java.awt.dnd.DragGestureListener;
/*     */ import java.awt.dnd.DragGestureRecognizer;
/*     */ import java.awt.dnd.DragSource;
/*     */ import java.awt.dnd.DragSourceDragEvent;
/*     */ import java.awt.dnd.DragSourceDropEvent;
/*     */ import java.awt.dnd.DragSourceEvent;
/*     */ import java.awt.dnd.DragSourceListener;
/*     */ import java.awt.dnd.DropTarget;
/*     */ import java.awt.dnd.DropTargetDragEvent;
/*     */ import java.awt.dnd.DropTargetDropEvent;
/*     */ import java.awt.dnd.DropTargetEvent;
/*     */ import java.awt.dnd.DropTargetListener;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.util.Enumeration;
/*     */ import javax.swing.JTree;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.event.TreeExpansionEvent;
/*     */ import javax.swing.event.TreeExpansionListener;
/*     */ import javax.swing.tree.DefaultMutableTreeNode;
/*     */ import javax.swing.tree.MutableTreeNode;
/*     */ import javax.swing.tree.TreeCellRenderer;
/*     */ import javax.swing.tree.TreeNode;
/*     */ import javax.swing.tree.TreePath;
/*     */ import mcframe.clientCore.beans.MCScrollPane;
/*     */ import mcframe.clientCore.beans.tree.MCTree;
/*     */ import mcframe.clientCore.beans.tree.MCTree64Delegate;
/*     */ import mcframe.clientCore.beans.tree.MCTreeModel;
/*     */ import mcframe.clientCore.beans.tree.MCTreeModel64;
/*     */ import mcframe.clientCore.beans.tree.MCTreeNode;
/*     */ import mcframe.clientCore.beans.tree.MCTreeTransferableHolder;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.clientCore.container.MCRowEvent;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCTree64<E2 extends MCConstRow>
/*     */   extends MCTree
/*     */   implements TreeExpansionListener, DragSourceListener, DropTargetListener, DragGestureListener
/*     */ {
/*     */   public MCTree64Delegate delegate64;
/*     */   protected boolean _enableDragAndDrop = true;
/*     */   public boolean isMultiSelection = false;
/*     */   protected static DataFlavor localObjectFlavor;
/*  71 */   protected String saveTreeState = "";
/*     */ 
/*     */   
/*     */   static {
/*     */     try {
/*  76 */       localObjectFlavor = new DataFlavor("application/x-java-jvm-local-objectref");
/*  77 */     } catch (ClassNotFoundException cnfe) {
/*     */       
/*  79 */       cnfe.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*  84 */   protected static DataFlavor[] supportedFlavors = new DataFlavor[] { localObjectFlavor };
/*     */   
/*     */   protected DragGestureRecognizer dgr;
/*     */   protected DragSource dragSource;
/*     */   protected DropTarget dropTarget;
/*  89 */   protected MCTreeNode<?> dropTargetNode = null; protected boolean isMultiSelectionDebug; protected int modifiers;
/*  90 */   protected MCTreeNode<?> draggedNode = null;
/*     */   protected final void init64() { if (this._enableDragAndDrop) { setCellRenderer((TreeCellRenderer)new MCTreeCellRenderer(this)); this.dragSource = new DragSource(); this.dgr = this.dragSource.createDefaultDragGestureRecognizer((Component)this, 2, this); this.dropTarget = new DropTarget((Component)this, this); }  this.saveTreeState = getExpansionState((JTree)this); addTreeExpansionListener(this); if (this.isMultiSelectionDebug)
/*     */       getSelectionModel().setSelectionMode(2);  }
/*  93 */   public void disableDragAndDrop() { this._enableDragAndDrop = false; this.dragSource.removeDragSourceListener(this); this.dragSource = null; this.dgr.removeDragGestureListener(this); this.dgr = null; this.dropTarget.removeDropTargetListener(this); this.dropTarget = null; } public Cursor defaultCursor = null; public boolean getEnableDragAndDrop() { return this._enableDragAndDrop; }
/*     */   protected void processMouseEvent(MouseEvent e) { if (e.getID() == 501 && SwingUtilities.isLeftMouseButton(e)) { TreePath pressed_treepath = getPathForLocation(e.getX(), e.getY()); MCScrollPane p = getScrollPane(); if (pressed_treepath != null) {
/*     */         p.setDragScrollEnabled(false);
/*     */       } else {
/*     */         p.setDragScrollEnabled(true);
/*     */       }  }
/*     */      super.processMouseEvent(e); }
/*     */   public void dragGestureRecognized(DragGestureEvent dge) { if (this.dragSource == null)
/*     */       return;  Point clickPoint = dge.getDragOrigin(); TreePath path = getPathForLocation(clickPoint.x, clickPoint.y); if (path == null)
/*     */       return;  this.draggedNode = (MCTreeNode)path.getLastPathComponent(); MCTreeTransferableHolder holder = new MCTreeTransferableHolder(this, this.draggedNode); MCTreeTransferable mCTreeTransferable = new MCTreeTransferable(this, holder); this.dragSource.startDrag(dge, this.defaultCursor, (Transferable)mCTreeTransferable, this); }
/* 103 */   @Deprecated public MCTree64(String name, boolean enable) { super(name);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 109 */     this.isMultiSelectionDebug = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 222 */     this.modifiers = 0; setModel((MCTreeModel)new MCTreeModel64()); this._enableDragAndDrop = enable; init64(); } public void dragDropEnd(DragSourceDropEvent dsde) { if (this.dropTargetNode != null || this.draggedNode != null) { this.dropTargetNode = null; this.draggedNode = null; repaintTree(); }  } protected void repaintTree() { repaint(); } public void dragExit(DragSourceEvent dse) {} public void dragExit(DropTargetEvent dte) {}
/*     */   public void dropActionChanged(DropTargetDragEvent dtde) {}
/* 224 */   public void dragEnter(DragSourceDragEvent dsde) { this.modifiers = dsde.getGestureModifiersEx(); }
/*     */   
/*     */   public void dragOver(DragSourceDragEvent dsde) {
/* 227 */     this.modifiers = dsde.getGestureModifiersEx();
/*     */   }
/*     */   
/*     */   public void dropActionChanged(DragSourceDragEvent dsde) {
/* 231 */     this.modifiers = dsde.getGestureModifiersEx();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isModifyDown() {
/* 239 */     boolean isModifyDown = false;
/*     */     
/* 241 */     int mask = 512;
/* 242 */     if ((this.modifiers & mask) == mask)
/*     */     {
/* 244 */       isModifyDown = true;
/*     */     }
/*     */     
/* 247 */     return isModifyDown;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void dragEnter(DropTargetDragEvent dtde) {
/* 253 */     dtde.acceptDrag(3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dragOver(DropTargetDragEvent dtde) {
/*     */     Object droppedObject;
/* 261 */     Point dragPoint = dtde.getLocation();
/* 262 */     TreePath path = getPathForLocation(dragPoint.x, dragPoint.y);
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 267 */       droppedObject = dtde.getTransferable().getTransferData(localObjectFlavor);
/*     */     }
/* 269 */     catch (UnsupportedFlavorException|java.io.IOException unsupportedFlavorException) {
/* 270 */       droppedObject = null;
/*     */     } 
/*     */     
/* 273 */     mcframe.clientCore.beans.tree.MCTree64<?> dragTree = null;
/* 274 */     MCTreeNode<?> dragNode = null;
/*     */ 
/*     */     
/* 277 */     int type = 1;
/*     */     
/* 279 */     if (path != null) {
/* 280 */       MCTreeNode<E2> targetNode = (MCTreeNode<E2>)path.getLastPathComponent();
/* 281 */       if (targetNode != this.dropTargetNode) {
/* 282 */         this.dropTargetNode = (MCTreeNode)path.getLastPathComponent();
/* 283 */         repaintTree();
/*     */       } 
/*     */ 
/*     */       
/* 287 */       if (!(droppedObject instanceof MCTreeTransferableHolder)) {
/* 288 */         path = null;
/*     */       } else {
/* 290 */         MCTreeTransferableHolder holder = (MCTreeTransferableHolder)droppedObject;
/* 291 */         dragTree = holder.draggedTree;
/* 292 */         dragNode = holder.draggedNode;
/* 293 */         boolean isModifyDown = isModifyDown();
/* 294 */         MCTreeNode<?> dropNode = (MCTreeNode)path.getLastPathComponent();
/* 295 */         if (dropNode.isLeaf() && !isModifyDown) {
/* 296 */           type = 1;
/*     */         } else {
/* 298 */           type = 2;
/*     */         } 
/*     */         
/* 301 */         if (!canMoveNode(type, dragTree, dropNode, this, dragNode)) {
/* 302 */           canMoveNode(type, dragTree, dropNode, this, dragNode);
/* 303 */           path = null;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 309 */     if (this.delegate64 != null)
/*     */     {
/* 311 */       if (path == null) {
/*     */         
/* 313 */         this.delegate64.changeNode(0, null, null, this, this.dropTargetNode);
/*     */ 
/*     */       
/*     */       }
/* 317 */       else if (!(droppedObject instanceof MCTreeTransferableHolder)) {
/*     */         
/* 319 */         this.delegate64.changeNode(0, null, null, this, this.dropTargetNode);
/*     */       } else {
/* 321 */         this.delegate64.changeNode(type, dragTree, dragNode, this, this.dropTargetNode);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void rejectDrop(DropTargetDropEvent dtde) {
/* 328 */     dtde.rejectDrop();
/* 329 */     this.dropTargetNode = null;
/* 330 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void drop(DropTargetDropEvent dtde) {
/* 336 */     Point dropPoint = dtde.getLocation();
/* 337 */     TreePath path = getPathForLocation(dropPoint.x, dropPoint.y);
/*     */ 
/*     */     
/* 340 */     if (path == null) {
/*     */       return;
/*     */     }
/*     */     
/* 344 */     MCTreeNode<?> dropNode = (MCTreeNode)path.getLastPathComponent();
/*     */     
/* 346 */     boolean dropped = false;
/* 347 */     dtde.acceptDrop(2);
/* 348 */     Object droppedObject = null;
/*     */     
/*     */     try {
/* 351 */       droppedObject = dtde.getTransferable().getTransferData(localObjectFlavor);
/* 352 */     } catch (UnsupportedFlavorException|java.io.IOException unsupportedFlavorException) {
/*     */       return;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 359 */     if (!(droppedObject instanceof MCTreeTransferableHolder)) {
/* 360 */       dtde.dropComplete(false);
/* 361 */       rejectDrop(dtde);
/*     */       
/*     */       return;
/*     */     } 
/* 365 */     MCTreeTransferableHolder holder = (MCTreeTransferableHolder)droppedObject;
/*     */     
/* 367 */     mcframe.clientCore.beans.tree.MCTree64<?> dragTree = holder.draggedTree;
/* 368 */     MCTreeNode<?> dragNode = holder.draggedNode;
/*     */     
/* 370 */     boolean isModifyDown = isModifyDown();
/*     */     
/* 372 */     int type = 1;
/* 373 */     if (dropNode.isLeaf() && !isModifyDown) {
/* 374 */       type = 1;
/*     */     } else {
/* 376 */       type = 2;
/*     */     } 
/*     */ 
/*     */     
/* 380 */     if (!canMoveNode(type, dragTree, dropNode, this, dragNode)) {
/* 381 */       dtde.dropComplete(false);
/* 382 */       rejectDrop(dtde);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 387 */     MCTreeNode<E2> oldParentNode = (MCTreeNode<E2>)dragNode.getParent();
/*     */ 
/*     */     
/* 390 */     dragTree.getModel().removeNodeFromParent((MutableTreeNode)dragNode);
/*     */     
/* 392 */     if (type == 1) {
/*     */       
/* 394 */       DefaultMutableTreeNode parent = (DefaultMutableTreeNode)dropNode.getParent();
/* 395 */       int idx = parent.getIndex((TreeNode)dropNode);
/* 396 */       getModel().insertNodeInto((MutableTreeNode)dragNode, parent, idx);
/*     */     } else {
/*     */       
/* 399 */       int idx = dropNode.getChildCount();
/* 400 */       getModel().insertNodeInto((MutableTreeNode)dragNode, (MutableTreeNode)dropNode, idx);
/*     */       
/* 402 */       TreePath treePath = new TreePath((Object[])dropNode.getPath());
/* 403 */       expandPath((JTree)this, treePath);
/*     */     } 
/*     */ 
/*     */     
/* 407 */     treePathChanged(type, this, dragTree, dragNode, oldParentNode, dropNode);
/*     */ 
/*     */     
/* 410 */     TreePath newPath = new TreePath((Object[])dropNode.getPath());
/*     */     
/* 412 */     scrollPathToVisible(newPath);
/* 413 */     setSelectionPath(newPath);
/*     */     
/* 415 */     dropped = true;
/* 416 */     dtde.dropComplete(dropped);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean canMoveNode(int type, MCTree<?> dropTree, MCTreeNode<?> dropNode, MCTree<?> droppedTree, MCTreeNode<?> droppedNode) {
/* 431 */     if (dropNode == droppedNode) {
/* 432 */       return false;
/*     */     }
/*     */     
/* 435 */     boolean canMove = true;
/*     */     
/* 437 */     DefaultMutableTreeNode parent = (DefaultMutableTreeNode)dropNode.getParent(); byte b; int i; TreeNode[] arrayOfTreeNode;
/* 438 */     for (i = (arrayOfTreeNode = parent.getPath()).length, b = 0; b < i; ) { Object p = arrayOfTreeNode[b];
/* 439 */       if (p == droppedNode) {
/* 440 */         canMove = false;
/*     */       }
/*     */       b++; }
/*     */     
/* 444 */     if (canMove && 
/* 445 */       this.delegate64 != null) {
/* 446 */       canMove = this.delegate64.canMoveNode(type, dropTree, dropNode, droppedTree, droppedNode);
/*     */     }
/*     */ 
/*     */     
/* 450 */     return canMove;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void treePathChanged(int type, MCTree dropTree, MCTree dragTree, MCTreeNode node, MCTreeNode oldParentNode, MCTreeNode newParentNode) {
/* 553 */     if (this.delegate64 != null)
/*     */     {
/* 555 */       this.delegate64.treePathChanged(type, dropTree, dragTree, node, oldParentNode, newParentNode);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String getExpansionState(JTree tree) {
/* 561 */     StringBuilder sb = new StringBuilder();
/* 562 */     for (int i = 0; i < tree.getRowCount(); i++) {
/* 563 */       TreePath tp = tree.getPathForRow(i);
/* 564 */       if (tree.isExpanded(i)) {
/* 565 */         sb.append(tp.toString());
/* 566 */         sb.append(",");
/*     */       } 
/*     */     } 
/* 569 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setExpansionState(JTree tree, String s) {
/* 574 */     for (int i = 0; i < tree.getRowCount(); i++) {
/* 575 */       TreePath tp = tree.getPathForRow(i);
/* 576 */       if (s.contains(tp.toString())) {
/* 577 */         tree.expandRow(i);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void expandAll(JTree tree, TreePath parentPath) {
/* 585 */     tree.expandPath(parentPath);
/* 586 */     TreeNode node = (TreeNode)parentPath.getLastPathComponent();
/* 587 */     if (node.getChildCount() >= 0) {
/* 588 */       for (Enumeration<E2> e = (Enumeration)node.children(); e.hasMoreElements(); ) {
/* 589 */         TreeNode n = (TreeNode)e.nextElement();
/* 590 */         TreePath path = parentPath.pathByAddingChild(n);
/* 591 */         expandAll(tree, path);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void expandPath(JTree tree, TreePath parentPath) {
/* 598 */     tree.expandPath(parentPath);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void treeExpanded(TreeExpansionEvent event) {
/* 604 */     this.saveTreeState = getExpansionState((JTree)this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void treeCollapsed(TreeExpansionEvent event) {
/* 610 */     this.saveTreeState = getExpansionState((JTree)this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void valueChanged(MCRowEvent event) {
/* 616 */     MCConstRow mCConstRow = event.getSourceRow();
/* 617 */     String n = event.getColumn();
/* 618 */     if (MCStringUtil.eq(n, getParentColumnName())) {
/* 619 */       if (!MCStringUtil.eq((String)event.getOldValue(), 
/* 620 */           (String)event.getNewValue())) {
/* 621 */         getModel().parentNodeChanged(mCConstRow);
/*     */       }
/* 623 */     } else if (MCStringUtil.eq(n, getChildColumnName())) {
/* 624 */       if (!MCStringUtil.eq((String)event.getOldValue(), 
/* 625 */           (String)event.getNewValue())) {
/* 626 */         getModel().childNodeChanged(mCConstRow);
/*     */       }
/* 628 */     } else if (MCStringUtil.eq(n, getLabelColumnName()) && 
/* 629 */       !MCStringUtil.eq((String)event.getOldValue(), 
/* 630 */         (String)event.getNewValue())) {
/* 631 */       getModel().labelChanged(mCConstRow);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\tree\MCTree64.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */