/*     */ package META-INF.versions.21.mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.event.FocusListener;
/*     */ import java.awt.event.KeyEvent;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.border.Border;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCButton;
/*     */ import mcframe.clientCore.beans.MCMode;
/*     */ import mcframe.clientCore.beans.MCResourceBeans;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.action.MCKeyActionManager;
/*     */ import mcframe.clientCore.beans.table.MCCellConfig;
/*     */ import mcframe.clientCore.beans.table.MCCellUtil;
/*     */ import mcframe.clientCore.beans.table.MCColumnConfig;
/*     */ import mcframe.clientCore.beans.table.MCEditorBeans;
/*     */ import mcframe.clientCore.beans.table.MCTable;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.clientCore.event.MCEventInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCEditorButton
/*     */   extends MCButton
/*     */   implements MCEditorBeans
/*     */ {
/*     */   private static final String TYPE = "table.column.button";
/*     */   private MCColumnConfig _column;
/*     */   private MCTable<?> _table;
/*  56 */   private int _index = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected MCEditorButton(String name, MCColumnConfig column) {
/*  71 */     super(name);
/*  72 */     setColumnConfig(column);
/*  73 */     setTable(column.getBaseTable());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initBeans() {
/*  78 */     super.initBeans();
/*  79 */     setHorizontalAlignment(0);
/*  80 */     setFocusTraversalKeysEnabled(false);
/*  81 */     setBorder(MCCellUtil.DEFAULT_BORDER); byte b; int i; FocusListener[] arrayOfFocusListener;
/*  82 */     for (i = (arrayOfFocusListener = getFocusListeners()).length, b = 0; b < i; ) { FocusListener l = arrayOfFocusListener[b];
/*  83 */       removeFocusListener(l);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initKeyAssign() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initResource() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getType() {
/* 107 */     return "table.column.button";
/*     */   }
/*     */ 
/*     */   
/*     */   public void transferFocus() {
/* 112 */     MCTable<?> t = getTable();
/* 113 */     t.transferFocus(getRowIndex(), t.getViewColumn(getColumnConfig()) + 1, 
/* 114 */         false, true, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCRootPanel getRootPanel() {
/* 119 */     return MCCellUtil.getRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCRootPanel getNearestRootPanel() {
/* 124 */     return MCCellUtil.getNearestRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessageByLocale() {
/* 129 */     return getColumnConfig().getMessageByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLabelByLocale() {
/* 134 */     return getColumnConfig().getLabelByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public Border getDefaultBorder() {
/* 139 */     return MCCellUtil.DEFAULT_BORDER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setRowIndex(int index) {
/* 148 */     this._index = index;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getRowIndex() {
/* 153 */     return this._index;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void valueCommited() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setColumnConfig(MCColumnConfig column) {
/* 173 */     this._column = column;
/*     */   }
/*     */   
/*     */   public final MCColumnConfig getColumnConfig() {
/* 177 */     return this._column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setTable(MCTable<?> table) {
/* 188 */     this._table = table;
/*     */   }
/*     */   
/*     */   public final MCTable<?> getTable() {
/* 192 */     return this._table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doCheckValueError() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setColumnInfo(int index, MCColumnConfig column) {
/* 213 */     setColumnConfig(column);
/* 214 */     setRowIndex(index);
/* 215 */     MCTable<?> table = getTable();
/* 216 */     MCKeyActionManager.init((MCResourceBeans)this, getInputMap(), getActionMap());
/* 217 */     MCKeyActionManager.initScreen((MCResourceBeans)this, getInputMap(), getActionMap());
/* 218 */     MCMode mode = MCCellUtil.isCellEditable(index, column, table);
/* 219 */     setMode(mode);
/* 220 */     setForeground(MCCellUtil.getForeground(index, column, table, false, mode));
/* 221 */     setBackground(MCCellUtil.getBackground(index, column, table, false, mode));
/* 222 */     setFont(column.getFont());
/* 223 */     MCCellConfig conf = column.getCellConfig();
/* 224 */     setText(conf.getButtonColumnValue(index, column, table, false));
/* 225 */     setIcon(conf.getButtonColumnIcon(index, column, table, false));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFocusOwner() {
/* 230 */     MCTable<?> t = getTable();
/* 231 */     return (t != null) ? (
/* 232 */       t.isRemoveNotifyProcessing() ? super.isFocusOwner() : false) : 
/* 233 */       super.isFocusOwner();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isMCFocusOwner() {
/* 238 */     MCTable<?> t = getTable();
/* 239 */     return (t != null) ? ((t.getMCEditorComponent() == this)) : isFocusOwner();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCEventInfo getEventInfo() {
/* 244 */     return getColumnConfig().getEventInfo();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNE() {
/* 249 */     getColumnConfig().doNE();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNX() {
/* 254 */     getColumnConfig().doNX();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doAP() {
/* 259 */     getColumnConfig().doAP();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void focusGained() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void focusLost() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Border getBorder() {
/* 282 */     Border b = MCCellUtil.getBorder(this);
/* 283 */     return (b != null) ? b : super.getBorder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource(MCRootPanel panel) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterRequestFocus() {
/* 307 */     MCBeansUtil.afterRequestFocus((JComponent)getTable());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void processKeyEvent(KeyEvent e) {
/* 312 */     MCCellUtil.beforeKeyEvent(e, this);
/* 313 */     super.processKeyEvent(e);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCConstRow getBaseRow() {
/* 325 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCConstRow getRow() {
/* 337 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Comparable<?> getViewValue() {
/* 349 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValueChanged(Comparable<?> value) {
/* 361 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRowToView() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setRowToViews() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean authorize() {
/* 384 */     MCColumnConfig c = getColumnConfig();
/* 385 */     return (c != null) ? c.authorize() : false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean checkAC() {
/* 390 */     MCColumnConfig c = getColumnConfig();
/* 391 */     return (c != null) ? c.checkAC() : false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean checkPassword() {
/* 396 */     MCColumnConfig c = getColumnConfig();
/* 397 */     return (c != null) ? c.checkPassword() : false;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getACType() {
/* 402 */     MCColumnConfig c = getColumnConfig();
/* 403 */     return (c != null) ? c.getACType() : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean needsPassword() {
/* 408 */     MCColumnConfig c = getColumnConfig();
/* 409 */     return (c != null) ? c.needsPassword() : false;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getAPMethodName() {
/* 414 */     MCColumnConfig c = getColumnConfig();
/* 415 */     return (c != null) ? c.getAPMethodName() : null;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public final void focusGainedSelect() {}
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\table\MCEditorButton.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */