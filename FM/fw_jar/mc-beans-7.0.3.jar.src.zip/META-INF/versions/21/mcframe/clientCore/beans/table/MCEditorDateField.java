/*     */ package META-INF.versions.21.mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.event.KeyEvent;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.border.Border;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCDateField;
/*     */ import mcframe.clientCore.beans.MCMode;
/*     */ import mcframe.clientCore.beans.MCModeBeans;
/*     */ import mcframe.clientCore.beans.MCResourceBeans;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.action.MCKeyActionManager;
/*     */ import mcframe.clientCore.beans.list.MCLinkedBeans;
/*     */ import mcframe.clientCore.beans.list.MCListType;
/*     */ import mcframe.clientCore.beans.popup.MCPopupConfig;
/*     */ import mcframe.clientCore.beans.popup.MCPopupMenu;
/*     */ import mcframe.clientCore.beans.table.MCBeansProxy;
/*     */ import mcframe.clientCore.beans.table.MCCellUtil;
/*     */ import mcframe.clientCore.beans.table.MCColumnConfig;
/*     */ import mcframe.clientCore.beans.table.MCEditorBeans;
/*     */ import mcframe.clientCore.beans.table.MCTable;
/*     */ import mcframe.clientCore.beans.table.MCTableColumn;
/*     */ import mcframe.clientCore.event.MCEventInfo;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCCalendarDate;
/*     */ import mcframe.commonCore.lang.MCDate;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCEditorDateField
/*     */   extends MCDateField
/*     */   implements MCEditorBeans
/*     */ {
/*     */   private static final String TYPE = "table.column.date";
/*     */   private MCColumnConfig _column;
/*     */   private MCTable<?> _table;
/*     */   
/*     */   @Deprecated
/*     */   protected MCEditorDateField(String name, MCColumnConfig column) {
/*  70 */     super(name);
/*  71 */     setColumnConfig(column);
/*  72 */     setTable(column.getBaseTable());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getType() {
/*  77 */     return "table.column.date";
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initBeans() {
/*  82 */     super.initBeans();
/*     */     
/*  84 */     setFocusTraversalKeysEnabled(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initKeyAssign() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initResource() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setColumnConfig(MCColumnConfig column) {
/* 115 */     this._column = column;
/*     */   }
/*     */ 
/*     */   
/*     */   public final MCColumnConfig getColumnConfig() {
/* 120 */     return this._column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setTable(MCTable<?> table) {
/* 131 */     this._table = table;
/*     */   }
/*     */ 
/*     */   
/*     */   public final MCTable getTable() {
/* 136 */     return this._table;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getRowIndex() {
/* 142 */     return MCCellUtil.getRowIndex(this);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void transferFocus() {
/* 148 */     if (isAmPmField() && MCMode.isEnable((MCModeBeans)this) && 
/* 149 */       !MCStringUtil.isNull(getText()) && isValueChanged() && !isShowingAmPmComboList()) {
/* 150 */       showOrChangeAmPm();
/*     */       
/*     */       return;
/*     */     } 
/* 154 */     MCTable<?> t = getTable();
/* 155 */     t.transferFocus(getRowIndex(), t.getViewColumn(getColumnConfig()) + 1, false, 
/* 156 */         true, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public Border getDefaultBorder() {
/* 161 */     return MCCellUtil.DEFAULT_BORDER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setColumnInfo(int index, MCColumnConfig column) {
/* 173 */     setColumnConfig(column);
/* 174 */     MCTable<?> table = getTable();
/* 175 */     MCKeyActionManager.init((MCResourceBeans)this, getInputMap(), getActionMap());
/* 176 */     MCKeyActionManager.initScreen((MCResourceBeans)this, getInputMap(), getActionMap());
/* 177 */     MCMode mode = MCCellUtil.isCellEditable(index, column, table);
/* 178 */     setMode(mode);
/* 179 */     setForeground(MCCellUtil.getForeground(index, column, table, false, mode));
/* 180 */     setBackground(MCCellUtil.getBackground(index, column, table, false, mode));
/* 181 */     setFont(column.getFont());
/* 182 */     setCaretColor(MCCellUtil.getCaretColor(index, column, table));
/* 183 */     setSelectionColor(MCCellUtil.getSelectionColor(index, column, table));
/* 184 */     setSelectedTextColor(MCCellUtil.getSelectedTextColor(index, column, table));
/* 185 */     setMeta(column.getMeta());
/* 186 */     setAutoFocus(column.isAutoFocus());
/* 187 */     setSelectAll(column.isSelectAll());
/* 188 */     setListConfig(column.getListConfig());
/* 189 */     setCalendarFormat(MCCellUtil.getDateFormat(index, column, table, mode));
/*     */     
/* 191 */     setCalendarValidator(column.getCalendarValidator());
/* 192 */     setRow(column.getTable().getRow(index), column.getRowColumnName());
/*     */     
/* 194 */     Border border = MCCellUtil.getEditorBorder(index, column, table);
/* 195 */     if (border != null) {
/* 196 */       setBorder(border);
/*     */     } else {
/*     */       
/* 199 */       setBorder(getDefaultBorder());
/*     */     } 
/* 201 */     setListListener(column.getListListener());
/* 202 */     MCPopupMenu menu = getComponentPopupMenu();
/* 203 */     if (menu != null) {
/* 204 */       menu.updateResource();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public MCLinkedBeans[] getLinkBeans() {
/* 210 */     MCColumnConfig c = getColumnConfig();
/* 211 */     return (c != null) ? c.getLinkBeans() : super.getLinkBeans();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCRootPanel getRootPanel() {
/* 216 */     return MCCellUtil.getRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCRootPanel getNearestRootPanel() {
/* 221 */     return MCCellUtil.getNearestRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessageByLocale() {
/* 226 */     return getColumnConfig().getMessageByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLabelByLocale() {
/* 231 */     return getColumnConfig().getLabelByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterRequestFocus() {
/* 236 */     MCRootPanel bp = getBaseRootPanel();
/* 237 */     MCBeansUtil.afterRequestFocus(bp, (JComponent)getTable());
/* 238 */     MCBeansUtil.scrollRectToVisible(bp, (JComponent)this, getHorizontalAlignment());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 243 */     repaint();
/*     */   }
/*     */ 
/*     */   
/*     */   public void commitValue() {
/* 248 */     getColumnConfig().setValue(getRowIndex(), (Comparable)getViewValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFocusOwner() {
/* 253 */     MCTable<?> t = getTable();
/* 254 */     return (t != null) ? (t.isRemoveNotifyProcessing() ? super.isFocusOwner() : false) : 
/* 255 */       super.isFocusOwner();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValueChanged() {
/* 260 */     return isValueChanged((Comparable<?>)getRowValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValueChanged(Comparable<?> value) {
/* 274 */     adjustViewValue();
/*     */     try {
/* 276 */       return isValueChanged((Comparable<?>)getValue(), value);
/*     */     }
/* 278 */     catch (MCException mCException) {
/* 279 */       return true;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isValueChanged(Comparable<?> view, Comparable<?> row) {
/* 285 */     return MCCellUtil.isValueChanged(this, view, row);
/*     */   }
/*     */ 
/*     */   
/*     */   public void valueCommited() {
/* 290 */     MCRow row = null;
/* 291 */     if ("input".equals(getListConfig().getOpeType())) {
/* 292 */       MCList<?> l = getList();
/* 293 */       if (l != null) {
/* 294 */         MCRow[] a = l.toArray();
/* 295 */         MCDate v = (MCDate)getValue();
/* 296 */         String n = getListNames()[0]; byte b; int i; MCRow[] arrayOfMCRow1;
/* 297 */         for (i = (arrayOfMCRow1 = a).length, b = 0; b < i; ) { MCRow r = arrayOfMCRow1[b];
/* 298 */           MCDate val = r.getDate(n);
/* 299 */           if (val != null && val.eq((MCCalendarDate)v, new mcframe.commonCore.lang.MCDateFieldType[0])) {
/* 300 */             row = r; break;
/*     */           } 
/*     */           b++; }
/*     */       
/*     */       } 
/*     */     } 
/* 306 */     if (row == null && 
/* 307 */       getListType() == MCListType.FREE) {
/* 308 */       row = MCRow.create();
/* 309 */       MCBeansProxy.PROXY.addColumn(row, getListNames()[0], getDataType(), 
/* 310 */           (Comparable)getViewValue());
/*     */     } 
/*     */     
/* 313 */     ((MCTableColumn)getColumnConfig()).execLink(getTable().getMCEditingRow(), row, 
/* 314 */         true);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isMCFocusOwner() {
/* 319 */     MCTable<?> t = getTable();
/* 320 */     return (t != null) ? ((t.getMCEditorComponent() == this)) : isFocusOwner();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCList doListEvent() {
/* 325 */     return getColumnConfig().doListEvent();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doDC() {
/* 330 */     super.doDC();
/* 331 */     getColumnConfig().doDC();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean doVC() {
/* 336 */     return getColumnConfig().doVC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNC() {
/* 341 */     getColumnConfig().doNC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNE() {
/* 346 */     getColumnConfig().doNE();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNX() {
/* 351 */     getColumnConfig().doNX();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doLC() {
/* 356 */     getColumnConfig().doLC();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCEventInfo getEventInfo() {
/* 361 */     return getColumnConfig().getEventInfo();
/*     */   }
/*     */ 
/*     */   
/*     */   public void focusGained() {
/* 366 */     setText((MCCalendarDate)getRowValue());
/* 367 */     focusGainedSelect();
/* 368 */     showCalenderIfFocusGained();
/* 369 */     this._suppressCalenderMPEvent = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void focusLost() {
/* 374 */     hideCalenderIfFocusLost();
/* 375 */     setText((MCCalendarDate)getRowValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRequestFocusEnabled() {
/* 380 */     return (MCCellUtil.isRequestFocusEnabled(this) && super.isRequestFocusEnabled());
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isMCRequestFocusEnabled() {
/* 385 */     return MCCellUtil.isFocusable(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public Border getBorder() {
/* 390 */     Border b = MCCellUtil.getBorder(this);
/* 391 */     return (b != null) ? b : super.getBorder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource(MCRootPanel panel) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doCheckValueError() {
/* 416 */     super.doCheckValueError();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCalendarEnabled() {
/* 421 */     return getColumnConfig().isCalendarEnabled();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean requestCommit() {
/* 426 */     if (!isValueChanged()) {
/* 427 */       return true;
/*     */     }
/* 429 */     MCTable<?> t = getTable();
/* 430 */     if (t.canChange()) {
/* 431 */       t.commitValue();
/* 432 */       return true;
/*     */     } 
/* 434 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCPopupConfig getPopupConfig() {
/* 439 */     MCTable<?> t = getTable();
/* 440 */     return (t != null) ? t.getPopupConfig() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCPopupMenu configurePopup(MCPopupMenu menu) {
/* 454 */     MCPopupConfig pc = getPopupConfig();
/* 455 */     return (pc != null) ? 
/* 456 */       pc.configurePopup(menu, getTable(), getRowIndex(), getColumnConfig()) : 
/* 457 */       menu;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void processKeyEvent(KeyEvent e) {
/* 462 */     MCCellUtil.beforeKeyEvent(e, this);
/* 463 */     super.processKeyEvent(e);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCDate getInitCalendarFocus() {
/* 468 */     MCDate v = MCCellUtil.getInitDateCalendarFocus(getRowIndex(), getColumnConfig(), 
/* 469 */         getTable());
/* 470 */     return (v != null) ? v : today();
/*     */   }
/*     */ 
/*     */   
/*     */   public Comparable<?> doListFormat(Comparable<?> value) {
/* 475 */     return getColumnConfig().doListFormat(getRowIndex(), value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getCalendarPanelID() {
/* 480 */     return MCCellUtil.getCalendarPanelID(getRowIndex(), getColumnConfig(), 
/* 481 */         getTable());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void execLink(MCRow row, boolean msg) {
/* 486 */     ((MCTableColumn)getColumnConfig()).execLink(getRowIndex(), row, msg);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\table\MCEditorDateField.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */