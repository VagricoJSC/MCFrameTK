package META-INF.versions.21.mcframe.clientCore.beans.table;

interface Resizable2 {
  int getElementCount();
  
  int getLowerBoundAt(int paramInt);
  
  int getUpperBoundAt(int paramInt);
  
  void setSizeAt(int paramInt1, int paramInt2);
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\table\MCLayoutTable$Resizable2.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */