/*     */ package META-INF.versions.21.mcframe.clientCore.beans.combobox;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Font;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import java.util.regex.Pattern;
/*     */ import java.util.regex.PatternSyntaxException;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.text.Document;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCMode;
/*     */ import mcframe.clientCore.beans.MCModeBeans;
/*     */ import mcframe.clientCore.beans.MCPluralValueField;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.MCRowBeans;
/*     */ import mcframe.clientCore.beans.combobox.MCBeansProxy;
/*     */ import mcframe.clientCore.beans.combobox.MCComboField;
/*     */ import mcframe.clientCore.beans.combobox.MCEventProxy;
/*     */ import mcframe.clientCore.beans.combobox.MCFieldComboBox;
/*     */ import mcframe.clientCore.beans.combobox.MCTextProxy;
/*     */ import mcframe.clientCore.beans.list.MCListType;
/*     */ import mcframe.clientCore.beans.text.MCDocumentBeans;
/*     */ import mcframe.clientCore.beans.text.MCIMDelegate;
/*     */ import mcframe.clientCore.beans.text.MCInputMethodType;
/*     */ import mcframe.clientCore.beans.text.MCTextDocument;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ import mcframe.commonCore.notice.Core_Msg;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCMessageList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCTextComboBox
/*     */   extends MCFieldComboBox<String>
/*     */   implements MCDocumentBeans, MCPluralValueField
/*     */ {
/*  53 */   private int _max_len = Integer.MAX_VALUE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String _trim_ptn;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean _input_method_editing = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   private List<Pattern> _accept_ptn = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   private List<Character> _except_chars = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   private MCInputMethodType _input_method_type = MCInputMethodType.NONE; private MCIMDelegate _im_delegate; private boolean _plural_value_enable; protected String getTrimPatternKey() { return MCConst.createKey(new String[] { getType(), "trim" }); }
/*     */   protected MCTextComboField getComboField() { return (MCTextComboField)super.getComboField(); }
/*     */   protected MCTextComboField createComboField() { return new MCTextComboField(this); }
/*     */   public String getType() { return "combo"; }
/*     */   public List<Pattern> getAcceptPattern() { if (this._accept_ptn != null)
/*     */       return this._accept_ptn;  String k = MCConst.createKey(new String[] { getType(), "accept" }); String p = MCConst.beans.getString(k); if (p != null)
/*     */       setAcceptPattern(p);  return this._accept_ptn; }
/*     */   public void setAcceptPattern(List<Pattern> l) { this._accept_ptn = l; }
/*     */   public void addAcceptPattern(String ptn) { List<Pattern> l = getAcceptPattern(); if (l == null) { setAcceptPattern(ptn); } else { addAcceptPattern(l, ptn); }  }
/*     */   public void addAcceptPattern(String ptn, int flags) { List<Pattern> l = getAcceptPattern(); if (l == null) { setAcceptPattern(ptn, flags); } else { addAcceptPattern(l, ptn, flags); }
/*     */      }
/*     */   private void setAcceptPattern(String ptn) { this._accept_ptn = new ArrayList<>(); addAcceptPattern(this._accept_ptn, ptn); }
/*     */   private void setAcceptPattern(String ptn, int flags) { this._accept_ptn = new ArrayList<>(); addAcceptPattern(this._accept_ptn, ptn, flags); }
/*     */   private void addAcceptPattern(List<Pattern> l, String ptn) { try { l.add(Pattern.compile(ptn)); }
/*     */     catch (PatternSyntaxException patternSyntaxException) { throw new MCException(Core_Msg.FCBAC0333, new Object[] { ptn }); }
/*     */      }
/*     */   private void addAcceptPattern(List<Pattern> l, String ptn, int flags) { try { l.add(Pattern.compile(ptn)); }
/*     */     catch (PatternSyntaxException patternSyntaxException) { throw new MCException(Core_Msg.FCBAC0333, new Object[] { ptn, Integer.valueOf(flags) }); }
/*     */      }
/* 115 */   @Deprecated public MCTextComboBox(String name) { super(name);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 686 */     this._plural_value_enable = false; }
/*     */   public List<Character> getExceptCharacter() { if (this._except_chars != null) return this._except_chars;  String k = MCConst.createKey(new String[] { getType(), "except" }); String s = MCConst.beans.getString(k); if (s != null && s.length() > 0) setExceptCharacter(s.toCharArray());  return this._except_chars; }
/*     */   public void setExceptCharacter(List<Character> l) { this._except_chars = l; }
/*     */   public void setExceptCharacter(char[] cs) { this._except_chars = new ArrayList<>(); byte b; int i; char[] arrayOfChar; for (i = (arrayOfChar = cs).length, b = 0; b < i; ) { Character c = Character.valueOf(arrayOfChar[b]); this._except_chars.add(c); b++; }  }
/*     */   public void addExceptCharacter(char c) { List<Character> l = getExceptCharacter(); if (l == null) { this._except_chars = new ArrayList<>(); l = this._except_chars; }  l.add(Character.valueOf(c)); }
/*     */   public MCMessageList checkInputValue(String value) { return getValueChecker().checkInputValue(this, value); }
/*     */   public String getTrimPattern() { return this._trim_ptn; }
/*     */   public void setTrimPattern(String pattern) { this._trim_ptn = pattern; }
/*     */   protected void setResourceInfo(MCRootPanel panel) { super.setResourceInfo(panel); setResourceTrimPattern(panel); }
/*     */   protected void setResourceTrimPattern(MCRootPanel panel) { String t = MCBeansProxy.PROXY.getBeansString(getTrimPatternKey(), panel); if (t != null) setTrimPattern(t);  }
/*     */   protected void setMeta(MCMeta meta) { super.setMeta(meta); if (meta != null) setLength(meta.length());  }
/* 697 */   public void setLength(int length) { this._max_len = (length < 0) ? Integer.MAX_VALUE : length; } public int getLength() { return this._max_len; } public void doAfterInsert() { if (!isPopupVisible()) return;  SwingUtilities.invokeLater((Runnable)new Object(this)); } private void setInputMethodEditing(boolean editing) { this._input_method_editing = editing; } public boolean isInputMethodEditing() { return this._input_method_editing; } public boolean checkInputValue(Comparable<?> value, MCMessageList list) { MCMessageList l = getValueChecker().checkInputValue(this, value); if (l.size() == 0) return true;  if (list != null) list.addAll((Collection)l);  return false; } public MCMessageList checkValue(Comparable<?> value) { return getValueChecker().checkValue(this, value); } public String getRowValue() { MCConstRow c = getBaseRow(); String n = getBaseRowColumnName(); return !MCBeansUtil.isNull(c, n) ? c.getString(n) : null; } void setPluralValueEnable(boolean enable) { if (MCConst.plugin.getBoolean(MCConst.createKey(new String[] { "ArrayValue", "invalid"
/* 698 */           }, ), false))
/*     */     
/* 700 */     { this._plural_value_enable = false; }
/*     */     else
/*     */     
/* 703 */     { this._plural_value_enable = enable; }  }
/*     */   public MCMessageList setValue(String value, MCMessageList list) { String v = (String)_adjustValue(value); v = MCBeansUtil._getExtractText(this, v); return super.setValue(v, list); }
/*     */   public void setViewValue(Comparable<?> value, MCMessageList list) { if (list == null) list = new MCMessageList();  if (value != null) { if (value instanceof String) { setValue((String)value, list); } else { list.add(MCBeansUtil.createCauseMsg((MCRowBeans)this, Core_Msg.FCBAC0068, new Object[0])); }  } else { setValue(null, list); }  }
/*     */   public String getValue() { String t = getText(); String v = getTrimValue(t); if (!MCStringUtil.eq(t, v)) setText(v);  return !MCStringUtil.isNull(v) ? v : null; }
/*     */   private String getTrimValue(String value) { String v; if (!isPluralValueEnable()) { v = MCBeansProxy.PROXY.trim(value, getTrimPattern()); } else if (!MCStringUtil.isNull(value)) { String[] va = MCStringUtil.arrayValueSplit(value); for (int i = 0; i < va.length; i++) va[i] = MCBeansProxy.PROXY.trim(va[i], getTrimPattern());  v = MCStringUtil.arrayValueJoin(va); } else { v = null; }  return MCStringUtil.isNull(v) ? null : v; }
/*     */   public void setRowToView() { MCBeansUtil.checkThread(); MCConstRow o = getBaseRow(); String n = getBaseRowColumnName(); if (MCBeansUtil.isNull(o, n)) return;  String v = MCStringUtil.convertToLF(o.getString(n)); if (MCStringUtil.isNull(v)) v = null;  String t = getText(); if (MCStringUtil.isNull(t)) t = null;  if (!MCStringUtil.eq(v, t)) { MCEventProxy.PROXY.setValue(getEventInfo(), v, v); boolean e = MCBeansProxy.PROXY.isEventEnabled(); try { MCBeansProxy.PROXY.setEventEnabled(false); setText(v); } finally { MCBeansProxy.PROXY.setEventEnabled(e); }  }  getComboField().adjustText(); }
/*     */   public void setText(String text) { setDocumentEditable(true); boolean e = isAutoFocus(); try { setAutoFocus(false); getComboField().setText(text); } finally { if (MCListType.SELECT_ONLY == getListType())
/* 710 */         setDocumentEditable(false);  setAutoFocus(e); }  } public boolean isPluralValueEnable() { return this._plural_value_enable; } public Comparable<?> doListFormat(Comparable<?> value) { return value; } protected void setDocumentEditable(boolean editable) { Document d = getDocument(); if (d instanceof MCTextDocument) ((MCTextDocument)d).setEditable(editable);  } public void focusGained() { super.focusGained(); _installInputMethod(); } public void focusLost() { super.focusLost(); _uninstallInputMethod(); } public void setInputMethodType(MCInputMethodType type) { if (type == null) type = MCInputMethodType.NONE;  this._input_method_type = type; } public MCInputMethodType getInputMethodType() { if (MCMode.isDisable((MCModeBeans)this)) return MCInputMethodType.OFF;  return this._input_method_type; } private MCIMDelegate getIMDelegate() { return (this._im_delegate != null) ? this._im_delegate : (this._im_delegate = MCTextProxy.PROXY.createIMDelegate()); }
/*     */   @Deprecated protected void _installInputMethod() { MCTextProxy.PROXY.installInputMethod(getIMDelegate(), (Component)this, getInputMethodType()); }
/*     */   @Deprecated protected void _uninstallInputMethod() { MCTextProxy.PROXY.uninstallInputMethod(getIMDelegate(), (Component)this, getInputMethodType()); }
/*     */   public void enableInputMethods(boolean enable) { if (getInputMethodType() == MCInputMethodType.OFF) enable = false;  super.enableInputMethods(enable); getComboField().enableInputMethods(enable); }
/*     */   protected boolean doIncrementalSearch() { String v = getText(); if (MCStringUtil.isNull(v)) return false;  MCList<?> l = getList(); if (l == null) return false;  boolean e = MCBeansProxy.PROXY.isEventEnabled(); try { MCBeansProxy.PROXY.setEventEnabled(false); String n = getKeyColumnName(); } finally { MCBeansProxy.PROXY.setEventEnabled(e); }  MCBeansProxy.PROXY.setEventEnabled(e); return false; }
/*     */   protected Comparable<?> _adjustValue(Comparable<?> value) { if (value instanceof String) { String v = MCStringUtil.convertToLF((String)value); v = getTrimValue(v); return v; }  return value; }
/* 716 */   @Deprecated public boolean _isLastInsert() { if (isPluralValueEnable()) {
/* 717 */       return false;
/*     */     }
/*     */     
/* 720 */     return (getLength() == MCStringUtil.codePointCount(getText())); }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAutoFocus() {
/* 725 */     if (isPluralValueEnable()) {
/* 726 */       return false;
/*     */     }
/* 728 */     return super.isAutoFocus();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void execLink(MCRow row, boolean msg) {
/* 734 */     if (isPluralValueEnable()) {
/* 735 */       MCListType y = getListType();
/* 736 */       if ((MCListType.STRICT.equals(y) || MCListType.SELECT_ONLY.equals(y)) && 
/* 737 */         row == null && !MCStringUtil.isNull(getValue())) {
/* 738 */         MCList<?> l = getModel().getList();
/* 739 */         if (l != null) {
/* 740 */           if (l.size() > 0) {
/* 741 */             row = l.get(0).clone();
/* 742 */             row.clear();
/*     */           } else {
/*     */             
/* 745 */             row = l.createRow();
/*     */           } 
/*     */         } else {
/*     */           
/* 749 */           row = MCRow.create();
/*     */         } 
/* 751 */         String n = getKeyColumnName();
/* 752 */         if (!row.contains(n)) {
/* 753 */           row.addStringColumn(n);
/*     */         }
/* 755 */         row.setString(n, getValue());
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 760 */     super.execLink(row, msg);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isValueChanged(Comparable<?> view, Comparable<?> row) {
/* 765 */     return super.isValueChanged(_adjustValue(view), _adjustValue(row));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void _setFont(Font font) {
/* 842 */     setFont(font);
/*     */   }
/*     */ 
/*     */   
/*     */   public String convToMaximumValues(String before, int offs, String str) {
/* 847 */     return getValueChecker().convMaximumValues(this, before, offs, str);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\combobox\MCTextComboBox.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */