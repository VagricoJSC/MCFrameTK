/*   */ package META-INF.versions.21.mcframe.clientCore.beans.listview;
/*   */ 
/*   */ public class MCListViewCompatibilityFactory {
/*   */   public static MCListView createListView(String name) {
/* 5 */     return (MCListView)new MCListView21(name);
/*   */   }
/*   */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\listview\MCListViewCompatibilityFactory.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */