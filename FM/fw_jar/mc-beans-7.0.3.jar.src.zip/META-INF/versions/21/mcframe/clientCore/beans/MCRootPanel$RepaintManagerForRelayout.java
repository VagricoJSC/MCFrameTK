package META-INF.versions.21.mcframe.clientCore.beans;

import java.awt.Window;
import javax.swing.JComponent;
import javax.swing.RepaintManager;
import mcframe.clientCore.beans.MCRootPanel;

public class RepaintManagerForRelayout extends RepaintManager {
  public void addDirtyRegion(Window window, int x, int y, int w, int h) {}
  
  public void addInvalidComponent(JComponent invalidComponent) {}
  
  public void addDirtyRegion(JComponent c, int x, int y, int w, int h) {}
  
  public void markCompletelyClean(JComponent aComponent) {}
  
  public void paintDirtyRegions() {}
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\MCRootPanel$RepaintManagerForRelayout.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */