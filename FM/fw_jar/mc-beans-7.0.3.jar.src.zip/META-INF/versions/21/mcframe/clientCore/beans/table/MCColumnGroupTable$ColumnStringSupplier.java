package META-INF.versions.21.mcframe.clientCore.beans.table;

import javax.swing.table.TableColumn;
import mcframe.clientCore.beans.table.MCColumnGroup;

interface ColumnStringSupplier {
  String getString();
  
  String getString(MCColumnGroup paramMCColumnGroup);
  
  TableColumn getColumn();
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\table\MCColumnGroupTable$ColumnStringSupplier.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */