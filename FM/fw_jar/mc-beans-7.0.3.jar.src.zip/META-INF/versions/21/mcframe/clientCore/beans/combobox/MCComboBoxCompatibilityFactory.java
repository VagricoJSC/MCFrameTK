/*    */ package META-INF.versions.21.mcframe.clientCore.beans.combobox;
/*    */ 
/*    */ public class MCComboBoxCompatibilityFactory {
/*    */   public static MCDateComboBox createDateComboBox(String name) {
/*  5 */     return (MCDateComboBox)new MCDateComboBox21(name);
/*    */   }
/*    */   
/*    */   public static MCNumberComboBox createNumberComboBox(String name) {
/*  9 */     return (MCNumberComboBox)new MCNumberComboBox21(name);
/*    */   }
/*    */   
/*    */   public static MCTextComboBox createTextComboBox(String name) {
/* 13 */     return (MCTextComboBox)new MCTextComboBox21(name);
/*    */   }
/*    */   
/*    */   public static MCTimestampComboBox createTimestampComboBox(String name) {
/* 17 */     return (MCTimestampComboBox)new MCTimestampComboBox21(name);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\combobox\MCComboBoxCompatibilityFactory.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */