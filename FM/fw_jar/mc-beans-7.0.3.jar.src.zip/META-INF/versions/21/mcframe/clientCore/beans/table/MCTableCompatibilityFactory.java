/*    */ package META-INF.versions.21.mcframe.clientCore.beans.table;
/*    */ import mcframe.clientCore.beans.table.MCColumnConfig;
/*    */ import mcframe.clientCore.beans.table.MCEditorTextComboBox;
/*    */ 
/*    */ public class MCTableCompatibilityFactory {
/*    */   public static MCEditorButton createEditorButton(String name, MCColumnConfig column) {
/*  7 */     return (MCEditorButton)new MCEditorButton21(name, column);
/*    */   }
/*    */   public static <E extends mcframe.clientCore.container.MCConstRow> MCColumnGroupTable<E> createColumnGroupTable(String name) {
/* 10 */     return (MCColumnGroupTable<E>)new MCColumnGroupTable21(name);
/*    */   }
/*    */   public static MCEditorCheckBox createEditorCheckBox(String name, MCColumnConfig column) {
/* 13 */     return (MCEditorCheckBox)new MCEditorCheckBox21(name, column);
/*    */   }
/*    */   public static MCEditorDateComboBox createEditorDateComboBox(String name, MCColumnConfig column) {
/* 16 */     return (MCEditorDateComboBox)new MCEditorDateComboBox21(name, column);
/*    */   }
/*    */   public static MCEditorDateField createEditorDateField(String name, MCColumnConfig column) {
/* 19 */     return (MCEditorDateField)new MCEditorDateField21(name, column);
/*    */   }
/*    */   public static MCEditorImageView createEditorImageView(String name, MCColumnConfig column) {
/* 22 */     return (MCEditorImageView)new MCEditorImageView21(name, column);
/*    */   }
/*    */   public static MCEditorNumberComboBox createEditorNumberComboBox(String name, MCColumnConfig column) {
/* 25 */     return (MCEditorNumberComboBox)new MCEditorNumberComboBox21(name, column);
/*    */   }
/*    */   public static MCEditorNumberField createEditorNumberField(String name, MCColumnConfig column) {
/* 28 */     return (MCEditorNumberField)new MCEditorNumberField21(name, column);
/*    */   }
/*    */   public static MCEditorPasswordField createEditorPasswordField(String name, MCColumnConfig column) {
/* 31 */     return (MCEditorPasswordField)new MCEditorPasswordField21(name, column);
/*    */   }
/*    */   public static MCEditorTextComboBox createEditorTextComboBox(String name, MCColumnConfig column) {
/* 34 */     return (MCEditorTextComboBox)new MCEditorTextComboBox21(name, column);
/*    */   }
/*    */   public static MCEditorTextField createEditorTextField(String name, MCColumnConfig column) {
/* 37 */     return (MCEditorTextField)new MCEditorTextField21(name, column);
/*    */   }
/*    */   public static MCEditorTimestampComboBox createEditorTimestampComboBox(String name, MCColumnConfig column) {
/* 40 */     return (MCEditorTimestampComboBox)new MCEditorTimestampComboBox21(name, column);
/*    */   }
/*    */   public static MCEditorTimestampField createEditorTimestampField(String name, MCColumnConfig column) {
/* 43 */     return (MCEditorTimestampField)new MCEditorTimestampField21(name, column);
/*    */   }
/*    */   public static MCFixedColumnTable createFixedColumnTable(MCTable table, String name) {
/* 46 */     return (MCFixedColumnTable)new MCFixedColumnTable21(table, name);
/*    */   }
/*    */   public static <E extends mcframe.clientCore.container.MCConstRow> MCLayoutTable<E> createLayoutTable(String name) {
/* 49 */     return (MCLayoutTable<E>)new MCLayoutTable21(name);
/*    */   }
/*    */   public static <E extends mcframe.clientCore.container.MCConstRow> MCTable2<E> createTable2(String name) {
/* 52 */     return (MCTable2<E>)new MCTable221(name);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\table\MCTableCompatibilityFactory.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */