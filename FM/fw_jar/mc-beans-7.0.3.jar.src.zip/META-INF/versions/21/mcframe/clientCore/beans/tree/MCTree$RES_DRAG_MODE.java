package META-INF.versions.21.mcframe.clientCore.beans.tree;

class RES_DRAG_MODE {
  private static final String MOVE = "DRAG_MOVE";
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\tree\MCTree$RES_DRAG_MODE.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */