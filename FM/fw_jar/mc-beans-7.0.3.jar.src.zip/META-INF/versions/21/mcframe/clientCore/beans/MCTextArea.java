/*      */ package META-INF.versions.21.mcframe.clientCore.beans;
/*      */ 
/*      */ import java.awt.AWTEvent;
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Font;
/*      */ import java.awt.Insets;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.event.FocusListener;
/*      */ import java.awt.event.InputMethodEvent;
/*      */ import java.awt.event.KeyEvent;
/*      */ import java.awt.event.MouseListener;
/*      */ import java.awt.event.MouseWheelListener;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.List;
/*      */ import java.util.regex.Pattern;
/*      */ import java.util.regex.PatternSyntaxException;
/*      */ import javax.swing.InputVerifier;
/*      */ import javax.swing.JComponent;
/*      */ import javax.swing.JPopupMenu;
/*      */ import javax.swing.JTextArea;
/*      */ import javax.swing.TransferHandler;
/*      */ import javax.swing.border.Border;
/*      */ import javax.swing.text.BadLocationException;
/*      */ import javax.swing.text.Document;
/*      */ import mcframe.clientCore.acl.MCACLManager;
/*      */ import mcframe.clientCore.beans.MCBeans;
/*      */ import mcframe.clientCore.beans.MCBeansDelegate;
/*      */ import mcframe.clientCore.beans.MCBeansFocusListener;
/*      */ import mcframe.clientCore.beans.MCBeansMouseListener;
/*      */ import mcframe.clientCore.beans.MCBeansUtil;
/*      */ import mcframe.clientCore.beans.MCCacheType;
/*      */ import mcframe.clientCore.beans.MCEventProxy;
/*      */ import mcframe.clientCore.beans.MCLabel;
/*      */ import mcframe.clientCore.beans.MCMode;
/*      */ import mcframe.clientCore.beans.MCModeBeans;
/*      */ import mcframe.clientCore.beans.MCModeInfo;
/*      */ import mcframe.clientCore.beans.MCPopupProxy;
/*      */ import mcframe.clientCore.beans.MCPropertyCache;
/*      */ import mcframe.clientCore.beans.MCResourceBeans;
/*      */ import mcframe.clientCore.beans.MCRootPanel;
/*      */ import mcframe.clientCore.beans.MCRowBeans;
/*      */ import mcframe.clientCore.beans.MCScrollPane;
/*      */ import mcframe.clientCore.beans.MCTabOrderBeans;
/*      */ import mcframe.clientCore.beans.MCTextProxy;
/*      */ import mcframe.clientCore.beans.action.MCActionBeans;
/*      */ import mcframe.clientCore.beans.action.MCKeyActionManager;
/*      */ import mcframe.clientCore.beans.list.MCLinkedBeans;
/*      */ import mcframe.clientCore.beans.popup.MCPopupBeans;
/*      */ import mcframe.clientCore.beans.popup.MCPopupConfig;
/*      */ import mcframe.clientCore.beans.popup.MCPopupMenu;
/*      */ import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
/*      */ import mcframe.clientCore.beans.text.MCDocumentBeans;
/*      */ import mcframe.clientCore.beans.text.MCIMDelegate;
/*      */ import mcframe.clientCore.beans.text.MCInputMethodType;
/*      */ import mcframe.clientCore.beans.text.MCInputVerifier;
/*      */ import mcframe.clientCore.beans.text.MCTextDocument;
/*      */ import mcframe.clientCore.beans.text.MCValueChecker;
/*      */ import mcframe.clientCore.container.MCConstRow;
/*      */ import mcframe.clientCore.container.MCRowEvent;
/*      */ import mcframe.clientCore.container.MCRowListener;
/*      */ import mcframe.clientCore.event.MCAPListener;
/*      */ import mcframe.clientCore.event.MCDCBeans;
/*      */ import mcframe.clientCore.event.MCDCListener;
/*      */ import mcframe.clientCore.event.MCEventBeans;
/*      */ import mcframe.clientCore.event.MCEventInfo;
/*      */ import mcframe.clientCore.event.MCEventList;
/*      */ import mcframe.clientCore.event.MCEventListener;
/*      */ import mcframe.clientCore.event.MCFDListener;
/*      */ import mcframe.clientCore.event.MCNCBeans;
/*      */ import mcframe.clientCore.event.MCNCListener;
/*      */ import mcframe.clientCore.event.MCNCReceiver;
/*      */ import mcframe.clientCore.event.MCNEBeans;
/*      */ import mcframe.clientCore.event.MCNEListener;
/*      */ import mcframe.clientCore.event.MCNEReceiver;
/*      */ import mcframe.clientCore.event.MCNXBeans;
/*      */ import mcframe.clientCore.event.MCNXListener;
/*      */ import mcframe.clientCore.event.MCNXReceiver;
/*      */ import mcframe.clientCore.event.MCVCBeans;
/*      */ import mcframe.clientCore.event.MCVCListener;
/*      */ import mcframe.clientCore.event.MCVCReceiver;
/*      */ import mcframe.clientCore.resource.MCConst;
/*      */ import mcframe.commonCore.container.MCRow;
/*      */ import mcframe.commonCore.lang.MCDataType;
/*      */ import mcframe.commonCore.lang.MCStringUtil;
/*      */ import mcframe.commonCore.meta.MCMeta;
/*      */ import mcframe.commonCore.notice.Core_Msg;
/*      */ import mcframe.commonCore.notice.MCException;
/*      */ import mcframe.commonCore.notice.MCLog;
/*      */ import mcframe.commonCore.notice.MCMessage;
/*      */ import mcframe.commonCore.notice.MCMessageList;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MCTextArea
/*      */   extends JTextArea
/*      */   implements MCTabOrderBeans, MCModeBeans, MCRowBeans, MCVCBeans, MCVCReceiver, MCNCBeans, MCNCReceiver, MCNEBeans, MCNEReceiver, MCNXBeans, MCNXReceiver, MCLinkedBeans, MCPopupBeans, MCDCBeans, MCDocumentBeans, MCActionBeans
/*      */ {
/*  110 */   private MCBeansDelegate _delegate = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String _trim_pattern;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  126 */   private MCTextPopupMenuItem _popup_cut = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  134 */   private MCTextPopupMenuItem _popup_copy = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  142 */   private MCTextPopupMenuItem _popup_paste = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  150 */   private MCTextPopupMenuItem _popup_open = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  158 */   private MCTextPopupMenuItem _popup_open_editor = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  166 */   private MCAPListener _popup_listener = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  174 */   private MCConstRow _link_row = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  182 */   private String _link_column_name = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  190 */   private MCDataType _link_type = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  198 */   private MCMeta _meta = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  206 */   private MCMode _mode = MCMode.NULL;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  214 */   private MCLabel _label = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  222 */   private MCEventInfo _event_info = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  230 */   private final MCEventList _event_list = new MCEventList();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  238 */   private int _length = Integer.MAX_VALUE;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _input_method_editing = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  254 */   private MCPopupConfig _popup_config = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _stock_editable = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  270 */   private MCValueChecker _value_checker = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _ignore_status = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  286 */   private MCRootPanel _panel = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  294 */   private MCRootPanel _init_panel = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _auto_focus = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _selectall = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  318 */   private String _message_name_resource = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  326 */   private String _message_name = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  334 */   private String _label_name = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  342 */   private Font _default_font = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  349 */   private Rectangle _default_ratio_bounds = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  357 */   private MCInputMethodType _input_method_type = MCInputMethodType.NONE;
/*      */ 
/*      */   
/*      */   private MCIMDelegate _im_delegate;
/*      */ 
/*      */   
/*      */   private boolean _required_flg = false;
/*      */ 
/*      */   
/*      */   private boolean _read_only_flg;
/*      */ 
/*      */   
/*      */   boolean _is_handle_processing;
/*      */ 
/*      */   
/*      */   private boolean _move_caret_position;
/*      */ 
/*      */   
/*      */   private List<Pattern> _accept_ptn;
/*      */ 
/*      */   
/*      */   private List<Character> _except_chars;
/*      */ 
/*      */   
/*      */   private Rectangle _default_bounds;
/*      */ 
/*      */   
/*      */   private MCFDListener _file_drop_listener;
/*      */ 
/*      */   
/*      */   private boolean _drop_enable;
/*      */ 
/*      */   
/*      */   protected boolean _isVisibleForMode;
/*      */ 
/*      */   
/*      */   protected boolean _isVisibleForPersonalize;
/*      */ 
/*      */   
/*      */   MouseWheelListener _wheelListener;
/*      */ 
/*      */   
/*      */   protected String getFontKey() {
/*  400 */     return MCConst.createKey(new String[] { getType(), "font" });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getSelectedFGKey() {
/*  411 */     return MCConst.createKey(new String[] { getType(), "selfg" });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getSelectedBGKey() {
/*  422 */     return MCConst.createKey(new String[] { getType(), "selbg" });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getCaretColorKey() {
/*  433 */     return MCConst.createKey(new String[] { getType(), "caretcolor" });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getAutoFocusKey() {
/*  444 */     return MCConst.createKey(new String[] { getType(), "autofocus" });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getSelectAllKey() {
/*  455 */     return MCConst.createKey(new String[] { getType(), "selectall" });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getTrimPatternKey() {
/*  466 */     return MCConst.createKey(new String[] { getType(), "trim" });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getTabSizeKey() {
/*  477 */     return MCConst.createKey(new String[] { getType(), "tabsize" });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void init() {
/*  487 */     initBeans();
/*  488 */     initResource();
/*  489 */     initKeyAssign();
/*  490 */     initPopupMenu();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initResource() {
/*  501 */     Font f = MCConst.beans.getFont(getFontKey());
/*  502 */     if (f != null) {
/*  503 */       setFont(f);
/*      */     }
/*      */ 
/*      */     
/*  507 */     Color cc = MCConst.beans.getColor(getCaretColorKey());
/*  508 */     if (cc != null) {
/*  509 */       setCaretColor(cc);
/*      */     }
/*      */ 
/*      */     
/*  513 */     Color fg = MCConst.beans.getColor(getSelectedFGKey());
/*  514 */     if (fg != null) {
/*  515 */       setSelectedTextColor(fg);
/*      */     }
/*      */ 
/*      */     
/*  519 */     Color bg = MCConst.beans.getColor(getSelectedBGKey());
/*  520 */     if (bg != null) {
/*  521 */       setSelectionColor(bg);
/*      */     }
/*      */ 
/*      */     
/*  525 */     boolean a = MCConst.beans.getBoolean(getAutoFocusKey(), isAutoFocus());
/*  526 */     setAutoFocus(a);
/*      */ 
/*      */ 
/*      */     
/*  530 */     boolean s = MCConst.beans.getBoolean(getSelectAllKey(), isSelectAll());
/*  531 */     setSelectAll(s);
/*      */ 
/*      */ 
/*      */     
/*  535 */     String t = MCConst.beans.getString(getTrimPatternKey());
/*  536 */     if (t != null) {
/*  537 */       setTrimPattern(t);
/*      */     }
/*      */ 
/*      */     
/*  541 */     int i = MCConst.beans.getInteger(getTabSizeKey(), getTabSize());
/*  542 */     setTabSize(i);
/*      */ 
/*      */     
/*  545 */     String m = MCBeansUtil.getLabelMsg(getName());
/*  546 */     if (m != null) {
/*  547 */       this._message_name_resource = m;
/*      */     }
/*      */ 
/*      */     
/*  551 */     String l = MCBeansUtil.getLabel(getName());
/*  552 */     if (l != null) {
/*  553 */       this._label_name = l;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initKeyAssign() {
/*  565 */     MCKeyActionManager.init((MCResourceBeans)this, getInputMap(), getActionMap());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initBeans() {
/*  575 */     setDocument((Document)new MCTextDocument(this));
/*  576 */     addFocusListener((FocusListener)MCBeansFocusListener.getInstance());
/*      */     
/*  578 */     addMouseListener((MouseListener)MCBeansMouseListener.getInstance());
/*      */ 
/*      */     
/*  581 */     addMouseWheelListener(this._wheelListener);
/*      */ 
/*      */     
/*  584 */     setMargin(new Insets(0, 1, 0, 1));
/*  585 */     setInputVerifier((InputVerifier)new MCInputVerifier());
/*      */ 
/*      */     
/*  588 */     setTransferHandler((TransferHandler)new MCTextAreaTransferHandler(this));
/*  589 */     this._file_drop_listener = (MCFDListener)new MCTextAreaFDListener(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initPopupMenu() {
/*  600 */     setComponentPopupMenu(new MCPopupMenu(this));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setName(String name) {
/*  616 */     setName(name, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setName(String name, boolean init) {
/*  631 */     MCBeansUtil.checkName(name);
/*  632 */     super.setName(name);
/*  633 */     if (init) {
/*  634 */       updateResource();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public String getType() {
/*  640 */     return "textarea";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCTextPopupMenuItem getCutMenuItem() {
/*  651 */     if (this._popup_cut == null) {
/*  652 */       this._popup_cut = MCBeansUtil.createPopupMenuItem(this, 
/*  653 */           "POPUP_CUT");
/*      */     }
/*  655 */     return this._popup_cut;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCTextPopupMenuItem getCopyMenuItem() {
/*  666 */     if (this._popup_copy == null) {
/*  667 */       this._popup_copy = MCBeansUtil.createPopupMenuItem(this, 
/*  668 */           "POPUP_COPY");
/*      */     }
/*  670 */     return this._popup_copy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCTextPopupMenuItem getPasteMenuItem() {
/*  681 */     if (this._popup_paste == null) {
/*  682 */       this._popup_paste = MCBeansUtil.createPopupMenuItem(this, 
/*  683 */           "POPUP_PASTE");
/*      */     }
/*  685 */     return this._popup_paste;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCTextPopupMenuItem getOpenMenuItem() {
/*  696 */     if (this._popup_open == null) {
/*  697 */       this._popup_open = MCBeansUtil.createPopupMenuItem(this, 
/*  698 */           "POPUP_OPEN");
/*      */     }
/*  700 */     return this._popup_open;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCTextPopupMenuItem getOpenEditorMenuItem() {
/*  711 */     if (this._popup_open_editor == null) {
/*  712 */       this._popup_open_editor = MCBeansUtil.createPopupMenuItem(this, 
/*  713 */           "POPUP_OPEN_EDITOR");
/*      */     }
/*  715 */     return this._popup_open_editor;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setRow(MCConstRow row, MCMeta meta) {
/*  720 */     MCBeansUtil.checkRow(this, (MCRow)row, meta);
/*  721 */     if (this._link_row != null) {
/*  722 */       this._link_row.removeRowListener((MCRowListener)this);
/*      */     }
/*  724 */     this._link_row = row;
/*  725 */     String name = meta.name();
/*  726 */     this._link_column_name = name;
/*  727 */     this._link_type = getBaseRow().getDataType(getBaseRowColumnName());
/*  728 */     setMeta(meta);
/*  729 */     row.removeRowListener(name, (MCRowListener)this);
/*  730 */     row.addRowListener(name, new MCRowListener[] { (MCRowListener)this });
/*      */     
/*  732 */     setRowToView();
/*      */     
/*  734 */     moveCaretPosition(0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setMeta(MCMeta meta) {
/*  749 */     this._meta = meta;
/*  750 */     if (meta != null) {
/*  751 */       setLength(meta.length());
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public MCMeta getMeta() {
/*  757 */     return this._meta;
/*      */   }
/*      */ 
/*      */   
/*      */   public MCConstRow getBaseRow() {
/*  762 */     MCConstRow r = this._link_row;
/*  763 */     return (r != null) ? (MCConstRow)r.getRootRow() : null;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getBaseRowColumnName() {
/*  768 */     MCConstRow r = this._link_row;
/*  769 */     return (r != null) ? r.getRootRowColumnPath(this._link_column_name) : this._link_column_name;
/*      */   }
/*      */ 
/*      */   
/*      */   public MCConstRow getRow() {
/*  774 */     return this._link_row;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getRowColumnName() {
/*  779 */     return this._link_column_name;
/*      */   }
/*      */ 
/*      */   
/*      */   public MCDataType getDataType() {
/*  784 */     return this._link_type;
/*      */   }
/*      */ 
/*      */   
/*      */   public void valueChanged(MCRowEvent event) {
/*  789 */     setRowToView();
/*      */ 
/*      */     
/*  792 */     if (this._move_caret_position) {
/*  793 */       moveCaretPosition(0);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRowToView() {
/*  800 */     MCBeansUtil.checkThread();
/*  801 */     MCConstRow r = getBaseRow();
/*  802 */     String n = getBaseRowColumnName();
/*  803 */     if (!MCBeansUtil.isNull(r, n)) {
/*  804 */       String v = MCStringUtil.convertToLF(r.getString(n));
/*  805 */       if (MCStringUtil.isNull(v)) {
/*  806 */         v = null;
/*      */       }
/*  808 */       String t = getText();
/*  809 */       if (MCStringUtil.isNull(t)) {
/*  810 */         t = null;
/*      */       }
/*  812 */       if (!MCStringUtil.eq(v, t)) {
/*  813 */         MCEventProxy.PROXY.setValue(getEventInfo(), v);
/*  814 */         boolean e = MCBeansUtil.isEventEnabled();
/*      */         try {
/*  816 */           MCBeansUtil.setEventEnabled(false);
/*  817 */           setText(v);
/*      */         } finally {
/*      */           
/*  820 */           MCBeansUtil.setEventEnabled(e);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setRowToViews() {
/*  828 */     setRowToView();
/*      */   }
/*      */ 
/*      */   
/*      */   public void localeChanged() {
/*  833 */     updateResource();
/*  834 */     MCPopupMenu m = getComponentPopupMenu();
/*  835 */     if (m != null)
/*  836 */       m.localeChanged(); 
/*      */   }
/*      */   @Deprecated
/*      */   public MCTextArea(String name) {
/*  840 */     this._read_only_flg = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2250 */     this._is_handle_processing = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2487 */     this._move_caret_position = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2882 */     this._accept_ptn = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2970 */     this._except_chars = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3053 */     this._default_bounds = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3268 */     this._drop_enable = MCBeansUtil.isDropEnable((MCBeans)this);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3350 */     this._isVisibleForMode = true;
/* 3351 */     this._isVisibleForPersonalize = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3398 */     this._wheelListener = (MouseWheelListener)new Object(this);
/*      */     setName(name, false);
/*      */     init();
/*      */   }
/*      */   
/*      */   private void setReadOnlyFlg(boolean flg) {
/*      */     this._read_only_flg = flg;
/*      */     setMode(this._mode);
/*      */   }
/*      */   
/*      */   private boolean getReadOnlyFlg() {
/*      */     return this._read_only_flg;
/*      */   }
/*      */   
/*      */   public void setMode(MCMode mode) {
/*      */     if (MCMode.isNull(mode))
/*      */       return; 
/*      */     MCMode m = mode;
/*      */     if (getModeInfo(m).getStatus() == 1)
/*      */       if (getReadOnlyFlg()) {
/*      */         m = MCMode.READ_ONLY;
/*      */       } else if (getRequiredFlg()) {
/*      */         m = MCMode.REQUIRED;
/*      */       }  
/*      */     if (this._mode != mode)
/*      */       this._mode = mode; 
/*      */     MCRootPanel bp = getBaseRootPanel();
/*      */     MCBeansUtil.log(bp, (MCBeans)this, Core_Msg.FCBAC0013, new Object[] { m.getName() });
/*      */     MCModeInfo mi = getModeInfo(m);
/*      */     MCScrollPane sp = getScrollPane();
/*      */     switch (mi.getStatus()) {
/*      */       case 1:
/*      */         setVisible(true);
/*      */         setEnabled(true);
/*      */         setFocusable(true);
/*      */         setEditable(true);
/*      */         sp.setVisible(true);
/*      */         break;
/*      */       case 2:
/*      */         setVisible(true);
/*      */         setEnabled(true);
/*      */         setFocusable(true);
/*      */         setEditable(false);
/*      */         sp.setVisible(true);
/*      */         break;
/*      */       case 3:
/*      */         setVisible(false);
/*      */         sp.setVisible(false);
/*      */         break;
/*      */     } 
/*      */     setForeground(mi.getForeground());
/*      */     setBackground(mi.getBackground());
/*      */     MCBeansUtil.log(bp, (MCBeans)this, Core_Msg.FCBAC0014, new Object[] { m.getName() });
/*      */     MCLabel l = getLabel();
/*      */     if (l != null)
/*      */       l.setMode(m); 
/*      */   }
/*      */   
/*      */   public MCMode getMode() {
/*      */     MCMode m = this._mode;
/*      */     MCModeInfo i = getModeInfo(m);
/*      */     if (i != null && i.getStatus() == 1)
/*      */       if (getReadOnlyFlg()) {
/*      */         m = MCMode.READ_ONLY;
/*      */       } else if (getRequiredFlg()) {
/*      */         m = MCMode.REQUIRED;
/*      */       }  
/*      */     return m;
/*      */   }
/*      */   
/*      */   public void setLabel(MCLabel label) {
/*      */     if (this._label != null)
/*      */       this._label.setLabelFor(null); 
/*      */     this._label = label;
/*      */     if (label != null) {
/*      */       label.setLabelFor(this);
/*      */       if (this._label_name != null)
/*      */         label.setText(this._label_name); 
/*      */     } 
/*      */   }
/*      */   
/*      */   public MCLabel getLabel() {
/*      */     return this._label;
/*      */   }
/*      */   
/*      */   public void append(String value) {
/*      */     if (value != null) {
/*      */       String v = getValue();
/*      */       setValue((v != null) ? v.concat(value) : value);
/*      */     } 
/*      */   }
/*      */   
/*      */   public MCMessageList setViewValue(int index, Comparable<?> value) {
/*      */     return setViewValue(value);
/*      */   }
/*      */   
/*      */   public void setViewValue(int index, Comparable<?> value, MCMessageList list) {
/*      */     setViewValue(value, list);
/*      */   }
/*      */   
/*      */   public MCMessageList setViewValue(Comparable<?> value) {
/*      */     MCMessageList l = new MCMessageList();
/*      */     setViewValue(value, l);
/*      */     return l;
/*      */   }
/*      */   
/*      */   public void setViewValue(Comparable<?> value, MCMessageList list) {
/*      */     if (list == null)
/*      */       list = new MCMessageList(); 
/*      */     if (value != null) {
/*      */       if (value instanceof String) {
/*      */         setValue((String)value, list);
/*      */       } else {
/*      */         list.add(MCBeansUtil.createCauseMsg(this, Core_Msg.FCBAC0068, new Object[0]));
/*      */       } 
/*      */     } else {
/*      */       setValue(null, list);
/*      */     } 
/*      */   }
/*      */   
/*      */   public String getViewValue(int index) {
/*      */     return getViewValue();
/*      */   }
/*      */   
/*      */   public String getViewValue() {
/*      */     return getValue();
/*      */   }
/*      */   
/*      */   public MCMessageList setValue(String value) {
/*      */     return setValue(value, null);
/*      */   }
/*      */   
/*      */   protected MCMessageList setValue(String value, MCMessageList list) {
/*      */     if (list == null)
/*      */       list = new MCMessageList(); 
/*      */     int cnt = list.size();
/*      */     value = (String)_adjustValue(value);
/*      */     value = MCBeansUtil._getExtractText(this, value);
/*      */     if (isValueChanged(value)) {
/*      */       canChange(value, list);
/*      */       if (list.size() == cnt) {
/*      */         setText(value);
/*      */         commitValue(true);
/*      */       } 
/*      */     } else {
/*      */       setRowToViews();
/*      */     } 
/*      */     return list;
/*      */   }
/*      */   
/*      */   protected Comparable<?> _adjustValue(Comparable<?> value) {
/*      */     if (value instanceof String) {
/*      */       String v = MCStringUtil.convertToLF((String)value);
/*      */       v = MCBeansUtil.trim(v, getTrimPattern());
/*      */       return v;
/*      */     } 
/*      */     return value;
/*      */   }
/*      */   
/*      */   public String getValue() {
/*      */     String t = getText();
/*      */     String v = MCBeansUtil.trim(t, getTrimPattern());
/*      */     if (!MCStringUtil.eq(t, v))
/*      */       setText(v); 
/*      */     return !MCStringUtil.isNull(v) ? v : null;
/*      */   }
/*      */   
/*      */   public void setText(String text) {
/*      */     boolean a = isAutoFocus();
/*      */     try {
/*      */       setAutoFocus(false);
/*      */       super.setText((text != null) ? text : "");
/*      */     } finally {
/*      */       setAutoFocus(a);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void clear() {
/*      */     MCBeansUtil.clear(this, null);
/*      */   }
/*      */   
/*      */   public void addAllListener(MCEventListener listener) {
/*      */     addNCListener((MCNCListener)listener);
/*      */     addNEListener((MCNEListener)listener);
/*      */     addNXListener((MCNXListener)listener);
/*      */     addVCListener((MCVCListener)listener);
/*      */     addDCListener((MCDCListener)listener);
/*      */   }
/*      */   
/*      */   public void setAllListener(MCEventListener listener) {
/*      */     setNCListener((MCNCListener)listener);
/*      */     setNEListener((MCNEListener)listener);
/*      */     setNXListener((MCNXListener)listener);
/*      */     setVCListener((MCVCListener)listener);
/*      */     setDCListener((MCDCListener)listener);
/*      */   }
/*      */   
/*      */   public final void addVCListener(MCVCListener listener) {
/*      */     this._event_list.add(listener);
/*      */   }
/*      */   
/*      */   public final void setVCListener(MCVCListener listener) {
/*      */     this._event_list.set(listener);
/*      */   }
/*      */   
/*      */   public final void removeVCListener(MCVCListener listener) {
/*      */     this._event_list.remove(listener);
/*      */   }
/*      */   
/*      */   public final MCVCListener[] getVCListeners() {
/*      */     return this._event_list.vc();
/*      */   }
/*      */   
/*      */   public boolean doVC() {
/*      */     return MCBeansUtil.vc(this);
/*      */   }
/*      */   
/*      */   public boolean isValueChanged() {
/*      */     return isValueChanged(getValue());
/*      */   }
/*      */   
/*      */   protected boolean isValueChanged(Comparable<?> value) {
/*      */     return isValueChanged(value, getRowValue());
/*      */   }
/*      */   
/*      */   protected boolean isValueChanged(Comparable<?> view, Comparable<?> row) {
/*      */     if (isInputMethodEditing())
/*      */       return true; 
/*      */     return getRootPanel().isValueChanged(this, _adjustValue(view), _adjustValue(row));
/*      */   }
/*      */   
/*      */   public String getRowValue() {
/*      */     MCConstRow c = getBaseRow();
/*      */     String n = getBaseRowColumnName();
/*      */     return !MCBeansUtil.isNull(c, n) ? c.getString(n) : null;
/*      */   }
/*      */   
/*      */   public boolean canChange() {
/*      */     return (canChange(getValue(), null).size() == 0);
/*      */   }
/*      */   
/*      */   protected MCMessageList canChange(String value, MCMessageList list) {
/*      */     if (list == null)
/*      */       list = new MCMessageList(); 
/*      */     int cnt = list.size();
/*      */     if (isInputMethodEditing()) {
/*      */       list.add(MCBeansUtil.createCauseMsg(this, Core_Msg.FCBAC0033, new Object[0]));
/*      */       return list;
/*      */     } 
/*      */     MCEventProxy.PROXY.setValue(getEventInfo(), getRowValue(), value);
/*      */     checkValue(value, list);
/*      */     if (list.size() == cnt)
/*      */       if (!doVC())
/*      */         list.add(MCBeansUtil.createCauseMsg(this, Core_Msg.FCBAC0032, new Object[] { value }));  
/*      */     if (list.size() != cnt)
/*      */       doCheckValueError(); 
/*      */     return list;
/*      */   }
/*      */   
/*      */   public final void addNCListener(MCNCListener listener) {
/*      */     this._event_list.add(listener);
/*      */   }
/*      */   
/*      */   public final void setNCListener(MCNCListener listener) {
/*      */     this._event_list.set(listener);
/*      */   }
/*      */   
/*      */   public final void removeNCListener(MCNCListener listener) {
/*      */     this._event_list.remove(listener);
/*      */   }
/*      */   
/*      */   public final MCNCListener[] getNCListeners() {
/*      */     return this._event_list.nc();
/*      */   }
/*      */   
/*      */   public void doNC() {
/*      */     MCBeansUtil.nc(this);
/*      */   }
/*      */   
/*      */   public void commitValue() {
/*      */     commitValue(false);
/*      */   }
/*      */   
/*      */   private void commitValue(boolean moveCaretPosition) {
/*      */     MCEventInfo tmpInfo = getEventInfo();
/*      */     Comparable<?> nv = tmpInfo.getNewValue();
/*      */     Comparable<?> ov = tmpInfo.getOldValue();
/*      */     setViewToRow(moveCaretPosition);
/*      */     MCEventProxy.PROXY.setValue(tmpInfo, ov, nv);
/*      */     doNC();
/*      */   }
/*      */   
/*      */   public final void addNEListener(MCNEListener listener) {
/*      */     this._event_list.add(listener);
/*      */   }
/*      */   
/*      */   public final void setNEListener(MCNEListener listener) {
/*      */     this._event_list.set(listener);
/*      */   }
/*      */   
/*      */   public final void removeNEListener(MCNEListener listener) {
/*      */     this._event_list.remove(listener);
/*      */   }
/*      */   
/*      */   public final MCNEListener[] getNEListeners() {
/*      */     return this._event_list.ne();
/*      */   }
/*      */   
/*      */   public void doNE() {
/*      */     MCEventProxy.PROXY.setValue(getEventInfo(), getRowValue());
/*      */     MCBeansUtil.ne(this);
/*      */   }
/*      */   
/*      */   public void focusGained() {
/*      */     doNE();
/*      */     focusGainedSelect();
/*      */     _installInputMethod();
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   protected void focusGainedSelect() {
/*      */     if (isSelectAll()) {
/*      */       selectAll();
/*      */     } else {
/*      */       if (getCaretPosition() < 0) {
/*      */         Document doc = getDocument();
/*      */         if (doc != null)
/*      */           select(doc.getLength(), doc.getLength()); 
/*      */       } 
/*      */       try {
/*      */         scrollRectToVisible(getUI().modelToView(this, getCaretPosition()));
/*      */       } catch (BadLocationException badLocationException) {}
/*      */     } 
/*      */   }
/*      */   
/*      */   public final void addNXListener(MCNXListener listener) {
/*      */     this._event_list.add(listener);
/*      */   }
/*      */   
/*      */   public final void setNXListener(MCNXListener listener) {
/*      */     this._event_list.set(listener);
/*      */   }
/*      */   
/*      */   public final void removeNXListener(MCNXListener listener) {
/*      */     this._event_list.remove(listener);
/*      */   }
/*      */   
/*      */   public final MCNXListener[] getNXListeners() {
/*      */     return this._event_list.nx();
/*      */   }
/*      */   
/*      */   public void doNX() {
/*      */     MCEventProxy.PROXY.setValue(getEventInfo(), getRowValue());
/*      */     MCBeansUtil.nx(this);
/*      */   }
/*      */   
/*      */   public void focusLost() {
/*      */     doNX();
/*      */     select(getCaretPosition(), getCaretPosition());
/*      */     _uninstallInputMethod();
/*      */   }
/*      */   
/*      */   public final void addDCListener(MCDCListener listener) {
/*      */     this._event_list.add(listener);
/*      */   }
/*      */   
/*      */   public final void setDCListener(MCDCListener listener) {
/*      */     this._event_list.set(listener);
/*      */   }
/*      */   
/*      */   public final void removeDCListener(MCDCListener listener) {
/*      */     this._event_list.remove(listener);
/*      */   }
/*      */   
/*      */   public final MCDCListener[] getDCListeners() {
/*      */     return this._event_list.dc();
/*      */   }
/*      */   
/*      */   public void doDC() {
/*      */     MCBeansUtil.dc(this);
/*      */   }
/*      */   
/*      */   public MCEventInfo getEventInfo() {
/*      */     if (this._event_info == null) {
/*      */       this._event_info = new MCEventInfo();
/*      */       MCEventProxy.PROXY.setComponent(this._event_info, (MCEventBeans)this);
/*      */     } 
/*      */     return this._event_info;
/*      */   }
/*      */   
/*      */   public MCMessageList checkValue(Comparable<?> value) {
/*      */     return getValueChecker().checkValue(this, value);
/*      */   }
/*      */   
/*      */   public boolean checkValue(Comparable<?> value, MCMessageList list) {
/*      */     MCMessageList l = getValueChecker().checkValue(this, value);
/*      */     boolean e = (l.size() == 0);
/*      */     if (!e && list != null)
/*      */       list.addAll((Collection)l); 
/*      */     return e;
/*      */   }
/*      */   
/*      */   public MCMessageList checkInputValue(String value) {
/*      */     return getValueChecker().checkInputValue(this, value);
/*      */   }
/*      */   
/*      */   public boolean checkInputValue(Comparable<?> value) {
/*      */     return checkInputValue(value, null);
/*      */   }
/*      */   
/*      */   public boolean checkInputValue(Comparable<?> value, MCMessageList list) {
/*      */     MCMessageList msg = getValueChecker().checkInputValue(this, value);
/*      */     boolean result = (msg.size() == 0);
/*      */     if (!result && list != null)
/*      */       list.addAll((Collection)msg); 
/*      */     return result;
/*      */   }
/*      */   
/*      */   public boolean isRequestFocusEnabled() {
/*      */     return (super.isRequestFocusEnabled() && isMCRequestFocusEnabled());
/*      */   }
/*      */   
/*      */   protected boolean isMCRequestFocusEnabled() {
/*      */     return MCBeansUtil.isFocusable(this);
/*      */   }
/*      */   
/*      */   public void mcRequestFocus() {
/*      */     MCBeansUtil.focus(this);
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public void grabFocus() {
/*      */     super.grabFocus();
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public void requestFocus() {
/*      */     doFocus(false);
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public boolean requestFocus(boolean temporary) {
/*      */     return doFocus(temporary);
/*      */   }
/*      */   
/*      */   protected boolean doFocus(boolean temporary) {
/*      */     if (super.requestFocus(temporary)) {
/*      */       if (!temporary)
/*      */         afterRequestFocus(); 
/*      */       return true;
/*      */     } 
/*      */     return false;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public boolean requestFocusInWindow() {
/*      */     return super.requestFocusInWindow();
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   protected boolean requestFocusInWindow(boolean temporary) {
/*      */     return super.requestFocusInWindow(temporary);
/*      */   }
/*      */   
/*      */   public void afterRequestFocus() {
/*      */     MCRootPanel panel = getBaseRootPanel();
/*      */     MCBeansUtil.afterRequestFocus(panel, this);
/*      */     MCBeansUtil.scrollRectToVisible(panel, this);
/*      */   }
/*      */   
/*      */   public void setLength(int length) {
/*      */     this._length = (length < 0) ? Integer.MAX_VALUE : length;
/*      */   }
/*      */   
/*      */   public int getLength() {
/*      */     return this._length;
/*      */   }
/*      */   
/*      */   public boolean isInputMethodEditing() {
/*      */     return this._input_method_editing;
/*      */   }
/*      */   
/*      */   protected void setInputMethodEditing(boolean editing) {
/*      */     this._input_method_editing = editing;
/*      */   }
/*      */   
/*      */   protected void processInputMethodEvent(InputMethodEvent e) {
/*      */     if (!e.isConsumed() && isEditable())
/*      */       setInputMethodEditing((e.getText() != null && e.getCommittedCharacterCount() != e.getText().getEndIndex())); 
/*      */     super.processInputMethodEvent(e);
/*      */   }
/*      */   
/*      */   public MCRootPanel getRootPanel() {
/*      */     if (this._init_panel != null)
/*      */       return this._init_panel; 
/*      */     return getNearestRootPanel();
/*      */   }
/*      */   
/*      */   public MCRootPanel getBaseRootPanel() {
/*      */     MCRootPanel p = getNearestRootPanel();
/*      */     return (p != null) ? p.getBaseRootPanel() : null;
/*      */   }
/*      */   
/*      */   public MCRootPanel getNearestRootPanel() {
/*      */     if (this._panel == null)
/*      */       this._panel = MCBeansUtil.getNearestRootPanel(this); 
/*      */     return this._panel;
/*      */   }
/*      */   
/*      */   public String getMessageByLocale() {
/*      */     String m = this._message_name;
/*      */     if (m == null)
/*      */       m = this._message_name_resource; 
/*      */     return MCBeansUtil.getNameForMessage((MCBeans)this, m);
/*      */   }
/*      */   
/*      */   public String getLabelByLocale() {
/*      */     MCLabel l = getLabel();
/*      */     return (l != null) ? l.getLabelByLocale() : null;
/*      */   }
/*      */   
/*      */   public void cut() {
/*      */     if (isEditable())
/*      */       super.cut(); 
/*      */   }
/*      */   
/*      */   public void paste() {
/*      */     if (isEditable()) {
/*      */       boolean temp = isAutoFocus();
/*      */       try {
/*      */         setAutoFocus(false);
/*      */         super.paste();
/*      */       } finally {
/*      */         setAutoFocus(temp);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public void setComponentPopupMenu(JPopupMenu popup) {
/*      */     if (popup instanceof MCPopupMenu)
/*      */       super.setComponentPopupMenu(popup); 
/*      */   }
/*      */   
/*      */   public void setComponentPopupMenu(MCPopupMenu popup) {
/*      */     super.setComponentPopupMenu((JPopupMenu)popup);
/*      */   }
/*      */   
/*      */   public void removeComponentPopupMenu() {
/*      */     setComponentPopupMenu(null);
/*      */   }
/*      */   
/*      */   public MCPopupMenu getComponentPopupMenu() {
/*      */     return (MCPopupMenu)super.getComponentPopupMenu();
/*      */   }
/*      */   
/*      */   public void setPopupConfig(MCPopupConfig config) {
/*      */     this._popup_config = config;
/*      */   }
/*      */   
/*      */   public MCPopupConfig getPopupConfig() {
/*      */     return this._popup_config;
/*      */   }
/*      */   
/*      */   public MCPopupMenu configurePopup() {
/*      */     boolean e = isEditable();
/*      */     if (!e && !MCBeansUtil.isTextSelected(this))
/*      */       return getRootPanel().configurePopup(); 
/*      */     addPopupMenuItems(new MCTextPopupMenuItem[] { getOpenMenuItem(), getCutMenuItem(), getCopyMenuItem(), getPasteMenuItem(), getOpenEditorMenuItem() });
/*      */     MCBeansUtil.setCutCopyPasteMenuVisible(this, getCutMenuItem(), getCopyMenuItem(), getPasteMenuItem());
/*      */     MCBeansUtil.setOpenMenuVisible(this, getOpenMenuItem());
/*      */     MCPopupProxy.PROXY.restoreVisible(new MCTextPopupMenuItem[] { getOpenEditorMenuItem() });
/*      */     MCPopupMenu m = configurePopup(getComponentPopupMenu());
/*      */     if (m != null)
/*      */       m.sort(); 
/*      */     return m;
/*      */   }
/*      */   
/*      */   protected MCPopupMenu configurePopup(MCPopupMenu menu) {
/*      */     MCPopupConfig pc = getPopupConfig();
/*      */     return menu = (pc != null) ? pc.configurePopup(menu, this) : menu;
/*      */   }
/*      */   
/*      */   private final void addPopupMenuItems(MCTextPopupMenuItem... items) {
/*      */     MCPopupMenu pm = getComponentPopupMenu();
/*      */     MCAPListener ap = getPopupActionListener();
/*      */     int idx = 0;
/*      */     byte b;
/*      */     int i;
/*      */     MCTextPopupMenuItem[] arrayOfMCTextPopupMenuItem;
/*      */     for (i = (arrayOfMCTextPopupMenuItem = items).length, b = 0; b < i; ) {
/*      */       MCTextPopupMenuItem mCTextPopupMenuItem = arrayOfMCTextPopupMenuItem[b];
/*      */       if (!pm.contains((Component)mCTextPopupMenuItem)) {
/*      */         mCTextPopupMenuItem.addAPListener(ap);
/*      */         pm.add(mCTextPopupMenuItem, idx++);
/*      */         mCTextPopupMenuItem.updateResource();
/*      */       } 
/*      */       b++;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void popupMenuWillBecomeVisible() {
/*      */     this._stock_editable = isEditable();
/*      */     setEditable(false);
/*      */   }
/*      */   
/*      */   public void popupMenuWillBecomeInvisible() {
/*      */     setEditable(this._stock_editable);
/*      */   }
/*      */   
/*      */   public void setValueChecker(MCValueChecker checker) {
/*      */     this._value_checker = checker;
/*      */   }
/*      */   
/*      */   public MCValueChecker getValueChecker() {
/*      */     if (this._value_checker == null)
/*      */       this._value_checker = new MCValueChecker(); 
/*      */     return this._value_checker;
/*      */   }
/*      */   
/*      */   protected void processEvent(AWTEvent e) {
/*      */     try {
/*      */       super.processEvent(e);
/*      */     } catch (Throwable t) {
/*      */       if (t instanceof ArrayIndexOutOfBoundsException && e instanceof java.awt.event.MouseEvent && (e.getID() == 500 || e.getID() == 506 || e.getID() == 501)) {
/*      */         MCLog.write(new MCMessage(Core_Msg.FCBAC9000, new Object[] { "6857057" }));
/*      */         return;
/*      */       } 
/*      */       handle(t);
/*      */       setRowToViews();
/*      */     } 
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public void handle(Throwable t) {
/*      */     if (!this._is_handle_processing) {
/*      */       this._is_handle_processing = true;
/*      */       try {
/*      */         setViewValue(getEventInfo().getOldValue());
/*      */         MCBeansUtil.handle(this, t);
/*      */       } finally {
/*      */         this._is_handle_processing = false;
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void processKeyEvent(KeyEvent e) {
/*      */     if (isMCFocusOwner())
/*      */       super.processKeyEvent(e); 
/*      */   }
/*      */   
/*      */   protected boolean isMCFocusOwner() {
/*      */     JComponent c = MCBeansUtil.getFocusOwner(this);
/*      */     return (c != null) ? ((this == c)) : hasFocus();
/*      */   }
/*      */   
/*      */   public void added() {
/*      */     this._panel = MCBeansUtil.getNearestRootPanel(this);
/*      */     if (MCMode.isNull(getMode()))
/*      */       setMode(MCMode.ENABLE); 
/*      */   }
/*      */   
/*      */   public void removed() {
/*      */     this._panel = MCBeansUtil.getNearestRootPanel(this);
/*      */   }
/*      */   
/*      */   public void updateResource() {
/*      */     updateResource(getBaseRootPanel());
/*      */   }
/*      */   
/*      */   public void updateResource(MCRootPanel panel) {
/*      */     if (panel != null) {
/*      */       if (!panel.isPartsFlag())
/*      */         MCKeyActionManager.initScreen((MCResourceBeans)this, getInputMap(), getActionMap()); 
/*      */       MCPropertyCache p = panel.getPropertyCache(MCCacheType.SCREEN);
/*      */       Font f = MCBeansUtil.getBeansFont(panel, p, getFontKey());
/*      */       if (f != null)
/*      */         setFont(f); 
/*      */       Color cc = MCBeansUtil.getBeansColor(panel, p, getCaretColorKey());
/*      */       if (cc != null)
/*      */         setCaretColor(cc); 
/*      */       Color fg = MCBeansUtil.getBeansColor(panel, p, getSelectedFGKey());
/*      */       if (fg != null)
/*      */         setSelectedTextColor(fg); 
/*      */       Color bg = MCBeansUtil.getBeansColor(panel, p, getSelectedBGKey());
/*      */       if (bg != null)
/*      */         setSelectionColor(bg); 
/*      */       boolean a = MCBeansUtil.getBeansBoolean(panel, p, getAutoFocusKey(), isAutoFocus());
/*      */       setAutoFocus(a);
/*      */       boolean s = MCBeansUtil.getBeansBoolean(panel, p, getSelectAllKey(), isSelectAll());
/*      */       setSelectAll(s);
/*      */       String t = MCBeansUtil.getBeansString(panel, p, getTrimPatternKey());
/*      */       if (t != null)
/*      */         setTrimPattern(t); 
/*      */       int i = MCBeansUtil.getBeansInteger(panel, p, getTabSizeKey(), getTabSize());
/*      */       setTabSize(i);
/*      */       String g = MCBeansUtil.getMessageName((MCResourceBeans)this);
/*      */       if (g != null)
/*      */         this._message_name_resource = g; 
/*      */       String b = MCBeansUtil.getLabel((MCBeans)this);
/*      */       if (b != null)
/*      */         this._label_name = b; 
/*      */       MCLabel l = getLabel();
/*      */       if (l != null)
/*      */         l.updateResource(panel); 
/*      */       MCPopupMenu m = getComponentPopupMenu();
/*      */       if (m != null)
/*      */         m.updateResource(panel); 
/*      */     } 
/*      */   }
/*      */   
/*      */   protected MCScrollPane getScrollPane() {
/*      */     Component c = getParent();
/*      */     while (c != null) {
/*      */       if (c instanceof MCScrollPane)
/*      */         return (MCScrollPane)c; 
/*      */       c = c.getParent();
/*      */     } 
/*      */     return null;
/*      */   }
/*      */   
/*      */   public MCScrollPane getScrollPaneForLayout() {
/*      */     return getScrollPane();
/*      */   }
/*      */   
/*      */   public final void setAutoFocus(boolean focus) {
/*      */     this._auto_focus = focus;
/*      */   }
/*      */   
/*      */   public boolean isAutoFocus() {
/*      */     if (MCBeansUtil.isBarcodeMode(this))
/*      */       return false; 
/*      */     return this._auto_focus;
/*      */   }
/*      */   
/*      */   public final void setSelectAll(boolean selectAll) {
/*      */     this._selectall = selectAll;
/*      */   }
/*      */   
/*      */   public boolean isSelectAll() {
/*      */     return this._selectall;
/*      */   }
/*      */   
/*      */   public void setTrimPattern(String pattern) {
/*      */     this._trim_pattern = pattern;
/*      */   }
/*      */   
/*      */   public String getTrimPattern() {
/*      */     return this._trim_pattern;
/*      */   }
/*      */   
/*      */   public void setViewToRow() {
/*      */     setViewToRow(false);
/*      */   }
/*      */   
/*      */   private void setViewToRow(boolean moveCaretPosition) {
/*      */     boolean m = this._move_caret_position;
/*      */     try {
/*      */       this._move_caret_position = moveCaretPosition;
/*      */       MCConstRow c = getBaseRow();
/*      */       String n = getBaseRowColumnName();
/*      */       if (!MCBeansUtil.isNull(c, n)) {
/*      */         c.setString(n, getValue());
/*      */         MCBeansUtil.setGUIModified(this, c);
/*      */       } 
/*      */     } finally {
/*      */       this._move_caret_position = m;
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean equalsIgnoreCase(Component compo) {
/*      */     return equals(compo);
/*      */   }
/*      */   
/*      */   public void doAfterInsert() {}
/*      */   
/*      */   public MCModeInfo getModeInfo() {
/*      */     return getModeInfo(getMode());
/*      */   }
/*      */   
/*      */   public final MCModeInfo getModeInfo(MCMode mode) {
/*      */     return getDelegate().getModeInfo(this, mode);
/*      */   }
/*      */   
/*      */   protected void doCheckValueError() {
/*      */     selectAll();
/*      */     MCBeansUtil.getErrorHandler((MCBeans)this).doCheckValueError((MCBeans)this);
/*      */   }
/*      */   
/*      */   public void initialized() {
/*      */     if (this._default_ratio_bounds == null)
/*      */       this._default_ratio_bounds = getBounds(); 
/*      */     if (this._default_font == null)
/*      */       this._default_font = getFont(); 
/*      */     this._init_panel = MCBeansUtil.getRootPanel(this);
/*      */     if (MCConst.beans.containsKey("p_autofocus"))
/*      */       setAutoFocus(MCConst.beans.getBoolean("p_autofocus")); 
/*      */     if (MCConst.beans.containsKey("p_selectall"))
/*      */       setSelectAll(MCConst.beans.getBoolean("p_selectall")); 
/*      */     setRequiredFlg(MCBeansUtil.getRequiredFlg(this, this));
/*      */     MCRootPanel bp = getBaseRootPanel();
/*      */     if (bp != null) {
/*      */       String itemid = MCBeansUtil.createGUIKey(this);
/*      */       setReadOnlyFlg(MCACLManager.isReadOnly(bp.getModuleID(), bp.getScreenID(), itemid));
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean doAction() {
/*      */     return false;
/*      */   }
/*      */   
/*      */   private MCBeansDelegate getDelegate() {
/*      */     if (this._delegate == null)
/*      */       this._delegate = new MCBeansDelegate(); 
/*      */     return this._delegate;
/*      */   }
/*      */   
/*      */   public final void addAliasName(String alias, MCRootPanel panel) {
/*      */     getDelegate().addAliasName(alias, panel);
/*      */   }
/*      */   
/*      */   public final void setAliasName(String alias, MCRootPanel panel) {
/*      */     getDelegate().setAliasName(alias, panel);
/*      */   }
/*      */   
/*      */   public final void removeAliasName(MCRootPanel panel) {
/*      */     getDelegate().removeAliasName(panel);
/*      */   }
/*      */   
/*      */   public final void removeAliasNames() {
/*      */     getDelegate().removeAliasNames();
/*      */   }
/*      */   
/*      */   public String getAliasName(MCRootPanel panel) {
/*      */     return getDelegate().getAliasName(panel);
/*      */   }
/*      */   
/*      */   public String[] getAliasNames() {
/*      */     return getDelegate().getAliasNames();
/*      */   }
/*      */   
/*      */   public void updateBounds(int ratio) {
/*      */     getScrollPane().updateBounds(ratio);
/*      */   }
/*      */   
/*      */   public void updateFontSize(int ratio) {
/*      */     MCBeansUtil.updateFontSize(this, ratio, this._default_font);
/*      */   }
/*      */   
/*      */   public final MCTabOrderBeans getNextBeans() {
/*      */     return getDelegate().getNextBeans();
/*      */   }
/*      */   
/*      */   public final void setNextBeans(MCTabOrderBeans compo, int updateType) {
/*      */     getDelegate().setNextBeans(this, compo, updateType);
/*      */   }
/*      */   
/*      */   public final void setNextBeans(MCTabOrderBeans compo) {
/*      */     getDelegate().setNextBeans(this, compo, 0);
/*      */   }
/*      */   
/*      */   public final void insertNextBeans(MCTabOrderBeans compo, int updateType) {
/*      */     getDelegate().insertNextBeans(this, compo, updateType);
/*      */   }
/*      */   
/*      */   public final void insertNextBeans(MCTabOrderBeans compo) {
/*      */     getDelegate().insertNextBeans(this, compo, 0);
/*      */   }
/*      */   
/*      */   public final void insertPreviousBeans(MCTabOrderBeans compo, int updateType) {
/*      */     getDelegate().insertPreviousBeans(this, compo, updateType);
/*      */   }
/*      */   
/*      */   public final void insertPreviousBeans(MCTabOrderBeans compo) {
/*      */     getDelegate().insertPreviousBeans(this, compo, 0);
/*      */   }
/*      */   
/*      */   public final MCTabOrderBeans getPreviousBeans() {
/*      */     return getDelegate().getPreviousBeans();
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public final void setPreviousBeans(MCTabOrderBeans compo) {
/*      */     getDelegate().setPreviousBeans(this, compo);
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public boolean isFocusableByKeybord() {
/*      */     return (isVisible() && isEnabled() && isFocusable() && isEditable());
/*      */   }
/*      */   
/*      */   public boolean isIgnoreStatus() {
/*      */     return this._ignore_status;
/*      */   }
/*      */   
/*      */   public void setIgnoreStatus(boolean ignore) {
/*      */     this._ignore_status = ignore;
/*      */   }
/*      */   
/*      */   public MCMode getMode(MCRootPanel panel, String status) {
/*      */     return getDelegate().getMode(panel, status);
/*      */   }
/*      */   
/*      */   public String[] getStatuses(MCRootPanel panel) {
/*      */     return getDelegate().getStatuses(panel);
/*      */   }
/*      */   
/*      */   public void putMode(MCRootPanel panel, String status, MCMode mode) {
/*      */     getDelegate().putMode(panel, status, mode);
/*      */   }
/*      */   
/*      */   public void setMode(MCRootPanel panel, String status) {
/*      */     setMode(getMode(panel, status));
/*      */   }
/*      */   
/*      */   public final boolean isTabOrderEnabled() {
/*      */     return getDelegate().isTabOrderEnabled();
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public final void setTabOrderEnabled(boolean enabled) {
/*      */     getDelegate().setTabOrderEnabled(enabled);
/*      */   }
/*      */   
/*      */   protected MCAPListener getPopupActionListener() {
/*      */     if (this._popup_listener == null)
/*      */       this._popup_listener = (MCAPListener)new MCPopupActionListener(this); 
/*      */     return this._popup_listener;
/*      */   }
/*      */   
/*      */   private String readFile(File file) throws IOException {
/*      */     StringBuilder sb = new StringBuilder();
/*      */     Exception exception1 = null, exception2 = null;
/*      */   }
/*      */   
/*      */   private void writeFile(File file) throws IOException {
/*      */     Exception exception1 = null, exception2 = null;
/*      */   }
/*      */   
/*      */   public List<Pattern> getAcceptPattern() {
/*      */     if (this._accept_ptn == null) {
/*      */       String k = MCConst.createKey(new String[] { getType(), "accept" });
/*      */       String ptn = MCConst.beans.getString(k);
/*      */       if (ptn != null)
/*      */         setAcceptPattern(ptn); 
/*      */     } 
/*      */     return this._accept_ptn;
/*      */   }
/*      */   
/*      */   public void setAcceptPattern(List<Pattern> l) {
/*      */     this._accept_ptn = l;
/*      */   }
/*      */   
/*      */   public void addAcceptPattern(String ptn) {
/*      */     List<Pattern> l = getAcceptPattern();
/*      */     if (l == null) {
/*      */       setAcceptPattern(ptn);
/*      */     } else {
/*      */       addAcceptPattern(l, ptn);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void addAcceptPattern(String ptn, int flags) {
/*      */     List<Pattern> l = getAcceptPattern();
/*      */     if (l == null) {
/*      */       setAcceptPattern(ptn, flags);
/*      */     } else {
/*      */       addAcceptPattern(l, ptn, flags);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void setAcceptPattern(String ptn) {
/*      */     this._accept_ptn = new ArrayList<>();
/*      */     addAcceptPattern(this._accept_ptn, ptn);
/*      */   }
/*      */   
/*      */   private void setAcceptPattern(String ptn, int flags) {
/*      */     this._accept_ptn = new ArrayList<>();
/*      */     addAcceptPattern(this._accept_ptn, ptn, flags);
/*      */   }
/*      */   
/*      */   private void addAcceptPattern(List<Pattern> l, String ptn) {
/*      */     try {
/*      */       l.add(Pattern.compile(ptn));
/*      */     } catch (PatternSyntaxException patternSyntaxException) {
/*      */       throw new MCException(Core_Msg.FCBAC0333, new Object[] { ptn });
/*      */     } 
/*      */   }
/*      */   
/*      */   private void addAcceptPattern(List<Pattern> l, String ptn, int flags) {
/*      */     try {
/*      */       l.add(Pattern.compile(ptn));
/*      */     } catch (PatternSyntaxException patternSyntaxException) {
/*      */       throw new MCException(Core_Msg.FCBAC0333, new Object[] { ptn, Integer.valueOf(flags) });
/*      */     } 
/*      */   }
/*      */   
/*      */   public List<Character> getExceptCharacter() {
/*      */     if (this._except_chars == null) {
/*      */       String k = MCConst.createKey(new String[] { getType(), "except" });
/*      */       String s = MCConst.beans.getString(k);
/*      */       if (s != null && s.length() > 0)
/*      */         setExceptCharacter(s.toCharArray()); 
/*      */     } 
/*      */     return this._except_chars;
/*      */   }
/*      */   
/*      */   public void setExceptCharacter(List<Character> l) {
/*      */     this._except_chars = l;
/*      */   }
/*      */   
/*      */   public void setExceptCharacter(char[] cs) {
/*      */     this._except_chars = new ArrayList<>();
/*      */     byte b;
/*      */     int i;
/*      */     char[] arrayOfChar;
/*      */     for (i = (arrayOfChar = cs).length, b = 0; b < i; ) {
/*      */       Character c = Character.valueOf(arrayOfChar[b]);
/*      */       this._except_chars.add(c);
/*      */       b++;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void addExceptCharacter(char c) {
/*      */     List<Character> l = getExceptCharacter();
/*      */     if (l == null) {
/*      */       this._except_chars = new ArrayList<>();
/*      */       l = this._except_chars;
/*      */     } 
/*      */     l.add(Character.valueOf(c));
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public Dimension getDefaultSize() {
/*      */     return getSize();
/*      */   }
/*      */   
/*      */   public Rectangle getDefaultBounds() {
/*      */     Rectangle a = this._default_ratio_bounds;
/*      */     return (a != null) ? a : bounds();
/*      */   }
/*      */   
/*      */   public void setDefaultRatioSize(Rectangle r) {
/*      */     this._default_ratio_bounds = r;
/*      */     setBounds(r);
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public void _cacheDefaultBounds(Rectangle bounds) {
/*      */     this._default_bounds = bounds;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public void _setDefaultBounds() {
/*      */     if (this._default_bounds != null)
/*      */       setBounds(this._default_bounds); 
/*      */   }
/*      */   
/*      */   public Rectangle _getDefaultBounds() {
/*      */     return this._default_bounds;
/*      */   }
/*      */   
/*      */   public void _setDefaultBounds(Rectangle r) {
/*      */     this._default_bounds = r;
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public JComponent getTargetComponent() {
/*      */     return this;
/*      */   }
/*      */   
/*      */   public JComponent getComponent() {
/*      */     return this;
/*      */   }
/*      */   
/*      */   public Comparable<?> doListFormat(Comparable<?> value) {
/*      */     return value;
/*      */   }
/*      */   
/*      */   public void setMessageName(String name) {
/*      */     this._message_name = MCBeansUtil.adjustMessageName(name);
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public String _getMessageName() {
/*      */     return this._message_name;
/*      */   }
/*      */   
/*      */   public void setRequiredFlg(boolean required) {
/*      */     this._required_flg = required;
/*      */     setMode(this._mode);
/*      */   }
/*      */   
/*      */   public boolean getRequiredFlg() {
/*      */     return this._required_flg;
/*      */   }
/*      */   
/*      */   public void setInputMethodType(MCInputMethodType type) {
/*      */     if (type == null)
/*      */       type = MCInputMethodType.NONE; 
/*      */     this._input_method_type = type;
/*      */   }
/*      */   
/*      */   public MCInputMethodType getInputMethodType() {
/*      */     if (MCMode.isDisable(this))
/*      */       return MCInputMethodType.OFF; 
/*      */     return this._input_method_type;
/*      */   }
/*      */   
/*      */   private MCIMDelegate getIMDelegate() {
/*      */     return (this._im_delegate != null) ? this._im_delegate : (this._im_delegate = MCTextProxy.PROXY.createIMDelegate());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   protected void _installInputMethod() {
/*      */     MCTextProxy.PROXY.installInputMethod(getIMDelegate(), this, getInputMethodType());
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   protected void _uninstallInputMethod() {
/*      */     MCTextProxy.PROXY.uninstallInputMethod(getIMDelegate(), this, getInputMethodType());
/*      */   }
/*      */   
/*      */   public void enableInputMethods(boolean enable) {
/*      */     if (getInputMethodType() == MCInputMethodType.OFF)
/*      */       enable = false; 
/*      */     super.enableInputMethods(enable);
/*      */   }
/*      */   
/*      */   public void setFocusable(boolean focusable) {
/*      */     super.setFocusable(focusable);
/*      */     MCBeansUtil.setFocusableAfter(this, focusable);
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public boolean _isLastInsert() {
/*      */     return (getLength() == MCStringUtil.codePointCount(getText()));
/*      */   }
/*      */   
/*      */   public Comparable<?> _adjustValueByFormat(Comparable<?> value) {
/*      */     return value;
/*      */   }
/*      */   
/*      */   public void setBorder(Border border) {
/*      */     MCRootPanel bp = getBaseRootPanel();
/*      */     boolean log = (bp != null && "FS".equals(bp.getModuleID()) && "FSBAP0130".equals(bp.getScreenID()));
/*      */     if (log)
/*      */       MCLog.write(Core_Msg.FCBAC0410, new Object[0]); 
/*      */     super.setBorder(border);
/*      */     if (log)
/*      */       MCLog.write(Core_Msg.FCBAC0411, new Object[] { getBorder() }); 
/*      */   }
/*      */   
/*      */   private boolean canFD(TransferHandler.TransferSupport support) {
/*      */     return (this._drop_enable && this._file_drop_listener != null && this._file_drop_listener.canFDEvent());
/*      */   }
/*      */   
/*      */   private void doFD() {
/*      */     MCBeansUtil.fd(this, getBaseRootPanel(), this._file_drop_listener);
/*      */   }
/*      */   
/*      */   public String convToMaximumValues(String before, int offs, String str) {
/*      */     return getValueChecker().convMaximumValues(this, before, offs, str);
/*      */   }
/*      */   
/*      */   public boolean isVisibleForPersonalize() {
/*      */     return this._isVisibleForPersonalize;
/*      */   }
/*      */   
/*      */   public boolean isVisibleForMode() {
/*      */     return this._isVisibleForMode;
/*      */   }
/*      */   
/*      */   public void setVisibleForLayout(boolean b) {
/*      */     super.setVisible(b);
/*      */   }
/*      */   
/*      */   public void setVisibleForPersonalize(boolean b) {
/*      */     this._isVisibleForPersonalize = b;
/*      */   }
/*      */   
/*      */   public void setVisible(boolean flag) {
/*      */     this._isVisibleForMode = flag;
/*      */     if (!this._isVisibleForPersonalize) {
/*      */       super.setVisible(false);
/*      */     } else {
/*      */       super.setVisible(flag);
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\MCTextArea.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */