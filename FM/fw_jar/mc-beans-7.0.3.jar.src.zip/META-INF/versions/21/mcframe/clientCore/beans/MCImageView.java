/*      */ package META-INF.versions.21.mcframe.clientCore.beans;
/*      */ 
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Font;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.event.FocusListener;
/*      */ import java.awt.event.MouseListener;
/*      */ import java.net.URL;
/*      */ import java.util.Collection;
/*      */ import java.util.List;
/*      */ import javax.swing.ButtonModel;
/*      */ import javax.swing.Icon;
/*      */ import javax.swing.ImageIcon;
/*      */ import javax.swing.InputVerifier;
/*      */ import javax.swing.JButton;
/*      */ import javax.swing.JComponent;
/*      */ import javax.swing.JPopupMenu;
/*      */ import javax.swing.TransferHandler;
/*      */ import mcframe.clientCore.acl.MCACLManager;
/*      */ import mcframe.clientCore.beans.MCBeans;
/*      */ import mcframe.clientCore.beans.MCBeansDelegate;
/*      */ import mcframe.clientCore.beans.MCBeansFocusListener;
/*      */ import mcframe.clientCore.beans.MCBeansUtil;
/*      */ import mcframe.clientCore.beans.MCContainerProxy;
/*      */ import mcframe.clientCore.beans.MCEventProxy;
/*      */ import mcframe.clientCore.beans.MCLabel;
/*      */ import mcframe.clientCore.beans.MCMode;
/*      */ import mcframe.clientCore.beans.MCModeBeans;
/*      */ import mcframe.clientCore.beans.MCModeInfo;
/*      */ import mcframe.clientCore.beans.MCResourceBeans;
/*      */ import mcframe.clientCore.beans.MCRootPanel;
/*      */ import mcframe.clientCore.beans.MCRowBeans;
/*      */ import mcframe.clientCore.beans.MCTabOrderBeans;
/*      */ import mcframe.clientCore.beans.action.MCActionBeans;
/*      */ import mcframe.clientCore.beans.action.MCKeyActionManager;
/*      */ import mcframe.clientCore.beans.list.MCLinkedBeans;
/*      */ import mcframe.clientCore.beans.mouse.MCTransferHandler;
/*      */ import mcframe.clientCore.beans.popup.MCImageBeans;
/*      */ import mcframe.clientCore.beans.popup.MCImagePanelInfo;
/*      */ import mcframe.clientCore.beans.text.MCInputVerifier;
/*      */ import mcframe.clientCore.beans.text.MCValueChecker;
/*      */ import mcframe.clientCore.container.MCConstRow;
/*      */ import mcframe.clientCore.container.MCRowEvent;
/*      */ import mcframe.clientCore.container.MCRowListener;
/*      */ import mcframe.clientCore.event.MCDCBeans;
/*      */ import mcframe.clientCore.event.MCDCListener;
/*      */ import mcframe.clientCore.event.MCEventBeans;
/*      */ import mcframe.clientCore.event.MCEventInfo;
/*      */ import mcframe.clientCore.event.MCEventList;
/*      */ import mcframe.clientCore.event.MCEventListener;
/*      */ import mcframe.clientCore.event.MCFDBeans;
/*      */ import mcframe.clientCore.event.MCFDListener;
/*      */ import mcframe.clientCore.event.MCNCBeans;
/*      */ import mcframe.clientCore.event.MCNCListener;
/*      */ import mcframe.clientCore.event.MCNCReceiver;
/*      */ import mcframe.clientCore.event.MCNEBeans;
/*      */ import mcframe.clientCore.event.MCNEListener;
/*      */ import mcframe.clientCore.event.MCNEReceiver;
/*      */ import mcframe.clientCore.event.MCNXBeans;
/*      */ import mcframe.clientCore.event.MCNXListener;
/*      */ import mcframe.clientCore.event.MCNXReceiver;
/*      */ import mcframe.clientCore.event.MCVCBeans;
/*      */ import mcframe.clientCore.event.MCVCListener;
/*      */ import mcframe.clientCore.event.MCVCReceiver;
/*      */ import mcframe.clientCore.requester.MCDownloader;
/*      */ import mcframe.commonCore.container.MCRow;
/*      */ import mcframe.commonCore.lang.MCBinary;
/*      */ import mcframe.commonCore.lang.MCDataType;
/*      */ import mcframe.commonCore.lang.MCStringUtil;
/*      */ import mcframe.commonCore.meta.MCMeta;
/*      */ import mcframe.commonCore.notice.Core_Msg;
/*      */ import mcframe.commonCore.notice.MCMessageList;
/*      */ 
/*      */ public class MCImageView
/*      */   extends JButton
/*      */   implements MCTabOrderBeans, MCModeBeans, MCNEBeans, MCNEReceiver, MCNXBeans, MCNXReceiver, MCImageBeans, MCActionBeans, MCDCBeans, MCVCBeans, MCVCReceiver, MCNCBeans, MCNCReceiver, MCRowBeans, MCLinkedBeans, MCFDBeans {
/*   79 */   private MCConstRow _link_row = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   87 */   private String _link_column_name = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   95 */   private MCDataType _link_type = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  103 */   private MCMeta _meta = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  111 */   private MCMode _mode = MCMode.NULL;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  119 */   private MCLabel _label = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  127 */   private MCEventInfo _event_info = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  135 */   private final MCEventList _event_list = new MCEventList();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  143 */   private MCValueChecker _value_checker = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  151 */   private MCBeansDelegate _beans_delegate = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _ignore_status = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  167 */   private MCRootPanel _panel = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  175 */   private MCRootPanel _init_panel = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  183 */   private String _message_name_resource = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  191 */   private String _message_name = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  199 */   private String _label_name = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  207 */   private Rectangle _default_ratio_bounds = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  215 */   private Font _default_font = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  223 */   private MCBinary _view_value = null;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _image_panel_enabled = true;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _required_flg = false;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _read_only_flg;
/*      */ 
/*      */ 
/*      */   
/*      */   private Rectangle _default_bounds;
/*      */ 
/*      */ 
/*      */   
/*      */   boolean _is_handle_processing;
/*      */ 
/*      */ 
/*      */   
/*      */   private String[] _image_panel_id;
/*      */ 
/*      */ 
/*      */   
/*      */   private MCImagePanelInfo _image_panel_info;
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String uiClassID = "MCImageViewUI";
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _drop_enable;
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _isVisibleForMode;
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean _isVisibleForPersonalize;
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setName(String name) {
/*  272 */     setName(name, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void setName(String name, boolean init) {
/*  287 */     MCBeansUtil.checkName(name);
/*  288 */     super.setName(name);
/*  289 */     if (init) {
/*  290 */       updateResource();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void init() {
/*  301 */     initBeans();
/*  302 */     initKeyAssign();
/*  303 */     initResource();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initBeans() {
/*  313 */     setDefaultCapable(false);
/*  314 */     enableInputMethods(false);
/*  315 */     addFocusListener((FocusListener)MCBeansFocusListener.getInstance());
/*  316 */     addMouseListener((MouseListener)new MCMouseListener(this));
/*  317 */     setModel((ButtonModel)new MCImageLabelModel(this));
/*  318 */     setOpaque(false);
/*      */     
/*  320 */     setInputVerifier((InputVerifier)new MCInputVerifier());
/*      */ 
/*      */     
/*  323 */     setComponentPopupMenu((JPopupMenu)new Object(this));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  336 */     setTransferHandler((TransferHandler)new MCTransferHandler(this));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initKeyAssign() {
/*  347 */     MCKeyActionManager.init((MCResourceBeans)this, getInputMap(), getActionMap());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initResource() {
/*  358 */     String m = MCBeansUtil.getLabelMsg(getName());
/*  359 */     if (m != null) {
/*  360 */       this._message_name_resource = m;
/*      */     }
/*      */ 
/*      */     
/*  364 */     String l = MCBeansUtil.getLabel(getName());
/*  365 */     if (l != null) {
/*  366 */       this._label_name = l;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final MCBeansDelegate getDelegate() {
/*  378 */     if (this._beans_delegate == null) {
/*  379 */       this._beans_delegate = new MCBeansDelegate();
/*      */     }
/*  381 */     return this._beans_delegate;
/*      */   }
/*      */ 
/*      */   
/*      */   public void focusGained() {
/*  386 */     doNE();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean doAction() {
/*  391 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addAllListener(MCEventListener listener) {
/*  418 */     addNEListener((MCNEListener)listener);
/*  419 */     addNXListener((MCNXListener)listener);
/*  420 */     addNCListener((MCNCListener)listener);
/*  421 */     addVCListener((MCVCListener)listener);
/*  422 */     addDCListener((MCDCListener)listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public MCEventInfo getEventInfo() {
/*  427 */     if (this._event_info == null) {
/*  428 */       this._event_info = new MCEventInfo();
/*  429 */       MCEventProxy.PROXY.setComponent(this._event_info, (MCEventBeans)this);
/*      */     } 
/*  431 */     return this._event_info;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAllListener(MCEventListener listener) {
/*  458 */     setNEListener((MCNEListener)listener);
/*  459 */     setNXListener((MCNXListener)listener);
/*  460 */     setNCListener((MCNCListener)listener);
/*  461 */     setVCListener((MCVCListener)listener);
/*  462 */     setDCListener((MCDCListener)listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void addNEListener(MCNEListener listener) {
/*  467 */     this._event_list.add(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public void doNE() {
/*  472 */     MCBeansUtil.ne(this);
/*      */   }
/*      */ 
/*      */   
/*      */   public final MCNEListener[] getNEListeners() {
/*  477 */     return this._event_list.ne();
/*      */   }
/*      */ 
/*      */   
/*      */   public final void removeNEListener(MCNEListener listener) {
/*  482 */     this._event_list.remove(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNEListener(MCNEListener listener) {
/*  487 */     this._event_list.set(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void addNXListener(MCNXListener listener) {
/*  492 */     this._event_list.add(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public void doNX() {
/*  497 */     MCBeansUtil.nx(this);
/*      */   }
/*      */ 
/*      */   
/*      */   public final MCNXListener[] getNXListeners() {
/*  502 */     return this._event_list.nx();
/*      */   }
/*      */ 
/*      */   
/*      */   public final void removeNXListener(MCNXListener listener) {
/*  507 */     this._event_list.remove(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNXListener(MCNXListener listener) {
/*  512 */     this._event_list.set(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void addDCListener(MCDCListener listener) {
/*  517 */     this._event_list.add(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public void doDC() {
/*  522 */     MCBeansUtil.dc(this);
/*      */   }
/*      */ 
/*      */   
/*      */   public final MCDCListener[] getDCListeners() {
/*  527 */     return this._event_list.dc();
/*      */   }
/*      */ 
/*      */   
/*      */   public final void removeDCListener(MCDCListener listener) {
/*  532 */     this._event_list.remove(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setDCListener(MCDCListener listener) {
/*  537 */     this._event_list.set(listener);
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateResource() {
/*  542 */     updateResource(getBaseRootPanel());
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateResource(MCRootPanel panel) {
/*  547 */     if (panel != null) {
/*  548 */       if (!panel.isPartsFlag()) {
/*  549 */         MCKeyActionManager.initScreen((MCResourceBeans)this, getInputMap(), getActionMap());
/*      */       }
/*      */ 
/*      */       
/*  553 */       String b = MCBeansUtil.getLabel((MCBeans)this);
/*  554 */       if (b != null) {
/*  555 */         this._label_name = b;
/*      */       }
/*      */ 
/*      */       
/*  559 */       String m = MCBeansUtil.getMessageName((MCResourceBeans)this);
/*  560 */       if (m != null) {
/*  561 */         this._message_name_resource = m;
/*      */       }
/*      */ 
/*      */       
/*  565 */       setBounds();
/*      */ 
/*      */       
/*  568 */       MCLabel l = getMCLabel();
/*  569 */       if (l != null) {
/*  570 */         l.updateResource(panel);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public final MCTabOrderBeans getNextBeans() {
/*  577 */     return getDelegate().getNextBeans();
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNextBeans(MCTabOrderBeans compo, int updateType) {
/*  582 */     getDelegate().setNextBeans(this, compo, updateType);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setNextBeans(MCTabOrderBeans compo) {
/*  587 */     getDelegate().setNextBeans(this, compo, 0);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void insertNextBeans(MCTabOrderBeans compo, int updateType) {
/*  592 */     getDelegate().insertNextBeans(this, compo, updateType);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void insertNextBeans(MCTabOrderBeans compo) {
/*  597 */     getDelegate().insertNextBeans(this, compo, 0);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void insertPreviousBeans(MCTabOrderBeans compo, int updateType) {
/*  602 */     getDelegate().insertPreviousBeans(this, compo, updateType);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void insertPreviousBeans(MCTabOrderBeans compo) {
/*  607 */     getDelegate().insertPreviousBeans(this, compo, 0);
/*      */   }
/*      */ 
/*      */   
/*      */   public final MCTabOrderBeans getPreviousBeans() {
/*  612 */     return getDelegate().getPreviousBeans();
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public final void setPreviousBeans(MCTabOrderBeans compo) {
/*  618 */     getDelegate().setPreviousBeans(this, compo);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isFocusableByKeybord() {
/*  625 */     return (isVisible() && isFocusable() && 
/*  626 */       1 == getModeInfo(getMode()).getStatus());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isRequestFocusEnabled() {
/*  657 */     return (super.isRequestFocusEnabled() && isMCRequestFocusEnabled());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean isMCRequestFocusEnabled() {
/*  676 */     return MCBeansUtil.isFocusable(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void mcRequestFocus() {
/*  693 */     MCBeansUtil.focus(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void grabFocus() {
/*  706 */     super.grabFocus();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void requestFocus() {
/*  719 */     doFocus(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public boolean requestFocus(boolean temporary) {
/*  734 */     return doFocus(temporary);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean doFocus(boolean temporary) {
/*  763 */     if (super.requestFocus(temporary)) {
/*  764 */       if (!temporary) {
/*  765 */         afterRequestFocus();
/*      */       }
/*  767 */       return true;
/*      */     } 
/*  769 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public boolean requestFocusInWindow() {
/*  783 */     return super.requestFocusInWindow();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected boolean requestFocusInWindow(boolean temporary) {
/*  798 */     return super.requestFocusInWindow(temporary);
/*      */   }
/*      */ 
/*      */   
/*      */   public void afterRequestFocus() {
/*  803 */     MCRootPanel bp = getBaseRootPanel();
/*  804 */     MCBeansUtil.afterRequestFocus(bp, this);
/*  805 */     MCBeansUtil.scrollRectToVisible(bp, this);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void addAliasName(String alias, MCRootPanel panel) {
/*  810 */     getDelegate().addAliasName(alias, panel);
/*      */   }
/*      */ 
/*      */   
/*      */   public void added() {
/*  815 */     this._panel = MCBeansUtil.getNearestRootPanel(this);
/*  816 */     if (MCMode.isNull(getMode())) {
/*  817 */       setMode(MCMode.ENABLE);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean equalsIgnoreCase(Component compo) {
/*  823 */     return equals(compo);
/*      */   }
/*      */ 
/*      */   
/*      */   public final String getAliasName(MCRootPanel panel) {
/*  828 */     return getDelegate().getAliasName(panel);
/*      */   }
/*      */ 
/*      */   
/*      */   public final String[] getAliasNames() {
/*  833 */     return getDelegate().getAliasNames();
/*      */   }
/*      */ 
/*      */   
/*      */   public String getLabelByLocale() {
/*  838 */     MCLabel l = getMCLabel();
/*  839 */     return (l != null) ? l.getLabelByLocale() : null;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getMessageByLocale() {
/*  844 */     String m = this._message_name;
/*  845 */     if (m == null) {
/*  846 */       m = this._message_name_resource;
/*      */     }
/*  848 */     return MCBeansUtil.getNameForMessage((MCBeans)this, m);
/*      */   }
/*      */ 
/*      */   
/*      */   public MCRootPanel getRootPanel() {
/*  853 */     if (this._init_panel != null) {
/*  854 */       return this._init_panel;
/*      */     }
/*  856 */     return getNearestRootPanel();
/*      */   }
/*      */ 
/*      */   
/*      */   public MCRootPanel getBaseRootPanel() {
/*  861 */     MCRootPanel p = getNearestRootPanel();
/*  862 */     return (p != null) ? p.getBaseRootPanel() : null;
/*      */   }
/*      */ 
/*      */   
/*      */   public MCRootPanel getNearestRootPanel() {
/*  867 */     if (this._panel == null) {
/*  868 */       this._panel = MCBeansUtil.getNearestRootPanel(this);
/*      */     }
/*  870 */     return this._panel;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getType() {
/*  875 */     return "imageview";
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void initialized() {
/*  881 */     if (this._default_ratio_bounds == null) {
/*  882 */       this._default_ratio_bounds = getBounds();
/*      */     }
/*  884 */     if (this._default_font == null) {
/*  885 */       this._default_font = getFont();
/*      */     }
/*  887 */     this._init_panel = MCBeansUtil.getRootPanel(this);
/*      */     
/*  889 */     setRequiredFlg(MCBeansUtil.getRequiredFlg(this, this));
/*      */     
/*  891 */     setDndResourceInfo();
/*      */     
/*  893 */     MCRootPanel bp = getBaseRootPanel();
/*  894 */     if (bp != null) {
/*  895 */       String itemid = MCBeansUtil.createGUIKey(this);
/*  896 */       setReadOnlyFlg(MCACLManager.isReadOnly(bp.getModuleID(), bp.getScreenID(), itemid));
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void localeChanged() {
/*  902 */     updateResource();
/*      */   }
/*      */ 
/*      */   
/*      */   public final void removeAliasName(MCRootPanel panel) {
/*  907 */     getDelegate().removeAliasName(panel);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void removeAliasNames() {
/*  912 */     getDelegate().removeAliasNames();
/*      */   }
/*      */ 
/*      */   
/*      */   public void removed() {
/*  917 */     this._panel = MCBeansUtil.getNearestRootPanel(this);
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setAliasName(String alias, MCRootPanel panel) {
/*  922 */     getDelegate().setAliasName(alias, panel);
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateBounds(int ratio) {
/*  927 */     MCBeansUtil.updateBounds(this, ratio, this._default_ratio_bounds);
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateFontSize(int ratio) {
/*  932 */     MCBeansUtil.updateFontSize(this, ratio, this._default_font);
/*      */   }
/*      */ 
/*      */   
/*      */   public void focusLost() {
/*  937 */     doNX();
/*      */   }
/*      */   @Deprecated
/*  940 */   public MCImageView(String name) { this._read_only_flg = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1453 */     this._default_bounds = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1536 */     this._is_handle_processing = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1783 */     this._drop_enable = MCBeansUtil.isDropEnable((MCBeans)this);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1847 */     this._isVisibleForMode = true;
/* 1848 */     this._isVisibleForPersonalize = true; setName(name); init(); }
/*      */   private void setReadOnlyFlg(boolean flg) { this._read_only_flg = flg; setMode(this._mode); }
/*      */   private boolean getReadOnlyFlg() { return this._read_only_flg; }
/* 1851 */   public MCMode getMode() { MCMode m = this._mode; MCModeInfo i = getModeInfo(m); if (i != null && i.getStatus() == 1) if (getReadOnlyFlg()) { m = MCMode.READ_ONLY; } else if (getRequiredFlg()) { m = MCMode.REQUIRED; }   return m; } public MCMode getMode(MCRootPanel panel, String status) { return getDelegate().getMode(panel, status); } public MCModeInfo getModeInfo() { return getModeInfo(getMode()); } public MCModeInfo getModeInfo(MCMode mode) { return getDelegate().getModeInfo(this, mode); } public String[] getStatuses(MCRootPanel panel) { return getDelegate().getStatuses(panel); } public void putMode(MCRootPanel panel, String status, MCMode mode) { getDelegate().putMode(panel, status, mode); } public void setMode(MCMode mode) { if (MCMode.isNull(mode)) return;  MCMode m = mode; if (getModeInfo(m).getStatus() == 1) if (getReadOnlyFlg()) { m = MCMode.READ_ONLY; } else if (getRequiredFlg()) { m = MCMode.REQUIRED; }   if (MCBeansUtil.setMode(this, m)) { if (this._mode != mode) this._mode = mode;  MCModeInfo info = getModeInfo(this._mode); if (info.getStatus() == 2) { setEnabled(true); setFocusable(true); }  MCLabel l = getMCLabel(); if (l != null) l.setMode(m);  }  } public void setMode(MCRootPanel panel, String status) { setMode(getMode(panel, status)); } public final void addNCListener(MCNCListener listener) { this._event_list.add(listener); } public void doNC() { MCBeansUtil.nc(this); } public final MCNCListener[] getNCListeners() { return this._event_list.nc(); } public final void removeNCListener(MCNCListener listener) { this._event_list.remove(listener); } public final void setNCListener(MCNCListener listener) { this._event_list.set(listener); } public void commitValue() { setViewToRow(); doNC(); MCEventProxy.PROXY.setValue(getEventInfo(), (Comparable)getRowValue()); } public final void addVCListener(MCVCListener listener) { this._event_list.add(listener); } public boolean doVC() { return MCBeansUtil.vc(this); } public final MCVCListener[] getVCListeners() { return this._event_list.vc(); } public final void removeVCListener(MCVCListener listener) { this._event_list.remove(listener); } public final void setVCListener(MCVCListener listener) { this._event_list.set(listener); } public boolean canChange() { boolean e = doVC(); if (!e) doCheckValueError();  return e; } protected void doCheckValueError() { MCBeansUtil.getErrorHandler((MCBeans)this).doCheckValueError((MCBeans)this); } public boolean isValueChanged() { return isValueChanged((Comparable<?>)getViewValue()); } protected boolean isValueChanged(Comparable<?> value) { return isValueChanged(value, (Comparable<?>)getRowValue()); } protected boolean isValueChanged(Comparable<?> view, Comparable<?> row) { return getRootPanel().isValueChanged(this, view, row); } public boolean checkInputValue(Comparable<?> value, MCMessageList list) { MCMessageList l = getValueChecker().checkInputValue(this, value); boolean e = (l.size() == 0); if (!e && list != null) list.addAll((Collection)l);  return e; } public boolean checkInputValue(Comparable<?> value) { return checkInputValue(value, null); } public boolean checkValue(Comparable<?> value, MCMessageList list) { MCMessageList l = getValueChecker().checkValue(this, value); boolean e = (l.size() == 0); if (!e && list != null) list.addAll((Collection)l);  return e; } public MCMessageList checkValue(Comparable<?> value) { return getValueChecker().checkValue(this, value); } public void clear() { MCBeansUtil.clear(this, null); } public MCConstRow getBaseRow() { MCConstRow mCConstRow = this._link_row; return (mCConstRow != null) ? (MCConstRow)mCConstRow.getRootRow() : null; } public String getBaseRowColumnName() { MCConstRow c = this._link_row; return (c != null) ? c.getRootRowColumnPath(this._link_column_name) : this._link_column_name; } public MCDataType getDataType() { return this._link_type; } public MCMeta getMeta() { return this._meta; } public MCConstRow getRow() { return this._link_row; } public String getRowColumnName() { return this._link_column_name; } public MCBinary getRowValue() { MCConstRow c = getBaseRow(); String n = getBaseRowColumnName(); return !MCBeansUtil.isNull(c, n) ? c.getBinary(n) : null; } public MCBinary getViewValue() { return getValue(); } public MCBinary getValue() { return this._view_value; } public boolean isIgnoreStatus() { return this._ignore_status; } public void setIgnoreStatus(boolean ignore) { this._ignore_status = ignore; } public void setRow(MCConstRow row, MCMeta meta) { MCBeansUtil.checkRow(this, (MCRow)row, meta); setMeta(meta); setRow(row, meta.name()); } protected void setRow(MCConstRow row, String name) { if (this._link_row != null) this._link_row.removeRowListener((MCRowListener)this);  this._link_row = row; this._link_column_name = name; this._link_type = getBaseRow().getDataType(getBaseRowColumnName()); MCContainerProxy.proxy.setRowListener(row, name, (MCRowListener)this); setRowToView(); } protected void setMeta(MCMeta meta) { this._meta = meta; } public void setRowToView() { MCBeansUtil.checkThread(); MCConstRow c = getBaseRow(); String n = getBaseRowColumnName(); if (!MCBeansUtil.isNull(c, n)) { MCBinary v = c.getBinary(n); boolean e = MCBeansUtil.isEventEnabled(); try { MCBeansUtil.setEventEnabled(false); setIcon(v); this._view_value = v; } finally { MCBeansUtil.setEventEnabled(e); }  }  } public void setRowToViews() { setRowToView(); } public MCMessageList setValue(MCBinary value) { return setValue(value, null); } public MCMessageList setViewValue(Comparable<?> value) { MCMessageList l = new MCMessageList(); setViewValue(value, l); return l; } public void valueChanged(MCRowEvent event) { setRowToView(); } public boolean isVisibleForPersonalize() { return this._isVisibleForPersonalize; }
/*      */   public MCBinary getViewValue(int index) { return getViewValue(); }
/*      */   public void setViewValue(Comparable<?> value, MCMessageList list) { if (value != null) { if (value instanceof MCBinary) { setValue((MCBinary)value, list); } else if (list != null) { list.add(MCBeansUtil.createCauseMsg(this, Core_Msg.FCBAC0077, new Object[0])); }  } else { setValue(null, list); }  }
/*      */   protected MCMessageList setValue(MCBinary value, MCMessageList list) { if (list == null) list = new MCMessageList();  if (isValueChanged((Comparable<?>)value)) { MCEventInfo info = getEventInfo(); MCEventProxy.PROXY.setValue(info, (Comparable)this._view_value, (Comparable)value); if (canChange()) { setIcon(value); this._view_value = value; commitValue(); } else { list.add(MCBeansUtil.createCauseMsg(this, Core_Msg.FCBAC0032, new Object[] { value })); }  MCEventProxy.PROXY.setValue(info, (Comparable)value); } else { setRowToViews(); }  return list; }
/* 1855 */   public void setViewValue(int index, Comparable<?> value, MCMessageList list) { setViewValue(value, list); } public MCMessageList setViewValue(int index, Comparable<?> value) { return setViewValue(value); } public void setLabel(MCLabel label) { if (this._label != null) this._label.setLabelFor(null);  this._label = label; if (label != null) { label.setLabelFor(this); if (this._label_name != null) label.setText(this._label_name);  }  } public MCLabel getMCLabel() { return this._label; } protected void setBounds() { MCBeansUtil.setBounds((MCResourceBeans)this); } @Deprecated public void _cacheDefaultBounds(Rectangle bounds) { this._default_bounds = bounds; } @Deprecated public void _setDefaultBounds() { if (this._default_bounds != null) setBounds(this._default_bounds);  } public Rectangle _getDefaultBounds() { return this._default_bounds; } public void _setDefaultBounds(Rectangle r) { this._default_bounds = r; } public void setViewToRow() { MCConstRow c = getBaseRow(); String n = getBaseRowColumnName(); if (!MCBeansUtil.isNull(c, n)) { c.setBinary(n, getValue()); MCBeansUtil.setGUIModified(this, c); }  } public void setValueChecker(MCValueChecker checker) { this._value_checker = checker; } public MCValueChecker getValueChecker() { if (this._value_checker == null) this._value_checker = new MCValueChecker();  return this._value_checker; } protected void setIcon(MCBinary value) { if (value != null) { URL u = null; try { u = MCDownloader.getBinaryURL(value); } catch (Exception e) { handle(e); }  if (u != null) { setIcon(new ImageIcon(u)); return; }  }  setIcon((Icon)null); } @Deprecated public void handle(Throwable t) { if (!this._is_handle_processing) { this._is_handle_processing = true; try { setViewValue(getEventInfo().getOldValue()); MCBeansUtil.handle(this, t); } finally { this._is_handle_processing = false; }  }  } public Color getBackground() { return null; } public void showImagePanel() { if (!isImagePanelEnabled()) return;  MCRootPanel bp = getBaseRootPanel(); if (bp == null) return;  MCImagePanelInfo i = getImagePanelInfo(); if (i == null) i = _createImagePanelInfo();  String[] a = getImagePanelID(); MCRootPanel p = bp.createPanel(a[0], a[1], MCRootPanel.SCREEN_MODAL, new Object[] { "T1", null, i }); bp.showChildPanel(p, MCRootPanel.SINGLE, new Object[0]); } public boolean isImagePanelEnabled() { return this._image_panel_enabled; } public void setImagePanelEnabled(boolean enabled) { this._image_panel_enabled = enabled; } public String getImagePanelModuleID() { return getImagePanelID()[0]; } public String getImagePanelScreenID() { return getImagePanelID()[1]; } public String[] getImagePanelID() { if (this._image_panel_id != null) return this._image_panel_id;  return new String[] { "FS", "FSBAP0220" }; } public void setImagePanel(String module, String screen) { if (MCStringUtil.containsNull(new String[] { module, screen })) { this._image_panel_id = null; } else { this._image_panel_id = new String[] { module, screen }; }  } public final boolean isTabOrderEnabled() { return getDelegate().isTabOrderEnabled(); } @Deprecated public final void setTabOrderEnabled(boolean enabled) { getDelegate().setTabOrderEnabled(enabled); } public Dimension getDefaultSize() { Rectangle a = this._default_ratio_bounds; int w = (a != null) ? a.width : getWidth(); int h = (a != null) ? a.height : getHeight(); return new Dimension(w, h); } public Rectangle getDefaultBounds() { Rectangle a = this._default_ratio_bounds; return (a != null) ? a : bounds(); } public void setDefaultRatioSize(Rectangle r) { this._default_ratio_bounds = r; } @Deprecated public JComponent getTargetComponent() { return this; } public Comparable<?> doListFormat(Comparable<?> value) { return value; } public void setMessageName(String name) { this._message_name = MCBeansUtil.adjustMessageName(name); } @Deprecated public String _getMessageName() { return this._message_name; } public void setRequiredFlg(boolean required) { this._required_flg = required; setMode(this._mode); } public boolean getRequiredFlg() { return this._required_flg; } public void setFocusable(boolean focusable) { super.setFocusable(focusable); MCBeansUtil.setFocusableAfter(this, focusable); } public Comparable<?> _adjustValueByFormat(Comparable<?> value) { return value; } public void setImagePanelInfo(MCImagePanelInfo i) { this._image_panel_info = i; } public MCImagePanelInfo getImagePanelInfo() { return this._image_panel_info; } @Deprecated protected MCImagePanelInfo _createImagePanelInfo() { MCImagePanelInfo i = new MCImagePanelInfo(); i.setLinkComponent(this); return i; } public String getUIClassID() { return "MCImageViewUI"; } public void setFDListener(MCFDListener listener) { setFDListener("ALL", listener); } public void setFDListener(String extension, MCFDListener listener) { this._event_list.set(extension, listener); } public void addFDListener(MCFDListener listener) { addFDListener("ALL", listener); } public void addFDListener(String extension, MCFDListener listener) { this._event_list.add(extension, listener); } public void removeFDListener(MCFDListener listener) { removeFDListener("ALL", listener); } public void removeFDListener(String extension, MCFDListener listener) { this._event_list.remove(extension, listener); } public boolean canFD(TransferHandler.TransferSupport support) { if (!this._drop_enable) return false;  for (List<MCFDListener> list : (Iterable<List<MCFDListener>>)this._event_list.fd().values()) { for (MCFDListener l : list) { if (l.canFDEvent()) return true;  }  }  return false; } public void doFD() { MCBeansUtil.fd(this, this._event_list.fd()); } private void setDndResourceInfo() { if (!this._drop_enable || !this._event_list.fd().isEmpty()) return;  MCBeansUtil.setDndResourceInfo(this); } public boolean isVisibleForMode() { return this._isVisibleForMode; }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setVisibleForLayout(boolean b) {
/* 1860 */     super.setVisible(b);
/*      */   }
/*      */   
/*      */   public void setVisibleForPersonalize(boolean b) {
/* 1864 */     this._isVisibleForPersonalize = b;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setVisible(boolean flag) {
/* 1869 */     this._isVisibleForMode = flag;
/* 1870 */     if (!this._isVisibleForPersonalize) {
/* 1871 */       super.setVisible(false);
/*      */     } else {
/*      */       
/* 1874 */       super.setVisible(flag);
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\MCImageView.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */