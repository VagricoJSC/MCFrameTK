/*     */ package META-INF.versions.21.mcframe.clientCore.beans;
/*     */ 
/*     */ import java.awt.Font;
/*     */ import java.util.Collection;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCCalendarField;
/*     */ import mcframe.clientCore.beans.MCEventProxy;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.MCRowBeans;
/*     */ import mcframe.clientCore.beans.text.MCCalendarFormat;
/*     */ import mcframe.clientCore.beans.text.MCDateFormat;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.commonCore.lang.MCCalendarDate;
/*     */ import mcframe.commonCore.lang.MCDataType;
/*     */ import mcframe.commonCore.lang.MCDate;
/*     */ import mcframe.commonCore.notice.Core_Msg;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCMessageList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCDateField
/*     */   extends MCCalendarField<MCDate>
/*     */ {
/*  31 */   private MCDateFormat _format = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public MCDateField(String name) {
/*  44 */     super(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setViewValue(Comparable<?> value, MCMessageList list) {
/*  74 */     if (list == null) {
/*  75 */       list = new MCMessageList();
/*     */     }
/*  77 */     if (value != null) {
/*  78 */       if (value instanceof MCDate) {
/*  79 */         setValue((MCCalendarDate)value, list);
/*     */       } else {
/*  81 */         list.add(MCBeansUtil.createCauseMsg((MCRowBeans)this, Core_Msg.FCBAC0069, new Object[0]));
/*     */       } 
/*     */     } else {
/*  84 */       setValue(null, list);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCMessageList checkValue(Comparable<?> value) {
/* 108 */     return getValueChecker().checkValue(this, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCalendarFormat(MCDateFormat format) {
/* 120 */     this._format = format;
/*     */     
/* 122 */     if (format != null) {
/* 123 */       setFormatPattern(format.getCalendarPattern());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCDateFormat getCalendarFormat() {
/* 137 */     if (this._format == null) {
/* 138 */       this._format = new MCDateFormat();
/*     */     }
/* 140 */     return this._format;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkValue(Comparable<?> value, MCMessageList list) {
/* 164 */     MCMessageList l = getValueChecker().checkValue(this, value);
/* 165 */     boolean e = (l.size() == 0);
/* 166 */     if (!e && list != null) {
/* 167 */       list.addAll((Collection)l);
/*     */     }
/* 169 */     return e;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkInputValue(Comparable<?> value, MCMessageList list) {
/* 192 */     MCMessageList l = getValueChecker().checkInputValue(this, value);
/* 193 */     boolean e = (l.size() == 0);
/* 194 */     if (!e && list != null) {
/* 195 */       list.addAll((Collection)l);
/*     */     }
/* 197 */     return e;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCDate today() {
/* 202 */     MCDate d = null;
/*     */     
/* 204 */     MCRootPanel p = getRootPanel();
/* 205 */     if (p != null) {
/*     */       try {
/* 207 */         d = (MCDate)p.today(MCDataType.DATE);
/* 208 */       } catch (Exception exception) {
/* 209 */         d = null;
/*     */       } 
/*     */     }
/* 212 */     if (d == null) {
/* 213 */       d = MCDate.today();
/*     */     }
/* 215 */     return d;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean setValueNoListCheck(Comparable<?> value, MCMessageList list, boolean doLC) {
/* 220 */     boolean result = true;
/*     */     
/* 222 */     MCDate v = null;
/* 223 */     if (value != null) {
/* 224 */       if (result = value instanceof MCDate) {
/* 225 */         v = (MCDate)value;
/*     */       } else {
/*     */         
/* 228 */         list.add(MCBeansUtil.createCauseMsg((MCRowBeans)this, Core_Msg.FCBAC0069, new Object[0]));
/*     */       } 
/*     */     }
/*     */     
/* 232 */     boolean changed = false;
/* 233 */     if (result)
/*     */     {
/* 235 */       if (changed = isValueChanged((Comparable)v)) {
/*     */ 
/*     */         
/* 238 */         MCEventProxy.PROXY.setValue(getEventInfo(), (Comparable)getRowValue(), value);
/*     */         
/* 240 */         if ((result = checkInputValue((Comparable<?>)v, list)) && (result = doVC()))
/*     */         {
/*     */           
/* 243 */           setText((MCCalendarDate)v);
/* 244 */           setViewToRow();
/* 245 */           doNC();
/*     */         
/*     */         }
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 252 */         setRowToViews();
/*     */       } 
/*     */     }
/*     */     
/* 256 */     if (!result) {
/* 257 */       doCheckValueError();
/*     */     }
/* 259 */     else if (doLC && changed) {
/* 260 */       doLC();
/*     */     } 
/*     */     
/* 263 */     return result;
/*     */   }
/*     */   
/*     */   public MCDate getRowValue() {
/* 267 */     MCConstRow c = getBaseRow();
/* 268 */     String n = getBaseRowColumnName();
/* 269 */     return !MCBeansUtil.isNull(c, n) ? c.getDate(n) : null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setViewToRow(Comparable<?> value) {
/* 274 */     MCConstRow c = getBaseRow();
/* 275 */     String n = getBaseRowColumnName();
/* 276 */     if (!MCBeansUtil.isNull(c, n)) {
/* 277 */       c.setDate(n, (MCDate)value);
/* 278 */       MCBeansUtil.setGUIModified((MCRowBeans)this, c);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setListCalendarFormat(MCDateFormat format) {
/* 290 */     setListCalendarFormat((MCCalendarFormat)format);
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCCalendarFormat<MCDate> createListCalendarFormat() {
/* 295 */     return (MCCalendarFormat<MCDate>)new MCDateFormat();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCDateFormat getListCalendarFormat() {
/* 300 */     return (MCDateFormat)super.getListCalendarFormat();
/*     */   }
/*     */ 
/*     */   
/*     */   public Comparable<?> doListFormat(Comparable<?> value) {
/*     */     MCDate v;
/* 306 */     if (value == null || "".equals(value)) {
/* 307 */       v = null;
/*     */     }
/* 309 */     else if (value instanceof MCDate) {
/* 310 */       v = (MCDate)value;
/*     */     } else {
/*     */       
/* 313 */       throw new MCException(MCBeansUtil.createMsg(this, Core_Msg.FCBAC0351, new Object[] { value }));
/*     */     } 
/* 315 */     return getListCalendarFormat().doOutputFormat((MCCalendarDate)v);
/*     */   }
/*     */ 
/*     */   
/*     */   public Comparable<?> _adjustValueByFormat(Comparable<?> value) {
/* 320 */     if (value instanceof MCDate) {
/* 321 */       return (Comparable<?>)MCBeansUtil.adjustValueByFormat(
/* 322 */           (MCCalendarDate)value, getCalendarFormat().getInputPattern());
/*     */     }
/* 324 */     return value;
/*     */   }
/*     */   
/*     */   void _setFont(Font font) {
/* 328 */     setFont(font);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\MCDateField.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */