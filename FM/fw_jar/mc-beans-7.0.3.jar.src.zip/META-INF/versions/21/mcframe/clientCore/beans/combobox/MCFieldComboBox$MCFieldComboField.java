/*      */ package META-INF.versions.21.mcframe.clientCore.beans.combobox;
/*      */ 
/*      */ import java.awt.Color;
/*      */ import java.awt.event.FocusEvent;
/*      */ import javax.swing.JComponent;
/*      */ import javax.swing.JPopupMenu;
/*      */ import javax.swing.JTextField;
/*      */ import javax.swing.border.Border;
/*      */ import javax.swing.text.Document;
/*      */ import mcframe.clientCore.beans.MCBeansUtil;
/*      */ import mcframe.clientCore.beans.MCMode;
/*      */ import mcframe.clientCore.beans.MCModeInfo;
/*      */ import mcframe.clientCore.beans.MCTabOrderBeans;
/*      */ import mcframe.clientCore.beans.combobox.MCComboField;
/*      */ import mcframe.clientCore.beans.combobox.MCFieldComboBox;
/*      */ import mcframe.clientCore.beans.list.MCListType;
/*      */ import mcframe.commonCore.lang.MCStringUtil;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class MCFieldComboField
/*      */   extends JTextField
/*      */   implements MCComboField
/*      */ {
/*      */   private boolean _stk_editable = true;
/*      */   
/*      */   protected MCFieldComboField() {
/*  809 */     init();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void init() {
/*  819 */     initBeans();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initBeans() {
/*  829 */     if (MCFieldComboBox.this.DEFAULT_BORDER == null) {
/*  830 */       MCFieldComboBox.this.DEFAULT_BORDER = getBorder();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public JComponent getComponent() {
/*  836 */     return this;
/*      */   }
/*      */ 
/*      */   
/*      */   public void modeChanged(MCMode mode) {
/*  841 */     MCModeInfo i = MCFieldComboBox.this.getModeInfo(mode);
/*  842 */     int s = i.getStatus();
/*  843 */     switch (s) {
/*      */       case 1:
/*      */       case 2:
/*  846 */         setVisible(true);
/*  847 */         setEnabled(true);
/*  848 */         setFocusable(true);
/*  849 */         setEditable((s == 1));
/*  850 */         setForeground(i.getForeground());
/*  851 */         setBackground(i.getBackground());
/*      */         break;
/*      */       case 3:
/*  854 */         setVisible(false);
/*      */         break;
/*      */     } 
/*      */   }
/*      */   
/*      */   public void popupMenuWillBecomeInvisible() {
/*  860 */     setEditable(this._stk_editable);
/*      */   }
/*      */   
/*      */   public void popupMenuWillBecomeVisible() {
/*  864 */     this._stk_editable = isEditable();
/*  865 */     setEditable(false);
/*      */   }
/*      */ 
/*      */   
/*      */   public JPopupMenu getComponentPopupMenu() {
/*  870 */     return (JPopupMenu)MCFieldComboBox.this.getComponentPopupMenu();
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isRequestFocusEnabled() {
/*  875 */     return (super.isRequestFocusEnabled() && isMCRequestFocusEnabled());
/*      */   }
/*      */   
/*      */   protected boolean isMCRequestFocusEnabled() {
/*  879 */     return MCBeansUtil.isFocusable((JComponent)MCFieldComboBox.this);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void requestFocus() {
/*  885 */     doFocus(false);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public boolean requestFocus(boolean temporary) {
/*  891 */     return doFocus(temporary);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected boolean requestFocusInWindow(boolean temporary) {
/*  897 */     return super.requestFocusInWindow(temporary);
/*      */   }
/*      */   
/*      */   protected boolean doFocus(boolean temporary) {
/*  901 */     if (super.requestFocus(temporary)) {
/*  902 */       if (!temporary) {
/*  903 */         MCFieldComboBox.this.afterRequestFocus();
/*      */       }
/*  905 */       return true;
/*      */     } 
/*  907 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public void transferFocus() {
/*  912 */     MCFieldComboBox.this.transferFocus();
/*      */   }
/*      */ 
/*      */   
/*      */   public Document getDocument() {
/*  917 */     Document d = super.getDocument();
/*  918 */     if (d == null) {
/*  919 */       setDocument(d = createDefaultModel());
/*      */     }
/*  921 */     return d;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void selectForward() {
/*  932 */     String t = getText();
/*  933 */     if (MCStringUtil.isNull(t)) {
/*      */       return;
/*      */     }
/*  936 */     select(0, Math.min(getCaret().getMark(), getCaret().getDot()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void selectBackword() {
/*  947 */     String t = getText();
/*  948 */     if (MCStringUtil.isNull(t)) {
/*      */       return;
/*      */     }
/*  951 */     select(Math.max(getCaret().getMark(), getCaret().getDot()), t.length());
/*      */   }
/*      */ 
/*      */   
/*      */   public Color getCaretColor() {
/*  956 */     if (MCListType.SELECT_ONLY == MCFieldComboBox.this.getListType()) {
/*  957 */       return getBackground();
/*      */     }
/*  959 */     return super.getCaretColor();
/*      */   }
/*      */   
/*      */   protected void adjustText() {
/*  963 */     if (!MCFieldComboBox.this.isMCFocusOwner()) {
/*  964 */       String txt = getText();
/*  965 */       int cnt = (txt != null) ? txt.length() : 0;
/*  966 */       switch (getHorizontalAlignment()) {
/*      */         case 2:
/*  968 */           setCaretPosition(0);
/*      */           break;
/*      */         case 0:
/*  971 */           setCaretPosition(cnt / 2);
/*      */           break;
/*      */         case 4:
/*  974 */           setCaretPosition(cnt);
/*      */           break;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateUI() {
/*  984 */     setName("MCComboBox.textField");
/*  985 */     super.updateUI();
/*      */   }
/*      */ 
/*      */   
/*      */   public void paste() {
/*  990 */     if (isEditable()) {
/*  991 */       boolean a = MCFieldComboBox.this.isAutoFocus();
/*      */       try {
/*  993 */         MCFieldComboBox.this.setAutoFocus(false);
/*      */         
/*  995 */         super.paste();
/*      */       }
/*      */       finally {
/*      */         
/*  999 */         MCFieldComboBox.this.setAutoFocus(a);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setFocusable(boolean focusable) {
/* 1006 */     super.setFocusable(focusable);
/* 1007 */     MCBeansUtil.setFocusableAfter((MCTabOrderBeans)MCFieldComboBox.this, focusable);
/*      */   }
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public Border getDefaultFieldBorder() {
/* 1013 */     return MCFieldComboBox.this.DEFAULT_BORDER;
/*      */   }
/*      */ 
/*      */   
/*      */   public void requestFocus(FocusEvent.Cause cause) {
/* 1018 */     doFocus(false);
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\combobox\MCFieldComboBox$MCFieldComboField.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */