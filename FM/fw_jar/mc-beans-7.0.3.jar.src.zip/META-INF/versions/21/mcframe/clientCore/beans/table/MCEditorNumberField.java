/*     */ package META-INF.versions.21.mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.math.BigDecimal;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.border.Border;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCMode;
/*     */ import mcframe.clientCore.beans.MCNumberField;
/*     */ import mcframe.clientCore.beans.MCResourceBeans;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.action.MCKeyActionManager;
/*     */ import mcframe.clientCore.beans.list.MCLinkedBeans;
/*     */ import mcframe.clientCore.beans.list.MCListType;
/*     */ import mcframe.clientCore.beans.popup.MCPopupConfig;
/*     */ import mcframe.clientCore.beans.popup.MCPopupMenu;
/*     */ import mcframe.clientCore.beans.table.MCBeansProxy;
/*     */ import mcframe.clientCore.beans.table.MCCellUtil;
/*     */ import mcframe.clientCore.beans.table.MCColumnConfig;
/*     */ import mcframe.clientCore.beans.table.MCEditorBeans;
/*     */ import mcframe.clientCore.beans.table.MCTable;
/*     */ import mcframe.clientCore.beans.table.MCTableColumn;
/*     */ import mcframe.clientCore.beans.text.MCNumberDocument;
/*     */ import mcframe.clientCore.beans.text.MCNumberFormat;
/*     */ import mcframe.clientCore.event.MCEventInfo;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCEditorNumberField
/*     */   extends MCNumberField
/*     */   implements MCEditorBeans
/*     */ {
/*     */   private static final String TYPE = "table.column.number";
/*     */   private MCColumnConfig _column;
/*     */   private MCTable<?> _table;
/*     */   
/*     */   @Deprecated
/*     */   protected MCEditorNumberField(String name, MCColumnConfig column) {
/*  71 */     super(name);
/*  72 */     setColumnConfig(column);
/*  73 */     setTable(column.getBaseTable());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getType() {
/*  78 */     return "table.column.number";
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initBeans() {
/*  83 */     super.initBeans();
/*     */ 
/*     */     
/*  86 */     setFocusTraversalKeysEnabled(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initKeyAssign() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initResource() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setColumnConfig(MCColumnConfig column) {
/* 117 */     this._column = column;
/*     */   }
/*     */   
/*     */   public final MCColumnConfig getColumnConfig() {
/* 121 */     return this._column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setTable(MCTable<?> table) {
/* 132 */     this._table = table;
/*     */   }
/*     */   
/*     */   public final MCTable getTable() {
/* 136 */     return this._table;
/*     */   }
/*     */ 
/*     */   
/*     */   public final int getRowIndex() {
/* 141 */     return MCCellUtil.getRowIndex(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void transferFocus() {
/* 146 */     MCTable<?> t = getTable();
/* 147 */     t.transferFocus(getRowIndex(), t.getViewColumn(getColumnConfig()) + 1, false, 
/* 148 */         true, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public Border getDefaultBorder() {
/* 153 */     return MCCellUtil.DEFAULT_BORDER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setColumnInfo(int index, MCColumnConfig column) {
/* 165 */     setColumnConfig(column);
/* 166 */     MCTable<?> table = getTable();
/* 167 */     MCKeyActionManager.init((MCResourceBeans)this, getInputMap(), getActionMap());
/* 168 */     MCKeyActionManager.initScreen((MCResourceBeans)this, getInputMap(), getActionMap());
/* 169 */     MCMode mode = MCCellUtil.isCellEditable(index, column, table);
/* 170 */     setMode(mode);
/* 171 */     setForeground(MCCellUtil.getForeground(index, column, table, false, mode));
/* 172 */     setBackground(MCCellUtil.getBackground(index, column, table, false, mode));
/* 173 */     setFont(column.getFont());
/* 174 */     setCaretColor(MCCellUtil.getCaretColor(index, column, table));
/* 175 */     setSelectionColor(MCCellUtil.getSelectionColor(index, column, table));
/* 176 */     setSelectedTextColor(MCCellUtil.getSelectedTextColor(index, column, table));
/* 177 */     setMeta(column.getMeta());
/* 178 */     setLength(column.getLength(index), column.getScale(index), column
/* 179 */         .isMinusEnable(index));
/* 180 */     setNumberFormat(MCCellUtil.getNumberFormat(index, column, table, mode));
/*     */     
/* 182 */     setViewScale(MCCellUtil.getViewScale(index, column, table));
/* 183 */     setViewZeroType(MCCellUtil.getViewZeroType(index, column, table));
/* 184 */     setViewRoundingMode(MCCellUtil.getViewRoundingMode(
/* 185 */           index, column, table));
/*     */     
/* 187 */     setRow(column.getTable().getRow(index), column.getRowColumnName());
/*     */     
/* 189 */     setAutoFocus(column.isAutoFocus());
/* 190 */     setSelectAll(column.isSelectAll());
/* 191 */     setListConfig(column.getListConfig());
/* 192 */     Border border = MCCellUtil.getEditorBorder(index, column, table);
/* 193 */     if (border != null) {
/* 194 */       setBorder(border);
/*     */     } else {
/*     */       
/* 197 */       setBorder(getDefaultBorder());
/*     */     } 
/* 199 */     setListListener(column.getListListener());
/* 200 */     MCPopupMenu menu = getComponentPopupMenu();
/* 201 */     if (menu != null) {
/* 202 */       menu.updateResource();
/*     */     }
/*     */   }
/*     */   
/*     */   public Color getForeground() {
/* 207 */     Color c = null;
/* 208 */     int idx = getRowIndex();
/* 209 */     MCTable<?> table = getTable();
/* 210 */     if (table != null && idx >= 0) {
/* 211 */       MCMode mode = MCCellUtil.isCellEditable(idx, this._column, table);
/* 212 */       c = MCCellUtil.getForeground(idx, this._column, table, false, mode);
/*     */     } else {
/*     */       
/* 215 */       c = super.getForeground();
/*     */     } 
/* 217 */     return c;
/*     */   }
/*     */ 
/*     */   
/*     */   public Color getBackground() {
/* 222 */     Color c = null;
/* 223 */     int idx = getRowIndex();
/* 224 */     MCTable<?> table = getTable();
/* 225 */     if (table != null && idx >= 0) {
/* 226 */       MCMode mode = MCCellUtil.isCellEditable(idx, this._column, table);
/* 227 */       c = MCCellUtil.getBackground(idx, this._column, table, false, mode);
/*     */     } else {
/*     */       
/* 230 */       c = super.getBackground();
/*     */     } 
/* 232 */     return c;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCLinkedBeans[] getLinkBeans() {
/* 237 */     MCColumnConfig c = getColumnConfig();
/* 238 */     return (c != null) ? c.getLinkBeans() : super.getLinkBeans();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCRootPanel getRootPanel() {
/* 243 */     return MCCellUtil.getRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCRootPanel getNearestRootPanel() {
/* 248 */     return MCCellUtil.getNearestRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessageByLocale() {
/* 253 */     return getColumnConfig().getMessageByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLabelByLocale() {
/* 258 */     return getColumnConfig().getLabelByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterRequestFocus() {
/* 263 */     MCRootPanel bp = getBaseRootPanel();
/* 264 */     MCBeansUtil.afterRequestFocus(bp, (JComponent)getTable());
/* 265 */     MCBeansUtil.scrollRectToVisible(bp, (JComponent)this, getHorizontalAlignment());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 270 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void commitValue() {}
/*     */ 
/*     */   
/*     */   public boolean isFocusOwner() {
/* 279 */     MCTable<?> t = getTable();
/* 280 */     return (t != null) ? (t.isRemoveNotifyProcessing() ? super.isFocusOwner() : false) : 
/* 281 */       super.isFocusOwner();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValueChanged() {
/* 286 */     return isValueChanged((Comparable<?>)getRowValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValueChanged(Comparable<?> value) {
/* 300 */     return isValueChanged((Comparable<?>)getValue(), value);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isValueChanged(Comparable<?> view, Comparable<?> row) {
/* 305 */     return MCCellUtil.isValueChanged(this, view, row);
/*     */   }
/*     */   
/*     */   public void valueCommited() {
/* 309 */     MCRow row = null;
/* 310 */     if ("input".equals(getListConfig().getOpeType())) {
/* 311 */       MCList<?> l = getList();
/* 312 */       if (l != null) {
/* 313 */         MCRow[] a = l.toArray();
/* 314 */         MCNumber v = getValue();
/* 315 */         String n = getListNames()[0]; byte b; int i; MCRow[] arrayOfMCRow1;
/* 316 */         for (i = (arrayOfMCRow1 = a).length, b = 0; b < i; ) { MCRow r = arrayOfMCRow1[b];
/* 317 */           MCNumber val = r.getNumber(n);
/* 318 */           if (val != null && val.eq((BigDecimal)v)) {
/* 319 */             row = r; break;
/*     */           } 
/*     */           b++; }
/*     */       
/*     */       } 
/*     */     } 
/* 325 */     if (row == null && 
/* 326 */       getListType() == MCListType.FREE) {
/* 327 */       row = MCRow.create();
/* 328 */       MCBeansProxy.PROXY.addColumn(row, getListNames()[0], getDataType(), 
/* 329 */           (Comparable)getViewValue());
/*     */     } 
/*     */     
/* 332 */     ((MCTableColumn)getColumnConfig()).execLink(getTable().getMCEditingRow(), row, 
/* 333 */         true);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isMCFocusOwner() {
/* 338 */     MCTable<?> t = getTable();
/* 339 */     return (t != null) ? ((t.getMCEditorComponent() == this)) : isFocusOwner();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void focusGained() {
/* 345 */     MCNumberDocument d = getDocument();
/* 346 */     boolean e = d.isValueCheck();
/* 347 */     d.setValueCheck(false);
/*     */     try {
/* 349 */       setText(getRowValue());
/* 350 */       focusGainedSelect();
/*     */     } finally {
/*     */       
/* 353 */       d.setValueCheck(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void focusLost() {
/* 359 */     MCNumberDocument d = getDocument();
/* 360 */     boolean e = d.isValueCheck();
/* 361 */     d.setValueCheck(false);
/*     */     try {
/* 363 */       setText(getRowValue());
/*     */     } finally {
/*     */       
/* 366 */       d.setValueCheck(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setText(MCNumber value) {
/* 372 */     super.setText(value);
/*     */   }
/*     */   
/*     */   public String doFormat(MCNumber value) {
/*     */     String rtn;
/* 377 */     MCNumberFormat f = getNumberFormat();
/* 378 */     int fieldScale = getScale();
/*     */     
/* 380 */     if (isMCFocusOwner()) {
/* 381 */       rtn = f.doInputFormat(value, fieldScale);
/*     */     } else {
/*     */       
/* 384 */       rtn = f.doOutputFormat(value, fieldScale);
/*     */     } 
/* 386 */     return rtn;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCList doListEvent() {
/* 391 */     return getColumnConfig().doListEvent();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean doVC() {
/* 396 */     return getColumnConfig().doVC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNC() {
/* 401 */     getColumnConfig().doNC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNE() {
/* 406 */     getColumnConfig().doNE();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNX() {
/* 411 */     getColumnConfig().doNX();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doLC() {
/* 416 */     getColumnConfig().doLC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doDC() {
/* 421 */     getColumnConfig().doDC();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCEventInfo getEventInfo() {
/* 426 */     return getColumnConfig().getEventInfo();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRequestFocusEnabled() {
/* 431 */     return (MCCellUtil.isRequestFocusEnabled(this) && super.isRequestFocusEnabled());
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isMCRequestFocusEnabled() {
/* 436 */     return MCCellUtil.isFocusable(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public Border getBorder() {
/* 441 */     Border b = MCCellUtil.getBorder(this);
/* 442 */     return (b != null) ? b : super.getBorder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource(MCRootPanel panel) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doCheckValueError() {
/* 467 */     super.doCheckValueError();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCPopupConfig getPopupConfig() {
/* 472 */     MCTable<?> t = getTable();
/* 473 */     return (t != null) ? t.getPopupConfig() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCPopupMenu configurePopup(MCPopupMenu menu) {
/* 487 */     MCPopupConfig pc = getPopupConfig();
/* 488 */     return (pc != null) ? pc.configurePopup(menu, getTable(), getRowIndex(), 
/* 489 */         getColumnConfig()) : menu;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void processKeyEvent(KeyEvent e) {
/* 494 */     MCCellUtil.beforeKeyEvent(e, this);
/* 495 */     super.processKeyEvent(e);
/*     */   }
/*     */ 
/*     */   
/*     */   public Comparable<?> doListFormat(Comparable<?> value) {
/* 500 */     return getColumnConfig().doListFormat(getRowIndex(), value);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void execLink(MCRow row, boolean msg) {
/* 505 */     ((MCTableColumn)getColumnConfig()).execLink(getRowIndex(), row, msg);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\table\MCEditorNumberField.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */