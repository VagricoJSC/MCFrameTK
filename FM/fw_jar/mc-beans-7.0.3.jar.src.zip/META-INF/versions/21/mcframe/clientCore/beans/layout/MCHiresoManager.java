/*     */ package META-INF.versions.21.mcframe.clientCore.beans.layout;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.concurrent.Semaphore;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import javafx.application.Platform;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.FontUIResource;
/*     */ import mcframe.clientCore.beans.MCBeans;
/*     */ import mcframe.clientCore.beans.MCFileChooser;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.layout.MCHiresoManagerResolution;
/*     */ import mcframe.clientCore.beans.popup.MCPopupMenu;
/*     */ import mcframe.clientCore.beans.table.MCColumnGroupTableHeader;
/*     */ import mcframe.clientCore.beans.table.MCLayoutTableHeader;
/*     */ import mcframe.clientCore.beans.table.MCTable2Header;
/*     */ import mcframe.clientCore.resource.MCConst;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.resource.ctrl.MCResource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCHiresoManager
/*     */ {
/*  44 */   private static Integer _default = null;
/*     */   
/*  46 */   private static Double _dpi = null;
/*  47 */   private static Dimension _resolution = null;
/*  48 */   private static double _dpiScale = 1.5D;
/*  49 */   private static double _displaySize = 15.0D;
/*     */   
/*  51 */   private static Dimension _minResolution = new Dimension(1920, 1080);
/*     */ 
/*     */   
/*  54 */   private static Dimension _maxFrameSize = new Dimension(1360, 768);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int _font_rate_100 = 100;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getFontRatio() {
/*  68 */     initFontRatio();
/*  69 */     return _default.intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int initFontRatio() {
/*  79 */     _default = Integer.valueOf(_getFontRatio());
/*  80 */     return _default.intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected static int _getFontRatio() {
/*  86 */     if (!isEnableHighResolution()) {
/*  87 */       return 100;
/*     */     }
/*     */     
/*  90 */     String mode = getMode();
/*  91 */     if ("dot".equals(mode)) {
/*  92 */       Integer r = _getDefaultFontRatio();
/*  93 */       if (r == null) {
/*  94 */         return 100;
/*     */       }
/*  96 */       return r.intValue();
/*  97 */     }  if ("dpi".equals(mode)) {
/*  98 */       if (_resolution == null) {
/*  99 */         _getWinodwsDpi();
/*     */       }
/* 101 */       if (_resolution == null) {
/* 102 */         return 100;
/*     */       }
/* 104 */       Integer res_dpi = _getResourceDpi();
/* 105 */       if (res_dpi == null || res_dpi.intValue() == 0) {
/* 106 */         return 100;
/*     */       }
/* 108 */       if (_dpi == null) {
/* 109 */         return 100;
/*     */       }
/*     */ 
/*     */       
/* 113 */       int ratio = 100;
/* 114 */       if (_resolution.width <= _minResolution.width && _resolution.height <= _minResolution.height)
/* 115 */         return 100; 
/* 116 */       if (_dpi.doubleValue() > 108.0D) {
/* 117 */         ratio = (int)(_dpi.doubleValue() * 100.0D / res_dpi.intValue() * _dpiScale);
/*     */         
/* 119 */         Dimension d = new Dimension(_maxFrameSize.width * ratio / 100, _maxFrameSize.height * ratio / 100);
/* 120 */         if (_resolution.width < d.width || _resolution.height < d.height) {
/* 121 */           double s = Math.min(d.width / _resolution.width, d.height / _resolution.height);
/* 122 */           ratio = (int)(ratio * s);
/*     */         } 
/*     */         
/* 125 */         return ratio;
/*     */       } 
/* 127 */       return 100;
/* 128 */     }  if ("resolution".equals(mode)) {
/*     */       
/* 130 */       if (_resolution == null) {
/* 131 */         _getWinodwsDpi();
/*     */       }
/* 133 */       if (_resolution == null) {
/* 134 */         return 100;
/*     */       }
/* 136 */       if (_resolution_list == null) {
/* 137 */         _initFontRatio();
/*     */       }
/* 139 */       Integer r = _getFontRatio(_resolution);
/* 140 */       if (r == null) {
/* 141 */         return 100;
/*     */       }
/* 143 */       return r.intValue();
/*     */     } 
/*     */     
/* 146 */     return 100;
/*     */   }
/*     */ 
/*     */   
/*     */   protected static Double _getResourceDpiScale() {
/* 151 */     if (isEnableHighResolution()) {
/* 152 */       MCNumber dpi_scale = MCConst.beans.getNumber(MCResource.createKey(new String[] { "high_resolution.dpi_scale" }));
/* 153 */       if (dpi_scale != null) {
/* 154 */         return Double.valueOf(dpi_scale.doubleValue());
/*     */       }
/*     */     } 
/* 157 */     return Double.valueOf(1.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   protected static Double _getResourceDisplaySize() {
/* 162 */     if (isEnableHighResolution()) {
/* 163 */       MCNumber display_size = MCConst.beans.getNumber(MCResource.createKey(new String[] { "high_resolution.display_size" }));
/* 164 */       if (display_size != null) {
/* 165 */         return Double.valueOf(display_size.doubleValue());
/*     */       }
/*     */     } 
/* 168 */     return Double.valueOf(1.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   protected static Dimension _getResourceMinResolution() {
/* 173 */     if (isEnableHighResolution()) {
/* 174 */       String min_resolution = MCConst.beans.getString(MCResource.createKey(new String[] { "high_resolution.min_resolution" }));
/* 175 */       if (min_resolution != null) {
/* 176 */         String[] s = MCStringUtil.split(",", min_resolution);
/* 177 */         int s0 = Integer.valueOf(s[0]).intValue();
/* 178 */         int s1 = Integer.valueOf(s[1]).intValue();
/* 179 */         return new Dimension(s0, s1);
/*     */       } 
/*     */     } 
/* 182 */     return new Dimension(1920, 1080);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static Integer _getResourceDpi() {
/* 192 */     if (isEnableHighResolution()) {
/* 193 */       MCNumber dpi = MCConst.beans.getNumber(MCResource.createKey(new String[] { "high_resolution.dpi" }));
/* 194 */       if (dpi != null) {
/* 195 */         return Integer.valueOf(dpi.intValue());
/*     */       }
/*     */     } 
/* 198 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected static Double _getWinodwsDpi() {
/* 204 */     _dpiScale = _getResourceDpiScale().doubleValue();
/* 205 */     _displaySize = _getResourceDisplaySize().doubleValue();
/* 206 */     _minResolution = _getResourceMinResolution();
/*     */ 
/*     */     
/*     */     try {
/* 210 */       Semaphore lock = new Semaphore(0);
/*     */ 
/*     */       
/* 213 */       Platform.runLater((Runnable)new Object(lock));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 286 */         lock.tryAcquire(1000L, TimeUnit.MILLISECONDS);
/* 287 */       } catch (InterruptedException ex) {
/* 288 */         ex.printStackTrace();
/*     */       } 
/*     */ 
/*     */       
/* 292 */       return _dpi;
/*     */     }
/* 294 */     catch (Throwable ex) {
/* 295 */       ex.printStackTrace();
/*     */ 
/*     */       
/* 298 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isEnableHighResolution() {
/* 308 */     Boolean b = Boolean.valueOf(MCConst.beans.getBoolean(MCResource.createKey(new String[] { "high_resolution.enable" })));
/* 309 */     return b.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean _initUIManager = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void initUIManager() {
/* 321 */     if (!_initUIManager) {
/* 322 */       _initUIManager = true;
/* 323 */       String f = MCConst.beans.getString(MCResource.createKey(new String[] { "high_resolution.tooltip", "use-uimanager" }));
/* 324 */       if (!MCStringUtil.isNull(f) && "true".equalsIgnoreCase(f)) {
/*     */ 
/*     */ 
/*     */         
/* 328 */         Font fnt = MCConst.beans.getFont(MCResource.createKey(new String[] { "high_resolution.tooltip.font" }));
/* 329 */         if (fnt != null) {
/* 330 */           UIManager.put("ToolTip.font", new FontUIResource(fnt));
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getToolTipText(JComponent c, String s) {
/* 354 */     initUIManager();
/*     */     
/* 356 */     if (MCStringUtil.isNull(s))
/* 357 */       return null; 
/* 358 */     if (isEnableHighResolution()) {
/*     */       
/* 360 */       int fontRatio = getFontRatio();
/*     */ 
/*     */ 
/*     */       
/* 364 */       if (c instanceof MCColumnGroupTableHeader) {
/* 365 */         fontRatio = ((MCColumnGroupTableHeader)c).getMCTable().getRatio();
/*     */       }
/* 367 */       else if (c instanceof MCLayoutTableHeader) {
/* 368 */         fontRatio = ((MCLayoutTableHeader)c).getMCTable().getRatio();
/*     */       }
/* 370 */       else if (c instanceof MCTable2Header) {
/* 371 */         fontRatio = ((MCTable2Header)c).getMCTable().getRatio();
/*     */       } 
/*     */ 
/*     */       
/* 375 */       if (c != null && c instanceof MCBeans) {
/* 376 */         MCRootPanel rp2 = ((MCBeans)c).getBaseRootPanel();
/* 377 */         if (rp2 != null) {
/* 378 */           fontRatio = rp2.getFontRatio();
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 383 */       String s2 = toHTMLText(s, fontRatio);
/* 384 */       return s2;
/*     */     } 
/* 386 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String getTooltipFontSize() {
/* 392 */     String f = MCConst.beans.getString("high_resolution.tooltip.font");
/* 393 */     if (MCStringUtil.isNull(f)) {
/* 394 */       f = "name,style,24";
/*     */     }
/* 396 */     String[] nameStyleSize = f.split(",");
/* 397 */     return nameStyleSize[2];
/*     */   }
/*     */ 
/*     */   
/*     */   protected static String toHTMLText(String text, int ratio) {
/* 402 */     StringBuilder sb = new StringBuilder();
/* 403 */     if (!text.startsWith("<html>")) {
/* 404 */       sb.append("<html>");
/*     */ 
/*     */ 
/*     */       
/* 408 */       String fontFamily = MCConst.beans.getString(MCResource.createKey(new String[] { "high_resolution.tooltip", "font-family" }));
/* 409 */       String fontStyle = MCConst.beans.getString(MCResource.createKey(new String[] { "high_resolution.tooltip", "font-style" }));
/* 410 */       String fontColor = MCConst.beans.getString(MCResource.createKey(new String[] { "high_resolution.tooltip", "font-color" }));
/* 411 */       String fontSize = MCConst.beans.getString(MCResource.createKey(new String[] { "high_resolution.tooltip", "font-size" }));
/* 412 */       if (MCStringUtil.isNull(fontSize)) {
/* 413 */         fontSize = getTooltipFontSize();
/*     */       }
/*     */ 
/*     */       
/* 417 */       MCNumber n = MCNumber.valueOf(fontSize).multiply(ratio).divide(100);
/* 418 */       String fontSize2 = String.valueOf(n.intValue());
/*     */       
/* 420 */       sb.append("<font color=");
/* 421 */       sb.append(fontColor);
/* 422 */       sb.append(">");
/*     */       
/* 424 */       sb.append("<p style=\"");
/*     */       
/* 426 */       sb.append("font-size: ");
/* 427 */       sb.append(fontSize2);
/* 428 */       sb.append("px; ");
/*     */       
/* 430 */       if (!_initUIManager) {
/* 431 */         sb.append("font-family: ");
/* 432 */         sb.append(fontFamily);
/* 433 */         sb.append("; ");
/* 434 */         sb.append("font-weight: ");
/* 435 */         sb.append(fontStyle);
/* 436 */         sb.append("; ");
/*     */       } 
/*     */       
/* 439 */       sb.append("\">");
/*     */       
/* 441 */       sb.append(MCStringUtil.convertToLF(text).replaceAll("\n", "<br>"));
/*     */       
/* 443 */       sb.append("</p>");
/*     */       
/* 445 */       sb.append("</font>");
/*     */     } else {
/* 447 */       sb.append(MCStringUtil.convertToLF(text).replaceAll("\n", "<br>"));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 452 */     if (!text.endsWith("</html>")) {
/* 453 */       sb.append("</html>");
/*     */     }
/*     */     
/* 456 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   protected static String toHtmlColor(Color col) {
/* 461 */     if (col == null) {
/* 462 */       return "#FFFFFF";
/*     */     }
/* 464 */     StringBuilder sb = new StringBuilder();
/* 465 */     sb.append("#");
/*     */ 
/*     */     
/* 468 */     String colCode = Integer.toHexString(col.getRed());
/* 469 */     sb.append((colCode.length() == 1) ? ("0" + colCode) : colCode);
/*     */ 
/*     */     
/* 472 */     colCode = Integer.toHexString(col.getGreen());
/* 473 */     sb.append((colCode.length() == 1) ? ("0" + colCode) : colCode);
/*     */ 
/*     */     
/* 476 */     colCode = Integer.toHexString(col.getBlue());
/* 477 */     sb.append((colCode.length() == 1) ? ("0" + colCode) : colCode);
/*     */     
/* 479 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Integer getFileChooserFontRatio(MCFileChooser fc, MCRootPanel rp) {
/* 496 */     if (isEnableHighResolution()) {
/* 497 */       String fontratioKey = MCResource.createKey(new String[] { "high_resolution.filechooser_fontratio" });
/* 498 */       if (MCConst.beans.containsKey(fontratioKey)) {
/* 499 */         int fontratio = MCConst.beans.getInteger(fontratioKey);
/* 500 */         return Integer.valueOf(fontratio);
/*     */       } 
/*     */ 
/*     */       
/* 504 */       if (rp != null) {
/* 505 */         MCRootPanel rp2 = rp.getBaseRootPanel();
/* 506 */         if (rp2 != null) {
/* 507 */           return Integer.valueOf(rp2.getFontRatio());
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 512 */       return Integer.valueOf(getFontRatio());
/*     */     } 
/*     */     
/* 515 */     return Integer.valueOf(100);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static Integer _getDefaultFontRatio() {
/* 525 */     if (isEnableHighResolution()) {
/* 526 */       String fontratioKey = MCResource.createKey(new String[] { "high_resolution.default_fontratio" });
/* 527 */       if (MCConst.beans.containsKey(fontratioKey)) {
/* 528 */         int fontratio = MCConst.beans.getInteger(fontratioKey);
/* 529 */         return Integer.valueOf(fontratio);
/*     */       } 
/*     */     } 
/* 532 */     return Integer.valueOf(100);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Font getPopupFont(String name, int style, int size) {
/* 545 */     Font def = new Font(name, style, size);
/*     */     
/* 547 */     String key = "popup.font";
/* 548 */     Font font = MCConst.beans.getFont(key, def);
/*     */     
/* 550 */     if (MCConst.beans.getBoolean(MCResource.createKey(new String[] { "high_resolution.enable" }))) {
/* 551 */       String f1 = font.getName();
/* 552 */       int f2 = font.getStyle();
/* 553 */       int f3 = font.getSize();
/* 554 */       int ratio = getFontRatio();
/* 555 */       f3 = Integer.valueOf(f3 * ratio / 100).intValue();
/* 556 */       font = new Font(f1, f2, f3);
/* 557 */       return font;
/*     */     } 
/*     */     
/* 560 */     return font;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Font getPopupFont(MCRootPanel rp, Font def) {
/* 571 */     Font font = def;
/*     */     
/* 573 */     if (MCConst.beans.getBoolean(MCResource.createKey(new String[] { "high_resolution.enable" }))) {
/* 574 */       String key = "popup.font";
/* 575 */       font = MCConst.beans.getFont(key, def);
/* 576 */       font = new Font(font.getName(), font.getStyle(), font.getSize());
/*     */       
/* 578 */       String f1 = font.getName();
/* 579 */       int f2 = font.getStyle();
/* 580 */       int f3 = font.getSize();
/* 581 */       int ratio = getFontRatio();
/* 582 */       if (rp != null) {
/* 583 */         ratio = rp.getFontRatio();
/*     */       }
/* 585 */       f3 = Integer.valueOf(f3 * ratio / 100).intValue();
/* 586 */       font = new Font(f1, f2, f3);
/* 587 */       return font;
/*     */     } 
/*     */     
/* 590 */     return font;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void updateMenuFont(MCRootPanel bp, MCPopupMenu menu) {
/* 600 */     if (isEnableHighResolution()) {
/* 601 */       _updateMenuFont(bp, (Container)menu);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static void _updateMenuFont(MCRootPanel bp, Container menu) {
/* 607 */     Font f = getPopupFont(bp, menu.getFont());
/* 608 */     menu.setFont(f);
/*     */     
/* 610 */     Component[] cs = menu.getComponents(); byte b; int i; Component[] arrayOfComponent1;
/* 611 */     for (i = (arrayOfComponent1 = cs).length, b = 0; b < i; ) { Component c = arrayOfComponent1[b];
/* 612 */       if (c instanceof Container) {
/* 613 */         _updateMenuFont(bp, (Container)c);
/*     */       }
/* 615 */       if (c instanceof JMenu) {
/* 616 */         _updateMenuFont(bp, (JMenu)c);
/*     */       }
/*     */       b++; }
/*     */   
/*     */   }
/*     */   
/*     */   private static void _updateMenuFont(MCRootPanel bp, JMenu menu) {
/* 623 */     Font f = getPopupFont(bp, menu.getFont());
/* 624 */     menu.setFont(f);
/*     */     
/* 626 */     Component[] cs = menu.getMenuComponents(); byte b; int i; Component[] arrayOfComponent1;
/* 627 */     for (i = (arrayOfComponent1 = cs).length, b = 0; b < i; ) { Component c = arrayOfComponent1[b];
/* 628 */       if (c instanceof Container) {
/* 629 */         _updateMenuFont(bp, (Container)c);
/*     */       }
/* 631 */       if (c instanceof JMenu) {
/* 632 */         _updateMenuFont(bp, (JMenu)c);
/*     */       }
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static String getMode() {
/* 650 */     if (isEnableHighResolution()) {
/* 651 */       String modeKey = MCResource.createKey(new String[] { "high_resolution.mode" });
/* 652 */       if (MCConst.beans.containsKey(modeKey)) {
/* 653 */         String s = MCConst.beans.getString(modeKey);
/* 654 */         return s;
/*     */       } 
/*     */     } 
/* 657 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static Integer getDpi() {
/* 668 */     if (isEnableHighResolution()) {
/* 669 */       String modeKey = MCResource.createKey(new String[] { "high_resolution.dpi" });
/* 670 */       if (MCConst.beans.containsKey(modeKey)) {
/* 671 */         int s = MCConst.beans.getInteger(modeKey);
/* 672 */         return Integer.valueOf(s);
/*     */       } 
/*     */     } 
/* 675 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 703 */   private static Integer _max_fontratio = Integer.valueOf(100);
/* 704 */   private static Integer _default_fontratio = Integer.valueOf(100);
/*     */ 
/*     */ 
/*     */   
/*     */   private static ArrayList<MCHiresoManagerResolution> _resolution_list;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static Integer _getFontRatio(Dimension resolution) {
/* 714 */     if (_resolution_list.size() == 0) {
/* 715 */       return _default_fontratio;
/*     */     }
/*     */     
/* 718 */     for (MCHiresoManagerResolution r : _resolution_list) {
/* 719 */       if (r.resolution() < resolution.width) {
/*     */         continue;
/*     */       }
/* 722 */       return Integer.valueOf(r.fontratio());
/*     */     } 
/*     */     
/* 725 */     return _max_fontratio;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void _initFontRatio() {
/* 733 */     if (isEnableHighResolution()) {
/*     */       
/* 735 */       _resolution_list = new ArrayList<>();
/*     */       
/* 737 */       String pattern = MCConst.createKey(new String[] { "high_resolution.resolution_table", "resolution*" });
/* 738 */       String[] ka = MCConst.beans.findPattern(pattern); byte b; int i; String[] arrayOfString1;
/* 739 */       for (i = (arrayOfString1 = ka).length, b = 0; b < i; ) { String k = arrayOfString1[b];
/* 740 */         String v = MCConst.beans.getString(k);
/* 741 */         String[] s = MCStringUtil.split(",", v);
/* 742 */         int s0 = Integer.valueOf(s[0]).intValue();
/* 743 */         int s1 = Integer.valueOf(s[1]).intValue();
/* 744 */         _resolution_list.add(new MCHiresoManagerResolution(s0, s1)); b++; }
/*     */       
/* 746 */       Collections.sort(_resolution_list, (Comparator<? super MCHiresoManagerResolution>)new Object());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 756 */       String defaultKey = MCConst.createKey(new String[] { "high_resolution.resolution_table.default" });
/* 757 */       if (MCConst.beans.containsKey(defaultKey)) {
/* 758 */         Integer def = Integer.valueOf(MCConst.beans.getInteger(defaultKey));
/* 759 */         _default_fontratio = def;
/*     */       } 
/*     */       
/* 762 */       String maxKey = MCConst.createKey(new String[] { "high_resolution.resolution_table.max_resolution" });
/* 763 */       if (MCConst.beans.containsKey(defaultKey)) {
/* 764 */         Integer max = Integer.valueOf(MCConst.beans.getInteger(maxKey));
/* 765 */         _max_fontratio = max;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isEnableGraphWheel() {
/* 776 */     if (isEnableHighResolution()) {
/* 777 */       Boolean b = Boolean.valueOf(MCConst.beans.getBoolean(MCResource.createKey(new String[] { "high_resolution.useGraphWheel" })));
/* 778 */       if (b != null) {
/* 779 */         return b.booleanValue();
/*     */       }
/*     */     } 
/* 782 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isEnableWebViewZoom() {
/* 791 */     if (isEnableHighResolution()) {
/* 792 */       boolean b = MCConst.beans.getBoolean(MCResource.createKey(new String[] { "high_resolution.useWebViewZoom" }, ), true);
/* 793 */       return b;
/*     */     } 
/* 795 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\layout\MCHiresoManager.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */