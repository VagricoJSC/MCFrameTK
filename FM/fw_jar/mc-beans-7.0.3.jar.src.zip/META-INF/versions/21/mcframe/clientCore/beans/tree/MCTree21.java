/*    */ package META-INF.versions.21.mcframe.clientCore.beans.tree;
/*    */ import mcframe.clientCore.beans.tree.MCTree;
/*    */ 
/*    */ class MCTree21 extends MCTree {
/*    */   public MCTree21(String name) {
/*  6 */     super(name);
/*    */   }
/*    */ 
/*    */   
/*    */   public void requestFocus(FocusEvent.Cause cause) {
/* 11 */     doFocus(false);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\tree\MCTree21.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */