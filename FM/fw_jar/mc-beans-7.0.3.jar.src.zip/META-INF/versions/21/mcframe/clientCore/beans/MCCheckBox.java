/*      */ package META-INF.versions.21.mcframe.clientCore.beans;
/*      */ import java.awt.AWTEvent;
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Font;
/*      */ import java.awt.Insets;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.FocusListener;
/*      */ import java.awt.event.MouseEvent;
/*      */ import java.util.Collection;
/*      */ import javax.swing.ButtonModel;
/*      */ import javax.swing.Icon;
/*      */ import javax.swing.InputVerifier;
/*      */ import javax.swing.JCheckBox;
/*      */ import javax.swing.JComponent;
/*      */ import javax.swing.JPopupMenu;
/*      */ import javax.swing.SwingUtilities;
/*      */ import javax.swing.border.Border;
/*      */ import mcframe.clientCore.acl.MCACLManager;
/*      */ import mcframe.clientCore.beans.MCBeans;
/*      */ import mcframe.clientCore.beans.MCBeansDelegate;
/*      */ import mcframe.clientCore.beans.MCBeansFocusListener;
/*      */ import mcframe.clientCore.beans.MCBeansUtil;
/*      */ import mcframe.clientCore.beans.MCCacheType;
/*      */ import mcframe.clientCore.beans.MCContainerProxy;
/*      */ import mcframe.clientCore.beans.MCEventProxy;
/*      */ import mcframe.clientCore.beans.MCLabelBeans;
/*      */ import mcframe.clientCore.beans.MCMode;
/*      */ import mcframe.clientCore.beans.MCModeBeans;
/*      */ import mcframe.clientCore.beans.MCModeInfo;
/*      */ import mcframe.clientCore.beans.MCPropertyCache;
/*      */ import mcframe.clientCore.beans.MCResourceBeans;
/*      */ import mcframe.clientCore.beans.MCRootPanel;
/*      */ import mcframe.clientCore.beans.MCRowBeans;
/*      */ import mcframe.clientCore.beans.MCTabOrderBeans;
/*      */ import mcframe.clientCore.beans.action.MCActionBeans;
/*      */ import mcframe.clientCore.beans.action.MCFunction;
/*      */ import mcframe.clientCore.beans.action.MCFunctionKey;
/*      */ import mcframe.clientCore.beans.action.MCKeyActionManager;
/*      */ import mcframe.clientCore.beans.layout.MCHiresoManager;
/*      */ import mcframe.clientCore.beans.list.MCLinkedBeans;
/*      */ import mcframe.clientCore.beans.text.MCInputVerifier;
/*      */ import mcframe.clientCore.beans.text.MCValueChecker;
/*      */ import mcframe.clientCore.container.MCConstRow;
/*      */ import mcframe.clientCore.container.MCRowEvent;
/*      */ import mcframe.clientCore.container.MCRowListener;
/*      */ import mcframe.clientCore.event.MCEventBeans;
/*      */ import mcframe.clientCore.event.MCEventInfo;
/*      */ import mcframe.clientCore.event.MCEventList;
/*      */ import mcframe.clientCore.event.MCEventListener;
/*      */ import mcframe.clientCore.event.MCFunctionBeans;
/*      */ import mcframe.clientCore.event.MCNCBeans;
/*      */ import mcframe.clientCore.event.MCNCListener;
/*      */ import mcframe.clientCore.event.MCNCReceiver;
/*      */ import mcframe.clientCore.event.MCNEBeans;
/*      */ import mcframe.clientCore.event.MCNEListener;
/*      */ import mcframe.clientCore.event.MCNEReceiver;
/*      */ import mcframe.clientCore.event.MCNXBeans;
/*      */ import mcframe.clientCore.event.MCNXListener;
/*      */ import mcframe.clientCore.event.MCVCBeans;
/*      */ import mcframe.clientCore.event.MCVCListener;
/*      */ import mcframe.clientCore.event.MCVCReceiver;
/*      */ import mcframe.clientCore.resource.MCConst;
/*      */ import mcframe.commonCore.container.MCRow;
/*      */ import mcframe.commonCore.lang.MCDataType;
/*      */ import mcframe.commonCore.lang.MCStringUtil;
/*      */ import mcframe.commonCore.meta.MCMeta;
/*      */ import mcframe.commonCore.notice.Core_Msg;
/*      */ import mcframe.commonCore.notice.MCMessageList;
/*      */ 
/*      */ public class MCCheckBox extends JCheckBox implements MCTabOrderBeans, MCModeBeans, MCRowBeans, MCVCBeans, MCVCReceiver, MCNCBeans, MCNCReceiver, MCNEBeans, MCNEReceiver, MCNXBeans, MCNXReceiver, MCLinkedBeans, MCLabelBeans, MCActionBeans, MCFunctionBeans {
/*   74 */   private static Border DEFAULT_BORDER = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   82 */   private MCConstRow _link_row = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   90 */   private String _link_column_name = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   98 */   private MCDataType _link_type = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  106 */   private MCMeta _meta = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  114 */   private MCMode _mode = MCMode.NULL;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  122 */   private MCBeansDelegate _delegate = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  130 */   private final MCEventList _event_list = new MCEventList();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  138 */   private MCEventInfo _event_info = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  146 */   private MCValueChecker _value_checker = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _ignore_status = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  162 */   private MCRootPanel _panel = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  170 */   private MCRootPanel _init_panel = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  178 */   private String _message_name_resource = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  186 */   private String _message_name = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  194 */   private String _label_name = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  202 */   private Rectangle _default_ratio_bounds = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  210 */   private Font _default_font = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  218 */   private int _ratio = 100;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  226 */   private MCFunction _function = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  234 */   private String _function_text = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  242 */   private String _function_tooltip = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  250 */   private String _function_abbreviation = null;
/*      */ 
/*      */   
/*      */   private boolean _read_only_flg;
/*      */ 
/*      */   
/*      */   private Rectangle _default_bounds;
/*      */ 
/*      */   
/*      */   private String _label_name_program;
/*      */ 
/*      */   
/*      */   private MCBeansUtil.HTMLTextInfo _html_text_info;
/*      */   
/*      */   private Font _font;
/*      */   
/*      */   private Font _multiline_font;
/*      */   
/*      */   protected boolean _isVisibleForMode;
/*      */   
/*      */   protected boolean _isVisibleForPersonalize;
/*      */ 
/*      */   
/*      */   private final void init() {
/*  274 */     initBeans();
/*  275 */     initResource();
/*  276 */     initKeyAssign();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initBeans() {
/*  286 */     setModel((ButtonModel)createModel());
/*  287 */     setOpaque(false);
/*  288 */     enableInputMethods(false);
/*  289 */     addFocusListener((FocusListener)MCBeansFocusListener.getInstance());
/*  290 */     setHorizontalAlignment(2);
/*      */     
/*  292 */     if (DEFAULT_BORDER == null) {
/*  293 */       DEFAULT_BORDER = getBorder();
/*      */     }
/*  295 */     setInputVerifier((InputVerifier)new MCInputVerifier());
/*      */ 
/*      */     
/*  298 */     setComponentPopupMenu((JPopupMenu)new Object(this));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected MCCheckBoxModel createModel() {
/*  319 */     return new MCCheckBoxModel(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initKeyAssign() {
/*  329 */     MCKeyActionManager.init((MCResourceBeans)this, getInputMap(), getActionMap());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initResource() {
/*  340 */     Font f = MCConst.beans.getFont(getFontKey());
/*  341 */     if (f != null) {
/*  342 */       setFont(f);
/*      */     }
/*      */     
/*  345 */     Font mlf = MCConst.beans.getFont(getMultilineFontKey());
/*  346 */     if (mlf != null) {
/*  347 */       setMultilineFont(mlf);
/*      */     }
/*      */     
/*  350 */     getHTMLTextInfo().setMarginTop(MCConst.beans.getInteger(getTextMarginTopKey(), 
/*  351 */           getHTMLTextInfo().getMarginTop()));
/*      */     
/*  353 */     getHTMLTextInfo().setMarginBottom(MCConst.beans.getInteger(
/*  354 */           getTextMarginBottomKey(), getHTMLTextInfo().getMarginBottom()));
/*      */ 
/*      */     
/*  357 */     String m = MCBeansUtil.getLabelMsg(getName());
/*  358 */     if (m != null) {
/*  359 */       this._message_name_resource = m;
/*      */     }
/*      */ 
/*      */     
/*  363 */     String l = MCBeansUtil.getLabel(getName());
/*  364 */     if (l != null) {
/*  365 */       this._label_name = l;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setName(String name) {
/*  382 */     setName(name, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void setName(String name, boolean init) {
/*  397 */     MCBeansUtil.checkName(name);
/*  398 */     super.setName(name);
/*  399 */     if (init) {
/*  400 */       updateResource();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public String getType() {
/*  406 */     return "check";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getFontKey() {
/*  417 */     return MCConst.createKey(new String[] { getType(), "font" });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getMultilineFontKey() {
/*  428 */     return MCConst.createKey(new String[] { getType(), "multiline_font" });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getTextMarginTopKey() {
/*  439 */     return MCConst.createKey(new String[] { getType(), "text_margin_top" });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getTextMarginBottomKey() {
/*  450 */     return MCConst.createKey(new String[] { getType(), "text_margin_bottom" });
/*      */   }
/*      */ 
/*      */   
/*      */   public void setRow(MCConstRow row, MCMeta meta) {
/*  455 */     MCBeansUtil.checkRow(this, (MCRow)row, meta);
/*  456 */     setMeta(meta);
/*  457 */     setRow(row, meta.name());
/*      */   }
/*      */   
/*      */   protected void setRow(MCConstRow row, String name) {
/*  461 */     if (this._link_row != null) {
/*  462 */       this._link_row.removeRowListener((MCRowListener)this);
/*      */     }
/*  464 */     this._link_row = row;
/*  465 */     this._link_column_name = name;
/*  466 */     this._link_type = getBaseRow().getDataType(getBaseRowColumnName());
/*  467 */     MCContainerProxy.proxy.setRowListener(row, name, (MCRowListener)this);
/*  468 */     setRowToView();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setMeta(MCMeta meta) {
/*  480 */     this._meta = meta;
/*      */   }
/*      */ 
/*      */   
/*      */   public MCMeta getMeta() {
/*  485 */     return this._meta;
/*      */   }
/*      */ 
/*      */   
/*      */   public MCConstRow getBaseRow() {
/*  490 */     MCConstRow row = this._link_row;
/*  491 */     return (row != null) ? (MCConstRow)row.getRootRow() : null;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getBaseRowColumnName() {
/*  496 */     MCConstRow row = this._link_row;
/*  497 */     return (row != null) ? row.getRootRowColumnPath(this._link_column_name) : 
/*  498 */       this._link_column_name;
/*      */   }
/*      */ 
/*      */   
/*      */   public MCConstRow getRow() {
/*  503 */     return this._link_row;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getRowColumnName() {
/*  508 */     return this._link_column_name;
/*      */   }
/*      */ 
/*      */   
/*      */   public MCDataType getDataType() {
/*  513 */     return this._link_type;
/*      */   }
/*      */ 
/*      */   
/*      */   public void valueChanged(MCRowEvent event) {
/*  518 */     setRowToView();
/*      */   }
/*      */ 
/*      */   
/*      */   public void setRowToView() {
/*  523 */     MCBeansUtil.checkThread();
/*  524 */     MCConstRow r = getBaseRow();
/*  525 */     String n = getBaseRowColumnName();
/*  526 */     if (!MCBeansUtil.isNull(r, n)) {
/*  527 */       boolean v = r.getBoolean(n);
/*  528 */       if (v != getValue()) {
/*  529 */         MCEventProxy.PROXY.setValue(getEventInfo(), Boolean.valueOf(v));
/*  530 */         boolean e = MCBeansUtil.isEventEnabled();
/*      */         try {
/*  532 */           MCBeansUtil.setEventEnabled(false);
/*  533 */           ((MCCheckBoxModel)getModel())._setSelected(v);
/*      */         } finally {
/*      */           
/*  536 */           MCBeansUtil.setEventEnabled(e);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setRowToViews() {
/*  544 */     setRowToView();
/*      */   }
/*      */ 
/*      */   
/*      */   public void localeChanged() {
/*  549 */     updateResource();
/*      */   }
/*      */   @Deprecated
/*  552 */   public MCCheckBox(String name) { this._read_only_flg = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1319 */     this._default_bounds = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2185 */     this._label_name_program = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2331 */     this._isVisibleForMode = true;
/* 2332 */     this._isVisibleForPersonalize = true; setName(name, false); init(); }
/*      */   private void setReadOnlyFlg(boolean flg) { this._read_only_flg = flg; setMode(this._mode); }
/*      */   private boolean getReadOnlyFlg() { return this._read_only_flg; }
/* 2335 */   public void setMode(MCMode mode) { if (MCMode.isNull(mode)) return;  MCMode m = mode; if (getModeInfo(m).getStatus() == 1 && getReadOnlyFlg()) m = MCMode.READ_ONLY;  if (MCBeansUtil.setMode(this, m)) { if (this._mode != mode) this._mode = mode;  fgChanged(); }  } public MCMode getMode() { MCMode m = this._mode; if (getModeInfo(m).getStatus() == 1 && getReadOnlyFlg()) m = MCMode.READ_ONLY;  return m; } public MCMessageList setViewValue(int index, Comparable<?> value) { return setViewValue(value); } public void setViewValue(int index, Comparable<?> value, MCMessageList list) { setViewValue(value, list); } public MCMessageList setViewValue(Comparable<?> value) { MCMessageList l = new MCMessageList(); setViewValue(value, l); return l; } public void setViewValue(Comparable<?> value, MCMessageList list) { if (value == null) value = Boolean.valueOf(false);  if (value instanceof Boolean) { setValue(((Boolean)value).booleanValue(), list); } else if (list != null) { list.add(MCBeansUtil.createCauseMsg(this, Core_Msg.FCBAC0067, new Object[0])); }  } public Comparable<?> getViewValue(int index) { return Boolean.valueOf(getValue()); } public Boolean getViewValue() { return Boolean.valueOf(getValue()); } public MCMessageList setValue(boolean value) { return setValue(value, new MCMessageList()); } protected MCMessageList setValue(boolean value, MCMessageList list) { if (list == null) list = new MCMessageList();  if (isValueChanged(Boolean.valueOf(value))) { MCEventInfo info = getEventInfo(); MCEventProxy.PROXY.setValue(info, Boolean.valueOf(isSelected()), Boolean.valueOf(value)); if (canChange()) { ((MCCheckBoxModel)getModel())._setSelected(value); super.setSelected(value); commitValue(); } else { list.add(MCBeansUtil.createCauseMsg(this, Core_Msg.FCBAC0032, new Object[] { Boolean.valueOf(value) })); }  MCEventProxy.PROXY.setValue(info, Boolean.valueOf(value)); } else { setRowToViews(); }  return list; } public boolean getValue() { return isSelected(); } public void clear() { MCBeansUtil.clear(this, Boolean.valueOf(false)); } public void addAllListener(MCEventListener listener) { addNCListener((MCNCListener)listener); addNEListener((MCNEListener)listener); addNXListener((MCNXListener)listener); addVCListener((MCVCListener)listener); } public void setAllListener(MCEventListener listener) { setNCListener((MCNCListener)listener); setNEListener((MCNEListener)listener); setNXListener((MCNXListener)listener); setVCListener((MCVCListener)listener); } public final void addVCListener(MCVCListener listener) { this._event_list.add(listener); } public final void setVCListener(MCVCListener listener) { this._event_list.set(listener); } public final void removeVCListener(MCVCListener listener) { this._event_list.remove(listener); } public final MCVCListener[] getVCListeners() { return this._event_list.vc(); } public boolean doVC() { return MCBeansUtil.vc(this); } public boolean isValueChanged() { return isValueChanged(Boolean.valueOf(getValue())); } protected boolean isValueChanged(Comparable<?> value) { return isValueChanged(value, getRowValue()); } protected boolean isValueChanged(Comparable<?> view, Comparable<?> row) { return getRootPanel().isValueChanged(this, view, row); } public Boolean getRowValue() { MCConstRow c = getBaseRow(); String n = getBaseRowColumnName(); return Boolean.valueOf(!MCBeansUtil.isNull(c, n) ? c.getBoolean(n) : false); } public boolean canChange() { boolean e = doVC(); if (!e) doCheckValueError();  return e; } protected void doCheckValueError() { MCBeansUtil.getErrorHandler((MCBeans)this).doCheckValueError((MCBeans)this); } public final void addNCListener(MCNCListener listener) { this._event_list.add(listener); } public final void setNCListener(MCNCListener listener) { this._event_list.set(listener); } public final void removeNCListener(MCNCListener listener) { this._event_list.remove(listener); } public final MCNCListener[] getNCListeners() { return this._event_list.nc(); } public void doNC() { MCBeansUtil.nc(this); } public void commitValue() { setViewToRow(); doNC(); MCEventProxy.PROXY.setValue(getEventInfo(), getRowValue()); } public void setViewToRow() { MCConstRow c = getBaseRow(); String n = getBaseRowColumnName(); if (!MCBeansUtil.isNull(c, n)) { c.setBoolean(n, getValue()); MCBeansUtil.setGUIModified(this, c); }  } public final void addNEListener(MCNEListener listener) { this._event_list.add(listener); } public final void setNEListener(MCNEListener listener) { this._event_list.set(listener); } public final void removeNEListener(MCNEListener listener) { this._event_list.remove(listener); } public final MCNEListener[] getNEListeners() { return this._event_list.ne(); } public void doNE() { MCBeansUtil.ne(this); } public void focusGained() { doNE(); } public final void addNXListener(MCNXListener listener) { this._event_list.add(listener); } public final void setNXListener(MCNXListener listener) { this._event_list.set(listener); } public final void removeNXListener(MCNXListener listener) { this._event_list.remove(listener); } public final MCNXListener[] getNXListeners() { return this._event_list.nx(); } public void doNX() { MCBeansUtil.nx(this); } public void focusLost() { doNX(); } public MCEventInfo getEventInfo() { if (this._event_info == null) { this._event_info = new MCEventInfo(); MCEventProxy.PROXY.setComponent(this._event_info, (MCEventBeans)this); }  return this._event_info; } public boolean isRequestFocusEnabled() { return (super.isRequestFocusEnabled() && isMCRequestFocusEnabled()); } protected boolean isMCRequestFocusEnabled() { return MCBeansUtil.isFocusable(this); } public void mcRequestFocus() { MCBeansUtil.focus(this); } @Deprecated public void grabFocus() { super.grabFocus(); } @Deprecated public void requestFocus() { doFocus(false); } @Deprecated public boolean requestFocus(boolean temporary) { return doFocus(temporary); } protected boolean doFocus(boolean temporary) { if (super.requestFocus(temporary)) { if (!temporary) afterRequestFocus();  return true; }  return false; } @Deprecated public boolean requestFocusInWindow() { return super.requestFocusInWindow(); } @Deprecated protected boolean requestFocusInWindow(boolean temporary) { return super.requestFocusInWindow(temporary); } public void afterRequestFocus() { MCRootPanel bp = getBaseRootPanel(); MCBeansUtil.afterRequestFocus(bp, this); MCBeansUtil.scrollRectToVisible(bp, this, getHorizontalAlignment()); } public MCRootPanel getRootPanel() { if (this._init_panel != null) return this._init_panel;  return getNearestRootPanel(); } public MCRootPanel getBaseRootPanel() { MCRootPanel p = getNearestRootPanel(); return (p != null) ? p.getBaseRootPanel() : null; } public MCRootPanel getNearestRootPanel() { if (this._panel == null) this._panel = MCBeansUtil.getNearestRootPanel(this);  return this._panel; } public String getMessageByLocale() { String m = this._message_name; if (m == null) m = this._message_name_resource;  return MCBeansUtil.getNameForMessage((MCBeans)this, m); } public String getLabelByLocale() { return this._label_name_program; } @Deprecated public void setSelected(boolean selected) { super.setSelected(selected); } protected void processEvent(AWTEvent e) { try { super.processEvent(e); } catch (Throwable t) { handle(t); }  } @Deprecated public void handle(Throwable t) { MCBeansUtil.handle(this, t); } protected void setBounds() { MCBeansUtil.setBounds((MCResourceBeans)this); } @Deprecated public void _cacheDefaultBounds(Rectangle bounds) { this._default_bounds = bounds; } @Deprecated public void _setDefaultBounds() { if (this._default_bounds != null) setBounds(this._default_bounds);  } public Rectangle _getDefaultBounds() { return this._default_bounds; } public void _setDefaultBounds(Rectangle r) { this._default_bounds = r; } protected void setLabelText() { String l = MCBeansUtil.getLabel((MCBeans)this); if (l != null) this._label_name = l;  String t = this._label_name; if (t != null && !t.equals(getLabelByLocale())) setText(t);  } public void added() { this._panel = MCBeansUtil.getNearestRootPanel(this); if (MCMode.isNull(getMode())) setMode(MCMode.ENABLE);  } public void removed() { this._panel = MCBeansUtil.getNearestRootPanel(this); } public void updateResource() { updateResource(getBaseRootPanel()); } public void updateResource(MCRootPanel panel) { if (panel != null) { if (!panel.isPartsFlag()) MCKeyActionManager.initScreen((MCResourceBeans)this, getInputMap(), getActionMap());  MCPropertyCache p = panel.getPropertyCache(MCCacheType.SCREEN); Font c = MCBeansUtil.getBeansFont(panel, p, getFontKey()); if (c != null) setFont(c);  Font mlf = MCBeansUtil.getBeansFont(panel, p, getMultilineFontKey()); if (mlf != null) setMultilineFont(mlf);  getHTMLTextInfo().setMarginTop(MCBeansUtil.getBeansInteger(panel, p, getTextMarginTopKey(), getHTMLTextInfo().getMarginTop())); getHTMLTextInfo().setMarginBottom(MCBeansUtil.getBeansInteger(panel, p, getTextMarginBottomKey(), getHTMLTextInfo().getMarginBottom())); setLabelText(); String m = MCBeansUtil.getMessageName((MCResourceBeans)this); if (m != null) this._message_name_resource = m;  setMCToolTipText((this._message_name != null) ? this._message_name : this._message_name_resource); setBounds(); setIcon(); setSelectedIcon(); setPressedIcon(); setDisabledIcon(); setDisabledSelectedIcon(); }  } protected void setIcon() { Icon icon = MCBeansUtil.getIcon((MCResourceBeans)this, new String[] { getType(), "icon.default" }); if (icon != null) setIcon(icon);  } protected void setSelectedIcon() { Icon icon = MCBeansUtil.getIcon((MCResourceBeans)this, new String[] { getType(), "icon.selected" }); if (icon != null) setSelectedIcon(icon);  } protected void setPressedIcon() { Icon icon = MCBeansUtil.getIcon((MCResourceBeans)this, new String[] { getType(), "icon.pressed" }); if (icon != null) setPressedIcon(icon);  } public boolean isVisibleForPersonalize() { return this._isVisibleForPersonalize; }
/*      */   protected void setDisabledIcon() { Icon icon = MCBeansUtil.getIcon((MCResourceBeans)this, new String[] { getType(), "icon.disabled" }); if (icon != null) setDisabledIcon(icon);  }
/*      */   protected void setDisabledSelectedIcon() { Icon icon = MCBeansUtil.getIcon((MCResourceBeans)this, new String[] { getType(), "icon.disabled-selected" }); if (icon != null) setDisabledSelectedIcon(icon);  }
/*      */   public void setValueChecker(MCValueChecker checker) { this._value_checker = checker; }
/* 2339 */   public MCValueChecker getValueChecker() { if (this._value_checker == null) this._value_checker = new MCValueChecker();  return this._value_checker; } public MCMessageList checkValue(Comparable<?> value) { return getValueChecker().checkValue(this, value); } public boolean checkValue(Comparable<?> value, MCMessageList list) { MCMessageList l = getValueChecker().checkValue(this, value); boolean e = (l.size() == 0); if (!e && list != null) list.addAll((Collection)l);  return e; } public boolean checkInputValue(Comparable<?> value) { return checkInputValue(value, null); } public boolean checkInputValue(Comparable<?> value, MCMessageList list) { MCMessageList l = getValueChecker().checkInputValue(this, value); boolean e = (l.size() == 0); if (!e && list != null) list.addAll((Collection)l);  return e; } public boolean equalsIgnoreCase(Component compo) { return equals(compo); } public final MCModeInfo getModeInfo() { return getModeInfo(getMode()); } public final MCModeInfo getModeInfo(MCMode mode) { return getDelegate().getModeInfo(this, mode); } public void initialized() { if (this._default_ratio_bounds == null) this._default_ratio_bounds = getBounds();  if (this._default_font == null) this._default_font = getFont();  this._init_panel = MCBeansUtil.getRootPanel(this); MCRootPanel bp = getBaseRootPanel(); if (bp != null) { String itemid = MCBeansUtil.createGUIKey(this); setReadOnlyFlg(MCACLManager.isReadOnly(bp.getModuleID(), bp.getScreenID(), itemid)); }  } public boolean doAction() { return false; } private MCBeansDelegate getDelegate() { if (this._delegate == null) this._delegate = new MCBeansDelegate();  return this._delegate; } public final void addAliasName(String alias, MCRootPanel panel) { getDelegate().addAliasName(alias, panel); } public final void setAliasName(String alias, MCRootPanel panel) { getDelegate().setAliasName(alias, panel); } public final void removeAliasName(MCRootPanel panel) { getDelegate().removeAliasName(panel); } public final void removeAliasNames() { getDelegate().removeAliasNames(); } public String getAliasName(MCRootPanel panel) { return getDelegate().getAliasName(panel); } public String[] getAliasNames() { return getDelegate().getAliasNames(); } public void enableInputMethods(boolean enable) { super.enableInputMethods(false); } protected boolean isMCFocusOwner() { JComponent o = MCBeansUtil.getFocusOwner(this); return (o != null) ? ((o == this)) : isFocusOwner(); } public void updateBounds(int ratio) { MCBeansUtil.updateBounds(this, ratio, this._default_ratio_bounds); } public void updateFontSize(int ratio) { if (MCBeansUtil.isEnableMultilineFont(this._multiline_font, this._label_name_program)) { MCBeansUtil.updateFontSize(this, ratio, this._multiline_font); } else { MCBeansUtil.updateFontSize(this, ratio, this._default_font); }  this._ratio = ratio; String p = this._label_name_program; if (!MCStringUtil.isNull(p) && MCStringUtil.convertToLF(p).contains("\n")) { Color fg = (getModeInfo() != null) ? getModeInfo().getLabelForeground() : getForeground(); super.setText(MCBeansUtil.toHTMLText((MCBeans)this, p, fg, ratio, getHTMLTextInfo())); }  } public Border getDefaultBorder() { return DEFAULT_BORDER; } public final MCTabOrderBeans getNextBeans() { return getDelegate().getNextBeans(); } public final void setNextBeans(MCTabOrderBeans compo, int updateType) { getDelegate().setNextBeans(this, compo, updateType); } public final void setNextBeans(MCTabOrderBeans compo) { getDelegate().setNextBeans(this, compo, 0); } public final void insertNextBeans(MCTabOrderBeans compo, int updateType) { getDelegate().insertNextBeans(this, compo, updateType); } public final void insertNextBeans(MCTabOrderBeans compo) { getDelegate().insertNextBeans(this, compo, 0); } public final void insertPreviousBeans(MCTabOrderBeans compo, int updateType) { getDelegate().insertPreviousBeans(this, compo, updateType); } public final void insertPreviousBeans(MCTabOrderBeans compo) { getDelegate().insertPreviousBeans(this, compo, 0); } public final MCTabOrderBeans getPreviousBeans() { return getDelegate().getPreviousBeans(); } @Deprecated public final void setPreviousBeans(MCTabOrderBeans compo) { getDelegate().setPreviousBeans(this, compo); } @Deprecated public boolean isFocusableByKeybord() { return (isVisible() && isEnabled() && isFocusable()); } public boolean isIgnoreStatus() { return this._ignore_status; } public void setIgnoreStatus(boolean ignore) { this._ignore_status = ignore; } public MCMode getMode(MCRootPanel panel, String status) { return getDelegate().getMode(panel, status); } public String[] getStatuses(MCRootPanel panel) { return getDelegate().getStatuses(panel); } public void putMode(MCRootPanel panel, String status, MCMode mode) { getDelegate().putMode(panel, status, mode); } public void setMode(MCRootPanel panel, String status) { setMode(getMode(panel, status)); } protected void fireActionPerformed(ActionEvent event) { super.fireActionPerformed(event); SwingUtilities.invokeLater((Runnable)new Object(this)); } public int getIconTextGap() { int i = super.getIconTextGap(); i = i * getRatio() / 100; return i; } public int getRatio() { return this._ratio; } public Insets getInsets() { Insets i = super.getInsets(); int a = getRatio(); i.top = i.top * a / 100; i.bottom = i.bottom * a / 100; i.left = i.left * a / 100; i.right = i.right * a / 100; return i; } public final boolean isTabOrderEnabled() { return getDelegate().isTabOrderEnabled(); } @Deprecated public final void setTabOrderEnabled(boolean enabled) { getDelegate().setTabOrderEnabled(enabled); } public Dimension getDefaultSize() { Rectangle a = this._default_ratio_bounds; int w = (a != null) ? a.width : getWidth(); int h = (a != null) ? a.height : getHeight(); return new Dimension(w, h); } public Rectangle getDefaultBounds() { Rectangle a = this._default_ratio_bounds; return (a != null) ? a : bounds(); } public void setDefaultRatioSize(Rectangle r) { this._default_ratio_bounds = r; } @Deprecated public JComponent getTargetComponent() { return this; } public Comparable<?> doListFormat(Comparable<?> value) { return value; } public void setMessageName(String name) { this._message_name = MCBeansUtil.adjustMessageName(name); setMCToolTipText((this._message_name != null) ? this._message_name : this._message_name_resource); } @Deprecated public String _getMessageName() { return this._message_name; } @Deprecated public void setRequiredFlg(boolean required) {} @Deprecated public boolean getRequiredFlg() { return false; } public void action(MCFunction function) { if (!isRequestFocusEnabled()) return;  requestFocus(); doClick(); } public MCFunction getFunction() { return this._function; } public MCFunctionKey getFunctionKey() { return (this._function != null) ? this._function.getKey() : null; } public void setFunction(MCFunction function) { this._function = function; this._function_text = null; this._function_tooltip = null; this._function_abbreviation = null; String m = (this._message_name != null) ? this._message_name : this._message_name_resource; if (m != null) setMCToolTipText(m);  MCRootPanel p = getRootPanel(); if (p != null) p.setFunction(this);  } public void setFunctionKey(MCFunctionKey key) { MCFunction f = (key != null) ? new MCFunction(key, this, 2) : null; setFunction(f); } protected String getFunctionKeyText() { if (this._function_text == null) { MCFunctionKey fk = getFunctionKey(); if (fk != null) { String kt = fk.getKeyText().toLowerCase(); String key = MCConst.createKey(new String[] { "function.text", kt }); if (MCConst.beans.containsKey(key)) this._function_text = MCConst.beans.getString(key);  }  }  return this._function_text; } protected String getFunctionKeyTooltipText() { if (this._function_tooltip == null) { MCFunctionKey fk = getFunctionKey(); if (fk != null) { String kt = fk.getKeyText().toLowerCase(); String key = MCConst.createKey(new String[] { "function.tooltip", kt }); if (MCConst.beans.containsKey(key)) this._function_tooltip = MCConst.beans.getString(key);  }  }  return this._function_tooltip; } public String getFunctionKeyAbbreviation() { return (this._function_abbreviation != null) ? this._function_abbreviation : (this._function_abbreviation = MCBeansUtil.getFunctionKeyAbbreviation(this)); } protected void setMCToolTipText(String text) { String s = text; if (s == null) s = "";  String function = getFunctionKeyTooltipText(); if (function != null) s = s + s;  if (s.length() == 0) s = null;  setToolTipText(s); } public String getToolTipText(MouseEvent event) { String tip = getToolTipText(); tip = MCHiresoManager.getToolTipText(this, tip); return tip; } public void setFocusable(boolean focusable) { super.setFocusable(focusable); MCBeansUtil.setFocusableAfter(this, focusable); } public void setText(String text) { if (MCStringUtil.isNull(text) || !MCStringUtil.convertToLF(text).contains("\n")) { this._label_name_program = text; super.setText(text); } else { this._label_name_program = text; Color fg = (getModeInfo() != null) ? getModeInfo().getLabelForeground() : getForeground(); super.setText(MCBeansUtil.toHTMLText((MCBeans)this, text, fg, getHTMLTextInfo())); }  adjustFont(); } @Deprecated public String getText() { return super.getText(); } public Font getDefaultFont() { return this._default_font; } public void setForeground(Color color) { super.setForeground(color); fgChanged(); } private void fgChanged() { String p = this._label_name_program; if (!MCStringUtil.isNull(p) && MCStringUtil.convertToLF(p).contains("\n")) { Color fg = (getModeInfo() != null) ? getModeInfo().getLabelForeground() : getForeground(); super.setText(MCBeansUtil.toHTMLText((MCBeans)this, this._label_name_program, fg, getHTMLTextInfo())); }  } private MCBeansUtil.HTMLTextInfo getHTMLTextInfo() { return (this._html_text_info != null) ? this._html_text_info : (this._html_text_info = new MCBeansUtil.HTMLTextInfo()); } public void setFont(Font font) { if (MCBeansUtil.isEnableMultilineFont(this._multiline_font, this._label_name_program)) { super.setFont(this._multiline_font); } else { super.setFont(font); }  this._font = font; } public void setMultilineFont(Font font) { this._multiline_font = font; } private void adjustFont() { Font f = this._font; if (MCBeansUtil.isEnableMultilineFont(this._multiline_font, this._label_name_program)) f = this._multiline_font;  if (f != null) { MCRootPanel p = getBaseRootPanel(); if (p != null) { MCBeansUtil.updateFontSize(this, p.getFontRatio(), f); } else { _setFont(f); }  }  } void _setFont(Font font) { super.setFont(font); } public Comparable<?> _adjustValueByFormat(Comparable<?> value) { return value; } public boolean isVisibleForMode() { return this._isVisibleForMode; }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setVisibleForLayout(boolean b) {
/* 2344 */     super.setVisible(b);
/*      */   }
/*      */   
/*      */   public void setVisibleForPersonalize(boolean b) {
/* 2348 */     this._isVisibleForPersonalize = b;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setVisible(boolean flag) {
/* 2353 */     this._isVisibleForMode = flag;
/* 2354 */     if (!this._isVisibleForPersonalize) {
/* 2355 */       super.setVisible(false);
/*      */     } else {
/*      */       
/* 2358 */       super.setVisible(flag);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isAnytimeFAction() {
/* 2364 */     return false;
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\MCCheckBox.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */