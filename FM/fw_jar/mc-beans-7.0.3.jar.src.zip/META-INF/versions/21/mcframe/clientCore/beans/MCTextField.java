/*      */ package META-INF.versions.21.mcframe.clientCore.beans;
/*      */ 
/*      */ import java.awt.Component;
/*      */ import java.awt.Rectangle;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.List;
/*      */ import java.util.regex.Pattern;
/*      */ import java.util.regex.PatternSyntaxException;
/*      */ import javax.swing.JComponent;
/*      */ import javax.swing.TransferHandler;
/*      */ import javax.swing.text.Document;
/*      */ import javax.swing.text.JTextComponent;
/*      */ import mcframe.clientCore.beans.MCBeans;
/*      */ import mcframe.clientCore.beans.MCBeansUtil;
/*      */ import mcframe.clientCore.beans.MCCacheType;
/*      */ import mcframe.clientCore.beans.MCEventProxy;
/*      */ import mcframe.clientCore.beans.MCField;
/*      */ import mcframe.clientCore.beans.MCMode;
/*      */ import mcframe.clientCore.beans.MCModeBeans;
/*      */ import mcframe.clientCore.beans.MCPluralValueField;
/*      */ import mcframe.clientCore.beans.MCPropertyCache;
/*      */ import mcframe.clientCore.beans.MCRootPanel;
/*      */ import mcframe.clientCore.beans.MCRowBeans;
/*      */ import mcframe.clientCore.beans.MCTextProxy;
/*      */ import mcframe.clientCore.beans.list.MCListType;
/*      */ import mcframe.clientCore.beans.popup.MCPopupBeans;
/*      */ import mcframe.clientCore.beans.popup.MCPopupMenu;
/*      */ import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
/*      */ import mcframe.clientCore.beans.text.MCDocumentBeans;
/*      */ import mcframe.clientCore.beans.text.MCIMDelegate;
/*      */ import mcframe.clientCore.beans.text.MCInputMethodType;
/*      */ import mcframe.clientCore.beans.text.MCTextDocument;
/*      */ import mcframe.clientCore.container.MCConstRow;
/*      */ import mcframe.clientCore.event.MCAPListener;
/*      */ import mcframe.clientCore.event.MCFDListener;
/*      */ import mcframe.clientCore.resource.MCConst;
/*      */ import mcframe.commonCore.container.MCList;
/*      */ import mcframe.commonCore.container.MCRow;
/*      */ import mcframe.commonCore.lang.MCStringUtil;
/*      */ import mcframe.commonCore.meta.MCMeta;
/*      */ import mcframe.commonCore.notice.Core_Msg;
/*      */ import mcframe.commonCore.notice.MCException;
/*      */ import mcframe.commonCore.notice.MCMessageList;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MCTextField
/*      */   extends MCField
/*      */   implements MCDocumentBeans, MCPluralValueField
/*      */ {
/*   54 */   private MCMeta _meta = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   62 */   private int _length = Integer.MAX_VALUE; private String _trim; private MCIMDelegate _im_delegate; private MCTextPopupMenuItem _popup_open; private List<Pattern> _accept_ptn; private List<Character> _except_chars; private boolean _plural_value_enable; private MCFDListener _file_drop_listener; private boolean _drop_enable; public String getType() { return "text"; } protected String getTrimPatternKey() { return MCConst.createKey(new String[] { getType(), "trim" }); } protected void initBeans() {
/*      */     super.initBeans();
/*      */     setHorizontalAlignment(2);
/*      */     setTransferHandler((TransferHandler)new MCTextFieldTransferHandler(this));
/*      */     this._file_drop_listener = (MCFDListener)new MCTextFieldFDListener(this);
/*      */   } protected void initResource() {
/*      */     super.initResource();
/*      */     String t = MCConst.beans.getString(getTrimPatternKey());
/*      */     if (t != null)
/*      */       setTrimPattern(t); 
/*      */   }
/*      */   protected void setMeta(MCMeta meta) {
/*      */     this._meta = meta;
/*      */     if (meta != null)
/*      */       setLength(meta.length()); 
/*      */   }
/*   78 */   private MCInputMethodType _input_method_type = MCInputMethodType.NONE;
/*      */   public MCMeta getMeta() { return this._meta; }
/*      */   public void setRowToView() { MCBeansUtil.checkThread(); MCConstRow r = getBaseRow(); String n = getBaseRowColumnName(); if (!MCBeansUtil.isNull(r, n)) { String v = MCStringUtil.convertToLF(r.getString(n)); if (MCStringUtil.isNull(v)) v = null;  String t = getText(); if (MCStringUtil.isNull(t)) t = null;  if (!MCStringUtil.eq(v, t)) { MCEventProxy.PROXY.setValue(getEventInfo(), v); boolean e = MCBeansUtil.isEventEnabled(); try { MCBeansUtil.setEventEnabled(false); setText(v); } finally { MCBeansUtil.setEventEnabled(e); }  }  adjustText(); }  }
/*      */   public MCMessageList setViewValue(Comparable<?> value) { MCMessageList l = new MCMessageList(); setViewValue(value, l); return l; }
/*      */   public void setViewValue(Comparable<?> value, MCMessageList list) { if (list == null)
/*      */       list = new MCMessageList();  if (value != null) { if (value instanceof String) { setValue((String)value, list); } else { list.add(MCBeansUtil.createCauseMsg((MCRowBeans)this, Core_Msg.FCBAC0068, new Object[0])); }  } else { setValue(null, list); }  }
/*      */   public String getViewValue() { return getValue(); }
/*      */   public MCMessageList setValue(String value) { return setValue(value, null); }
/*      */   protected MCMessageList setValue(String value, MCMessageList list) { if (list == null)
/*      */       list = new MCMessageList();  int cnt = list.size(); value = (String)_adjustValue(value); value = MCBeansUtil._getExtractText(this, value); if (isValueChanged(value)) { canChange(value, list); if (list.size() == cnt) { setText(value); commitValue(value, false); }  } else { setRowToViews(); }  return list; }
/*      */   public String getValue() { String t = getText(); String v = getTrimValue(t); if (!MCStringUtil.eq(t, v))
/*      */       setText(v);  return !MCStringUtil.isNull(v) ? v : null; }
/*      */   public boolean canChange() { return (canChange(getValue(), null).size() == 0); }
/*      */   protected MCMessageList canChange(String value, MCMessageList list) { if (list == null)
/*      */       list = new MCMessageList();  int cnt = list.size(); if (isInputMethodEditing()) { list.add(MCBeansUtil.createCauseMsg((MCRowBeans)this, Core_Msg.FCBAC0033, new Object[0])); return list; }  MCEventProxy.PROXY.setValue(getEventInfo(), getRowValue(), value); checkValue(value, list); if (list.size() == cnt)
/*      */       if (!doVC())
/*      */         list.add(MCBeansUtil.createCauseMsg((MCRowBeans)this, Core_Msg.FCBAC0032, new Object[] { value }));   if (list.size() != cnt)
/*      */       doCheckValueError();  return list; }
/*      */   public MCMessageList checkValue(Comparable<?> value) { return getValueChecker().checkValue(this, value); }
/*      */   public boolean checkValue(Comparable<?> value, MCMessageList list) { MCMessageList l = getValueChecker().checkValue(this, value); boolean e = (l.size() == 0); if (!e && list != null)
/*      */       list.addAll((Collection)l);  return e; }
/*      */   public MCMessageList checkInputValue(String value) { return getValueChecker().checkInputValue(this, value); }
/*      */   public boolean checkInputValue(Comparable<?> value, MCMessageList list) { MCMessageList l = getValueChecker().checkInputValue(this, value); boolean e = (l.size() == 0); if (!e && list != null)
/*      */       list.addAll((Collection)l);  return e; }
/*      */   public void updateResource(MCRootPanel panel) { super.updateResource(panel); if (panel != null) { MCPropertyCache p = panel.getPropertyCache(MCCacheType.SCREEN); String t = MCBeansUtil.getBeansString(panel, p, getTrimPatternKey()); if (t != null)
/*      */         setTrimPattern(t);  }  }
/*      */   public void setTrimPattern(String pattern) { this._trim = pattern; }
/*      */   public String getTrimPattern() { return this._trim; }
/*      */   public void setLength(int length) { this._length = (length < 0) ? Integer.MAX_VALUE : length; }
/*  107 */   public int getLength() { return this._length; } public void doAfterInsert() {} @Deprecated public MCTextField(String name) { super(name);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  807 */     this._accept_ptn = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  895 */     this._except_chars = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1057 */     this._plural_value_enable = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1233 */     this._drop_enable = MCBeansUtil.isDropEnable((MCBeans)this); }
/*      */   boolean setValueNoListCheck(Comparable<?> value, MCMessageList list, boolean doLC) { boolean result = true; String v = null; if (value != null)
/*      */       if (result = value instanceof String) { v = (String)_adjustValue(value); v = MCBeansUtil._getExtractText(this, v); } else { list.add(MCBeansUtil.createCauseMsg((MCRowBeans)this, Core_Msg.FCBAC0068, new Object[0])); }   boolean changed = false; if (result)
/*      */       if (changed = isValueChanged(v)) { MCEventProxy.PROXY.setValue(getEventInfo(), getRowValue(), value); if ((result = checkInputValue(v, list)) && (result = doVC())) { setText(v); setViewToRow(); doNC(); }  } else { setRowToViews(); }   if (!result) { doCheckValueError(); } else if (doLC && changed) { doLC(); }  return result; }
/*      */   protected Comparable<?> _adjustValue(Comparable<?> value) { if (value instanceof String) { String v = MCStringUtil.convertToLF((String)value); v = getTrimValue(v); return v; }  return value; }
/*      */   private String getTrimValue(String value) { String v; if (!isPluralValueEnable()) { v = MCBeansUtil.trim(value, getTrimPattern()); } else if (!MCStringUtil.isNull(value)) { String[] va = MCStringUtil.arrayValueSplit(value); for (int i = 0; i < va.length; i++)
/*      */         va[i] = MCBeansUtil.trim(va[i], getTrimPattern());  v = MCStringUtil.arrayValueJoin(va); } else { v = null; }  return MCStringUtil.isNull(v) ? null : v; }
/*      */   @Deprecated public void setDocument(Document doc) { if (doc instanceof MCTextDocument)
/*      */       super.setDocument(doc);  }
/*      */   public void setDocument(MCTextDocument doc) { super.setDocument((Document)doc); }
/*      */   public MCTextDocument getDocument() { MCTextDocument mCTextDocument; Document d = super.getDocument(); if (d == null) { mCTextDocument = new MCTextDocument(this); setDocument(mCTextDocument); }  return mCTextDocument; }
/*      */   public String getRowValue() { MCConstRow c = getBaseRow(); String n = getBaseRowColumnName(); return !MCBeansUtil.isNull(c, n) ? c.getString(n) : null; }
/* 1245 */   protected void setViewToRow(Comparable<?> value) { MCConstRow c = getBaseRow(); String n = getBaseRowColumnName(); if (!MCBeansUtil.isNull(c, n)) { c.setString(n, (String)value); MCBeansUtil.setGUIModified((MCRowBeans)this, c); }  } private boolean canFD(TransferHandler.TransferSupport support) { return (this._drop_enable && this._file_drop_listener != null && 
/* 1246 */       this._file_drop_listener.canFDEvent()); } public List<Pattern> getAcceptPattern() { if (this._accept_ptn == null) { String k = MCConst.createKey(new String[] { getType(), "accept" }); String ptn = MCConst.beans.getString(k); if (ptn != null) setAcceptPattern(ptn);  }  return this._accept_ptn; } public void setAcceptPattern(List<Pattern> l) { this._accept_ptn = l; } public void addAcceptPattern(String ptn) { List<Pattern> l = getAcceptPattern(); if (l == null) { setAcceptPattern(ptn); } else { addAcceptPattern(l, ptn); }  } public void addAcceptPattern(String ptn, int flags) { List<Pattern> l = getAcceptPattern(); if (l == null) { setAcceptPattern(ptn, flags); } else { addAcceptPattern(l, ptn, flags); }  } private void setAcceptPattern(String ptn) { this._accept_ptn = new ArrayList<>(); addAcceptPattern(this._accept_ptn, ptn); } private void setAcceptPattern(String ptn, int flags) { this._accept_ptn = new ArrayList<>(); addAcceptPattern(this._accept_ptn, ptn, flags); } private void addAcceptPattern(List<Pattern> l, String ptn) { try { l.add(Pattern.compile(ptn)); } catch (PatternSyntaxException patternSyntaxException) { throw new MCException(Core_Msg.FCBAC0333, new Object[] { ptn }); }  }
/*      */   private void addAcceptPattern(List<Pattern> l, String ptn, int flags) { try { l.add(Pattern.compile(ptn)); } catch (PatternSyntaxException patternSyntaxException) { throw new MCException(Core_Msg.FCBAC0333, new Object[] { ptn, Integer.valueOf(flags) }); }  }
/*      */   public List<Character> getExceptCharacter() { if (this._except_chars == null) { String k = MCConst.createKey(new String[] { getType(), "except" }); String s = MCConst.beans.getString(k); if (s != null && s.length() > 0) setExceptCharacter(s.toCharArray());  }  return this._except_chars; }
/*      */   public void setExceptCharacter(List<Character> l) { this._except_chars = l; }
/*      */   public void setExceptCharacter(char[] cs) { this._except_chars = new ArrayList<>(); byte b; int i; char[] arrayOfChar; for (i = (arrayOfChar = cs).length, b = 0; b < i; ) { Character c = Character.valueOf(arrayOfChar[b]); this._except_chars.add(c); b++; }  }
/*      */   public void addExceptCharacter(char c) { List<Character> l = getExceptCharacter(); if (l == null) { this._except_chars = new ArrayList<>(); l = this._except_chars; }  l.add(Character.valueOf(c)); }
/*      */   public JComponent getComponent() { return (JComponent)this; }
/*      */   public Comparable<?> doListFormat(Comparable<?> value) { return value; }
/*      */   public void focusGained() { super.focusGained(); _installInputMethod(); }
/*      */   public void focusLost() { super.focusLost(); _uninstallInputMethod(); }
/*      */   void repaintFocusChange() { Rectangle r = getBounds(); r.x = 0; r.y = 0; paintImmediately(r); }
/* 1257 */   private void doFD() { MCBeansUtil.fd((JComponent)this, getBaseRootPanel(), this._file_drop_listener); } public void setInputMethodType(MCInputMethodType type) { if (type == null)
/*      */       type = MCInputMethodType.NONE;  this._input_method_type = type; }
/*      */   public MCInputMethodType getInputMethodType() { if (MCMode.isDisable((MCModeBeans)this))
/*      */       return MCInputMethodType.OFF;  return this._input_method_type; }
/*      */   private MCIMDelegate getIMDelegate() { return (this._im_delegate != null) ? this._im_delegate : (this._im_delegate = MCTextProxy.PROXY.createIMDelegate()); }
/*      */   @Deprecated protected void _installInputMethod() { MCTextProxy.PROXY.installInputMethod(getIMDelegate(), (Component)this, getInputMethodType()); }
/*      */   @Deprecated protected void _uninstallInputMethod() { MCTextProxy.PROXY.uninstallInputMethod(getIMDelegate(), (Component)this, getInputMethodType()); }
/*      */   public void enableInputMethods(boolean enable) { if (getInputMethodType() == MCInputMethodType.OFF)
/*      */       enable = false;  super.enableInputMethods(enable); }
/*      */   void setPluralValueEnable(boolean enable) { if (MCConst.plugin.getBoolean(MCConst.createKey(new String[] { "ArrayValue", "invalid" }, ), false)) {
/*      */       this._plural_value_enable = false;
/*      */     } else {
/*      */       this._plural_value_enable = enable;
/*      */     }  }
/*      */   public boolean isPluralValueEnable() { return this._plural_value_enable; }
/*      */   @Deprecated public boolean _isLastInsert() { if (isPluralValueEnable())
/*      */       return false;  String text = getText(); MCRootPanel base = getBaseRootPanel(); if (base != null && base.isInPluralValue())
/*      */       text = base.removeNotLikeString((MCBeans)this, text);  return (getLength() == MCStringUtil.codePointCount(text)); }
/*      */   public boolean isAutoFocus() { if (isPluralValueEnable())
/*      */       return false;  return super.isAutoFocus(); }
/*      */   protected void execLink(MCRow row, boolean msg) { row = setPluralValue(row); super.execLink(row, msg); }
/*      */   protected MCRow setPluralValue(MCRow row) { if (isPluralValueEnable()) {
/*      */       MCListType y = getListType(); if ((MCListType.STRICT.equals(y) || MCListType.SELECT_ONLY.equals(y)) && row == null && !MCStringUtil.isNull(getValue())) {
/*      */         MCList<?> l = getList(); if (l != null) {
/*      */           if (l.size() > 0) {
/*      */             row = l.get(0).clone(); row.clear();
/*      */           } else {
/*      */             row = l.createRow();
/*      */           } 
/*      */         } else {
/*      */           row = MCRow.create();
/*      */         }  String n = getListNames()[0]; if (!row.contains(n))
/*      */           row.addStringColumn(n);  row.setString(n, getValue());
/*      */       } 
/*      */     }  return row; }
/*      */   public void paste() { MCTextDocument d = getDocument(); try {
/*      */       MCTextProxy.PROXY.setPasteActionProcessing(d, true); super.paste();
/*      */     } finally {
/*      */       MCTextProxy.PROXY.setPasteActionProcessing(d, false);
/*      */     }  }
/*      */   protected boolean isValueChanged(Comparable<?> view, Comparable<?> row) { return super.isValueChanged(_adjustValue(view), _adjustValue(row)); }
/*      */   public MCPopupMenu configurePopup() { MCAPListener ap = getPopupActionListener(); MCPopupMenu m = super.configurePopup(); MCPopupMenu pm = getComponentPopupMenu(); MCTextPopupMenuItem item = getOpenMenuItem(); if (!pm.contains((Component)item)) {
/*      */       item.addAPListener(ap); pm.add(item); item.updateResource();
/*      */     }  MCBeansUtil.setOpenMenuVisible((JTextComponent)this, item); if (m != null)
/*      */       m.sort();  return m; }
/*      */   protected MCAPListener getPopupActionListener() { if (this._popup_listener == null)
/*      */       this._popup_listener = (MCAPListener)new MCPopupActionListener(this);  return this._popup_listener; }
/*      */   public MCTextPopupMenuItem getOpenMenuItem() { if (this._popup_open == null)
/*      */       this._popup_open = MCBeansUtil.createPopupMenuItem((MCPopupBeans)this, "POPUP_OPEN"); 
/*      */     return this._popup_open; }
/* 1307 */   public String convToMaximumValues(String before, int offs, String str) { return getValueChecker().convMaximumValues(this, before, offs, str); }
/*      */ 
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\MCTextField.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */