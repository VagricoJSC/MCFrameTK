/*   */ package META-INF.versions.21.mcframe.clientCore.beans;
/*   */ 
/*   */ import mcframe.clientCore.beans.MCButton;
/*   */ 
/*   */ public class MCBeansCompatibilityUtil {
/*   */   public static MCButton createButtonStatusBar(String name) {
/* 7 */     return (MCButton)new Object(name);
/*   */   }
/*   */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\MCBeansCompatibilityUtil.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */