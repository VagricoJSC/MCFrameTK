/*    */ package META-INF.versions.21.mcframe.clientCore.beans;
/*    */ import java.awt.event.FocusEvent;
/*    */ 
/*    */ class MCButton21 extends MCButton {
/*    */   public MCButton21(String name) {
/*  6 */     super(name);
/*    */   }
/*    */   
/*    */   public MCButton21(String name, String group) {
/* 10 */     super(name, group);
/*    */   }
/*    */ 
/*    */   
/*    */   public void requestFocus(FocusEvent.Cause cause) {
/* 15 */     doFocus(false);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\MCButton21.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */