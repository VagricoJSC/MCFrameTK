/*    */ package META-INF.versions.21.mcframe.clientCore.beans;
/*    */ import java.awt.event.FocusEvent;
/*    */ 
/*    */ class MCRadioButton21 extends MCRadioButton {
/*    */   public MCRadioButton21(String name) {
/*  6 */     super(name);
/*    */   }
/*    */ 
/*    */   
/*    */   public void requestFocus(FocusEvent.Cause cause) {
/* 11 */     doFocus(false);
/*    */   }
/*    */ 
/*    */   
/*    */   public final boolean requestFocusInWindow(FocusEvent.Cause cause) {
/*    */     try {
/* 17 */       Method m = JToggleButton.class.getDeclaredMethod("requestFocusInWindowUnconditionally", new Class[] { FocusEvent.Cause.class });
/* 18 */       m.setAccessible(true);
/* 19 */       return ((Boolean)m.invoke(this, new Object[] { cause })).booleanValue();
/*    */     }
/* 21 */     catch (Exception exception) {
/*    */ 
/*    */       
/* 24 */       return false;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\MCRadioButton21.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */