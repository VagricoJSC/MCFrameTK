/*     */ package META-INF.versions.21.mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.swing.table.JTableHeader;
/*     */ import javax.swing.table.TableCellRenderer;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.table.MCColumnConfig;
/*     */ import mcframe.clientCore.beans.table.MCColumnGroup;
/*     */ import mcframe.clientCore.beans.table.MCColumnGroupMember;
/*     */ import mcframe.clientCore.beans.table.MCColumnGroupTableColumnModel;
/*     */ import mcframe.clientCore.beans.table.MCColumnGroupTableHeader;
/*     */ import mcframe.clientCore.beans.table.MCFixedColumnGroupTable;
/*     */ import mcframe.clientCore.beans.table.MCFixedColumnTable;
/*     */ import mcframe.clientCore.beans.table.MCMultiLineHeaderRenderer;
/*     */ import mcframe.clientCore.beans.table.MCTable;
/*     */ import mcframe.clientCore.beans.table.MCTableColumn;
/*     */ import mcframe.clientCore.beans.table.MCTableColumnModel;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.util.MCCollectionUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCColumnGroupTable<E extends MCConstRow>
/*     */   extends MCTable<E>
/*     */ {
/*     */   @Deprecated
/*     */   public MCColumnGroupTable(String name) {
/*  34 */     super(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addColumnGroup(MCColumnGroup cg) {
/*  45 */     cg.setTable(this);
/*  46 */     getColumnModel().addColumnGroup(cg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addColumnGroup(MCTable<? extends MCConstRow> table) {
/*  63 */     if (table instanceof mcframe.clientCore.beans.table.MCColumnGroupTable) {
/*  64 */       MCColumnGroupTableColumnModel model = getColumnModel();
/*  65 */       mcframe.clientCore.beans.table.MCColumnGroupTable<?> ptable = (mcframe.clientCore.beans.table.MCColumnGroupTable)table;
/*  66 */       MCColumnGroupTableColumnModel pmodel = ptable.getColumnModel();
/*  67 */       MCColumnGroup[] cgs = pmodel.getColumnGroups(); byte b; int i; MCColumnGroup[] arrayOfMCColumnGroup1;
/*  68 */       for (i = (arrayOfMCColumnGroup1 = cgs).length, b = 0; b < i; ) { MCColumnGroup cg = arrayOfMCColumnGroup1[b];
/*  69 */         model.addColumnGroup(cg);
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCColumnGroup[] getAllColumnGroups() {
/*  85 */     MCFixedColumnGroupTable<E> fixed = getFixedColumnGroupTable();
/*  86 */     return (MCColumnGroup[])MCCollectionUtil.concat((Object[][])new MCColumnGroup[][] { fixed.getColumnModel().getAllColumnGroups(), 
/*  87 */           getColumnModel().getAllColumnGroups() });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   mcframe.clientCore.beans.table.MCColumnGroupTable<E> getBodyColumnGroupTable() {
/*  98 */     return (mcframe.clientCore.beans.table.MCColumnGroupTable<E>)getBodyTable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCFixedColumnGroupTable<E> getFixedColumnGroupTable() {
/* 109 */     return (MCFixedColumnGroupTable<E>)getFixedColumnTable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getColumnLabelByLocale(MCColumnConfig column) {
/* 135 */     MCColumnGroupTableColumnModel model = isFixedColumn(column) ? getFixedColumnGroupTable()
/* 136 */       .getColumnModel() : getColumnModel();
/* 137 */     return getColumnLabelByLocale((MCTableColumn)column, model);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getColumnLabelByLocale(MCTableColumn column, MCColumnGroupTableColumnModel model) {
/* 152 */     return createColumnGroupString((ColumnStringSupplier)new Object(this, column), 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 167 */         model, null, null, ".");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getColumnMessageByLocale(MCColumnConfig column) {
/* 194 */     MCColumnGroupTableColumnModel model = isFixedColumn(column) ? getFixedColumnGroupTable()
/* 195 */       .getColumnModel() : getColumnModel();
/* 196 */     return getColumnMessageByLocale((MCTableColumn)column, model);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getColumnMessageByLocale(MCTableColumn column, MCColumnGroupTableColumnModel model) {
/* 211 */     return createColumnGroupString((ColumnStringSupplier)new Object(this, column), 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 226 */         model, null, null, ".");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String createColumnGroupString(ColumnStringSupplier css, MCColumnGroupTableColumnModel model, String format, String groupformat, String separator) {
/* 314 */     if (css == null || css.getColumn() == null) {
/* 315 */       return null;
/*     */     }
/* 317 */     MCColumnGroup[] cgs = model.getColumnGroups(css.getColumn());
/* 318 */     if (cgs.length == 0)
/*     */     {
/* 320 */       return css.getString();
/*     */     }
/*     */ 
/*     */     
/* 324 */     separator = (separator != null) ? separator : "";
/*     */ 
/*     */     
/* 327 */     StringBuilder cgsb = new StringBuilder();
/* 328 */     if (groupformat == null) {
/*     */       byte b; int i; MCColumnGroup[] arrayOfMCColumnGroup;
/* 330 */       for (i = (arrayOfMCColumnGroup = cgs).length, b = 0; b < i; ) { MCColumnGroup cg = arrayOfMCColumnGroup[b];
/* 331 */         cgsb.append(css.getString(cg));
/* 332 */         cgsb.append(separator); b++; }
/*     */     
/*     */     } else {
/*     */       byte b; int i;
/*     */       MCColumnGroup[] arrayOfMCColumnGroup;
/* 337 */       for (i = (arrayOfMCColumnGroup = cgs).length, b = 0; b < i; ) { MCColumnGroup cg = arrayOfMCColumnGroup[b];
/* 338 */         cgsb.append(MCStringUtil.bind(groupformat, new Object[] { css.getString(cg) }));
/* 339 */         cgsb.append(separator); b++; }
/*     */     
/*     */     } 
/* 342 */     cgsb.setLength(cgsb.length() - separator.length());
/*     */ 
/*     */     
/* 345 */     String name = css.getString();
/* 346 */     name = (format != null) ? MCStringUtil.bind(format, new Object[] { cgsb, name }) : (cgsb.toString() + cgsb.toString() + 
/* 347 */       separator);
/*     */ 
/*     */     
/* 350 */     return name.replaceAll("\n|\r", "");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCFixedColumnTable<E> createFixedColumnTable(String name) {
/* 358 */     return (MCFixedColumnTable<E>)new MCFixedColumnGroupTable(this, name);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected JTableHeader createDefaultTableHeader() {
/* 364 */     return (JTableHeader)new MCColumnGroupTableHeader((TableColumnModel)getColumnModel());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MCColumnGroupTableHeader getTableHeader() {
/* 370 */     return (MCColumnGroupTableHeader)super.getTableHeader();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCColumnGroupTableColumnModel createDefaultColumnModel() {
/* 376 */     return new MCColumnGroupTableColumnModel();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MCColumnGroupTableColumnModel getColumnModel() {
/* 382 */     return (MCColumnGroupTableColumnModel)super.getColumnModel();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setRenderers() {
/* 388 */     getTableHeader().setDefaultRenderer(
/* 389 */         (TableCellRenderer)new MCMultiLineHeaderRenderer(getTableHeader().getDefaultRenderer()));
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateResource(MCRootPanel panel) {
/* 394 */     super.updateResource(panel);
/*     */ 
/*     */     
/* 397 */     if (panel != null && isBodyTable()) {
/* 398 */       MCColumnGroup[] cgs = getAllColumnGroups(); byte b; int i; MCColumnGroup[] arrayOfMCColumnGroup1;
/* 399 */       for (i = (arrayOfMCColumnGroup1 = cgs).length, b = 0; b < i; ) { MCColumnGroup cg = arrayOfMCColumnGroup1[b];
/* 400 */         cg.updateResource(panel);
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   }
/*     */   
/*     */   void updateColumnsFontSize(int fontratio, int widthratio, boolean check) {
/* 407 */     super.updateColumnsFontSize(fontratio, widthratio, check);
/*     */ 
/*     */     
/* 410 */     MCColumnGroup[] cgs = getAllColumnGroups(); byte b; int i; MCColumnGroup[] arrayOfMCColumnGroup1;
/* 411 */     for (i = (arrayOfMCColumnGroup1 = cgs).length, b = 0; b < i; ) { MCColumnGroup cg = arrayOfMCColumnGroup1[b];
/* 412 */       cg.getColumn().updateFontSize(fontratio, widthratio, check);
/*     */       b++; }
/*     */   
/*     */   }
/*     */   
/*     */   void initColumns() {
/* 418 */     super.initColumns();
/*     */ 
/*     */     
/* 421 */     MCColumnGroup[] cgs = getAllColumnGroups(); byte b; int i; MCColumnGroup[] arrayOfMCColumnGroup1;
/* 422 */     for (i = (arrayOfMCColumnGroup1 = cgs).length, b = 0; b < i; ) { MCColumnGroup cg = arrayOfMCColumnGroup1[b];
/* 423 */       cg.getColumn().initialized();
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void _setUserColumnOrder(Map<Integer, MCColumnConfig> m) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUnscrollColumn(MCColumnConfig column) {
/* 435 */     column = setUnscrollColumnGroup(column);
/*     */     
/* 437 */     super.setUnscrollColumn(column);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCColumnConfig setUnscrollColumnGroup(MCColumnConfig column) {
/* 455 */     boolean find = (column == null);
/* 456 */     MCColumnGroup belong = null;
/* 457 */     Set<MCColumnGroup> setf = new LinkedHashSet<>();
/* 458 */     Set<MCColumnGroup> sets = new LinkedHashSet<>();
/*     */     
/* 460 */     MCColumnGroupTableColumnModel[] models = {
/* 461 */         getFixedColumnGroupTable().getColumnModel(), getColumnModel() }; byte b; int i;
/*     */     MCColumnGroupTableColumnModel[] arrayOfMCColumnGroupTableColumnModel1;
/* 463 */     for (i = (arrayOfMCColumnGroupTableColumnModel1 = models).length, b = 0; b < i; ) { MCColumnGroupTableColumnModel model = arrayOfMCColumnGroupTableColumnModel1[b];
/* 464 */       int len = model.getColumnCount();
/* 465 */       for (int j = 0; j < len; j++) {
/* 466 */         TableColumn tc = model.getColumn(j);
/* 467 */         MCColumnGroup[] cgs = model.getColumnGroups(tc);
/* 468 */         if (cgs.length > 0)
/*     */         {
/* 470 */           if (find) {
/*     */             
/* 472 */             if (!setf.contains(cgs[0])) {
/* 473 */               sets.add(cgs[0]);
/*     */             }
/*     */           }
/*     */           else {
/*     */             
/* 478 */             setf.add(cgs[0]);
/*     */           } 
/*     */         }
/* 481 */         if (tc == column) {
/*     */           
/* 483 */           find = true;
/* 484 */           belong = (cgs.length > 0) ? cgs[0] : null;
/*     */         } 
/*     */       }  b++; }
/*     */     
/* 488 */     if (belong != null)
/*     */     {
/* 490 */       column = getLastGroupMember(belong);
/*     */     }
/*     */ 
/*     */     
/* 494 */     models[0].setAllColumnGroup(setf);
/* 495 */     models[1].setAllColumnGroup(sets);
/*     */     
/* 497 */     return column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private MCColumnConfig getLastGroupMember(MCColumnGroup cg) {
/* 509 */     MCColumnConfig c = null;
/* 510 */     MCColumnGroupMember[] gms = cg.getMembers();
/* 511 */     int size = gms.length;
/* 512 */     if (size > 0) {
/* 513 */       MCColumnGroupMember gm = gms[size - 1];
/* 514 */       if (gm instanceof MCColumnGroup) {
/* 515 */         c = getLastGroupMember((MCColumnGroup)gm);
/*     */       } else {
/*     */         
/* 518 */         c = (MCColumnConfig)gm;
/*     */       } 
/*     */     } 
/* 521 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void adjustWidth(MCTableColumn column) {
/* 528 */     super.adjustWidth(column);
/*     */     
/* 530 */     MCColumnGroupTableColumnModel[] models = {
/* 531 */         getFixedColumnGroupTable().getColumnModel(), getColumnModel() }; byte b; int i;
/*     */     MCColumnGroupTableColumnModel[] arrayOfMCColumnGroupTableColumnModel1;
/* 533 */     for (i = (arrayOfMCColumnGroupTableColumnModel1 = models).length, b = 0; b < i; ) { MCColumnGroupTableColumnModel model = arrayOfMCColumnGroupTableColumnModel1[b];
/* 534 */       MCColumnGroup[] cgs = model.getColumnGroups((TableColumn)column);
/* 535 */       if (cgs.length <= 0) {
/*     */         b++;
/*     */         
/*     */         continue;
/*     */       } 
/* 540 */       for (int cgpos = cgs.length - 1; cgpos >= 0; cgpos--) {
/* 541 */         MCColumnGroup cg = cgs[cgpos];
/* 542 */         MCTableColumn[] cols = cg.getAllColumns();
/* 543 */         int allwidth = 0;
/* 544 */         for (int colpos = cols.length - 1; colpos >= 0; colpos--) {
/* 545 */           MCTableColumn col = cols[colpos];
/* 546 */           if (col.isViewColumn()) {
/* 547 */             if (allwidth <= 0 && col != column) {
/*     */               break;
/*     */             }
/*     */             
/* 551 */             allwidth += col.getPreferredWidth();
/*     */           } 
/*     */         } 
/* 554 */         if (allwidth <= 0) {
/*     */           break;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 560 */         int cgwidth = cg.getColumn().getAdjustedWidth();
/* 561 */         if (cgwidth > allwidth) {
/*     */           
/* 563 */           int newwidth = column.getPreferredWidth() + cgwidth - allwidth;
/* 564 */           column.setPreferredWidth(newwidth);
/*     */         } 
/*     */       } 
/*     */       break; }
/*     */   
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\table\MCColumnGroupTable.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */