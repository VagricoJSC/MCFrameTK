/*     */ package META-INF.versions.21.mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.event.KeyEvent;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.border.Border;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCMode;
/*     */ import mcframe.clientCore.beans.MCResourceBeans;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.action.MCKeyActionManager;
/*     */ import mcframe.clientCore.beans.combobox.MCCalendarComboBox;
/*     */ import mcframe.clientCore.beans.combobox.MCComboField;
/*     */ import mcframe.clientCore.beans.combobox.MCComboListModel;
/*     */ import mcframe.clientCore.beans.combobox.MCFieldComboBox;
/*     */ import mcframe.clientCore.beans.combobox.MCTimestampComboBox;
/*     */ import mcframe.clientCore.beans.list.MCLinkBeans;
/*     */ import mcframe.clientCore.beans.list.MCLinkedBeans;
/*     */ import mcframe.clientCore.beans.list.MCListConfig;
/*     */ import mcframe.clientCore.beans.list.MCListType;
/*     */ import mcframe.clientCore.beans.popup.MCPopupConfig;
/*     */ import mcframe.clientCore.beans.popup.MCPopupMenu;
/*     */ import mcframe.clientCore.beans.table.MCBeansProxy;
/*     */ import mcframe.clientCore.beans.table.MCCellUtil;
/*     */ import mcframe.clientCore.beans.table.MCColumnConfig;
/*     */ import mcframe.clientCore.beans.table.MCEditorBeans;
/*     */ import mcframe.clientCore.beans.table.MCEventProxy;
/*     */ import mcframe.clientCore.beans.table.MCTable;
/*     */ import mcframe.clientCore.beans.table.MCTableColumn;
/*     */ import mcframe.clientCore.event.MCEventInfo;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCCalendarDate;
/*     */ import mcframe.commonCore.lang.MCTimestamp;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCEditorTimestampComboBox
/*     */   extends MCTimestampComboBox
/*     */   implements MCEditorBeans
/*     */ {
/*  44 */   private MCTable<?> _table = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   private MCColumnConfig _column = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected MCEditorTimestampComboBox(String name, MCColumnConfig column) {
/*  65 */     super(name);
/*     */     
/*  67 */     setColumnConfig(column);
/*  68 */     setTable(column.getBaseTable());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getType() {
/*  73 */     return "table.column.combo-date";
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initBeans() {
/*  78 */     super.initBeans();
/*     */     
/*  80 */     setFocusTraversalKeysEnabled(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initKeyAssign() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initResource() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setTable(MCTable<?> table) {
/*  99 */     this._table = table;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCTable<?> getTable() {
/* 104 */     return this._table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setColumnConfig(MCColumnConfig column) {
/* 115 */     this._column = column;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCColumnConfig getColumnConfig() {
/* 120 */     return this._column;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getRowIndex() {
/* 125 */     return MCCellUtil.getRowIndex(this);
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCEditorComboField getComboField() {
/* 130 */     return (MCEditorComboField)super.getComboField();
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCEditorComboField createComboField() {
/* 135 */     return new MCEditorComboField(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void valueCommited() {
/* 140 */     MCTable<?> t = getTable();
/* 141 */     String o = getListConfig().getOpeType();
/*     */     
/* 143 */     MCTimestamp v = (MCTimestamp)getValue();
/* 144 */     if ("input".equals(o)) {
/* 145 */       setSelectedItem((Comparable)v);
/*     */     }
/* 147 */     else if ("list".equals(o) && 
/* 148 */       v == null) {
/* 149 */       setSelectedItem((Comparable)v);
/*     */     } 
/*     */ 
/*     */     
/* 153 */     MCRow row = getSelectedListRow();
/*     */     
/* 155 */     if ("input".equals(o)) {
/* 156 */       row = getListRow((Comparable)getValue());
/*     */     }
/* 158 */     if (row == null && 
/* 159 */       getListType() == MCListType.FREE) {
/* 160 */       row = MCRow.create();
/* 161 */       MCBeansProxy.PROXY.addColumn(row, getListNames()[0], getDataType(), 
/* 162 */           getViewValue());
/*     */     } 
/*     */     
/* 165 */     MCEventInfo e = getEventInfo();
/* 166 */     String key = getKeyColumnName();
/* 167 */     if (MCBeansProxy.PROXY.haveLinkValuesNull(e, (MCLinkBeans)this, (Comparable)getValue(), getList(), key)) {
/* 168 */       MCRow r = row.clone();
/* 169 */       r.clear();
/* 170 */       r.setValue(key, e.getNewValue());
/* 171 */       ((MCTableColumn)getColumnConfig()).execLink(t.getMCEditingRow(), r, true);
/*     */     } else {
/*     */       
/* 174 */       ((MCTableColumn)getColumnConfig()).execLink(t.getMCEditingRow(), row, true);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Border getDefaultBorder() {
/* 180 */     return MCCellUtil.DEFAULT_BORDER;
/*     */   }
/*     */ 
/*     */   
/*     */   public void transferFocus() {
/* 185 */     MCTable<?> t = getTable();
/* 186 */     t.transferFocus(getRowIndex(), t.getViewColumn(getColumnConfig()) + 1, false, 
/* 187 */         true, true);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void execLink(MCRow row, boolean msg) {
/* 192 */     ((MCTableColumn)getColumnConfig()).execLink(getRowIndex(), row, msg);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canChange() {
/*     */     try {
/* 198 */       MCTable.setEditingStoppedEnabled(false);
/*     */ 
/*     */       
/* 201 */       MCEventInfo info = getTable().getEventInfo();
/* 202 */       MCEventProxy.PROXY.setIndex(info, getTable().getMCSelectedRow(), 
/* 203 */           info.getNewIndex());
/*     */       
/* 205 */       return super.canChange();
/*     */     } finally {
/*     */       
/* 208 */       MCTable.setEditingStoppedEnabled(true);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void setColumnInfo(int index, MCColumnConfig column) {
/* 213 */     setColumnConfig(column);
/* 214 */     MCTable<?> table = getTable();
/*     */     
/* 216 */     MCKeyActionManager.init((MCResourceBeans)this, getInputMap(1), 
/* 217 */         getActionMap());
/* 218 */     JComponent c = getComboField().getComponent();
/* 219 */     MCKeyActionManager.init((MCResourceBeans)this, c.getInputMap(), c.getActionMap());
/*     */     
/* 221 */     MCKeyActionManager.initScreen((MCResourceBeans)this, 
/* 222 */         getInputMap(1), getActionMap());
/* 223 */     MCKeyActionManager.initScreen((MCResourceBeans)this, c.getInputMap(), c.getActionMap());
/*     */     
/* 225 */     MCMode mode = MCCellUtil.isCellEditable(index, column, table);
/* 226 */     setMode(mode);
/* 227 */     setForeground(MCCellUtil.getForeground(index, column, table, false, mode));
/* 228 */     setBackground(MCCellUtil.getBackground(index, column, table, false, mode));
/* 229 */     setFont(column.getFont());
/* 230 */     setCaretColor(MCCellUtil.getCaretColor(index, column, table));
/* 231 */     setSelectionColor(MCCellUtil.getSelectionColor(index, column, table));
/* 232 */     setSelectedTextColor(MCCellUtil.getSelectedTextColor(index, column, table));
/* 233 */     setMeta(column.getMeta());
/* 234 */     setListVisibleColumn(column.getListVisibleColumn());
/* 235 */     setRow(column.getTable().getRow(index), column.getRowColumnName());
/* 236 */     setAutoFocus(column.isAutoFocus());
/* 237 */     setSelectAll(column.isSelectAll());
/* 238 */     MCListConfig lc = column.getListConfig();
/* 239 */     setListConfig(lc);
/* 240 */     setCalendarFormat(MCCellUtil.getTimestampFormat(index, column, table, mode));
/* 241 */     setCalendarValidator(column.getCalendarValidator());
/*     */     
/* 243 */     if (lc.getListType() == MCListType.SELECT_ONLY) {
/* 244 */       setDocumentEditable(false);
/*     */     }
/*     */     
/* 247 */     setComboListConfig(column.getComboListConfig());
/*     */     
/* 249 */     Border border = MCCellUtil.getEditorBorder(index, column, table);
/* 250 */     if (border != null) {
/* 251 */       setBorder(border);
/*     */     } else {
/*     */       
/* 254 */       setBorder(getDefaultBorder());
/*     */     } 
/* 256 */     MCPopupMenu menu = getComponentPopupMenu();
/* 257 */     if (menu != null) {
/* 258 */       menu.updateResource();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Border getBorder() {
/* 264 */     Border b = MCCellUtil.getBorder(this);
/* 265 */     return (b != null) ? b : super.getBorder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCRootPanel getRootPanel() {
/* 277 */     return MCCellUtil.getRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCRootPanel getNearestRootPanel() {
/* 282 */     return MCCellUtil.getNearestRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessageByLocale() {
/* 287 */     return getColumnConfig().getMessageByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLabelByLocale() {
/* 292 */     return getColumnConfig().getLabelByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterRequestFocus() {
/* 297 */     MCRootPanel bp = getBaseRootPanel();
/* 298 */     MCBeansUtil.afterRequestFocus(bp, (JComponent)getTable());
/* 299 */     MCBeansUtil.scrollRectToVisible(bp, (JComponent)this, 
/* 300 */         getComboField().getHorizontalAlignment());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 305 */     repaint();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFocusOwner() {
/* 310 */     MCTable<?> t = getTable();
/* 311 */     return (t != null) ? (t.isRemoveNotifyProcessing() ? super.isFocusOwner() : false) : 
/* 312 */       super.isFocusOwner();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValueChanged() {
/* 317 */     return isValueChanged((Comparable<?>)getRowValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValueChanged(Comparable<?> value) {
/* 322 */     adjustViewValue();
/*     */     try {
/* 324 */       return isValueChanged((Comparable<?>)getValue(), value);
/*     */     }
/* 326 */     catch (MCException mCException) {
/* 327 */       return true;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isValueChanged(Comparable<?> view, Comparable<?> row) {
/* 333 */     return MCCellUtil.isValueChanged(this, view, row);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasFocus() {
/* 338 */     MCTable<?> t = getTable();
/* 339 */     return (t != null) ? ((this == t.getMCEditorComponent())) : super.hasFocus();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isMCFocusOwner() {
/* 344 */     MCTable<?> t = getTable();
/* 345 */     return (t != null) ? ((t.getMCEditorComponent() == this)) : isFocusOwner();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCListType getListType() {
/* 350 */     MCColumnConfig c = getColumnConfig();
/* 351 */     return (c != null) ? c.getListType() : super.getListType();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCLinkedBeans[] getLinkBeans() {
/* 356 */     MCColumnConfig c = getColumnConfig();
/* 357 */     return (c != null) ? c.getLinkBeans() : super.getLinkBeans();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRowToViews() {
/* 362 */     boolean e = MCBeansProxy.PROXY.isEventEnabled();
/*     */     try {
/* 364 */       MCBeansProxy.PROXY.setEventEnabled(false);
/* 365 */       setRowToView();
/* 366 */       MCLinkedBeans[] cs = getLinkBeans(); byte b; int i; MCLinkedBeans[] arrayOfMCLinkedBeans1;
/* 367 */       for (i = (arrayOfMCLinkedBeans1 = cs).length, b = 0; b < i; ) { MCLinkedBeans c = arrayOfMCLinkedBeans1[b];
/* 368 */         if (c instanceof MCColumnConfig) {
/* 369 */           MCColumnConfig col = (MCColumnConfig)c;
/* 370 */           int j = getRowIndex();
/* 371 */           col.setValue(j, 
/* 372 */               getTable().getRow(j).getValue(col.getBaseRowColumnName()));
/*     */         } 
/*     */         b++; }
/*     */     
/*     */     } finally {
/* 377 */       MCBeansProxy.PROXY.setEventEnabled(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCList doListEventEx() {
/* 386 */     MCTableColumn c = (MCTableColumn)getColumnConfig();
/* 387 */     MCEventProxy.PROXY.setEventIndex(c.getEventInfo(), getRowIndex());
/* 388 */     return c.doListEventEx();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCList doListEvent() {
/*     */     try {
/* 394 */       MCColumnConfig c = getColumnConfig();
/* 395 */       MCEventProxy.PROXY.setEventIndex(c.getEventInfo(), getRowIndex());
/* 396 */       return c.doListEvent();
/*     */     }
/* 398 */     catch (MCException e) {
/* 399 */       handle((Throwable)e);
/*     */       
/* 401 */       setRowToViews();
/*     */       
/* 403 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean doListEventWithNull() {
/* 408 */     MCColumnConfig c = getColumnConfig();
/* 409 */     return (c != null) ? c.doListEventWithNull() : false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean haveLinkValuesNullWhenDupliKeyTyped() {
/* 414 */     MCColumnConfig c = getColumnConfig();
/* 415 */     return (c != null) ? c.haveLinkValuesNullWhenDupliKeyTyped() : false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean doVC() {
/* 420 */     return getColumnConfig().doVC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNC() {
/* 425 */     getColumnConfig().doNC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNE() {
/* 430 */     getColumnConfig().doNE();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNX() {
/* 435 */     getColumnConfig().doNX();
/*     */     
/* 437 */     getListConfig().setOpeType("input");
/*     */   }
/*     */ 
/*     */   
/*     */   public void doLC() {
/* 442 */     getColumnConfig().doLC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doDC() {
/* 447 */     getColumnConfig().doDC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void focusGained() {
/* 452 */     setText((MCCalendarDate)getRowValue());
/* 453 */     focusGainedSelect();
/*     */   }
/*     */ 
/*     */   
/*     */   public void focusLost() {
/* 458 */     setText((MCCalendarDate)getRowValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public MCEventInfo getEventInfo() {
/* 463 */     return getColumnConfig().getEventInfo();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource(MCRootPanel panel) {}
/*     */ 
/*     */   
/*     */   public void doCheckValueError() {
/* 476 */     super.doCheckValueError();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCPopupConfig getPopupConfig() {
/* 481 */     MCTable<?> t = getTable();
/* 482 */     return (t != null) ? t.getPopupConfig() : null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCPopupMenu configurePopup(MCPopupMenu menu) {
/* 487 */     MCPopupConfig pc = getPopupConfig();
/* 488 */     return (pc != null) ? 
/* 489 */       pc.configurePopup(menu, getTable(), getRowIndex(), getColumnConfig()) : 
/* 490 */       menu;
/*     */   }
/*     */ 
/*     */   
/*     */   public void processKeyEvent(KeyEvent e) {
/* 495 */     MCCellUtil.beforeKeyEvent(e, this);
/* 496 */     super.processKeyEvent(e);
/*     */   }
/*     */ 
/*     */   
/*     */   public Comparable<?> doListFormat(Comparable<?> value) {
/* 501 */     return getColumnConfig().doListFormat(getRowIndex(), value);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Color getListForeground(MCRow row, boolean selected) {
/* 506 */     MCColumnConfig c = getColumnConfig();
/* 507 */     return getComboListConfig().getRowForeground(c, getRowIndex(), c.getTable(), row, 
/* 508 */         selected);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Color getListBackground(MCRow row, boolean selected) {
/* 513 */     MCColumnConfig c = getColumnConfig();
/* 514 */     return getComboListConfig().getRowBackground(c, getRowIndex(), c.getTable(), row, 
/* 515 */         selected);
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCEditorComboListModel createModel() {
/* 520 */     return new MCEditorComboListModel(this, this);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\table\MCEditorTimestampComboBox.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */