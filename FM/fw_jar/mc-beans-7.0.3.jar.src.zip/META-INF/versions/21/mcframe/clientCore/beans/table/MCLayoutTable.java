/*     */ package META-INF.versions.21.mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import javax.swing.SizeSequence;
/*     */ import javax.swing.table.JTableHeader;
/*     */ import javax.swing.table.TableCellRenderer;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.table.MCColumnConfig;
/*     */ import mcframe.clientCore.beans.table.MCColumnLayout;
/*     */ import mcframe.clientCore.beans.table.MCColumnLayoutMember;
/*     */ import mcframe.clientCore.beans.table.MCFixedColumnLayoutTable;
/*     */ import mcframe.clientCore.beans.table.MCFixedColumnTable;
/*     */ import mcframe.clientCore.beans.table.MCLayoutTableColumnModel;
/*     */ import mcframe.clientCore.beans.table.MCLayoutTableHeader;
/*     */ import mcframe.clientCore.beans.table.MCMultiLineHeaderRenderer;
/*     */ import mcframe.clientCore.beans.table.MCTable;
/*     */ import mcframe.clientCore.beans.table.MCTableColumn;
/*     */ import mcframe.clientCore.beans.table.MCTableColumnModel;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.clientCore.event.MCAPBeans;
/*     */ import mcframe.clientCore.event.MCEventInfo;
/*     */ import mcframe.commonCore.util.MCCollectionUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCLayoutTable<E extends MCConstRow>
/*     */   extends MCTable<E>
/*     */ {
/*     */   private static final String uiClassID = "MCLayoutTableUI";
/*     */   
/*     */   @Deprecated
/*     */   public MCLayoutTable(String name) {
/*  47 */     super(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addColumnLayout(MCColumnLayout layout) {
/*  59 */     getColumnModel().addColumnLayout(layout);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addColumnLayout(MCTable<? extends MCConstRow> table) {
/*  76 */     if (table instanceof mcframe.clientCore.beans.table.MCLayoutTable) {
/*  77 */       MCLayoutTableColumnModel model = getColumnModel();
/*  78 */       mcframe.clientCore.beans.table.MCLayoutTable<?> ptable = (mcframe.clientCore.beans.table.MCLayoutTable)table;
/*  79 */       MCLayoutTableColumnModel pmodel = ptable.getColumnModel();
/*  80 */       MCColumnLayout[] cls = pmodel.getColumnLayouts(); byte b; int i; MCColumnLayout[] arrayOfMCColumnLayout1;
/*  81 */       for (i = (arrayOfMCColumnLayout1 = cls).length, b = 0; b < i; ) { MCColumnLayout cl = arrayOfMCColumnLayout1[b];
/*  82 */         model.addColumnLayout(cl);
/*     */         b++; }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCColumnLayout[] getColumnLayouts() {
/* 101 */     return getColumnModel().getColumnLayouts();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTierCount() {
/* 113 */     MCFixedColumnLayoutTable<E> ft = getFixedColumnLayoutTable();
/* 114 */     return Math.max(_getTierCount(ft.getColumnModel()), 
/* 115 */         _getTierCount(getColumnModel()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int _getTierCount(MCLayoutTableColumnModel model) {
/* 127 */     int tier = 0;
/* 128 */     Iterator<MCColumnLayoutMember> ite = model.createLayoutMemberIterator();
/* 129 */     while (ite.hasNext()) {
/* 130 */       MCColumnLayoutMember member = ite.next();
/* 131 */       if (member instanceof MCColumnLayout) {
/* 132 */         MCColumnLayout layout = (MCColumnLayout)member;
/* 133 */         tier = Math.max(tier, layout.getTierCount()); continue;
/*     */       } 
/* 135 */       if (member instanceof MCTableColumn && 
/* 136 */         tier == 0) {
/* 137 */         tier = 1;
/*     */       }
/*     */     } 
/*     */     
/* 141 */     return tier;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   mcframe.clientCore.beans.table.MCLayoutTable<E> getBodyLayoutTable() {
/* 160 */     return (mcframe.clientCore.beans.table.MCLayoutTable<E>)getBodyTable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCFixedColumnLayoutTable<E> getFixedColumnLayoutTable() {
/* 179 */     return (MCFixedColumnLayoutTable<E>)getFixedColumnTable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUIClassID() {
/* 190 */     return "MCLayoutTableUI";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCFixedColumnLayoutTable<E> createFixedColumnTable(String name) {
/* 196 */     return new MCFixedColumnLayoutTable(this, name);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCLayoutTableHeader createDefaultTableHeader() {
/* 202 */     return new MCLayoutTableHeader(getColumnModel());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MCLayoutTableHeader getTableHeader() {
/* 208 */     return (MCLayoutTableHeader)super.getTableHeader();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCLayoutTableColumnModel createDefaultColumnModel() {
/* 214 */     return new MCLayoutTableColumnModel();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MCLayoutTableColumnModel getColumnModel() {
/* 220 */     return (MCLayoutTableColumnModel)super.getColumnModel();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setRenderers() {
/* 226 */     getTableHeader().setDefaultRenderer(
/* 227 */         (TableCellRenderer)new MCMultiLineHeaderRenderer(
/* 228 */           getTableHeader().getDefaultRenderer()));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   void initColumns() {
/* 234 */     super.initColumns();
/*     */ 
/*     */     
/* 237 */     MCColumnLayout[] ls = getColumnModel().getColumnLayouts(); byte b; int i; MCColumnLayout[] arrayOfMCColumnLayout1;
/* 238 */     for (i = (arrayOfMCColumnLayout1 = ls).length, b = 0; b < i; ) { MCColumnLayout l = arrayOfMCColumnLayout1[b];
/* 239 */       l.initialized();
/*     */       b++; }
/*     */   
/*     */   }
/*     */   
/*     */   public void doAPEvent(MCAPBeans compo, MCEventInfo info) {
/* 245 */     if (compo == getColumnWidthPanelMenuItem()) {
/*     */       
/* 247 */       MCRootPanel bp = getBaseRootPanel();
/* 248 */       MCRootPanel p = bp.createPanel(
/* 249 */           "FS", "FSBAP0110", MCRootPanel.SCREEN_MODAL, new Object[] { "T1", null, this });
/* 250 */       bp.showChildPanel(p, MCRootPanel.MULTI, new Object[0]);
/*     */     } else {
/*     */       
/* 253 */       super.doAPEvent(compo, info);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int getTierInRow() {
/* 263 */     return getTierCount();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUnscrollColumn(MCColumnConfig column) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MCColumnConfig setUnscrollColumnLayout(MCColumnConfig column) {
/* 292 */     boolean find = (column == null);
/* 293 */     MCColumnConfig border = column;
/* 294 */     Set<MCColumnLayout> setf = new LinkedHashSet<>();
/* 295 */     Set<MCColumnLayout> sets = new LinkedHashSet<>();
/*     */     
/* 297 */     MCLayoutTableColumnModel[] models = {
/* 298 */         getFixedColumnLayoutTable().getColumnModel(), 
/* 299 */         getColumnModel() }; byte b; int i;
/*     */     MCLayoutTableColumnModel[] arrayOfMCLayoutTableColumnModel1;
/* 301 */     for (i = (arrayOfMCLayoutTableColumnModel1 = models).length, b = 0; b < i; ) { MCLayoutTableColumnModel model = arrayOfMCLayoutTableColumnModel1[b];
/* 302 */       Iterator<MCColumnLayoutMember> ite = 
/* 303 */         model.createLayoutMemberIterator();
/* 304 */       while (ite.hasNext()) {
/* 305 */         MCColumnLayoutMember member = ite.next();
/* 306 */         if (member instanceof MCColumnLayout) {
/*     */           
/* 308 */           MCColumnLayout l = (MCColumnLayout)member;
/* 309 */           if (find) {
/*     */             
/* 311 */             sets.add(l);
/*     */             
/*     */             continue;
/*     */           } 
/* 315 */           setf.add(l);
/* 316 */           find = l.contains(column);
/* 317 */           if (find) {
/*     */             
/* 319 */             MCColumnConfig[] ccs = l.getAllColumnConfigs();
/* 320 */             border = ccs[ccs.length - 1];
/*     */           } 
/*     */           continue;
/*     */         } 
/* 324 */         if (member instanceof MCTableColumn)
/*     */         {
/* 326 */           if (member == column)
/*     */           {
/* 328 */             find = true;
/*     */           }
/*     */         }
/*     */       } 
/*     */       
/*     */       b++; }
/*     */     
/* 335 */     models[0].setAllColumnLayout(setf);
/* 336 */     models[1].setAllColumnLayout(sets);
/*     */     
/* 338 */     return border;
/*     */   }
/*     */ 
/*     */   
/*     */   void updateColumnsFontSize(int fontratio, int widthratio, boolean check) {
/* 343 */     MCColumnLayout[] ls = (MCColumnLayout[])MCCollectionUtil.concat((Object[][])new MCColumnLayout[][] {
/* 344 */           getFixedColumnLayoutTable().getColumnModel().getColumnLayouts(), 
/* 345 */           getColumnModel().getColumnLayouts() }); byte b;
/*     */     int i;
/*     */     MCColumnLayout[] arrayOfMCColumnLayout1;
/* 348 */     for (i = (arrayOfMCColumnLayout1 = ls).length, b = 0; b < i; ) { MCColumnLayout l = arrayOfMCColumnLayout1[b];
/* 349 */       l.setRunningPropertyChangeEvent(true);
/* 350 */       l.invalidateWidthCache(true);
/* 351 */       l.invalidateMinWidthCache(true);
/* 352 */       l.invalidatePreferredWidthCache(true);
/*     */       b++; }
/*     */     
/* 355 */     super.updateColumnsFontSize(fontratio, widthratio, check);
/*     */     
/* 357 */     for (i = (arrayOfMCColumnLayout1 = ls).length, b = 0; b < i; ) { MCColumnLayout l = arrayOfMCColumnLayout1[b];
/* 358 */       l.cancelRunningPropertyChangeEvent(true);
/*     */       b++; }
/*     */   
/*     */   }
/*     */   
/*     */   void adjustWidth(boolean all) {
/* 364 */     boolean visible = getBaseTable().isAdjustWidthOnlyVisibleRow();
/* 365 */     int count = getBaseTable().getAdjustWidthRowCount();
/*     */ 
/*     */     
/* 368 */     getFixedColumnLayoutTable().getColumnModel().adjustWidth(
/* 369 */         all, visible, count);
/*     */     
/* 371 */     getColumnModel().adjustWidth(all, visible, count);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int rowAtPoint(Point point) {
/* 389 */     Point p = new Point(point);
/* 390 */     int tier = getTierCount();
/* 391 */     p.y /= tier;
/* 392 */     return super.rowAtPoint(p);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int columnAtPoint(Point point) {
/* 403 */     int pos = 0;
/* 404 */     int x = 0;
/* 405 */     int y = 0;
/*     */     
/* 407 */     int row = rowAtPoint(point);
/* 408 */     if (row < 0) {
/* 409 */       return -1;
/*     */     }
/* 411 */     int tiercnt = getTierCount();
/* 412 */     for (int i = 0; i < row; i++) {
/* 413 */       y += getRowHeight(i) * tiercnt;
/*     */     }
/* 415 */     point.y -= y;
/* 416 */     if (point.y < 0) {
/* 417 */       point.y = 0;
/*     */     }
/*     */     
/* 420 */     int height = getRowHeight(row);
/*     */     
/* 422 */     MCLayoutTableColumnModel cm = getColumnModel();
/* 423 */     Iterator<MCColumnLayoutMember> iterator = 
/* 424 */       cm.createLayoutMemberIterator();
/* 425 */     while (iterator.hasNext()) {
/* 426 */       MCColumnLayoutMember member = iterator.next();
/* 427 */       if (member instanceof MCColumnLayout) {
/* 428 */         MCColumnLayout l = (MCColumnLayout)member;
/* 429 */         int lw = l.getWidth();
/* 430 */         if (x + lw > point.x) {
/*     */           
/* 432 */           Point p = point.getLocation();
/* 433 */           p.x -= x;
/* 434 */           pos += l.columnAtPoint(p, height * tiercnt, height);
/*     */           break;
/*     */         } 
/* 437 */         x += lw;
/* 438 */         pos += l.getAllColumnCount(); continue;
/*     */       } 
/* 440 */       if (member instanceof MCTableColumn) {
/* 441 */         x += ((MCTableColumn)member).getWidth();
/* 442 */         if (x > point.x) {
/*     */           break;
/*     */         }
/*     */ 
/*     */         
/* 447 */         pos++;
/*     */       } 
/*     */     } 
/*     */     
/* 451 */     return (cm.getColumnCount() > pos) ? pos : -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Rectangle getCellRect(int row, int column, boolean includeSpacing) {
/* 462 */     Rectangle r = new Rectangle();
/* 463 */     boolean valid = true;
/* 464 */     int tier = getTierCount();
/*     */     
/* 466 */     if (row < 0) {
/*     */       
/* 468 */       valid = false;
/*     */     }
/* 470 */     else if (row >= getRowCount()) {
/* 471 */       r.y = getHeight();
/* 472 */       valid = false;
/*     */     } else {
/*     */       
/* 475 */       r.height = getRowHeight(row) * tier;
/* 476 */       SizeSequence rowModel = getRowModel();
/* 477 */       r.y = (rowModel == null) ? (row * r.height) : rowModel.getPosition(row);
/* 478 */       r.y *= tier;
/*     */     } 
/*     */     
/* 481 */     if (column < 0) {
/*     */       
/* 483 */       valid = false;
/*     */     }
/* 485 */     else if (column >= getColumnModel().getColumnCount()) {
/* 486 */       r.x = getWidth();
/*     */       
/* 488 */       valid = false;
/*     */     } else {
/*     */       
/* 491 */       int pos = 0;
/* 492 */       MCLayoutTableColumnModel cm = getColumnModel();
/* 493 */       Iterator<MCColumnLayoutMember> iterator = 
/* 494 */         cm.createLayoutMemberIterator();
/* 495 */       while (iterator.hasNext()) {
/* 496 */         MCColumnLayoutMember member = iterator.next();
/* 497 */         if (member instanceof MCColumnLayout) {
/* 498 */           MCColumnLayout l = (MCColumnLayout)member;
/* 499 */           int cnt = l.getAllColumnCount();
/* 500 */           if (pos + cnt > column) {
/*     */             
/* 502 */             MCTableColumn col = cm.getColumn(column);
/* 503 */             r = l.getCellRect(r, col, getRowHeight());
/*     */             break;
/*     */           } 
/* 506 */           r.x += l.getWidth();
/* 507 */           pos += cnt; continue;
/*     */         } 
/* 509 */         if (member instanceof MCTableColumn) {
/* 510 */           int w = ((MCTableColumn)member).getWidth();
/* 511 */           if (pos == column) {
/*     */             
/* 513 */             r.width = w;
/*     */             break;
/*     */           } 
/* 516 */           r.x += w;
/* 517 */           pos++;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 522 */     if (valid && !includeSpacing) {
/* 523 */       int rm = Math.min(getRowMargin(), r.height);
/* 524 */       int cm = Math.min(getColumnModel().getColumnMargin(), r.width);
/* 525 */       r.setBounds(r.x + cm / 2, r.y + rm / 2, r.width - cm, r.height - rm);
/*     */     } 
/* 527 */     return r;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doLayout() {
/* 546 */     TableColumn resizingColumn = getResizingColumn();
/* 547 */     if (resizingColumn == null) {
/* 548 */       setWidthsFromPreferredWidths(false);
/*     */     } else {
/*     */       
/* 551 */       int columnIndex = viewIndexForColumn(resizingColumn);
/* 552 */       int delta = getWidth() - getColumnModel().getTotalColumnWidth();
/* 553 */       accommodateDelta(columnIndex, delta);
/* 554 */       delta = getWidth() - getColumnModel().getTotalColumnWidth();
/* 555 */       if (delta != 0) {
/* 556 */         resizingColumn.setWidth(resizingColumn.getWidth() + delta);
/*     */       }
/* 558 */       setWidthsFromPreferredWidths(true);
/*     */     } 
/*     */ 
/*     */     
/* 562 */     layout();
/*     */   }
/*     */ 
/*     */   
/*     */   private TableColumn getResizingColumn() {
/* 567 */     return (this.tableHeader == null) ? 
/* 568 */       null : this.tableHeader.getResizingColumn();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int viewIndexForColumn(TableColumn aColumn) {
/* 582 */     MCLayoutTableColumnModel mCLayoutTableColumnModel = getColumnModel();
/* 583 */     for (int column = 0; column < mCLayoutTableColumnModel.getColumnCount(); column++) {
/* 584 */       if (mCLayoutTableColumnModel.getColumn(column) == aColumn) {
/* 585 */         return column;
/*     */       }
/*     */     } 
/* 588 */     return -1;
/*     */   }
/*     */   
/*     */   private void accommodateDelta(int resizingColumnIndex, int delta) {
/* 592 */     MCColumnLayoutMember[] ms = 
/* 593 */       getColumnModel().getLayoutMemberArray();
/* 594 */     int columnCount = ms.length;
/* 595 */     int to = columnCount;
/* 596 */     int from = 0;
/* 597 */     MCTableColumn col = getColumnModel().getColumn(resizingColumnIndex);
/* 598 */     for (int i = 0; i < ms.length; i++) {
/* 599 */       MCColumnLayoutMember m = ms[i];
/* 600 */       if (m instanceof MCColumnLayout) {
/* 601 */         if (((MCColumnLayout)m).contains((MCColumnConfig)col)) {
/* 602 */           from = i;
/*     */           
/*     */           break;
/*     */         } 
/* 606 */       } else if (m instanceof MCTable && 
/* 607 */         m == col) {
/* 608 */         from = i;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*     */     
/* 614 */     switch (this.autoResizeMode) {
/*     */       case 1:
/* 616 */         from++;
/* 617 */         to = Math.min(from + 1, columnCount);
/*     */         break;
/*     */       case 2:
/* 620 */         from++;
/* 621 */         to = columnCount;
/*     */         break;
/*     */       case 3:
/* 624 */         from = columnCount - 1;
/* 625 */         to = from + 1;
/*     */         break;
/*     */       case 4:
/* 628 */         from = 0;
/* 629 */         to = columnCount;
/*     */         break;
/*     */ 
/*     */       
/*     */       default:
/*     */         return;
/*     */     } 
/*     */     
/* 637 */     int start = from;
/* 638 */     int end = to;
/* 639 */     Object object = new Object(this, end, start, ms);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 659 */     int totalWidth = 0;
/* 660 */     for (int j = start; j < end; j++) {
/* 661 */       totalWidth += ms[j].getWidth();
/*     */     }
/*     */     
/* 664 */     adjustSizes((totalWidth + delta), (Resizable3)object, false);
/*     */   }
/*     */   
/*     */   private void setWidthsFromPreferredWidths(boolean inverse) {
/* 668 */     int totalWidth = getWidth();
/* 669 */     int totalPreferred = (getPreferredSize()).width;
/* 670 */     int target = !inverse ? totalWidth : totalPreferred;
/*     */     
/* 672 */     MCColumnLayoutMember[] ms = 
/* 673 */       getColumnModel().getLayoutMemberArray();
/* 674 */     Object object = new Object(this, ms, inverse);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 704 */     adjustSizes(target, (Resizable3)object, inverse);
/*     */   }
/*     */   private void adjustSizes(long target, Resizable3 r3, boolean inverse) {
/*     */     Object object;
/* 708 */     int N = r3.getElementCount();
/* 709 */     long totalPreferred = 0L;
/* 710 */     for (int i = 0; i < N; i++) {
/* 711 */       totalPreferred += r3.getMidPointAt(i);
/*     */     }
/*     */ 
/*     */     
/* 715 */     if (((target < totalPreferred) ? true : false) == (inverse ? false : true)) {
/* 716 */       object = new Object(this, r3);
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */       
/* 724 */       object = new Object(this, r3);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 731 */     adjustSizes(target, (Resizable2)object, !inverse);
/*     */   }
/*     */   
/*     */   private void adjustSizes(long target, Resizable2 r, boolean limitToRange) {
/* 735 */     long totalLowerBound = 0L;
/* 736 */     long totalUpperBound = 0L; int i;
/* 737 */     for (i = 0; i < r.getElementCount(); i++) {
/* 738 */       totalLowerBound += r.getLowerBoundAt(i);
/* 739 */       totalUpperBound += r.getUpperBoundAt(i);
/*     */     } 
/*     */     
/* 742 */     if (limitToRange) {
/* 743 */       target = Math.min(Math.max(totalLowerBound, target), totalUpperBound);
/*     */     }
/*     */     
/* 746 */     for (i = 0; i < r.getElementCount(); i++) {
/* 747 */       int newSize, lowerBound = r.getLowerBoundAt(i);
/* 748 */       int upperBound = r.getUpperBoundAt(i);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 753 */       if (totalLowerBound == totalUpperBound) {
/* 754 */         newSize = lowerBound;
/*     */       } else {
/*     */         
/* 757 */         double f = (target - totalLowerBound) / (totalUpperBound - totalLowerBound);
/* 758 */         newSize = (int)Math.round(lowerBound + f * (upperBound - lowerBound));
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 763 */       r.setSizeAt(newSize, i);
/* 764 */       target -= newSize;
/* 765 */       totalLowerBound -= lowerBound;
/* 766 */       totalUpperBound -= upperBound;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\table\MCLayoutTable.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */