/*      */ package META-INF.versions.21.mcframe.clientCore.beans;
/*      */ 
/*      */ import java.awt.AWTEvent;
/*      */ import java.awt.Component;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Font;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.Insets;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.event.ComponentListener;
/*      */ import java.beans.PropertyChangeListener;
/*      */ import java.util.HashMap;
/*      */ import javax.swing.JSplitPane;
/*      */ import mcframe.clientCore.beans.MCBeans;
/*      */ import mcframe.clientCore.beans.MCBeansDelegate;
/*      */ import mcframe.clientCore.beans.MCBeansResourceProxy;
/*      */ import mcframe.clientCore.beans.MCBeansUtil;
/*      */ import mcframe.clientCore.beans.MCCacheType;
/*      */ import mcframe.clientCore.beans.MCPanel;
/*      */ import mcframe.clientCore.beans.MCPropertyCache;
/*      */ import mcframe.clientCore.beans.MCResourceBeans;
/*      */ import mcframe.clientCore.beans.MCRootPanel;
/*      */ import mcframe.clientCore.beans.action.MCKeyActionManager;
/*      */ import mcframe.clientCore.beans.layout.MCAutoLayout;
/*      */ import mcframe.clientCore.beans.resource.MCPanelBoundsResourceIO;
/*      */ import mcframe.clientCore.resource.MCConst;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MCSplitPane
/*      */   extends JSplitPane
/*      */   implements MCResourceBeans
/*      */ {
/*   41 */   private static final MCSplitPanePropertyChangeListener PROPERTY_CHANGE_LISTENER = new MCSplitPanePropertyChangeListener();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   49 */   private MCBeansDelegate _delegate = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   57 */   private MCRootPanel _panel = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   65 */   private MCRootPanel _init_panel = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   73 */   private Rectangle _default_ratio_bounds = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   81 */   private Font _default_font = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   89 */   private int _default_divider_location = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   97 */   private String _message_name = null;
/*      */   protected boolean _isExpandSplitPane = false;
/*      */   private Rectangle _default_bounds;
/*      */   private boolean _init_weight;
/*      */   
/*      */   public boolean isExpandSplitPane() {
/*  103 */     return this._isExpandSplitPane;
/*      */   }
/*      */   
/*      */   public void setExpandSplitPane(boolean isExpandSplitPane) {
/*  107 */     this._isExpandSplitPane = isExpandSplitPane;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void init() {
/*  132 */     initBeans();
/*  133 */     initKeyAssign();
/*  134 */     initResource();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initBeans() {
/*  144 */     setOneTouchExpandable(true);
/*  145 */     setResizeWeight(0.5D);
/*      */     
/*  147 */     setInheritsPopupMenu(true);
/*      */     
/*  149 */     addPropertyChangeListener((PropertyChangeListener)PROPERTY_CHANGE_LISTENER);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initResource() {
/*  160 */     String k = MCConst.createKey(new String[] { getType(), "divider.size" });
/*  161 */     int s = MCConst.beans.getInteger(k, getDividerSize());
/*  162 */     setDividerSize(s);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initKeyAssign() {
/*  172 */     MCKeyActionManager.init(this, getInputMap(1), 
/*  173 */         getActionMap());
/*  174 */     MCKeyActionManager.init(this, getInputMap(2), 
/*  175 */         getActionMap());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setName(String name) {
/*  191 */     setName(name, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void setName(String name, boolean init) {
/*  207 */     MCBeansUtil.checkName(name);
/*  208 */     super.setName(name);
/*  209 */     if (init) {
/*  210 */       updateResource();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final MCBeansDelegate getDelegate() {
/*  222 */     if (this._delegate == null) {
/*  223 */       this._delegate = new MCBeansDelegate();
/*      */     }
/*  225 */     return this._delegate;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateResource() {}
/*      */ 
/*      */   
/*      */   public void updateResource(MCRootPanel panel) {
/*  234 */     if (panel == null) {
/*      */       return;
/*      */     }
/*  237 */     if (!panel.isPartsFlag()) {
/*  238 */       MCKeyActionManager.initScreen(this, 
/*  239 */           getInputMap(1), getActionMap());
/*  240 */       MCKeyActionManager.initScreen(this, getInputMap(2), 
/*  241 */           getActionMap());
/*      */     } 
/*  243 */     MCPropertyCache p = panel.getPropertyCache(MCCacheType.SCREEN);
/*      */ 
/*      */ 
/*      */     
/*  247 */     String k = MCConst.createKey(new String[] { getType(), "divider.size" });
/*  248 */     int s = MCBeansUtil.getBeansInteger(panel, p, k, getDividerSize());
/*  249 */     setDividerSize(s);
/*      */ 
/*      */ 
/*      */     
/*  253 */     MCBeansUtil.setBounds(this);
/*      */   }
/*      */   @Deprecated public void _cacheDefaultBounds(Rectangle bounds) { this._default_bounds = bounds; }
/*      */   @Deprecated public void _setDefaultBounds() { if (this._default_bounds != null) setBounds(this._default_bounds);  }
/*      */   public Rectangle _getDefaultBounds() { return this._default_bounds; }
/*      */   public void _setDefaultBounds(Rectangle r) { this._default_bounds = r; }
/*      */   public final void addAliasName(String alias, MCRootPanel panel) { getDelegate().addAliasName(alias, panel); }
/*      */   public void added() { this._panel = MCBeansUtil.getNearestRootPanel(this); MCBeansUtil.added(this); }
/*      */   public boolean equalsIgnoreCase(Component compo) { return equals(compo); }
/*  262 */   public final String getAliasName(MCRootPanel panel) { return getDelegate().getAliasName(panel); } public final String[] getAliasNames() { return getDelegate().getAliasNames(); } public String getLabelByLocale() { return MCBeansUtil.getLabel((MCBeans)this); } public String getMessageByLocale() { if (this._message_name != null) return this._message_name;  return MCBeansUtil.getMessageName(this); } public MCRootPanel getRootPanel() { if (this._init_panel != null) return this._init_panel;  return getNearestRootPanel(); } public MCRootPanel getBaseRootPanel() { MCRootPanel p = getNearestRootPanel(); return (p != null) ? p.getBaseRootPanel() : null; } public MCRootPanel getNearestRootPanel() { if (this._panel == null) this._panel = MCBeansUtil.getNearestRootPanel(this);  return this._panel; } public String getType() { return "splitpane"; } public void initialized() { if (this._default_ratio_bounds == null) this._default_ratio_bounds = getBounds();  if (this._default_font == null) this._default_font = getFont();  if (this._defaultDividerSize == null) this._defaultDividerSize = Integer.valueOf(getDividerSize());  _setDefault_divider_location(); this._init_panel = MCBeansUtil.getRootPanel(this); int pos = getDividerLocationFromUser(); if (pos != -1) { setDividerLocationWithRatio(pos); getBaseRootPanel().setDividerMap(this, Integer.valueOf(pos)); } else { MCAutoLayout autoLayout = new MCAutoLayout(); MCRootPanel rp = getBaseRootPanel(); autoLayout.setupTargetPanel(rp); autoLayout.setupPanelList(); Integer pos2 = autoLayout.getLocalizedDividerLocation(rp, this); if (pos2 != null) { setDividerLocation(pos2.intValue()); getBaseRootPanel().setDividerMap(this, pos2); getBaseRootPanel().setNeedResetDividerLocation(false); }  }  MCBeansUtil.initialized(this); } void _setDefault_divider_location() { MCRootPanel r = getBaseRootPanel(); if (r != null) { int ratio = r.getLayoutRatio(); if (ratio == 100 && ratio > 0) { this._default_divider_location = getDividerLocation(); } else { this._default_divider_location = getDividerLocation() * 100 / ratio; }  } else { this._default_divider_location = getDividerLocation(); }  this._default_divider_location = getDividerLocation(); } public int getDividerLocationFromUser() { Integer result = getBaseRootPanel().getPanelBoundsResourceIO().getSplitPaneDividerLocation(getName()); return (result != null) ? result.intValue() : -1; } public void localeChanged() { updateResource(); MCBeansUtil.localeChanged(this); } public final void removeAliasName(MCRootPanel panel) { getDelegate().removeAliasName(panel); } public final void removeAliasNames() { getDelegate().removeAliasNames(); } public void removed() { this._panel = MCBeansUtil.getNearestRootPanel(this); MCBeansUtil.removed(this); } public final void setAliasName(String alias, MCRootPanel panel) { getDelegate().setAliasName(alias, panel); } public void updateBounds(int ratio) { if (!isValid() && isShowing()) return;  MCRootPanel bp = getBaseRootPanel(); if (!bp.isInitialized()) { MCBeansUtil.updateBounds(this, ratio, this._default_ratio_bounds); MCPanelBoundsResourceIO pio = bp.getPanelBoundsResourceIO(); String pfx = MCConst.createKey(new String[] { bp.getModuleID(), bp.getScreenID() }); if (!MCBeansResourceProxy.PROXY.isLastReaded(pio, pfx)) pio.read(pfx);  Integer i = pio.getSplitPaneDividerLocation(getName()); if (i == null || i.intValue() < 0) { if (this._default_divider_location != Integer.MAX_VALUE) { setDividerLocation(this._default_divider_location, ratio); updateUI(); }  } else { i = Integer.valueOf(MCBeansUtil.adjust(i.intValue(), 100, ratio)); setDividerLocation(i.intValue(), 100); updateUI(); }  } else { int xl, ol = getDividerLocationWithRatio(); int ml = (getLocation()).y + (getInsets()).top; if (getOrientation() == 0) { xl = (getLocation()).y + getHeight() - (getInsets()).bottom - getDividerSize(); } else { xl = (getLocation()).x + getWidth() - (getInsets()).right - getDividerSize(); }  MCBeansUtil.updateBounds(this, ratio, this._default_ratio_bounds); if (ol > ml) if (ol >= xl) addComponentListener((ComponentListener)new Object(this, ratio));   }  } public void updateFontSize(int ratio) { MCBeansUtil.updateFontSize(this, ratio, this._default_font); } protected void processEvent(AWTEvent e) { try { super.processEvent(e); } catch (Throwable t) { handle(t); }  } @Deprecated public void handle(Throwable t) { MCBeansUtil.handle(this, t); } public void mcRequestFocus() { MCBeansUtil.focus(this); } @Deprecated public void grabFocus() { super.grabFocus(); } @Deprecated public void requestFocus() { doFocus(false); } @Deprecated public boolean requestFocus(boolean temporary) { return doFocus(temporary); } protected boolean doFocus(boolean temporary) { if (super.requestFocus(temporary)) return true;  return false; } @Deprecated public boolean requestFocusInWindow() { return super.requestFocusInWindow(); } @Deprecated protected boolean requestFocusInWindow(boolean temporary) { return super.requestFocusInWindow(temporary); } @Deprecated public MCSplitPane(String name) { this._default_bounds = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  782 */     this._init_weight = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  943 */     this._useRatio = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1134 */     this._saveFontRatio = -1;
/* 1135 */     this._saveHeight = -1;
/* 1136 */     this._saveHeight2 = -1;
/*      */ 
/*      */     
/* 1139 */     this.useProportionalLocation = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1329 */     this._canUpdateDividerLocation = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1371 */     this.both_end = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1418 */     this._defaultDividerSize = null; setName(name); init(); }
/*      */   public void setDefault() { if (getResizeWeight() < 1.0D) { setDividerLocationWithRatio(this._default_divider_location); updateUI(); }  }
/* 1420 */   public Dimension getDefaultSize() { Rectangle a = this._default_ratio_bounds; int w = (a != null) ? a.width : getWidth(); int h = (a != null) ? a.height : getHeight(); return new Dimension(w, h); } public Rectangle getDefaultBounds() { Rectangle a = this._default_ratio_bounds; return (a != null) ? a : getBounds(); } public void setDefaultRatioSize(Rectangle r) { this._default_ratio_bounds = r; } @Deprecated public void afterRequestFocus() { MCBeansUtil.afterRequestFocus(getBaseRootPanel(), this); } public void setMessageName(String name) { this._message_name = MCBeansUtil.adjustMessageName(name); } public void paint(Graphics g) { try { this._useRatio = false; super.paint(g); } finally { this._useRatio = true; }  } @Deprecated public String _getMessageName() { return this._message_name; } public void doLayout() { try { this._useRatio = false; super.doLayout(); } finally { this._useRatio = true; }  } private static HashMap<String, Integer> _locationMap = new HashMap<>(); private static HashMap<String, Integer> _locationSizeMap = new HashMap<>(); Integer getDefaultDividerSize() { if (this._defaultDividerSize == null) {
/* 1421 */       this._defaultDividerSize = Integer.valueOf(getDividerSize());
/*      */     }
/* 1423 */     return this._defaultDividerSize; } private boolean _useRatio; private int _saveFontRatio; private int _saveHeight; private int _saveHeight2; protected boolean useProportionalLocation; private boolean _canUpdateDividerLocation; private Boolean both_end; Integer _defaultDividerSize; @Deprecated public static Integer getDividerLocationMap(mcframe.clientCore.beans.MCSplitPane sp, String key) { if (_locationMap == null) _locationMap = new HashMap<>();  if (_locationSizeMap == null) _locationSizeMap = new HashMap<>();  if (!_locationSizeMap.containsKey(key)) return null;  int s1 = sp.getMaximumDividerLocation(); int s2 = ((Integer)_locationSizeMap.get(key)).intValue(); if (s1 != s2) return null;  if (_locationMap.containsKey(key)) return _locationMap.get(key);  return null; } @Deprecated public static void setDividerLocationMap(mcframe.clientCore.beans.MCSplitPane sp, String key, int n) { if (_locationMap == null) _locationMap = new HashMap<>();  if (_locationSizeMap == null) _locationSizeMap = new HashMap<>();  int s = sp.getMaximumDividerLocation(); _locationMap.put(key, Integer.valueOf(n)); _locationSizeMap.put(key, Integer.valueOf(s)); } @Deprecated public static void removeDividerLocationMap(String key) { if (_locationMap != null && _locationMap.containsKey(key)) _locationMap.remove(key);  if (_locationSizeMap != null && _locationSizeMap.containsKey(key)) _locationSizeMap.remove(key);  } public int getDividerLocationWithoutRatio() { if (getBaseRootPanel() == null) return getDividerLocation();  int ratio = getBaseRootPanel().getLayoutRatio(); if (ratio == 100) return getDividerLocation();  return (int)Math.ceil(getDividerLocation() * 100.0D / ratio); } int getDividerLocation(int ratio) { return (int)Math.ceil(getDividerLocation() * 100.0D / ratio); } public int getDividerLocationWithRatio() { return getDividerLocation(); } public void setDividerLocation(int location, int ratio) { if (ratio == 100) { setDividerLocation(location); } else { int loc = (int)Math.ceil((location * ratio) / 100.0D); setDividerLocationWithoutRatio(loc, Integer.valueOf(ratio)); }  } public void setDividerLocationWithRatio(int location) { if (getBaseRootPanel() == null) { setDividerLocation(location); } else { int ratio = getBaseRootPanel().getLayoutRatio(); setDividerLocation(location, ratio); }  } public void setUseRatio(boolean useRatio) { this._useRatio = useRatio; }
/*      */   public boolean isUseRatio() { return this._useRatio; }
/*      */   public void setDividerLocation(int location) { if (!this._useRatio) { setDividerLocationWithoutRatio(location); } else if (getBaseRootPanel() != null) { int ratio = getBaseRootPanel().getLayoutRatio(); int loc = (int)Math.min(Math.ceil(location * ratio / 100.0D), 2.147483647E9D); setDividerLocationWithoutRatio(loc); } else { setDividerLocationWithoutRatio(location); }  }
/*      */   public void setDividerLocationWithoutRatio(int location, Integer ratioForMax) { if (!this._canUpdateDividerLocation) return;  if (this._panel != null && this._panel.isDisableLayoutInit()) return;  if (this._panel != null && this._panel.isRelayout() && this._panel.getDividerLocationForRelayout().containsKey(getName())) { Integer integer = (Integer)this._panel.getDividerLocationForRelayout().get(getName()); super.setDividerLocation(integer.intValue()); return; }  if (getPreferredSize().getHeight() > 0.0D) this._init_weight = true;  if (location == -1) return;  if (getOrientation() == 1) { super.setDividerLocation(location); return; }  if (location == Integer.MAX_VALUE) { super.setDividerLocation(location); return; }  int n = location; int min = getMinimumDividerLocation(); if (ratioForMax != null) { int max = getMaximumDividerLocation(ratioForMax); if (n > max) n = max;  } else { int max = getMaximumDividerLocation(); if (n > max) n = max;  }  if (n < min) n = min;  super.setDividerLocation(n); }
/*      */   public void setDividerLocationWithoutRatio(int location) { setDividerLocationWithoutRatio(location, null); }
/*      */   public int getMaximumDividerLocation() { return getMaximumDividerLocation(null); }
/* 1429 */   void updateDividerSize(int before, int after) { int _dividerSize = Math.max(getDefaultDividerSize().intValue() * after / 100, 3);
/* 1430 */     setDividerSize(_dividerSize); }
/*      */ 
/*      */   
/*      */   public int getMaximumDividerLocation(Integer ratio) {
/*      */     if (this.useProportionalLocation) {
/*      */       int n = super.getMaximumDividerLocation();
/*      */       return n;
/*      */     } 
/*      */     if (!isExpandSplitPane() && this._init_weight)
/*      */       return Integer.MAX_VALUE; 
/*      */     Component rightC = getRightComponent();
/*      */     if (rightC instanceof MCPanel) {
/*      */       if (getOrientation() == 1)
/*      */         return super.getMaximumDividerLocation(); 
/*      */       Insets insets = getInsets();
/*      */       boolean b = isExpandSplitPane();
/*      */       int n = getToptPanelHeight(b, ratio);
/*      */       if (insets != null)
/*      */         if (getOrientation() == 1) {
/*      */           n -= insets.right;
/*      */         } else {
/*      */           n -= insets.top;
/*      */         }  
/*      */       return n;
/*      */     } 
/*      */     return super.getMaximumDividerLocation();
/*      */   }
/*      */   
/*      */   public int getMinimumDividerLocation() {
/*      */     int n = super.getMinimumDividerLocation();
/*      */     return n;
/*      */   }
/*      */   
/*      */   public void setResizeWeight(double value) {
/*      */     double d = value;
/*      */     if (value < 0.0D) {
/*      */       d = 0.0D;
/*      */     } else if (value > 1.0D) {
/*      */       d = 1.0D;
/*      */     } 
/*      */     super.setResizeWeight(d);
/*      */   }
/*      */   
/*      */   public int getToptPanelHeight(boolean isExpandUnit) {
/*      */     return getToptPanelHeight(isExpandUnit, null);
/*      */   }
/*      */   
/*      */   protected int getToptPanelHeight(boolean isExpandUnit, Integer ratio) {
/*      */     if (getOrientation() == 0) {
/*      */       Component c1 = getTopComponent();
/*      */       if (!c1.isShowing()) {
/*      */         int h2 = (int)c1.getPreferredSize().getHeight();
/*      */         if (ratio != null)
/*      */           h2 = h2 * ratio.intValue() / 100; 
/*      */         return h2;
/*      */       } 
/*      */       if (!(c1 instanceof MCPanel))
/*      */         return super.getMaximumDividerLocation(); 
/*      */       int fontRatio = this._panel.getBaseRootPanel().getLayoutRatio();
/*      */       if (ratio != null) {
/*      */         int i = ((MCPanel)c1).getMaxHeightForSplitPane(isExpandUnit);
/*      */         int _ratio1 = getBaseRootPanel().getLayoutRatio();
/*      */         int _ratio2 = ratio.intValue();
/*      */         if (_ratio1 == _ratio2)
/*      */           return i; 
/*      */         i = i * _ratio2 / _ratio1;
/*      */         return i;
/*      */       } 
/*      */       if (fontRatio != this._saveFontRatio)
/*      */         this._saveHeight = -1; 
/*      */       int h = -1;
/*      */       if (this._saveHeight == -1) {
/*      */         h = ((MCPanel)c1).getMaxHeightForSplitPane(isExpandUnit);
/*      */         this._saveHeight = h;
/*      */         this._saveFontRatio = this._panel.getLayoutRatio();
/*      */       } else {
/*      */         h = this._saveHeight;
/*      */       } 
/*      */       if (h == -1)
/*      */         return super.getMaximumDividerLocation(); 
/*      */       int _ratio = 100;
/*      */       if (getBaseRootPanel() != null)
/*      */         _ratio = getBaseRootPanel().getLayoutRatio(); 
/*      */       if (_ratio == 100)
/*      */         return h; 
/*      */       return h;
/*      */     } 
/*      */     return super.getMaximumDividerLocation();
/*      */   }
/*      */   
/*      */   public void resetSaveHeight() {
/*      */     this._saveHeight = -1;
/*      */   }
/*      */   
/*      */   public void setMaxSaveHeight() {
/*      */     this._saveHeight2 = getToptPanelHeight(false);
/*      */     this._saveHeight = Integer.MAX_VALUE;
/*      */   }
/*      */   
/*      */   public void setMaxSaveHeight2() {
/*      */     this._saveHeight = this._saveHeight2;
/*      */   }
/*      */   
/*      */   public int getSaveHeight2() {
/*      */     return this._saveHeight2;
/*      */   }
/*      */   
/*      */   public void setDividerLocation(double proportionalLocation) {
/*      */     this.useProportionalLocation = true;
/*      */     int n = 0;
/*      */     if (getOrientation() == 0) {
/*      */       n = (int)((getHeight() - getDividerSize()) * proportionalLocation);
/*      */     } else {
/*      */       n = (int)((getWidth() - getDividerSize()) * proportionalLocation);
/*      */     } 
/*      */     setDividerLocationWithoutRatio(n);
/*      */   }
/*      */   
/*      */   public void useProportionalLocation(boolean b) {
/*      */     this.useProportionalLocation = b;
/*      */   }
/*      */   
/*      */   public boolean useProportionalLocation() {
/*      */     return this.useProportionalLocation;
/*      */   }
/*      */   
/*      */   public boolean canUpdateDividerLocation() {
/*      */     return this._canUpdateDividerLocation;
/*      */   }
/*      */   
/*      */   public void setCanUpdateDividerLocation(boolean _canUpdateDividerLocation) {
/*      */     this._canUpdateDividerLocation = _canUpdateDividerLocation;
/*      */   }
/*      */   
/*      */   public void setPreferredSize(Dimension preferredSize) {
/*      */     super.setPreferredSize(preferredSize);
/*      */   }
/*      */   
/*      */   public void setSize(Dimension size) {
/*      */     super.setSize(size);
/*      */   }
/*      */   
/*      */   public void setSize(int width, int height) {
/*      */     super.setSize(width, height);
/*      */   }
/*      */   
/*      */   public void setBounds(int x, int y, int width, int height) {
/*      */     super.setBounds(x, y, width, height);
/*      */   }
/*      */   
/*      */   public Boolean getBothEnd() {
/*      */     return this.both_end;
/*      */   }
/*      */   
/*      */   public void setBothEnd(Boolean both_end) {
/*      */     this.both_end = both_end;
/*      */   }
/*      */   
/*      */   public void validate() {
/*      */     this._useRatio = false;
/*      */     super.validate();
/*      */     this._useRatio = true;
/*      */   }
/*      */   
/*      */   public void validateTree() {
/*      */     super.validateTree();
/*      */   }
/*      */   
/*      */   @Deprecated
/*      */   public void layout() {
/*      */     try {
/*      */       this._useRatio = false;
/*      */       super.layout();
/*      */     } finally {
/*      */       this._useRatio = true;
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\MCSplitPane.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */