/*     */ package META-INF.versions.21.mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.util.List;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.border.Border;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCMode;
/*     */ import mcframe.clientCore.beans.MCResourceBeans;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.action.MCKeyActionManager;
/*     */ import mcframe.clientCore.beans.combobox.MCComboField;
/*     */ import mcframe.clientCore.beans.combobox.MCComboListModel;
/*     */ import mcframe.clientCore.beans.combobox.MCFieldComboBox;
/*     */ import mcframe.clientCore.beans.combobox.MCTextComboBox;
/*     */ import mcframe.clientCore.beans.list.MCLinkBeans;
/*     */ import mcframe.clientCore.beans.list.MCLinkedBeans;
/*     */ import mcframe.clientCore.beans.list.MCListConfig;
/*     */ import mcframe.clientCore.beans.list.MCListType;
/*     */ import mcframe.clientCore.beans.popup.MCPopupConfig;
/*     */ import mcframe.clientCore.beans.popup.MCPopupMenu;
/*     */ import mcframe.clientCore.beans.table.MCBeansProxy;
/*     */ import mcframe.clientCore.beans.table.MCCellUtil;
/*     */ import mcframe.clientCore.beans.table.MCColumnConfig;
/*     */ import mcframe.clientCore.beans.table.MCEditorBeans;
/*     */ import mcframe.clientCore.beans.table.MCEventProxy;
/*     */ import mcframe.clientCore.beans.table.MCTable;
/*     */ import mcframe.clientCore.beans.table.MCTableColumn;
/*     */ import mcframe.clientCore.beans.text.MCInputMethodType;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.clientCore.event.MCEventInfo;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCEditorTextComboBox
/*     */   extends MCTextComboBox
/*     */   implements MCEditorBeans
/*     */ {
/*  47 */   private MCTable<?> _table = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   private MCColumnConfig _column = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected MCEditorTextComboBox(String name, MCColumnConfig column) {
/*  68 */     super(name);
/*     */     
/*  70 */     setColumnConfig(column);
/*  71 */     setTable(column.getBaseTable());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getType() {
/*  76 */     return "table.column.combo";
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initBeans() {
/*  81 */     super.initBeans();
/*     */     
/*  83 */     setFocusTraversalKeysEnabled(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initKeyAssign() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initResource() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setTable(MCTable<?> table) {
/* 102 */     this._table = table;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCTable<?> getTable() {
/* 107 */     return this._table;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setColumnConfig(MCColumnConfig column) {
/* 118 */     this._column = column;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCColumnConfig getColumnConfig() {
/* 123 */     return this._column;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getRowIndex() {
/* 128 */     return MCCellUtil.getRowIndex(this);
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCEditorComboField getComboField() {
/* 133 */     return (MCEditorComboField)super.getComboField();
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCEditorComboField createComboField() {
/* 138 */     return new MCEditorComboField(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void valueCommited() {
/* 143 */     MCTable<?> t = getTable();
/* 144 */     String o = getListConfig().getOpeType();
/*     */     
/* 146 */     String v = getValue();
/* 147 */     if ("input".equals(o)) {
/* 148 */       setSelectedItem(v);
/*     */     }
/* 150 */     else if ("list".equals(o) && 
/* 151 */       MCStringUtil.isNull(v)) {
/* 152 */       setSelectedItem(v);
/*     */     } 
/*     */ 
/*     */     
/* 156 */     MCRow row = getSelectedListRow();
/*     */     
/* 158 */     if ("input".equals(o)) {
/* 159 */       row = getListRow(getValue());
/*     */     }
/* 161 */     if (row == null && 
/* 162 */       getListType() == MCListType.FREE) {
/* 163 */       row = MCRow.create();
/* 164 */       MCBeansProxy.PROXY.addColumn(row, getListNames()[0], getDataType(), 
/* 165 */           getViewValue());
/*     */     } 
/*     */     
/* 168 */     MCEventInfo e = getEventInfo();
/* 169 */     String key = getKeyColumnName();
/* 170 */     if (MCBeansProxy.PROXY.haveLinkValuesNull(e, (MCLinkBeans)this, getValue(), getList(), key)) {
/* 171 */       MCRow r = row.clone();
/* 172 */       r.clear();
/* 173 */       r.setValue(key, e.getNewValue());
/* 174 */       ((MCTableColumn)getColumnConfig()).execLink(t.getMCEditingRow(), r, true);
/*     */     } else {
/*     */       
/* 177 */       ((MCTableColumn)getColumnConfig()).execLink(t.getMCEditingRow(), row, true);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Border getDefaultBorder() {
/* 183 */     return MCCellUtil.DEFAULT_BORDER;
/*     */   }
/*     */ 
/*     */   
/*     */   public void transferFocus() {
/* 188 */     MCTable<?> t = getTable();
/* 189 */     t.transferFocus(getRowIndex(), t.getViewColumn(getColumnConfig()) + 1, false, 
/* 190 */         true, true);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void execLink(MCRow row, boolean msg) {
/* 195 */     ((MCTableColumn)getColumnConfig()).execLink(getRowIndex(), row, msg);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean canChange() {
/*     */     try {
/* 201 */       MCTable.setEditingStoppedEnabled(false);
/*     */ 
/*     */       
/* 204 */       MCEventInfo info = getTable().getEventInfo();
/* 205 */       MCEventProxy.PROXY.setIndex(info, getTable().getMCSelectedRow(), 
/* 206 */           info.getNewIndex());
/*     */       
/* 208 */       return super.canChange();
/*     */     } finally {
/*     */       
/* 211 */       MCTable.setEditingStoppedEnabled(true);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void setColumnInfo(int index, MCColumnConfig column) {
/* 216 */     setColumnConfig(column);
/* 217 */     MCTable<?> table = getTable();
/*     */     
/* 219 */     MCKeyActionManager.init((MCResourceBeans)this, getInputMap(1), 
/* 220 */         getActionMap());
/* 221 */     JComponent c = getComboField().getComponent();
/* 222 */     MCKeyActionManager.init((MCResourceBeans)this, c.getInputMap(), c.getActionMap());
/*     */     
/* 224 */     MCKeyActionManager.initScreen((MCResourceBeans)this, 
/* 225 */         getInputMap(1), getActionMap());
/* 226 */     MCKeyActionManager.initScreen((MCResourceBeans)this, c.getInputMap(), c.getActionMap());
/*     */     
/* 228 */     MCMode mode = MCCellUtil.isCellEditable(index, column, table);
/* 229 */     setMode(mode);
/* 230 */     setForeground(MCCellUtil.getForeground(index, column, table, false, mode));
/* 231 */     setBackground(MCCellUtil.getBackground(index, column, table, false, mode));
/* 232 */     setFont(column.getFont());
/* 233 */     setCaretColor(MCCellUtil.getCaretColor(index, column, table));
/* 234 */     setSelectionColor(MCCellUtil.getSelectionColor(index, column, table));
/* 235 */     setSelectedTextColor(MCCellUtil.getSelectedTextColor(index, column, table));
/* 236 */     setMeta(column.getMeta());
/* 237 */     setLength(column.getLength(index));
/* 238 */     setListVisibleColumn(column.getListVisibleColumn());
/* 239 */     setRow(column.getTable().getRow(index), column.getRowColumnName());
/* 240 */     setAutoFocus(column.isAutoFocus());
/* 241 */     setSelectAll(column.isSelectAll());
/* 242 */     MCListConfig lc = column.getListConfig();
/* 243 */     setListConfig(lc);
/* 244 */     if (lc.getListType() == MCListType.SELECT_ONLY) {
/* 245 */       setDocumentEditable(false);
/*     */     }
/*     */     
/* 248 */     setComboListConfig(column.getComboListConfig());
/*     */     
/* 250 */     setTrimPattern(column.getTrimPattern());
/* 251 */     Border border = MCCellUtil.getEditorBorder(index, column, table);
/* 252 */     if (border != null) {
/* 253 */       setBorder(border);
/*     */     } else {
/*     */       
/* 256 */       setBorder(getDefaultBorder());
/*     */     } 
/* 258 */     MCPopupMenu menu = getComponentPopupMenu();
/* 259 */     if (menu != null) {
/* 260 */       menu.updateResource();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setDummyColumnInfo(MCColumnConfig column, MCConstRow dummy) {
/* 271 */     setColumnConfig(column);
/*     */     
/* 273 */     setMeta(column.getMeta());
/* 274 */     setLength(column.getLength());
/*     */     
/* 276 */     if (dummy.contains(column.getBaseRowColumnName())) {
/* 277 */       setRow(dummy, column.getBaseRowColumnName());
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 284 */       setRow((MCConstRow)column.getTable().getList().createRow(), 
/* 285 */           column.getRowColumnName());
/*     */     } 
/* 287 */     setAutoFocus(false);
/* 288 */     setSelectAll(false);
/* 289 */     setTrimPattern(column.getTrimPattern());
/*     */   }
/*     */   
/*     */   public Border getBorder() {
/* 293 */     Border b = MCCellUtil.getBorder(this);
/* 294 */     return (b != null) ? b : super.getBorder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCRootPanel getRootPanel() {
/* 307 */     return MCCellUtil.getRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCRootPanel getNearestRootPanel() {
/* 312 */     return MCCellUtil.getNearestRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessageByLocale() {
/* 317 */     return getColumnConfig().getMessageByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLabelByLocale() {
/* 322 */     return getColumnConfig().getLabelByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterRequestFocus() {
/* 327 */     MCRootPanel bp = getBaseRootPanel();
/* 328 */     MCBeansUtil.afterRequestFocus(bp, (JComponent)getTable());
/* 329 */     MCBeansUtil.scrollRectToVisible(bp, (JComponent)this, 
/* 330 */         getComboField().getHorizontalAlignment());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 335 */     repaint();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFocusOwner() {
/* 340 */     MCTable<?> t = getTable();
/* 341 */     return (t != null) ? (t.isRemoveNotifyProcessing() ? super.isFocusOwner() : false) : 
/* 342 */       super.isFocusOwner();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValueChanged() {
/* 347 */     return isValueChanged(getRowValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValueChanged(Comparable<?> value) {
/* 352 */     return isValueChanged(getValue(), value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isValueChanged(Comparable<?> view, Comparable<?> row) {
/* 358 */     if (isInputMethodEditing()) {
/* 359 */       return true;
/*     */     }
/*     */     
/* 362 */     return MCCellUtil.isValueChanged(this, view, row);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasFocus() {
/* 367 */     MCTable<?> t = getTable();
/* 368 */     return (t != null) ? ((this == t.getMCEditorComponent())) : super.hasFocus();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isMCFocusOwner() {
/* 373 */     MCTable<?> t = getTable();
/* 374 */     return (t != null) ? ((t.getMCEditorComponent() == this)) : isFocusOwner();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCListType getListType() {
/* 379 */     MCColumnConfig c = getColumnConfig();
/* 380 */     return (c != null) ? c.getListType() : super.getListType();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCLinkedBeans[] getLinkBeans() {
/* 385 */     MCColumnConfig c = getColumnConfig();
/* 386 */     return (c != null) ? c.getLinkBeans() : super.getLinkBeans();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRowToViews() {
/* 391 */     boolean e = MCBeansProxy.PROXY.isEventEnabled();
/*     */     try {
/* 393 */       MCBeansProxy.PROXY.setEventEnabled(false);
/* 394 */       setRowToView();
/* 395 */       MCLinkedBeans[] cs = getLinkBeans(); byte b; int i; MCLinkedBeans[] arrayOfMCLinkedBeans1;
/* 396 */       for (i = (arrayOfMCLinkedBeans1 = cs).length, b = 0; b < i; ) { MCLinkedBeans c = arrayOfMCLinkedBeans1[b];
/* 397 */         if (c instanceof MCColumnConfig) {
/* 398 */           MCColumnConfig col = (MCColumnConfig)c;
/* 399 */           int j = getRowIndex();
/* 400 */           col.setValue(j, 
/* 401 */               getTable().getRow(j).getValue(col.getBaseRowColumnName()));
/*     */         } 
/*     */         b++; }
/*     */     
/*     */     } finally {
/* 406 */       MCBeansProxy.PROXY.setEventEnabled(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCList doListEventEx() {
/* 415 */     MCTableColumn c = (MCTableColumn)getColumnConfig();
/* 416 */     MCEventProxy.PROXY.setEventIndex(c.getEventInfo(), getRowIndex());
/* 417 */     return c.doListEventEx();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCList doListEvent() {
/*     */     try {
/* 423 */       MCColumnConfig c = getColumnConfig();
/* 424 */       MCEventProxy.PROXY.setEventIndex(c.getEventInfo(), getRowIndex());
/* 425 */       return c.doListEvent();
/*     */     }
/* 427 */     catch (MCException e) {
/* 428 */       handle((Throwable)e);
/*     */       
/* 430 */       setRowToViews();
/*     */       
/* 432 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean doListEventWithNull() {
/* 437 */     MCColumnConfig c = getColumnConfig();
/* 438 */     return (c != null) ? c.doListEventWithNull() : false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean haveLinkValuesNullWhenDupliKeyTyped() {
/* 443 */     MCColumnConfig c = getColumnConfig();
/* 444 */     return (c != null) ? c.haveLinkValuesNullWhenDupliKeyTyped() : false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean doVC() {
/* 449 */     return getColumnConfig().doVC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNC() {
/* 454 */     getColumnConfig().doNC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNE() {
/* 459 */     getColumnConfig().doNE();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNX() {
/* 464 */     getColumnConfig().doNX();
/*     */     
/* 466 */     getListConfig().setOpeType("input");
/*     */   }
/*     */ 
/*     */   
/*     */   public void doLC() {
/* 471 */     getColumnConfig().doLC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doDC() {
/* 476 */     getColumnConfig().doDC();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void focusGained() {
/* 482 */     focusGainedSelect();
/*     */     
/* 484 */     _installInputMethod();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void focusLost() {
/* 490 */     _uninstallInputMethod();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCEventInfo getEventInfo() {
/* 495 */     return getColumnConfig().getEventInfo();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource(MCRootPanel panel) {}
/*     */ 
/*     */   
/*     */   public void doCheckValueError() {
/* 508 */     super.doCheckValueError();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCPopupConfig getPopupConfig() {
/* 513 */     MCTable<?> t = getTable();
/* 514 */     return (t != null) ? t.getPopupConfig() : null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCPopupMenu configurePopup(MCPopupMenu menu) {
/* 519 */     MCPopupConfig pc = getPopupConfig();
/* 520 */     return (pc != null) ? 
/* 521 */       pc.configurePopup(menu, getTable(), getRowIndex(), getColumnConfig()) : 
/* 522 */       menu;
/*     */   }
/*     */ 
/*     */   
/*     */   public void processKeyEvent(KeyEvent e) {
/* 527 */     MCCellUtil.beforeKeyEvent(e, this);
/* 528 */     super.processKeyEvent(e);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Pattern> getAcceptPattern() {
/* 533 */     return getColumnConfig().getAcceptPattern();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Character> getExceptCharacter() {
/* 538 */     return getColumnConfig().getExceptCharacter();
/*     */   }
/*     */ 
/*     */   
/*     */   public Comparable<?> doListFormat(Comparable<?> value) {
/* 543 */     return getColumnConfig().doListFormat(getRowIndex(), value);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Color getListForeground(MCRow row, boolean selected) {
/* 548 */     MCColumnConfig c = getColumnConfig();
/* 549 */     return getComboListConfig().getRowForeground(c, getRowIndex(), c.getTable(), row, 
/* 550 */         selected);
/*     */   }
/*     */ 
/*     */   
/*     */   protected Color getListBackground(MCRow row, boolean selected) {
/* 555 */     MCColumnConfig c = getColumnConfig();
/* 556 */     return getComboListConfig().getRowBackground(c, getRowIndex(), c.getTable(), row, 
/* 557 */         selected);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCInputMethodType getInputMethodType() {
/* 562 */     MCColumnConfig c = getColumnConfig();
/* 563 */     return (c != null) ? c.getInputMethodType() : super.getInputMethodType();
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCEditorComboListModel createModel() {
/* 568 */     return new MCEditorComboListModel(this, this);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\table\MCEditorTextComboBox.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */