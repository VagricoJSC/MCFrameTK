/*     */ package META-INF.versions.21.mcframe.clientCore.beans.combobox;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import javax.swing.SwingUtilities;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.MCRowBeans;
/*     */ import mcframe.clientCore.beans.combobox.MCBeansProxy;
/*     */ import mcframe.clientCore.beans.combobox.MCCalendarComboBox;
/*     */ import mcframe.clientCore.beans.combobox.MCComboField;
/*     */ import mcframe.clientCore.beans.combobox.MCFieldComboBox;
/*     */ import mcframe.clientCore.beans.text.MCCalendarDocumentBeans;
/*     */ import mcframe.clientCore.beans.text.MCCalendarFormat;
/*     */ import mcframe.clientCore.beans.text.MCDateFormat;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.lang.MCCalendarDate;
/*     */ import mcframe.commonCore.lang.MCDataType;
/*     */ import mcframe.commonCore.lang.MCDate;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.notice.Core_Msg;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCMessageList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCDateComboBox
/*     */   extends MCCalendarComboBox<MCDate>
/*     */   implements MCCalendarDocumentBeans<MCDate>
/*     */ {
/*     */   @Deprecated
/*     */   public MCDateComboBox(String name) {
/*  43 */     super(name);
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCDateComboField getComboField() {
/*  48 */     return (MCDateComboField)super.getComboField();
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCDateComboField createComboField() {
/*  53 */     return new MCDateComboField(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCalendarFormat(MCDateFormat format) {
/*  64 */     setCalendarFormat((MCCalendarFormat)format);
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCCalendarFormat<MCDate> createCalendarFormat() {
/*  69 */     return (MCCalendarFormat<MCDate>)new MCDateFormat();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCDateFormat getCalendarFormat() {
/*  74 */     return (MCDateFormat)super.getCalendarFormat();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setListCalendarFormat(MCDateFormat format) {
/*  85 */     setListCalendarFormat((MCCalendarFormat)format);
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCCalendarFormat<MCDate> createListCalendarFormat() {
/*  90 */     return (MCCalendarFormat<MCDate>)new MCDateFormat();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCDateFormat getListCalendarFormat() {
/*  95 */     return (MCDateFormat)super.getListCalendarFormat();
/*     */   }
/*     */ 
/*     */   
/*     */   public Comparable<?> doListFormat(Comparable<?> value) {
/*     */     MCDate v;
/* 101 */     if (value == null || "".equals(value)) {
/* 102 */       v = null;
/*     */     }
/* 104 */     else if (value instanceof MCDate) {
/* 105 */       v = (MCDate)value;
/*     */     } else {
/*     */       
/* 108 */       throw new MCException(MCBeansUtil.createMsg(this, Core_Msg.FCBAC0351, new Object[] { value }));
/*     */     } 
/* 110 */     return getListCalendarFormat().doOutputFormat((MCCalendarDate)v);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean checkInputValue(Comparable<?> value, MCMessageList list) {
/* 115 */     MCMessageList l = getValueChecker().checkInputValue(this, value);
/* 116 */     if (l.size() == 0) {
/* 117 */       return true;
/*     */     }
/* 119 */     if (list != null) {
/* 120 */       list.addAll((Collection)l);
/*     */     }
/* 122 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCMessageList checkValue(Comparable<?> value) {
/* 127 */     return getValueChecker().checkValue(this, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCDate getRowValue() {
/* 132 */     MCConstRow c = getBaseRow();
/* 133 */     String n = getBaseRowColumnName();
/* 134 */     return !MCBeansUtil.isNull(c, n) ? c.getDate(n) : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setViewValue(Comparable<?> value, MCMessageList list) {
/* 139 */     if (list == null) {
/* 140 */       list = new MCMessageList();
/*     */     }
/* 142 */     if (value != null) {
/* 143 */       if (value instanceof MCDate) {
/* 144 */         setValue(value, list);
/*     */       } else {
/*     */         
/* 147 */         list.add(MCBeansUtil.createCauseMsg((MCRowBeans)this, Core_Msg.FCBAC0069, new Object[0]));
/*     */       } 
/*     */     } else {
/*     */       
/* 151 */       setValue(null, list);
/*     */     } 
/*     */   }
/*     */   
/*     */   public MCDate today() {
/*     */     MCDate v;
/* 157 */     MCRootPanel p = getRootPanel();
/* 158 */     if (p == null) {
/* 159 */       return MCDate.today();
/*     */     }
/*     */     
/*     */     try {
/* 163 */       v = (MCDate)p.today(MCDataType.DATE);
/*     */     }
/* 165 */     catch (Exception exception) {
/* 166 */       v = null;
/*     */     } 
/* 168 */     return (v != null) ? v : MCDate.today();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doAfterInsert() {
/* 173 */     if (!isPopupVisible()) {
/*     */       return;
/*     */     }
/*     */     
/* 177 */     SwingUtilities.invokeLater((Runnable)new Object(this));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean doIncrementalSearch() {
/* 211 */     String v = getText();
/* 212 */     if (MCStringUtil.isNull(v)) {
/* 213 */       return false;
/*     */     }
/*     */     
/* 216 */     MCList<?> l = getList();
/* 217 */     if (l == null) {
/* 218 */       return false;
/*     */     }
/*     */     
/* 221 */     boolean e = MCBeansProxy.PROXY.isEventEnabled();
/*     */     
/* 223 */     try { MCBeansProxy.PROXY.setEventEnabled(false);
/* 224 */       String n = getKeyColumnName();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */        }
/*     */     
/*     */     finally
/*     */     
/*     */     { 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 249 */       MCBeansProxy.PROXY.setEventEnabled(e); }  MCBeansProxy.PROXY.setEventEnabled(e);
/*     */     
/* 251 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public Comparable<?> _adjustValueByFormat(Comparable<?> value) {
/* 256 */     if (value instanceof MCDate) {
/* 257 */       return (Comparable<?>)MCBeansProxy.PROXY.adjustValueByFormat(
/* 258 */           (MCCalendarDate)value, getCalendarFormat().getInputPattern());
/*     */     }
/* 260 */     return value;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\combobox\MCDateComboBox.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */