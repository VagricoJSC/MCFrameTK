/*     */ package META-INF.versions.21.mcframe.clientCore.beans;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCCalendarField;
/*     */ import mcframe.clientCore.beans.MCEventProxy;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.MCRowBeans;
/*     */ import mcframe.clientCore.beans.text.MCCalendarFormat;
/*     */ import mcframe.clientCore.beans.text.MCTimestampFormat;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.commonCore.lang.MCCalendarDate;
/*     */ import mcframe.commonCore.lang.MCDataType;
/*     */ import mcframe.commonCore.lang.MCTimestamp;
/*     */ import mcframe.commonCore.notice.Core_Msg;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCMessageList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCTimestampField
/*     */   extends MCCalendarField<MCTimestamp>
/*     */ {
/*  29 */   private MCTimestampFormat _format = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public MCTimestampField(String name) {
/*  42 */     super(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setViewValue(Comparable<?> value, MCMessageList list) {
/*  73 */     if (list == null) {
/*  74 */       list = new MCMessageList();
/*     */     }
/*  76 */     if (value != null) {
/*  77 */       if (value instanceof MCTimestamp) {
/*  78 */         setValue((MCCalendarDate)value, list);
/*     */       } else {
/*  80 */         list.add(MCBeansUtil.createCauseMsg((MCRowBeans)this, Core_Msg.FCBAC0087, new Object[0]));
/*     */       } 
/*     */     } else {
/*  83 */       setValue(null, list);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCMessageList checkValue(Comparable<?> value) {
/* 107 */     return getValueChecker().checkValue(this, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkValue(Comparable<?> value, MCMessageList list) {
/* 131 */     MCMessageList l = getValueChecker().checkValue(this, value);
/* 132 */     boolean e = (l.size() == 0);
/* 133 */     if (!e && list != null) {
/* 134 */       list.addAll((Collection)l);
/*     */     }
/* 136 */     return e;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkInputValue(Comparable<?> value, MCMessageList list) {
/* 159 */     MCMessageList l = getValueChecker().checkInputValue(this, value);
/* 160 */     boolean e = (l.size() == 0);
/* 161 */     if (!e && list != null) {
/* 162 */       list.addAll((Collection)l);
/*     */     }
/* 164 */     return e;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCalendarFormat(MCTimestampFormat format) {
/* 176 */     this._format = format;
/*     */     
/* 178 */     if (format != null) {
/* 179 */       setFormatPattern(format.getCalendarPattern());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MCTimestampFormat getCalendarFormat() {
/* 193 */     if (this._format == null) {
/* 194 */       this._format = new MCTimestampFormat();
/*     */     }
/* 196 */     return this._format;
/*     */   }
/*     */ 
/*     */   
/*     */   public MCTimestamp today() {
/* 201 */     MCTimestamp t = null;
/*     */     
/* 203 */     MCRootPanel p = getRootPanel();
/* 204 */     if (p != null) {
/*     */       try {
/* 206 */         t = (MCTimestamp)p.today(MCDataType.TIMESTAMP);
/* 207 */       } catch (Exception exception) {
/* 208 */         t = null;
/*     */       } 
/*     */     }
/* 211 */     if (t == null) {
/* 212 */       t = MCTimestamp.today();
/*     */     }
/* 214 */     return t;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean setValueNoListCheck(Comparable<?> value, MCMessageList list, boolean doLC) {
/* 219 */     boolean result = true;
/*     */     
/* 221 */     MCTimestamp v = null;
/* 222 */     if (value != null) {
/* 223 */       if (result = value instanceof MCTimestamp) {
/* 224 */         v = (MCTimestamp)value;
/*     */       } else {
/*     */         
/* 227 */         list.add(MCBeansUtil.createCauseMsg((MCRowBeans)this, Core_Msg.FCBAC0087, new Object[0]));
/*     */       } 
/*     */     }
/*     */     
/* 231 */     boolean changed = false;
/* 232 */     if (result)
/*     */     {
/* 234 */       if (changed = isValueChanged((Comparable)v)) {
/*     */ 
/*     */         
/* 237 */         MCEventProxy.PROXY.setValue(getEventInfo(), (Comparable)getRowValue(), value);
/*     */         
/* 239 */         if ((result = checkInputValue((Comparable<?>)v, list)) && (result = doVC()))
/*     */         {
/*     */           
/* 242 */           setText((MCCalendarDate)v);
/* 243 */           setViewToRow();
/* 244 */           doNC();
/*     */         
/*     */         }
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 251 */         setRowToViews();
/*     */       } 
/*     */     }
/*     */     
/* 255 */     if (!result) {
/* 256 */       doCheckValueError();
/*     */     }
/* 258 */     else if (doLC && changed) {
/* 259 */       doLC();
/*     */     } 
/*     */     
/* 262 */     return result;
/*     */   }
/*     */   
/*     */   public MCTimestamp getRowValue() {
/* 266 */     MCConstRow c = getBaseRow();
/* 267 */     String n = getBaseRowColumnName();
/* 268 */     return !MCBeansUtil.isNull(c, n) ? c.getTimestamp(n) : null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void setViewToRow(Comparable<?> value) {
/* 273 */     MCConstRow c = getBaseRow();
/* 274 */     String n = getBaseRowColumnName();
/* 275 */     if (!MCBeansUtil.isNull(c, n)) {
/* 276 */       c.setTimestamp(n, (MCTimestamp)value);
/* 277 */       MCBeansUtil.setGUIModified((MCRowBeans)this, c);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setListCalendarFormat(MCTimestampFormat format) {
/* 289 */     setListCalendarFormat((MCCalendarFormat)format);
/*     */   }
/*     */ 
/*     */   
/*     */   protected MCCalendarFormat<MCTimestamp> createListCalendarFormat() {
/* 294 */     return (MCCalendarFormat<MCTimestamp>)new MCTimestampFormat();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCTimestampFormat getListCalendarFormat() {
/* 299 */     return (MCTimestampFormat)super.getListCalendarFormat();
/*     */   }
/*     */ 
/*     */   
/*     */   public Comparable<?> doListFormat(Comparable<?> value) {
/*     */     MCTimestamp v;
/* 305 */     if (value == null || "".equals(value)) {
/* 306 */       v = null;
/*     */     }
/* 308 */     else if (value instanceof MCTimestamp) {
/* 309 */       v = (MCTimestamp)value;
/*     */     } else {
/*     */       
/* 312 */       throw new MCException(MCBeansUtil.createMsg(this, Core_Msg.FCBAC0352, new Object[] { value }));
/*     */     } 
/* 314 */     return getListCalendarFormat().doOutputFormat((MCCalendarDate)v);
/*     */   }
/*     */ 
/*     */   
/*     */   public Comparable<?> _adjustValueByFormat(Comparable<?> value) {
/* 319 */     if (value instanceof MCTimestamp) {
/* 320 */       return (Comparable<?>)MCBeansUtil.adjustValueByFormat(
/* 321 */           (MCCalendarDate)value, getCalendarFormat().getInputPattern());
/*     */     }
/* 323 */     return value;
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\MCTimestampField.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */