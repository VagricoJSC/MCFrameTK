package META-INF.versions.21.mcframe.clientCore.beans.table;

import mcframe.clientCore.beans.table.MCLayoutTable;

interface Resizable3 extends MCLayoutTable.Resizable2 {
  int getMidPointAt(int paramInt);
}


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\table\MCLayoutTable$Resizable3.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */