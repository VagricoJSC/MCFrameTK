/*    */ package META-INF.versions.21.mcframe.clientCore.beans.table;
/*    */ import java.awt.event.FocusEvent;
/*    */ import mcframe.clientCore.beans.table.MCTable2;
/*    */ import mcframe.clientCore.container.MCConstRow;
/*    */ 
/*    */ class MCTable221<E extends MCConstRow> extends MCTable2<E> {
/*    */   public MCTable221(String name) {
/*  8 */     super(name);
/*    */   }
/*    */ 
/*    */   
/*    */   public void requestFocus(FocusEvent.Cause cause) {
/* 13 */     doFocus(false);
/*    */   }
/*    */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\table\MCTable221.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */