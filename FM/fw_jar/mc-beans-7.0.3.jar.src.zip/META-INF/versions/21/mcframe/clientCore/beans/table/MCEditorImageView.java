/*     */ package META-INF.versions.21.mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.event.FocusListener;
/*     */ import java.awt.event.KeyEvent;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.border.Border;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCImageView;
/*     */ import mcframe.clientCore.beans.MCMode;
/*     */ import mcframe.clientCore.beans.MCResourceBeans;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.action.MCKeyActionManager;
/*     */ import mcframe.clientCore.beans.popup.MCImagePanelInfo;
/*     */ import mcframe.clientCore.beans.table.MCCellUtil;
/*     */ import mcframe.clientCore.beans.table.MCColumnConfig;
/*     */ import mcframe.clientCore.beans.table.MCEditorBeans;
/*     */ import mcframe.clientCore.beans.table.MCEventProxy;
/*     */ import mcframe.clientCore.beans.table.MCTable;
/*     */ import mcframe.clientCore.event.MCEventInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCEditorImageView
/*     */   extends MCImageView
/*     */   implements MCEditorBeans
/*     */ {
/*     */   private static final String TYPE = "table.column.imageview";
/*     */   private MCColumnConfig _column;
/*     */   private MCTable<?> _table;
/*     */   
/*     */   @Deprecated
/*     */   protected MCEditorImageView(String name, MCColumnConfig column) {
/*  62 */     super(name);
/*  63 */     setColumnConfig(column);
/*  64 */     setTable(column.getBaseTable());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initBeans() {
/*  69 */     super.initBeans();
/*  70 */     setHorizontalAlignment(0);
/*  71 */     setFocusTraversalKeysEnabled(false);
/*  72 */     setBorder(MCCellUtil.DEFAULT_BORDER); byte b; int i; FocusListener[] arrayOfFocusListener;
/*  73 */     for (i = (arrayOfFocusListener = getFocusListeners()).length, b = 0; b < i; ) { FocusListener l = arrayOfFocusListener[b];
/*  74 */       removeFocusListener(l);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initKeyAssign() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initResource() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getType() {
/*  98 */     return "table.column.imageview";
/*     */   }
/*     */ 
/*     */   
/*     */   public void transferFocus() {
/* 103 */     MCTable<?> t = getTable();
/* 104 */     t.transferFocus(getRowIndex(), t.getViewColumn(getColumnConfig()) + 1, 
/* 105 */         false, true, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCRootPanel getRootPanel() {
/* 110 */     return MCCellUtil.getRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCRootPanel getNearestRootPanel() {
/* 115 */     return MCCellUtil.getNearestRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessageByLocale() {
/* 120 */     return getColumnConfig().getMessageByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLabelByLocale() {
/* 125 */     return getColumnConfig().getLabelByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public void commitValue() {
/* 130 */     getTable().commitValue();
/*     */   }
/*     */   
/*     */   public Border getDefaultBorder() {
/* 134 */     return MCCellUtil.DEFAULT_BORDER;
/*     */   }
/*     */   
/*     */   public final int getRowIndex() {
/* 138 */     return MCCellUtil.getRowIndex(this);
/*     */   }
/*     */   
/*     */   public void valueCommited() {
/* 142 */     MCEventProxy.PROXY.setValue(getEventInfo(), (Comparable)getRowValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setColumnConfig(MCColumnConfig column) {
/* 153 */     this._column = column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCColumnConfig getColumnConfig() {
/* 164 */     return this._column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setTable(MCTable<?> table) {
/* 175 */     this._table = table;
/*     */   }
/*     */   
/*     */   public final MCTable<?> getTable() {
/* 179 */     return this._table;
/*     */   }
/*     */ 
/*     */   
/*     */   public void doCheckValueError() {
/* 184 */     super.doCheckValueError();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setColumnInfo(int index, MCColumnConfig column) {
/* 196 */     setColumnConfig(column);
/* 197 */     MCTable<?> table = getTable();
/* 198 */     MCKeyActionManager.init((MCResourceBeans)this, getInputMap(), getActionMap());
/* 199 */     MCKeyActionManager.initScreen((MCResourceBeans)this, getInputMap(), getActionMap());
/* 200 */     MCMode mode = MCCellUtil.isCellEditable(index, column, table);
/* 201 */     setMode(mode);
/* 202 */     setForeground(MCCellUtil.getForeground(index, column, table, false, mode));
/* 203 */     setBackground(MCCellUtil.getBackground(index, column, table, false, mode));
/* 204 */     setFont(column.getFont());
/* 205 */     setMeta(column.getMeta());
/* 206 */     setRow(column.getTable().getRow(index), column.getRowColumnName());
/* 207 */     Border border = MCCellUtil.getEditorBorder(index, column, table);
/* 208 */     if (border != null) {
/* 209 */       setBorder(border);
/*     */     } else {
/* 211 */       setBorder(getDefaultBorder());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFocusOwner() {
/* 217 */     MCTable<?> t = getTable();
/* 218 */     return (t != null) ? (
/* 219 */       t.isRemoveNotifyProcessing() ? super.isFocusOwner() : false) : 
/* 220 */       super.isFocusOwner();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValueChanged() {
/* 225 */     return isValueChanged((Comparable<?>)getRowValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValueChanged(Comparable<?> value) {
/* 239 */     return isValueChanged((Comparable<?>)getValue(), value);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isValueChanged(Comparable<?> view, Comparable<?> row) {
/* 244 */     return MCCellUtil.isValueChanged(this, view, row);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean doVC() {
/* 249 */     return getColumnConfig().doVC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNC() {
/* 254 */     getColumnConfig().doNC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNE() {
/* 259 */     getColumnConfig().doNE();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNX() {
/* 264 */     getColumnConfig().doNX();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCEventInfo getEventInfo() {
/* 269 */     return getColumnConfig().getEventInfo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void focusGained() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void focusLost() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Border getBorder() {
/* 292 */     Border b = MCCellUtil.getBorder(this);
/* 293 */     return (b != null) ? b : super.getBorder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource(MCRootPanel panel) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterRequestFocus() {
/* 317 */     MCBeansUtil.afterRequestFocus((JComponent)getTable());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void processKeyEvent(KeyEvent e) {
/* 322 */     MCCellUtil.beforeKeyEvent(e, this);
/* 323 */     super.processKeyEvent(e);
/*     */   }
/*     */ 
/*     */   
/*     */   public Comparable<?> doListFormat(Comparable<?> value) {
/* 328 */     return getColumnConfig().doListFormat(getRowIndex(), value);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isImagePanelEnabled() {
/* 333 */     return getColumnConfig().isImagePanelEnabled();
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getImagePanelID() {
/* 338 */     return getColumnConfig().getImagePanelID();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCImagePanelInfo getImagePanelInfo() {
/* 343 */     return getColumnConfig().getImagePanelInfo();
/*     */   }
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   protected MCImagePanelInfo _createImagePanelInfo() {
/* 349 */     MCImagePanelInfo i = super._createImagePanelInfo();
/*     */     
/* 351 */     i.setLinkComponent(getColumnConfig(), getRowIndex());
/* 352 */     return i;
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public final void focusGainedSelect() {}
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\table\MCEditorImageView.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */