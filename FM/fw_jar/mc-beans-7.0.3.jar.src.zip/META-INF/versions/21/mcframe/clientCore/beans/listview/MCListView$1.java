/*     */ package META-INF.versions.21.mcframe.clientCore.beans.listview;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.MouseEvent;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.ListCellRenderer;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.event.MouseInputListener;
/*     */ import mcframe.clientCore.beans.listview.MCListView;
/*     */ import mcframe.clientCore.beans.listview.MCListViewCellRenderer;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class null
/*     */   implements MouseInputListener
/*     */ {
/*     */   public void mouseClicked(MouseEvent e) {
/* 369 */     if (SwingUtilities.isLeftMouseButton(e)) {
/* 370 */       switch (e.getClickCount()) {
/*     */ 
/*     */         
/*     */         case 2:
/* 374 */           MCListView.this.doDC();
/*     */           break;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void mousePressed(MouseEvent e) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseReleased(MouseEvent e) {
/* 387 */     MCListView<P> list = MCListView.this;
/*     */     
/* 389 */     if (list.getModel().getSize() == 0) {
/*     */       return;
/*     */     }
/*     */     
/* 393 */     Point pt = e.getPoint();
/* 394 */     int index = list.locationToIndex(pt);
/* 395 */     MCConstRow mCConstRow = list.getModel().getElementAt(index);
/*     */ 
/*     */     
/* 398 */     if (MCListView.this._drag != null) {
/* 399 */       boolean fire = (MCListView.this._dragsize > MCListView.this._drag_action);
/* 400 */       MCListView.this._drag = null;
/* 401 */       MCListView.this._dragstart = 0;
/* 402 */       MCListView.this._dragsize = 0;
/* 403 */       if (fire)
/*     */       {
/* 405 */         MCListView.this.changeCheckedValue(mCConstRow);
/*     */       }
/*     */ 
/*     */       
/* 409 */       MCListView.this.repaint();
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 414 */     ListCellRenderer<? super P> cr = 
/* 415 */       list.getCellRenderer();
/* 416 */     if (cr instanceof MCListViewCellRenderer) {
/* 417 */       MCListViewCellRenderer<? super P> mcr = 
/* 418 */         (MCListViewCellRenderer<? super P>)cr;
/* 419 */       if (mcr.isCheckEnabled()) {
/* 420 */         Component c = mcr.getListCellRendererComponent(
/* 421 */             (JList)list, mCConstRow, index, true, true);
/* 422 */         Rectangle r = list.getCellBounds(index, index);
/* 423 */         c.setBounds(r);
/* 424 */         MCListView.this.layoutComponent(c);
/* 425 */         pt.translate(-r.x, -r.y);
/* 426 */         Component b = SwingUtilities.getDeepestComponentAt(c, pt.x, pt.y);
/* 427 */         if (b == mcr.getCheckComponent())
/*     */         {
/* 429 */           MCListView.this.changeCheckedValue(mCConstRow);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void mouseDragged(MouseEvent e) {
/* 436 */     MCConstRow mCConstRow = (MCConstRow)MCListView.this.getSelectedValue();
/* 437 */     if (mCConstRow == null) {
/*     */       return;
/*     */     }
/*     */     
/* 441 */     if (MCListView.this._drag == null) {
/*     */       
/* 443 */       MCListView.this._drag = mCConstRow;
/* 444 */       MCListView.this._dragstart = e.getX();
/*     */     } 
/* 446 */     MCListView.this._dragsize = e.getX() - MCListView.this._dragstart;
/* 447 */     if (MCListView.this._dragsize < 0) {
/* 448 */       MCListView.this._dragsize = 0;
/*     */     }
/* 450 */     MCListView.this.repaint();
/*     */   }
/*     */   
/*     */   public void mouseMoved(MouseEvent e) {}
/*     */   
/*     */   public void mouseEntered(MouseEvent e) {}
/*     */   
/*     */   public void mouseExited(MouseEvent e) {}
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\listview\MCListView$1.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */