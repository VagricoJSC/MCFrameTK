/*     */ package META-INF.versions.21.mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.util.List;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.border.Border;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCMode;
/*     */ import mcframe.clientCore.beans.MCResourceBeans;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.MCTextField;
/*     */ import mcframe.clientCore.beans.action.MCKeyActionManager;
/*     */ import mcframe.clientCore.beans.list.MCLinkBeans;
/*     */ import mcframe.clientCore.beans.list.MCLinkedBeans;
/*     */ import mcframe.clientCore.beans.list.MCListType;
/*     */ import mcframe.clientCore.beans.popup.MCPopupConfig;
/*     */ import mcframe.clientCore.beans.popup.MCPopupMenu;
/*     */ import mcframe.clientCore.beans.table.MCBeansProxy;
/*     */ import mcframe.clientCore.beans.table.MCCellUtil;
/*     */ import mcframe.clientCore.beans.table.MCColumnConfig;
/*     */ import mcframe.clientCore.beans.table.MCEditorBeans;
/*     */ import mcframe.clientCore.beans.table.MCTable;
/*     */ import mcframe.clientCore.beans.table.MCTableColumn;
/*     */ import mcframe.clientCore.beans.text.MCInputMethodType;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.clientCore.event.MCEventInfo;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCEditorTextField
/*     */   extends MCTextField
/*     */   implements MCEditorBeans
/*     */ {
/*     */   private static final String TYPE = "table.column.text";
/*     */   private MCColumnConfig _column;
/*     */   private MCTable<?> _table;
/*     */   
/*     */   @Deprecated
/*     */   protected MCEditorTextField(String name, MCColumnConfig column) {
/*  72 */     super(name);
/*  73 */     setColumnConfig(column);
/*  74 */     setTable(column.getBaseTable());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getType() {
/*  79 */     return "table.column.text";
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initBeans() {
/*  84 */     super.initBeans();
/*     */ 
/*     */     
/*  87 */     setFocusTraversalKeysEnabled(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initResource() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initKeyAssign() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setColumnConfig(MCColumnConfig column) {
/* 118 */     this._column = column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final MCColumnConfig getColumnConfig() {
/* 130 */     return this._column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean doListEventWithNull() {
/* 141 */     MCColumnConfig c = getColumnConfig();
/* 142 */     if (c != null) {
/* 143 */       return c.doListEventWithNull();
/*     */     }
/* 145 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean haveLinkValuesNullWhenDupliKeyTyped() {
/* 157 */     MCColumnConfig c = getColumnConfig();
/* 158 */     if (c != null) {
/* 159 */       return c.haveLinkValuesNullWhenDupliKeyTyped();
/*     */     }
/* 161 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setTable(MCTable<?> table) {
/* 172 */     this._table = table;
/*     */   }
/*     */ 
/*     */   
/*     */   public final MCTable getTable() {
/* 177 */     return this._table;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getRowIndex() {
/* 183 */     return MCCellUtil.getRowIndex(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void transferFocus() {
/* 188 */     MCTable<?> t = getTable();
/* 189 */     t.transferFocus(getRowIndex(), t.getViewColumn(getColumnConfig()) + 1, false, 
/* 190 */         true, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public Border getDefaultBorder() {
/* 195 */     return MCCellUtil.DEFAULT_BORDER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setColumnInfo(int index, MCColumnConfig column) {
/* 207 */     setColumnConfig(column);
/* 208 */     MCTable<?> table = getTable();
/* 209 */     MCKeyActionManager.init((MCResourceBeans)this, getInputMap(), getActionMap());
/* 210 */     MCKeyActionManager.initScreen((MCResourceBeans)this, getInputMap(), getActionMap());
/* 211 */     MCMode mode = MCCellUtil.isCellEditable(index, column, table);
/* 212 */     setMode(mode);
/* 213 */     setForeground(MCCellUtil.getForeground(index, column, table, false, mode));
/* 214 */     setBackground(MCCellUtil.getBackground(index, column, table, false, mode));
/* 215 */     setFont(column.getFont());
/* 216 */     setCaretColor(MCCellUtil.getCaretColor(index, column, table));
/* 217 */     setSelectionColor(MCCellUtil.getSelectionColor(index, column, table));
/* 218 */     setSelectedTextColor(MCCellUtil.getSelectedTextColor(index, column, table));
/* 219 */     setMeta(column.getMeta());
/* 220 */     setLength(column.getLength(index));
/* 221 */     setRow(column.getTable().getRow(index), column.getRowColumnName());
/*     */     
/* 223 */     setAutoFocus(column.isAutoFocus());
/* 224 */     setSelectAll(column.isSelectAll());
/* 225 */     setListConfig(column.getListConfig());
/* 226 */     setTrimPattern(column.getTrimPattern());
/* 227 */     Border border = MCCellUtil.getEditorBorder(index, column, table);
/* 228 */     if (border != null) {
/* 229 */       setBorder(border);
/*     */     } else {
/*     */       
/* 232 */       setBorder(getDefaultBorder());
/*     */     } 
/* 234 */     setListListener(column.getListListener());
/*     */     
/* 236 */     MCPopupMenu menu = getComponentPopupMenu();
/* 237 */     if (menu != null) {
/* 238 */       menu.updateResource();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setDummyColumnInfo(MCColumnConfig column, MCConstRow dummy) {
/* 249 */     setColumnConfig(column);
/* 250 */     setMeta(column.getMeta());
/* 251 */     setLength(column.getLength());
/*     */     
/* 253 */     if (dummy.contains(column.getBaseRowColumnName())) {
/* 254 */       setRow(dummy, column.getBaseRowColumnName());
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 261 */       setRow((MCConstRow)column.getTable().getList().createRow(), 
/* 262 */           column.getRowColumnName());
/*     */     } 
/*     */     
/* 265 */     setAutoFocus(false);
/* 266 */     setSelectAll(false);
/* 267 */     setTrimPattern(column.getTrimPattern());
/*     */   }
/*     */ 
/*     */   
/*     */   public MCLinkedBeans[] getLinkBeans() {
/* 272 */     MCColumnConfig c = getColumnConfig();
/* 273 */     return (c != null) ? c.getLinkBeans() : super.getLinkBeans();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCRootPanel getRootPanel() {
/* 278 */     return MCCellUtil.getRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCRootPanel getNearestRootPanel() {
/* 283 */     return MCCellUtil.getNearestRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessageByLocale() {
/* 288 */     return getColumnConfig().getMessageByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLabelByLocale() {
/* 293 */     return getColumnConfig().getLabelByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterRequestFocus() {
/* 298 */     MCRootPanel bp = getBaseRootPanel();
/* 299 */     MCBeansUtil.afterRequestFocus(bp, (JComponent)getTable());
/* 300 */     MCBeansUtil.scrollRectToVisible(bp, (JComponent)this, getHorizontalAlignment());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 305 */     repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void commitValue() {}
/*     */ 
/*     */   
/*     */   public boolean isFocusOwner() {
/* 314 */     MCTable<?> t = getTable();
/* 315 */     return (t != null) ? (t.isRemoveNotifyProcessing() ? super.isFocusOwner() : false) : 
/* 316 */       super.isFocusOwner();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValueChanged() {
/* 321 */     return isValueChanged(getRowValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValueChanged(Comparable<?> value) {
/* 335 */     return isValueChanged(getValue(), value);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean isValueChanged(Comparable<?> view, Comparable<?> row) {
/* 341 */     if (isInputMethodEditing()) {
/* 342 */       return true;
/*     */     }
/*     */     
/* 345 */     return MCCellUtil.isValueChanged(this, view, row);
/*     */   }
/*     */ 
/*     */   
/*     */   public void valueCommited() {
/* 350 */     MCRow row = null;
/* 351 */     MCEventInfo e = getEventInfo();
/* 352 */     Comparable<?> newvalue = e.getNewValue();
/* 353 */     String key = getListNames()[0];
/* 354 */     MCList<?> l = null;
/* 355 */     if (newvalue != null || doListEventWithNull())
/*     */     {
/* 357 */       l = getList();
/*     */     }
/*     */     
/* 360 */     if ("input".equals(getListConfig().getOpeType()))
/*     */     {
/* 362 */       if (l != null) {
/* 363 */         MCRow[] a = l.toArray(); byte b; int i;
/*     */         MCRow[] arrayOfMCRow1;
/* 365 */         for (i = (arrayOfMCRow1 = a).length, b = 0; b < i; ) { MCRow r = arrayOfMCRow1[b];
/* 366 */           String val = r.getString(key);
/* 367 */           if (val != null && val.equals(newvalue)) {
/* 368 */             row = r;
/*     */             break;
/*     */           } 
/*     */           b++; }
/*     */       
/*     */       }  } 
/* 374 */     if (row == null && 
/* 375 */       getListType() == MCListType.FREE) {
/* 376 */       row = MCRow.create();
/* 377 */       MCBeansProxy.PROXY.addColumn(row, key, getDataType(), 
/* 378 */           getViewValue());
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 384 */     if (MCBeansProxy.PROXY.haveLinkValuesNull(e, (MCLinkBeans)this, getValue(), l, key)) {
/* 385 */       MCRow r = row.clone();
/* 386 */       r.clear();
/* 387 */       r.setValue(key, newvalue);
/* 388 */       ((MCTableColumn)getColumnConfig()).execLink(getTable().getMCEditingRow(), r, 
/* 389 */           true);
/*     */     } else {
/*     */       
/* 392 */       ((MCTableColumn)getColumnConfig()).execLink(getTable().getMCEditingRow(), 
/* 393 */           row, true);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getListNames() {
/* 403 */     return getColumnConfig().getListNames();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isMCFocusOwner() {
/* 408 */     MCTable<?> t = getTable();
/* 409 */     return (t != null) ? ((t.getMCEditorComponent() == this)) : isFocusOwner();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCList doListEventEx() {
/* 417 */     return ((MCTableColumn)getColumnConfig()).doListEventEx();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCList doListEvent() {
/* 422 */     return getColumnConfig().doListEvent();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean doVC() {
/* 427 */     return getColumnConfig().doVC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNC() {
/* 432 */     getColumnConfig().doNC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNE() {
/* 437 */     getColumnConfig().doNE();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNX() {
/* 442 */     getColumnConfig().doNX();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doLC() {
/* 447 */     getColumnConfig().doLC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doDC() {
/* 452 */     getColumnConfig().doDC();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCEventInfo getEventInfo() {
/* 457 */     return getColumnConfig().getEventInfo();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void focusGained() {
/* 463 */     focusGainedSelect();
/*     */     
/* 465 */     _installInputMethod();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void focusLost() {
/* 471 */     _uninstallInputMethod();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRequestFocusEnabled() {
/* 476 */     return (MCCellUtil.isRequestFocusEnabled(this) && super.isRequestFocusEnabled());
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isMCRequestFocusEnabled() {
/* 481 */     return MCCellUtil.isFocusable(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public Border getBorder() {
/* 486 */     Border b = MCCellUtil.getBorder(this);
/* 487 */     return (b != null) ? b : super.getBorder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource(MCRootPanel panel) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doCheckValueError() {
/* 512 */     super.doCheckValueError();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCPopupConfig getPopupConfig() {
/* 517 */     MCTable<?> t = getTable();
/* 518 */     return (t != null) ? t.getPopupConfig() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCPopupMenu configurePopup(MCPopupMenu menu) {
/* 532 */     MCPopupConfig pc = getPopupConfig();
/* 533 */     return (pc != null) ? 
/* 534 */       pc.configurePopup(menu, getTable(), getRowIndex(), getColumnConfig()) : 
/* 535 */       menu;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void processKeyEvent(KeyEvent e) {
/* 540 */     MCCellUtil.beforeKeyEvent(e, this);
/* 541 */     super.processKeyEvent(e);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Pattern> getAcceptPattern() {
/* 546 */     return getColumnConfig().getAcceptPattern();
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Character> getExceptCharacter() {
/* 551 */     return getColumnConfig().getExceptCharacter();
/*     */   }
/*     */ 
/*     */   
/*     */   public Comparable<?> doListFormat(Comparable<?> value) {
/* 556 */     return getColumnConfig().doListFormat(getRowIndex(), value);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCInputMethodType getInputMethodType() {
/* 561 */     MCColumnConfig c = getColumnConfig();
/* 562 */     return (c != null) ? c.getInputMethodType() : super.getInputMethodType();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void execLink(MCRow row, boolean msg) {
/* 567 */     row = setPluralValue(row);
/* 568 */     ((MCTableColumn)getColumnConfig()).execLink(getRowIndex(), row, msg);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\table\MCEditorTextField.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */