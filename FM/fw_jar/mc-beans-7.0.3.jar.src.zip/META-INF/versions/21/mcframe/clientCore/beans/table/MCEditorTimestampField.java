/*     */ package META-INF.versions.21.mcframe.clientCore.beans.table;
/*     */ 
/*     */ import java.awt.event.KeyEvent;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.border.Border;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCMode;
/*     */ import mcframe.clientCore.beans.MCModeBeans;
/*     */ import mcframe.clientCore.beans.MCResourceBeans;
/*     */ import mcframe.clientCore.beans.MCRootPanel;
/*     */ import mcframe.clientCore.beans.MCTimestampField;
/*     */ import mcframe.clientCore.beans.action.MCKeyActionManager;
/*     */ import mcframe.clientCore.beans.list.MCLinkedBeans;
/*     */ import mcframe.clientCore.beans.list.MCListType;
/*     */ import mcframe.clientCore.beans.popup.MCPopupConfig;
/*     */ import mcframe.clientCore.beans.popup.MCPopupMenu;
/*     */ import mcframe.clientCore.beans.table.MCBeansProxy;
/*     */ import mcframe.clientCore.beans.table.MCCellUtil;
/*     */ import mcframe.clientCore.beans.table.MCColumnConfig;
/*     */ import mcframe.clientCore.beans.table.MCEditorBeans;
/*     */ import mcframe.clientCore.beans.table.MCTable;
/*     */ import mcframe.clientCore.beans.table.MCTableColumn;
/*     */ import mcframe.clientCore.event.MCEventInfo;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.container.MCRow;
/*     */ import mcframe.commonCore.lang.MCCalendarDate;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.lang.MCTimestamp;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCEditorTimestampField
/*     */   extends MCTimestampField
/*     */   implements MCEditorBeans
/*     */ {
/*     */   private static final String TYPE = "table.column.date";
/*     */   private MCColumnConfig _column;
/*     */   private MCTable<?> _table;
/*     */   
/*     */   @Deprecated
/*     */   public MCEditorTimestampField(String name, MCColumnConfig column) {
/*  72 */     super(name);
/*  73 */     setColumnConfig(column);
/*  74 */     setTable(column.getBaseTable());
/*     */   }
/*     */ 
/*     */   
/*     */   public String getType() {
/*  79 */     return "table.column.date";
/*     */   }
/*     */ 
/*     */   
/*     */   protected void initBeans() {
/*  84 */     super.initBeans();
/*     */ 
/*     */     
/*  87 */     setFocusTraversalKeysEnabled(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initKeyAssign() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void initResource() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Border getDefaultBorder() {
/* 112 */     return MCCellUtil.DEFAULT_BORDER;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setColumnInfo(int index, MCColumnConfig column) {
/* 124 */     setColumnConfig(column);
/* 125 */     MCTable<?> table = getTable();
/* 126 */     MCKeyActionManager.init((MCResourceBeans)this, getInputMap(), getActionMap());
/* 127 */     MCKeyActionManager.initScreen((MCResourceBeans)this, getInputMap(), getActionMap());
/* 128 */     MCMode mode = MCCellUtil.isCellEditable(index, column, table);
/* 129 */     setMode(mode);
/* 130 */     setForeground(MCCellUtil.getForeground(index, column, table, false, mode));
/* 131 */     setBackground(MCCellUtil.getBackground(index, column, table, false, mode));
/* 132 */     setFont(column.getFont());
/* 133 */     setCaretColor(MCCellUtil.getCaretColor(index, column, table));
/* 134 */     setSelectionColor(MCCellUtil.getSelectionColor(index, column, table));
/* 135 */     setSelectedTextColor(MCCellUtil.getSelectedTextColor(index, column, table));
/* 136 */     setMeta(column.getMeta());
/* 137 */     setAutoFocus(column.isAutoFocus());
/* 138 */     setSelectAll(column.isSelectAll());
/* 139 */     setListConfig(column.getListConfig());
/* 140 */     setCalendarFormat(MCCellUtil.getTimestampFormat(index, column, table, mode));
/*     */     
/* 142 */     setCalendarValidator(column.getCalendarValidator());
/*     */     
/* 144 */     setRow(column.getTable().getRow(index), column.getRowColumnName());
/*     */     
/* 146 */     Border border = MCCellUtil.getEditorBorder(index, column, table);
/* 147 */     if (border != null) {
/* 148 */       setBorder(border);
/*     */     } else {
/*     */       
/* 151 */       setBorder(getDefaultBorder());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isValueChanged() {
/* 157 */     return isValueChanged((Comparable<?>)getRowValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isValueChanged(Comparable<?> value) {
/* 171 */     adjustViewValue();
/*     */     try {
/* 173 */       return isValueChanged((Comparable<?>)getValue(), value);
/*     */     }
/* 175 */     catch (MCException mCException) {
/* 176 */       return true;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isValueChanged(Comparable<?> view, Comparable<?> row) {
/* 182 */     return MCCellUtil.isValueChanged(this, view, row);
/*     */   }
/*     */ 
/*     */   
/*     */   public void valueCommited() {
/* 187 */     MCRow row = null;
/* 188 */     if ("input".equals(getListConfig().getOpeType())) {
/* 189 */       MCList<?> l = getList();
/* 190 */       if (l != null) {
/* 191 */         MCRow[] a = l.toArray();
/* 192 */         MCTimestamp v = (MCTimestamp)getValue();
/* 193 */         String n = getListNames()[0]; byte b; int i; MCRow[] arrayOfMCRow1;
/* 194 */         for (i = (arrayOfMCRow1 = a).length, b = 0; b < i; ) { MCRow r = arrayOfMCRow1[b];
/* 195 */           MCTimestamp val = r.getTimestamp(n);
/* 196 */           if (val != null && val.eq((MCCalendarDate)v, new mcframe.commonCore.lang.MCDateFieldType[0])) {
/* 197 */             row = r; break;
/*     */           } 
/*     */           b++; }
/*     */       
/*     */       } 
/*     */     } 
/* 203 */     if (row == null && 
/* 204 */       getListType() == MCListType.FREE) {
/* 205 */       row = MCRow.create();
/* 206 */       MCBeansProxy.PROXY.addColumn(row, getListNames()[0], getDataType(), 
/* 207 */           (Comparable)getViewValue());
/*     */     } 
/*     */     
/* 210 */     ((MCTableColumn)getColumnConfig()).execLink(getTable().getMCEditingRow(), row, 
/* 211 */         true);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isMCFocusOwner() {
/* 216 */     MCTable<?> t = getTable();
/* 217 */     return (t != null) ? ((t.getMCEditorComponent() == this)) : isFocusOwner();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCLinkedBeans[] getLinkBeans() {
/* 222 */     MCColumnConfig c = getColumnConfig();
/* 223 */     return (c != null) ? c.getLinkBeans() : super.getLinkBeans();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCRootPanel getRootPanel() {
/* 228 */     return MCCellUtil.getRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCRootPanel getNearestRootPanel() {
/* 233 */     return MCCellUtil.getNearestRootPanel(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public String getMessageByLocale() {
/* 238 */     return getColumnConfig().getMessageByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getLabelByLocale() {
/* 243 */     return getColumnConfig().getLabelByLocale();
/*     */   }
/*     */ 
/*     */   
/*     */   public void afterRequestFocus() {
/* 248 */     MCRootPanel bp = getBaseRootPanel();
/* 249 */     MCBeansUtil.afterRequestFocus(bp, (JComponent)getTable());
/* 250 */     MCBeansUtil.scrollRectToVisible(bp, (JComponent)this, getHorizontalAlignment());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 255 */     repaint();
/*     */   }
/*     */ 
/*     */   
/*     */   public void commitValue() {
/* 260 */     getColumnConfig().setValue(getRowIndex(), (Comparable)getViewValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isFocusOwner() {
/* 265 */     MCTable<?> t = getTable();
/* 266 */     return (t != null) ? (t.isRemoveNotifyProcessing() ? super.isFocusOwner() : false) : 
/* 267 */       super.isFocusOwner();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void transferFocus() {
/* 273 */     if (isAmPmField() && MCMode.isEnable((MCModeBeans)this) && 
/* 274 */       !MCStringUtil.isNull(getText()) && isValueChanged() && !isShowingAmPmComboList()) {
/* 275 */       showOrChangeAmPm();
/*     */       
/*     */       return;
/*     */     } 
/* 279 */     MCTable<?> t = getTable();
/* 280 */     t.transferFocus(getRowIndex(), t.getViewColumn(getColumnConfig()) + 1, false, 
/* 281 */         true, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setColumnConfig(MCColumnConfig column) {
/* 292 */     this._column = column;
/*     */   }
/*     */ 
/*     */   
/*     */   public final MCColumnConfig getColumnConfig() {
/* 297 */     return this._column;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void setTable(MCTable<?> table) {
/* 308 */     this._table = table;
/*     */   }
/*     */ 
/*     */   
/*     */   public final MCTable getTable() {
/* 313 */     return this._table;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public final int getRowIndex() {
/* 319 */     return MCCellUtil.getRowIndex(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCList doListEvent() {
/* 324 */     return getColumnConfig().doListEvent();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean doVC() {
/* 329 */     return getColumnConfig().doVC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNC() {
/* 334 */     getColumnConfig().doNC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNE() {
/* 339 */     getColumnConfig().doNE();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doNX() {
/* 344 */     getColumnConfig().doNX();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doLC() {
/* 349 */     getColumnConfig().doLC();
/*     */   }
/*     */ 
/*     */   
/*     */   public void doDC() {
/* 354 */     super.doDC();
/* 355 */     getColumnConfig().doDC();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCEventInfo getEventInfo() {
/* 360 */     return getColumnConfig().getEventInfo();
/*     */   }
/*     */ 
/*     */   
/*     */   public void focusGained() {
/* 365 */     setText((MCCalendarDate)getRowValue());
/* 366 */     focusGainedSelect();
/* 367 */     showCalenderIfFocusGained();
/* 368 */     this._suppressCalenderMPEvent = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void focusLost() {
/* 373 */     hideCalenderIfFocusLost();
/* 374 */     setText((MCCalendarDate)getRowValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRequestFocusEnabled() {
/* 379 */     return (MCCellUtil.isRequestFocusEnabled(this) && super.isRequestFocusEnabled());
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean isMCRequestFocusEnabled() {
/* 384 */     return MCCellUtil.isFocusable(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public Border getBorder() {
/* 389 */     Border b = MCCellUtil.getBorder(this);
/* 390 */     return (b != null) ? b : super.getBorder();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateResource(MCRootPanel panel) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void doCheckValueError() {
/* 415 */     super.doCheckValueError();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isCalendarEnabled() {
/* 420 */     return getColumnConfig().isCalendarEnabled();
/*     */   }
/*     */ 
/*     */   
/*     */   public MCPopupConfig getPopupConfig() {
/* 425 */     MCTable<?> t = getTable();
/* 426 */     return (t != null) ? t.getPopupConfig() : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected MCPopupMenu configurePopup(MCPopupMenu menu) {
/* 440 */     MCPopupConfig pc = getPopupConfig();
/* 441 */     return (pc != null) ? 
/* 442 */       pc.configurePopup(menu, getTable(), getRowIndex(), getColumnConfig()) : 
/* 443 */       menu;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void processKeyEvent(KeyEvent e) {
/* 448 */     MCCellUtil.beforeKeyEvent(e, this);
/* 449 */     super.processKeyEvent(e);
/*     */   }
/*     */ 
/*     */   
/*     */   public MCTimestamp getInitCalendarFocus() {
/* 454 */     MCTimestamp v = MCCellUtil.getInitTimestampCalendarFocus(getRowIndex(), 
/* 455 */         getColumnConfig(), getTable());
/* 456 */     return (v != null) ? v : today();
/*     */   }
/*     */ 
/*     */   
/*     */   public Comparable<?> doListFormat(Comparable<?> value) {
/* 461 */     return getColumnConfig().doListFormat(getRowIndex(), value);
/*     */   }
/*     */ 
/*     */   
/*     */   public String[] getCalendarPanelID() {
/* 466 */     return MCCellUtil.getCalendarPanelID(getRowIndex(), getColumnConfig(), 
/* 467 */         getTable());
/*     */   }
/*     */ 
/*     */   
/*     */   protected void execLink(MCRow row, boolean msg) {
/* 472 */     ((MCTableColumn)getColumnConfig()).execLink(getRowIndex(), row, msg);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\table\MCEditorTimestampField.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */