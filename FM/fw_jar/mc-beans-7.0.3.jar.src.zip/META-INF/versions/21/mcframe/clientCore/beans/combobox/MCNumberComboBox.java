/*     */ package META-INF.versions.21.mcframe.clientCore.beans.combobox;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.RoundingMode;
/*     */ import java.util.Collection;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.text.Document;
/*     */ import mcframe.clientCore.beans.MCBeansUtil;
/*     */ import mcframe.clientCore.beans.MCRowBeans;
/*     */ import mcframe.clientCore.beans.combobox.MCBeansProxy;
/*     */ import mcframe.clientCore.beans.combobox.MCComboField;
/*     */ import mcframe.clientCore.beans.combobox.MCEventProxy;
/*     */ import mcframe.clientCore.beans.combobox.MCFieldComboBox;
/*     */ import mcframe.clientCore.beans.list.MCListType;
/*     */ import mcframe.clientCore.beans.text.MCNumberDocument;
/*     */ import mcframe.clientCore.beans.text.MCNumberDocumentBeans;
/*     */ import mcframe.clientCore.beans.text.MCNumberFormat;
/*     */ import mcframe.clientCore.beans.text.MCNumberPattern;
/*     */ import mcframe.clientCore.container.MCConstRow;
/*     */ import mcframe.commonCore.container.MCList;
/*     */ import mcframe.commonCore.lang.MCNumber;
/*     */ import mcframe.commonCore.lang.MCNumberUtil;
/*     */ import mcframe.commonCore.lang.MCStringUtil;
/*     */ import mcframe.commonCore.meta.MCMeta;
/*     */ import mcframe.commonCore.notice.Core_Msg;
/*     */ import mcframe.commonCore.notice.MCException;
/*     */ import mcframe.commonCore.notice.MCMessageList;
/*     */ import mcframe.commonCore.resource.MCFormatConst;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCNumberComboBox
/*     */   extends MCFieldComboBox<MCNumber>
/*     */   implements MCNumberDocumentBeans
/*     */ {
/*  48 */   private int _length = Integer.MAX_VALUE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  56 */   private int _scale = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean _minus = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   private MCNumberFormat _format = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   private MCNumberFormat _list_format = null;
/*     */   
/*     */   private Integer _view_scale;
/*     */   
/*     */   private MCFormatConst.MCZeroType _view_zero_type;
/*     */   
/*     */   private RoundingMode _view_rounding_mode;
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public MCNumberComboBox(String name) {
/*  91 */     super(name);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 663 */     this._view_scale = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 671 */     this._view_zero_type = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 679 */     this._view_rounding_mode = null;
/*     */   } protected MCNumberComboField getComboField() { return (MCNumberComboField)super.getComboField(); } protected MCNumberComboField createComboField() { return new MCNumberComboField(this); } public String getType() { return "combo-number"; } protected void setMeta(MCMeta meta) { super.setMeta(meta); if (meta != null) setLength(meta.length(), meta.scale(), meta.minusEnable());  } public void setLength(int length, int scale, boolean minus) { setLength(length); setScale(scale); setMinusEnable(minus); } public void setLength(int length) { this._length = (length < 0) ? Integer.MAX_VALUE : length; } public void setScale(int scale) { if (this._scale != scale) { this._scale = (scale < 0) ? 1073741823 : scale; setText(getRowValue()); }  } public void setMinusEnable(boolean minus) { this._minus = minus; } public int getLength() { return this._length; } public int getScale() { return this._scale; } public boolean isMinusEnable() { return this._minus; } public void setNumberFormat(MCNumberFormat format) { this._format = format; } public MCNumberFormat getNumberFormat() { return (this._format != null) ? this._format : (this._format = new MCNumberFormat()); } public void setFormatPattern(MCNumberPattern pattern) { getNumberFormat().setNumberPattern(pattern); setText(getRowValue()); setListFormatPattern(pattern); } public void setFormatID(String id) { setFormatPattern(MCNumberPattern.create(id)); setText(getRowValue()); }
/*     */   public void setListNumberFormat(MCNumberFormat format) { this._list_format = format; }
/*     */   public MCNumberFormat getListNumberFormat() { return (this._list_format != null) ? this._list_format : (this._list_format = new MCNumberFormat()); }
/* 683 */   public void setViewScale(int scale) { this._view_scale = (scale < 0) ? null : Integer.valueOf(scale);
/*     */     
/* 685 */     setText(getRowValue()); }
/*     */   public void setListFormatPattern(MCNumberPattern pattern) { getListNumberFormat().setNumberPattern(pattern); }
/*     */   public void setListFormatID(String id) { setListFormatPattern(MCNumberPattern.create(id)); }
/*     */   public void focusGained() { super.focusGained(); Document d = getDocument(); if (d instanceof MCNumberDocument) { MCNumberDocument n = (MCNumberDocument)d; boolean e = n.isValueCheck(); try { n.setValueCheck(false); setText(getRowValue()); focusGainedSelect(); } finally { n.setValueCheck(e); }  } else { setText(getRowValue()); focusGainedSelect(); }  }
/*     */   public void focusLost() { super.focusLost(); Document d = getDocument(); if (d instanceof MCNumberDocument) { MCNumberDocument n = (MCNumberDocument)d; boolean e = n.isValueCheck(); try { n.setValueCheck(false); setText(getRowValue()); } finally { n.setValueCheck(e); }  } else { setText(getRowValue()); }
/* 690 */      } public int getViewScale() { if (this._view_scale != null) {
/* 691 */       return this._view_scale.intValue();
/*     */     }
/* 693 */     return getScale(); }
/*     */   public String doFormat(MCNumber value) { String rtn; MCNumberFormat f = getNumberFormat(); int fieldScale = getScale(); if (isMCFocusOwner()) { rtn = f.doInputFormat(value, fieldScale); } else { int scale = getViewScale(); if (value != null) { value = value.multiply(f.getOutputMultiplier()); int s = value.scale(); if (s > scale) { RoundingMode m = getViewRoundingMode(); if (m != null) value = value.setScale(scale, m);  }  value = value.divide(f.getOutputMultiplier()); }  MCNumberPattern cp = f.getNumberPattern(); MCNumberPattern p = MCNumberPattern.create(cp.getID(), cp.getInputPattern(), cp.getOutputPattern(), cp.getPositiveForeground(), cp.getNegativeForeground(), getViewZeroType()); try { f.setNumberPattern(p); rtn = f.doOutputFormat(value, scale); } finally { f.setNumberPattern(cp); }  }  return rtn; }
/*     */   public MCNumber doParse(String value) { MCNumberFormat f = getNumberFormat(); int s = getScale(); return isMCFocusOwner() ? f.doInputParse(value, s) : f.doOutputParse(value, s); }
/*     */   public boolean isInputMethodEditing() { return false; }
/*     */   public boolean checkInputValue(Comparable<?> value, MCMessageList list) { MCMessageList l = getValueChecker().checkInputValue(this, value); if (l.size() == 0) return true;  if (list != null) list.addAll((Collection)l);  return false; }
/* 698 */   public MCMessageList checkValue(Comparable<?> value) { return getValueChecker().checkValue(this, value); } public MCNumber getRowValue() { MCConstRow c = getBaseRow(); String n = getBaseRowColumnName(); return !MCBeansUtil.isNull(c, n) ? c.getNumber(n) : null; } public void setViewValue(Comparable<?> value, MCMessageList list) { if (list == null) list = new MCMessageList();  if (value != null) { if (value instanceof MCNumber) { setValue(value, list); } else { list.add(MCBeansUtil.createCauseMsg((MCRowBeans)this, Core_Msg.FCBAC0070, new Object[0])); }  } else { setValue(null, list); }  } public MCNumber getValue() { String t = getText(); MCNumber v = null; try { v = doParse(t); } catch (MCException mCException) { MCNumberFormat f = getNumberFormat(); int s = getScale(); v = isMCFocusOwner() ? f.doOutputParse(t, s) : f.doInputParse(t, s); }  return v; } public void setRowToView() { MCBeansUtil.checkThread(); MCConstRow r = getBaseRow(); String n = getBaseRowColumnName(); if (!MCBeansUtil.isNull(r, n)) { MCNumber v = r.getNumber(n); if (!MCNumberUtil.eq(v, getValue())) { MCEventProxy.PROXY.setValue(getEventInfo(), (Comparable)v, (Comparable)v); boolean e = MCBeansProxy.PROXY.isEventEnabled(); try { MCBeansProxy.PROXY.setEventEnabled(false); setText(v); } finally { MCBeansProxy.PROXY.setEventEnabled(e); }  }  getComboField().adjustText(); }  } public void setViewZeroType(MCFormatConst.MCZeroType type) { this._view_zero_type = type;
/*     */     
/* 700 */     setText(getRowValue()); } public void setText(MCNumber text) { setDocumentEditable(true); boolean e = isAutoFocus(); try { setAutoFocus(false); getComboField().setText(doFormat(text)); } finally { if (MCListType.SELECT_ONLY == getListType()) setDocumentEditable(false);  setAutoFocus(e); }  }
/*     */   protected void setDocumentEditable(boolean editable) { Document d = getDocument(); if (d instanceof MCNumberDocument) ((MCNumberDocument)d).setEditable(editable);  }
/*     */   public Comparable<?> doListFormat(Comparable<?> value) { MCNumber v; if (value == null || "".equals(value)) { v = null; } else if (value instanceof MCNumber) { v = (MCNumber)value; } else { throw new MCException(MCBeansUtil.createMsg(this, Core_Msg.FCBAC0350, new Object[] { value })); }  return getListNumberFormat().doOutputFormat(v, getScale()); }
/*     */   public void doAfterInsert() { if (!isPopupVisible()) return;  SwingUtilities.invokeLater((Runnable)new Object(this)); }
/*     */   protected boolean doIncrementalSearch() { String v = getText(); if (MCStringUtil.isNull(v)) return false;  MCList<?> l = getList(); if (l == null) return false;  boolean e = MCBeansProxy.PROXY.isEventEnabled(); try { MCBeansProxy.PROXY.setEventEnabled(false); String n = getKeyColumnName(); } finally { MCBeansProxy.PROXY.setEventEnabled(e); }  MCBeansProxy.PROXY.setEventEnabled(e); return false; }
/* 705 */   public MCFormatConst.MCZeroType getViewZeroType() { if (this._view_zero_type != null) {
/* 706 */       return this._view_zero_type;
/*     */     }
/* 708 */     MCNumberFormat f = getNumberFormat();
/* 709 */     if (f != null) {
/* 710 */       return f.getNumberPattern().getZeroType();
/*     */     }
/* 712 */     return MCFormatConst.MCZeroType.NONE; }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setViewRoundingMode(RoundingMode mode) {
/* 717 */     this._view_rounding_mode = mode;
/*     */     
/* 719 */     setText(getRowValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public RoundingMode getViewRoundingMode() {
/* 724 */     return this._view_rounding_mode;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean eqData(MCNumber v1, Comparable<?> v2) {
/* 729 */     return (v2 instanceof MCNumber) ? 
/* 730 */       v1.eq((BigDecimal)v2) : super.eqData((Comparable)v1, v2);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\combobox\MCNumberComboBox.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */