/*      */ package META-INF.versions.21.mcframe.clientCore.beans;
/*      */ 
/*      */ import java.awt.AWTEvent;
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Font;
/*      */ import java.awt.Point;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.Toolkit;
/*      */ import java.awt.event.FocusEvent;
/*      */ import java.awt.event.FocusListener;
/*      */ import java.awt.event.KeyEvent;
/*      */ import java.awt.event.MouseListener;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Date;
/*      */ import java.util.List;
/*      */ import java.util.Timer;
/*      */ import java.util.TimerTask;
/*      */ import java.util.regex.Pattern;
/*      */ import java.util.regex.PatternSyntaxException;
/*      */ import javax.swing.InputVerifier;
/*      */ import javax.swing.JComponent;
/*      */ import javax.swing.JPasswordField;
/*      */ import javax.swing.JPopupMenu;
/*      */ import javax.swing.JToolTip;
/*      */ import javax.swing.Popup;
/*      */ import javax.swing.border.Border;
/*      */ import javax.swing.text.Document;
/*      */ import mcframe.clientCore.acl.MCACLManager;
/*      */ import mcframe.clientCore.beans.MCBeans;
/*      */ import mcframe.clientCore.beans.MCBeansDelegate;
/*      */ import mcframe.clientCore.beans.MCBeansFocusListener;
/*      */ import mcframe.clientCore.beans.MCBeansMouseListener;
/*      */ import mcframe.clientCore.beans.MCBeansUtil;
/*      */ import mcframe.clientCore.beans.MCCacheType;
/*      */ import mcframe.clientCore.beans.MCContainerProxy;
/*      */ import mcframe.clientCore.beans.MCEventProxy;
/*      */ import mcframe.clientCore.beans.MCLabel;
/*      */ import mcframe.clientCore.beans.MCMode;
/*      */ import mcframe.clientCore.beans.MCModeBeans;
/*      */ import mcframe.clientCore.beans.MCModeInfo;
/*      */ import mcframe.clientCore.beans.MCPropertyCache;
/*      */ import mcframe.clientCore.beans.MCResourceBeans;
/*      */ import mcframe.clientCore.beans.MCRootPanel;
/*      */ import mcframe.clientCore.beans.MCRowBeans;
/*      */ import mcframe.clientCore.beans.MCTabOrderBeans;
/*      */ import mcframe.clientCore.beans.action.MCActionBeans;
/*      */ import mcframe.clientCore.beans.action.MCKeyActionManager;
/*      */ import mcframe.clientCore.beans.list.MCLinkedBeans;
/*      */ import mcframe.clientCore.beans.popup.MCPopupBeans;
/*      */ import mcframe.clientCore.beans.popup.MCPopupConfig;
/*      */ import mcframe.clientCore.beans.popup.MCPopupMenu;
/*      */ import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
/*      */ import mcframe.clientCore.beans.text.MCDocumentBeans;
/*      */ import mcframe.clientCore.beans.text.MCInputVerifier;
/*      */ import mcframe.clientCore.beans.text.MCTextDocument;
/*      */ import mcframe.clientCore.beans.text.MCValueChecker;
/*      */ import mcframe.clientCore.container.MCConstRow;
/*      */ import mcframe.clientCore.container.MCRowEvent;
/*      */ import mcframe.clientCore.container.MCRowListener;
/*      */ import mcframe.clientCore.event.MCAPListener;
/*      */ import mcframe.clientCore.event.MCDCBeans;
/*      */ import mcframe.clientCore.event.MCDCListener;
/*      */ import mcframe.clientCore.event.MCEventBeans;
/*      */ import mcframe.clientCore.event.MCEventInfo;
/*      */ import mcframe.clientCore.event.MCEventList;
/*      */ import mcframe.clientCore.event.MCEventListener;
/*      */ import mcframe.clientCore.event.MCNCBeans;
/*      */ import mcframe.clientCore.event.MCNCListener;
/*      */ import mcframe.clientCore.event.MCNCReceiver;
/*      */ import mcframe.clientCore.event.MCNEBeans;
/*      */ import mcframe.clientCore.event.MCNEListener;
/*      */ import mcframe.clientCore.event.MCNEReceiver;
/*      */ import mcframe.clientCore.event.MCNXBeans;
/*      */ import mcframe.clientCore.event.MCNXListener;
/*      */ import mcframe.clientCore.event.MCNXReceiver;
/*      */ import mcframe.clientCore.event.MCVCBeans;
/*      */ import mcframe.clientCore.event.MCVCListener;
/*      */ import mcframe.clientCore.event.MCVCReceiver;
/*      */ import mcframe.clientCore.resource.MCConst;
/*      */ import mcframe.commonCore.container.MCRow;
/*      */ import mcframe.commonCore.lang.MCDataType;
/*      */ import mcframe.commonCore.lang.MCStringUtil;
/*      */ import mcframe.commonCore.meta.MCMeta;
/*      */ import mcframe.commonCore.notice.Core_Msg;
/*      */ import mcframe.commonCore.notice.MCException;
/*      */ import mcframe.commonCore.notice.MCLog;
/*      */ import mcframe.commonCore.notice.MCMessage;
/*      */ import mcframe.commonCore.notice.MCMessageList;
/*      */ 
/*      */ public class MCPasswordField
/*      */   extends JPasswordField
/*      */   implements MCTabOrderBeans, MCModeBeans, MCRowBeans, MCVCBeans, MCVCReceiver, MCNCBeans, MCNCReceiver, MCNEBeans, MCNEReceiver, MCNXBeans, MCNXReceiver, MCLinkedBeans, MCPopupBeans, MCDCBeans, MCDocumentBeans, MCActionBeans
/*      */ {
/*   97 */   private static Border DEFAULT_BORDER = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  105 */   private MCTextPopupMenuItem _popup_paste = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  113 */   private MCAPListener _popup_listener = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  121 */   private MCBeansDelegate _delegate = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String _trim_pattern;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  137 */   private MCConstRow _link_row = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  145 */   private String _link_column_name = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  153 */   private MCDataType _link_type = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  161 */   private MCMeta _meta = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  169 */   private MCMode _mode = MCMode.NULL;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  177 */   private MCLabel _label = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  185 */   private MCEventInfo _event_info = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  193 */   private final MCEventList _event_list = new MCEventList();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  201 */   private int _length = Integer.MAX_VALUE;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  209 */   private MCPopupConfig _popup_config = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  217 */   private MCValueChecker _value_checker = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _stock_editable = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _ignore_status = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  241 */   private MCRootPanel _panel = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  249 */   private MCRootPanel _init_panel = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _auto_focus = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _selectall = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  273 */   private String _message_name_resource = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  281 */   private String _message_name = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  289 */   private String _label_name = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  297 */   private Rectangle _default_ratio_bounds = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  305 */   private Font _default_font = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _required_flg = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  323 */   private Popup _caps_lock_popup = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  331 */   private Integer _caps_lock_tool_tip_millisecond = null;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _do_hide_caps_lock_tooltip = false;
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _read_only_flg;
/*      */ 
/*      */ 
/*      */   
/*      */   private Rectangle _default_bounds;
/*      */ 
/*      */ 
/*      */   
/*      */   boolean _is_handle_processing;
/*      */ 
/*      */   
/*      */   private List<Pattern> _accept_ptn;
/*      */ 
/*      */   
/*      */   private List<Character> _except_chars;
/*      */ 
/*      */   
/*      */   protected boolean _isVisibleForMode;
/*      */ 
/*      */   
/*      */   protected boolean _isVisibleForPersonalize;
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getFontKey() {
/*  364 */     return MCConst.createKey(new String[] { getType(), "font" });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getSelectedFGKey() {
/*  375 */     return MCConst.createKey(new String[] { getType(), "selfg" });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getSelectedBGKey() {
/*  386 */     return MCConst.createKey(new String[] { getType(), "selbg" });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getCaretColorKey() {
/*  397 */     return MCConst.createKey(new String[] { getType(), "caretcolor" });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getAutoFocusKey() {
/*  408 */     return MCConst.createKey(new String[] { getType(), "autofocus" });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getSelectAllKey() {
/*  419 */     return MCConst.createKey(new String[] { getType(), "selectall" });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getTrimPatternKey() {
/*  430 */     return MCConst.createKey(new String[] { getType(), "trim" });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getEchoCharKey() {
/*  441 */     return MCConst.createKey(new String[] { getType(), "echo" });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void init() {
/*  451 */     initBeans();
/*  452 */     initResource();
/*  453 */     initKeyAssign();
/*  454 */     initPopupMenu();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initBeans() {
/*  464 */     setDocument((Document)new MCTextDocument(this));
/*  465 */     enableInputMethods(false);
/*  466 */     addFocusListener((FocusListener)MCBeansFocusListener.getInstance());
/*      */     
/*  468 */     addMouseListener((MouseListener)MCBeansMouseListener.getInstance());
/*  469 */     setHorizontalAlignment(2);
/*      */     
/*  471 */     if (DEFAULT_BORDER == null) {
/*  472 */       DEFAULT_BORDER = getBorder();
/*      */     }
/*  474 */     setInputVerifier((InputVerifier)new MCInputVerifier());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initKeyAssign() {
/*  484 */     MCKeyActionManager.init((MCResourceBeans)this, getInputMap(), getActionMap());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initPopupMenu() {
/*  494 */     setComponentPopupMenu(new MCPopupMenu(this));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initResource() {
/*  505 */     Font f = MCConst.beans.getFont(getFontKey());
/*  506 */     if (f != null) {
/*  507 */       setFont(f);
/*      */     }
/*      */ 
/*      */     
/*  511 */     Color cc = MCConst.beans.getColor(getCaretColorKey());
/*  512 */     if (cc != null) {
/*  513 */       setCaretColor(cc);
/*      */     }
/*      */ 
/*      */     
/*  517 */     Color fg = MCConst.beans.getColor(getSelectedFGKey());
/*  518 */     if (fg != null) {
/*  519 */       setSelectedTextColor(fg);
/*      */     }
/*      */ 
/*      */     
/*  523 */     Color bg = MCConst.beans.getColor(getSelectedBGKey());
/*  524 */     if (bg != null) {
/*  525 */       setSelectionColor(bg);
/*      */     }
/*      */ 
/*      */     
/*  529 */     boolean a = MCConst.beans.getBoolean(getAutoFocusKey(), isAutoFocus());
/*  530 */     setAutoFocus(a);
/*      */ 
/*      */     
/*  533 */     boolean s = MCConst.beans.getBoolean(getSelectAllKey(), isSelectAll());
/*  534 */     setSelectAll(s);
/*      */ 
/*      */     
/*  537 */     String t = MCConst.beans.getString(getTrimPatternKey());
/*  538 */     if (t != null) {
/*  539 */       setTrimPattern(t);
/*      */     }
/*      */ 
/*      */     
/*  543 */     char e = MCConst.beans.getCharacter(getEchoCharKey(), getEchoChar());
/*  544 */     setEchoChar(e);
/*      */ 
/*      */     
/*  547 */     String m = MCBeansUtil.getLabelMsg(getName());
/*  548 */     if (m != null) {
/*  549 */       this._message_name_resource = m;
/*      */     }
/*      */ 
/*      */     
/*  553 */     String l = MCBeansUtil.getLabel(getName());
/*  554 */     if (l != null) {
/*  555 */       this._label_name = l;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setName(String name) {
/*  572 */     setName(name, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setName(String name, boolean init) {
/*  587 */     MCBeansUtil.checkName(name);
/*  588 */     super.setName(name);
/*  589 */     if (init) {
/*  590 */       updateResource();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MCTextPopupMenuItem getPasteMenuItem() {
/*  602 */     if (this._popup_paste == null) {
/*  603 */       this._popup_paste = MCBeansUtil.createPopupMenuItem(this, 
/*  604 */           "POPUP_PASTE");
/*      */     }
/*  606 */     return this._popup_paste;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getType() {
/*  611 */     return "password";
/*      */   }
/*      */ 
/*      */   
/*      */   public void setRow(MCConstRow row, MCMeta meta) {
/*  616 */     MCBeansUtil.checkRow(this, (MCRow)row, meta);
/*  617 */     setMeta(meta);
/*  618 */     setRow(row, meta.name());
/*      */   }
/*      */   
/*      */   protected void setRow(MCConstRow row, String name) {
/*  622 */     if (this._link_row != null) {
/*  623 */       this._link_row.removeRowListener((MCRowListener)this);
/*      */     }
/*  625 */     this._link_row = row;
/*  626 */     this._link_column_name = name;
/*  627 */     this._link_type = getBaseRow().getDataType(getBaseRowColumnName());
/*  628 */     MCContainerProxy.proxy.setRowListener(row, name, (MCRowListener)this);
/*  629 */     setRowToView();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setMeta(MCMeta meta) {
/*  642 */     this._meta = meta;
/*  643 */     if (meta != null) {
/*  644 */       setLength(meta.length());
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public MCMeta getMeta() {
/*  650 */     return this._meta;
/*      */   }
/*      */ 
/*      */   
/*      */   public MCConstRow getBaseRow() {
/*  655 */     MCConstRow r = this._link_row;
/*  656 */     return (r != null) ? (MCConstRow)r.getRootRow() : null;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getBaseRowColumnName() {
/*  661 */     MCConstRow r = this._link_row;
/*  662 */     return (r != null) ? r.getRootRowColumnPath(this._link_column_name) : this._link_column_name;
/*      */   }
/*      */ 
/*      */   
/*      */   public MCConstRow getRow() {
/*  667 */     return this._link_row;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getRowColumnName() {
/*  672 */     return this._link_column_name;
/*      */   }
/*      */ 
/*      */   
/*      */   public MCDataType getDataType() {
/*  677 */     return this._link_type;
/*      */   }
/*      */ 
/*      */   
/*      */   public void valueChanged(MCRowEvent event) {
/*  682 */     setRowToView();
/*      */   }
/*      */ 
/*      */   
/*      */   public void setRowToView() {
/*  687 */     MCBeansUtil.checkThread();
/*  688 */     MCConstRow r = getBaseRow();
/*  689 */     String n = getBaseRowColumnName();
/*  690 */     if (!MCBeansUtil.isNull(r, n)) {
/*  691 */       String v = MCStringUtil.convertToLF(r.getString(n));
/*  692 */       if (MCStringUtil.isNull(v)) {
/*  693 */         v = null;
/*      */       }
/*  695 */       String t = String.valueOf(getPassword());
/*  696 */       if (MCStringUtil.isNull(t)) {
/*  697 */         t = null;
/*      */       }
/*  699 */       if (!MCStringUtil.eq(v, t)) {
/*  700 */         MCEventProxy.PROXY.setValue(getEventInfo(), v);
/*  701 */         boolean e = MCBeansUtil.isEventEnabled();
/*      */         try {
/*  703 */           MCBeansUtil.setEventEnabled(false);
/*  704 */           setText(v);
/*      */         } finally {
/*      */           
/*  707 */           MCBeansUtil.setEventEnabled(e);
/*      */         } 
/*      */       } 
/*      */       
/*  711 */       adjustText();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void setRowToViews() {
/*  717 */     setRowToView();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   protected void adjustText() {
/*  739 */     if (!isMCFocusOwner()) {
/*  740 */       String txt = getText();
/*  741 */       int cnt = (txt != null) ? txt.length() : 0;
/*  742 */       switch (getHorizontalAlignment()) {
/*      */         case 2:
/*  744 */           setCaretPosition(0);
/*      */           break;
/*      */         case 0:
/*  747 */           setCaretPosition(cnt / 2);
/*      */           break;
/*      */         case 4:
/*  750 */           setCaretPosition(cnt);
/*      */           break;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void localeChanged() {
/*  760 */     updateResource();
/*  761 */     MCPopupMenu m = getComponentPopupMenu();
/*  762 */     if (m != null)
/*  763 */       m.localeChanged(); 
/*      */   }
/*      */   
/*      */   @Deprecated
/*  767 */   public MCPasswordField(String name) { this._read_only_flg = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2160 */     this._default_bounds = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2372 */     this._is_handle_processing = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2681 */     this._accept_ptn = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2769 */     this._except_chars = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2941 */     this._isVisibleForMode = true;
/* 2942 */     this._isVisibleForPersonalize = true; setName(name, false); init(); }
/*      */   private void setReadOnlyFlg(boolean flg) { this._read_only_flg = flg; setMode(this._mode); }
/*      */   private boolean getReadOnlyFlg() { return this._read_only_flg; }
/* 2945 */   public void setMode(MCMode mode) { if (MCMode.isNull(mode)) return;  MCMode m = mode; if (getModeInfo(m).getStatus() == 1) if (getReadOnlyFlg()) { m = MCMode.READ_ONLY; } else if (getRequiredFlg()) { m = MCMode.REQUIRED; }   if (MCBeansUtil.setMode(this, m)) { if (this._mode != mode) this._mode = mode;  MCLabel l = getLabel(); if (l != null) l.setMode(m);  }  } public MCMode getMode() { MCMode m = this._mode; MCModeInfo i = getModeInfo(m); if (i != null && i.getStatus() == 1) if (getReadOnlyFlg()) { m = MCMode.READ_ONLY; } else if (getRequiredFlg()) { m = MCMode.REQUIRED; }   return m; } public void setLabel(MCLabel label) { if (this._label != null) this._label.setLabelFor(null);  this._label = label; if (label != null) { label.setLabelFor(this); if (this._label_name != null) label.setText(this._label_name);  }  } public MCLabel getLabel() { return this._label; } public MCMessageList setViewValue(int index, Comparable<?> value) { return setViewValue(value); } public void setViewValue(int index, Comparable<?> value, MCMessageList list) { setViewValue(value, list); } public MCMessageList setViewValue(Comparable<?> value) { MCMessageList l = new MCMessageList(); setViewValue(value, l); return l; } public void setViewValue(Comparable<?> value, MCMessageList list) { if (list == null) list = new MCMessageList();  if (value != null) { if (value instanceof String) { setValue((String)value, list); } else { list.add(MCBeansUtil.createCauseMsg(this, Core_Msg.FCBAC0068, new Object[0])); }  } else { setValue(null, list); }  } public String getViewValue(int index) { return getViewValue(); } public String getViewValue() { return getValue(); } public MCMessageList setValue(String value) { return setValue(value, null); } protected MCMessageList setValue(String value, MCMessageList list) { if (list == null) list = new MCMessageList();  int cnt = list.size(); value = (String)_adjustValue(value); value = MCBeansUtil._getExtractText(this, value); if (isValueChanged(value)) { canChange(value, list); if (list.size() == cnt) { setText(value); commitValue(); }  } else { setRowToViews(); }  return list; } protected Comparable<?> _adjustValue(Comparable<?> value) { if (value instanceof String) { String v = MCStringUtil.convertToLF((String)value); v = MCBeansUtil.trim(v, getTrimPattern()); return v; }  return value; } public String getValue() { String t = String.valueOf(getPassword()); String v = MCBeansUtil.trim(t, getTrimPattern()); if (!MCStringUtil.eq(t, v)) setText(v);  return !MCStringUtil.isNull(v) ? v : null; } public void setText(String text) { boolean a = isAutoFocus(); try { setAutoFocus(false); super.setText((text != null) ? text : ""); } finally { setAutoFocus(a); }  } public void clear() { MCBeansUtil.clear(this, null); } public void addAllListener(MCEventListener listener) { addNCListener((MCNCListener)listener); addNEListener((MCNEListener)listener); addNXListener((MCNXListener)listener); addVCListener((MCVCListener)listener); addDCListener((MCDCListener)listener); } public void setAllListener(MCEventListener listener) { setNCListener((MCNCListener)listener); setNEListener((MCNEListener)listener); setNXListener((MCNXListener)listener); setVCListener((MCVCListener)listener); setDCListener((MCDCListener)listener); } public final void addVCListener(MCVCListener listener) { this._event_list.add(listener); } public final void setVCListener(MCVCListener listener) { this._event_list.set(listener); } public final void removeVCListener(MCVCListener listener) { this._event_list.remove(listener); } public final MCVCListener[] getVCListeners() { return this._event_list.vc(); } public boolean doVC() { return MCBeansUtil.vc(this); } public boolean isValueChanged() { return isValueChanged(getValue()); } protected boolean isValueChanged(Comparable<?> value) { return isValueChanged(value, getRowValue()); } protected boolean isValueChanged(Comparable<?> view, Comparable<?> row) { if (isInputMethodEditing()) return true;  return getRootPanel().isValueChanged(this, _adjustValue(view), _adjustValue(row)); } public String getRowValue() { MCConstRow c = getBaseRow(); String n = getBaseRowColumnName(); return !MCBeansUtil.isNull(c, n) ? c.getString(n) : null; } public boolean canChange() { return (canChange(getValue(), null).size() == 0); } protected MCMessageList canChange(String value, MCMessageList list) { if (list == null) list = new MCMessageList();  int cnt = list.size(); if (isInputMethodEditing()) { list.add(MCBeansUtil.createCauseMsg(this, Core_Msg.FCBAC0033, new Object[0])); return list; }  MCEventProxy.PROXY.setValue(getEventInfo(), getRowValue(), value); checkValue(value, list); if (list.size() == cnt) if (!doVC()) list.add(MCBeansUtil.createCauseMsg(this, Core_Msg.FCBAC0032, new Object[] { value }));   if (list.size() != cnt) doCheckValueError();  return list; } public final void addNCListener(MCNCListener listener) { this._event_list.add(listener); } public final void setNCListener(MCNCListener listener) { this._event_list.set(listener); } public final void removeNCListener(MCNCListener listener) { this._event_list.remove(listener); } public final MCNCListener[] getNCListeners() { return this._event_list.nc(); } public void doNC() { MCBeansUtil.nc(this); } public void commitValue() { MCEventInfo tmpInfo = getEventInfo(); Comparable<?> nv = tmpInfo.getNewValue(); Comparable<?> ov = tmpInfo.getOldValue(); setViewToRow(); MCEventProxy.PROXY.setValue(tmpInfo, ov, nv); doNC(); } public final void addNEListener(MCNEListener listener) { this._event_list.add(listener); } public final void setNEListener(MCNEListener listener) { this._event_list.set(listener); } public final void removeNEListener(MCNEListener listener) { this._event_list.remove(listener); } public final MCNEListener[] getNEListeners() { return this._event_list.ne(); } public void doNE() { MCBeansUtil.ne(this); } public void focusGained() { doNE(); focusGainedSelect(); } @Deprecated public final void focusGainedSelect() { if (isSelectAll()) { selectAll(); } else { Document doc = getDocument(); if (doc != null) select(doc.getLength(), doc.getLength());  }  } protected void processFocusEvent(FocusEvent e) { super.processFocusEvent(e); switch (e.getID()) { case 1004: showCapsLockTooltip(); break;case 1005: hideCapsLockToolTip(); break; }  } private void showCapsLockTooltip() { if (!Toolkit.getDefaultToolkit().getLockingKeyState(20)) return;  if (this._caps_lock_popup != null) return;  int ms = getCapsLockToolTipMillisecond(); if (ms <= 0) return;  JToolTip t = createToolTip(); String s = (new MCMessage(Core_Msg.FCBAC0357, new Object[0])).toString(); t.setTipText(s); Point l = getLocationOnScreen(); int x = l.x; int y = l.y + getHeight(); Object object1 = new Object(this, this, t, x, y); this._caps_lock_popup = (Popup)object1; this._caps_lock_popup.show(); Object object2 = new Object(this, (Popup)object1); Timer m = new Timer(); Date d = new Date(System.currentTimeMillis() + ms); m.schedule((TimerTask)object2, d); } private void hideCapsLockToolTip() { if (this._do_hide_caps_lock_tooltip) return;  try { this._do_hide_caps_lock_tooltip = true; if (this._caps_lock_popup != null) { this._caps_lock_popup.hide(); this._caps_lock_popup = null; }  } finally { this._do_hide_caps_lock_tooltip = false; }  } private int getCapsLockToolTipMillisecond() { if (this._caps_lock_tool_tip_millisecond != null) return this._caps_lock_tool_tip_millisecond.intValue();  String k = MCConst.createKey(new String[] { "capslock.tooltip.millisecond" }); if (MCConst.beans.containsKey(k)) { this._caps_lock_tool_tip_millisecond = Integer.valueOf(MCConst.beans.getInteger(k, 4000)); } else { this._caps_lock_tool_tip_millisecond = Integer.valueOf(4000); }  return this._caps_lock_tool_tip_millisecond.intValue(); } public final void addNXListener(MCNXListener listener) { this._event_list.add(listener); } public final void setNXListener(MCNXListener listener) { this._event_list.set(listener); } public final void removeNXListener(MCNXListener listener) { this._event_list.remove(listener); } public final MCNXListener[] getNXListeners() { return this._event_list.nx(); } public void doNX() { MCBeansUtil.nx(this); } public void focusLost() { doNX(); select(0, 0); } public final void addDCListener(MCDCListener listener) { this._event_list.add(listener); } public final void setDCListener(MCDCListener listener) { this._event_list.set(listener); } public final void removeDCListener(MCDCListener listener) { this._event_list.remove(listener); } public final MCDCListener[] getDCListeners() { return this._event_list.dc(); } public void doDC() { MCBeansUtil.dc(this); } public MCEventInfo getEventInfo() { if (this._event_info == null) { this._event_info = new MCEventInfo(); MCEventProxy.PROXY.setComponent(this._event_info, (MCEventBeans)this); }  return this._event_info; } public MCMessageList checkValue(Comparable<?> value) { return getValueChecker().checkValue(this, value); } public boolean checkValue(Comparable<?> value, MCMessageList list) { MCMessageList l = getValueChecker().checkValue(this, value); boolean e = (l.size() == 0); if (!e && list != null) list.addAll((Collection)l);  return e; } public MCMessageList checkInputValue(String value) { return getValueChecker().checkInputValue(this, value); } public boolean checkInputValue(Comparable<?> value) { return checkInputValue(value, null); } public boolean checkInputValue(Comparable<?> value, MCMessageList list) { MCMessageList l = getValueChecker().checkInputValue(this, value); boolean e = (l.size() == 0); if (!e && list != null) list.addAll((Collection)l);  return e; } public boolean isRequestFocusEnabled() { return (super.isRequestFocusEnabled() && isMCRequestFocusEnabled()); } protected boolean isMCRequestFocusEnabled() { return MCBeansUtil.isFocusable(this); } public void mcRequestFocus() { MCBeansUtil.focus(this); } @Deprecated public void grabFocus() { super.grabFocus(); } @Deprecated public void requestFocus() { doFocus(false); } @Deprecated public boolean requestFocus(boolean temporary) { return doFocus(temporary); } protected boolean doFocus(boolean temporary) { if (super.requestFocus(temporary)) { if (!temporary) afterRequestFocus();  return true; }  return false; } @Deprecated public boolean requestFocusInWindow() { return super.requestFocusInWindow(); } @Deprecated protected boolean requestFocusInWindow(boolean temporary) { return super.requestFocusInWindow(temporary); } public void afterRequestFocus() { MCRootPanel bp = getBaseRootPanel(); MCBeansUtil.afterRequestFocus(bp, this); MCBeansUtil.scrollRectToVisible(bp, this, getHorizontalAlignment()); } public void setLength(int length) { this._length = (length < 0) ? Integer.MAX_VALUE : length; } public int getLength() { return this._length; } public MCRootPanel getRootPanel() { if (this._init_panel != null) return this._init_panel;  return getNearestRootPanel(); } public MCRootPanel getBaseRootPanel() { MCRootPanel p = getNearestRootPanel(); return (p != null) ? p.getBaseRootPanel() : null; } public MCRootPanel getNearestRootPanel() { if (this._panel == null) this._panel = MCBeansUtil.getNearestRootPanel(this);  return this._panel; } public String getMessageByLocale() { String m = this._message_name; if (m == null) m = this._message_name_resource;  return MCBeansUtil.getNameForMessage((MCBeans)this, m); } public String getLabelByLocale() { MCLabel l = getLabel(); return (l != null) ? l.getLabelByLocale() : null; } public void cut() { if (isEditable()) super.cut();  } public void paste() { if (isEditable()) { boolean a = isAutoFocus(); try { setAutoFocus(false); super.paste(); } finally { setAutoFocus(a); }  }  } @Deprecated public void setComponentPopupMenu(JPopupMenu popup) { if (popup instanceof MCPopupMenu) super.setComponentPopupMenu(popup);  } public void setComponentPopupMenu(MCPopupMenu popup) { super.setComponentPopupMenu((JPopupMenu)popup); } public void removeComponentPopupMenu() { setComponentPopupMenu(null); } public MCPopupMenu getComponentPopupMenu() { return (MCPopupMenu)super.getComponentPopupMenu(); } public void setPopupConfig(MCPopupConfig config) { this._popup_config = config; } public MCPopupConfig getPopupConfig() { return this._popup_config; } public boolean isVisibleForPersonalize() { return this._isVisibleForPersonalize; }
/*      */   public MCPopupMenu configurePopup() { if (!isEditable() && !MCBeansUtil.isTextSelected(this)) return getRootPanel().configurePopup();  addPopupMenuItems(new MCTextPopupMenuItem[] { getPasteMenuItem() }); MCBeansUtil.setCutCopyPasteMenuVisible(this, null, null, getPasteMenuItem()); MCPopupMenu m = configurePopup(getComponentPopupMenu()); if (m != null) m.sort();  return m; }
/*      */   protected MCPopupMenu configurePopup(MCPopupMenu menu) { MCPopupConfig pc = getPopupConfig(); return menu = (pc != null) ? pc.configurePopup(menu, this) : menu; }
/*      */   private final void addPopupMenuItems(MCTextPopupMenuItem... items) { MCPopupMenu pm = getComponentPopupMenu(); MCAPListener ap = getPopupActionListener(); int idx = 0; byte b; int i; MCTextPopupMenuItem[] arrayOfMCTextPopupMenuItem; for (i = (arrayOfMCTextPopupMenuItem = items).length, b = 0; b < i; ) { MCTextPopupMenuItem mCTextPopupMenuItem = arrayOfMCTextPopupMenuItem[b]; if (!pm.contains((Component)mCTextPopupMenuItem)) { mCTextPopupMenuItem.addAPListener(ap); pm.add(mCTextPopupMenuItem, idx++); mCTextPopupMenuItem.updateResource(); }  b++; }  }
/* 2949 */   public void setValueChecker(MCValueChecker checker) { this._value_checker = checker; } public MCValueChecker getValueChecker() { if (this._value_checker == null) this._value_checker = new MCValueChecker();  return this._value_checker; } public void popupMenuWillBecomeVisible() { this._stock_editable = isEditable(); setEditable(false); } public void popupMenuWillBecomeInvisible() { setEditable(this._stock_editable); } protected void setBounds() { MCBeansUtil.setBounds((MCResourceBeans)this); } @Deprecated public void _cacheDefaultBounds(Rectangle bounds) { this._default_bounds = bounds; } @Deprecated public void _setDefaultBounds() { if (this._default_bounds != null) setBounds(this._default_bounds);  } public Rectangle _getDefaultBounds() { return this._default_bounds; } public void _setDefaultBounds(Rectangle r) { this._default_bounds = r; } public void added() { this._panel = MCBeansUtil.getNearestRootPanel(this); if (MCMode.isNull(getMode())) setMode(MCMode.ENABLE);  } public void removed() { this._panel = MCBeansUtil.getNearestRootPanel(this); } public void updateResource() { updateResource(getBaseRootPanel()); } public void updateResource(MCRootPanel panel) { if (panel != null) { if (!panel.isPartsFlag()) MCKeyActionManager.initScreen((MCResourceBeans)this, getInputMap(), getActionMap());  MCPropertyCache p = panel.getPropertyCache(MCCacheType.SCREEN); Font f = MCBeansUtil.getBeansFont(panel, p, getFontKey()); if (f != null) setFont(f);  Color cc = MCBeansUtil.getBeansColor(panel, p, getCaretColorKey()); if (cc != null) setCaretColor(cc);  Color fg = MCBeansUtil.getBeansColor(panel, p, getSelectedFGKey()); if (fg != null) setSelectedTextColor(fg);  Color bg = MCBeansUtil.getBeansColor(panel, p, getSelectedBGKey()); if (bg != null) setSelectionColor(bg);  boolean a = MCBeansUtil.getBeansBoolean(panel, p, getAutoFocusKey(), isAutoFocus()); setAutoFocus(a); boolean s = MCBeansUtil.getBeansBoolean(panel, p, getSelectAllKey(), isSelectAll()); setSelectAll(s); String t = MCBeansUtil.getBeansString(panel, p, getTrimPatternKey()); if (t != null) setTrimPattern(t);  char e = MCBeansUtil.getBeansCharacter(panel, p, getEchoCharKey(), getEchoChar()); setEchoChar(e); String g = MCBeansUtil.getMessageName((MCResourceBeans)this); if (g != null) this._message_name_resource = g;  String b = MCBeansUtil.getLabel((MCBeans)this); if (b != null) this._label_name = b;  setBounds(); MCLabel l = getLabel(); if (l != null) l.updateResource(panel);  MCPopupMenu m = getComponentPopupMenu(); if (m != null) m.updateResource(panel);  }  } public final void setAutoFocus(boolean focus) { this._auto_focus = focus; } public boolean isAutoFocus() { if (MCBeansUtil.isBarcodeMode(this)) return false;  return this._auto_focus; } public final void setSelectAll(boolean selectAll) { this._selectall = selectAll; } public boolean isSelectAll() { return this._selectall; } public JComponent getComponent() { return this; } public void setTrimPattern(String pattern) { this._trim_pattern = pattern; } public String getTrimPattern() { return this._trim_pattern; } protected void processEvent(AWTEvent e) { try { super.processEvent(e); } catch (Throwable t) { if (t instanceof ArrayIndexOutOfBoundsException && e instanceof java.awt.event.MouseEvent && (e.getID() == 500 || e.getID() == 506 || e.getID() == 501)) { MCLog.write(new MCMessage(Core_Msg.FCBAC9000, new Object[] { "6857057" })); return; }  handle(t); setRowToViews(); }  } @Deprecated public void handle(Throwable t) { if (!this._is_handle_processing) { this._is_handle_processing = true; try { setViewValue(getEventInfo().getOldValue()); MCBeansUtil.handle(this, t); } finally { this._is_handle_processing = false; }  }  } protected void processKeyEvent(KeyEvent e) { if (isMCFocusOwner()) { super.processKeyEvent(e); if (e.getID() == 401) if (e.getKeyCode() != 20) { hideCapsLockToolTip(); } else if (!Toolkit.getDefaultToolkit().getLockingKeyState(20)) { hideCapsLockToolTip(); } else { showCapsLockTooltip(); }   }  } protected boolean isMCFocusOwner() { JComponent c = MCBeansUtil.getFocusOwner(this); return (c != null) ? ((this == c)) : hasFocus(); } public boolean isInputMethodEditing() { return false; } public void setViewToRow() { MCConstRow c = getBaseRow(); String n = getBaseRowColumnName(); if (!MCBeansUtil.isNull(c, n)) { c.setString(n, getValue()); MCBeansUtil.setGUIModified(this, c); }  } public boolean equalsIgnoreCase(Component compo) { return equals(compo); } public void doAfterInsert() {} public final MCModeInfo getModeInfo() { return getModeInfo(getMode()); } public final MCModeInfo getModeInfo(MCMode mode) { return getDelegate().getModeInfo(this, mode); } public void initialized() { if (this._default_ratio_bounds == null) this._default_ratio_bounds = getBounds();  if (this._default_font == null) this._default_font = getFont();  this._init_panel = MCBeansUtil.getRootPanel(this); if (MCConst.beans.containsKey("p_autofocus")) setAutoFocus(MCConst.beans.getBoolean("p_autofocus"));  if (MCConst.beans.containsKey("p_selectall")) setSelectAll(MCConst.beans.getBoolean("p_selectall"));  setRequiredFlg(MCBeansUtil.getRequiredFlg(this, this)); MCRootPanel bp = getBaseRootPanel(); if (bp != null) { String itemid = MCBeansUtil.createGUIKey(this); setReadOnlyFlg(MCACLManager.isReadOnly(bp.getModuleID(), bp.getScreenID(), itemid)); }  } public boolean doAction() { return false; } protected void doCheckValueError() { selectAll(); MCBeansUtil.getErrorHandler((MCBeans)this).doCheckValueError((MCBeans)this); } private MCBeansDelegate getDelegate() { if (this._delegate == null) this._delegate = new MCBeansDelegate();  return this._delegate; } public final void addAliasName(String alias, MCRootPanel panel) { getDelegate().addAliasName(alias, panel); } public final void setAliasName(String alias, MCRootPanel panel) { getDelegate().setAliasName(alias, panel); } public final void removeAliasName(MCRootPanel panel) { getDelegate().removeAliasName(panel); } public final void removeAliasNames() { getDelegate().removeAliasNames(); } public String getAliasName(MCRootPanel panel) { return getDelegate().getAliasName(panel); } public String[] getAliasNames() { return getDelegate().getAliasNames(); } public void enableInputMethods(boolean enable) { super.enableInputMethods(false); } public void updateBounds(int ratio) { MCBeansUtil.updateBounds(this, ratio, this._default_ratio_bounds); } public void updateFontSize(int ratio) { MCBeansUtil.updateFontSize(this, ratio, this._default_font); } public final MCTabOrderBeans getNextBeans() { return getDelegate().getNextBeans(); } public final void setNextBeans(MCTabOrderBeans compo, int updateType) { getDelegate().setNextBeans(this, compo, updateType); } public final void setNextBeans(MCTabOrderBeans compo) { getDelegate().setNextBeans(this, compo, 0); } public final void insertNextBeans(MCTabOrderBeans compo, int updateType) { getDelegate().insertNextBeans(this, compo, updateType); } public final void insertNextBeans(MCTabOrderBeans compo) { getDelegate().insertNextBeans(this, compo, 0); } public final void insertPreviousBeans(MCTabOrderBeans compo, int updateType) { getDelegate().insertPreviousBeans(this, compo, updateType); } public final void insertPreviousBeans(MCTabOrderBeans compo) { getDelegate().insertPreviousBeans(this, compo, 0); } public final MCTabOrderBeans getPreviousBeans() { return getDelegate().getPreviousBeans(); } @Deprecated public final void setPreviousBeans(MCTabOrderBeans compo) { getDelegate().setPreviousBeans(this, compo); } @Deprecated public boolean isFocusableByKeybord() { return (isVisible() && isEnabled() && isFocusable() && isEditable()); } public boolean isIgnoreStatus() { return this._ignore_status; } public void setIgnoreStatus(boolean ignore) { this._ignore_status = ignore; } public MCMode getMode(MCRootPanel panel, String status) { return getDelegate().getMode(panel, status); } public String[] getStatuses(MCRootPanel panel) { return getDelegate().getStatuses(panel); } public void putMode(MCRootPanel panel, String status, MCMode mode) { getDelegate().putMode(panel, status, mode); } public void setMode(MCRootPanel panel, String status) { setMode(getMode(panel, status)); } public Border getDefaultBorder() { return DEFAULT_BORDER; } public final boolean isTabOrderEnabled() { return getDelegate().isTabOrderEnabled(); } @Deprecated public final void setTabOrderEnabled(boolean enabled) { getDelegate().setTabOrderEnabled(enabled); } public List<Pattern> getAcceptPattern() { if (this._accept_ptn == null) { String k = MCConst.createKey(new String[] { getType(), "accept" }); String ptn = MCConst.beans.getString(k); if (ptn != null) setAcceptPattern(ptn);  }  return this._accept_ptn; } public void setAcceptPattern(List<Pattern> l) { this._accept_ptn = l; } public void addAcceptPattern(String ptn) { List<Pattern> l = getAcceptPattern(); if (l == null) { setAcceptPattern(ptn); } else { addAcceptPattern(l, ptn); }  } public void addAcceptPattern(String ptn, int flags) { List<Pattern> l = getAcceptPattern(); if (l == null) { setAcceptPattern(ptn, flags); } else { addAcceptPattern(l, ptn, flags); }  } private void setAcceptPattern(String ptn) { this._accept_ptn = new ArrayList<>(); addAcceptPattern(this._accept_ptn, ptn); } private void setAcceptPattern(String ptn, int flags) { this._accept_ptn = new ArrayList<>(); addAcceptPattern(this._accept_ptn, ptn, flags); } private void addAcceptPattern(List<Pattern> l, String ptn) { try { l.add(Pattern.compile(ptn)); } catch (PatternSyntaxException patternSyntaxException) { throw new MCException(Core_Msg.FCBAC0333, new Object[] { ptn }); }  } private void addAcceptPattern(List<Pattern> l, String ptn, int flags) { try { l.add(Pattern.compile(ptn)); } catch (PatternSyntaxException patternSyntaxException) { throw new MCException(Core_Msg.FCBAC0333, new Object[] { ptn, Integer.valueOf(flags) }); }  } public List<Character> getExceptCharacter() { if (this._except_chars == null) { String k = MCConst.createKey(new String[] { getType(), "except" }); String s = MCConst.beans.getString(k); if (s != null && s.length() > 0) setExceptCharacter(s.toCharArray());  }  return this._except_chars; } public void setExceptCharacter(List<Character> l) { this._except_chars = l; } public void setExceptCharacter(char[] cs) { this._except_chars = new ArrayList<>(); byte b; int i; char[] arrayOfChar; for (i = (arrayOfChar = cs).length, b = 0; b < i; ) { Character c = Character.valueOf(arrayOfChar[b]); this._except_chars.add(c); b++; }  } public void addExceptCharacter(char c) { List<Character> l = getExceptCharacter(); if (l == null) { this._except_chars = new ArrayList<>(); l = this._except_chars; }  l.add(Character.valueOf(c)); } public Dimension getDefaultSize() { Rectangle a = this._default_ratio_bounds; int w = (a != null) ? a.width : getWidth(); int h = (a != null) ? a.height : getHeight(); return new Dimension(w, h); } public Rectangle getDefaultBounds() { Rectangle a = this._default_ratio_bounds; return (a != null) ? a : bounds(); } public void setDefaultRatioSize(Rectangle r) { this._default_ratio_bounds = r; } @Deprecated public JComponent getTargetComponent() { return this; } public Comparable<?> doListFormat(Comparable<?> value) { return value; } public void setMessageName(String name) { this._message_name = MCBeansUtil.adjustMessageName(name); } @Deprecated public String _getMessageName() { return this._message_name; } public void setRequiredFlg(boolean required) { this._required_flg = required; setMode(this._mode); } public boolean getRequiredFlg() { return this._required_flg; } protected MCAPListener getPopupActionListener() { if (this._popup_listener == null) this._popup_listener = (MCAPListener)new MCPopupActionListener(this);  return this._popup_listener; } public void setFocusable(boolean focusable) { super.setFocusable(focusable); MCBeansUtil.setFocusableAfter(this, focusable); } @Deprecated public boolean _isLastInsert() { return (getLength() == MCStringUtil.codePointCount(getText())); } public Comparable<?> _adjustValueByFormat(Comparable<?> value) { return value; } public String convToMaximumValues(String before, int offs, String str) { return getValueChecker().convMaximumValues(this, before, offs, str); } public boolean isVisibleForMode() { return this._isVisibleForMode; }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setVisibleForLayout(boolean b) {
/* 2954 */     super.setVisible(b);
/*      */   }
/*      */   
/*      */   public void setVisibleForPersonalize(boolean b) {
/* 2958 */     this._isVisibleForPersonalize = b;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setVisible(boolean flag) {
/* 2963 */     this._isVisibleForMode = flag;
/* 2964 */     if (!this._isVisibleForPersonalize) {
/* 2965 */       super.setVisible(false);
/*      */     } else {
/*      */       
/* 2968 */       super.setVisible(flag);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void _resetDefaultFont() {
/* 2981 */     this._default_font = getFont();
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\MCPasswordField.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */