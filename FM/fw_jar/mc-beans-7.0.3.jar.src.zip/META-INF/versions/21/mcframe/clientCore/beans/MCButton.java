/*      */ package META-INF.versions.21.mcframe.clientCore.beans;
/*      */ import java.awt.AWTEvent;
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Font;
/*      */ import java.awt.Image;
/*      */ import java.awt.Insets;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.FocusListener;
/*      */ import java.awt.event.MouseEvent;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import javax.swing.Icon;
/*      */ import javax.swing.ImageIcon;
/*      */ import javax.swing.JButton;
/*      */ import javax.swing.JComponent;
/*      */ import javax.swing.JPopupMenu;
/*      */ import javax.swing.SwingUtilities;
/*      */ import javax.swing.TransferHandler;
/*      */ import javax.swing.border.Border;
/*      */ import mcframe.clientCore.acl.MCACLManager;
/*      */ import mcframe.clientCore.beans.MCACBeans;
/*      */ import mcframe.clientCore.beans.MCActionProxy;
/*      */ import mcframe.clientCore.beans.MCBeans;
/*      */ import mcframe.clientCore.beans.MCBeansDelegate;
/*      */ import mcframe.clientCore.beans.MCBeansFocusListener;
/*      */ import mcframe.clientCore.beans.MCBeansUtil;
/*      */ import mcframe.clientCore.beans.MCCacheType;
/*      */ import mcframe.clientCore.beans.MCComboBoxProxy;
/*      */ import mcframe.clientCore.beans.MCEventProxy;
/*      */ import mcframe.clientCore.beans.MCFrame;
/*      */ import mcframe.clientCore.beans.MCMode;
/*      */ import mcframe.clientCore.beans.MCModeInfo;
/*      */ import mcframe.clientCore.beans.MCPropertyCache;
/*      */ import mcframe.clientCore.beans.MCResourceBeans;
/*      */ import mcframe.clientCore.beans.MCRootPanel;
/*      */ import mcframe.clientCore.beans.MCTabOrderBeans;
/*      */ import mcframe.clientCore.beans.action.MCFunction;
/*      */ import mcframe.clientCore.beans.action.MCFunctionKey;
/*      */ import mcframe.clientCore.beans.action.MCKeyActionManager;
/*      */ import mcframe.clientCore.beans.border.MCButtonLineBorder;
/*      */ import mcframe.clientCore.beans.layout.MCHiresoManager;
/*      */ import mcframe.clientCore.beans.mouse.MCTransferHandler;
/*      */ import mcframe.clientCore.beans.plaf.metal.MCMetalButtonUI;
/*      */ import mcframe.clientCore.beans.popup.MCPopupConfig;
/*      */ import mcframe.clientCore.beans.popup.MCPopupMenu;
/*      */ import mcframe.clientCore.event.MCAPListener;
/*      */ import mcframe.clientCore.event.MCEventInfo;
/*      */ import mcframe.clientCore.event.MCEventList;
/*      */ import mcframe.clientCore.event.MCEventListener;
/*      */ import mcframe.clientCore.event.MCFDBeans;
/*      */ import mcframe.clientCore.event.MCFDListener;
/*      */ import mcframe.clientCore.event.MCFunctionBeans;
/*      */ import mcframe.clientCore.event.MCNEBeans;
/*      */ import mcframe.clientCore.event.MCNEListener;
/*      */ import mcframe.clientCore.event.MCNEReceiver;
/*      */ import mcframe.clientCore.event.MCNXBeans;
/*      */ import mcframe.clientCore.event.MCNXListener;
/*      */ import mcframe.clientCore.resource.MCConst;
/*      */ import mcframe.clientCore.resource.MCIconSupplier;
/*      */ import mcframe.commonCore.lang.MCStringUtil;
/*      */ import mcframe.commonCore.notice.Core_Msg;
/*      */ import mcframe.commonCore.notice.MCLog;
/*      */ import mcframe.commonCore.resource.MCConst;
/*      */ import mcframe.commonCore.resource.ctrl.MCResource;
/*      */ 
/*      */ public class MCButton extends JButton implements MCTabOrderBeans, MCModeBeans, MCNEBeans, MCNEReceiver, MCNXBeans, MCNXReceiver, MCAPBeans, MCFunctionBeans, MCACBeans, MCActionBeans, MCPopupBeans, MCFDBeans {
/*      */   static boolean ACTION = false;
/*      */   private static final String TYPE = "button";
/*      */   private static final String GRP_TOKEN = "@@GRP@@";
/*      */   private static final String FOCUSED_FG_KEY_FORM = "button@@GRP@@.focused.fg";
/*      */   private static final String FOCUSED_BG_KEY_FORM = "button@@GRP@@.focused.bg";
/*      */   private static final String FOCUSED_UL_KEY_FORM = "button@@GRP@@.focused.line";
/*      */   private static final String UL_KEY_FORM = "button@@GRP@@.line";
/*      */   private static final String FONT_KEY_FORM = "button@@GRP@@.font";
/*      */   private static final String MULTILINE_FONT_KEY_FORM = "button@@GRP@@.multiline_font";
/*      */   private static final String TEXT_MARGIN_TOP_KEY_FORM = "button@@GRP@@.text_margin_top";
/*      */   private static final String TEXT_MARGIN_BOTTOM_KEY_FORM = "button@@GRP@@.text_margin_bottom";
/*      */   private static final String BORDER_TICKNESS_KEY = "button@@GRP@@.border.tickness";
/*      */   private static final String BORDER_ROUNDED_CORNERS_KEY = "button@@GRP@@.border.rounded_corners";
/*      */   private static final String BORDER_HALF_ARC_KEY = "button@@GRP@@.border.halfarc";
/*      */   
/*      */   @Deprecated
/*      */   public static boolean action() {
/*   87 */     return ACTION;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  232 */   private MCMode _mode = MCMode.NULL;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  240 */   private MCFunction _function = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  248 */   private String _function_text = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  256 */   private String _function_tooltip = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  264 */   private String _function_abbreviation = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  272 */   private MCEventInfo _event_info = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  280 */   private final MCEventList _event_list = new MCEventList();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  288 */   private MCBeansDelegate _beans_delegate = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  296 */   private String _icon_key = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  304 */   private Icon _deficon = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  312 */   private Icon _defdisabledicon = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean _icon_err = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  328 */   private MCRootPanel _panel = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  336 */   private MCRootPanel _init_panel = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  344 */   private Color _focused_foreground = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  352 */   private Color _focused_background = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  360 */   private Color _grpline = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  368 */   private Color _focused_grpline = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  376 */   private String _message_name_resource = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  384 */   private String _message_name = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  392 */   private String _label_name = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  400 */   private String _ac_type = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  408 */   private Rectangle _default_ratio_bounds = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  416 */   private Font _default_font = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  424 */   private String _ap_method_name = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  434 */   private String _group = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  441 */   protected Border _app_border = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  449 */   private MCPopupConfig _popup_config = null;
/*      */   
/*  451 */   private MCIconSupplier _iconsupplier = null;
/*      */ 
/*      */   
/*  454 */   private mcframe.clientCore.beans.MCButton nextButtonForBarcode = null;
/*  455 */   private Object nextFocusForBarcode = null;
/*      */   
/*      */   private boolean _read_only_flg;
/*      */   
/*      */   private boolean _do_button_action_processing;
/*      */   private Rectangle _default_bounds;
/*      */   
/*      */   public void setNextButtonForBarcode(mcframe.clientCore.beans.MCButton nextButtonForBarcode) {
/*  463 */     this.nextButtonForBarcode = nextButtonForBarcode;
/*      */   }
/*      */   
/*      */   public mcframe.clientCore.beans.MCButton getNextButtonForBarcode() {
/*  467 */     return this.nextButtonForBarcode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNextFocusForBarcode(Object nextFocusForBarcode) {
/*  477 */     this.nextFocusForBarcode = nextFocusForBarcode;
/*      */   }
/*      */   
/*      */   public Object getNextFocusForBarcode() {
/*  481 */     return this.nextFocusForBarcode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public MCButton(String name, String group) {
/*  512 */     this(name);
/*  513 */     this._group = group;
/*  514 */     initResource();
/*      */   }
/*      */   
/*      */   public void setIconSupplier(MCIconSupplier s) {
/*  518 */     this._iconsupplier = s;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getGroup() {
/*  530 */     return this._group;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String[] getFontKey() {
/*  541 */     return getResourceKeyByGroup("button@@GRP@@.font");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String[] getFocusedFGKey() {
/*  552 */     return getResourceKeyByGroup("button@@GRP@@.focused.fg");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String[] getFocusedBGKey() {
/*  563 */     return getResourceKeyByGroup("button@@GRP@@.focused.bg");
/*      */   }
/*      */   
/*      */   private String[] getMultilineFontKey() {
/*  567 */     return getResourceKeyByGroup("button@@GRP@@.multiline_font");
/*      */   }
/*      */   
/*      */   private String[] getTextMarginTopKey() {
/*  571 */     return getResourceKeyByGroup("button@@GRP@@.text_margin_top");
/*      */   }
/*      */   
/*      */   private String[] getTextMarginBottomKey() {
/*  575 */     return getResourceKeyByGroup("button@@GRP@@.text_margin_bottom");
/*      */   }
/*      */   
/*      */   private String[] getBorderTicknessKey() {
/*  579 */     return getResourceKeyByGroup("button@@GRP@@.border.tickness");
/*      */   }
/*      */   
/*      */   private String[] getBorderRoundedCornersKey() {
/*  583 */     return getResourceKeyByGroup("button@@GRP@@.border.rounded_corners");
/*      */   }
/*      */   
/*      */   private String[] getBorderHalfArcKey() {
/*  587 */     return getResourceKeyByGroup("button@@GRP@@.border.halfarc");
/*      */   }
/*      */   
/*      */   protected String[] getFocusedUnderLineKey() {
/*  591 */     return getResourceKeyByGroup("button@@GRP@@.focused.line");
/*      */   }
/*      */   
/*      */   protected String[] getUnderLineKey() {
/*  595 */     return getResourceKeyByGroup("button@@GRP@@.line");
/*      */   }
/*      */   
/*      */   private String[] getResourceKeyByGroup(String key) {
/*  599 */     String k = key.replace("@@GRP@@", "");
/*  600 */     String g = getGroup();
/*      */     
/*  602 */     String[] a = new String[(g != null) ? 2 : 1];
/*  603 */     int i = 0;
/*  604 */     if (g != null) {
/*  605 */       a[i++] = key.replace("@@GRP@@", "_" + g);
/*      */     }
/*  607 */     a[i] = k;
/*  608 */     return a;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void init() {
/*  618 */     initBeans();
/*  619 */     initKeyAssign();
/*  620 */     initResource();
/*  621 */     initComponentPopupMenu();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initBeans() {
/*  631 */     setModel((ButtonModel)new MCButtonModel(this));
/*  632 */     setDefaultCapable(false);
/*  633 */     enableInputMethods(false);
/*  634 */     addFocusListener((FocusListener)MCBeansFocusListener.getInstance());
/*      */ 
/*      */     
/*  637 */     setComponentPopupMenu((JPopupMenu)new Object(this));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  650 */     setTransferHandler((TransferHandler)new MCTransferHandler(this));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initKeyAssign() {
/*  661 */     MCKeyActionManager.init((MCResourceBeans)this, getInputMap(), getActionMap());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initResource() {
/*  672 */     Font f = null; byte b; int i; String[] arrayOfString1;
/*  673 */     for (i = (arrayOfString1 = getFontKey()).length, b = 0; b < i; ) { String str = arrayOfString1[b];
/*  674 */       f = MCConst.beans.getFont(str);
/*  675 */       if (f != null)
/*      */         break; 
/*      */       b++; }
/*      */     
/*  679 */     if (f != null) {
/*  680 */       setFont(f);
/*      */     }
/*      */ 
/*      */     
/*  684 */     Color fg = null; int j; String[] arrayOfString2;
/*  685 */     for (j = (arrayOfString2 = getFocusedFGKey()).length, i = 0; i < j; ) { String str = arrayOfString2[i];
/*  686 */       fg = MCConst.beans.getColor(str);
/*  687 */       if (fg != null)
/*      */         break; 
/*      */       i++; }
/*      */     
/*  691 */     if (fg != null) {
/*  692 */       setFocusedForeground(fg);
/*      */     }
/*      */ 
/*      */     
/*  696 */     Color bg = null; int k; String[] arrayOfString3;
/*  697 */     for (k = (arrayOfString3 = getFocusedBGKey()).length, j = 0; j < k; ) { String str = arrayOfString3[j];
/*  698 */       bg = MCConst.beans.getColor(str);
/*  699 */       if (bg != null)
/*      */         break; 
/*      */       j++; }
/*      */     
/*  703 */     if (bg != null) {
/*  704 */       setFocusedBackground(bg);
/*      */     }
/*      */ 
/*      */     
/*  708 */     Color ful = null; int n; String[] arrayOfString4;
/*  709 */     for (n = (arrayOfString4 = getFocusedUnderLineKey()).length, k = 0; k < n; ) { String str = arrayOfString4[k];
/*  710 */       ful = MCConst.beans.getColor(str);
/*  711 */       if (ful != null)
/*      */         break; 
/*      */       k++; }
/*      */     
/*  715 */     if (ful != null) {
/*  716 */       setFocusedGrpLine(ful);
/*      */     }
/*      */ 
/*      */     
/*  720 */     Color ul = null; int i1; String[] arrayOfString5;
/*  721 */     for (i1 = (arrayOfString5 = getUnderLineKey()).length, n = 0; n < i1; ) { String str = arrayOfString5[n];
/*  722 */       ul = MCConst.beans.getColor(str);
/*  723 */       if (ul != null)
/*      */         break; 
/*      */       n++; }
/*      */     
/*  727 */     if (ul != null) {
/*  728 */       setGrpLine(ul);
/*      */     }
/*      */ 
/*      */     
/*  732 */     for (i1 = (arrayOfString5 = getMultilineFontKey()).length, n = 0; n < i1; ) { String str = arrayOfString5[n];
/*      */       Font mlf;
/*  734 */       if ((mlf = MCConst.beans.getFont(str)) != null) {
/*  735 */         setMultilineFont(mlf);
/*      */         
/*      */         break;
/*      */       } 
/*      */       n++; }
/*      */     
/*  741 */     int mtd = getHTMLTextInfo().getMarginTop(); int i2; String[] arrayOfString6;
/*  742 */     for (i2 = (arrayOfString6 = getTextMarginTopKey()).length, i1 = 0; i1 < i2; ) { String str = arrayOfString6[i1];
/*      */       int mt;
/*  744 */       if ((mt = MCConst.beans.getInteger(str, mtd)) != mtd) {
/*  745 */         getHTMLTextInfo().setMarginTop(mt);
/*      */         
/*      */         break;
/*      */       } 
/*      */       i1++; }
/*      */     
/*  751 */     int mbd = getHTMLTextInfo().getMarginBottom(); String[] arrayOfString7;
/*  752 */     for (int i3 = (arrayOfString7 = getTextMarginBottomKey()).length; i2 < i3; ) { String str = arrayOfString7[i2];
/*      */       int mb;
/*  754 */       if ((mb = MCConst.beans.getInteger(str, mbd)) != mbd) {
/*  755 */         getHTMLTextInfo().setMarginBottom(mb);
/*      */         
/*      */         break;
/*      */       } 
/*      */       i2++; }
/*      */     
/*  761 */     String m = MCBeansUtil.getLabelMsg(getName());
/*  762 */     if (m != null) {
/*  763 */       this._message_name_resource = m;
/*      */     }
/*      */ 
/*      */     
/*  767 */     String l = MCBeansUtil.getLabel(getName());
/*  768 */     if (l != null) {
/*  769 */       this._label_name = l;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initComponentPopupMenu() {
/*  781 */     setComponentPopupMenu(new MCPopupMenu(this));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Deprecated
/*      */   public void setBorder(Border border) {
/*  793 */     super.setBorder(border);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMCBorder(Border border) {
/*  804 */     this._app_border = border;
/*  805 */     if (this._app_border == null) {
/*  806 */       resetBorder();
/*      */     } else {
/*      */       
/*  809 */       setBorder(border);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void resetBorder() {
/*  819 */     if (this._app_border == null) {
/*  820 */       int t = -1;
/*  821 */       boolean rounded = false;
/*  822 */       boolean halfarc = false; String k; byte b1; int i; String[] arrayOfString;
/*  823 */       for (i = (arrayOfString = getBorderTicknessKey()).length, b1 = 0, k = arrayOfString[b1]; b1 < i && (
/*  824 */         t = MCConst.beans.getInteger(k, -1)) < 0; b1++);
/*      */ 
/*      */ 
/*      */       
/*  828 */       for (i = (arrayOfString = getBorderRoundedCornersKey()).length, b1 = 0; b1 < i; ) { k = arrayOfString[b1];
/*  829 */         if (MCConst.beans.containsKey(k)) {
/*  830 */           rounded = MCConst.beans.getBoolean(k, false); break;
/*      */         } 
/*      */         b1++; }
/*      */       
/*  834 */       for (i = (arrayOfString = getBorderHalfArcKey()).length, b1 = 0; b1 < i; ) { k = arrayOfString[b1];
/*  835 */         if (MCConst.beans.containsKey(k)) {
/*  836 */           halfarc = MCConst.beans.getBoolean(k, false); break;
/*      */         } 
/*      */         b1++; }
/*      */       
/*  840 */       MCButtonLineBorder b = new MCButtonLineBorder(t, rounded, halfarc);
/*      */       
/*  842 */       MCRootPanel p = getBaseRootPanel();
/*  843 */       if (p != null) {
/*  844 */         b.setRatio(p.getLayoutRatio());
/*      */       }
/*  846 */       setBorder((Border)b);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setName(String name) {
/*  863 */     setName(name, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void setName(String name, boolean init) {
/*  878 */     MCBeansUtil.checkName(name);
/*  879 */     super.setName(name);
/*  880 */     if (init) {
/*  881 */       updateResource();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public String getType() {
/*  887 */     return "button";
/*      */   }
/*      */ 
/*      */   
/*      */   public void localeChanged() {
/*  892 */     updateResource();
/*      */   }
/*      */   @Deprecated
/*  895 */   public MCButton(String name) { this._read_only_flg = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1354 */     this._do_button_action_processing = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1799 */     this._default_bounds = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2824 */     this._label_name_program = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3047 */     this._drop_enable = MCBeansUtil.isDropEnable((MCBeans)this);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3123 */     this._isVisibleForMode = true;
/* 3124 */     this._isVisibleForPersonalize = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3154 */     this._isAnytimeFAction = false; setName(name, false); init(); }
/*      */   private void setReadOnlyFlg(boolean flg) { if (this._read_only_flg != flg) { this._read_only_flg = flg; setMode(this._mode); }  }
/*      */   private boolean getReadOnlyFlg() { return this._read_only_flg; }
/*      */   public void setMode(MCMode mode) { MCMode m = mode; if (getModeInfo(m).getStatus() == 1 && getReadOnlyFlg()) m = MCMode.READ_ONLY;  if (MCBeansUtil.setMode(this, m)) { this._mode = mode; if (getModeInfo().getStatus() != 3 && !authorize()) { setEnabled(false); setFocusable(false); MCModeInfo i = getModeInfo(MCMode.UNAUTHORIZED); setForeground(i.getForeground()); setBackground(i.getBackground()); }  fgChanged(); }  }
/* 3158 */   public MCMode getMode() { MCMode m = this._mode; MCModeInfo i = getModeInfo(m); if (i != null && i.getStatus() == 1 && getReadOnlyFlg()) m = MCMode.READ_ONLY;  return m; } public boolean isRequestFocusEnabled() { return (super.isRequestFocusEnabled() && isMCRequestFocusEnabled()); } protected boolean isMCRequestFocusEnabled() { return MCBeansUtil.isFocusable(this); } public void mcRequestFocus() { MCBeansUtil.focus(this); } @Deprecated public void grabFocus() { super.grabFocus(); } @Deprecated public void requestFocus() { doFocus(false); } @Deprecated public boolean requestFocus(boolean temporary) { return doFocus(temporary); } protected boolean doFocus(boolean temporary) { if (super.requestFocus(temporary)) { if (!temporary) afterRequestFocus();  return true; }  return false; } @Deprecated public boolean requestFocusInWindow() { return super.requestFocusInWindow(); } @Deprecated protected boolean requestFocusInWindow(boolean temporary) { return super.requestFocusInWindow(temporary); } public void afterRequestFocus() { MCRootPanel bp = getBaseRootPanel(); MCBeansUtil.afterRequestFocus(bp, this); MCBeansUtil.scrollRectToVisible(bp, this); } public MCRootPanel getRootPanel() { if (this._init_panel != null) return this._init_panel;  return getNearestRootPanel(); } public MCRootPanel getBaseRootPanel() { MCRootPanel p = getNearestRootPanel(); return (p != null) ? p.getBaseRootPanel() : null; } public MCRootPanel getNearestRootPanel() { if (this._panel == null) this._panel = MCBeansUtil.getNearestRootPanel(this);  return this._panel; } public String getMessageByLocale() { String m = this._message_name; if (m == null) m = this._message_name_resource;  return MCBeansUtil.getNameForMessage((MCBeans)this, m); } public String getLabelByLocale() { return this._label_name_program; } static final void setActionExecuting(boolean action) { ACTION = action; } protected void fireActionPerformed(ActionEvent event) { super.fireActionPerformed(event); doButtonAction(true); } public boolean doButtonAction() { MCPopupMenu.hideActivePopupMenu(); if (!isVisible()) return false;  MCRootPanel p = getBaseRootPanel(); if (p == null) return false;  if (!(p instanceof mcframe.clientCore.beans.popup.MCCalendarPanel)) MCCalendarPopup.hideActivePopup();  JComponent o = MCBeansUtil.getFocusOwner(this); if (!equalsIgnoreCase(o) && !MCBeansUtil.requestCommit(o)) return false;  if (!isEnabled() || !isFocusable()) return false;  requestFocus(); return doButtonAction(false); } private boolean doButtonAction(boolean ope) { if (ope) { if (this._do_button_action_processing) return false;  try { this._do_button_action_processing = true; MCLog.write(Core_Msg.FCBAC0416, new Object[] { MCRootPanel.getStackTrace() }); return _doButtonAction(ope); } finally { this._do_button_action_processing = false; }  }  return _doButtonAction(ope); } private boolean _doButtonAction(boolean ope) { MCRootPanel bp = getBaseRootPanel(); if (ope) if (ACTION || MCComboBoxProxy.PROXY.isListPressing() || !MCActionProxy.PROXY.setEventStatus(bp, (MCBeans)this)) return false;   MCFrame f = bp.getFrame(); if (ope && f != null && !f.isActive()) return false;  boolean b = bp.isBarcodeMode(); if (b) { if (!isMCFocusOwner() && !isAnytimeFAction()) { JComponent c = MCBeansUtil.getFocusOwner(this); if (c != null && c instanceof MCVCReceiver && ((MCVCReceiver)c).isValueChanged()) return false;  }  } else if (!isMCFocusOwner() && !isAnytimeFAction()) { return false; }  if (ope) ACTION = true;  if (!checkAC()) return false;  try { MCBeansUtil.setClientOperationType(this, "BP"); MCBeansUtil.doHistoryRegister(this); doAP(); } finally { MCBeansUtil.setClientOperation((MCBeans)this, null); if (isMCFocusOwner() && !isEnabled()) transferFocus();  if (ope) SwingUtilities.invokeLater((Runnable)new Object(this, bp));  }  return true; } protected boolean isMCFocusOwner() { JComponent c = MCBeansUtil.getFocusOwner(this); return (c != null) ? equals(c) : isFocusOwner(); } public void setFunctionKey(MCFunctionKey key) { MCFunction f = (key != null) ? new MCFunction(key, this, 2) : null; setFunction(f); } public MCFunctionKey getFunctionKey() { return (this._function != null) ? this._function.getKey() : null; } public void setFunction(MCFunction function) { this._function = function; this._function_text = null; this._function_tooltip = null; this._function_abbreviation = null; String m = (this._message_name != null) ? this._message_name : this._message_name_resource; if (m != null) setMCToolTipText(m);  MCRootPanel p = getRootPanel(); if (p != null) p.setFunction(this);  } public MCFunction getFunction() { return this._function; } public String getIconKey() { return this._icon_key; } public void action(MCFunction function) { if (ACTION) return;  writeButtonActionLog(true); if (isRequestFocusEnabled()) { requestFocus(); doClick(); writeButtonActionLog(false); } else if (isAnytimeFAction()) { fireActionPerformed(null); writeButtonActionLog(false); }  } protected String getFunctionKeyText() { if (this._function_text == null) { MCFunctionKey fk = getFunctionKey(); if (fk != null) { String kt = fk.getKeyText().toLowerCase(); String key = MCResource.createKey(new String[] { "function.text", kt }); if (MCConst.beans.containsKey(key)) this._function_text = MCConst.beans.getString(key);  }  }  return this._function_text; } protected String getFunctionKeyTooltipText() { if (this._function_tooltip == null) { MCFunctionKey fk = getFunctionKey(); if (fk != null) { String kt = fk.getKeyText().toLowerCase(); String key = MCResource.createKey(new String[] { "function.tooltip", kt }); if (MCConst.beans.containsKey(key)) this._function_tooltip = MCConst.beans.getString(key);  }  }  return this._function_tooltip; } public String getFunctionKeyAbbreviation() { return (this._function_abbreviation != null) ? this._function_abbreviation : (this._function_abbreviation = MCBeansUtil.getFunctionKeyAbbreviation(this)); } public void addAllListener(MCEventListener listener) { addAPListener((MCAPListener)listener); addNEListener((MCNEListener)listener); addNXListener((MCNXListener)listener); } public void setAllListener(MCEventListener listener) { setAPListener((MCAPListener)listener); setNEListener((MCNEListener)listener); setNXListener((MCNXListener)listener); } public MCEventInfo getEventInfo() { if (this._event_info == null) { this._event_info = new MCEventInfo(); MCEventProxy.PROXY.setComponent(this._event_info, (MCEventBeans)this); }  return this._event_info; } public final void addAPListener(MCAPListener listener) { this._event_list.add(listener); } public final void setAPListener(MCAPListener listener) { this._event_list.set(listener); } public final void removeAPListener(MCAPListener listener) { this._event_list.remove(listener); } public final MCAPListener[] getAPListeners() { return this._event_list.ap(); } public void doAP() { MCBeansUtil.ap(this); } public final void addNEListener(MCNEListener listener) { this._event_list.add(listener); } public final void setNEListener(MCNEListener listener) { this._event_list.set(listener); } public final void removeNEListener(MCNEListener listener) { this._event_list.remove(listener); } public final MCNEListener[] getNEListeners() { return this._event_list.ne(); } public void doNE() { MCBeansUtil.ne(this); } public void focusGained() { doNE(); fgChanged(); } public final void addNXListener(MCNXListener listener) { this._event_list.add(listener); } public final void setNXListener(MCNXListener listener) { this._event_list.set(listener); } public final void removeNXListener(MCNXListener listener) { this._event_list.remove(listener); } public final MCNXListener[] getNXListeners() { return this._event_list.nx(); } public void doNX() { MCBeansUtil.nx(this); } public void focusLost() { doNX(); fgChanged(); } protected void processEvent(AWTEvent e) { try { super.processEvent(e); } catch (Throwable t) { handle(t); }  } @Deprecated public void handle(Throwable t) { MCBeansUtil.handle(this, t); } protected void processMouseEvent(MouseEvent e) { if (e.getID() == 501 && !MCActionProxy.PROXY.canEvent(getBaseRootPanel(), (MCBeans)this)) return;  if (SwingUtilities.isLeftMouseButton(e)) switch (e.getID()) { case 501: writeButtonActionLog(true); super.processMouseEvent(e); return;case 502: super.processMouseEvent(e); writeButtonActionLog(false); return; }   super.processMouseEvent(e); } protected void setBounds() { MCBeansUtil.setBounds((MCResourceBeans)this); } @Deprecated public void _cacheDefaultBounds(Rectangle bounds) { this._default_bounds = bounds; } @Deprecated public void _setDefaultBounds() { if (this._default_bounds != null) setBounds(this._default_bounds);  } public Rectangle _getDefaultBounds() { return this._default_bounds; } public void _setDefaultBounds(Rectangle r) { this._default_bounds = r; } public void setBounds(int x, int y, int width, int height) { if (x == getX() && y == getY() && width == getWidth() && height == getHeight()) return;  super.setBounds(x, y, width, height); resetBorder(); } protected void setLabelText() { String l = MCBeansUtil.getLabel((MCBeans)this); if (l != null) this._label_name = l;  String t = this._label_name; if (t != null) { if (!MCStringUtil.isNull(t)) { String ft = getFunctionKeyText(); if (ft != null) t = t + t;  }  if (!t.equals(getLabelByLocale())) setText(t);  }  resetBorder(); } protected void setMCToolTipText(String text) { if (text == null) return;  String s = text; String function = getFunctionKeyTooltipText(); if (function != null) s = s + s;  if (s.length() == 0) s = null;  setToolTipText(s); } public String getToolTipText(MouseEvent event) { String tip = getToolTipText(); tip = MCHiresoManager.getToolTipText(this, tip); return tip; } public void added() { this._panel = MCBeansUtil.getNearestRootPanel(this); if (MCMode.isNull(getMode())) setMode(MCMode.ENABLE);  } public void removed() { this._panel = MCBeansUtil.getNearestRootPanel(this); } public void updateResource() { updateResource(getBaseRootPanel()); } public void updateResource(MCRootPanel panel) { if (panel != null) { if (!panel.isPartsFlag()) MCKeyActionManager.initScreen((MCResourceBeans)this, getInputMap(), getActionMap());  MCPropertyCache p = panel.getPropertyCache(MCCacheType.SCREEN); Color fg = null; byte b; int i; String[] arrayOfString1; for (i = (arrayOfString1 = getFocusedFGKey()).length, b = 0; b < i; ) { String str = arrayOfString1[b]; fg = MCBeansUtil.getBeansColor(panel, p, str); if (fg != null) break;  b++; }  if (fg != null) setFocusedForeground(fg);  Color bg = null; int j; String[] arrayOfString2; for (j = (arrayOfString2 = getFocusedBGKey()).length, i = 0; i < j; ) { String str = arrayOfString2[i]; bg = MCBeansUtil.getBeansColor(panel, p, str); if (bg != null) break;  i++; }  if (bg != null) setFocusedBackground(bg);  Font f = null; int k; String[] arrayOfString3; for (k = (arrayOfString3 = getFontKey()).length, j = 0; j < k; ) { String str = arrayOfString3[j]; f = MCBeansUtil.getBeansFont(panel, p, str); if (f != null) break;  j++; }  if (f != null) setFont(f);  Font mlf = null; int n; String[] arrayOfString4; for (n = (arrayOfString4 = getMultilineFontKey()).length, k = 0; k < n; ) { String str = arrayOfString4[k]; if ((mlf = MCBeansUtil.getBeansFont(panel, p, str)) != null) { setMultilineFont(mlf); break; }  k++; }  int mtd = getHTMLTextInfo().getMarginTop(); int i1; String[] arrayOfString5; for (i1 = (arrayOfString5 = getTextMarginTopKey()).length, n = 0; n < i1; ) { String str = arrayOfString5[n]; int mt; if ((mt = MCBeansUtil.getBeansInteger(panel, p, str, mtd)) != mtd) { getHTMLTextInfo().setMarginTop(mt); break; }  n++; }  int mbd = getHTMLTextInfo().getMarginBottom(); String[] arrayOfString6; for (int i2 = (arrayOfString6 = getTextMarginBottomKey()).length; i1 < i2; ) { String str = arrayOfString6[i1]; int mb; if ((mb = MCBeansUtil.getBeansInteger(panel, p, str, mbd)) != mbd) { getHTMLTextInfo().setMarginBottom(mb); break; }  i1++; }  setLabelText(); String m = MCBeansUtil.getMessageName((MCResourceBeans)this); if (m != null) this._message_name_resource = m;  setMCToolTipText((this._message_name != null) ? this._message_name : this._message_name_resource); setACType(); setBounds(); }  } protected void setACType() { String k = MCBeansUtil.getACTypeKey((MCResourceBeans)this); if (!MCStringUtil.isNull(k)) { String a = MCConst.actype.getType(new String[] { k }); this._ac_type = a; }  } public Color getForeground() { Color c = null; if (!authorize()) c = getModeInfo(MCMode.UNAUTHORIZED).getForeground();  if (c == null) { if (isMCFocusOwner()) c = getFocusedForeground();  if (c == null) c = super.getForeground();  }  return c; } public void setForeground(Color color) { super.setForeground(color); fgChanged(); } private void fgChanged() { String p = this._label_name_program; if (!MCStringUtil.isNull(p) && MCStringUtil.convertToLF(p).contains("\n")) { Color fg = getForeground(); if (!getModel().isEnabled() && getUI() instanceof MCMetalButtonUI) fg = ((MCMetalButtonUI)getUI()).getDisabledTextColor();  super.setText(MCBeansUtil.toHTMLText((MCBeans)this, this._label_name_program, fg, getHTMLTextInfo())); }  } public Color getBackground() { Color c = null; if (!authorize()) c = getModeInfo(MCMode.UNAUTHORIZED).getBackground();  if (c == null) { if (isMCFocusOwner()) c = getFocusedBackground();  if (c == null) c = super.getBackground();  }  return c; } public Color getGrpLine() { return this._grpline; } public Color getFocusedGrpLine() { return this._focused_grpline; } public void setGrpLine(Color b) { this._grpline = b; } public void setFocusedGrpLine(Color b) { this._focused_grpline = b; } public void setIcon(Icon icon) { MCRootPanel rp = getBaseRootPanel(); if (rp != null) { int n = rp.getLayoutRatio(); if (n != 100) { Icon icon2 = getAdjustDefIcon(n); super.setIcon(icon2); }  } else { super.setIcon(icon); }  this._deficon = icon; iconUpdated(); } public void setDisabledIcon(Icon icon) { super.setDisabledIcon(icon); this._defdisabledicon = icon; iconUpdated(); } private void iconUpdated() { resetBorder(); adjustImageIcon(); MCRootPanel rp = getBaseRootPanel(); if (rp != null) adjustImageIcon(rp.getLayoutRatio());  } private void adjustImageIcon() { if (MCBeansUtil.isAdjustSize((MCResourceBeans)this)) { Icon i = getIcon(); if (i != null && i instanceof ImageIcon) { ImageIcon c = (ImageIcon)i; ImageIcon image = MCBeansUtil.adjustIconSizeWithCache(c, getIconSize(i), this._iconsupplier); if (image != null) super.setIcon(image);  }  Icon di = getDisabledIcon(); if (di != null && di instanceof ImageIcon) { ImageIcon c = (ImageIcon)di; ImageIcon image = MCBeansUtil.adjustIconSizeWithCache(c, getIconSize(di), this._iconsupplier); if (image != null) super.setDisabledIcon(image);  }  }  } private Icon getAdjustDefIcon(int ratio) { if (ratio == 100) return this._deficon;  Icon i = this._deficon; if (i != null && i instanceof ImageIcon) { ImageIcon newIcon = getAdjustedImageIcon((ImageIcon)i, ratio); if (newIcon != null) return newIcon;  }  return this._deficon; } private void adjustImageIcon(int ratio) { if (ratio == 100) { super.setIcon(this._deficon); super.setDisabledIcon(this._defdisabledicon); return; }  Icon i = this._deficon; if (i != null && i instanceof ImageIcon) { ImageIcon newIcon = getAdjustedImageIcon((ImageIcon)i, ratio); if (newIcon != null) super.setIcon(newIcon);  }  Icon di = this._defdisabledicon; if (di != null && di instanceof ImageIcon) { ImageIcon newIcon = getAdjustedImageIcon((ImageIcon)di, ratio); if (newIcon != null) super.setDisabledIcon(newIcon);  }  } private static HashMap<ImageIcon, HashMap<String, ImageIcon>> _iconMap = null; private String[] _password_dialog_id; private String _label_name_program; private MCBeansUtil.HTMLTextInfo _html_text_info; private Font _font; private Font _multiline_font; private boolean _drop_enable; protected boolean _isVisibleForMode; protected boolean _isVisibleForPersonalize; boolean _isAnytimeFAction; public boolean isAnytimeFAction() { return this._isAnytimeFAction; }
/*      */   private final ImageIcon getAdjustedImageIcon(ImageIcon c, int ratio) { if (_iconMap == null) _iconMap = new HashMap<>();  HashMap<String, ImageIcon> _map = null; String _sizeKey = "" + ratio; if (_iconMap.containsKey(c)) { _map = _iconMap.get(c); if (_map.containsKey(_sizeKey)) { ImageIcon _icon = _map.get(_sizeKey); if (_icon != null) return _icon;  }  } else { _map = new HashMap<>(); _iconMap.put(c, _map); }  ImageIcon newIcon = null; int w = c.getIconWidth() * ratio / 100; int h = c.getIconHeight() * ratio / 100; Image img = c.getImage().getScaledInstance(w, h, 4); if (this._iconsupplier == null) { newIcon = new ImageIcon(img); } else { newIcon = this._iconsupplier.createIcon(img); }  _map.put(_sizeKey, newIcon); return newIcon; }
/*      */   private final Dimension getIconSize(Icon icon) { return MCBeansUtil.getIconPreferredSize(this, icon, getBorderInsets()); }
/*      */   private final Insets getBorderInsets() { Border b = getBorder(); if (b != null) { Insets i = b.getBorderInsets(this); return new Insets(i.top + 2, i.left + 2, i.bottom + 2, i.right + 2); }  return new Insets(2, 2, 2, 2); }
/*      */   public void setIcon(String key) { Icon i = MCBeansUtil.get((MCResourceBeans)this, key); if (i != null) { setIcon(i); this._icon_key = key; } else { handleIconError(); }  }
/* 3163 */   public void setGroup(String aGroup) { this._group = aGroup; initResource(); resetBorder(); getDelegate().removeAllModeInfoList(this); setMode(getMode()); } public void setIconPath(String path) { Icon i = MCBeansUtil.getFromPath((MCResourceBeans)this, path); if (i != null) { setIcon(i); this._icon_key = path; } else { handleIconError(); }  } private final void handleIconError() { this._icon_err = true; setText(getMessageByLocale()); } public void setPasswordDialog(String module, String screen) { if (MCStringUtil.containsNull(new String[] { module, screen })) { this._password_dialog_id = null; } else { this._password_dialog_id = new String[] { module, screen }; }  } public String[] getPasswordDialogID() { return (this._password_dialog_id != null) ? this._password_dialog_id : MCBeansUtil.getPasswordDialogID(getBaseRootPanel()); } public String getACType() { return this._ac_type; } public boolean isEnabled() { return super.isEnabled() ? authorize() : false; } public boolean checkAC() { return authorize() ? (needsPassword() ? checkPassword() : true) : false; } public boolean authorize() { if (MCBeansUtil.isACTypeDisable(this)) return true;  return MCBeansUtil.authorize(this); } public boolean needsPassword() { if (MCBeansUtil.isACTypeDisable(this)) return false;  return MCBeansUtil.needsPassword(this); } public boolean checkPassword() { return MCBeansUtil.checkPassword(this); } public boolean equalsIgnoreCase(Component compo) { return equals(compo); } public void setFocusedForeground(Color color) { this._focused_foreground = color; } public Color getFocusedForeground() { return this._focused_foreground; } public void setFocusedBackground(Color color) { this._focused_background = color; } public Color getFocusedBackground() { return this._focused_background; } public MCModeInfo getModeInfo() { return getModeInfo(getMode()); } public MCModeInfo getModeInfo(MCMode mode) { return getDelegate().getModeInfo(this, mode); } public void initialized() { if (this._icon_err) { setText(getMessageByLocale()); this._icon_err = false; }  if (this._default_ratio_bounds == null) this._default_ratio_bounds = getBounds();  if (this._default_font == null) this._default_font = getFont();  this._init_panel = MCBeansUtil.getRootPanel(this); setDndResourceInfo(); MCRootPanel bp = getBaseRootPanel(); if (bp != null) { String itemid = MCBeansUtil.createGUIKey(this); setReadOnlyFlg(MCACLManager.isReadOnly(bp.getModuleID(), bp.getScreenID(), itemid)); }  } public boolean doAction() { return false; } private final MCBeansDelegate getDelegate() { if (this._beans_delegate == null) this._beans_delegate = new MCBeansDelegate();  return this._beans_delegate; } public final void addAliasName(String alias, MCRootPanel panel) { getDelegate().addAliasName(alias, panel); } public final void setAliasName(String alias, MCRootPanel panel) { getDelegate().setAliasName(alias, panel); } public final void removeAliasName(MCRootPanel panel) { getDelegate().removeAliasName(panel); } public final void removeAliasNames() { getDelegate().removeAliasNames(); } public final String getAliasName(MCRootPanel panel) { return getDelegate().getAliasName(panel); } public final String[] getAliasNames() { return getDelegate().getAliasNames(); } public void enableInputMethods(boolean enable) { super.enableInputMethods(false); } public void updateBounds(int ratio) { MCBeansUtil.updateBounds(this, ratio, this._default_ratio_bounds); updateBorderTickness(ratio); adjustImageIcon(ratio); } public void updateFontSize(int ratio) { if (MCBeansUtil.isEnableMultilineFont(this._multiline_font, this._label_name_program)) { MCBeansUtil.updateFontSize(this, ratio, this._multiline_font); } else { MCBeansUtil.updateFontSize(this, ratio, this._default_font); }  String p = this._label_name_program; if (!MCStringUtil.isNull(p) && MCStringUtil.convertToLF(p).contains("\n")) { Color fg = getForeground(); if (!getModel().isEnabled() && getUI() instanceof MCMetalButtonUI) fg = ((MCMetalButtonUI)getUI()).getDisabledTextColor();  super.setText(MCBeansUtil.toHTMLText((MCBeans)this, p, fg, ratio, getHTMLTextInfo())); }  updateBorderTickness(ratio); } private void updateBorderTickness(int ratio) { Border b = getBorder(); if (b instanceof MCButtonLineBorder) { MCButtonLineBorder bl = (MCButtonLineBorder)b; bl.setRatio(ratio); }  } public final MCTabOrderBeans getNextBeans() { return getDelegate().getNextBeans(); } public final void setNextBeans(MCTabOrderBeans compo, int updateType) { getDelegate().setNextBeans(this, compo, updateType); } public final void setNextBeans(MCTabOrderBeans compo) { getDelegate().setNextBeans(this, compo, 0); } public final void insertNextBeans(MCTabOrderBeans compo, int updateType) { getDelegate().insertNextBeans(this, compo, updateType); } public final void insertNextBeans(MCTabOrderBeans compo) { getDelegate().insertNextBeans(this, compo, 0); } public final void insertPreviousBeans(MCTabOrderBeans compo, int updateType) { getDelegate().insertPreviousBeans(this, compo, updateType); } public final void insertPreviousBeans(MCTabOrderBeans compo) { getDelegate().insertPreviousBeans(this, compo, 0); } public final MCTabOrderBeans getPreviousBeans() { return getDelegate().getPreviousBeans(); } @Deprecated public final void setPreviousBeans(MCTabOrderBeans compo) { getDelegate().setPreviousBeans(this, compo); } @Deprecated public boolean isFocusableByKeybord() { return (isVisible() && isEnabled() && isFocusable()); } public MCMode getMode(MCRootPanel panel, String status) { return getDelegate().getMode(panel, status); } public String[] getStatuses(MCRootPanel panel) { return getDelegate().getStatuses(panel); } public void putMode(MCRootPanel panel, String status, MCMode mode) { getDelegate().putMode(panel, status, mode); } public void setMode(MCRootPanel panel, String status) { setMode(getMode(panel, status)); } public final boolean isTabOrderEnabled() { return getDelegate().isTabOrderEnabled(); } @Deprecated public final void setTabOrderEnabled(boolean enabled) { getDelegate().setTabOrderEnabled(enabled); } public String getAPMethodName() { return this._ap_method_name; } public void setAPMethodName(String name) { this._ap_method_name = name; } public Dimension getDefaultSize() { Rectangle a = this._default_ratio_bounds; int w = (a != null) ? a.width : getWidth(); int h = (a != null) ? a.height : getHeight(); return new Dimension(w, h); } public Rectangle getDefaultBounds() { Rectangle a = this._default_ratio_bounds; return (a != null) ? a : bounds(); } public void setDefaultRatioSize(Rectangle r) { this._default_ratio_bounds = r; } @Deprecated public JComponent getTargetComponent() { return this; } public void setMessageName(String name) { this._message_name = MCBeansUtil.adjustMessageName(name); setMCToolTipText((this._message_name != null) ? this._message_name : this._message_name_resource); } @Deprecated public String _getMessageName() { return this._message_name; } public void setFocusable(boolean focusable) { super.setFocusable(focusable); MCBeansUtil.setFocusableAfter(this, focusable); } void writeButtonActionLog(boolean start) { MCRootPanel p = getBaseRootPanel(); if (p == null) return;  MCLog.write(start ? Core_Msg.FCBAC0223 : Core_Msg.FCBAC0224, new Object[] { p.getModuleID(), p.getScreenID(), p.getScreenName(), getName(), getMessageByLocale() }); } public void setText(String text) { if (MCStringUtil.isNull(text) || !MCStringUtil.convertToLF(text).contains("\n")) { this._label_name_program = text; super.setText(text); } else { this._label_name_program = text; Color fg = getForeground(); if (!getModel().isEnabled() && getUI() instanceof MCMetalButtonUI) fg = ((MCMetalButtonUI)getUI()).getDisabledTextColor();  super.setText(MCBeansUtil.toHTMLText((MCBeans)this, text, fg, getHTMLTextInfo())); }  adjustFont(); resetBorder(); } @Deprecated public String getText() { return super.getText(); } void setDefaultFont(Font f) { this._default_font = f; } public Font getDefaultFont() { return this._default_font; } public void _resetDefaultFont() { this._default_font = getFont(); } private MCBeansUtil.HTMLTextInfo getHTMLTextInfo() { return (this._html_text_info != null) ? this._html_text_info : (this._html_text_info = new MCBeansUtil.HTMLTextInfo()); } public void setFont(Font font) { if (MCBeansUtil.isEnableMultilineFont(this._multiline_font, this._label_name_program)) { super.setFont(this._multiline_font); } else { super.setFont(font); }  this._font = font; } public void setMultilineFont(Font font) { this._multiline_font = font; } private void adjustFont() { Font f = this._font; if (MCBeansUtil.isEnableMultilineFont(this._multiline_font, this._label_name_program)) f = this._multiline_font;  if (f != null) { MCRootPanel p = getBaseRootPanel(); if (p != null) { if (!"GC_Button".equals(getName())) MCBeansUtil.updateFontSize(this, p.getFontRatio(), f);  } else { _setFont(f); }  }  } void _setFont(Font font) { super.setFont(font); } public MCPopupMenu configurePopup() { MCPopupMenu m = configurePopup(getComponentPopupMenu()); if (m != null) m.sort();  return m; } protected MCPopupMenu configurePopup(MCPopupMenu menu) { MCPopupConfig pc = getPopupConfig(); return menu = (pc != null) ? pc.configurePopup(menu, this) : menu; } public void popupMenuWillBecomeVisible() {} public void popupMenuWillBecomeInvisible() {} public void setPopupConfig(MCPopupConfig config) { this._popup_config = config; } public MCPopupConfig getPopupConfig() { return this._popup_config; } @Deprecated public void setComponentPopupMenu(JPopupMenu popup) { super.setComponentPopupMenu(popup); } public void setComponentPopupMenu(MCPopupMenu popup) { super.setComponentPopupMenu((JPopupMenu)popup); } public void removeComponentPopupMenu() { setComponentPopupMenu(null); } public MCPopupMenu getComponentPopupMenu() { return (MCPopupMenu)super.getComponentPopupMenu(); } public void setFDListener(MCFDListener listener) { setFDListener("ALL", listener); } public void setFDListener(String extension, MCFDListener listener) { this._event_list.set(extension, listener); } public void addFDListener(MCFDListener listener) { addFDListener("ALL", listener); } public void addFDListener(String extension, MCFDListener listener) { this._event_list.add(extension, listener); } public void removeFDListener(MCFDListener listener) { removeFDListener("ALL", listener); } public void removeFDListener(String extension, MCFDListener listener) { this._event_list.remove(extension, listener); } public boolean canFD(TransferHandler.TransferSupport support) { if (!this._drop_enable) return false;  if (getComponentPopupMenu() != null) configurePopup();  for (List<MCFDListener> list : (Iterable<List<MCFDListener>>)this._event_list.fd().values()) { for (MCFDListener l : list) { if (l.canFDEvent()) return true;  }  }  return false; } public void doFD() { MCBeansUtil.fd(this, this._event_list.fd()); } private void setDndResourceInfo() { if (!this._drop_enable) return;  if (getComponentPopupMenu() != null) configurePopup();  if (!this._event_list.fd().isEmpty()) return;  MCBeansUtil.setDndResourceInfo(this); } public boolean isVisibleForPersonalize() { return this._isVisibleForPersonalize; } public boolean isVisibleForMode() { return this._isVisibleForMode; } public void setVisibleForLayout(boolean b) { super.setVisible(b); } public void setVisibleForPersonalize(boolean b) { this._isVisibleForPersonalize = b; } public void setVisible(boolean flag) { this._isVisibleForMode = flag; if (!this._isVisibleForPersonalize) { super.setVisible(false); } else { super.setVisible(flag); }  } @Deprecated void setAnytimeFAction(boolean isAnytimeFAction) { this._isAnytimeFAction = isAnytimeFAction; }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Icon getDefIcon() {
/* 3169 */     return this._deficon;
/*      */   }
/*      */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\META-INF\versions\21\mcframe\clientCore\beans\MCButton.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */