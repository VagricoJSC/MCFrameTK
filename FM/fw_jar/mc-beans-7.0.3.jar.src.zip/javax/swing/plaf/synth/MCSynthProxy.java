/*     */ package javax.swing.plaf.synth;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import javax.swing.JComponent;
/*     */ import mcframe.commonCore.sys.MCFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MCSynthProxy
/*     */ {
/*     */   public static SynthStyle SynthLookAndFeel_updateStyle(SynthContext context, SynthUI ui) {
/*  25 */     Class[] types = {
/*  26 */         SynthContext.class, 
/*  27 */         SynthUI.class
/*     */       };
/*  29 */     Object[] args = {
/*  30 */         context, 
/*  31 */         ui
/*     */       };
/*  33 */     return (SynthStyle)MCFactory.invokeStatic(SynthLookAndFeel.class, "updateStyle", types, args);
/*     */   }
/*     */   
/*     */   public static int SynthLookAndFeel_getComponentState(JComponent c) {
/*  37 */     Class[] types = {
/*  38 */         Component.class
/*     */       };
/*  40 */     Object[] args = {
/*  41 */         c
/*     */       };
/*  43 */     Integer i = (Integer)MCFactory.invokeStatic(SynthLookAndFeel.class, "getComponentState", types, args);
/*  44 */     return i.intValue();
/*     */   }
/*     */   
/*     */   public static Region SynthLookAndFeel_getRegion(JComponent c) {
/*  48 */     Class[] types = {
/*  49 */         JComponent.class
/*     */       };
/*  51 */     Object[] args = {
/*  52 */         c
/*     */       };
/*  54 */     return (Region)MCFactory.invokeStatic(SynthLookAndFeel.class, "getRegion", types, args);
/*     */   }
/*     */   
/*     */   public static void SynthLookAndFeel_update(SynthContext context, Graphics g) {
/*  58 */     Class[] types = {
/*  59 */         SynthContext.class, 
/*  60 */         Graphics.class
/*     */       };
/*  62 */     Object[] args = {
/*  63 */         context, 
/*  64 */         g
/*     */       };
/*  66 */     MCFactory.invokeStatic(SynthLookAndFeel.class, "update", types, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SynthContext SynthContext_getContext(Class<?> type, JComponent component, Region region, SynthStyle style, int state) {
/*  78 */     Class[] types = {
/*  79 */         Class.class, 
/*  80 */         JComponent.class, 
/*  81 */         Region.class, 
/*  82 */         SynthStyle.class, 
/*  83 */         int.class
/*     */       };
/*  85 */     Object[] args = {
/*  86 */         SynthContext.class, 
/*  87 */         component, 
/*  88 */         region, 
/*  89 */         style, 
/*  90 */         Integer.valueOf(state)
/*     */       };
/*  92 */     return (SynthContext)MCFactory.invokeStatic(SynthContext.class, "getContext", types, args);
/*     */   }
/*     */   
/*     */   public static void SynthContext_dispose(SynthContext context) {
/*  96 */     Class[] types = new Class[0];
/*     */     
/*  98 */     Object[] args = new Object[0];
/*     */     
/* 100 */     MCFactory.invoke(context, "dispose", types, args);
/*     */   }
/*     */   
/*     */   public static SynthPainter SynthContext_getPainter(SynthContext context) {
/* 104 */     Class[] types = new Class[0];
/*     */     
/* 106 */     Object[] args = new Object[0];
/*     */     
/* 108 */     return (SynthPainter)MCFactory.invoke(context, "getPainter", types, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Region new_Region(String name, String ui, boolean subregion) {
/* 118 */     Class[] types = {
/* 119 */         String.class, 
/* 120 */         String.class, 
/* 121 */         boolean.class
/*     */       };
/* 123 */     Object[] args = {
/* 124 */         name, 
/* 125 */         ui, 
/* 126 */         Boolean.valueOf(subregion)
/*     */       };
/* 128 */     return (Region)MCFactory.create(Region.class, types, args);
/*     */   }
/*     */ }


/* Location:              C:\Work\PJ\TK\dev\FM\fw_jar\mc-beans-7.0.3.jar!\javax\swing\plaf\synth\MCSynthProxy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */