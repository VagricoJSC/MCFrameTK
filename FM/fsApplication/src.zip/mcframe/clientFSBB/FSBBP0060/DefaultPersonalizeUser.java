package mcframe.clientFSBB.FSBBP0060;

import mcframe.clientCore.resource.MCUserInfo;
import mcframe.clientCore.sys.MCSys;
import mcframe.commonFX.constant.FXC_RESOURCE_SETTING_UNIT;

/**
 * パーソナライズユーザとしてログインユーザを渡します。
 */
public class DefaultPersonalizeUser implements FSBBP0060_PersonalizeUser {

	@Override
	public MCUserInfo getExportUserInfo() {
		MCUserInfo info = new MCUserInfo();
		info.userid(getExportUser());
		return info;
	}

	@Override
	public MCUserInfo[] getImportUserInfoArray() {
		String[] users = getImportUserArray();
		if (users == null) {
			return new MCUserInfo[0];
		}

		MCUserInfo[] infos = new MCUserInfo[users.length];
		for (int i = 0; i < infos.length; i++) {
			MCUserInfo info = new MCUserInfo();
			info.userid(users[i]);
			infos[i] = info;
		}

		return infos;
	}

	@Override
	public FXC_RESOURCE_SETTING_UNIT getSettingUnit() {
		return FXC_RESOURCE_SETTING_UNIT.TYPE_USER;
	}

	/**
	 * エクスポートするユーザ名を返します。
	 *
	 * @return エクスポートするユーザ名
	 */
	protected String getExportUser() {
		return MCSys.user.ID();
	}

	/**
	 * インポートするユーザ名を配列にして返します。
	 *
	 * @return インポートするユーザ名の配列
	 */
	protected String[] getImportUserArray() {
		return new String[] {
				MCSys.user.ID()
		};
	}

}
