package mcframe.clientFSBB.FSBBP0060;

import mcframe.clientCore.resource.MCUserInfo;
import mcframe.commonFX.constant.FXC_RESOURCE_SETTING_UNIT;

/**
 * パーソナライズ入出力部品に作業対象のユーザ情報を渡すインターフェイスです。
 */
public interface FSBBP0060_PersonalizeUser {

	/**
	 * エクスポートするユーザの情報を返します。
	 *
	 * @return エクスポートするユーザの情報
	 */
	public MCUserInfo getExportUserInfo();

	/**
	 * インポートするユーザ情報を配列にして返します。
	 *
	 * @return インポートするユーザ情報の配列
	 */
	public MCUserInfo[] getImportUserInfoArray();

	/**
	 * リソースの設定単位を返します。
	 *
	 * @return リソースの設定単位
	 */
	public FXC_RESOURCE_SETTING_UNIT getSettingUnit();

}
