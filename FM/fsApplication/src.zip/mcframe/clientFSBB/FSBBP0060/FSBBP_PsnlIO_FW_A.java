package mcframe.clientFSBB.FSBBP0060;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBBP_PsnlIO"パネルクラスです。<p>
 *
 * ライセンス割当を変更する画面です。<br>
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBBP_PsnlIO_FW_A extends mcframe.clientFSUC.FSUCP0000.FSUCP_PanelBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBB";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBBP0060";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Psnl]ブロック関連のField定義
	public MCPanel PsnlPanel = null;
	// [Psnl]ブロックの項目のField定義
	/**
	 *  インポート.<p>
	 *
	 */
	public MCButton Psnl_imp = null;
	/**
	 *  エクスポート.<p>
	 *
	 */
	public MCButton Psnl_exp = null;
	/** [ENABLE]モードを表す定数 */
	public static final String ENABLE = "ENABLE";
	/** [DISABLE]モードを表す定数 */
	public static final String DISABLE = "DISABLE";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{ENABLE, DISABLE};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(PsnlPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBBP_PsnlIO_FW_A() {

	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBBP_PsnlIO_FW.jbCreatePsnl((FSBBP_PsnlIO)this);
	}

	/**
	 * [Psnl]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreatePsnl(FSBBP_PsnlIO p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}


	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBBP_PsnlIO create(){
		FSBBP_PsnlIO p = new FSBBP_PsnlIO();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}


	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBBP_PsnlIO_FW.jbfInitPsnl((FSBBP_PsnlIO)this);
		FSBBP_PsnlIO_FW.jbInitPsnl((FSBBP_PsnlIO)this);
	}

	/**
	 * [Psnl]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitPsnl(FSBBP_PsnlIO p) {
		// ブロック関連の初期化
		p.PsnlPanel = p.beansFactory.createPanel("Psnl");
		// ブロックの項目の初期化
		p.Psnl_imp = p.beansFactory.createButton("Psnl.imp");
		p.Psnl_exp = p.beansFactory.createButton("Psnl.exp");
	}

	/**
	 * [Psnl]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitPsnl(FSBBP_PsnlIO p) {
		// ブロック関連の初期化
		p.add(p.PsnlPanel);
		p.setLastBeans(p.PsnlPanel);
		p.PsnlPanel.setValueCheck(false);
		// ブロックの項目の初期化
		p.Psnl_imp.setFunctionKey(MCFunctionKey.F19);
		p.PsnlPanel.add(p.Psnl_imp);
		p.PsnlPanel.setLastBeans(p.Psnl_imp);
		p.Psnl_imp.setNextBeans(p.Psnl_exp);
		p.Psnl_exp.setFunctionKey(MCFunctionKey.F20);
		p.PsnlPanel.add(p.Psnl_exp);
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBBP_PsnlIO_FW.mcInitPsnl((FSBBP_PsnlIO)this);

		// [ENABLE]ステータスのモードの設定
		FSBBP_PsnlIO_FW.statusInitENABLE_Psnl((FSBBP_PsnlIO)this);

		// [DISABLE]ステータスのモードの設定
		FSBBP_PsnlIO_FW.statusInitDISABLE_Psnl((FSBBP_PsnlIO)this);

	}

	/**
	 *  [Psnl]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitPsnl(FSBBP_PsnlIO p) {
		p.Psnl_imp.addAllListener(p);
		p.Psnl_imp.setAPMethodName("doPsnl_imp");
		p.Psnl_exp.addAllListener(p);
		p.Psnl_exp.setAPMethodName("doPsnl_exp");
	}

	/**
	 * [ENABLE]ステータスの[Psnl]ブロックのモードの設定
	 */
	protected static void statusInitENABLE_Psnl(FSBBP_PsnlIO p){
		p.Psnl_imp.putMode(p, ENABLE, MCMode.ENABLE);
		p.Psnl_exp.putMode(p, ENABLE, MCMode.ENABLE);

	}

	/**
	 * [DISABLE]ステータスの[Psnl]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_Psnl(FSBBP_PsnlIO p){
		p.Psnl_imp.putMode(p, DISABLE, MCMode.DISABLE);
		p.Psnl_exp.putMode(p, DISABLE, MCMode.DISABLE);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return ENABLE;
	}

	/**
	 * Table/Treeの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
	}

	/**
	 * この画面を[ENABLE]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setENABLEStatus() {
		status = ENABLE;
		setAllStatus(status);
	}

	/**
	 * この画面を[DISABLE]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setDISABLEStatus() {
		status = DISABLE;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (ENABLE.equals(status)) {
			setENABLEStatus();
		}
		else if (DISABLE.equals(status)) {
			setDISABLEStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}


	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == Psnl_imp) doPsnl_imp(info);
		else if (ap == Psnl_exp) doPsnl_exp(info);
	}

	/**
	 * [Psnl]パネルの[imp]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doPsnl_imp(MCEventInfo info);

	/**
	 * [Psnl]パネルの[exp]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doPsnl_exp(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}