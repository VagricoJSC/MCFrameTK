package mcframe.clientFSBB.FSBBP0060;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;


import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START

//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBBP_PsnlIO"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBBP_PsnlIO_FW extends FSBBP_PsnlIO_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	/**
	 * パーソナライズ入出力の対象ユーザを返すオブジェクトです。
	 */
	private FSBBP0060_PersonalizeUser _puser;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBBP_PsnlIO_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * Panel[Psnl]のボタン[imp]の押下時の処理
	 */
	@Override
	public void doPsnl_imp(MCEventInfo info) {
		openModalPanel("FS", "FSBBP0110", T2, null, _puser);
	}

	/**
	 * Panel[Psnl]のボタン[exp]の押下時の処理
	 */
	@Override
	public void doPsnl_exp(MCEventInfo info) {
		openModalPanel("FS", "FSBBP0110", T1, null, _puser);
	}

	/**
	 * 入出力対象のユーザ情報を返すオブジェクトを設定します。
	 *
	 * @param pu 入出力対象のユーザ情報を返すオブジェクト
	 */
	public void setPersonalizeUser(FSBBP0060_PersonalizeUser pu) {
		_puser = pu;
	}

}