package mcframe.clientFSBB.FSBBP0070;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"NetConf"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class NetConfR_FW_A extends MCConstRow {

	/**
	 *  送信リトライ回数.<p>
	 *
	 */
	public static final String $retry = "retry";
	/**
	 *  リトライデフォルト.<p>
	 *
	 */
	public static final String $retry_def = "retry_def";
	/**
	 *  タイムアウト（ミリ秒）.<p>
	 *
	 */
	public static final String $receive_timeout = "receive_timeout";
	/**
	 *  タイムアウト（ミリ秒）デフォルト.<p>
	 *
	 */
	public static final String $receive_timeout_def = "receive_timeout_def";
	/**
	 *  送信上限量.<p>
	 *
	 */
	public static final String $ulLimitSize = "ulLimitSize";
	/**
	 *  送信上限量無制限.<p>
	 *
	 */
	public static final String $ulLimitSize_unlimit = "ulLimitSize_unlimit";
	/**
	 *  受信上限量.<p>
	 *
	 */
	public static final String $limitSize = "limitSize";
	/**
	 *  受信上限量無制限.<p>
	 *
	 */
	public static final String $limitSize_unlimit = "limitSize_unlimit";


	public static final MCMeta retry_META = createNumberMeta($retry, 5, 0, false);
	public static final MCMeta retry_def_META = createCommonMeta($retry_def, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta receive_timeout_META = createNumberMeta($receive_timeout, 10, 0, false);
	public static final MCMeta receive_timeout_def_META = createCommonMeta($receive_timeout_def, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta ulLimitSize_META = createNumberMeta($ulLimitSize, 10, 0, false);
	public static final MCMeta ulLimitSize_unlimit_META = createCommonMeta($ulLimitSize_unlimit, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta limitSize_META = createNumberMeta($limitSize, 10, 0, false);
	public static final MCMeta limitSize_unlimit_META = createCommonMeta($limitSize_unlimit, mcframe.commonCore.meta.M_META.FLG);

	protected static final ConstMetaList<NetConfR> constMetas = new ConstMetaList<NetConfR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			retry_META,
			retry_def_META,
			receive_timeout_META,
			receive_timeout_def_META,
			ulLimitSize_META,
			ulLimitSize_unlimit_META,
			limitSize_META,
			limitSize_unlimit_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected NetConfR_FW_A(ConstMetaList<? extends NetConfR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public NetConfR clone() {
		return (NetConfR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public NetConfR createInstance() {
		return (NetConfR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public NetConfR getValues(String... names) {
		return (NetConfR) super.getValues(names);
	}



	/**
	 *  送信リトライ回数.<p>
	 *
	 */
	public MCNumber retry() {
		return getConstNumber(offset + 0, $retry);
	}

	/**
	 *  送信リトライ回数.<p>
	 *
	 */
	public void retry(MCNumber value) {
		setConstNumber(offset + 0, $retry, value);
	}

	/**
	 *  送信リトライ回数.<p>
	 *
	 */
	public void retry(int value) {
		setConstNumber(offset + 0, $retry, value);
	}

	/**
	 *  送信リトライ回数.<p>
	 *
	 */
	public void retry(long value) {
		setConstNumber(offset + 0, $retry, value);
	}

	/**
	 *  送信リトライ回数.<p>
	 *
	 */
	public void retry(float value) {
		setConstNumber(offset + 0, $retry, value);
	}

	/**
	 *  送信リトライ回数.<p>
	 *
	 */
	public void retry(double value) {
		setConstNumber(offset + 0, $retry, value);
	}


	/**
	 *  リトライデフォルト.<p>
	 *
	 */
	public boolean retry_def() {
		return getConstBoolean(offset + 1, $retry_def);
	}

	/**
	 *  リトライデフォルト.<p>
	 *
	 */
	public void retry_def(boolean value) {
		setConstBoolean(offset + 1, $retry_def, value);
	}


	/**
	 *  タイムアウト（ミリ秒）.<p>
	 *
	 */
	public MCNumber receive_timeout() {
		return getConstNumber(offset + 2, $receive_timeout);
	}

	/**
	 *  タイムアウト（ミリ秒）.<p>
	 *
	 */
	public void receive_timeout(MCNumber value) {
		setConstNumber(offset + 2, $receive_timeout, value);
	}

	/**
	 *  タイムアウト（ミリ秒）.<p>
	 *
	 */
	public void receive_timeout(int value) {
		setConstNumber(offset + 2, $receive_timeout, value);
	}

	/**
	 *  タイムアウト（ミリ秒）.<p>
	 *
	 */
	public void receive_timeout(long value) {
		setConstNumber(offset + 2, $receive_timeout, value);
	}

	/**
	 *  タイムアウト（ミリ秒）.<p>
	 *
	 */
	public void receive_timeout(float value) {
		setConstNumber(offset + 2, $receive_timeout, value);
	}

	/**
	 *  タイムアウト（ミリ秒）.<p>
	 *
	 */
	public void receive_timeout(double value) {
		setConstNumber(offset + 2, $receive_timeout, value);
	}


	/**
	 *  タイムアウト（ミリ秒）デフォルト.<p>
	 *
	 */
	public boolean receive_timeout_def() {
		return getConstBoolean(offset + 3, $receive_timeout_def);
	}

	/**
	 *  タイムアウト（ミリ秒）デフォルト.<p>
	 *
	 */
	public void receive_timeout_def(boolean value) {
		setConstBoolean(offset + 3, $receive_timeout_def, value);
	}


	/**
	 *  送信上限量.<p>
	 *
	 */
	public MCNumber ulLimitSize() {
		return getConstNumber(offset + 4, $ulLimitSize);
	}

	/**
	 *  送信上限量.<p>
	 *
	 */
	public void ulLimitSize(MCNumber value) {
		setConstNumber(offset + 4, $ulLimitSize, value);
	}

	/**
	 *  送信上限量.<p>
	 *
	 */
	public void ulLimitSize(int value) {
		setConstNumber(offset + 4, $ulLimitSize, value);
	}

	/**
	 *  送信上限量.<p>
	 *
	 */
	public void ulLimitSize(long value) {
		setConstNumber(offset + 4, $ulLimitSize, value);
	}

	/**
	 *  送信上限量.<p>
	 *
	 */
	public void ulLimitSize(float value) {
		setConstNumber(offset + 4, $ulLimitSize, value);
	}

	/**
	 *  送信上限量.<p>
	 *
	 */
	public void ulLimitSize(double value) {
		setConstNumber(offset + 4, $ulLimitSize, value);
	}


	/**
	 *  送信上限量無制限.<p>
	 *
	 */
	public boolean ulLimitSize_unlimit() {
		return getConstBoolean(offset + 5, $ulLimitSize_unlimit);
	}

	/**
	 *  送信上限量無制限.<p>
	 *
	 */
	public void ulLimitSize_unlimit(boolean value) {
		setConstBoolean(offset + 5, $ulLimitSize_unlimit, value);
	}


	/**
	 *  受信上限量.<p>
	 *
	 */
	public MCNumber limitSize() {
		return getConstNumber(offset + 6, $limitSize);
	}

	/**
	 *  受信上限量.<p>
	 *
	 */
	public void limitSize(MCNumber value) {
		setConstNumber(offset + 6, $limitSize, value);
	}

	/**
	 *  受信上限量.<p>
	 *
	 */
	public void limitSize(int value) {
		setConstNumber(offset + 6, $limitSize, value);
	}

	/**
	 *  受信上限量.<p>
	 *
	 */
	public void limitSize(long value) {
		setConstNumber(offset + 6, $limitSize, value);
	}

	/**
	 *  受信上限量.<p>
	 *
	 */
	public void limitSize(float value) {
		setConstNumber(offset + 6, $limitSize, value);
	}

	/**
	 *  受信上限量.<p>
	 *
	 */
	public void limitSize(double value) {
		setConstNumber(offset + 6, $limitSize, value);
	}


	/**
	 *  受信上限量無制限.<p>
	 *
	 */
	public boolean limitSize_unlimit() {
		return getConstBoolean(offset + 7, $limitSize_unlimit);
	}

	/**
	 *  受信上限量無制限.<p>
	 *
	 */
	public void limitSize_unlimit(boolean value) {
		setConstBoolean(offset + 7, $limitSize_unlimit, value);
	}


	public MCNumber getNumber(String name) {
		if ($retry.equalsIgnoreCase(name)) {
			return retry();
		}
		if ($receive_timeout.equalsIgnoreCase(name)) {
			return receive_timeout();
		}
		if ($ulLimitSize.equalsIgnoreCase(name)) {
			return ulLimitSize();
		}
		if ($limitSize.equalsIgnoreCase(name)) {
			return limitSize();
		}
		return super.getNumber(name);
	}
	public boolean getBoolean(String name) {
		if ($retry_def.equalsIgnoreCase(name)) {
			return retry_def();
		}
		if ($receive_timeout_def.equalsIgnoreCase(name)) {
			return receive_timeout_def();
		}
		if ($ulLimitSize_unlimit.equalsIgnoreCase(name)) {
			return ulLimitSize_unlimit();
		}
		if ($limitSize_unlimit.equalsIgnoreCase(name)) {
			return limitSize_unlimit();
		}
		return super.getBoolean(name);
	}

	public MCNumber getNumberNE(String name) {
		if ($retry.equalsIgnoreCase(name)) {
			return retry();
		}
		if ($receive_timeout.equalsIgnoreCase(name)) {
			return receive_timeout();
		}
		if ($ulLimitSize.equalsIgnoreCase(name)) {
			return ulLimitSize();
		}
		if ($limitSize.equalsIgnoreCase(name)) {
			return limitSize();
		}
		return super.getNumberNE(name);
	}
	public boolean getBooleanNE(String name) {
		if ($retry_def.equalsIgnoreCase(name)) {
			return retry_def();
		}
		if ($receive_timeout_def.equalsIgnoreCase(name)) {
			return receive_timeout_def();
		}
		if ($ulLimitSize_unlimit.equalsIgnoreCase(name)) {
			return ulLimitSize_unlimit();
		}
		if ($limitSize_unlimit.equalsIgnoreCase(name)) {
			return limitSize_unlimit();
		}
		return super.getBooleanNE(name);
	}

	public void setNumber(String name, MCNumber value) {
		if ($retry.equalsIgnoreCase(name)) {
			retry(value);
			return;
		}
		if ($receive_timeout.equalsIgnoreCase(name)) {
			receive_timeout(value);
			return;
		}
		if ($ulLimitSize.equalsIgnoreCase(name)) {
			ulLimitSize(value);
			return;
		}
		if ($limitSize.equalsIgnoreCase(name)) {
			limitSize(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, int value) {
		if ($retry.equalsIgnoreCase(name)) {
			retry(value);
			return;
		}
		if ($receive_timeout.equalsIgnoreCase(name)) {
			receive_timeout(value);
			return;
		}
		if ($ulLimitSize.equalsIgnoreCase(name)) {
			ulLimitSize(value);
			return;
		}
		if ($limitSize.equalsIgnoreCase(name)) {
			limitSize(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, long value) {
		if ($retry.equalsIgnoreCase(name)) {
			retry(value);
			return;
		}
		if ($receive_timeout.equalsIgnoreCase(name)) {
			receive_timeout(value);
			return;
		}
		if ($ulLimitSize.equalsIgnoreCase(name)) {
			ulLimitSize(value);
			return;
		}
		if ($limitSize.equalsIgnoreCase(name)) {
			limitSize(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, float value) {
		if ($retry.equalsIgnoreCase(name)) {
			retry(value);
			return;
		}
		if ($receive_timeout.equalsIgnoreCase(name)) {
			receive_timeout(value);
			return;
		}
		if ($ulLimitSize.equalsIgnoreCase(name)) {
			ulLimitSize(value);
			return;
		}
		if ($limitSize.equalsIgnoreCase(name)) {
			limitSize(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, double value) {
		if ($retry.equalsIgnoreCase(name)) {
			retry(value);
			return;
		}
		if ($receive_timeout.equalsIgnoreCase(name)) {
			receive_timeout(value);
			return;
		}
		if ($ulLimitSize.equalsIgnoreCase(name)) {
			ulLimitSize(value);
			return;
		}
		if ($limitSize.equalsIgnoreCase(name)) {
			limitSize(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setBoolean(String name, boolean value) {
		if ($retry_def.equalsIgnoreCase(name)) {
			retry_def(value);
			return;
		}
		if ($receive_timeout_def.equalsIgnoreCase(name)) {
			receive_timeout_def(value);
			return;
		}
		if ($ulLimitSize_unlimit.equalsIgnoreCase(name)) {
			ulLimitSize_unlimit(value);
			return;
		}
		if ($limitSize_unlimit.equalsIgnoreCase(name)) {
			limitSize_unlimit(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setNumberNE(String name, MCNumber value) {
		if ($retry.equalsIgnoreCase(name)) {
			retry(value);
			return;
		}
		if ($receive_timeout.equalsIgnoreCase(name)) {
			receive_timeout(value);
			return;
		}
		if ($ulLimitSize.equalsIgnoreCase(name)) {
			ulLimitSize(value);
			return;
		}
		if ($limitSize.equalsIgnoreCase(name)) {
			limitSize(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, int value) {
		if ($retry.equalsIgnoreCase(name)) {
			retry(value);
			return;
		}
		if ($receive_timeout.equalsIgnoreCase(name)) {
			receive_timeout(value);
			return;
		}
		if ($ulLimitSize.equalsIgnoreCase(name)) {
			ulLimitSize(value);
			return;
		}
		if ($limitSize.equalsIgnoreCase(name)) {
			limitSize(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, long value) {
		if ($retry.equalsIgnoreCase(name)) {
			retry(value);
			return;
		}
		if ($receive_timeout.equalsIgnoreCase(name)) {
			receive_timeout(value);
			return;
		}
		if ($ulLimitSize.equalsIgnoreCase(name)) {
			ulLimitSize(value);
			return;
		}
		if ($limitSize.equalsIgnoreCase(name)) {
			limitSize(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, float value) {
		if ($retry.equalsIgnoreCase(name)) {
			retry(value);
			return;
		}
		if ($receive_timeout.equalsIgnoreCase(name)) {
			receive_timeout(value);
			return;
		}
		if ($ulLimitSize.equalsIgnoreCase(name)) {
			ulLimitSize(value);
			return;
		}
		if ($limitSize.equalsIgnoreCase(name)) {
			limitSize(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, double value) {
		if ($retry.equalsIgnoreCase(name)) {
			retry(value);
			return;
		}
		if ($receive_timeout.equalsIgnoreCase(name)) {
			receive_timeout(value);
			return;
		}
		if ($ulLimitSize.equalsIgnoreCase(name)) {
			ulLimitSize(value);
			return;
		}
		if ($limitSize.equalsIgnoreCase(name)) {
			limitSize(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setBooleanNE(String name, boolean value) {
		if ($retry_def.equalsIgnoreCase(name)) {
			retry_def(value);
			return;
		}
		if ($receive_timeout_def.equalsIgnoreCase(name)) {
			receive_timeout_def(value);
			return;
		}
		if ($ulLimitSize_unlimit.equalsIgnoreCase(name)) {
			ulLimitSize_unlimit(value);
			return;
		}
		if ($limitSize_unlimit.equalsIgnoreCase(name)) {
			limitSize_unlimit(value);
			return;
		}
		super.setBooleanNE(name, value);
	}



}

