package mcframe.clientFSBB.FSBBP0070;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;


import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.clientCore.resource.MCConfig;
import mcframe.clientCore.resource.MCConst;
import mcframe.commonCore.sys.MCExec;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBBP0070"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBBP0070_FW extends FSBBP0070_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START
	protected static final String RETRY_KEY = "net.request.retry";
	protected static final String RECEIVE_TIMEOUT_KEY = "net.request.receive_timeout";
	protected static final String REQ_LIMITSIZE_KEY = "net.request.limitSize";
	protected static final String RES_LIMITSIZE_KEY = "net.response.limitSize";
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBBP0070_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * Panel[NetConf]のボタン[inet_setting]の押下時の処理
	 */
	@Override
	public void doNetConf_inet_setting(MCEventInfo info) {
		String command = MCConst.app.getString("FS.FSBBP0020.inet_setting.command");
		if (command != null) {
			MCExec exec = new MCExec(command);
			exec.execute();
		}
	}

	@Override
	public void doNetConf_retry_def_NC(MCEventInfo info){
		super.doNetConf_retry_def_NC(info);
		setModeByFlg();
	}
	
	@Override
	public void doNetConf_receive_timeout_def_NC(MCEventInfo info){
		super.doNetConf_receive_timeout_def_NC(info);
		setModeByFlg();
	}
	
	@Override
	public void doNetConf_ulLimitSize_unlimit_NC(MCEventInfo info){
		super.doNetConf_ulLimitSize_unlimit_NC(info);
		setModeByFlg();
	}
	
	@Override
	public void doNetConf_limitSize_unlimit_NC(MCEventInfo info){
		super.doNetConf_limitSize_unlimit_NC(info);
		setModeByFlg();
	}
	
	@Override
	public void setINITStatus(){
		super.setINITStatus();
		setModeByFlg();
		NetConfPanel.focusFirstComponent();
	}
	
	protected void setModeByFlg() {
		if (getNetConfR().retry_def()) {
			NetConf_retry.setMode(MCMode.READ_ONLY);
		}
		else {
			NetConf_retry.setMode(this, getStatus());
		}
		
		if (getNetConfR().receive_timeout_def()) {
			NetConf_receive_timeout.setMode(MCMode.READ_ONLY);
		}
		else {
			NetConf_receive_timeout.setMode(this, getStatus());
		}
		
		if (getNetConfR().ulLimitSize_unlimit()) {
			NetConf_ulLimitSize.setMode(MCMode.READ_ONLY);
		}
		else {
			NetConf_ulLimitSize.setMode(this, getStatus());
		}
		
		if (getNetConfR().limitSize_unlimit()) {
			NetConf_limitSize.setMode(MCMode.READ_ONLY);
		}
		else {
			NetConf_limitSize.setMode(this, getStatus());
		}
	}

	@Override
	protected void valueInit() {
		super.valueInit();
		loadConfig();
	}

	/**
	 * 設定内容を読み込みます。<P>
	 */
	protected void loadConfig() {
		int retry = MCConfig.client.getInteger(RETRY_KEY);
		if (retry < 0) {
			getNetConfR().retry_def(true);
			getNetConfR().retry(null);
		}
		else {
			getNetConfR().retry_def(false);
			getNetConfR().retry(retry);
		}
		
		int receive_timeout = MCConfig.client.getInteger(RECEIVE_TIMEOUT_KEY);
		if (receive_timeout < 0) {
			getNetConfR().receive_timeout_def(true);
			getNetConfR().receive_timeout(null);
		}
		else {
			getNetConfR().receive_timeout_def(false);
			getNetConfR().receive_timeout(receive_timeout);
		}
		
		int ulLimitSize = MCConfig.client.getInteger(REQ_LIMITSIZE_KEY);
		if (ulLimitSize < 0) {
			getNetConfR().ulLimitSize_unlimit(true);
			getNetConfR().ulLimitSize(null);
		}
		else {
			getNetConfR().ulLimitSize_unlimit(false);
			getNetConfR().ulLimitSize(ulLimitSize);
		}
		
		int limitSize = MCConfig.client.getInteger(RES_LIMITSIZE_KEY);
		if (limitSize < 0) {
			getNetConfR().limitSize_unlimit(true);
			getNetConfR().limitSize(null);
		}
		else {
			getNetConfR().limitSize_unlimit(false);
			getNetConfR().limitSize(limitSize);
		}
		
		setModeByFlg();
	}
	
	@Override
	public void saveDfltConfig(MCMessageList msgList) {
		MCConfig.client.remove(RETRY_KEY);
		MCConfig.client.remove(RECEIVE_TIMEOUT_KEY);
		MCConfig.client.remove(REQ_LIMITSIZE_KEY);
		MCConfig.client.remove(RES_LIMITSIZE_KEY);
	}
	
	@Override
	public void saveUpdConfig(MCMessageList msgList) {
		MCNumber retry;
		if (getNetConfR().retry_def()) {
			retry = new MCNumber(-1);
		}
		else {
			retry = getNetConfR().retry();
		}
		
		MCNumber receive_timeout;
		if (getNetConfR().receive_timeout_def()) {
			receive_timeout = new MCNumber(-1);
		}
		else {
			receive_timeout = getNetConfR().receive_timeout();
		}
		
		MCNumber ulLimitSize;
		if (getNetConfR().ulLimitSize_unlimit()) {
			ulLimitSize = new MCNumber(-1);
		}
		else {
			ulLimitSize = getNetConfR().ulLimitSize();
		}
		
		MCNumber limitSize;
		if (getNetConfR().limitSize_unlimit()) {
			limitSize = new MCNumber(-1);
		}
		else {
			limitSize = getNetConfR().limitSize();
		}

		
		MCConfig.client.setInteger(RETRY_KEY, retry.intValue());
		MCConfig.client.setInteger(RECEIVE_TIMEOUT_KEY, receive_timeout.intValue());
		MCConfig.client.setInteger(REQ_LIMITSIZE_KEY, ulLimitSize.intValue());
		MCConfig.client.setInteger(RES_LIMITSIZE_KEY, limitSize.intValue());
	}
	
	@Override
	public boolean checkUpdConfig() {
		MCMessageList l = checkReq(getNetConfR());
		if (l.size() > 0) {
			message(l);
			return false;
		}
		return true;
	}

}