package mcframe.clientFSBB.FSBBP0070;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBBP0070"パネルクラスです。<p>
 *
 * 通信の環境設定画面です。<br>
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBBP0070_FW_A extends mcframe.clientFSBB.FSBBP0100.FSBBP_PartsBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBB";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBBP0070";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Main]ブロック関連のField定義
	// [Main]ブロックの項目のField定義
	// [NetConf]ブロック関連のField定義
	public MCPanel NetConfPanel = null;
	public MCTitledBorder NetConfTitledBorder = null;
	// [NetConf]ブロックの項目のField定義
	public MCLabel NetConf_retry_Label = null;
	/**
	 *  送信リトライ回数.<p>
	 *
	 */
	public MCNumberField NetConf_retry = null;
	/**
	 *  リトライデフォルト.<p>
	 *
	 */
	public MCCheckBox NetConf_retry_def = null;
	public MCLabel NetConf_receive_timeout_Label = null;
	/**
	 *  タイムアウト（ミリ秒）.<p>
	 *
	 */
	public MCNumberField NetConf_receive_timeout = null;
	/**
	 *  タイムアウト（ミリ秒）デフォルト.<p>
	 *
	 */
	public MCCheckBox NetConf_receive_timeout_def = null;
	public MCLabel NetConf_ulLimitSize_Label = null;
	/**
	 *  送信上限量.<p>
	 *
	 */
	public MCNumberField NetConf_ulLimitSize = null;
	/**
	 *  送信上限量無制限.<p>
	 *
	 */
	public MCCheckBox NetConf_ulLimitSize_unlimit = null;
	public MCLabel NetConf_limitSize_Label = null;
	/**
	 *  受信上限量.<p>
	 *
	 */
	public MCNumberField NetConf_limitSize = null;
	/**
	 *  受信上限量無制限.<p>
	 *
	 */
	public MCCheckBox NetConf_limitSize_unlimit = null;
	/**
	 *  インターネットの設定.<p>
	 *
	 */
	public MCButton NetConf_inet_setting = null;
	// [Blank]ブロック関連のField定義
	public MCPanel BlankPanel = null;
	// [Blank]ブロックの項目のField定義
	/** [INIT]モードを表す定数 */
	public static final String INIT = "INIT";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{INIT};
	
	/** [NetConf]ブロックのコンテナField定義 */
	private final mcframe.clientFSBB.FSBBP0070.NetConfR aNetConfR;

	/**
	 * 項目コピーによってaNetConfRを設定します。
	 *
	 * aNetConfRのインスタンスは変更されません。
	 *
	 * @param row NetConfR
	 */
	public void setNetConfR(mcframe.clientFSBB.FSBBP0070.NetConfR row) {
		if (row != null) {
			MCRow.copyall(getNetConfR(), row);
		}
	}

	/**
	 * [NetConf]ブロックのコンテナaNetConfRを返します。
	 *
	 * @return NetConfR
	 */
	public mcframe.clientFSBB.FSBBP0070.NetConfR getNetConfR() {
		return aNetConfR;
	}

	/**
	 * aNetConfRを作成します。
	 *
	 * @return NetConfR
	 */
	public mcframe.clientFSBB.FSBBP0070.NetConfR createNetConfR() {
		return mcframe.clientFSBB.FSBBP0070.NetConfR.create();
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getNetConfR())) ret.add(getNetConfR());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getNetConfR()) return "NetConf";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("NetConf")) return getNetConfR();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(NetConfPanel);
		ret.add(BlankPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBBP0070_FW_A() {
		aNetConfR = createNetConfR();

	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBBP0070_FW.jbCreateMain((FSBBP0070)this);
		FSBBP0070_FW.jbCreateNetConf((FSBBP0070)this);
		FSBBP0070_FW.jbCreateBlank((FSBBP0070)this);
	}

	/**
	 * [Main]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateMain(FSBBP0070 p) {
	}

	/**
	 * [NetConf]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateNetConf(FSBBP0070 p) {
	}

	/**
	 * [Blank]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateBlank(FSBBP0070 p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}


	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBBP0070 create(){
		FSBBP0070 p = new FSBBP0070();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}


	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBBP0070_FW.jbfInitMain((FSBBP0070)this);
		FSBBP0070_FW.jbfInitNetConf((FSBBP0070)this);
		FSBBP0070_FW.jbfInitBlank((FSBBP0070)this);
		FSBBP0070_FW.jbInitMain((FSBBP0070)this);
		FSBBP0070_FW.jbInitNetConf((FSBBP0070)this);
		FSBBP0070_FW.jbInitBlank((FSBBP0070)this);
	}

	/**
	 * [Main]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitMain(FSBBP0070 p) {
		// ブロック関連の初期化
		// ブロックの項目の初期化
	}

	/**
	 * [NetConf]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitNetConf(FSBBP0070 p) {
		// ブロック関連の初期化
		p.NetConfPanel = p.beansFactory.createPanel("NetConf");
		p.NetConfTitledBorder = p.beansFactory.createTitledBorder();
		// ブロックの項目の初期化
		p.NetConf_retry_Label = p.beansFactory.createLabel("NetConf.retry_Label");
		p.NetConf_retry = p.beansFactory.createNumberField("NetConf.retry");
		p.NetConf_retry.setLabel(p.NetConf_retry_Label);
		p.NetConf_retry_def = p.beansFactory.createCheckBox("NetConf.retry_def");
		p.NetConf_receive_timeout_Label = p.beansFactory.createLabel("NetConf.receive_timeout_Label");
		p.NetConf_receive_timeout = p.beansFactory.createNumberField("NetConf.receive_timeout");
		p.NetConf_receive_timeout.setLabel(p.NetConf_receive_timeout_Label);
		p.NetConf_receive_timeout_def = p.beansFactory.createCheckBox("NetConf.receive_timeout_def");
		p.NetConf_ulLimitSize_Label = p.beansFactory.createLabel("NetConf.ulLimitSize_Label");
		p.NetConf_ulLimitSize = p.beansFactory.createNumberField("NetConf.ulLimitSize");
		p.NetConf_ulLimitSize.setLabel(p.NetConf_ulLimitSize_Label);
		p.NetConf_ulLimitSize_unlimit = p.beansFactory.createCheckBox("NetConf.ulLimitSize_unlimit");
		p.NetConf_limitSize_Label = p.beansFactory.createLabel("NetConf.limitSize_Label");
		p.NetConf_limitSize = p.beansFactory.createNumberField("NetConf.limitSize");
		p.NetConf_limitSize.setLabel(p.NetConf_limitSize_Label);
		p.NetConf_limitSize_unlimit = p.beansFactory.createCheckBox("NetConf.limitSize_unlimit");
		p.NetConf_inet_setting = p.beansFactory.createButton("NetConf.inet_setting");
	}

	/**
	 * [Blank]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitBlank(FSBBP0070 p) {
		// ブロック関連の初期化
		p.BlankPanel = p.beansFactory.createPanel("Blank");
		// ブロックの項目の初期化
	}

	/**
	 * [Main]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitMain(FSBBP0070 p) {
		// ブロック関連の初期化
		p.MainPanel.setLayoutPosition("C+");
		// ブロックの項目の初期化
		p.MainPanel.add(p.NetConfPanel, null);
		p.MainPanel.setLastBeans(p.NetConfPanel);
		p.NetConfPanel.setNextBeans(p.BlankPanel);
		p.MainPanel.add(p.BlankPanel, null);
	}

	/**
	 * [NetConf]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitNetConf(FSBBP0070 p) {
		// ブロック関連の初期化
		p.NetConfPanel.setBorder(p.NetConfTitledBorder);
		p.NetConfPanel.setLayoutPosition("N");
		// ブロックの項目の初期化
		p.NetConfPanel.add(p.NetConf_retry_Label);
		p.NetConfPanel.add(p.NetConf_retry);
		p.NetConfPanel.setLastBeans(p.NetConf_retry);
		p.NetConf_retry.setNextBeans(p.NetConf_retry_def);
		p.NetConf_retry.setRow(p.getNetConfR(), mcframe.clientFSBB.FSBBP0070.NetConfR.retry_META);
		p.NetConfPanel.add(p.NetConf_retry_def);
		p.NetConf_retry_def.setNextBeans(p.NetConf_receive_timeout);
		p.NetConf_retry_def.setRow(p.getNetConfR(), mcframe.clientFSBB.FSBBP0070.NetConfR.retry_def_META);
		p.NetConfPanel.add(p.NetConf_receive_timeout_Label);
		p.NetConfPanel.add(p.NetConf_receive_timeout);
		p.NetConf_receive_timeout.setNextBeans(p.NetConf_receive_timeout_def);
		p.NetConf_receive_timeout.setRow(p.getNetConfR(), mcframe.clientFSBB.FSBBP0070.NetConfR.receive_timeout_META);
		p.NetConfPanel.add(p.NetConf_receive_timeout_def);
		p.NetConf_receive_timeout_def.setNextBeans(p.NetConf_ulLimitSize);
		p.NetConf_receive_timeout_def.setRow(p.getNetConfR(), mcframe.clientFSBB.FSBBP0070.NetConfR.receive_timeout_def_META);
		p.NetConfPanel.add(p.NetConf_ulLimitSize_Label);
		p.NetConfPanel.add(p.NetConf_ulLimitSize);
		p.NetConf_ulLimitSize.setNextBeans(p.NetConf_ulLimitSize_unlimit);
		p.NetConf_ulLimitSize.setRow(p.getNetConfR(), mcframe.clientFSBB.FSBBP0070.NetConfR.ulLimitSize_META);
		p.NetConfPanel.add(p.NetConf_ulLimitSize_unlimit);
		p.NetConf_ulLimitSize_unlimit.setNextBeans(p.NetConf_limitSize);
		p.NetConf_ulLimitSize_unlimit.setRow(p.getNetConfR(), mcframe.clientFSBB.FSBBP0070.NetConfR.ulLimitSize_unlimit_META);
		p.NetConfPanel.add(p.NetConf_limitSize_Label);
		p.NetConfPanel.add(p.NetConf_limitSize);
		p.NetConf_limitSize.setNextBeans(p.NetConf_limitSize_unlimit);
		p.NetConf_limitSize.setRow(p.getNetConfR(), mcframe.clientFSBB.FSBBP0070.NetConfR.limitSize_META);
		p.NetConfPanel.add(p.NetConf_limitSize_unlimit);
		p.NetConf_limitSize_unlimit.setNextBeans(p.NetConf_inet_setting);
		p.NetConf_limitSize_unlimit.setRow(p.getNetConfR(), mcframe.clientFSBB.FSBBP0070.NetConfR.limitSize_unlimit_META);
		p.NetConf_inet_setting.setFunctionKey(MCFunctionKey.F8);
		p.NetConfPanel.add(p.NetConf_inet_setting);
	}

	/**
	 * [Blank]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitBlank(FSBBP0070 p) {
		// ブロック関連の初期化
		p.BlankPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "S";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBBP0070_FW.mcInitMain((FSBBP0070)this);
		FSBBP0070_FW.mcInitNetConf((FSBBP0070)this);
		FSBBP0070_FW.mcInitBlank((FSBBP0070)this);

		// [INIT]ステータスのモードの設定
		FSBBP0070_FW.statusInitINIT_Main((FSBBP0070)this);
		FSBBP0070_FW.statusInitINIT_NetConf((FSBBP0070)this);
		FSBBP0070_FW.statusInitINIT_Blank((FSBBP0070)this);

	}

	/**
	 *  [Main]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitMain(FSBBP0070 p) {
	}

	/**
	 *  [NetConf]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitNetConf(FSBBP0070 p) {
		p.NetConf_retry.setListListener(p);
		p.NetConf_retry.addAllListener(p);
		p.NetConf_retry_def.addAllListener(p);
		p.NetConf_receive_timeout.setListListener(p);
		p.NetConf_receive_timeout.addAllListener(p);
		p.NetConf_receive_timeout_def.addAllListener(p);
		p.NetConf_ulLimitSize.setListListener(p);
		p.NetConf_ulLimitSize.addAllListener(p);
		p.NetConf_ulLimitSize_unlimit.addAllListener(p);
		p.NetConf_limitSize.setListListener(p);
		p.NetConf_limitSize.addAllListener(p);
		p.NetConf_limitSize_unlimit.addAllListener(p);
		p.NetConf_inet_setting.addAllListener(p);
		p.NetConf_inet_setting.setAPMethodName("doNetConf_inet_setting");
	}

	/**
	 *  [Blank]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitBlank(FSBBP0070 p) {
	}

	/**
	 * [INIT]ステータスの[Main]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Main(FSBBP0070 p){

	}

	/**
	 * [INIT]ステータスの[NetConf]ブロックのモードの設定
	 */
	protected static void statusInitINIT_NetConf(FSBBP0070 p){
		p.NetConf_retry.putMode(p, INIT, MCMode.REQUIRED);
		p.NetConf_retry_def.putMode(p, INIT, MCMode.REQUIRED);
		p.NetConf_receive_timeout.putMode(p, INIT, MCMode.REQUIRED);
		p.NetConf_receive_timeout_def.putMode(p, INIT, MCMode.REQUIRED);
		p.NetConf_ulLimitSize.putMode(p, INIT, MCMode.REQUIRED);
		p.NetConf_ulLimitSize_unlimit.putMode(p, INIT, MCMode.REQUIRED);
		p.NetConf_limitSize.putMode(p, INIT, MCMode.REQUIRED);
		p.NetConf_limitSize_unlimit.putMode(p, INIT, MCMode.REQUIRED);
		p.NetConf_inet_setting.putMode(p, INIT, MCMode.ENABLE);

	}

	/**
	 * [INIT]ステータスの[Blank]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Blank(FSBBP0070 p){

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return INIT;
	}

	/**
	 * Table/Tree/GanttChartの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
	}


	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == NetConf_inet_setting) doNetConf_inet_setting(info);
	}

	/**
	 * [NetConf]パネルの[inet_setting]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doNetConf_inet_setting(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == NetConf_retry) return doNetConf_retry_VC(info);
		if (vc == NetConf_retry_def) return doNetConf_retry_def_VC(info);
		if (vc == NetConf_receive_timeout) return doNetConf_receive_timeout_VC(info);
		if (vc == NetConf_receive_timeout_def) return doNetConf_receive_timeout_def_VC(info);
		if (vc == NetConf_ulLimitSize) return doNetConf_ulLimitSize_VC(info);
		if (vc == NetConf_ulLimitSize_unlimit) return doNetConf_ulLimitSize_unlimit_VC(info);
		if (vc == NetConf_limitSize) return doNetConf_limitSize_VC(info);
		if (vc == NetConf_limitSize_unlimit) return doNetConf_limitSize_unlimit_VC(info);
		return true;
	}

	/**
	 * [NetConf]パネルの[retry]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doNetConf_retry_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [NetConf]パネルの[retry_def]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doNetConf_retry_def_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [NetConf]パネルの[receive_timeout]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doNetConf_receive_timeout_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [NetConf]パネルの[receive_timeout_def]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doNetConf_receive_timeout_def_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [NetConf]パネルの[ulLimitSize]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doNetConf_ulLimitSize_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [NetConf]パネルの[ulLimitSize_unlimit]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doNetConf_ulLimitSize_unlimit_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [NetConf]パネルの[limitSize]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doNetConf_limitSize_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [NetConf]パネルの[limitSize_unlimit]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doNetConf_limitSize_unlimit_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == NetConf_retry) doNetConf_retry_NC(info);
		else if (nc == NetConf_retry_def) doNetConf_retry_def_NC(info);
		else if (nc == NetConf_receive_timeout) doNetConf_receive_timeout_NC(info);
		else if (nc == NetConf_receive_timeout_def) doNetConf_receive_timeout_def_NC(info);
		else if (nc == NetConf_ulLimitSize) doNetConf_ulLimitSize_NC(info);
		else if (nc == NetConf_ulLimitSize_unlimit) doNetConf_ulLimitSize_unlimit_NC(info);
		else if (nc == NetConf_limitSize) doNetConf_limitSize_NC(info);
		else if (nc == NetConf_limitSize_unlimit) doNetConf_limitSize_unlimit_NC(info);
	}

	/**
	 * [NetConf]パネルの[retry]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doNetConf_retry_NC(MCEventInfo info){
	}

	/**
	 * [NetConf]パネルの[retry_def]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doNetConf_retry_def_NC(MCEventInfo info){
	}

	/**
	 * [NetConf]パネルの[receive_timeout]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doNetConf_receive_timeout_NC(MCEventInfo info){
	}

	/**
	 * [NetConf]パネルの[receive_timeout_def]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doNetConf_receive_timeout_def_NC(MCEventInfo info){
	}

	/**
	 * [NetConf]パネルの[ulLimitSize]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doNetConf_ulLimitSize_NC(MCEventInfo info){
	}

	/**
	 * [NetConf]パネルの[ulLimitSize_unlimit]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doNetConf_ulLimitSize_unlimit_NC(MCEventInfo info){
	}

	/**
	 * [NetConf]パネルの[limitSize]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doNetConf_limitSize_NC(MCEventInfo info){
	}

	/**
	 * [NetConf]パネルの[limitSize_unlimit]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doNetConf_limitSize_unlimit_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == NetConf_retry) doNetConf_retry_NE(info);
		else if (ne == NetConf_retry_def) doNetConf_retry_def_NE(info);
		else if (ne == NetConf_receive_timeout) doNetConf_receive_timeout_NE(info);
		else if (ne == NetConf_receive_timeout_def) doNetConf_receive_timeout_def_NE(info);
		else if (ne == NetConf_ulLimitSize) doNetConf_ulLimitSize_NE(info);
		else if (ne == NetConf_ulLimitSize_unlimit) doNetConf_ulLimitSize_unlimit_NE(info);
		else if (ne == NetConf_limitSize) doNetConf_limitSize_NE(info);
		else if (ne == NetConf_limitSize_unlimit) doNetConf_limitSize_unlimit_NE(info);
	}

	/**
	 * [NetConf]パネルの[retry]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doNetConf_retry_NE(MCEventInfo info){
	}

	/**
	 * [NetConf]パネルの[retry_def]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doNetConf_retry_def_NE(MCEventInfo info){
	}

	/**
	 * [NetConf]パネルの[receive_timeout]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doNetConf_receive_timeout_NE(MCEventInfo info){
	}

	/**
	 * [NetConf]パネルの[receive_timeout_def]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doNetConf_receive_timeout_def_NE(MCEventInfo info){
	}

	/**
	 * [NetConf]パネルの[ulLimitSize]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doNetConf_ulLimitSize_NE(MCEventInfo info){
	}

	/**
	 * [NetConf]パネルの[ulLimitSize_unlimit]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doNetConf_ulLimitSize_unlimit_NE(MCEventInfo info){
	}

	/**
	 * [NetConf]パネルの[limitSize]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doNetConf_limitSize_NE(MCEventInfo info){
	}

	/**
	 * [NetConf]パネルの[limitSize_unlimit]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doNetConf_limitSize_unlimit_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == NetConf_retry) doNetConf_retry_NX(info);
		else if (nx == NetConf_retry_def) doNetConf_retry_def_NX(info);
		else if (nx == NetConf_receive_timeout) doNetConf_receive_timeout_NX(info);
		else if (nx == NetConf_receive_timeout_def) doNetConf_receive_timeout_def_NX(info);
		else if (nx == NetConf_ulLimitSize) doNetConf_ulLimitSize_NX(info);
		else if (nx == NetConf_ulLimitSize_unlimit) doNetConf_ulLimitSize_unlimit_NX(info);
		else if (nx == NetConf_limitSize) doNetConf_limitSize_NX(info);
		else if (nx == NetConf_limitSize_unlimit) doNetConf_limitSize_unlimit_NX(info);
	}

	/**
	 * [NetConf]パネルの[retry]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doNetConf_retry_NX(MCEventInfo info){
	}

	/**
	 * [NetConf]パネルの[retry_def]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doNetConf_retry_def_NX(MCEventInfo info){
	}

	/**
	 * [NetConf]パネルの[receive_timeout]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doNetConf_receive_timeout_NX(MCEventInfo info){
	}

	/**
	 * [NetConf]パネルの[receive_timeout_def]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doNetConf_receive_timeout_def_NX(MCEventInfo info){
	}

	/**
	 * [NetConf]パネルの[ulLimitSize]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doNetConf_ulLimitSize_NX(MCEventInfo info){
	}

	/**
	 * [NetConf]パネルの[ulLimitSize_unlimit]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doNetConf_ulLimitSize_unlimit_NX(MCEventInfo info){
	}

	/**
	 * [NetConf]パネルの[limitSize]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doNetConf_limitSize_NX(MCEventInfo info){
	}

	/**
	 * [NetConf]パネルの[limitSize_unlimit]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doNetConf_limitSize_unlimit_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == NetConf_retry) doNetConf_retry_LC(info);
		else if (lc == NetConf_receive_timeout) doNetConf_receive_timeout_LC(info);
		else if (lc == NetConf_ulLimitSize) doNetConf_ulLimitSize_LC(info);
		else if (lc == NetConf_limitSize) doNetConf_limitSize_LC(info);
	}

	/**
	 * [NetConf]パネルの[retry]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doNetConf_retry_LC(MCEventInfo info){
	}

	/**
	 * [NetConf]パネルの[receive_timeout]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doNetConf_receive_timeout_LC(MCEventInfo info){
	}

	/**
	 * [NetConf]パネルの[ulLimitSize]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doNetConf_ulLimitSize_LC(MCEventInfo info){
	}

	/**
	 * [NetConf]パネルの[limitSize]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doNetConf_limitSize_LC(MCEventInfo info){
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}