package mcframe.clientFSBB.FSBBP0030;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;


import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import java.util.Map;
import java.util.Set;
import mcframe.clientFSBB.FSBBP0000.MCConfigPanel;
import mcframe.clientFSBB.FSBBP0000.MenuR;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBBP0030"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBBP0030_FW extends FSBBP0030_FW_A implements MCConfigPanel {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBBP0030_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	@Override
	public String getComment() {
		return null;
	}

	@Override
	public Map<String, MCRootPanel> getConfigPanels() {
		return null;
	}

	@Override
	public MCList<MenuR> getMenu() {
		return null;
	}

	@Override
	public boolean checkConfig() {
		return true;
		
	}

	@Override
	public void saveConfig(MCMessageList msgList) {
	}

}