package mcframe.clientFSBB.FSBBP0090;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBBP0090"パネルクラスです。<p>
 *
 * 画面起動高速化の環境設定画面です。<br>
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBBP0090_FW_A extends mcframe.clientFSBB.FSBBP0100.FSBBP_PartsBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBB";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBBP0090";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Main]ブロック関連のField定義
	// [Main]ブロックの項目のField定義
	// [PreloadDtl]ブロック関連のField定義
	public MCPanel PreloadDtlPanel = null;
	public MCScrollPane PreloadDtlScrollPane = null;
	public MCTable2<mcframe.clientFSBB.FSBBP0090.PreloadDtlR> PreloadDtlTable = null;
	// [PreloadDtl]ブロックの項目のField定義
	/**
	 *  有効.<p>
	 *
	 */
	public MCColumnConfig columnPreloadDtl_enable = null;
	/**
	 *  モジュールＩＤ.<p>
	 *
	 */
	public MCColumnConfig columnPreloadDtl_module_id = null;
	/**
	 *  モジュール名.<p>
	 *
	 */
	public MCColumnConfig columnPreloadDtl_module_id_nm = null;
	/**
	 *  画面ＩＤ.<p>
	 *
	 */
	public MCColumnConfig columnPreloadDtl_screen_id = null;
	/**
	 *  画面名.<p>
	 *
	 */
	public MCColumnConfig columnPreloadDtl_screen_nm = null;
	/**
	 *  モジュールＩＤ.<p>
	 *
	 */
	public MCColumnConfig columnPreloadDtl_screen_module_id = null;
	// [PreloadBtn]ブロック関連のField定義
	public MCPanel PreloadBtnPanel = null;
	// [PreloadBtn]ブロックの項目のField定義
	/**
	 *  行追加.<p>
	 *
	 */
	public MCButton PreloadBtn_radd = null;
	/**
	 *  行削除.<p>
	 *
	 */
	public MCButton PreloadBtn_rdel = null;
	/** [INIT]モードを表す定数 */
	public static final String INIT = "INIT";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{INIT};
	
	/** [PreloadDtl]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBB.FSBBP0090.PreloadDtlR> aPreloadDtlL;

	/**
	 * コピーによってaPreloadDtlLを設定します。
	 *
	 * aPreloadDtlLのインスタンスは変更されません。
	 *
	 * @param dataset PreloadDtlL
	 */
	public void setPreloadDtlL(MCList<mcframe.clientFSBB.FSBBP0090.PreloadDtlR> aList) {
		if (getPreloadDtlL() != aList) {
			getPreloadDtlL().setAll(aList);
		}
	}

	/**
	 * [PreloadDtl]ブロックのコンテナaPreloadDtlLを返します。
	 *
	 * @return PreloadDtlL
	 */
	public MCList<mcframe.clientFSBB.FSBBP0090.PreloadDtlR> getPreloadDtlL() {
		return aPreloadDtlL;
	}

	/**
	 * aPreloadDtlRを作成します。
	 *
	 * @return PreloadDtlR
	 */
	public mcframe.clientFSBB.FSBBP0090.PreloadDtlR createPreloadDtlR() {
		return mcframe.clientFSBB.FSBBP0090.PreloadDtlR.create();
	}

	/**
	 * aPreloadDtlLを作成します。
	 *
	 * @return PreloadDtlL
	 */
	public MCList<mcframe.clientFSBB.FSBBP0090.PreloadDtlR> createPreloadDtlL() {
		return MCList.create(mcframe.clientFSBB.FSBBP0090.PreloadDtlR.class);
	}

	/**
	 * PreloadDtlTableを初期化します。
	 */
	protected void createPreloadDtlTable(){
		if(PreloadDtlTable == null){
			PreloadDtlTable = beansFactory.createTable2("PreloadDtl.table");
		}
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getPreloadDtlL())) ret.add(getPreloadDtlL());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getPreloadDtlL()) return "PreloadDtl";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("PreloadDtl")) return getPreloadDtlL();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(PreloadDtlPanel);
		ret.add(PreloadBtnPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBBP0090_FW_A() {
		aPreloadDtlL = createPreloadDtlL();

	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBBP0090_FW_A(String name) {
		aPreloadDtlL = createPreloadDtlL();
		createPreloadDtlTable();
		PreloadDtlTable.setRowName(name);
	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBBP0090_FW.jbCreateMain((FSBBP0090)this);
		FSBBP0090_FW.jbCreatePreloadDtl((FSBBP0090)this);
		FSBBP0090_FW.jbCreatePreloadBtn((FSBBP0090)this);
	}

	/**
	 * [Main]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateMain(FSBBP0090 p) {
	}

	/**
	 * [PreloadDtl]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreatePreloadDtl(FSBBP0090 p) {
	}

	/**
	 * [PreloadBtn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreatePreloadBtn(FSBBP0090 p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}

	
	/** [PreloadDtl_module_id_ListPutter]の定義 */
	private MCListPutter PreloadDtl_module_id_p = null;

	/**
	 * [PreloadDtl_module_id_ListPutter]の取得
	 */
	protected MCListPutter getPreloadDtl_module_id_ListPutter() {
		if (PreloadDtl_module_id_p == null) {
			PreloadDtl_module_id_p = createPreloadDtl_module_id_ListPutter(columnPreloadDtl_module_id, "module_id", "module_id_nm");

		}
		return PreloadDtl_module_id_p;
	}
	
	
	/** [PreloadDtl_screen_id_ListPutter]の定義 */
	private MCListPutter PreloadDtl_screen_id_p = null;

	/**
	 * [PreloadDtl_screen_id_ListPutter]の取得
	 */
	protected MCListPutter getPreloadDtl_screen_id_ListPutter() {
		if (PreloadDtl_screen_id_p == null) {
			PreloadDtl_screen_id_p = createPreloadDtl_screen_id_ListPutter(columnPreloadDtl_screen_id, "screen_id", "screen_nm","screen_module_id");

		}
		return PreloadDtl_screen_id_p;
	}
	

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBBP0090 create(){
		FSBBP0090 p = new FSBBP0090();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBBP0090 create(String name){
		FSBBP0090 p = new FSBBP0090(name);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBBP0090_FW.jbfInitMain((FSBBP0090)this);
		FSBBP0090_FW.jbfInitPreloadDtl((FSBBP0090)this);
		FSBBP0090_FW.jbfInitPreloadBtn((FSBBP0090)this);
		FSBBP0090_FW.jbInitMain((FSBBP0090)this);
		FSBBP0090_FW.jbInitPreloadDtl((FSBBP0090)this);
		FSBBP0090_FW.jbInitPreloadBtn((FSBBP0090)this);
	}

	/**
	 * [Main]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitMain(FSBBP0090 p) {
		// ブロック関連の初期化
		// ブロックの項目の初期化
	}

	/**
	 * [PreloadDtl]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitPreloadDtl(FSBBP0090 p) {
		// ブロック関連の初期化
		p.PreloadDtlPanel = p.beansFactory.createPanel("PreloadDtl");
		p.PreloadDtlScrollPane = p.beansFactory.createScrollPane("PreloadDtl.scroll");
		p.createPreloadDtlTable();
		// ブロックの項目の初期化
		p.columnPreloadDtl_enable = p.beansFactory.createTableColumn("PreloadDtl.enable", MCColumnType.CHECK);
		p.columnPreloadDtl_module_id = p.beansFactory.createTableColumn("PreloadDtl.module_id", MCColumnType.TEXT_COMBO);
		p.columnPreloadDtl_module_id_nm = p.beansFactory.createTableColumn("PreloadDtl.module_id_nm", MCColumnType.TEXT);
		p.columnPreloadDtl_screen_id = p.beansFactory.createTableColumn("PreloadDtl.screen_id", MCColumnType.TEXT);
		p.columnPreloadDtl_screen_nm = p.beansFactory.createTableColumn("PreloadDtl.screen_nm", MCColumnType.TEXT);
		p.columnPreloadDtl_screen_module_id = p.beansFactory.createTableColumn("PreloadDtl.screen_module_id", MCColumnType.TEXT);
	}

	/**
	 * [PreloadBtn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitPreloadBtn(FSBBP0090 p) {
		// ブロック関連の初期化
		p.PreloadBtnPanel = p.beansFactory.createPanel("PreloadBtn");
		// ブロックの項目の初期化
		p.PreloadBtn_radd = p.beansFactory.createButton("PreloadBtn.radd", "no_border");
		p.PreloadBtn_rdel = p.beansFactory.createButton("PreloadBtn.rdel", "no_border");
	}

	/**
	 * [Main]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitMain(FSBBP0090 p) {
		// ブロック関連の初期化
		p.MainPanel.setLayoutPosition("C+");
		// ブロックの項目の初期化
		p.MainPanel.add(p.PreloadDtlPanel, null);
		p.MainPanel.setLastBeans(p.PreloadDtlPanel);
		p.PreloadDtlPanel.setNextBeans(p.PreloadBtnPanel);
		p.MainPanel.add(p.PreloadBtnPanel, null);
	}

	/**
	 * [PreloadDtl]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitPreloadDtl(FSBBP0090 p) {
		// ブロック関連の初期化
		p.PreloadDtlPanel.add(p.PreloadDtlScrollPane);
		p.PreloadDtlPanel.setLastBeans(p.PreloadDtlTable);
		p.PreloadDtlScrollPane.setViewportView(p.PreloadDtlTable);
		p.PreloadDtlTable.setList(p.getPreloadDtlL());
		p.PreloadDtlPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * [PreloadBtn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitPreloadBtn(FSBBP0090 p) {
		// ブロック関連の初期化
		p.PreloadBtnPanel.setLayoutPosition("S");
		// ブロックの項目の初期化
		p.PreloadBtn_radd.setIcon("INSERT_RECORD");
		p.PreloadBtn_radd.setFunctionKey(MCFunctionKey.F5);
		p.PreloadBtnPanel.add(p.PreloadBtn_radd);
		p.PreloadBtnPanel.setLastBeans(p.PreloadBtn_radd);
		p.PreloadBtn_radd.setNextBeans(p.PreloadBtn_rdel);
		p.PreloadBtn_rdel.setIcon("DELETE_RECORD");
		p.PreloadBtn_rdel.setFunctionKey(MCFunctionKey.F6);
		p.PreloadBtnPanel.add(p.PreloadBtn_rdel);
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "S";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBBP0090_FW.mcInitMain((FSBBP0090)this);
		FSBBP0090_FW.mcInitPreloadDtl((FSBBP0090)this);
		FSBBP0090_FW.mcInitPreloadBtn((FSBBP0090)this);

		// [INIT]ステータスのモードの設定
		FSBBP0090_FW.statusInitINIT_Main((FSBBP0090)this);
		FSBBP0090_FW.statusInitINIT_PreloadDtl((FSBBP0090)this);
		FSBBP0090_FW.statusInitINIT_PreloadBtn((FSBBP0090)this);

	}

	/**
	 *  [Main]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitMain(FSBBP0090 p) {
	}

	/**
	 *  [PreloadDtl]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitPreloadDtl(FSBBP0090 p) {
		p.PreloadDtlTable.addAllListener(p);
		p.columnPreloadDtl_enable.addAllListener(p);
		p.columnPreloadDtl_module_id.addAllListener(p);
		p.columnPreloadDtl_module_id.setListListener(p);
		p.columnPreloadDtl_module_id_nm.addAllListener(p);
		p.columnPreloadDtl_module_id_nm.setListListener(p);
		p.columnPreloadDtl_screen_id.addAllListener(p);
		p.columnPreloadDtl_screen_id.setListListener(p);
		p.columnPreloadDtl_screen_nm.addAllListener(p);
		p.columnPreloadDtl_screen_nm.setListListener(p);
		p.columnPreloadDtl_screen_module_id.addAllListener(p);
		p.columnPreloadDtl_screen_module_id.setListListener(p);
	}

	/**
	 *  [PreloadBtn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitPreloadBtn(FSBBP0090 p) {
		p.PreloadBtn_radd.addAllListener(p);
		p.PreloadBtn_radd.setAPMethodName("doPreloadBtn_radd");
		p.PreloadBtn_rdel.addAllListener(p);
		p.PreloadBtn_rdel.setAPMethodName("doPreloadBtn_rdel");
	}

	/**
	 * [INIT]ステータスの[Main]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Main(FSBBP0090 p){

	}

	/**
	 * [INIT]ステータスの[PreloadDtl]ブロックのモードの設定
	 */
	protected static void statusInitINIT_PreloadDtl(FSBBP0090 p){
		p.columnPreloadDtl_enable.putMode(p, INIT, MCMode.REQUIRED);
		p.columnPreloadDtl_module_id.putMode(p, INIT, MCMode.REQUIRED);
		p.columnPreloadDtl_module_id_nm.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnPreloadDtl_screen_id.putMode(p, INIT, MCMode.REQUIRED);
		p.columnPreloadDtl_screen_nm.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnPreloadDtl_screen_module_id.putMode(p, INIT, MCMode.INVISIBLE);

	}

	/**
	 * [INIT]ステータスの[PreloadBtn]ブロックのモードの設定
	 */
	protected static void statusInitINIT_PreloadBtn(FSBBP0090 p){
		p.PreloadBtn_radd.putMode(p, INIT, MCMode.ENABLE);
		p.PreloadBtn_rdel.putMode(p, INIT, MCMode.ENABLE);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return INIT;
	}

	/**
	 * Table/Tree/GanttChartの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
		FSBBP0090_FW.setTableConfigPreloadDtl((FSBBP0090)this);
	}

	/**
	 * [PreloadDtl]ブロックのTableの設定
	 */
	protected static void setTableConfigPreloadDtl(FSBBP0090 p) {
		p.columnPreloadDtl_enable.setMeta(mcframe.clientFSBB.FSBBP0090.PreloadDtlR.enable_META);
		p.PreloadDtlTable.addColumnConfig(p.columnPreloadDtl_enable);
		p.columnPreloadDtl_module_id.setMeta(mcframe.clientFSBB.FSBBP0090.PreloadDtlR.module_id_META);
		p.columnPreloadDtl_module_id.addLinkBeans(p.columnPreloadDtl_module_id_nm);
		p.PreloadDtlTable.addColumnConfig(p.columnPreloadDtl_module_id);
		p.columnPreloadDtl_module_id_nm.setMeta(mcframe.clientFSBB.FSBBP0090.PreloadDtlR.module_id_nm_META);
		p.PreloadDtlTable.addColumnConfig(p.columnPreloadDtl_module_id_nm);
		p.columnPreloadDtl_screen_id.setMeta(mcframe.clientFSBB.FSBBP0090.PreloadDtlR.screen_id_META);
		p.columnPreloadDtl_screen_id.setListType(MCListType.STRICT);
		p.columnPreloadDtl_screen_id.addLinkBeans(p.columnPreloadDtl_screen_nm,p.columnPreloadDtl_screen_module_id);
		p.PreloadDtlTable.addColumnConfig(p.columnPreloadDtl_screen_id);
		p.columnPreloadDtl_screen_nm.setMeta(mcframe.clientFSBB.FSBBP0090.PreloadDtlR.screen_nm_META);
		p.PreloadDtlTable.addColumnConfig(p.columnPreloadDtl_screen_nm);
		p.columnPreloadDtl_screen_module_id.setMeta(mcframe.clientFSBB.FSBBP0090.PreloadDtlR.screen_module_id_META);
		p.PreloadDtlTable.addColumnConfig(p.columnPreloadDtl_screen_module_id);
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
		columnPreloadDtl_module_id.setListVisibleColumn(MCListLogic.getViewColumnName());
		columnPreloadDtl_module_id.getListConfig().setPutter(getPreloadDtl_module_id_ListPutter());
		columnPreloadDtl_screen_id.getListConfig().setPutter(getPreloadDtl_screen_id_ListPutter());
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
	}

	/**
	 * [PreloadDtl_module_id_ListPutter]の作成
	 */
	protected MCListPutter createPreloadDtl_module_id_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("FS.FSUAP0010.UserModuleID");
		return lp;
	}
	 
	/**
	 * [PreloadDtl_screen_id_ListPutter]の作成
	 */
	protected MCListPutter createPreloadDtl_screen_id_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("");
		return lp;
	}
	 

	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		if(combo == columnPreloadDtl_module_id) return getPreloadDtl_module_id(row, info);
		if(combo == columnPreloadDtl_screen_id) return getPreloadDtl_screen_id(row, info);
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == PreloadBtn_radd) doPreloadBtn_radd(info);
		else if (ap == PreloadBtn_rdel) doPreloadBtn_rdel(info);
	}

	/**
	 * [PreloadBtn]パネルの[radd]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doPreloadBtn_radd(MCEventInfo info);

	/**
	 * [PreloadBtn]パネルの[rdel]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doPreloadBtn_rdel(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == PreloadDtlTable) return doPreloadDtl_VC(info);
		if (vc == columnPreloadDtl_enable) return doPreloadDtl_enable_VC(info);
		if (vc == columnPreloadDtl_module_id) return doPreloadDtl_module_id_VC(info);
		if (vc == columnPreloadDtl_module_id_nm) return doPreloadDtl_module_id_nm_VC(info);
		if (vc == columnPreloadDtl_screen_id) return doPreloadDtl_screen_id_VC(info);
		if (vc == columnPreloadDtl_screen_nm) return doPreloadDtl_screen_nm_VC(info);
		if (vc == columnPreloadDtl_screen_module_id) return doPreloadDtl_screen_module_id_VC(info);
		return true;
	}

	/**
	 * [PreloadDtl]Tableの選択行が変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doPreloadDtl_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [PreloadDtl]パネルの[enable]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doPreloadDtl_enable_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [PreloadDtl]パネルの[module_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doPreloadDtl_module_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [PreloadDtl]パネルの[module_id_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doPreloadDtl_module_id_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [PreloadDtl]パネルの[screen_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doPreloadDtl_screen_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [PreloadDtl]パネルの[screen_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doPreloadDtl_screen_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [PreloadDtl]パネルの[screen_module_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doPreloadDtl_screen_module_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == PreloadDtlTable) doPreloadDtl_NC(info);
		else if (nc == columnPreloadDtl_enable) doPreloadDtl_enable_NC(info);
		else if (nc == columnPreloadDtl_module_id) doPreloadDtl_module_id_NC(info);
		else if (nc == columnPreloadDtl_module_id_nm) doPreloadDtl_module_id_nm_NC(info);
		else if (nc == columnPreloadDtl_screen_id) doPreloadDtl_screen_id_NC(info);
		else if (nc == columnPreloadDtl_screen_nm) doPreloadDtl_screen_nm_NC(info);
		else if (nc == columnPreloadDtl_screen_module_id) doPreloadDtl_screen_module_id_NC(info);
	}

	/**
	 * [PreloadDtl]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPreloadDtl_NC(MCEventInfo info){
	}

	/**
	 * [PreloadDtl]パネルの[enable]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPreloadDtl_enable_NC(MCEventInfo info){
	}

	/**
	 * [PreloadDtl]パネルの[module_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPreloadDtl_module_id_NC(MCEventInfo info){
	}

	/**
	 * [PreloadDtl]パネルの[module_id_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPreloadDtl_module_id_nm_NC(MCEventInfo info){
	}

	/**
	 * [PreloadDtl]パネルの[screen_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPreloadDtl_screen_id_NC(MCEventInfo info){
	}

	/**
	 * [PreloadDtl]パネルの[screen_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPreloadDtl_screen_nm_NC(MCEventInfo info){
	}

	/**
	 * [PreloadDtl]パネルの[screen_module_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPreloadDtl_screen_module_id_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == PreloadDtlTable) doPreloadDtl_NE(info);
		else if (ne == columnPreloadDtl_enable) doPreloadDtl_enable_NE(info);
		else if (ne == columnPreloadDtl_module_id) doPreloadDtl_module_id_NE(info);
		else if (ne == columnPreloadDtl_module_id_nm) doPreloadDtl_module_id_nm_NE(info);
		else if (ne == columnPreloadDtl_screen_id) doPreloadDtl_screen_id_NE(info);
		else if (ne == columnPreloadDtl_screen_nm) doPreloadDtl_screen_nm_NE(info);
		else if (ne == columnPreloadDtl_screen_module_id) doPreloadDtl_screen_module_id_NE(info);
	}

	/**
	 * [PreloadDtl]TableのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPreloadDtl_NE(MCEventInfo info){
	}

	/**
	 * [PreloadDtl]パネルの[enable]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPreloadDtl_enable_NE(MCEventInfo info){
	}

	/**
	 * [PreloadDtl]パネルの[module_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPreloadDtl_module_id_NE(MCEventInfo info){
	}

	/**
	 * [PreloadDtl]パネルの[module_id_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPreloadDtl_module_id_nm_NE(MCEventInfo info){
	}

	/**
	 * [PreloadDtl]パネルの[screen_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPreloadDtl_screen_id_NE(MCEventInfo info){
	}

	/**
	 * [PreloadDtl]パネルの[screen_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPreloadDtl_screen_nm_NE(MCEventInfo info){
	}

	/**
	 * [PreloadDtl]パネルの[screen_module_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPreloadDtl_screen_module_id_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == PreloadDtlTable) doPreloadDtl_NX(info);
		else if (nx == columnPreloadDtl_enable) doPreloadDtl_enable_NX(info);
		else if (nx == columnPreloadDtl_module_id) doPreloadDtl_module_id_NX(info);
		else if (nx == columnPreloadDtl_module_id_nm) doPreloadDtl_module_id_nm_NX(info);
		else if (nx == columnPreloadDtl_screen_id) doPreloadDtl_screen_id_NX(info);
		else if (nx == columnPreloadDtl_screen_nm) doPreloadDtl_screen_nm_NX(info);
		else if (nx == columnPreloadDtl_screen_module_id) doPreloadDtl_screen_module_id_NX(info);
	}

	/**
	 * [PreloadDtl]TableのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPreloadDtl_NX(MCEventInfo info){
	}

	/**
	 * [PreloadDtl]パネルの[enable]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPreloadDtl_enable_NX(MCEventInfo info){
	}

	/**
	 * [PreloadDtl]パネルの[module_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPreloadDtl_module_id_NX(MCEventInfo info){
	}

	/**
	 * [PreloadDtl]パネルの[module_id_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPreloadDtl_module_id_nm_NX(MCEventInfo info){
	}

	/**
	 * [PreloadDtl]パネルの[screen_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPreloadDtl_screen_id_NX(MCEventInfo info){
	}

	/**
	 * [PreloadDtl]パネルの[screen_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPreloadDtl_screen_nm_NX(MCEventInfo info){
	}

	/**
	 * [PreloadDtl]パネルの[screen_module_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPreloadDtl_screen_module_id_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == columnPreloadDtl_module_id) doPreloadDtl_module_id_LC(info);
		else if (lc == columnPreloadDtl_module_id_nm) doPreloadDtl_module_id_nm_LC(info);
		else if (lc == columnPreloadDtl_screen_id) doPreloadDtl_screen_id_LC(info);
		else if (lc == columnPreloadDtl_screen_nm) doPreloadDtl_screen_nm_LC(info);
		else if (lc == columnPreloadDtl_screen_module_id) doPreloadDtl_screen_module_id_LC(info);
	}

	/**
	 * [PreloadDtl]パネルの[module_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPreloadDtl_module_id_LC(MCEventInfo info){
	}

	/**
	 * [PreloadDtl]パネルの[module_id_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPreloadDtl_module_id_nm_LC(MCEventInfo info){
	}

	/**
	 * [PreloadDtl]パネルの[screen_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPreloadDtl_screen_id_LC(MCEventInfo info){
	}

	/**
	 * [PreloadDtl]パネルの[screen_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPreloadDtl_screen_nm_LC(MCEventInfo info){
	}

	/**
	 * [PreloadDtl]パネルの[screen_module_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPreloadDtl_screen_module_id_LC(MCEventInfo info){
	}

	/**
	 * コンボ／リストのリスト[columnPreloadDtl_module_id]の作成メソッド
	 */
	public MCList getPreloadDtl_module_id(MCRow row, MCEventInfo info){
		return ((mcframe.clientFSUA.FSUAP0010.FSUAP_List)MCListLogic.create("mcframe.clientFSUA.FSUAP0010.FSUAP_List", this)).getUserModuleID(row, info);
	}

	/**
	 * コンボ／リストのリスト[columnPreloadDtl_screen_id]の作成メソッド
	 */
	public MCList getPreloadDtl_screen_id(MCRow row, MCEventInfo info){
		return null;
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}