package mcframe.clientFSBB.FSBBP0090;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;


import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.clientCore.resource.MCConst;
import mcframe.clientCore.sys.MCSys;
import mcframe.commonFXBA.FXBAC0020.FXBAC_ListLogicBase;
import mcframe.clientFXBA.FXBAP0010.FXBAP_ISPanel;
import mcframe.clientFXBA.FXBAP0080.FXBAP_CellConfig;
import mcframe.commonFS.constant.FSC_MODULE_ID;
import static mcframe.commonFSUA.FSUAC0010.FSUAC_List.FSUAP0020Cols;
import static mcframe.commonFSUA.FSUAC0010.FSUAC_List.UserModuleIDCols;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBBP0090"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBBP0090_FW extends FSBBP0090_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START
	/**
	 * Preloadのリソースキーです。
	 */
	public static final String PRELOAD_KEY = "preload";

	/**
	 * 有効のリソースキーです。
	 */
	public static final String ENABLE_KEY = "enable";

	/**
	 * classidのリソースキーです。
	 */
	public static final String CLASSID_KEY = "classid";
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBBP0090_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBBP0090_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * Panel[PreloadBtn]のボタン[radd]の押下時の処理
	 */
	@Override
	public void doPreloadBtn_radd(MCEventInfo info) {
		insertRow(PreloadDtlTable);
	}

	/**
	 * Panel[PreloadBtn]のボタン[rdel]の押下時の処理
	 */
	@Override
	public void doPreloadBtn_rdel(MCEventInfo info) {
		deleteRow(PreloadDtlTable);
	}

	@Override
	protected void saveDfltConfig(MCMessageList msgList) {
		for (String m : getLicensedModuleIDs()) {
			for (String key : MCConst.app.findPattern(MCConst.createKey(m,
					PRELOAD_KEY, "**"))) {
				MCConst.app.remove(key);
			}
		}
		msgList.add(msgPreloadChanged());
	}

	/**
	 * ログインユーザが使用可能なモジュールＩＤの配列を返す
	 * 
	 * @return ログインユーザが使用可能なモジュールＩＤの配列
	 */
	protected String[] getLicensedModuleIDs() {
		return MCSys.user.modules();
	}

	@Override
	protected void valueInit() {
		super.valueInit();
		MCList<PreloadDtlR> list = createPreloadDtlL();
		for (String m : getLicensedModuleIDs()) {
			for (String key : MCConst.app.findPattern(MCConst.createKey(m,
					PRELOAD_KEY, "*"))) {
				PreloadDtlR r = createPreloadDtlR();
				r.enable(MCConst.app.getBoolean(
						MCConst.createKey(key, ENABLE_KEY), false));
				String[] split = MCConst.splitKey(key);
				r.module_id(m);
				FSC_MODULE_ID.putNameNE(r, PreloadDtlR.$module_id, PreloadDtlR.$module_id_nm);
				r.screen_id(split[2]);
				r.screen_nm(MCConst.label.getLabel(MCConst.createKey(m,
						split[2], "label")));
				r.ptn(MCConst.app.containsKey(MCConst.createKey(key,
						CLASSID_KEY)));
				list.add(r);
			}
		}
		getPreloadDtlL().setAll(list);
		sort(PreloadDtlTable);
	}
	@Override
	protected void listInit() {
		super.listInit();		
		getPreloadDtl_module_id_ListPutter().setColumns(
				UserModuleIDCols.$o_module_id,
				UserModuleIDCols.$o_module_nm);
		getPreloadDtl_screen_id_ListPutter().setColumns(
				FSUAP0020Cols.$o_screen_id, 
				FSUAP0020Cols.$o_screen_name,
				FSUAP0020Cols.$o_module_id);
	}
	
	@Override
	protected void linkBeansToISPanel() {
		super.linkBeansToISPanel();

		linkBeansToISPanel(columnPreloadDtl_screen_id, "FS", "FSUAP0020", true);
		getPreloadDtl_screen_id_ListPutter().putBind(FSUAP0020Cols.$i_module_id,
				columnPreloadDtl_module_id);
		getPreloadDtl_screen_id_ListPutter().putBind(FSUAP0020Cols.$i_check_ac_flg, true);
	}

	@Override
	public void setINITStatus() {
		super.setINITStatus();
		PreloadDtlTable.selectLeftmostColumn(0);
	}

	@Override
	protected void fillSpaceForOpen() {
		super.fillSpaceForOpen();
		PreloadDtlTable.adjustWidth();
		PreloadDtlTable.fillSpace();
	}

	@Override
	protected void setSortColumn() {
		super.setSortColumn();
		PreloadDtlTable.addSortColumn(columnPreloadDtl_module_id, SortType.ASC);
		PreloadDtlTable.addSortColumn(columnPreloadDtl_screen_id, SortType.ASC);
	}

	@Override
	public void saveUpdConfig(MCMessageList msgList) {
		if (isStatusChanged()) {
			saveDfltConfig(msgList);
			MCList<PreloadDtlR> l = exceptDeleteAndEmpty(getPreloadDtlL());
			for (PreloadDtlR r : l) {
				MCConst.app.setBoolean(MCConst.createKey(r.module_id(),
						PRELOAD_KEY, r.screen_id(), ENABLE_KEY), r.enable());
			}
		}
	}

	@Override
	public boolean checkUpdConfig() {
		MCMessageList l = checkReq(getPreloadDtlL().statusChangedList());
		checkDuplicate(l, PreloadDtlTable, PreloadDtlR.$module_id,
				PreloadDtlR.$screen_id);
		if (l.size() > 0) {
			message(l);
			return false;
		}
		return true;
	}

	/**
	 * 登録完了後のメッセージを返します。
	 * 
	 * @return
	 */
	public MCMessage msgPreloadChanged() {
		return new MCMessage(FSBBC0015);
	}

	@Override
	public void doPreloadDtl_NC(MCEventInfo info) {
		super.doPreloadDtl_NC(info);
		PreloadDtlR r = PreloadDtlTable.getSelectedMCRow();
		if (r != null && r.ptn()) {
			PreloadBtn_rdel.setMode(MCMode.DISABLE);
		} else {
			setDefaultMode(PreloadBtn_rdel);
		}
	}

	@Override
	public void doPreloadDtl_module_id_LC(MCEventInfo info) {
		super.doPreloadDtl_module_id_LC(info);
		if (!isScreenIDEnable(info.getEventIndex())) {
			setValueEx(columnPreloadDtl_screen_id, info.getEventIndex(), null);
		}
	}

	protected boolean isScreenIDEnable(int index) {
		PreloadDtlR r = getPreloadDtlL().get(index);
		if (isNull(r.module_id())) {
			return false;
		}
		MCRow o = MCRow.create();
		MCList<MCRow> l = getScreenInfo(o, index);
		if (l == null) {
			return false;
		}
		l = l.subList(FSUAP0020Cols.$o_module_id, r.module_id());
		l = l.subList(FSUAP0020Cols.$o_screen_id, r.screen_id());
		return l != null && l.size() > 0;
	}
	
	protected MCList<MCRow> getScreenInfo(MCRow row, int index) {
		_inputSupportType = INPUT_SUPPORT_GET_LIST;
		ISPanelLinker ir = getISPanelLinkerNE(columnPreloadDtl_screen_id);
		if (ir != null && ir.isEnable()) {
			row.setStringNE(FXBAC_ListLogicBase.$INPUT_VAL, getPreloadDtlL().get(index).screen_id());
			FXBAP_ISPanel p = getISPanel(columnPreloadDtl_screen_id, index);
			return p.getList(row, this);
		}
		return null;
	}
	
	@Override
	public void doPreloadDtl_screen_id_LC(MCEventInfo info) {
		super.doPreloadDtl_screen_id_LC(info);
		
		PreloadDtlR r = getPreloadDtlL().get(info.getEventIndex());
		String s = r.screen_id();
		if (isNull(s)) {
			return;
		}
		setValueEx(columnPreloadDtl_module_id, info.getEventIndex(), 
				r.screen_module_id());
	}

	@Override
	protected void setCellConfig() {
		super.setCellConfig();
		PreloadDtlTable.setCellConfig(createFSBBP0090_CellConfig());
	}

	/**
	 * PreloadDtlTable用CellConfigを返します。
	 * 
	 * @return CellConfig
	 */
	protected MCCellConfig createFSBBP0090_CellConfig() {
		return new FSBBP0090_CellConfig();
	}

	/**
	 * PreloadDtlTable用CellConfigクラスです。
	 */
	public class FSBBP0090_CellConfig extends FXBAP_CellConfig {
		@Override
		public MCMode getPriorMode(int index, MCColumnConfig column,
				MCTable table) {
			if (column != columnPreloadDtl_enable) {
				if (getPreloadDtlL().get(index).ptn()) {
					return MCMode.READ_ONLY;
				}
			}
			return super.getPriorMode(index, column, table);
		}

	}

}