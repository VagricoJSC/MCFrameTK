package mcframe.clientFSBB.FSBBP0000;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Menu"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class MenuR_FW_A extends MCConstRow {

	public static final String $parent = "parent";
	public static final String $key = "key";
	public static final String $id = "id";
	public static final String $label = "label";
	public static final String $sort_idx = "sort_idx";
	public static final String $conf_flg = "conf_flg";
	public static final String $label_nm = "label_nm";
	public static final String $cmnt = "cmnt";


	public static final MCMeta parent_META = createStringMeta($parent);
	public static final MCMeta key_META = createStringMeta($key);
	public static final MCMeta id_META = createStringMeta($id);
	public static final MCMeta label_META = createStringMeta($label);
	public static final MCMeta sort_idx_META = createCommonMeta($sort_idx, mcframe.commonCore.meta.M_META.INT);
	public static final MCMeta conf_flg_META = createCommonMeta($conf_flg, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta label_nm_META = createStringMeta($label_nm, 30);
	public static final MCMeta cmnt_META = createStringMeta($cmnt, 50);

	protected static final ConstMetaList<MenuR> constMetas = new ConstMetaList<MenuR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			parent_META,
			key_META,
			id_META,
			label_META,
			sort_idx_META,
			conf_flg_META,
			label_nm_META,
			cmnt_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected MenuR_FW_A(ConstMetaList<? extends MenuR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public MenuR clone() {
		return (MenuR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public MenuR createInstance() {
		return (MenuR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public MenuR getValues(String... names) {
		return (MenuR) super.getValues(names);
	}



	public String parent() {
		return getConstString(offset + 0, $parent);
	}

	public void parent(String value) {
		setConstString(offset + 0, $parent, value);
	}


	public String key() {
		return getConstString(offset + 1, $key);
	}

	public void key(String value) {
		setConstString(offset + 1, $key, value);
	}


	public String id() {
		return getConstString(offset + 2, $id);
	}

	public void id(String value) {
		setConstString(offset + 2, $id, value);
	}


	public String label() {
		return getConstString(offset + 3, $label);
	}

	public void label(String value) {
		setConstString(offset + 3, $label, value);
	}


	public MCNumber sort_idx() {
		return getConstNumber(offset + 4, $sort_idx);
	}

	public void sort_idx(MCNumber value) {
		setConstNumber(offset + 4, $sort_idx, value);
	}

	public void sort_idx(int value) {
		setConstNumber(offset + 4, $sort_idx, value);
	}

	public void sort_idx(long value) {
		setConstNumber(offset + 4, $sort_idx, value);
	}

	public void sort_idx(float value) {
		setConstNumber(offset + 4, $sort_idx, value);
	}

	public void sort_idx(double value) {
		setConstNumber(offset + 4, $sort_idx, value);
	}


	public boolean conf_flg() {
		return getConstBoolean(offset + 5, $conf_flg);
	}

	public void conf_flg(boolean value) {
		setConstBoolean(offset + 5, $conf_flg, value);
	}


	public String label_nm() {
		return getConstString(offset + 6, $label_nm);
	}

	public void label_nm(String value) {
		setConstString(offset + 6, $label_nm, value);
	}


	public String cmnt() {
		return getConstString(offset + 7, $cmnt);
	}

	public void cmnt(String value) {
		setConstString(offset + 7, $cmnt, value);
	}


	public String getString(String name) {
		if ($parent.equalsIgnoreCase(name)) {
			return parent();
		}
		if ($key.equalsIgnoreCase(name)) {
			return key();
		}
		if ($id.equalsIgnoreCase(name)) {
			return id();
		}
		if ($label.equalsIgnoreCase(name)) {
			return label();
		}
		if ($label_nm.equalsIgnoreCase(name)) {
			return label_nm();
		}
		if ($cmnt.equalsIgnoreCase(name)) {
			return cmnt();
		}
		return super.getString(name);
	}
	public MCNumber getNumber(String name) {
		if ($sort_idx.equalsIgnoreCase(name)) {
			return sort_idx();
		}
		return super.getNumber(name);
	}
	public boolean getBoolean(String name) {
		if ($conf_flg.equalsIgnoreCase(name)) {
			return conf_flg();
		}
		return super.getBoolean(name);
	}

	public String getStringNE(String name) {
		if ($parent.equalsIgnoreCase(name)) {
			return parent();
		}
		if ($key.equalsIgnoreCase(name)) {
			return key();
		}
		if ($id.equalsIgnoreCase(name)) {
			return id();
		}
		if ($label.equalsIgnoreCase(name)) {
			return label();
		}
		if ($label_nm.equalsIgnoreCase(name)) {
			return label_nm();
		}
		if ($cmnt.equalsIgnoreCase(name)) {
			return cmnt();
		}
		return super.getStringNE(name);
	}
	public MCNumber getNumberNE(String name) {
		if ($sort_idx.equalsIgnoreCase(name)) {
			return sort_idx();
		}
		return super.getNumberNE(name);
	}
	public boolean getBooleanNE(String name) {
		if ($conf_flg.equalsIgnoreCase(name)) {
			return conf_flg();
		}
		return super.getBooleanNE(name);
	}

	public void setString(String name, String value) {
		if ($parent.equalsIgnoreCase(name)) {
			parent(value);
			return;
		}
		if ($key.equalsIgnoreCase(name)) {
			key(value);
			return;
		}
		if ($id.equalsIgnoreCase(name)) {
			id(value);
			return;
		}
		if ($label.equalsIgnoreCase(name)) {
			label(value);
			return;
		}
		if ($label_nm.equalsIgnoreCase(name)) {
			label_nm(value);
			return;
		}
		if ($cmnt.equalsIgnoreCase(name)) {
			cmnt(value);
			return;
		}
		super.setString(name, value);
	}
	public void setNumber(String name, MCNumber value) {
		if ($sort_idx.equalsIgnoreCase(name)) {
			sort_idx(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, int value) {
		if ($sort_idx.equalsIgnoreCase(name)) {
			sort_idx(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, long value) {
		if ($sort_idx.equalsIgnoreCase(name)) {
			sort_idx(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, float value) {
		if ($sort_idx.equalsIgnoreCase(name)) {
			sort_idx(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, double value) {
		if ($sort_idx.equalsIgnoreCase(name)) {
			sort_idx(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setBoolean(String name, boolean value) {
		if ($conf_flg.equalsIgnoreCase(name)) {
			conf_flg(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($parent.equalsIgnoreCase(name)) {
			parent(value);
			return;
		}
		if ($key.equalsIgnoreCase(name)) {
			key(value);
			return;
		}
		if ($id.equalsIgnoreCase(name)) {
			id(value);
			return;
		}
		if ($label.equalsIgnoreCase(name)) {
			label(value);
			return;
		}
		if ($label_nm.equalsIgnoreCase(name)) {
			label_nm(value);
			return;
		}
		if ($cmnt.equalsIgnoreCase(name)) {
			cmnt(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setNumberNE(String name, MCNumber value) {
		if ($sort_idx.equalsIgnoreCase(name)) {
			sort_idx(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, int value) {
		if ($sort_idx.equalsIgnoreCase(name)) {
			sort_idx(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, long value) {
		if ($sort_idx.equalsIgnoreCase(name)) {
			sort_idx(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, float value) {
		if ($sort_idx.equalsIgnoreCase(name)) {
			sort_idx(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, double value) {
		if ($sort_idx.equalsIgnoreCase(name)) {
			sort_idx(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setBooleanNE(String name, boolean value) {
		if ($conf_flg.equalsIgnoreCase(name)) {
			conf_flg(value);
			return;
		}
		super.setBooleanNE(name, value);
	}



}

