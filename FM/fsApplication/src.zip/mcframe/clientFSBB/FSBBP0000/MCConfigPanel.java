package mcframe.clientFSBB.FSBBP0000;

import java.util.Map;
import java.util.Set;
import mcframe.clientCore.beans.MCRootPanel;
import mcframe.clientCore.beans.table.MCColumnConfig;
import mcframe.clientCore.beans.table.MCTable;
import mcframe.commonCore.container.MCList;
import mcframe.commonCore.notice.MCMessageList;


/**
 * 環境設定画面用の画面インターフェースです。
 */
public interface MCConfigPanel {
	
	/**
	 * 画面に設定されている情報および、この設定画面
	 * 以下の階層の設定を全て保存します。
	 * <p>
	 * 引数のメッセージリストにメッセージを追加すると、登録完了後にまとめて表示されます。
	 * 
	 * @param msgList メッセージリスト
	 */
	public void saveConfig(MCMessageList msgList);
	
	/**
	 * 画面に設定されている情報および、この設定画面
	 * 以下の階層の設定をチェックします。
	 */
	public boolean checkConfig();
	
	/**
	 * この設定画面以下の階層のメニューを取得します。
	 * この設定画面以下の階層がない場合はnullを返します。
	 *
	 * @return
	 */
	public MCList<MenuR> getMenu();
	
	/**
	 * この設定画面以下の階層のメニューを取得します。
	 * この設定画面以下の階層がない場合はnullを返します。
	 *
	 * @return
	 */
	public Map<String, MCRootPanel> getConfigPanels();
	
	/**
	 * この設定画面の名前を取得します。
	 * 名前がない場合はnullを返します。
	 *
	 * @return
	 */
	public String getScreenName();
	
	/**
	 * この設定画面の説明を取得します。
	 * 説明がない場合はnullを返します。
	 *
	 * @return
	 */
	public String getComment();
}
