package mcframe.clientFSBB.FSBBP0080;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBBP0080"パネルクラスです。<p>
 *
 * 色の環境設定画面です。<br>
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBBP0080_FW_A extends mcframe.clientFSBB.FSBBP0100.FSBBP_PartsBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBB";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBBP0080";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Main]ブロック関連のField定義
	// [Main]ブロックの項目のField定義
	// [Color]ブロック関連のField定義
	public MCPanel ColorPanel = null;
	public MCScrollPane ColorScrollPane = null;
	public MCTable2<mcframe.clientFSBB.FSBBP0080.ColorR> ColorTable = null;
	// [Color]ブロックの項目のField定義
	/**
	 *  ソート順.<p>
	 *
	 */
	public MCColumnConfig columnColor_sort_order = null;
	/**
	 *  設定項目.<p>
	 *
	 */
	public MCColumnConfig columnColor_name = null;
	public mcframe.clientFSUB.FSUBP0120.FSUBP_Color_D Color_color_p_PPanel;
	public MCColumnConfig columnColor_red;// [Color]の[color_p.red]を[columnColor_red]としてエイリアス定義。
	public MCColumnConfig columnColor_green;// [Color]の[color_p.green]を[columnColor_green]としてエイリアス定義。
	public MCColumnConfig columnColor_blue;// [Color]の[color_p.blue]を[columnColor_blue]としてエイリアス定義。
	public MCColumnConfig columnColor_color;// [Color]の[color_p.color]を[columnColor_color]としてエイリアス定義。
	/** [INIT]モードを表す定数 */
	public static final String INIT = "INIT";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{INIT};
	
	/** [Color]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBB.FSBBP0080.ColorR> aColorL;

	/**
	 * コピーによってaColorLを設定します。
	 *
	 * aColorLのインスタンスは変更されません。
	 *
	 * @param dataset ColorL
	 */
	public void setColorL(MCList<mcframe.clientFSBB.FSBBP0080.ColorR> aList) {
		if (getColorL() != aList) {
			getColorL().setAll(aList);
		}
	}

	/**
	 * [Color]ブロックのコンテナaColorLを返します。
	 *
	 * @return ColorL
	 */
	public MCList<mcframe.clientFSBB.FSBBP0080.ColorR> getColorL() {
		return aColorL;
	}

	/**
	 * aColorRを作成します。
	 *
	 * @return ColorR
	 */
	public mcframe.clientFSBB.FSBBP0080.ColorR createColorR() {
		return mcframe.clientFSBB.FSBBP0080.ColorR.create();
	}

	/**
	 * aColorLを作成します。
	 *
	 * @return ColorL
	 */
	public MCList<mcframe.clientFSBB.FSBBP0080.ColorR> createColorL() {
		return MCList.create(mcframe.clientFSBB.FSBBP0080.ColorR.class);
	}

	/**
	 * ColorTableを初期化します。
	 */
	protected void createColorTable(){
		if(ColorTable == null){
			ColorTable = beansFactory.createTable2("Color.table");
		}
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getColorL())) ret.add(getColorL());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getColorL()) return "Color";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("Color")) return getColorL();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(ColorPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBBP0080_FW_A() {
		aColorL = createColorL();

	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBBP0080_FW_A(String name) {
		aColorL = createColorL();
		createColorTable();
		ColorTable.setRowName(name);
	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBBP0080_FW.jbCreateMain((FSBBP0080)this);
		FSBBP0080_FW.jbCreateColor((FSBBP0080)this);
	}

	/**
	 * [Main]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateMain(FSBBP0080 p) {
	}

	/**
	 * [Color]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateColor(FSBBP0080 p) {
		p.Color_color_p_PPanel = mcframe.clientFSUB.FSUBP0120.FSUBP_Color_D.create(mcframe.clientFSBB.FSBBP0080.ColorR.$color_p);
		p.Color_color_p_PPanel.setName("Color.color_p");
		p.columnColor_red = p.Color_color_p_PPanel.columnColor_red;
		p.columnColor_red.addAliasName("Color.red", p);
		p.columnColor_green = p.Color_color_p_PPanel.columnColor_green;
		p.columnColor_green.addAliasName("Color.green", p);
		p.columnColor_blue = p.Color_color_p_PPanel.columnColor_blue;
		p.columnColor_blue.addAliasName("Color.blue", p);
		p.columnColor_color = p.Color_color_p_PPanel.columnColor_color;
		p.columnColor_color.addAliasName("Color.color", p);
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}


	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBBP0080 create(){
		FSBBP0080 p = new FSBBP0080();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBBP0080 create(String name){
		FSBBP0080 p = new FSBBP0080(name);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBBP0080_FW.jbfInitMain((FSBBP0080)this);
		FSBBP0080_FW.jbfInitColor((FSBBP0080)this);
		FSBBP0080_FW.jbInitMain((FSBBP0080)this);
		FSBBP0080_FW.jbInitColor((FSBBP0080)this);
	}

	/**
	 * [Main]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitMain(FSBBP0080 p) {
		// ブロック関連の初期化
		// ブロックの項目の初期化
	}

	/**
	 * [Color]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitColor(FSBBP0080 p) {
		// ブロック関連の初期化
		p.ColorPanel = p.beansFactory.createPanel("Color");
		p.ColorScrollPane = p.beansFactory.createScrollPane("Color.scroll");
		p.createColorTable();
		// ブロックの項目の初期化
		p.columnColor_sort_order = p.beansFactory.createTableColumn("Color.sort_order", MCColumnType.NUMBER);
		p.columnColor_name = p.beansFactory.createTableColumn("Color.name", MCColumnType.TEXT);
	}

	/**
	 * [Main]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitMain(FSBBP0080 p) {
		// ブロック関連の初期化
		p.MainPanel.setLayoutPosition("C+");
		// ブロックの項目の初期化
		p.MainPanel.add(p.ColorPanel, null);
		p.MainPanel.setLastBeans(p.ColorPanel);
	}

	/**
	 * [Color]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitColor(FSBBP0080 p) {
		// ブロック関連の初期化
		p.ColorPanel.add(p.ColorScrollPane);
		p.ColorPanel.setLastBeans(p.ColorTable);
		p.ColorScrollPane.setViewportView(p.ColorTable);
		p.ColorTable.setList(p.getColorL());
		p.ColorPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "S";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBBP0080_FW.mcInitMain((FSBBP0080)this);
		FSBBP0080_FW.mcInitColor((FSBBP0080)this);

		// [INIT]ステータスのモードの設定
		FSBBP0080_FW.statusInitINIT_Main((FSBBP0080)this);
		FSBBP0080_FW.statusInitINIT_Color((FSBBP0080)this);

	}

	/**
	 *  [Main]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitMain(FSBBP0080 p) {
	}

	/**
	 *  [Color]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitColor(FSBBP0080 p) {
		p.ColorTable.addAllListener(p);
		p.columnColor_sort_order.addAllListener(p);
		p.columnColor_sort_order.setListListener(p);
		p.columnColor_name.addAllListener(p);
		p.columnColor_name.setListListener(p);
	}

	/**
	 * [INIT]ステータスの[Main]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Main(FSBBP0080 p){

	}

	/**
	 * [INIT]ステータスの[Color]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Color(FSBBP0080 p){
		p.columnColor_sort_order.putMode(p, INIT, MCMode.INVISIBLE);
		p.columnColor_name.putMode(p, INIT, MCMode.READ_ONLY);
		p.Color_color_p_PPanel.putStatus(INIT, mcframe.clientFSUB.FSUBP0120.FSUBP_Color_D.ENABLE);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return INIT;
	}

	/**
	 * Table/Tree/GanttChartの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
		FSBBP0080_FW.setTableConfigColor((FSBBP0080)this);
	}

	/**
	 * [Color]ブロックのTableの設定
	 */
	protected static void setTableConfigColor(FSBBP0080 p) {
		p.columnColor_sort_order.setMeta(mcframe.clientFSBB.FSBBP0080.ColorR.sort_order_META);
		p.ColorTable.addColumnConfig(p.columnColor_sort_order);
		p.columnColor_name.setMeta(mcframe.clientFSBB.FSBBP0080.ColorR.name_META);
		p.ColorTable.addColumnConfig(p.columnColor_name);
		p.ColorTable.addTable(p.Color_color_p_PPanel.ColorTable);
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
	}


	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
	}

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == ColorTable) return doColor_VC(info);
		if (vc == columnColor_sort_order) return doColor_sort_order_VC(info);
		if (vc == columnColor_name) return doColor_name_VC(info);
		return true;
	}

	/**
	 * [Color]Tableの選択行が変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doColor_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Color]パネルの[sort_order]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doColor_sort_order_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Color]パネルの[name]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doColor_name_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == ColorTable) doColor_NC(info);
		else if (nc == columnColor_sort_order) doColor_sort_order_NC(info);
		else if (nc == columnColor_name) doColor_name_NC(info);
	}

	/**
	 * [Color]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doColor_NC(MCEventInfo info){
	}

	/**
	 * [Color]パネルの[sort_order]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doColor_sort_order_NC(MCEventInfo info){
	}

	/**
	 * [Color]パネルの[name]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doColor_name_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == ColorTable) doColor_NE(info);
		else if (ne == columnColor_sort_order) doColor_sort_order_NE(info);
		else if (ne == columnColor_name) doColor_name_NE(info);
	}

	/**
	 * [Color]TableのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doColor_NE(MCEventInfo info){
	}

	/**
	 * [Color]パネルの[sort_order]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doColor_sort_order_NE(MCEventInfo info){
	}

	/**
	 * [Color]パネルの[name]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doColor_name_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == ColorTable) doColor_NX(info);
		else if (nx == columnColor_sort_order) doColor_sort_order_NX(info);
		else if (nx == columnColor_name) doColor_name_NX(info);
	}

	/**
	 * [Color]TableのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doColor_NX(MCEventInfo info){
	}

	/**
	 * [Color]パネルの[sort_order]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doColor_sort_order_NX(MCEventInfo info){
	}

	/**
	 * [Color]パネルの[name]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doColor_name_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == columnColor_sort_order) doColor_sort_order_LC(info);
		else if (lc == columnColor_name) doColor_name_LC(info);
	}

	/**
	 * [Color]パネルの[sort_order]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doColor_sort_order_LC(MCEventInfo info){
	}

	/**
	 * [Color]パネルの[name]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doColor_name_LC(MCEventInfo info){
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}