package mcframe.clientFSBB.FSBBP0080;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;

import mcframe.clientFSUB.FSUBP0120.*;

import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START

import java.util.Map;
import java.util.Set;

import mcframe.clientCore.resource.MCConst;
import mcframe.commonCore.container.MCList.SortType;

import mcframe.clientFSBB.FSBBP0000.MCConfigPanel;
import mcframe.clientFSBB.FSBBP0000.MenuR;
import mcframe.commonFS.constant.FSC_COLOR_KEY;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBBP0080"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBBP0080_FW extends FSBBP0080_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBBP0080_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBBP0080_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	@Override
	protected void saveDfltConfig(MCMessageList msgList) {
		for (ColorR o : getColorL()) {
			removeResourceColor(o);
		}
		MCBeansUtil.setLookAndFeel();
		msgList.add(msgColorChanged());
	}
	
	@Override
	public void saveUpdConfig(MCMessageList msgList) {
		if (isStatusChanged()) {
			MCList<ColorR> l = getColorL().statusChangedList();
			
			for (ColorR c : l) {
				setResourceColor(c);
			}
			MCBeansUtil.setLookAndFeel();
			msgList.add(msgColorChanged());
		}
	}

	@Override
	public boolean checkUpdConfig() {
		MCMessageList l = checkReq(getColorL().statusChangedList());
		if (l.size() > 0) {
			message(l);
			return false;
		}
		return true;
	}

	/**
	 * 登録完了後のメッセージを返します。
	 * 
	 * @return
	 */
	public MCMessage msgColorChanged() {
		return new MCMessage(FSBBC0012);
	}

	@Override
	protected void valueInit() {
		super.valueInit();

		MCList<MCRow> l = FSC_COLOR_KEY.list();
		l.sort(FSC_COLOR_KEY.$SORT_ORDER);
		
		MCList<ColorR> tmp = createColorL();
		
		for (MCRow o : l) {
			FSC_COLOR_KEY k = FSC_COLOR_KEY.get(
					o.getString(FSC_COLOR_KEY.$VALUE));
			
			if (!checkResourceType(k.resource_type())) {
				continue;
			}
			
			ColorR d = getColorL().createRow();
			d.sort_order(tmp.size());
			d.name(k.name());
			d.resource_type(k.resource_type());
			d.resource_key(k.resource_key());

			Color c = getResourceColor(d.resource_type(), d.resource_key());
			if (c != null) {
				d.red(c.getRed());
				d.green(c.getGreen());
				d.blue(c.getBlue());
			}
			
			tmp.add(d);
		}
		
		tmp.sort(ColorR.$sort_order);
		
		setColorL(tmp);
	}

	@Override
	protected void fillSpaceForOpen() {
		super.fillSpaceForOpen();
		ColorTable.adjustWidth();		
	}

	@Override
	protected void setSortColumn() {
		super.setSortColumn();
		ColorTable.addSortColumn(columnColor_sort_order, SortType.ASC);
	}

	@Override
	public void setINITStatus() {
		super.setINITStatus();
		ColorTable.selectLeftmostColumn(0);
	}

	/**
	 * リソースタイプをチェックします。<p>
	 * この画面の色設定の対象となるリソースの場合は true を返します。
	 *
	 * @param type リソースタイプ
	 * @return リソースタイプがこの画面の色設定の対象ではない場合は false
	 */
	protected boolean checkResourceType(String type) {
		if (MCConst.beans.getFileBase().equalsIgnoreCase(type)) {
			return true;
		}
		if (MCConst.app.getFileBase().equals(type)) {
			return true;
		}
		return false;
	}
	
	/**
	 * リソースに保存されている色情報を返します。<p>
	 * 色情報が見つからなかった場合は null を返します。
	 *
	 * @param type リソースタイプ
	 * @param key リソースキー
	 * @return 色情報、または null
	 */
	protected Color getResourceColor(String type, String key) {
		if (MCConst.beans.getFileBase().equalsIgnoreCase(type)) {
			return MCConst.beans.getColor(key);
		}
		if (MCConst.app.getFileBase().equalsIgnoreCase(type)) {
			return MCConst.app.getColor(key);
		}
		return null;
	}
	
	/**
	 * リソースに色情報を設定します。
	 *
	 * @param data 色情報のコンテナ
	 */
	protected void setResourceColor(ColorR data) {
		if (data == null) {
			return;
		}
		
		Color c = null;
		MCNumber r = data.red();
		MCNumber g = data.green();
		MCNumber b = data.blue();
		if (!isNullOr(r, g, b)) {
			c = new Color(r.intValue(), g.intValue(), b.intValue());
		}
		String k = data.resource_key();
		String t = data.resource_type();
		if (MCConst.beans.getFileBase().equalsIgnoreCase(t)) {
			if (c != null) {
				MCConst.beans.setColor(k, c);
			}
			else {
				MCConst.beans.remove(k);
			}
		}
		else if (MCConst.app.getFileBase().equalsIgnoreCase(t)) {
			if (c != null) {
				MCConst.app.setColor(k, c);
			}
			else {
				MCConst.app.remove(k);
			}
		}
	}

	/**
	 * リソースから設定情報を削除します。
	 * 
	 * @param data 色情報のコンテナ
	 */
	protected void removeResourceColor(ColorR data) {
		if (data == null) {
			return;
		}
		
		String k = data.resource_key();
		String t = data.resource_type();
		if (MCConst.beans.getFileBase().equalsIgnoreCase(t)) {
			MCConst.beans.remove(k);
		}
		else if (MCConst.app.getFileBase().equalsIgnoreCase(t)) {
			MCConst.app.remove(k);
		}
	}
		
	@Override
	protected void customVisibleColumnConfigs(MCTable table, String type,
			Set<MCColumnConfig> confSet) {
		super.customVisibleColumnConfigs(table, type, confSet);
		
		if (MCRootPanel.SORT_ORDER_PANEL.equals(type)) {
			confSet.remove(columnColor_color);
			confSet.add(columnColor_sort_order);
		}
		else if (MCRootPanel.ROW_FILTER_PANEL.equals(type)) {
			confSet.remove(columnColor_color);
		}
	}

}