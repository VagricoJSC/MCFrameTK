package mcframe.clientFSBB.FSBBP0040;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Printer"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class PrinterR_FW_A extends MCConstRow {

	/**
	 *  プリンタＩＤ.<p>
	 *
	 */
	public static final String $printer_id = "printer_id";
	/**
	 *  プリンタ名.<p>
	 *
	 */
	public static final String $printer_name = "printer_name";


	public static final MCMeta printer_id_META = createCommonMeta($printer_id, mcframe.commonCore.meta.M_META.PRINTER_ID);
	public static final MCMeta printer_name_META = createCommonMeta($printer_name, mcframe.commonCore.meta.M_META.PRINTER_NAME);

	protected static final ConstMetaList<PrinterR> constMetas = new ConstMetaList<PrinterR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			printer_id_META,
			printer_name_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected PrinterR_FW_A(ConstMetaList<? extends PrinterR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public PrinterR clone() {
		return (PrinterR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public PrinterR createInstance() {
		return (PrinterR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public PrinterR getValues(String... names) {
		return (PrinterR) super.getValues(names);
	}



	/**
	 *  プリンタＩＤ.<p>
	 *
	 */
	public String printer_id() {
		return getConstString(offset + 0, $printer_id);
	}

	/**
	 *  プリンタＩＤ.<p>
	 *
	 */
	public void printer_id(String value) {
		setConstString(offset + 0, $printer_id, value);
	}


	/**
	 *  プリンタ名.<p>
	 *
	 */
	public String printer_name() {
		return getConstString(offset + 1, $printer_name);
	}

	/**
	 *  プリンタ名.<p>
	 *
	 */
	public void printer_name(String value) {
		setConstString(offset + 1, $printer_name, value);
	}


	public String getString(String name) {
		if ($printer_id.equalsIgnoreCase(name)) {
			return printer_id();
		}
		if ($printer_name.equalsIgnoreCase(name)) {
			return printer_name();
		}
		return super.getString(name);
	}

	public String getStringNE(String name) {
		if ($printer_id.equalsIgnoreCase(name)) {
			return printer_id();
		}
		if ($printer_name.equalsIgnoreCase(name)) {
			return printer_name();
		}
		return super.getStringNE(name);
	}

	public void setString(String name, String value) {
		if ($printer_id.equalsIgnoreCase(name)) {
			printer_id(value);
			return;
		}
		if ($printer_name.equalsIgnoreCase(name)) {
			printer_name(value);
			return;
		}
		super.setString(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($printer_id.equalsIgnoreCase(name)) {
			printer_id(value);
			return;
		}
		if ($printer_name.equalsIgnoreCase(name)) {
			printer_name(value);
			return;
		}
		super.setStringNE(name, value);
	}



}

