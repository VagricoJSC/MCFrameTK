package mcframe.clientFSBB.FSBBP0040;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Report"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class ReportR_FW_A extends MCConstRow {

	/**
	 *  帳票ＩＤ.<p>
	 *
	 */
	public static final String $report_id = "report_id";
	/**
	 *  帳票名.<p>
	 *
	 */
	public static final String $report_name = "report_name";
	/**
	 *  プリンタＩＤ.<p>
	 *
	 */
	public static final String $printer_id = "printer_id";
	/**
	 *  プレビュー.<p>
	 *
	 */
	public static final String $preview = "preview";
	/**
	 *  確認ダイアログ.<p>
	 *
	 */
	public static final String $dialog = "dialog";


	public static final MCMeta report_id_META = createCommonMeta($report_id, mcframe.commonCore.meta.M_META.REPORT_ID);
	public static final MCMeta report_name_META = createCommonMeta($report_name, mcframe.commonCore.meta.M_META.REPORT_NAME);
	public static final MCMeta printer_id_META = createCommonMeta($printer_id, mcframe.commonCore.meta.M_META.PRINTER_ID);
	public static final MCMeta preview_META = createCommonMeta($preview, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta dialog_META = createCommonMeta($dialog, mcframe.commonCore.meta.M_META.FLG);

	protected static final ConstMetaList<ReportR> constMetas = new ConstMetaList<ReportR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			report_id_META,
			report_name_META,
			printer_id_META,
			preview_META,
			dialog_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected ReportR_FW_A(ConstMetaList<? extends ReportR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ReportR clone() {
		return (ReportR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ReportR createInstance() {
		return (ReportR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ReportR getValues(String... names) {
		return (ReportR) super.getValues(names);
	}



	/**
	 *  帳票ＩＤ.<p>
	 *
	 */
	public String report_id() {
		return getConstString(offset + 0, $report_id);
	}

	/**
	 *  帳票ＩＤ.<p>
	 *
	 */
	public void report_id(String value) {
		setConstString(offset + 0, $report_id, value);
	}


	/**
	 *  帳票名.<p>
	 *
	 */
	public String report_name() {
		return getConstString(offset + 1, $report_name);
	}

	/**
	 *  帳票名.<p>
	 *
	 */
	public void report_name(String value) {
		setConstString(offset + 1, $report_name, value);
	}


	/**
	 *  プリンタＩＤ.<p>
	 *
	 */
	public String printer_id() {
		return getConstString(offset + 2, $printer_id);
	}

	/**
	 *  プリンタＩＤ.<p>
	 *
	 */
	public void printer_id(String value) {
		setConstString(offset + 2, $printer_id, value);
	}


	/**
	 *  プレビュー.<p>
	 *
	 */
	public boolean preview() {
		return getConstBoolean(offset + 3, $preview);
	}

	/**
	 *  プレビュー.<p>
	 *
	 */
	public void preview(boolean value) {
		setConstBoolean(offset + 3, $preview, value);
	}


	/**
	 *  確認ダイアログ.<p>
	 *
	 */
	public boolean dialog() {
		return getConstBoolean(offset + 4, $dialog);
	}

	/**
	 *  確認ダイアログ.<p>
	 *
	 */
	public void dialog(boolean value) {
		setConstBoolean(offset + 4, $dialog, value);
	}


	public String getString(String name) {
		if ($report_id.equalsIgnoreCase(name)) {
			return report_id();
		}
		if ($report_name.equalsIgnoreCase(name)) {
			return report_name();
		}
		if ($printer_id.equalsIgnoreCase(name)) {
			return printer_id();
		}
		return super.getString(name);
	}
	public boolean getBoolean(String name) {
		if ($preview.equalsIgnoreCase(name)) {
			return preview();
		}
		if ($dialog.equalsIgnoreCase(name)) {
			return dialog();
		}
		return super.getBoolean(name);
	}

	public String getStringNE(String name) {
		if ($report_id.equalsIgnoreCase(name)) {
			return report_id();
		}
		if ($report_name.equalsIgnoreCase(name)) {
			return report_name();
		}
		if ($printer_id.equalsIgnoreCase(name)) {
			return printer_id();
		}
		return super.getStringNE(name);
	}
	public boolean getBooleanNE(String name) {
		if ($preview.equalsIgnoreCase(name)) {
			return preview();
		}
		if ($dialog.equalsIgnoreCase(name)) {
			return dialog();
		}
		return super.getBooleanNE(name);
	}

	public void setString(String name, String value) {
		if ($report_id.equalsIgnoreCase(name)) {
			report_id(value);
			return;
		}
		if ($report_name.equalsIgnoreCase(name)) {
			report_name(value);
			return;
		}
		if ($printer_id.equalsIgnoreCase(name)) {
			printer_id(value);
			return;
		}
		super.setString(name, value);
	}
	public void setBoolean(String name, boolean value) {
		if ($preview.equalsIgnoreCase(name)) {
			preview(value);
			return;
		}
		if ($dialog.equalsIgnoreCase(name)) {
			dialog(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($report_id.equalsIgnoreCase(name)) {
			report_id(value);
			return;
		}
		if ($report_name.equalsIgnoreCase(name)) {
			report_name(value);
			return;
		}
		if ($printer_id.equalsIgnoreCase(name)) {
			printer_id(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setBooleanNE(String name, boolean value) {
		if ($preview.equalsIgnoreCase(name)) {
			preview(value);
			return;
		}
		if ($dialog.equalsIgnoreCase(name)) {
			dialog(value);
			return;
		}
		super.setBooleanNE(name, value);
	}



}

