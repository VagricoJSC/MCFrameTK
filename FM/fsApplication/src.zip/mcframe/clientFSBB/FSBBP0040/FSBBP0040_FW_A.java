package mcframe.clientFSBB.FSBBP0040;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBBP0040"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBBP0040_FW_A extends mcframe.clientFSBB.FSBBP0100.FSBBP_PartsBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBB";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBBP0040";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Main]ブロック関連のField定義
	// [Main]ブロックの項目のField定義
	// [PrintDef_Tab]ブロック関連のField定義
	public MCPanel PrintDef_TabPanel = null;
	public MCTitledBorder PrintDef_TabTitledBorder = null;
	public MCTabbedPane PrintDef_TabTab = null;
	// [PrintDef_Tab]ブロックの項目のField定義
	// [ReportPnl]ブロック関連のField定義
	public MCPanel ReportPnlPanel = null;
	public MCTitledBorder ReportPnlTitledBorder = null;
	// [ReportPnl]ブロックの項目のField定義
	// [Report]ブロック関連のField定義
	public MCPanel ReportPanel = null;
	public MCScrollPane ReportScrollPane = null;
	public MCTable2<mcframe.clientFSBB.FSBBP0040.ReportR> ReportTable = null;
	// [Report]ブロックの項目のField定義
	/**
	 *  帳票ＩＤ.<p>
	 *
	 */
	public MCColumnConfig columnReport_report_id = null;
	/**
	 *  帳票名.<p>
	 *
	 */
	public MCColumnConfig columnReport_report_name = null;
	/**
	 *  プリンタＩＤ.<p>
	 *
	 */
	public MCColumnConfig columnReport_printer_id = null;
	/**
	 *  プレビュー.<p>
	 *
	 */
	public MCColumnConfig columnReport_preview = null;
	/**
	 *  確認ダイアログ.<p>
	 *
	 */
	public MCColumnConfig columnReport_dialog = null;
	// [ReportBtn]ブロック関連のField定義
	public MCPanel ReportBtnPanel = null;
	// [ReportBtn]ブロックの項目のField定義
	/**
	 * 追加 追加.<p>
	 *
	 */
	public MCButton ReportBtn_add = null;
	/**
	 * 削除 削除.<p>
	 *
	 */
	public MCButton ReportBtn_del = null;
	// [PrinterPnl]ブロック関連のField定義
	public MCPanel PrinterPnlPanel = null;
	public MCTitledBorder PrinterPnlTitledBorder = null;
	// [PrinterPnl]ブロックの項目のField定義
	// [Printer]ブロック関連のField定義
	public MCPanel PrinterPanel = null;
	public MCScrollPane PrinterScrollPane = null;
	public MCTable2<mcframe.clientFSBB.FSBBP0040.PrinterR> PrinterTable = null;
	// [Printer]ブロックの項目のField定義
	/**
	 *  プリンタＩＤ.<p>
	 *
	 */
	public MCColumnConfig columnPrinter_printer_id = null;
	/**
	 *  プリンタ名.<p>
	 *
	 */
	public MCColumnConfig columnPrinter_printer_name = null;
	// [PrinterBtn]ブロック関連のField定義
	public MCPanel PrinterBtnPanel = null;
	// [PrinterBtn]ブロックの項目のField定義
	/**
	 * 追加 追加.<p>
	 *
	 */
	public MCButton PrinterBtn_add = null;
	/**
	 * 削除 削除.<p>
	 *
	 */
	public MCButton PrinterBtn_del = null;
	/** [INIT]モードを表す定数 */
	public static final String INIT = "INIT";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{INIT};
	
	/** [Report]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBB.FSBBP0040.ReportR> aReportL;
	/** [Printer]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBB.FSBBP0040.PrinterR> aPrinterL;

	/**
	 * コピーによってaReportLを設定します。
	 *
	 * aReportLのインスタンスは変更されません。
	 *
	 * @param dataset ReportL
	 */
	public void setReportL(MCList<mcframe.clientFSBB.FSBBP0040.ReportR> aList) {
		if (getReportL() != aList) {
			getReportL().setAll(aList);
		}
	}

	/**
	 * [Report]ブロックのコンテナaReportLを返します。
	 *
	 * @return ReportL
	 */
	public MCList<mcframe.clientFSBB.FSBBP0040.ReportR> getReportL() {
		return aReportL;
	}

	/**
	 * aReportRを作成します。
	 *
	 * @return ReportR
	 */
	public mcframe.clientFSBB.FSBBP0040.ReportR createReportR() {
		return mcframe.clientFSBB.FSBBP0040.ReportR.create();
	}

	/**
	 * aReportLを作成します。
	 *
	 * @return ReportL
	 */
	public MCList<mcframe.clientFSBB.FSBBP0040.ReportR> createReportL() {
		return MCList.create(mcframe.clientFSBB.FSBBP0040.ReportR.class);
	}

	/**
	 * ReportTableを初期化します。
	 */
	protected void createReportTable(){
		if(ReportTable == null){
			ReportTable = beansFactory.createTable2("Report.table");
		}
	}

	/**
	 * コピーによってaPrinterLを設定します。
	 *
	 * aPrinterLのインスタンスは変更されません。
	 *
	 * @param dataset PrinterL
	 */
	public void setPrinterL(MCList<mcframe.clientFSBB.FSBBP0040.PrinterR> aList) {
		if (getPrinterL() != aList) {
			getPrinterL().setAll(aList);
		}
	}

	/**
	 * [Printer]ブロックのコンテナaPrinterLを返します。
	 *
	 * @return PrinterL
	 */
	public MCList<mcframe.clientFSBB.FSBBP0040.PrinterR> getPrinterL() {
		return aPrinterL;
	}

	/**
	 * aPrinterRを作成します。
	 *
	 * @return PrinterR
	 */
	public mcframe.clientFSBB.FSBBP0040.PrinterR createPrinterR() {
		return mcframe.clientFSBB.FSBBP0040.PrinterR.create();
	}

	/**
	 * aPrinterLを作成します。
	 *
	 * @return PrinterL
	 */
	public MCList<mcframe.clientFSBB.FSBBP0040.PrinterR> createPrinterL() {
		return MCList.create(mcframe.clientFSBB.FSBBP0040.PrinterR.class);
	}

	/**
	 * PrinterTableを初期化します。
	 */
	protected void createPrinterTable(){
		if(PrinterTable == null){
			PrinterTable = beansFactory.createTable2("Printer.table");
		}
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getReportL())) ret.add(getReportL());
		if(!MCCollectionUtil.contains(ret, getPrinterL())) ret.add(getPrinterL());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getReportL()) return "Report";
		if(aCnt == getPrinterL()) return "Printer";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("Report")) return getReportL();
		if(bId.equals("Printer")) return getPrinterL();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(PrintDef_TabPanel);
		ret.add(ReportPnlPanel);
		ret.add(ReportPanel);
		ret.add(ReportBtnPanel);
		ret.add(PrinterPnlPanel);
		ret.add(PrinterPanel);
		ret.add(PrinterBtnPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBBP0040_FW_A() {
		aReportL = createReportL();
		aPrinterL = createPrinterL();

	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBBP0040_FW_A(String name) {
		aReportL = createReportL();
		createReportTable();
		ReportTable.setRowName(name);
		aPrinterL = createPrinterL();
		createPrinterTable();
		PrinterTable.setRowName(name);
	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBBP0040_FW.jbCreateMain((FSBBP0040)this);
		FSBBP0040_FW.jbCreatePrintDef_Tab((FSBBP0040)this);
		FSBBP0040_FW.jbCreateReportPnl((FSBBP0040)this);
		FSBBP0040_FW.jbCreateReport((FSBBP0040)this);
		FSBBP0040_FW.jbCreateReportBtn((FSBBP0040)this);
		FSBBP0040_FW.jbCreatePrinterPnl((FSBBP0040)this);
		FSBBP0040_FW.jbCreatePrinter((FSBBP0040)this);
		FSBBP0040_FW.jbCreatePrinterBtn((FSBBP0040)this);
	}

	/**
	 * [Main]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateMain(FSBBP0040 p) {
	}

	/**
	 * [PrintDef_Tab]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreatePrintDef_Tab(FSBBP0040 p) {
	}

	/**
	 * [ReportPnl]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateReportPnl(FSBBP0040 p) {
	}

	/**
	 * [Report]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateReport(FSBBP0040 p) {
	}

	/**
	 * [ReportBtn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateReportBtn(FSBBP0040 p) {
	}

	/**
	 * [PrinterPnl]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreatePrinterPnl(FSBBP0040 p) {
	}

	/**
	 * [Printer]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreatePrinter(FSBBP0040 p) {
	}

	/**
	 * [PrinterBtn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreatePrinterBtn(FSBBP0040 p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}

	
	/** [Report_report_id_ListPutter]の定義 */
	private MCListPutter Report_report_id_p = null;

	/**
	 * [Report_report_id_ListPutter]の取得
	 */
	protected MCListPutter getReport_report_id_ListPutter() {
		if (Report_report_id_p == null) {
			Report_report_id_p = createReport_report_id_ListPutter(columnReport_report_id, "report_id", "report_name");

		}
		return Report_report_id_p;
	}
	
	
	/** [Report_printer_id_ListPutter]の定義 */
	private MCListPutter Report_printer_id_p = null;

	/**
	 * [Report_printer_id_ListPutter]の取得
	 */
	protected MCListPutter getReport_printer_id_ListPutter() {
		if (Report_printer_id_p == null) {
			Report_printer_id_p = createReport_printer_id_ListPutter(columnReport_printer_id, "printer_id");

		}
		return Report_printer_id_p;
	}
	
	
	/** [Printer_printer_name_ListPutter]の定義 */
	private MCListPutter Printer_printer_name_p = null;

	/**
	 * [Printer_printer_name_ListPutter]の取得
	 */
	protected MCListPutter getPrinter_printer_name_ListPutter() {
		if (Printer_printer_name_p == null) {
			Printer_printer_name_p = createPrinter_printer_name_ListPutter(columnPrinter_printer_name, "printer_name");

		}
		return Printer_printer_name_p;
	}
	

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBBP0040 create(){
		FSBBP0040 p = new FSBBP0040();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBBP0040 create(String name){
		FSBBP0040 p = new FSBBP0040(name);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBBP0040_FW.jbfInitMain((FSBBP0040)this);
		FSBBP0040_FW.jbfInitPrintDef_Tab((FSBBP0040)this);
		FSBBP0040_FW.jbfInitReportPnl((FSBBP0040)this);
		FSBBP0040_FW.jbfInitReport((FSBBP0040)this);
		FSBBP0040_FW.jbfInitReportBtn((FSBBP0040)this);
		FSBBP0040_FW.jbfInitPrinterPnl((FSBBP0040)this);
		FSBBP0040_FW.jbfInitPrinter((FSBBP0040)this);
		FSBBP0040_FW.jbfInitPrinterBtn((FSBBP0040)this);
		FSBBP0040_FW.jbInitMain((FSBBP0040)this);
		FSBBP0040_FW.jbInitPrintDef_Tab((FSBBP0040)this);
		FSBBP0040_FW.jbInitReportPnl((FSBBP0040)this);
		FSBBP0040_FW.jbInitReport((FSBBP0040)this);
		FSBBP0040_FW.jbInitReportBtn((FSBBP0040)this);
		FSBBP0040_FW.jbInitPrinterPnl((FSBBP0040)this);
		FSBBP0040_FW.jbInitPrinter((FSBBP0040)this);
		FSBBP0040_FW.jbInitPrinterBtn((FSBBP0040)this);
	}

	/**
	 * [Main]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitMain(FSBBP0040 p) {
		// ブロック関連の初期化
		// ブロックの項目の初期化
	}

	/**
	 * [PrintDef_Tab]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitPrintDef_Tab(FSBBP0040 p) {
		// ブロック関連の初期化
		p.PrintDef_TabPanel = p.beansFactory.createPanel("PrintDef_Tab");
		p.PrintDef_TabTitledBorder = p.beansFactory.createTitledBorder();
		p.PrintDef_TabTab = p.beansFactory.createTabbedPane("PrintDef_Tab.tab");
		// ブロックの項目の初期化
	}

	/**
	 * [ReportPnl]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitReportPnl(FSBBP0040 p) {
		// ブロック関連の初期化
		p.ReportPnlPanel = p.beansFactory.createPanel("ReportPnl");
		p.ReportPnlTitledBorder = p.beansFactory.createTitledBorder();
		// ブロックの項目の初期化
	}

	/**
	 * [Report]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitReport(FSBBP0040 p) {
		// ブロック関連の初期化
		p.ReportPanel = p.beansFactory.createPanel("Report");
		p.ReportScrollPane = p.beansFactory.createScrollPane("Report.scroll");
		p.createReportTable();
		// ブロックの項目の初期化
		p.columnReport_report_id = p.beansFactory.createTableColumn("Report.report_id", MCColumnType.TEXT_COMBO_FREE);
		p.columnReport_report_name = p.beansFactory.createTableColumn("Report.report_name", MCColumnType.TEXT);
		p.columnReport_printer_id = p.beansFactory.createTableColumn("Report.printer_id", MCColumnType.TEXT_COMBO);
		p.columnReport_preview = p.beansFactory.createTableColumn("Report.preview", MCColumnType.CHECK);
		p.columnReport_dialog = p.beansFactory.createTableColumn("Report.dialog", MCColumnType.CHECK);
	}

	/**
	 * [ReportBtn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitReportBtn(FSBBP0040 p) {
		// ブロック関連の初期化
		p.ReportBtnPanel = p.beansFactory.createPanel("ReportBtn");
		// ブロックの項目の初期化
		p.ReportBtn_add = p.beansFactory.createButton("ReportBtn.add", "no_border");
		p.ReportBtn_del = p.beansFactory.createButton("ReportBtn.del", "no_border");
	}

	/**
	 * [PrinterPnl]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitPrinterPnl(FSBBP0040 p) {
		// ブロック関連の初期化
		p.PrinterPnlPanel = p.beansFactory.createPanel("PrinterPnl");
		p.PrinterPnlTitledBorder = p.beansFactory.createTitledBorder();
		// ブロックの項目の初期化
	}

	/**
	 * [Printer]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitPrinter(FSBBP0040 p) {
		// ブロック関連の初期化
		p.PrinterPanel = p.beansFactory.createPanel("Printer");
		p.PrinterScrollPane = p.beansFactory.createScrollPane("Printer.scroll");
		p.createPrinterTable();
		// ブロックの項目の初期化
		p.columnPrinter_printer_id = p.beansFactory.createTableColumn("Printer.printer_id", MCColumnType.TEXT);
		p.columnPrinter_printer_name = p.beansFactory.createTableColumn("Printer.printer_name", MCColumnType.TEXT_COMBO_FREE);
	}

	/**
	 * [PrinterBtn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitPrinterBtn(FSBBP0040 p) {
		// ブロック関連の初期化
		p.PrinterBtnPanel = p.beansFactory.createPanel("PrinterBtn");
		// ブロックの項目の初期化
		p.PrinterBtn_add = p.beansFactory.createButton("PrinterBtn.add", "no_border");
		p.PrinterBtn_del = p.beansFactory.createButton("PrinterBtn.del", "no_border");
	}

	/**
	 * [Main]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitMain(FSBBP0040 p) {
		// ブロック関連の初期化
		p.MainPanel.setLayoutPosition("C+");
		// ブロックの項目の初期化
		p.MainPanel.add(p.PrintDef_TabPanel, null);
		p.MainPanel.setLastBeans(p.PrintDef_TabPanel);
		p.PrintDef_TabPanel.setNextBeans(p.ReportPnlPanel);
		p.MainPanel.add(p.ReportPnlPanel, null);
		p.ReportPnlPanel.setNextBeans(p.PrinterPnlPanel);
		p.MainPanel.add(p.PrinterPnlPanel, null);
	}

	/**
	 * [PrintDef_Tab]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitPrintDef_Tab(FSBBP0040 p) {
		// ブロック関連の初期化
		p.PrintDef_TabPanel.setBorder(p.PrintDef_TabTitledBorder);
		p.PrintDef_TabPanel.add(p.PrintDef_TabTab);
		p.PrintDef_TabPanel.setLastBeans(p.PrintDef_TabTab);
		p.PrintDef_TabPanel.setValueCheck(false);
		p.PrintDef_TabPanel.setLayoutPosition("N");
		// ブロックの項目の初期化
	}

	/**
	 * [ReportPnl]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitReportPnl(FSBBP0040 p) {
		// ブロック関連の初期化
		p.ReportPnlPanel.setBorder(p.ReportPnlTitledBorder);
		p.ReportPnlPanel.setLayoutPosition("CL+");
		// ブロックの項目の初期化
		p.ReportPnlPanel.add(p.ReportPanel, null);
		p.ReportPnlPanel.setLastBeans(p.ReportPanel);
		p.ReportPanel.setNextBeans(p.ReportBtnPanel);
		p.ReportPnlPanel.add(p.ReportBtnPanel, null);
	}

	/**
	 * [Report]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitReport(FSBBP0040 p) {
		// ブロック関連の初期化
		p.ReportPanel.add(p.ReportScrollPane);
		p.ReportPanel.setLastBeans(p.ReportTable);
		p.ReportScrollPane.setViewportView(p.ReportTable);
		p.ReportTable.setList(p.getReportL());
		p.ReportPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * [ReportBtn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitReportBtn(FSBBP0040 p) {
		// ブロック関連の初期化
		p.ReportBtnPanel.setLayoutPosition("S");
		// ブロックの項目の初期化
		p.ReportBtn_add.setIcon("INSERT_RECORD");
		p.ReportBtn_add.setFunctionKey(MCFunctionKey.F13);
		p.ReportBtnPanel.add(p.ReportBtn_add);
		p.ReportBtnPanel.setLastBeans(p.ReportBtn_add);
		p.ReportBtn_add.setNextBeans(p.ReportBtn_del);
		p.ReportBtn_del.setIcon("DELETE_RECORD");
		p.ReportBtn_del.setFunctionKey(MCFunctionKey.F14);
		p.ReportBtnPanel.add(p.ReportBtn_del);
	}

	/**
	 * [PrinterPnl]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitPrinterPnl(FSBBP0040 p) {
		// ブロック関連の初期化
		p.PrinterPnlPanel.setBorder(p.PrinterPnlTitledBorder);
		p.PrinterPnlPanel.setLayoutPosition("CR+");
		// ブロックの項目の初期化
		p.PrinterPnlPanel.add(p.PrinterPanel, null);
		p.PrinterPnlPanel.setLastBeans(p.PrinterPanel);
		p.PrinterPanel.setNextBeans(p.PrinterBtnPanel);
		p.PrinterPnlPanel.add(p.PrinterBtnPanel, null);
	}

	/**
	 * [Printer]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitPrinter(FSBBP0040 p) {
		// ブロック関連の初期化
		p.PrinterPanel.add(p.PrinterScrollPane);
		p.PrinterPanel.setLastBeans(p.PrinterTable);
		p.PrinterScrollPane.setViewportView(p.PrinterTable);
		p.PrinterTable.setList(p.getPrinterL());
		p.PrinterPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * [PrinterBtn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitPrinterBtn(FSBBP0040 p) {
		// ブロック関連の初期化
		p.PrinterBtnPanel.setLayoutPosition("S");
		// ブロックの項目の初期化
		p.PrinterBtn_add.setIcon("INSERT_RECORD");
		p.PrinterBtn_add.setFunctionKey(MCFunctionKey.F5);
		p.PrinterBtnPanel.add(p.PrinterBtn_add);
		p.PrinterBtnPanel.setLastBeans(p.PrinterBtn_add);
		p.PrinterBtn_add.setNextBeans(p.PrinterBtn_del);
		p.PrinterBtn_del.setIcon("DELETE_RECORD");
		p.PrinterBtn_del.setFunctionKey(MCFunctionKey.F6);
		p.PrinterBtnPanel.add(p.PrinterBtn_del);
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "S";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBBP0040_FW.mcInitMain((FSBBP0040)this);
		FSBBP0040_FW.mcInitPrintDef_Tab((FSBBP0040)this);
		FSBBP0040_FW.mcInitReportPnl((FSBBP0040)this);
		FSBBP0040_FW.mcInitReport((FSBBP0040)this);
		FSBBP0040_FW.mcInitReportBtn((FSBBP0040)this);
		FSBBP0040_FW.mcInitPrinterPnl((FSBBP0040)this);
		FSBBP0040_FW.mcInitPrinter((FSBBP0040)this);
		FSBBP0040_FW.mcInitPrinterBtn((FSBBP0040)this);

		// [INIT]ステータスのモードの設定
		FSBBP0040_FW.statusInitINIT_Main((FSBBP0040)this);
		FSBBP0040_FW.statusInitINIT_PrintDef__Tab((FSBBP0040)this);
		FSBBP0040_FW.statusInitINIT_ReportPnl((FSBBP0040)this);
		FSBBP0040_FW.statusInitINIT_Report((FSBBP0040)this);
		FSBBP0040_FW.statusInitINIT_ReportBtn((FSBBP0040)this);
		FSBBP0040_FW.statusInitINIT_PrinterPnl((FSBBP0040)this);
		FSBBP0040_FW.statusInitINIT_Printer((FSBBP0040)this);
		FSBBP0040_FW.statusInitINIT_PrinterBtn((FSBBP0040)this);

	}

	/**
	 *  [Main]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitMain(FSBBP0040 p) {
	}

	/**
	 *  [PrintDef_Tab]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitPrintDef_Tab(FSBBP0040 p) {
		p.PrintDef_TabTab.addAllListener(p);
	}

	/**
	 *  [ReportPnl]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitReportPnl(FSBBP0040 p) {
	}

	/**
	 *  [Report]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitReport(FSBBP0040 p) {
		p.ReportTable.addAllListener(p);
		p.columnReport_report_id.addAllListener(p);
		p.columnReport_report_id.setListListener(p);
		p.columnReport_report_name.addAllListener(p);
		p.columnReport_report_name.setListListener(p);
		p.columnReport_printer_id.addAllListener(p);
		p.columnReport_printer_id.setListListener(p);
		p.columnReport_preview.addAllListener(p);
		p.columnReport_dialog.addAllListener(p);
	}

	/**
	 *  [ReportBtn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitReportBtn(FSBBP0040 p) {
		p.ReportBtn_add.addAllListener(p);
		p.ReportBtn_add.setAPMethodName("doReportBtn_add");
		p.ReportBtn_del.addAllListener(p);
		p.ReportBtn_del.setAPMethodName("doReportBtn_del");
	}

	/**
	 *  [PrinterPnl]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitPrinterPnl(FSBBP0040 p) {
	}

	/**
	 *  [Printer]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitPrinter(FSBBP0040 p) {
		p.PrinterTable.addAllListener(p);
		p.columnPrinter_printer_id.addAllListener(p);
		p.columnPrinter_printer_id.setListListener(p);
		p.columnPrinter_printer_name.addAllListener(p);
		p.columnPrinter_printer_name.setListListener(p);
	}

	/**
	 *  [PrinterBtn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitPrinterBtn(FSBBP0040 p) {
		p.PrinterBtn_add.addAllListener(p);
		p.PrinterBtn_add.setAPMethodName("doPrinterBtn_add");
		p.PrinterBtn_del.addAllListener(p);
		p.PrinterBtn_del.setAPMethodName("doPrinterBtn_del");
	}

	/**
	 * [INIT]ステータスの[Main]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Main(FSBBP0040 p){

	}

	/**
	 * [INIT]ステータスの[PrintDef_Tab]ブロックのモードの設定
	 */
	protected static void statusInitINIT_PrintDef__Tab(FSBBP0040 p){

	}

	/**
	 * [INIT]ステータスの[ReportPnl]ブロックのモードの設定
	 */
	protected static void statusInitINIT_ReportPnl(FSBBP0040 p){

	}

	/**
	 * [INIT]ステータスの[Report]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Report(FSBBP0040 p){
		p.columnReport_report_id.putMode(p, INIT, MCMode.REQUIRED);
		p.columnReport_report_name.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnReport_printer_id.putMode(p, INIT, MCMode.ENABLE);
		p.columnReport_preview.putMode(p, INIT, MCMode.REQUIRED);
		p.columnReport_dialog.putMode(p, INIT, MCMode.REQUIRED);

	}

	/**
	 * [INIT]ステータスの[ReportBtn]ブロックのモードの設定
	 */
	protected static void statusInitINIT_ReportBtn(FSBBP0040 p){
		p.ReportBtn_add.putMode(p, INIT, MCMode.ENABLE);
		p.ReportBtn_del.putMode(p, INIT, MCMode.ENABLE);

	}

	/**
	 * [INIT]ステータスの[PrinterPnl]ブロックのモードの設定
	 */
	protected static void statusInitINIT_PrinterPnl(FSBBP0040 p){

	}

	/**
	 * [INIT]ステータスの[Printer]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Printer(FSBBP0040 p){
		p.columnPrinter_printer_id.putMode(p, INIT, MCMode.REQUIRED);
		p.columnPrinter_printer_name.putMode(p, INIT, MCMode.REQUIRED);

	}

	/**
	 * [INIT]ステータスの[PrinterBtn]ブロックのモードの設定
	 */
	protected static void statusInitINIT_PrinterBtn(FSBBP0040 p){
		p.PrinterBtn_add.putMode(p, INIT, MCMode.ENABLE);
		p.PrinterBtn_del.putMode(p, INIT, MCMode.ENABLE);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return INIT;
	}

	/**
	 * Table/Tree/GanttChartの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
		FSBBP0040_FW.setTableConfigReport((FSBBP0040)this);
		FSBBP0040_FW.setTableConfigPrinter((FSBBP0040)this);
	}

	/**
	 * [Report]ブロックのTableの設定
	 */
	protected static void setTableConfigReport(FSBBP0040 p) {
		p.columnReport_report_id.setMeta(mcframe.clientFSBB.FSBBP0040.ReportR.report_id_META);
		p.columnReport_report_id.addLinkBeans(p.columnReport_report_name);
		p.ReportTable.addColumnConfig(p.columnReport_report_id);
		p.columnReport_report_name.setMeta(mcframe.clientFSBB.FSBBP0040.ReportR.report_name_META);
		p.ReportTable.addColumnConfig(p.columnReport_report_name);
		p.columnReport_printer_id.setMeta(mcframe.clientFSBB.FSBBP0040.ReportR.printer_id_META);
		p.ReportTable.addColumnConfig(p.columnReport_printer_id);
		p.columnReport_preview.setMeta(mcframe.clientFSBB.FSBBP0040.ReportR.preview_META);
		p.ReportTable.addColumnConfig(p.columnReport_preview);
		p.columnReport_dialog.setMeta(mcframe.clientFSBB.FSBBP0040.ReportR.dialog_META);
		p.ReportTable.addColumnConfig(p.columnReport_dialog);
	}

	/**
	 * [Printer]ブロックのTableの設定
	 */
	protected static void setTableConfigPrinter(FSBBP0040 p) {
		p.columnPrinter_printer_id.setMeta(mcframe.clientFSBB.FSBBP0040.PrinterR.printer_id_META);
		p.PrinterTable.addColumnConfig(p.columnPrinter_printer_id);
		p.columnPrinter_printer_name.setMeta(mcframe.clientFSBB.FSBBP0040.PrinterR.printer_name_META);
		p.PrinterTable.addColumnConfig(p.columnPrinter_printer_name);
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
		columnReport_report_id.setListVisibleColumn(MCListLogic.getViewColumnName());
		columnReport_report_id.getListConfig().setPutter(getReport_report_id_ListPutter());
		columnReport_printer_id.setListVisibleColumn(MCListLogic.getViewColumnName());
		columnReport_printer_id.getListConfig().setPutter(getReport_printer_id_ListPutter());
		columnPrinter_printer_name.setListVisibleColumn(MCListLogic.getViewColumnName());
		columnPrinter_printer_name.getListConfig().setPutter(getPrinter_printer_name_ListPutter());
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
	}

	/**
	 * [Report_report_id_ListPutter]の作成
	 */
	protected MCListPutter createReport_report_id_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("FS.FSUAP0010.ReportID");
		return lp;
	}
	 
	/**
	 * [Report_printer_id_ListPutter]の作成
	 */
	protected MCListPutter createReport_printer_id_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("");
		return lp;
	}
	 
	/**
	 * [Printer_printer_name_ListPutter]の作成
	 */
	protected MCListPutter createPrinter_printer_name_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("FS.FSUAP0010.PrinterName");
		return lp;
	}
	 

	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		if(combo == columnReport_report_id) return getReport_report_id(row, info);
		if(combo == columnReport_printer_id) return getReport_printer_id(row, info);
		if(combo == columnPrinter_printer_name) return getPrinter_printer_name(row, info);
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == ReportBtn_add) doReportBtn_add(info);
		else if (ap == ReportBtn_del) doReportBtn_del(info);
		else if (ap == PrinterBtn_add) doPrinterBtn_add(info);
		else if (ap == PrinterBtn_del) doPrinterBtn_del(info);
	}

	/**
	 * [ReportBtn]パネルの[add]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doReportBtn_add(MCEventInfo info);

	/**
	 * [ReportBtn]パネルの[del]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doReportBtn_del(MCEventInfo info);

	/**
	 * [PrinterBtn]パネルの[add]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doPrinterBtn_add(MCEventInfo info);

	/**
	 * [PrinterBtn]パネルの[del]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doPrinterBtn_del(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == PrintDef_TabTab) return doPrintDef_Tab_VC(info);
		if (vc == ReportTable) return doReport_VC(info);
		if (vc == PrinterTable) return doPrinter_VC(info);
		if (vc == columnReport_report_id) return doReport_report_id_VC(info);
		if (vc == columnReport_report_name) return doReport_report_name_VC(info);
		if (vc == columnReport_printer_id) return doReport_printer_id_VC(info);
		if (vc == columnReport_preview) return doReport_preview_VC(info);
		if (vc == columnReport_dialog) return doReport_dialog_VC(info);
		if (vc == columnPrinter_printer_id) return doPrinter_printer_id_VC(info);
		if (vc == columnPrinter_printer_name) return doPrinter_printer_name_VC(info);
		return true;
	}

	/**
	 * [PrintDef_Tab]Tabの選択Tabが変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doPrintDef_Tab_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Report]Tableの選択行が変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doReport_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Printer]Tableの選択行が変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doPrinter_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Report]パネルの[report_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doReport_report_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Report]パネルの[report_name]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doReport_report_name_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Report]パネルの[printer_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doReport_printer_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Report]パネルの[preview]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doReport_preview_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Report]パネルの[dialog]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doReport_dialog_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Printer]パネルの[printer_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doPrinter_printer_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Printer]パネルの[printer_name]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doPrinter_printer_name_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == PrintDef_TabTab) doPrintDef_Tab_NC(info);
		else if (nc == ReportTable) doReport_NC(info);
		else if (nc == PrinterTable) doPrinter_NC(info);
		else if (nc == columnReport_report_id) doReport_report_id_NC(info);
		else if (nc == columnReport_report_name) doReport_report_name_NC(info);
		else if (nc == columnReport_printer_id) doReport_printer_id_NC(info);
		else if (nc == columnReport_preview) doReport_preview_NC(info);
		else if (nc == columnReport_dialog) doReport_dialog_NC(info);
		else if (nc == columnPrinter_printer_id) doPrinter_printer_id_NC(info);
		else if (nc == columnPrinter_printer_name) doPrinter_printer_name_NC(info);
	}

	/**
	 * [PrintDef_Tab]Tabの選択Tabが変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPrintDef_Tab_NC(MCEventInfo info){
	}

	/**
	 * [Report]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doReport_NC(MCEventInfo info){
	}

	/**
	 * [Printer]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPrinter_NC(MCEventInfo info){
	}

	/**
	 * [Report]パネルの[report_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doReport_report_id_NC(MCEventInfo info){
	}

	/**
	 * [Report]パネルの[report_name]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doReport_report_name_NC(MCEventInfo info){
	}

	/**
	 * [Report]パネルの[printer_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doReport_printer_id_NC(MCEventInfo info){
	}

	/**
	 * [Report]パネルの[preview]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doReport_preview_NC(MCEventInfo info){
	}

	/**
	 * [Report]パネルの[dialog]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doReport_dialog_NC(MCEventInfo info){
	}

	/**
	 * [Printer]パネルの[printer_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPrinter_printer_id_NC(MCEventInfo info){
	}

	/**
	 * [Printer]パネルの[printer_name]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPrinter_printer_name_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == PrintDef_TabTab) doPrintDef_Tab_NE(info);
		else if (ne == ReportTable) doReport_NE(info);
		else if (ne == PrinterTable) doPrinter_NE(info);
		else if (ne == columnReport_report_id) doReport_report_id_NE(info);
		else if (ne == columnReport_report_name) doReport_report_name_NE(info);
		else if (ne == columnReport_printer_id) doReport_printer_id_NE(info);
		else if (ne == columnReport_preview) doReport_preview_NE(info);
		else if (ne == columnReport_dialog) doReport_dialog_NE(info);
		else if (ne == columnPrinter_printer_id) doPrinter_printer_id_NE(info);
		else if (ne == columnPrinter_printer_name) doPrinter_printer_name_NE(info);
	}

	/**
	 * [PrintDef_Tab]TabのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPrintDef_Tab_NE(MCEventInfo info){
	}

	/**
	 * [Report]TableのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doReport_NE(MCEventInfo info){
	}

	/**
	 * [Printer]TableのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPrinter_NE(MCEventInfo info){
	}

	/**
	 * [Report]パネルの[report_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doReport_report_id_NE(MCEventInfo info){
	}

	/**
	 * [Report]パネルの[report_name]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doReport_report_name_NE(MCEventInfo info){
	}

	/**
	 * [Report]パネルの[printer_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doReport_printer_id_NE(MCEventInfo info){
	}

	/**
	 * [Report]パネルの[preview]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doReport_preview_NE(MCEventInfo info){
	}

	/**
	 * [Report]パネルの[dialog]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doReport_dialog_NE(MCEventInfo info){
	}

	/**
	 * [Printer]パネルの[printer_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPrinter_printer_id_NE(MCEventInfo info){
	}

	/**
	 * [Printer]パネルの[printer_name]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPrinter_printer_name_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == PrintDef_TabTab) doPrintDef_Tab_NX(info);
		else if (nx == ReportTable) doReport_NX(info);
		else if (nx == PrinterTable) doPrinter_NX(info);
		else if (nx == columnReport_report_id) doReport_report_id_NX(info);
		else if (nx == columnReport_report_name) doReport_report_name_NX(info);
		else if (nx == columnReport_printer_id) doReport_printer_id_NX(info);
		else if (nx == columnReport_preview) doReport_preview_NX(info);
		else if (nx == columnReport_dialog) doReport_dialog_NX(info);
		else if (nx == columnPrinter_printer_id) doPrinter_printer_id_NX(info);
		else if (nx == columnPrinter_printer_name) doPrinter_printer_name_NX(info);
	}

	/**
	 * [PrintDef_Tab]TabのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPrintDef_Tab_NX(MCEventInfo info){
	}

	/**
	 * [Report]TableのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doReport_NX(MCEventInfo info){
	}

	/**
	 * [Printer]TableのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPrinter_NX(MCEventInfo info){
	}

	/**
	 * [Report]パネルの[report_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doReport_report_id_NX(MCEventInfo info){
	}

	/**
	 * [Report]パネルの[report_name]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doReport_report_name_NX(MCEventInfo info){
	}

	/**
	 * [Report]パネルの[printer_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doReport_printer_id_NX(MCEventInfo info){
	}

	/**
	 * [Report]パネルの[preview]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doReport_preview_NX(MCEventInfo info){
	}

	/**
	 * [Report]パネルの[dialog]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doReport_dialog_NX(MCEventInfo info){
	}

	/**
	 * [Printer]パネルの[printer_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPrinter_printer_id_NX(MCEventInfo info){
	}

	/**
	 * [Printer]パネルの[printer_name]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPrinter_printer_name_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == columnReport_report_id) doReport_report_id_LC(info);
		else if (lc == columnReport_report_name) doReport_report_name_LC(info);
		else if (lc == columnReport_printer_id) doReport_printer_id_LC(info);
		else if (lc == columnPrinter_printer_id) doPrinter_printer_id_LC(info);
		else if (lc == columnPrinter_printer_name) doPrinter_printer_name_LC(info);
	}

	/**
	 * [Report]パネルの[report_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doReport_report_id_LC(MCEventInfo info){
	}

	/**
	 * [Report]パネルの[report_name]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doReport_report_name_LC(MCEventInfo info){
	}

	/**
	 * [Report]パネルの[printer_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doReport_printer_id_LC(MCEventInfo info){
	}

	/**
	 * [Printer]パネルの[printer_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPrinter_printer_id_LC(MCEventInfo info){
	}

	/**
	 * [Printer]パネルの[printer_name]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPrinter_printer_name_LC(MCEventInfo info){
	}

	/**
	 * コンボ／リストのリスト[columnReport_report_id]の作成メソッド
	 */
	public MCList getReport_report_id(MCRow row, MCEventInfo info){
		return ((mcframe.clientFSUA.FSUAP0010.FSUAP_List)MCListLogic.create("mcframe.clientFSUA.FSUAP0010.FSUAP_List", this)).getReportID(row, info);
	}

	/**
	 * コンボ／リストのリスト[columnReport_printer_id]の作成メソッド
	 */
	public MCList getReport_printer_id(MCRow row, MCEventInfo info){
		return null;
	}

	/**
	 * コンボ／リストのリスト[columnPrinter_printer_name]の作成メソッド
	 */
	public MCList getPrinter_printer_name(MCRow row, MCEventInfo info){
		return ((mcframe.clientFSUA.FSUAP0010.FSUAP_List)MCListLogic.create("mcframe.clientFSUA.FSUAP0010.FSUAP_List", this)).getPrinterName(row, info);
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}