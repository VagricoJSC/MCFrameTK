package mcframe.clientFSBB.FSBBP0040;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;


import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.clientCore.report.MCClientReportDefine;

import java.util.Map;
import java.util.Set;

import mcframe.clientFSBB.FSBBP0000.MCConfigPanel;
import mcframe.clientFSBB.FSBBP0000.MenuR;
import mcframe.commonFSUA.FSUAC0010.FSUAC_List;
import mcframe.commonCore.report.container.*;
import mcframe.commonCore.xml.MCXMLDocument;
import mcframe.clientCore.resource.MCConfig;
import mcframe.clientCore.resource.MCConst;

import java.io.File;

import org.w3c.dom.DOMException;

import mcframe.clientFSBB.FSBBP0050.FSBBP0050;
import mcframe.commonCore.report.MCReportConst;
import mcframe.commonCore.resource.ctrl.MCResource;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBBP0040"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBBP0040_FW extends FSBBP0040_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START
	
	/**
	 * 印刷関連の設定管理オブジェクトです。
	 */
	MCClientReportDefine rpDef = new MCClientReportDefine();
	
	
	/**
	 * カートリッジ毎の部品を保持するフィールドです。
	 */
	List<FSBBP0050> _pdefTab = new ArrayList<FSBBP0050>();
	
	/**
	 * GUI 部品の設定を変更したかどうかを表すフラグ
	 */
	boolean _beans_modify = false;
	
	/**
	 * 非表示カートリッジリスト取得用キー
	 */
	public static final String INVISIBLE_KEY = "invisible";
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBBP0040_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBBP0040_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * Panel[PrinterBtn]のボタン[add]の押下時の処理
	 */
	public void doPrinterBtn_add(MCEventInfo info) {
		insertRow(PrinterTable);
	}
	/**
	 * Panel[PrinterBtn]のボタン[del]の押下時の処理
	 */
	public void doPrinterBtn_del(MCEventInfo info) {
		deleteRow(PrinterTable);
	}
	/**
	 * Panel[ReportBtn]のボタン[add]の押下時の処理
	 */
	public void doReportBtn_add(MCEventInfo info) {
		insertRow(ReportTable);
	}
	/**
	 * Panel[ReportBtn]のボタン[del]の押下時の処理
	 */
	public void doReportBtn_del(MCEventInfo info) {
		deleteRow(ReportTable);
	}

	@Override
	protected void valueInit() {
		super.valueInit();
		reportDefLoad();
	}

	/**
	 * 
	 * 印刷関連の設定を読込ます。<P>
	 */
	public void reportDefLoad() {
		MCList<PrinterR> pl = createPrinterL();
		MCList<ReportR> rl = createReportL();
		
		getPrinterL().clear();
		getReportL().clear();
		
		for (int i = 0; i < _pdefTab.size(); i++) {
			_pdefTab.get(i).reportDefLoad();
		}
		
		rpDef.reload();
		// プリンタ定義
		MCPrinterL<MCPrinterR> pls = rpDef.getPrinterL();
		for (int i = 0; i < pls.size(); i++) {
			if (!pls.get(i).isDefaultPrinter()) {
				MCPrinterR pr = pls.get(i);
				PrinterR add = createPrinterR();
				add.printer_id(pr.printer_id());
				add.printer_name(pr.printer_name());
				pl.add(add);
			}
		}
		setPrinterL(pl);

		sort(PrinterTable);
		

		// 帳票定義
		MCReportDefineL<MCReportDefineR> rls = rpDef.getReportDefineL();
		for (int i = 0; i < rls.size(); i++) {
			MCReportDefineR rr = rls.get(i);
			ReportR add = createReportR();
			add.report_id(rr.report_id());
			add.report_name(rr.report_name());
			add.printer_id(rr.printer_id());
			add.preview(rr.preview());
			add.dialog(rr.dialog());
			rl.add(add);
		}
		setReportL(rl);
		sort(ReportTable);
	}

	@Override
	protected void fillSpaceForOpen() {
		super.fillSpaceForOpen();
		PrinterTable.adjustWidth();
		PrinterTable.fillSpace();
		ReportTable.adjustWidth();
		ReportTable.fillSpace();
	}

	@Override
	protected void listInit() {
		super.listInit();
		getReport_report_id_ListPutter().setColumns(FSUAC_List.ReportIDCols.outAll());
		getPrinter_printer_name_ListPutter().setColumns(
									FSUAC_List.PrinterNameCols.$o_printer_name);
		columnReport_printer_id.setListVisibleColumn(PrinterR.$printer_id,
														PrinterR.$printer_name);
	}	
	

	/**
	 * コンボ／リストのリスト[columnReport_printer_id]の作成メソッド
	 */
	public MCList getReport_printer_id(MCRow row, MCEventInfo info){
		MCList<PrinterR> rtn = getPrinterL().clone();
		for (int i = rtn.size() - 1; i >= 0; i--) {
			if (rtn.get(i).printer_id() == null) {
				rtn.remove(i);
			}
		}
		PrinterR def = createPrinterR();
		def.printer_id(rpDef.DEFAULT_PRINTER_ID);
		def.printer_name(rpDef.DEFAULT_PRINTER_NAME);
		rtn.add(0, def);
		return rtn;
	}

	/**
	 * 画面に設定されている情報および、この設定画面
	 * 以下の階層の設定をチェックします。<P>
	 *
	 * @return 問題ない場合は、true
	 * @see mcframe.clientFSBB.FSBBP0000.MCConfigPanel#checkConfig()
	 */
	@Override
	public boolean checkUpdConfig() {
		MCList<PrinterR> temp_pls = getPrinterL().statusChangedList();
		MCList<ReportR> temp_rls = getReportL().statusChangedList();
		
		//入力チェック
		MCMessageList ls = this.checkReq(temp_pls, temp_rls);
		
		for (int i = 0; i < _pdefTab.size(); i++) {
			_pdefTab.get(i).chekConfig(ls);
		}

		checkContainsPeriod(ls, temp_rls, columnReport_report_id);
		checkContainsPeriod(ls, temp_pls, columnPrinter_printer_id);

		//重複チェック
		this.checkDuplicate(ls, PrinterTable, PrinterR.$printer_id);
		this.checkDuplicate(ls, ReportTable, ReportR.$report_id);
		
		checkForeign(ls);
		
		//XMLのチェック
		chekXML(ls, temp_pls, temp_rls);
		
		if (ls.size() > 0) {
			this.message(ls);
			return false;
		}
		return true;
	}
	
	/**
	 * 指定されたカラムにピリオドが含まれていないかチェックします。
	 *
	 * @param ls メッセージリスト
	 * @param list チェック対象のリスト
	 * @param column カラムコンフィグ
	 */
	protected void checkContainsPeriod(MCMessageList ls, MCList list, MCColumnConfig column) {
		for (int i=0; i<list.size(); i++) {
			String v = list.get(i).getStringNE(column.getBaseRowColumnName());
			if (!isNull(v) && v.contains(".")) {
				ls.add(new MCMessage(list.get(i), column.getRowColumnName(), FSBBC0014, column.getMessageByLocale()));
			}
		}
	}
	
	/**
	 * プリンターIDと帳票IDの関連性をチェックします。<P>
	 *
	 * @param msgList メッセージリスト
	 */
	public void checkForeign(MCMessageList msgList) {
		MCList<PrinterR> pls = getPrinterL();
		MCIndexKey key = pls.createIndex(PrinterR.$printer_id);

		MCList<ReportR> rls = getReportL();
		for (int i = 0; i < rls.size(); i++) {
			ReportR r = rls.get(i);
			if (r.isStatusDelete() || r.printer_id() == null) {
				continue;
			}
			MCList<PrinterR> chk = pls.subList(key, r.printer_id());
			if (chk.size() > 0) {
				if (chk.get(0).isStatusDelete()){
					MCMessage msg = new MCMessage(FSBBC0004, r.printer_id());
					msgList.add(msg);
				}
			}else if (!r.printer_id().equals(rpDef.DEFAULT_PRINTER_ID)) {
				MCMessage msg = new MCMessage(FSBBC0011, r.printer_id());
				msgList.add(msg);
			}
		}	
	}

	/**
	 * 印刷関連の情報を更新します。<P>
	 *
	 * @see mcframe.clientFSBB.FSBBP0000.MCConfigPanel#saveConfig()
	 */
	@Override
	public void saveUpdConfig(MCMessageList msgList) {
		for (int i = 0; i < _pdefTab.size(); i++) {
			_pdefTab.get(i).saveConfig();
		}
		
		MCPrinterL<MCPrinterR> pls = MCPrinterL.createFC_ReportCommon_MCPrinter(MCPrinterR.class);
		for (int i = 0; i < getPrinterL().size(); i++) {
			PrinterR r = getPrinterL().get(i);
			if (r.isStatusDelete() || r.isEmpty()) {
				continue;
			}
			MCPrinterR addR = MCPrinterR.create();
			addR.printer_id(r.printer_id());
			addR.printer_name(r.printer_name());
			pls.add(addR);
		}
		rpDef.setPrinterList(pls);

		MCReportDefineL<MCReportDefineR> rls = 
						MCReportDefineL.createFC_ReportCommon_MCReportDefine(MCReportDefineR.class);
		for (int i = 0; i < getReportL().size(); i++) {
			ReportR r = getReportL().get(i);
			if (r.isStatusDelete() || r.isEmpty()) {
				continue;
			}
			MCReportDefineR addR = MCReportDefineR.create();
			addR.report_id(r.report_id());
			addR.report_name(r.report_name());
			addR.printer_id(r.printer_id());
			addR.preview(r.preview());
			addR.dialog(r.dialog());
			rls.add(addR);
		}
		rpDef.setReportDefineList(rls);
	}
	
	@Override
	public void saveDfltConfig(MCMessageList msgList) {
		for (int i = 0; i < _pdefTab.size(); i++) {
			_pdefTab.get(i).saveDefConfig();
		}
		rpDef.setPrinterList(MCPrinterL.createFC_ReportCommon_MCPrinter(MCPrinterR.class));
		
		rpDef.setReportDefineList(MCReportDefineL.createFC_ReportCommon_MCReportDefine(MCReportDefineR.class));
	}
	

	@Override
	public boolean beforeOpen() {
		if (super.beforeOpen()) {
			
			PrinterTable.addSortColumn(columnPrinter_printer_id, MCList.SortType.ASC);
			ReportTable.addSortColumn(columnReport_report_id, MCList.SortType.ASC);
			
			String dcn = MCReportConst.getClientCartridgeName();
			String dcnLbl = null;
			if (dcn != null) {
				String cn = MCReportConst.getClientCartridge(dcn);
				if (cn == null) {
					MCMessage msg = new MCMessage(FSBBC0010, dcn); 
					dcnLbl =  msg.toString();
				}
				else{
					String lbl = MCReportConst.getClientCartridgeLabel(dcn);				
					if (lbl == null) {
						lbl = dcn;
					}
					dcnLbl = lbl;
				}
			}
			FSBBP0050 tpl = FSBBP0050.create();
			tpl.setCartridge_name(FSBBP0050.DEFAULT, dcnLbl);  
			tpl.setDEFAULTStatus();
			
			_pdefTab.add(tpl);
			PrintDef_TabTab.add(tpl, MCConst.label.getLabel(
					MCResource.createKey("reportCartride", FSBBP0050.DEFAULT)));
			PrintDef_TabTab.setFirstBeans(tpl);

			
			String[] keys = MCReportConst.getClientCartridgeKeys();
			if (keys != null) {
				for (int i = 0; i < keys.length; i++) {
					String[] sp = MCResource.splitKey(keys[i]);
					if (isCartridgeInvisible(sp[2])) {
						continue;
					}
					String cn = MCReportConst.getClientCartridge(sp[2]);
					if (cn == null) {
						continue;
					}
					FSBBP0050 pl = FSBBP0050.create();
					pl.setCartridge_name(sp[2], null); 

					_pdefTab.get(_pdefTab.size() - 1).setNextBeans(pl);
					_pdefTab.add(pl);
					
					String lbl = MCReportConst.getClientCartridgeLabel(sp[2]);	
					if (lbl == null) {
						lbl = sp[2];
					}
					pl.setOTHERStatus();
					PrintDef_TabTab.add(pl, lbl);
					PrintDef_TabTab.setTabLayoutPolicy(
							PrintDef_TabTab.SCROLL_TAB_LAYOUT);
				}
			}
			return true;
		}
		return false;
	}

	/**
	 * カートリッジを非表示にするかどうか返します。
	 *
	 *@param c カートリッジ
	 * @return カートリッジを非表示にする場合true
	 */
	protected boolean isCartridgeInvisible(String c) {
		return MCConst.app.getBoolean(MCConst.createKey(MODULE_ID, SCREEN_ID, c, INVISIBLE_KEY), false);
	}

	/**
	 * 登録対象のリストのブロックでisEmptyのRowがあったら、
	 * その属性値をクリアしします。
	 */
	@Override
	protected void clearEmptyRowStatus() {
		super.clearEmptyRowStatus();
		for (FSBBP0050 tab : _pdefTab) {
			clearEmptyRowStatus(tab.getPrintDef_FormL());
		}
	}

	@Override
	public boolean isChanged() {
		boolean rtn = super.isChanged();
		if (!rtn) {
			for (int i = 0; i < _pdefTab.size(); i++) {
				if (_pdefTab.get(i).isChanged()) {
					return true;
				}
			}
		}
		return rtn;
	}
	
	/**
	 * XMLのタグになる値のチェックを行う。<P>
	 *
	 * @param ml メッセージリスト
	 * @param lp プリンタのリスト
	 * @param lr 帳票のリスト
	 */
	protected void chekXML(MCMessageList ml, MCList<PrinterR> lp, MCList<ReportR> lr) {
		MCXMLDocument doc = MCXMLDocument.createNewDocument("a", "b", null); 
		for (int i = 0; i < lp.size(); i++) {
			PrinterR r = lp.get(i);
			try{
				doc.createElement(r.printer_id());
			}catch (DOMException ex) {
				ml.add(new MCMessage(r, PrinterR.$printer_id, FSBBC0005,
						columnPrinter_printer_id.getLabelByLocale(),
							r.printer_id()));
			}
 		}
		for (int i = 0; i < lr.size(); i++) {
			ReportR r = lr.get(i);
			try{
				doc.createElement(r.report_id());
			}catch (DOMException ex) {
				ml.add(new MCMessage(r, ReportR.$report_id, FSBBC0005, 
						columnReport_report_id.getLabelByLocale(),
						r.report_id()));
			}
 		}
	}
	
	@Override
	public void setINITStatus() {
		super.setINITStatus();
		
		if (_pdefTab.size() > 0) {
			_pdefTab.get(0).focusFirstComponent();
		}
		
	}

	@Override
	public void doReport_report_id_NC(MCEventInfo info){
		super.doReport_report_id_NC(info);
		ReportR r = ReportTable.getSelectedMCRow();
		r.report_name(rpDef.getReportName(r.report_id()));
	}

	@Override
	public List<MCContainer> getContainers() {
		List<MCContainer> ret =  super.getContainers();
		for (int i = 0; i < _pdefTab.size(); i++) {
			ret.addAll(_pdefTab.get(i).getContainers());
		}
		return ret;
	}

}