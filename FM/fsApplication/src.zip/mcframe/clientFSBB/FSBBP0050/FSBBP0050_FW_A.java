package mcframe.clientFSBB.FSBBP0050;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBBP0050"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBBP0050_FW_A extends mcframe.clientFSUC.FSUCP0000.FSUCP_PanelBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBB";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBBP0050";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [PrintDef]ブロック関連のField定義
	public MCPanel PrintDefPanel = null;
	// [PrintDef]ブロックの項目のField定義
	public MCLabel PrintDef_print_command_Label = null;
	/**
	 *  帳票アプリケーションパス.<p>
	 *
	 */
	public MCTextField PrintDef_print_command = null;
	/**
	 * 参照 参照.<p>
	 *
	 */
	public MCButton PrintDef_print_command_FB = null;
	public MCLabel PrintDef_report_data_dir_Label = null;
	/**
	 *  帳票データディレクトリ.<p>
	 *
	 */
	public MCTextField PrintDef_report_data_dir = null;
	/**
	 * 参照 参照.<p>
	 *
	 */
	public MCButton PrintDef_report_data_dir_FB = null;
	public MCLabel PrintDef_report_if_dir_Label = null;
	/**
	 *  インターフェースファイルディレクトリ.<p>
	 *
	 */
	public MCTextField PrintDef_report_if_dir = null;
	/**
	 * 参照 参照.<p>
	 *
	 */
	public MCButton PrintDef_report_if_dir_FB = null;
	public MCLabel PrintDef_default_cartridge_name_Label = null;
	/**
	 *  デフォルトカートリッジ名.<p>
	 *
	 */
	public MCTextField PrintDef_default_cartridge_name = null;
	// [PrintDef_Form]ブロック関連のField定義
	public MCPanel PrintDef_FormPanel = null;
	public MCScrollPane PrintDef_FormScrollPane = null;
	public MCTable2<mcframe.clientFSBB.FSBBP0050.PrintDef_FormR> PrintDef_FormTable = null;
	// [PrintDef_Form]ブロックの項目のField定義
	/**
	 *  帳票フォームディレクトリ.<p>
	 *
	 */
	public MCColumnConfig columnPrintDef_Form_report_form_dir = null;
	// [Btn]ブロック関連のField定義
	public MCPanel BtnPanel = null;
	// [Btn]ブロックの項目のField定義
	/**
	 * 追加 追加.<p>
	 *
	 */
	public MCButton Btn_add = null;
	/**
	 * 削除 削除.<p>
	 *
	 */
	public MCButton Btn_del = null;
	public mcframe.clientFSUB.FSUBP0060.FSUBP_RowMove_H Btn_args_move_p_PPanel;
	/**
	 * 参照 参照.<p>
	 *
	 */
	public MCButton Btn_report_form_dir_FB = null;
	/** [DEFAULT]モードを表す定数 */
	public static final String DEFAULT = "DEFAULT";
	/** [OTHER]モードを表す定数 */
	public static final String OTHER = "OTHER";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{DEFAULT, OTHER};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	
	/** [PrintDef]ブロックのコンテナField定義 */
	private final mcframe.clientFSBB.FSBBP0050.PrintDefR aPrintDefR;
	/** [PrintDef_Form]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBB.FSBBP0050.PrintDef_FormR> aPrintDef_FormL;

	/**
	 * 項目コピーによってaPrintDefRを設定します。
	 *
	 * aPrintDefRのインスタンスは変更されません。
	 *
	 * @param row PrintDefR
	 */
	public void setPrintDefR(mcframe.clientFSBB.FSBBP0050.PrintDefR row) {
		if (row != null) {
			MCRow.copyall(getPrintDefR(), row);
		}
	}

	/**
	 * [PrintDef]ブロックのコンテナaPrintDefRを返します。
	 *
	 * @return PrintDefR
	 */
	public mcframe.clientFSBB.FSBBP0050.PrintDefR getPrintDefR() {
		return aPrintDefR;
	}

	/**
	 * aPrintDefRを作成します。
	 *
	 * @return PrintDefR
	 */
	public mcframe.clientFSBB.FSBBP0050.PrintDefR createPrintDefR() {
		return mcframe.clientFSBB.FSBBP0050.PrintDefR.create();
	}

	/**
	 * コピーによってaPrintDef_FormLを設定します。
	 *
	 * aPrintDef_FormLのインスタンスは変更されません。
	 *
	 * @param dataset PrintDef_FormL
	 */
	public void setPrintDef_FormL(MCList<mcframe.clientFSBB.FSBBP0050.PrintDef_FormR> aList) {
		if (getPrintDef_FormL() != aList) {
			getPrintDef_FormL().setAll(aList);
		}
	}

	/**
	 * [PrintDef_Form]ブロックのコンテナaPrintDef_FormLを返します。
	 *
	 * @return PrintDef_FormL
	 */
	public MCList<mcframe.clientFSBB.FSBBP0050.PrintDef_FormR> getPrintDef_FormL() {
		return aPrintDef_FormL;
	}

	/**
	 * aPrintDef_FormRを作成します。
	 *
	 * @return PrintDef_FormR
	 */
	public mcframe.clientFSBB.FSBBP0050.PrintDef_FormR createPrintDef_FormR() {
		return mcframe.clientFSBB.FSBBP0050.PrintDef_FormR.create();
	}

	/**
	 * aPrintDef_FormLを作成します。
	 *
	 * @return PrintDef_FormL
	 */
	public MCList<mcframe.clientFSBB.FSBBP0050.PrintDef_FormR> createPrintDef_FormL() {
		return MCList.create(mcframe.clientFSBB.FSBBP0050.PrintDef_FormR.class);
	}

	/**
	 * PrintDef_FormTableを初期化します。
	 */
	protected void createPrintDef_FormTable(){
		if(PrintDef_FormTable == null){
			PrintDef_FormTable = beansFactory.createTable2("PrintDef_Form.table");
		}
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getPrintDefR())) ret.add(getPrintDefR());
		if(!MCCollectionUtil.contains(ret, getPrintDef_FormL())) ret.add(getPrintDef_FormL());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getPrintDefR()) return "PrintDef";
		if(aCnt == getPrintDef_FormL()) return "PrintDef_Form";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("PrintDef")) return getPrintDefR();
		if(bId.equals("PrintDef_Form")) return getPrintDef_FormL();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(PrintDefPanel);
		ret.add(PrintDef_FormPanel);
		ret.add(BtnPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBBP0050_FW_A() {
		aPrintDefR = createPrintDefR();
		aPrintDef_FormL = createPrintDef_FormL();

	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBBP0050_FW_A(String name) {
		aPrintDefR = createPrintDefR();
		aPrintDef_FormL = createPrintDef_FormL();
		createPrintDef_FormTable();
		PrintDef_FormTable.setRowName(name);
	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBBP0050_FW.jbCreatePrintDef((FSBBP0050)this);
		FSBBP0050_FW.jbCreatePrintDef_Form((FSBBP0050)this);
		FSBBP0050_FW.jbCreateBtn((FSBBP0050)this);
	}

	/**
	 * [PrintDef]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreatePrintDef(FSBBP0050 p) {
	}

	/**
	 * [PrintDef_Form]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreatePrintDef_Form(FSBBP0050 p) {
	}

	/**
	 * [Btn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateBtn(FSBBP0050 p) {
		p.Btn_args_move_p_PPanel = mcframe.clientFSUB.FSUBP0060.FSUBP_RowMove_H.create();
		p.Btn_args_move_p_PPanel.setName("Btn.args_move_p");
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}


	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBBP0050 create(){
		FSBBP0050 p = new FSBBP0050();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBBP0050 create(String name){
		FSBBP0050 p = new FSBBP0050(name);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBBP0050_FW.jbfInitPrintDef((FSBBP0050)this);
		FSBBP0050_FW.jbfInitPrintDef_Form((FSBBP0050)this);
		FSBBP0050_FW.jbfInitBtn((FSBBP0050)this);
		FSBBP0050_FW.jbInitPrintDef((FSBBP0050)this);
		FSBBP0050_FW.jbInitPrintDef_Form((FSBBP0050)this);
		FSBBP0050_FW.jbInitBtn((FSBBP0050)this);
	}

	/**
	 * [PrintDef]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitPrintDef(FSBBP0050 p) {
		// ブロック関連の初期化
		p.PrintDefPanel = p.beansFactory.createPanel("PrintDef");
		// ブロックの項目の初期化
		p.PrintDef_print_command_Label = p.beansFactory.createLabel("PrintDef.print_command_Label");
		p.PrintDef_print_command = p.beansFactory.createTextField("PrintDef.print_command");
		p.PrintDef_print_command.setLabel(p.PrintDef_print_command_Label);
		p.PrintDef_print_command_FB = p.beansFactory.createButton("PrintDef.print_command_FB", "no_border");
		p.PrintDef_report_data_dir_Label = p.beansFactory.createLabel("PrintDef.report_data_dir_Label");
		p.PrintDef_report_data_dir = p.beansFactory.createTextField("PrintDef.report_data_dir");
		p.PrintDef_report_data_dir.setLabel(p.PrintDef_report_data_dir_Label);
		p.PrintDef_report_data_dir_FB = p.beansFactory.createButton("PrintDef.report_data_dir_FB", "no_border");
		p.PrintDef_report_if_dir_Label = p.beansFactory.createLabel("PrintDef.report_if_dir_Label");
		p.PrintDef_report_if_dir = p.beansFactory.createTextField("PrintDef.report_if_dir");
		p.PrintDef_report_if_dir.setLabel(p.PrintDef_report_if_dir_Label);
		p.PrintDef_report_if_dir_FB = p.beansFactory.createButton("PrintDef.report_if_dir_FB", "no_border");
		p.PrintDef_default_cartridge_name_Label = p.beansFactory.createLabel("PrintDef.default_cartridge_name_Label");
		p.PrintDef_default_cartridge_name = p.beansFactory.createTextField("PrintDef.default_cartridge_name");
		p.PrintDef_default_cartridge_name.setLabel(p.PrintDef_default_cartridge_name_Label);
	}

	/**
	 * [PrintDef_Form]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitPrintDef_Form(FSBBP0050 p) {
		// ブロック関連の初期化
		p.PrintDef_FormPanel = p.beansFactory.createPanel("PrintDef_Form");
		p.PrintDef_FormScrollPane = p.beansFactory.createScrollPane("PrintDef_Form.scroll");
		p.createPrintDef_FormTable();
		// ブロックの項目の初期化
		p.columnPrintDef_Form_report_form_dir = p.beansFactory.createTableColumn("PrintDef_Form.report_form_dir", MCColumnType.TEXT);
	}

	/**
	 * [Btn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitBtn(FSBBP0050 p) {
		// ブロック関連の初期化
		p.BtnPanel = p.beansFactory.createPanel("Btn");
		// ブロックの項目の初期化
		p.Btn_add = p.beansFactory.createButton("Btn.add", "no_border");
		p.Btn_del = p.beansFactory.createButton("Btn.del", "no_border");
		p.Btn_report_form_dir_FB = p.beansFactory.createButton("Btn.report_form_dir_FB", "no_border");
	}

	/**
	 * [PrintDef]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitPrintDef(FSBBP0050 p) {
		// ブロック関連の初期化
		p.add(p.PrintDefPanel);
		p.setLastBeans(p.PrintDefPanel);
		p.PrintDefPanel.setNextBeans(p.PrintDef_FormPanel);
		p.PrintDefPanel.setLayoutPosition("N");
		// ブロックの項目の初期化
		p.PrintDefPanel.add(p.PrintDef_print_command_Label);
		p.PrintDefPanel.add(p.PrintDef_print_command);
		p.PrintDefPanel.setLastBeans(p.PrintDef_print_command);
		p.PrintDef_print_command.setNextBeans(p.PrintDef_print_command_FB);
		p.PrintDef_print_command.setRow(p.getPrintDefR(), mcframe.clientFSBB.FSBBP0050.PrintDefR.print_command_META);
		p.PrintDef_print_command_FB.setIcon("FOLDER");
		p.PrintDef_print_command_FB.setFunctionKey(MCFunctionKey.F23);
		p.PrintDefPanel.add(p.PrintDef_print_command_FB);
		p.PrintDef_print_command_FB.setNextBeans(p.PrintDef_report_data_dir);
		p.PrintDefPanel.add(p.PrintDef_report_data_dir_Label);
		p.PrintDefPanel.add(p.PrintDef_report_data_dir);
		p.PrintDef_report_data_dir.setNextBeans(p.PrintDef_report_data_dir_FB);
		p.PrintDef_report_data_dir.setRow(p.getPrintDefR(), mcframe.clientFSBB.FSBBP0050.PrintDefR.report_data_dir_META);
		p.PrintDef_report_data_dir_FB.setIcon("FOLDER");
		p.PrintDef_report_data_dir_FB.setFunctionKey(MCFunctionKey.F15);
		p.PrintDefPanel.add(p.PrintDef_report_data_dir_FB);
		p.PrintDef_report_data_dir_FB.setNextBeans(p.PrintDef_report_if_dir);
		p.PrintDefPanel.add(p.PrintDef_report_if_dir_Label);
		p.PrintDefPanel.add(p.PrintDef_report_if_dir);
		p.PrintDef_report_if_dir.setNextBeans(p.PrintDef_report_if_dir_FB);
		p.PrintDef_report_if_dir.setRow(p.getPrintDefR(), mcframe.clientFSBB.FSBBP0050.PrintDefR.report_if_dir_META);
		p.PrintDef_report_if_dir_FB.setIcon("FOLDER");
		p.PrintDef_report_if_dir_FB.setFunctionKey(MCFunctionKey.F15);
		p.PrintDefPanel.add(p.PrintDef_report_if_dir_FB);
		p.PrintDef_report_if_dir_FB.setNextBeans(p.PrintDef_default_cartridge_name);
		p.PrintDefPanel.add(p.PrintDef_default_cartridge_name_Label);
		p.PrintDefPanel.add(p.PrintDef_default_cartridge_name);
		p.PrintDef_default_cartridge_name.setRow(p.getPrintDefR(), mcframe.clientFSBB.FSBBP0050.PrintDefR.default_cartridge_name_META);
	}

	/**
	 * [PrintDef_Form]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitPrintDef_Form(FSBBP0050 p) {
		// ブロック関連の初期化
		p.add(p.PrintDef_FormPanel);
		p.PrintDef_FormPanel.setNextBeans(p.BtnPanel);
		p.PrintDef_FormPanel.add(p.PrintDef_FormScrollPane);
		p.PrintDef_FormPanel.setLastBeans(p.PrintDef_FormTable);
		p.PrintDef_FormScrollPane.setViewportView(p.PrintDef_FormTable);
		p.PrintDef_FormTable.setList(p.getPrintDef_FormL());
		p.PrintDef_FormPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * [Btn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitBtn(FSBBP0050 p) {
		// ブロック関連の初期化
		p.add(p.BtnPanel);
		p.BtnPanel.setLayoutPosition("S");
		// ブロックの項目の初期化
		p.Btn_add.setIcon("INSERT_RECORD");
		p.Btn_add.setFunctionKey(MCFunctionKey.F7);
		p.BtnPanel.add(p.Btn_add);
		p.BtnPanel.setLastBeans(p.Btn_add);
		p.Btn_add.setNextBeans(p.Btn_del);
		p.Btn_del.setIcon("DELETE_RECORD");
		p.Btn_del.setFunctionKey(MCFunctionKey.F8);
		p.BtnPanel.add(p.Btn_del);
		p.Btn_del.setNextBeans(p.Btn_args_move_p_PPanel);
		p.BtnPanel.add(p.Btn_args_move_p_PPanel);
		p.Btn_args_move_p_PPanel.setNextBeans(p.Btn_report_form_dir_FB);
		p.Btn_report_form_dir_FB.setIcon("FOLDER");
		p.Btn_report_form_dir_FB.setFunctionKey(MCFunctionKey.F17);
		p.BtnPanel.add(p.Btn_report_form_dir_FB);
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "S";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBBP0050_FW.mcInitPrintDef((FSBBP0050)this);
		FSBBP0050_FW.mcInitPrintDef_Form((FSBBP0050)this);
		FSBBP0050_FW.mcInitBtn((FSBBP0050)this);

		// [DEFAULT]ステータスのモードの設定
		FSBBP0050_FW.statusInitDEFAULT_PrintDef((FSBBP0050)this);
		FSBBP0050_FW.statusInitDEFAULT_PrintDef__Form((FSBBP0050)this);
		FSBBP0050_FW.statusInitDEFAULT_Btn((FSBBP0050)this);

		// [OTHER]ステータスのモードの設定
		FSBBP0050_FW.statusInitOTHER_PrintDef((FSBBP0050)this);
		FSBBP0050_FW.statusInitOTHER_PrintDef__Form((FSBBP0050)this);
		FSBBP0050_FW.statusInitOTHER_Btn((FSBBP0050)this);

	}

	/**
	 *  [PrintDef]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitPrintDef(FSBBP0050 p) {
		p.PrintDef_print_command.setListListener(p);
		p.PrintDef_print_command.addAllListener(p);
		p.PrintDef_print_command_FB.addAllListener(p);
		p.PrintDef_print_command_FB.setAPMethodName("doPrintDef_print_command_FB");
		p.PrintDef_report_data_dir.setListListener(p);
		p.PrintDef_report_data_dir.addAllListener(p);
		p.PrintDef_report_data_dir_FB.addAllListener(p);
		p.PrintDef_report_data_dir_FB.setAPMethodName("doPrintDef_report_data_dir_FB");
		p.PrintDef_report_if_dir.setListListener(p);
		p.PrintDef_report_if_dir.addAllListener(p);
		p.PrintDef_report_if_dir_FB.addAllListener(p);
		p.PrintDef_report_if_dir_FB.setAPMethodName("doPrintDef_report_if_dir_FB");
		p.PrintDef_default_cartridge_name.setListListener(p);
		p.PrintDef_default_cartridge_name.addAllListener(p);
	}

	/**
	 *  [PrintDef_Form]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitPrintDef_Form(FSBBP0050 p) {
		p.PrintDef_FormTable.addAllListener(p);
		p.columnPrintDef_Form_report_form_dir.addAllListener(p);
		p.columnPrintDef_Form_report_form_dir.setListListener(p);
	}

	/**
	 *  [Btn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitBtn(FSBBP0050 p) {
		p.Btn_add.addAllListener(p);
		p.Btn_add.setAPMethodName("doBtn_add");
		p.Btn_del.addAllListener(p);
		p.Btn_del.setAPMethodName("doBtn_del");
		p.Btn_report_form_dir_FB.addAllListener(p);
		p.Btn_report_form_dir_FB.setAPMethodName("doBtn_report_form_dir_FB");
	}

	/**
	 * [DEFAULT]ステータスの[PrintDef]ブロックのモードの設定
	 */
	protected static void statusInitDEFAULT_PrintDef(FSBBP0050 p){
		p.PrintDef_print_command.putMode(p, DEFAULT, MCMode.INVISIBLE);
		p.PrintDef_print_command_FB.putMode(p, DEFAULT, MCMode.INVISIBLE);
		p.PrintDef_report_data_dir.putMode(p, DEFAULT, MCMode.INVISIBLE);
		p.PrintDef_report_data_dir_FB.putMode(p, DEFAULT, MCMode.INVISIBLE);
		p.PrintDef_report_if_dir.putMode(p, DEFAULT, MCMode.ENABLE);
		p.PrintDef_report_if_dir_FB.putMode(p, DEFAULT, MCMode.ENABLE);
		p.PrintDef_default_cartridge_name.putMode(p, DEFAULT, MCMode.READ_ONLY);

	}

	/**
	 * [DEFAULT]ステータスの[PrintDef_Form]ブロックのモードの設定
	 */
	protected static void statusInitDEFAULT_PrintDef__Form(FSBBP0050 p){
		p.columnPrintDef_Form_report_form_dir.putMode(p, DEFAULT, MCMode.INVISIBLE);

	}

	/**
	 * [DEFAULT]ステータスの[Btn]ブロックのモードの設定
	 */
	protected static void statusInitDEFAULT_Btn(FSBBP0050 p){
		p.Btn_add.putMode(p, DEFAULT, MCMode.INVISIBLE);
		p.Btn_del.putMode(p, DEFAULT, MCMode.INVISIBLE);
		p.Btn_args_move_p_PPanel.putStatus(DEFAULT, mcframe.clientFSUB.FSUBP0060.FSUBP_RowMove_H.INVISIBLE);
		p.Btn_report_form_dir_FB.putMode(p, DEFAULT, MCMode.INVISIBLE);

	}

	/**
	 * [OTHER]ステータスの[PrintDef]ブロックのモードの設定
	 */
	protected static void statusInitOTHER_PrintDef(FSBBP0050 p){
		p.PrintDef_print_command.putMode(p, OTHER, MCMode.ENABLE);
		p.PrintDef_print_command_FB.putMode(p, OTHER, MCMode.ENABLE);
		p.PrintDef_report_data_dir.putMode(p, OTHER, MCMode.ENABLE);
		p.PrintDef_report_data_dir_FB.putMode(p, OTHER, MCMode.ENABLE);
		p.PrintDef_report_if_dir.putMode(p, OTHER, MCMode.INVISIBLE);
		p.PrintDef_report_if_dir_FB.putMode(p, OTHER, MCMode.INVISIBLE);
		p.PrintDef_default_cartridge_name.putMode(p, OTHER, MCMode.INVISIBLE);

	}

	/**
	 * [OTHER]ステータスの[PrintDef_Form]ブロックのモードの設定
	 */
	protected static void statusInitOTHER_PrintDef__Form(FSBBP0050 p){
		p.columnPrintDef_Form_report_form_dir.putMode(p, OTHER, MCMode.ENABLE);

	}

	/**
	 * [OTHER]ステータスの[Btn]ブロックのモードの設定
	 */
	protected static void statusInitOTHER_Btn(FSBBP0050 p){
		p.Btn_add.putMode(p, OTHER, MCMode.ENABLE);
		p.Btn_del.putMode(p, OTHER, MCMode.ENABLE);
		p.Btn_args_move_p_PPanel.putStatus(OTHER, mcframe.clientFSUB.FSUBP0060.FSUBP_RowMove_H.ENABLE);
		p.Btn_report_form_dir_FB.putMode(p, OTHER, MCMode.ENABLE);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return DEFAULT;
	}

	/**
	 * Table/Tree/GanttChartの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
		FSBBP0050_FW.setTableConfigPrintDef_Form((FSBBP0050)this);
	}

	/**
	 * [PrintDef_Form]ブロックのTableの設定
	 */
	protected static void setTableConfigPrintDef_Form(FSBBP0050 p) {
		p.columnPrintDef_Form_report_form_dir.setMeta(mcframe.clientFSBB.FSBBP0050.PrintDef_FormR.report_form_dir_META);
		p.PrintDef_FormTable.addColumnConfig(p.columnPrintDef_Form_report_form_dir);
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
	}

	/**
	 * この画面を[DEFAULT]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setDEFAULTStatus() {
		status = DEFAULT;
		setAllStatus(status);
	}

	/**
	 * この画面を[OTHER]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setOTHERStatus() {
		status = OTHER;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (DEFAULT.equals(status)) {
			setDEFAULTStatus();
		}
		else if (OTHER.equals(status)) {
			setOTHERStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}


	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == PrintDef_print_command_FB) doPrintDef_print_command_FB(info);
		else if (ap == PrintDef_report_data_dir_FB) doPrintDef_report_data_dir_FB(info);
		else if (ap == PrintDef_report_if_dir_FB) doPrintDef_report_if_dir_FB(info);
		else if (ap == Btn_add) doBtn_add(info);
		else if (ap == Btn_del) doBtn_del(info);
		else if (ap == Btn_report_form_dir_FB) doBtn_report_form_dir_FB(info);
	}

	/**
	 * [PrintDef]パネルの[print_command_FB]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doPrintDef_print_command_FB(MCEventInfo info);

	/**
	 * [PrintDef]パネルの[report_data_dir_FB]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doPrintDef_report_data_dir_FB(MCEventInfo info);

	/**
	 * [PrintDef]パネルの[report_if_dir_FB]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doPrintDef_report_if_dir_FB(MCEventInfo info);

	/**
	 * [Btn]パネルの[add]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_add(MCEventInfo info);

	/**
	 * [Btn]パネルの[del]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_del(MCEventInfo info);

	/**
	 * [Btn]パネルの[report_form_dir_FB]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_report_form_dir_FB(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == PrintDef_FormTable) return doPrintDef_Form_VC(info);
		if (vc == PrintDef_print_command) return doPrintDef_print_command_VC(info);
		if (vc == PrintDef_report_data_dir) return doPrintDef_report_data_dir_VC(info);
		if (vc == PrintDef_report_if_dir) return doPrintDef_report_if_dir_VC(info);
		if (vc == PrintDef_default_cartridge_name) return doPrintDef_default_cartridge_name_VC(info);
		if (vc == columnPrintDef_Form_report_form_dir) return doPrintDef_Form_report_form_dir_VC(info);
		return true;
	}

	/**
	 * [PrintDef_Form]Tableの選択行が変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doPrintDef_Form_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [PrintDef]パネルの[print_command]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doPrintDef_print_command_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [PrintDef]パネルの[report_data_dir]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doPrintDef_report_data_dir_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [PrintDef]パネルの[report_if_dir]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doPrintDef_report_if_dir_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [PrintDef]パネルの[default_cartridge_name]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doPrintDef_default_cartridge_name_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [PrintDef_Form]パネルの[report_form_dir]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doPrintDef_Form_report_form_dir_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == PrintDef_FormTable) doPrintDef_Form_NC(info);
		else if (nc == PrintDef_print_command) doPrintDef_print_command_NC(info);
		else if (nc == PrintDef_report_data_dir) doPrintDef_report_data_dir_NC(info);
		else if (nc == PrintDef_report_if_dir) doPrintDef_report_if_dir_NC(info);
		else if (nc == PrintDef_default_cartridge_name) doPrintDef_default_cartridge_name_NC(info);
		else if (nc == columnPrintDef_Form_report_form_dir) doPrintDef_Form_report_form_dir_NC(info);
	}

	/**
	 * [PrintDef_Form]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPrintDef_Form_NC(MCEventInfo info){
	}

	/**
	 * [PrintDef]パネルの[print_command]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPrintDef_print_command_NC(MCEventInfo info){
	}

	/**
	 * [PrintDef]パネルの[report_data_dir]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPrintDef_report_data_dir_NC(MCEventInfo info){
	}

	/**
	 * [PrintDef]パネルの[report_if_dir]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPrintDef_report_if_dir_NC(MCEventInfo info){
	}

	/**
	 * [PrintDef]パネルの[default_cartridge_name]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPrintDef_default_cartridge_name_NC(MCEventInfo info){
	}

	/**
	 * [PrintDef_Form]パネルの[report_form_dir]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPrintDef_Form_report_form_dir_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == PrintDef_FormTable) doPrintDef_Form_NE(info);
		else if (ne == PrintDef_print_command) doPrintDef_print_command_NE(info);
		else if (ne == PrintDef_report_data_dir) doPrintDef_report_data_dir_NE(info);
		else if (ne == PrintDef_report_if_dir) doPrintDef_report_if_dir_NE(info);
		else if (ne == PrintDef_default_cartridge_name) doPrintDef_default_cartridge_name_NE(info);
		else if (ne == columnPrintDef_Form_report_form_dir) doPrintDef_Form_report_form_dir_NE(info);
	}

	/**
	 * [PrintDef_Form]TableのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPrintDef_Form_NE(MCEventInfo info){
	}

	/**
	 * [PrintDef]パネルの[print_command]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPrintDef_print_command_NE(MCEventInfo info){
	}

	/**
	 * [PrintDef]パネルの[report_data_dir]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPrintDef_report_data_dir_NE(MCEventInfo info){
	}

	/**
	 * [PrintDef]パネルの[report_if_dir]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPrintDef_report_if_dir_NE(MCEventInfo info){
	}

	/**
	 * [PrintDef]パネルの[default_cartridge_name]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPrintDef_default_cartridge_name_NE(MCEventInfo info){
	}

	/**
	 * [PrintDef_Form]パネルの[report_form_dir]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPrintDef_Form_report_form_dir_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == PrintDef_FormTable) doPrintDef_Form_NX(info);
		else if (nx == PrintDef_print_command) doPrintDef_print_command_NX(info);
		else if (nx == PrintDef_report_data_dir) doPrintDef_report_data_dir_NX(info);
		else if (nx == PrintDef_report_if_dir) doPrintDef_report_if_dir_NX(info);
		else if (nx == PrintDef_default_cartridge_name) doPrintDef_default_cartridge_name_NX(info);
		else if (nx == columnPrintDef_Form_report_form_dir) doPrintDef_Form_report_form_dir_NX(info);
	}

	/**
	 * [PrintDef_Form]TableのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPrintDef_Form_NX(MCEventInfo info){
	}

	/**
	 * [PrintDef]パネルの[print_command]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPrintDef_print_command_NX(MCEventInfo info){
	}

	/**
	 * [PrintDef]パネルの[report_data_dir]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPrintDef_report_data_dir_NX(MCEventInfo info){
	}

	/**
	 * [PrintDef]パネルの[report_if_dir]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPrintDef_report_if_dir_NX(MCEventInfo info){
	}

	/**
	 * [PrintDef]パネルの[default_cartridge_name]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPrintDef_default_cartridge_name_NX(MCEventInfo info){
	}

	/**
	 * [PrintDef_Form]パネルの[report_form_dir]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPrintDef_Form_report_form_dir_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == PrintDef_print_command) doPrintDef_print_command_LC(info);
		else if (lc == PrintDef_report_data_dir) doPrintDef_report_data_dir_LC(info);
		else if (lc == PrintDef_report_if_dir) doPrintDef_report_if_dir_LC(info);
		else if (lc == PrintDef_default_cartridge_name) doPrintDef_default_cartridge_name_LC(info);
		else if (lc == columnPrintDef_Form_report_form_dir) doPrintDef_Form_report_form_dir_LC(info);
	}

	/**
	 * [PrintDef]パネルの[print_command]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPrintDef_print_command_LC(MCEventInfo info){
	}

	/**
	 * [PrintDef]パネルの[report_data_dir]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPrintDef_report_data_dir_LC(MCEventInfo info){
	}

	/**
	 * [PrintDef]パネルの[report_if_dir]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPrintDef_report_if_dir_LC(MCEventInfo info){
	}

	/**
	 * [PrintDef]パネルの[default_cartridge_name]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPrintDef_default_cartridge_name_LC(MCEventInfo info){
	}

	/**
	 * [PrintDef_Form]パネルの[report_form_dir]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doPrintDef_Form_report_form_dir_LC(MCEventInfo info){
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}