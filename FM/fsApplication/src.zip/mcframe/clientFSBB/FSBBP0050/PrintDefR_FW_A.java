package mcframe.clientFSBB.FSBBP0050;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"PrintDef"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class PrintDefR_FW_A extends MCConstRow {

	/**
	 *  カードリッジ名称.<p>
	 *
	 */
	public static final String $cartridge_name = "cartridge_name";
	/**
	 *  帳票アプリケーションパス.<p>
	 *
	 */
	public static final String $print_command = "print_command";
	/**
	 *  帳票データディレクトリ.<p>
	 *
	 */
	public static final String $report_data_dir = "report_data_dir";
	/**
	 *  インターフェースファイルディレクトリ.<p>
	 *
	 */
	public static final String $report_if_dir = "report_if_dir";
	/**
	 *  デフォルトカートリッジ名.<p>
	 *
	 */
	public static final String $default_cartridge_name = "default_cartridge_name";


	public static final MCMeta cartridge_name_META = createCommonMeta($cartridge_name, mcframe.commonCore.meta.M_META.CARTRIDGE_NM);
	public static final MCMeta print_command_META = createCommonMeta($print_command, mcframe.commonCore.meta.M_META.PRINT_COMMAND);
	public static final MCMeta report_data_dir_META = createCommonMeta($report_data_dir, mcframe.commonCore.meta.M_META.PATH);
	public static final MCMeta report_if_dir_META = createCommonMeta($report_if_dir, mcframe.commonCore.meta.M_META.PATH);
	public static final MCMeta default_cartridge_name_META = createCommonMeta($default_cartridge_name, mcframe.commonCore.meta.M_META.CARTRIDGE_NM);

	protected static final ConstMetaList<PrintDefR> constMetas = new ConstMetaList<PrintDefR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			cartridge_name_META,
			print_command_META,
			report_data_dir_META,
			report_if_dir_META,
			default_cartridge_name_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected PrintDefR_FW_A(ConstMetaList<? extends PrintDefR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public PrintDefR clone() {
		return (PrintDefR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public PrintDefR createInstance() {
		return (PrintDefR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public PrintDefR getValues(String... names) {
		return (PrintDefR) super.getValues(names);
	}



	/**
	 *  カードリッジ名称.<p>
	 *
	 */
	public String cartridge_name() {
		return getConstString(offset + 0, $cartridge_name);
	}

	/**
	 *  カードリッジ名称.<p>
	 *
	 */
	public void cartridge_name(String value) {
		setConstString(offset + 0, $cartridge_name, value);
	}


	/**
	 *  帳票アプリケーションパス.<p>
	 *
	 */
	public String print_command() {
		return getConstString(offset + 1, $print_command);
	}

	/**
	 *  帳票アプリケーションパス.<p>
	 *
	 */
	public void print_command(String value) {
		setConstString(offset + 1, $print_command, value);
	}


	/**
	 *  帳票データディレクトリ.<p>
	 *
	 */
	public String report_data_dir() {
		return getConstString(offset + 2, $report_data_dir);
	}

	/**
	 *  帳票データディレクトリ.<p>
	 *
	 */
	public void report_data_dir(String value) {
		setConstString(offset + 2, $report_data_dir, value);
	}


	/**
	 *  インターフェースファイルディレクトリ.<p>
	 *
	 */
	public String report_if_dir() {
		return getConstString(offset + 3, $report_if_dir);
	}

	/**
	 *  インターフェースファイルディレクトリ.<p>
	 *
	 */
	public void report_if_dir(String value) {
		setConstString(offset + 3, $report_if_dir, value);
	}


	/**
	 *  デフォルトカートリッジ名.<p>
	 *
	 */
	public String default_cartridge_name() {
		return getConstString(offset + 4, $default_cartridge_name);
	}

	/**
	 *  デフォルトカートリッジ名.<p>
	 *
	 */
	public void default_cartridge_name(String value) {
		setConstString(offset + 4, $default_cartridge_name, value);
	}


	public String getString(String name) {
		if ($cartridge_name.equalsIgnoreCase(name)) {
			return cartridge_name();
		}
		if ($print_command.equalsIgnoreCase(name)) {
			return print_command();
		}
		if ($report_data_dir.equalsIgnoreCase(name)) {
			return report_data_dir();
		}
		if ($report_if_dir.equalsIgnoreCase(name)) {
			return report_if_dir();
		}
		if ($default_cartridge_name.equalsIgnoreCase(name)) {
			return default_cartridge_name();
		}
		return super.getString(name);
	}

	public String getStringNE(String name) {
		if ($cartridge_name.equalsIgnoreCase(name)) {
			return cartridge_name();
		}
		if ($print_command.equalsIgnoreCase(name)) {
			return print_command();
		}
		if ($report_data_dir.equalsIgnoreCase(name)) {
			return report_data_dir();
		}
		if ($report_if_dir.equalsIgnoreCase(name)) {
			return report_if_dir();
		}
		if ($default_cartridge_name.equalsIgnoreCase(name)) {
			return default_cartridge_name();
		}
		return super.getStringNE(name);
	}

	public void setString(String name, String value) {
		if ($cartridge_name.equalsIgnoreCase(name)) {
			cartridge_name(value);
			return;
		}
		if ($print_command.equalsIgnoreCase(name)) {
			print_command(value);
			return;
		}
		if ($report_data_dir.equalsIgnoreCase(name)) {
			report_data_dir(value);
			return;
		}
		if ($report_if_dir.equalsIgnoreCase(name)) {
			report_if_dir(value);
			return;
		}
		if ($default_cartridge_name.equalsIgnoreCase(name)) {
			default_cartridge_name(value);
			return;
		}
		super.setString(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($cartridge_name.equalsIgnoreCase(name)) {
			cartridge_name(value);
			return;
		}
		if ($print_command.equalsIgnoreCase(name)) {
			print_command(value);
			return;
		}
		if ($report_data_dir.equalsIgnoreCase(name)) {
			report_data_dir(value);
			return;
		}
		if ($report_if_dir.equalsIgnoreCase(name)) {
			report_if_dir(value);
			return;
		}
		if ($default_cartridge_name.equalsIgnoreCase(name)) {
			default_cartridge_name(value);
			return;
		}
		super.setStringNE(name, value);
	}



}

