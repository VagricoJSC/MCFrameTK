package mcframe.clientFSBB.FSBBP0050;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;

import mcframe.clientFSUB.FSUBP0060.*;

import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import java.io.File;
import mcframe.clientCore.report.MCReportConf;
import mcframe.commonCore.util.MCFileUtil;
import mcframe.clientCore.beans.popup.MCPopupBeans;
import mcframe.clientFXBA.FXBAP0100.FXBAP_PopupConfig;
import mcframe.clientCore.resource.MCConst;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBBP0050"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBBP0050_FW extends FSBBP0050_FW_A implements mcframe.clientFSUB.FSUBP0000.IfRowMoveBase {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	/**
	 * デフォルトの設定を表す名称
	 * 
	 */
	public static final String DEFAULT = "DEFAULT";
	
	
	/**
	 * カードリッジ名称
	 */
	String _cdName = null;
	
	/**
	 * デフォルトカードリッジ名
	 */
	String _defcdName = null;
	
	/**
	 * フォーム非表示カートリッジリスト取得用キー
	 */
	public static final String INVISIBLE_KEY = MCConst.createKey(MODULE_ID, SCREEN_ID, "form_invisible");
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBBP0050_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBBP0050_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * Panel[Btn]のボタン[add]の押下時の処理
	 */
	@Override
	public void doBtn_add(MCEventInfo info) {
		insertRow(PrintDef_FormTable);
	}
	/**
	 * Panel[Btn]のボタン[del]の押下時の処理
	 */
	@Override
	public void doBtn_del(MCEventInfo info) {
		deleteRow(PrintDef_FormTable);
	}
	/**
	 * Panel[Btn]のボタン[report_form_dir_FB]の押下時の処理
	 */
	@Override
	public void doBtn_report_form_dir_FB(MCEventInfo info) {
		PrintDef_FormR r = PrintDef_FormTable.getSelectedMCRow();
		
		if (r != null) {
			File path = null;
			if (r.report_form_dir() != null) {
				path = new File(MCReportConf.getBindValue(
									r.report_form_dir()));
			}
			path = MCFileChooser.showSelectDirDialog(path, this);
			if (path != null) {
				PrintDef_FormTable.setValue(path.getPath(), 
						PrintDef_FormTable.getMCSelectedRow(),
						columnPrintDef_Form_report_form_dir);
				
				
			}
		}
		
	}
	/**
	 * Panel[PrintDef]のボタン[print_command_FB]の押下時の処理
	 */
	public void doPrintDef_print_command_FB(MCEventInfo info) {
		File path = null;
		if (getPrintDefR().print_command() != null) {
			path = new File(MCReportConf.getBindValue(
					getPrintDefR().print_command()));
		}
		path = MCFileChooser.showLoadDialog(path, this, MCFileChooser.ALL);
		if (path != null) {
			PrintDef_print_command.setValue(path.getPath());
		}
		focusFirstComponent();
	}

	/**
	 * Panel[PrintDef]のボタン[report_data_dir_FB]の押下時の処理
	 */
	public void doPrintDef_report_data_dir_FB(MCEventInfo info) {
		File path = null;
		if (getPrintDefR().report_data_dir() != null) {
			path = new File(MCReportConf.getBindValue(
					getPrintDefR().report_data_dir()));
		}
		path = MCFileChooser.showSelectDirDialog(path, this);
		if (path != null) {
			PrintDef_report_data_dir.setValue(path.getPath());
		}
	}

	/**
	 * Panel[PrintDef]のボタン[report_if_dir_FB]の押下時の処理
	 */
	public void doPrintDef_report_if_dir_FB(MCEventInfo info) {
		File path = null;
		if (getPrintDefR().report_if_dir() != null) {
			path = new File(MCReportConf.getBindValue(
					getPrintDefR().report_if_dir()));
		}
		path = MCFileChooser.showSelectDirDialog(path, this);
		if (path != null) {
			PrintDef_report_if_dir.setValue(path.getPath());
		}
	}
	/**
	 * 
	 * 印刷関連の設定を読込ます。<P>
	 *
	 */
	public void reportDefLoad() {
		getPrintDefR().clear();
		getPrintDefR().cartridge_name(_cdName);
		getPrintDefR().default_cartridge_name(_defcdName);
		getPrintDef_FormL().clear();
		if (DEFAULT.equals(_cdName)) {
			getPrintDefR().print_command(MCReportConf.getPrintCommand_src());
			getPrintDefR().report_if_dir(MCReportConf.getIfDataPath_src());
		}else{
			getPrintDefR().print_command(MCReportConf.getPrintCommand_src(_cdName));
			getPrintDefR().report_data_dir(MCReportConf.getDataPath_src(_cdName));
			
			String[] formpath = MCReportConf.getFormPath_src(_cdName);
			for (String fp : formpath) {
				PrintDef_FormR r = getPrintDef_FormL().createRow();
				r.report_form_dir(fp);
				getPrintDef_FormL().add(r);
			}
		}
		PrintDef_FormTable.adjustWidth();
		PrintDef_FormTable.fillSpace();
	}
	
	@Override
	public void afterOpen() {
		super.afterOpen();
		fillSpaceForOpen();
	}
	

	@Override
	protected void fillSpaceForOpen() {
		super.fillSpaceForOpen();
		PrintDef_FormTable.adjustWidth();
		PrintDef_FormTable.fillSpace();
	}

	/**
	 * 印刷関連の情報を更新します。<P>
	 *
	 */
	public void saveConfig() {
		String name = getPrintDefR().cartridge_name();
		if (name.equals(DEFAULT)) {
			MCReportConf.setPrintCommand(getPrintDefR().print_command());
			MCReportConf.setIfDataPath(getPrintDefR().report_if_dir());
		}else{
			MCReportConf.setPrintCommand(name, getPrintDefR().print_command());
			MCReportConf.setDataPath(name, getPrintDefR().report_data_dir());
			
			
			List<String> fp = new ArrayList<String>();
			MCList<PrintDef_FormR> tls = getPrintDef_FormL();
			for (PrintDef_FormR r : tls) {
				if (!r.isStatusDelete() && 
						!MCStringUtil.isNull(r.report_form_dir())) {
					fp.add(r.report_form_dir());
				}
			}
			MCReportConf.setFormPath(name, fp.toArray(new String[]{}));
		}
	}
	
	/**
	 * デフォルト設定に戻します。
	 *
	 */
	public void saveDefConfig() {
		String name = getPrintDefR().cartridge_name();
		if (name.equals(DEFAULT)) {
			MCReportConf.removePrintCommand();
			MCReportConf.removeIfDataPath();
		}else{
			MCReportConf.removePrintCommand(name);
			MCReportConf.removeDataPath(name);
			MCReportConf.removeFormPath(name);
		}
	}
	
	/**
	 * 設定のチェックを行います。<P>
	 *
	 * @param ls メッセージリスト
	 */
	public void chekConfig(MCMessageList ls) {
		String name = getPrintDefR().cartridge_name();
		String path = null;
		File f = null;

		//帳票アプリケーションパスは、引数を含むかもしれないので
		//チェックしない。
		
		if (columnPrintDef_Form_report_form_dir.isVisible()) {
			MCList<PrintDef_FormR> tls = getPrintDef_FormL().statusChangedList();
			for (PrintDef_FormR r : tls) {
				if (r.isStatusDelete()) {
					continue;
				}
				path = MCReportConf.getBindValue(r.report_form_dir());
				if (path != null) {
					f = new File(path);
					if (!f.exists()) {
						ls.add(new MCMessage(r, 
								PrintDef_FormR.$report_form_dir,
								FSBBC0006 , name, 
								r.report_form_dir(), path));
					}
				}
			}
		}
		this.checkDuplicate(ls, PrintDef_FormTable, 
				PrintDef_FormR.$report_form_dir);

		
		if (PrintDef_report_data_dir.isVisible()) {
			path = MCReportConf.getBindValue(
									getPrintDefR().report_data_dir());
			if (path != null) {
				f = new File(path);
				try{
					MCFileUtil.mkDir(f);
					if (!f.exists()) {
						ls.add(new MCMessage(getPrintDefR(), 
								PrintDefR.$report_data_dir,
								FSBBC0007 , name, 
								getPrintDefR().report_data_dir(), path));
					}
				}catch (MCException e) {
					if (e.getID().equals(FCUCC0011)) {
						ls.add(new MCMessage(getPrintDefR(), 
								PrintDefR.$report_data_dir,
								FSBBC0007 , name, 
								getPrintDefR().report_data_dir(), path));
					}
				}
			}
		}
		if (PrintDef_report_if_dir.isVisible()) {
			path = MCReportConf.getBindValue(
					getPrintDefR().report_if_dir());
			if (path != null) {
				f = new File(path);
				try{
					MCFileUtil.mkDir(f);
					if (!f.exists()) {
						ls.add(new MCMessage(getPrintDefR(), 
								PrintDefR.$report_if_dir,
								FSBBC0008, getPrintDefR().report_if_dir(), path));
					}
				}catch (MCException e) {
					if (e.getID().equals(FCUCC0011)) {
						ls.add(new MCMessage(getPrintDefR(), 
								PrintDefR.$report_if_dir,
								FSBBC0008, getPrintDefR().report_if_dir(), path));
					}
				}
			}
		}
	}

	/**
	 * カートリッジ名称を設定します。
	 *
	 * @param cd カートリッジ名称
	 * @param def デフォルトカートリッジ名称
	 */
	public void setCartridge_name(String cd, String def) {
		_cdName = cd;
		_defcdName = def;
	}
	
	@Override
	public void setDEFAULTStatus() {
		super.setDEFAULTStatus();
		
		PrintDef_FormPanel.setVisible(false);
		PrintDefPanel.setNextBeans(BtnPanel);
	}
	
	@Override
	public void setOTHERStatus() {
		super.setOTHERStatus();
		if (isFormInvisible()) {
			PrintDef_FormPanel.setVisible(false);
			BtnPanel.setVisible(false);
			PrintDefPanel.setNextBeans(BtnPanel.getNextBeans());
		}
	}

	/**
	 * フォームディレクトリテーブルを非表示にするかどうか返します。
	 *
	 * @return フォームディレクトリテーブルを非表示にする場合true
	 */
	protected boolean isFormInvisible() {
		String v = MCConst.app.getString(MCConst.createKey(INVISIBLE_KEY));
		if (!isNull(v)) {
			for (String c : MCStringUtil.split(",", v)) {
				if (isSame(c, _cdName)) {
					return true;
				}
			}
		}
		return false;
	}

	@Override
	public MCTable<?> getRowMoveTable() {
		return PrintDef_FormTable;
	}

	@Override
	public boolean isStatusChange() {
		return true;
	}

	@Override
	protected FXBAP_PopupConfig createFXBAP_PopupConfig(MCPopupBeans beans) {
		FXBAP_PopupConfig conf = super.createFXBAP_PopupConfig(beans);
		if (beans == PrintDef_FormTable) {
			conf.ignoreSortOrder(true);
			conf.ignoreRowFilter(true);
			conf.ignoreSumInfo(true);
		}
		return conf;
	}

	@Override
	public String getTableName(MCTable<?> table, String type) {
		return super.getTableName(table, type) + _cdName;
	}

}