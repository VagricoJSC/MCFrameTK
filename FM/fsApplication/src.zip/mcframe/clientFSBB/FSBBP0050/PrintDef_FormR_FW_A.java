package mcframe.clientFSBB.FSBBP0050;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"PrintDef_Form"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class PrintDef_FormR_FW_A extends MCConstRow {

	/**
	 *  帳票フォームディレクトリ.<p>
	 *
	 */
	public static final String $report_form_dir = "report_form_dir";


	public static final MCMeta report_form_dir_META = createCommonMeta($report_form_dir, mcframe.commonCore.meta.M_META.PATH);

	protected static final ConstMetaList<PrintDef_FormR> constMetas = new ConstMetaList<PrintDef_FormR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			report_form_dir_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected PrintDef_FormR_FW_A(ConstMetaList<? extends PrintDef_FormR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public PrintDef_FormR clone() {
		return (PrintDef_FormR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public PrintDef_FormR createInstance() {
		return (PrintDef_FormR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public PrintDef_FormR getValues(String... names) {
		return (PrintDef_FormR) super.getValues(names);
	}



	/**
	 *  帳票フォームディレクトリ.<p>
	 *
	 */
	public String report_form_dir() {
		return getConstString(offset + 0, $report_form_dir);
	}

	/**
	 *  帳票フォームディレクトリ.<p>
	 *
	 */
	public void report_form_dir(String value) {
		setConstString(offset + 0, $report_form_dir, value);
	}


	public String getString(String name) {
		if ($report_form_dir.equalsIgnoreCase(name)) {
			return report_form_dir();
		}
		return super.getString(name);
	}

	public String getStringNE(String name) {
		if ($report_form_dir.equalsIgnoreCase(name)) {
			return report_form_dir();
		}
		return super.getStringNE(name);
	}

	public void setString(String name, String value) {
		if ($report_form_dir.equalsIgnoreCase(name)) {
			report_form_dir(value);
			return;
		}
		super.setString(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($report_form_dir.equalsIgnoreCase(name)) {
			report_form_dir(value);
			return;
		}
		super.setStringNE(name, value);
	}



}

