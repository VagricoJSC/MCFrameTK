package mcframe.clientFSBB.FSBBP0010;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import mcframe.clientCore.beans.MCRootPanel;
import mcframe.clientCore.resource.MCConst;
import mcframe.clientFSBB.FSBBP0000.MCConfigPanel;
import mcframe.commonCore.lang.MCNumber;
import static mcframe.commonCore.sys.MCFactory.*;

/**
* 環境設定画面のメニューの設定情報です。
*/
public class MenuSetting {


	/**
	 * キーの接頭辞です。
	 */
	private static final String KEY_PREFIX = "FS.FSBBP0010.menu";

	/**
	 * 設定画面のモジュールIDキーです。
	 */
	private static final String KEY_MODULE_ID = "moduleID";

	/**
	 * 設定画面のスクリーンIDキーです。
	 */
	private static final String KEY_SCREEN_ID = "screenID";


	/**
	 * 設定画面の表示順のキーです。
	 */
	private static final String KEY_NUM = "num";

	/**
	 * 非表示フラグのキーです。
	 */
	private static final String KEY_IGNORE = "ignore";
	
	/**
	 * 設定画面のキーのリストをキャッシュを保持するフィールドです。
	 * 
	 */
	private List<String> keys = new ArrayList<String>();


	/**
	 * シングルトンのインスタンスです。
	 */
	private static MenuSetting instance = null;

	/**
	 * 唯一のインスタンスを返します。
	 *
	 * @return インスタンス
	 */
	public static final MenuSetting getInstance() {
		if (instance == null) {
			instance =  new MenuSetting();
		}
		return instance;
	}

	/**
	 * コンストラクタです。
	 */
	private MenuSetting() {
		String pattern = KEY_PREFIX + ".*";
		Collections.addAll(keys, MCConst.app.findPattern(pattern));
	}
	
	
	/**
	 * 環境設定画面に登録されている、設定画面のキーのリストを返します。
	 * 
	 * キーは以下の書式になります。<br>
	 * <i>W.WEP0100.(キー)</i>
	 * 
	 * 
	 * <p>
	 * キーが見つからない場合は要素0のリストを返します。
	 *
	 * @return 設定画面のIDのリスト
	 */
	public final List<String> getKeyList() {
		return keys;
	}
	
	/**
	 * 設定画面を返します。
	 *
	 * @param key 設定画面のキー
	 * @return 設定画面
	 */
	public final MCConfigPanel getScreen(String key) {
		boolean ignore = MCConst.app.getBoolean(
				MCConst.createKey(key, KEY_IGNORE), false);
		String moduleID = MCConst.app.getString(
				MCConst.createKey(key, KEY_MODULE_ID));
		String screenID = MCConst.app.getString(
				MCConst.createKey(key, KEY_SCREEN_ID));
		if (!ignore) {
			Class<? extends MCRootPanel> clazz = MCConst.screen.getClass(moduleID
					, screenID, MCRootPanel.class);
			MCRootPanel pn = (MCRootPanel)invokeStatic(clazz, "create"
					, new Class[]{}, new Object[]{});
			
			if (!(pn instanceof MCConfigPanel)) {
				return createEmptyPanel();
			}
			else {
				return (MCConfigPanel)pn;
			}
		}
		return null;
	}
	
	/**
	 * 設定画面の表示順をを返します。
	 *
	 * @param key 設定画面のキー
	 * @return 設定画面
	 */
	public final MCNumber getNum(String key) {
		return MCConst.app.getNumber(MCConst.createKey(key, KEY_NUM), MCNumber.ZERO);
	}
	
	/**
	 * 空の設定画面を返します。
	 *
	 * @return 空の設定画面
	 */
	protected  MCConfigPanel createEmptyPanel() {
		return mcframe.clientFSBB.FSBBP0030.FSBBP0030.create();
	}

}
