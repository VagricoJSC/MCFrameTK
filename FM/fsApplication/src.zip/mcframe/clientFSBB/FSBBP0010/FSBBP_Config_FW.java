package mcframe.clientFSBB.FSBBP0010;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;

import mcframe.clientFSBB.FSBBP0000.*;

import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import java.util.Map;
import java.util.HashMap;
import javax.swing.SwingUtilities;
import mcframe.clientCore.beans.layout.MCGeneralLayout;
import mcframe.clientFXBA.FXBAP0010.FXBAP_PanelBase;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBBP_Config"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBBP_Config_FW extends FSBBP_Config_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	/**
	 * 設定画面として登録されている画面を保持するマップです。
	 */
	Map<String, MCRootPanel> pns = new HashMap<String, MCRootPanel>();

	/**
	 * メニューツリーのリストです。
	 */
	MCList<MenuR> menu = MCList.create(MenuR.class);

	/**
	 * 表示済の画面のリストです。
	 */
	List<MCRootPanel> init = new ArrayList<MCRootPanel>();
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBBP_Config_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBBP_Config_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * Panel[Btn]のボタン[upd]の押下時の処理
	 */
	public void doBtn_upd(MCEventInfo info) {
		// MCSettingPanelが使われているものは、保存してから閉じる
		if (confirm(msgUpdateConfirm()) != MCMessageBox.YES_OPTION) {
			return;
		}

		List<MCConfigPanel> l = new ArrayList<MCConfigPanel>();
		for (MenuR c : getMenuL()) {
			MCRootPanel p = pns.get(c.id());
			if (p instanceof MCConfigPanel) {
				l.add((MCConfigPanel)p);
			}
		}

		// MCConfigPanel の配列
		MCConfigPanel[] a = l.toArray(new MCConfigPanel[l.size()]);

		// チェック
		for (MCConfigPanel p : a) {
			if (!p.checkConfig()) {
				return;
			}
		}

		// 更新
		MCMessageList msgList = new MCMessageList();
		for (MCConfigPanel p : a) {
			p.saveConfig(msgList);
		}

		showUpdEndMsg(msgList);

		requestCloseWindow();
	}

	/**
	 * Panel[Btn]のボタン[cncl]の押下時の処理
	 */
	public void doBtn_cncl(MCEventInfo info) {
		// 保存せずに閉じる
		requestCloseWindow();
	}

	/**
	 * Panel[Btn]のボタン[cncl]の押下時の処理
	 */
	@Override
	public void doMenu_NC(MCEventInfo info) {
		// 設定枠のクリア
		int idx = info.getOldIndex();
		if (idx >= 0) {
			MenuR bfr = getMenuL().get(idx);
			MCRootPanel bfrpnl = pns.get(bfr.id());
			bfrpnl.setVisible(false);
//			setVisible(bfrpnl, MCMode.INVISIBLE);
		}

		// 設定枠の再設定
		MenuR aft = MenuTree.getSelectedMCRow();
		MCRootPanel aftpnl = pns.get(aft.id());
		aftpnl.setVisible(true);
		setVisible(aftpnl, MCMode.ENABLE);
		getConfHdrR().label_nm(aft.label_nm());
		getConfHdrR().cmnt(aft.cmnt());

		// レイアウト再設定
		setConfLayout(aftpnl);

		// タブ順の再設定
		ConfPanel.setFirstBeans(aftpnl);

		activeInit(aftpnl);
	}

	/**
	 * パネルに配置されているテーブルのモードを変更します。<BR>
	 * （テーブルサイズ変更対応）
	 *
	 * @param pnl パネル
	 * @param mode モード
	 */
	protected void setVisible(MCRootPanel pnl, MCMode mode) {
		for (MCTable t : MCBeansUtil.getAllComponents(MCTable.class, pnl)) {
			t.setMode(mode);
		}
	}

	/**
	 * パネルを配置しなおします。
	 *
	 * @param tar パネル
	 */
	protected void setConfLayout(final MCRootPanel tar) {
		Dimension ps = getPreferredSize();
		// スクロールバーを正しく表示するための高さ計算
		int ph = ps.height - ConfPanel.getPreferredSize().height;

		ConfPanel.remove(tar);
		ConfPanel.add(BorderLayout.CENTER, tar);

		// ツリー選択時に高さを再計算するためにPreferredSizeを設定しておく
		ConfPanel.setPreferredSize(new Dimension(tar.getMinimumSize()));

		ph = ph + ConfPanel.getPreferredSize().height;

		// RootPanelにスクロールバーを表示する高さを設定
		setPreferredSize(new Dimension(ps.width, ph));

		// 7013-0074(【アプリ多言語に伴う対応】省略改行無しラベル対応（$fit$改行機能＋α）)
		// パネル単位で動的レイアウトを行う。
		// パネルのラベルが...になるため。
		MCGeneralLayout.relayoutForRootPanel(tar);

		// 7013-2275(SP3高解像度対応不具合まとめ)
		// 拡大縮小後に切替すると画面が崩れる場合の対応
		MCLayouter.fontRatioChange(this, this.getFontRatio());
	}

	/**
	 * 画面がアクティブになった時の表示処理を行います。
	 *
	 * 表示処理は初回表示時のみ実行されます。
	 *
	 * @param tar パネル
	 */
	protected void activeInit(final MCRootPanel tar) {
		if (init.contains(tar)) {
			return;
		}
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				try {
					// 埋込画面表示処理
					doAfterOpens(tar);
				}
				catch (Throwable e) {
					MCBeansUtil.handle(getBaseRootPanel(), e);
				}
			}
		});
		init.add(tar);
	}

	/**
	 * {@link MCRootPanel#afterOpen()} を実行します。
	 * 指定された画面に埋込画面が存在する場合は、
	 * 埋込画面の {@link MCRootPanel#afterOpen()} も実行します。
	 *
	 * @param panel 画面
	 */
	protected void doAfterOpens(MCRootPanel panel) {
		for (MCRootPanel p : panel.getPartsPanels()) {
			doAfterOpens(p);
//			p.setAutoLayoutUseAutoLayout(false);
		}
		panel.afterOpen();
//		panel.setAutoLayoutUseAutoLayout(false);
//		this.setAutoLayoutUseAutoLayout(false);
	}

	@Override
	protected void jbInit() {
		super.jbInit();
		// リソースの読込み
		MenuSetting setting = MenuSetting.getInstance();
		List<String> keys = setting.getKeyList();

		MCConfigPanel pnl;
		MCNumber idx;
		for (String key :keys) {
			// 画面初期化
			pnl = setting.getScreen(key);
			idx = setting.getNum(key);
			if (pnl != null) {
				// ベース階層に追加
				MenuR itm = MenuR.create();
				itm.key(key);
				itm.id(String.valueOf(pnl.hashCode()));
				itm.parent(null);
				itm.label(pnl.getScreenName());
				itm.label_nm(pnl.getScreenName());
				itm.cmnt(pnl.getComment());
				itm.sort_idx(idx);
				menu.add(itm);

				if (pnl instanceof MCRootPanel) {
					pns.put(itm.id(), (MCRootPanel)pnl);
				}

				// 下階層を追加
				menu.addAll(pnl.getMenu());
				if (pnl.getConfigPanels() != null) {
					pns.putAll(pnl.getConfigPanels());
				}
			}
		}
		menu.sort(MenuR.$sort_idx);

		// 全パネルを不可視で追加
		ConfPanel.setLayout(new BorderLayout());
		for (MCRootPanel tar : pns.values()) {
			// パネルの追加
			tar.setVisible(false);
			setVisible(tar, MCMode.INVISIBLE);
			ConfPanel.add(tar);
		}
	}

	@Override
	public String getTableName(MCTable table, String type) {
		return table.getRootPanel().getTableName(table, type);
	}

	@Override
	public boolean beforeOpen() {
		if (super.beforeOpen()) {
			getMenuL().setAll(menu);

			// 7.0.1 左側のメニューパネルのdivider位置を固定する。
			MCSplitPane _sp = getSplitPane(MenuPnlPanel);
			if(_sp != null) {
				_sp.setResizeWeight(0.0);
			}

			return true;
		}
		return false;
	}

	@Override
	public void setOpenFocus() {
		if (getMenuL().size() > 0) {
			MenuTree.selectRow(getMenuL().get(0));
		}
	}

	@Override
	public void screenClearBody() {
		// メニューをクリアしたくないため、各パネルごとにクリアする
		for (MCRootPanel p : pns.values()) {
			if (p instanceof FXBAP_PanelBase) {
				((FXBAP_PanelBase)p).screenClearBody();
			}
			else {
				for (MCContainer c : p.getContainers()) {
					c.clear();
				}
			}
		}
		init.clear();
	}

	@Override
	public void screenClearSetDefault() {
		// メニューをクリアしたくないため、各パネルごとにクリアする
		for (MCRootPanel p : pns.values()) {
			if (p instanceof FXBAP_PanelBase) {
				((FXBAP_PanelBase)p).screenClearSetDefault();
			}
		}
	}

	@Override
	public void screenClearSetMode() {
		// メニューをクリアしたくないため、各パネルごとにクリアする
		for (MCRootPanel p : pns.values()) {
			if (p instanceof FXBAP_PanelBase) {
				((FXBAP_PanelBase)p).screenClearSetMode();
			}
		}
	}

	/**
	 * 登録完了メッセージを表示します。
	 */
	protected void showUpdEndMsg(MCMessageList msgList) {
		if (msgList.isEmpty()) {
			dialog(msgUpdated());
		}
		else {
			msgList.add(0, msgUpdated());
			messageNoSort(msgList, MCFrameType.SYSTEM_MODAL);
		}
	}

	/**
	 * 動的レイアウト禁止
	 */
	@Override
	public boolean isEnableDynamicLayout() {
		return false;
	}

}