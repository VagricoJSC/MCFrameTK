package mcframe.clientFSBB.FSBBP0010;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"ConfHdr"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class ConfHdrR_FW_A extends MCConstRow {

	/**
	 *  タイトル.<p>
	 *
	 */
	public static final String $label_nm = "label_nm";
	/**
	 *  説明.<p>
	 *
	 */
	public static final String $cmnt = "cmnt";


	public static final MCMeta label_nm_META = createStringMeta($label_nm, 30);
	public static final MCMeta cmnt_META = createStringMeta($cmnt, 50);

	protected static final ConstMetaList<ConfHdrR> constMetas = new ConstMetaList<ConfHdrR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			label_nm_META,
			cmnt_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected ConfHdrR_FW_A(ConstMetaList<? extends ConfHdrR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ConfHdrR clone() {
		return (ConfHdrR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ConfHdrR createInstance() {
		return (ConfHdrR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ConfHdrR getValues(String... names) {
		return (ConfHdrR) super.getValues(names);
	}



	/**
	 *  タイトル.<p>
	 *
	 */
	public String label_nm() {
		return getConstString(offset + 0, $label_nm);
	}

	/**
	 *  タイトル.<p>
	 *
	 */
	public void label_nm(String value) {
		setConstString(offset + 0, $label_nm, value);
	}


	/**
	 *  説明.<p>
	 *
	 */
	public String cmnt() {
		return getConstString(offset + 1, $cmnt);
	}

	/**
	 *  説明.<p>
	 *
	 */
	public void cmnt(String value) {
		setConstString(offset + 1, $cmnt, value);
	}


	public String getString(String name) {
		if ($label_nm.equalsIgnoreCase(name)) {
			return label_nm();
		}
		if ($cmnt.equalsIgnoreCase(name)) {
			return cmnt();
		}
		return super.getString(name);
	}

	public String getStringNE(String name) {
		if ($label_nm.equalsIgnoreCase(name)) {
			return label_nm();
		}
		if ($cmnt.equalsIgnoreCase(name)) {
			return cmnt();
		}
		return super.getStringNE(name);
	}

	public void setString(String name, String value) {
		if ($label_nm.equalsIgnoreCase(name)) {
			label_nm(value);
			return;
		}
		if ($cmnt.equalsIgnoreCase(name)) {
			cmnt(value);
			return;
		}
		super.setString(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($label_nm.equalsIgnoreCase(name)) {
			label_nm(value);
			return;
		}
		if ($cmnt.equalsIgnoreCase(name)) {
			cmnt(value);
			return;
		}
		super.setStringNE(name, value);
	}



}

