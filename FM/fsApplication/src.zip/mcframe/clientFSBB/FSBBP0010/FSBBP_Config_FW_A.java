package mcframe.clientFSBB.FSBBP0010;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBBP_Config"パネルクラスです。<p>
 *
 * ログイン後の環境設定画面のデスクトップです。<br>
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBBP_Config_FW_A extends mcframe.clientFSUC.FSUCP0000.FSUCP_PanelBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBB";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBBP0010";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [MenuPnl]ブロック関連のField定義
	public MCPanel MenuPnlPanel = null;
	public MCTitledBorder MenuPnlTitledBorder = null;
	// [MenuPnl]ブロックの項目のField定義
	// [MenuHdr]ブロック関連のField定義
	public MCPanel MenuHdrPanel = null;
	// [MenuHdr]ブロックの項目のField定義
	// [Menu]ブロック関連のField定義
	public MCPanel MenuPanel = null;
	public MCScrollPane MenuScrollPane = null;
	public MCTree<mcframe.clientFSBB.FSBBP0000.MenuR> MenuTree = null;
	// [Menu]ブロックの項目のField定義
	// [ConfPnl]ブロック関連のField定義
	public MCPanel ConfPnlPanel = null;
	public MCTitledBorder ConfPnlTitledBorder = null;
	// [ConfPnl]ブロックの項目のField定義
	// [ConfHdr]ブロック関連のField定義
	public MCPanel ConfHdrPanel = null;
	// [ConfHdr]ブロックの項目のField定義
	/**
	 *  タイトル.<p>
	 *
	 */
	public MCTextField ConfHdr_label_nm = null;
	/**
	 *  説明.<p>
	 *
	 */
	public MCTextField ConfHdr_cmnt = null;
	// [Conf]ブロック関連のField定義
	public MCPanel ConfPanel = null;
	// [Conf]ブロックの項目のField定義
	// [Btn]ブロック関連のField定義
	public MCPanel BtnPanel = null;
	// [Btn]ブロックの項目のField定義
	/**
	 *  適用後閉じる.<p>
	 *
	 */
	public MCButton Btn_upd = null;
	/**
	 *  適用せず閉じる.<p>
	 *
	 */
	public MCButton Btn_cncl = null;
	/** [INIT]モードを表す定数 */
	public static final String INIT = "INIT";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{INIT};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	
	/** [Menu]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBB.FSBBP0000.MenuR> aMenuL;
	/** [ConfHdr]ブロックのコンテナField定義 */
	private final mcframe.clientFSBB.FSBBP0010.ConfHdrR aConfHdrR;

	/**
	 * コピーによってaMenuLを設定します。
	 *
	 * aMenuLのインスタンスは変更されません。
	 *
	 * @param dataset MenuL
	 */
	public void setMenuL(MCList<mcframe.clientFSBB.FSBBP0000.MenuR> aList) {
		if (getMenuL() != aList) {
			getMenuL().setAll(aList);
		}
	}

	/**
	 * [Menu]ブロックのコンテナaMenuLを返します。
	 *
	 * @return MenuL
	 */
	public MCList<mcframe.clientFSBB.FSBBP0000.MenuR> getMenuL() {
		return aMenuL;
	}

	/**
	 * aMenuRを作成します。
	 *
	 * @return MenuR
	 */
	public mcframe.clientFSBB.FSBBP0000.MenuR createMenuR() {
		return mcframe.clientFSBB.FSBBP0000.MenuR.create();
	}

	/**
	 * aMenuLを作成します。
	 *
	 * @return MenuL
	 */
	public MCList<mcframe.clientFSBB.FSBBP0000.MenuR> createMenuL() {
		return MCList.create(mcframe.clientFSBB.FSBBP0000.MenuR.class);
	}

	/**
	 * 項目コピーによってaConfHdrRを設定します。
	 *
	 * aConfHdrRのインスタンスは変更されません。
	 *
	 * @param row ConfHdrR
	 */
	public void setConfHdrR(mcframe.clientFSBB.FSBBP0010.ConfHdrR row) {
		if (row != null) {
			MCRow.copyall(getConfHdrR(), row);
		}
	}

	/**
	 * [ConfHdr]ブロックのコンテナaConfHdrRを返します。
	 *
	 * @return ConfHdrR
	 */
	public mcframe.clientFSBB.FSBBP0010.ConfHdrR getConfHdrR() {
		return aConfHdrR;
	}

	/**
	 * aConfHdrRを作成します。
	 *
	 * @return ConfHdrR
	 */
	public mcframe.clientFSBB.FSBBP0010.ConfHdrR createConfHdrR() {
		return mcframe.clientFSBB.FSBBP0010.ConfHdrR.create();
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getMenuL())) ret.add(getMenuL());
		if(!MCCollectionUtil.contains(ret, getConfHdrR())) ret.add(getConfHdrR());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getMenuL()) return "Menu";
		if(aCnt == getConfHdrR()) return "ConfHdr";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("Menu")) return getMenuL();
		if(bId.equals("ConfHdr")) return getConfHdrR();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(MenuPnlPanel);
		ret.add(MenuHdrPanel);
		ret.add(MenuPanel);
		ret.add(ConfPnlPanel);
		ret.add(ConfHdrPanel);
		ret.add(ConfPanel);
		ret.add(BtnPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBBP_Config_FW_A() {
		aMenuL = createMenuL();
		aConfHdrR = createConfHdrR();

	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBBP_Config_FW_A(String name) {
		aMenuL = createMenuL();
		aConfHdrR = createConfHdrR();
	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBBP_Config_FW.jbCreateMenuPnl((FSBBP_Config)this);
		FSBBP_Config_FW.jbCreateMenuHdr((FSBBP_Config)this);
		FSBBP_Config_FW.jbCreateMenu((FSBBP_Config)this);
		FSBBP_Config_FW.jbCreateConfPnl((FSBBP_Config)this);
		FSBBP_Config_FW.jbCreateConfHdr((FSBBP_Config)this);
		FSBBP_Config_FW.jbCreateConf((FSBBP_Config)this);
		FSBBP_Config_FW.jbCreateBtn((FSBBP_Config)this);
	}

	/**
	 * [MenuPnl]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateMenuPnl(FSBBP_Config p) {
	}

	/**
	 * [MenuHdr]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateMenuHdr(FSBBP_Config p) {
	}

	/**
	 * [Menu]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateMenu(FSBBP_Config p) {
	}

	/**
	 * [ConfPnl]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateConfPnl(FSBBP_Config p) {
	}

	/**
	 * [ConfHdr]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateConfHdr(FSBBP_Config p) {
	}

	/**
	 * [Conf]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateConf(FSBBP_Config p) {
	}

	/**
	 * [Btn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateBtn(FSBBP_Config p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}


	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBBP_Config create(){
		FSBBP_Config p = new FSBBP_Config();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBBP_Config create(String name){
		FSBBP_Config p = new FSBBP_Config(name);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBBP_Config_FW.jbfInitMenuPnl((FSBBP_Config)this);
		FSBBP_Config_FW.jbfInitMenuHdr((FSBBP_Config)this);
		FSBBP_Config_FW.jbfInitMenu((FSBBP_Config)this);
		FSBBP_Config_FW.jbfInitConfPnl((FSBBP_Config)this);
		FSBBP_Config_FW.jbfInitConfHdr((FSBBP_Config)this);
		FSBBP_Config_FW.jbfInitConf((FSBBP_Config)this);
		FSBBP_Config_FW.jbfInitBtn((FSBBP_Config)this);
		FSBBP_Config_FW.jbInitMenuPnl((FSBBP_Config)this);
		FSBBP_Config_FW.jbInitMenuHdr((FSBBP_Config)this);
		FSBBP_Config_FW.jbInitMenu((FSBBP_Config)this);
		FSBBP_Config_FW.jbInitConfPnl((FSBBP_Config)this);
		FSBBP_Config_FW.jbInitConfHdr((FSBBP_Config)this);
		FSBBP_Config_FW.jbInitConf((FSBBP_Config)this);
		FSBBP_Config_FW.jbInitBtn((FSBBP_Config)this);
	}

	/**
	 * [MenuPnl]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitMenuPnl(FSBBP_Config p) {
		// ブロック関連の初期化
		p.MenuPnlPanel = p.beansFactory.createPanel("MenuPnl");
		p.MenuPnlTitledBorder = p.beansFactory.createTitledBorder();
		// ブロックの項目の初期化
	}

	/**
	 * [MenuHdr]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitMenuHdr(FSBBP_Config p) {
		// ブロック関連の初期化
		p.MenuHdrPanel = p.beansFactory.createPanel("MenuHdr");
		// ブロックの項目の初期化
	}

	/**
	 * [Menu]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitMenu(FSBBP_Config p) {
		// ブロック関連の初期化
		p.MenuPanel = p.beansFactory.createPanel("Menu");
		p.MenuScrollPane = p.beansFactory.createScrollPane("Menu.scroll");
		p.MenuTree = p.beansFactory.createTree("Menu.tree");
		// ブロックの項目の初期化
	}

	/**
	 * [ConfPnl]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitConfPnl(FSBBP_Config p) {
		// ブロック関連の初期化
		p.ConfPnlPanel = p.beansFactory.createPanel("ConfPnl");
		p.ConfPnlTitledBorder = p.beansFactory.createTitledBorder();
		// ブロックの項目の初期化
	}

	/**
	 * [ConfHdr]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitConfHdr(FSBBP_Config p) {
		// ブロック関連の初期化
		p.ConfHdrPanel = p.beansFactory.createPanel("ConfHdr");
		// ブロックの項目の初期化
		p.ConfHdr_label_nm = p.beansFactory.createTextField("ConfHdr.label_nm");
		p.ConfHdr_cmnt = p.beansFactory.createTextField("ConfHdr.cmnt");
	}

	/**
	 * [Conf]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitConf(FSBBP_Config p) {
		// ブロック関連の初期化
		p.ConfPanel = p.beansFactory.createPanel("Conf");
		// ブロックの項目の初期化
	}

	/**
	 * [Btn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitBtn(FSBBP_Config p) {
		// ブロック関連の初期化
		p.BtnPanel = p.beansFactory.createPanel("Btn");
		// ブロックの項目の初期化
		p.Btn_upd = p.beansFactory.createButton("Btn.upd");
		p.Btn_cncl = p.beansFactory.createButton("Btn.cncl");
	}

	/**
	 * [MenuPnl]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitMenuPnl(FSBBP_Config p) {
		// ブロック関連の初期化
		p.MenuPnlPanel.setBorder(p.MenuPnlTitledBorder);
		p.add(p.MenuPnlPanel);
		p.setLastBeans(p.MenuPnlPanel);
		p.MenuPnlPanel.setNextBeans(p.ConfPnlPanel);
		p.MenuPnlPanel.setLayoutPosition("CLC+");
		// ブロックの項目の初期化
		p.MenuPnlPanel.add(p.MenuHdrPanel, null);
		p.MenuPnlPanel.setLastBeans(p.MenuHdrPanel);
		p.MenuHdrPanel.setNextBeans(p.MenuPanel);
		p.MenuPnlPanel.add(p.MenuPanel, null);
	}

	/**
	 * [MenuHdr]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitMenuHdr(FSBBP_Config p) {
		// ブロック関連の初期化
		p.MenuHdrPanel.setLayoutPosition("N");
		// ブロックの項目の初期化
	}

	/**
	 * [Menu]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitMenu(FSBBP_Config p) {
		// ブロック関連の初期化
		p.MenuPanel.add(p.MenuScrollPane);
		p.MenuPanel.setLastBeans(p.MenuTree);
		p.MenuScrollPane.setViewportView(p.MenuTree);
		p.MenuTree.setList(p.getMenuL());
		p.MenuPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * [ConfPnl]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitConfPnl(FSBBP_Config p) {
		// ブロック関連の初期化
		p.ConfPnlPanel.setBorder(p.ConfPnlTitledBorder);
		p.add(p.ConfPnlPanel);
		p.ConfPnlPanel.setNextBeans(p.BtnPanel);
		p.ConfPnlPanel.setLayoutPosition("CRC+");
		// ブロックの項目の初期化
		p.ConfPnlPanel.add(p.ConfHdrPanel, null);
		p.ConfPnlPanel.setLastBeans(p.ConfHdrPanel);
		p.ConfHdrPanel.setNextBeans(p.ConfPanel);
		p.ConfPnlPanel.add(p.ConfPanel, null);
	}

	/**
	 * [ConfHdr]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitConfHdr(FSBBP_Config p) {
		// ブロック関連の初期化
		p.ConfHdrPanel.setLayoutPosition("N");
		// ブロックの項目の初期化
		p.ConfHdrPanel.add(p.ConfHdr_label_nm);
		p.ConfHdrPanel.setLastBeans(p.ConfHdr_label_nm);
		p.ConfHdr_label_nm.setNextBeans(p.ConfHdr_cmnt);
		p.ConfHdr_label_nm.setRow(p.getConfHdrR(), mcframe.clientFSBB.FSBBP0010.ConfHdrR.label_nm_META);
		p.ConfHdrPanel.add(p.ConfHdr_cmnt);
		p.ConfHdr_cmnt.setRow(p.getConfHdrR(), mcframe.clientFSBB.FSBBP0010.ConfHdrR.cmnt_META);
	}

	/**
	 * [Conf]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitConf(FSBBP_Config p) {
		// ブロック関連の初期化
		p.ConfPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * [Btn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitBtn(FSBBP_Config p) {
		// ブロック関連の初期化
		p.add(p.BtnPanel);
		p.BtnPanel.setLayoutPosition("S");
		// ブロックの項目の初期化
		p.Btn_upd.setFunctionKey(MCFunctionKey.F9);
		p.BtnPanel.add(p.Btn_upd);
		p.BtnPanel.setLastBeans(p.Btn_upd);
		p.Btn_upd.setNextBeans(p.Btn_cncl);
		p.Btn_cncl.setFunctionKey(MCFunctionKey.F11);
		p.BtnPanel.add(p.Btn_cncl);
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "G";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBBP_Config_FW.mcInitMenuPnl((FSBBP_Config)this);
		FSBBP_Config_FW.mcInitMenuHdr((FSBBP_Config)this);
		FSBBP_Config_FW.mcInitMenu((FSBBP_Config)this);
		FSBBP_Config_FW.mcInitConfPnl((FSBBP_Config)this);
		FSBBP_Config_FW.mcInitConfHdr((FSBBP_Config)this);
		FSBBP_Config_FW.mcInitConf((FSBBP_Config)this);
		FSBBP_Config_FW.mcInitBtn((FSBBP_Config)this);

		// [INIT]ステータスのモードの設定
		FSBBP_Config_FW.statusInitINIT_MenuPnl((FSBBP_Config)this);
		FSBBP_Config_FW.statusInitINIT_MenuHdr((FSBBP_Config)this);
		FSBBP_Config_FW.statusInitINIT_Menu((FSBBP_Config)this);
		FSBBP_Config_FW.statusInitINIT_ConfPnl((FSBBP_Config)this);
		FSBBP_Config_FW.statusInitINIT_ConfHdr((FSBBP_Config)this);
		FSBBP_Config_FW.statusInitINIT_Conf((FSBBP_Config)this);
		FSBBP_Config_FW.statusInitINIT_Btn((FSBBP_Config)this);

	}

	/**
	 *  [MenuPnl]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitMenuPnl(FSBBP_Config p) {
	}

	/**
	 *  [MenuHdr]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitMenuHdr(FSBBP_Config p) {
	}

	/**
	 *  [Menu]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitMenu(FSBBP_Config p) {
		p.MenuTree.addAllListener(p);
	}

	/**
	 *  [ConfPnl]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitConfPnl(FSBBP_Config p) {
	}

	/**
	 *  [ConfHdr]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitConfHdr(FSBBP_Config p) {
		p.ConfHdr_label_nm.setListListener(p);
		p.ConfHdr_label_nm.addAllListener(p);
		p.ConfHdr_cmnt.setListListener(p);
		p.ConfHdr_cmnt.addAllListener(p);
	}

	/**
	 *  [Conf]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitConf(FSBBP_Config p) {
	}

	/**
	 *  [Btn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitBtn(FSBBP_Config p) {
		p.Btn_upd.addAllListener(p);
		p.Btn_upd.setAPMethodName("doBtn_upd");
		p.Btn_cncl.addAllListener(p);
		p.Btn_cncl.setAPMethodName("doBtn_cncl");
	}

	/**
	 * [INIT]ステータスの[MenuPnl]ブロックのモードの設定
	 */
	protected static void statusInitINIT_MenuPnl(FSBBP_Config p){

	}

	/**
	 * [INIT]ステータスの[MenuHdr]ブロックのモードの設定
	 */
	protected static void statusInitINIT_MenuHdr(FSBBP_Config p){

	}

	/**
	 * [INIT]ステータスの[Menu]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Menu(FSBBP_Config p){

	}

	/**
	 * [INIT]ステータスの[ConfPnl]ブロックのモードの設定
	 */
	protected static void statusInitINIT_ConfPnl(FSBBP_Config p){

	}

	/**
	 * [INIT]ステータスの[ConfHdr]ブロックのモードの設定
	 */
	protected static void statusInitINIT_ConfHdr(FSBBP_Config p){
		p.ConfHdr_label_nm.putMode(p, INIT, MCMode.READ_ONLY);
		p.ConfHdr_cmnt.putMode(p, INIT, MCMode.READ_ONLY);

	}

	/**
	 * [INIT]ステータスの[Conf]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Conf(FSBBP_Config p){

	}

	/**
	 * [INIT]ステータスの[Btn]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Btn(FSBBP_Config p){
		p.Btn_upd.putMode(p, INIT, MCMode.ENABLE);
		p.Btn_cncl.putMode(p, INIT, MCMode.ENABLE);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return INIT;
	}

	/**
	 * Table/Tree/GanttChartの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
		FSBBP_Config_FW.setTableConfigMenu((FSBBP_Config)this);
	}

	/**
	 * [Menu]ブロックのTreeの設定
	 */
	protected static void setTableConfigMenu(FSBBP_Config p) {
		p.MenuTree.setKeyColumnName("parent", "key", "label");
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
	}

	/**
	 * この画面を[INIT]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setINITStatus() {
		status = INIT;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (INIT.equals(status)) {
			setINITStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}


	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == Btn_upd) doBtn_upd(info);
		else if (ap == Btn_cncl) doBtn_cncl(info);
	}

	/**
	 * [Btn]パネルの[upd]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_upd(MCEventInfo info);

	/**
	 * [Btn]パネルの[cncl]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_cncl(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == MenuTree) return doMenu_VC(info);
		if (vc == ConfHdr_label_nm) return doConfHdr_label_nm_VC(info);
		if (vc == ConfHdr_cmnt) return doConfHdr_cmnt_VC(info);
		return true;
	}

	/**
	 * [Menu]Treeの選択ノードが変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMenu_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ConfHdr]パネルの[label_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doConfHdr_label_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ConfHdr]パネルの[cmnt]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doConfHdr_cmnt_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == MenuTree) doMenu_NC(info);
		else if (nc == ConfHdr_label_nm) doConfHdr_label_nm_NC(info);
		else if (nc == ConfHdr_cmnt) doConfHdr_cmnt_NC(info);
	}

	/**
	 * [Menu]Treeの選択ノードが変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMenu_NC(MCEventInfo info){
	}

	/**
	 * [ConfHdr]パネルの[label_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doConfHdr_label_nm_NC(MCEventInfo info){
	}

	/**
	 * [ConfHdr]パネルの[cmnt]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doConfHdr_cmnt_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == MenuTree) doMenu_NE(info);
		else if (ne == ConfHdr_label_nm) doConfHdr_label_nm_NE(info);
		else if (ne == ConfHdr_cmnt) doConfHdr_cmnt_NE(info);
	}

	/**
	 * [Menu]TreeのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMenu_NE(MCEventInfo info){
	}

	/**
	 * [ConfHdr]パネルの[label_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doConfHdr_label_nm_NE(MCEventInfo info){
	}

	/**
	 * [ConfHdr]パネルの[cmnt]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doConfHdr_cmnt_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == MenuTree) doMenu_NX(info);
		else if (nx == ConfHdr_label_nm) doConfHdr_label_nm_NX(info);
		else if (nx == ConfHdr_cmnt) doConfHdr_cmnt_NX(info);
	}

	/**
	 * [Menu]TreeのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMenu_NX(MCEventInfo info){
	}

	/**
	 * [ConfHdr]パネルの[label_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doConfHdr_label_nm_NX(MCEventInfo info){
	}

	/**
	 * [ConfHdr]パネルの[cmnt]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doConfHdr_cmnt_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == ConfHdr_label_nm) doConfHdr_label_nm_LC(info);
		else if (lc == ConfHdr_cmnt) doConfHdr_cmnt_LC(info);
	}

	/**
	 * [ConfHdr]パネルの[label_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doConfHdr_label_nm_LC(MCEventInfo info){
	}

	/**
	 * [ConfHdr]パネルの[cmnt]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doConfHdr_cmnt_LC(MCEventInfo info){
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}