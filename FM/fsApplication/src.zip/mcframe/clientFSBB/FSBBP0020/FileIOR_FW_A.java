package mcframe.clientFSBB.FSBBP0020;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"FileIO"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class FileIOR_FW_A extends MCConstRow {

	/**
	 *  初期表示ディレクトリ.<p>
	 *
	 */
	public static final String $init_dir = "init_dir";
	/**
	 *  テーブル出力.<p>
	 *
	 */
	public static final String $tbl_display = "tbl_display";
	/**
	 *  画面出力.<p>
	 *
	 */
	public static final String $rootpnl_display = "rootpnl_display";


	public static final MCMeta init_dir_META = createCommonMeta($init_dir, mcframe.commonCore.meta.M_META.PATH);
	public static final MCMeta tbl_display_META = createCommonMeta($tbl_display, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta rootpnl_display_META = createCommonMeta($rootpnl_display, mcframe.commonCore.meta.M_META.FLG);

	protected static final ConstMetaList<FileIOR> constMetas = new ConstMetaList<FileIOR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			init_dir_META,
			tbl_display_META,
			rootpnl_display_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected FileIOR_FW_A(ConstMetaList<? extends FileIOR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public FileIOR clone() {
		return (FileIOR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public FileIOR createInstance() {
		return (FileIOR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public FileIOR getValues(String... names) {
		return (FileIOR) super.getValues(names);
	}



	/**
	 *  初期表示ディレクトリ.<p>
	 *
	 */
	public String init_dir() {
		return getConstString(offset + 0, $init_dir);
	}

	/**
	 *  初期表示ディレクトリ.<p>
	 *
	 */
	public void init_dir(String value) {
		setConstString(offset + 0, $init_dir, value);
	}


	/**
	 *  テーブル出力.<p>
	 *
	 */
	public boolean tbl_display() {
		return getConstBoolean(offset + 1, $tbl_display);
	}

	/**
	 *  テーブル出力.<p>
	 *
	 */
	public void tbl_display(boolean value) {
		setConstBoolean(offset + 1, $tbl_display, value);
	}


	/**
	 *  画面出力.<p>
	 *
	 */
	public boolean rootpnl_display() {
		return getConstBoolean(offset + 2, $rootpnl_display);
	}

	/**
	 *  画面出力.<p>
	 *
	 */
	public void rootpnl_display(boolean value) {
		setConstBoolean(offset + 2, $rootpnl_display, value);
	}


	public String getString(String name) {
		if ($init_dir.equalsIgnoreCase(name)) {
			return init_dir();
		}
		return super.getString(name);
	}
	public boolean getBoolean(String name) {
		if ($tbl_display.equalsIgnoreCase(name)) {
			return tbl_display();
		}
		if ($rootpnl_display.equalsIgnoreCase(name)) {
			return rootpnl_display();
		}
		return super.getBoolean(name);
	}

	public String getStringNE(String name) {
		if ($init_dir.equalsIgnoreCase(name)) {
			return init_dir();
		}
		return super.getStringNE(name);
	}
	public boolean getBooleanNE(String name) {
		if ($tbl_display.equalsIgnoreCase(name)) {
			return tbl_display();
		}
		if ($rootpnl_display.equalsIgnoreCase(name)) {
			return rootpnl_display();
		}
		return super.getBooleanNE(name);
	}

	public void setString(String name, String value) {
		if ($init_dir.equalsIgnoreCase(name)) {
			init_dir(value);
			return;
		}
		super.setString(name, value);
	}
	public void setBoolean(String name, boolean value) {
		if ($tbl_display.equalsIgnoreCase(name)) {
			tbl_display(value);
			return;
		}
		if ($rootpnl_display.equalsIgnoreCase(name)) {
			rootpnl_display(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($init_dir.equalsIgnoreCase(name)) {
			init_dir(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setBooleanNE(String name, boolean value) {
		if ($tbl_display.equalsIgnoreCase(name)) {
			tbl_display(value);
			return;
		}
		if ($rootpnl_display.equalsIgnoreCase(name)) {
			rootpnl_display(value);
			return;
		}
		super.setBooleanNE(name, value);
	}



}

