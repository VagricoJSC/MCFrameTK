package mcframe.clientFSBB.FSBBP0020;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Screen"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class ScreenR_FW_A extends MCConstRow {

	/**
	 *  モジュールＩＤ.<p>
	 *
	 */
	public static final String $initModuleID = "initModuleID";
	/**
	 *  画面ＩＤ.<p>
	 *
	 */
	public static final String $initScreenID = "initScreenID";
	/**
	 *  画面名.<p>
	 *
	 */
	public static final String $initScreenName = "initScreenName";
	/**
	 *  モジュールＩＤ.<p>
	 *
	 */
	public static final String $initScreenModuleID = "initScreenModuleID";
	/**
	 *  画面モード.<p>
	 *
	 */
	public static final String $initScreenMode = "initScreenMode";


	public static final MCMeta initModuleID_META = createCommonMeta($initModuleID, mcframe.commonCore.meta.M_META.MODULE_ID);
	public static final MCMeta initScreenID_META = createCommonMeta($initScreenID, mcframe.commonCore.meta.M_META.SCREEN_ID);
	public static final MCMeta initScreenName_META = createCommonMeta($initScreenName, mcframe.commonCore.meta.M_META.SCREEN_NAME);
	public static final MCMeta initScreenModuleID_META = createCommonMeta($initScreenModuleID, mcframe.commonCore.meta.M_META.MODULE_ID);
	public static final MCMeta initScreenMode_META = createNumberMeta($initScreenMode);

	protected static final ConstMetaList<ScreenR> constMetas = new ConstMetaList<ScreenR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			initModuleID_META,
			initScreenID_META,
			initScreenName_META,
			initScreenModuleID_META,
			initScreenMode_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected ScreenR_FW_A(ConstMetaList<? extends ScreenR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ScreenR clone() {
		return (ScreenR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ScreenR createInstance() {
		return (ScreenR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ScreenR getValues(String... names) {
		return (ScreenR) super.getValues(names);
	}



	/**
	 *  モジュールＩＤ.<p>
	 *
	 */
	public String initModuleID() {
		return getConstString(offset + 0, $initModuleID);
	}

	/**
	 *  モジュールＩＤ.<p>
	 *
	 */
	public void initModuleID(String value) {
		setConstString(offset + 0, $initModuleID, value);
	}


	/**
	 *  画面ＩＤ.<p>
	 *
	 */
	public String initScreenID() {
		return getConstString(offset + 1, $initScreenID);
	}

	/**
	 *  画面ＩＤ.<p>
	 *
	 */
	public void initScreenID(String value) {
		setConstString(offset + 1, $initScreenID, value);
	}


	/**
	 *  画面名.<p>
	 *
	 */
	public String initScreenName() {
		return getConstString(offset + 2, $initScreenName);
	}

	/**
	 *  画面名.<p>
	 *
	 */
	public void initScreenName(String value) {
		setConstString(offset + 2, $initScreenName, value);
	}


	/**
	 *  モジュールＩＤ.<p>
	 *
	 */
	public String initScreenModuleID() {
		return getConstString(offset + 3, $initScreenModuleID);
	}

	/**
	 *  モジュールＩＤ.<p>
	 *
	 */
	public void initScreenModuleID(String value) {
		setConstString(offset + 3, $initScreenModuleID, value);
	}


	/**
	 *  画面モード.<p>
	 *
	 */
	public MCNumber initScreenMode() {
		return getConstNumber(offset + 4, $initScreenMode);
	}

	/**
	 *  画面モード.<p>
	 *
	 */
	public void initScreenMode(MCNumber value) {
		setConstNumber(offset + 4, $initScreenMode, value);
	}

	/**
	 *  画面モード.<p>
	 *
	 */
	public void initScreenMode(int value) {
		setConstNumber(offset + 4, $initScreenMode, value);
	}

	/**
	 *  画面モード.<p>
	 *
	 */
	public void initScreenMode(long value) {
		setConstNumber(offset + 4, $initScreenMode, value);
	}

	/**
	 *  画面モード.<p>
	 *
	 */
	public void initScreenMode(float value) {
		setConstNumber(offset + 4, $initScreenMode, value);
	}

	/**
	 *  画面モード.<p>
	 *
	 */
	public void initScreenMode(double value) {
		setConstNumber(offset + 4, $initScreenMode, value);
	}


	public String getString(String name) {
		if ($initModuleID.equalsIgnoreCase(name)) {
			return initModuleID();
		}
		if ($initScreenID.equalsIgnoreCase(name)) {
			return initScreenID();
		}
		if ($initScreenName.equalsIgnoreCase(name)) {
			return initScreenName();
		}
		if ($initScreenModuleID.equalsIgnoreCase(name)) {
			return initScreenModuleID();
		}
		return super.getString(name);
	}
	public MCNumber getNumber(String name) {
		if ($initScreenMode.equalsIgnoreCase(name)) {
			return initScreenMode();
		}
		return super.getNumber(name);
	}

	public String getStringNE(String name) {
		if ($initModuleID.equalsIgnoreCase(name)) {
			return initModuleID();
		}
		if ($initScreenID.equalsIgnoreCase(name)) {
			return initScreenID();
		}
		if ($initScreenName.equalsIgnoreCase(name)) {
			return initScreenName();
		}
		if ($initScreenModuleID.equalsIgnoreCase(name)) {
			return initScreenModuleID();
		}
		return super.getStringNE(name);
	}
	public MCNumber getNumberNE(String name) {
		if ($initScreenMode.equalsIgnoreCase(name)) {
			return initScreenMode();
		}
		return super.getNumberNE(name);
	}

	public void setString(String name, String value) {
		if ($initModuleID.equalsIgnoreCase(name)) {
			initModuleID(value);
			return;
		}
		if ($initScreenID.equalsIgnoreCase(name)) {
			initScreenID(value);
			return;
		}
		if ($initScreenName.equalsIgnoreCase(name)) {
			initScreenName(value);
			return;
		}
		if ($initScreenModuleID.equalsIgnoreCase(name)) {
			initScreenModuleID(value);
			return;
		}
		super.setString(name, value);
	}
	public void setNumber(String name, MCNumber value) {
		if ($initScreenMode.equalsIgnoreCase(name)) {
			initScreenMode(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, int value) {
		if ($initScreenMode.equalsIgnoreCase(name)) {
			initScreenMode(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, long value) {
		if ($initScreenMode.equalsIgnoreCase(name)) {
			initScreenMode(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, float value) {
		if ($initScreenMode.equalsIgnoreCase(name)) {
			initScreenMode(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, double value) {
		if ($initScreenMode.equalsIgnoreCase(name)) {
			initScreenMode(value);
			return;
		}
		super.setNumber(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($initModuleID.equalsIgnoreCase(name)) {
			initModuleID(value);
			return;
		}
		if ($initScreenID.equalsIgnoreCase(name)) {
			initScreenID(value);
			return;
		}
		if ($initScreenName.equalsIgnoreCase(name)) {
			initScreenName(value);
			return;
		}
		if ($initScreenModuleID.equalsIgnoreCase(name)) {
			initScreenModuleID(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setNumberNE(String name, MCNumber value) {
		if ($initScreenMode.equalsIgnoreCase(name)) {
			initScreenMode(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, int value) {
		if ($initScreenMode.equalsIgnoreCase(name)) {
			initScreenMode(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, long value) {
		if ($initScreenMode.equalsIgnoreCase(name)) {
			initScreenMode(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, float value) {
		if ($initScreenMode.equalsIgnoreCase(name)) {
			initScreenMode(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, double value) {
		if ($initScreenMode.equalsIgnoreCase(name)) {
			initScreenMode(value);
			return;
		}
		super.setNumberNE(name, value);
	}



}

