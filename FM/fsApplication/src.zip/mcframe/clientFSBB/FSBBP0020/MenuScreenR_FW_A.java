package mcframe.clientFSBB.FSBBP0020;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"MenuScreen"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class MenuScreenR_FW_A extends MCConstRow {

	/**
	 *  初期選択メニュータブ.<p>
	 *
	 */
	public static final String $initTabName = "initTabName";
	/**
	 *  初期選択メニューパス.<p>
	 *
	 */
	public static final String $initTabPath = "initTabPath";


	public static final MCMeta initTabName_META = createStringMeta($initTabName, 256);
	public static final MCMeta initTabPath_META = createStringMeta($initTabPath, 2000);

	protected static final ConstMetaList<MenuScreenR> constMetas = new ConstMetaList<MenuScreenR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			initTabName_META,
			initTabPath_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected MenuScreenR_FW_A(ConstMetaList<? extends MenuScreenR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public MenuScreenR clone() {
		return (MenuScreenR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public MenuScreenR createInstance() {
		return (MenuScreenR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public MenuScreenR getValues(String... names) {
		return (MenuScreenR) super.getValues(names);
	}



	/**
	 *  初期選択メニュータブ.<p>
	 *
	 */
	public String initTabName() {
		return getConstString(offset + 0, $initTabName);
	}

	/**
	 *  初期選択メニュータブ.<p>
	 *
	 */
	public void initTabName(String value) {
		setConstString(offset + 0, $initTabName, value);
	}


	/**
	 *  初期選択メニューパス.<p>
	 *
	 */
	public String initTabPath() {
		return getConstString(offset + 1, $initTabPath);
	}

	/**
	 *  初期選択メニューパス.<p>
	 *
	 */
	public void initTabPath(String value) {
		setConstString(offset + 1, $initTabPath, value);
	}


	public String getString(String name) {
		if ($initTabName.equalsIgnoreCase(name)) {
			return initTabName();
		}
		if ($initTabPath.equalsIgnoreCase(name)) {
			return initTabPath();
		}
		return super.getString(name);
	}

	public String getStringNE(String name) {
		if ($initTabName.equalsIgnoreCase(name)) {
			return initTabName();
		}
		if ($initTabPath.equalsIgnoreCase(name)) {
			return initTabPath();
		}
		return super.getStringNE(name);
	}

	public void setString(String name, String value) {
		if ($initTabName.equalsIgnoreCase(name)) {
			initTabName(value);
			return;
		}
		if ($initTabPath.equalsIgnoreCase(name)) {
			initTabPath(value);
			return;
		}
		super.setString(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($initTabName.equalsIgnoreCase(name)) {
			initTabName(value);
			return;
		}
		if ($initTabPath.equalsIgnoreCase(name)) {
			initTabPath(value);
			return;
		}
		super.setStringNE(name, value);
	}



}

