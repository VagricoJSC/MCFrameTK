package mcframe.clientFSBB.FSBBP0020;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBBP0020"パネルクラスです。<p>
 *
 * 一般の環境設定画面です。<br>
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBBP0020_FW_A extends mcframe.clientFSBB.FSBBP0100.FSBBP_PartsBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBB";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBBP0020";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Main]ブロック関連のField定義
	// [Main]ブロックの項目のField定義
	// [MenuScreen]ブロック関連のField定義
	public MCPanel MenuScreenPanel = null;
	public MCTitledBorder MenuScreenTitledBorder = null;
	// [MenuScreen]ブロックの項目のField定義
	public MCLabel MenuScreen_initTabName_Label = null;
	/**
	 *  初期選択メニュータブ.<p>
	 *
	 */
	public MCTextComboBox MenuScreen_initTabName = null;
	public MCLabel MenuScreen_initTabPath_Label = null;
	/**
	 *  初期選択メニューパス.<p>
	 *
	 */
	public MCTextField MenuScreen_initTabPath = null;
	// [Screen]ブロック関連のField定義
	public MCPanel ScreenPanel = null;
	public MCTitledBorder ScreenTitledBorder = null;
	// [Screen]ブロックの項目のField定義
	/**
	 *  初期表示画面.<p>
	 *
	 */
	public MCLabel Screen_initScreenLabel = null;
	/**
	 *  モジュールＩＤ.<p>
	 *
	 */
	public MCTextComboBox Screen_initModuleID = null;
	/**
	 *  画面ＩＤ.<p>
	 *
	 */
	public MCTextField Screen_initScreenID = null;
	/**
	 *  画面名.<p>
	 *
	 */
	public MCTextField Screen_initScreenName = null;
	/**
	 *  モジュールＩＤ.<p>
	 *
	 */
	public MCTextField Screen_initScreenModuleID = null;
	/**
	 *  画面モード.<p>
	 *
	 */
	public MCNumberField Screen_initScreenMode = null;
	// [Dialog]ブロック関連のField定義
	public MCPanel DialogPanel = null;
	public MCTitledBorder DialogTitledBorder = null;
	// [Dialog]ブロックの項目のField定義
	public MCLabel Dialog_prog_delay_millis_Label = null;
	/**
	 *  処理中ダイアログ遅延(ミリ秒).<p>
	 *
	 */
	public MCNumberField Dialog_prog_delay_millis = null;
	// [FileIO]ブロック関連のField定義
	public MCPanel FileIOPanel = null;
	public MCTitledBorder FileIOTitledBorder = null;
	// [FileIO]ブロックの項目のField定義
	public MCLabel FileIO_init_dir_Label = null;
	/**
	 *  初期表示ディレクトリ.<p>
	 *
	 */
	public MCTextField FileIO_init_dir = null;
	/**
	 *  参照.<p>
	 *
	 */
	public MCButton FileIO_init_dir_FB = null;
	/**
	 *  Ｅｘｃｅｌ出力後にファイルを表示する.<p>
	 *
	 */
	public MCLabel FileIO_display_lab = null;
	/**
	 *  テーブル出力.<p>
	 *
	 */
	public MCCheckBox FileIO_tbl_display = null;
	/**
	 *  画面出力.<p>
	 *
	 */
	public MCCheckBox FileIO_rootpnl_display = null;
	// [Beans]ブロック関連のField定義
	public MCPanel BeansPanel = null;
	// [Beans]ブロックの項目のField定義
	public MCLabel Beans_gui_auto_focus_typ_nm_Label = null;
	/**
	 *  最大文字数入力時のフォーカス移動.<p>
	 *
	 */
	public MCTextComboBox Beans_gui_auto_focus_typ_nm = null;
	public MCTextField Beans_gui_auto_focus_typ = null;
	// [Browser]ブロック関連のField定義
	public MCPanel BrowserPanel = null;
	public MCTitledBorder BrowserTitledBorder = null;
	// [Browser]ブロックの項目のField定義
	public MCLabel Browser_browser_path_Label = null;
	/**
	 *  ブラウザ実行ファイル.<p>
	 *
	 */
	public MCTextField Browser_browser_path = null;
	/**
	 *  参照.<p>
	 *
	 */
	public MCButton Browser_browser_path_FB = null;
	// [Browser_comm]ブロック関連のField定義
	public MCPanel Browser_commPanel = null;
	public MCTitledBorder Browser_commTitledBorder = null;
	// [Browser_comm]ブロックの項目のField定義
	public MCLabel Browser_comm_browser_path_Label = null;
	/**
	 *  ブラウザ実行ファイル.<p>
	 *
	 */
	public MCTextField Browser_comm_browser_path = null;
	/**
	 *  参照.<p>
	 *
	 */
	public MCButton Browser_comm_browser_path_FB = null;
	// [Psnl]ブロック関連のField定義
	public MCPanel PsnlPanel = null;
	public MCTitledBorder PsnlTitledBorder = null;
	// [Psnl]ブロックの項目のField定義
	public mcframe.clientFSUB.FSUBP0090.FSUBP_SettingUnit_H Psnl_setting_PPanel;
	/**
	 *  会社共通.<p>
	 *
	 */
	public MCButton Psnl_upd_ext = null;
	/**
	 *  システム共通.<p>
	 *
	 */
	public MCButton Psnl_upd_sys = null;
	public mcframe.clientFSBB.FSBBP0060.FSBBP_PsnlIO Psnl_psnl_PPanel;
	// [Blank]ブロック関連のField定義
	public MCPanel BlankPanel = null;
	// [Blank]ブロックの項目のField定義
	/** [INIT]モードを表す定数 */
	public static final String INIT = "INIT";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{INIT};
	
	/** [MenuScreen]ブロックのコンテナField定義 */
	private final mcframe.clientFSBB.FSBBP0020.MenuScreenR aMenuScreenR;
	/** [Screen]ブロックのコンテナField定義 */
	private final mcframe.clientFSBB.FSBBP0020.ScreenR aScreenR;
	/** [Dialog]ブロックのコンテナField定義 */
	private final mcframe.clientFSBB.FSBBP0020.DialogR aDialogR;
	/** [FileIO]ブロックのコンテナField定義 */
	private final mcframe.clientFSBB.FSBBP0020.FileIOR aFileIOR;
	/** [Beans]ブロックのコンテナField定義 */
	private final mcframe.clientFSBB.FSBBP0020.BeansR aBeansR;
	/** [Browser]ブロックのコンテナField定義 */
	private final mcframe.clientFSBB.FSBBP0020.BrowserR aBrowserR;
	/** [Browser_comm]ブロックのコンテナField定義 */
	private final mcframe.clientFSBB.FSBBP0020.Browser_commR aBrowser_commR;

	/**
	 * 項目コピーによってaMenuScreenRを設定します。
	 *
	 * aMenuScreenRのインスタンスは変更されません。
	 *
	 * @param row MenuScreenR
	 */
	public void setMenuScreenR(mcframe.clientFSBB.FSBBP0020.MenuScreenR row) {
		if (row != null) {
			MCRow.copyall(getMenuScreenR(), row);
		}
	}

	/**
	 * [MenuScreen]ブロックのコンテナaMenuScreenRを返します。
	 *
	 * @return MenuScreenR
	 */
	public mcframe.clientFSBB.FSBBP0020.MenuScreenR getMenuScreenR() {
		return aMenuScreenR;
	}

	/**
	 * aMenuScreenRを作成します。
	 *
	 * @return MenuScreenR
	 */
	public mcframe.clientFSBB.FSBBP0020.MenuScreenR createMenuScreenR() {
		return mcframe.clientFSBB.FSBBP0020.MenuScreenR.create();
	}

	/**
	 * 項目コピーによってaScreenRを設定します。
	 *
	 * aScreenRのインスタンスは変更されません。
	 *
	 * @param row ScreenR
	 */
	public void setScreenR(mcframe.clientFSBB.FSBBP0020.ScreenR row) {
		if (row != null) {
			MCRow.copyall(getScreenR(), row);
		}
	}

	/**
	 * [Screen]ブロックのコンテナaScreenRを返します。
	 *
	 * @return ScreenR
	 */
	public mcframe.clientFSBB.FSBBP0020.ScreenR getScreenR() {
		return aScreenR;
	}

	/**
	 * aScreenRを作成します。
	 *
	 * @return ScreenR
	 */
	public mcframe.clientFSBB.FSBBP0020.ScreenR createScreenR() {
		return mcframe.clientFSBB.FSBBP0020.ScreenR.create();
	}

	/**
	 * 項目コピーによってaDialogRを設定します。
	 *
	 * aDialogRのインスタンスは変更されません。
	 *
	 * @param row DialogR
	 */
	public void setDialogR(mcframe.clientFSBB.FSBBP0020.DialogR row) {
		if (row != null) {
			MCRow.copyall(getDialogR(), row);
		}
	}

	/**
	 * [Dialog]ブロックのコンテナaDialogRを返します。
	 *
	 * @return DialogR
	 */
	public mcframe.clientFSBB.FSBBP0020.DialogR getDialogR() {
		return aDialogR;
	}

	/**
	 * aDialogRを作成します。
	 *
	 * @return DialogR
	 */
	public mcframe.clientFSBB.FSBBP0020.DialogR createDialogR() {
		return mcframe.clientFSBB.FSBBP0020.DialogR.create();
	}

	/**
	 * 項目コピーによってaFileIORを設定します。
	 *
	 * aFileIORのインスタンスは変更されません。
	 *
	 * @param row FileIOR
	 */
	public void setFileIOR(mcframe.clientFSBB.FSBBP0020.FileIOR row) {
		if (row != null) {
			MCRow.copyall(getFileIOR(), row);
		}
	}

	/**
	 * [FileIO]ブロックのコンテナaFileIORを返します。
	 *
	 * @return FileIOR
	 */
	public mcframe.clientFSBB.FSBBP0020.FileIOR getFileIOR() {
		return aFileIOR;
	}

	/**
	 * aFileIORを作成します。
	 *
	 * @return FileIOR
	 */
	public mcframe.clientFSBB.FSBBP0020.FileIOR createFileIOR() {
		return mcframe.clientFSBB.FSBBP0020.FileIOR.create();
	}

	/**
	 * 項目コピーによってaBeansRを設定します。
	 *
	 * aBeansRのインスタンスは変更されません。
	 *
	 * @param row BeansR
	 */
	public void setBeansR(mcframe.clientFSBB.FSBBP0020.BeansR row) {
		if (row != null) {
			MCRow.copyall(getBeansR(), row);
		}
	}

	/**
	 * [Beans]ブロックのコンテナaBeansRを返します。
	 *
	 * @return BeansR
	 */
	public mcframe.clientFSBB.FSBBP0020.BeansR getBeansR() {
		return aBeansR;
	}

	/**
	 * aBeansRを作成します。
	 *
	 * @return BeansR
	 */
	public mcframe.clientFSBB.FSBBP0020.BeansR createBeansR() {
		return mcframe.clientFSBB.FSBBP0020.BeansR.create();
	}

	/**
	 * 項目コピーによってaBrowserRを設定します。
	 *
	 * aBrowserRのインスタンスは変更されません。
	 *
	 * @param row BrowserR
	 */
	public void setBrowserR(mcframe.clientFSBB.FSBBP0020.BrowserR row) {
		if (row != null) {
			MCRow.copyall(getBrowserR(), row);
		}
	}

	/**
	 * [Browser]ブロックのコンテナaBrowserRを返します。
	 *
	 * @return BrowserR
	 */
	public mcframe.clientFSBB.FSBBP0020.BrowserR getBrowserR() {
		return aBrowserR;
	}

	/**
	 * aBrowserRを作成します。
	 *
	 * @return BrowserR
	 */
	public mcframe.clientFSBB.FSBBP0020.BrowserR createBrowserR() {
		return mcframe.clientFSBB.FSBBP0020.BrowserR.create();
	}

	/**
	 * 項目コピーによってaBrowser_commRを設定します。
	 *
	 * aBrowser_commRのインスタンスは変更されません。
	 *
	 * @param row Browser_commR
	 */
	public void setBrowser_commR(mcframe.clientFSBB.FSBBP0020.Browser_commR row) {
		if (row != null) {
			MCRow.copyall(getBrowser_commR(), row);
		}
	}

	/**
	 * [Browser_comm]ブロックのコンテナaBrowser_commRを返します。
	 *
	 * @return Browser_commR
	 */
	public mcframe.clientFSBB.FSBBP0020.Browser_commR getBrowser_commR() {
		return aBrowser_commR;
	}

	/**
	 * aBrowser_commRを作成します。
	 *
	 * @return Browser_commR
	 */
	public mcframe.clientFSBB.FSBBP0020.Browser_commR createBrowser_commR() {
		return mcframe.clientFSBB.FSBBP0020.Browser_commR.create();
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getMenuScreenR())) ret.add(getMenuScreenR());
		if(!MCCollectionUtil.contains(ret, getScreenR())) ret.add(getScreenR());
		if(!MCCollectionUtil.contains(ret, getDialogR())) ret.add(getDialogR());
		if(!MCCollectionUtil.contains(ret, getFileIOR())) ret.add(getFileIOR());
		if(!MCCollectionUtil.contains(ret, getBeansR())) ret.add(getBeansR());
		if(!MCCollectionUtil.contains(ret, getBrowserR())) ret.add(getBrowserR());
		if(!MCCollectionUtil.contains(ret, getBrowser_commR())) ret.add(getBrowser_commR());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getMenuScreenR()) return "MenuScreen";
		if(aCnt == getScreenR()) return "Screen";
		if(aCnt == getDialogR()) return "Dialog";
		if(aCnt == getFileIOR()) return "FileIO";
		if(aCnt == getBeansR()) return "Beans";
		if(aCnt == getBrowserR()) return "Browser";
		if(aCnt == getBrowser_commR()) return "Browser_comm";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("MenuScreen")) return getMenuScreenR();
		if(bId.equals("Screen")) return getScreenR();
		if(bId.equals("Dialog")) return getDialogR();
		if(bId.equals("FileIO")) return getFileIOR();
		if(bId.equals("Beans")) return getBeansR();
		if(bId.equals("Browser")) return getBrowserR();
		if(bId.equals("Browser_comm")) return getBrowser_commR();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(MenuScreenPanel);
		ret.add(ScreenPanel);
		ret.add(DialogPanel);
		ret.add(FileIOPanel);
		ret.add(BeansPanel);
		ret.add(BrowserPanel);
		ret.add(Browser_commPanel);
		ret.add(PsnlPanel);
		ret.add(BlankPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBBP0020_FW_A() {
		aMenuScreenR = createMenuScreenR();
		aScreenR = createScreenR();
		aDialogR = createDialogR();
		aFileIOR = createFileIOR();
		aBeansR = createBeansR();
		aBrowserR = createBrowserR();
		aBrowser_commR = createBrowser_commR();

	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBBP0020_FW.jbCreateMain((FSBBP0020)this);
		FSBBP0020_FW.jbCreateMenuScreen((FSBBP0020)this);
		FSBBP0020_FW.jbCreateScreen((FSBBP0020)this);
		FSBBP0020_FW.jbCreateDialog((FSBBP0020)this);
		FSBBP0020_FW.jbCreateFileIO((FSBBP0020)this);
		FSBBP0020_FW.jbCreateBeans((FSBBP0020)this);
		FSBBP0020_FW.jbCreateBrowser((FSBBP0020)this);
		FSBBP0020_FW.jbCreateBrowser_comm((FSBBP0020)this);
		FSBBP0020_FW.jbCreatePsnl((FSBBP0020)this);
		FSBBP0020_FW.jbCreateBlank((FSBBP0020)this);
	}

	/**
	 * [Main]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateMain(FSBBP0020 p) {
	}

	/**
	 * [MenuScreen]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateMenuScreen(FSBBP0020 p) {
	}

	/**
	 * [Screen]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateScreen(FSBBP0020 p) {
	}

	/**
	 * [Dialog]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateDialog(FSBBP0020 p) {
	}

	/**
	 * [FileIO]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateFileIO(FSBBP0020 p) {
	}

	/**
	 * [Beans]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateBeans(FSBBP0020 p) {
	}

	/**
	 * [Browser]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateBrowser(FSBBP0020 p) {
	}

	/**
	 * [Browser_comm]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateBrowser_comm(FSBBP0020 p) {
	}

	/**
	 * [Psnl]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreatePsnl(FSBBP0020 p) {
		p.Psnl_setting_PPanel = mcframe.clientFSUB.FSUBP0090.FSUBP_SettingUnit_H.create();
		p.Psnl_setting_PPanel.setName("Psnl.setting");
		p.Psnl_psnl_PPanel = mcframe.clientFSBB.FSBBP0060.FSBBP_PsnlIO.create();
		p.Psnl_psnl_PPanel.setName("Psnl.psnl");
	}

	/**
	 * [Blank]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateBlank(FSBBP0020 p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}

	
	/** [MenuScreen_initTabName_ListPutter]の定義 */
	private MCListPutter MenuScreen_initTabName_p = null;

	/**
	 * [MenuScreen_initTabName_ListPutter]の取得
	 */
	protected MCListPutter getMenuScreen_initTabName_ListPutter() {
		if (MenuScreen_initTabName_p == null) {
			MenuScreen_initTabName_p = createMenuScreen_initTabName_ListPutter(MenuScreen_initTabName, "initTabName", "initTabPath");

		}
		return MenuScreen_initTabName_p;
	}
	
	
	/** [Screen_initModuleID_ListPutter]の定義 */
	private MCListPutter Screen_initModuleID_p = null;

	/**
	 * [Screen_initModuleID_ListPutter]の取得
	 */
	protected MCListPutter getScreen_initModuleID_ListPutter() {
		if (Screen_initModuleID_p == null) {
			Screen_initModuleID_p = createScreen_initModuleID_ListPutter(Screen_initModuleID, "initModuleID");

		}
		return Screen_initModuleID_p;
	}
	
	
	/** [Screen_initScreenID_ListPutter]の定義 */
	private MCListPutter Screen_initScreenID_p = null;

	/**
	 * [Screen_initScreenID_ListPutter]の取得
	 */
	protected MCListPutter getScreen_initScreenID_ListPutter() {
		if (Screen_initScreenID_p == null) {
			Screen_initScreenID_p = createScreen_initScreenID_ListPutter(Screen_initScreenID, "initScreenID", "initScreenName","initScreenModuleID");

		}
		return Screen_initScreenID_p;
	}
	
	
	/** [Beans_gui_auto_focus_typ_nm_ListPutter]の定義 */
	private MCListPutter Beans_gui_auto_focus_typ_nm_p = null;

	/**
	 * [Beans_gui_auto_focus_typ_nm_ListPutter]の取得
	 */
	protected MCListPutter getBeans_gui_auto_focus_typ_nm_ListPutter() {
		if (Beans_gui_auto_focus_typ_nm_p == null) {
			Beans_gui_auto_focus_typ_nm_p = createBeans_gui_auto_focus_typ_nm_ListPutter(Beans_gui_auto_focus_typ_nm, "gui_auto_focus_typ_nm", "gui_auto_focus_typ");

		}
		return Beans_gui_auto_focus_typ_nm_p;
	}
	

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBBP0020 create(){
		FSBBP0020 p = new FSBBP0020();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}


	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBBP0020_FW.jbfInitMain((FSBBP0020)this);
		FSBBP0020_FW.jbfInitMenuScreen((FSBBP0020)this);
		FSBBP0020_FW.jbfInitScreen((FSBBP0020)this);
		FSBBP0020_FW.jbfInitDialog((FSBBP0020)this);
		FSBBP0020_FW.jbfInitFileIO((FSBBP0020)this);
		FSBBP0020_FW.jbfInitBeans((FSBBP0020)this);
		FSBBP0020_FW.jbfInitBrowser((FSBBP0020)this);
		FSBBP0020_FW.jbfInitBrowser_comm((FSBBP0020)this);
		FSBBP0020_FW.jbfInitPsnl((FSBBP0020)this);
		FSBBP0020_FW.jbfInitBlank((FSBBP0020)this);
		FSBBP0020_FW.jbInitMain((FSBBP0020)this);
		FSBBP0020_FW.jbInitMenuScreen((FSBBP0020)this);
		FSBBP0020_FW.jbInitScreen((FSBBP0020)this);
		FSBBP0020_FW.jbInitDialog((FSBBP0020)this);
		FSBBP0020_FW.jbInitFileIO((FSBBP0020)this);
		FSBBP0020_FW.jbInitBeans((FSBBP0020)this);
		FSBBP0020_FW.jbInitBrowser((FSBBP0020)this);
		FSBBP0020_FW.jbInitBrowser_comm((FSBBP0020)this);
		FSBBP0020_FW.jbInitPsnl((FSBBP0020)this);
		FSBBP0020_FW.jbInitBlank((FSBBP0020)this);
	}

	/**
	 * [Main]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitMain(FSBBP0020 p) {
		// ブロック関連の初期化
		// ブロックの項目の初期化
	}

	/**
	 * [MenuScreen]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitMenuScreen(FSBBP0020 p) {
		// ブロック関連の初期化
		p.MenuScreenPanel = p.beansFactory.createPanel("MenuScreen");
		p.MenuScreenTitledBorder = p.beansFactory.createTitledBorder();
		// ブロックの項目の初期化
		p.MenuScreen_initTabName_Label = p.beansFactory.createLabel("MenuScreen.initTabName_Label");
		p.MenuScreen_initTabName = p.beansFactory.createTextComboBox("MenuScreen.initTabName");
		p.MenuScreen_initTabName.setLabel(p.MenuScreen_initTabName_Label);
		p.MenuScreen_initTabPath_Label = p.beansFactory.createLabel("MenuScreen.initTabPath_Label");
		p.MenuScreen_initTabPath = p.beansFactory.createTextField("MenuScreen.initTabPath");
		p.MenuScreen_initTabPath.setLabel(p.MenuScreen_initTabPath_Label);
	}

	/**
	 * [Screen]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitScreen(FSBBP0020 p) {
		// ブロック関連の初期化
		p.ScreenPanel = p.beansFactory.createPanel("Screen");
		p.ScreenTitledBorder = p.beansFactory.createTitledBorder();
		// ブロックの項目の初期化
		p.Screen_initScreenLabel = p.beansFactory.createLabel("Screen.initScreenLabel");
		p.Screen_initModuleID = p.beansFactory.createTextComboBox("Screen.initModuleID");
		p.Screen_initScreenID = p.beansFactory.createTextField("Screen.initScreenID");
		p.Screen_initScreenName = p.beansFactory.createTextField("Screen.initScreenName");
		p.Screen_initScreenModuleID = p.beansFactory.createTextField("Screen.initScreenModuleID");
		p.Screen_initScreenMode = p.beansFactory.createNumberField("Screen.initScreenMode");
	}

	/**
	 * [Dialog]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitDialog(FSBBP0020 p) {
		// ブロック関連の初期化
		p.DialogPanel = p.beansFactory.createPanel("Dialog");
		p.DialogTitledBorder = p.beansFactory.createTitledBorder();
		// ブロックの項目の初期化
		p.Dialog_prog_delay_millis_Label = p.beansFactory.createLabel("Dialog.prog_delay_millis_Label");
		p.Dialog_prog_delay_millis = p.beansFactory.createNumberField("Dialog.prog_delay_millis");
		p.Dialog_prog_delay_millis.setLabel(p.Dialog_prog_delay_millis_Label);
	}

	/**
	 * [FileIO]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitFileIO(FSBBP0020 p) {
		// ブロック関連の初期化
		p.FileIOPanel = p.beansFactory.createPanel("FileIO");
		p.FileIOTitledBorder = p.beansFactory.createTitledBorder();
		// ブロックの項目の初期化
		p.FileIO_init_dir_Label = p.beansFactory.createLabel("FileIO.init_dir_Label");
		p.FileIO_init_dir = p.beansFactory.createTextField("FileIO.init_dir");
		p.FileIO_init_dir.setLabel(p.FileIO_init_dir_Label);
		p.FileIO_init_dir_FB = p.beansFactory.createButton("FileIO.init_dir_FB", "no_border");
		p.FileIO_display_lab = p.beansFactory.createLabel("FileIO.display_lab");
		p.FileIO_tbl_display = p.beansFactory.createCheckBox("FileIO.tbl_display");
		p.FileIO_rootpnl_display = p.beansFactory.createCheckBox("FileIO.rootpnl_display");
	}

	/**
	 * [Beans]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitBeans(FSBBP0020 p) {
		// ブロック関連の初期化
		p.BeansPanel = p.beansFactory.createPanel("Beans");
		// ブロックの項目の初期化
		p.Beans_gui_auto_focus_typ_nm_Label = p.beansFactory.createLabel("Beans.gui_auto_focus_typ_nm_Label");
		p.Beans_gui_auto_focus_typ_nm = p.beansFactory.createTextComboBox("Beans.gui_auto_focus_typ_nm");
		p.Beans_gui_auto_focus_typ_nm.setLabel(p.Beans_gui_auto_focus_typ_nm_Label);
		p.Beans_gui_auto_focus_typ = p.beansFactory.createTextField("Beans.gui_auto_focus_typ");
	}

	/**
	 * [Browser]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitBrowser(FSBBP0020 p) {
		// ブロック関連の初期化
		p.BrowserPanel = p.beansFactory.createPanel("Browser");
		p.BrowserTitledBorder = p.beansFactory.createTitledBorder();
		// ブロックの項目の初期化
		p.Browser_browser_path_Label = p.beansFactory.createLabel("Browser.browser_path_Label");
		p.Browser_browser_path = p.beansFactory.createTextField("Browser.browser_path");
		p.Browser_browser_path.setLabel(p.Browser_browser_path_Label);
		p.Browser_browser_path_FB = p.beansFactory.createButton("Browser.browser_path_FB", "no_border");
	}

	/**
	 * [Browser_comm]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitBrowser_comm(FSBBP0020 p) {
		// ブロック関連の初期化
		p.Browser_commPanel = p.beansFactory.createPanel("Browser_comm");
		p.Browser_commTitledBorder = p.beansFactory.createTitledBorder();
		// ブロックの項目の初期化
		p.Browser_comm_browser_path_Label = p.beansFactory.createLabel("Browser_comm.browser_path_Label");
		p.Browser_comm_browser_path = p.beansFactory.createTextField("Browser_comm.browser_path");
		p.Browser_comm_browser_path.setLabel(p.Browser_comm_browser_path_Label);
		p.Browser_comm_browser_path_FB = p.beansFactory.createButton("Browser_comm.browser_path_FB", "no_border");
	}

	/**
	 * [Psnl]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitPsnl(FSBBP0020 p) {
		// ブロック関連の初期化
		p.PsnlPanel = p.beansFactory.createPanel("Psnl");
		p.PsnlTitledBorder = p.beansFactory.createTitledBorder();
		// ブロックの項目の初期化
		p.Psnl_upd_ext = p.beansFactory.createButton("Psnl.upd_ext");
		p.Psnl_upd_sys = p.beansFactory.createButton("Psnl.upd_sys");
	}

	/**
	 * [Blank]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitBlank(FSBBP0020 p) {
		// ブロック関連の初期化
		p.BlankPanel = p.beansFactory.createPanel("Blank");
		// ブロックの項目の初期化
	}

	/**
	 * [Main]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitMain(FSBBP0020 p) {
		// ブロック関連の初期化
		p.MainPanel.setLayoutPosition("C+");
		// ブロックの項目の初期化
		p.MainPanel.add(p.MenuScreenPanel, null);
		p.MainPanel.setLastBeans(p.MenuScreenPanel);
		p.MenuScreenPanel.setNextBeans(p.ScreenPanel);
		p.MainPanel.add(p.ScreenPanel, null);
		p.ScreenPanel.setNextBeans(p.DialogPanel);
		p.MainPanel.add(p.DialogPanel, null);
		p.DialogPanel.setNextBeans(p.FileIOPanel);
		p.MainPanel.add(p.FileIOPanel, null);
		p.FileIOPanel.setNextBeans(p.BeansPanel);
		p.MainPanel.add(p.BeansPanel, null);
		p.BeansPanel.setNextBeans(p.BrowserPanel);
		p.MainPanel.add(p.BrowserPanel, null);
		p.BrowserPanel.setNextBeans(p.Browser_commPanel);
		p.MainPanel.add(p.Browser_commPanel, null);
		p.Browser_commPanel.setNextBeans(p.PsnlPanel);
		p.MainPanel.add(p.PsnlPanel, null);
		p.PsnlPanel.setNextBeans(p.BlankPanel);
		p.MainPanel.add(p.BlankPanel, null);
	}

	/**
	 * [MenuScreen]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitMenuScreen(FSBBP0020 p) {
		// ブロック関連の初期化
		p.MenuScreenPanel.setBorder(p.MenuScreenTitledBorder);
		p.MenuScreenPanel.setLayoutPosition("N");
		// ブロックの項目の初期化
		p.MenuScreen_initTabName.setListType(MCListType.STRICT);
		p.MenuScreen_initTabName.setLinkBeans(p.MenuScreen_initTabPath);
		p.MenuScreenPanel.add(p.MenuScreen_initTabName_Label);
		p.MenuScreenPanel.add(p.MenuScreen_initTabName);
		p.MenuScreenPanel.setLastBeans(p.MenuScreen_initTabName);
		p.MenuScreen_initTabName.setNextBeans(p.MenuScreen_initTabPath);
		p.MenuScreen_initTabName.setRow(p.getMenuScreenR(), mcframe.clientFSBB.FSBBP0020.MenuScreenR.initTabName_META);
		p.MenuScreenPanel.add(p.MenuScreen_initTabPath_Label);
		p.MenuScreenPanel.add(p.MenuScreen_initTabPath);
		p.MenuScreen_initTabPath.setRow(p.getMenuScreenR(), mcframe.clientFSBB.FSBBP0020.MenuScreenR.initTabPath_META);
	}

	/**
	 * [Screen]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitScreen(FSBBP0020 p) {
		// ブロック関連の初期化
		p.ScreenPanel.setBorder(p.ScreenTitledBorder);
		p.ScreenPanel.setLayoutPosition("N");
		// ブロックの項目の初期化
		p.ScreenPanel.add(p.Screen_initScreenLabel);
		p.Screen_initModuleID.setListType(MCListType.STRICT);
		p.ScreenPanel.add(p.Screen_initModuleID);
		p.ScreenPanel.setLastBeans(p.Screen_initModuleID);
		p.Screen_initModuleID.setNextBeans(p.Screen_initScreenID);
		p.Screen_initModuleID.setRow(p.getScreenR(), mcframe.clientFSBB.FSBBP0020.ScreenR.initModuleID_META);
		p.ScreenPanel.add(p.Screen_initScreenID);
		p.Screen_initScreenID.setNextBeans(p.Screen_initScreenName);
		p.Screen_initScreenID.setRow(p.getScreenR(), mcframe.clientFSBB.FSBBP0020.ScreenR.initScreenID_META);
		p.Screen_initScreenID.addLinkBeans(p.Screen_initScreenName,p.Screen_initScreenModuleID);
		p.Screen_initScreenID.setListType(MCListType.STRICT);
		p.ScreenPanel.add(p.Screen_initScreenName);
		p.Screen_initScreenName.setNextBeans(p.Screen_initScreenModuleID);
		p.Screen_initScreenName.setRow(p.getScreenR(), mcframe.clientFSBB.FSBBP0020.ScreenR.initScreenName_META);
		p.ScreenPanel.add(p.Screen_initScreenModuleID);
		p.Screen_initScreenModuleID.setNextBeans(p.Screen_initScreenMode);
		p.Screen_initScreenModuleID.setRow(p.getScreenR(), mcframe.clientFSBB.FSBBP0020.ScreenR.initScreenModuleID_META);
		p.ScreenPanel.add(p.Screen_initScreenMode);
		p.Screen_initScreenMode.setNextBeans(p.Beans_gui_auto_focus_typ_nm);
		p.Screen_initScreenMode.setRow(p.getScreenR(), mcframe.clientFSBB.FSBBP0020.ScreenR.initScreenMode_META);
	}

	/**
	 * [Dialog]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitDialog(FSBBP0020 p) {
		// ブロック関連の初期化
		p.DialogPanel.setBorder(p.DialogTitledBorder);
		p.DialogPanel.setLayoutPosition("N");
		// ブロックの項目の初期化
		p.DialogPanel.add(p.Dialog_prog_delay_millis_Label);
		p.DialogPanel.add(p.Dialog_prog_delay_millis);
		p.DialogPanel.setLastBeans(p.Dialog_prog_delay_millis);
		p.Dialog_prog_delay_millis.setRow(p.getDialogR(), mcframe.clientFSBB.FSBBP0020.DialogR.prog_delay_millis_META);
	}

	/**
	 * [FileIO]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitFileIO(FSBBP0020 p) {
		// ブロック関連の初期化
		p.FileIOPanel.setBorder(p.FileIOTitledBorder);
		p.FileIOPanel.setLayoutPosition("N");
		// ブロックの項目の初期化
		p.FileIOPanel.add(p.FileIO_init_dir_Label);
		p.FileIOPanel.add(p.FileIO_init_dir);
		p.FileIOPanel.setLastBeans(p.FileIO_init_dir);
		p.FileIO_init_dir.setNextBeans(p.FileIO_init_dir_FB);
		p.FileIO_init_dir.setRow(p.getFileIOR(), mcframe.clientFSBB.FSBBP0020.FileIOR.init_dir_META);
		p.FileIO_init_dir_FB.setIcon("FOLDER");
		p.FileIO_init_dir_FB.setFunctionKey(MCFunctionKey.F17);
		p.FileIOPanel.add(p.FileIO_init_dir_FB);
		p.FileIO_init_dir_FB.setNextBeans(p.FileIO_tbl_display);
		p.FileIOPanel.add(p.FileIO_display_lab);
		p.FileIOPanel.add(p.FileIO_tbl_display);
		p.FileIO_tbl_display.setNextBeans(p.FileIO_rootpnl_display);
		p.FileIO_tbl_display.setRow(p.getFileIOR(), mcframe.clientFSBB.FSBBP0020.FileIOR.tbl_display_META);
		p.FileIOPanel.add(p.FileIO_rootpnl_display);
		p.FileIO_rootpnl_display.setRow(p.getFileIOR(), mcframe.clientFSBB.FSBBP0020.FileIOR.rootpnl_display_META);
	}

	/**
	 * [Beans]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitBeans(FSBBP0020 p) {
		// ブロック関連の初期化
		p.BeansPanel.setLayoutPosition("N");
		// ブロックの項目の初期化
		p.Beans_gui_auto_focus_typ_nm.setListType(MCListType.STRICT);
		p.Beans_gui_auto_focus_typ_nm.setLinkBeans(p.Beans_gui_auto_focus_typ);
		p.ScreenPanel.add(p.Beans_gui_auto_focus_typ_nm_Label);
		p.ScreenPanel.add(p.Beans_gui_auto_focus_typ_nm);
		p.Beans_gui_auto_focus_typ_nm.setRow(p.getBeansR(), mcframe.clientFSBB.FSBBP0020.BeansR.gui_auto_focus_typ_nm_META);
		p.BeansPanel.add(p.Beans_gui_auto_focus_typ);
		p.BeansPanel.setLastBeans(p.Beans_gui_auto_focus_typ);
		p.Beans_gui_auto_focus_typ.setRow(p.getBeansR(), mcframe.clientFSBB.FSBBP0020.BeansR.gui_auto_focus_typ_META);
	}

	/**
	 * [Browser]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitBrowser(FSBBP0020 p) {
		// ブロック関連の初期化
		p.BrowserPanel.setBorder(p.BrowserTitledBorder);
		p.BrowserPanel.setLayoutPosition("N");
		// ブロックの項目の初期化
		p.BrowserPanel.add(p.Browser_browser_path_Label);
		p.BrowserPanel.add(p.Browser_browser_path);
		p.BrowserPanel.setLastBeans(p.Browser_browser_path);
		p.Browser_browser_path.setNextBeans(p.Browser_browser_path_FB);
		p.Browser_browser_path.setRow(p.getBrowserR(), mcframe.clientFSBB.FSBBP0020.BrowserR.browser_path_META);
		p.Browser_browser_path_FB.setIcon("FOLDER");
		p.Browser_browser_path_FB.setFunctionKey(MCFunctionKey.F18);
		p.BrowserPanel.add(p.Browser_browser_path_FB);
	}

	/**
	 * [Browser_comm]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitBrowser_comm(FSBBP0020 p) {
		// ブロック関連の初期化
		p.Browser_commPanel.setBorder(p.Browser_commTitledBorder);
		p.Browser_commPanel.setLayoutPosition("N");
		// ブロックの項目の初期化
		p.Browser_commPanel.add(p.Browser_comm_browser_path_Label);
		p.Browser_commPanel.add(p.Browser_comm_browser_path);
		p.Browser_commPanel.setLastBeans(p.Browser_comm_browser_path);
		p.Browser_comm_browser_path.setNextBeans(p.Browser_comm_browser_path_FB);
		p.Browser_comm_browser_path.setRow(p.getBrowser_commR(), mcframe.clientFSBB.FSBBP0020.Browser_commR.browser_path_META);
		p.Browser_comm_browser_path_FB.setIcon("FOLDER");
		p.Browser_comm_browser_path_FB.setFunctionKey(MCFunctionKey.F21);
		p.Browser_commPanel.add(p.Browser_comm_browser_path_FB);
	}

	/**
	 * [Psnl]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitPsnl(FSBBP0020 p) {
		// ブロック関連の初期化
		p.PsnlPanel.setBorder(p.PsnlTitledBorder);
		p.PsnlPanel.setLayoutPosition("N");
		// ブロックの項目の初期化
		p.PsnlPanel.add(p.Psnl_setting_PPanel);
		p.PsnlPanel.setLastBeans(p.Psnl_setting_PPanel);
		p.Psnl_setting_PPanel.setNextBeans(p.Psnl_upd_ext);
		p.PsnlPanel.add(p.Psnl_upd_ext);
		p.Psnl_upd_ext.setNextBeans(p.Psnl_upd_sys);
		p.PsnlPanel.add(p.Psnl_upd_sys);
		p.Psnl_upd_sys.setNextBeans(p.Psnl_psnl_PPanel);
		p.PsnlPanel.add(p.Psnl_psnl_PPanel);
	}

	/**
	 * [Blank]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitBlank(FSBBP0020 p) {
		// ブロック関連の初期化
		p.BlankPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "S";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBBP0020_FW.mcInitMain((FSBBP0020)this);
		FSBBP0020_FW.mcInitMenuScreen((FSBBP0020)this);
		FSBBP0020_FW.mcInitScreen((FSBBP0020)this);
		FSBBP0020_FW.mcInitDialog((FSBBP0020)this);
		FSBBP0020_FW.mcInitFileIO((FSBBP0020)this);
		FSBBP0020_FW.mcInitBeans((FSBBP0020)this);
		FSBBP0020_FW.mcInitBrowser((FSBBP0020)this);
		FSBBP0020_FW.mcInitBrowser_comm((FSBBP0020)this);
		FSBBP0020_FW.mcInitPsnl((FSBBP0020)this);
		FSBBP0020_FW.mcInitBlank((FSBBP0020)this);

		// [INIT]ステータスのモードの設定
		FSBBP0020_FW.statusInitINIT_Main((FSBBP0020)this);
		FSBBP0020_FW.statusInitINIT_MenuScreen((FSBBP0020)this);
		FSBBP0020_FW.statusInitINIT_Screen((FSBBP0020)this);
		FSBBP0020_FW.statusInitINIT_Dialog((FSBBP0020)this);
		FSBBP0020_FW.statusInitINIT_FileIO((FSBBP0020)this);
		FSBBP0020_FW.statusInitINIT_Beans((FSBBP0020)this);
		FSBBP0020_FW.statusInitINIT_Browser((FSBBP0020)this);
		FSBBP0020_FW.statusInitINIT_Browser__comm((FSBBP0020)this);
		FSBBP0020_FW.statusInitINIT_Psnl((FSBBP0020)this);
		FSBBP0020_FW.statusInitINIT_Blank((FSBBP0020)this);

	}

	/**
	 *  [Main]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitMain(FSBBP0020 p) {
	}

	/**
	 *  [MenuScreen]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitMenuScreen(FSBBP0020 p) {
		p.MenuScreen_initTabName.setListListener(p);
		p.MenuScreen_initTabName.addAllListener(p);
		p.MenuScreen_initTabPath.setListListener(p);
		p.MenuScreen_initTabPath.addAllListener(p);
	}

	/**
	 *  [Screen]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitScreen(FSBBP0020 p) {
		p.Screen_initModuleID.setListListener(p);
		p.Screen_initModuleID.addAllListener(p);
		p.Screen_initScreenID.setListListener(p);
		p.Screen_initScreenID.addAllListener(p);
		p.Screen_initScreenName.setListListener(p);
		p.Screen_initScreenName.addAllListener(p);
		p.Screen_initScreenModuleID.setListListener(p);
		p.Screen_initScreenModuleID.addAllListener(p);
		p.Screen_initScreenMode.setListListener(p);
		p.Screen_initScreenMode.addAllListener(p);
	}

	/**
	 *  [Dialog]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitDialog(FSBBP0020 p) {
		p.Dialog_prog_delay_millis.setListListener(p);
		p.Dialog_prog_delay_millis.addAllListener(p);
	}

	/**
	 *  [FileIO]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitFileIO(FSBBP0020 p) {
		p.FileIO_init_dir.setListListener(p);
		p.FileIO_init_dir.addAllListener(p);
		p.FileIO_init_dir_FB.addAllListener(p);
		p.FileIO_init_dir_FB.setAPMethodName("doFileIO_init_dir_FB");
		p.FileIO_tbl_display.addAllListener(p);
		p.FileIO_rootpnl_display.addAllListener(p);
	}

	/**
	 *  [Beans]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitBeans(FSBBP0020 p) {
		p.Beans_gui_auto_focus_typ_nm.setListListener(p);
		p.Beans_gui_auto_focus_typ_nm.addAllListener(p);
		p.Beans_gui_auto_focus_typ.setListListener(p);
		p.Beans_gui_auto_focus_typ.addAllListener(p);
	}

	/**
	 *  [Browser]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitBrowser(FSBBP0020 p) {
		p.Browser_browser_path.setListListener(p);
		p.Browser_browser_path.addAllListener(p);
		p.Browser_browser_path_FB.addAllListener(p);
		p.Browser_browser_path_FB.setAPMethodName("doBrowser_browser_path_FB");
	}

	/**
	 *  [Browser_comm]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitBrowser_comm(FSBBP0020 p) {
		p.Browser_comm_browser_path.setListListener(p);
		p.Browser_comm_browser_path.addAllListener(p);
		p.Browser_comm_browser_path_FB.addAllListener(p);
		p.Browser_comm_browser_path_FB.setAPMethodName("doBrowser_comm_browser_path_FB");
	}

	/**
	 *  [Psnl]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitPsnl(FSBBP0020 p) {
		p.Psnl_upd_ext.addAllListener(p);
		p.Psnl_upd_ext.setAPMethodName("doPsnl_upd_ext");
		p.Psnl_upd_sys.addAllListener(p);
		p.Psnl_upd_sys.setAPMethodName("doPsnl_upd_sys");
	}

	/**
	 *  [Blank]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitBlank(FSBBP0020 p) {
	}

	/**
	 * [INIT]ステータスの[Main]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Main(FSBBP0020 p){

	}

	/**
	 * [INIT]ステータスの[MenuScreen]ブロックのモードの設定
	 */
	protected static void statusInitINIT_MenuScreen(FSBBP0020 p){
		p.MenuScreen_initTabName.putMode(p, INIT, MCMode.ENABLE);
		p.MenuScreen_initTabPath.putMode(p, INIT, MCMode.INVISIBLE);

	}

	/**
	 * [INIT]ステータスの[Screen]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Screen(FSBBP0020 p){
		p.Screen_initModuleID.putMode(p, INIT, MCMode.ENABLE);
		p.Screen_initScreenID.putMode(p, INIT, MCMode.ENABLE);
		p.Screen_initScreenName.putMode(p, INIT, MCMode.READ_ONLY);
		p.Screen_initScreenModuleID.putMode(p, INIT, MCMode.INVISIBLE);
		p.Screen_initScreenMode.putMode(p, INIT, MCMode.INVISIBLE);

	}

	/**
	 * [INIT]ステータスの[Dialog]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Dialog(FSBBP0020 p){
		p.Dialog_prog_delay_millis.putMode(p, INIT, MCMode.REQUIRED);

	}

	/**
	 * [INIT]ステータスの[FileIO]ブロックのモードの設定
	 */
	protected static void statusInitINIT_FileIO(FSBBP0020 p){
		p.FileIO_init_dir_FB.putMode(p, INIT, MCMode.ENABLE);
		p.FileIO_display_lab.putMode(p, INIT, MCMode.ENABLE);
		p.FileIO_tbl_display.putMode(p, INIT, MCMode.REQUIRED);
		p.FileIO_rootpnl_display.putMode(p, INIT, MCMode.REQUIRED);

	}

	/**
	 * [INIT]ステータスの[Beans]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Beans(FSBBP0020 p){
		p.Beans_gui_auto_focus_typ_nm.putMode(p, INIT, MCMode.ENABLE);
		p.Beans_gui_auto_focus_typ.putMode(p, INIT, MCMode.INVISIBLE);

	}

	/**
	 * [INIT]ステータスの[Browser]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Browser(FSBBP0020 p){
		p.Browser_browser_path.putMode(p, INIT, MCMode.ENABLE);
		p.Browser_browser_path_FB.putMode(p, INIT, MCMode.ENABLE);

	}

	/**
	 * [INIT]ステータスの[Browser_comm]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Browser__comm(FSBBP0020 p){
		p.Browser_comm_browser_path.putMode(p, INIT, MCMode.ENABLE);
		p.Browser_comm_browser_path_FB.putMode(p, INIT, MCMode.ENABLE);

	}

	/**
	 * [INIT]ステータスの[Psnl]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Psnl(FSBBP0020 p){
		p.Psnl_setting_PPanel.putStatus(INIT, mcframe.clientFSUB.FSUBP0090.FSUBP_SettingUnit_H.REQUIRED);
		p.Psnl_upd_ext.putMode(p, INIT, MCMode.INVISIBLE);
		p.Psnl_upd_sys.putMode(p, INIT, MCMode.INVISIBLE);
		p.Psnl_psnl_PPanel.putStatus(INIT, mcframe.clientFSBB.FSBBP0060.FSBBP_PsnlIO.ENABLE);

	}

	/**
	 * [INIT]ステータスの[Blank]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Blank(FSBBP0020 p){

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return INIT;
	}

	/**
	 * Table/Treeの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
		MenuScreen_initTabName.setListVisibleColumn(MCListLogic.getViewColumnName());
		MenuScreen_initTabName.getListConfig().setPutter(getMenuScreen_initTabName_ListPutter());
		Screen_initModuleID.setListVisibleColumn(MCListLogic.getViewColumnName());
		Screen_initModuleID.getListConfig().setPutter(getScreen_initModuleID_ListPutter());
		Screen_initScreenID.getListConfig().setPutter(getScreen_initScreenID_ListPutter());
		Beans_gui_auto_focus_typ_nm.setListVisibleColumn(MCListLogic.getViewColumnName());
		Beans_gui_auto_focus_typ_nm.getListConfig().setPutter(getBeans_gui_auto_focus_typ_nm_ListPutter());
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
	}

	/**
	 * [MenuScreen_initTabName_ListPutter]の作成
	 */
	protected MCListPutter createMenuScreen_initTabName_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("FS.FSUAP0010.MenuTab");
		return lp;
	}
	 
	/**
	 * [Screen_initModuleID_ListPutter]の作成
	 */
	protected MCListPutter createScreen_initModuleID_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("FS.FSUAP0010.UserModuleID");
		return lp;
	}
	 
	/**
	 * [Screen_initScreenID_ListPutter]の作成
	 */
	protected MCListPutter createScreen_initScreenID_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("");
		return lp;
	}
	 
	/**
	 * [Beans_gui_auto_focus_typ_nm_ListPutter]の作成
	 */
	protected MCListPutter createBeans_gui_auto_focus_typ_nm_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("FS.FSUAP0010.GUIAutoFocusTyp");
		return lp;
	}
	 

	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		if(combo == MenuScreen_initTabName) return getMenuScreen_initTabName(row, info);
		if(combo == Screen_initModuleID) return getScreen_initModuleID(row, info);
		if(combo == Screen_initScreenID) return getScreen_initScreenID(row, info);
		if(combo == Beans_gui_auto_focus_typ_nm) return getBeans_gui_auto_focus_typ_nm(row, info);
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == FileIO_init_dir_FB) doFileIO_init_dir_FB(info);
		else if (ap == Browser_browser_path_FB) doBrowser_browser_path_FB(info);
		else if (ap == Browser_comm_browser_path_FB) doBrowser_comm_browser_path_FB(info);
		else if (ap == Psnl_upd_ext) doPsnl_upd_ext(info);
		else if (ap == Psnl_upd_sys) doPsnl_upd_sys(info);
	}

	/**
	 * [FileIO]パネルの[init_dir_FB]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doFileIO_init_dir_FB(MCEventInfo info);

	/**
	 * [Browser]パネルの[browser_path_FB]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBrowser_browser_path_FB(MCEventInfo info);

	/**
	 * [Browser_comm]パネルの[browser_path_FB]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBrowser_comm_browser_path_FB(MCEventInfo info);

	/**
	 * [Psnl]パネルの[upd_ext]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doPsnl_upd_ext(MCEventInfo info);

	/**
	 * [Psnl]パネルの[upd_sys]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doPsnl_upd_sys(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == MenuScreen_initTabName) return doMenuScreen_initTabName_VC(info);
		if (vc == MenuScreen_initTabPath) return doMenuScreen_initTabPath_VC(info);
		if (vc == Screen_initModuleID) return doScreen_initModuleID_VC(info);
		if (vc == Screen_initScreenID) return doScreen_initScreenID_VC(info);
		if (vc == Screen_initScreenName) return doScreen_initScreenName_VC(info);
		if (vc == Screen_initScreenModuleID) return doScreen_initScreenModuleID_VC(info);
		if (vc == Screen_initScreenMode) return doScreen_initScreenMode_VC(info);
		if (vc == Dialog_prog_delay_millis) return doDialog_prog_delay_millis_VC(info);
		if (vc == FileIO_init_dir) return doFileIO_init_dir_VC(info);
		if (vc == FileIO_tbl_display) return doFileIO_tbl_display_VC(info);
		if (vc == FileIO_rootpnl_display) return doFileIO_rootpnl_display_VC(info);
		if (vc == Beans_gui_auto_focus_typ_nm) return doBeans_gui_auto_focus_typ_nm_VC(info);
		if (vc == Beans_gui_auto_focus_typ) return doBeans_gui_auto_focus_typ_VC(info);
		if (vc == Browser_browser_path) return doBrowser_browser_path_VC(info);
		if (vc == Browser_comm_browser_path) return doBrowser_comm_browser_path_VC(info);
		return true;
	}

	/**
	 * [MenuScreen]パネルの[initTabName]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMenuScreen_initTabName_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [MenuScreen]パネルの[initTabPath]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMenuScreen_initTabPath_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Screen]パネルの[initModuleID]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doScreen_initModuleID_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Screen]パネルの[initScreenID]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doScreen_initScreenID_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Screen]パネルの[initScreenName]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doScreen_initScreenName_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Screen]パネルの[initScreenModuleID]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doScreen_initScreenModuleID_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Screen]パネルの[initScreenMode]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doScreen_initScreenMode_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Dialog]パネルの[prog_delay_millis]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDialog_prog_delay_millis_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [FileIO]パネルの[init_dir]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doFileIO_init_dir_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [FileIO]パネルの[tbl_display]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doFileIO_tbl_display_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [FileIO]パネルの[rootpnl_display]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doFileIO_rootpnl_display_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Beans]パネルの[gui_auto_focus_typ_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doBeans_gui_auto_focus_typ_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Beans]パネルの[gui_auto_focus_typ]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doBeans_gui_auto_focus_typ_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Browser]パネルの[browser_path]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doBrowser_browser_path_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Browser_comm]パネルの[browser_path]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doBrowser_comm_browser_path_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == MenuScreen_initTabName) doMenuScreen_initTabName_NC(info);
		else if (nc == MenuScreen_initTabPath) doMenuScreen_initTabPath_NC(info);
		else if (nc == Screen_initModuleID) doScreen_initModuleID_NC(info);
		else if (nc == Screen_initScreenID) doScreen_initScreenID_NC(info);
		else if (nc == Screen_initScreenName) doScreen_initScreenName_NC(info);
		else if (nc == Screen_initScreenModuleID) doScreen_initScreenModuleID_NC(info);
		else if (nc == Screen_initScreenMode) doScreen_initScreenMode_NC(info);
		else if (nc == Dialog_prog_delay_millis) doDialog_prog_delay_millis_NC(info);
		else if (nc == FileIO_init_dir) doFileIO_init_dir_NC(info);
		else if (nc == FileIO_tbl_display) doFileIO_tbl_display_NC(info);
		else if (nc == FileIO_rootpnl_display) doFileIO_rootpnl_display_NC(info);
		else if (nc == Beans_gui_auto_focus_typ_nm) doBeans_gui_auto_focus_typ_nm_NC(info);
		else if (nc == Beans_gui_auto_focus_typ) doBeans_gui_auto_focus_typ_NC(info);
		else if (nc == Browser_browser_path) doBrowser_browser_path_NC(info);
		else if (nc == Browser_comm_browser_path) doBrowser_comm_browser_path_NC(info);
	}

	/**
	 * [MenuScreen]パネルの[initTabName]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMenuScreen_initTabName_NC(MCEventInfo info){
	}

	/**
	 * [MenuScreen]パネルの[initTabPath]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMenuScreen_initTabPath_NC(MCEventInfo info){
	}

	/**
	 * [Screen]パネルの[initModuleID]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_initModuleID_NC(MCEventInfo info){
	}

	/**
	 * [Screen]パネルの[initScreenID]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_initScreenID_NC(MCEventInfo info){
	}

	/**
	 * [Screen]パネルの[initScreenName]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_initScreenName_NC(MCEventInfo info){
	}

	/**
	 * [Screen]パネルの[initScreenModuleID]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_initScreenModuleID_NC(MCEventInfo info){
	}

	/**
	 * [Screen]パネルの[initScreenMode]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_initScreenMode_NC(MCEventInfo info){
	}

	/**
	 * [Dialog]パネルの[prog_delay_millis]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDialog_prog_delay_millis_NC(MCEventInfo info){
	}

	/**
	 * [FileIO]パネルの[init_dir]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doFileIO_init_dir_NC(MCEventInfo info){
	}

	/**
	 * [FileIO]パネルの[tbl_display]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doFileIO_tbl_display_NC(MCEventInfo info){
	}

	/**
	 * [FileIO]パネルの[rootpnl_display]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doFileIO_rootpnl_display_NC(MCEventInfo info){
	}

	/**
	 * [Beans]パネルの[gui_auto_focus_typ_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBeans_gui_auto_focus_typ_nm_NC(MCEventInfo info){
	}

	/**
	 * [Beans]パネルの[gui_auto_focus_typ]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBeans_gui_auto_focus_typ_NC(MCEventInfo info){
	}

	/**
	 * [Browser]パネルの[browser_path]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBrowser_browser_path_NC(MCEventInfo info){
	}

	/**
	 * [Browser_comm]パネルの[browser_path]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBrowser_comm_browser_path_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == MenuScreen_initTabName) doMenuScreen_initTabName_NE(info);
		else if (ne == MenuScreen_initTabPath) doMenuScreen_initTabPath_NE(info);
		else if (ne == Screen_initModuleID) doScreen_initModuleID_NE(info);
		else if (ne == Screen_initScreenID) doScreen_initScreenID_NE(info);
		else if (ne == Screen_initScreenName) doScreen_initScreenName_NE(info);
		else if (ne == Screen_initScreenModuleID) doScreen_initScreenModuleID_NE(info);
		else if (ne == Screen_initScreenMode) doScreen_initScreenMode_NE(info);
		else if (ne == Dialog_prog_delay_millis) doDialog_prog_delay_millis_NE(info);
		else if (ne == FileIO_init_dir) doFileIO_init_dir_NE(info);
		else if (ne == FileIO_tbl_display) doFileIO_tbl_display_NE(info);
		else if (ne == FileIO_rootpnl_display) doFileIO_rootpnl_display_NE(info);
		else if (ne == Beans_gui_auto_focus_typ_nm) doBeans_gui_auto_focus_typ_nm_NE(info);
		else if (ne == Beans_gui_auto_focus_typ) doBeans_gui_auto_focus_typ_NE(info);
		else if (ne == Browser_browser_path) doBrowser_browser_path_NE(info);
		else if (ne == Browser_comm_browser_path) doBrowser_comm_browser_path_NE(info);
	}

	/**
	 * [MenuScreen]パネルの[initTabName]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMenuScreen_initTabName_NE(MCEventInfo info){
	}

	/**
	 * [MenuScreen]パネルの[initTabPath]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMenuScreen_initTabPath_NE(MCEventInfo info){
	}

	/**
	 * [Screen]パネルの[initModuleID]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_initModuleID_NE(MCEventInfo info){
	}

	/**
	 * [Screen]パネルの[initScreenID]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_initScreenID_NE(MCEventInfo info){
	}

	/**
	 * [Screen]パネルの[initScreenName]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_initScreenName_NE(MCEventInfo info){
	}

	/**
	 * [Screen]パネルの[initScreenModuleID]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_initScreenModuleID_NE(MCEventInfo info){
	}

	/**
	 * [Screen]パネルの[initScreenMode]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_initScreenMode_NE(MCEventInfo info){
	}

	/**
	 * [Dialog]パネルの[prog_delay_millis]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDialog_prog_delay_millis_NE(MCEventInfo info){
	}

	/**
	 * [FileIO]パネルの[init_dir]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doFileIO_init_dir_NE(MCEventInfo info){
	}

	/**
	 * [FileIO]パネルの[tbl_display]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doFileIO_tbl_display_NE(MCEventInfo info){
	}

	/**
	 * [FileIO]パネルの[rootpnl_display]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doFileIO_rootpnl_display_NE(MCEventInfo info){
	}

	/**
	 * [Beans]パネルの[gui_auto_focus_typ_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBeans_gui_auto_focus_typ_nm_NE(MCEventInfo info){
	}

	/**
	 * [Beans]パネルの[gui_auto_focus_typ]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBeans_gui_auto_focus_typ_NE(MCEventInfo info){
	}

	/**
	 * [Browser]パネルの[browser_path]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBrowser_browser_path_NE(MCEventInfo info){
	}

	/**
	 * [Browser_comm]パネルの[browser_path]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBrowser_comm_browser_path_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == MenuScreen_initTabName) doMenuScreen_initTabName_NX(info);
		else if (nx == MenuScreen_initTabPath) doMenuScreen_initTabPath_NX(info);
		else if (nx == Screen_initModuleID) doScreen_initModuleID_NX(info);
		else if (nx == Screen_initScreenID) doScreen_initScreenID_NX(info);
		else if (nx == Screen_initScreenName) doScreen_initScreenName_NX(info);
		else if (nx == Screen_initScreenModuleID) doScreen_initScreenModuleID_NX(info);
		else if (nx == Screen_initScreenMode) doScreen_initScreenMode_NX(info);
		else if (nx == Dialog_prog_delay_millis) doDialog_prog_delay_millis_NX(info);
		else if (nx == FileIO_init_dir) doFileIO_init_dir_NX(info);
		else if (nx == FileIO_tbl_display) doFileIO_tbl_display_NX(info);
		else if (nx == FileIO_rootpnl_display) doFileIO_rootpnl_display_NX(info);
		else if (nx == Beans_gui_auto_focus_typ_nm) doBeans_gui_auto_focus_typ_nm_NX(info);
		else if (nx == Beans_gui_auto_focus_typ) doBeans_gui_auto_focus_typ_NX(info);
		else if (nx == Browser_browser_path) doBrowser_browser_path_NX(info);
		else if (nx == Browser_comm_browser_path) doBrowser_comm_browser_path_NX(info);
	}

	/**
	 * [MenuScreen]パネルの[initTabName]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMenuScreen_initTabName_NX(MCEventInfo info){
	}

	/**
	 * [MenuScreen]パネルの[initTabPath]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMenuScreen_initTabPath_NX(MCEventInfo info){
	}

	/**
	 * [Screen]パネルの[initModuleID]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_initModuleID_NX(MCEventInfo info){
	}

	/**
	 * [Screen]パネルの[initScreenID]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_initScreenID_NX(MCEventInfo info){
	}

	/**
	 * [Screen]パネルの[initScreenName]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_initScreenName_NX(MCEventInfo info){
	}

	/**
	 * [Screen]パネルの[initScreenModuleID]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_initScreenModuleID_NX(MCEventInfo info){
	}

	/**
	 * [Screen]パネルの[initScreenMode]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_initScreenMode_NX(MCEventInfo info){
	}

	/**
	 * [Dialog]パネルの[prog_delay_millis]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDialog_prog_delay_millis_NX(MCEventInfo info){
	}

	/**
	 * [FileIO]パネルの[init_dir]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doFileIO_init_dir_NX(MCEventInfo info){
	}

	/**
	 * [FileIO]パネルの[tbl_display]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doFileIO_tbl_display_NX(MCEventInfo info){
	}

	/**
	 * [FileIO]パネルの[rootpnl_display]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doFileIO_rootpnl_display_NX(MCEventInfo info){
	}

	/**
	 * [Beans]パネルの[gui_auto_focus_typ_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBeans_gui_auto_focus_typ_nm_NX(MCEventInfo info){
	}

	/**
	 * [Beans]パネルの[gui_auto_focus_typ]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBeans_gui_auto_focus_typ_NX(MCEventInfo info){
	}

	/**
	 * [Browser]パネルの[browser_path]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBrowser_browser_path_NX(MCEventInfo info){
	}

	/**
	 * [Browser_comm]パネルの[browser_path]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBrowser_comm_browser_path_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == MenuScreen_initTabName) doMenuScreen_initTabName_LC(info);
		else if (lc == MenuScreen_initTabPath) doMenuScreen_initTabPath_LC(info);
		else if (lc == Screen_initModuleID) doScreen_initModuleID_LC(info);
		else if (lc == Screen_initScreenID) doScreen_initScreenID_LC(info);
		else if (lc == Screen_initScreenName) doScreen_initScreenName_LC(info);
		else if (lc == Screen_initScreenModuleID) doScreen_initScreenModuleID_LC(info);
		else if (lc == Screen_initScreenMode) doScreen_initScreenMode_LC(info);
		else if (lc == Dialog_prog_delay_millis) doDialog_prog_delay_millis_LC(info);
		else if (lc == FileIO_init_dir) doFileIO_init_dir_LC(info);
		else if (lc == Beans_gui_auto_focus_typ_nm) doBeans_gui_auto_focus_typ_nm_LC(info);
		else if (lc == Beans_gui_auto_focus_typ) doBeans_gui_auto_focus_typ_LC(info);
		else if (lc == Browser_browser_path) doBrowser_browser_path_LC(info);
		else if (lc == Browser_comm_browser_path) doBrowser_comm_browser_path_LC(info);
	}

	/**
	 * [MenuScreen]パネルの[initTabName]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMenuScreen_initTabName_LC(MCEventInfo info){
	}

	/**
	 * [MenuScreen]パネルの[initTabPath]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMenuScreen_initTabPath_LC(MCEventInfo info){
	}

	/**
	 * [Screen]パネルの[initModuleID]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_initModuleID_LC(MCEventInfo info){
	}

	/**
	 * [Screen]パネルの[initScreenID]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_initScreenID_LC(MCEventInfo info){
	}

	/**
	 * [Screen]パネルの[initScreenName]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_initScreenName_LC(MCEventInfo info){
	}

	/**
	 * [Screen]パネルの[initScreenModuleID]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_initScreenModuleID_LC(MCEventInfo info){
	}

	/**
	 * [Screen]パネルの[initScreenMode]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doScreen_initScreenMode_LC(MCEventInfo info){
	}

	/**
	 * [Dialog]パネルの[prog_delay_millis]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDialog_prog_delay_millis_LC(MCEventInfo info){
	}

	/**
	 * [FileIO]パネルの[init_dir]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doFileIO_init_dir_LC(MCEventInfo info){
	}

	/**
	 * [Beans]パネルの[gui_auto_focus_typ_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBeans_gui_auto_focus_typ_nm_LC(MCEventInfo info){
	}

	/**
	 * [Beans]パネルの[gui_auto_focus_typ]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBeans_gui_auto_focus_typ_LC(MCEventInfo info){
	}

	/**
	 * [Browser]パネルの[browser_path]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBrowser_browser_path_LC(MCEventInfo info){
	}

	/**
	 * [Browser_comm]パネルの[browser_path]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBrowser_comm_browser_path_LC(MCEventInfo info){
	}

	/**
	 * コンボ／リストのリスト[MenuScreen_initTabName]の作成メソッド
	 */
	public MCList getMenuScreen_initTabName(MCRow row, MCEventInfo info){
		return ((mcframe.clientFSUA.FSUAP0010.FSUAP_List)MCListLogic.create("mcframe.clientFSUA.FSUAP0010.FSUAP_List", this)).getMenuTab(row, info);
	}

	/**
	 * コンボ／リストのリスト[Screen_initModuleID]の作成メソッド
	 */
	public MCList getScreen_initModuleID(MCRow row, MCEventInfo info){
		return ((mcframe.clientFSUA.FSUAP0010.FSUAP_List)MCListLogic.create("mcframe.clientFSUA.FSUAP0010.FSUAP_List", this)).getUserModuleID(row, info);
	}

	/**
	 * コンボ／リストのリスト[Screen_initScreenID]の作成メソッド
	 */
	public MCList getScreen_initScreenID(MCRow row, MCEventInfo info){
		return null;
	}

	/**
	 * コンボ／リストのリスト[Beans_gui_auto_focus_typ_nm]の作成メソッド
	 */
	public MCList getBeans_gui_auto_focus_typ_nm(MCRow row, MCEventInfo info){
		return ((mcframe.clientFSUA.FSUAP0010.FSUAP_List)MCListLogic.create("mcframe.clientFSUA.FSUAP0010.FSUAP_List", this)).getGUIAutoFocusTyp(row, info);
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}