package mcframe.clientFSBB.FSBBP0020;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Beans"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class BeansR_FW_A extends MCConstRow {

	/**
	 *  最大文字数入力時のフォーカス移動.<p>
	 *
	 */
	public static final String $gui_auto_focus_typ_nm = "gui_auto_focus_typ_nm";
	public static final String $gui_auto_focus_typ = "gui_auto_focus_typ";


	public static final MCMeta gui_auto_focus_typ_nm_META = createStringMeta($gui_auto_focus_typ_nm);
	public static final MCMeta gui_auto_focus_typ_META = createStringMeta($gui_auto_focus_typ);

	protected static final ConstMetaList<BeansR> constMetas = new ConstMetaList<BeansR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			gui_auto_focus_typ_nm_META,
			gui_auto_focus_typ_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected BeansR_FW_A(ConstMetaList<? extends BeansR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public BeansR clone() {
		return (BeansR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public BeansR createInstance() {
		return (BeansR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public BeansR getValues(String... names) {
		return (BeansR) super.getValues(names);
	}



	/**
	 *  最大文字数入力時のフォーカス移動.<p>
	 *
	 */
	public String gui_auto_focus_typ_nm() {
		return getConstString(offset + 0, $gui_auto_focus_typ_nm);
	}

	/**
	 *  最大文字数入力時のフォーカス移動.<p>
	 *
	 */
	public void gui_auto_focus_typ_nm(String value) {
		setConstString(offset + 0, $gui_auto_focus_typ_nm, value);
	}


	public String gui_auto_focus_typ() {
		return getConstString(offset + 1, $gui_auto_focus_typ);
	}

	public void gui_auto_focus_typ(String value) {
		setConstString(offset + 1, $gui_auto_focus_typ, value);
	}


	public String getString(String name) {
		if ($gui_auto_focus_typ_nm.equalsIgnoreCase(name)) {
			return gui_auto_focus_typ_nm();
		}
		if ($gui_auto_focus_typ.equalsIgnoreCase(name)) {
			return gui_auto_focus_typ();
		}
		return super.getString(name);
	}

	public String getStringNE(String name) {
		if ($gui_auto_focus_typ_nm.equalsIgnoreCase(name)) {
			return gui_auto_focus_typ_nm();
		}
		if ($gui_auto_focus_typ.equalsIgnoreCase(name)) {
			return gui_auto_focus_typ();
		}
		return super.getStringNE(name);
	}

	public void setString(String name, String value) {
		if ($gui_auto_focus_typ_nm.equalsIgnoreCase(name)) {
			gui_auto_focus_typ_nm(value);
			return;
		}
		if ($gui_auto_focus_typ.equalsIgnoreCase(name)) {
			gui_auto_focus_typ(value);
			return;
		}
		super.setString(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($gui_auto_focus_typ_nm.equalsIgnoreCase(name)) {
			gui_auto_focus_typ_nm(value);
			return;
		}
		if ($gui_auto_focus_typ.equalsIgnoreCase(name)) {
			gui_auto_focus_typ(value);
			return;
		}
		super.setStringNE(name, value);
	}



}

