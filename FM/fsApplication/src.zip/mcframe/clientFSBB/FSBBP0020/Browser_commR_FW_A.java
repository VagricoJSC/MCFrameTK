package mcframe.clientFSBB.FSBBP0020;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Browser_comm"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class Browser_commR_FW_A extends MCConstRow {

	/**
	 *  ブラウザ実行ファイル.<p>
	 *
	 */
	public static final String $browser_path = "browser_path";


	public static final MCMeta browser_path_META = createCommonMeta($browser_path, mcframe.commonCore.meta.M_META.PATH);

	protected static final ConstMetaList<Browser_commR> constMetas = new ConstMetaList<Browser_commR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			browser_path_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected Browser_commR_FW_A(ConstMetaList<? extends Browser_commR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public Browser_commR clone() {
		return (Browser_commR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public Browser_commR createInstance() {
		return (Browser_commR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public Browser_commR getValues(String... names) {
		return (Browser_commR) super.getValues(names);
	}



	/**
	 *  ブラウザ実行ファイル.<p>
	 *
	 */
	public String browser_path() {
		return getConstString(offset + 0, $browser_path);
	}

	/**
	 *  ブラウザ実行ファイル.<p>
	 *
	 */
	public void browser_path(String value) {
		setConstString(offset + 0, $browser_path, value);
	}


	public String getString(String name) {
		if ($browser_path.equalsIgnoreCase(name)) {
			return browser_path();
		}
		return super.getString(name);
	}

	public String getStringNE(String name) {
		if ($browser_path.equalsIgnoreCase(name)) {
			return browser_path();
		}
		return super.getStringNE(name);
	}

	public void setString(String name, String value) {
		if ($browser_path.equalsIgnoreCase(name)) {
			browser_path(value);
			return;
		}
		super.setString(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($browser_path.equalsIgnoreCase(name)) {
			browser_path(value);
			return;
		}
		super.setStringNE(name, value);
	}



}

