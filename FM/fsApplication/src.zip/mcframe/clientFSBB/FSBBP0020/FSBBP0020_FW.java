package mcframe.clientFSBB.FSBBP0020;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;

import mcframe.clientFSBB.FSBBP0060.*;
import mcframe.clientFSUB.FSUBP0090.*;

import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.clientFSBB.FSBBP0000.MCConfigPanel;
import mcframe.clientCore.resource.MCConfig;
import mcframe.clientCore.resource.MCConst;
import mcframe.clientCore.resource.MCUserInfo;
import mcframe.clientCore.sys.MCSys;
import mcframe.commonCore.resource.ctrl.MCGroupResource;
import mcframe.commonCore.resource.ctrl.MCResource;
import mcframe.commonFS.constant.FSC_GUI_AUTO_FOCUS_TYP;
import mcframe.commonFSUA.FSUAC0010.FSUAC_List;
import mcframe.commonFX.constant.FXC_RESOURCE_SETTING_UNIT;

import java.io.File;

import mcframe.clientFXBA.FXBAP0010.FXBAP_ISPanel;
import mcframe.commonFXBA.FXBAC0020.FXBAC_ListLogicBase;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBBP0020"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBBP0020_FW extends FSBBP0020_FW_A implements MCConfigPanel {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START
	
	/**
	 * メニュー関連のKey
	 */
	protected static String menufont_key = 
										MCResource.createKey("menu", "font");
	
	/**
	 * 処理中ダイアログ遅延のキー
	 */
	public static final String progDialogDelay_key = "progdialog.delaymillis";
	
	/**
	 * 処理中ダイアログ遅延の初期値
	 */
	public static final int progDialogDelay = 500;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBBP0020_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * Panel[Browser_comm]のボタン[browser_path_FB]の押下時の処理
	 */
	@Override
	public void doBrowser_comm_browser_path_FB(MCEventInfo info) {
		File f = null;
		String v = getBrowser_commR().browser_path();
		if (!isNull(v)) {
			f = new File(v);
			if (!f.isFile()) {
				f = null;
			}
		}
		
		f = MCFileChooser.showLoadDialog(f, this, MCFileChooser.ALL);
		if (f != null) {
			Browser_comm_browser_path.setValue(f.getPath());
		}
	}
	/**
	 * Panel[Psnl]のボタン[upd_ext]の押下時の処理
	 */
	@Override
	public void doPsnl_upd_ext(MCEventInfo info) {
	}
	/**
	 * Panel[Psnl]のボタン[upd_sys]の押下時の処理
	 */
	@Override
	public void doPsnl_upd_sys(MCEventInfo info) {
	}
	/**
	 * Panel[Browser]のボタン[browser_path_FB]の押下時の処理
	 */
	@Override
	public void doBrowser_browser_path_FB(MCEventInfo info) {
		File f = null;
		String v = getBrowserR().browser_path();
		if (!isNull(v)) {
			f = new File(v);
			if (!f.isFile()) {
				f = null;
			}
		}
		
		f = MCFileChooser.showLoadDialog(f, this, MCFileChooser.ALL);
		if (f != null) {
			Browser_browser_path.setValue(f.getPath());
		}
	}
	/**
	 * Panel[FileIO]のボタン[init_dir_FB]の押下時の処理
	 */
	public void doFileIO_init_dir_FB(MCEventInfo info) {
		File f = null;
		String v = getFileIOR().init_dir();
		if (!isNull(v)) {
			f = new File(v);
			if (!f.isDirectory()) {
				f = null;
			}
		}
		f = MCFileChooser.showSelectDirDialog(f, this);
		if (f != null) {
			FileIO_init_dir.setValue(f.getPath());
		}
	}
	
	@Override
	protected void valueInit() {
		super.valueInit();
		loadConfig();
	}

	/**
	 * 画面に設定されている情報および、この設定画面
	 * 以下の階層の設定をチェックします。<P>
	 *
	 * @return 問題ない場合は、true
	 * @see mcframe.clientFSBB.FSBBP0000.MCConfigPanel#checkConfig()
	 */
	@Override
	public boolean checkUpdConfig() {
		MCMessageList l = checkReq(getScreenR());
		l.addAll(checkReq(getDialogR()));
		if (l.size() > 0) {
			message(l);
			return false;
		}
		return true;
	}

	@Override
	public void saveUpdConfig(MCMessageList msgList) {
		MenuScreenR ms = getMenuScreenR();
		if (ms.isStatusModify()) {
			MCConst.menu.initTabPath(ms.initTabPath());
		}

		ScreenR s = getScreenR();
		if (s.isStatusModify()) {
			MCConfig.client.setString(
					"startup.screen.moduleid", s.initModuleID());
			MCConfig.client.setString(
					"startup.screen.screenid", s.initScreenID());
			MCConfig.client.setNumber(
					"startup.screen.mode", MCNumber.ZERO);
		}
		
		// ダイアログ
		MCNumber progDelay = getDialogR().prog_delay_millis();
		MCConfig.client.setInteger(progDialogDelay_key, progDelay.intValue());
		
		// ファイル
		if (getFileIOR().isStatusModify()) {
			MCConfig.client.setString(MCFileChooser.DEF_DIR_KEY, getFileIOR().init_dir());
			MCConst.beans.setBoolean(MCBeansWriter.TABLE_DISPLAY_KEY, getFileIOR().tbl_display());
			MCConst.beans.setBoolean(MCBeansWriter.ROOTPANEL_DISPLAY_KEY, getFileIOR().rootpnl_display());
		}
		
		if (getBeansR().isStatusModify()) {
			String afv = getBeansR().gui_auto_focus_typ();
			if (afv == null) {
				MCConst.beans.remove(MCBeansConsts.P_AUTO_FOCUS_KEY);
			}
			else {
				if (FSC_GUI_AUTO_FOCUS_TYP.isMOVE_FOCUS(afv)) {
					MCConst.beans.setBoolean(
							MCBeansConsts.P_AUTO_FOCUS_KEY, true);
				}
				else if (FSC_GUI_AUTO_FOCUS_TYP.isNOT_MOVE(afv)) {
					MCConst.beans.setBoolean(
							MCBeansConsts.P_AUTO_FOCUS_KEY, false);
				}
			}
			msgList.add(msgBeansModified());
		}
		
		if (getBrowserR().isStatusModify()) {
			MCConfig.client.setString(
					MCConfig.client.getBrowserFilePathKey(), getBrowserR().browser_path());
		}
		
		if (getBrowser_commR().isStatusModify()) {
			MCConfig.client.setString(
					MCConfig.client.getCommunicationBrowserFilePathKey(), 
					getBrowser_commR().browser_path());
		}
		
	}

	/**
	 * デフォルトの内容で保存します。<P>
	 */
	@Override
	public void saveDfltConfig(MCMessageList msgList) {
		MCConst.menu.removeInitTabPath();
		
		MCConfig.client.remove("startup.screen.moduleid");
		MCConfig.client.remove("startup.screen.screenid");
		MCConfig.client.remove("startup.screen.mode");
		
		// ダイアログ
		MCConfig.client.remove(progDialogDelay_key);
		
		// ファイル
		MCConfig.client.remove(MCFileChooser.DEF_DIR_KEY);
		MCConst.beans.remove(MCBeansWriter.TABLE_DISPLAY_KEY);
		MCConst.beans.remove(MCBeansWriter.ROOTPANEL_DISPLAY_KEY);
		
		if (MCConst.beans.containsKey(MCBeansConsts.P_AUTO_FOCUS_KEY)) {
			MCConst.beans.remove(MCBeansConsts.P_AUTO_FOCUS_KEY);
			msgList.add(msgBeansModified());
		}

		MCConfig.client.remove(MCConfig.client.getBrowserFilePathKey());
		MCConfig.client.remove(MCConfig.client.getCommunicationBrowserFilePathKey());
	}
	
	/**
	 * 設定内容を読み込みます。<P>
	 */
	protected void loadConfig() {
		//メニュー関連
		String v = MCConst.menu.initTabPath();
		if (v == null) {
			getMenuScreenR().clear(
					MenuScreenR.$initTabName, MenuScreenR.$initTabPath);
		}else{
			MCRow r = MCRow.create();
			r.setStringNE(FSUAC_List.MenuTabCols.$o_menu_path, v);
			MCList l = getMenuScreen_initTabName(r, new MCEventInfo());
			if (l != null && l.size() > 0) {
				getMenuScreenR().initTabName(
						l.getStringNE(0, FSUAC_List.MenuTabCols.$o_menu_name));
				getMenuScreenR().initTabPath(
						l.getStringNE(0, FSUAC_List.MenuTabCols.$o_menu_path));
			}
		}
		
		Status ss = getScreenR().getStatus();
		try {
			String im = MCConfig.client.getString("startup.screen.moduleid");
			String is = MCConfig.client.getString("startup.screen.screenid");
			MCNumber sm = MCConfig.client.getNumber("startup.screen.mode");
			
			getScreenR().initModuleID(im);
			getScreenR().initScreenID(is);
			getScreenR().initScreenName(MCConst.label.getLabel(MCConst.createKey(im, is, "label")));
			getScreenR().initScreenMode(sm);
			setScreen_ScreenID_Mode();
		}
		finally {
			getScreenR().setStatus(ss);
		}

		// ダイアログ
		int progDelay = MCConfig.client.getInteger(progDialogDelay_key, progDialogDelay);
		getDialogR().prog_delay_millis(progDelay);
		
		// ファイル関連
		getFileIOR().init_dir(MCConfig.client.getString(MCFileChooser.DEF_DIR_KEY));
		getFileIOR().tbl_display(MCConst.beans.getBoolean(MCBeansWriter.TABLE_DISPLAY_KEY));
		getFileIOR().rootpnl_display(MCConst.beans.getBoolean(MCBeansWriter.ROOTPANEL_DISPLAY_KEY));
		
		if (MCConst.beans.containsKey(MCBeansConsts.P_AUTO_FOCUS_KEY)) {
			boolean af = MCConst.beans.getBoolean(
					MCBeansConsts.P_AUTO_FOCUS_KEY);
			String afv = null;
			if (af) {
				afv = FSC_GUI_AUTO_FOCUS_TYP.MOVE_FOCUS.name();
			}
			else {
				afv = FSC_GUI_AUTO_FOCUS_TYP.NOT_MOVE.name();
			}
			Beans_gui_auto_focus_typ_nm.setValue(afv);
		}
		else {
			Beans_gui_auto_focus_typ_nm.setValue(null);
		}
		
		getBrowserR().browser_path(MCConfig.client.getBrowserFilePath());
		getBrowser_commR().browser_path(MCConfig.client.getCommunicationBrowserFilePath());
	}
	
	/**
	 * 登録処理が完了した後のメッセージを表示します。
	 */
	public MCMessage msgBeansModified() {
		return new MCMessage(FSBBC0009);
	}
	
	//-----------------イベント処理----------------------

	@Override
	public void doScreen_initModuleID_LC(MCEventInfo info) {
		super.doScreen_initModuleID_LC(info);
		
		if (!isScreenIDEnable()) {
			setValueEx(Screen_initScreenID, null);
		}
		
		setScreen_ScreenID_Mode();
	}

	protected boolean isScreenIDEnable() {
		String m = getScreenR().initModuleID();
		if (isNull(m)) {
			return false;
		}
		MCRow o = MCRow.create();
		MCList<MCRow> l = getScreenInfo(o);
		if (l == null) {
			return false;
		}
		l = l.subList(FSUAC_List.FSUAP0020Cols.$o_module_id, m);
		l = l.subList(FSUAC_List.FSUAP0020Cols.$o_screen_id, 
				getScreenR().initScreenID());
		return l != null && l.size() > 0;
	}
	
	protected MCList<MCRow> getScreenInfo(MCRow row) {
		_inputSupportType = INPUT_SUPPORT_GET_LIST;
		ISPanelLinker ir = getISPanelLinkerNE(Screen_initScreenID);
		if (ir != null && ir.isEnable()) {
			row.setStringNE(FXBAC_ListLogicBase.$INPUT_VAL, getScreenR().initScreenID());
			FXBAP_ISPanel p = getISPanel(Screen_initScreenID, -1);
			return p.getList(row, this);
		}
		return null;
	}
	
	protected void setScreen_ScreenID_Mode() {
		if (!isDefaultModeEditable(Screen_initScreenID)) {
			return;
		}
		if (!isNull(getScreenR().initModuleID())) {
			Screen_initScreenID.setMode(MCMode.REQUIRED);
		}
		else {
			setDefaultMode(Screen_initScreenID);
		}
	}
	
	@Override
	public void doScreen_initScreenID_LC(MCEventInfo info) {
		super.doScreen_initScreenID_LC(info);
		
		String s = getScreenR().initScreenID();
		if (!isNull(s)) {
			setValueEx(Screen_initModuleID, 
					getScreenR().initScreenModuleID());
		}
		
		setScreen_ScreenID_Mode();
	}

	//-----------------ステータス処理----------------------
	@Override
	public void setINITStatus(){
		super.setINITStatus();
		setScreen_ScreenID_Mode();
		focusFirstComponent();
	}
	

	//-----------------コンボリスト処理----------------------
	@Override
	protected void listInit() {
		super.listInit();
		getMenuScreen_initTabName_ListPutter().setColumns(
											FSUAC_List.MenuTabCols.$o_menu_name,
											FSUAC_List.MenuTabCols.$o_menu_path);
		MenuScreen_initTabName.setListVisibleColumn(
											FSUAC_List.MenuTabCols.$o_menu_name);
		
		getScreen_initModuleID_ListPutter().setColumns(
				FSUAC_List.UserModuleIDCols.$o_module_id,
				FSUAC_List.UserModuleIDCols.$o_module_nm);
		getScreen_initScreenID_ListPutter().setColumns(
				FSUAC_List.FSUAP0020Cols.$o_screen_id, 
				FSUAC_List.FSUAP0020Cols.$o_screen_name,
				FSUAC_List.FSUAP0020Cols.$o_module_id);
	}
	
	//-----------------入力補助処理----------------------
	
	@Override
	protected void linkBeansToISPanel() {
		super.linkBeansToISPanel();

		linkBeansToISPanel(Screen_initScreenID, "FS", "FSUAP0020", true);
		getScreen_initScreenID_ListPutter().putBind(FSUAC_List.FSUAP0020Cols.$i_module_id,
				Screen_initModuleID);
		getScreen_initScreenID_ListPutter()
				.putBind(FSUAC_List.FSUAP0020Cols.$i_check_ac_flg, true);
	}
	
	@Override
	public void setStatus(String status) {
		super.setStatus(status);
		
		if (!Psnl_upd_ext.authorize()) {
			Psnl_setting_PPanel.Setting_setting_unit_EXT.setMode(MCMode.READ_ONLY);
		}
		if (!Psnl_upd_sys.authorize()) {
			Psnl_setting_PPanel.Setting_setting_unit_SYS.setMode(MCMode.READ_ONLY);
		}
	}
	
	@Override
	protected void beansAttrInit() {
		super.beansAttrInit();
		
		Psnl_psnl_PPanel.setPersonalizeUser(createPersonalizeUser());
	}

	/**
	 * パーソナライズ入出力部品に対象のユーザを通知するクラスを作成します。
	 */
	protected FSBBP0060_PersonalizeUser createPersonalizeUser() {
		return new PersonalizeUser();
	}
	
	/**
	 * パーソナライズ入出力部品に対象のユーザを通知するクラスです。
	 */
	protected class PersonalizeUser implements FSBBP0060_PersonalizeUser {
		
		@Override
		public MCUserInfo getExportUserInfo() {
			return getUserInfo();
		}

		@Override
		public MCUserInfo[] getImportUserInfoArray() {
			return new MCUserInfo[] {getUserInfo()};
		}
		
		@Override
		public FXC_RESOURCE_SETTING_UNIT getSettingUnit() {
			return FXC_RESOURCE_SETTING_UNIT.get(getSettingR().setting_unit());
		}

		protected MCUserInfo getUserInfo() {
			MCUserInfo info = new MCUserInfo();

			FXC_RESOURCE_SETTING_UNIT unit = FXC_RESOURCE_SETTING_UNIT.get(
					getSettingR().setting_unit());
			if (FXC_RESOURCE_SETTING_UNIT.isTYPE_USER(unit)) {
				info.userid(MCSys.user.ID());
			}
			else if (FXC_RESOURCE_SETTING_UNIT.isTYPE_EXT(unit)) {
				info.userid(MCGroupResource.EXT_ATTR_USER_ID);
				info.cocd(MCSys.user.coCD());
				info.extattr1(MCSys.user.extattr1());
				info.extattr2(MCSys.user.extattr2());
				info.extattr3(MCSys.user.extattr3());
			}
			else if (FXC_RESOURCE_SETTING_UNIT.isTYPE_SYS(unit)) {
				info.userid(MCGroupResource.SYSTEM_USER_ID);
			}

			return info;
		}
		
		protected SettingR getSettingR() {
			return Psnl_setting_PPanel.getSettingR();
		}
		
	}

}