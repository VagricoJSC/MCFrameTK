package mcframe.clientFSBB.FSBBP0020;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Dialog"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class DialogR_FW_A extends MCConstRow {

	/**
	 *  処理中ダイアログ遅延(ミリ秒).<p>
	 *
	 */
	public static final String $prog_delay_millis = "prog_delay_millis";


	public static final MCMeta prog_delay_millis_META = createNumberMeta($prog_delay_millis, 10, 0, false);

	protected static final ConstMetaList<DialogR> constMetas = new ConstMetaList<DialogR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			prog_delay_millis_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected DialogR_FW_A(ConstMetaList<? extends DialogR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public DialogR clone() {
		return (DialogR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public DialogR createInstance() {
		return (DialogR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public DialogR getValues(String... names) {
		return (DialogR) super.getValues(names);
	}



	/**
	 *  処理中ダイアログ遅延(ミリ秒).<p>
	 *
	 */
	public MCNumber prog_delay_millis() {
		return getConstNumber(offset + 0, $prog_delay_millis);
	}

	/**
	 *  処理中ダイアログ遅延(ミリ秒).<p>
	 *
	 */
	public void prog_delay_millis(MCNumber value) {
		setConstNumber(offset + 0, $prog_delay_millis, value);
	}

	/**
	 *  処理中ダイアログ遅延(ミリ秒).<p>
	 *
	 */
	public void prog_delay_millis(int value) {
		setConstNumber(offset + 0, $prog_delay_millis, value);
	}

	/**
	 *  処理中ダイアログ遅延(ミリ秒).<p>
	 *
	 */
	public void prog_delay_millis(long value) {
		setConstNumber(offset + 0, $prog_delay_millis, value);
	}

	/**
	 *  処理中ダイアログ遅延(ミリ秒).<p>
	 *
	 */
	public void prog_delay_millis(float value) {
		setConstNumber(offset + 0, $prog_delay_millis, value);
	}

	/**
	 *  処理中ダイアログ遅延(ミリ秒).<p>
	 *
	 */
	public void prog_delay_millis(double value) {
		setConstNumber(offset + 0, $prog_delay_millis, value);
	}


	public MCNumber getNumber(String name) {
		if ($prog_delay_millis.equalsIgnoreCase(name)) {
			return prog_delay_millis();
		}
		return super.getNumber(name);
	}

	public MCNumber getNumberNE(String name) {
		if ($prog_delay_millis.equalsIgnoreCase(name)) {
			return prog_delay_millis();
		}
		return super.getNumberNE(name);
	}

	public void setNumber(String name, MCNumber value) {
		if ($prog_delay_millis.equalsIgnoreCase(name)) {
			prog_delay_millis(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, int value) {
		if ($prog_delay_millis.equalsIgnoreCase(name)) {
			prog_delay_millis(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, long value) {
		if ($prog_delay_millis.equalsIgnoreCase(name)) {
			prog_delay_millis(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, float value) {
		if ($prog_delay_millis.equalsIgnoreCase(name)) {
			prog_delay_millis(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, double value) {
		if ($prog_delay_millis.equalsIgnoreCase(name)) {
			prog_delay_millis(value);
			return;
		}
		super.setNumber(name, value);
	}

	public void setNumberNE(String name, MCNumber value) {
		if ($prog_delay_millis.equalsIgnoreCase(name)) {
			prog_delay_millis(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, int value) {
		if ($prog_delay_millis.equalsIgnoreCase(name)) {
			prog_delay_millis(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, long value) {
		if ($prog_delay_millis.equalsIgnoreCase(name)) {
			prog_delay_millis(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, float value) {
		if ($prog_delay_millis.equalsIgnoreCase(name)) {
			prog_delay_millis(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, double value) {
		if ($prog_delay_millis.equalsIgnoreCase(name)) {
			prog_delay_millis(value);
			return;
		}
		super.setNumberNE(name, value);
	}



}

