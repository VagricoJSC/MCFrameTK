package mcframe.clientFSBA.FSBAP0370;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;

import mcframe.clientFSUB.FSUBP0080.*;

import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START

import javax.swing.JMenu;
import javax.swing.JPopupMenu;
import javax.swing.MenuElement;

import mcframe.clientCore.beans.list.MCLinkBeans;
import mcframe.clientCore.beans.popup.MCMenu;
import mcframe.clientCore.beans.popup.MCPopupBeans;
import mcframe.clientCore.beans.popup.MCPopupMenu;
import mcframe.clientCore.beans.popup.MCPopupMenuItem;
import mcframe.clientCore.beans.text.MCDateFormat;
import mcframe.clientCore.beans.text.MCNumberFormat;
import mcframe.clientCore.beans.text.MCTimestampFormat;
import mcframe.clientCore.container.MCRowEvent;
import mcframe.clientCore.container.MCRowStatusEvent;
import mcframe.clientCore.resource.MCConst;
import mcframe.commonCore.util.MCCollectionUtil;

import mcframe.commonFS.constant.FSC_H_ALIGN_TYPE;

import mcframe.clientFXBA.FXBAP0010.FXBAP_PanelBase;
import mcframe.clientFXBA.FXBAP0080.FXBAP_CellConfig;
import mcframe.clientFXBA.FXBAP0100.FXBAP_PopupConfig;
import mcframe.clientFXBA.FXBAP0110.FXBAP_ListListener;
import mcframe.clientFXBA.FXBAP0110.FXBAP_RowListener;

import mcframe.clientFSUC.FSUCP0000.FSUCP_PopupConfig;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP_VerticalView_D"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP_VerticalView_D_FW extends FSBAP_VerticalView_D_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	/**
	 * チェックボックスの値の表現方法に関する定数です。
	 * チェックボックスの値を1,0で表現します。
	 */
	public static final int BOOLEAN_TYPE_1_0 = 1;
	
	/**
	 * チェックボックスの値の表現方法に関する定数です。
	 * チェックボックスの値をtrue,falseで表現します。
	 */
	public static final int BOOLEAN_TYPE_TRUE_FALSE = 2;
	
	/**
	 * 親テーブルです。
	 */
	protected MCTable<?> _par_table = null;
	
	/**
	 * 親テーブルのリストを格納します。
	 * 親テーブルのリストに対して直接ソートなどの処理を実行すると、
	 * 親テーブルに影響するため、このリストに移し替えます。
	 */
	protected MCList<?> _par_list = MCList.create(MCRow.class);
	
	/**
	 * 親テーブルのコンテナに設定するロウリスナです。
	 */
	protected ParRowListener _par_row_listener = null;
	
	/**
	 * 親テーブルのコンテナに設定するリストリスナです。
	 */
	protected ParListListener _par_list_listener = null;
	
	/**
	 * 表示するデータの列数です。
	 */
	protected int _column_count = 100;
	
	/**
	 * 現在表示対象としている最小の行番号です。
	 */
	protected int _crnt_min = 0;
	
	/**
	 * 現在表示対象としている最大の行番号です。
	 */
	protected int _crnt_max = _crnt_min + _column_count;
	
	/**
	 * 最後にダブルクリックでソートしたときの行の番号です。
	 */
	protected int _crnt_sort_idx = -1;
	
	/**
	 * 最後にダブルクリックでソートしたときのソート順です。
	 */
	protected MCList.SortType _crnt_sort_typ = null;
	
	/**
	 * 縦横変換処理中ＦＬＧです。
	 */
	protected boolean _is_conv_processing = false;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_VerticalView_D_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_VerticalView_D_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * Panel[Btm]のボタン[prev]の押下時の処理
	 */
	@Override
	public void doBtm_prev(MCEventInfo info) {
		if (_crnt_min - _column_count >= 0) {
			_crnt_min = _crnt_min - _column_count;
			_crnt_max = _crnt_max - _column_count;
			conv();
		}
	}
	
	/**
	 * Panel[Btm]のボタン[next]の押下時の処理
	 */
	@Override
	public void doBtm_next(MCEventInfo info) {
		if (_crnt_max < _par_list.size()) {
			_crnt_min = _crnt_min + _column_count;
			_crnt_max = _crnt_max + _column_count;
			conv();
		}
	}
	
	/**
	 * 他画面から呼び出された場合の初期化を実装します。<br>
	 * <P>
	 * <li>起動タイプ：T1<br>
	 * バインド値＜必須＞<br>
	 * <table border = 1>
	 * <tr>
	 * <th>カラム名</th>
	 * <th>型</th>
	 * <th>備考</th>
	 * </tr>
	 * <tr>
	 * <td>無し</td>
	 * <td>無し</td>
	 * <td>無し</td>
	 * </tr>
	 * </table> <br>
	 * その他の引数[0]：親テーブルのインスタンス（必須）</li>
	 * </P>
	 * 
	 * @param openTyp 起動タイプ
	 * @param bind バインド値
	 * @param args その他の引数
	 */
	@Override
	protected void initByScreenParam(
			String openTyp, MCRow bind, Object... param) {
		super.initByScreenParam(openTyp, bind, param);

		if (T1 == openTyp) {
			Object o = param[0];
			if (o instanceof MCTable<?>) {
				MCTable<?> t = (MCTable<?>)o;
				MCRootPanel p = t.getBaseRootPanel();
				if (p instanceof FXBAP_PanelBase 
						&& t.getCellConfig() instanceof FXBAP_CellConfig) {
					init(t);
					conv();
				}
				else {
					throw new MCAppException(FSBAC0057);
				}
			}
			else {
				throw new MCAppException(FSBAC0057);
			}
		}
		else {
			throw new MCAppException(msgUnknownOpenParam());
		}
	}
	
	/**
	 * 画面呼び出し時の初期化処理
	 * 
	 * @param p_tbl 親テーブル
	 */
	protected void init(MCTable<?> p_tbl) {
		_par_table = p_tbl;
		
		addParRowListener();

		// 親テーブルのリストを移し替える
		// フィルタされている行は縦表示の対象外とする
		_par_list.setAll((MCList)_par_table.getViewRows());
		
		initRowCntCnd();
		initSortCnd();
	}
	
	/**
	 * 親テーブルのコンテナにロウリスナとリストリスナを設定します。
	 */
	protected void addParRowListener() {
		for (MCConstRow o : _par_table.getList()) {
			o.addRowListener(getParRowListener());
			o.addRowStatusListener(getParRowListener());
		}
		
		_par_table.getList().addListListener(getParListListener());
	}
	
	/**
	 * 親テーブルのコンテナからロウリスナとリストリスナを削除します。<p>
	 * {@link #addParRowListener()} で設定したロウリスナとリストリスナを削除します。
	 */
	protected void removeParRowListener() {
		if (_par_table == null) {
			return;
		}
		for (MCConstRow o : _par_table.getList()) {
			o.removeRowListener(getParRowListener());
			o.removeRowStatusListener(getParRowListener());
		}

		_par_table.getList().removeListListener(getParListListener());
	}
	
	/**
	 * 行数表示条件を初期化します。
	 */
	protected void initRowCntCnd() {
		_crnt_min = 0;
		_crnt_max = _crnt_min + _column_count;
	}
	
	/**
	 * ソート条件を初期化します。
	 */
	protected void initSortCnd() {
		_crnt_sort_idx = -1;
		_crnt_sort_typ = null;
	}
	
	@Override
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		
		if (getBtmR().input() 
				&& isDataColumn(info.getComponent())) {
			setFocusToParentCell(info);
		}
	}
	
	@Override
	public void doDCEvent(MCDCBeans dc, MCEventInfo info) {
		super.doDCEvent(dc, info);
		
		if (isDataColumn(dc)) {
			openISPanel((MCColumnConfig)dc, info.getEventIndex());
			doViewTable_DC(dc, info);
		}
		else if (dc == ViewTable) {
			doViewTable_DC(dc, info);
		}
	}
	
	@Override
	public void openISPanel(MCLinkBeans compo, int eventIndex) {
		// 親テーブルのセルの入力補助を起動する
		MCColumnConfig pc = getParColumnConfig(eventIndex);
		((FXBAP_PanelBase)pc.getRootPanel()).openISPanel(
				pc, _par_table.getMCSelectedRow());
	}
	
	/**
	 * 縦表示テーブルをダブルクリックしたときの処理を実行します。
	 * 
	 * @param dc GUI 部品
	 * @param info イベント情報
	 */
	public void doViewTable_DC(MCDCBeans dc, MCEventInfo info) {
		// タイトルカラムの場合
		if (isTitleColumn(info.getClickColumn())) {
			// ソートする
			sort(info);
		}
		// 編集不可の場合
		else if (isDataColumn(info.getClickColumn())) {
			// 親テーブルのセルにフォーカスを移動する
			setFocusToParentCell(info);
			// 画面を閉じる
			closeView();
		}
		// 編集可能な場合
		else if (isDataColumn(info.getComponent())) {
			// 親テーブルのセルにフォーカスを移動する
			setFocusToParentCell(info);
		}
	}
	
	/**
	 * ソート処理を実行します。
	 * 
	 * @param info イベント情報
	 */
	protected void sort(MCEventInfo info) {
		// 入力モードの場合はソートしない
		if (info.getClickIndex() < 0 || getBtmR().input()) {
			return;
		}
		
		// ソートできないカラムの場合はソートしない
		MCColumnConfig c = getParColumnConfig(info.getEventIndex());
		if (c == null || !c.isSortable()) {
			return;
		}
		
		// ソート条件の設定
		_crnt_sort_typ = (_crnt_sort_idx != info.getClickIndex() 
				|| _crnt_sort_typ == MCList.SortType.DESC) 
				? MCList.SortType.ASC : MCList.SortType.DESC;
		_crnt_sort_idx = info.getClickIndex();
		
		// ソート
		_par_list.sort(
				_crnt_sort_typ, getViewL().get(_crnt_sort_idx).par_col_nm());
		
		// 行数表示の初期化
		initRowCntCnd();
		
		// 縦表示
		conv();
	}
	
	/**
	 * 親テーブルのセルにフォーカスを移動します。
	 * 
	 * @param info イベント情報
	 */
	protected void setFocusToParentCell(MCEventInfo info) {
		if (info.getEventIndex() < 0) {
			return;
		}
		
		MCColumnConfig vc = null;
		if (info.getComponent() instanceof MCColumnConfig) {
			vc = (MCColumnConfig)info.getComponent();
		}
		else if (info.getComponent() instanceof MCTable<?>) {
			vc = info.getClickColumn();
		}
		else {
			return;
		}
		
		MCRow po = getParRow(vc);
		MCColumnConfig pc = getParColumnConfig(info.getEventIndex());
		
		// 選択した行と親テーブルの行が一致しない場合
		// 親テーブルの状況が変わっているためフォーカスを移動しない
		if (_par_table.getRow(po.getGUIIndex()) != po) {
			return;
		}
		
		// 親テーブルのセルにフォーカスを移動する
		_par_table.focusCellAt(po.getGUIIndex(), pc);
	}
	
	/**
	 * 画面を閉じます。
	 */
	protected void closeView() {
		// 親画面を前面に出して自身を閉じる
		_par_table.getBaseRootPanel().moveToFront();
		requestCloseWindow();
	}
	
	@Override
	public void doBtm_input_NC(MCEventInfo info) {
		super.doBtm_input_NC(info);
		
		// ソート等の条件をクリア
		_par_list.setAll((MCList)_par_table.getList());
		
		// 行数表示の初期化
		initRowCntCnd();
		
		// 再縦表示（入力モードも変更される）
		conv();
	}

	/**
	 * 前次ボタンのモードを設定します。
	 */
	protected void setButtonMode() {
		setBtm_prev_Mode();
		setBtm_next_Mode();
	}
	
	/**
	 * 前ボタンのモードを設定します。
	 */
	protected void setBtm_prev_Mode() {
		Btm_prev.setMode((_crnt_min - _column_count < 0) 
				? MCMode.DISABLE : MCMode.ENABLE);
	}
	
	/**
	 * 次ボタンのモードを設定します。
	 */
	protected void setBtm_next_Mode() {
		Btm_next.setMode((_crnt_max >= _par_list.size()) 
				? MCMode.DISABLE : MCMode.ENABLE);
	}
	
	@Override
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		
		// データ表示用のカラムの場合にのみアクションする
		if (isDataColumn(vc)) {
			return setValToParTable(info);
		}
		return true;
	}
	
	@Override
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		
		if (isDataColumn(nc)) {
			int idx = info.getEventIndex();
			MCColumnConfig vc = (MCColumnConfig)info.getComponent();
			
			MCColumnConfig pc = getParColumnConfig(idx);
			MCDataType py = pc.getDataType();
			if (MCDataType.BOOLEAN.equals(py)) {
				MCRow po = getParRow(vc);
				Boolean pv = po.getBoolean(pc.getBaseRowColumnName());
				if (!isSame(pv.booleanValue(), 
						convStringToBoolean((String)info.getNewValue()))) {
//				if (!isSame(pv.toString(), (String)info.getNewValue())) {
					getViewL().get(idx).setString(
							vc.getBaseRowColumnName(), pv.toString());
				}
			}
			
		}
	}
	
	/**
	 * 指定された項目がタイトルカラムの場合は true を返します。
	 * 
	 * @param compo 画面項目
	 * @return 指定された項目がタイトルカラムではない場合は false
	 */
	protected boolean isTitleColumn(MCBeans compo) {
		return compo == columnView_title;
	}
	
	/**
	 * 指定された項目がデータ表示用カラムの場合は true を返します。
	 * 
	 * @param compo 画面項目
	 * @return 指定された項目がデータ表示用カラムではない場合は false
	 */
	protected boolean isDataColumn(MCBeans compo) {
		if (!(compo instanceof MCColumnConfig)) {
			return false;
		}
		
		MCColumnConfig c = (MCColumnConfig)compo;
		String n = c.getRowColumnName();
		return !isNull(n) && n.indexOf("data") != -1;
	}
	
	/**
	 * 縦表示テーブルに入力した値を親テーブルに反映します。
	 * 値を親テーブルに反映できた場合は true を返します。
	 * 
	 * @param info イベント情報
	 * @return 値を親テーブルに反映できなかった場合は false
	 */
	protected boolean setValToParTable(MCEventInfo info) {
		// 縦横変換中の場合は常に入力可能
		if (_is_conv_processing) {
			return true;
		}
		
		int idx = info.getEventIndex();
		MCColumnConfig vc = (MCColumnConfig)info.getComponent();
		
		MCRow po = getParRow(vc);
		MCColumnConfig pc = getParColumnConfig(idx);
		
		try {
			Comparable<?> v = toParData((String)info.getNewValue(), pc, vc);
			_par_table.focusCellAt(po.getGUIIndex(), pc);
			setValueEx(pc, po.getGUIIndex(), v);
		}
		catch (MCException ex) {
			return false;
		}
		
//		convByParColumnConfig(pc, po);
		
		return true;
	}

	/**
	 * 縦横変換処理を実行します。
	 */
	protected void conv() {
		// FROM-TOで指定された範囲のデータを全て縦表示テーブルに反映する
		// 表示する親テーブルの対象行を洗い替える場合に使用する
		beforeConv();
		doConv();
		afterConv();
	}
	
	/**
	 * 縦横変換の前処理を実行します。
	 */
	protected void beforeConv() {
		// クリア
		getViewL().clear();
		
		// モードの初期設定
		setSRCHStatus();
		setButtonMode();
	}
	
	/**
	 * 縦横変換処理を実行します。
	 */
	protected void doConv() {
		MCColumnConfig[] p_cols = _par_table.getColumnConfigs();
		MCColumnConfig[] pv_cols = _par_table.getViewColumnConfigs();
		boolean first = true;
		
		MCList<ViewR> l = createViewL();
		
		for (int i = 0; i < p_cols.length; i++) {
			// 親テーブルの項目（列）ごとの処理
			MCColumnConfig pc = p_cols[i];
		
			// データを持たないカラム、非表示カラムは除外する
			if (!pc.isLinkRowColumn() 
					|| !MCCollectionUtil.contains(pc, pv_cols)) {
				continue;
			}
			
			ViewR o = createViewR(pc, i);
			
			int cnt = 0;
			
			// 親テーブルの項目に対応するデータをマッピングする（縦の１列を横の１行に）
			for (int j = _crnt_min; j < _crnt_max; j++) {
				boolean d = j >= _par_list.size();
				if (!first && d) {
					break;
				}
				
				MCColumnConfig vc = ViewTable.getColumnConfig(cnt + 1);
				
				// 空のカラムは非表示にする
				if (d) {
					vc.setMode(MCMode.INVISIBLE);
					cnt++;
					continue;
				}

				// データの設定
				String v = toViewData(_par_list.getValue(
						j, pc.getBaseRowColumnName()), pc, vc);
				o.setValue(vc.getRowColumnName(), v);
				
				// ヘッダの設定（１回目のみ）
				if (first) {
					// ヘッダに親リストの行番号を設定
					String no = Integer.toString(j + 1);
					vc.setHeaderMessage(no);
					vc.setHeaderName(no);
					vc.setHeaderBackground(getStatusCellBackground(vc));
					vc.setHeaderForeground(getStatusCellForeground(vc));
				}

				cnt++;
			}
			
			first = false;
			
			l.add(o);
		}
		setViewL(l);
	}
//	protected void doConv() {
//		MCColumnConfig[] p_cols = _par_table.getViewColumnConfigs();
//		boolean first = true;
//		
//		MCList<ViewR> l = createViewL();
//		for (int i = 0; i < p_cols.length; i++) {
//			l.add(createViewR(p_cols[i], i));
//		}
//		setViewL(l);
//		
//		// 親テーブルの項目（列）ごとの処理
//		for (int i = 0; i < p_cols.length; i++) {
//			MCColumnConfig pc = p_cols[i];
//			
//			int cnt = 0;
//			
//			// 親テーブルの項目に対応するデータをマッピングする（縦の１列を横の１行に）
//			for (int j = _crnt_min; j < _crnt_max; j++) {
//				MCColumnConfig vc = ViewTable.getColumnConfig(cnt + 1);
//				
//				// 空のカラムは非表示にする
//				if (j >= _par_list.size()) {
//					vc.setMode(MCMode.INVISIBLE);
//					cnt++;
//					continue;
//				}
//				
//				// データの設定
//				if (pc.isLinkRowColumn()) {
//					String v = toViewData(_par_list.getValue(
//							j, pc.getBaseRowColumnName()), pc, vc);
//					setValueInConv(vc, i, v);
//				}
//				
//				// ヘッダの設定（１回目のみ）
//				if (first) {
//					// ヘッダに親リストの行番号を設定
//					String no = Integer.toString(j + 1);
//					vc.setHeaderMessage(no);
//					vc.setHeaderName(no);
//					vc.setHeaderBackground(getStatusCellBackground(vc));
//					vc.setHeaderForeground(getStatusCellForeground(vc));
//				}
//				cnt++;
//			}
//			first = false;
//		}
//		setViewL(l);
//	}

	/**
	 * 縦表示テーブルに値を設定します。縦横変換処理で使用します。
	 * 
	 * @param v_col 縦表示テーブルのテーブルカラム
	 * @param index 行番号
	 * @param value 値
	 */
	protected void setValueInConv(
			MCColumnConfig v_col, int index, Comparable<?> value) {
		getViewL().get(index).setValue(v_col.getRowColumnName(), value);
	}
//	protected void setValueInConv(
//			MCColumnConfig v_col, int index, Comparable<?> value) {
//		// 縦横変換処理中はVCイベントをスキップする
//		try {
//			_is_conv_processing = true;
//			v_col.setValue(index, value);
//		}
//		finally {
//			_is_conv_processing = false;
//		}
//	}
	
	/**
	 * 縦横変換の後処理を実行します。
	 */
	protected void afterConv() {
		// 件数の設定
		setRowCnt();
	}

	/**
	 * 縦表示テーブルに追加する行を作成します。<p>
	 * 
	 * @param p_col 親テーブルのテーブルカラム
	 * @param p_idx 親テーブルのテーブルカラムのインデックス値
	 * @return 縦表示テーブルに追加する行
	 */
	protected ViewR createViewR(MCColumnConfig p_col, int p_idx) {
		ViewR o = ViewR.create();
		o.title(p_col.getLabelByLocale()); 				// タイトル
		o.dat_typ(p_col.getDataType().name()); 			// データ型
		o.par_col_nm(p_col.getBaseRowColumnName()); 	// カラム名
		o.par_col_idx(p_idx);
		return o;
	}
	
	/**
	 * データを型に応じてStringに変換する
	 * 
	 * @param p_val データ
	 * @param p_col データに対応するカラムコンフィグ
	 * @return Stringに変換されたデータ
	 */
	protected String toViewData(
			Comparable<?> p_val, MCColumnConfig p_col, MCColumnConfig v_col) {
		FXBAP_CellConfig pf = (FXBAP_CellConfig) p_col.getCellConfig();
		MCRow po = getParRow(v_col);
		MCMode pm = pf.isCellEditable(
				po.getGUIIndex(), p_col, p_col.getTable());
		boolean input = (p_col.getModeInfo(pm).getStatus() 
				== MCMode.ENABLE_STATUS) ? getBtmR().input() : false;

		MCDataType py = p_col.getDataType();
		if (py == null) {
			return null;
		}
		switch (py) {
			case STRING:
				if (p_col.getColumnType() == MCColumnType.PASSWORD) {
					return null;
				}
				return (String) p_val;
			case NUMBER:
				MCNumberFormat nf = getCellNumberFormat(p_col, v_col);
				int ns = getCellScale(p_col, v_col, input);
				return input ? nf.doInputFormat((MCNumber) p_val, ns) 
						: nf.doOutputFormat((MCNumber) p_val, ns);
			case DATE:
				if (p_val != null) {
					MCDateFormat df = getCellDateFormat(p_col, v_col);
					String dp = input 
							? df.getInputPattern() : df.getOutputPattern();
					return ((MCDate) p_val).toString(dp);
				}
				return input ? null : getCellDateFormat(
						p_col, v_col).getOutputBlank();
			case TIMESTAMP:
				if (p_val != null) {
					MCTimestampFormat tf = getCellTimestampFormat(p_col, v_col);
					String tp = input 
							? tf.getInputPattern() : tf.getOutputPattern();
					return ((MCTimestamp) p_val).toString(tp);
				}
				return input ? null : getCellTimestampFormat(
						p_col, v_col).getOutputBlank();
			case BOOLEAN:
				return convBooleanToString((Boolean)p_val);
//				return String.valueOf(p_val);
			default:
				return null;	
		}
	}
	
	/**
	 * 件数を設定します。
	 */
	protected void setRowCnt() {
		setValueEx(Btm_fr, new MCNumber(
				_par_list.size() > 0 ? _crnt_min + 1 : 0));
		setValueEx(Btm_to, new MCNumber(
				_crnt_max < _par_list.size() ? _crnt_max : _par_list.size()));
		setValueEx(Btm_cnt, new MCNumber(
				_par_list.size()));
	}
		
	/**
	 * 親テーブルのデータを縦表示テーブルに反映します。
	 * 
	 * @param p_col 親テーブルのテーブルカラム
	 * @param p_row 親テーブルの行
	 */
	protected void convByParColumnConfig(MCColumnConfig p_col, MCRow p_row) {
		MCColumnConfig vc = getViewColumnConfig(p_row);
		ViewR vo = getViewRow(p_col.getBaseRowColumnName());
		
		String v = toViewData(p_col.getValue(p_row.getGUIIndex()), p_col, vc);
		setValueInConv(vc, vo.getGUIIndex(), v);
	}
	
	/**
	 * 縦表示テーブルのデータを親テーブルのデータ型に変換します。
	 * 
	 * @param v_val 縦表示テーブルのデータ
	 * @param p_col 親テーブルのテーブルカラム
	 * @param v_col 縦表示テーブルのテーブルカラム
	 * @return 親テーブルのデータ型に変換されたデータ
	 */
	protected Comparable<?> toParData(
			String v_val, MCColumnConfig p_col, MCColumnConfig v_col) {
		// データとデータ型に従ってStringに変換する
		MCDataType py = p_col.getDataType();
		if (py == null) {
			return null;
		}
		switch (py) {
			case STRING:
				return v_val;
			case NUMBER:
				if (v_val == null) {
					return null;
				}
				return MCNumber.valueOf(v_val);
			case DATE:
				if (v_val == null) {
					return null;
				}
				
				MCDateFormat df = getCellDateFormat(p_col, v_col);
				return df.doInputParse(v_val);
//				return MCDate.valueOf(v_val, getCellDateFormat(
//						p_col, v_col).getInputPattern());
			case TIMESTAMP:
				if (v_val == null) {
					return null;
				}
				
				MCTimestampFormat tf = getCellTimestampFormat(p_col, v_col);
				return tf.doInputParse(v_val);
//				return MCTimestamp.valueOf(v_val, getCellTimestampFormat(
//						p_col, v_col).getInputPattern());
			case BOOLEAN:
				return convStringToBoolean(v_val);
//				return Boolean.valueOf(v_val).booleanValue();
			default:
				return null;
		}
	}
	
	/**
	 * 親テーブルのセルの小数点以下の桁数を返します。
	 *
	 * @param p_col 親テーブルのテーブルカラム
	 * @param v_col 縦表示テーブルのテーブルカラム
	 * @param input 入力用の場合は true、表示用の場合は false
	 * @return 親テーブルのセルの小数点以下の桁数
	 */
	protected int getCellScale(
			MCColumnConfig p_col, MCColumnConfig v_col, boolean input) {
		MCRow po = getParRow(v_col);
		FXBAP_CellConfig pf = (FXBAP_CellConfig) p_col.getCellConfig();
		return input 
				? pf.getCellScale(po.getGUIIndex(), p_col, p_col.getTable()) 
				: pf.getCellViewScale(po.getGUIIndex(), p_col, p_col.getTable());
	}
	
	/**
	 * 親テーブルのセルの数値フォーマットを返します。
	 * 
	 * @param p_col 親テーブルのテーブルカラム
	 * @param v_col 縦表示テーブルのテーブルカラム
	 * @return 親テーブルのセルの数値フォーマット
	 */
	protected MCNumberFormat getCellNumberFormat(
			MCColumnConfig p_col, MCColumnConfig v_col) {
		MCRow po = getParRow(v_col);
		FXBAP_CellConfig pf = (FXBAP_CellConfig)p_col.getCellConfig();
		int pi = po.getGUIIndex();
		MCTable<?> pt = p_col.getTable();
		return pf.getCellNumberFormat(
				pi, p_col, pt, pf.isCellEditable(pi, p_col, pt));
	}

	/**
	 * 親テーブルのセルの日付フォーマットを返します。
	 *
	 * @param p_col 親テーブルのテーブルカラム
	 * @param v_col 縦表示テーブルのテーブルカラム
	 * @return 親テーブルのセルの日付フォーマット
	 */
	protected MCDateFormat getCellDateFormat(
			MCColumnConfig p_col, MCColumnConfig v_col) {
		MCRow po = getParRow(v_col);
		FXBAP_CellConfig pf = (FXBAP_CellConfig) p_col.getCellConfig();
		int pi = po.getGUIIndex();
		MCTable<?> pt = p_col.getTable();
		return pf.getCellDateFormat(
				pi, p_col, pt, pf.isCellEditable(pi, p_col, pt));
	}
	
	/**
	 * 親テーブルのセルの日付フォーマットを返します。
	 *
	 * @param p_col 親テーブルのテーブルカラム
	 * @param v_col 縦表示テーブルのテーブルカラム
	 * @return 親テーブルのセルの日付フォーマット
	 */
	protected MCTimestampFormat getCellTimestampFormat(
			MCColumnConfig p_col, MCColumnConfig v_col) {
		MCRow po = getParRow(v_col);
		FXBAP_CellConfig pf = (FXBAP_CellConfig) p_col.getCellConfig();
		int pi = po.getGUIIndex();
		MCTable<?> pt = p_col.getTable();
		return pf.getCellTimestampFormat(
				pi, p_col, pt, pf.isCellEditable(pi, p_col, pt));
	}
	
	/**
	 * 親テーブルのステータスカラムの背景色を返します。
	 *
	 * @param v_col 縦表示テーブルのテーブルカラム
	 * @return 親テーブルのステータスカラムの背景色
	 */
	protected Color getStatusCellBackground(MCColumnConfig v_col) {
		if (!_par_table.getStatusColumn().isVisible()) {
			return null;
		}
		
		MCRow po = getParRow(v_col);
		FXBAP_CellConfig pf = (FXBAP_CellConfig) _par_table.getCellConfig();
		return pf.getStatusColumnBackground(
				po.getGUIIndex(), _par_table.getStatusColumn(), 
				_par_table, false, po.getStatus());
	}
	
	/**
	 * 親テーブルのステータスカラムの文字の色を返します。
	 *
	 * @param v_col 縦表示テーブルのテーブルカラム
	 * @return 親テーブルのステータスカラムの文字の色
	 */
	protected Color getStatusCellForeground(MCColumnConfig v_col) {
		if (!_par_table.getStatusColumn().isVisible()) {
			return null;
		}
		
		MCRow po = getParRow(v_col);
		FXBAP_CellConfig pf = (FXBAP_CellConfig) _par_table.getCellConfig();
		return pf.getStatusColumnForeground(
				po.getGUIIndex(), _par_table.getStatusColumn(), 
				_par_table, false, po.getStatus());
	}

	/**
	 * 親テーブルの行から対応する縦表示テーブルのテーブルカラムを取得します。
	 * 
	 * @param p_row 親テーブルの行
	 * @return 縦表示テーブルのテーブルカラム
	 */
	protected MCColumnConfig getViewColumnConfig(MCRow p_row) {
		MCNumber fr = getBtmR().fr();
		MCNumber to = getBtmR().to();
		int pi = p_row.getGUIIndex() + 1;
		
		if (isNullOr(fr, to) || fr.gt(pi) || to.lt(pi)) {
			return null;
		}
		
		for (MCColumnConfig vc : ViewTable.getColumnConfigs()) {
			if (!isDataColumn(vc)) {
				continue;
			}
			if (pi == Integer.parseInt(vc.getHeaderName())) {
				return vc;
			}
		}
		return null;
	}
	
	/**
	 * 親テーブルのテーブルカラムに対応する縦表示テーブルの行を取得します。
	 * 
	 * @param p_bo_col_nm 親テーブルのテーブルカラムの {@link MCColumnConfig#getBaseRowColumnName()}
	 * @return 縦表示テーブルの行
	 */
	protected ViewR getViewRow(String p_bo_col_nm) {
		return getViewL().getFirst(ViewR.$par_col_nm, p_bo_col_nm);
	}
	
	/**
	 * 縦表示の行に対応する親テーブルのテーブルカラムを取得します。
	 * 
	 * @param v_idx 縦表示の行のインデックス値
	 * @return 親テーブルのテーブルカラム
	 */
	protected MCColumnConfig getParColumnConfig(int v_idx) {
		return _par_table.getColumnConfig(
				getViewL().get(v_idx).par_col_idx().intValue());
	}
	
	/**
	 * 縦表示列に対応した親テーブルの行を取得する
	 * 
	 * @param v_col 縦表示テーブルのカラムコンフィグ 
	 * @return 縦表示列に対応した親テーブルの行
	 */
	protected MCRow getParRow(MCColumnConfig v_col) {
		if (!isDataColumn(v_col)) {
			return null;
		}
		
		if (v_col.getModeInfo().getStatus() == MCMode.INVISIBLE_STATUS) {
			return null;
		}
		
		return _par_list.get(Integer.parseInt(v_col.getHeaderName()) - 1);
	}

	/**
	 * 縦表示テーブルに設定するセルコンフィグを作成します。
	 * 
	 * @return セルコンフィグ
	 */
	protected MCCellConfig createViewTableCellConfig() {
		return new ViewTableCellConfig();
	}
	
	/**
	 * 縦表示テーブルに設定するセルコンフィグです。
	 */
	protected class ViewTableCellConfig extends FXBAP_CellConfig {
		
		@Override
		public Color getPriorFG(
				int index, MCColumnConfig column, MCTable table, MCMode mode) {
			// タイトル列
			if (isTitleColumn(column)) {
				return getParColumnConfig(index).getHeaderForeground();
			}
			
			// 選択した行と親テーブルの行が一致しない場合
			// 親テーブルの状況が変わっているため色はデフォルト
			MCRow po = getParRow(column);
			if (_par_table.getRow(po.getGUIIndex()) != po) {
				return super.getPriorFG(index, column, table, mode);
			}
			
			MCColumnConfig pc = getParColumnConfig(index);
			FXBAP_CellConfig pf = (FXBAP_CellConfig) pc.getCellConfig();
			int pi = po.getGUIIndex();
			MCTable<?> pt = pc.getTable();
			return pf.getCellForeground(
					pi, pc, pt, false, pf.isCellEditable(pi, pc, pt));
		}
		
		@Override
		public Color getPriorBG(
				int index, MCColumnConfig column, MCTable table, MCMode mode) {
			// タイトル列
			if (isTitleColumn(column)) {
				return getParColumnConfig(index).getHeaderBackground();
			}
			
			// 選択した行と親テーブルの行が一致しない場合は
			// 親テーブルの状況が変わっているため色はデフォルト
			MCRow po = getParRow(column);
			if (_par_table.getRow(po.getGUIIndex()) != po) {
				return super.getPriorBG(index, column, table, mode);
			}
			
			MCColumnConfig pc = getParColumnConfig(index);
			FXBAP_CellConfig pf = (FXBAP_CellConfig) pc.getCellConfig();
			int pi = po.getGUIIndex();
			MCTable<?> pt = pc.getTable();			
			return pf.getCellBackground(
					pi, pc, pt, false, pf.isCellEditable(pi, pc, pt));
		}
		
		@Override
		public MCMode getPriorMode(
				int index, MCColumnConfig column, MCTable table) {
			// 入力モードではない場合は入力不可
			if (!getBtmR().input()) {
				return super.getPriorMode(index, column, table);
			}
			// タイトル列
			if (isTitleColumn(column)) {
				return super.getPriorMode(index, column, table);
			}
			
			// 選択した行と親テーブルの行が一致しない場合
			// 親テーブルの状況が変わっているため色はデフォルト
			MCRow po = getParRow(column);
			if (_par_table.getRow(po.getGUIIndex()) != po) {
				return super.getPriorMode(index, column, table);
			}
			
			MCColumnConfig pc = getParColumnConfig(index);
			
			// パスワード、イメージビュー、ボタンは入力（押下）可能にしない
			MCColumnType py = pc.getColumnType();
			if (py == MCColumnType.PASSWORD 
					|| py == MCColumnType.IMAGE_VIEW) {
				return super.getPriorMode(index, column, table);
			}
			
			FXBAP_CellConfig pf = (FXBAP_CellConfig) pc.getCellConfig();
			return pf.isCellEditable(po.getGUIIndex(), pc, pc.getTable());
		}
	}
	
	/**
	 * 親テーブルのコンテナに設定するリストリスナを返します。
	 * 
	 * @return リストリスナ
	 */
	protected ParListListener getParListListener() {
		if (_par_list_listener != null) {
			return _par_list_listener;
		}
		
		_par_list_listener = new ParListListener();
		_par_list_listener.addRowListener(getParRowListener());
		
		return _par_list_listener;
	}

	/**
	 * 親テーブルのコンテナに対するリスナークラス<br>
	 * 行追加・行削除のたびにデータをリフレッシュする<br>
	 * そのため大量のデータを扱う画面で簡易入力モードで行追加・削除する場合はパフォーマンスが悪くなる
	 *
	 */
	protected class ParListListener extends FXBAP_ListListener {
		
		@Override
		public void rowAdded(MCListEvent event) {
			super.rowAdded(event);
			
			convByListEvent(event);
		}

		@Override
		public void rowRemoved(MCListEvent[] events) {
			super.rowRemoved(events);
			
			convByListEvent(events);
		}

		@Override
		public void rowRemoved(MCListEvent event) {
			super.rowRemoved(event);
			
			convByListEvent(event);
		}
		
		@Override
		public void listSorted(MCListEvent event) {
			super.listSorted(event);
			
			convByListEvent(event);
		}
		
		@Override
		public void listCleared(MCListEvent event) {
			super.listSorted(event);
			
			convByListEvent(event);
		}
		
		@Override
		public void rowSet(MCListEvent event) {
			super.rowSet(event);
			
			convByListEvent(event);
		}
		
		/**
		 * 親テーブルのデータを縦表示テーブルに反映します。
		 *
		 * @param event リストイベント
		 */
		protected void convByListEvent(MCListEvent event) {
			// ソート等の条件をクリア
			_par_list.setAll((MCList)event.getSourceList());
			
			// 行数表示の初期化
			initRowCntCnd();
			
			// 再縦表示（入力モードも変更される）
			conv();
		}
		
		/**
		 * 親テーブルのデータを縦表示テーブルに反映します。
		 *
		 * @param event リストイベント
		 */
		protected void convByListEvent(MCListEvent[] events) {
			// ソート等の条件をクリア
			_par_list.setAll((MCList)events[0].getSourceList());
			
			// 行数表示の初期化
			initRowCntCnd();
			
			// 再縦表示（入力モードも変更される）
			conv();
		}
	}

	/**
	 * 親テーブルのコンテナに設定するロウリスナを返します。
	 *
	 * @return ロウリスナ
	 */
	protected FXBAP_RowListener getParRowListener() {
		return _par_row_listener != null 
				? _par_row_listener 
				: (_par_row_listener = new ParRowListener());
	}

	/**
	 * 親テーブルのコンテナに設定するロウリスナです。
	 */
	protected class ParRowListener extends FXBAP_RowListener {
		
		@Override
		public void valueChanged(MCRowEvent event) {
			super.valueChanged(event);
			
			// イベントが発生した値を縦表示テーブルに反映する
			ViewR o = getViewRow(event.getColumn());
			if (o == null) {
				return;
			}
			
			MCColumnConfig pc = _par_table.getColumnConfig(
					o.par_col_idx().intValue());
			convByParColumnConfig(pc, event.getSourceRow());
		}
		
		@Override
		public void statusChanged(MCRowStatusEvent event) {
			super.statusChanged(event);
			
			MCColumnConfig vc = getViewColumnConfig(event.getSourceRow());
			vc.setHeaderBackground(getStatusCellBackground(vc));
			vc.setHeaderForeground(getStatusCellForeground(vc));
		}
	}

	@Override
	protected void tableInit() {
		
		super.tableInit();
		ViewTable.setSortable(false);
		ViewTable.setReorderingAllowed(false);
		
		// トリムの設定は親画面に任せるため本画面では全てオフにする
		for (MCColumnConfig conf : ViewTable.getColumnConfigs()) {
			conf.setTrimPattern(MCBeansConsts.TRIM_NONE);
		}
	
	}
	
	@Override
	protected void setCellConfig() {
		super.setCellConfig();
		
		ViewTable.setCellConfig(createViewTableCellConfig());
	}

	@Override
	protected FXBAP_PopupConfig createFXBAP_PopupConfig(MCPopupBeans beans) {
		return new VerticalViewPopupConfig();
	}
	
	/**
	 * 縦表示テーブルに設定するポップアップコンフィグです。
	 */
	protected class VerticalViewPopupConfig extends FSUCP_PopupConfig {
		
		/**
		 * コンストラクタです。
		 */
		public VerticalViewPopupConfig() {
			super(null);
		}

		@Override
		protected void customPopup(MCPopupMenu menu, MCTable table) {
			super.customPopup(menu, table);
			
			MCPopupMenu pm = _par_table.configurePopup();
			MenuElement[] pse = pm.getSubElements();
			
			// 親テーブルのファイル入出力の設定に合わせてポップアップ表示を調整する
			if (!isVisible(pse, _par_table.getFileIOMenu())) {
				menu.removeMenu(table.getFileIOMenu());
			}
			else {
				if (!isVisible(pse, _par_table.getExcelOutMenuItem())) {
					menu.removeMenuItem(table.getExcelOutMenuItem());
				}
				if (!isVisible(pse, _par_table.getExcelOutSelectMenuItem())) {
					menu.removeMenuItem(table.getExcelOutSelectMenuItem());
				}
				if (!isVisible(pse, _par_table.getExcelOpenMenuItem())) {
					menu.removeMenuItem(table.getExcelOpenMenuItem());
				}
				if (!isVisible(pse, _par_table.getExcelOpenSelectMenuItem())) {
					menu.removeMenuItem(table.getExcelOpenSelectMenuItem());
				}
				if (!isVisible(pse, _par_table.getCSVOutMenuItem())) {
					menu.removeMenuItem(table.getCSVOutMenuItem());
				}
				if (!isVisible(pse, _par_table.getCSVOutSelectMenuItem())) {
					menu.removeMenuItem(table.getCSVOutSelectMenuItem());
				}
			}
		}

		@Override
		protected boolean ignorePanelFileIO() {
			return true;
		}

		@Override
		protected boolean ignorePanelVerticalView(MCRootPanel pnl) {
			return true;
		}

		@Override
		protected boolean ignoreTableVerticalView(MCTable<?> tbl) {
			return true;
		}

		@Override
		protected boolean ignoreSortOrder() {
			return true;
		}

		@Override
		protected boolean ignoreTableSort() {
			return true;
		}

		@Override
		protected boolean ignoreRowFilter() {
			return true;
		}

		@Override
		protected boolean ignoreSrchCnd(MCRootPanel panel) {
			return true;
		}

		@Override
		protected boolean ignoreSumInfo() {
			return true;
		}

		@Override
		protected boolean ignoreColumnWidth() {
			return true;
		}
		
	}
	
	/**
	 * itm に指定されたオブジェクトを elms が含み、かつ表示されているかどうかをチェックする
	 * 
	 * @param elms メニューの構成要素の配列
	 * @param itm メニューの構成要素
	 * @return itm が elms に含まれ、かつ表示されている場合はtrue
	 */
	protected boolean isVisible(MenuElement[] elms, Object itm) {
		if (contains(elms, itm)) {
			if (itm instanceof MCPopupMenuItem) {
				return ((MCPopupMenuItem)itm).isVisible();
			}
			if (itm instanceof MCMenu) {
				return ((MCMenu)itm).isVisible();
			}
		}
		return false;
	}
	
	/**
	 * itm に指定されたオブジェクトを elms が含むかどうかをチェックする
	 * 
	 * @param elms メニューの構成要素の配列
	 * @param itm メニューの構成要素
	 * @return itm が elms に含まれる場合はtrue
	 */
	protected boolean contains(MenuElement[] elms, Object itm) {
		if (elms == null) {
			return false;
		}
		
		for (MenuElement elm : elms) {
			if (elm == itm) {
				return true;
			}
			else if (elm instanceof JPopupMenu) {
				if (contains(((JPopupMenu)elm).getSubElements(), itm)) {
					return true;
				}
			}
			else if (elm instanceof JMenu) {
				if (contains(((JMenu)elm).getSubElements(), itm)) {
					return true;
				}
			}
		}
		return false;
	}
	
	@Override
	public boolean screenClear() {
		// 画面クリアを無効にする
		return false;
	}
	
	@Override
	public boolean beforeClose() {
		if (!super.beforeClose()) {
			return false;
		}
		
		removeParRowListener();
		return true;
	}

	@Override
	protected void listInit() {
		super.listInit();
		
		Btm_h_align_type_nm.setListVisibleColumn(BtmR.$h_align_type_nm);
	}

	@Override
	public void doBtm_h_align_type_LC(MCEventInfo info) {
		super.doBtm_h_align_type_LC(info);

		int ha = MCColumnConfig.LEFT;
		String v = getBtmR().h_align_type();
		if (FSC_H_ALIGN_TYPE.isTYPE_LEFT(v)) {
			ha = MCColumnConfig.LEFT;
		}
		else if (FSC_H_ALIGN_TYPE.isTYPE_CENTER(v)) {
			ha = MCColumnConfig.CENTER;
		}
		else if (FSC_H_ALIGN_TYPE.isTYPE_RIGHT(v)) {
			ha = MCColumnConfig.RIGHT;
		}
		
		for (MCColumnConfig c : ViewTable.getViewColumnConfigs()) {
			if (isDataColumn(c)) {
				c.setHorizontalAlignment(ha);
			}
		}
	}
	
	/**
	 * チェックボックスの値の表現方法を返します。
	 *
	 * @return チェックボックスの値の表現方法
	 */
	protected int getBooleanType() {
		String pfx = "BooleanType";
		for (String[] msa : getModuleAndScreenIDs()) {
			String k = MCConst.createKey(msa[0], msa[1], pfx);
			if (MCConst.app.containsKey(k)) {
				return MCConst.app.getInteger(k, BOOLEAN_TYPE_1_0);
			}
		}
		return BOOLEAN_TYPE_1_0;
	}

	/**
	 * チェックボックス項目の値を String から boolean に変換します。
	 *
	 * @param value チェックボックス項目の値（String）
	 * @return チェックボックス項目の値（boolean）
	 */
	protected boolean convStringToBoolean(String value) {
		switch (getBooleanType()) {
			case BOOLEAN_TYPE_TRUE_FALSE:
				return Boolean.TRUE.toString().equals(value);
			default:
				return "1".equals(value);
		}
	}
	
	/**
	 * チェックボックス項目の値を boolean から String に変換します。
	 * 
	 * @param value チェックボックス項目の値（boolean）
	 * @return チェックボックス項目の値（String）
	 */
	protected String convBooleanToString(boolean value) {
		switch (getBooleanType()) {
			case BOOLEAN_TYPE_TRUE_FALSE:
				return Boolean.toString(value);
			default:
				return value ? "1" : "0";
		}
	}

}