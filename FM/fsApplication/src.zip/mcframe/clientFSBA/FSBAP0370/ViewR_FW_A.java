package mcframe.clientFSBA.FSBAP0370;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"View"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class ViewR_FW_A extends MCConstRow {

	/**
	 *  項目.<p>
	 *
	 */
	public static final String $title = "title";
	/**
	 *  1.<p>
	 *
	 */
	public static final String $data1 = "data1";
	/**
	 *  2.<p>
	 *
	 */
	public static final String $data2 = "data2";
	/**
	 *  3.<p>
	 *
	 */
	public static final String $data3 = "data3";
	/**
	 *  4.<p>
	 *
	 */
	public static final String $data4 = "data4";
	/**
	 *  5.<p>
	 *
	 */
	public static final String $data5 = "data5";
	/**
	 *  6.<p>
	 *
	 */
	public static final String $data6 = "data6";
	/**
	 *  7.<p>
	 *
	 */
	public static final String $data7 = "data7";
	/**
	 *  8.<p>
	 *
	 */
	public static final String $data8 = "data8";
	/**
	 *  9.<p>
	 *
	 */
	public static final String $data9 = "data9";
	/**
	 *  10.<p>
	 *
	 */
	public static final String $data10 = "data10";
	/**
	 *  11.<p>
	 *
	 */
	public static final String $data11 = "data11";
	/**
	 *  12.<p>
	 *
	 */
	public static final String $data12 = "data12";
	/**
	 *  13.<p>
	 *
	 */
	public static final String $data13 = "data13";
	/**
	 *  14.<p>
	 *
	 */
	public static final String $data14 = "data14";
	/**
	 *  15.<p>
	 *
	 */
	public static final String $data15 = "data15";
	/**
	 *  16.<p>
	 *
	 */
	public static final String $data16 = "data16";
	/**
	 *  17.<p>
	 *
	 */
	public static final String $data17 = "data17";
	/**
	 *  18.<p>
	 *
	 */
	public static final String $data18 = "data18";
	/**
	 *  19.<p>
	 *
	 */
	public static final String $data19 = "data19";
	/**
	 *  20.<p>
	 *
	 */
	public static final String $data20 = "data20";
	/**
	 *  21.<p>
	 *
	 */
	public static final String $data21 = "data21";
	/**
	 *  22.<p>
	 *
	 */
	public static final String $data22 = "data22";
	/**
	 *  23.<p>
	 *
	 */
	public static final String $data23 = "data23";
	/**
	 *  24.<p>
	 *
	 */
	public static final String $data24 = "data24";
	/**
	 *  25.<p>
	 *
	 */
	public static final String $data25 = "data25";
	/**
	 *  26.<p>
	 *
	 */
	public static final String $data26 = "data26";
	/**
	 *  27.<p>
	 *
	 */
	public static final String $data27 = "data27";
	/**
	 *  28.<p>
	 *
	 */
	public static final String $data28 = "data28";
	/**
	 *  29.<p>
	 *
	 */
	public static final String $data29 = "data29";
	/**
	 *  30.<p>
	 *
	 */
	public static final String $data30 = "data30";
	/**
	 *  31.<p>
	 *
	 */
	public static final String $data31 = "data31";
	/**
	 *  32.<p>
	 *
	 */
	public static final String $data32 = "data32";
	/**
	 *  33.<p>
	 *
	 */
	public static final String $data33 = "data33";
	/**
	 *  34.<p>
	 *
	 */
	public static final String $data34 = "data34";
	/**
	 *  35.<p>
	 *
	 */
	public static final String $data35 = "data35";
	/**
	 *  36.<p>
	 *
	 */
	public static final String $data36 = "data36";
	/**
	 *  37.<p>
	 *
	 */
	public static final String $data37 = "data37";
	/**
	 *  38.<p>
	 *
	 */
	public static final String $data38 = "data38";
	/**
	 *  39.<p>
	 *
	 */
	public static final String $data39 = "data39";
	/**
	 *  40.<p>
	 *
	 */
	public static final String $data40 = "data40";
	/**
	 *  41.<p>
	 *
	 */
	public static final String $data41 = "data41";
	/**
	 *  42.<p>
	 *
	 */
	public static final String $data42 = "data42";
	/**
	 *  43.<p>
	 *
	 */
	public static final String $data43 = "data43";
	/**
	 *  44.<p>
	 *
	 */
	public static final String $data44 = "data44";
	/**
	 *  45.<p>
	 *
	 */
	public static final String $data45 = "data45";
	/**
	 *  46.<p>
	 *
	 */
	public static final String $data46 = "data46";
	/**
	 *  47.<p>
	 *
	 */
	public static final String $data47 = "data47";
	/**
	 *  48.<p>
	 *
	 */
	public static final String $data48 = "data48";
	/**
	 *  49.<p>
	 *
	 */
	public static final String $data49 = "data49";
	/**
	 *  50.<p>
	 *
	 */
	public static final String $data50 = "data50";
	/**
	 *  51.<p>
	 *
	 */
	public static final String $data51 = "data51";
	/**
	 *  52.<p>
	 *
	 */
	public static final String $data52 = "data52";
	/**
	 *  53.<p>
	 *
	 */
	public static final String $data53 = "data53";
	/**
	 *  54.<p>
	 *
	 */
	public static final String $data54 = "data54";
	/**
	 *  55.<p>
	 *
	 */
	public static final String $data55 = "data55";
	/**
	 *  56.<p>
	 *
	 */
	public static final String $data56 = "data56";
	/**
	 *  57.<p>
	 *
	 */
	public static final String $data57 = "data57";
	/**
	 *  58.<p>
	 *
	 */
	public static final String $data58 = "data58";
	/**
	 *  59.<p>
	 *
	 */
	public static final String $data59 = "data59";
	/**
	 *  60.<p>
	 *
	 */
	public static final String $data60 = "data60";
	/**
	 *  61.<p>
	 *
	 */
	public static final String $data61 = "data61";
	/**
	 *  62.<p>
	 *
	 */
	public static final String $data62 = "data62";
	/**
	 *  63.<p>
	 *
	 */
	public static final String $data63 = "data63";
	/**
	 *  64.<p>
	 *
	 */
	public static final String $data64 = "data64";
	/**
	 *  65.<p>
	 *
	 */
	public static final String $data65 = "data65";
	/**
	 *  66.<p>
	 *
	 */
	public static final String $data66 = "data66";
	/**
	 *  67.<p>
	 *
	 */
	public static final String $data67 = "data67";
	/**
	 *  68.<p>
	 *
	 */
	public static final String $data68 = "data68";
	/**
	 *  69.<p>
	 *
	 */
	public static final String $data69 = "data69";
	/**
	 *  70.<p>
	 *
	 */
	public static final String $data70 = "data70";
	/**
	 *  71.<p>
	 *
	 */
	public static final String $data71 = "data71";
	/**
	 *  72.<p>
	 *
	 */
	public static final String $data72 = "data72";
	/**
	 *  73.<p>
	 *
	 */
	public static final String $data73 = "data73";
	/**
	 *  74.<p>
	 *
	 */
	public static final String $data74 = "data74";
	/**
	 *  75.<p>
	 *
	 */
	public static final String $data75 = "data75";
	/**
	 *  76.<p>
	 *
	 */
	public static final String $data76 = "data76";
	/**
	 *  77.<p>
	 *
	 */
	public static final String $data77 = "data77";
	/**
	 *  78.<p>
	 *
	 */
	public static final String $data78 = "data78";
	/**
	 *  79.<p>
	 *
	 */
	public static final String $data79 = "data79";
	/**
	 *  80.<p>
	 *
	 */
	public static final String $data80 = "data80";
	/**
	 *  81.<p>
	 *
	 */
	public static final String $data81 = "data81";
	/**
	 *  82.<p>
	 *
	 */
	public static final String $data82 = "data82";
	/**
	 *  83.<p>
	 *
	 */
	public static final String $data83 = "data83";
	/**
	 *  84.<p>
	 *
	 */
	public static final String $data84 = "data84";
	/**
	 *  85.<p>
	 *
	 */
	public static final String $data85 = "data85";
	/**
	 *  86.<p>
	 *
	 */
	public static final String $data86 = "data86";
	/**
	 *  87.<p>
	 *
	 */
	public static final String $data87 = "data87";
	/**
	 *  88.<p>
	 *
	 */
	public static final String $data88 = "data88";
	/**
	 *  89.<p>
	 *
	 */
	public static final String $data89 = "data89";
	/**
	 *  90.<p>
	 *
	 */
	public static final String $data90 = "data90";
	/**
	 *  91.<p>
	 *
	 */
	public static final String $data91 = "data91";
	/**
	 *  92.<p>
	 *
	 */
	public static final String $data92 = "data92";
	/**
	 *  93.<p>
	 *
	 */
	public static final String $data93 = "data93";
	/**
	 *  94.<p>
	 *
	 */
	public static final String $data94 = "data94";
	/**
	 *  95.<p>
	 *
	 */
	public static final String $data95 = "data95";
	/**
	 *  96.<p>
	 *
	 */
	public static final String $data96 = "data96";
	/**
	 *  97.<p>
	 *
	 */
	public static final String $data97 = "data97";
	/**
	 *  98.<p>
	 *
	 */
	public static final String $data98 = "data98";
	/**
	 *  99.<p>
	 *
	 */
	public static final String $data99 = "data99";
	/**
	 *  100.<p>
	 *
	 */
	public static final String $data100 = "data100";
	/**
	 *  データ型.<p>
	 *
	 */
	public static final String $dat_typ = "dat_typ";
	/**
	 *  親カラム名.<p>
	 *
	 */
	public static final String $par_col_nm = "par_col_nm";
	/**
	 *  親カラムインデックス.<p>
	 *
	 */
	public static final String $par_col_idx = "par_col_idx";


	public static final MCMeta title_META = createStringMeta($title);
	public static final MCMeta data1_META = createStringMeta($data1);
	public static final MCMeta data2_META = createStringMeta($data2);
	public static final MCMeta data3_META = createStringMeta($data3);
	public static final MCMeta data4_META = createStringMeta($data4);
	public static final MCMeta data5_META = createStringMeta($data5);
	public static final MCMeta data6_META = createStringMeta($data6);
	public static final MCMeta data7_META = createStringMeta($data7);
	public static final MCMeta data8_META = createStringMeta($data8);
	public static final MCMeta data9_META = createStringMeta($data9);
	public static final MCMeta data10_META = createStringMeta($data10);
	public static final MCMeta data11_META = createStringMeta($data11);
	public static final MCMeta data12_META = createStringMeta($data12);
	public static final MCMeta data13_META = createStringMeta($data13);
	public static final MCMeta data14_META = createStringMeta($data14);
	public static final MCMeta data15_META = createStringMeta($data15);
	public static final MCMeta data16_META = createStringMeta($data16);
	public static final MCMeta data17_META = createStringMeta($data17);
	public static final MCMeta data18_META = createStringMeta($data18);
	public static final MCMeta data19_META = createStringMeta($data19);
	public static final MCMeta data20_META = createStringMeta($data20);
	public static final MCMeta data21_META = createStringMeta($data21);
	public static final MCMeta data22_META = createStringMeta($data22);
	public static final MCMeta data23_META = createStringMeta($data23);
	public static final MCMeta data24_META = createStringMeta($data24);
	public static final MCMeta data25_META = createStringMeta($data25);
	public static final MCMeta data26_META = createStringMeta($data26);
	public static final MCMeta data27_META = createStringMeta($data27);
	public static final MCMeta data28_META = createStringMeta($data28);
	public static final MCMeta data29_META = createStringMeta($data29);
	public static final MCMeta data30_META = createStringMeta($data30);
	public static final MCMeta data31_META = createStringMeta($data31);
	public static final MCMeta data32_META = createStringMeta($data32);
	public static final MCMeta data33_META = createStringMeta($data33);
	public static final MCMeta data34_META = createStringMeta($data34);
	public static final MCMeta data35_META = createStringMeta($data35);
	public static final MCMeta data36_META = createStringMeta($data36);
	public static final MCMeta data37_META = createStringMeta($data37);
	public static final MCMeta data38_META = createStringMeta($data38);
	public static final MCMeta data39_META = createStringMeta($data39);
	public static final MCMeta data40_META = createStringMeta($data40);
	public static final MCMeta data41_META = createStringMeta($data41);
	public static final MCMeta data42_META = createStringMeta($data42);
	public static final MCMeta data43_META = createStringMeta($data43);
	public static final MCMeta data44_META = createStringMeta($data44);
	public static final MCMeta data45_META = createStringMeta($data45);
	public static final MCMeta data46_META = createStringMeta($data46);
	public static final MCMeta data47_META = createStringMeta($data47);
	public static final MCMeta data48_META = createStringMeta($data48);
	public static final MCMeta data49_META = createStringMeta($data49);
	public static final MCMeta data50_META = createStringMeta($data50);
	public static final MCMeta data51_META = createStringMeta($data51);
	public static final MCMeta data52_META = createStringMeta($data52);
	public static final MCMeta data53_META = createStringMeta($data53);
	public static final MCMeta data54_META = createStringMeta($data54);
	public static final MCMeta data55_META = createStringMeta($data55);
	public static final MCMeta data56_META = createStringMeta($data56);
	public static final MCMeta data57_META = createStringMeta($data57);
	public static final MCMeta data58_META = createStringMeta($data58);
	public static final MCMeta data59_META = createStringMeta($data59);
	public static final MCMeta data60_META = createStringMeta($data60);
	public static final MCMeta data61_META = createStringMeta($data61);
	public static final MCMeta data62_META = createStringMeta($data62);
	public static final MCMeta data63_META = createStringMeta($data63);
	public static final MCMeta data64_META = createStringMeta($data64);
	public static final MCMeta data65_META = createStringMeta($data65);
	public static final MCMeta data66_META = createStringMeta($data66);
	public static final MCMeta data67_META = createStringMeta($data67);
	public static final MCMeta data68_META = createStringMeta($data68);
	public static final MCMeta data69_META = createStringMeta($data69);
	public static final MCMeta data70_META = createStringMeta($data70);
	public static final MCMeta data71_META = createStringMeta($data71);
	public static final MCMeta data72_META = createStringMeta($data72);
	public static final MCMeta data73_META = createStringMeta($data73);
	public static final MCMeta data74_META = createStringMeta($data74);
	public static final MCMeta data75_META = createStringMeta($data75);
	public static final MCMeta data76_META = createStringMeta($data76);
	public static final MCMeta data77_META = createStringMeta($data77);
	public static final MCMeta data78_META = createStringMeta($data78);
	public static final MCMeta data79_META = createStringMeta($data79);
	public static final MCMeta data80_META = createStringMeta($data80);
	public static final MCMeta data81_META = createStringMeta($data81);
	public static final MCMeta data82_META = createStringMeta($data82);
	public static final MCMeta data83_META = createStringMeta($data83);
	public static final MCMeta data84_META = createStringMeta($data84);
	public static final MCMeta data85_META = createStringMeta($data85);
	public static final MCMeta data86_META = createStringMeta($data86);
	public static final MCMeta data87_META = createStringMeta($data87);
	public static final MCMeta data88_META = createStringMeta($data88);
	public static final MCMeta data89_META = createStringMeta($data89);
	public static final MCMeta data90_META = createStringMeta($data90);
	public static final MCMeta data91_META = createStringMeta($data91);
	public static final MCMeta data92_META = createStringMeta($data92);
	public static final MCMeta data93_META = createStringMeta($data93);
	public static final MCMeta data94_META = createStringMeta($data94);
	public static final MCMeta data95_META = createStringMeta($data95);
	public static final MCMeta data96_META = createStringMeta($data96);
	public static final MCMeta data97_META = createStringMeta($data97);
	public static final MCMeta data98_META = createStringMeta($data98);
	public static final MCMeta data99_META = createStringMeta($data99);
	public static final MCMeta data100_META = createStringMeta($data100);
	public static final MCMeta dat_typ_META = createStringMeta($dat_typ);
	public static final MCMeta par_col_nm_META = createStringMeta($par_col_nm);
	public static final MCMeta par_col_idx_META = createNumberMeta($par_col_idx);

	protected static final ConstMetaList<ViewR> constMetas = new ConstMetaList<ViewR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			title_META,
			data1_META,
			data2_META,
			data3_META,
			data4_META,
			data5_META,
			data6_META,
			data7_META,
			data8_META,
			data9_META,
			data10_META,
			data11_META,
			data12_META,
			data13_META,
			data14_META,
			data15_META,
			data16_META,
			data17_META,
			data18_META,
			data19_META,
			data20_META,
			data21_META,
			data22_META,
			data23_META,
			data24_META,
			data25_META,
			data26_META,
			data27_META,
			data28_META,
			data29_META,
			data30_META,
			data31_META,
			data32_META,
			data33_META,
			data34_META,
			data35_META,
			data36_META,
			data37_META,
			data38_META,
			data39_META,
			data40_META,
			data41_META,
			data42_META,
			data43_META,
			data44_META,
			data45_META,
			data46_META,
			data47_META,
			data48_META,
			data49_META,
			data50_META,
			data51_META,
			data52_META,
			data53_META,
			data54_META,
			data55_META,
			data56_META,
			data57_META,
			data58_META,
			data59_META,
			data60_META,
			data61_META,
			data62_META,
			data63_META,
			data64_META,
			data65_META,
			data66_META,
			data67_META,
			data68_META,
			data69_META,
			data70_META,
			data71_META,
			data72_META,
			data73_META,
			data74_META,
			data75_META,
			data76_META,
			data77_META,
			data78_META,
			data79_META,
			data80_META,
			data81_META,
			data82_META,
			data83_META,
			data84_META,
			data85_META,
			data86_META,
			data87_META,
			data88_META,
			data89_META,
			data90_META,
			data91_META,
			data92_META,
			data93_META,
			data94_META,
			data95_META,
			data96_META,
			data97_META,
			data98_META,
			data99_META,
			data100_META,
			dat_typ_META,
			par_col_nm_META,
			par_col_idx_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected ViewR_FW_A(ConstMetaList<? extends ViewR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ViewR clone() {
		return (ViewR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ViewR createInstance() {
		return (ViewR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ViewR getValues(String... names) {
		return (ViewR) super.getValues(names);
	}



	/**
	 *  項目.<p>
	 *
	 */
	public String title() {
		return getConstString(offset + 0, $title);
	}

	/**
	 *  項目.<p>
	 *
	 */
	public void title(String value) {
		setConstString(offset + 0, $title, value);
	}


	/**
	 *  1.<p>
	 *
	 */
	public String data1() {
		return getConstString(offset + 1, $data1);
	}

	/**
	 *  1.<p>
	 *
	 */
	public void data1(String value) {
		setConstString(offset + 1, $data1, value);
	}


	/**
	 *  2.<p>
	 *
	 */
	public String data2() {
		return getConstString(offset + 2, $data2);
	}

	/**
	 *  2.<p>
	 *
	 */
	public void data2(String value) {
		setConstString(offset + 2, $data2, value);
	}


	/**
	 *  3.<p>
	 *
	 */
	public String data3() {
		return getConstString(offset + 3, $data3);
	}

	/**
	 *  3.<p>
	 *
	 */
	public void data3(String value) {
		setConstString(offset + 3, $data3, value);
	}


	/**
	 *  4.<p>
	 *
	 */
	public String data4() {
		return getConstString(offset + 4, $data4);
	}

	/**
	 *  4.<p>
	 *
	 */
	public void data4(String value) {
		setConstString(offset + 4, $data4, value);
	}


	/**
	 *  5.<p>
	 *
	 */
	public String data5() {
		return getConstString(offset + 5, $data5);
	}

	/**
	 *  5.<p>
	 *
	 */
	public void data5(String value) {
		setConstString(offset + 5, $data5, value);
	}


	/**
	 *  6.<p>
	 *
	 */
	public String data6() {
		return getConstString(offset + 6, $data6);
	}

	/**
	 *  6.<p>
	 *
	 */
	public void data6(String value) {
		setConstString(offset + 6, $data6, value);
	}


	/**
	 *  7.<p>
	 *
	 */
	public String data7() {
		return getConstString(offset + 7, $data7);
	}

	/**
	 *  7.<p>
	 *
	 */
	public void data7(String value) {
		setConstString(offset + 7, $data7, value);
	}


	/**
	 *  8.<p>
	 *
	 */
	public String data8() {
		return getConstString(offset + 8, $data8);
	}

	/**
	 *  8.<p>
	 *
	 */
	public void data8(String value) {
		setConstString(offset + 8, $data8, value);
	}


	/**
	 *  9.<p>
	 *
	 */
	public String data9() {
		return getConstString(offset + 9, $data9);
	}

	/**
	 *  9.<p>
	 *
	 */
	public void data9(String value) {
		setConstString(offset + 9, $data9, value);
	}


	/**
	 *  10.<p>
	 *
	 */
	public String data10() {
		return getConstString(offset + 10, $data10);
	}

	/**
	 *  10.<p>
	 *
	 */
	public void data10(String value) {
		setConstString(offset + 10, $data10, value);
	}


	/**
	 *  11.<p>
	 *
	 */
	public String data11() {
		return getConstString(offset + 11, $data11);
	}

	/**
	 *  11.<p>
	 *
	 */
	public void data11(String value) {
		setConstString(offset + 11, $data11, value);
	}


	/**
	 *  12.<p>
	 *
	 */
	public String data12() {
		return getConstString(offset + 12, $data12);
	}

	/**
	 *  12.<p>
	 *
	 */
	public void data12(String value) {
		setConstString(offset + 12, $data12, value);
	}


	/**
	 *  13.<p>
	 *
	 */
	public String data13() {
		return getConstString(offset + 13, $data13);
	}

	/**
	 *  13.<p>
	 *
	 */
	public void data13(String value) {
		setConstString(offset + 13, $data13, value);
	}


	/**
	 *  14.<p>
	 *
	 */
	public String data14() {
		return getConstString(offset + 14, $data14);
	}

	/**
	 *  14.<p>
	 *
	 */
	public void data14(String value) {
		setConstString(offset + 14, $data14, value);
	}


	/**
	 *  15.<p>
	 *
	 */
	public String data15() {
		return getConstString(offset + 15, $data15);
	}

	/**
	 *  15.<p>
	 *
	 */
	public void data15(String value) {
		setConstString(offset + 15, $data15, value);
	}


	/**
	 *  16.<p>
	 *
	 */
	public String data16() {
		return getConstString(offset + 16, $data16);
	}

	/**
	 *  16.<p>
	 *
	 */
	public void data16(String value) {
		setConstString(offset + 16, $data16, value);
	}


	/**
	 *  17.<p>
	 *
	 */
	public String data17() {
		return getConstString(offset + 17, $data17);
	}

	/**
	 *  17.<p>
	 *
	 */
	public void data17(String value) {
		setConstString(offset + 17, $data17, value);
	}


	/**
	 *  18.<p>
	 *
	 */
	public String data18() {
		return getConstString(offset + 18, $data18);
	}

	/**
	 *  18.<p>
	 *
	 */
	public void data18(String value) {
		setConstString(offset + 18, $data18, value);
	}


	/**
	 *  19.<p>
	 *
	 */
	public String data19() {
		return getConstString(offset + 19, $data19);
	}

	/**
	 *  19.<p>
	 *
	 */
	public void data19(String value) {
		setConstString(offset + 19, $data19, value);
	}


	/**
	 *  20.<p>
	 *
	 */
	public String data20() {
		return getConstString(offset + 20, $data20);
	}

	/**
	 *  20.<p>
	 *
	 */
	public void data20(String value) {
		setConstString(offset + 20, $data20, value);
	}


	/**
	 *  21.<p>
	 *
	 */
	public String data21() {
		return getConstString(offset + 21, $data21);
	}

	/**
	 *  21.<p>
	 *
	 */
	public void data21(String value) {
		setConstString(offset + 21, $data21, value);
	}


	/**
	 *  22.<p>
	 *
	 */
	public String data22() {
		return getConstString(offset + 22, $data22);
	}

	/**
	 *  22.<p>
	 *
	 */
	public void data22(String value) {
		setConstString(offset + 22, $data22, value);
	}


	/**
	 *  23.<p>
	 *
	 */
	public String data23() {
		return getConstString(offset + 23, $data23);
	}

	/**
	 *  23.<p>
	 *
	 */
	public void data23(String value) {
		setConstString(offset + 23, $data23, value);
	}


	/**
	 *  24.<p>
	 *
	 */
	public String data24() {
		return getConstString(offset + 24, $data24);
	}

	/**
	 *  24.<p>
	 *
	 */
	public void data24(String value) {
		setConstString(offset + 24, $data24, value);
	}


	/**
	 *  25.<p>
	 *
	 */
	public String data25() {
		return getConstString(offset + 25, $data25);
	}

	/**
	 *  25.<p>
	 *
	 */
	public void data25(String value) {
		setConstString(offset + 25, $data25, value);
	}


	/**
	 *  26.<p>
	 *
	 */
	public String data26() {
		return getConstString(offset + 26, $data26);
	}

	/**
	 *  26.<p>
	 *
	 */
	public void data26(String value) {
		setConstString(offset + 26, $data26, value);
	}


	/**
	 *  27.<p>
	 *
	 */
	public String data27() {
		return getConstString(offset + 27, $data27);
	}

	/**
	 *  27.<p>
	 *
	 */
	public void data27(String value) {
		setConstString(offset + 27, $data27, value);
	}


	/**
	 *  28.<p>
	 *
	 */
	public String data28() {
		return getConstString(offset + 28, $data28);
	}

	/**
	 *  28.<p>
	 *
	 */
	public void data28(String value) {
		setConstString(offset + 28, $data28, value);
	}


	/**
	 *  29.<p>
	 *
	 */
	public String data29() {
		return getConstString(offset + 29, $data29);
	}

	/**
	 *  29.<p>
	 *
	 */
	public void data29(String value) {
		setConstString(offset + 29, $data29, value);
	}


	/**
	 *  30.<p>
	 *
	 */
	public String data30() {
		return getConstString(offset + 30, $data30);
	}

	/**
	 *  30.<p>
	 *
	 */
	public void data30(String value) {
		setConstString(offset + 30, $data30, value);
	}


	/**
	 *  31.<p>
	 *
	 */
	public String data31() {
		return getConstString(offset + 31, $data31);
	}

	/**
	 *  31.<p>
	 *
	 */
	public void data31(String value) {
		setConstString(offset + 31, $data31, value);
	}


	/**
	 *  32.<p>
	 *
	 */
	public String data32() {
		return getConstString(offset + 32, $data32);
	}

	/**
	 *  32.<p>
	 *
	 */
	public void data32(String value) {
		setConstString(offset + 32, $data32, value);
	}


	/**
	 *  33.<p>
	 *
	 */
	public String data33() {
		return getConstString(offset + 33, $data33);
	}

	/**
	 *  33.<p>
	 *
	 */
	public void data33(String value) {
		setConstString(offset + 33, $data33, value);
	}


	/**
	 *  34.<p>
	 *
	 */
	public String data34() {
		return getConstString(offset + 34, $data34);
	}

	/**
	 *  34.<p>
	 *
	 */
	public void data34(String value) {
		setConstString(offset + 34, $data34, value);
	}


	/**
	 *  35.<p>
	 *
	 */
	public String data35() {
		return getConstString(offset + 35, $data35);
	}

	/**
	 *  35.<p>
	 *
	 */
	public void data35(String value) {
		setConstString(offset + 35, $data35, value);
	}


	/**
	 *  36.<p>
	 *
	 */
	public String data36() {
		return getConstString(offset + 36, $data36);
	}

	/**
	 *  36.<p>
	 *
	 */
	public void data36(String value) {
		setConstString(offset + 36, $data36, value);
	}


	/**
	 *  37.<p>
	 *
	 */
	public String data37() {
		return getConstString(offset + 37, $data37);
	}

	/**
	 *  37.<p>
	 *
	 */
	public void data37(String value) {
		setConstString(offset + 37, $data37, value);
	}


	/**
	 *  38.<p>
	 *
	 */
	public String data38() {
		return getConstString(offset + 38, $data38);
	}

	/**
	 *  38.<p>
	 *
	 */
	public void data38(String value) {
		setConstString(offset + 38, $data38, value);
	}


	/**
	 *  39.<p>
	 *
	 */
	public String data39() {
		return getConstString(offset + 39, $data39);
	}

	/**
	 *  39.<p>
	 *
	 */
	public void data39(String value) {
		setConstString(offset + 39, $data39, value);
	}


	/**
	 *  40.<p>
	 *
	 */
	public String data40() {
		return getConstString(offset + 40, $data40);
	}

	/**
	 *  40.<p>
	 *
	 */
	public void data40(String value) {
		setConstString(offset + 40, $data40, value);
	}


	/**
	 *  41.<p>
	 *
	 */
	public String data41() {
		return getConstString(offset + 41, $data41);
	}

	/**
	 *  41.<p>
	 *
	 */
	public void data41(String value) {
		setConstString(offset + 41, $data41, value);
	}


	/**
	 *  42.<p>
	 *
	 */
	public String data42() {
		return getConstString(offset + 42, $data42);
	}

	/**
	 *  42.<p>
	 *
	 */
	public void data42(String value) {
		setConstString(offset + 42, $data42, value);
	}


	/**
	 *  43.<p>
	 *
	 */
	public String data43() {
		return getConstString(offset + 43, $data43);
	}

	/**
	 *  43.<p>
	 *
	 */
	public void data43(String value) {
		setConstString(offset + 43, $data43, value);
	}


	/**
	 *  44.<p>
	 *
	 */
	public String data44() {
		return getConstString(offset + 44, $data44);
	}

	/**
	 *  44.<p>
	 *
	 */
	public void data44(String value) {
		setConstString(offset + 44, $data44, value);
	}


	/**
	 *  45.<p>
	 *
	 */
	public String data45() {
		return getConstString(offset + 45, $data45);
	}

	/**
	 *  45.<p>
	 *
	 */
	public void data45(String value) {
		setConstString(offset + 45, $data45, value);
	}


	/**
	 *  46.<p>
	 *
	 */
	public String data46() {
		return getConstString(offset + 46, $data46);
	}

	/**
	 *  46.<p>
	 *
	 */
	public void data46(String value) {
		setConstString(offset + 46, $data46, value);
	}


	/**
	 *  47.<p>
	 *
	 */
	public String data47() {
		return getConstString(offset + 47, $data47);
	}

	/**
	 *  47.<p>
	 *
	 */
	public void data47(String value) {
		setConstString(offset + 47, $data47, value);
	}


	/**
	 *  48.<p>
	 *
	 */
	public String data48() {
		return getConstString(offset + 48, $data48);
	}

	/**
	 *  48.<p>
	 *
	 */
	public void data48(String value) {
		setConstString(offset + 48, $data48, value);
	}


	/**
	 *  49.<p>
	 *
	 */
	public String data49() {
		return getConstString(offset + 49, $data49);
	}

	/**
	 *  49.<p>
	 *
	 */
	public void data49(String value) {
		setConstString(offset + 49, $data49, value);
	}


	/**
	 *  50.<p>
	 *
	 */
	public String data50() {
		return getConstString(offset + 50, $data50);
	}

	/**
	 *  50.<p>
	 *
	 */
	public void data50(String value) {
		setConstString(offset + 50, $data50, value);
	}


	/**
	 *  51.<p>
	 *
	 */
	public String data51() {
		return getConstString(offset + 51, $data51);
	}

	/**
	 *  51.<p>
	 *
	 */
	public void data51(String value) {
		setConstString(offset + 51, $data51, value);
	}


	/**
	 *  52.<p>
	 *
	 */
	public String data52() {
		return getConstString(offset + 52, $data52);
	}

	/**
	 *  52.<p>
	 *
	 */
	public void data52(String value) {
		setConstString(offset + 52, $data52, value);
	}


	/**
	 *  53.<p>
	 *
	 */
	public String data53() {
		return getConstString(offset + 53, $data53);
	}

	/**
	 *  53.<p>
	 *
	 */
	public void data53(String value) {
		setConstString(offset + 53, $data53, value);
	}


	/**
	 *  54.<p>
	 *
	 */
	public String data54() {
		return getConstString(offset + 54, $data54);
	}

	/**
	 *  54.<p>
	 *
	 */
	public void data54(String value) {
		setConstString(offset + 54, $data54, value);
	}


	/**
	 *  55.<p>
	 *
	 */
	public String data55() {
		return getConstString(offset + 55, $data55);
	}

	/**
	 *  55.<p>
	 *
	 */
	public void data55(String value) {
		setConstString(offset + 55, $data55, value);
	}


	/**
	 *  56.<p>
	 *
	 */
	public String data56() {
		return getConstString(offset + 56, $data56);
	}

	/**
	 *  56.<p>
	 *
	 */
	public void data56(String value) {
		setConstString(offset + 56, $data56, value);
	}


	/**
	 *  57.<p>
	 *
	 */
	public String data57() {
		return getConstString(offset + 57, $data57);
	}

	/**
	 *  57.<p>
	 *
	 */
	public void data57(String value) {
		setConstString(offset + 57, $data57, value);
	}


	/**
	 *  58.<p>
	 *
	 */
	public String data58() {
		return getConstString(offset + 58, $data58);
	}

	/**
	 *  58.<p>
	 *
	 */
	public void data58(String value) {
		setConstString(offset + 58, $data58, value);
	}


	/**
	 *  59.<p>
	 *
	 */
	public String data59() {
		return getConstString(offset + 59, $data59);
	}

	/**
	 *  59.<p>
	 *
	 */
	public void data59(String value) {
		setConstString(offset + 59, $data59, value);
	}


	/**
	 *  60.<p>
	 *
	 */
	public String data60() {
		return getConstString(offset + 60, $data60);
	}

	/**
	 *  60.<p>
	 *
	 */
	public void data60(String value) {
		setConstString(offset + 60, $data60, value);
	}


	/**
	 *  61.<p>
	 *
	 */
	public String data61() {
		return getConstString(offset + 61, $data61);
	}

	/**
	 *  61.<p>
	 *
	 */
	public void data61(String value) {
		setConstString(offset + 61, $data61, value);
	}


	/**
	 *  62.<p>
	 *
	 */
	public String data62() {
		return getConstString(offset + 62, $data62);
	}

	/**
	 *  62.<p>
	 *
	 */
	public void data62(String value) {
		setConstString(offset + 62, $data62, value);
	}


	/**
	 *  63.<p>
	 *
	 */
	public String data63() {
		return getConstString(offset + 63, $data63);
	}

	/**
	 *  63.<p>
	 *
	 */
	public void data63(String value) {
		setConstString(offset + 63, $data63, value);
	}


	/**
	 *  64.<p>
	 *
	 */
	public String data64() {
		return getConstString(offset + 64, $data64);
	}

	/**
	 *  64.<p>
	 *
	 */
	public void data64(String value) {
		setConstString(offset + 64, $data64, value);
	}


	/**
	 *  65.<p>
	 *
	 */
	public String data65() {
		return getConstString(offset + 65, $data65);
	}

	/**
	 *  65.<p>
	 *
	 */
	public void data65(String value) {
		setConstString(offset + 65, $data65, value);
	}


	/**
	 *  66.<p>
	 *
	 */
	public String data66() {
		return getConstString(offset + 66, $data66);
	}

	/**
	 *  66.<p>
	 *
	 */
	public void data66(String value) {
		setConstString(offset + 66, $data66, value);
	}


	/**
	 *  67.<p>
	 *
	 */
	public String data67() {
		return getConstString(offset + 67, $data67);
	}

	/**
	 *  67.<p>
	 *
	 */
	public void data67(String value) {
		setConstString(offset + 67, $data67, value);
	}


	/**
	 *  68.<p>
	 *
	 */
	public String data68() {
		return getConstString(offset + 68, $data68);
	}

	/**
	 *  68.<p>
	 *
	 */
	public void data68(String value) {
		setConstString(offset + 68, $data68, value);
	}


	/**
	 *  69.<p>
	 *
	 */
	public String data69() {
		return getConstString(offset + 69, $data69);
	}

	/**
	 *  69.<p>
	 *
	 */
	public void data69(String value) {
		setConstString(offset + 69, $data69, value);
	}


	/**
	 *  70.<p>
	 *
	 */
	public String data70() {
		return getConstString(offset + 70, $data70);
	}

	/**
	 *  70.<p>
	 *
	 */
	public void data70(String value) {
		setConstString(offset + 70, $data70, value);
	}


	/**
	 *  71.<p>
	 *
	 */
	public String data71() {
		return getConstString(offset + 71, $data71);
	}

	/**
	 *  71.<p>
	 *
	 */
	public void data71(String value) {
		setConstString(offset + 71, $data71, value);
	}


	/**
	 *  72.<p>
	 *
	 */
	public String data72() {
		return getConstString(offset + 72, $data72);
	}

	/**
	 *  72.<p>
	 *
	 */
	public void data72(String value) {
		setConstString(offset + 72, $data72, value);
	}


	/**
	 *  73.<p>
	 *
	 */
	public String data73() {
		return getConstString(offset + 73, $data73);
	}

	/**
	 *  73.<p>
	 *
	 */
	public void data73(String value) {
		setConstString(offset + 73, $data73, value);
	}


	/**
	 *  74.<p>
	 *
	 */
	public String data74() {
		return getConstString(offset + 74, $data74);
	}

	/**
	 *  74.<p>
	 *
	 */
	public void data74(String value) {
		setConstString(offset + 74, $data74, value);
	}


	/**
	 *  75.<p>
	 *
	 */
	public String data75() {
		return getConstString(offset + 75, $data75);
	}

	/**
	 *  75.<p>
	 *
	 */
	public void data75(String value) {
		setConstString(offset + 75, $data75, value);
	}


	/**
	 *  76.<p>
	 *
	 */
	public String data76() {
		return getConstString(offset + 76, $data76);
	}

	/**
	 *  76.<p>
	 *
	 */
	public void data76(String value) {
		setConstString(offset + 76, $data76, value);
	}


	/**
	 *  77.<p>
	 *
	 */
	public String data77() {
		return getConstString(offset + 77, $data77);
	}

	/**
	 *  77.<p>
	 *
	 */
	public void data77(String value) {
		setConstString(offset + 77, $data77, value);
	}


	/**
	 *  78.<p>
	 *
	 */
	public String data78() {
		return getConstString(offset + 78, $data78);
	}

	/**
	 *  78.<p>
	 *
	 */
	public void data78(String value) {
		setConstString(offset + 78, $data78, value);
	}


	/**
	 *  79.<p>
	 *
	 */
	public String data79() {
		return getConstString(offset + 79, $data79);
	}

	/**
	 *  79.<p>
	 *
	 */
	public void data79(String value) {
		setConstString(offset + 79, $data79, value);
	}


	/**
	 *  80.<p>
	 *
	 */
	public String data80() {
		return getConstString(offset + 80, $data80);
	}

	/**
	 *  80.<p>
	 *
	 */
	public void data80(String value) {
		setConstString(offset + 80, $data80, value);
	}


	/**
	 *  81.<p>
	 *
	 */
	public String data81() {
		return getConstString(offset + 81, $data81);
	}

	/**
	 *  81.<p>
	 *
	 */
	public void data81(String value) {
		setConstString(offset + 81, $data81, value);
	}


	/**
	 *  82.<p>
	 *
	 */
	public String data82() {
		return getConstString(offset + 82, $data82);
	}

	/**
	 *  82.<p>
	 *
	 */
	public void data82(String value) {
		setConstString(offset + 82, $data82, value);
	}


	/**
	 *  83.<p>
	 *
	 */
	public String data83() {
		return getConstString(offset + 83, $data83);
	}

	/**
	 *  83.<p>
	 *
	 */
	public void data83(String value) {
		setConstString(offset + 83, $data83, value);
	}


	/**
	 *  84.<p>
	 *
	 */
	public String data84() {
		return getConstString(offset + 84, $data84);
	}

	/**
	 *  84.<p>
	 *
	 */
	public void data84(String value) {
		setConstString(offset + 84, $data84, value);
	}


	/**
	 *  85.<p>
	 *
	 */
	public String data85() {
		return getConstString(offset + 85, $data85);
	}

	/**
	 *  85.<p>
	 *
	 */
	public void data85(String value) {
		setConstString(offset + 85, $data85, value);
	}


	/**
	 *  86.<p>
	 *
	 */
	public String data86() {
		return getConstString(offset + 86, $data86);
	}

	/**
	 *  86.<p>
	 *
	 */
	public void data86(String value) {
		setConstString(offset + 86, $data86, value);
	}


	/**
	 *  87.<p>
	 *
	 */
	public String data87() {
		return getConstString(offset + 87, $data87);
	}

	/**
	 *  87.<p>
	 *
	 */
	public void data87(String value) {
		setConstString(offset + 87, $data87, value);
	}


	/**
	 *  88.<p>
	 *
	 */
	public String data88() {
		return getConstString(offset + 88, $data88);
	}

	/**
	 *  88.<p>
	 *
	 */
	public void data88(String value) {
		setConstString(offset + 88, $data88, value);
	}


	/**
	 *  89.<p>
	 *
	 */
	public String data89() {
		return getConstString(offset + 89, $data89);
	}

	/**
	 *  89.<p>
	 *
	 */
	public void data89(String value) {
		setConstString(offset + 89, $data89, value);
	}


	/**
	 *  90.<p>
	 *
	 */
	public String data90() {
		return getConstString(offset + 90, $data90);
	}

	/**
	 *  90.<p>
	 *
	 */
	public void data90(String value) {
		setConstString(offset + 90, $data90, value);
	}


	/**
	 *  91.<p>
	 *
	 */
	public String data91() {
		return getConstString(offset + 91, $data91);
	}

	/**
	 *  91.<p>
	 *
	 */
	public void data91(String value) {
		setConstString(offset + 91, $data91, value);
	}


	/**
	 *  92.<p>
	 *
	 */
	public String data92() {
		return getConstString(offset + 92, $data92);
	}

	/**
	 *  92.<p>
	 *
	 */
	public void data92(String value) {
		setConstString(offset + 92, $data92, value);
	}


	/**
	 *  93.<p>
	 *
	 */
	public String data93() {
		return getConstString(offset + 93, $data93);
	}

	/**
	 *  93.<p>
	 *
	 */
	public void data93(String value) {
		setConstString(offset + 93, $data93, value);
	}


	/**
	 *  94.<p>
	 *
	 */
	public String data94() {
		return getConstString(offset + 94, $data94);
	}

	/**
	 *  94.<p>
	 *
	 */
	public void data94(String value) {
		setConstString(offset + 94, $data94, value);
	}


	/**
	 *  95.<p>
	 *
	 */
	public String data95() {
		return getConstString(offset + 95, $data95);
	}

	/**
	 *  95.<p>
	 *
	 */
	public void data95(String value) {
		setConstString(offset + 95, $data95, value);
	}


	/**
	 *  96.<p>
	 *
	 */
	public String data96() {
		return getConstString(offset + 96, $data96);
	}

	/**
	 *  96.<p>
	 *
	 */
	public void data96(String value) {
		setConstString(offset + 96, $data96, value);
	}


	/**
	 *  97.<p>
	 *
	 */
	public String data97() {
		return getConstString(offset + 97, $data97);
	}

	/**
	 *  97.<p>
	 *
	 */
	public void data97(String value) {
		setConstString(offset + 97, $data97, value);
	}


	/**
	 *  98.<p>
	 *
	 */
	public String data98() {
		return getConstString(offset + 98, $data98);
	}

	/**
	 *  98.<p>
	 *
	 */
	public void data98(String value) {
		setConstString(offset + 98, $data98, value);
	}


	/**
	 *  99.<p>
	 *
	 */
	public String data99() {
		return getConstString(offset + 99, $data99);
	}

	/**
	 *  99.<p>
	 *
	 */
	public void data99(String value) {
		setConstString(offset + 99, $data99, value);
	}


	/**
	 *  100.<p>
	 *
	 */
	public String data100() {
		return getConstString(offset + 100, $data100);
	}

	/**
	 *  100.<p>
	 *
	 */
	public void data100(String value) {
		setConstString(offset + 100, $data100, value);
	}


	/**
	 *  データ型.<p>
	 *
	 */
	public String dat_typ() {
		return getConstString(offset + 101, $dat_typ);
	}

	/**
	 *  データ型.<p>
	 *
	 */
	public void dat_typ(String value) {
		setConstString(offset + 101, $dat_typ, value);
	}


	/**
	 *  親カラム名.<p>
	 *
	 */
	public String par_col_nm() {
		return getConstString(offset + 102, $par_col_nm);
	}

	/**
	 *  親カラム名.<p>
	 *
	 */
	public void par_col_nm(String value) {
		setConstString(offset + 102, $par_col_nm, value);
	}


	/**
	 *  親カラムインデックス.<p>
	 *
	 */
	public MCNumber par_col_idx() {
		return getConstNumber(offset + 103, $par_col_idx);
	}

	/**
	 *  親カラムインデックス.<p>
	 *
	 */
	public void par_col_idx(MCNumber value) {
		setConstNumber(offset + 103, $par_col_idx, value);
	}

	/**
	 *  親カラムインデックス.<p>
	 *
	 */
	public void par_col_idx(int value) {
		setConstNumber(offset + 103, $par_col_idx, value);
	}

	/**
	 *  親カラムインデックス.<p>
	 *
	 */
	public void par_col_idx(long value) {
		setConstNumber(offset + 103, $par_col_idx, value);
	}

	/**
	 *  親カラムインデックス.<p>
	 *
	 */
	public void par_col_idx(float value) {
		setConstNumber(offset + 103, $par_col_idx, value);
	}

	/**
	 *  親カラムインデックス.<p>
	 *
	 */
	public void par_col_idx(double value) {
		setConstNumber(offset + 103, $par_col_idx, value);
	}


	public String getString(String name) {
		if ($title.equalsIgnoreCase(name)) {
			return title();
		}
		if ($data1.equalsIgnoreCase(name)) {
			return data1();
		}
		if ($data2.equalsIgnoreCase(name)) {
			return data2();
		}
		if ($data3.equalsIgnoreCase(name)) {
			return data3();
		}
		if ($data4.equalsIgnoreCase(name)) {
			return data4();
		}
		if ($data5.equalsIgnoreCase(name)) {
			return data5();
		}
		if ($data6.equalsIgnoreCase(name)) {
			return data6();
		}
		if ($data7.equalsIgnoreCase(name)) {
			return data7();
		}
		if ($data8.equalsIgnoreCase(name)) {
			return data8();
		}
		if ($data9.equalsIgnoreCase(name)) {
			return data9();
		}
		if ($data10.equalsIgnoreCase(name)) {
			return data10();
		}
		if ($data11.equalsIgnoreCase(name)) {
			return data11();
		}
		if ($data12.equalsIgnoreCase(name)) {
			return data12();
		}
		if ($data13.equalsIgnoreCase(name)) {
			return data13();
		}
		if ($data14.equalsIgnoreCase(name)) {
			return data14();
		}
		if ($data15.equalsIgnoreCase(name)) {
			return data15();
		}
		if ($data16.equalsIgnoreCase(name)) {
			return data16();
		}
		if ($data17.equalsIgnoreCase(name)) {
			return data17();
		}
		if ($data18.equalsIgnoreCase(name)) {
			return data18();
		}
		if ($data19.equalsIgnoreCase(name)) {
			return data19();
		}
		if ($data20.equalsIgnoreCase(name)) {
			return data20();
		}
		if ($data21.equalsIgnoreCase(name)) {
			return data21();
		}
		if ($data22.equalsIgnoreCase(name)) {
			return data22();
		}
		if ($data23.equalsIgnoreCase(name)) {
			return data23();
		}
		if ($data24.equalsIgnoreCase(name)) {
			return data24();
		}
		if ($data25.equalsIgnoreCase(name)) {
			return data25();
		}
		if ($data26.equalsIgnoreCase(name)) {
			return data26();
		}
		if ($data27.equalsIgnoreCase(name)) {
			return data27();
		}
		if ($data28.equalsIgnoreCase(name)) {
			return data28();
		}
		if ($data29.equalsIgnoreCase(name)) {
			return data29();
		}
		if ($data30.equalsIgnoreCase(name)) {
			return data30();
		}
		if ($data31.equalsIgnoreCase(name)) {
			return data31();
		}
		if ($data32.equalsIgnoreCase(name)) {
			return data32();
		}
		if ($data33.equalsIgnoreCase(name)) {
			return data33();
		}
		if ($data34.equalsIgnoreCase(name)) {
			return data34();
		}
		if ($data35.equalsIgnoreCase(name)) {
			return data35();
		}
		if ($data36.equalsIgnoreCase(name)) {
			return data36();
		}
		if ($data37.equalsIgnoreCase(name)) {
			return data37();
		}
		if ($data38.equalsIgnoreCase(name)) {
			return data38();
		}
		if ($data39.equalsIgnoreCase(name)) {
			return data39();
		}
		if ($data40.equalsIgnoreCase(name)) {
			return data40();
		}
		if ($data41.equalsIgnoreCase(name)) {
			return data41();
		}
		if ($data42.equalsIgnoreCase(name)) {
			return data42();
		}
		if ($data43.equalsIgnoreCase(name)) {
			return data43();
		}
		if ($data44.equalsIgnoreCase(name)) {
			return data44();
		}
		if ($data45.equalsIgnoreCase(name)) {
			return data45();
		}
		if ($data46.equalsIgnoreCase(name)) {
			return data46();
		}
		if ($data47.equalsIgnoreCase(name)) {
			return data47();
		}
		if ($data48.equalsIgnoreCase(name)) {
			return data48();
		}
		if ($data49.equalsIgnoreCase(name)) {
			return data49();
		}
		if ($data50.equalsIgnoreCase(name)) {
			return data50();
		}
		if ($data51.equalsIgnoreCase(name)) {
			return data51();
		}
		if ($data52.equalsIgnoreCase(name)) {
			return data52();
		}
		if ($data53.equalsIgnoreCase(name)) {
			return data53();
		}
		if ($data54.equalsIgnoreCase(name)) {
			return data54();
		}
		if ($data55.equalsIgnoreCase(name)) {
			return data55();
		}
		if ($data56.equalsIgnoreCase(name)) {
			return data56();
		}
		if ($data57.equalsIgnoreCase(name)) {
			return data57();
		}
		if ($data58.equalsIgnoreCase(name)) {
			return data58();
		}
		if ($data59.equalsIgnoreCase(name)) {
			return data59();
		}
		if ($data60.equalsIgnoreCase(name)) {
			return data60();
		}
		if ($data61.equalsIgnoreCase(name)) {
			return data61();
		}
		if ($data62.equalsIgnoreCase(name)) {
			return data62();
		}
		if ($data63.equalsIgnoreCase(name)) {
			return data63();
		}
		if ($data64.equalsIgnoreCase(name)) {
			return data64();
		}
		if ($data65.equalsIgnoreCase(name)) {
			return data65();
		}
		if ($data66.equalsIgnoreCase(name)) {
			return data66();
		}
		if ($data67.equalsIgnoreCase(name)) {
			return data67();
		}
		if ($data68.equalsIgnoreCase(name)) {
			return data68();
		}
		if ($data69.equalsIgnoreCase(name)) {
			return data69();
		}
		if ($data70.equalsIgnoreCase(name)) {
			return data70();
		}
		if ($data71.equalsIgnoreCase(name)) {
			return data71();
		}
		if ($data72.equalsIgnoreCase(name)) {
			return data72();
		}
		if ($data73.equalsIgnoreCase(name)) {
			return data73();
		}
		if ($data74.equalsIgnoreCase(name)) {
			return data74();
		}
		if ($data75.equalsIgnoreCase(name)) {
			return data75();
		}
		if ($data76.equalsIgnoreCase(name)) {
			return data76();
		}
		if ($data77.equalsIgnoreCase(name)) {
			return data77();
		}
		if ($data78.equalsIgnoreCase(name)) {
			return data78();
		}
		if ($data79.equalsIgnoreCase(name)) {
			return data79();
		}
		if ($data80.equalsIgnoreCase(name)) {
			return data80();
		}
		if ($data81.equalsIgnoreCase(name)) {
			return data81();
		}
		if ($data82.equalsIgnoreCase(name)) {
			return data82();
		}
		if ($data83.equalsIgnoreCase(name)) {
			return data83();
		}
		if ($data84.equalsIgnoreCase(name)) {
			return data84();
		}
		if ($data85.equalsIgnoreCase(name)) {
			return data85();
		}
		if ($data86.equalsIgnoreCase(name)) {
			return data86();
		}
		if ($data87.equalsIgnoreCase(name)) {
			return data87();
		}
		if ($data88.equalsIgnoreCase(name)) {
			return data88();
		}
		if ($data89.equalsIgnoreCase(name)) {
			return data89();
		}
		if ($data90.equalsIgnoreCase(name)) {
			return data90();
		}
		if ($data91.equalsIgnoreCase(name)) {
			return data91();
		}
		if ($data92.equalsIgnoreCase(name)) {
			return data92();
		}
		if ($data93.equalsIgnoreCase(name)) {
			return data93();
		}
		if ($data94.equalsIgnoreCase(name)) {
			return data94();
		}
		if ($data95.equalsIgnoreCase(name)) {
			return data95();
		}
		if ($data96.equalsIgnoreCase(name)) {
			return data96();
		}
		if ($data97.equalsIgnoreCase(name)) {
			return data97();
		}
		if ($data98.equalsIgnoreCase(name)) {
			return data98();
		}
		if ($data99.equalsIgnoreCase(name)) {
			return data99();
		}
		if ($data100.equalsIgnoreCase(name)) {
			return data100();
		}
		if ($dat_typ.equalsIgnoreCase(name)) {
			return dat_typ();
		}
		if ($par_col_nm.equalsIgnoreCase(name)) {
			return par_col_nm();
		}
		return super.getString(name);
	}
	public MCNumber getNumber(String name) {
		if ($par_col_idx.equalsIgnoreCase(name)) {
			return par_col_idx();
		}
		return super.getNumber(name);
	}

	public String getStringNE(String name) {
		if ($title.equalsIgnoreCase(name)) {
			return title();
		}
		if ($data1.equalsIgnoreCase(name)) {
			return data1();
		}
		if ($data2.equalsIgnoreCase(name)) {
			return data2();
		}
		if ($data3.equalsIgnoreCase(name)) {
			return data3();
		}
		if ($data4.equalsIgnoreCase(name)) {
			return data4();
		}
		if ($data5.equalsIgnoreCase(name)) {
			return data5();
		}
		if ($data6.equalsIgnoreCase(name)) {
			return data6();
		}
		if ($data7.equalsIgnoreCase(name)) {
			return data7();
		}
		if ($data8.equalsIgnoreCase(name)) {
			return data8();
		}
		if ($data9.equalsIgnoreCase(name)) {
			return data9();
		}
		if ($data10.equalsIgnoreCase(name)) {
			return data10();
		}
		if ($data11.equalsIgnoreCase(name)) {
			return data11();
		}
		if ($data12.equalsIgnoreCase(name)) {
			return data12();
		}
		if ($data13.equalsIgnoreCase(name)) {
			return data13();
		}
		if ($data14.equalsIgnoreCase(name)) {
			return data14();
		}
		if ($data15.equalsIgnoreCase(name)) {
			return data15();
		}
		if ($data16.equalsIgnoreCase(name)) {
			return data16();
		}
		if ($data17.equalsIgnoreCase(name)) {
			return data17();
		}
		if ($data18.equalsIgnoreCase(name)) {
			return data18();
		}
		if ($data19.equalsIgnoreCase(name)) {
			return data19();
		}
		if ($data20.equalsIgnoreCase(name)) {
			return data20();
		}
		if ($data21.equalsIgnoreCase(name)) {
			return data21();
		}
		if ($data22.equalsIgnoreCase(name)) {
			return data22();
		}
		if ($data23.equalsIgnoreCase(name)) {
			return data23();
		}
		if ($data24.equalsIgnoreCase(name)) {
			return data24();
		}
		if ($data25.equalsIgnoreCase(name)) {
			return data25();
		}
		if ($data26.equalsIgnoreCase(name)) {
			return data26();
		}
		if ($data27.equalsIgnoreCase(name)) {
			return data27();
		}
		if ($data28.equalsIgnoreCase(name)) {
			return data28();
		}
		if ($data29.equalsIgnoreCase(name)) {
			return data29();
		}
		if ($data30.equalsIgnoreCase(name)) {
			return data30();
		}
		if ($data31.equalsIgnoreCase(name)) {
			return data31();
		}
		if ($data32.equalsIgnoreCase(name)) {
			return data32();
		}
		if ($data33.equalsIgnoreCase(name)) {
			return data33();
		}
		if ($data34.equalsIgnoreCase(name)) {
			return data34();
		}
		if ($data35.equalsIgnoreCase(name)) {
			return data35();
		}
		if ($data36.equalsIgnoreCase(name)) {
			return data36();
		}
		if ($data37.equalsIgnoreCase(name)) {
			return data37();
		}
		if ($data38.equalsIgnoreCase(name)) {
			return data38();
		}
		if ($data39.equalsIgnoreCase(name)) {
			return data39();
		}
		if ($data40.equalsIgnoreCase(name)) {
			return data40();
		}
		if ($data41.equalsIgnoreCase(name)) {
			return data41();
		}
		if ($data42.equalsIgnoreCase(name)) {
			return data42();
		}
		if ($data43.equalsIgnoreCase(name)) {
			return data43();
		}
		if ($data44.equalsIgnoreCase(name)) {
			return data44();
		}
		if ($data45.equalsIgnoreCase(name)) {
			return data45();
		}
		if ($data46.equalsIgnoreCase(name)) {
			return data46();
		}
		if ($data47.equalsIgnoreCase(name)) {
			return data47();
		}
		if ($data48.equalsIgnoreCase(name)) {
			return data48();
		}
		if ($data49.equalsIgnoreCase(name)) {
			return data49();
		}
		if ($data50.equalsIgnoreCase(name)) {
			return data50();
		}
		if ($data51.equalsIgnoreCase(name)) {
			return data51();
		}
		if ($data52.equalsIgnoreCase(name)) {
			return data52();
		}
		if ($data53.equalsIgnoreCase(name)) {
			return data53();
		}
		if ($data54.equalsIgnoreCase(name)) {
			return data54();
		}
		if ($data55.equalsIgnoreCase(name)) {
			return data55();
		}
		if ($data56.equalsIgnoreCase(name)) {
			return data56();
		}
		if ($data57.equalsIgnoreCase(name)) {
			return data57();
		}
		if ($data58.equalsIgnoreCase(name)) {
			return data58();
		}
		if ($data59.equalsIgnoreCase(name)) {
			return data59();
		}
		if ($data60.equalsIgnoreCase(name)) {
			return data60();
		}
		if ($data61.equalsIgnoreCase(name)) {
			return data61();
		}
		if ($data62.equalsIgnoreCase(name)) {
			return data62();
		}
		if ($data63.equalsIgnoreCase(name)) {
			return data63();
		}
		if ($data64.equalsIgnoreCase(name)) {
			return data64();
		}
		if ($data65.equalsIgnoreCase(name)) {
			return data65();
		}
		if ($data66.equalsIgnoreCase(name)) {
			return data66();
		}
		if ($data67.equalsIgnoreCase(name)) {
			return data67();
		}
		if ($data68.equalsIgnoreCase(name)) {
			return data68();
		}
		if ($data69.equalsIgnoreCase(name)) {
			return data69();
		}
		if ($data70.equalsIgnoreCase(name)) {
			return data70();
		}
		if ($data71.equalsIgnoreCase(name)) {
			return data71();
		}
		if ($data72.equalsIgnoreCase(name)) {
			return data72();
		}
		if ($data73.equalsIgnoreCase(name)) {
			return data73();
		}
		if ($data74.equalsIgnoreCase(name)) {
			return data74();
		}
		if ($data75.equalsIgnoreCase(name)) {
			return data75();
		}
		if ($data76.equalsIgnoreCase(name)) {
			return data76();
		}
		if ($data77.equalsIgnoreCase(name)) {
			return data77();
		}
		if ($data78.equalsIgnoreCase(name)) {
			return data78();
		}
		if ($data79.equalsIgnoreCase(name)) {
			return data79();
		}
		if ($data80.equalsIgnoreCase(name)) {
			return data80();
		}
		if ($data81.equalsIgnoreCase(name)) {
			return data81();
		}
		if ($data82.equalsIgnoreCase(name)) {
			return data82();
		}
		if ($data83.equalsIgnoreCase(name)) {
			return data83();
		}
		if ($data84.equalsIgnoreCase(name)) {
			return data84();
		}
		if ($data85.equalsIgnoreCase(name)) {
			return data85();
		}
		if ($data86.equalsIgnoreCase(name)) {
			return data86();
		}
		if ($data87.equalsIgnoreCase(name)) {
			return data87();
		}
		if ($data88.equalsIgnoreCase(name)) {
			return data88();
		}
		if ($data89.equalsIgnoreCase(name)) {
			return data89();
		}
		if ($data90.equalsIgnoreCase(name)) {
			return data90();
		}
		if ($data91.equalsIgnoreCase(name)) {
			return data91();
		}
		if ($data92.equalsIgnoreCase(name)) {
			return data92();
		}
		if ($data93.equalsIgnoreCase(name)) {
			return data93();
		}
		if ($data94.equalsIgnoreCase(name)) {
			return data94();
		}
		if ($data95.equalsIgnoreCase(name)) {
			return data95();
		}
		if ($data96.equalsIgnoreCase(name)) {
			return data96();
		}
		if ($data97.equalsIgnoreCase(name)) {
			return data97();
		}
		if ($data98.equalsIgnoreCase(name)) {
			return data98();
		}
		if ($data99.equalsIgnoreCase(name)) {
			return data99();
		}
		if ($data100.equalsIgnoreCase(name)) {
			return data100();
		}
		if ($dat_typ.equalsIgnoreCase(name)) {
			return dat_typ();
		}
		if ($par_col_nm.equalsIgnoreCase(name)) {
			return par_col_nm();
		}
		return super.getStringNE(name);
	}
	public MCNumber getNumberNE(String name) {
		if ($par_col_idx.equalsIgnoreCase(name)) {
			return par_col_idx();
		}
		return super.getNumberNE(name);
	}

	public void setString(String name, String value) {
		if ($title.equalsIgnoreCase(name)) {
			title(value);
			return;
		}
		if ($data1.equalsIgnoreCase(name)) {
			data1(value);
			return;
		}
		if ($data2.equalsIgnoreCase(name)) {
			data2(value);
			return;
		}
		if ($data3.equalsIgnoreCase(name)) {
			data3(value);
			return;
		}
		if ($data4.equalsIgnoreCase(name)) {
			data4(value);
			return;
		}
		if ($data5.equalsIgnoreCase(name)) {
			data5(value);
			return;
		}
		if ($data6.equalsIgnoreCase(name)) {
			data6(value);
			return;
		}
		if ($data7.equalsIgnoreCase(name)) {
			data7(value);
			return;
		}
		if ($data8.equalsIgnoreCase(name)) {
			data8(value);
			return;
		}
		if ($data9.equalsIgnoreCase(name)) {
			data9(value);
			return;
		}
		if ($data10.equalsIgnoreCase(name)) {
			data10(value);
			return;
		}
		if ($data11.equalsIgnoreCase(name)) {
			data11(value);
			return;
		}
		if ($data12.equalsIgnoreCase(name)) {
			data12(value);
			return;
		}
		if ($data13.equalsIgnoreCase(name)) {
			data13(value);
			return;
		}
		if ($data14.equalsIgnoreCase(name)) {
			data14(value);
			return;
		}
		if ($data15.equalsIgnoreCase(name)) {
			data15(value);
			return;
		}
		if ($data16.equalsIgnoreCase(name)) {
			data16(value);
			return;
		}
		if ($data17.equalsIgnoreCase(name)) {
			data17(value);
			return;
		}
		if ($data18.equalsIgnoreCase(name)) {
			data18(value);
			return;
		}
		if ($data19.equalsIgnoreCase(name)) {
			data19(value);
			return;
		}
		if ($data20.equalsIgnoreCase(name)) {
			data20(value);
			return;
		}
		if ($data21.equalsIgnoreCase(name)) {
			data21(value);
			return;
		}
		if ($data22.equalsIgnoreCase(name)) {
			data22(value);
			return;
		}
		if ($data23.equalsIgnoreCase(name)) {
			data23(value);
			return;
		}
		if ($data24.equalsIgnoreCase(name)) {
			data24(value);
			return;
		}
		if ($data25.equalsIgnoreCase(name)) {
			data25(value);
			return;
		}
		if ($data26.equalsIgnoreCase(name)) {
			data26(value);
			return;
		}
		if ($data27.equalsIgnoreCase(name)) {
			data27(value);
			return;
		}
		if ($data28.equalsIgnoreCase(name)) {
			data28(value);
			return;
		}
		if ($data29.equalsIgnoreCase(name)) {
			data29(value);
			return;
		}
		if ($data30.equalsIgnoreCase(name)) {
			data30(value);
			return;
		}
		if ($data31.equalsIgnoreCase(name)) {
			data31(value);
			return;
		}
		if ($data32.equalsIgnoreCase(name)) {
			data32(value);
			return;
		}
		if ($data33.equalsIgnoreCase(name)) {
			data33(value);
			return;
		}
		if ($data34.equalsIgnoreCase(name)) {
			data34(value);
			return;
		}
		if ($data35.equalsIgnoreCase(name)) {
			data35(value);
			return;
		}
		if ($data36.equalsIgnoreCase(name)) {
			data36(value);
			return;
		}
		if ($data37.equalsIgnoreCase(name)) {
			data37(value);
			return;
		}
		if ($data38.equalsIgnoreCase(name)) {
			data38(value);
			return;
		}
		if ($data39.equalsIgnoreCase(name)) {
			data39(value);
			return;
		}
		if ($data40.equalsIgnoreCase(name)) {
			data40(value);
			return;
		}
		if ($data41.equalsIgnoreCase(name)) {
			data41(value);
			return;
		}
		if ($data42.equalsIgnoreCase(name)) {
			data42(value);
			return;
		}
		if ($data43.equalsIgnoreCase(name)) {
			data43(value);
			return;
		}
		if ($data44.equalsIgnoreCase(name)) {
			data44(value);
			return;
		}
		if ($data45.equalsIgnoreCase(name)) {
			data45(value);
			return;
		}
		if ($data46.equalsIgnoreCase(name)) {
			data46(value);
			return;
		}
		if ($data47.equalsIgnoreCase(name)) {
			data47(value);
			return;
		}
		if ($data48.equalsIgnoreCase(name)) {
			data48(value);
			return;
		}
		if ($data49.equalsIgnoreCase(name)) {
			data49(value);
			return;
		}
		if ($data50.equalsIgnoreCase(name)) {
			data50(value);
			return;
		}
		if ($data51.equalsIgnoreCase(name)) {
			data51(value);
			return;
		}
		if ($data52.equalsIgnoreCase(name)) {
			data52(value);
			return;
		}
		if ($data53.equalsIgnoreCase(name)) {
			data53(value);
			return;
		}
		if ($data54.equalsIgnoreCase(name)) {
			data54(value);
			return;
		}
		if ($data55.equalsIgnoreCase(name)) {
			data55(value);
			return;
		}
		if ($data56.equalsIgnoreCase(name)) {
			data56(value);
			return;
		}
		if ($data57.equalsIgnoreCase(name)) {
			data57(value);
			return;
		}
		if ($data58.equalsIgnoreCase(name)) {
			data58(value);
			return;
		}
		if ($data59.equalsIgnoreCase(name)) {
			data59(value);
			return;
		}
		if ($data60.equalsIgnoreCase(name)) {
			data60(value);
			return;
		}
		if ($data61.equalsIgnoreCase(name)) {
			data61(value);
			return;
		}
		if ($data62.equalsIgnoreCase(name)) {
			data62(value);
			return;
		}
		if ($data63.equalsIgnoreCase(name)) {
			data63(value);
			return;
		}
		if ($data64.equalsIgnoreCase(name)) {
			data64(value);
			return;
		}
		if ($data65.equalsIgnoreCase(name)) {
			data65(value);
			return;
		}
		if ($data66.equalsIgnoreCase(name)) {
			data66(value);
			return;
		}
		if ($data67.equalsIgnoreCase(name)) {
			data67(value);
			return;
		}
		if ($data68.equalsIgnoreCase(name)) {
			data68(value);
			return;
		}
		if ($data69.equalsIgnoreCase(name)) {
			data69(value);
			return;
		}
		if ($data70.equalsIgnoreCase(name)) {
			data70(value);
			return;
		}
		if ($data71.equalsIgnoreCase(name)) {
			data71(value);
			return;
		}
		if ($data72.equalsIgnoreCase(name)) {
			data72(value);
			return;
		}
		if ($data73.equalsIgnoreCase(name)) {
			data73(value);
			return;
		}
		if ($data74.equalsIgnoreCase(name)) {
			data74(value);
			return;
		}
		if ($data75.equalsIgnoreCase(name)) {
			data75(value);
			return;
		}
		if ($data76.equalsIgnoreCase(name)) {
			data76(value);
			return;
		}
		if ($data77.equalsIgnoreCase(name)) {
			data77(value);
			return;
		}
		if ($data78.equalsIgnoreCase(name)) {
			data78(value);
			return;
		}
		if ($data79.equalsIgnoreCase(name)) {
			data79(value);
			return;
		}
		if ($data80.equalsIgnoreCase(name)) {
			data80(value);
			return;
		}
		if ($data81.equalsIgnoreCase(name)) {
			data81(value);
			return;
		}
		if ($data82.equalsIgnoreCase(name)) {
			data82(value);
			return;
		}
		if ($data83.equalsIgnoreCase(name)) {
			data83(value);
			return;
		}
		if ($data84.equalsIgnoreCase(name)) {
			data84(value);
			return;
		}
		if ($data85.equalsIgnoreCase(name)) {
			data85(value);
			return;
		}
		if ($data86.equalsIgnoreCase(name)) {
			data86(value);
			return;
		}
		if ($data87.equalsIgnoreCase(name)) {
			data87(value);
			return;
		}
		if ($data88.equalsIgnoreCase(name)) {
			data88(value);
			return;
		}
		if ($data89.equalsIgnoreCase(name)) {
			data89(value);
			return;
		}
		if ($data90.equalsIgnoreCase(name)) {
			data90(value);
			return;
		}
		if ($data91.equalsIgnoreCase(name)) {
			data91(value);
			return;
		}
		if ($data92.equalsIgnoreCase(name)) {
			data92(value);
			return;
		}
		if ($data93.equalsIgnoreCase(name)) {
			data93(value);
			return;
		}
		if ($data94.equalsIgnoreCase(name)) {
			data94(value);
			return;
		}
		if ($data95.equalsIgnoreCase(name)) {
			data95(value);
			return;
		}
		if ($data96.equalsIgnoreCase(name)) {
			data96(value);
			return;
		}
		if ($data97.equalsIgnoreCase(name)) {
			data97(value);
			return;
		}
		if ($data98.equalsIgnoreCase(name)) {
			data98(value);
			return;
		}
		if ($data99.equalsIgnoreCase(name)) {
			data99(value);
			return;
		}
		if ($data100.equalsIgnoreCase(name)) {
			data100(value);
			return;
		}
		if ($dat_typ.equalsIgnoreCase(name)) {
			dat_typ(value);
			return;
		}
		if ($par_col_nm.equalsIgnoreCase(name)) {
			par_col_nm(value);
			return;
		}
		super.setString(name, value);
	}
	public void setNumber(String name, MCNumber value) {
		if ($par_col_idx.equalsIgnoreCase(name)) {
			par_col_idx(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, int value) {
		if ($par_col_idx.equalsIgnoreCase(name)) {
			par_col_idx(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, long value) {
		if ($par_col_idx.equalsIgnoreCase(name)) {
			par_col_idx(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, float value) {
		if ($par_col_idx.equalsIgnoreCase(name)) {
			par_col_idx(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, double value) {
		if ($par_col_idx.equalsIgnoreCase(name)) {
			par_col_idx(value);
			return;
		}
		super.setNumber(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($title.equalsIgnoreCase(name)) {
			title(value);
			return;
		}
		if ($data1.equalsIgnoreCase(name)) {
			data1(value);
			return;
		}
		if ($data2.equalsIgnoreCase(name)) {
			data2(value);
			return;
		}
		if ($data3.equalsIgnoreCase(name)) {
			data3(value);
			return;
		}
		if ($data4.equalsIgnoreCase(name)) {
			data4(value);
			return;
		}
		if ($data5.equalsIgnoreCase(name)) {
			data5(value);
			return;
		}
		if ($data6.equalsIgnoreCase(name)) {
			data6(value);
			return;
		}
		if ($data7.equalsIgnoreCase(name)) {
			data7(value);
			return;
		}
		if ($data8.equalsIgnoreCase(name)) {
			data8(value);
			return;
		}
		if ($data9.equalsIgnoreCase(name)) {
			data9(value);
			return;
		}
		if ($data10.equalsIgnoreCase(name)) {
			data10(value);
			return;
		}
		if ($data11.equalsIgnoreCase(name)) {
			data11(value);
			return;
		}
		if ($data12.equalsIgnoreCase(name)) {
			data12(value);
			return;
		}
		if ($data13.equalsIgnoreCase(name)) {
			data13(value);
			return;
		}
		if ($data14.equalsIgnoreCase(name)) {
			data14(value);
			return;
		}
		if ($data15.equalsIgnoreCase(name)) {
			data15(value);
			return;
		}
		if ($data16.equalsIgnoreCase(name)) {
			data16(value);
			return;
		}
		if ($data17.equalsIgnoreCase(name)) {
			data17(value);
			return;
		}
		if ($data18.equalsIgnoreCase(name)) {
			data18(value);
			return;
		}
		if ($data19.equalsIgnoreCase(name)) {
			data19(value);
			return;
		}
		if ($data20.equalsIgnoreCase(name)) {
			data20(value);
			return;
		}
		if ($data21.equalsIgnoreCase(name)) {
			data21(value);
			return;
		}
		if ($data22.equalsIgnoreCase(name)) {
			data22(value);
			return;
		}
		if ($data23.equalsIgnoreCase(name)) {
			data23(value);
			return;
		}
		if ($data24.equalsIgnoreCase(name)) {
			data24(value);
			return;
		}
		if ($data25.equalsIgnoreCase(name)) {
			data25(value);
			return;
		}
		if ($data26.equalsIgnoreCase(name)) {
			data26(value);
			return;
		}
		if ($data27.equalsIgnoreCase(name)) {
			data27(value);
			return;
		}
		if ($data28.equalsIgnoreCase(name)) {
			data28(value);
			return;
		}
		if ($data29.equalsIgnoreCase(name)) {
			data29(value);
			return;
		}
		if ($data30.equalsIgnoreCase(name)) {
			data30(value);
			return;
		}
		if ($data31.equalsIgnoreCase(name)) {
			data31(value);
			return;
		}
		if ($data32.equalsIgnoreCase(name)) {
			data32(value);
			return;
		}
		if ($data33.equalsIgnoreCase(name)) {
			data33(value);
			return;
		}
		if ($data34.equalsIgnoreCase(name)) {
			data34(value);
			return;
		}
		if ($data35.equalsIgnoreCase(name)) {
			data35(value);
			return;
		}
		if ($data36.equalsIgnoreCase(name)) {
			data36(value);
			return;
		}
		if ($data37.equalsIgnoreCase(name)) {
			data37(value);
			return;
		}
		if ($data38.equalsIgnoreCase(name)) {
			data38(value);
			return;
		}
		if ($data39.equalsIgnoreCase(name)) {
			data39(value);
			return;
		}
		if ($data40.equalsIgnoreCase(name)) {
			data40(value);
			return;
		}
		if ($data41.equalsIgnoreCase(name)) {
			data41(value);
			return;
		}
		if ($data42.equalsIgnoreCase(name)) {
			data42(value);
			return;
		}
		if ($data43.equalsIgnoreCase(name)) {
			data43(value);
			return;
		}
		if ($data44.equalsIgnoreCase(name)) {
			data44(value);
			return;
		}
		if ($data45.equalsIgnoreCase(name)) {
			data45(value);
			return;
		}
		if ($data46.equalsIgnoreCase(name)) {
			data46(value);
			return;
		}
		if ($data47.equalsIgnoreCase(name)) {
			data47(value);
			return;
		}
		if ($data48.equalsIgnoreCase(name)) {
			data48(value);
			return;
		}
		if ($data49.equalsIgnoreCase(name)) {
			data49(value);
			return;
		}
		if ($data50.equalsIgnoreCase(name)) {
			data50(value);
			return;
		}
		if ($data51.equalsIgnoreCase(name)) {
			data51(value);
			return;
		}
		if ($data52.equalsIgnoreCase(name)) {
			data52(value);
			return;
		}
		if ($data53.equalsIgnoreCase(name)) {
			data53(value);
			return;
		}
		if ($data54.equalsIgnoreCase(name)) {
			data54(value);
			return;
		}
		if ($data55.equalsIgnoreCase(name)) {
			data55(value);
			return;
		}
		if ($data56.equalsIgnoreCase(name)) {
			data56(value);
			return;
		}
		if ($data57.equalsIgnoreCase(name)) {
			data57(value);
			return;
		}
		if ($data58.equalsIgnoreCase(name)) {
			data58(value);
			return;
		}
		if ($data59.equalsIgnoreCase(name)) {
			data59(value);
			return;
		}
		if ($data60.equalsIgnoreCase(name)) {
			data60(value);
			return;
		}
		if ($data61.equalsIgnoreCase(name)) {
			data61(value);
			return;
		}
		if ($data62.equalsIgnoreCase(name)) {
			data62(value);
			return;
		}
		if ($data63.equalsIgnoreCase(name)) {
			data63(value);
			return;
		}
		if ($data64.equalsIgnoreCase(name)) {
			data64(value);
			return;
		}
		if ($data65.equalsIgnoreCase(name)) {
			data65(value);
			return;
		}
		if ($data66.equalsIgnoreCase(name)) {
			data66(value);
			return;
		}
		if ($data67.equalsIgnoreCase(name)) {
			data67(value);
			return;
		}
		if ($data68.equalsIgnoreCase(name)) {
			data68(value);
			return;
		}
		if ($data69.equalsIgnoreCase(name)) {
			data69(value);
			return;
		}
		if ($data70.equalsIgnoreCase(name)) {
			data70(value);
			return;
		}
		if ($data71.equalsIgnoreCase(name)) {
			data71(value);
			return;
		}
		if ($data72.equalsIgnoreCase(name)) {
			data72(value);
			return;
		}
		if ($data73.equalsIgnoreCase(name)) {
			data73(value);
			return;
		}
		if ($data74.equalsIgnoreCase(name)) {
			data74(value);
			return;
		}
		if ($data75.equalsIgnoreCase(name)) {
			data75(value);
			return;
		}
		if ($data76.equalsIgnoreCase(name)) {
			data76(value);
			return;
		}
		if ($data77.equalsIgnoreCase(name)) {
			data77(value);
			return;
		}
		if ($data78.equalsIgnoreCase(name)) {
			data78(value);
			return;
		}
		if ($data79.equalsIgnoreCase(name)) {
			data79(value);
			return;
		}
		if ($data80.equalsIgnoreCase(name)) {
			data80(value);
			return;
		}
		if ($data81.equalsIgnoreCase(name)) {
			data81(value);
			return;
		}
		if ($data82.equalsIgnoreCase(name)) {
			data82(value);
			return;
		}
		if ($data83.equalsIgnoreCase(name)) {
			data83(value);
			return;
		}
		if ($data84.equalsIgnoreCase(name)) {
			data84(value);
			return;
		}
		if ($data85.equalsIgnoreCase(name)) {
			data85(value);
			return;
		}
		if ($data86.equalsIgnoreCase(name)) {
			data86(value);
			return;
		}
		if ($data87.equalsIgnoreCase(name)) {
			data87(value);
			return;
		}
		if ($data88.equalsIgnoreCase(name)) {
			data88(value);
			return;
		}
		if ($data89.equalsIgnoreCase(name)) {
			data89(value);
			return;
		}
		if ($data90.equalsIgnoreCase(name)) {
			data90(value);
			return;
		}
		if ($data91.equalsIgnoreCase(name)) {
			data91(value);
			return;
		}
		if ($data92.equalsIgnoreCase(name)) {
			data92(value);
			return;
		}
		if ($data93.equalsIgnoreCase(name)) {
			data93(value);
			return;
		}
		if ($data94.equalsIgnoreCase(name)) {
			data94(value);
			return;
		}
		if ($data95.equalsIgnoreCase(name)) {
			data95(value);
			return;
		}
		if ($data96.equalsIgnoreCase(name)) {
			data96(value);
			return;
		}
		if ($data97.equalsIgnoreCase(name)) {
			data97(value);
			return;
		}
		if ($data98.equalsIgnoreCase(name)) {
			data98(value);
			return;
		}
		if ($data99.equalsIgnoreCase(name)) {
			data99(value);
			return;
		}
		if ($data100.equalsIgnoreCase(name)) {
			data100(value);
			return;
		}
		if ($dat_typ.equalsIgnoreCase(name)) {
			dat_typ(value);
			return;
		}
		if ($par_col_nm.equalsIgnoreCase(name)) {
			par_col_nm(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setNumberNE(String name, MCNumber value) {
		if ($par_col_idx.equalsIgnoreCase(name)) {
			par_col_idx(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, int value) {
		if ($par_col_idx.equalsIgnoreCase(name)) {
			par_col_idx(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, long value) {
		if ($par_col_idx.equalsIgnoreCase(name)) {
			par_col_idx(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, float value) {
		if ($par_col_idx.equalsIgnoreCase(name)) {
			par_col_idx(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, double value) {
		if ($par_col_idx.equalsIgnoreCase(name)) {
			par_col_idx(value);
			return;
		}
		super.setNumberNE(name, value);
	}



}

