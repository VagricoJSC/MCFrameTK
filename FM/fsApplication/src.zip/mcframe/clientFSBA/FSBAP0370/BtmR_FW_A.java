package mcframe.clientFSBA.FSBAP0370;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Btm"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class BtmR_FW_A extends MCConstRow {

	/**
	 *  データ件数.<p>
	 *
	 */
	public static final String $cnt = "cnt";
	/**
	 *  開始行.<p>
	 *
	 */
	public static final String $fr = "fr";
	/**
	 *  終了行.<p>
	 *
	 */
	public static final String $to = "to";
	/**
	 *  簡易入力.<p>
	 *
	 */
	public static final String $input = "input";
	public static final String $h_align_type = "h_align_type";
	/**
	 *  値の横位置.<p>
	 *
	 */
	public static final String $h_align_type_nm = "h_align_type_nm";


	public static final MCMeta cnt_META = createNumberMeta($cnt);
	public static final MCMeta fr_META = createNumberMeta($fr);
	public static final MCMeta to_META = createNumberMeta($to);
	public static final MCMeta input_META = createCommonMeta($input, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta h_align_type_META = createStringMeta($h_align_type);
	public static final MCMeta h_align_type_nm_META = createStringMeta($h_align_type_nm);

	protected static final ConstMetaList<BtmR> constMetas = new ConstMetaList<BtmR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			cnt_META,
			fr_META,
			to_META,
			input_META,
			h_align_type_META,
			h_align_type_nm_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected BtmR_FW_A(ConstMetaList<? extends BtmR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public BtmR clone() {
		return (BtmR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public BtmR createInstance() {
		return (BtmR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public BtmR getValues(String... names) {
		return (BtmR) super.getValues(names);
	}



	/**
	 *  データ件数.<p>
	 *
	 */
	public MCNumber cnt() {
		return getConstNumber(offset + 0, $cnt);
	}

	/**
	 *  データ件数.<p>
	 *
	 */
	public void cnt(MCNumber value) {
		setConstNumber(offset + 0, $cnt, value);
	}

	/**
	 *  データ件数.<p>
	 *
	 */
	public void cnt(int value) {
		setConstNumber(offset + 0, $cnt, value);
	}

	/**
	 *  データ件数.<p>
	 *
	 */
	public void cnt(long value) {
		setConstNumber(offset + 0, $cnt, value);
	}

	/**
	 *  データ件数.<p>
	 *
	 */
	public void cnt(float value) {
		setConstNumber(offset + 0, $cnt, value);
	}

	/**
	 *  データ件数.<p>
	 *
	 */
	public void cnt(double value) {
		setConstNumber(offset + 0, $cnt, value);
	}


	/**
	 *  開始行.<p>
	 *
	 */
	public MCNumber fr() {
		return getConstNumber(offset + 1, $fr);
	}

	/**
	 *  開始行.<p>
	 *
	 */
	public void fr(MCNumber value) {
		setConstNumber(offset + 1, $fr, value);
	}

	/**
	 *  開始行.<p>
	 *
	 */
	public void fr(int value) {
		setConstNumber(offset + 1, $fr, value);
	}

	/**
	 *  開始行.<p>
	 *
	 */
	public void fr(long value) {
		setConstNumber(offset + 1, $fr, value);
	}

	/**
	 *  開始行.<p>
	 *
	 */
	public void fr(float value) {
		setConstNumber(offset + 1, $fr, value);
	}

	/**
	 *  開始行.<p>
	 *
	 */
	public void fr(double value) {
		setConstNumber(offset + 1, $fr, value);
	}


	/**
	 *  終了行.<p>
	 *
	 */
	public MCNumber to() {
		return getConstNumber(offset + 2, $to);
	}

	/**
	 *  終了行.<p>
	 *
	 */
	public void to(MCNumber value) {
		setConstNumber(offset + 2, $to, value);
	}

	/**
	 *  終了行.<p>
	 *
	 */
	public void to(int value) {
		setConstNumber(offset + 2, $to, value);
	}

	/**
	 *  終了行.<p>
	 *
	 */
	public void to(long value) {
		setConstNumber(offset + 2, $to, value);
	}

	/**
	 *  終了行.<p>
	 *
	 */
	public void to(float value) {
		setConstNumber(offset + 2, $to, value);
	}

	/**
	 *  終了行.<p>
	 *
	 */
	public void to(double value) {
		setConstNumber(offset + 2, $to, value);
	}


	/**
	 *  簡易入力.<p>
	 *
	 */
	public boolean input() {
		return getConstBoolean(offset + 3, $input);
	}

	/**
	 *  簡易入力.<p>
	 *
	 */
	public void input(boolean value) {
		setConstBoolean(offset + 3, $input, value);
	}


	public String h_align_type() {
		return getConstString(offset + 4, $h_align_type);
	}

	public void h_align_type(String value) {
		setConstString(offset + 4, $h_align_type, value);
	}


	/**
	 *  値の横位置.<p>
	 *
	 */
	public String h_align_type_nm() {
		return getConstString(offset + 5, $h_align_type_nm);
	}

	/**
	 *  値の横位置.<p>
	 *
	 */
	public void h_align_type_nm(String value) {
		setConstString(offset + 5, $h_align_type_nm, value);
	}


	public String getString(String name) {
		if ($h_align_type.equalsIgnoreCase(name)) {
			return h_align_type();
		}
		if ($h_align_type_nm.equalsIgnoreCase(name)) {
			return h_align_type_nm();
		}
		return super.getString(name);
	}
	public MCNumber getNumber(String name) {
		if ($cnt.equalsIgnoreCase(name)) {
			return cnt();
		}
		if ($fr.equalsIgnoreCase(name)) {
			return fr();
		}
		if ($to.equalsIgnoreCase(name)) {
			return to();
		}
		return super.getNumber(name);
	}
	public boolean getBoolean(String name) {
		if ($input.equalsIgnoreCase(name)) {
			return input();
		}
		return super.getBoolean(name);
	}

	public String getStringNE(String name) {
		if ($h_align_type.equalsIgnoreCase(name)) {
			return h_align_type();
		}
		if ($h_align_type_nm.equalsIgnoreCase(name)) {
			return h_align_type_nm();
		}
		return super.getStringNE(name);
	}
	public MCNumber getNumberNE(String name) {
		if ($cnt.equalsIgnoreCase(name)) {
			return cnt();
		}
		if ($fr.equalsIgnoreCase(name)) {
			return fr();
		}
		if ($to.equalsIgnoreCase(name)) {
			return to();
		}
		return super.getNumberNE(name);
	}
	public boolean getBooleanNE(String name) {
		if ($input.equalsIgnoreCase(name)) {
			return input();
		}
		return super.getBooleanNE(name);
	}

	public void setString(String name, String value) {
		if ($h_align_type.equalsIgnoreCase(name)) {
			h_align_type(value);
			return;
		}
		if ($h_align_type_nm.equalsIgnoreCase(name)) {
			h_align_type_nm(value);
			return;
		}
		super.setString(name, value);
	}
	public void setNumber(String name, MCNumber value) {
		if ($cnt.equalsIgnoreCase(name)) {
			cnt(value);
			return;
		}
		if ($fr.equalsIgnoreCase(name)) {
			fr(value);
			return;
		}
		if ($to.equalsIgnoreCase(name)) {
			to(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, int value) {
		if ($cnt.equalsIgnoreCase(name)) {
			cnt(value);
			return;
		}
		if ($fr.equalsIgnoreCase(name)) {
			fr(value);
			return;
		}
		if ($to.equalsIgnoreCase(name)) {
			to(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, long value) {
		if ($cnt.equalsIgnoreCase(name)) {
			cnt(value);
			return;
		}
		if ($fr.equalsIgnoreCase(name)) {
			fr(value);
			return;
		}
		if ($to.equalsIgnoreCase(name)) {
			to(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, float value) {
		if ($cnt.equalsIgnoreCase(name)) {
			cnt(value);
			return;
		}
		if ($fr.equalsIgnoreCase(name)) {
			fr(value);
			return;
		}
		if ($to.equalsIgnoreCase(name)) {
			to(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, double value) {
		if ($cnt.equalsIgnoreCase(name)) {
			cnt(value);
			return;
		}
		if ($fr.equalsIgnoreCase(name)) {
			fr(value);
			return;
		}
		if ($to.equalsIgnoreCase(name)) {
			to(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setBoolean(String name, boolean value) {
		if ($input.equalsIgnoreCase(name)) {
			input(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($h_align_type.equalsIgnoreCase(name)) {
			h_align_type(value);
			return;
		}
		if ($h_align_type_nm.equalsIgnoreCase(name)) {
			h_align_type_nm(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setNumberNE(String name, MCNumber value) {
		if ($cnt.equalsIgnoreCase(name)) {
			cnt(value);
			return;
		}
		if ($fr.equalsIgnoreCase(name)) {
			fr(value);
			return;
		}
		if ($to.equalsIgnoreCase(name)) {
			to(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, int value) {
		if ($cnt.equalsIgnoreCase(name)) {
			cnt(value);
			return;
		}
		if ($fr.equalsIgnoreCase(name)) {
			fr(value);
			return;
		}
		if ($to.equalsIgnoreCase(name)) {
			to(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, long value) {
		if ($cnt.equalsIgnoreCase(name)) {
			cnt(value);
			return;
		}
		if ($fr.equalsIgnoreCase(name)) {
			fr(value);
			return;
		}
		if ($to.equalsIgnoreCase(name)) {
			to(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, float value) {
		if ($cnt.equalsIgnoreCase(name)) {
			cnt(value);
			return;
		}
		if ($fr.equalsIgnoreCase(name)) {
			fr(value);
			return;
		}
		if ($to.equalsIgnoreCase(name)) {
			to(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, double value) {
		if ($cnt.equalsIgnoreCase(name)) {
			cnt(value);
			return;
		}
		if ($fr.equalsIgnoreCase(name)) {
			fr(value);
			return;
		}
		if ($to.equalsIgnoreCase(name)) {
			to(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setBooleanNE(String name, boolean value) {
		if ($input.equalsIgnoreCase(name)) {
			input(value);
			return;
		}
		super.setBooleanNE(name, value);
	}



}

