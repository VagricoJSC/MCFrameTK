package mcframe.clientFSBA.FSBAP0370;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBAP_VerticalView_D"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP_VerticalView_D_FW_A extends mcframe.clientFSUC.FSUCP0000.FSUCP_PanelBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0370";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [View]ブロック関連のField定義
	public MCPanel ViewPanel = null;
	public MCScrollPane ViewScrollPane = null;
	public MCTable2<mcframe.clientFSBA.FSBAP0370.ViewR> ViewTable = null;
	// [View]ブロックの項目のField定義
	/**
	 *  項目.<p>
	 *
	 */
	public MCColumnConfig columnView_title = null;
	/**
	 *  1.<p>
	 *
	 */
	public MCColumnConfig columnView_data1 = null;
	/**
	 *  2.<p>
	 *
	 */
	public MCColumnConfig columnView_data2 = null;
	/**
	 *  3.<p>
	 *
	 */
	public MCColumnConfig columnView_data3 = null;
	/**
	 *  4.<p>
	 *
	 */
	public MCColumnConfig columnView_data4 = null;
	/**
	 *  5.<p>
	 *
	 */
	public MCColumnConfig columnView_data5 = null;
	/**
	 *  6.<p>
	 *
	 */
	public MCColumnConfig columnView_data6 = null;
	/**
	 *  7.<p>
	 *
	 */
	public MCColumnConfig columnView_data7 = null;
	/**
	 *  8.<p>
	 *
	 */
	public MCColumnConfig columnView_data8 = null;
	/**
	 *  9.<p>
	 *
	 */
	public MCColumnConfig columnView_data9 = null;
	/**
	 *  10.<p>
	 *
	 */
	public MCColumnConfig columnView_data10 = null;
	/**
	 *  11.<p>
	 *
	 */
	public MCColumnConfig columnView_data11 = null;
	/**
	 *  12.<p>
	 *
	 */
	public MCColumnConfig columnView_data12 = null;
	/**
	 *  13.<p>
	 *
	 */
	public MCColumnConfig columnView_data13 = null;
	/**
	 *  14.<p>
	 *
	 */
	public MCColumnConfig columnView_data14 = null;
	/**
	 *  15.<p>
	 *
	 */
	public MCColumnConfig columnView_data15 = null;
	/**
	 *  16.<p>
	 *
	 */
	public MCColumnConfig columnView_data16 = null;
	/**
	 *  17.<p>
	 *
	 */
	public MCColumnConfig columnView_data17 = null;
	/**
	 *  18.<p>
	 *
	 */
	public MCColumnConfig columnView_data18 = null;
	/**
	 *  19.<p>
	 *
	 */
	public MCColumnConfig columnView_data19 = null;
	/**
	 *  20.<p>
	 *
	 */
	public MCColumnConfig columnView_data20 = null;
	/**
	 *  21.<p>
	 *
	 */
	public MCColumnConfig columnView_data21 = null;
	/**
	 *  22.<p>
	 *
	 */
	public MCColumnConfig columnView_data22 = null;
	/**
	 *  23.<p>
	 *
	 */
	public MCColumnConfig columnView_data23 = null;
	/**
	 *  24.<p>
	 *
	 */
	public MCColumnConfig columnView_data24 = null;
	/**
	 *  25.<p>
	 *
	 */
	public MCColumnConfig columnView_data25 = null;
	/**
	 *  26.<p>
	 *
	 */
	public MCColumnConfig columnView_data26 = null;
	/**
	 *  27.<p>
	 *
	 */
	public MCColumnConfig columnView_data27 = null;
	/**
	 *  28.<p>
	 *
	 */
	public MCColumnConfig columnView_data28 = null;
	/**
	 *  29.<p>
	 *
	 */
	public MCColumnConfig columnView_data29 = null;
	/**
	 *  30.<p>
	 *
	 */
	public MCColumnConfig columnView_data30 = null;
	/**
	 *  31.<p>
	 *
	 */
	public MCColumnConfig columnView_data31 = null;
	/**
	 *  32.<p>
	 *
	 */
	public MCColumnConfig columnView_data32 = null;
	/**
	 *  33.<p>
	 *
	 */
	public MCColumnConfig columnView_data33 = null;
	/**
	 *  34.<p>
	 *
	 */
	public MCColumnConfig columnView_data34 = null;
	/**
	 *  35.<p>
	 *
	 */
	public MCColumnConfig columnView_data35 = null;
	/**
	 *  36.<p>
	 *
	 */
	public MCColumnConfig columnView_data36 = null;
	/**
	 *  37.<p>
	 *
	 */
	public MCColumnConfig columnView_data37 = null;
	/**
	 *  38.<p>
	 *
	 */
	public MCColumnConfig columnView_data38 = null;
	/**
	 *  39.<p>
	 *
	 */
	public MCColumnConfig columnView_data39 = null;
	/**
	 *  40.<p>
	 *
	 */
	public MCColumnConfig columnView_data40 = null;
	/**
	 *  41.<p>
	 *
	 */
	public MCColumnConfig columnView_data41 = null;
	/**
	 *  42.<p>
	 *
	 */
	public MCColumnConfig columnView_data42 = null;
	/**
	 *  43.<p>
	 *
	 */
	public MCColumnConfig columnView_data43 = null;
	/**
	 *  44.<p>
	 *
	 */
	public MCColumnConfig columnView_data44 = null;
	/**
	 *  45.<p>
	 *
	 */
	public MCColumnConfig columnView_data45 = null;
	/**
	 *  46.<p>
	 *
	 */
	public MCColumnConfig columnView_data46 = null;
	/**
	 *  47.<p>
	 *
	 */
	public MCColumnConfig columnView_data47 = null;
	/**
	 *  48.<p>
	 *
	 */
	public MCColumnConfig columnView_data48 = null;
	/**
	 *  49.<p>
	 *
	 */
	public MCColumnConfig columnView_data49 = null;
	/**
	 *  50.<p>
	 *
	 */
	public MCColumnConfig columnView_data50 = null;
	/**
	 *  51.<p>
	 *
	 */
	public MCColumnConfig columnView_data51 = null;
	/**
	 *  52.<p>
	 *
	 */
	public MCColumnConfig columnView_data52 = null;
	/**
	 *  53.<p>
	 *
	 */
	public MCColumnConfig columnView_data53 = null;
	/**
	 *  54.<p>
	 *
	 */
	public MCColumnConfig columnView_data54 = null;
	/**
	 *  55.<p>
	 *
	 */
	public MCColumnConfig columnView_data55 = null;
	/**
	 *  56.<p>
	 *
	 */
	public MCColumnConfig columnView_data56 = null;
	/**
	 *  57.<p>
	 *
	 */
	public MCColumnConfig columnView_data57 = null;
	/**
	 *  58.<p>
	 *
	 */
	public MCColumnConfig columnView_data58 = null;
	/**
	 *  59.<p>
	 *
	 */
	public MCColumnConfig columnView_data59 = null;
	/**
	 *  60.<p>
	 *
	 */
	public MCColumnConfig columnView_data60 = null;
	/**
	 *  61.<p>
	 *
	 */
	public MCColumnConfig columnView_data61 = null;
	/**
	 *  62.<p>
	 *
	 */
	public MCColumnConfig columnView_data62 = null;
	/**
	 *  63.<p>
	 *
	 */
	public MCColumnConfig columnView_data63 = null;
	/**
	 *  64.<p>
	 *
	 */
	public MCColumnConfig columnView_data64 = null;
	/**
	 *  65.<p>
	 *
	 */
	public MCColumnConfig columnView_data65 = null;
	/**
	 *  66.<p>
	 *
	 */
	public MCColumnConfig columnView_data66 = null;
	/**
	 *  67.<p>
	 *
	 */
	public MCColumnConfig columnView_data67 = null;
	/**
	 *  68.<p>
	 *
	 */
	public MCColumnConfig columnView_data68 = null;
	/**
	 *  69.<p>
	 *
	 */
	public MCColumnConfig columnView_data69 = null;
	/**
	 *  70.<p>
	 *
	 */
	public MCColumnConfig columnView_data70 = null;
	/**
	 *  71.<p>
	 *
	 */
	public MCColumnConfig columnView_data71 = null;
	/**
	 *  72.<p>
	 *
	 */
	public MCColumnConfig columnView_data72 = null;
	/**
	 *  73.<p>
	 *
	 */
	public MCColumnConfig columnView_data73 = null;
	/**
	 *  74.<p>
	 *
	 */
	public MCColumnConfig columnView_data74 = null;
	/**
	 *  75.<p>
	 *
	 */
	public MCColumnConfig columnView_data75 = null;
	/**
	 *  76.<p>
	 *
	 */
	public MCColumnConfig columnView_data76 = null;
	/**
	 *  77.<p>
	 *
	 */
	public MCColumnConfig columnView_data77 = null;
	/**
	 *  78.<p>
	 *
	 */
	public MCColumnConfig columnView_data78 = null;
	/**
	 *  79.<p>
	 *
	 */
	public MCColumnConfig columnView_data79 = null;
	/**
	 *  80.<p>
	 *
	 */
	public MCColumnConfig columnView_data80 = null;
	/**
	 *  81.<p>
	 *
	 */
	public MCColumnConfig columnView_data81 = null;
	/**
	 *  82.<p>
	 *
	 */
	public MCColumnConfig columnView_data82 = null;
	/**
	 *  83.<p>
	 *
	 */
	public MCColumnConfig columnView_data83 = null;
	/**
	 *  84.<p>
	 *
	 */
	public MCColumnConfig columnView_data84 = null;
	/**
	 *  85.<p>
	 *
	 */
	public MCColumnConfig columnView_data85 = null;
	/**
	 *  86.<p>
	 *
	 */
	public MCColumnConfig columnView_data86 = null;
	/**
	 *  87.<p>
	 *
	 */
	public MCColumnConfig columnView_data87 = null;
	/**
	 *  88.<p>
	 *
	 */
	public MCColumnConfig columnView_data88 = null;
	/**
	 *  89.<p>
	 *
	 */
	public MCColumnConfig columnView_data89 = null;
	/**
	 *  90.<p>
	 *
	 */
	public MCColumnConfig columnView_data90 = null;
	/**
	 *  91.<p>
	 *
	 */
	public MCColumnConfig columnView_data91 = null;
	/**
	 *  92.<p>
	 *
	 */
	public MCColumnConfig columnView_data92 = null;
	/**
	 *  93.<p>
	 *
	 */
	public MCColumnConfig columnView_data93 = null;
	/**
	 *  94.<p>
	 *
	 */
	public MCColumnConfig columnView_data94 = null;
	/**
	 *  95.<p>
	 *
	 */
	public MCColumnConfig columnView_data95 = null;
	/**
	 *  96.<p>
	 *
	 */
	public MCColumnConfig columnView_data96 = null;
	/**
	 *  97.<p>
	 *
	 */
	public MCColumnConfig columnView_data97 = null;
	/**
	 *  98.<p>
	 *
	 */
	public MCColumnConfig columnView_data98 = null;
	/**
	 *  99.<p>
	 *
	 */
	public MCColumnConfig columnView_data99 = null;
	/**
	 *  100.<p>
	 *
	 */
	public MCColumnConfig columnView_data100 = null;
	// [Btm]ブロック関連のField定義
	public MCPanel BtmPanel = null;
	// [Btm]ブロックの項目のField定義
	/**
	 *  データ件数.<p>
	 *
	 */
	public MCNumberField Btm_cnt = null;
	public MCLabel Btm_fr_Label = null;
	/**
	 *  開始行.<p>
	 *
	 */
	public MCNumberField Btm_fr = null;
	public MCLabel Btm_to_Label = null;
	/**
	 *  終了行.<p>
	 *
	 */
	public MCNumberField Btm_to = null;
	/**
	 *  前.<p>
	 *
	 */
	public MCButton Btm_prev = null;
	/**
	 *  次.<p>
	 *
	 */
	public MCButton Btm_next = null;
	/**
	 *  簡易入力.<p>
	 *
	 */
	public MCCheckBox Btm_input = null;
	public MCTextField Btm_h_align_type = null;
	public MCLabel Btm_h_align_type_nm_Label = null;
	/**
	 *  値の横位置.<p>
	 *
	 */
	public MCTextComboBox Btm_h_align_type_nm = null;
	public mcframe.clientFSUB.FSUBP0080.FSUBP_ParScreenNm_H Btm_par_screen_nm_p_PPanel;
	/** [SRCH]モードを表す定数 */
	public static final String SRCH = "SRCH";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{SRCH};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	
	/** [View]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0370.ViewR> aViewL;
	/** [Btm]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0370.BtmR aBtmR;

	/**
	 * コピーによってaViewLを設定します。
	 *
	 * aViewLのインスタンスは変更されません。
	 *
	 * @param dataset ViewL
	 */
	public void setViewL(MCList<mcframe.clientFSBA.FSBAP0370.ViewR> aList) {
		if (getViewL() != aList) {
			getViewL().setAll(aList);
		}
	}

	/**
	 * [View]ブロックのコンテナaViewLを返します。
	 *
	 * @return ViewL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0370.ViewR> getViewL() {
		return aViewL;
	}

	/**
	 * aViewRを作成します。
	 *
	 * @return ViewR
	 */
	public mcframe.clientFSBA.FSBAP0370.ViewR createViewR() {
		return mcframe.clientFSBA.FSBAP0370.ViewR.create();
	}

	/**
	 * aViewLを作成します。
	 *
	 * @return ViewL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0370.ViewR> createViewL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0370.ViewR.class);
	}

	/**
	 * ViewTableを初期化します。
	 */
	protected void createViewTable(){
		if(ViewTable == null){
			ViewTable = beansFactory.createTable2("View.table");
		}
	}

	/**
	 * 項目コピーによってaBtmRを設定します。
	 *
	 * aBtmRのインスタンスは変更されません。
	 *
	 * @param row BtmR
	 */
	public void setBtmR(mcframe.clientFSBA.FSBAP0370.BtmR row) {
		if (row != null) {
			MCRow.copyall(getBtmR(), row);
		}
	}

	/**
	 * [Btm]ブロックのコンテナaBtmRを返します。
	 *
	 * @return BtmR
	 */
	public mcframe.clientFSBA.FSBAP0370.BtmR getBtmR() {
		return aBtmR;
	}

	/**
	 * aBtmRを作成します。
	 *
	 * @return BtmR
	 */
	public mcframe.clientFSBA.FSBAP0370.BtmR createBtmR() {
		return mcframe.clientFSBA.FSBAP0370.BtmR.create();
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getViewL())) ret.add(getViewL());
		if(!MCCollectionUtil.contains(ret, getBtmR())) ret.add(getBtmR());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getViewL()) return "View";
		if(aCnt == getBtmR()) return "Btm";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("View")) return getViewL();
		if(bId.equals("Btm")) return getBtmR();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(ViewPanel);
		ret.add(BtmPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_VerticalView_D_FW_A() {
		aViewL = createViewL();
		aBtmR = createBtmR();

	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_VerticalView_D_FW_A(String name) {
		aViewL = createViewL();
		createViewTable();
		ViewTable.setRowName(name);
		aBtmR = createBtmR();
	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP_VerticalView_D_FW.jbCreateView((FSBAP_VerticalView_D)this);
		FSBAP_VerticalView_D_FW.jbCreateBtm((FSBAP_VerticalView_D)this);
	}

	/**
	 * [View]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateView(FSBAP_VerticalView_D p) {
	}

	/**
	 * [Btm]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateBtm(FSBAP_VerticalView_D p) {
		p.Btm_par_screen_nm_p_PPanel = mcframe.clientFSUB.FSUBP0080.FSUBP_ParScreenNm_H.create();
		p.Btm_par_screen_nm_p_PPanel.setName("Btm.par_screen_nm_p");
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}

	
	/** [Btm_h_align_type_nm_ListPutter]の定義 */
	private MCListPutter Btm_h_align_type_nm_p = null;

	/**
	 * [Btm_h_align_type_nm_ListPutter]の取得
	 */
	protected MCListPutter getBtm_h_align_type_nm_ListPutter() {
		if (Btm_h_align_type_nm_p == null) {
			Btm_h_align_type_nm_p = createBtm_h_align_type_nm_ListPutter(Btm_h_align_type_nm, "h_align_type_nm", "h_align_type");

		}
		return Btm_h_align_type_nm_p;
	}
	

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP_VerticalView_D create(){
		FSBAP_VerticalView_D p = new FSBAP_VerticalView_D();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP_VerticalView_D create(String name){
		FSBAP_VerticalView_D p = new FSBAP_VerticalView_D(name);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP_VerticalView_D_FW.jbfInitView((FSBAP_VerticalView_D)this);
		FSBAP_VerticalView_D_FW.jbfInitBtm((FSBAP_VerticalView_D)this);
		FSBAP_VerticalView_D_FW.jbInitView((FSBAP_VerticalView_D)this);
		FSBAP_VerticalView_D_FW.jbInitBtm((FSBAP_VerticalView_D)this);
	}

	/**
	 * [View]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitView(FSBAP_VerticalView_D p) {
		// ブロック関連の初期化
		p.ViewPanel = p.beansFactory.createPanel("View");
		p.ViewScrollPane = p.beansFactory.createScrollPane("View.scroll");
		p.createViewTable();
		// ブロックの項目の初期化
		p.columnView_title = p.beansFactory.createTableColumn("View.title", MCColumnType.TEXT);
		p.columnView_data1 = p.beansFactory.createTableColumn("View.data1", MCColumnType.TEXT);
		p.columnView_data2 = p.beansFactory.createTableColumn("View.data2", MCColumnType.TEXT);
		p.columnView_data3 = p.beansFactory.createTableColumn("View.data3", MCColumnType.TEXT);
		p.columnView_data4 = p.beansFactory.createTableColumn("View.data4", MCColumnType.TEXT);
		p.columnView_data5 = p.beansFactory.createTableColumn("View.data5", MCColumnType.TEXT);
		p.columnView_data6 = p.beansFactory.createTableColumn("View.data6", MCColumnType.TEXT);
		p.columnView_data7 = p.beansFactory.createTableColumn("View.data7", MCColumnType.TEXT);
		p.columnView_data8 = p.beansFactory.createTableColumn("View.data8", MCColumnType.TEXT);
		p.columnView_data9 = p.beansFactory.createTableColumn("View.data9", MCColumnType.TEXT);
		p.columnView_data10 = p.beansFactory.createTableColumn("View.data10", MCColumnType.TEXT);
		p.columnView_data11 = p.beansFactory.createTableColumn("View.data11", MCColumnType.TEXT);
		p.columnView_data12 = p.beansFactory.createTableColumn("View.data12", MCColumnType.TEXT);
		p.columnView_data13 = p.beansFactory.createTableColumn("View.data13", MCColumnType.TEXT);
		p.columnView_data14 = p.beansFactory.createTableColumn("View.data14", MCColumnType.TEXT);
		p.columnView_data15 = p.beansFactory.createTableColumn("View.data15", MCColumnType.TEXT);
		p.columnView_data16 = p.beansFactory.createTableColumn("View.data16", MCColumnType.TEXT);
		p.columnView_data17 = p.beansFactory.createTableColumn("View.data17", MCColumnType.TEXT);
		p.columnView_data18 = p.beansFactory.createTableColumn("View.data18", MCColumnType.TEXT);
		p.columnView_data19 = p.beansFactory.createTableColumn("View.data19", MCColumnType.TEXT);
		p.columnView_data20 = p.beansFactory.createTableColumn("View.data20", MCColumnType.TEXT);
		p.columnView_data21 = p.beansFactory.createTableColumn("View.data21", MCColumnType.TEXT);
		p.columnView_data22 = p.beansFactory.createTableColumn("View.data22", MCColumnType.TEXT);
		p.columnView_data23 = p.beansFactory.createTableColumn("View.data23", MCColumnType.TEXT);
		p.columnView_data24 = p.beansFactory.createTableColumn("View.data24", MCColumnType.TEXT);
		p.columnView_data25 = p.beansFactory.createTableColumn("View.data25", MCColumnType.TEXT);
		p.columnView_data26 = p.beansFactory.createTableColumn("View.data26", MCColumnType.TEXT);
		p.columnView_data27 = p.beansFactory.createTableColumn("View.data27", MCColumnType.TEXT);
		p.columnView_data28 = p.beansFactory.createTableColumn("View.data28", MCColumnType.TEXT);
		p.columnView_data29 = p.beansFactory.createTableColumn("View.data29", MCColumnType.TEXT);
		p.columnView_data30 = p.beansFactory.createTableColumn("View.data30", MCColumnType.TEXT);
		p.columnView_data31 = p.beansFactory.createTableColumn("View.data31", MCColumnType.TEXT);
		p.columnView_data32 = p.beansFactory.createTableColumn("View.data32", MCColumnType.TEXT);
		p.columnView_data33 = p.beansFactory.createTableColumn("View.data33", MCColumnType.TEXT);
		p.columnView_data34 = p.beansFactory.createTableColumn("View.data34", MCColumnType.TEXT);
		p.columnView_data35 = p.beansFactory.createTableColumn("View.data35", MCColumnType.TEXT);
		p.columnView_data36 = p.beansFactory.createTableColumn("View.data36", MCColumnType.TEXT);
		p.columnView_data37 = p.beansFactory.createTableColumn("View.data37", MCColumnType.TEXT);
		p.columnView_data38 = p.beansFactory.createTableColumn("View.data38", MCColumnType.TEXT);
		p.columnView_data39 = p.beansFactory.createTableColumn("View.data39", MCColumnType.TEXT);
		p.columnView_data40 = p.beansFactory.createTableColumn("View.data40", MCColumnType.TEXT);
		p.columnView_data41 = p.beansFactory.createTableColumn("View.data41", MCColumnType.TEXT);
		p.columnView_data42 = p.beansFactory.createTableColumn("View.data42", MCColumnType.TEXT);
		p.columnView_data43 = p.beansFactory.createTableColumn("View.data43", MCColumnType.TEXT);
		p.columnView_data44 = p.beansFactory.createTableColumn("View.data44", MCColumnType.TEXT);
		p.columnView_data45 = p.beansFactory.createTableColumn("View.data45", MCColumnType.TEXT);
		p.columnView_data46 = p.beansFactory.createTableColumn("View.data46", MCColumnType.TEXT);
		p.columnView_data47 = p.beansFactory.createTableColumn("View.data47", MCColumnType.TEXT);
		p.columnView_data48 = p.beansFactory.createTableColumn("View.data48", MCColumnType.TEXT);
		p.columnView_data49 = p.beansFactory.createTableColumn("View.data49", MCColumnType.TEXT);
		p.columnView_data50 = p.beansFactory.createTableColumn("View.data50", MCColumnType.TEXT);
		p.columnView_data51 = p.beansFactory.createTableColumn("View.data51", MCColumnType.TEXT);
		p.columnView_data52 = p.beansFactory.createTableColumn("View.data52", MCColumnType.TEXT);
		p.columnView_data53 = p.beansFactory.createTableColumn("View.data53", MCColumnType.TEXT);
		p.columnView_data54 = p.beansFactory.createTableColumn("View.data54", MCColumnType.TEXT);
		p.columnView_data55 = p.beansFactory.createTableColumn("View.data55", MCColumnType.TEXT);
		p.columnView_data56 = p.beansFactory.createTableColumn("View.data56", MCColumnType.TEXT);
		p.columnView_data57 = p.beansFactory.createTableColumn("View.data57", MCColumnType.TEXT);
		p.columnView_data58 = p.beansFactory.createTableColumn("View.data58", MCColumnType.TEXT);
		p.columnView_data59 = p.beansFactory.createTableColumn("View.data59", MCColumnType.TEXT);
		p.columnView_data60 = p.beansFactory.createTableColumn("View.data60", MCColumnType.TEXT);
		p.columnView_data61 = p.beansFactory.createTableColumn("View.data61", MCColumnType.TEXT);
		p.columnView_data62 = p.beansFactory.createTableColumn("View.data62", MCColumnType.TEXT);
		p.columnView_data63 = p.beansFactory.createTableColumn("View.data63", MCColumnType.TEXT);
		p.columnView_data64 = p.beansFactory.createTableColumn("View.data64", MCColumnType.TEXT);
		p.columnView_data65 = p.beansFactory.createTableColumn("View.data65", MCColumnType.TEXT);
		p.columnView_data66 = p.beansFactory.createTableColumn("View.data66", MCColumnType.TEXT);
		p.columnView_data67 = p.beansFactory.createTableColumn("View.data67", MCColumnType.TEXT);
		p.columnView_data68 = p.beansFactory.createTableColumn("View.data68", MCColumnType.TEXT);
		p.columnView_data69 = p.beansFactory.createTableColumn("View.data69", MCColumnType.TEXT);
		p.columnView_data70 = p.beansFactory.createTableColumn("View.data70", MCColumnType.TEXT);
		p.columnView_data71 = p.beansFactory.createTableColumn("View.data71", MCColumnType.TEXT);
		p.columnView_data72 = p.beansFactory.createTableColumn("View.data72", MCColumnType.TEXT);
		p.columnView_data73 = p.beansFactory.createTableColumn("View.data73", MCColumnType.TEXT);
		p.columnView_data74 = p.beansFactory.createTableColumn("View.data74", MCColumnType.TEXT);
		p.columnView_data75 = p.beansFactory.createTableColumn("View.data75", MCColumnType.TEXT);
		p.columnView_data76 = p.beansFactory.createTableColumn("View.data76", MCColumnType.TEXT);
		p.columnView_data77 = p.beansFactory.createTableColumn("View.data77", MCColumnType.TEXT);
		p.columnView_data78 = p.beansFactory.createTableColumn("View.data78", MCColumnType.TEXT);
		p.columnView_data79 = p.beansFactory.createTableColumn("View.data79", MCColumnType.TEXT);
		p.columnView_data80 = p.beansFactory.createTableColumn("View.data80", MCColumnType.TEXT);
		p.columnView_data81 = p.beansFactory.createTableColumn("View.data81", MCColumnType.TEXT);
		p.columnView_data82 = p.beansFactory.createTableColumn("View.data82", MCColumnType.TEXT);
		p.columnView_data83 = p.beansFactory.createTableColumn("View.data83", MCColumnType.TEXT);
		p.columnView_data84 = p.beansFactory.createTableColumn("View.data84", MCColumnType.TEXT);
		p.columnView_data85 = p.beansFactory.createTableColumn("View.data85", MCColumnType.TEXT);
		p.columnView_data86 = p.beansFactory.createTableColumn("View.data86", MCColumnType.TEXT);
		p.columnView_data87 = p.beansFactory.createTableColumn("View.data87", MCColumnType.TEXT);
		p.columnView_data88 = p.beansFactory.createTableColumn("View.data88", MCColumnType.TEXT);
		p.columnView_data89 = p.beansFactory.createTableColumn("View.data89", MCColumnType.TEXT);
		p.columnView_data90 = p.beansFactory.createTableColumn("View.data90", MCColumnType.TEXT);
		p.columnView_data91 = p.beansFactory.createTableColumn("View.data91", MCColumnType.TEXT);
		p.columnView_data92 = p.beansFactory.createTableColumn("View.data92", MCColumnType.TEXT);
		p.columnView_data93 = p.beansFactory.createTableColumn("View.data93", MCColumnType.TEXT);
		p.columnView_data94 = p.beansFactory.createTableColumn("View.data94", MCColumnType.TEXT);
		p.columnView_data95 = p.beansFactory.createTableColumn("View.data95", MCColumnType.TEXT);
		p.columnView_data96 = p.beansFactory.createTableColumn("View.data96", MCColumnType.TEXT);
		p.columnView_data97 = p.beansFactory.createTableColumn("View.data97", MCColumnType.TEXT);
		p.columnView_data98 = p.beansFactory.createTableColumn("View.data98", MCColumnType.TEXT);
		p.columnView_data99 = p.beansFactory.createTableColumn("View.data99", MCColumnType.TEXT);
		p.columnView_data100 = p.beansFactory.createTableColumn("View.data100", MCColumnType.TEXT);
	}

	/**
	 * [Btm]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitBtm(FSBAP_VerticalView_D p) {
		// ブロック関連の初期化
		p.BtmPanel = p.beansFactory.createPanel("Btm");
		// ブロックの項目の初期化
		p.Btm_cnt = p.beansFactory.createNumberField("Btm.cnt");
		p.Btm_fr_Label = p.beansFactory.createLabel("Btm.fr_Label");
		p.Btm_fr = p.beansFactory.createNumberField("Btm.fr");
		p.Btm_fr.setLabel(p.Btm_fr_Label);
		p.Btm_to_Label = p.beansFactory.createLabel("Btm.to_Label");
		p.Btm_to = p.beansFactory.createNumberField("Btm.to");
		p.Btm_to.setLabel(p.Btm_to_Label);
		p.Btm_prev = p.beansFactory.createButton("Btm.prev", "no_border");
		p.Btm_next = p.beansFactory.createButton("Btm.next", "no_border");
		p.Btm_input = p.beansFactory.createCheckBox("Btm.input");
		p.Btm_h_align_type = p.beansFactory.createTextField("Btm.h_align_type");
		p.Btm_h_align_type_nm_Label = p.beansFactory.createLabel("Btm.h_align_type_nm_Label");
		p.Btm_h_align_type_nm = p.beansFactory.createTextComboBox("Btm.h_align_type_nm");
		p.Btm_h_align_type_nm.setLabel(p.Btm_h_align_type_nm_Label);
	}

	/**
	 * [View]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitView(FSBAP_VerticalView_D p) {
		// ブロック関連の初期化
		p.add(p.ViewPanel);
		p.setLastBeans(p.ViewPanel);
		p.ViewPanel.setNextBeans(p.BtmPanel);
		p.ViewPanel.add(p.ViewScrollPane);
		p.ViewPanel.setLastBeans(p.ViewTable);
		p.ViewScrollPane.setViewportView(p.ViewTable);
		p.ViewTable.setList(p.getViewL());
		p.ViewTable.setStatusColumnVisible(false);
		p.ViewPanel.setValueCheck(false);
		p.ViewPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * [Btm]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitBtm(FSBAP_VerticalView_D p) {
		// ブロック関連の初期化
		p.add(p.BtmPanel);
		p.BtmPanel.setValueCheck(false);
		p.BtmPanel.setLayoutPosition("S");
		// ブロックの項目の初期化
		p.BtmPanel.add(p.Btm_cnt);
		p.BtmPanel.setLastBeans(p.Btm_cnt);
		p.Btm_cnt.setNextBeans(p.Btm_fr);
		p.Btm_cnt.setRow(p.getBtmR(), mcframe.clientFSBA.FSBAP0370.BtmR.cnt_META);
		p.BtmPanel.add(p.Btm_fr_Label);
		p.BtmPanel.add(p.Btm_fr);
		p.Btm_fr.setNextBeans(p.Btm_to);
		p.Btm_fr.setRow(p.getBtmR(), mcframe.clientFSBA.FSBAP0370.BtmR.fr_META);
		p.BtmPanel.add(p.Btm_to_Label);
		p.BtmPanel.add(p.Btm_to);
		p.Btm_to.setNextBeans(p.Btm_prev);
		p.Btm_to.setRow(p.getBtmR(), mcframe.clientFSBA.FSBAP0370.BtmR.to_META);
		p.Btm_prev.setIcon("PREV");
		p.Btm_prev.setFunctionKey(MCFunctionKey.F13);
		p.BtmPanel.add(p.Btm_prev);
		p.Btm_prev.setNextBeans(p.Btm_next);
		p.Btm_next.setIcon("NEXT");
		p.Btm_next.setFunctionKey(MCFunctionKey.F14);
		p.BtmPanel.add(p.Btm_next);
		p.Btm_next.setNextBeans(p.Btm_input);
		p.BtmPanel.add(p.Btm_input);
		p.Btm_input.setNextBeans(p.Btm_h_align_type);
		p.Btm_input.setRow(p.getBtmR(), mcframe.clientFSBA.FSBAP0370.BtmR.input_META);
		p.BtmPanel.add(p.Btm_h_align_type);
		p.Btm_h_align_type.setNextBeans(p.Btm_h_align_type_nm);
		p.Btm_h_align_type.setRow(p.getBtmR(), mcframe.clientFSBA.FSBAP0370.BtmR.h_align_type_META);
		p.Btm_h_align_type_nm.setListType(MCListType.STRICT);
		p.Btm_h_align_type_nm.setLinkBeans(p.Btm_h_align_type);
		p.BtmPanel.add(p.Btm_h_align_type_nm_Label);
		p.BtmPanel.add(p.Btm_h_align_type_nm);
		p.Btm_h_align_type_nm.setNextBeans(p.Btm_par_screen_nm_p_PPanel);
		p.Btm_h_align_type_nm.setRow(p.getBtmR(), mcframe.clientFSBA.FSBAP0370.BtmR.h_align_type_nm_META);
		p.BtmPanel.add(p.Btm_par_screen_nm_p_PPanel);
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "G";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP_VerticalView_D_FW.mcInitView((FSBAP_VerticalView_D)this);
		FSBAP_VerticalView_D_FW.mcInitBtm((FSBAP_VerticalView_D)this);

		// [SRCH]ステータスのモードの設定
		FSBAP_VerticalView_D_FW.statusInitSRCH_View((FSBAP_VerticalView_D)this);
		FSBAP_VerticalView_D_FW.statusInitSRCH_Btm((FSBAP_VerticalView_D)this);

	}

	/**
	 *  [View]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitView(FSBAP_VerticalView_D p) {
		p.ViewTable.addAllListener(p);
		p.columnView_title.addAllListener(p);
		p.columnView_title.setListListener(p);
		p.columnView_data1.addAllListener(p);
		p.columnView_data1.setListListener(p);
		p.columnView_data2.addAllListener(p);
		p.columnView_data2.setListListener(p);
		p.columnView_data3.addAllListener(p);
		p.columnView_data3.setListListener(p);
		p.columnView_data4.addAllListener(p);
		p.columnView_data4.setListListener(p);
		p.columnView_data5.addAllListener(p);
		p.columnView_data5.setListListener(p);
		p.columnView_data6.addAllListener(p);
		p.columnView_data6.setListListener(p);
		p.columnView_data7.addAllListener(p);
		p.columnView_data7.setListListener(p);
		p.columnView_data8.addAllListener(p);
		p.columnView_data8.setListListener(p);
		p.columnView_data9.addAllListener(p);
		p.columnView_data9.setListListener(p);
		p.columnView_data10.addAllListener(p);
		p.columnView_data10.setListListener(p);
		p.columnView_data11.addAllListener(p);
		p.columnView_data11.setListListener(p);
		p.columnView_data12.addAllListener(p);
		p.columnView_data12.setListListener(p);
		p.columnView_data13.addAllListener(p);
		p.columnView_data13.setListListener(p);
		p.columnView_data14.addAllListener(p);
		p.columnView_data14.setListListener(p);
		p.columnView_data15.addAllListener(p);
		p.columnView_data15.setListListener(p);
		p.columnView_data16.addAllListener(p);
		p.columnView_data16.setListListener(p);
		p.columnView_data17.addAllListener(p);
		p.columnView_data17.setListListener(p);
		p.columnView_data18.addAllListener(p);
		p.columnView_data18.setListListener(p);
		p.columnView_data19.addAllListener(p);
		p.columnView_data19.setListListener(p);
		p.columnView_data20.addAllListener(p);
		p.columnView_data20.setListListener(p);
		p.columnView_data21.addAllListener(p);
		p.columnView_data21.setListListener(p);
		p.columnView_data22.addAllListener(p);
		p.columnView_data22.setListListener(p);
		p.columnView_data23.addAllListener(p);
		p.columnView_data23.setListListener(p);
		p.columnView_data24.addAllListener(p);
		p.columnView_data24.setListListener(p);
		p.columnView_data25.addAllListener(p);
		p.columnView_data25.setListListener(p);
		p.columnView_data26.addAllListener(p);
		p.columnView_data26.setListListener(p);
		p.columnView_data27.addAllListener(p);
		p.columnView_data27.setListListener(p);
		p.columnView_data28.addAllListener(p);
		p.columnView_data28.setListListener(p);
		p.columnView_data29.addAllListener(p);
		p.columnView_data29.setListListener(p);
		p.columnView_data30.addAllListener(p);
		p.columnView_data30.setListListener(p);
		p.columnView_data31.addAllListener(p);
		p.columnView_data31.setListListener(p);
		p.columnView_data32.addAllListener(p);
		p.columnView_data32.setListListener(p);
		p.columnView_data33.addAllListener(p);
		p.columnView_data33.setListListener(p);
		p.columnView_data34.addAllListener(p);
		p.columnView_data34.setListListener(p);
		p.columnView_data35.addAllListener(p);
		p.columnView_data35.setListListener(p);
		p.columnView_data36.addAllListener(p);
		p.columnView_data36.setListListener(p);
		p.columnView_data37.addAllListener(p);
		p.columnView_data37.setListListener(p);
		p.columnView_data38.addAllListener(p);
		p.columnView_data38.setListListener(p);
		p.columnView_data39.addAllListener(p);
		p.columnView_data39.setListListener(p);
		p.columnView_data40.addAllListener(p);
		p.columnView_data40.setListListener(p);
		p.columnView_data41.addAllListener(p);
		p.columnView_data41.setListListener(p);
		p.columnView_data42.addAllListener(p);
		p.columnView_data42.setListListener(p);
		p.columnView_data43.addAllListener(p);
		p.columnView_data43.setListListener(p);
		p.columnView_data44.addAllListener(p);
		p.columnView_data44.setListListener(p);
		p.columnView_data45.addAllListener(p);
		p.columnView_data45.setListListener(p);
		p.columnView_data46.addAllListener(p);
		p.columnView_data46.setListListener(p);
		p.columnView_data47.addAllListener(p);
		p.columnView_data47.setListListener(p);
		p.columnView_data48.addAllListener(p);
		p.columnView_data48.setListListener(p);
		p.columnView_data49.addAllListener(p);
		p.columnView_data49.setListListener(p);
		p.columnView_data50.addAllListener(p);
		p.columnView_data50.setListListener(p);
		p.columnView_data51.addAllListener(p);
		p.columnView_data51.setListListener(p);
		p.columnView_data52.addAllListener(p);
		p.columnView_data52.setListListener(p);
		p.columnView_data53.addAllListener(p);
		p.columnView_data53.setListListener(p);
		p.columnView_data54.addAllListener(p);
		p.columnView_data54.setListListener(p);
		p.columnView_data55.addAllListener(p);
		p.columnView_data55.setListListener(p);
		p.columnView_data56.addAllListener(p);
		p.columnView_data56.setListListener(p);
		p.columnView_data57.addAllListener(p);
		p.columnView_data57.setListListener(p);
		p.columnView_data58.addAllListener(p);
		p.columnView_data58.setListListener(p);
		p.columnView_data59.addAllListener(p);
		p.columnView_data59.setListListener(p);
		p.columnView_data60.addAllListener(p);
		p.columnView_data60.setListListener(p);
		p.columnView_data61.addAllListener(p);
		p.columnView_data61.setListListener(p);
		p.columnView_data62.addAllListener(p);
		p.columnView_data62.setListListener(p);
		p.columnView_data63.addAllListener(p);
		p.columnView_data63.setListListener(p);
		p.columnView_data64.addAllListener(p);
		p.columnView_data64.setListListener(p);
		p.columnView_data65.addAllListener(p);
		p.columnView_data65.setListListener(p);
		p.columnView_data66.addAllListener(p);
		p.columnView_data66.setListListener(p);
		p.columnView_data67.addAllListener(p);
		p.columnView_data67.setListListener(p);
		p.columnView_data68.addAllListener(p);
		p.columnView_data68.setListListener(p);
		p.columnView_data69.addAllListener(p);
		p.columnView_data69.setListListener(p);
		p.columnView_data70.addAllListener(p);
		p.columnView_data70.setListListener(p);
		p.columnView_data71.addAllListener(p);
		p.columnView_data71.setListListener(p);
		p.columnView_data72.addAllListener(p);
		p.columnView_data72.setListListener(p);
		p.columnView_data73.addAllListener(p);
		p.columnView_data73.setListListener(p);
		p.columnView_data74.addAllListener(p);
		p.columnView_data74.setListListener(p);
		p.columnView_data75.addAllListener(p);
		p.columnView_data75.setListListener(p);
		p.columnView_data76.addAllListener(p);
		p.columnView_data76.setListListener(p);
		p.columnView_data77.addAllListener(p);
		p.columnView_data77.setListListener(p);
		p.columnView_data78.addAllListener(p);
		p.columnView_data78.setListListener(p);
		p.columnView_data79.addAllListener(p);
		p.columnView_data79.setListListener(p);
		p.columnView_data80.addAllListener(p);
		p.columnView_data80.setListListener(p);
		p.columnView_data81.addAllListener(p);
		p.columnView_data81.setListListener(p);
		p.columnView_data82.addAllListener(p);
		p.columnView_data82.setListListener(p);
		p.columnView_data83.addAllListener(p);
		p.columnView_data83.setListListener(p);
		p.columnView_data84.addAllListener(p);
		p.columnView_data84.setListListener(p);
		p.columnView_data85.addAllListener(p);
		p.columnView_data85.setListListener(p);
		p.columnView_data86.addAllListener(p);
		p.columnView_data86.setListListener(p);
		p.columnView_data87.addAllListener(p);
		p.columnView_data87.setListListener(p);
		p.columnView_data88.addAllListener(p);
		p.columnView_data88.setListListener(p);
		p.columnView_data89.addAllListener(p);
		p.columnView_data89.setListListener(p);
		p.columnView_data90.addAllListener(p);
		p.columnView_data90.setListListener(p);
		p.columnView_data91.addAllListener(p);
		p.columnView_data91.setListListener(p);
		p.columnView_data92.addAllListener(p);
		p.columnView_data92.setListListener(p);
		p.columnView_data93.addAllListener(p);
		p.columnView_data93.setListListener(p);
		p.columnView_data94.addAllListener(p);
		p.columnView_data94.setListListener(p);
		p.columnView_data95.addAllListener(p);
		p.columnView_data95.setListListener(p);
		p.columnView_data96.addAllListener(p);
		p.columnView_data96.setListListener(p);
		p.columnView_data97.addAllListener(p);
		p.columnView_data97.setListListener(p);
		p.columnView_data98.addAllListener(p);
		p.columnView_data98.setListListener(p);
		p.columnView_data99.addAllListener(p);
		p.columnView_data99.setListListener(p);
		p.columnView_data100.addAllListener(p);
		p.columnView_data100.setListListener(p);
	}

	/**
	 *  [Btm]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitBtm(FSBAP_VerticalView_D p) {
		p.Btm_cnt.setListListener(p);
		p.Btm_cnt.addAllListener(p);
		p.Btm_fr.setListListener(p);
		p.Btm_fr.addAllListener(p);
		p.Btm_to.setListListener(p);
		p.Btm_to.addAllListener(p);
		p.Btm_prev.addAllListener(p);
		p.Btm_prev.setAPMethodName("doBtm_prev");
		p.Btm_next.addAllListener(p);
		p.Btm_next.setAPMethodName("doBtm_next");
		p.Btm_input.addAllListener(p);
		p.Btm_h_align_type.setListListener(p);
		p.Btm_h_align_type.addAllListener(p);
		p.Btm_h_align_type_nm.setListListener(p);
		p.Btm_h_align_type_nm.addAllListener(p);
	}

	/**
	 * [SRCH]ステータスの[View]ブロックのモードの設定
	 */
	protected static void statusInitSRCH_View(FSBAP_VerticalView_D p){
		p.columnView_title.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data1.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data2.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data3.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data4.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data5.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data6.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data7.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data8.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data9.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data10.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data11.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data12.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data13.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data14.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data15.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data16.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data17.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data18.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data19.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data20.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data21.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data22.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data23.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data24.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data25.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data26.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data27.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data28.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data29.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data30.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data31.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data32.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data33.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data34.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data35.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data36.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data37.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data38.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data39.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data40.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data41.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data42.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data43.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data44.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data45.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data46.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data47.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data48.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data49.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data50.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data51.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data52.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data53.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data54.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data55.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data56.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data57.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data58.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data59.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data60.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data61.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data62.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data63.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data64.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data65.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data66.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data67.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data68.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data69.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data70.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data71.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data72.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data73.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data74.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data75.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data76.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data77.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data78.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data79.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data80.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data81.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data82.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data83.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data84.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data85.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data86.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data87.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data88.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data89.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data90.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data91.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data92.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data93.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data94.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data95.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data96.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data97.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data98.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data99.putMode(p, SRCH, MCMode.READ_ONLY);
		p.columnView_data100.putMode(p, SRCH, MCMode.READ_ONLY);

	}

	/**
	 * [SRCH]ステータスの[Btm]ブロックのモードの設定
	 */
	protected static void statusInitSRCH_Btm(FSBAP_VerticalView_D p){
		p.Btm_cnt.putMode(p, SRCH, MCMode.READ_ONLY);
		p.Btm_fr.putMode(p, SRCH, MCMode.READ_ONLY);
		p.Btm_to.putMode(p, SRCH, MCMode.READ_ONLY);
		p.Btm_prev.putMode(p, SRCH, MCMode.ENABLE);
		p.Btm_next.putMode(p, SRCH, MCMode.ENABLE);
		p.Btm_input.putMode(p, SRCH, MCMode.REQUIRED);
		p.Btm_h_align_type.putMode(p, SRCH, MCMode.INVISIBLE);
		p.Btm_h_align_type_nm.putMode(p, SRCH, MCMode.ENABLE);
		p.Btm_par_screen_nm_p_PPanel.putStatus(SRCH, mcframe.clientFSUB.FSUBP0080.FSUBP_ParScreenNm_H.READ_ONLY);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return SRCH;
	}

	/**
	 * Table/Tree/GanttChartの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
		FSBAP_VerticalView_D_FW.setTableConfigView((FSBAP_VerticalView_D)this);
	}

	/**
	 * [View]ブロックのTableの設定
	 */
	protected static void setTableConfigView(FSBAP_VerticalView_D p) {
		p.columnView_title.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.title_META);
		p.ViewTable.addColumnConfig(p.columnView_title);
		p.columnView_data1.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data1_META);
		p.ViewTable.addColumnConfig(p.columnView_data1);
		p.columnView_data2.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data2_META);
		p.ViewTable.addColumnConfig(p.columnView_data2);
		p.columnView_data3.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data3_META);
		p.ViewTable.addColumnConfig(p.columnView_data3);
		p.columnView_data4.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data4_META);
		p.ViewTable.addColumnConfig(p.columnView_data4);
		p.columnView_data5.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data5_META);
		p.ViewTable.addColumnConfig(p.columnView_data5);
		p.columnView_data6.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data6_META);
		p.ViewTable.addColumnConfig(p.columnView_data6);
		p.columnView_data7.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data7_META);
		p.ViewTable.addColumnConfig(p.columnView_data7);
		p.columnView_data8.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data8_META);
		p.ViewTable.addColumnConfig(p.columnView_data8);
		p.columnView_data9.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data9_META);
		p.ViewTable.addColumnConfig(p.columnView_data9);
		p.columnView_data10.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data10_META);
		p.ViewTable.addColumnConfig(p.columnView_data10);
		p.columnView_data11.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data11_META);
		p.ViewTable.addColumnConfig(p.columnView_data11);
		p.columnView_data12.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data12_META);
		p.ViewTable.addColumnConfig(p.columnView_data12);
		p.columnView_data13.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data13_META);
		p.ViewTable.addColumnConfig(p.columnView_data13);
		p.columnView_data14.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data14_META);
		p.ViewTable.addColumnConfig(p.columnView_data14);
		p.columnView_data15.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data15_META);
		p.ViewTable.addColumnConfig(p.columnView_data15);
		p.columnView_data16.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data16_META);
		p.ViewTable.addColumnConfig(p.columnView_data16);
		p.columnView_data17.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data17_META);
		p.ViewTable.addColumnConfig(p.columnView_data17);
		p.columnView_data18.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data18_META);
		p.ViewTable.addColumnConfig(p.columnView_data18);
		p.columnView_data19.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data19_META);
		p.ViewTable.addColumnConfig(p.columnView_data19);
		p.columnView_data20.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data20_META);
		p.ViewTable.addColumnConfig(p.columnView_data20);
		p.columnView_data21.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data21_META);
		p.ViewTable.addColumnConfig(p.columnView_data21);
		p.columnView_data22.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data22_META);
		p.ViewTable.addColumnConfig(p.columnView_data22);
		p.columnView_data23.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data23_META);
		p.ViewTable.addColumnConfig(p.columnView_data23);
		p.columnView_data24.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data24_META);
		p.ViewTable.addColumnConfig(p.columnView_data24);
		p.columnView_data25.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data25_META);
		p.ViewTable.addColumnConfig(p.columnView_data25);
		p.columnView_data26.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data26_META);
		p.ViewTable.addColumnConfig(p.columnView_data26);
		p.columnView_data27.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data27_META);
		p.ViewTable.addColumnConfig(p.columnView_data27);
		p.columnView_data28.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data28_META);
		p.ViewTable.addColumnConfig(p.columnView_data28);
		p.columnView_data29.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data29_META);
		p.ViewTable.addColumnConfig(p.columnView_data29);
		p.columnView_data30.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data30_META);
		p.ViewTable.addColumnConfig(p.columnView_data30);
		p.columnView_data31.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data31_META);
		p.ViewTable.addColumnConfig(p.columnView_data31);
		p.columnView_data32.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data32_META);
		p.ViewTable.addColumnConfig(p.columnView_data32);
		p.columnView_data33.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data33_META);
		p.ViewTable.addColumnConfig(p.columnView_data33);
		p.columnView_data34.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data34_META);
		p.ViewTable.addColumnConfig(p.columnView_data34);
		p.columnView_data35.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data35_META);
		p.ViewTable.addColumnConfig(p.columnView_data35);
		p.columnView_data36.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data36_META);
		p.ViewTable.addColumnConfig(p.columnView_data36);
		p.columnView_data37.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data37_META);
		p.ViewTable.addColumnConfig(p.columnView_data37);
		p.columnView_data38.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data38_META);
		p.ViewTable.addColumnConfig(p.columnView_data38);
		p.columnView_data39.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data39_META);
		p.ViewTable.addColumnConfig(p.columnView_data39);
		p.columnView_data40.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data40_META);
		p.ViewTable.addColumnConfig(p.columnView_data40);
		p.columnView_data41.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data41_META);
		p.ViewTable.addColumnConfig(p.columnView_data41);
		p.columnView_data42.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data42_META);
		p.ViewTable.addColumnConfig(p.columnView_data42);
		p.columnView_data43.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data43_META);
		p.ViewTable.addColumnConfig(p.columnView_data43);
		p.columnView_data44.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data44_META);
		p.ViewTable.addColumnConfig(p.columnView_data44);
		p.columnView_data45.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data45_META);
		p.ViewTable.addColumnConfig(p.columnView_data45);
		p.columnView_data46.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data46_META);
		p.ViewTable.addColumnConfig(p.columnView_data46);
		p.columnView_data47.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data47_META);
		p.ViewTable.addColumnConfig(p.columnView_data47);
		p.columnView_data48.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data48_META);
		p.ViewTable.addColumnConfig(p.columnView_data48);
		p.columnView_data49.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data49_META);
		p.ViewTable.addColumnConfig(p.columnView_data49);
		p.columnView_data50.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data50_META);
		p.ViewTable.addColumnConfig(p.columnView_data50);
		p.columnView_data51.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data51_META);
		p.ViewTable.addColumnConfig(p.columnView_data51);
		p.columnView_data52.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data52_META);
		p.ViewTable.addColumnConfig(p.columnView_data52);
		p.columnView_data53.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data53_META);
		p.ViewTable.addColumnConfig(p.columnView_data53);
		p.columnView_data54.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data54_META);
		p.ViewTable.addColumnConfig(p.columnView_data54);
		p.columnView_data55.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data55_META);
		p.ViewTable.addColumnConfig(p.columnView_data55);
		p.columnView_data56.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data56_META);
		p.ViewTable.addColumnConfig(p.columnView_data56);
		p.columnView_data57.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data57_META);
		p.ViewTable.addColumnConfig(p.columnView_data57);
		p.columnView_data58.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data58_META);
		p.ViewTable.addColumnConfig(p.columnView_data58);
		p.columnView_data59.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data59_META);
		p.ViewTable.addColumnConfig(p.columnView_data59);
		p.columnView_data60.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data60_META);
		p.ViewTable.addColumnConfig(p.columnView_data60);
		p.columnView_data61.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data61_META);
		p.ViewTable.addColumnConfig(p.columnView_data61);
		p.columnView_data62.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data62_META);
		p.ViewTable.addColumnConfig(p.columnView_data62);
		p.columnView_data63.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data63_META);
		p.ViewTable.addColumnConfig(p.columnView_data63);
		p.columnView_data64.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data64_META);
		p.ViewTable.addColumnConfig(p.columnView_data64);
		p.columnView_data65.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data65_META);
		p.ViewTable.addColumnConfig(p.columnView_data65);
		p.columnView_data66.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data66_META);
		p.ViewTable.addColumnConfig(p.columnView_data66);
		p.columnView_data67.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data67_META);
		p.ViewTable.addColumnConfig(p.columnView_data67);
		p.columnView_data68.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data68_META);
		p.ViewTable.addColumnConfig(p.columnView_data68);
		p.columnView_data69.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data69_META);
		p.ViewTable.addColumnConfig(p.columnView_data69);
		p.columnView_data70.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data70_META);
		p.ViewTable.addColumnConfig(p.columnView_data70);
		p.columnView_data71.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data71_META);
		p.ViewTable.addColumnConfig(p.columnView_data71);
		p.columnView_data72.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data72_META);
		p.ViewTable.addColumnConfig(p.columnView_data72);
		p.columnView_data73.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data73_META);
		p.ViewTable.addColumnConfig(p.columnView_data73);
		p.columnView_data74.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data74_META);
		p.ViewTable.addColumnConfig(p.columnView_data74);
		p.columnView_data75.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data75_META);
		p.ViewTable.addColumnConfig(p.columnView_data75);
		p.columnView_data76.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data76_META);
		p.ViewTable.addColumnConfig(p.columnView_data76);
		p.columnView_data77.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data77_META);
		p.ViewTable.addColumnConfig(p.columnView_data77);
		p.columnView_data78.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data78_META);
		p.ViewTable.addColumnConfig(p.columnView_data78);
		p.columnView_data79.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data79_META);
		p.ViewTable.addColumnConfig(p.columnView_data79);
		p.columnView_data80.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data80_META);
		p.ViewTable.addColumnConfig(p.columnView_data80);
		p.columnView_data81.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data81_META);
		p.ViewTable.addColumnConfig(p.columnView_data81);
		p.columnView_data82.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data82_META);
		p.ViewTable.addColumnConfig(p.columnView_data82);
		p.columnView_data83.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data83_META);
		p.ViewTable.addColumnConfig(p.columnView_data83);
		p.columnView_data84.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data84_META);
		p.ViewTable.addColumnConfig(p.columnView_data84);
		p.columnView_data85.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data85_META);
		p.ViewTable.addColumnConfig(p.columnView_data85);
		p.columnView_data86.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data86_META);
		p.ViewTable.addColumnConfig(p.columnView_data86);
		p.columnView_data87.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data87_META);
		p.ViewTable.addColumnConfig(p.columnView_data87);
		p.columnView_data88.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data88_META);
		p.ViewTable.addColumnConfig(p.columnView_data88);
		p.columnView_data89.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data89_META);
		p.ViewTable.addColumnConfig(p.columnView_data89);
		p.columnView_data90.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data90_META);
		p.ViewTable.addColumnConfig(p.columnView_data90);
		p.columnView_data91.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data91_META);
		p.ViewTable.addColumnConfig(p.columnView_data91);
		p.columnView_data92.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data92_META);
		p.ViewTable.addColumnConfig(p.columnView_data92);
		p.columnView_data93.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data93_META);
		p.ViewTable.addColumnConfig(p.columnView_data93);
		p.columnView_data94.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data94_META);
		p.ViewTable.addColumnConfig(p.columnView_data94);
		p.columnView_data95.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data95_META);
		p.ViewTable.addColumnConfig(p.columnView_data95);
		p.columnView_data96.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data96_META);
		p.ViewTable.addColumnConfig(p.columnView_data96);
		p.columnView_data97.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data97_META);
		p.ViewTable.addColumnConfig(p.columnView_data97);
		p.columnView_data98.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data98_META);
		p.ViewTable.addColumnConfig(p.columnView_data98);
		p.columnView_data99.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data99_META);
		p.ViewTable.addColumnConfig(p.columnView_data99);
		p.columnView_data100.setMeta(mcframe.clientFSBA.FSBAP0370.ViewR.data100_META);
		p.ViewTable.addColumnConfig(p.columnView_data100);
		// スクロール固定カラムの指定
		p.ViewTable.setUnscrollColumn(p.columnView_title);
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
		Btm_h_align_type_nm.setListVisibleColumn(MCListLogic.getViewColumnName());
		Btm_h_align_type_nm.getListConfig().setPutter(getBtm_h_align_type_nm_ListPutter());
	}

	/**
	 * この画面を[SRCH]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setSRCHStatus() {
		status = SRCH;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (SRCH.equals(status)) {
			setSRCHStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * [Btm_h_align_type_nm_ListPutter]の作成
	 */
	protected MCListPutter createBtm_h_align_type_nm_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("FS.FSUAP0010.HAlignType");
		return lp;
	}
	 

	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		if(combo == Btm_h_align_type_nm) return getBtm_h_align_type_nm(row, info);
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == Btm_prev) doBtm_prev(info);
		else if (ap == Btm_next) doBtm_next(info);
	}

	/**
	 * [Btm]パネルの[prev]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtm_prev(MCEventInfo info);

	/**
	 * [Btm]パネルの[next]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtm_next(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == ViewTable) return doView_VC(info);
		if (vc == columnView_title) return doView_title_VC(info);
		if (vc == columnView_data1) return doView_data1_VC(info);
		if (vc == columnView_data2) return doView_data2_VC(info);
		if (vc == columnView_data3) return doView_data3_VC(info);
		if (vc == columnView_data4) return doView_data4_VC(info);
		if (vc == columnView_data5) return doView_data5_VC(info);
		if (vc == columnView_data6) return doView_data6_VC(info);
		if (vc == columnView_data7) return doView_data7_VC(info);
		if (vc == columnView_data8) return doView_data8_VC(info);
		if (vc == columnView_data9) return doView_data9_VC(info);
		if (vc == columnView_data10) return doView_data10_VC(info);
		if (vc == columnView_data11) return doView_data11_VC(info);
		if (vc == columnView_data12) return doView_data12_VC(info);
		if (vc == columnView_data13) return doView_data13_VC(info);
		if (vc == columnView_data14) return doView_data14_VC(info);
		if (vc == columnView_data15) return doView_data15_VC(info);
		if (vc == columnView_data16) return doView_data16_VC(info);
		if (vc == columnView_data17) return doView_data17_VC(info);
		if (vc == columnView_data18) return doView_data18_VC(info);
		if (vc == columnView_data19) return doView_data19_VC(info);
		if (vc == columnView_data20) return doView_data20_VC(info);
		if (vc == columnView_data21) return doView_data21_VC(info);
		if (vc == columnView_data22) return doView_data22_VC(info);
		if (vc == columnView_data23) return doView_data23_VC(info);
		if (vc == columnView_data24) return doView_data24_VC(info);
		if (vc == columnView_data25) return doView_data25_VC(info);
		if (vc == columnView_data26) return doView_data26_VC(info);
		if (vc == columnView_data27) return doView_data27_VC(info);
		if (vc == columnView_data28) return doView_data28_VC(info);
		if (vc == columnView_data29) return doView_data29_VC(info);
		if (vc == columnView_data30) return doView_data30_VC(info);
		if (vc == columnView_data31) return doView_data31_VC(info);
		if (vc == columnView_data32) return doView_data32_VC(info);
		if (vc == columnView_data33) return doView_data33_VC(info);
		if (vc == columnView_data34) return doView_data34_VC(info);
		if (vc == columnView_data35) return doView_data35_VC(info);
		if (vc == columnView_data36) return doView_data36_VC(info);
		if (vc == columnView_data37) return doView_data37_VC(info);
		if (vc == columnView_data38) return doView_data38_VC(info);
		if (vc == columnView_data39) return doView_data39_VC(info);
		if (vc == columnView_data40) return doView_data40_VC(info);
		if (vc == columnView_data41) return doView_data41_VC(info);
		if (vc == columnView_data42) return doView_data42_VC(info);
		if (vc == columnView_data43) return doView_data43_VC(info);
		if (vc == columnView_data44) return doView_data44_VC(info);
		if (vc == columnView_data45) return doView_data45_VC(info);
		if (vc == columnView_data46) return doView_data46_VC(info);
		if (vc == columnView_data47) return doView_data47_VC(info);
		if (vc == columnView_data48) return doView_data48_VC(info);
		if (vc == columnView_data49) return doView_data49_VC(info);
		if (vc == columnView_data50) return doView_data50_VC(info);
		if (vc == columnView_data51) return doView_data51_VC(info);
		if (vc == columnView_data52) return doView_data52_VC(info);
		if (vc == columnView_data53) return doView_data53_VC(info);
		if (vc == columnView_data54) return doView_data54_VC(info);
		if (vc == columnView_data55) return doView_data55_VC(info);
		if (vc == columnView_data56) return doView_data56_VC(info);
		if (vc == columnView_data57) return doView_data57_VC(info);
		if (vc == columnView_data58) return doView_data58_VC(info);
		if (vc == columnView_data59) return doView_data59_VC(info);
		if (vc == columnView_data60) return doView_data60_VC(info);
		if (vc == columnView_data61) return doView_data61_VC(info);
		if (vc == columnView_data62) return doView_data62_VC(info);
		if (vc == columnView_data63) return doView_data63_VC(info);
		if (vc == columnView_data64) return doView_data64_VC(info);
		if (vc == columnView_data65) return doView_data65_VC(info);
		if (vc == columnView_data66) return doView_data66_VC(info);
		if (vc == columnView_data67) return doView_data67_VC(info);
		if (vc == columnView_data68) return doView_data68_VC(info);
		if (vc == columnView_data69) return doView_data69_VC(info);
		if (vc == columnView_data70) return doView_data70_VC(info);
		if (vc == columnView_data71) return doView_data71_VC(info);
		if (vc == columnView_data72) return doView_data72_VC(info);
		if (vc == columnView_data73) return doView_data73_VC(info);
		if (vc == columnView_data74) return doView_data74_VC(info);
		if (vc == columnView_data75) return doView_data75_VC(info);
		if (vc == columnView_data76) return doView_data76_VC(info);
		if (vc == columnView_data77) return doView_data77_VC(info);
		if (vc == columnView_data78) return doView_data78_VC(info);
		if (vc == columnView_data79) return doView_data79_VC(info);
		if (vc == columnView_data80) return doView_data80_VC(info);
		if (vc == columnView_data81) return doView_data81_VC(info);
		if (vc == columnView_data82) return doView_data82_VC(info);
		if (vc == columnView_data83) return doView_data83_VC(info);
		if (vc == columnView_data84) return doView_data84_VC(info);
		if (vc == columnView_data85) return doView_data85_VC(info);
		if (vc == columnView_data86) return doView_data86_VC(info);
		if (vc == columnView_data87) return doView_data87_VC(info);
		if (vc == columnView_data88) return doView_data88_VC(info);
		if (vc == columnView_data89) return doView_data89_VC(info);
		if (vc == columnView_data90) return doView_data90_VC(info);
		if (vc == columnView_data91) return doView_data91_VC(info);
		if (vc == columnView_data92) return doView_data92_VC(info);
		if (vc == columnView_data93) return doView_data93_VC(info);
		if (vc == columnView_data94) return doView_data94_VC(info);
		if (vc == columnView_data95) return doView_data95_VC(info);
		if (vc == columnView_data96) return doView_data96_VC(info);
		if (vc == columnView_data97) return doView_data97_VC(info);
		if (vc == columnView_data98) return doView_data98_VC(info);
		if (vc == columnView_data99) return doView_data99_VC(info);
		if (vc == columnView_data100) return doView_data100_VC(info);
		if (vc == Btm_cnt) return doBtm_cnt_VC(info);
		if (vc == Btm_fr) return doBtm_fr_VC(info);
		if (vc == Btm_to) return doBtm_to_VC(info);
		if (vc == Btm_input) return doBtm_input_VC(info);
		if (vc == Btm_h_align_type) return doBtm_h_align_type_VC(info);
		if (vc == Btm_h_align_type_nm) return doBtm_h_align_type_nm_VC(info);
		return true;
	}

	/**
	 * [View]Tableの選択行が変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[title]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_title_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data1]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data1_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data2]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data2_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data3]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data3_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data4]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data4_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data5]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data5_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data6]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data6_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data7]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data7_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data8]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data8_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data9]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data9_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data10]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data10_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data11]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data11_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data12]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data12_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data13]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data13_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data14]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data14_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data15]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data15_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data16]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data16_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data17]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data17_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data18]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data18_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data19]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data19_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data20]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data20_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data21]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data21_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data22]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data22_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data23]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data23_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data24]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data24_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data25]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data25_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data26]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data26_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data27]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data27_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data28]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data28_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data29]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data29_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data30]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data30_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data31]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data31_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data32]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data32_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data33]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data33_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data34]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data34_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data35]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data35_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data36]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data36_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data37]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data37_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data38]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data38_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data39]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data39_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data40]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data40_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data41]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data41_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data42]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data42_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data43]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data43_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data44]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data44_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data45]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data45_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data46]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data46_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data47]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data47_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data48]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data48_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data49]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data49_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data50]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data50_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data51]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data51_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data52]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data52_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data53]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data53_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data54]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data54_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data55]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data55_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data56]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data56_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data57]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data57_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data58]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data58_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data59]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data59_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data60]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data60_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data61]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data61_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data62]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data62_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data63]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data63_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data64]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data64_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data65]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data65_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data66]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data66_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data67]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data67_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data68]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data68_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data69]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data69_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data70]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data70_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data71]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data71_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data72]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data72_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data73]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data73_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data74]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data74_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data75]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data75_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data76]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data76_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data77]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data77_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data78]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data78_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data79]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data79_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data80]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data80_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data81]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data81_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data82]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data82_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data83]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data83_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data84]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data84_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data85]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data85_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data86]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data86_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data87]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data87_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data88]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data88_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data89]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data89_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data90]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data90_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data91]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data91_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data92]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data92_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data93]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data93_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data94]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data94_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data95]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data95_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data96]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data96_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data97]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data97_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data98]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data98_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data99]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data99_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [View]パネルの[data100]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doView_data100_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Btm]パネルの[cnt]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doBtm_cnt_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Btm]パネルの[fr]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doBtm_fr_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Btm]パネルの[to]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doBtm_to_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Btm]パネルの[input]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doBtm_input_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Btm]パネルの[h_align_type]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doBtm_h_align_type_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Btm]パネルの[h_align_type_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doBtm_h_align_type_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == ViewTable) doView_NC(info);
		else if (nc == columnView_title) doView_title_NC(info);
		else if (nc == columnView_data1) doView_data1_NC(info);
		else if (nc == columnView_data2) doView_data2_NC(info);
		else if (nc == columnView_data3) doView_data3_NC(info);
		else if (nc == columnView_data4) doView_data4_NC(info);
		else if (nc == columnView_data5) doView_data5_NC(info);
		else if (nc == columnView_data6) doView_data6_NC(info);
		else if (nc == columnView_data7) doView_data7_NC(info);
		else if (nc == columnView_data8) doView_data8_NC(info);
		else if (nc == columnView_data9) doView_data9_NC(info);
		else if (nc == columnView_data10) doView_data10_NC(info);
		else if (nc == columnView_data11) doView_data11_NC(info);
		else if (nc == columnView_data12) doView_data12_NC(info);
		else if (nc == columnView_data13) doView_data13_NC(info);
		else if (nc == columnView_data14) doView_data14_NC(info);
		else if (nc == columnView_data15) doView_data15_NC(info);
		else if (nc == columnView_data16) doView_data16_NC(info);
		else if (nc == columnView_data17) doView_data17_NC(info);
		else if (nc == columnView_data18) doView_data18_NC(info);
		else if (nc == columnView_data19) doView_data19_NC(info);
		else if (nc == columnView_data20) doView_data20_NC(info);
		else if (nc == columnView_data21) doView_data21_NC(info);
		else if (nc == columnView_data22) doView_data22_NC(info);
		else if (nc == columnView_data23) doView_data23_NC(info);
		else if (nc == columnView_data24) doView_data24_NC(info);
		else if (nc == columnView_data25) doView_data25_NC(info);
		else if (nc == columnView_data26) doView_data26_NC(info);
		else if (nc == columnView_data27) doView_data27_NC(info);
		else if (nc == columnView_data28) doView_data28_NC(info);
		else if (nc == columnView_data29) doView_data29_NC(info);
		else if (nc == columnView_data30) doView_data30_NC(info);
		else if (nc == columnView_data31) doView_data31_NC(info);
		else if (nc == columnView_data32) doView_data32_NC(info);
		else if (nc == columnView_data33) doView_data33_NC(info);
		else if (nc == columnView_data34) doView_data34_NC(info);
		else if (nc == columnView_data35) doView_data35_NC(info);
		else if (nc == columnView_data36) doView_data36_NC(info);
		else if (nc == columnView_data37) doView_data37_NC(info);
		else if (nc == columnView_data38) doView_data38_NC(info);
		else if (nc == columnView_data39) doView_data39_NC(info);
		else if (nc == columnView_data40) doView_data40_NC(info);
		else if (nc == columnView_data41) doView_data41_NC(info);
		else if (nc == columnView_data42) doView_data42_NC(info);
		else if (nc == columnView_data43) doView_data43_NC(info);
		else if (nc == columnView_data44) doView_data44_NC(info);
		else if (nc == columnView_data45) doView_data45_NC(info);
		else if (nc == columnView_data46) doView_data46_NC(info);
		else if (nc == columnView_data47) doView_data47_NC(info);
		else if (nc == columnView_data48) doView_data48_NC(info);
		else if (nc == columnView_data49) doView_data49_NC(info);
		else if (nc == columnView_data50) doView_data50_NC(info);
		else if (nc == columnView_data51) doView_data51_NC(info);
		else if (nc == columnView_data52) doView_data52_NC(info);
		else if (nc == columnView_data53) doView_data53_NC(info);
		else if (nc == columnView_data54) doView_data54_NC(info);
		else if (nc == columnView_data55) doView_data55_NC(info);
		else if (nc == columnView_data56) doView_data56_NC(info);
		else if (nc == columnView_data57) doView_data57_NC(info);
		else if (nc == columnView_data58) doView_data58_NC(info);
		else if (nc == columnView_data59) doView_data59_NC(info);
		else if (nc == columnView_data60) doView_data60_NC(info);
		else if (nc == columnView_data61) doView_data61_NC(info);
		else if (nc == columnView_data62) doView_data62_NC(info);
		else if (nc == columnView_data63) doView_data63_NC(info);
		else if (nc == columnView_data64) doView_data64_NC(info);
		else if (nc == columnView_data65) doView_data65_NC(info);
		else if (nc == columnView_data66) doView_data66_NC(info);
		else if (nc == columnView_data67) doView_data67_NC(info);
		else if (nc == columnView_data68) doView_data68_NC(info);
		else if (nc == columnView_data69) doView_data69_NC(info);
		else if (nc == columnView_data70) doView_data70_NC(info);
		else if (nc == columnView_data71) doView_data71_NC(info);
		else if (nc == columnView_data72) doView_data72_NC(info);
		else if (nc == columnView_data73) doView_data73_NC(info);
		else if (nc == columnView_data74) doView_data74_NC(info);
		else if (nc == columnView_data75) doView_data75_NC(info);
		else if (nc == columnView_data76) doView_data76_NC(info);
		else if (nc == columnView_data77) doView_data77_NC(info);
		else if (nc == columnView_data78) doView_data78_NC(info);
		else if (nc == columnView_data79) doView_data79_NC(info);
		else if (nc == columnView_data80) doView_data80_NC(info);
		else if (nc == columnView_data81) doView_data81_NC(info);
		else if (nc == columnView_data82) doView_data82_NC(info);
		else if (nc == columnView_data83) doView_data83_NC(info);
		else if (nc == columnView_data84) doView_data84_NC(info);
		else if (nc == columnView_data85) doView_data85_NC(info);
		else if (nc == columnView_data86) doView_data86_NC(info);
		else if (nc == columnView_data87) doView_data87_NC(info);
		else if (nc == columnView_data88) doView_data88_NC(info);
		else if (nc == columnView_data89) doView_data89_NC(info);
		else if (nc == columnView_data90) doView_data90_NC(info);
		else if (nc == columnView_data91) doView_data91_NC(info);
		else if (nc == columnView_data92) doView_data92_NC(info);
		else if (nc == columnView_data93) doView_data93_NC(info);
		else if (nc == columnView_data94) doView_data94_NC(info);
		else if (nc == columnView_data95) doView_data95_NC(info);
		else if (nc == columnView_data96) doView_data96_NC(info);
		else if (nc == columnView_data97) doView_data97_NC(info);
		else if (nc == columnView_data98) doView_data98_NC(info);
		else if (nc == columnView_data99) doView_data99_NC(info);
		else if (nc == columnView_data100) doView_data100_NC(info);
		else if (nc == Btm_cnt) doBtm_cnt_NC(info);
		else if (nc == Btm_fr) doBtm_fr_NC(info);
		else if (nc == Btm_to) doBtm_to_NC(info);
		else if (nc == Btm_input) doBtm_input_NC(info);
		else if (nc == Btm_h_align_type) doBtm_h_align_type_NC(info);
		else if (nc == Btm_h_align_type_nm) doBtm_h_align_type_nm_NC(info);
	}

	/**
	 * [View]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[title]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_title_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data1]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data1_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data2]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data2_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data3]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data3_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data4]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data4_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data5]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data5_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data6]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data6_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data7]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data7_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data8]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data8_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data9]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data9_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data10]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data10_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data11]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data11_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data12]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data12_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data13]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data13_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data14]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data14_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data15]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data15_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data16]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data16_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data17]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data17_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data18]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data18_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data19]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data19_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data20]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data20_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data21]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data21_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data22]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data22_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data23]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data23_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data24]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data24_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data25]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data25_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data26]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data26_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data27]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data27_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data28]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data28_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data29]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data29_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data30]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data30_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data31]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data31_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data32]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data32_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data33]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data33_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data34]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data34_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data35]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data35_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data36]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data36_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data37]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data37_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data38]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data38_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data39]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data39_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data40]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data40_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data41]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data41_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data42]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data42_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data43]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data43_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data44]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data44_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data45]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data45_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data46]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data46_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data47]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data47_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data48]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data48_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data49]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data49_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data50]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data50_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data51]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data51_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data52]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data52_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data53]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data53_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data54]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data54_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data55]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data55_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data56]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data56_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data57]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data57_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data58]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data58_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data59]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data59_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data60]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data60_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data61]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data61_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data62]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data62_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data63]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data63_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data64]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data64_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data65]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data65_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data66]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data66_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data67]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data67_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data68]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data68_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data69]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data69_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data70]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data70_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data71]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data71_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data72]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data72_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data73]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data73_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data74]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data74_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data75]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data75_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data76]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data76_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data77]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data77_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data78]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data78_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data79]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data79_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data80]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data80_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data81]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data81_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data82]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data82_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data83]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data83_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data84]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data84_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data85]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data85_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data86]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data86_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data87]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data87_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data88]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data88_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data89]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data89_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data90]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data90_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data91]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data91_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data92]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data92_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data93]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data93_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data94]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data94_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data95]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data95_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data96]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data96_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data97]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data97_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data98]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data98_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data99]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data99_NC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data100]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data100_NC(MCEventInfo info){
	}

	/**
	 * [Btm]パネルの[cnt]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtm_cnt_NC(MCEventInfo info){
	}

	/**
	 * [Btm]パネルの[fr]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtm_fr_NC(MCEventInfo info){
	}

	/**
	 * [Btm]パネルの[to]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtm_to_NC(MCEventInfo info){
	}

	/**
	 * [Btm]パネルの[input]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtm_input_NC(MCEventInfo info){
	}

	/**
	 * [Btm]パネルの[h_align_type]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtm_h_align_type_NC(MCEventInfo info){
	}

	/**
	 * [Btm]パネルの[h_align_type_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtm_h_align_type_nm_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == ViewTable) doView_NE(info);
		else if (ne == columnView_title) doView_title_NE(info);
		else if (ne == columnView_data1) doView_data1_NE(info);
		else if (ne == columnView_data2) doView_data2_NE(info);
		else if (ne == columnView_data3) doView_data3_NE(info);
		else if (ne == columnView_data4) doView_data4_NE(info);
		else if (ne == columnView_data5) doView_data5_NE(info);
		else if (ne == columnView_data6) doView_data6_NE(info);
		else if (ne == columnView_data7) doView_data7_NE(info);
		else if (ne == columnView_data8) doView_data8_NE(info);
		else if (ne == columnView_data9) doView_data9_NE(info);
		else if (ne == columnView_data10) doView_data10_NE(info);
		else if (ne == columnView_data11) doView_data11_NE(info);
		else if (ne == columnView_data12) doView_data12_NE(info);
		else if (ne == columnView_data13) doView_data13_NE(info);
		else if (ne == columnView_data14) doView_data14_NE(info);
		else if (ne == columnView_data15) doView_data15_NE(info);
		else if (ne == columnView_data16) doView_data16_NE(info);
		else if (ne == columnView_data17) doView_data17_NE(info);
		else if (ne == columnView_data18) doView_data18_NE(info);
		else if (ne == columnView_data19) doView_data19_NE(info);
		else if (ne == columnView_data20) doView_data20_NE(info);
		else if (ne == columnView_data21) doView_data21_NE(info);
		else if (ne == columnView_data22) doView_data22_NE(info);
		else if (ne == columnView_data23) doView_data23_NE(info);
		else if (ne == columnView_data24) doView_data24_NE(info);
		else if (ne == columnView_data25) doView_data25_NE(info);
		else if (ne == columnView_data26) doView_data26_NE(info);
		else if (ne == columnView_data27) doView_data27_NE(info);
		else if (ne == columnView_data28) doView_data28_NE(info);
		else if (ne == columnView_data29) doView_data29_NE(info);
		else if (ne == columnView_data30) doView_data30_NE(info);
		else if (ne == columnView_data31) doView_data31_NE(info);
		else if (ne == columnView_data32) doView_data32_NE(info);
		else if (ne == columnView_data33) doView_data33_NE(info);
		else if (ne == columnView_data34) doView_data34_NE(info);
		else if (ne == columnView_data35) doView_data35_NE(info);
		else if (ne == columnView_data36) doView_data36_NE(info);
		else if (ne == columnView_data37) doView_data37_NE(info);
		else if (ne == columnView_data38) doView_data38_NE(info);
		else if (ne == columnView_data39) doView_data39_NE(info);
		else if (ne == columnView_data40) doView_data40_NE(info);
		else if (ne == columnView_data41) doView_data41_NE(info);
		else if (ne == columnView_data42) doView_data42_NE(info);
		else if (ne == columnView_data43) doView_data43_NE(info);
		else if (ne == columnView_data44) doView_data44_NE(info);
		else if (ne == columnView_data45) doView_data45_NE(info);
		else if (ne == columnView_data46) doView_data46_NE(info);
		else if (ne == columnView_data47) doView_data47_NE(info);
		else if (ne == columnView_data48) doView_data48_NE(info);
		else if (ne == columnView_data49) doView_data49_NE(info);
		else if (ne == columnView_data50) doView_data50_NE(info);
		else if (ne == columnView_data51) doView_data51_NE(info);
		else if (ne == columnView_data52) doView_data52_NE(info);
		else if (ne == columnView_data53) doView_data53_NE(info);
		else if (ne == columnView_data54) doView_data54_NE(info);
		else if (ne == columnView_data55) doView_data55_NE(info);
		else if (ne == columnView_data56) doView_data56_NE(info);
		else if (ne == columnView_data57) doView_data57_NE(info);
		else if (ne == columnView_data58) doView_data58_NE(info);
		else if (ne == columnView_data59) doView_data59_NE(info);
		else if (ne == columnView_data60) doView_data60_NE(info);
		else if (ne == columnView_data61) doView_data61_NE(info);
		else if (ne == columnView_data62) doView_data62_NE(info);
		else if (ne == columnView_data63) doView_data63_NE(info);
		else if (ne == columnView_data64) doView_data64_NE(info);
		else if (ne == columnView_data65) doView_data65_NE(info);
		else if (ne == columnView_data66) doView_data66_NE(info);
		else if (ne == columnView_data67) doView_data67_NE(info);
		else if (ne == columnView_data68) doView_data68_NE(info);
		else if (ne == columnView_data69) doView_data69_NE(info);
		else if (ne == columnView_data70) doView_data70_NE(info);
		else if (ne == columnView_data71) doView_data71_NE(info);
		else if (ne == columnView_data72) doView_data72_NE(info);
		else if (ne == columnView_data73) doView_data73_NE(info);
		else if (ne == columnView_data74) doView_data74_NE(info);
		else if (ne == columnView_data75) doView_data75_NE(info);
		else if (ne == columnView_data76) doView_data76_NE(info);
		else if (ne == columnView_data77) doView_data77_NE(info);
		else if (ne == columnView_data78) doView_data78_NE(info);
		else if (ne == columnView_data79) doView_data79_NE(info);
		else if (ne == columnView_data80) doView_data80_NE(info);
		else if (ne == columnView_data81) doView_data81_NE(info);
		else if (ne == columnView_data82) doView_data82_NE(info);
		else if (ne == columnView_data83) doView_data83_NE(info);
		else if (ne == columnView_data84) doView_data84_NE(info);
		else if (ne == columnView_data85) doView_data85_NE(info);
		else if (ne == columnView_data86) doView_data86_NE(info);
		else if (ne == columnView_data87) doView_data87_NE(info);
		else if (ne == columnView_data88) doView_data88_NE(info);
		else if (ne == columnView_data89) doView_data89_NE(info);
		else if (ne == columnView_data90) doView_data90_NE(info);
		else if (ne == columnView_data91) doView_data91_NE(info);
		else if (ne == columnView_data92) doView_data92_NE(info);
		else if (ne == columnView_data93) doView_data93_NE(info);
		else if (ne == columnView_data94) doView_data94_NE(info);
		else if (ne == columnView_data95) doView_data95_NE(info);
		else if (ne == columnView_data96) doView_data96_NE(info);
		else if (ne == columnView_data97) doView_data97_NE(info);
		else if (ne == columnView_data98) doView_data98_NE(info);
		else if (ne == columnView_data99) doView_data99_NE(info);
		else if (ne == columnView_data100) doView_data100_NE(info);
		else if (ne == Btm_cnt) doBtm_cnt_NE(info);
		else if (ne == Btm_fr) doBtm_fr_NE(info);
		else if (ne == Btm_to) doBtm_to_NE(info);
		else if (ne == Btm_input) doBtm_input_NE(info);
		else if (ne == Btm_h_align_type) doBtm_h_align_type_NE(info);
		else if (ne == Btm_h_align_type_nm) doBtm_h_align_type_nm_NE(info);
	}

	/**
	 * [View]TableのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[title]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_title_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data1]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data1_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data2]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data2_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data3]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data3_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data4]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data4_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data5]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data5_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data6]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data6_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data7]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data7_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data8]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data8_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data9]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data9_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data10]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data10_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data11]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data11_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data12]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data12_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data13]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data13_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data14]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data14_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data15]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data15_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data16]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data16_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data17]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data17_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data18]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data18_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data19]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data19_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data20]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data20_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data21]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data21_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data22]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data22_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data23]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data23_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data24]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data24_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data25]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data25_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data26]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data26_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data27]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data27_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data28]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data28_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data29]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data29_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data30]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data30_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data31]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data31_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data32]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data32_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data33]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data33_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data34]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data34_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data35]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data35_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data36]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data36_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data37]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data37_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data38]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data38_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data39]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data39_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data40]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data40_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data41]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data41_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data42]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data42_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data43]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data43_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data44]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data44_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data45]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data45_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data46]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data46_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data47]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data47_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data48]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data48_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data49]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data49_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data50]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data50_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data51]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data51_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data52]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data52_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data53]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data53_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data54]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data54_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data55]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data55_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data56]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data56_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data57]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data57_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data58]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data58_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data59]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data59_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data60]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data60_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data61]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data61_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data62]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data62_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data63]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data63_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data64]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data64_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data65]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data65_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data66]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data66_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data67]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data67_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data68]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data68_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data69]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data69_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data70]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data70_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data71]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data71_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data72]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data72_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data73]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data73_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data74]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data74_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data75]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data75_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data76]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data76_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data77]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data77_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data78]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data78_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data79]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data79_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data80]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data80_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data81]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data81_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data82]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data82_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data83]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data83_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data84]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data84_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data85]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data85_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data86]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data86_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data87]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data87_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data88]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data88_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data89]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data89_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data90]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data90_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data91]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data91_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data92]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data92_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data93]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data93_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data94]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data94_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data95]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data95_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data96]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data96_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data97]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data97_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data98]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data98_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data99]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data99_NE(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data100]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data100_NE(MCEventInfo info){
	}

	/**
	 * [Btm]パネルの[cnt]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtm_cnt_NE(MCEventInfo info){
	}

	/**
	 * [Btm]パネルの[fr]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtm_fr_NE(MCEventInfo info){
	}

	/**
	 * [Btm]パネルの[to]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtm_to_NE(MCEventInfo info){
	}

	/**
	 * [Btm]パネルの[input]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtm_input_NE(MCEventInfo info){
	}

	/**
	 * [Btm]パネルの[h_align_type]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtm_h_align_type_NE(MCEventInfo info){
	}

	/**
	 * [Btm]パネルの[h_align_type_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtm_h_align_type_nm_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == ViewTable) doView_NX(info);
		else if (nx == columnView_title) doView_title_NX(info);
		else if (nx == columnView_data1) doView_data1_NX(info);
		else if (nx == columnView_data2) doView_data2_NX(info);
		else if (nx == columnView_data3) doView_data3_NX(info);
		else if (nx == columnView_data4) doView_data4_NX(info);
		else if (nx == columnView_data5) doView_data5_NX(info);
		else if (nx == columnView_data6) doView_data6_NX(info);
		else if (nx == columnView_data7) doView_data7_NX(info);
		else if (nx == columnView_data8) doView_data8_NX(info);
		else if (nx == columnView_data9) doView_data9_NX(info);
		else if (nx == columnView_data10) doView_data10_NX(info);
		else if (nx == columnView_data11) doView_data11_NX(info);
		else if (nx == columnView_data12) doView_data12_NX(info);
		else if (nx == columnView_data13) doView_data13_NX(info);
		else if (nx == columnView_data14) doView_data14_NX(info);
		else if (nx == columnView_data15) doView_data15_NX(info);
		else if (nx == columnView_data16) doView_data16_NX(info);
		else if (nx == columnView_data17) doView_data17_NX(info);
		else if (nx == columnView_data18) doView_data18_NX(info);
		else if (nx == columnView_data19) doView_data19_NX(info);
		else if (nx == columnView_data20) doView_data20_NX(info);
		else if (nx == columnView_data21) doView_data21_NX(info);
		else if (nx == columnView_data22) doView_data22_NX(info);
		else if (nx == columnView_data23) doView_data23_NX(info);
		else if (nx == columnView_data24) doView_data24_NX(info);
		else if (nx == columnView_data25) doView_data25_NX(info);
		else if (nx == columnView_data26) doView_data26_NX(info);
		else if (nx == columnView_data27) doView_data27_NX(info);
		else if (nx == columnView_data28) doView_data28_NX(info);
		else if (nx == columnView_data29) doView_data29_NX(info);
		else if (nx == columnView_data30) doView_data30_NX(info);
		else if (nx == columnView_data31) doView_data31_NX(info);
		else if (nx == columnView_data32) doView_data32_NX(info);
		else if (nx == columnView_data33) doView_data33_NX(info);
		else if (nx == columnView_data34) doView_data34_NX(info);
		else if (nx == columnView_data35) doView_data35_NX(info);
		else if (nx == columnView_data36) doView_data36_NX(info);
		else if (nx == columnView_data37) doView_data37_NX(info);
		else if (nx == columnView_data38) doView_data38_NX(info);
		else if (nx == columnView_data39) doView_data39_NX(info);
		else if (nx == columnView_data40) doView_data40_NX(info);
		else if (nx == columnView_data41) doView_data41_NX(info);
		else if (nx == columnView_data42) doView_data42_NX(info);
		else if (nx == columnView_data43) doView_data43_NX(info);
		else if (nx == columnView_data44) doView_data44_NX(info);
		else if (nx == columnView_data45) doView_data45_NX(info);
		else if (nx == columnView_data46) doView_data46_NX(info);
		else if (nx == columnView_data47) doView_data47_NX(info);
		else if (nx == columnView_data48) doView_data48_NX(info);
		else if (nx == columnView_data49) doView_data49_NX(info);
		else if (nx == columnView_data50) doView_data50_NX(info);
		else if (nx == columnView_data51) doView_data51_NX(info);
		else if (nx == columnView_data52) doView_data52_NX(info);
		else if (nx == columnView_data53) doView_data53_NX(info);
		else if (nx == columnView_data54) doView_data54_NX(info);
		else if (nx == columnView_data55) doView_data55_NX(info);
		else if (nx == columnView_data56) doView_data56_NX(info);
		else if (nx == columnView_data57) doView_data57_NX(info);
		else if (nx == columnView_data58) doView_data58_NX(info);
		else if (nx == columnView_data59) doView_data59_NX(info);
		else if (nx == columnView_data60) doView_data60_NX(info);
		else if (nx == columnView_data61) doView_data61_NX(info);
		else if (nx == columnView_data62) doView_data62_NX(info);
		else if (nx == columnView_data63) doView_data63_NX(info);
		else if (nx == columnView_data64) doView_data64_NX(info);
		else if (nx == columnView_data65) doView_data65_NX(info);
		else if (nx == columnView_data66) doView_data66_NX(info);
		else if (nx == columnView_data67) doView_data67_NX(info);
		else if (nx == columnView_data68) doView_data68_NX(info);
		else if (nx == columnView_data69) doView_data69_NX(info);
		else if (nx == columnView_data70) doView_data70_NX(info);
		else if (nx == columnView_data71) doView_data71_NX(info);
		else if (nx == columnView_data72) doView_data72_NX(info);
		else if (nx == columnView_data73) doView_data73_NX(info);
		else if (nx == columnView_data74) doView_data74_NX(info);
		else if (nx == columnView_data75) doView_data75_NX(info);
		else if (nx == columnView_data76) doView_data76_NX(info);
		else if (nx == columnView_data77) doView_data77_NX(info);
		else if (nx == columnView_data78) doView_data78_NX(info);
		else if (nx == columnView_data79) doView_data79_NX(info);
		else if (nx == columnView_data80) doView_data80_NX(info);
		else if (nx == columnView_data81) doView_data81_NX(info);
		else if (nx == columnView_data82) doView_data82_NX(info);
		else if (nx == columnView_data83) doView_data83_NX(info);
		else if (nx == columnView_data84) doView_data84_NX(info);
		else if (nx == columnView_data85) doView_data85_NX(info);
		else if (nx == columnView_data86) doView_data86_NX(info);
		else if (nx == columnView_data87) doView_data87_NX(info);
		else if (nx == columnView_data88) doView_data88_NX(info);
		else if (nx == columnView_data89) doView_data89_NX(info);
		else if (nx == columnView_data90) doView_data90_NX(info);
		else if (nx == columnView_data91) doView_data91_NX(info);
		else if (nx == columnView_data92) doView_data92_NX(info);
		else if (nx == columnView_data93) doView_data93_NX(info);
		else if (nx == columnView_data94) doView_data94_NX(info);
		else if (nx == columnView_data95) doView_data95_NX(info);
		else if (nx == columnView_data96) doView_data96_NX(info);
		else if (nx == columnView_data97) doView_data97_NX(info);
		else if (nx == columnView_data98) doView_data98_NX(info);
		else if (nx == columnView_data99) doView_data99_NX(info);
		else if (nx == columnView_data100) doView_data100_NX(info);
		else if (nx == Btm_cnt) doBtm_cnt_NX(info);
		else if (nx == Btm_fr) doBtm_fr_NX(info);
		else if (nx == Btm_to) doBtm_to_NX(info);
		else if (nx == Btm_input) doBtm_input_NX(info);
		else if (nx == Btm_h_align_type) doBtm_h_align_type_NX(info);
		else if (nx == Btm_h_align_type_nm) doBtm_h_align_type_nm_NX(info);
	}

	/**
	 * [View]TableのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[title]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_title_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data1]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data1_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data2]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data2_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data3]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data3_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data4]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data4_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data5]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data5_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data6]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data6_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data7]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data7_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data8]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data8_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data9]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data9_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data10]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data10_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data11]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data11_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data12]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data12_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data13]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data13_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data14]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data14_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data15]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data15_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data16]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data16_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data17]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data17_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data18]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data18_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data19]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data19_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data20]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data20_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data21]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data21_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data22]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data22_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data23]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data23_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data24]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data24_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data25]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data25_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data26]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data26_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data27]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data27_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data28]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data28_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data29]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data29_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data30]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data30_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data31]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data31_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data32]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data32_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data33]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data33_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data34]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data34_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data35]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data35_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data36]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data36_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data37]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data37_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data38]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data38_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data39]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data39_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data40]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data40_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data41]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data41_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data42]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data42_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data43]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data43_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data44]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data44_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data45]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data45_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data46]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data46_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data47]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data47_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data48]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data48_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data49]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data49_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data50]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data50_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data51]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data51_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data52]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data52_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data53]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data53_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data54]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data54_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data55]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data55_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data56]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data56_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data57]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data57_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data58]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data58_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data59]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data59_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data60]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data60_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data61]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data61_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data62]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data62_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data63]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data63_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data64]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data64_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data65]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data65_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data66]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data66_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data67]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data67_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data68]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data68_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data69]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data69_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data70]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data70_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data71]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data71_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data72]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data72_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data73]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data73_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data74]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data74_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data75]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data75_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data76]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data76_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data77]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data77_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data78]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data78_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data79]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data79_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data80]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data80_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data81]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data81_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data82]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data82_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data83]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data83_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data84]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data84_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data85]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data85_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data86]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data86_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data87]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data87_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data88]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data88_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data89]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data89_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data90]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data90_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data91]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data91_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data92]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data92_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data93]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data93_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data94]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data94_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data95]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data95_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data96]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data96_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data97]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data97_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data98]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data98_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data99]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data99_NX(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data100]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data100_NX(MCEventInfo info){
	}

	/**
	 * [Btm]パネルの[cnt]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtm_cnt_NX(MCEventInfo info){
	}

	/**
	 * [Btm]パネルの[fr]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtm_fr_NX(MCEventInfo info){
	}

	/**
	 * [Btm]パネルの[to]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtm_to_NX(MCEventInfo info){
	}

	/**
	 * [Btm]パネルの[input]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtm_input_NX(MCEventInfo info){
	}

	/**
	 * [Btm]パネルの[h_align_type]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtm_h_align_type_NX(MCEventInfo info){
	}

	/**
	 * [Btm]パネルの[h_align_type_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtm_h_align_type_nm_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == columnView_title) doView_title_LC(info);
		else if (lc == columnView_data1) doView_data1_LC(info);
		else if (lc == columnView_data2) doView_data2_LC(info);
		else if (lc == columnView_data3) doView_data3_LC(info);
		else if (lc == columnView_data4) doView_data4_LC(info);
		else if (lc == columnView_data5) doView_data5_LC(info);
		else if (lc == columnView_data6) doView_data6_LC(info);
		else if (lc == columnView_data7) doView_data7_LC(info);
		else if (lc == columnView_data8) doView_data8_LC(info);
		else if (lc == columnView_data9) doView_data9_LC(info);
		else if (lc == columnView_data10) doView_data10_LC(info);
		else if (lc == columnView_data11) doView_data11_LC(info);
		else if (lc == columnView_data12) doView_data12_LC(info);
		else if (lc == columnView_data13) doView_data13_LC(info);
		else if (lc == columnView_data14) doView_data14_LC(info);
		else if (lc == columnView_data15) doView_data15_LC(info);
		else if (lc == columnView_data16) doView_data16_LC(info);
		else if (lc == columnView_data17) doView_data17_LC(info);
		else if (lc == columnView_data18) doView_data18_LC(info);
		else if (lc == columnView_data19) doView_data19_LC(info);
		else if (lc == columnView_data20) doView_data20_LC(info);
		else if (lc == columnView_data21) doView_data21_LC(info);
		else if (lc == columnView_data22) doView_data22_LC(info);
		else if (lc == columnView_data23) doView_data23_LC(info);
		else if (lc == columnView_data24) doView_data24_LC(info);
		else if (lc == columnView_data25) doView_data25_LC(info);
		else if (lc == columnView_data26) doView_data26_LC(info);
		else if (lc == columnView_data27) doView_data27_LC(info);
		else if (lc == columnView_data28) doView_data28_LC(info);
		else if (lc == columnView_data29) doView_data29_LC(info);
		else if (lc == columnView_data30) doView_data30_LC(info);
		else if (lc == columnView_data31) doView_data31_LC(info);
		else if (lc == columnView_data32) doView_data32_LC(info);
		else if (lc == columnView_data33) doView_data33_LC(info);
		else if (lc == columnView_data34) doView_data34_LC(info);
		else if (lc == columnView_data35) doView_data35_LC(info);
		else if (lc == columnView_data36) doView_data36_LC(info);
		else if (lc == columnView_data37) doView_data37_LC(info);
		else if (lc == columnView_data38) doView_data38_LC(info);
		else if (lc == columnView_data39) doView_data39_LC(info);
		else if (lc == columnView_data40) doView_data40_LC(info);
		else if (lc == columnView_data41) doView_data41_LC(info);
		else if (lc == columnView_data42) doView_data42_LC(info);
		else if (lc == columnView_data43) doView_data43_LC(info);
		else if (lc == columnView_data44) doView_data44_LC(info);
		else if (lc == columnView_data45) doView_data45_LC(info);
		else if (lc == columnView_data46) doView_data46_LC(info);
		else if (lc == columnView_data47) doView_data47_LC(info);
		else if (lc == columnView_data48) doView_data48_LC(info);
		else if (lc == columnView_data49) doView_data49_LC(info);
		else if (lc == columnView_data50) doView_data50_LC(info);
		else if (lc == columnView_data51) doView_data51_LC(info);
		else if (lc == columnView_data52) doView_data52_LC(info);
		else if (lc == columnView_data53) doView_data53_LC(info);
		else if (lc == columnView_data54) doView_data54_LC(info);
		else if (lc == columnView_data55) doView_data55_LC(info);
		else if (lc == columnView_data56) doView_data56_LC(info);
		else if (lc == columnView_data57) doView_data57_LC(info);
		else if (lc == columnView_data58) doView_data58_LC(info);
		else if (lc == columnView_data59) doView_data59_LC(info);
		else if (lc == columnView_data60) doView_data60_LC(info);
		else if (lc == columnView_data61) doView_data61_LC(info);
		else if (lc == columnView_data62) doView_data62_LC(info);
		else if (lc == columnView_data63) doView_data63_LC(info);
		else if (lc == columnView_data64) doView_data64_LC(info);
		else if (lc == columnView_data65) doView_data65_LC(info);
		else if (lc == columnView_data66) doView_data66_LC(info);
		else if (lc == columnView_data67) doView_data67_LC(info);
		else if (lc == columnView_data68) doView_data68_LC(info);
		else if (lc == columnView_data69) doView_data69_LC(info);
		else if (lc == columnView_data70) doView_data70_LC(info);
		else if (lc == columnView_data71) doView_data71_LC(info);
		else if (lc == columnView_data72) doView_data72_LC(info);
		else if (lc == columnView_data73) doView_data73_LC(info);
		else if (lc == columnView_data74) doView_data74_LC(info);
		else if (lc == columnView_data75) doView_data75_LC(info);
		else if (lc == columnView_data76) doView_data76_LC(info);
		else if (lc == columnView_data77) doView_data77_LC(info);
		else if (lc == columnView_data78) doView_data78_LC(info);
		else if (lc == columnView_data79) doView_data79_LC(info);
		else if (lc == columnView_data80) doView_data80_LC(info);
		else if (lc == columnView_data81) doView_data81_LC(info);
		else if (lc == columnView_data82) doView_data82_LC(info);
		else if (lc == columnView_data83) doView_data83_LC(info);
		else if (lc == columnView_data84) doView_data84_LC(info);
		else if (lc == columnView_data85) doView_data85_LC(info);
		else if (lc == columnView_data86) doView_data86_LC(info);
		else if (lc == columnView_data87) doView_data87_LC(info);
		else if (lc == columnView_data88) doView_data88_LC(info);
		else if (lc == columnView_data89) doView_data89_LC(info);
		else if (lc == columnView_data90) doView_data90_LC(info);
		else if (lc == columnView_data91) doView_data91_LC(info);
		else if (lc == columnView_data92) doView_data92_LC(info);
		else if (lc == columnView_data93) doView_data93_LC(info);
		else if (lc == columnView_data94) doView_data94_LC(info);
		else if (lc == columnView_data95) doView_data95_LC(info);
		else if (lc == columnView_data96) doView_data96_LC(info);
		else if (lc == columnView_data97) doView_data97_LC(info);
		else if (lc == columnView_data98) doView_data98_LC(info);
		else if (lc == columnView_data99) doView_data99_LC(info);
		else if (lc == columnView_data100) doView_data100_LC(info);
		else if (lc == Btm_cnt) doBtm_cnt_LC(info);
		else if (lc == Btm_fr) doBtm_fr_LC(info);
		else if (lc == Btm_to) doBtm_to_LC(info);
		else if (lc == Btm_h_align_type) doBtm_h_align_type_LC(info);
		else if (lc == Btm_h_align_type_nm) doBtm_h_align_type_nm_LC(info);
	}

	/**
	 * [View]パネルの[title]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_title_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data1]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data1_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data2]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data2_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data3]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data3_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data4]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data4_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data5]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data5_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data6]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data6_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data7]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data7_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data8]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data8_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data9]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data9_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data10]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data10_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data11]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data11_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data12]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data12_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data13]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data13_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data14]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data14_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data15]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data15_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data16]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data16_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data17]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data17_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data18]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data18_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data19]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data19_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data20]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data20_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data21]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data21_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data22]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data22_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data23]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data23_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data24]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data24_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data25]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data25_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data26]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data26_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data27]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data27_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data28]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data28_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data29]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data29_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data30]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data30_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data31]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data31_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data32]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data32_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data33]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data33_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data34]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data34_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data35]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data35_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data36]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data36_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data37]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data37_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data38]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data38_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data39]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data39_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data40]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data40_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data41]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data41_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data42]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data42_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data43]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data43_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data44]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data44_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data45]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data45_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data46]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data46_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data47]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data47_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data48]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data48_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data49]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data49_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data50]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data50_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data51]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data51_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data52]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data52_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data53]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data53_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data54]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data54_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data55]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data55_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data56]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data56_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data57]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data57_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data58]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data58_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data59]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data59_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data60]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data60_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data61]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data61_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data62]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data62_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data63]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data63_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data64]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data64_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data65]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data65_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data66]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data66_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data67]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data67_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data68]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data68_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data69]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data69_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data70]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data70_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data71]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data71_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data72]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data72_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data73]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data73_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data74]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data74_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data75]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data75_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data76]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data76_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data77]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data77_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data78]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data78_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data79]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data79_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data80]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data80_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data81]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data81_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data82]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data82_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data83]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data83_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data84]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data84_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data85]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data85_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data86]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data86_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data87]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data87_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data88]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data88_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data89]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data89_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data90]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data90_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data91]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data91_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data92]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data92_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data93]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data93_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data94]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data94_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data95]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data95_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data96]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data96_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data97]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data97_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data98]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data98_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data99]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data99_LC(MCEventInfo info){
	}

	/**
	 * [View]パネルの[data100]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doView_data100_LC(MCEventInfo info){
	}

	/**
	 * [Btm]パネルの[cnt]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtm_cnt_LC(MCEventInfo info){
	}

	/**
	 * [Btm]パネルの[fr]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtm_fr_LC(MCEventInfo info){
	}

	/**
	 * [Btm]パネルの[to]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtm_to_LC(MCEventInfo info){
	}

	/**
	 * [Btm]パネルの[h_align_type]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtm_h_align_type_LC(MCEventInfo info){
	}

	/**
	 * [Btm]パネルの[h_align_type_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doBtm_h_align_type_nm_LC(MCEventInfo info){
	}

	/**
	 * コンボ／リストのリスト[Btm_h_align_type_nm]の作成メソッド
	 */
	public MCList getBtm_h_align_type_nm(MCRow row, MCEventInfo info){
		return ((mcframe.clientFSUA.FSUAP0010.FSUAP_List)MCListLogic.create("mcframe.clientFSUA.FSUAP0010.FSUAP_List", this)).getHAlignType(row, info);
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}