package mcframe.clientFSBA.FSBAP0000;

import mcframe.clientCore.beans.MCButton;
import mcframe.clientCore.beans.popup.MCCalendarPanel;
import mcframe.commonCore.lang.MCCalendarDate;

/**
 * カレンダ画面を実装するためのインターフェースです。
 * カレンダ画面には「月画面」と「日付画面」が配置されます。
 * 
 * @see mcframe.clientFSBA.FSBAP0000.IfCalendarMonthPanel
 * @see mcframe.clientFSBA.FSBAP0000.IfCalendarDatePanel
 */
public interface IfCalendarPanel extends MCCalendarPanel {

	/**
	 * カレンダ画面の「年月」部品を返します。
	 * 
	 * @return 「年月」部品
	 */
	public IfCalendarMonthPanel getMonthPanel();
	
	/**
	 * カレンダ画面の「日」部品を返します。
	 * 
	 * @return 「日」部品
	 */
	public IfCalendarDatePanel getDatePanel();
	
	/**
	 * 日付ボタンに日付を設定します。
	 * 
	 * @param compo 日付ボタン
	 * @param value 日付
	 */
	public void setButtonDate(MCButton compo, MCCalendarDate<?> value);
}