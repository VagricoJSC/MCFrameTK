package mcframe.clientFSBA.FSBAP0000;

import mcframe.clientCore.beans.popup.MCCalendarPopup;

/**
 * 月画面を実装するためのインターフェースです。
 * 月画面はカレンダ画面に配置されます。
 * 
 * @see mcframe.clientFSBA.FSBAP0000.IfCalendarPanel
 */
public interface IfCalendarMonthPanel {

	/**
	 * カレンダ画面を返します。
	 * この画面がカレンダ画面に配置されていない場合は null を返します。
	 *
	 * @return カレンダ画面または null
	 */
	public IfCalendarPanel getCalendarPanel();
	
	/**
	 * カレンダポップアップを設定します。
	 * 
	 * @param popup カレンダポップアップ
	 */
	public void setCalendarPopup(MCCalendarPopup popup);
}