package mcframe.clientFSBA.FSBAP0000;

import mcframe.clientCore.beans.MCRootPanel;
import mcframe.clientCore.beans.table.MCTable;

/**
 * テーブル同期部品を利用する画面に実装するインタフェースです。
 */
public interface IfSyncTableBase {
	
	/**
	 * テーブル同期の主となるテーブルを返します。
	 */
	public MCTable<?> getHSyncMainTable(MCRootPanel panel);
}