package mcframe.clientFSBA.FSBAP0000;

/**
 * 日付画面を実装するためのインターフェースです。
 * 日付画面はカレンダ画面に配置されます。
 * 
 * @see mcframe.clientFSBA.FSBAP0000.IfCalendarPanel
 */
public interface IfCalendarDatePanel {
	
	/**
	 * カレンダ画面を返します。
	 * この画面がカレンダ画面に配置されていない場合は null を返します。
	 *
	 * @return カレンダ画面または null
	 */
	public IfCalendarPanel getCalendarPanel();
	
	/**
	 * 日付ボタンに日付を設定します。
	 */
	public void setButtonDate();
}