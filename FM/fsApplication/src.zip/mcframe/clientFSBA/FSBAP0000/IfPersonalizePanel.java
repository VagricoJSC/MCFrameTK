package mcframe.clientFSBA.FSBAP0000;

import mcframe.clientCore.beans.table.MCTable;

import mcframe.clientFSUB.FSUBP0000.IfRowMoveBase;

/**
 * パーソナライズ部品（FSBAP0010）を埋込画面として利用する画面を実装するためのインターフェースです。
 */
public interface IfPersonalizePanel extends IfRowMoveBase {

	/**
	 * パーソナライズデータを表示するテーブルを返します。
	 * 
	 * @return テーブル
	 */
	@Override
	public MCTable<?> getRowMoveTable();
	
	/**
	 * [デフォルト] ボタンのアクションを実行します。
	 */
	public void doDefaultAction();
	
	/**
	 * [キャンセル] ボタンのアクションを実行します。
	 */
	public void doCancelAction();
	
	/**
	 * [決定] ボタンのアクションを実行します。
	 */
	public void doDecisionAction();
}