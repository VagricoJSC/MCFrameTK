package mcframe.clientFSBA.FSBAP0000;

import java.awt.Color;

public interface IfColorPanelBase {
	
	/**
	 * 色情報設定画面で選択された色を設定します。
	 * 
	 * @param index 処理対象行
	 * @param color 色
	 */
	public void setColorValue(int index, Color color);
	
}