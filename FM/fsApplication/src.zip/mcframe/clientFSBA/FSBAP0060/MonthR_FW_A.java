package mcframe.clientFSBA.FSBAP0060;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Month"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class MonthR_FW_A extends MCConstRow {

	public static final String $Format = "Format";


	public static final MCMeta Format_META = createCommonMeta($Format, mcframe.commonCore.meta.M_META.YM);

	protected static final ConstMetaList<MonthR> constMetas = new ConstMetaList<MonthR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			Format_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected MonthR_FW_A(ConstMetaList<? extends MonthR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public MonthR clone() {
		return (MonthR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public MonthR createInstance() {
		return (MonthR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public MonthR getValues(String... names) {
		return (MonthR) super.getValues(names);
	}



	public MCDate Format() {
		return getConstDate(offset + 0, $Format);
	}

	public void Format(MCDate value) {
		setConstDate(offset + 0, $Format, value);
	}


	public MCDate getDate(String name) {
		if ($Format.equalsIgnoreCase(name)) {
			return Format();
		}
		return super.getDate(name);
	}

	public MCDate getDateNE(String name) {
		if ($Format.equalsIgnoreCase(name)) {
			return Format();
		}
		return super.getDateNE(name);
	}

	public void setDate(String name, MCDate value) {
		if ($Format.equalsIgnoreCase(name)) {
			Format(value);
			return;
		}
		super.setDate(name, value);
	}

	public void setDateNE(String name, MCDate value) {
		if ($Format.equalsIgnoreCase(name)) {
			Format(value);
			return;
		}
		super.setDateNE(name, value);
	}



}

