package mcframe.clientFSBA.FSBAP0060;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBAP0060"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP0060_FW_A extends MCRootPanel{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0060";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Month]ブロック関連のField定義
	public MCPanel MonthPanel = null;
	// [Month]ブロックの項目のField定義
	/**
	 * 前月 前月.<p>
	 *
	 */
	public MCButton Month_Previous = null;
	/**
	 * 月 .<p>
	 *
	 */
	public MCButton Month_Month = null;
	/**
	 * 次月 次月.<p>
	 *
	 */
	public MCButton Month_Next = null;
	public MCDateField Month_Format = null;
	/** [INIT]モードを表す定数 */
	public static final String INIT = "INIT";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{INIT};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	
	/** [Month]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0060.MonthR aMonthR;

	/**
	 * 項目コピーによってaMonthRを設定します。
	 *
	 * aMonthRのインスタンスは変更されません。
	 *
	 * @param row MonthR
	 */
	public void setMonthR(mcframe.clientFSBA.FSBAP0060.MonthR row) {
		if (row != null) {
			MCRow.copyall(getMonthR(), row);
		}
	}

	/**
	 * [Month]ブロックのコンテナaMonthRを返します。
	 *
	 * @return MonthR
	 */
	public mcframe.clientFSBA.FSBAP0060.MonthR getMonthR() {
		return aMonthR;
	}

	/**
	 * aMonthRを作成します。
	 *
	 * @return MonthR
	 */
	public mcframe.clientFSBA.FSBAP0060.MonthR createMonthR() {
		return mcframe.clientFSBA.FSBAP0060.MonthR.create();
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getMonthR())) ret.add(getMonthR());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getMonthR()) return "Month";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("Month")) return getMonthR();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(MonthPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0060_FW_A() {
		aMonthR = createMonthR();

	}

	/**
	 * コンストラクタです。埋込画面として作成するときに使用します。
	 *
	 * @param row 対応するInnerRow
	 */
	protected FSBAP0060_FW_A(mcframe.clientFSBA.FSBAP0060.MonthR row){
		aMonthR = row;
	}

	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP0060_FW.jbCreateMonth((FSBAP0060)this);
	}

	/**
	 * [Month]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateMonth(FSBAP0060 p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}


	/**
	 * この画面を埋め込み画面として作成します。
	 */	
	public static FSBAP0060 create(mcframe.clientFSBA.FSBAP0060.MonthR row){
		FSBAP0060 p = new FSBAP0060(row);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP0060 create(){
		FSBAP0060 p = new FSBAP0060();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}


	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP0060_FW.jbfInitMonth((FSBAP0060)this);
		FSBAP0060_FW.jbInitMonth((FSBAP0060)this);
	}

	/**
	 * [Month]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitMonth(FSBAP0060 p) {
		// ブロック関連の初期化
		p.MonthPanel = p.beansFactory.createPanel("Month");
		// ブロックの項目の初期化
		p.Month_Previous = p.beansFactory.createButton("Month.Previous", "calender_arrow");
		p.Month_Month = p.beansFactory.createButton("Month.Month");
		p.Month_Next = p.beansFactory.createButton("Month.Next", "calender_arrow");
		p.Month_Format = p.beansFactory.createDateField("Month.Format");
	}

	/**
	 * [Month]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitMonth(FSBAP0060 p) {
		// ブロック関連の初期化
		p.add(p.MonthPanel);
		p.setFirstBeans(p.MonthPanel);
		// ブロックの項目の初期化
		p.Month_Previous.setIcon("SUB_MONTH");
		p.MonthPanel.add(p.Month_Previous);
		p.MonthPanel.setFirstBeans(p.Month_Previous);
		p.Month_Previous.setNextBeans(p.Month_Month);
		p.MonthPanel.add(p.Month_Month);
		p.Month_Month.setNextBeans(p.Month_Next);
		p.Month_Next.setIcon("ADD_MONTH");
		p.MonthPanel.add(p.Month_Next);
		p.Month_Next.setNextBeans(p.Month_Format);
		p.MonthPanel.add(p.Month_Format);
		p.Month_Format.setRow(p.getMonthR(), mcframe.clientFSBA.FSBAP0060.MonthR.Format_META);
		p.Month_Format.setFormatID(mcframe.commonCore.meta.M_META.YM_FORMAT);
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP0060_FW.mcInitMonth((FSBAP0060)this);

		// [INIT]ステータスのモードの設定
		FSBAP0060_FW.statusInitINIT_Month((FSBAP0060)this);

	}

	/**
	 *  [Month]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitMonth(FSBAP0060 p) {
		p.Month_Previous.addAllListener(p);
		p.Month_Previous.setAPMethodName("doMonth_Previous");
		p.Month_Month.addAllListener(p);
		p.Month_Month.setAPMethodName("doMonth_Month");
		p.Month_Next.addAllListener(p);
		p.Month_Next.setAPMethodName("doMonth_Next");
		p.Month_Format.setListListener(p);
		p.Month_Format.addAllListener(p);
	}

	/**
	 * [INIT]ステータスの[Month]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Month(FSBAP0060 p){
		p.Month_Previous.putMode(p, INIT, MCMode.ENABLE);
		p.Month_Month.putMode(p, INIT, MCMode.ENABLE);
		p.Month_Next.putMode(p, INIT, MCMode.ENABLE);
		p.Month_Format.putMode(p, INIT, MCMode.INVISIBLE);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return INIT;
	}

	/**
	 * Table/Tree/GanttChartの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
	}

	/**
	 * この画面を[INIT]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setINITStatus() {
		status = INIT;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (INIT.equals(status)) {
			setINITStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}


	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == Month_Previous) doMonth_Previous(info);
		else if (ap == Month_Month) doMonth_Month(info);
		else if (ap == Month_Next) doMonth_Next(info);
	}

	/**
	 * [Month]パネルの[Previous]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doMonth_Previous(MCEventInfo info);

	/**
	 * [Month]パネルの[Month]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doMonth_Month(MCEventInfo info);

	/**
	 * [Month]パネルの[Next]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doMonth_Next(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == Month_Format) return doMonth_Format_VC(info);
		return true;
	}

	/**
	 * [Month]パネルの[Format]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMonth_Format_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == Month_Format) doMonth_Format_NC(info);
	}

	/**
	 * [Month]パネルの[Format]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMonth_Format_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == Month_Format) doMonth_Format_NE(info);
	}

	/**
	 * [Month]パネルの[Format]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMonth_Format_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == Month_Format) doMonth_Format_NX(info);
	}

	/**
	 * [Month]パネルの[Format]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMonth_Format_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == Month_Format) doMonth_Format_LC(info);
	}

	/**
	 * [Month]パネルの[Format]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMonth_Format_LC(MCEventInfo info){
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}