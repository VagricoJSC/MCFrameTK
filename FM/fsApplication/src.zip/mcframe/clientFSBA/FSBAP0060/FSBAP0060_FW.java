package mcframe.clientFSBA.FSBAP0060;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;


import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START

import javax.swing.SwingUtilities;

import mcframe.commonCore.resource.ctrl.MCResource;
import mcframe.clientCore.resource.MCConst;

import mcframe.clientCore.beans.popup.MCCalendarPanel;
import mcframe.clientCore.beans.popup.MCCalendarPopup;
import mcframe.clientCore.beans.popup.MCPopupConfig;
import mcframe.clientCore.beans.text.MCCalendarValidator;

import mcframe.clientFSBA.FSBAP0000.IfCalendarMonthPanel;
import mcframe.clientFSBA.FSBAP0000.IfCalendarPanel;

//import mcframe.clientFSBA.FSBAP0140.ScreenR;

//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP0060"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP0060_FW extends FSBAP0060_FW_A implements IfCalendarMonthPanel, MCCalendarPanel {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	/**
	 * カレンダポップアップです。
	 */
	private MCCalendarPopup popup;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0060_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込画面として作成するときに使用します。
	 *
	 * @param row 対応するInnerRow
	 */
	protected FSBAP0060_FW(mcframe.clientFSBA.FSBAP0060.MonthR row) {
		super(row);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_ROW_Month START

		//FMCB CUSTOM_CONSTRUCTOR_ROW_Month END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	@Override
	public void requestCloseWindow() {
		if (!isPartsPanel()) {
			if (!getCalendarPopup().addedToLayerdPane()) {
				getCalendarPopup().setVisible(false);
			}
			else {
				Component c = (Component)getCalendarPopup().getCalendarBeans();
				getCalendarPopup().setVisible(false);
				c.requestFocus();
			}
		}
	}

	/**
	 * Panel[Month]のボタン[Previous]の押下時の処理
	 */
	public void doMonth_Previous(MCEventInfo info) {
		MCCalendarPopup o = getCalendarPopup();
		MCCalendarDate<?> v = o.getCurrentDate();
		v = v.addMonth(-1);
		o.setCurrentDate(v);
		initMonthButton();
		
		IfCalendarPanel p = getCalendarPanel();
		if (p != null) {
			p.getDatePanel().setButtonDate();
		}
	}

	/**
	 * Panel[Month]のボタン[Month]の押下時の処理
	 */
	public void doMonth_Month(MCEventInfo info) {
		doMonthButtonAction();
	}

	/**
	 * Panel[Month]のボタン[Next]の押下時の処理
	 */
	public void doMonth_Next(MCEventInfo info) {
		MCCalendarPopup o = getCalendarPopup();
		MCCalendarDate<?> v = o.getCurrentDate();
		v = v.addMonth(1);
		o.setCurrentDate(v);
		initMonthButton();
		
		IfCalendarPanel p = getCalendarPanel();
		if (p != null) {
			p.getDatePanel().setButtonDate();
		}
	}
	
	@Override
	public void setINITStatus() {
		super.setINITStatus();
		
		setMonthButtonMode();
	}
	
	@Override
	public void afterOpen() {
		super.afterOpen();
		
		if (!isPartsPanel()) {
			if (!getCalendarPopup().addedToLayerdPane()) {
				// 7012-2246 (日付入力補助の左矢印ボタンが効かない事がある)
				SwingUtilities.invokeLater(() -> Month_Month.mcRequestFocus());
				// Month_Month.mcRequestFocus();
				// 7012-2246 ここまで
			}
		}
	}

	public IfCalendarPanel getCalendarPanel() {
		MCRootPanel p = getBaseRootPanel();
		return p instanceof IfCalendarPanel ? (IfCalendarPanel)p : null;
	}
	
	public void setCalendarPopup(MCCalendarPopup popup) {
		this.popup = popup;
		initMonthButton();
		
		IfCalendarPanel p = getCalendarPanel();
		if (p != null) {
			p.getDatePanel().setButtonDate();
		}
	}
	
	public MCCalendarPopup getCalendarPopup() {
		return popup;
	}
	
	/**
	 * 「月」ボタンを押下したときに実行されます。
	 */
	protected void doMonthButtonAction() {
		MCCalendarPopup p = getCalendarPopup();
		if (p.addedToLayerdPane()) {
			Component cp = (Component)p.getCalendarPanel();
			if (cp != null && !cp.isVisible()) {
				return;
			}
		}
		else {
			if (!p.isVisible()) {
				return;
			}
		}
		
		MCCalendarDate<?> v = p.getCurrentDate();
		v = v.startOfMonth();
		p.setCalendarValue(v);
		if (p.addedToLayerdPane()) {
			p.hideIfAddedToLayerdPane(true);
		}
		else {
			MCRootPanel rp = Month_Month.getBaseRootPanel();
			rp.requestCloseWindow();
			rp.getParent().remove(rp);
			((Component) p.getCalendarBeans()).requestFocus();
		}
	}

	/**
	 * 「月」ボタンを初期化します。
	 * カレンダポップアップの基準月に合わせて表示文字列を変更します。
	 */
	protected void initMonthButton() {
		MCCalendarDate<?> v = getCalendarPopup().getCurrentDate();
		v = v.startOfMonth();

		setMonthButtonMode();
		
		getMonthR().Format(
				(v instanceof MCDate) ? 
						(MCDate)v : MCDate.valueOf((MCTimestamp)v));
		String t = Month_Format.getText();
		Month_Month.setText(t);
		Month_Month.setToolTipText(t);
	}
	
	/**
	 * 「月」ボタンのモードを設定します。
	 */
	protected void setMonthButtonMode() {
		MCCalendarDate<?> v = getCalendarPopup().getCurrentDate();
		v = v.startOfMonth();
		MCCalendarValidator cv = 
			getCalendarPopup().getCalendarBeans().getCalendarValidator();
		Month_Month.setMode(cv.checkDate(v) ? MCMode.ENABLE : MCMode.DISABLE);
	}
	
	@Override
	protected void customInit() {
		super.customInit();
		
		if (!isPartsPanel()) {
			MCPopupConfig c = new MCPopupConfig();
			c.ignorePanelPopup(true);
			setPopupConfig(c);
		}
	}

	// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
	// 月パネルの高さが合わないため補正する。
	// 自動生成によるリソースの値がおかしい。
	@Override
	public void layoutInit() {
		super.layoutInit();

		// リソースのframe_hを取り出し補正する。
		String[][] s = getModuleAndScreenIDs();
		boolean b = false;
		String[] ka = {"frame_h"};
		for (String[] element : s) {
			String p = MCResource.createKey(element[0], element[1]);
			for (int j = 0; j < ka.length; j++) {
				String k = MCResource.createKey(p, ka[j]);
				if (MCConst.layout.containsKey(k)) {
					int frame_h = MCConst.layout.getInteger(k, -1);
					MonthPanel.setSize(MonthPanel.getSize().width, frame_h);

					// 7013-2275(SP3高解像度対応不具合まとめ)
					Dimension d = new Dimension(MonthPanel.getSize().width, frame_h);
					setPreferredSize(d);

					b = true;
					break;
				}
			}
			if(b == true) {
				break;
			}
		}
	}
	// 7013-0007 ここまで

	// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
	@Override
	protected void updatedResourceColor() {
		// 背景色設定不要
//		super.updatedResourceColor();
	}

	// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
	@Override
	protected boolean hasHeaderStatusBar() {
		return false;
	}
	// 7013-0007 ここまで

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	// 7013-2275(SP3高解像度対応不具合まとめ)
	@Override
	public String getLayoutKey() {
		return "S";
	}

}