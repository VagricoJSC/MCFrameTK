package mcframe.clientFSBA.FSBAP0160;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBAP0160"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP0160_FW_A extends mcframe.clientFSUC.FSUCP0000.FSUCP_PanelBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0160";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Search]ブロック関連のField定義
	public MCPanel SearchPanel = null;
	public MCTitledBorder SearchTitledBorder = null;
	// [Search]ブロックの項目のField定義
	public MCLabel Search_ModuleID_Label = null;
	/**
	 * モジュールＩＤ モジュールＩＤ.<p>
	 *
	 */
	public MCTextComboBox Search_ModuleID = null;
	/**
	 * モジュール名 モジュール名.<p>
	 *
	 */
	public MCTextField Search_ModuleName = null;
	public MCLabel Search_ScreenID_Label = null;
	/**
	 * 画面ＩＤ 画面ＩＤ.<p>
	 *
	 */
	public MCTextComboBox Search_ScreenID = null;
	/**
	 * 画面名 画面名.<p>
	 *
	 */
	public MCTextField Search_ScreenName = null;
	/**
	 * 検索 検索する.<p>
	 *
	 */
	public MCButton Search_Search = null;
	// [List]ブロック関連のField定義
	public MCPanel ListPanel = null;
	public MCScrollPane ListScrollPane = null;
	public MCTable2<mcframe.clientFSBA.FSBAP0160.ListR> ListTable = null;
	// [List]ブロックの項目のField定義
	/**
	 * モジュールＩＤ モジュールＩＤ.<p>
	 *
	 */
	public MCColumnConfig columnList_ModuleID = null;
	/**
	 * モジュール名 モジュール名.<p>
	 *
	 */
	public MCColumnConfig columnList_ModuleName = null;
	/**
	 * 画面ＩＤ 画面ＩＤ.<p>
	 *
	 */
	public MCColumnConfig columnList_ScreenID = null;
	/**
	 * 画面名 画面名.<p>
	 *
	 */
	public MCColumnConfig columnList_ScreenName = null;
	// [Memo]ブロック関連のField定義
	public MCPanel MemoPanel = null;
	// [Memo]ブロックの項目のField定義
	public mcframe.clientFSBA.FSBAP0150.FSBAP0150 Memo_MemoPanel_PPanel;
	/** [INIT]モードを表す定数 */
	public static final String INIT = "INIT";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{INIT};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	
	/** [Search]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0160.SearchR aSearchR;
	/** [List]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0160.ListR> aListL;

	/**
	 * 項目コピーによってaSearchRを設定します。
	 *
	 * aSearchRのインスタンスは変更されません。
	 *
	 * @param row SearchR
	 */
	public void setSearchR(mcframe.clientFSBA.FSBAP0160.SearchR row) {
		if (row != null) {
			MCRow.copyall(getSearchR(), row);
		}
	}

	/**
	 * [Search]ブロックのコンテナaSearchRを返します。
	 *
	 * @return SearchR
	 */
	public mcframe.clientFSBA.FSBAP0160.SearchR getSearchR() {
		return aSearchR;
	}

	/**
	 * aSearchRを作成します。
	 *
	 * @return SearchR
	 */
	public mcframe.clientFSBA.FSBAP0160.SearchR createSearchR() {
		return mcframe.clientFSBA.FSBAP0160.SearchR.create();
	}

	/**
	 * コピーによってaListLを設定します。
	 *
	 * aListLのインスタンスは変更されません。
	 *
	 * @param dataset ListL
	 */
	public void setListL(MCList<mcframe.clientFSBA.FSBAP0160.ListR> aList) {
		if (getListL() != aList) {
			getListL().setAll(aList);
		}
	}

	/**
	 * [List]ブロックのコンテナaListLを返します。
	 *
	 * @return ListL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0160.ListR> getListL() {
		return aListL;
	}

	/**
	 * aListRを作成します。
	 *
	 * @return ListR
	 */
	public mcframe.clientFSBA.FSBAP0160.ListR createListR() {
		return mcframe.clientFSBA.FSBAP0160.ListR.create();
	}

	/**
	 * aListLを作成します。
	 *
	 * @return ListL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0160.ListR> createListL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0160.ListR.class);
	}

	/**
	 * ListTableを初期化します。
	 */
	protected void createListTable(){
		if(ListTable == null){
			ListTable = beansFactory.createTable2("List.table");
		}
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getSearchR())) ret.add(getSearchR());
		if(!MCCollectionUtil.contains(ret, getListL())) ret.add(getListL());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getSearchR()) return "Search";
		if(aCnt == getListL()) return "List";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("Search")) return getSearchR();
		if(bId.equals("List")) return getListL();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(SearchPanel);
		ret.add(ListPanel);
		ret.add(MemoPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0160_FW_A() {
		aSearchR = createSearchR();
		aListL = createListL();

	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP0160_FW_A(String name) {
		aSearchR = createSearchR();
		aListL = createListL();
		createListTable();
		ListTable.setRowName(name);
	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP0160_FW.jbCreateSearch((FSBAP0160)this);
		FSBAP0160_FW.jbCreateList((FSBAP0160)this);
		FSBAP0160_FW.jbCreateMemo((FSBAP0160)this);
	}

	/**
	 * [Search]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateSearch(FSBAP0160 p) {
	}

	/**
	 * [List]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateList(FSBAP0160 p) {
	}

	/**
	 * [Memo]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateMemo(FSBAP0160 p) {
		p.Memo_MemoPanel_PPanel = mcframe.clientFSBA.FSBAP0150.FSBAP0150.create();
		p.Memo_MemoPanel_PPanel.setName("Memo.MemoPanel");
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}

	
	/** [Search_ModuleID_ListPutter]の定義 */
	private MCListPutter Search_ModuleID_p = null;

	/**
	 * [Search_ModuleID_ListPutter]の取得
	 */
	protected MCListPutter getSearch_ModuleID_ListPutter() {
		if (Search_ModuleID_p == null) {
			Search_ModuleID_p = createSearch_ModuleID_ListPutter(Search_ModuleID, "ModuleID", "ModuleName");

		}
		return Search_ModuleID_p;
	}
	
	
	/** [Search_ScreenID_ListPutter]の定義 */
	private MCListPutter Search_ScreenID_p = null;

	/**
	 * [Search_ScreenID_ListPutter]の取得
	 */
	protected MCListPutter getSearch_ScreenID_ListPutter() {
		if (Search_ScreenID_p == null) {
			Search_ScreenID_p = createSearch_ScreenID_ListPutter(Search_ScreenID, "ScreenID", "ScreenName");

		}
		return Search_ScreenID_p;
	}
	

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP0160 create(){
		FSBAP0160 p = new FSBAP0160();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP0160 create(String name){
		FSBAP0160 p = new FSBAP0160(name);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP0160_FW.jbfInitSearch((FSBAP0160)this);
		FSBAP0160_FW.jbfInitList((FSBAP0160)this);
		FSBAP0160_FW.jbfInitMemo((FSBAP0160)this);
		FSBAP0160_FW.jbInitSearch((FSBAP0160)this);
		FSBAP0160_FW.jbInitList((FSBAP0160)this);
		FSBAP0160_FW.jbInitMemo((FSBAP0160)this);
	}

	/**
	 * [Search]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitSearch(FSBAP0160 p) {
		// ブロック関連の初期化
		p.SearchPanel = p.beansFactory.createPanel("Search");
		p.SearchTitledBorder = p.beansFactory.createTitledBorder();
		// ブロックの項目の初期化
		p.Search_ModuleID_Label = p.beansFactory.createLabel("Search.ModuleID_Label");
		p.Search_ModuleID = p.beansFactory.createTextComboBox("Search.ModuleID");
		p.Search_ModuleID.setLabel(p.Search_ModuleID_Label);
		p.Search_ModuleName = p.beansFactory.createTextField("Search.ModuleName");
		p.Search_ScreenID_Label = p.beansFactory.createLabel("Search.ScreenID_Label");
		p.Search_ScreenID = p.beansFactory.createTextComboBox("Search.ScreenID");
		p.Search_ScreenID.setLabel(p.Search_ScreenID_Label);
		p.Search_ScreenName = p.beansFactory.createTextField("Search.ScreenName");
		p.Search_Search = p.beansFactory.createButton("Search.Search", "srch");
	}

	/**
	 * [List]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitList(FSBAP0160 p) {
		// ブロック関連の初期化
		p.ListPanel = p.beansFactory.createPanel("List");
		p.ListScrollPane = p.beansFactory.createScrollPane("List.scroll");
		p.createListTable();
		// ブロックの項目の初期化
		p.columnList_ModuleID = p.beansFactory.createTableColumn("List.ModuleID", MCColumnType.TEXT);
		p.columnList_ModuleName = p.beansFactory.createTableColumn("List.ModuleName", MCColumnType.TEXT);
		p.columnList_ScreenID = p.beansFactory.createTableColumn("List.ScreenID", MCColumnType.TEXT);
		p.columnList_ScreenName = p.beansFactory.createTableColumn("List.ScreenName", MCColumnType.TEXT);
	}

	/**
	 * [Memo]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitMemo(FSBAP0160 p) {
		// ブロック関連の初期化
		p.MemoPanel = p.beansFactory.createPanel("Memo");
		// ブロックの項目の初期化
	}

	/**
	 * [Search]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitSearch(FSBAP0160 p) {
		// ブロック関連の初期化
		p.SearchPanel.setBorder(p.SearchTitledBorder);
		p.add(p.SearchPanel);
		p.setLastBeans(p.SearchPanel);
		p.SearchPanel.setNextBeans(p.ListPanel);
		p.SearchPanel.setValueCheck(false);
		p.SearchPanel.setExtValue(MCPanel.SRCH_CND_SETTING_PANEL, true);
		p.SearchPanel.setLayoutPosition("N");
		// ブロックの項目の初期化
		p.Search_ModuleID.setListType(MCListType.STRICT);
		p.Search_ModuleID.setLinkBeans(p.Search_ModuleName);
		p.SearchPanel.add(p.Search_ModuleID_Label);
		p.SearchPanel.add(p.Search_ModuleID);
		p.SearchPanel.setLastBeans(p.Search_ModuleID);
		p.Search_ModuleID.setNextBeans(p.Search_ModuleName);
		p.Search_ModuleID.setRow(p.getSearchR(), mcframe.clientFSBA.FSBAP0160.SearchR.ModuleID_META);
		p.SearchPanel.add(p.Search_ModuleName);
		p.Search_ModuleName.setNextBeans(p.Search_ScreenID);
		p.Search_ModuleName.setRow(p.getSearchR(), mcframe.clientFSBA.FSBAP0160.SearchR.ModuleName_META);
		p.Search_ScreenID.setListType(MCListType.FREE);
		p.Search_ScreenID.setLinkBeans(p.Search_ScreenName);
		p.SearchPanel.add(p.Search_ScreenID_Label);
		p.SearchPanel.add(p.Search_ScreenID);
		p.Search_ScreenID.setNextBeans(p.Search_ScreenName);
		p.Search_ScreenID.setRow(p.getSearchR(), mcframe.clientFSBA.FSBAP0160.SearchR.ScreenID_META);
		p.SearchPanel.add(p.Search_ScreenName);
		p.Search_ScreenName.setNextBeans(p.Search_Search);
		p.Search_ScreenName.setRow(p.getSearchR(), mcframe.clientFSBA.FSBAP0160.SearchR.ScreenName_META);
		p.Search_Search.setIcon("SEARCH");
		p.Search_Search.setFunctionKey(MCFunctionKey.F1);
		p.SearchPanel.add(p.Search_Search);
	}

	/**
	 * [List]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitList(FSBAP0160 p) {
		// ブロック関連の初期化
		p.add(p.ListPanel);
		p.ListPanel.setNextBeans(p.MemoPanel);
		p.ListPanel.add(p.ListScrollPane);
		p.ListPanel.setLastBeans(p.ListTable);
		p.ListScrollPane.setViewportView(p.ListTable);
		p.ListTable.setList(p.getListL());
		p.ListPanel.setLayoutPosition("CLC");
		// ブロックの項目の初期化
	}

	/**
	 * [Memo]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitMemo(FSBAP0160 p) {
		// ブロック関連の初期化
		p.add(p.MemoPanel);
		p.MemoPanel.setLayoutPosition("CRC");
		// ブロックの項目の初期化
		p.MemoPanel.add(p.Memo_MemoPanel_PPanel);
		p.MemoPanel.setLastBeans(p.Memo_MemoPanel_PPanel);
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "G";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP0160_FW.mcInitSearch((FSBAP0160)this);
		FSBAP0160_FW.mcInitList((FSBAP0160)this);
		FSBAP0160_FW.mcInitMemo((FSBAP0160)this);

		// [INIT]ステータスのモードの設定
		FSBAP0160_FW.statusInitINIT_Search((FSBAP0160)this);
		FSBAP0160_FW.statusInitINIT_List((FSBAP0160)this);
		FSBAP0160_FW.statusInitINIT_Memo((FSBAP0160)this);

	}

	/**
	 *  [Search]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitSearch(FSBAP0160 p) {
		p.Search_ModuleID.setListListener(p);
		p.Search_ModuleID.addAllListener(p);
		p.Search_ModuleName.setListListener(p);
		p.Search_ModuleName.addAllListener(p);
		p.Search_ScreenID.setListListener(p);
		p.Search_ScreenID.addAllListener(p);
		p.Search_ScreenName.setListListener(p);
		p.Search_ScreenName.addAllListener(p);
		p.Search_Search.addAllListener(p);
		p.Search_Search.setAPMethodName("doSearch_Search");
	}

	/**
	 *  [List]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitList(FSBAP0160 p) {
		p.ListTable.addAllListener(p);
		p.columnList_ModuleID.addAllListener(p);
		p.columnList_ModuleID.setListListener(p);
		p.columnList_ModuleName.addAllListener(p);
		p.columnList_ModuleName.setListListener(p);
		p.columnList_ScreenID.addAllListener(p);
		p.columnList_ScreenID.setListListener(p);
		p.columnList_ScreenName.addAllListener(p);
		p.columnList_ScreenName.setListListener(p);
	}

	/**
	 *  [Memo]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitMemo(FSBAP0160 p) {
	}

	/**
	 * [INIT]ステータスの[Search]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Search(FSBAP0160 p){
		p.Search_ModuleName.putMode(p, INIT, MCMode.READ_ONLY);
		p.Search_ScreenName.putMode(p, INIT, MCMode.READ_ONLY);
		p.Search_Search.putMode(p, INIT, MCMode.ENABLE);

	}

	/**
	 * [INIT]ステータスの[List]ブロックのモードの設定
	 */
	protected static void statusInitINIT_List(FSBAP0160 p){
		p.columnList_ModuleID.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnList_ModuleName.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnList_ScreenID.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnList_ScreenName.putMode(p, INIT, MCMode.READ_ONLY);

	}

	/**
	 * [INIT]ステータスの[Memo]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Memo(FSBAP0160 p){
		p.Memo_MemoPanel_PPanel.putStatus(INIT, mcframe.clientFSBA.FSBAP0150.FSBAP0150.NOEDIT);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return INIT;
	}

	/**
	 * Table/Tree/GanttChartの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
		FSBAP0160_FW.setTableConfigList((FSBAP0160)this);
	}

	/**
	 * [List]ブロックのTableの設定
	 */
	protected static void setTableConfigList(FSBAP0160 p) {
		p.columnList_ModuleID.setMeta(mcframe.clientFSBA.FSBAP0160.ListR.ModuleID_META);
		p.ListTable.addColumnConfig(p.columnList_ModuleID);
		p.columnList_ModuleName.setMeta(mcframe.clientFSBA.FSBAP0160.ListR.ModuleName_META);
		p.ListTable.addColumnConfig(p.columnList_ModuleName);
		p.columnList_ScreenID.setMeta(mcframe.clientFSBA.FSBAP0160.ListR.ScreenID_META);
		p.ListTable.addColumnConfig(p.columnList_ScreenID);
		p.columnList_ScreenName.setMeta(mcframe.clientFSBA.FSBAP0160.ListR.ScreenName_META);
		p.ListTable.addColumnConfig(p.columnList_ScreenName);
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
		Search_ModuleID.setListVisibleColumn(MCListLogic.getViewColumnName());
		Search_ModuleID.getListConfig().setPutter(getSearch_ModuleID_ListPutter());
		Search_ScreenID.setListVisibleColumn(MCListLogic.getViewColumnName());
		Search_ScreenID.getListConfig().setPutter(getSearch_ScreenID_ListPutter());
	}

	/**
	 * この画面を[INIT]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setINITStatus() {
		status = INIT;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (INIT.equals(status)) {
			setINITStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * [Search_ModuleID_ListPutter]の作成
	 */
	protected MCListPutter createSearch_ModuleID_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("FS.FSUAP0010.UserModuleID");
		return lp;
	}
	 
	/**
	 * [Search_ScreenID_ListPutter]の作成
	 */
	protected MCListPutter createSearch_ScreenID_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("FS.FSUAP0010.UserMemoScreenID");
		return lp;
	}
	 

	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		if(combo == Search_ModuleID) return getSearch_ModuleID(row, info);
		if(combo == Search_ScreenID) return getSearch_ScreenID(row, info);
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == Search_Search) doSearch_Search(info);
	}

	/**
	 * [Search]パネルの[Search]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doSearch_Search(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == ListTable) return doList_VC(info);
		if (vc == Search_ModuleID) return doSearch_ModuleID_VC(info);
		if (vc == Search_ModuleName) return doSearch_ModuleName_VC(info);
		if (vc == Search_ScreenID) return doSearch_ScreenID_VC(info);
		if (vc == Search_ScreenName) return doSearch_ScreenName_VC(info);
		if (vc == columnList_ModuleID) return doList_ModuleID_VC(info);
		if (vc == columnList_ModuleName) return doList_ModuleName_VC(info);
		if (vc == columnList_ScreenID) return doList_ScreenID_VC(info);
		if (vc == columnList_ScreenName) return doList_ScreenName_VC(info);
		return true;
	}

	/**
	 * [List]Tableの選択行が変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doList_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Search]パネルの[ModuleID]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doSearch_ModuleID_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Search]パネルの[ModuleName]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doSearch_ModuleName_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Search]パネルの[ScreenID]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doSearch_ScreenID_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Search]パネルの[ScreenName]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doSearch_ScreenName_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [List]パネルの[ModuleID]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doList_ModuleID_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [List]パネルの[ModuleName]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doList_ModuleName_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [List]パネルの[ScreenID]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doList_ScreenID_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [List]パネルの[ScreenName]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doList_ScreenName_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == ListTable) doList_NC(info);
		else if (nc == Search_ModuleID) doSearch_ModuleID_NC(info);
		else if (nc == Search_ModuleName) doSearch_ModuleName_NC(info);
		else if (nc == Search_ScreenID) doSearch_ScreenID_NC(info);
		else if (nc == Search_ScreenName) doSearch_ScreenName_NC(info);
		else if (nc == columnList_ModuleID) doList_ModuleID_NC(info);
		else if (nc == columnList_ModuleName) doList_ModuleName_NC(info);
		else if (nc == columnList_ScreenID) doList_ScreenID_NC(info);
		else if (nc == columnList_ScreenName) doList_ScreenName_NC(info);
	}

	/**
	 * [List]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_NC(MCEventInfo info){
	}

	/**
	 * [Search]パネルの[ModuleID]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doSearch_ModuleID_NC(MCEventInfo info){
	}

	/**
	 * [Search]パネルの[ModuleName]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doSearch_ModuleName_NC(MCEventInfo info){
	}

	/**
	 * [Search]パネルの[ScreenID]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doSearch_ScreenID_NC(MCEventInfo info){
	}

	/**
	 * [Search]パネルの[ScreenName]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doSearch_ScreenName_NC(MCEventInfo info){
	}

	/**
	 * [List]パネルの[ModuleID]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_ModuleID_NC(MCEventInfo info){
	}

	/**
	 * [List]パネルの[ModuleName]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_ModuleName_NC(MCEventInfo info){
	}

	/**
	 * [List]パネルの[ScreenID]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_ScreenID_NC(MCEventInfo info){
	}

	/**
	 * [List]パネルの[ScreenName]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_ScreenName_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == ListTable) doList_NE(info);
		else if (ne == Search_ModuleID) doSearch_ModuleID_NE(info);
		else if (ne == Search_ModuleName) doSearch_ModuleName_NE(info);
		else if (ne == Search_ScreenID) doSearch_ScreenID_NE(info);
		else if (ne == Search_ScreenName) doSearch_ScreenName_NE(info);
		else if (ne == columnList_ModuleID) doList_ModuleID_NE(info);
		else if (ne == columnList_ModuleName) doList_ModuleName_NE(info);
		else if (ne == columnList_ScreenID) doList_ScreenID_NE(info);
		else if (ne == columnList_ScreenName) doList_ScreenName_NE(info);
	}

	/**
	 * [List]TableのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_NE(MCEventInfo info){
	}

	/**
	 * [Search]パネルの[ModuleID]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doSearch_ModuleID_NE(MCEventInfo info){
	}

	/**
	 * [Search]パネルの[ModuleName]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doSearch_ModuleName_NE(MCEventInfo info){
	}

	/**
	 * [Search]パネルの[ScreenID]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doSearch_ScreenID_NE(MCEventInfo info){
	}

	/**
	 * [Search]パネルの[ScreenName]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doSearch_ScreenName_NE(MCEventInfo info){
	}

	/**
	 * [List]パネルの[ModuleID]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_ModuleID_NE(MCEventInfo info){
	}

	/**
	 * [List]パネルの[ModuleName]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_ModuleName_NE(MCEventInfo info){
	}

	/**
	 * [List]パネルの[ScreenID]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_ScreenID_NE(MCEventInfo info){
	}

	/**
	 * [List]パネルの[ScreenName]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_ScreenName_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == ListTable) doList_NX(info);
		else if (nx == Search_ModuleID) doSearch_ModuleID_NX(info);
		else if (nx == Search_ModuleName) doSearch_ModuleName_NX(info);
		else if (nx == Search_ScreenID) doSearch_ScreenID_NX(info);
		else if (nx == Search_ScreenName) doSearch_ScreenName_NX(info);
		else if (nx == columnList_ModuleID) doList_ModuleID_NX(info);
		else if (nx == columnList_ModuleName) doList_ModuleName_NX(info);
		else if (nx == columnList_ScreenID) doList_ScreenID_NX(info);
		else if (nx == columnList_ScreenName) doList_ScreenName_NX(info);
	}

	/**
	 * [List]TableのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_NX(MCEventInfo info){
	}

	/**
	 * [Search]パネルの[ModuleID]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doSearch_ModuleID_NX(MCEventInfo info){
	}

	/**
	 * [Search]パネルの[ModuleName]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doSearch_ModuleName_NX(MCEventInfo info){
	}

	/**
	 * [Search]パネルの[ScreenID]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doSearch_ScreenID_NX(MCEventInfo info){
	}

	/**
	 * [Search]パネルの[ScreenName]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doSearch_ScreenName_NX(MCEventInfo info){
	}

	/**
	 * [List]パネルの[ModuleID]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_ModuleID_NX(MCEventInfo info){
	}

	/**
	 * [List]パネルの[ModuleName]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_ModuleName_NX(MCEventInfo info){
	}

	/**
	 * [List]パネルの[ScreenID]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_ScreenID_NX(MCEventInfo info){
	}

	/**
	 * [List]パネルの[ScreenName]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_ScreenName_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == Search_ModuleID) doSearch_ModuleID_LC(info);
		else if (lc == Search_ModuleName) doSearch_ModuleName_LC(info);
		else if (lc == Search_ScreenID) doSearch_ScreenID_LC(info);
		else if (lc == Search_ScreenName) doSearch_ScreenName_LC(info);
		else if (lc == columnList_ModuleID) doList_ModuleID_LC(info);
		else if (lc == columnList_ModuleName) doList_ModuleName_LC(info);
		else if (lc == columnList_ScreenID) doList_ScreenID_LC(info);
		else if (lc == columnList_ScreenName) doList_ScreenName_LC(info);
	}

	/**
	 * [Search]パネルの[ModuleID]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doSearch_ModuleID_LC(MCEventInfo info){
	}

	/**
	 * [Search]パネルの[ModuleName]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doSearch_ModuleName_LC(MCEventInfo info){
	}

	/**
	 * [Search]パネルの[ScreenID]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doSearch_ScreenID_LC(MCEventInfo info){
	}

	/**
	 * [Search]パネルの[ScreenName]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doSearch_ScreenName_LC(MCEventInfo info){
	}

	/**
	 * [List]パネルの[ModuleID]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_ModuleID_LC(MCEventInfo info){
	}

	/**
	 * [List]パネルの[ModuleName]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_ModuleName_LC(MCEventInfo info){
	}

	/**
	 * [List]パネルの[ScreenID]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_ScreenID_LC(MCEventInfo info){
	}

	/**
	 * [List]パネルの[ScreenName]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_ScreenName_LC(MCEventInfo info){
	}

	/**
	 * コンボ／リストのリスト[Search_ModuleID]の作成メソッド
	 */
	public MCList getSearch_ModuleID(MCRow row, MCEventInfo info){
		return ((mcframe.clientFSUA.FSUAP0010.FSUAP_List)MCListLogic.create("mcframe.clientFSUA.FSUAP0010.FSUAP_List", this)).getUserModuleID(row, info);
	}

	/**
	 * コンボ／リストのリスト[Search_ScreenID]の作成メソッド
	 */
	public MCList getSearch_ScreenID(MCRow row, MCEventInfo info){
		return ((mcframe.clientFSUA.FSUAP0010.FSUAP_List)MCListLogic.create("mcframe.clientFSUA.FSUAP0010.FSUAP_List", this)).getUserMemoScreenID(row, info);
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}