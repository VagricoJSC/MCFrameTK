package mcframe.clientFSBA.FSBAP0830;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBAP0830"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP0830_FW_A extends mcframe.clientFSUC.FSUCP0000.FSUCP_PanelBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0830";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Dialog]ブロック関連のField定義
	public MCPanel DialogPanel = null;
	// [Dialog]ブロックの項目のField定義
	public MCLabel Dialog_setting_name_Label = null;
	/**
	 *  設定名.<p>
	 *
	 */
	public MCTextField Dialog_setting_name = null;
	/**
	 *  更新する.<p>
	 *
	 */
	public MCButton Dialog_upd = null;
	/**
	 *  キャンセル.<p>
	 *
	 */
	public MCButton Dialog_cancel = null;
	/** [INIT]モードを表す定数 */
	public static final String INIT = "INIT";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{INIT};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	
	/** [Dialog]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0830.DialogR aDialogR;

	/**
	 * 項目コピーによってaDialogRを設定します。
	 *
	 * aDialogRのインスタンスは変更されません。
	 *
	 * @param row DialogR
	 */
	public void setDialogR(mcframe.clientFSBA.FSBAP0830.DialogR row) {
		if (row != null) {
			MCRow.copyall(getDialogR(), row);
		}
	}

	/**
	 * [Dialog]ブロックのコンテナaDialogRを返します。
	 *
	 * @return DialogR
	 */
	public mcframe.clientFSBA.FSBAP0830.DialogR getDialogR() {
		return aDialogR;
	}

	/**
	 * aDialogRを作成します。
	 *
	 * @return DialogR
	 */
	public mcframe.clientFSBA.FSBAP0830.DialogR createDialogR() {
		return mcframe.clientFSBA.FSBAP0830.DialogR.create();
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getDialogR())) ret.add(getDialogR());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getDialogR()) return "Dialog";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("Dialog")) return getDialogR();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(DialogPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0830_FW_A() {
		aDialogR = createDialogR();

	}

	/**
	 * コンストラクタです。埋込画面として作成するときに使用します。
	 *
	 * @param row 対応するInnerRow
	 */
	protected FSBAP0830_FW_A(mcframe.clientFSBA.FSBAP0830.DialogR row){
		aDialogR = row;
	}

	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP0830_FW.jbCreateDialog((FSBAP0830)this);
	}

	/**
	 * [Dialog]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateDialog(FSBAP0830 p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}


	/**
	 * この画面を埋め込み画面として作成します。
	 */	
	public static FSBAP0830 create(mcframe.clientFSBA.FSBAP0830.DialogR row){
		FSBAP0830 p = new FSBAP0830(row);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP0830 create(){
		FSBAP0830 p = new FSBAP0830();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}


	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP0830_FW.jbfInitDialog((FSBAP0830)this);
		FSBAP0830_FW.jbInitDialog((FSBAP0830)this);
	}

	/**
	 * [Dialog]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitDialog(FSBAP0830 p) {
		// ブロック関連の初期化
		p.DialogPanel = p.beansFactory.createPanel("Dialog");
		// ブロックの項目の初期化
		p.Dialog_setting_name_Label = p.beansFactory.createLabel("Dialog.setting_name_Label");
		p.Dialog_setting_name = p.beansFactory.createTextField("Dialog.setting_name");
		p.Dialog_setting_name.setLabel(p.Dialog_setting_name_Label);
		p.Dialog_upd = p.beansFactory.createButton("Dialog.upd", "upd");
		p.Dialog_cancel = p.beansFactory.createButton("Dialog.cancel");
	}

	/**
	 * [Dialog]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitDialog(FSBAP0830 p) {
		// ブロック関連の初期化
		p.add(p.DialogPanel);
		p.setLastBeans(p.DialogPanel);
		p.DialogPanel.setValueCheck(false);
		p.DialogPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
		p.DialogPanel.add(p.Dialog_setting_name_Label);
		p.DialogPanel.add(p.Dialog_setting_name);
		p.DialogPanel.setLastBeans(p.Dialog_setting_name);
		p.Dialog_setting_name.setNextBeans(p.Dialog_upd);
		p.Dialog_setting_name.setRow(p.getDialogR(), mcframe.clientFSBA.FSBAP0830.DialogR.setting_name_META);
		p.Dialog_upd.setIcon("REGISTER");
		p.DialogPanel.add(p.Dialog_upd);
		p.Dialog_upd.setNextBeans(p.Dialog_cancel);
		p.DialogPanel.add(p.Dialog_cancel);
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "S";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP0830_FW.mcInitDialog((FSBAP0830)this);

		// [INIT]ステータスのモードの設定
		FSBAP0830_FW.statusInitINIT_Dialog((FSBAP0830)this);

	}

	/**
	 *  [Dialog]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitDialog(FSBAP0830 p) {
		p.Dialog_setting_name.setListListener(p);
		p.Dialog_setting_name.addAllListener(p);
		p.Dialog_upd.addAllListener(p);
		p.Dialog_upd.setAPMethodName("doDialog_upd");
		p.Dialog_cancel.addAllListener(p);
		p.Dialog_cancel.setAPMethodName("doDialog_cancel");
	}

	/**
	 * [INIT]ステータスの[Dialog]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Dialog(FSBAP0830 p){
		p.Dialog_setting_name.putMode(p, INIT, MCMode.REQUIRED);
		p.Dialog_upd.putMode(p, INIT, MCMode.ENABLE);
		p.Dialog_cancel.putMode(p, INIT, MCMode.ENABLE);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return INIT;
	}

	/**
	 * Table/Treeの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
	}

	/**
	 * この画面を[INIT]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setINITStatus() {
		status = INIT;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (INIT.equals(status)) {
			setINITStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}


	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == Dialog_upd) doDialog_upd(info);
		else if (ap == Dialog_cancel) doDialog_cancel(info);
	}

	/**
	 * [Dialog]パネルの[upd]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDialog_upd(MCEventInfo info);

	/**
	 * [Dialog]パネルの[cancel]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doDialog_cancel(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == Dialog_setting_name) return doDialog_setting_name_VC(info);
		return true;
	}

	/**
	 * [Dialog]パネルの[setting_name]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDialog_setting_name_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == Dialog_setting_name) doDialog_setting_name_NC(info);
	}

	/**
	 * [Dialog]パネルの[setting_name]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDialog_setting_name_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == Dialog_setting_name) doDialog_setting_name_NE(info);
	}

	/**
	 * [Dialog]パネルの[setting_name]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDialog_setting_name_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == Dialog_setting_name) doDialog_setting_name_NX(info);
	}

	/**
	 * [Dialog]パネルの[setting_name]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDialog_setting_name_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == Dialog_setting_name) doDialog_setting_name_LC(info);
	}

	/**
	 * [Dialog]パネルの[setting_name]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDialog_setting_name_LC(MCEventInfo info){
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}