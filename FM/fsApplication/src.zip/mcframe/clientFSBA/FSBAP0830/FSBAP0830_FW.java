package mcframe.clientFSBA.FSBAP0830;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;


import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.clientCore.beans.popup.MCPopupBeans;
import mcframe.clientFSUC.FSUCP0000.FSUCP_PopupConfig;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP0830"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP0830_FW extends FSBAP0830_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START
	
	protected DialogR _data;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0830_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込画面として作成するときに使用します。
	 *
	 * @param row 対応するInnerRow
	 */
	protected FSBAP0830_FW(mcframe.clientFSBA.FSBAP0830.DialogR row) {
		super(row);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_ROW_Dialog START

		//FMCB CUSTOM_CONSTRUCTOR_ROW_Dialog END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * Panel[Dialog]のボタン[cancel]の押下時の処理
	 */
	@Override
	public void doDialog_cancel(MCEventInfo info) {
		requestCloseWindow();
	}
	/**
	 * Panel[Dialog]のボタン[upd]の押下時の処理
	 */
	@Override
	public void doDialog_upd(MCEventInfo info) {
		MCMessageList msgL = checkReq(getDialogR());
		if (!msgL.isEmpty()) {
			message(msgL);
			return;
		}
		
		_data.setting_name(getDialogR().setting_name());
		
		requestCloseWindow();
	}

	/**
	 * 他画面から呼び出された場合の初期化を実装します。
	 *
	 * <li>起動タイプ：T1 <br>
	 * バインド値 ＜使用しない＞<br>
	 * その他の引数：
	 * <table border = 1>
	 * <tr>
	 * <th>カラム名</th>
	 * <th>型</th>
	 * <th>備考</th>
	 * </tr>
	 * <tr>
	 * <td>第１引数</td>
	 * <td>DialogR</td>
	 * <td>入力された設定名を格納する</td>
	 * </tr>
	 * </table></li>
	 *
	 * @param openTyp 起動タイプ
	 * @param bind バインド値
	 * @param args その他の引数
	 */
	@Override
	protected void initByScreenParam(String openTyp, MCRow bind, Object... args) {
		if (T1.equals(openTyp)) {
			_data = (DialogR) bind;
		}
	}
	
	@Override
	protected String getPopupPattern(MCPopupBeans compo) {
		return FSUCP_PopupConfig.REMOVE_ALL;
	}
	
	@Override
	protected void setDefaultScreenPosition() {
		setArrangementCenter(getParentPanel());
	}

}