package mcframe.clientFSBA.FSBAP0690;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;

import mcframe.clientFSUB.FSUBP0080.*;
import mcframe.clientFSUB.FSUBP0090.*;

import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import static mcframe.clientFXUC.FXUCP0220.FXUCP_PersonalizeGroupUtil.*;
import static mcframe.commonFSUA.FSUAC0010.FSUAC_List.LocationIDCols;
import static mcframe.commonFSUA.FSUAC0010.FSUAC_List.SearchCndIDCols;
import static mcframe.commonFSUA.FSUAC0010.FSUAC_List.TableColumnOrderIDCols;
import static mcframe.commonFSUA.FSUAC0010.FSUAC_List.TableFilterIDCols;
import static mcframe.commonFSUA.FSUAC0010.FSUAC_List.TableSortIDCols;
import static mcframe.commonFSUA.FSUAC0010.FSUAC_List.TableSignalIDCols;

import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

import javax.swing.SwingUtilities;

import mcframe.clientCore.beans.popup.MCPopupBeans;
import mcframe.clientCore.beans.popup.MCPopupConfig;
import mcframe.clientCore.beans.resource.MCColumnWidthInfo;
import mcframe.clientCore.beans.resource.MCColumnWidthResourceIO;
import mcframe.clientCore.beans.resource.MCPersonalizeResourceIO;
import mcframe.clientCore.beans.resource.MCRowFilterInfo;
import mcframe.clientCore.beans.resource.MCRowFilterResourceIO;
import mcframe.clientCore.beans.resource.MCRowSignalInfo;
import mcframe.clientCore.beans.resource.MCRowSignalResourceIO;
import mcframe.clientCore.beans.resource.MCSortOrderInfo;
import mcframe.clientCore.beans.resource.MCSortOrderResourceIO;
import mcframe.clientCore.resource.MCConst;

import mcframe.clientFSBA.FSBAP0030.ListDtlR;
import mcframe.clientFSBA.FSBAP0830.DialogR;
import mcframe.clientFSBE.FSBEP0320.FSBEP0320_Util2;
import mcframe.clientFSBE.FSBEP0330.MCPersonalizeGrpUtil;
import mcframe.clientFSUC.FSUCP0000.FSUCP_PopupConfig;
import mcframe.clientFXBA.FXBAP0080.FXBAP_CellConfig;
import mcframe.clientFXBA.FXBAP0100.FXBAP_PopupConfig;
import mcframe.clientFXUC.FXUCP0070.FXUCP_SrchCndUtil;
import mcframe.clientFXUC.FXUCP0210.FXUCP_PersonalizeUtil;
import mcframe.clientFXUC.FXUCP0220.FXUCP_PersonalizeGroupUtil;

import mcframe.commonCore.resource.ctrl.MCGroupResource;
import mcframe.commonCore.resource.ctrl.MCResourceLayerType;

import mcframe.commonFX.constant.FXC_RESOURCE_SETTING_UNIT;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP0690"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP0690_FW extends FSBAP0690_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	/**
	 * 設定対象の画面です。
	 */
	protected MCRootPanel _target_panel = null;

	/**
	 * 紐付ＮＯ
	 */
	protected int _pno = 0;

	/**
	 * テーブルパーソナライズのリスト
	 */
	protected MCList<TableDtlR> _tableDtlAllL = createTableDtlL();
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0690_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP0690_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * Panel[GrpDtlBtn]のボタン[rdel]の押下時の処理
	 */
	@Override
	public void doGrpDtlBtn_rdel(MCEventInfo info) {
		deleteRow(GrpDtlTable);
	}

	/**
	 * Panel[GrpDtlBtn]のボタン[rcopy]の押下時の処理
	 */
	@Override
	public void doGrpDtlBtn_rcopy(MCEventInfo info) {
		GrpDtlR r = GrpDtlTable.getSelectedMCRow();
		// 空行はコピーできない
		if (r == null || isGrpDtlEmpty(r)) {
			return;
		}

		// データが変更されている行はコピーできない
		if (!r.isStatusNone() || !_tableDtlAllL.subList(TableDtlR.$pno, r.pno())
				.statusChangedList().isEmpty()) {
			return;
		}

		GrpDtlR n = r.clone();
		GrpDtlTable.insertRow(r.getGUIIndex() + 1, n);

		n.pno(_pno++);
		n.setting_unit_type(Setting_setting_PPanel.getSettingR().setting_unit());
		FXC_RESOURCE_SETTING_UNIT.putName(n, GrpDtlR.$setting_unit_type,
				GrpDtlR.$setting_unit_type_nm);
		n.per_grp_id(null);

		n.setStatus(MCRow.CREATE);

		MCList<TableDtlR> tblL = createTableDtlL();
		tblL.addAll(_tableDtlAllL.subList(TableDtlR.$pno, r.pno()).clone());
		tblL.setNumber(TableDtlR.$pno, n.pno());
		_tableDtlAllL.addAll(tblL);
		getTableDtlL().setAll(tblL);

		sort(TableDtlTable);
		TableDtlTable.adjustWidth();
		if (!getTableDtlL().isEmpty()) {
			TableDtlTable.selectRowNoFocus(0);
		}

		setStatus(EDITABLE);
	}

	/**
	 * Panel[InfoBtn]のボタン[upd]の押下時の処理
	 */
	@Override
	public void doInfoBtn_upd(MCEventInfo info) {
		if (confirm(msgUpdateConfirm()) != MCMessageBox.YES_OPTION) {
			return;
		}
		MCList<GrpDtlR> grpL = getUp0();
		if (grpL.isEmpty()) {
			dialog(msgNoDataChange());
			return;
		}

		MCMessageList msgList = checkReq(grpL);

		MCList<GrpDtlR> check_grpL = createGrpDtlL();
		MCList<GrpDtlR> unitL = getGrpDtlL().subList(GrpDtlR.$setting_unit_type,
				Setting_setting_PPanel.getSettingR().setting_unit());

		unitL.forEach(r -> {
			if (!r.isStatusDelete() && !isGrpDtlEmpty(r)) {
				check_grpL.add(r);
			}
		});

		checkDuplicate(msgList, check_grpL, GrpDtlTable, GrpDtlR.$per_grp_nm);
		if (!msgList.isEmpty()) {
			message(msgList);
			return;
		}

		updateGrp(grpL);
		searchGrp();

		dialog(msgUpdated());
	}

	/**
	 * Panel[InfoBtn]のボタン[upd_ext]の押下時の処理
	 */
	@Override
	public void doInfoBtn_upd_ext(MCEventInfo info) {
	}

	/**
	 * Panel[InfoBtn]のボタン[upd_sys]の押下時の処理
	 */
	@Override
	public void doInfoBtn_upd_sys(MCEventInfo info) {
	}

	/**
	 * Panel[BtnSettings]のボタン[signalSettings]の押下時の処理
	 */
	@Override
	public void doBtnSettings_signalSettings(MCEventInfo info) {
		MCTable<?> table = getSelectedTable();
		if (table == null) {
			return;
		}

		Class<? extends MCRootPanel> c = FSBAP0740_Sub.class;
		FSBAP0740_Sub p1 = (FSBAP0740_Sub) MCBeansUtil.createPanel(this, c, MODELESS);
		p1.setTargetTable(table);
		p1.mainPanel2 = this;
		GrpDtlR r = GrpDtlTable.getSelectedMCRow();
		if (r != null) {
			p1.saveNm = r.per_grp_nm();
		}
		TableDtlR tr = TableDtlTable.getSelectedMCRow();
		if (tr != null) {
			p1.saveID = tr.signal_id();
		}

		showChildPanel(p1, SINGLE, T1, null, table);
	}

	/**
	 * パーソナライズグループを更新します。
	 *
	 * @param grpL
	 *            更新対象のグループ
	 */
	protected void updateGrp(MCList<GrpDtlR> grpL) {
		String moduleID = _target_panel.getModuleID();
		String screenID = _target_panel.getScreenID();

		setGroupID(grpL);
		setSettingUnitType(grpL);

		MCIndexKey idx = _tableDtlAllL.createIndex(TableDtlR.$pno);

		for (GrpDtlR r : grpL) {
			MCResourceLayerType type = getResourceLayerType(r.setting_unit_type());
			if (r.isStatusDelete()) {
				removePersonalize(type, moduleID, screenID, r.per_grp_id());
			}
			else {
				MCList<TableDtlR> tblL = _tableDtlAllL.subList(idx, r.pno());
				savePersonalize(type, moduleID, screenID, r.per_grp_id(), r.per_grp_nm(),
						r.remark(), r.search_settings_id(), r.location_settings_id(),
						tblL);
			}
		}

		saveResource();
//		MCConst.saveUser();
	}

	/**
	 * リソース設定を保存します。
	 */
	@SuppressWarnings("deprecation")
	protected void saveResource() {
		try {
			MCConst.saveResource();
		}
		catch (Exception e) {
			// 保存に失敗した場合はリソースの変更履歴をクリアする
			MCConst.commitResource();
			throw e;
		}
	}

	/**
	 * グループＩＤを設定します。
	 *
	 * @param grpL 更新対象のグループ
	 */
	protected void setGroupID(MCList<GrpDtlR> grpL) {
		int no = getGroupIDNo();
		for (GrpDtlR o : grpL) {
			if (isNull(o.per_grp_id())) {
				o.per_grp_id(MCPersonalizeResourceIO
						.createSettingInfoID(getResourceLayerType(), no++));
			}
		}
	}

	/**
	 * 設定単位ＣＤを設定します。
	 * 
	 * @param grpL 更新対象のグループ
	 */
	protected void setSettingUnitType(MCList<GrpDtlR> grpL) {
		String type = Setting_setting_PPanel.getSettingR().setting_unit();
		grpL.forEach(o -> {
			if (isNull(o.setting_unit_type())) {
				o.setting_unit_type(type);
			}
		});
	}

	/**
	 * グループＩＤの末尾の番号を返します。
	 *
	 * @return 番号
	 */
	protected int getGroupIDNo() {
		int n = -1;
		for (GrpDtlR o : getGrpDtlL()) {
			if (!isNull(o.per_grp_id())) {
				n = Math.max(n, MCPersonalizeResourceIO
						.getSettingInfoNO(getResourceLayerType(), o.per_grp_id()));
			}
		}
		return n;
	}

	/**
	 * GrpDtlTableの更新対象行を返します。
	 *
	 * @return 更新対象行
	 */
	protected MCList<GrpDtlR> getUp0() {
		MCList<GrpDtlR> ret = getGrpDtlL().statusChangedList();
		ret.removeIf(r -> isGrpDtlEmpty(r));
		MCList<TableDtlR> tblL = _tableDtlAllL.statusChangedList()
				.groupBy(TableDtlR.$pno);
		for (TableDtlR r : tblL) {
			if (ret.getFirst(GrpDtlR.$pno, r.pno()) == null) {
				ret.add(getGrpDtlL().getFirst(GrpDtlR.$pno, r.pno()));
			}
		}
		return ret;
	}

	/**
	 * GrpDtlRが空行扱いの場合trueを返します。
	 *
	 * @param r ロウ
	 * @return 空行の場合true
	 */
	protected boolean isGrpDtlEmpty(GrpDtlR r) {
		return r.isEmpty(GrpDtlR.$per_grp_id, GrpDtlR.$per_grp_nm,
				GrpDtlR.$search_settings_id, GrpDtlR.$location_settings_id,
				GrpDtlR.$remark);
	}

	/**
	 * Panel[GrpDtlBtn]のボタン[radd]の押下時の処理
	 */
	@Override
	public void doGrpDtlBtn_radd(MCEventInfo info) {
		GrpDtlR r = insertRow(GrpDtlTable);
		if (r != null) {
			r.pno(_pno++);

			MCList<TableDtlR> tblL = loadPersonalizeTable(getResourceLayerType(),
					_target_panel.getModuleID(), _target_panel.getScreenID(), null);
			tblL.setNumber(TableDtlR.$pno, r.pno());
			_tableDtlAllL.addAll(tblL);
			getTableDtlL().setAll(tblL);
		}
	}

	/**
	 * Panel[BtnSettings]のボタン[searchSettings]の押下時の処理
	 */
	@Override
	public void doBtnSettings_searchSettings(MCEventInfo info) {
		Class<? extends MCRootPanel> c = FSBAP0310_Sub.class;
		FSBAP0310_Sub p1 = (FSBAP0310_Sub) MCBeansUtil.createPanel(this, c, MODELESS);
		p1.setTargetPanel(_target_panel);
		p1.mainPanel2 = this;
		GrpDtlR r = GrpDtlTable.getSelectedMCRow();
		if (r != null) {
			p1.saveID = r.search_settings_id();
			p1.saveNm = r.per_grp_nm();
		}

		showChildPanel(p1, SINGLE);
	}

	/**
	 * Panel[BtnSettings]のボタン[locationSettings]の押下時の処理
	 */
	@Override
	public void doBtnSettings_locationSettings(MCEventInfo info) {
		Class<? extends MCRootPanel> c = FSBEP0320_Sub.class;
		FSBEP0320_Sub p1 = (FSBEP0320_Sub) MCBeansUtil.createPanel(this, c, MODELESS);
		p1.setTargetPanel(_target_panel);
		p1.mainPanel2 = this;
		GrpDtlR r = GrpDtlTable.getSelectedMCRow();
		if (r != null) {
			p1.saveID = r.location_settings_id();
			p1.saveNm = r.per_grp_nm();
		}

		showChildPanel(p1, SINGLE);
	}

	/**
	 * Panel[BtnSettings]のボタン[columnOrderSettings]の押下時の処理
	 */
	@Override
	public void doBtnSettings_columnOrderSettings(MCEventInfo info) {
		MCTable<?> table = getSelectedTable();
		if (table == null) {
			return;
		}

		if (table instanceof MCTable2) {
			Class<? extends MCRootPanel> c = FSBAP0100_Sub.class;
			FSBAP0100_Sub p1 = (FSBAP0100_Sub) MCBeansUtil.createPanel(this, c, MODELESS);
			p1.setTargetTable(table);
			p1.mainPanel2 = this;
			GrpDtlR r = GrpDtlTable.getSelectedMCRow();
			if (r != null) {
				p1.saveNm = r.per_grp_nm();
			}
			TableDtlR tr = TableDtlTable.getSelectedMCRow();
			if (tr != null) {
				p1.saveID = tr.column_order_id();
			}

			showChildPanel(p1, SINGLE);
		}
		else if (table instanceof MCLayoutTable) {
			Class<? extends MCRootPanel> c = FSBAP0110_Sub.class;
			FSBAP0110_Sub p1 = (FSBAP0110_Sub) MCBeansUtil.createPanel(this, c, MODELESS);
			p1.setTargetTable(table);
			p1.mainPanel2 = this;
			GrpDtlR r = GrpDtlTable.getSelectedMCRow();
			if (r != null) {
				p1.saveNm = r.per_grp_nm();
			}
			TableDtlR tr = TableDtlTable.getSelectedMCRow();
			if (tr != null) {
				p1.saveID = tr.column_order_id();
			}

			showChildPanel(p1, SINGLE);
		}
		else if (table instanceof MCTable) {
			Class<? extends MCRootPanel> c = FSBAP0090_Sub.class;
			FSBAP0090_Sub p1 = (FSBAP0090_Sub) MCBeansUtil.createPanel(this, c, MODELESS);
			p1.setTargetTable(table);
			p1.mainPanel2 = this;
			GrpDtlR r = GrpDtlTable.getSelectedMCRow();
			if (r != null) {
				p1.saveNm = r.per_grp_nm();
			}
			TableDtlR tr = TableDtlTable.getSelectedMCRow();
			if (tr != null) {
				p1.saveID = tr.column_order_id();
			}

			showChildPanel(p1, SINGLE);
		}
	}

	/**
	 * Panel[BtnSettings]のボタン[sortSettings]の押下時の処理
	 */
	@Override
	public void doBtnSettings_sortSettings(MCEventInfo info) {
		MCTable<?> table = getSelectedTable();
		if (table == null) {
			return;
		}

		Class<? extends MCRootPanel> c = FSBAP0120_Sub.class;
		FSBAP0120_Sub p1 = (FSBAP0120_Sub) MCBeansUtil.createPanel(this, c, MODELESS);
		p1.setTargetTable(table);
		p1.mainPanel2 = this;
		GrpDtlR r = GrpDtlTable.getSelectedMCRow();
		if (r != null) {
			p1.saveNm = r.per_grp_nm();
		}
		TableDtlR tr = TableDtlTable.getSelectedMCRow();
		if (tr != null) {
			p1.saveID = tr.sort_id();
		}

		showChildPanel(p1, SINGLE);
	}

	/**
	 * Panel[BtnSettings]のボタン[filterSettings]の押下時の処理
	 */
	@Override
	public void doBtnSettings_filterSettings(MCEventInfo info) {

		MCTable<?> table = getSelectedTable();
		if (table == null) {
			return;
		}

		Class<? extends MCRootPanel> c = FSBAP0330_Sub.class;
		FSBAP0330_Sub p1 = (FSBAP0330_Sub) MCBeansUtil.createPanel(this, c, MODELESS);
		p1.setTargetTable(table);
		p1.mainPanel2 = this;
		GrpDtlR r = GrpDtlTable.getSelectedMCRow();
		if (r != null) {
			p1.saveNm = r.per_grp_nm();
		}
		TableDtlR tr = TableDtlTable.getSelectedMCRow();
		if (tr != null) {
			p1.saveID = tr.filter_id();
		}

		showChildPanel(p1, SINGLE, T1, null, table);
	}

	// 行選択されているMCTableを取り出す。
	protected MCTable<?> getSelectedTable() {
		return getTargetTable(TableDtlTable.getSelectedMCRow());
	}

	protected MCTable<?> getTargetTable(TableDtlR r) {
		if (r == null) {
			return null;
		}
		MCTable<?>[] list = getTargetTables();
		for (MCTable<?> t : list) {
			if (t.getName().equals(r.table_id())) {
				return t;
			}
		}
		return null;
	}

	/**
	 * 設定対象の画面に配置されているテーブルを配列にして返します。
	 *
	 * @return 設定対象の画面に配置されているテーブルの配列
	 */
	protected MCTable<?>[] getTargetTables() {
		List<MCTable<?>> l = new ArrayList<>();
		MCTable<?>[] ta = MCBeansUtil.getAllComponents(MCTable.class, getTargetPanel());
		for (MCTable<?> t : ta) {
			if (t instanceof MCFixedColumnTable<?>) {
				continue;
			}
			l.add(t);
		}
		return l.toArray(new MCTable<?>[l.size()]);
	}

	/**
	 * 設定対象の画面を返します。
	 *
	 * @return 設定対象の画面
	 */
	protected MCRootPanel getTargetPanel() {
		if (_target_panel != null) {
			return _target_panel;
		}
		return (_target_panel = getParentPanel());
	}

	@Override
	protected void initByScreenParam(String openTyp, MCRow bind, Object... args) {
		super.initByScreenParam(openTyp, bind, args);

		if (T1.equals(openTyp)) {
			valueInit();
		}
		else {
			throw new MCAppException(msgUnknownOpenParam());
		}
	}

	@Override
	protected void valueInit() {
		super.valueInit();

		searchGrp();
	}

	@Override
	protected void tableInit() {
		super.tableInit();

		GrpDtlTable.setSortable(false);
		TableDtlTable.setSortable(false);
	}

	/**
	 * パーソナライズグループを検索します。
	 */
	protected void searchGrp() {
		String moduleID = _target_panel.getModuleID();
		String screenID = _target_panel.getScreenID();

		MCList<GrpDtlR> grpL = createGrpDtlL();
		loadPersonalizeList(grpL, moduleID, screenID);
		for (GrpDtlR r : grpL) {
			FXC_RESOURCE_SETTING_UNIT.putName(r, GrpDtlR.$setting_unit_type,
					GrpDtlR.$setting_unit_type_nm);

			setSrchCndSettingsName(r, moduleID, screenID);
			setLocationSettingsName(r, moduleID, screenID);
		}
		grpL.setStatus(Status.NONE);

		_tableDtlAllL.clear();
		for (GrpDtlR r : grpL) {
			r.pno(_pno++);
			MCList<TableDtlR> tblL = loadPersonalizeTable(
					getResourceLayerType(r.setting_unit_type()), moduleID, screenID,
					r.per_grp_id());
			tblL.setNumber(TableDtlR.$pno, r.pno());
			_tableDtlAllL.addAll(tblL);
		}
		_tableDtlAllL.setStatus(Status.NONE);

		MCList<GrpDtlR> disp_grpL = createGrpDtlL();

		String u = Setting_setting_PPanel.getSettingR().setting_unit();
		// システム共通のパーソナライズグループはどのラジオボタンが選択されていても表示する
		disp_grpL.addAll(0, grpL.subList(GrpDtlR.$setting_unit_type,
				MCResourceLayerType.SYS.toString()));
		if (!FXC_RESOURCE_SETTING_UNIT.isTYPE_SYS(u)) {
			// 会社共通のパーソナライズグループは「ユーザ」または「会社共通」のラジオボタンが選択されている場合のみ表示する
			disp_grpL.addAll(0, grpL.subList(GrpDtlR.$setting_unit_type,
					MCResourceLayerType.EXT.toString()));
			if (!FXC_RESOURCE_SETTING_UNIT.isTYPE_EXT(u)) {
				// ユーザのパーソナライズグループは「ユーザ」のラジオボタンが選択されている場合のみ表示する
				disp_grpL.addAll(0, grpL.subList(GrpDtlR.$setting_unit_type,
						MCResourceLayerType.USER.toString()));
			}
		}

		getGrpDtlL().setAll(disp_grpL);
		sort(GrpDtlTable);
		GrpDtlTable.adjustWidth();
		GrpDtlTable.fillSpace();
		setPno();
		GrpDtlTable.selectLeftmostColumn(0);
	}

	/**
	 * GrpDtlTableに紐付ＮＯを設定します。
	 */
	protected void setPno() {
		getGrpDtlL().forEach(r -> {
			if (isNull(r.pno())) {
				r.pno(_pno++);
			}
		});
	}

	@Override
	protected String getPopupPattern(MCPopupBeans compo) {
		return FSUCP_PopupConfig.PERSONALIZE_PANEL;
	}

	// Toolbarから呼び出される。
	public static void doPersonalizeGroupSettings(MCRootPanel panel) {
		MCRootPanel p = MCBeansUtil.createPanel(panel.getRootPanel(), MODULE_ID,
				SCREEN_ID, MODELESS);
		FSBAP0690 p1 = (FSBAP0690) p;
		p1._target_panel = panel;
		p1.setupParameter(panel);

		panel.showChildPanel(p, SINGLE);
	}

	protected void setupParameter(MCRootPanel panel) {
		valueInit();
	}

	// 設定されているパーソナライズグループに切り替える。
	public static void doPersonalizeGroup(MCRootPanel panel, String aPerGrp) {
		MCPersonalizeGrpUtil util = new MCPersonalizeGrpUtil();
		util.doApplyPersonalizeGrp(panel, aPerGrp);
	}

	public static void doPersonalizeSaveCurrentSettings(MCRootPanel panel) {
		FSBAP0690 app = FSBAP0690.create();
		app._target_panel = panel;
		app.personalizeSaveCurrentSettings(panel);
	}

	// サブ画面と同期をとるためのセマフォ
	protected Semaphore lockSemaphore;

	protected List<Semaphore> semaphores;

	protected String id;

	protected String nm;

	protected MCList<TableDtlR> tableList;

	protected GrpDtlR gr = GrpDtlR.create();

	protected void _personalizeSaveCurrentSettings(MCRootPanel panel) {
		// グループIDを指定
		// FSBEP0320　配置情報設定
		// FSBAP0310　入力値設定
		// FSBAP0090　カラム順・サイズ変更（MCTable）
		// FSBAP0100　カラム順・サイズ変更（MCTable2）
		// FSBAP0110　カラム順・サイズ変更（MCLayoutTable）
		// FSBAP0120　ソート順変更
		// FSBAP0330　フィルタ情報設定
		// FSBAP0740　シグナル設定

		gr = createGrpDtlR();
		gr.per_grp_id(id);
		gr.per_grp_nm(nm);
		getGrpDtlL().add(gr);
		GrpDtlTable.selectRow(getGrpDtlL().size());

		// 配置情報設定
		if (isIgnoreLocation(panel) == false) {
			Class<? extends MCRootPanel> c2 = FSBEP0320_Sub.class;
			FSBEP0320_Sub p2 = (FSBEP0320_Sub) MCBeansUtil.createPanel(this, c2,
					MODELESS);
			p2.setTargetRootPanel(panel);
			p2.mainPanel2 = this;
			p2.isSaveMode = true;
			p2.saveNm = nm;
			p2.row = gr;
			p2.semaphore = createSemaphone();
			MCBeansUtil.showPanel(p2, MULTI);
		}

		// 入力値設定
		if (isIgnoreSrchCnd(panel) == false) {
			Class<? extends MCRootPanel> c1 = FSBAP0310_Sub.class;
			FSBAP0310_Sub p1 = (FSBAP0310_Sub) MCBeansUtil.createPanel(this, c1,
					MODELESS);
			p1.setTargetPanel(panel);
			p1.mainPanel2 = this;
			p1.isSaveMode = true;
			p1.saveNm = nm;
			p1.row = gr;
			p1.semaphore = createSemaphone();
			MCBeansUtil.showPanel(p1, MULTI);
		}

		for (MCTable<?> table : getTargetTables()) {
			MCPopupConfig config2 = table.getPopupConfig();
			boolean isIgnoreColumnWidth = config2.isIgnoreColumnWidth();
			boolean isIgnoreSortOrder = config2.isIgnoreSortOrder();
			boolean isIgnoreRowFilter = config2.isIgnoreRowFilter();
			boolean isIgnoreRowSignal = config2.isIgnoreRowSignal();

			TableDtlR r1 = createTableDtlR();
			r1.table_id(table.getName());

			r1.column_order_id(null);
			r1.column_order_nm(isIgnoreColumnWidth ? null : nm);

			r1.sort_id(null);
			r1.sort_nm(isIgnoreSortOrder ? null : nm);

			r1.filter_id(null);
			r1.filter_nm(isIgnoreRowFilter ? null : nm);

			r1.signal_id(null);
			r1.signal_nm(isIgnoreRowSignal ? null : nm);

			getTableDtlL().add(r1);
			TableDtlTable.selectRow(getTableDtlL().size());
			tableList.add(r1);

			// カラム順・サイズ変更
			if (isIgnoreColumnWidth == false) {
				// カラム順・サイズ変更（MCTable2）
				if (table instanceof MCTable2) {
					Class<? extends MCRootPanel> c3 = FSBAP0100_Sub.class;
					FSBAP0100_Sub p3 = (FSBAP0100_Sub) MCBeansUtil.createPanel(this, c3,
							MODELESS);
					p3.setTargetTable(table);
					p3.mainPanel2 = this;
					p3.isSaveMode = true;
					p3.saveNm = nm;
					p3.row = r1;
					p3.semaphore = createSemaphone();
					MCBeansUtil.showPanel(p3, MULTI);
				}
				// カラム順・サイズ変更（MCLayoutTable）
				else if (table instanceof MCLayoutTable) {
					Class<? extends MCRootPanel> c3 = FSBAP0110_Sub.class;
					FSBAP0110_Sub p3 = (FSBAP0110_Sub) MCBeansUtil.createPanel(this, c3,
							MODELESS);
					p3.setTargetTable(table);
					p3.mainPanel2 = this;
					p3.isSaveMode = true;
					p3.saveNm = nm;
					p3.row = r1;
					p3.semaphore = createSemaphone();
					MCBeansUtil.showPanel(p3, MULTI);
				}
				// カラム順・サイズ変更（MCTable）
				else if (table instanceof MCTable) {
					Class<? extends MCRootPanel> c3 = FSBAP0090_Sub.class;
					FSBAP0090_Sub p3 = (FSBAP0090_Sub) MCBeansUtil.createPanel(this, c3,
							MODELESS);
					p3.setTargetTable(table);
					p3.mainPanel2 = this;
					p3.isSaveMode = true;
					p3.saveNm = nm;
					p3.row = r1;
					p3.semaphore = createSemaphone();
					MCBeansUtil.showPanel(p3, MULTI);
				}
			}

			// ソート順変更
			if (isIgnoreSortOrder == false) {
				Class<? extends MCRootPanel> c4 = FSBAP0120_Sub.class;
				FSBAP0120_Sub p4 = (FSBAP0120_Sub) MCBeansUtil.createPanel(this, c4,
						MODELESS);
				p4.setTargetTable(table);
				p4.mainPanel2 = this;
				p4.isSaveMode = true;
				p4.saveNm = nm;
				p4.row = r1;
				p4.semaphore = createSemaphone();
				MCBeansUtil.showPanel(p4, MULTI);
			}

			// フィルタ情報設定
			if (isIgnoreRowFilter == false) {
				Class<? extends MCRootPanel> c5 = FSBAP0330_Sub.class;
				FSBAP0330_Sub p5 = (FSBAP0330_Sub) MCBeansUtil.createPanel(this, c5,
						MODELESS, T1, null, table);
				p5.setTargetTable(table);
				p5.mainPanel2 = this;
				p5.isSaveMode = true;
				p5.saveNm = nm;
				p5.row = r1;
				p5.semaphore = createSemaphone();
				MCBeansUtil.showPanel(p5, MULTI);
			}

			// シグナル設定
			if (isIgnoreRowSignal == false) {
				Class<? extends MCRootPanel> c5 = FSBAP0740_Sub.class;
				FSBAP0740_Sub p6 = (FSBAP0740_Sub) MCBeansUtil.createPanel(this, c5,
						MODELESS, T1, null, table);
				p6.setTargetTable(table);
				p6.mainPanel2 = this;
				p6.isSaveMode = true;
				p6.saveNm = nm;
				p6.row = r1;
				p6.semaphore = createSemaphone();
				MCBeansUtil.showPanel(p6, MULTI);
			}
		}
	}

	protected boolean isIgnoreSrchCnd(MCRootPanel panel) {
		MCPopupConfig config1 = panel.getPopupConfig();
		if (config1 instanceof FXBAP_PopupConfig) {
			return ((FXBAP_PopupConfig) config1).isIgnoreSrchCnd(panel);
		}
		return false;
	}

	protected boolean isIgnoreLocation(MCRootPanel panel) {
		return !panel.enablePersonalizeLocation;
	}

	protected class SaveThread1 extends Thread {

		MCRootPanel panel;

		public SaveThread1(MCRootPanel p) {
			super("FSBAP0690 SaveThread1");
			panel = p;
		}

		@Override
		public void run() {
			SwingUtilities.invokeLater(() -> {
				_personalizeSaveCurrentSettings(panel);
				lockSemaphore.release();
			});
		}
	}

	protected class SaveThread2 extends Thread {

		MCRootPanel panel;

		public SaveThread2(MCRootPanel p) {
			super("FSBAP0690 SaveThread2");
			panel = p;
		}

		@Override
		public void run() {
			acquireSemaphore(lockSemaphore);
			__personalizeSaveCurrentSettings(panel);
		}
	}

	protected void personalizeSaveCurrentSettings(MCRootPanel panel) {

//		nm = FXUCP_PersonalizeGroupUtil.createGroupNM(panel);
		nm = "";
		id = FXUCP_PersonalizeGroupUtil.createGroupID(panel);

		DialogR data = DialogR.create();
		openSystemModalPanel("FS", "FSBAP0830", T1, data);
		nm = data.setting_name();
		if (isNull(nm)) {
			return;
		}

		// 同じ名前がある場合は上書きする。
		String grp_id = FXUCP_PersonalizeGroupUtil.getGroupID(panel, nm);
		if (grp_id != null) {
			id = grp_id;
		}

		tableList = MCList.create(TableDtlR.class);
		semaphores = new ArrayList<>();

		lockSemaphore = new Semaphore(0);

		// ２つの非同期スレッドで同期をとる。
		// 子画面の処理が完全に終わる前に保存操作が起きないようにする。
		SaveThread1 thread1 = new SaveThread1(panel);
		thread1.start();

		SaveThread2 thread2 = new SaveThread2(panel);
		thread2.start();
	}

	protected void __personalizeSaveCurrentSettings(MCRootPanel panel) {

		// 子画面の全ての処理が終わるまで待つ。
		semaphores.forEach(sema -> {
			acquireSemaphore(sema);
		});

		SwingUtilities.invokeLater(() -> {
			String moduleID = panel.getModuleID();
			String screenID = panel.getScreenID();
			// 備考は空文字で渡す
			FXUCP_PersonalizeGroupUtil.savePersonalize(MCResourceLayerType.USER, moduleID,
					screenID, id, nm, "", gr.search_settings_id(),
					gr.location_settings_id(), tableList);
			saveResource();
		});
	}

	protected Semaphore createSemaphone() {
		Semaphore semaphore = new Semaphore(0);
		semaphores.add(semaphore);
		return semaphore;
	}

	protected void acquireSemaphore(Semaphore sema) {
		long timeout = 10000; // 10秒で完了できない場合は中止する。
		try {
			sema.tryAcquire(timeout, TimeUnit.MILLISECONDS);
		}
		catch (InterruptedException e) {
			throw new MCException(e);
		}
	}

	/**
	 * 入力値設定の設定情報名を設定します。
	 */
	protected void setSrchCndSettingsName(GrpDtlR r, String moduleID, String screenID) {
		r.search_settings_nm(FXUCP_SrchCndUtil.getSettingInfoUnitName(moduleID, screenID,
				r.search_settings_id()));
	}

	/**
	 * 項目配置変更の設定情報名を設定します。
	 */
	protected void setLocationSettingsName(GrpDtlR r, String moduleID, String screenID) {
		ListDtlR locR = FSBEP0320_Util2.loadPersonalize(moduleID, screenID,
				r.location_settings_id());
		if (locR != null) {
			r.location_settings_nm(FXUCP_PersonalizeUtil.getSettingInfoUnitName(
					locR.setting_info_nm(), locR.setting_unit_type()));
		}
	}

	/**
	 * カラム順・サイズ変更の設定情報名を設定します。
	 */
	protected void setColumnOrderSettingsName(TableDtlR r, String moduleID,
			String screenID) {
		MCColumnWidthInfo info = MCColumnWidthResourceIO.readInfo(moduleID, screenID,
				r.table_id(), r.column_order_id());
		if (info != null) {
			r.column_order_nm(FXUCP_PersonalizeUtil.getSettingInfoUnitName(
					info.getSettingInfoName(), info.getSettingUnitType()));
		}
	}

	/**
	 * ソート順変更の設定情報名を設定します。
	 */
	protected void setSortOrderSettingsName(TableDtlR r, String moduleID, String screenID) {
		MCSortOrderInfo info = MCSortOrderResourceIO.readInfo(moduleID, screenID,
				r.table_id(), r.sort_id());
		if (info != null) {
			r.sort_nm(FXUCP_PersonalizeUtil.getSettingInfoUnitName(
					info.getSettingInfoName(), info.getSettingUnitType()));
		}
	}

	/**
	 * フィルタ情報設定の設定情報名を設定します。
	 */
	protected void setRowFilterSettingsName(TableDtlR r, String moduleID, String screenID) {
		MCRowFilterInfo info = MCRowFilterResourceIO.readInfo(moduleID, screenID,
				r.table_id(), r.filter_id());
		if (info != null) {
			r.filter_nm(FXUCP_PersonalizeUtil.getSettingInfoUnitName(
					info.getSettingInfoName(), info.getSettingUnitType()));
		}
	}

	/**
	 * シグナル設定の設定情報名を設定します。
	 */
	protected void setRowSignalSettingsName(TableDtlR r, String moduleID, String screenID) {
		MCRowSignalInfo info = MCRowSignalResourceIO.readInfo(moduleID, screenID,
				r.table_id(), r.signal_id());
		if (info != null) {
			r.signal_nm(FXUCP_PersonalizeUtil.getSettingInfoUnitName(
					info.getSettingInfoName(), info.getSettingUnitType()));
		}
	}

	/**
	 * テーブル設定をパーソナライズから読込みする。
	 *
	 * @param moduleID
	 * @param screenID
	 * @param aPerGrpID
	 * @return
	 */
	protected MCList<TableDtlR> loadPersonalizeTable(MCResourceLayerType type,
			String moduleID, String screenID, String aPerGrpID) {

		MCList<TableDtlR> resL = createTableDtlL();
		FXUCP_PersonalizeGroupUtil.loadPersonalizeTable(type, resL, moduleID, screenID,
				aPerGrpID);

		MCList<TableDtlR> list = MCList.create(TableDtlR.class);
		MCTable<?>[] tables = getTargetTables();
		String[] tblNm = MCBeansUtil.getTableName(tables);
		for (int i = 0; i < tables.length; i++) {
			String id = tables[i].getName();
			TableDtlR r = resL.getFirst(TableDtlR.$table_id, id);
			if (r != null) {
				r.table_nm(tblNm[i]);
				setColumnOrderSettingsName(r, moduleID, screenID);
				setSortOrderSettingsName(r, moduleID, screenID);
				setRowFilterSettingsName(r, moduleID, screenID);
				setRowSignalSettingsName(r, moduleID, screenID);
			}
			else {
				r = TableDtlR.create();
				r.table_nm(tblNm[i]);
				r.table_id(id);
			}
			list.add(r);
		}

		return list;
	}

	/**
	 * [GrpDtl]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info
	 *            イベント情報
	 */
	@Override
	public void doGrpDtl_NC(MCEventInfo info) {
		super.doGrpDtl_NC(info);

		grpListChanged();
	}

	// 一覧が変更されたとき
	protected void grpListChanged() {
		GrpDtlR r = GrpDtlTable.getSelectedMCRow();
		if (r != null) {
			getTableHdrR().pno(r.pno());
			getTableHdrR().per_grp_id(r.per_grp_id());
			getTableHdrR().per_grp_nm(r.per_grp_nm());
			getTableHdrR().search_settings_id(r.search_settings_id());
			getTableHdrR().search_settings_nm(r.search_settings_nm());
			getTableHdrR().location_settings_id(r.location_settings_id());
			getTableHdrR().location_settings_nm(r.location_settings_nm());

			MCList<TableDtlR> list = _tableDtlAllL.subList(TableDtlR.$pno, r.pno());
			if (list.isEmpty()) {
				list = loadPersonalizeTable(getResourceLayerType(r.setting_unit_type()),
						_target_panel.getModuleID(), _target_panel.getScreenID(), null);
				list.setStatus(Status.GUICREATE);
				list.setNumber(TableDtlR.$pno, r.pno());
				_tableDtlAllL.addAll(list);
			}
			getTableDtlL().setAll(list);
			sort(TableDtlTable);
			TableDtlTable.adjustWidth();

			if (!getTableDtlL().isEmpty()) {
				TableDtlTable.selectRowNoFocus(0);
			}

			getInfoHdrR().per_grp_nm(r.per_grp_nm());
			getInfoHdrR().remark(r.remark());

			setStatus(EDITABLE);
		}
		else {
			getTableHdrR().clear();
			getTableDtlL().clear();
			getInfoHdrR().clear();

			setStatus(INIT);
		}
	}

	// 入力値設定ID
	protected void setSearchID(MCRootPanel p, String setting_unit_type, String info_id,
			String info_nm) {
		GrpDtlR r = GrpDtlTable.getSelectedMCRow();
		if (r != null) {
			String nm = MCPersonalizeGrpUtil.getDispSettingName(setting_unit_type,
					info_nm);
			setValueEx(TableHdr_search_settings_id, info_id);
			setValueEx(TableHdr_search_settings_nm, nm);
		}
		GrpDtlTable.adjustWidth();
	}

	// 項目配置設定ID
	protected void setLocationID(MCRootPanel p, String setting_unit_type, String info_id,
			String info_nm) {
		GrpDtlR r = GrpDtlTable.getSelectedMCRow();
		if (r != null) {
			String nm = MCPersonalizeGrpUtil.getDispSettingName(setting_unit_type,
					info_nm);
			setValueEx(TableHdr_location_settings_id, info_id);
			setValueEx(TableHdr_location_settings_nm, nm);
		}
		GrpDtlTable.adjustWidth();
	}

	// カラム順設定ID
	protected void setColumnOrderID(MCRootPanel p, String setting_unit_type,
			String info_id, String info_nm) {
		TableDtlR r = TableDtlTable.getSelectedMCRow();
		if (r != null) {
			String nm = MCPersonalizeGrpUtil.getDispSettingName(setting_unit_type,
					info_nm);
			setValueEx(columnTableDtl_column_order_id, r.getGUIIndex(), info_id);
			setValueEx(columnTableDtl_column_order_nm, r.getGUIIndex(), nm);
		}
		TableDtlTable.adjustWidth();
	}

	// ソート順設定ID
	protected void setSortID(MCRootPanel p, String setting_unit_type, String info_id,
			String info_nm) {
		TableDtlR r = TableDtlTable.getSelectedMCRow();
		if (r != null) {
			String nm = MCPersonalizeGrpUtil.getDispSettingName(setting_unit_type,
					info_nm);
			setValueEx(columnTableDtl_sort_id, r.getGUIIndex(), info_id);
			setValueEx(columnTableDtl_sort_nm, r.getGUIIndex(), nm);
		}
		TableDtlTable.adjustWidth();
	}

	// フィルタ設定ID
	protected void setFilterID(MCRootPanel p, String setting_unit_type, String info_id,
			String info_nm) {
		TableDtlR r = TableDtlTable.getSelectedMCRow();
		if (r != null) {
			String nm = MCPersonalizeGrpUtil.getDispSettingName(setting_unit_type,
					info_nm);
			setValueEx(columnTableDtl_filter_id, r.getGUIIndex(), info_id);
			setValueEx(columnTableDtl_filter_nm, r.getGUIIndex(), nm);
		}
		TableDtlTable.adjustWidth();
	}

	// シグナル設定ID
	protected void setSignalID(MCRootPanel p, String setting_unit_type, String info_id,
			String info_nm) {
		TableDtlR r = TableDtlTable.getSelectedMCRow();
		if (r != null) {
			String nm = MCPersonalizeGrpUtil.getDispSettingName(setting_unit_type,
					info_nm);
			setValueEx(columnTableDtl_signal_id, r.getGUIIndex(), info_id);
			setValueEx(columnTableDtl_signal_nm, r.getGUIIndex(), nm);
		}
		TableDtlTable.adjustWidth();
	}

	// 画面を中央に表示
	@Override
	protected void setDefaultScreenPosition() {
		super.setDefaultScreenPosition();

		setArrangementCenter();
	}

	@Override
	public MCList getTableHdr_search_settings_nm(MCRow row, MCEventInfo info) {
		row.setStringNE(SearchCndIDCols.$i_moduleID, _target_panel.getModuleID());
		row.setStringNE(SearchCndIDCols.$i_screenID, _target_panel.getScreenID());
		row.setStringNE(SearchCndIDCols.$i_settingUnitType,
				Setting_setting_PPanel.getSettingR().setting_unit());
		return super.getTableHdr_search_settings_nm(row, info);
	}

	@Override
	public MCList getTableHdr_location_settings_nm(MCRow row, MCEventInfo info) {
		row.setStringNE(LocationIDCols.$i_moduleID, _target_panel.getModuleID());
		row.setStringNE(LocationIDCols.$i_screenID, _target_panel.getScreenID());
		row.setStringNE(SearchCndIDCols.$i_settingUnitType,
				Setting_setting_PPanel.getSettingR().setting_unit());
		return super.getTableHdr_location_settings_nm(row, info);
	}

	@Override
	public MCList getTableDtl_column_order_nm(MCRow row, MCEventInfo info) {
		row.setStringNE(TableColumnOrderIDCols.$i_moduleID, _target_panel.getModuleID());
		row.setStringNE(TableColumnOrderIDCols.$i_screenID, _target_panel.getScreenID());
		row.setStringNE(TableColumnOrderIDCols.$i_tableID,
				getTableDtlL().get(info.getEventIndex()).table_id());
		row.setStringNE(SearchCndIDCols.$i_settingUnitType,
				Setting_setting_PPanel.getSettingR().setting_unit());
		return super.getTableDtl_column_order_nm(row, info);
	}

	@Override
	public MCList getTableDtl_sort_nm(MCRow row, MCEventInfo info) {
		row.setStringNE(TableSortIDCols.$i_moduleID, _target_panel.getModuleID());
		row.setStringNE(TableSortIDCols.$i_screenID, _target_panel.getScreenID());
		row.setStringNE(TableSortIDCols.$i_tableID,
				getTableDtlL().get(info.getEventIndex()).table_id());
		row.setStringNE(SearchCndIDCols.$i_settingUnitType,
				Setting_setting_PPanel.getSettingR().setting_unit());
		return super.getTableDtl_sort_nm(row, info);
	}

	@Override
	public MCList getTableDtl_filter_nm(MCRow row, MCEventInfo info) {
		row.setStringNE(TableFilterIDCols.$i_moduleID, _target_panel.getModuleID());
		row.setStringNE(TableFilterIDCols.$i_screenID, _target_panel.getScreenID());
		row.setStringNE(TableFilterIDCols.$i_tableID,
				getTableDtlL().get(info.getEventIndex()).table_id());
		row.setStringNE(SearchCndIDCols.$i_settingUnitType,
				Setting_setting_PPanel.getSettingR().setting_unit());
		return super.getTableDtl_filter_nm(row, info);
	}

	@Override
	public MCList getTableDtl_signal_nm(MCRow row, MCEventInfo info) {
		row.setStringNE(TableSignalIDCols.$i_moduleID, _target_panel.getModuleID());
		row.setStringNE(TableSignalIDCols.$i_screenID, _target_panel.getScreenID());
		row.setStringNE(TableSignalIDCols.$i_tableID,
				getTableDtlL().get(info.getEventIndex()).table_id());
		row.setStringNE(SearchCndIDCols.$i_settingUnitType,
				Setting_setting_PPanel.getSettingR().setting_unit());
		return super.getTableDtl_signal_nm(row, info);
	}

	@Override
	public void doTableDtl_NC(MCEventInfo info) {
		setEnablement();
	}

	@Override
	public void doInfoHdr_remark_LC(MCEventInfo info) {
		super.doInfoHdr_remark_LC(info);

		GrpDtlR s = GrpDtlTable.getSelectedMCRow();
		if (s != null) {
			setValueEx(columnGrpDtl_remark, s.getGUIIndex(), getInfoHdrR().remark());
		}

	}

	@Override
	public void doInfoHdr_per_grp_nm_LC(MCEventInfo info) {
		super.doInfoHdr_per_grp_nm_LC(info);

		GrpDtlR s = GrpDtlTable.getSelectedMCRow();
		if (s != null) {
			setValueEx(columnGrpDtl_per_grp_nm, s.getGUIIndex(),
					getInfoHdrR().per_grp_nm());

			if (isNull(s.setting_unit_type())) {
				s.setting_unit_type(Setting_setting_PPanel.getSettingR().setting_unit());
				FXC_RESOURCE_SETTING_UNIT.putNameNE(s, ListDtlR.$setting_unit_type,
						ListDtlR.$setting_unit_type_nm);
			}
		}
	}

	@Override
	public void doTableHdr_search_settings_nm_LC(MCEventInfo info) {
		super.doTableHdr_search_settings_nm_LC(info);

		GrpDtlR s = GrpDtlTable.getSelectedMCRow();
		if (s != null) {
			setValueEx(columnGrpDtl_search_settings_id, s.getGUIIndex(),
					getTableHdrR().search_settings_id());
			setValueEx(columnGrpDtl_search_settings_nm, s.getGUIIndex(),
					getTableHdrR().search_settings_nm());
		}
	}

	@Override
	public void doTableHdr_location_settings_nm_LC(MCEventInfo info) {
		super.doTableHdr_location_settings_nm_LC(info);

		GrpDtlR s = GrpDtlTable.getSelectedMCRow();
		if (s != null) {
			setValueEx(columnGrpDtl_location_settings_id, s.getGUIIndex(),
					getTableHdrR().location_settings_id());
			setValueEx(columnGrpDtl_location_settings_nm, s.getGUIIndex(),
					getTableHdrR().location_settings_nm());
		}
	}

	@Override
	protected void listenerInit() {
		super.listenerInit();

		Setting_setting_PPanel.Setting_setting_unit_Group.addVCListener(this);
		Setting_setting_PPanel.Setting_setting_unit_Group.addNCListener(this);
	}

	@Override
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}

		if (vc == Setting_setting_PPanel.Setting_setting_unit_Group) {
			return doSetting_setting_unit_VC(info);
		}
		return true;
	}

	protected boolean doSetting_setting_unit_VC(MCEventInfo info) {
		if (isChanged()) {
			if (confirm(FSBAC0059) != MCMessageBox.YES_OPTION) {
				return false;
			}
		}

		return true;
	}

	@Override
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);

		if (nc == Setting_setting_PPanel.Setting_setting_unit_Group) {
			doSetting_setting_unit_NC(info);
		}
	}

	protected void doSetting_setting_unit_NC(MCEventInfo info) {
		valueInit();
		fillSpaceForOpen();
		setOpenFocus();
	}

	@Override
	public void setStatus(String status) {
		if (EDITABLE.equals(status)) {
			GrpDtlR r = GrpDtlTable.getSelectedMCRow();
			if (r != null) {
				String u = Setting_setting_PPanel.getSettingR().setting_unit();
				String type = r.setting_unit_type();
				if (!isNull(type) && !isSame(u, type)) {
					status = DISABLE;
				}
			}
		}

		super.setStatus(status);

		if (!isSettingUnitExtEnable()) {
			Setting_setting_PPanel.Setting_setting_unit_EXT.setMode(MCMode.READ_ONLY);
		}
		if (!isSettingUnitSysEnable()) {
			Setting_setting_PPanel.Setting_setting_unit_SYS.setMode(MCMode.READ_ONLY);
		}

		setEnablement();
	}

	protected boolean isSettingUnitExtEnable() {
		return InfoBtn_upd_ext.authorize()
				&& isSearchedProgram(FXC_RESOURCE_SETTING_UNIT.TYPE_EXT.value(),
						MCGroupResource.PGM_ID_SYSTEM);
	}	
	
	protected boolean isSettingUnitSysEnable() {
		return InfoBtn_upd_sys.authorize()
				&& isSearchedProgram(FXC_RESOURCE_SETTING_UNIT.TYPE_SYS.value(),
						MCGroupResource.PGM_ID_SYSTEM);
	}
	
	protected boolean isSearchedProgram(String type, String pgmid) {
		return MCConst.app.isSearchedProgram(getResourceLayerType(type), pgmid);
	}

	// ボタンを使用不可にする。
	protected void setEnablement() {
		// 行コピー
		GrpDtlR r = GrpDtlTable.getSelectedMCRow();
		if (r == null || isNull(r.per_grp_id())) {
			GrpDtlBtn_rcopy.setMode(MCMode.DISABLE);
		}
		else {
			setDefaultMode(GrpDtlBtn_rcopy);
		}

		// 入力値設定
		if (isIgnoreSrchCnd(_target_panel)) {
			TableHdr_search_settings_nm.setMode(MCMode.READ_ONLY);
			BtnSettings_searchSettings.setMode(MCMode.DISABLE);
		}
		else {
			setDefaultMode(TableHdr_search_settings_nm);
			setDefaultMode(BtnSettings_searchSettings);
		}

		// 配置情報設定
		if (isIgnoreLocation(_target_panel)) {
			TableHdr_location_settings_nm.setMode(MCMode.READ_ONLY);
			BtnSettings_locationSettings.setMode(MCMode.DISABLE);
		}
		else {
			setDefaultMode(TableHdr_location_settings_nm);
			setDefaultMode(BtnSettings_locationSettings);
		}

		MCTable<?> target = getTargetTable(TableDtlTable.getSelectedMCRow());
		if (target != null) {
			MCPopupConfig popup = target.getPopupConfig();
			if (popup.isIgnoreColumnWidth()) {
				BtnSettings_columnOrderSettings.setMode(MCMode.DISABLE);
			}
			else {
				setDefaultMode(BtnSettings_columnOrderSettings);
			}
			if (popup.isIgnoreSortOrder()) {
				BtnSettings_sortSettings.setMode(MCMode.DISABLE);
			}
			else {
				setDefaultMode(BtnSettings_sortSettings);
			}
			if (popup.isIgnoreRowFilter()) {
				BtnSettings_filterSettings.setMode(MCMode.DISABLE);
			}
			else {
				setDefaultMode(BtnSettings_filterSettings);
			}
			if (popup.isIgnoreRowSignal()) {
				BtnSettings_signalSettings.setMode(MCMode.DISABLE);
			}
			else {
				setDefaultMode(BtnSettings_signalSettings);
			}
		}
		else {
			BtnSettings_columnOrderSettings.setMode(MCMode.DISABLE);
			BtnSettings_sortSettings.setMode(MCMode.DISABLE);
			BtnSettings_filterSettings.setMode(MCMode.DISABLE);
			BtnSettings_signalSettings.setMode(MCMode.DISABLE);
		}
	}

	protected MCResourceLayerType getResourceLayerType() {
		return getResourceLayerType(Setting_setting_PPanel.getSettingR().setting_unit());
	}

	protected MCResourceLayerType getResourceLayerType(String type) {
		return MCPersonalizeResourceIO.toResourceLayerType(type);
	}

	@Override
	public void setCellConfig() {
		super.setCellConfig();

		TableDtlTable.setCellConfig(createTableDtlCellConfig());
	}

	protected MCCellConfig createTableDtlCellConfig() {
		return new TableDtlCellConfig();
	}

	protected class TableDtlCellConfig extends FXBAP_CellConfig {

		@Override
		public MCMode getPriorMode(int index, MCColumnConfig column, MCTable table) {
			if (!isDefaultModeEditable(column)) {
				return super.getPriorMode(index, column, table);
			}

			if (column == columnTableDtl_column_order_nm) {
				MCTable<?> target = getTargetTable(TableDtlTable.getSelectedMCRow());
				if (target != null) {
					if (target.getPopupConfig().isIgnoreColumnWidth()) {
						return MCMode.READ_ONLY;
					}
				}
			}
			else if (column == columnTableDtl_sort_nm) {
				MCTable<?> target = getTargetTable(TableDtlTable.getSelectedMCRow());
				if (target != null) {
					if (target.getPopupConfig().isIgnoreSortOrder()) {
						return MCMode.READ_ONLY;
					}
				}
			}
			else if (column == columnTableDtl_filter_nm) {
				MCTable<?> target = getTargetTable(TableDtlTable.getSelectedMCRow());
				if (target != null) {
					if (target.getPopupConfig().isIgnoreRowFilter()) {
						return MCMode.READ_ONLY;
					}
				}
			}
			else if (column == columnTableDtl_signal_nm) {
				MCTable<?> target = getTargetTable(TableDtlTable.getSelectedMCRow());
				if (target != null) {
					if (target.getPopupConfig().isIgnoreRowSignal()) {
						return MCMode.READ_ONLY;
					}
				}
			}

			return super.getPriorMode(index, column, table);
		}

	}

}