package mcframe.clientFSBA.FSBAP0690;

import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.isNull;

import java.util.concurrent.Semaphore;

import mcframe.clientCore.beans.table.MCTable;
import mcframe.clientFSBA.FSBAP0030.ListDtlR;
import mcframe.clientFSBA.FSBAP0090.FSBAP_ColOdr;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.resource.ctrl.MCResourceLayerType;

@SuppressWarnings("serial")
public class FSBAP0090_Sub extends FSBAP_ColOdr {

	protected boolean isSaveMode = false;

	protected String saveID = null;

	protected String saveNm = "Current";

	protected Semaphore semaphore = null;

	protected FSBAP0690_FW mainPanel2 = null;

	protected TableDtlR row;
	
	@SuppressWarnings("deprecation")
	@Override
	public boolean beforeOpen() {
		if (mainPanel2.getResourceLayerType() == MCResourceLayerType.EXT) {
			setValueEx(Setting_setting_PPanel.Setting_setting_unit_Group,
					Setting_setting_PPanel.Setting_setting_unit_EXT.getActionCommand());
		}
		else if (mainPanel2.getResourceLayerType() == MCResourceLayerType.SYS) {
			setValueEx(Setting_setting_PPanel.Setting_setting_unit_Group,
					Setting_setting_PPanel.Setting_setting_unit_SYS.getActionCommand());
		}
		return super.beforeOpen();
	}

	@SuppressWarnings("deprecation")
	@Override
	public void afterOpen() {
		super.afterOpen();

		ListDtlR r = null;
		if (!isNull(saveID)) {
			r = getListDtlL().getFirst(ListDtlR.$setting_info_id, saveID);
		}
		if (r == null && !isNull(saveNm)) {
			r = getListDtlL().getFirst(ListDtlR.$setting_info_nm, saveNm);
		}
		if (r == null) {
			for (ListDtlR r2 : getListDtlL()) {
				if (r2.isEmpty()) {
					r = r2;
					break;
				}
			}
			if (r == null) {
				r = ListDtlR.create();
				getListDtlL().add(r);
			}
			ListDtlTable.selectLeftmostColumn(r.getGUIIndex());
			setValueEx(ListHdr_setting_info_nm, saveNm);
			r.setStatus(Status.CREATE);
		}
		else {
			ListDtlTable.selectLeftmostColumn(r.getGUIIndex());
		}

		if (isSaveMode == true) {
			doUpdAction();
		}
	}

	/**
	 * カラム情報設定対象のテーブルを設定します。
	 *
	 * @param table
	 *            カラム情報設定対象のテーブル
	 */
	public void setTargetTable(MCTable<?> table) {
		_target_table = table;
	}

	/**
	 * 登録ボタンの処理を実行します。
	 */
	protected void doUpdAction() {
		if (isSaveMode == false) {
			if (!execUpdComfirm() || !checkForUpd()) {
				return;
			}
		}

		beforeUpd();
		doUpd();
		afterUpd();

		saveID = getListHdrR().setting_info_id();
		saveNm = getListHdrR().setting_info_nm();

		if (mainPanel2 != null) {
			mainPanel2.setColumnOrderID(this, getListHdrR().setting_unit_type(),
					getListHdrR().setting_info_id(), getListHdrR().setting_info_nm());
		}
		else {
			showUpdEndMsg();
		}
		if (row != null) {
			row.column_order_id(getListHdrR().setting_info_id());
			row.column_order_nm(getListHdrR().setting_info_nm());
		}

		if (semaphore != null) {
			semaphore.release();
		}

		// 登録後に閉じる。
		requestCloseWindow();
	}

	/**
	 * 登録後適用ボタンの処理を実行します。
	 */
	protected void doUpdApplyAction() {
		if (!execUpdComfirm() || !checkForUpd()) {
			return;
		}

		beforeUpd();
		doUpd();
		afterUpd();

		saveID = getListHdrR().setting_info_id();
		saveNm = getListHdrR().setting_info_nm();

		if (mainPanel2 != null) {
			mainPanel2.setColumnOrderID(this, getListHdrR().setting_unit_type(),
					getListHdrR().setting_info_id(), getListHdrR().setting_info_nm());
		}
		else {
			showUpdEndMsg();
		}
		if (row != null) {
			row.column_order_id(getListHdrR().setting_info_id());
			row.column_order_nm(getListHdrR().setting_info_nm());
		}
	}
	
	@Override
	protected boolean isSettingUnitUserEnable() {
		if (mainPanel2.getResourceLayerType() == MCResourceLayerType.EXT
				|| mainPanel2.getResourceLayerType() == MCResourceLayerType.SYS) {
			return false;
		}
		return super.isSettingUnitUserEnable();
	}

	@Override
	protected boolean isSettingUnitExtEnable() {
		if (mainPanel2.getResourceLayerType() == MCResourceLayerType.SYS) {
			return false;
		}
		return super.isSettingUnitExtEnable();
	}
}
