package mcframe.clientFSBA.FSBAP0690;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"TableHdr"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class TableHdrR_FW_A extends MCConstRow {

	/**
	 *  紐付ＮＯ.<p>
	 *
	 */
	public static final String $pno = "pno";
	/**
	 *  グループＩＤ.<p>
	 *
	 */
	public static final String $per_grp_id = "per_grp_id";
	/**
	 *  グループ名.<p>
	 *
	 */
	public static final String $per_grp_nm = "per_grp_nm";
	/**
	 *  入力値設定ＩＤ.<p>
	 *
	 */
	public static final String $search_settings_id = "search_settings_id";
	/**
	 *  入力値設定名.<p>
	 *
	 */
	public static final String $search_settings_nm = "search_settings_nm";
	/**
	 *  配置情報設定ＩＤ.<p>
	 *
	 */
	public static final String $location_settings_id = "location_settings_id";
	/**
	 *  配置情報設定名.<p>
	 *
	 */
	public static final String $location_settings_nm = "location_settings_nm";


	public static final MCMeta pno_META = createNumberMeta($pno);
	public static final MCMeta per_grp_id_META = createStringMeta($per_grp_id);
	public static final MCMeta per_grp_nm_META = createStringMeta($per_grp_nm);
	public static final MCMeta search_settings_id_META = createStringMeta($search_settings_id);
	public static final MCMeta search_settings_nm_META = createStringMeta($search_settings_nm);
	public static final MCMeta location_settings_id_META = createStringMeta($location_settings_id);
	public static final MCMeta location_settings_nm_META = createStringMeta($location_settings_nm);

	protected static final ConstMetaList<TableHdrR> constMetas = new ConstMetaList<TableHdrR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			pno_META,
			per_grp_id_META,
			per_grp_nm_META,
			search_settings_id_META,
			search_settings_nm_META,
			location_settings_id_META,
			location_settings_nm_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected TableHdrR_FW_A(ConstMetaList<? extends TableHdrR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public TableHdrR clone() {
		return (TableHdrR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public TableHdrR createInstance() {
		return (TableHdrR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public TableHdrR getValues(String... names) {
		return (TableHdrR) super.getValues(names);
	}



	/**
	 *  紐付ＮＯ.<p>
	 *
	 */
	public MCNumber pno() {
		return getConstNumber(offset + 0, $pno);
	}

	/**
	 *  紐付ＮＯ.<p>
	 *
	 */
	public void pno(MCNumber value) {
		setConstNumber(offset + 0, $pno, value);
	}

	/**
	 *  紐付ＮＯ.<p>
	 *
	 */
	public void pno(int value) {
		setConstNumber(offset + 0, $pno, value);
	}

	/**
	 *  紐付ＮＯ.<p>
	 *
	 */
	public void pno(long value) {
		setConstNumber(offset + 0, $pno, value);
	}

	/**
	 *  紐付ＮＯ.<p>
	 *
	 */
	public void pno(float value) {
		setConstNumber(offset + 0, $pno, value);
	}

	/**
	 *  紐付ＮＯ.<p>
	 *
	 */
	public void pno(double value) {
		setConstNumber(offset + 0, $pno, value);
	}


	/**
	 *  グループＩＤ.<p>
	 *
	 */
	public String per_grp_id() {
		return getConstString(offset + 1, $per_grp_id);
	}

	/**
	 *  グループＩＤ.<p>
	 *
	 */
	public void per_grp_id(String value) {
		setConstString(offset + 1, $per_grp_id, value);
	}


	/**
	 *  グループ名.<p>
	 *
	 */
	public String per_grp_nm() {
		return getConstString(offset + 2, $per_grp_nm);
	}

	/**
	 *  グループ名.<p>
	 *
	 */
	public void per_grp_nm(String value) {
		setConstString(offset + 2, $per_grp_nm, value);
	}


	/**
	 *  入力値設定ＩＤ.<p>
	 *
	 */
	public String search_settings_id() {
		return getConstString(offset + 3, $search_settings_id);
	}

	/**
	 *  入力値設定ＩＤ.<p>
	 *
	 */
	public void search_settings_id(String value) {
		setConstString(offset + 3, $search_settings_id, value);
	}


	/**
	 *  入力値設定名.<p>
	 *
	 */
	public String search_settings_nm() {
		return getConstString(offset + 4, $search_settings_nm);
	}

	/**
	 *  入力値設定名.<p>
	 *
	 */
	public void search_settings_nm(String value) {
		setConstString(offset + 4, $search_settings_nm, value);
	}


	/**
	 *  配置情報設定ＩＤ.<p>
	 *
	 */
	public String location_settings_id() {
		return getConstString(offset + 5, $location_settings_id);
	}

	/**
	 *  配置情報設定ＩＤ.<p>
	 *
	 */
	public void location_settings_id(String value) {
		setConstString(offset + 5, $location_settings_id, value);
	}


	/**
	 *  配置情報設定名.<p>
	 *
	 */
	public String location_settings_nm() {
		return getConstString(offset + 6, $location_settings_nm);
	}

	/**
	 *  配置情報設定名.<p>
	 *
	 */
	public void location_settings_nm(String value) {
		setConstString(offset + 6, $location_settings_nm, value);
	}


	public String getString(String name) {
		if ($per_grp_id.equalsIgnoreCase(name)) {
			return per_grp_id();
		}
		if ($per_grp_nm.equalsIgnoreCase(name)) {
			return per_grp_nm();
		}
		if ($search_settings_id.equalsIgnoreCase(name)) {
			return search_settings_id();
		}
		if ($search_settings_nm.equalsIgnoreCase(name)) {
			return search_settings_nm();
		}
		if ($location_settings_id.equalsIgnoreCase(name)) {
			return location_settings_id();
		}
		if ($location_settings_nm.equalsIgnoreCase(name)) {
			return location_settings_nm();
		}
		return super.getString(name);
	}
	public MCNumber getNumber(String name) {
		if ($pno.equalsIgnoreCase(name)) {
			return pno();
		}
		return super.getNumber(name);
	}

	public String getStringNE(String name) {
		if ($per_grp_id.equalsIgnoreCase(name)) {
			return per_grp_id();
		}
		if ($per_grp_nm.equalsIgnoreCase(name)) {
			return per_grp_nm();
		}
		if ($search_settings_id.equalsIgnoreCase(name)) {
			return search_settings_id();
		}
		if ($search_settings_nm.equalsIgnoreCase(name)) {
			return search_settings_nm();
		}
		if ($location_settings_id.equalsIgnoreCase(name)) {
			return location_settings_id();
		}
		if ($location_settings_nm.equalsIgnoreCase(name)) {
			return location_settings_nm();
		}
		return super.getStringNE(name);
	}
	public MCNumber getNumberNE(String name) {
		if ($pno.equalsIgnoreCase(name)) {
			return pno();
		}
		return super.getNumberNE(name);
	}

	public void setString(String name, String value) {
		if ($per_grp_id.equalsIgnoreCase(name)) {
			per_grp_id(value);
			return;
		}
		if ($per_grp_nm.equalsIgnoreCase(name)) {
			per_grp_nm(value);
			return;
		}
		if ($search_settings_id.equalsIgnoreCase(name)) {
			search_settings_id(value);
			return;
		}
		if ($search_settings_nm.equalsIgnoreCase(name)) {
			search_settings_nm(value);
			return;
		}
		if ($location_settings_id.equalsIgnoreCase(name)) {
			location_settings_id(value);
			return;
		}
		if ($location_settings_nm.equalsIgnoreCase(name)) {
			location_settings_nm(value);
			return;
		}
		super.setString(name, value);
	}
	public void setNumber(String name, MCNumber value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, int value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, long value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, float value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, double value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumber(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($per_grp_id.equalsIgnoreCase(name)) {
			per_grp_id(value);
			return;
		}
		if ($per_grp_nm.equalsIgnoreCase(name)) {
			per_grp_nm(value);
			return;
		}
		if ($search_settings_id.equalsIgnoreCase(name)) {
			search_settings_id(value);
			return;
		}
		if ($search_settings_nm.equalsIgnoreCase(name)) {
			search_settings_nm(value);
			return;
		}
		if ($location_settings_id.equalsIgnoreCase(name)) {
			location_settings_id(value);
			return;
		}
		if ($location_settings_nm.equalsIgnoreCase(name)) {
			location_settings_nm(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setNumberNE(String name, MCNumber value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, int value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, long value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, float value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, double value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumberNE(name, value);
	}



}

