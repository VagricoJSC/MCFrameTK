package mcframe.clientFSBA.FSBAP0690;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"TableDtl"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class TableDtlR_FW_A extends mcframe.clientFXUC.FXUCP0220.TableInfoR {

	/**
	 *  紐付ＮＯ.<p>
	 *
	 */
	public static final String $pno = "pno";


	public static final MCMeta pno_META = createNumberMeta($pno);

	protected static final ConstMetaList<TableDtlR> constMetas = new ConstMetaList<TableDtlR>(
		mcframe.clientFXUC.FXUCP0220.TableInfoR.constMetas,
		new MCMeta[]{
			pno_META,
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		mcframe.clientFXUC.FXUCP0220.TableInfoR.KEYS,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		mcframe.clientFXUC.FXUCP0220.TableInfoR.EXTMAP
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected TableDtlR_FW_A(ConstMetaList<? extends TableDtlR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public TableDtlR clone() {
		return (TableDtlR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public TableDtlR createInstance() {
		return (TableDtlR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public TableDtlR getValues(String... names) {
		return (TableDtlR) super.getValues(names);
	}



	/**
	 *  紐付ＮＯ.<p>
	 *
	 */
	public MCNumber pno() {
		return getConstNumber(offset + 0, $pno);
	}

	/**
	 *  紐付ＮＯ.<p>
	 *
	 */
	public void pno(MCNumber value) {
		setConstNumber(offset + 0, $pno, value);
	}

	/**
	 *  紐付ＮＯ.<p>
	 *
	 */
	public void pno(int value) {
		setConstNumber(offset + 0, $pno, value);
	}

	/**
	 *  紐付ＮＯ.<p>
	 *
	 */
	public void pno(long value) {
		setConstNumber(offset + 0, $pno, value);
	}

	/**
	 *  紐付ＮＯ.<p>
	 *
	 */
	public void pno(float value) {
		setConstNumber(offset + 0, $pno, value);
	}

	/**
	 *  紐付ＮＯ.<p>
	 *
	 */
	public void pno(double value) {
		setConstNumber(offset + 0, $pno, value);
	}


	public String getString(String name) {
		return super.getString(name);
	}
	public MCNumber getNumber(String name) {
		if ($pno.equalsIgnoreCase(name)) {
			return pno();
		}
		return super.getNumber(name);
	}

	public String getStringNE(String name) {
		return super.getStringNE(name);
	}
	public MCNumber getNumberNE(String name) {
		if ($pno.equalsIgnoreCase(name)) {
			return pno();
		}
		return super.getNumberNE(name);
	}

	public void setString(String name, String value) {
		super.setString(name, value);
	}
	public void setNumber(String name, MCNumber value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, int value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, long value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, float value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, double value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumber(name, value);
	}

	public void setStringNE(String name, String value) {
		super.setStringNE(name, value);
	}
	public void setNumberNE(String name, MCNumber value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, int value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, long value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, float value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, double value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumberNE(name, value);
	}



}

