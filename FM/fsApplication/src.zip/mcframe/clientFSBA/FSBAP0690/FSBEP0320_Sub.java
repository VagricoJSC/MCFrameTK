package mcframe.clientFSBA.FSBAP0690;

import mcframe.clientCore.beans.MCRootPanel;
import mcframe.clientFSBA.FSBAP0030.ListDtlR;
import mcframe.clientFSBE.FSBEP0320.FSBEP0320;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

import java.util.concurrent.Semaphore;

import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.resource.ctrl.MCResourceLayerType;

@SuppressWarnings("serial")
public class FSBEP0320_Sub extends FSBEP0320 {

	protected boolean isSaveMode = false;

	protected String saveID = null;

	protected String saveNm = "Current";

	protected Semaphore semaphore = null;

	protected FSBAP0690_FW mainPanel2 = null;

	protected GrpDtlR row;
	
	@Override
	public boolean beforeOpen() {
		if (mainPanel2.getResourceLayerType() == MCResourceLayerType.EXT) {
			setValueEx(Setting_setting_PPanel.Setting_setting_unit_Group,
					Setting_setting_PPanel.Setting_setting_unit_EXT.getActionCommand());
		}
		else if (mainPanel2.getResourceLayerType() == MCResourceLayerType.SYS) {
			setValueEx(Setting_setting_PPanel.Setting_setting_unit_Group,
					Setting_setting_PPanel.Setting_setting_unit_SYS.getActionCommand());
		}
		return super.beforeOpen();
	}

	@Override
	public void afterOpen() {
		super.afterOpen();

		ListDtlR r = null;
		if (!isNull(saveID)) {
			r = getListDtlL().getFirst(ListDtlR.$setting_info_id, saveID);
		}
		if (r == null && !isNull(saveNm)) {
			r = getListDtlL().getFirst(ListDtlR.$setting_info_nm, saveNm);
		}
		if (r == null) {
			for (ListDtlR r2 : getListDtlL()) {
				if (r2.isEmpty()) {
					r = r2;
					break;
				}
			}
			if (r == null) {
				r = ListDtlR.create();
				getListDtlL().add(r);
			}
			ListDtlTable.selectLeftmostColumn(r.getGUIIndex());
			setValueEx(ListHdr_setting_info_nm, saveNm);
			r.setStatus(Status.CREATE);
		}
		else {
			ListDtlTable.selectLeftmostColumn(r.getGUIIndex());
		}

		if (isSaveMode) {
			doUpdAction();
		}
	}

	@Override
	public void doUpdAction() {
		if (!isSaveMode) {
			if (!execUpdComfirm() || !checkForUpd()) {
				return;
			}
		}

		beforeUpd();
		doUpd();
		afterUpd();

		saveID = getListHdrR().setting_info_id();
		saveNm = getListHdrR().setting_info_nm();

		if (mainPanel2 != null) {
			mainPanel2.setLocationID(this, getListHdrR().setting_unit_type(),
					getListHdrR().setting_info_id(), getListHdrR().setting_info_nm());
		}
		else {
			showUpdEndMsg();
		}

		if (row != null) {
			row.location_settings_id(getListHdrR().setting_info_id());
			row.location_settings_nm(getListHdrR().setting_info_nm());
		}

		// 登録後に閉じる。
		clearStatus();

		if (semaphore != null) {
			semaphore.release();
		}

		requestCloseWindow();
	}

	@Override
	protected void doUpdApplyAction() {
		if (!execUpdComfirm() || !checkForUpd()) {
			return;
		}

		beforeUpd();
		doUpd();
		afterUpd();

		saveID = getListHdrR().setting_info_id();
		saveNm = getListHdrR().setting_info_nm();

		if (mainPanel2 != null) {
			mainPanel2.setLocationID(this, getListHdrR().setting_unit_type(),
					getListHdrR().setting_info_id(), getListHdrR().setting_info_nm());
		}
		else {
			showUpdEndMsg();
		}

		if (row != null) {
			row.location_settings_id(getListHdrR().setting_info_id());
			row.location_settings_nm(getListHdrR().setting_info_nm());
		}
	}

    /**
	 * 親画面を設定します。
	 *
	 */
	public void setTargetPanel(MCRootPanel p) {
		targetRootPanel = p;
	}

	// 画面を中央に表示
	@Override
	protected void setDefaultScreenPosition() {
		super.setDefaultScreenPosition();

		setArrangementCenter();
	}

	@Override
	protected boolean isSettingUnitUserEnable() {
		if (mainPanel2.getResourceLayerType() == MCResourceLayerType.EXT
				|| mainPanel2.getResourceLayerType() == MCResourceLayerType.SYS) {
			return false;
		}
		return super.isSettingUnitUserEnable();
	}

	@Override
	protected boolean isSettingUnitExtEnable() {
		if (mainPanel2.getResourceLayerType() == MCResourceLayerType.SYS) {
			return false;
		}
		return super.isSettingUnitExtEnable();
	}
}
