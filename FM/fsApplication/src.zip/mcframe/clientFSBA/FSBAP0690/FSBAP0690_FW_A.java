package mcframe.clientFSBA.FSBAP0690;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBAP0690"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP0690_FW_A extends mcframe.clientFSUC.FSUCP0000.FSUCP_PanelBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0690";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Setting]ブロック関連のField定義
	public MCPanel SettingPanel = null;
	// [Setting]ブロックの項目のField定義
	public mcframe.clientFSUB.FSUBP0090.FSUBP_SettingUnit_H Setting_setting_PPanel;
	// [GrpPanel]ブロック関連のField定義
	public MCPanel GrpPanelPanel = null;
	// [GrpPanel]ブロックの項目のField定義
	// [GrpDtl]ブロック関連のField定義
	public MCPanel GrpDtlPanel = null;
	public MCScrollPane GrpDtlScrollPane = null;
	public MCTable2<mcframe.clientFSBA.FSBAP0690.GrpDtlR> GrpDtlTable = null;
	// [GrpDtl]ブロックの項目のField定義
	/**
	 *  設定単位ＣＤ.<p>
	 *
	 */
	public MCColumnConfig columnGrpDtl_setting_unit_type = null;
	/**
	 *  設定単位名.<p>
	 *
	 */
	public MCColumnConfig columnGrpDtl_setting_unit_type_nm = null;
	/**
	 *  設定情報ＩＤ.<p>
	 *
	 */
	public MCColumnConfig columnGrpDtl_per_grp_id = null;
	/**
	 *  設定情報名.<p>
	 *
	 */
	public MCColumnConfig columnGrpDtl_per_grp_nm = null;
	/**
	 *  入力値設定ＩＤ.<p>
	 *
	 */
	public MCColumnConfig columnGrpDtl_search_settings_id = null;
	/**
	 *  入力値設定名.<p>
	 *
	 */
	public MCColumnConfig columnGrpDtl_search_settings_nm = null;
	/**
	 *  配置情報設定ＩＤ.<p>
	 *
	 */
	public MCColumnConfig columnGrpDtl_location_settings_id = null;
	/**
	 *  配置情報設定名.<p>
	 *
	 */
	public MCColumnConfig columnGrpDtl_location_settings_nm = null;
	/**
	 *  備考.<p>
	 *
	 */
	public MCColumnConfig columnGrpDtl_remark = null;
	// [GrpDtlBtn]ブロック関連のField定義
	public MCPanel GrpDtlBtnPanel = null;
	// [GrpDtlBtn]ブロックの項目のField定義
	/**
	 *  行追加.<p>
	 *
	 */
	public MCButton GrpDtlBtn_radd = null;
	/**
	 *  行削除.<p>
	 *
	 */
	public MCButton GrpDtlBtn_rdel = null;
	/**
	 *  行コピー.<p>
	 *
	 */
	public MCButton GrpDtlBtn_rcopy = null;
	// [DataPanel]ブロック関連のField定義
	public MCPanel DataPanelPanel = null;
	// [DataPanel]ブロックの項目のField定義
	// [TableHdr]ブロック関連のField定義
	public MCPanel TableHdrPanel = null;
	// [TableHdr]ブロックの項目のField定義
	/**
	 *  入力値設定ＩＤ.<p>
	 *
	 */
	public MCTextField TableHdr_search_settings_id = null;
	public MCLabel TableHdr_search_settings_nm_Label = null;
	/**
	 *  入力値設定名.<p>
	 *
	 */
	public MCTextComboBox TableHdr_search_settings_nm = null;
	/**
	 *  配置情報設定ＩＤ.<p>
	 *
	 */
	public MCTextField TableHdr_location_settings_id = null;
	public MCLabel TableHdr_location_settings_nm_Label = null;
	/**
	 *  配置情報設定名.<p>
	 *
	 */
	public MCTextComboBox TableHdr_location_settings_nm = null;
	// [TableDtl]ブロック関連のField定義
	public MCPanel TableDtlPanel = null;
	public MCScrollPane TableDtlScrollPane = null;
	public MCTable2<mcframe.clientFSBA.FSBAP0690.TableDtlR> TableDtlTable = null;
	// [TableDtl]ブロックの項目のField定義
	/**
	 *  テーブル.<p>
	 *
	 */
	public MCColumnConfig columnTableDtl_table_nm = null;
	/**
	 *  カラム順・サイズ変更ＩＤ.<p>
	 *
	 */
	public MCColumnConfig columnTableDtl_column_order_id = null;
	/**
	 *  カラム順・サイズ変更名.<p>
	 *
	 */
	public MCColumnConfig columnTableDtl_column_order_nm = null;
	/**
	 *  ソート順変更ＩＤ.<p>
	 *
	 */
	public MCColumnConfig columnTableDtl_sort_id = null;
	/**
	 *  ソート順変更名.<p>
	 *
	 */
	public MCColumnConfig columnTableDtl_sort_nm = null;
	/**
	 *  フィルタ情報設定ＩＤ.<p>
	 *
	 */
	public MCColumnConfig columnTableDtl_filter_id = null;
	/**
	 *  フィルタ情報設定名.<p>
	 *
	 */
	public MCColumnConfig columnTableDtl_filter_nm = null;
	/**
	 *  シグナル設定ＩＤ.<p>
	 *
	 */
	public MCColumnConfig columnTableDtl_signal_id = null;
	/**
	 *  シグナル設定名.<p>
	 *
	 */
	public MCColumnConfig columnTableDtl_signal_nm = null;
	// [BtnSettings]ブロック関連のField定義
	public MCPanel BtnSettingsPanel = null;
	// [BtnSettings]ブロックの項目のField定義
	/**
	 *  入力値設定.<p>
	 *
	 */
	public MCButton BtnSettings_searchSettings = null;
	/**
	 *  配置情報設定.<p>
	 *
	 */
	public MCButton BtnSettings_locationSettings = null;
	/**
	 *  カラム順・サイズ変更.<p>
	 *
	 */
	public MCButton BtnSettings_columnOrderSettings = null;
	/**
	 *  ソート順変更.<p>
	 *
	 */
	public MCButton BtnSettings_sortSettings = null;
	/**
	 *  フィルタ情報設定.<p>
	 *
	 */
	public MCButton BtnSettings_filterSettings = null;
	/**
	 *  シグナル設定.<p>
	 *
	 */
	public MCButton BtnSettings_signalSettings = null;
	// [InfoHdr]ブロック関連のField定義
	public MCPanel InfoHdrPanel = null;
	// [InfoHdr]ブロックの項目のField定義
	public MCLabel InfoHdr_per_grp_nm_Label = null;
	/**
	 *  設定情報名.<p>
	 *
	 */
	public MCTextField InfoHdr_per_grp_nm = null;
	public MCLabel InfoHdr_remark_Label = null;
	/**
	 *  備考.<p>
	 *
	 */
	public MCTextField InfoHdr_remark = null;
	// [InfoBtn]ブロック関連のField定義
	public MCPanel InfoBtnPanel = null;
	// [InfoBtn]ブロックの項目のField定義
	/**
	 *  更新する.<p>
	 *
	 */
	public MCButton InfoBtn_upd = null;
	/**
	 *  更新する（会社共通）.<p>
	 *
	 */
	public MCButton InfoBtn_upd_ext = null;
	/**
	 *  更新する（システム共通）.<p>
	 *
	 */
	public MCButton InfoBtn_upd_sys = null;
	// [InfoScreen]ブロック関連のField定義
	public MCPanel InfoScreenPanel = null;
	// [InfoScreen]ブロックの項目のField定義
	public mcframe.clientFSUB.FSUBP0080.FSUBP_ParScreenNm_H InfoScreen_par_screen_nm_p_PPanel;
	/** [INIT]モードを表す定数 */
	public static final String INIT = "INIT";
	/** [EDITABLE]モードを表す定数 */
	public static final String EDITABLE = "EDITABLE";
	/** [DISABLE]モードを表す定数 */
	public static final String DISABLE = "DISABLE";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{INIT, EDITABLE, DISABLE};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	
	/** [GrpDtl]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0690.GrpDtlR> aGrpDtlL;
	/** [TableHdr]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0690.TableHdrR aTableHdrR;
	/** [TableDtl]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0690.TableDtlR> aTableDtlL;
	/** [InfoHdr]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0690.InfoHdrR aInfoHdrR;

	/**
	 * コピーによってaGrpDtlLを設定します。
	 *
	 * aGrpDtlLのインスタンスは変更されません。
	 *
	 * @param dataset GrpDtlL
	 */
	public void setGrpDtlL(MCList<mcframe.clientFSBA.FSBAP0690.GrpDtlR> aList) {
		if (getGrpDtlL() != aList) {
			getGrpDtlL().setAll(aList);
		}
	}

	/**
	 * [GrpDtl]ブロックのコンテナaGrpDtlLを返します。
	 *
	 * @return GrpDtlL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0690.GrpDtlR> getGrpDtlL() {
		return aGrpDtlL;
	}

	/**
	 * aGrpDtlRを作成します。
	 *
	 * @return GrpDtlR
	 */
	public mcframe.clientFSBA.FSBAP0690.GrpDtlR createGrpDtlR() {
		return mcframe.clientFSBA.FSBAP0690.GrpDtlR.create();
	}

	/**
	 * aGrpDtlLを作成します。
	 *
	 * @return GrpDtlL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0690.GrpDtlR> createGrpDtlL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0690.GrpDtlR.class);
	}

	/**
	 * GrpDtlTableを初期化します。
	 */
	protected void createGrpDtlTable(){
		if(GrpDtlTable == null){
			GrpDtlTable = beansFactory.createTable2("GrpDtl.table");
		}
	}

	/**
	 * 項目コピーによってaTableHdrRを設定します。
	 *
	 * aTableHdrRのインスタンスは変更されません。
	 *
	 * @param row TableHdrR
	 */
	public void setTableHdrR(mcframe.clientFSBA.FSBAP0690.TableHdrR row) {
		if (row != null) {
			MCRow.copyall(getTableHdrR(), row);
		}
	}

	/**
	 * [TableHdr]ブロックのコンテナaTableHdrRを返します。
	 *
	 * @return TableHdrR
	 */
	public mcframe.clientFSBA.FSBAP0690.TableHdrR getTableHdrR() {
		return aTableHdrR;
	}

	/**
	 * aTableHdrRを作成します。
	 *
	 * @return TableHdrR
	 */
	public mcframe.clientFSBA.FSBAP0690.TableHdrR createTableHdrR() {
		return mcframe.clientFSBA.FSBAP0690.TableHdrR.create();
	}

	/**
	 * コピーによってaTableDtlLを設定します。
	 *
	 * aTableDtlLのインスタンスは変更されません。
	 *
	 * @param dataset TableDtlL
	 */
	public void setTableDtlL(MCList<mcframe.clientFSBA.FSBAP0690.TableDtlR> aList) {
		if (getTableDtlL() != aList) {
			getTableDtlL().setAll(aList);
		}
	}

	/**
	 * [TableDtl]ブロックのコンテナaTableDtlLを返します。
	 *
	 * @return TableDtlL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0690.TableDtlR> getTableDtlL() {
		return aTableDtlL;
	}

	/**
	 * aTableDtlRを作成します。
	 *
	 * @return TableDtlR
	 */
	public mcframe.clientFSBA.FSBAP0690.TableDtlR createTableDtlR() {
		return mcframe.clientFSBA.FSBAP0690.TableDtlR.create();
	}

	/**
	 * aTableDtlLを作成します。
	 *
	 * @return TableDtlL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0690.TableDtlR> createTableDtlL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0690.TableDtlR.class);
	}

	/**
	 * TableDtlTableを初期化します。
	 */
	protected void createTableDtlTable(){
		if(TableDtlTable == null){
			TableDtlTable = beansFactory.createTable2("TableDtl.table");
		}
	}

	/**
	 * 項目コピーによってaInfoHdrRを設定します。
	 *
	 * aInfoHdrRのインスタンスは変更されません。
	 *
	 * @param row InfoHdrR
	 */
	public void setInfoHdrR(mcframe.clientFSBA.FSBAP0690.InfoHdrR row) {
		if (row != null) {
			MCRow.copyall(getInfoHdrR(), row);
		}
	}

	/**
	 * [InfoHdr]ブロックのコンテナaInfoHdrRを返します。
	 *
	 * @return InfoHdrR
	 */
	public mcframe.clientFSBA.FSBAP0690.InfoHdrR getInfoHdrR() {
		return aInfoHdrR;
	}

	/**
	 * aInfoHdrRを作成します。
	 *
	 * @return InfoHdrR
	 */
	public mcframe.clientFSBA.FSBAP0690.InfoHdrR createInfoHdrR() {
		return mcframe.clientFSBA.FSBAP0690.InfoHdrR.create();
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getGrpDtlL())) ret.add(getGrpDtlL());
		if(!MCCollectionUtil.contains(ret, getTableHdrR())) ret.add(getTableHdrR());
		if(!MCCollectionUtil.contains(ret, getTableDtlL())) ret.add(getTableDtlL());
		if(!MCCollectionUtil.contains(ret, getInfoHdrR())) ret.add(getInfoHdrR());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getGrpDtlL()) return "GrpDtl";
		if(aCnt == getTableHdrR()) return "TableHdr";
		if(aCnt == getTableDtlL()) return "TableDtl";
		if(aCnt == getInfoHdrR()) return "InfoHdr";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("GrpDtl")) return getGrpDtlL();
		if(bId.equals("TableHdr")) return getTableHdrR();
		if(bId.equals("TableDtl")) return getTableDtlL();
		if(bId.equals("InfoHdr")) return getInfoHdrR();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(SettingPanel);
		ret.add(GrpPanelPanel);
		ret.add(GrpDtlPanel);
		ret.add(GrpDtlBtnPanel);
		ret.add(DataPanelPanel);
		ret.add(TableHdrPanel);
		ret.add(TableDtlPanel);
		ret.add(BtnSettingsPanel);
		ret.add(InfoHdrPanel);
		ret.add(InfoBtnPanel);
		ret.add(InfoScreenPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0690_FW_A() {
		aGrpDtlL = createGrpDtlL();
		aTableHdrR = createTableHdrR();
		aTableDtlL = createTableDtlL();
		aInfoHdrR = createInfoHdrR();

	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP0690_FW_A(String name) {
		aGrpDtlL = createGrpDtlL();
		createGrpDtlTable();
		GrpDtlTable.setRowName(name);
		aTableHdrR = createTableHdrR();
		aTableDtlL = createTableDtlL();
		createTableDtlTable();
		TableDtlTable.setRowName(name);
		aInfoHdrR = createInfoHdrR();
	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP0690_FW.jbCreateSetting((FSBAP0690)this);
		FSBAP0690_FW.jbCreateGrpPanel((FSBAP0690)this);
		FSBAP0690_FW.jbCreateGrpDtl((FSBAP0690)this);
		FSBAP0690_FW.jbCreateGrpDtlBtn((FSBAP0690)this);
		FSBAP0690_FW.jbCreateDataPanel((FSBAP0690)this);
		FSBAP0690_FW.jbCreateTableHdr((FSBAP0690)this);
		FSBAP0690_FW.jbCreateTableDtl((FSBAP0690)this);
		FSBAP0690_FW.jbCreateBtnSettings((FSBAP0690)this);
		FSBAP0690_FW.jbCreateInfoHdr((FSBAP0690)this);
		FSBAP0690_FW.jbCreateInfoBtn((FSBAP0690)this);
		FSBAP0690_FW.jbCreateInfoScreen((FSBAP0690)this);
	}

	/**
	 * [Setting]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateSetting(FSBAP0690 p) {
		p.Setting_setting_PPanel = mcframe.clientFSUB.FSUBP0090.FSUBP_SettingUnit_H.create();
		p.Setting_setting_PPanel.setName("Setting.setting");
	}

	/**
	 * [GrpPanel]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateGrpPanel(FSBAP0690 p) {
	}

	/**
	 * [GrpDtl]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateGrpDtl(FSBAP0690 p) {
	}

	/**
	 * [GrpDtlBtn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateGrpDtlBtn(FSBAP0690 p) {
	}

	/**
	 * [DataPanel]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateDataPanel(FSBAP0690 p) {
	}

	/**
	 * [TableHdr]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateTableHdr(FSBAP0690 p) {
	}

	/**
	 * [TableDtl]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateTableDtl(FSBAP0690 p) {
	}

	/**
	 * [BtnSettings]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateBtnSettings(FSBAP0690 p) {
	}

	/**
	 * [InfoHdr]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateInfoHdr(FSBAP0690 p) {
	}

	/**
	 * [InfoBtn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateInfoBtn(FSBAP0690 p) {
	}

	/**
	 * [InfoScreen]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateInfoScreen(FSBAP0690 p) {
		p.InfoScreen_par_screen_nm_p_PPanel = mcframe.clientFSUB.FSUBP0080.FSUBP_ParScreenNm_H.create();
		p.InfoScreen_par_screen_nm_p_PPanel.setName("InfoScreen.par_screen_nm_p");
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}

	
	/** [TableHdr_search_settings_nm_ListPutter]の定義 */
	private MCListPutter TableHdr_search_settings_nm_p = null;

	/**
	 * [TableHdr_search_settings_nm_ListPutter]の取得
	 */
	protected MCListPutter getTableHdr_search_settings_nm_ListPutter() {
		if (TableHdr_search_settings_nm_p == null) {
			TableHdr_search_settings_nm_p = createTableHdr_search_settings_nm_ListPutter(TableHdr_search_settings_nm, "search_settings_nm", "search_settings_id");

		}
		return TableHdr_search_settings_nm_p;
	}
	
	
	/** [TableHdr_location_settings_nm_ListPutter]の定義 */
	private MCListPutter TableHdr_location_settings_nm_p = null;

	/**
	 * [TableHdr_location_settings_nm_ListPutter]の取得
	 */
	protected MCListPutter getTableHdr_location_settings_nm_ListPutter() {
		if (TableHdr_location_settings_nm_p == null) {
			TableHdr_location_settings_nm_p = createTableHdr_location_settings_nm_ListPutter(TableHdr_location_settings_nm, "location_settings_nm", "location_settings_id");

		}
		return TableHdr_location_settings_nm_p;
	}
	
	
	/** [TableDtl_column_order_nm_ListPutter]の定義 */
	private MCListPutter TableDtl_column_order_nm_p = null;

	/**
	 * [TableDtl_column_order_nm_ListPutter]の取得
	 */
	protected MCListPutter getTableDtl_column_order_nm_ListPutter() {
		if (TableDtl_column_order_nm_p == null) {
			TableDtl_column_order_nm_p = createTableDtl_column_order_nm_ListPutter(columnTableDtl_column_order_nm, "column_order_nm", "column_order_id");

		}
		return TableDtl_column_order_nm_p;
	}
	
	
	/** [TableDtl_sort_nm_ListPutter]の定義 */
	private MCListPutter TableDtl_sort_nm_p = null;

	/**
	 * [TableDtl_sort_nm_ListPutter]の取得
	 */
	protected MCListPutter getTableDtl_sort_nm_ListPutter() {
		if (TableDtl_sort_nm_p == null) {
			TableDtl_sort_nm_p = createTableDtl_sort_nm_ListPutter(columnTableDtl_sort_nm, "sort_nm", "sort_id");

		}
		return TableDtl_sort_nm_p;
	}
	
	
	/** [TableDtl_filter_nm_ListPutter]の定義 */
	private MCListPutter TableDtl_filter_nm_p = null;

	/**
	 * [TableDtl_filter_nm_ListPutter]の取得
	 */
	protected MCListPutter getTableDtl_filter_nm_ListPutter() {
		if (TableDtl_filter_nm_p == null) {
			TableDtl_filter_nm_p = createTableDtl_filter_nm_ListPutter(columnTableDtl_filter_nm, "filter_nm", "filter_id");

		}
		return TableDtl_filter_nm_p;
	}
	
	
	/** [TableDtl_signal_nm_ListPutter]の定義 */
	private MCListPutter TableDtl_signal_nm_p = null;

	/**
	 * [TableDtl_signal_nm_ListPutter]の取得
	 */
	protected MCListPutter getTableDtl_signal_nm_ListPutter() {
		if (TableDtl_signal_nm_p == null) {
			TableDtl_signal_nm_p = createTableDtl_signal_nm_ListPutter(columnTableDtl_signal_nm, "signal_nm", "signal_id");

		}
		return TableDtl_signal_nm_p;
	}
	

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP0690 create(){
		FSBAP0690 p = new FSBAP0690();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP0690 create(String name){
		FSBAP0690 p = new FSBAP0690(name);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP0690_FW.jbfInitSetting((FSBAP0690)this);
		FSBAP0690_FW.jbfInitGrpPanel((FSBAP0690)this);
		FSBAP0690_FW.jbfInitGrpDtl((FSBAP0690)this);
		FSBAP0690_FW.jbfInitGrpDtlBtn((FSBAP0690)this);
		FSBAP0690_FW.jbfInitDataPanel((FSBAP0690)this);
		FSBAP0690_FW.jbfInitTableHdr((FSBAP0690)this);
		FSBAP0690_FW.jbfInitTableDtl((FSBAP0690)this);
		FSBAP0690_FW.jbfInitBtnSettings((FSBAP0690)this);
		FSBAP0690_FW.jbfInitInfoHdr((FSBAP0690)this);
		FSBAP0690_FW.jbfInitInfoBtn((FSBAP0690)this);
		FSBAP0690_FW.jbfInitInfoScreen((FSBAP0690)this);
		FSBAP0690_FW.jbInitSetting((FSBAP0690)this);
		FSBAP0690_FW.jbInitGrpPanel((FSBAP0690)this);
		FSBAP0690_FW.jbInitGrpDtl((FSBAP0690)this);
		FSBAP0690_FW.jbInitGrpDtlBtn((FSBAP0690)this);
		FSBAP0690_FW.jbInitDataPanel((FSBAP0690)this);
		FSBAP0690_FW.jbInitTableHdr((FSBAP0690)this);
		FSBAP0690_FW.jbInitTableDtl((FSBAP0690)this);
		FSBAP0690_FW.jbInitBtnSettings((FSBAP0690)this);
		FSBAP0690_FW.jbInitInfoHdr((FSBAP0690)this);
		FSBAP0690_FW.jbInitInfoBtn((FSBAP0690)this);
		FSBAP0690_FW.jbInitInfoScreen((FSBAP0690)this);
	}

	/**
	 * [Setting]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitSetting(FSBAP0690 p) {
		// ブロック関連の初期化
		p.SettingPanel = p.beansFactory.createPanel("Setting");
		// ブロックの項目の初期化
	}

	/**
	 * [GrpPanel]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitGrpPanel(FSBAP0690 p) {
		// ブロック関連の初期化
		p.GrpPanelPanel = p.beansFactory.createPanel("GrpPanel");
		// ブロックの項目の初期化
	}

	/**
	 * [GrpDtl]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitGrpDtl(FSBAP0690 p) {
		// ブロック関連の初期化
		p.GrpDtlPanel = p.beansFactory.createPanel("GrpDtl");
		p.GrpDtlScrollPane = p.beansFactory.createScrollPane("GrpDtl.scroll");
		p.createGrpDtlTable();
		// ブロックの項目の初期化
		p.columnGrpDtl_setting_unit_type = p.beansFactory.createTableColumn("GrpDtl.setting_unit_type", MCColumnType.TEXT);
		p.columnGrpDtl_setting_unit_type_nm = p.beansFactory.createTableColumn("GrpDtl.setting_unit_type_nm", MCColumnType.TEXT);
		p.columnGrpDtl_per_grp_id = p.beansFactory.createTableColumn("GrpDtl.per_grp_id", MCColumnType.TEXT);
		p.columnGrpDtl_per_grp_nm = p.beansFactory.createTableColumn("GrpDtl.per_grp_nm", MCColumnType.TEXT);
		p.columnGrpDtl_search_settings_id = p.beansFactory.createTableColumn("GrpDtl.search_settings_id", MCColumnType.TEXT);
		p.columnGrpDtl_search_settings_nm = p.beansFactory.createTableColumn("GrpDtl.search_settings_nm", MCColumnType.TEXT);
		p.columnGrpDtl_location_settings_id = p.beansFactory.createTableColumn("GrpDtl.location_settings_id", MCColumnType.TEXT);
		p.columnGrpDtl_location_settings_nm = p.beansFactory.createTableColumn("GrpDtl.location_settings_nm", MCColumnType.TEXT);
		p.columnGrpDtl_remark = p.beansFactory.createTableColumn("GrpDtl.remark", MCColumnType.TEXT);
	}

	/**
	 * [GrpDtlBtn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitGrpDtlBtn(FSBAP0690 p) {
		// ブロック関連の初期化
		p.GrpDtlBtnPanel = p.beansFactory.createPanel("GrpDtlBtn");
		// ブロックの項目の初期化
		p.GrpDtlBtn_radd = p.beansFactory.createButton("GrpDtlBtn.radd", "no_border");
		p.GrpDtlBtn_rdel = p.beansFactory.createButton("GrpDtlBtn.rdel", "no_border");
		p.GrpDtlBtn_rcopy = p.beansFactory.createButton("GrpDtlBtn.rcopy", "no_border");
	}

	/**
	 * [DataPanel]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitDataPanel(FSBAP0690 p) {
		// ブロック関連の初期化
		p.DataPanelPanel = p.beansFactory.createPanel("DataPanel");
		// ブロックの項目の初期化
	}

	/**
	 * [TableHdr]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitTableHdr(FSBAP0690 p) {
		// ブロック関連の初期化
		p.TableHdrPanel = p.beansFactory.createPanel("TableHdr");
		// ブロックの項目の初期化
		p.TableHdr_search_settings_id = p.beansFactory.createTextField("TableHdr.search_settings_id");
		p.TableHdr_search_settings_nm_Label = p.beansFactory.createLabel("TableHdr.search_settings_nm_Label");
		p.TableHdr_search_settings_nm = p.beansFactory.createTextComboBox("TableHdr.search_settings_nm");
		p.TableHdr_search_settings_nm.setLabel(p.TableHdr_search_settings_nm_Label);
		p.TableHdr_location_settings_id = p.beansFactory.createTextField("TableHdr.location_settings_id");
		p.TableHdr_location_settings_nm_Label = p.beansFactory.createLabel("TableHdr.location_settings_nm_Label");
		p.TableHdr_location_settings_nm = p.beansFactory.createTextComboBox("TableHdr.location_settings_nm");
		p.TableHdr_location_settings_nm.setLabel(p.TableHdr_location_settings_nm_Label);
	}

	/**
	 * [TableDtl]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitTableDtl(FSBAP0690 p) {
		// ブロック関連の初期化
		p.TableDtlPanel = p.beansFactory.createPanel("TableDtl");
		p.TableDtlScrollPane = p.beansFactory.createScrollPane("TableDtl.scroll");
		p.createTableDtlTable();
		// ブロックの項目の初期化
		p.columnTableDtl_table_nm = p.beansFactory.createTableColumn("TableDtl.table_nm", MCColumnType.TEXT);
		p.columnTableDtl_column_order_id = p.beansFactory.createTableColumn("TableDtl.column_order_id", MCColumnType.TEXT);
		p.columnTableDtl_column_order_nm = p.beansFactory.createTableColumn("TableDtl.column_order_nm", MCColumnType.TEXT_COMBO);
		p.columnTableDtl_sort_id = p.beansFactory.createTableColumn("TableDtl.sort_id", MCColumnType.TEXT);
		p.columnTableDtl_sort_nm = p.beansFactory.createTableColumn("TableDtl.sort_nm", MCColumnType.TEXT_COMBO);
		p.columnTableDtl_filter_id = p.beansFactory.createTableColumn("TableDtl.filter_id", MCColumnType.TEXT);
		p.columnTableDtl_filter_nm = p.beansFactory.createTableColumn("TableDtl.filter_nm", MCColumnType.TEXT_COMBO);
		p.columnTableDtl_signal_id = p.beansFactory.createTableColumn("TableDtl.signal_id", MCColumnType.TEXT);
		p.columnTableDtl_signal_nm = p.beansFactory.createTableColumn("TableDtl.signal_nm", MCColumnType.TEXT_COMBO);
	}

	/**
	 * [BtnSettings]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitBtnSettings(FSBAP0690 p) {
		// ブロック関連の初期化
		p.BtnSettingsPanel = p.beansFactory.createPanel("BtnSettings");
		// ブロックの項目の初期化
		p.BtnSettings_searchSettings = p.beansFactory.createButton("BtnSettings.searchSettings", "open");
		p.BtnSettings_locationSettings = p.beansFactory.createButton("BtnSettings.locationSettings", "open");
		p.BtnSettings_columnOrderSettings = p.beansFactory.createButton("BtnSettings.columnOrderSettings", "open");
		p.BtnSettings_sortSettings = p.beansFactory.createButton("BtnSettings.sortSettings", "open");
		p.BtnSettings_filterSettings = p.beansFactory.createButton("BtnSettings.filterSettings", "open");
		p.BtnSettings_signalSettings = p.beansFactory.createButton("BtnSettings.signalSettings", "open");
	}

	/**
	 * [InfoHdr]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitInfoHdr(FSBAP0690 p) {
		// ブロック関連の初期化
		p.InfoHdrPanel = p.beansFactory.createPanel("InfoHdr");
		// ブロックの項目の初期化
		p.InfoHdr_per_grp_nm_Label = p.beansFactory.createLabel("InfoHdr.per_grp_nm_Label");
		p.InfoHdr_per_grp_nm = p.beansFactory.createTextField("InfoHdr.per_grp_nm");
		p.InfoHdr_per_grp_nm.setLabel(p.InfoHdr_per_grp_nm_Label);
		p.InfoHdr_remark_Label = p.beansFactory.createLabel("InfoHdr.remark_Label");
		p.InfoHdr_remark = p.beansFactory.createTextField("InfoHdr.remark");
		p.InfoHdr_remark.setLabel(p.InfoHdr_remark_Label);
	}

	/**
	 * [InfoBtn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitInfoBtn(FSBAP0690 p) {
		// ブロック関連の初期化
		p.InfoBtnPanel = p.beansFactory.createPanel("InfoBtn");
		// ブロックの項目の初期化
		p.InfoBtn_upd = p.beansFactory.createButton("InfoBtn.upd", "upd");
		p.InfoBtn_upd_ext = p.beansFactory.createButton("InfoBtn.upd_ext", "upd");
		p.InfoBtn_upd_sys = p.beansFactory.createButton("InfoBtn.upd_sys", "upd");
	}

	/**
	 * [InfoScreen]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitInfoScreen(FSBAP0690 p) {
		// ブロック関連の初期化
		p.InfoScreenPanel = p.beansFactory.createPanel("InfoScreen");
		// ブロックの項目の初期化
	}

	/**
	 * [Setting]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitSetting(FSBAP0690 p) {
		// ブロック関連の初期化
		p.add(p.SettingPanel);
		p.setLastBeans(p.SettingPanel);
		p.SettingPanel.setNextBeans(p.GrpPanelPanel);
		p.SettingPanel.setValueCheck(false);
		p.SettingPanel.setLayoutPosition("N");
		// ブロックの項目の初期化
		p.SettingPanel.add(p.Setting_setting_PPanel);
		p.SettingPanel.setLastBeans(p.Setting_setting_PPanel);
	}

	/**
	 * [GrpPanel]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitGrpPanel(FSBAP0690 p) {
		// ブロック関連の初期化
		p.add(p.GrpPanelPanel);
		p.GrpPanelPanel.setNextBeans(p.DataPanelPanel);
		p.GrpPanelPanel.setLayoutPosition("CTC+");
		// ブロックの項目の初期化
		p.GrpPanelPanel.add(p.GrpDtlPanel, null);
		p.GrpPanelPanel.setLastBeans(p.GrpDtlPanel);
		p.GrpDtlPanel.setNextBeans(p.GrpDtlBtnPanel);
		p.GrpPanelPanel.add(p.GrpDtlBtnPanel, null);
	}

	/**
	 * [GrpDtl]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitGrpDtl(FSBAP0690 p) {
		// ブロック関連の初期化
		p.GrpDtlPanel.add(p.GrpDtlScrollPane);
		p.GrpDtlPanel.setLastBeans(p.GrpDtlTable);
		p.GrpDtlScrollPane.setViewportView(p.GrpDtlTable);
		p.GrpDtlTable.setList(p.getGrpDtlL());
		p.GrpDtlPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * [GrpDtlBtn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitGrpDtlBtn(FSBAP0690 p) {
		// ブロック関連の初期化
		p.GrpDtlBtnPanel.setLayoutPosition("SW");
		// ブロックの項目の初期化
		p.GrpDtlBtn_radd.setIcon("INSERT_RECORD");
		p.GrpDtlBtn_radd.setFunctionKey(MCFunctionKey.F5);
		p.GrpDtlBtnPanel.add(p.GrpDtlBtn_radd);
		p.GrpDtlBtnPanel.setLastBeans(p.GrpDtlBtn_radd);
		p.GrpDtlBtn_radd.setNextBeans(p.GrpDtlBtn_rdel);
		p.GrpDtlBtn_rdel.setIcon("DELETE_RECORD");
		p.GrpDtlBtn_rdel.setFunctionKey(MCFunctionKey.F6);
		p.GrpDtlBtnPanel.add(p.GrpDtlBtn_rdel);
		p.GrpDtlBtn_rdel.setNextBeans(p.GrpDtlBtn_rcopy);
		p.GrpDtlBtn_rcopy.setIcon("COPY_RECORD");
		p.GrpDtlBtn_rcopy.setFunctionKey(MCFunctionKey.F15);
		p.GrpDtlBtnPanel.add(p.GrpDtlBtn_rcopy);
	}

	/**
	 * [DataPanel]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitDataPanel(FSBAP0690 p) {
		// ブロック関連の初期化
		p.add(p.DataPanelPanel);
		p.DataPanelPanel.setNextBeans(p.InfoScreenPanel);
		p.DataPanelPanel.setLayoutPosition("CBC+");
		// ブロックの項目の初期化
		p.DataPanelPanel.add(p.TableHdrPanel, null);
		p.DataPanelPanel.setLastBeans(p.TableHdrPanel);
		p.TableHdrPanel.setNextBeans(p.TableDtlPanel);
		p.DataPanelPanel.add(p.TableDtlPanel, null);
		p.TableDtlPanel.setNextBeans(p.BtnSettingsPanel);
		p.DataPanelPanel.add(p.BtnSettingsPanel, null);
		p.BtnSettingsPanel.setNextBeans(p.InfoHdrPanel);
		p.DataPanelPanel.add(p.InfoHdrPanel, null);
		p.InfoHdrPanel.setNextBeans(p.InfoBtnPanel);
		p.DataPanelPanel.add(p.InfoBtnPanel, null);
	}

	/**
	 * [TableHdr]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitTableHdr(FSBAP0690 p) {
		// ブロック関連の初期化
		p.TableHdrPanel.setLayoutPosition("N");
		// ブロックの項目の初期化
		p.TableHdrPanel.add(p.TableHdr_search_settings_id);
		p.TableHdrPanel.setLastBeans(p.TableHdr_search_settings_id);
		p.TableHdr_search_settings_id.setNextBeans(p.TableHdr_search_settings_nm);
		p.TableHdr_search_settings_id.setRow(p.getTableHdrR(), mcframe.clientFSBA.FSBAP0690.TableHdrR.search_settings_id_META);
		p.TableHdr_search_settings_nm.setListType(MCListType.STRICT);
		p.TableHdr_search_settings_nm.setLinkBeans(p.TableHdr_search_settings_id);
		p.TableHdrPanel.add(p.TableHdr_search_settings_nm_Label);
		p.TableHdrPanel.add(p.TableHdr_search_settings_nm);
		p.TableHdr_search_settings_nm.setNextBeans(p.TableHdr_location_settings_id);
		p.TableHdr_search_settings_nm.setRow(p.getTableHdrR(), mcframe.clientFSBA.FSBAP0690.TableHdrR.search_settings_nm_META);
		p.TableHdrPanel.add(p.TableHdr_location_settings_id);
		p.TableHdr_location_settings_id.setNextBeans(p.TableHdr_location_settings_nm);
		p.TableHdr_location_settings_id.setRow(p.getTableHdrR(), mcframe.clientFSBA.FSBAP0690.TableHdrR.location_settings_id_META);
		p.TableHdr_location_settings_nm.setListType(MCListType.STRICT);
		p.TableHdr_location_settings_nm.setLinkBeans(p.TableHdr_location_settings_id);
		p.TableHdrPanel.add(p.TableHdr_location_settings_nm_Label);
		p.TableHdrPanel.add(p.TableHdr_location_settings_nm);
		p.TableHdr_location_settings_nm.setRow(p.getTableHdrR(), mcframe.clientFSBA.FSBAP0690.TableHdrR.location_settings_nm_META);
	}

	/**
	 * [TableDtl]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitTableDtl(FSBAP0690 p) {
		// ブロック関連の初期化
		p.TableDtlPanel.add(p.TableDtlScrollPane);
		p.TableDtlPanel.setLastBeans(p.TableDtlTable);
		p.TableDtlScrollPane.setViewportView(p.TableDtlTable);
		p.TableDtlTable.setList(p.getTableDtlL());
		p.TableDtlPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * [BtnSettings]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitBtnSettings(FSBAP0690 p) {
		// ブロック関連の初期化
		p.BtnSettingsPanel.setLayoutPosition("SNN");
		// ブロックの項目の初期化
		p.BtnSettings_searchSettings.setFunctionKey(MCFunctionKey.F16);
		p.BtnSettingsPanel.add(p.BtnSettings_searchSettings);
		p.BtnSettingsPanel.setLastBeans(p.BtnSettings_searchSettings);
		p.BtnSettings_searchSettings.setNextBeans(p.BtnSettings_locationSettings);
		p.BtnSettings_locationSettings.setFunctionKey(MCFunctionKey.F17);
		p.BtnSettingsPanel.add(p.BtnSettings_locationSettings);
		p.BtnSettings_locationSettings.setNextBeans(p.BtnSettings_columnOrderSettings);
		p.BtnSettings_columnOrderSettings.setFunctionKey(MCFunctionKey.F18);
		p.BtnSettingsPanel.add(p.BtnSettings_columnOrderSettings);
		p.BtnSettings_columnOrderSettings.setNextBeans(p.BtnSettings_sortSettings);
		p.BtnSettings_sortSettings.setFunctionKey(MCFunctionKey.F19);
		p.BtnSettingsPanel.add(p.BtnSettings_sortSettings);
		p.BtnSettings_sortSettings.setNextBeans(p.BtnSettings_filterSettings);
		p.BtnSettings_filterSettings.setFunctionKey(MCFunctionKey.F20);
		p.BtnSettingsPanel.add(p.BtnSettings_filterSettings);
		p.BtnSettings_filterSettings.setNextBeans(p.BtnSettings_signalSettings);
		p.BtnSettings_signalSettings.setFunctionKey(MCFunctionKey.F21);
		p.BtnSettingsPanel.add(p.BtnSettings_signalSettings);
	}

	/**
	 * [InfoHdr]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitInfoHdr(FSBAP0690 p) {
		// ブロック関連の初期化
		p.InfoHdrPanel.setLayoutPosition("SNS");
		// ブロックの項目の初期化
		p.InfoHdrPanel.add(p.InfoHdr_per_grp_nm_Label);
		p.InfoHdrPanel.add(p.InfoHdr_per_grp_nm);
		p.InfoHdrPanel.setLastBeans(p.InfoHdr_per_grp_nm);
		p.InfoHdr_per_grp_nm.setNextBeans(p.InfoHdr_remark);
		p.InfoHdr_per_grp_nm.setRow(p.getInfoHdrR(), mcframe.clientFSBA.FSBAP0690.InfoHdrR.per_grp_nm_META);
		p.InfoHdrPanel.add(p.InfoHdr_remark_Label);
		p.InfoHdrPanel.add(p.InfoHdr_remark);
		p.InfoHdr_remark.setRow(p.getInfoHdrR(), mcframe.clientFSBA.FSBAP0690.InfoHdrR.remark_META);
	}

	/**
	 * [InfoBtn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitInfoBtn(FSBAP0690 p) {
		// ブロック関連の初期化
		p.InfoBtnPanel.setLayoutPosition("SW");
		// ブロックの項目の初期化
		p.InfoBtn_upd.setIcon("REGISTER");
		p.InfoBtn_upd.setFunctionKey(MCFunctionKey.F9);
		p.InfoBtnPanel.add(p.InfoBtn_upd);
		p.InfoBtnPanel.setLastBeans(p.InfoBtn_upd);
		p.InfoBtn_upd.setNextBeans(p.InfoBtn_upd_ext);
		p.InfoBtn_upd_ext.setIcon("REGISTER");
		p.InfoBtn_upd_ext.setFunctionKey(MCFunctionKey.F9);
		p.InfoBtnPanel.add(p.InfoBtn_upd_ext);
		p.InfoBtn_upd_ext.setNextBeans(p.InfoBtn_upd_sys);
		p.InfoBtn_upd_sys.setIcon("REGISTER");
		p.InfoBtn_upd_sys.setFunctionKey(MCFunctionKey.F9);
		p.InfoBtnPanel.add(p.InfoBtn_upd_sys);
	}

	/**
	 * [InfoScreen]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitInfoScreen(FSBAP0690 p) {
		// ブロック関連の初期化
		p.add(p.InfoScreenPanel);
		p.InfoScreenPanel.setLayoutPosition("S");
		// ブロックの項目の初期化
		p.InfoScreenPanel.add(p.InfoScreen_par_screen_nm_p_PPanel);
		p.InfoScreenPanel.setLastBeans(p.InfoScreen_par_screen_nm_p_PPanel);
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "G";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP0690_FW.mcInitSetting((FSBAP0690)this);
		FSBAP0690_FW.mcInitGrpPanel((FSBAP0690)this);
		FSBAP0690_FW.mcInitGrpDtl((FSBAP0690)this);
		FSBAP0690_FW.mcInitGrpDtlBtn((FSBAP0690)this);
		FSBAP0690_FW.mcInitDataPanel((FSBAP0690)this);
		FSBAP0690_FW.mcInitTableHdr((FSBAP0690)this);
		FSBAP0690_FW.mcInitTableDtl((FSBAP0690)this);
		FSBAP0690_FW.mcInitBtnSettings((FSBAP0690)this);
		FSBAP0690_FW.mcInitInfoHdr((FSBAP0690)this);
		FSBAP0690_FW.mcInitInfoBtn((FSBAP0690)this);
		FSBAP0690_FW.mcInitInfoScreen((FSBAP0690)this);

		// [INIT]ステータスのモードの設定
		FSBAP0690_FW.statusInitINIT_Setting((FSBAP0690)this);
		FSBAP0690_FW.statusInitINIT_GrpPanel((FSBAP0690)this);
		FSBAP0690_FW.statusInitINIT_GrpDtl((FSBAP0690)this);
		FSBAP0690_FW.statusInitINIT_GrpDtlBtn((FSBAP0690)this);
		FSBAP0690_FW.statusInitINIT_DataPanel((FSBAP0690)this);
		FSBAP0690_FW.statusInitINIT_TableHdr((FSBAP0690)this);
		FSBAP0690_FW.statusInitINIT_TableDtl((FSBAP0690)this);
		FSBAP0690_FW.statusInitINIT_BtnSettings((FSBAP0690)this);
		FSBAP0690_FW.statusInitINIT_InfoHdr((FSBAP0690)this);
		FSBAP0690_FW.statusInitINIT_InfoBtn((FSBAP0690)this);
		FSBAP0690_FW.statusInitINIT_InfoScreen((FSBAP0690)this);

		// [EDITABLE]ステータスのモードの設定
		FSBAP0690_FW.statusInitEDITABLE_Setting((FSBAP0690)this);
		FSBAP0690_FW.statusInitEDITABLE_GrpPanel((FSBAP0690)this);
		FSBAP0690_FW.statusInitEDITABLE_GrpDtl((FSBAP0690)this);
		FSBAP0690_FW.statusInitEDITABLE_GrpDtlBtn((FSBAP0690)this);
		FSBAP0690_FW.statusInitEDITABLE_DataPanel((FSBAP0690)this);
		FSBAP0690_FW.statusInitEDITABLE_TableHdr((FSBAP0690)this);
		FSBAP0690_FW.statusInitEDITABLE_TableDtl((FSBAP0690)this);
		FSBAP0690_FW.statusInitEDITABLE_BtnSettings((FSBAP0690)this);
		FSBAP0690_FW.statusInitEDITABLE_InfoHdr((FSBAP0690)this);
		FSBAP0690_FW.statusInitEDITABLE_InfoBtn((FSBAP0690)this);
		FSBAP0690_FW.statusInitEDITABLE_InfoScreen((FSBAP0690)this);

		// [DISABLE]ステータスのモードの設定
		FSBAP0690_FW.statusInitDISABLE_Setting((FSBAP0690)this);
		FSBAP0690_FW.statusInitDISABLE_GrpPanel((FSBAP0690)this);
		FSBAP0690_FW.statusInitDISABLE_GrpDtl((FSBAP0690)this);
		FSBAP0690_FW.statusInitDISABLE_GrpDtlBtn((FSBAP0690)this);
		FSBAP0690_FW.statusInitDISABLE_DataPanel((FSBAP0690)this);
		FSBAP0690_FW.statusInitDISABLE_TableHdr((FSBAP0690)this);
		FSBAP0690_FW.statusInitDISABLE_TableDtl((FSBAP0690)this);
		FSBAP0690_FW.statusInitDISABLE_BtnSettings((FSBAP0690)this);
		FSBAP0690_FW.statusInitDISABLE_InfoHdr((FSBAP0690)this);
		FSBAP0690_FW.statusInitDISABLE_InfoBtn((FSBAP0690)this);
		FSBAP0690_FW.statusInitDISABLE_InfoScreen((FSBAP0690)this);

	}

	/**
	 *  [Setting]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitSetting(FSBAP0690 p) {
	}

	/**
	 *  [GrpPanel]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitGrpPanel(FSBAP0690 p) {
	}

	/**
	 *  [GrpDtl]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitGrpDtl(FSBAP0690 p) {
		p.GrpDtlTable.addAllListener(p);
		p.columnGrpDtl_setting_unit_type.addAllListener(p);
		p.columnGrpDtl_setting_unit_type.setListListener(p);
		p.columnGrpDtl_setting_unit_type_nm.addAllListener(p);
		p.columnGrpDtl_setting_unit_type_nm.setListListener(p);
		p.columnGrpDtl_per_grp_id.addAllListener(p);
		p.columnGrpDtl_per_grp_id.setListListener(p);
		p.columnGrpDtl_per_grp_nm.addAllListener(p);
		p.columnGrpDtl_per_grp_nm.setListListener(p);
		p.columnGrpDtl_search_settings_id.addAllListener(p);
		p.columnGrpDtl_search_settings_id.setListListener(p);
		p.columnGrpDtl_search_settings_nm.addAllListener(p);
		p.columnGrpDtl_search_settings_nm.setListListener(p);
		p.columnGrpDtl_location_settings_id.addAllListener(p);
		p.columnGrpDtl_location_settings_id.setListListener(p);
		p.columnGrpDtl_location_settings_nm.addAllListener(p);
		p.columnGrpDtl_location_settings_nm.setListListener(p);
		p.columnGrpDtl_remark.addAllListener(p);
		p.columnGrpDtl_remark.setListListener(p);
	}

	/**
	 *  [GrpDtlBtn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitGrpDtlBtn(FSBAP0690 p) {
		p.GrpDtlBtn_radd.addAllListener(p);
		p.GrpDtlBtn_radd.setAPMethodName("doGrpDtlBtn_radd");
		p.GrpDtlBtn_rdel.addAllListener(p);
		p.GrpDtlBtn_rdel.setAPMethodName("doGrpDtlBtn_rdel");
		p.GrpDtlBtn_rcopy.addAllListener(p);
		p.GrpDtlBtn_rcopy.setAPMethodName("doGrpDtlBtn_rcopy");
	}

	/**
	 *  [DataPanel]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitDataPanel(FSBAP0690 p) {
	}

	/**
	 *  [TableHdr]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitTableHdr(FSBAP0690 p) {
		p.TableHdr_search_settings_id.setListListener(p);
		p.TableHdr_search_settings_id.addAllListener(p);
		p.TableHdr_search_settings_nm.setListListener(p);
		p.TableHdr_search_settings_nm.addAllListener(p);
		p.TableHdr_location_settings_id.setListListener(p);
		p.TableHdr_location_settings_id.addAllListener(p);
		p.TableHdr_location_settings_nm.setListListener(p);
		p.TableHdr_location_settings_nm.addAllListener(p);
	}

	/**
	 *  [TableDtl]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitTableDtl(FSBAP0690 p) {
		p.TableDtlTable.addAllListener(p);
		p.columnTableDtl_table_nm.addAllListener(p);
		p.columnTableDtl_table_nm.setListListener(p);
		p.columnTableDtl_column_order_id.addAllListener(p);
		p.columnTableDtl_column_order_id.setListListener(p);
		p.columnTableDtl_column_order_nm.addAllListener(p);
		p.columnTableDtl_column_order_nm.setListListener(p);
		p.columnTableDtl_sort_id.addAllListener(p);
		p.columnTableDtl_sort_id.setListListener(p);
		p.columnTableDtl_sort_nm.addAllListener(p);
		p.columnTableDtl_sort_nm.setListListener(p);
		p.columnTableDtl_filter_id.addAllListener(p);
		p.columnTableDtl_filter_id.setListListener(p);
		p.columnTableDtl_filter_nm.addAllListener(p);
		p.columnTableDtl_filter_nm.setListListener(p);
		p.columnTableDtl_signal_id.addAllListener(p);
		p.columnTableDtl_signal_id.setListListener(p);
		p.columnTableDtl_signal_nm.addAllListener(p);
		p.columnTableDtl_signal_nm.setListListener(p);
	}

	/**
	 *  [BtnSettings]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitBtnSettings(FSBAP0690 p) {
		p.BtnSettings_searchSettings.addAllListener(p);
		p.BtnSettings_searchSettings.setAPMethodName("doBtnSettings_searchSettings");
		p.BtnSettings_locationSettings.addAllListener(p);
		p.BtnSettings_locationSettings.setAPMethodName("doBtnSettings_locationSettings");
		p.BtnSettings_columnOrderSettings.addAllListener(p);
		p.BtnSettings_columnOrderSettings.setAPMethodName("doBtnSettings_columnOrderSettings");
		p.BtnSettings_sortSettings.addAllListener(p);
		p.BtnSettings_sortSettings.setAPMethodName("doBtnSettings_sortSettings");
		p.BtnSettings_filterSettings.addAllListener(p);
		p.BtnSettings_filterSettings.setAPMethodName("doBtnSettings_filterSettings");
		p.BtnSettings_signalSettings.addAllListener(p);
		p.BtnSettings_signalSettings.setAPMethodName("doBtnSettings_signalSettings");
	}

	/**
	 *  [InfoHdr]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitInfoHdr(FSBAP0690 p) {
		p.InfoHdr_per_grp_nm.setListListener(p);
		p.InfoHdr_per_grp_nm.addAllListener(p);
		p.InfoHdr_remark.setListListener(p);
		p.InfoHdr_remark.addAllListener(p);
	}

	/**
	 *  [InfoBtn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitInfoBtn(FSBAP0690 p) {
		p.InfoBtn_upd.addAllListener(p);
		p.InfoBtn_upd.setAPMethodName("doInfoBtn_upd");
		p.InfoBtn_upd_ext.addAllListener(p);
		p.InfoBtn_upd_ext.setAPMethodName("doInfoBtn_upd_ext");
		p.InfoBtn_upd_sys.addAllListener(p);
		p.InfoBtn_upd_sys.setAPMethodName("doInfoBtn_upd_sys");
	}

	/**
	 *  [InfoScreen]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitInfoScreen(FSBAP0690 p) {
	}

	/**
	 * [INIT]ステータスの[Setting]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Setting(FSBAP0690 p){
		p.Setting_setting_PPanel.putStatus(INIT, mcframe.clientFSUB.FSUBP0090.FSUBP_SettingUnit_H.REQUIRED);

	}

	/**
	 * [INIT]ステータスの[GrpPanel]ブロックのモードの設定
	 */
	protected static void statusInitINIT_GrpPanel(FSBAP0690 p){

	}

	/**
	 * [INIT]ステータスの[GrpDtl]ブロックのモードの設定
	 */
	protected static void statusInitINIT_GrpDtl(FSBAP0690 p){
		p.columnGrpDtl_setting_unit_type.putMode(p, INIT, MCMode.INVISIBLE);
		p.columnGrpDtl_setting_unit_type_nm.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnGrpDtl_per_grp_id.putMode(p, INIT, MCMode.INVISIBLE);
		p.columnGrpDtl_per_grp_nm.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnGrpDtl_search_settings_id.putMode(p, INIT, MCMode.INVISIBLE);
		p.columnGrpDtl_search_settings_nm.putMode(p, INIT, MCMode.INVISIBLE);
		p.columnGrpDtl_location_settings_id.putMode(p, INIT, MCMode.INVISIBLE);
		p.columnGrpDtl_location_settings_nm.putMode(p, INIT, MCMode.INVISIBLE);
		p.columnGrpDtl_remark.putMode(p, INIT, MCMode.READ_ONLY);

	}

	/**
	 * [INIT]ステータスの[GrpDtlBtn]ブロックのモードの設定
	 */
	protected static void statusInitINIT_GrpDtlBtn(FSBAP0690 p){
		p.GrpDtlBtn_radd.putMode(p, INIT, MCMode.ENABLE);
		p.GrpDtlBtn_rdel.putMode(p, INIT, MCMode.DISABLE);
		p.GrpDtlBtn_rcopy.putMode(p, INIT, MCMode.DISABLE);

	}

	/**
	 * [INIT]ステータスの[DataPanel]ブロックのモードの設定
	 */
	protected static void statusInitINIT_DataPanel(FSBAP0690 p){

	}

	/**
	 * [INIT]ステータスの[TableHdr]ブロックのモードの設定
	 */
	protected static void statusInitINIT_TableHdr(FSBAP0690 p){
		p.TableHdr_search_settings_id.putMode(p, INIT, MCMode.INVISIBLE);
		p.TableHdr_search_settings_nm.putMode(p, INIT, MCMode.READ_ONLY);
		p.TableHdr_location_settings_id.putMode(p, INIT, MCMode.INVISIBLE);
		p.TableHdr_location_settings_nm.putMode(p, INIT, MCMode.READ_ONLY);

	}

	/**
	 * [INIT]ステータスの[TableDtl]ブロックのモードの設定
	 */
	protected static void statusInitINIT_TableDtl(FSBAP0690 p){
		p.columnTableDtl_table_nm.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnTableDtl_column_order_id.putMode(p, INIT, MCMode.INVISIBLE);
		p.columnTableDtl_column_order_nm.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnTableDtl_sort_id.putMode(p, INIT, MCMode.INVISIBLE);
		p.columnTableDtl_sort_nm.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnTableDtl_filter_id.putMode(p, INIT, MCMode.INVISIBLE);
		p.columnTableDtl_filter_nm.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnTableDtl_signal_id.putMode(p, INIT, MCMode.INVISIBLE);
		p.columnTableDtl_signal_nm.putMode(p, INIT, MCMode.READ_ONLY);

	}

	/**
	 * [INIT]ステータスの[BtnSettings]ブロックのモードの設定
	 */
	protected static void statusInitINIT_BtnSettings(FSBAP0690 p){
		p.BtnSettings_searchSettings.putMode(p, INIT, MCMode.READ_ONLY);
		p.BtnSettings_locationSettings.putMode(p, INIT, MCMode.READ_ONLY);
		p.BtnSettings_columnOrderSettings.putMode(p, INIT, MCMode.READ_ONLY);
		p.BtnSettings_sortSettings.putMode(p, INIT, MCMode.READ_ONLY);
		p.BtnSettings_filterSettings.putMode(p, INIT, MCMode.READ_ONLY);
		p.BtnSettings_signalSettings.putMode(p, INIT, MCMode.READ_ONLY);

	}

	/**
	 * [INIT]ステータスの[InfoHdr]ブロックのモードの設定
	 */
	protected static void statusInitINIT_InfoHdr(FSBAP0690 p){
		p.InfoHdr_per_grp_nm.putMode(p, INIT, MCMode.READ_ONLY);
		p.InfoHdr_remark.putMode(p, INIT, MCMode.READ_ONLY);

	}

	/**
	 * [INIT]ステータスの[InfoBtn]ブロックのモードの設定
	 */
	protected static void statusInitINIT_InfoBtn(FSBAP0690 p){
		p.InfoBtn_upd.putMode(p, INIT, MCMode.DISABLE);
		p.InfoBtn_upd_ext.putMode(p, INIT, MCMode.INVISIBLE);
		p.InfoBtn_upd_sys.putMode(p, INIT, MCMode.INVISIBLE);

	}

	/**
	 * [INIT]ステータスの[InfoScreen]ブロックのモードの設定
	 */
	protected static void statusInitINIT_InfoScreen(FSBAP0690 p){
		p.InfoScreen_par_screen_nm_p_PPanel.putStatus(INIT, mcframe.clientFSUB.FSUBP0080.FSUBP_ParScreenNm_H.READ_ONLY);

	}

	/**
	 * [EDITABLE]ステータスの[Setting]ブロックのモードの設定
	 */
	protected static void statusInitEDITABLE_Setting(FSBAP0690 p){
		p.Setting_setting_PPanel.putStatus(EDITABLE, mcframe.clientFSUB.FSUBP0090.FSUBP_SettingUnit_H.REQUIRED);

	}

	/**
	 * [EDITABLE]ステータスの[GrpPanel]ブロックのモードの設定
	 */
	protected static void statusInitEDITABLE_GrpPanel(FSBAP0690 p){

	}

	/**
	 * [EDITABLE]ステータスの[GrpDtl]ブロックのモードの設定
	 */
	protected static void statusInitEDITABLE_GrpDtl(FSBAP0690 p){
		p.columnGrpDtl_setting_unit_type.putMode(p, EDITABLE, MCMode.INVISIBLE);
		p.columnGrpDtl_setting_unit_type_nm.putMode(p, EDITABLE, MCMode.READ_ONLY);
		p.columnGrpDtl_per_grp_id.putMode(p, EDITABLE, MCMode.INVISIBLE);
		p.columnGrpDtl_per_grp_nm.putMode(p, EDITABLE, MCMode.READ_ONLY);
		p.columnGrpDtl_search_settings_id.putMode(p, EDITABLE, MCMode.INVISIBLE);
		p.columnGrpDtl_search_settings_nm.putMode(p, EDITABLE, MCMode.INVISIBLE);
		p.columnGrpDtl_location_settings_id.putMode(p, EDITABLE, MCMode.INVISIBLE);
		p.columnGrpDtl_location_settings_nm.putMode(p, EDITABLE, MCMode.INVISIBLE);
		p.columnGrpDtl_remark.putMode(p, EDITABLE, MCMode.READ_ONLY);

	}

	/**
	 * [EDITABLE]ステータスの[GrpDtlBtn]ブロックのモードの設定
	 */
	protected static void statusInitEDITABLE_GrpDtlBtn(FSBAP0690 p){
		p.GrpDtlBtn_radd.putMode(p, EDITABLE, MCMode.ENABLE);
		p.GrpDtlBtn_rdel.putMode(p, EDITABLE, MCMode.ENABLE);
		p.GrpDtlBtn_rcopy.putMode(p, EDITABLE, MCMode.ENABLE);

	}

	/**
	 * [EDITABLE]ステータスの[DataPanel]ブロックのモードの設定
	 */
	protected static void statusInitEDITABLE_DataPanel(FSBAP0690 p){

	}

	/**
	 * [EDITABLE]ステータスの[TableHdr]ブロックのモードの設定
	 */
	protected static void statusInitEDITABLE_TableHdr(FSBAP0690 p){
		p.TableHdr_search_settings_id.putMode(p, EDITABLE, MCMode.INVISIBLE);
		p.TableHdr_search_settings_nm.putMode(p, EDITABLE, MCMode.ENABLE);
		p.TableHdr_location_settings_id.putMode(p, EDITABLE, MCMode.INVISIBLE);
		p.TableHdr_location_settings_nm.putMode(p, EDITABLE, MCMode.ENABLE);

	}

	/**
	 * [EDITABLE]ステータスの[TableDtl]ブロックのモードの設定
	 */
	protected static void statusInitEDITABLE_TableDtl(FSBAP0690 p){
		p.columnTableDtl_table_nm.putMode(p, EDITABLE, MCMode.READ_ONLY);
		p.columnTableDtl_column_order_id.putMode(p, EDITABLE, MCMode.INVISIBLE);
		p.columnTableDtl_column_order_nm.putMode(p, EDITABLE, MCMode.ENABLE);
		p.columnTableDtl_sort_id.putMode(p, EDITABLE, MCMode.INVISIBLE);
		p.columnTableDtl_sort_nm.putMode(p, EDITABLE, MCMode.ENABLE);
		p.columnTableDtl_filter_id.putMode(p, EDITABLE, MCMode.INVISIBLE);
		p.columnTableDtl_filter_nm.putMode(p, EDITABLE, MCMode.ENABLE);
		p.columnTableDtl_signal_id.putMode(p, EDITABLE, MCMode.INVISIBLE);
		p.columnTableDtl_signal_nm.putMode(p, EDITABLE, MCMode.ENABLE);

	}

	/**
	 * [EDITABLE]ステータスの[BtnSettings]ブロックのモードの設定
	 */
	protected static void statusInitEDITABLE_BtnSettings(FSBAP0690 p){
		p.BtnSettings_searchSettings.putMode(p, EDITABLE, MCMode.ENABLE);
		p.BtnSettings_locationSettings.putMode(p, EDITABLE, MCMode.ENABLE);
		p.BtnSettings_columnOrderSettings.putMode(p, EDITABLE, MCMode.ENABLE);
		p.BtnSettings_sortSettings.putMode(p, EDITABLE, MCMode.ENABLE);
		p.BtnSettings_filterSettings.putMode(p, EDITABLE, MCMode.ENABLE);
		p.BtnSettings_signalSettings.putMode(p, EDITABLE, MCMode.ENABLE);

	}

	/**
	 * [EDITABLE]ステータスの[InfoHdr]ブロックのモードの設定
	 */
	protected static void statusInitEDITABLE_InfoHdr(FSBAP0690 p){
		p.InfoHdr_per_grp_nm.putMode(p, EDITABLE, MCMode.REQUIRED);
		p.InfoHdr_remark.putMode(p, EDITABLE, MCMode.ENABLE);

	}

	/**
	 * [EDITABLE]ステータスの[InfoBtn]ブロックのモードの設定
	 */
	protected static void statusInitEDITABLE_InfoBtn(FSBAP0690 p){
		p.InfoBtn_upd.putMode(p, EDITABLE, MCMode.ENABLE);

	}

	/**
	 * [EDITABLE]ステータスの[InfoScreen]ブロックのモードの設定
	 */
	protected static void statusInitEDITABLE_InfoScreen(FSBAP0690 p){
		p.InfoScreen_par_screen_nm_p_PPanel.putStatus(EDITABLE, mcframe.clientFSUB.FSUBP0080.FSUBP_ParScreenNm_H.READ_ONLY);

	}

	/**
	 * [DISABLE]ステータスの[Setting]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_Setting(FSBAP0690 p){
		p.Setting_setting_PPanel.putStatus(DISABLE, mcframe.clientFSUB.FSUBP0090.FSUBP_SettingUnit_H.REQUIRED);

	}

	/**
	 * [DISABLE]ステータスの[GrpPanel]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_GrpPanel(FSBAP0690 p){

	}

	/**
	 * [DISABLE]ステータスの[GrpDtl]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_GrpDtl(FSBAP0690 p){
		p.columnGrpDtl_setting_unit_type.putMode(p, DISABLE, MCMode.INVISIBLE);
		p.columnGrpDtl_setting_unit_type_nm.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnGrpDtl_per_grp_id.putMode(p, DISABLE, MCMode.INVISIBLE);
		p.columnGrpDtl_per_grp_nm.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnGrpDtl_search_settings_id.putMode(p, DISABLE, MCMode.INVISIBLE);
		p.columnGrpDtl_search_settings_nm.putMode(p, DISABLE, MCMode.INVISIBLE);
		p.columnGrpDtl_location_settings_id.putMode(p, DISABLE, MCMode.INVISIBLE);
		p.columnGrpDtl_location_settings_nm.putMode(p, DISABLE, MCMode.INVISIBLE);
		p.columnGrpDtl_remark.putMode(p, DISABLE, MCMode.READ_ONLY);

	}

	/**
	 * [DISABLE]ステータスの[GrpDtlBtn]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_GrpDtlBtn(FSBAP0690 p){
		p.GrpDtlBtn_radd.putMode(p, DISABLE, MCMode.ENABLE);
		p.GrpDtlBtn_rdel.putMode(p, DISABLE, MCMode.DISABLE);
		p.GrpDtlBtn_rcopy.putMode(p, DISABLE, MCMode.ENABLE);

	}

	/**
	 * [DISABLE]ステータスの[DataPanel]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_DataPanel(FSBAP0690 p){

	}

	/**
	 * [DISABLE]ステータスの[TableHdr]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_TableHdr(FSBAP0690 p){
		p.TableHdr_search_settings_id.putMode(p, DISABLE, MCMode.INVISIBLE);
		p.TableHdr_search_settings_nm.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.TableHdr_location_settings_id.putMode(p, DISABLE, MCMode.INVISIBLE);
		p.TableHdr_location_settings_nm.putMode(p, DISABLE, MCMode.READ_ONLY);

	}

	/**
	 * [DISABLE]ステータスの[TableDtl]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_TableDtl(FSBAP0690 p){
		p.columnTableDtl_table_nm.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnTableDtl_column_order_id.putMode(p, DISABLE, MCMode.INVISIBLE);
		p.columnTableDtl_column_order_nm.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnTableDtl_sort_id.putMode(p, DISABLE, MCMode.INVISIBLE);
		p.columnTableDtl_sort_nm.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnTableDtl_filter_id.putMode(p, DISABLE, MCMode.INVISIBLE);
		p.columnTableDtl_filter_nm.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnTableDtl_signal_id.putMode(p, DISABLE, MCMode.INVISIBLE);
		p.columnTableDtl_signal_nm.putMode(p, DISABLE, MCMode.READ_ONLY);

	}

	/**
	 * [DISABLE]ステータスの[BtnSettings]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_BtnSettings(FSBAP0690 p){
		p.BtnSettings_searchSettings.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.BtnSettings_locationSettings.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.BtnSettings_columnOrderSettings.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.BtnSettings_sortSettings.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.BtnSettings_filterSettings.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.BtnSettings_signalSettings.putMode(p, DISABLE, MCMode.READ_ONLY);

	}

	/**
	 * [DISABLE]ステータスの[InfoHdr]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_InfoHdr(FSBAP0690 p){
		p.InfoHdr_per_grp_nm.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.InfoHdr_remark.putMode(p, DISABLE, MCMode.READ_ONLY);

	}

	/**
	 * [DISABLE]ステータスの[InfoBtn]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_InfoBtn(FSBAP0690 p){
		p.InfoBtn_upd.putMode(p, DISABLE, MCMode.DISABLE);
		p.InfoBtn_upd_ext.putMode(p, DISABLE, MCMode.INVISIBLE);
		p.InfoBtn_upd_sys.putMode(p, DISABLE, MCMode.INVISIBLE);

	}

	/**
	 * [DISABLE]ステータスの[InfoScreen]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_InfoScreen(FSBAP0690 p){
		p.InfoScreen_par_screen_nm_p_PPanel.putStatus(DISABLE, mcframe.clientFSUB.FSUBP0080.FSUBP_ParScreenNm_H.READ_ONLY);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return INIT;
	}

	/**
	 * Table/Treeの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
		FSBAP0690_FW.setTableConfigGrpDtl((FSBAP0690)this);
		FSBAP0690_FW.setTableConfigTableDtl((FSBAP0690)this);
	}

	/**
	 * [GrpDtl]ブロックのTableの設定
	 */
	protected static void setTableConfigGrpDtl(FSBAP0690 p) {
		p.columnGrpDtl_setting_unit_type.setMeta(mcframe.clientFSBA.FSBAP0690.GrpDtlR.setting_unit_type_META);
		p.GrpDtlTable.addColumnConfig(p.columnGrpDtl_setting_unit_type);
		p.columnGrpDtl_setting_unit_type_nm.setMeta(mcframe.clientFSBA.FSBAP0690.GrpDtlR.setting_unit_type_nm_META);
		p.GrpDtlTable.addColumnConfig(p.columnGrpDtl_setting_unit_type_nm);
		p.columnGrpDtl_per_grp_id.setMeta(mcframe.clientFSBA.FSBAP0690.GrpDtlR.per_grp_id_META);
		p.GrpDtlTable.addColumnConfig(p.columnGrpDtl_per_grp_id);
		p.columnGrpDtl_per_grp_nm.setMeta(mcframe.clientFSBA.FSBAP0690.GrpDtlR.per_grp_nm_META);
		p.GrpDtlTable.addColumnConfig(p.columnGrpDtl_per_grp_nm);
		p.columnGrpDtl_search_settings_id.setMeta(mcframe.clientFSBA.FSBAP0690.GrpDtlR.search_settings_id_META);
		p.GrpDtlTable.addColumnConfig(p.columnGrpDtl_search_settings_id);
		p.columnGrpDtl_search_settings_nm.setMeta(mcframe.clientFSBA.FSBAP0690.GrpDtlR.search_settings_nm_META);
		p.GrpDtlTable.addColumnConfig(p.columnGrpDtl_search_settings_nm);
		p.columnGrpDtl_location_settings_id.setMeta(mcframe.clientFSBA.FSBAP0690.GrpDtlR.location_settings_id_META);
		p.GrpDtlTable.addColumnConfig(p.columnGrpDtl_location_settings_id);
		p.columnGrpDtl_location_settings_nm.setMeta(mcframe.clientFSBA.FSBAP0690.GrpDtlR.location_settings_nm_META);
		p.GrpDtlTable.addColumnConfig(p.columnGrpDtl_location_settings_nm);
		p.columnGrpDtl_remark.setMeta(mcframe.clientFSBA.FSBAP0690.GrpDtlR.remark_META);
		p.GrpDtlTable.addColumnConfig(p.columnGrpDtl_remark);
	}

	/**
	 * [TableDtl]ブロックのTableの設定
	 */
	protected static void setTableConfigTableDtl(FSBAP0690 p) {
		p.columnTableDtl_table_nm.setMeta(mcframe.clientFSBA.FSBAP0690.TableDtlR.table_nm_META);
		p.TableDtlTable.addColumnConfig(p.columnTableDtl_table_nm);
		p.columnTableDtl_column_order_id.setMeta(mcframe.clientFSBA.FSBAP0690.TableDtlR.column_order_id_META);
		p.TableDtlTable.addColumnConfig(p.columnTableDtl_column_order_id);
		p.columnTableDtl_column_order_nm.setMeta(mcframe.clientFSBA.FSBAP0690.TableDtlR.column_order_nm_META);
		p.columnTableDtl_column_order_nm.addLinkBeans(p.columnTableDtl_column_order_id);
		p.TableDtlTable.addColumnConfig(p.columnTableDtl_column_order_nm);
		p.columnTableDtl_sort_id.setMeta(mcframe.clientFSBA.FSBAP0690.TableDtlR.sort_id_META);
		p.TableDtlTable.addColumnConfig(p.columnTableDtl_sort_id);
		p.columnTableDtl_sort_nm.setMeta(mcframe.clientFSBA.FSBAP0690.TableDtlR.sort_nm_META);
		p.columnTableDtl_sort_nm.addLinkBeans(p.columnTableDtl_sort_id);
		p.TableDtlTable.addColumnConfig(p.columnTableDtl_sort_nm);
		p.columnTableDtl_filter_id.setMeta(mcframe.clientFSBA.FSBAP0690.TableDtlR.filter_id_META);
		p.TableDtlTable.addColumnConfig(p.columnTableDtl_filter_id);
		p.columnTableDtl_filter_nm.setMeta(mcframe.clientFSBA.FSBAP0690.TableDtlR.filter_nm_META);
		p.columnTableDtl_filter_nm.addLinkBeans(p.columnTableDtl_filter_id);
		p.TableDtlTable.addColumnConfig(p.columnTableDtl_filter_nm);
		p.columnTableDtl_signal_id.setMeta(mcframe.clientFSBA.FSBAP0690.TableDtlR.signal_id_META);
		p.TableDtlTable.addColumnConfig(p.columnTableDtl_signal_id);
		p.columnTableDtl_signal_nm.setMeta(mcframe.clientFSBA.FSBAP0690.TableDtlR.signal_nm_META);
		p.columnTableDtl_signal_nm.addLinkBeans(p.columnTableDtl_signal_id);
		p.TableDtlTable.addColumnConfig(p.columnTableDtl_signal_nm);
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
		TableHdr_search_settings_nm.setListVisibleColumn(MCListLogic.getViewColumnName());
		TableHdr_search_settings_nm.getListConfig().setPutter(getTableHdr_search_settings_nm_ListPutter());
		TableHdr_location_settings_nm.setListVisibleColumn(MCListLogic.getViewColumnName());
		TableHdr_location_settings_nm.getListConfig().setPutter(getTableHdr_location_settings_nm_ListPutter());
		columnTableDtl_column_order_nm.setListVisibleColumn(MCListLogic.getViewColumnName());
		columnTableDtl_column_order_nm.getListConfig().setPutter(getTableDtl_column_order_nm_ListPutter());
		columnTableDtl_sort_nm.setListVisibleColumn(MCListLogic.getViewColumnName());
		columnTableDtl_sort_nm.getListConfig().setPutter(getTableDtl_sort_nm_ListPutter());
		columnTableDtl_filter_nm.setListVisibleColumn(MCListLogic.getViewColumnName());
		columnTableDtl_filter_nm.getListConfig().setPutter(getTableDtl_filter_nm_ListPutter());
		columnTableDtl_signal_nm.setListVisibleColumn(MCListLogic.getViewColumnName());
		columnTableDtl_signal_nm.getListConfig().setPutter(getTableDtl_signal_nm_ListPutter());
	}

	/**
	 * この画面を[INIT]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setINITStatus() {
		status = INIT;
		setAllStatus(status);
	}

	/**
	 * この画面を[EDITABLE]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setEDITABLEStatus() {
		status = EDITABLE;
		setAllStatus(status);
	}

	/**
	 * この画面を[DISABLE]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setDISABLEStatus() {
		status = DISABLE;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (INIT.equals(status)) {
			setINITStatus();
		}
		else if (EDITABLE.equals(status)) {
			setEDITABLEStatus();
		}
		else if (DISABLE.equals(status)) {
			setDISABLEStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * [TableHdr_search_settings_nm_ListPutter]の作成
	 */
	protected MCListPutter createTableHdr_search_settings_nm_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("FS.FSUAP0010.SearchCndID");
		return lp;
	}
	 
	/**
	 * [TableHdr_location_settings_nm_ListPutter]の作成
	 */
	protected MCListPutter createTableHdr_location_settings_nm_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("FS.FSUAP0010.LocationID");
		return lp;
	}
	 
	/**
	 * [TableDtl_column_order_nm_ListPutter]の作成
	 */
	protected MCListPutter createTableDtl_column_order_nm_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("FS.FSUAP0010.TableColumnOrderID");
		return lp;
	}
	 
	/**
	 * [TableDtl_sort_nm_ListPutter]の作成
	 */
	protected MCListPutter createTableDtl_sort_nm_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("FS.FSUAP0010.TableSortID");
		return lp;
	}
	 
	/**
	 * [TableDtl_filter_nm_ListPutter]の作成
	 */
	protected MCListPutter createTableDtl_filter_nm_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("FS.FSUAP0010.TableFilterID");
		return lp;
	}
	 
	/**
	 * [TableDtl_signal_nm_ListPutter]の作成
	 */
	protected MCListPutter createTableDtl_signal_nm_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("FS.FSUAP0010.TableSignalID");
		return lp;
	}
	 

	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		if(combo == TableHdr_search_settings_nm) return getTableHdr_search_settings_nm(row, info);
		if(combo == TableHdr_location_settings_nm) return getTableHdr_location_settings_nm(row, info);
		if(combo == columnTableDtl_column_order_nm) return getTableDtl_column_order_nm(row, info);
		if(combo == columnTableDtl_sort_nm) return getTableDtl_sort_nm(row, info);
		if(combo == columnTableDtl_filter_nm) return getTableDtl_filter_nm(row, info);
		if(combo == columnTableDtl_signal_nm) return getTableDtl_signal_nm(row, info);
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == GrpDtlBtn_radd) doGrpDtlBtn_radd(info);
		else if (ap == GrpDtlBtn_rdel) doGrpDtlBtn_rdel(info);
		else if (ap == GrpDtlBtn_rcopy) doGrpDtlBtn_rcopy(info);
		else if (ap == BtnSettings_searchSettings) doBtnSettings_searchSettings(info);
		else if (ap == BtnSettings_locationSettings) doBtnSettings_locationSettings(info);
		else if (ap == BtnSettings_columnOrderSettings) doBtnSettings_columnOrderSettings(info);
		else if (ap == BtnSettings_sortSettings) doBtnSettings_sortSettings(info);
		else if (ap == BtnSettings_filterSettings) doBtnSettings_filterSettings(info);
		else if (ap == BtnSettings_signalSettings) doBtnSettings_signalSettings(info);
		else if (ap == InfoBtn_upd) doInfoBtn_upd(info);
		else if (ap == InfoBtn_upd_ext) doInfoBtn_upd_ext(info);
		else if (ap == InfoBtn_upd_sys) doInfoBtn_upd_sys(info);
	}

	/**
	 * [GrpDtlBtn]パネルの[radd]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doGrpDtlBtn_radd(MCEventInfo info);

	/**
	 * [GrpDtlBtn]パネルの[rdel]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doGrpDtlBtn_rdel(MCEventInfo info);

	/**
	 * [GrpDtlBtn]パネルの[rcopy]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doGrpDtlBtn_rcopy(MCEventInfo info);

	/**
	 * [BtnSettings]パネルの[searchSettings]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtnSettings_searchSettings(MCEventInfo info);

	/**
	 * [BtnSettings]パネルの[locationSettings]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtnSettings_locationSettings(MCEventInfo info);

	/**
	 * [BtnSettings]パネルの[columnOrderSettings]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtnSettings_columnOrderSettings(MCEventInfo info);

	/**
	 * [BtnSettings]パネルの[sortSettings]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtnSettings_sortSettings(MCEventInfo info);

	/**
	 * [BtnSettings]パネルの[filterSettings]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtnSettings_filterSettings(MCEventInfo info);

	/**
	 * [BtnSettings]パネルの[signalSettings]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtnSettings_signalSettings(MCEventInfo info);

	/**
	 * [InfoBtn]パネルの[upd]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doInfoBtn_upd(MCEventInfo info);

	/**
	 * [InfoBtn]パネルの[upd_ext]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doInfoBtn_upd_ext(MCEventInfo info);

	/**
	 * [InfoBtn]パネルの[upd_sys]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doInfoBtn_upd_sys(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == GrpDtlTable) return doGrpDtl_VC(info);
		if (vc == TableDtlTable) return doTableDtl_VC(info);
		if (vc == columnGrpDtl_setting_unit_type) return doGrpDtl_setting_unit_type_VC(info);
		if (vc == columnGrpDtl_setting_unit_type_nm) return doGrpDtl_setting_unit_type_nm_VC(info);
		if (vc == columnGrpDtl_per_grp_id) return doGrpDtl_per_grp_id_VC(info);
		if (vc == columnGrpDtl_per_grp_nm) return doGrpDtl_per_grp_nm_VC(info);
		if (vc == columnGrpDtl_search_settings_id) return doGrpDtl_search_settings_id_VC(info);
		if (vc == columnGrpDtl_search_settings_nm) return doGrpDtl_search_settings_nm_VC(info);
		if (vc == columnGrpDtl_location_settings_id) return doGrpDtl_location_settings_id_VC(info);
		if (vc == columnGrpDtl_location_settings_nm) return doGrpDtl_location_settings_nm_VC(info);
		if (vc == columnGrpDtl_remark) return doGrpDtl_remark_VC(info);
		if (vc == TableHdr_search_settings_id) return doTableHdr_search_settings_id_VC(info);
		if (vc == TableHdr_search_settings_nm) return doTableHdr_search_settings_nm_VC(info);
		if (vc == TableHdr_location_settings_id) return doTableHdr_location_settings_id_VC(info);
		if (vc == TableHdr_location_settings_nm) return doTableHdr_location_settings_nm_VC(info);
		if (vc == columnTableDtl_table_nm) return doTableDtl_table_nm_VC(info);
		if (vc == columnTableDtl_column_order_id) return doTableDtl_column_order_id_VC(info);
		if (vc == columnTableDtl_column_order_nm) return doTableDtl_column_order_nm_VC(info);
		if (vc == columnTableDtl_sort_id) return doTableDtl_sort_id_VC(info);
		if (vc == columnTableDtl_sort_nm) return doTableDtl_sort_nm_VC(info);
		if (vc == columnTableDtl_filter_id) return doTableDtl_filter_id_VC(info);
		if (vc == columnTableDtl_filter_nm) return doTableDtl_filter_nm_VC(info);
		if (vc == columnTableDtl_signal_id) return doTableDtl_signal_id_VC(info);
		if (vc == columnTableDtl_signal_nm) return doTableDtl_signal_nm_VC(info);
		if (vc == InfoHdr_per_grp_nm) return doInfoHdr_per_grp_nm_VC(info);
		if (vc == InfoHdr_remark) return doInfoHdr_remark_VC(info);
		return true;
	}

	/**
	 * [GrpDtl]Tableの選択行が変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doGrpDtl_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [TableDtl]Tableの選択行が変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doTableDtl_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [GrpDtl]パネルの[setting_unit_type]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doGrpDtl_setting_unit_type_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [GrpDtl]パネルの[setting_unit_type_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doGrpDtl_setting_unit_type_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [GrpDtl]パネルの[per_grp_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doGrpDtl_per_grp_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [GrpDtl]パネルの[per_grp_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doGrpDtl_per_grp_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [GrpDtl]パネルの[search_settings_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doGrpDtl_search_settings_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [GrpDtl]パネルの[search_settings_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doGrpDtl_search_settings_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [GrpDtl]パネルの[location_settings_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doGrpDtl_location_settings_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [GrpDtl]パネルの[location_settings_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doGrpDtl_location_settings_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [GrpDtl]パネルの[remark]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doGrpDtl_remark_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [TableHdr]パネルの[search_settings_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doTableHdr_search_settings_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [TableHdr]パネルの[search_settings_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doTableHdr_search_settings_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [TableHdr]パネルの[location_settings_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doTableHdr_location_settings_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [TableHdr]パネルの[location_settings_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doTableHdr_location_settings_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [TableDtl]パネルの[table_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doTableDtl_table_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [TableDtl]パネルの[column_order_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doTableDtl_column_order_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [TableDtl]パネルの[column_order_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doTableDtl_column_order_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [TableDtl]パネルの[sort_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doTableDtl_sort_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [TableDtl]パネルの[sort_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doTableDtl_sort_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [TableDtl]パネルの[filter_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doTableDtl_filter_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [TableDtl]パネルの[filter_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doTableDtl_filter_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [TableDtl]パネルの[signal_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doTableDtl_signal_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [TableDtl]パネルの[signal_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doTableDtl_signal_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoHdr]パネルの[per_grp_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoHdr_per_grp_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoHdr]パネルの[remark]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoHdr_remark_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == GrpDtlTable) doGrpDtl_NC(info);
		else if (nc == TableDtlTable) doTableDtl_NC(info);
		else if (nc == columnGrpDtl_setting_unit_type) doGrpDtl_setting_unit_type_NC(info);
		else if (nc == columnGrpDtl_setting_unit_type_nm) doGrpDtl_setting_unit_type_nm_NC(info);
		else if (nc == columnGrpDtl_per_grp_id) doGrpDtl_per_grp_id_NC(info);
		else if (nc == columnGrpDtl_per_grp_nm) doGrpDtl_per_grp_nm_NC(info);
		else if (nc == columnGrpDtl_search_settings_id) doGrpDtl_search_settings_id_NC(info);
		else if (nc == columnGrpDtl_search_settings_nm) doGrpDtl_search_settings_nm_NC(info);
		else if (nc == columnGrpDtl_location_settings_id) doGrpDtl_location_settings_id_NC(info);
		else if (nc == columnGrpDtl_location_settings_nm) doGrpDtl_location_settings_nm_NC(info);
		else if (nc == columnGrpDtl_remark) doGrpDtl_remark_NC(info);
		else if (nc == TableHdr_search_settings_id) doTableHdr_search_settings_id_NC(info);
		else if (nc == TableHdr_search_settings_nm) doTableHdr_search_settings_nm_NC(info);
		else if (nc == TableHdr_location_settings_id) doTableHdr_location_settings_id_NC(info);
		else if (nc == TableHdr_location_settings_nm) doTableHdr_location_settings_nm_NC(info);
		else if (nc == columnTableDtl_table_nm) doTableDtl_table_nm_NC(info);
		else if (nc == columnTableDtl_column_order_id) doTableDtl_column_order_id_NC(info);
		else if (nc == columnTableDtl_column_order_nm) doTableDtl_column_order_nm_NC(info);
		else if (nc == columnTableDtl_sort_id) doTableDtl_sort_id_NC(info);
		else if (nc == columnTableDtl_sort_nm) doTableDtl_sort_nm_NC(info);
		else if (nc == columnTableDtl_filter_id) doTableDtl_filter_id_NC(info);
		else if (nc == columnTableDtl_filter_nm) doTableDtl_filter_nm_NC(info);
		else if (nc == columnTableDtl_signal_id) doTableDtl_signal_id_NC(info);
		else if (nc == columnTableDtl_signal_nm) doTableDtl_signal_nm_NC(info);
		else if (nc == InfoHdr_per_grp_nm) doInfoHdr_per_grp_nm_NC(info);
		else if (nc == InfoHdr_remark) doInfoHdr_remark_NC(info);
	}

	/**
	 * [GrpDtl]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doGrpDtl_NC(MCEventInfo info){
	}

	/**
	 * [TableDtl]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableDtl_NC(MCEventInfo info){
	}

	/**
	 * [GrpDtl]パネルの[setting_unit_type]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doGrpDtl_setting_unit_type_NC(MCEventInfo info){
	}

	/**
	 * [GrpDtl]パネルの[setting_unit_type_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doGrpDtl_setting_unit_type_nm_NC(MCEventInfo info){
	}

	/**
	 * [GrpDtl]パネルの[per_grp_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doGrpDtl_per_grp_id_NC(MCEventInfo info){
	}

	/**
	 * [GrpDtl]パネルの[per_grp_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doGrpDtl_per_grp_nm_NC(MCEventInfo info){
	}

	/**
	 * [GrpDtl]パネルの[search_settings_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doGrpDtl_search_settings_id_NC(MCEventInfo info){
	}

	/**
	 * [GrpDtl]パネルの[search_settings_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doGrpDtl_search_settings_nm_NC(MCEventInfo info){
	}

	/**
	 * [GrpDtl]パネルの[location_settings_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doGrpDtl_location_settings_id_NC(MCEventInfo info){
	}

	/**
	 * [GrpDtl]パネルの[location_settings_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doGrpDtl_location_settings_nm_NC(MCEventInfo info){
	}

	/**
	 * [GrpDtl]パネルの[remark]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doGrpDtl_remark_NC(MCEventInfo info){
	}

	/**
	 * [TableHdr]パネルの[search_settings_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableHdr_search_settings_id_NC(MCEventInfo info){
	}

	/**
	 * [TableHdr]パネルの[search_settings_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableHdr_search_settings_nm_NC(MCEventInfo info){
	}

	/**
	 * [TableHdr]パネルの[location_settings_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableHdr_location_settings_id_NC(MCEventInfo info){
	}

	/**
	 * [TableHdr]パネルの[location_settings_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableHdr_location_settings_nm_NC(MCEventInfo info){
	}

	/**
	 * [TableDtl]パネルの[table_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableDtl_table_nm_NC(MCEventInfo info){
	}

	/**
	 * [TableDtl]パネルの[column_order_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableDtl_column_order_id_NC(MCEventInfo info){
	}

	/**
	 * [TableDtl]パネルの[column_order_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableDtl_column_order_nm_NC(MCEventInfo info){
	}

	/**
	 * [TableDtl]パネルの[sort_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableDtl_sort_id_NC(MCEventInfo info){
	}

	/**
	 * [TableDtl]パネルの[sort_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableDtl_sort_nm_NC(MCEventInfo info){
	}

	/**
	 * [TableDtl]パネルの[filter_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableDtl_filter_id_NC(MCEventInfo info){
	}

	/**
	 * [TableDtl]パネルの[filter_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableDtl_filter_nm_NC(MCEventInfo info){
	}

	/**
	 * [TableDtl]パネルの[signal_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableDtl_signal_id_NC(MCEventInfo info){
	}

	/**
	 * [TableDtl]パネルの[signal_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableDtl_signal_nm_NC(MCEventInfo info){
	}

	/**
	 * [InfoHdr]パネルの[per_grp_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoHdr_per_grp_nm_NC(MCEventInfo info){
	}

	/**
	 * [InfoHdr]パネルの[remark]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoHdr_remark_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == GrpDtlTable) doGrpDtl_NE(info);
		else if (ne == TableDtlTable) doTableDtl_NE(info);
		else if (ne == columnGrpDtl_setting_unit_type) doGrpDtl_setting_unit_type_NE(info);
		else if (ne == columnGrpDtl_setting_unit_type_nm) doGrpDtl_setting_unit_type_nm_NE(info);
		else if (ne == columnGrpDtl_per_grp_id) doGrpDtl_per_grp_id_NE(info);
		else if (ne == columnGrpDtl_per_grp_nm) doGrpDtl_per_grp_nm_NE(info);
		else if (ne == columnGrpDtl_search_settings_id) doGrpDtl_search_settings_id_NE(info);
		else if (ne == columnGrpDtl_search_settings_nm) doGrpDtl_search_settings_nm_NE(info);
		else if (ne == columnGrpDtl_location_settings_id) doGrpDtl_location_settings_id_NE(info);
		else if (ne == columnGrpDtl_location_settings_nm) doGrpDtl_location_settings_nm_NE(info);
		else if (ne == columnGrpDtl_remark) doGrpDtl_remark_NE(info);
		else if (ne == TableHdr_search_settings_id) doTableHdr_search_settings_id_NE(info);
		else if (ne == TableHdr_search_settings_nm) doTableHdr_search_settings_nm_NE(info);
		else if (ne == TableHdr_location_settings_id) doTableHdr_location_settings_id_NE(info);
		else if (ne == TableHdr_location_settings_nm) doTableHdr_location_settings_nm_NE(info);
		else if (ne == columnTableDtl_table_nm) doTableDtl_table_nm_NE(info);
		else if (ne == columnTableDtl_column_order_id) doTableDtl_column_order_id_NE(info);
		else if (ne == columnTableDtl_column_order_nm) doTableDtl_column_order_nm_NE(info);
		else if (ne == columnTableDtl_sort_id) doTableDtl_sort_id_NE(info);
		else if (ne == columnTableDtl_sort_nm) doTableDtl_sort_nm_NE(info);
		else if (ne == columnTableDtl_filter_id) doTableDtl_filter_id_NE(info);
		else if (ne == columnTableDtl_filter_nm) doTableDtl_filter_nm_NE(info);
		else if (ne == columnTableDtl_signal_id) doTableDtl_signal_id_NE(info);
		else if (ne == columnTableDtl_signal_nm) doTableDtl_signal_nm_NE(info);
		else if (ne == InfoHdr_per_grp_nm) doInfoHdr_per_grp_nm_NE(info);
		else if (ne == InfoHdr_remark) doInfoHdr_remark_NE(info);
	}

	/**
	 * [GrpDtl]TableのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doGrpDtl_NE(MCEventInfo info){
	}

	/**
	 * [TableDtl]TableのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableDtl_NE(MCEventInfo info){
	}

	/**
	 * [GrpDtl]パネルの[setting_unit_type]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doGrpDtl_setting_unit_type_NE(MCEventInfo info){
	}

	/**
	 * [GrpDtl]パネルの[setting_unit_type_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doGrpDtl_setting_unit_type_nm_NE(MCEventInfo info){
	}

	/**
	 * [GrpDtl]パネルの[per_grp_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doGrpDtl_per_grp_id_NE(MCEventInfo info){
	}

	/**
	 * [GrpDtl]パネルの[per_grp_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doGrpDtl_per_grp_nm_NE(MCEventInfo info){
	}

	/**
	 * [GrpDtl]パネルの[search_settings_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doGrpDtl_search_settings_id_NE(MCEventInfo info){
	}

	/**
	 * [GrpDtl]パネルの[search_settings_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doGrpDtl_search_settings_nm_NE(MCEventInfo info){
	}

	/**
	 * [GrpDtl]パネルの[location_settings_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doGrpDtl_location_settings_id_NE(MCEventInfo info){
	}

	/**
	 * [GrpDtl]パネルの[location_settings_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doGrpDtl_location_settings_nm_NE(MCEventInfo info){
	}

	/**
	 * [GrpDtl]パネルの[remark]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doGrpDtl_remark_NE(MCEventInfo info){
	}

	/**
	 * [TableHdr]パネルの[search_settings_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableHdr_search_settings_id_NE(MCEventInfo info){
	}

	/**
	 * [TableHdr]パネルの[search_settings_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableHdr_search_settings_nm_NE(MCEventInfo info){
	}

	/**
	 * [TableHdr]パネルの[location_settings_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableHdr_location_settings_id_NE(MCEventInfo info){
	}

	/**
	 * [TableHdr]パネルの[location_settings_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableHdr_location_settings_nm_NE(MCEventInfo info){
	}

	/**
	 * [TableDtl]パネルの[table_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableDtl_table_nm_NE(MCEventInfo info){
	}

	/**
	 * [TableDtl]パネルの[column_order_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableDtl_column_order_id_NE(MCEventInfo info){
	}

	/**
	 * [TableDtl]パネルの[column_order_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableDtl_column_order_nm_NE(MCEventInfo info){
	}

	/**
	 * [TableDtl]パネルの[sort_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableDtl_sort_id_NE(MCEventInfo info){
	}

	/**
	 * [TableDtl]パネルの[sort_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableDtl_sort_nm_NE(MCEventInfo info){
	}

	/**
	 * [TableDtl]パネルの[filter_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableDtl_filter_id_NE(MCEventInfo info){
	}

	/**
	 * [TableDtl]パネルの[filter_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableDtl_filter_nm_NE(MCEventInfo info){
	}

	/**
	 * [TableDtl]パネルの[signal_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableDtl_signal_id_NE(MCEventInfo info){
	}

	/**
	 * [TableDtl]パネルの[signal_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableDtl_signal_nm_NE(MCEventInfo info){
	}

	/**
	 * [InfoHdr]パネルの[per_grp_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoHdr_per_grp_nm_NE(MCEventInfo info){
	}

	/**
	 * [InfoHdr]パネルの[remark]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoHdr_remark_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == GrpDtlTable) doGrpDtl_NX(info);
		else if (nx == TableDtlTable) doTableDtl_NX(info);
		else if (nx == columnGrpDtl_setting_unit_type) doGrpDtl_setting_unit_type_NX(info);
		else if (nx == columnGrpDtl_setting_unit_type_nm) doGrpDtl_setting_unit_type_nm_NX(info);
		else if (nx == columnGrpDtl_per_grp_id) doGrpDtl_per_grp_id_NX(info);
		else if (nx == columnGrpDtl_per_grp_nm) doGrpDtl_per_grp_nm_NX(info);
		else if (nx == columnGrpDtl_search_settings_id) doGrpDtl_search_settings_id_NX(info);
		else if (nx == columnGrpDtl_search_settings_nm) doGrpDtl_search_settings_nm_NX(info);
		else if (nx == columnGrpDtl_location_settings_id) doGrpDtl_location_settings_id_NX(info);
		else if (nx == columnGrpDtl_location_settings_nm) doGrpDtl_location_settings_nm_NX(info);
		else if (nx == columnGrpDtl_remark) doGrpDtl_remark_NX(info);
		else if (nx == TableHdr_search_settings_id) doTableHdr_search_settings_id_NX(info);
		else if (nx == TableHdr_search_settings_nm) doTableHdr_search_settings_nm_NX(info);
		else if (nx == TableHdr_location_settings_id) doTableHdr_location_settings_id_NX(info);
		else if (nx == TableHdr_location_settings_nm) doTableHdr_location_settings_nm_NX(info);
		else if (nx == columnTableDtl_table_nm) doTableDtl_table_nm_NX(info);
		else if (nx == columnTableDtl_column_order_id) doTableDtl_column_order_id_NX(info);
		else if (nx == columnTableDtl_column_order_nm) doTableDtl_column_order_nm_NX(info);
		else if (nx == columnTableDtl_sort_id) doTableDtl_sort_id_NX(info);
		else if (nx == columnTableDtl_sort_nm) doTableDtl_sort_nm_NX(info);
		else if (nx == columnTableDtl_filter_id) doTableDtl_filter_id_NX(info);
		else if (nx == columnTableDtl_filter_nm) doTableDtl_filter_nm_NX(info);
		else if (nx == columnTableDtl_signal_id) doTableDtl_signal_id_NX(info);
		else if (nx == columnTableDtl_signal_nm) doTableDtl_signal_nm_NX(info);
		else if (nx == InfoHdr_per_grp_nm) doInfoHdr_per_grp_nm_NX(info);
		else if (nx == InfoHdr_remark) doInfoHdr_remark_NX(info);
	}

	/**
	 * [GrpDtl]TableのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doGrpDtl_NX(MCEventInfo info){
	}

	/**
	 * [TableDtl]TableのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableDtl_NX(MCEventInfo info){
	}

	/**
	 * [GrpDtl]パネルの[setting_unit_type]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doGrpDtl_setting_unit_type_NX(MCEventInfo info){
	}

	/**
	 * [GrpDtl]パネルの[setting_unit_type_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doGrpDtl_setting_unit_type_nm_NX(MCEventInfo info){
	}

	/**
	 * [GrpDtl]パネルの[per_grp_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doGrpDtl_per_grp_id_NX(MCEventInfo info){
	}

	/**
	 * [GrpDtl]パネルの[per_grp_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doGrpDtl_per_grp_nm_NX(MCEventInfo info){
	}

	/**
	 * [GrpDtl]パネルの[search_settings_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doGrpDtl_search_settings_id_NX(MCEventInfo info){
	}

	/**
	 * [GrpDtl]パネルの[search_settings_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doGrpDtl_search_settings_nm_NX(MCEventInfo info){
	}

	/**
	 * [GrpDtl]パネルの[location_settings_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doGrpDtl_location_settings_id_NX(MCEventInfo info){
	}

	/**
	 * [GrpDtl]パネルの[location_settings_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doGrpDtl_location_settings_nm_NX(MCEventInfo info){
	}

	/**
	 * [GrpDtl]パネルの[remark]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doGrpDtl_remark_NX(MCEventInfo info){
	}

	/**
	 * [TableHdr]パネルの[search_settings_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableHdr_search_settings_id_NX(MCEventInfo info){
	}

	/**
	 * [TableHdr]パネルの[search_settings_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableHdr_search_settings_nm_NX(MCEventInfo info){
	}

	/**
	 * [TableHdr]パネルの[location_settings_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableHdr_location_settings_id_NX(MCEventInfo info){
	}

	/**
	 * [TableHdr]パネルの[location_settings_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableHdr_location_settings_nm_NX(MCEventInfo info){
	}

	/**
	 * [TableDtl]パネルの[table_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableDtl_table_nm_NX(MCEventInfo info){
	}

	/**
	 * [TableDtl]パネルの[column_order_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableDtl_column_order_id_NX(MCEventInfo info){
	}

	/**
	 * [TableDtl]パネルの[column_order_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableDtl_column_order_nm_NX(MCEventInfo info){
	}

	/**
	 * [TableDtl]パネルの[sort_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableDtl_sort_id_NX(MCEventInfo info){
	}

	/**
	 * [TableDtl]パネルの[sort_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableDtl_sort_nm_NX(MCEventInfo info){
	}

	/**
	 * [TableDtl]パネルの[filter_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableDtl_filter_id_NX(MCEventInfo info){
	}

	/**
	 * [TableDtl]パネルの[filter_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableDtl_filter_nm_NX(MCEventInfo info){
	}

	/**
	 * [TableDtl]パネルの[signal_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableDtl_signal_id_NX(MCEventInfo info){
	}

	/**
	 * [TableDtl]パネルの[signal_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableDtl_signal_nm_NX(MCEventInfo info){
	}

	/**
	 * [InfoHdr]パネルの[per_grp_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoHdr_per_grp_nm_NX(MCEventInfo info){
	}

	/**
	 * [InfoHdr]パネルの[remark]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoHdr_remark_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == columnGrpDtl_setting_unit_type) doGrpDtl_setting_unit_type_LC(info);
		else if (lc == columnGrpDtl_setting_unit_type_nm) doGrpDtl_setting_unit_type_nm_LC(info);
		else if (lc == columnGrpDtl_per_grp_id) doGrpDtl_per_grp_id_LC(info);
		else if (lc == columnGrpDtl_per_grp_nm) doGrpDtl_per_grp_nm_LC(info);
		else if (lc == columnGrpDtl_search_settings_id) doGrpDtl_search_settings_id_LC(info);
		else if (lc == columnGrpDtl_search_settings_nm) doGrpDtl_search_settings_nm_LC(info);
		else if (lc == columnGrpDtl_location_settings_id) doGrpDtl_location_settings_id_LC(info);
		else if (lc == columnGrpDtl_location_settings_nm) doGrpDtl_location_settings_nm_LC(info);
		else if (lc == columnGrpDtl_remark) doGrpDtl_remark_LC(info);
		else if (lc == TableHdr_search_settings_id) doTableHdr_search_settings_id_LC(info);
		else if (lc == TableHdr_search_settings_nm) doTableHdr_search_settings_nm_LC(info);
		else if (lc == TableHdr_location_settings_id) doTableHdr_location_settings_id_LC(info);
		else if (lc == TableHdr_location_settings_nm) doTableHdr_location_settings_nm_LC(info);
		else if (lc == columnTableDtl_table_nm) doTableDtl_table_nm_LC(info);
		else if (lc == columnTableDtl_column_order_id) doTableDtl_column_order_id_LC(info);
		else if (lc == columnTableDtl_column_order_nm) doTableDtl_column_order_nm_LC(info);
		else if (lc == columnTableDtl_sort_id) doTableDtl_sort_id_LC(info);
		else if (lc == columnTableDtl_sort_nm) doTableDtl_sort_nm_LC(info);
		else if (lc == columnTableDtl_filter_id) doTableDtl_filter_id_LC(info);
		else if (lc == columnTableDtl_filter_nm) doTableDtl_filter_nm_LC(info);
		else if (lc == columnTableDtl_signal_id) doTableDtl_signal_id_LC(info);
		else if (lc == columnTableDtl_signal_nm) doTableDtl_signal_nm_LC(info);
		else if (lc == InfoHdr_per_grp_nm) doInfoHdr_per_grp_nm_LC(info);
		else if (lc == InfoHdr_remark) doInfoHdr_remark_LC(info);
	}

	/**
	 * [GrpDtl]パネルの[setting_unit_type]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doGrpDtl_setting_unit_type_LC(MCEventInfo info){
	}

	/**
	 * [GrpDtl]パネルの[setting_unit_type_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doGrpDtl_setting_unit_type_nm_LC(MCEventInfo info){
	}

	/**
	 * [GrpDtl]パネルの[per_grp_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doGrpDtl_per_grp_id_LC(MCEventInfo info){
	}

	/**
	 * [GrpDtl]パネルの[per_grp_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doGrpDtl_per_grp_nm_LC(MCEventInfo info){
	}

	/**
	 * [GrpDtl]パネルの[search_settings_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doGrpDtl_search_settings_id_LC(MCEventInfo info){
	}

	/**
	 * [GrpDtl]パネルの[search_settings_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doGrpDtl_search_settings_nm_LC(MCEventInfo info){
	}

	/**
	 * [GrpDtl]パネルの[location_settings_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doGrpDtl_location_settings_id_LC(MCEventInfo info){
	}

	/**
	 * [GrpDtl]パネルの[location_settings_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doGrpDtl_location_settings_nm_LC(MCEventInfo info){
	}

	/**
	 * [GrpDtl]パネルの[remark]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doGrpDtl_remark_LC(MCEventInfo info){
	}

	/**
	 * [TableHdr]パネルの[search_settings_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableHdr_search_settings_id_LC(MCEventInfo info){
	}

	/**
	 * [TableHdr]パネルの[search_settings_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableHdr_search_settings_nm_LC(MCEventInfo info){
	}

	/**
	 * [TableHdr]パネルの[location_settings_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableHdr_location_settings_id_LC(MCEventInfo info){
	}

	/**
	 * [TableHdr]パネルの[location_settings_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableHdr_location_settings_nm_LC(MCEventInfo info){
	}

	/**
	 * [TableDtl]パネルの[table_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableDtl_table_nm_LC(MCEventInfo info){
	}

	/**
	 * [TableDtl]パネルの[column_order_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableDtl_column_order_id_LC(MCEventInfo info){
	}

	/**
	 * [TableDtl]パネルの[column_order_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableDtl_column_order_nm_LC(MCEventInfo info){
	}

	/**
	 * [TableDtl]パネルの[sort_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableDtl_sort_id_LC(MCEventInfo info){
	}

	/**
	 * [TableDtl]パネルの[sort_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableDtl_sort_nm_LC(MCEventInfo info){
	}

	/**
	 * [TableDtl]パネルの[filter_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableDtl_filter_id_LC(MCEventInfo info){
	}

	/**
	 * [TableDtl]パネルの[filter_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableDtl_filter_nm_LC(MCEventInfo info){
	}

	/**
	 * [TableDtl]パネルの[signal_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableDtl_signal_id_LC(MCEventInfo info){
	}

	/**
	 * [TableDtl]パネルの[signal_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doTableDtl_signal_nm_LC(MCEventInfo info){
	}

	/**
	 * [InfoHdr]パネルの[per_grp_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoHdr_per_grp_nm_LC(MCEventInfo info){
	}

	/**
	 * [InfoHdr]パネルの[remark]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoHdr_remark_LC(MCEventInfo info){
	}

	/**
	 * コンボ／リストのリスト[TableHdr_search_settings_nm]の作成メソッド
	 */
	public MCList getTableHdr_search_settings_nm(MCRow row, MCEventInfo info){
		return ((mcframe.clientFSUA.FSUAP0010.FSUAP_List)MCListLogic.create("mcframe.clientFSUA.FSUAP0010.FSUAP_List", this)).getSearchCndID(row, info);
	}

	/**
	 * コンボ／リストのリスト[TableHdr_location_settings_nm]の作成メソッド
	 */
	public MCList getTableHdr_location_settings_nm(MCRow row, MCEventInfo info){
		return ((mcframe.clientFSUA.FSUAP0010.FSUAP_List)MCListLogic.create("mcframe.clientFSUA.FSUAP0010.FSUAP_List", this)).getLocationID(row, info);
	}

	/**
	 * コンボ／リストのリスト[columnTableDtl_column_order_nm]の作成メソッド
	 */
	public MCList getTableDtl_column_order_nm(MCRow row, MCEventInfo info){
		return ((mcframe.clientFSUA.FSUAP0010.FSUAP_List)MCListLogic.create("mcframe.clientFSUA.FSUAP0010.FSUAP_List", this)).getTableColumnOrderID(row, info);
	}

	/**
	 * コンボ／リストのリスト[columnTableDtl_sort_nm]の作成メソッド
	 */
	public MCList getTableDtl_sort_nm(MCRow row, MCEventInfo info){
		return ((mcframe.clientFSUA.FSUAP0010.FSUAP_List)MCListLogic.create("mcframe.clientFSUA.FSUAP0010.FSUAP_List", this)).getTableSortID(row, info);
	}

	/**
	 * コンボ／リストのリスト[columnTableDtl_filter_nm]の作成メソッド
	 */
	public MCList getTableDtl_filter_nm(MCRow row, MCEventInfo info){
		return ((mcframe.clientFSUA.FSUAP0010.FSUAP_List)MCListLogic.create("mcframe.clientFSUA.FSUAP0010.FSUAP_List", this)).getTableFilterID(row, info);
	}

	/**
	 * コンボ／リストのリスト[columnTableDtl_signal_nm]の作成メソッド
	 */
	public MCList getTableDtl_signal_nm(MCRow row, MCEventInfo info){
		return ((mcframe.clientFSUA.FSUAP0010.FSUAP_List)MCListLogic.create("mcframe.clientFSUA.FSUAP0010.FSUAP_List", this)).getTableSignalID(row, info);
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}