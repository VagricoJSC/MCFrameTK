package mcframe.clientFSBA.FSBAP0260;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBAP_Info_Edit_Ext"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP_Info_Edit_Ext_FW_A extends mcframe.clientFSBA.FSBAP0250.FSBAP_Info_Edit{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0260";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Search]ブロック関連のField定義
	// [Search]ブロックの項目のField定義
	// [Edit]ブロック関連のField定義
	// [Edit]ブロックの項目のField定義
	/** [INIT]モードを表す定数 */
	public static final String INIT = "INIT";
	/** [EDIT]モードを表す定数 */
	public static final String EDIT = "EDIT";
	/** [EDIT_DEL]モードを表す定数 */
	public static final String EDIT_DEL = "EDIT_DEL";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{INIT, EDIT, EDIT_DEL};
	
	/** [Search]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0260.SearchR aSearchR;
	/** [Edit]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0260.EditR aEditR;

	/**
	 * 項目コピーによってaSearchRを設定します。
	 *
	 * aSearchRのインスタンスは変更されません。
	 *
	 * @param row SearchR
	 */
	public void setSearchR(mcframe.clientFSBA.FSBAP0260.SearchR row) {
		if (row != null) {
			MCRow.copyall(getSearchR(), row);
		}
	}

	/**
	 * [Search]ブロックのコンテナaSearchRを返します。
	 *
	 * @return SearchR
	 */
	public mcframe.clientFSBA.FSBAP0260.SearchR getSearchR() {
		return aSearchR;
	}

	/**
	 * aSearchRを作成します。
	 *
	 * @return SearchR
	 */
	public mcframe.clientFSBA.FSBAP0260.SearchR createSearchR() {
		return mcframe.clientFSBA.FSBAP0260.SearchR.create();
	}

	/**
	 * 項目コピーによってaEditRを設定します。
	 *
	 * aEditRのインスタンスは変更されません。
	 *
	 * @param row EditR
	 */
	public void setEditR(mcframe.clientFSBA.FSBAP0260.EditR row) {
		if (row != null) {
			MCRow.copyall(getEditR(), row);
		}
	}

	/**
	 * [Edit]ブロックのコンテナaEditRを返します。
	 *
	 * @return EditR
	 */
	public mcframe.clientFSBA.FSBAP0260.EditR getEditR() {
		return aEditR;
	}

	/**
	 * aEditRを作成します。
	 *
	 * @return EditR
	 */
	public mcframe.clientFSBA.FSBAP0260.EditR createEditR() {
		return mcframe.clientFSBA.FSBAP0260.EditR.create();
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getSearchR())) ret.add(getSearchR());
		if(!MCCollectionUtil.contains(ret, getEditR())) ret.add(getEditR());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getSearchR()) return "Search";
		if(aCnt == getEditR()) return "Edit";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("Search")) return getSearchR();
		if(bId.equals("Edit")) return getEditR();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_Info_Edit_Ext_FW_A() {
		aSearchR = createSearchR();
		aEditR = createEditR();

	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_Info_Edit_Ext_FW_A(String name) {
		super(name);
		aSearchR = createSearchR();
		aEditR = createEditR();
	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP_Info_Edit_Ext_FW.jbCreateSearch((FSBAP_Info_Edit_Ext)this);
		FSBAP_Info_Edit_Ext_FW.jbCreateEdit((FSBAP_Info_Edit_Ext)this);
	}

	/**
	 * [Search]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateSearch(FSBAP_Info_Edit_Ext p) {
	}

	/**
	 * [Edit]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateEdit(FSBAP_Info_Edit_Ext p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}


	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP_Info_Edit_Ext create(){
		FSBAP_Info_Edit_Ext p = new FSBAP_Info_Edit_Ext();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}


	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP_Info_Edit_Ext_FW.jbfInitSearch((FSBAP_Info_Edit_Ext)this);
		FSBAP_Info_Edit_Ext_FW.jbfInitEdit((FSBAP_Info_Edit_Ext)this);
		FSBAP_Info_Edit_Ext_FW.jbInitSearch((FSBAP_Info_Edit_Ext)this);
		FSBAP_Info_Edit_Ext_FW.jbInitEdit((FSBAP_Info_Edit_Ext)this);
	}

	/**
	 * [Search]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitSearch(FSBAP_Info_Edit_Ext p) {
		// ブロック関連の初期化
		// ブロックの項目の初期化
	}

	/**
	 * [Edit]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitEdit(FSBAP_Info_Edit_Ext p) {
		// ブロック関連の初期化
		// ブロックの項目の初期化
	}

	/**
	 * [Search]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitSearch(FSBAP_Info_Edit_Ext p) {
		// ブロック関連の初期化
		p.SearchPanel.setValueCheck(false);
		p.SearchPanel.setExtValue(MCPanel.SRCH_CND_SETTING_PANEL, true);
		p.SearchPanel.setLayoutPosition("N");
		// ブロックの項目の初期化
	}

	/**
	 * [Edit]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitEdit(FSBAP_Info_Edit_Ext p) {
		// ブロック関連の初期化
		p.EditPanel.setLayoutPosition("CRC");
		// ブロックの項目の初期化
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "G";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP_Info_Edit_Ext_FW.mcInitSearch((FSBAP_Info_Edit_Ext)this);
		FSBAP_Info_Edit_Ext_FW.mcInitEdit((FSBAP_Info_Edit_Ext)this);

		// [INIT]ステータスのモードの設定
		FSBAP_Info_Edit_Ext_FW.statusInitINIT_Search((FSBAP_Info_Edit_Ext)this);
		FSBAP_Info_Edit_Ext_FW.statusInitINIT_Edit((FSBAP_Info_Edit_Ext)this);

		// [EDIT]ステータスのモードの設定
		FSBAP_Info_Edit_Ext_FW.statusInitEDIT_Search((FSBAP_Info_Edit_Ext)this);
		FSBAP_Info_Edit_Ext_FW.statusInitEDIT_Edit((FSBAP_Info_Edit_Ext)this);

		// [EDIT_DEL]ステータスのモードの設定
		FSBAP_Info_Edit_Ext_FW.statusInitEDIT__DEL_Search((FSBAP_Info_Edit_Ext)this);
		FSBAP_Info_Edit_Ext_FW.statusInitEDIT__DEL_Edit((FSBAP_Info_Edit_Ext)this);

	}

	/**
	 *  [Search]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitSearch(FSBAP_Info_Edit_Ext p) {
	}

	/**
	 *  [Edit]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitEdit(FSBAP_Info_Edit_Ext p) {
	}

	/**
	 * [INIT]ステータスの[Search]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Search(FSBAP_Info_Edit_Ext p){
		p.Search_ext_PPanel.putStatus(INIT, mcframe.clientFSBF.FSBFP0120.FSBFP_Ext_ARRAY.REF);

	}

	/**
	 * [INIT]ステータスの[Edit]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Edit(FSBAP_Info_Edit_Ext p){
		p.Edit_ext_PPanel.putStatus(INIT, mcframe.clientFSBF.FSBFP0100.FSBFP_Ext.REF);

	}

	/**
	 * [EDIT]ステータスの[Search]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_Search(FSBAP_Info_Edit_Ext p){
		p.Search_ext_PPanel.putStatus(EDIT, mcframe.clientFSBF.FSBFP0120.FSBFP_Ext_ARRAY.REF);

	}

	/**
	 * [EDIT]ステータスの[Edit]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_Edit(FSBAP_Info_Edit_Ext p){
		p.Edit_ext_PPanel.putStatus(EDIT, mcframe.clientFSBF.FSBFP0100.FSBFP_Ext.REF);

	}

	/**
	 * [EDIT_DEL]ステータスの[Search]ブロックのモードの設定
	 */
	protected static void statusInitEDIT__DEL_Search(FSBAP_Info_Edit_Ext p){
		p.Search_ext_PPanel.putStatus(EDIT_DEL, mcframe.clientFSBF.FSBFP0120.FSBFP_Ext_ARRAY.REF);

	}

	/**
	 * [EDIT_DEL]ステータスの[Edit]ブロックのモードの設定
	 */
	protected static void statusInitEDIT__DEL_Edit(FSBAP_Info_Edit_Ext p){
		p.Edit_ext_PPanel.putStatus(EDIT_DEL, mcframe.clientFSBF.FSBFP0100.FSBFP_Ext.REF);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return INIT;
	}

	/**
	 * Table/Treeの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
	}


	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
	}

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}