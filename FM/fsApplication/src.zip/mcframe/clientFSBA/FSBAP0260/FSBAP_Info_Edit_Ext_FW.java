package mcframe.clientFSBA.FSBAP0260;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;

import mcframe.clientFSBF.FSBFP0100.*;
import mcframe.clientFSBF.FSBFP0120.*;

import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.clientCore.sys.MCSys;
import mcframe.clientFSBA.FSBAP0250.InfoR;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP_Info_Edit_Ext"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP_Info_Edit_Ext_FW extends FSBAP_Info_Edit_Ext_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_Info_Edit_Ext_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_Info_Edit_Ext_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	@Override
	protected void valueInit() {
		super.valueInit();
		Search_co_cd.setValue(MCSys.user.coCD());
		Search_attr1.setValue(MCSys.user.extattr1());
		Search_attr2.setValue(MCSys.user.extattr2());
		Search_attr3.setValue(MCSys.user.extattr3());
		getSearchR().ext_flg(true);
	}

	@Override
	protected void reverceRow() {
		super.reverceRow();
		
		InfoR lr = InfoTable.getSelectedMCRow();
		if (lr != null) {
			if (lr.isStatusCreate()) {
				int index = lr.getGUIIndex();
				setValueEx(columnInfo_co_cd, index, MCSys.user.coCD());
				setValueEx(columnInfo_attr1, index, MCSys.user.extattr1());
				setValueEx(columnInfo_attr2, index, MCSys.user.extattr2());
				setValueEx(columnInfo_attr3, index, MCSys.user.extattr3());

				setValueEx(Edit_co_cd, MCSys.user.coCD());
				setValueEx(Edit_attr1, MCSys.user.extattr1());
				setValueEx(Edit_attr2, MCSys.user.extattr2());
				setValueEx(Edit_attr3, MCSys.user.extattr3());
			}
		}
	}

}