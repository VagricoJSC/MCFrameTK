package mcframe.clientFSBA.FSBAP0310;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;

import mcframe.clientFXUC.FXUCP0070.*;

import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import mcframe.clientCore.beans.text.MCCalendarDocumentBeans;
import mcframe.clientCore.beans.text.MCTimestampFormat;
import mcframe.clientCore.resource.MCConst;

import mcframe.clientFSBA.FSBAP0030.ListDtlR;
import mcframe.clientFSBA.FSBAP0670.FSBAP0670_FW;
import mcframe.commonFS.constant.FSC_DAY_OF_WEEK_TYPE;
import mcframe.commonFX.constant.FXC_RESOURCE_SETTING_UNIT;

import mcframe.clientFXBA.FXBAP0010.IfSrchCndBase;
import mcframe.clientFXBA.FXBAP0080.FXBAP_CellConfig;
import mcframe.clientCore.beans.resource.MCPersonalizeResourceIO;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP_SrchCnd"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP_SrchCnd_FW extends FSBAP_SrchCnd_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	/**
	 * 入力値設定対象の画面です。
	 */
	protected IfSrchCndBase _target_panel = null;

	/**
	 * 削除確認中を表すフラグです。
	 */
	protected boolean _inDelConfirm = false;

	/**
	 * 検索枠の GUI 部品のリストです。<p>
	 * 第一要素：String（枠名）、第二要素：MCRowBeans（GUI部品）
	 */
	protected List<Object[]> _compos = new ArrayList<Object[]>();

	/**
	 * 検索枠の GUI 部品とリソースキーのリストです。
	 * 第一要素：MCRowBeans（GUI部品）、第二要素：String（リソースキー）
	 */
	protected List<Object[]> _field_key_list = new ArrayList<Object[]>();

	/**
	 * デフォルトに戻す処理におけるメッセージを格納するためのリストです。
	 */
	protected MCMessageList _default_message_list = new MCMessageList();

	/**
	 * 画面表示時の検索条件のリストです。
	 */
	protected MCList<SrchCndR> _init_srch_cnd_list = null;

	/**
	 * 設定情報ＩＤのシーケンス番号のマップです。
	 */
	protected Map<String, Integer> _setting_info_no_map = null;

	/**
	 *  バーコード設定画面
	 */
	protected FSBAP0670_FW mainPanelForBarcode = null;

	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_SrchCnd_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_SrchCnd_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * mainPanelForBarcode
	 * @return FSBAP0670_FW
	 */
	public FSBAP0670_FW getMainPanelForBarcode() {
		return mainPanelForBarcode;
	}

	/**
	 * mainPanelForBarcode
	 * @param mainPanelForBarcode FSBAP0670_FW
	 */
	public void setMainPanelForBarcode(FSBAP0670_FW mainPanelForBarcode) {
		this.mainPanelForBarcode = mainPanelForBarcode;
	}

	/**
	 * Panel[InfoBtn]のボタン[select_all]の押下時の処理
	 */
	@Override
	public void doInfoBtn_select_all(MCEventInfo info) {
		setValueEx(columnInfoDtl_set_flg, true);
	}
	/**
	 * Panel[InfoBtn]のボタン[deselect_all]の押下時の処理
	 */
	@Override
	public void doInfoBtn_deselect_all(MCEventInfo info) {
		setValueEx(columnInfoDtl_set_flg, false);
	}

	/**
	 * 親画面を返します。
	 *
	 * @return 親画面
	 * @throws MCAppException [FSBAC0044]
	 * 親画面が null、または、IfSrchCndBaseを実装していない場合
	 */
	protected IfSrchCndBase getTargetPanel() {
		if (_target_panel != null) {
			return _target_panel;
		}
		MCRootPanel p = getParentPanel();
		if (p == null || !(p instanceof IfSrchCndBase)) {
			throw new MCAppException(
					FSBAC0044, getModuleID(), getScreenID());
		}
		return (_target_panel = (IfSrchCndBase)p);
	}

	@Override
	protected void setInitInfoData(ListDtlR data) {
		super.setInitInfoData(data);

		// 登録済みの行が選択された場合
		FSBAP_SrchCndInfo si = getSettingInfo(data);
		if (si != null) {
			setListHdrR(si.getSettingInfo());
			setInfoBtnR(si.getSrchInfo());
			MCList<SrchCndR> c1 = si.getSrchCndList();
			MCList<SrchCndR> sl = createInfoDtlL();

			// システム非表示を除く 7.0.1
			if(_target_panel instanceof MCRootPanel) {
				MCSystemLocationUtil util = new MCSystemLocationUtil();
				util.initSystemInvisible((MCRootPanel)_target_panel);

				for (SrchCndR c : c1) {
					MCRowBeans c2 = getRowBeans(c);
					if(c2 instanceof Component && util.isVisibleComponent((Component)c2) == false) {
						continue;
					}
					SrchCndR nc = c.clone();
					sl.add(nc);
				}
			} else {
				for (SrchCndR c : c1) {
					SrchCndR nc = c.clone();
					sl.add(nc);
				}
			}


			FSC_DAY_OF_WEEK_TYPE.putNameNE(
					sl, SrchCndR.$day_of_week_type, SrchCndR.$day_of_week_type_nm);

			setInfoDtlL(sl);
			getInfoDtlL().setStatus(MCRow.NONE);

			InfoDtlTable.adjustWidth();

			return;
		}

		// 新規行が選択された場合
		getInfoDtlL().clear();
		getListHdrR().clearAll();

		doLoad();
		getInfoBtnR().clearAll();

		InfoDtlTable.adjustWidth();

	}

	@Override
	protected boolean isInfoDataChanged() {
		return !getInfoDtlL().isStatusNone() || !getInfoBtnR().isStatusNone();
	}

	protected String setting_unit_barcode() {
		return "BARCODE";
	}

	@Override
	protected void removeResource(boolean doSave) {
		IfSrchCndBase bp = getTargetPanel();

		String u = getSettingR().setting_unit();

		// バーコード対応
		if (mainPanelForBarcode != null) {
			u = setting_unit_barcode();
		}

		Map<String, Integer> m = FXUCP_SrchCndUtil.readSettingInfoNO(bp);

		FXUCP_SrchCndUtil.removeResourceNoSave(u, bp);

		// 設定情報ＩＤのシーケンスを再設定する
		if (m.containsKey(u) && isRemainedAfterDel(u)) {
			Map<String, Integer> nm = new HashMap<String, Integer>();
			nm.put(u, m.get(u));
			FXUCP_SrchCndUtil.writeResourceNoSave(bp, nm, null, null);
		}
		if (doSave) {
			MCPersonalizeResourceIO.saveResource();
		}

		bp._setSrchCndInfo(null);
		bp._setSrchCndInfoList(null);
	}

	/**
	 * removeResourceで指定したIDのみを削除するメソッド。
	 * 
	 * @param doSave 保存するかどうかのフラグ
	 * @param setting_info_id 設定情報ID
	 */
	protected void removeResourceById(boolean doSave, String setting_info_id) {
		IfSrchCndBase bp = getTargetPanel();
		if (setting_info_id != null) {
//			IfSrchCndBase bp = getTargetPanel();
	
			String u = getSettingR().setting_unit();
	
			// バーコード対応
			if (mainPanelForBarcode != null) {
				u = setting_unit_barcode();
			}
	
			Map<String, Integer> m = FXUCP_SrchCndUtil.readSettingInfoNO(bp);
	
			FXUCP_SrchCndUtil.removeResourceNoSaveById(u, bp, setting_info_id);
	
			// 設定情報ＩＤのシーケンスを再設定する
			if (m.containsKey(u) && isRemainedAfterDel(u)) {
				Map<String, Integer> nm = new HashMap<String, Integer>();
				nm.put(u, m.get(u));
				FXUCP_SrchCndUtil.writeResourceNoSave(bp, nm, null, null);
			}
			if (doSave) {
				MCPersonalizeResourceIO.saveResource();
			}
		}

		bp._setSrchCndInfo(null);
		bp._setSrchCndInfoList(null);
	}

	@Override
	protected void setInitData() {
		super.setInitData();

		getInfoDtlL().clear();
		getInfoBtnR().clearAll();

		_compos.clear();
		_field_key_list.clear();

		IfSrchCndBase bp = getTargetPanel();

		_compos = FXUCP_SrchCndUtil.getSrchCndBeans(bp, true);
		_field_key_list = FXUCP_SrchCndUtil.createGUIKeyList(_compos);

		MCList<ListDtlR> il = createListDtlL();

		List<SrchCndInfo> l = new ArrayList<SrchCndInfo>();

		List<SrchCndInfo> sl = new ArrayList<SrchCndInfo>();
		List<SrchCndInfo> el = new ArrayList<SrchCndInfo>();
		List<SrchCndInfo> ul = new ArrayList<SrchCndInfo>();
		List<SrchCndInfo> bl = new ArrayList<SrchCndInfo>();

		// バーコード対応
		if(mainPanelForBarcode != null) {
			for (SrchCndInfo i : bp.getSrchCndInfoList()) {
				String y = i.getSettingUnitType();
				if (FXC_RESOURCE_SETTING_UNIT.isTYPE_BARCODE(y)) {
					bl.add(i);
				}
			}
			l.addAll(0, bl);
		} else {
			for (SrchCndInfo i : bp.getSrchCndInfoList()) {
				String y = i.getSettingUnitType();
				if (FXC_RESOURCE_SETTING_UNIT.isTYPE_SYS(y)) {
					sl.add(i);
				}
				else if (FXC_RESOURCE_SETTING_UNIT.isTYPE_EXT(y)) {
					el.add(i);
				}
				else if (FXC_RESOURCE_SETTING_UNIT.isTYPE_USER(y)) {
					ul.add(i);
				}
				else if (FXC_RESOURCE_SETTING_UNIT.isTYPE_BARCODE(y)) {
					bl.add(i);
				}
			}

			String u = getSettingR().setting_unit();

			l.addAll(0, sl);
			if (!FXC_RESOURCE_SETTING_UNIT.isTYPE_SYS(u)) {
				l.addAll(0, el);
				if (!FXC_RESOURCE_SETTING_UNIT.isTYPE_EXT(u)) {
					l.addAll(0, ul);
				}
			}
		}

		_setting_info_no_map = FXUCP_SrchCndUtil.readSettingInfoNO(bp);

		int pi = 0;
		for (SrchCndInfo ci : l) {
			FSBAP_SrchCndInfo si = new FSBAP_SrchCndInfo();

			ListDtlR lo = createListDtlR();
			lo.setting_info_id(ci.getSettingInfoID());
			lo.setting_info_nm(ci.getSettingInfoName());
			if (isNull(lo.setting_info_nm())) {
				lo.setting_info_nm(
						getPreviousSettingNamePrefix() + String.valueOf(++pi));
			}

			lo.remark(ci.getRemark());
			lo.init_flg(ci.getInitFlg());

			lo.setting_unit_type(ci.getSettingUnitType());
			FXC_RESOURCE_SETTING_UNIT.putName(lo,
					ListDtlR.$setting_unit_type,
					ListDtlR.$setting_unit_type_nm);

			il.add(lo);

			si.setSettingInfo(lo.clone());

			// システム非表示対応 7.0.1
			MCSystemLocationUtil util = new MCSystemLocationUtil();
			util.initSystemInvisible((MCRootPanel)_target_panel);

			MCList<SrchCndR> scl = createInfoDtlL();
			for (SrchCndR so : ci.getSrchCndList()) {
				MCRowBeans c3 = getRowBeans(so);
				if(c3 instanceof Component && util.isVisibleComponent((Component)c3) == false) {
					continue;
				}

				scl.add(so);
			}
			si.setSrchCndList(scl);

			InfoBtnR bo = createInfoBtnR();
			bo.srch_flg(ci.getInitSrchFlg());
			bo.clear_flg(ci.getClearFlg());

			si.setSrchInfo(bo.clone());

			getSettingInfoMap().put(MCConst.createKey(
					ci.getSettingUnitType(), ci.getSettingInfoID()), si);
		}

		setListDtlL(il);

		SrchCndInfo i = getTargetPanel().getSrchCndInfo();
		if (i == null) {
			i = new SrchCndInfo();
		}

		_init_srch_cnd_list = createInfoDtlL();

		List<MCBeans> a = new ArrayList<>();
		for (Object[] oa : _compos) {
			MCRowBeans o = (MCRowBeans)oa[1];
			if (o instanceof MCButtonGroup) {
				a.addAll(Arrays.asList(((MCButtonGroup)o).getRadioButtons()));
			}
			else {
				a.add(o);
			}
		}

		List<Object[]> pnl = MCBeansUtil.getPanelNameList(a.toArray(new MCBeans[0]));

		for (Object[] oa : _compos) {
			MCRowBeans c = (MCRowBeans)oa[1];
			String k = null;
			for (Object[] ka : _field_key_list) {
				if (c.equals(ka[0])) {
					k = (String)ka[1];
					break;
				}
			}

			SrchCndR o = null;
			for (SrchCndR s : i.getSrchCndList()) {
				if (isSame(k, s.field_key())) {
					o = s;
					break;
				}
			}
			if (o == null) {
				o = createInfoDtlR();
				o.field_key(k);
				o.name(FXUCP_SrchCndUtil.getMessageName(c));
				o.panel_name(getPanelLabelName(c, pnl));
			}
			SrchCndR d = FXUCP_SrchCndUtil.getData(bp, c, o);
			_init_srch_cnd_list.add(d);
		}

//		for (SrchCndR s : i.getSrchCndList()) {
//			MCRowBeans c = null;
//			String k = s.field_key();
//			for (Object[] oa : _compos) {
//				if (isSame(k, (String)oa[1])) {
//					c = (MCRowBeans)oa[0];
//					break;
//				}
//			}
//			if (c != null) {
//				SrchCndR d = FXUCP_SrchCndUtil.getData(bp, c, s);
//				_init_srch_cnd_list.add(d);
//			}
//		}
		ListDtlTable.adjustWidth();
	}

	/**
	 * 枠のラベル名を返します。
	 *
	 * @param compo GUI 部品
	 * @param list リスト（第一要素：GUI 部品、第二要素：MCRootPanel、または MCPanel、第三要素：枠名、または null）
	 * @return 枠のラベル名、または null
	 */
	protected String getPanelLabelName(MCRowBeans compo, List<Object[]> list) {
		if (compo instanceof MCButtonGroup) {
			MCRadioButton o = ((MCButtonGroup)compo).getSelectedButton();
			if (o != null) {
				for (Object[] a : list) {
					if (o.equals(a[0])) {
						return (String)a[2];
					}
				}
			}
		}
		else {
			for (Object[] a : list) {
				if (compo.equals(a[0])) {
					return (String)a[2];
				}
			}
		}
		return null;
	}

	@Override
	protected void setTargetPanelDefault() {
		_default_message_list.clear();
		if (getTargetPanel()._applySrchCndInfo(null) != null) {
			_default_message_list.add(new MCMessage(FSBAC0051));
		}
	}

	@Override
	protected void updateTargetPanel() {
		ListDtlR s = ListDtlTable.getSelectedMCRow();
		FSBAP_SrchCndInfo si = getSettingInfo(s);

		ListDtlR c1 = si.getSettingInfo().clone();
		MCList<SrchCndR> c2 = si.getSrchCndList().clone();
		InfoBtnR c3 = si.getSrchInfo().clone();

		SrchCndInfo i = createSrchCndInfo(
				c1.setting_info_id(), c1, c2, c3);

		getTargetPanel()._applySrchCndInfo(i);
	}

	@Override
	protected void writeResource() {
//		removeResource(false);

		IfSrchCndBase pp = getTargetPanel();
		// 汎用編集テーブル以外の場合
		if (!isTargetGeneralTable()) {
			removeResource(false);
		}

		List<SrchCndInfo> il = new ArrayList<SrchCndInfo>();

		ListDtlR s = ListDtlTable.getSelectedMCRow();

		String u = getSettingR().setting_unit();
		if(mainPanelForBarcode != null) {
			u = setting_unit_barcode();
		}

		Integer no = _setting_info_no_map.get(u);
		if (no == null) {
			no = Math.max(getMaxSettingInfoNO(), 0);
		}

		for (ListDtlR o : getListDtlL()) {
			// 空またはステータスがDELETEで汎用テーブル編集以外の場合
			if (o.isEmpty() || (o.isStatusDelete() && !isTargetGeneralTable())) {
				continue;
			}

			ListDtlR c1;
			MCList<SrchCndR> c2;
			InfoBtnR c3;

			String y = o.setting_unit_type();
			if(mainPanelForBarcode != null) {
				y = setting_unit_barcode();
			}

			// 選択行ではない場合
			if (s != o) {
				if (!u.equals(y)) {
					continue;
				}

				FSBAP_SrchCndInfo si = getSettingInfo(o);
				if (si == null) {
					continue;
				}
				c1 = si.getSettingInfo().clone();
				c1.init_flg(o.init_flg());
				c1.setting_unit_type(o.setting_unit_type());
				c1.setting_unit_type_nm(o.setting_unit_type_nm());
				c2 = si.getSrchCndList().clone();
				c3 = si.getSrchInfo().clone();
			}
			// 選択行の場合
			else {
				if (isNull(y)) {
					o.setting_unit_type(u);
					FXC_RESOURCE_SETTING_UNIT.putNameNE(o,
							ListDtlR.$setting_unit_type,
							ListDtlR.$setting_unit_type_nm);
					y = o.setting_unit_type();
				}

				if (!u.equals(y)) {
					continue;
				}

				c1 = createListDtlR();
				c2 = createInfoDtlL();
				c1.setValues(ListDtlR.colnames(),
						getListHdrR(), ListDtlR.colnames());
				c1.init_flg(o.init_flg());
				c1.setting_unit_type(o.setting_unit_type());
				c1.setting_unit_type_nm(o.setting_unit_type_nm());

				for (SrchCndR t : getInfoDtlL()) {
					if (t.isEmpty() || t.isStatusDelete()) {
						continue;
					}
					c2.add(t.clone());
				}

				c3 = getInfoBtnR().clone();
				// 汎用テーブル編集の場合
				if (isTargetGeneralTable()) {
					String id = c1.setting_info_id();
					// 新規の場合
					if (isNull(id) || id.equals("old_setting_info_id")) {
						id = FXUCP_SrchCndUtil.createSettingInfoID(u, no++);
						removeResourceById(false, null);						
					}
					// 更新または削除の場合、対象のIDのみを削除する
					else {
						removeResourceById(false, id);
					}
					// 削除の場合は追加しない
					if (!s.isStatusDelete()) {
						SrchCndInfo f = createSrchCndInfo(
								id, c1, c2, c3);
						il.add(f);
					}
				}
			}

			// 汎用テーブル編集以外の場合
			if(!isTargetGeneralTable()) {
				String id = c1.setting_info_id();
				if (isNull(id) || id.equals("old_setting_info_id")) {
					id = FXUCP_SrchCndUtil.createSettingInfoID(u, no++);
				}
				SrchCndInfo f = createSrchCndInfo(
						id, c1, c2, c3);
				il.add(f);
			}
		}

		boolean isNotEmpty = il.size() > 0 ? true : false;
		if (isNotEmpty) {
			Map<String, Integer> m = new HashMap<String, Integer>();
			m.put(u, no);
			FXUCP_SrchCndUtil.writeResourceNoSave(pp, m, il, _compos);
		}
		MCPersonalizeResourceIO.saveResource();

	}

	protected SrchCndInfo createSrchCndInfo(
			String id, ListDtlR info, MCList<SrchCndR> list, InfoBtnR btn) {
		SrchCndInfo f = new SrchCndInfo();
		f.setSettingInfoID(id);
		f.setSettingInfoName(info.setting_info_nm());
		f.setRemark(info.remark());
		f.setInitFlg(info.init_flg());
		f.setSettingUnitType(info.setting_unit_type());

		List<SrchCndR> cl = new ArrayList<SrchCndR>();
		cl.addAll(list);
		f.setSrchCndList(cl);

		f.setInitSrchFlg(btn.srch_flg());
		f.setClearFlg(btn.clear_flg());
		return f;
	}

	@Override
	protected boolean checkForLoad() {
		if (!super.checkForLoad()) {
			return false;
		}

		if (!getInfoDtlL().isStatusNone()) {
			if (confirm(FSBAC0059) != MCMessageBox.YES_OPTION) {
				return false;
			}
		}
		return true;
	}

	@Override
	protected void doLoad() {
		super.doLoad();

		MCList<SrchCndR> ol = _init_srch_cnd_list;
		if (ol == null) {
			return;
		}

		MCList<SrchCndR> nl = createInfoDtlL();
		// 既存行変更
		if (getInfoDtlL().size() == ol.size()) {
			MCList<SrchCndR> tvl = createInfoDtlL();
			tvl.addAll(getInfoDtlL());

			ListDtlR s = ListDtlTable.getSelectedMCRow();
			boolean e = s != null && getSettingInfo(s) != null;

			for (int i = 0; i < ol.size(); i++) {
				SrchCndR o = ol.get(i);
				MCList<SrchCndR> sl = tvl.subList(
						new String[] {
								SrchCndR.$panel_name, SrchCndR.$name
						},
						new Comparable<?>[] {
								o.panel_name(), o.name()
						}
				);
				if (sl.size() != 1) {
					break;
				}
				SrchCndR so = sl.get(0);
				SrchCndR n = o.clone();
				nl.add(n);

				// 表示されている行と異なる場合は、変更ステータスとする
				if (!so.equals(n) || i != getInfoDtlL().indexOf(so)) {
					if (e) {
						n.setStatus(MCRow.MODIFY);
					}
					else {
						n.setStatus(MCRow.CREATE);
					}
				}
				// 表示されている行と同じ場合は、ステータスを変更しない
				else {
					n.setStatus(so.getStatus());
				}

				tvl.removeAll(sl);
			}

			if (nl.size() == ol.size()) {
				setInfoDtlL(nl);
				validateList(nl);
				return;
			}

			nl.clear();
		}
		// 新規追加
		// システム非表示を除く 7.0.1
		if(_target_panel instanceof MCRootPanel) {
			MCSystemLocationUtil util = new MCSystemLocationUtil();
			util.initSystemInvisible((MCRootPanel)_target_panel);
			for (SrchCndR o : ol) {
				MCRowBeans c1 = getRowBeans(o);
				if(c1 instanceof Component && util.isVisibleComponent((Component)c1) == false) {
					continue;
				}
				SrchCndR n = o.clone();
				nl.add(n);
				n.setStatus(MCRow.GUICREATE);

			}
		} else {
			for (SrchCndR o : ol) {
				SrchCndR n = o.clone();
				nl.add(n);
				n.setStatus(MCRow.GUICREATE);
			}
		}

		setInfoDtlL(nl);
		validateList(nl);
	}

	protected void validateList(MCList<SrchCndR> nl) {

		MCMessageList ml = nl.validate(SrchCndR.$text);
		for (int i = 0; i < ml.size(); i++) {
			MCMessage m = ml.get(i);
			if (m.getID().equals(FCBBC0063)) {
				SrchCndR r = (SrchCndR) m.getCauseRow();
				ml.set(i,
						new MCMessage(r, SrchCndR.$text, FSBAC0014,
								r.getGUIIndex() + 1, columnInfoDtl_text
										.getLabelByLocale(), r.text(), r.text()
										.length(), SrchCndR.text_META.length()));
				r.text(null);// 桁あふれの場合はnullに変更
			}
		}
		//削除では、削除確認中に編集状態を元に戻す処理が実行される。
		//新規追加行を元に戻す場合、桁あふれの値は設定されていない状態に戻すだけでよく、ダイアログを表示する必要はないため、
		//_inDelConfirmで削除確認中かどうかでメッセージの表示を制限している。
		if (!_inDelConfirm && ml.size() > 0) {
			message(ml);
		}
	}

	@Override
	protected boolean execDelComfirm() {
		_inDelConfirm = true;
		try {
			return super.execDelComfirm();
		}
		finally {
			_inDelConfirm = false;
		}
	}
	@Override
	protected void afterCopyRow() {
		super.afterCopyRow();

		for (SrchCndR o : getInfoDtlL()) {
			if (o.set_flg() && !o.isEmpty()) {
				o.setStatus(MCRow.CREATE);
			}
		}

		getListHdrR().init_flg(false);
		getListHdrR().setting_info_id(null);
		getListHdrR().setting_info_nm(null);
		// 画面で現在アクティブになっている設定単位を設定
		getListHdrR().setting_unit_type(getSettingR().setting_unit());
		FXC_RESOURCE_SETTING_UNIT.putNameNE(getListHdrR(), 
				ListDtlR.$setting_unit_type, 
				ListDtlR.$setting_unit_type_nm);

		setStatus(EDIT);

	}

	@Override
	protected boolean checkForApply() {
		if (!super.checkForApply()) {
			return false;
		}

		// 空行のステータスをクリアする
		clearEmptyRowStatus(getInfoDtlL());

		MCList<SrchCndR> l = exceptEmpty(getInfoDtlL());

		// フィルタ情報の必須項目をチェックする
		MCMessageList m = checkReq(l);
		if (m.size() > 0) {
			message(m);
			return false;
		}

		if (isChanged()) {
			if (confirm(FSBAC0059) != MCMessageBox.YES_OPTION) {
				return false;
			}

			ListDtlR o = ListDtlTable.getSelectedMCRow();
			setInitListData(o);
			setInitInfoData(o);
		}

		return true;

	}

	@Override
	protected void doApply() {
		if (!MCMode.isEnable(ListDtlBtn_apply)) {
			statusClear();
			requestCloseWindow();
		}
		updateTargetPanel();
	}

	@Override
	protected boolean checkForUpd() {
		if (!super.checkForUpd()) {
			return false;
		}

		MCList<SrchCndR> l = getInfoDtlL().subList(SrchCndR.$set_flg, true);
		if (l.size() == 0) {
			dialog(FSBAC0067);
			return false;
		}

		clearEmptyRowStatus(getInfoDtlL());

		return true;
	}

	// 640
	// サブクラス用のcheckForUpd
	protected boolean checkForUpd2() {
		return super.checkForUpd();
	}

	@Override
	protected void afterUpd() {
		super.afterUpd();

		getTargetPanel()._setSrchCndInfoList(null);
	}

	@Override
	protected void showDefEndMsg() {
		MCMessageList l = _default_message_list;

		if (l.size() > 0) {
			MCMessage m = new MCMessage(
					FXBAP0031, new MCMessage(FSBAC0005).toString());
			l.add(0, m);
			sortMessageList(l);
			MCMessageBox.message(
					this, MCFrameType.SYSTEM_MODAL, null, l);
		}
		else {
			super.showDefEndMsg();
		}

	}

	@Override
	protected void afterDel() {
		super.afterDel();

		getTargetPanel()._setSrchCndInfoList(null);
	}

	@Override
	protected void afterDef() {
		super.afterDef();

		getTargetPanel()._setSrchCndInfoList(null);
	}

	@Override
	protected void tableInit() {
		super.tableInit();

		InfoDtlTable.setSortable(false);
	}

	@Override
	protected void listInit() {
		super.listInit();

		columnInfoDtl_radio.setListVisibleColumn(
				SrchCndR.$radio, SrchCndR.$radio_nm);
	}

	@Override
	public MCList<?> getInfoDtl_radio(MCRow row, MCEventInfo info) {
		return getRadioList(row, info);
	}

	protected MCList<MCRow> getRadioList(MCRow row, MCEventInfo info) {
		int index = info.getEventIndex();
		if (getInfoDtlL().size() <= index) {
			return null;
		}

		MCRowBeans c = getRowBeans(getInfoDtlL().get(index));
		if (!(c instanceof MCButtonGroup)) {
			return null;
		}

		MCList<MCRow> list = MCList.create(MCRow.class);
		for (MCRadioButton b : ((MCButtonGroup)c).getRadioButtons()) {
			MCModeInfo i = b.getModeInfo();
			if (i != null && i.getStatus() == MCMode.ENABLE_STATUS) {
				MCRow d = MCRow.create();
				d.addStringColumn(SrchCndR.$radio, b.getActionCommand());
				d.addStringColumn(SrchCndR.$radio_nm, getRadioButtonName(b));
				list.add(d);
			}
		}
		return list;
	}

	/**
	 * ラジオボタンのコンボリストに表示するラジオボタン名を返します。
	 *
	 * @param compo ラジオボタン
	 * @return ラジオボタン名
	 */
	protected String getRadioButtonName(MCRadioButton compo) {
		String n = compo.getLabelByLocale();
		if (!isNull(n)) {
			return n;
		}
		n = compo.getMessageByLocale();
		if (!isNull(n)) {
			return n;
		}
		return null;
	}

	protected MCRowBeans getRowBeans(SrchCndR data) {
		List<Object[]> oal = _compos;
		List<Object[]> okl = _field_key_list;
		if (oal == null || okl == null) {
			return null;
		}
		for (Object[] oa : oal) {
			MCRowBeans c = (MCRowBeans)oa[1];

			String k = null;
			for (Object[] ka : _field_key_list) {
				if (c.equals(ka[0])) {
					k = (String)ka[1];
					break;
				}
			}

			if (MCStringUtil.eq(k, data.field_key())) {
				return c;
			}
		}
		return null;
	}

	@Override
	public void setStatus(String status) {
		super.setStatus(status);

		IfSrchCndBase bp = getTargetPanel();
		if (!bp.isPanelNameVisibleInSrchCnd()) {
			columnInfoDtl_panel_name.setMode(MCMode.INVISIBLE);
		}

		MCFrame f = ((MCRootPanel)bp).getFrame();
		if (f.getFrameType() == SYSTEM_MODAL) {
			ListDtlBtn_apply.setMode(MCMode.DISABLE);
		}
		else {
			setDefaultMode(ListDtlBtn_apply);
		}
	}

	@Override
	public void doInfoDtl_date_NC(MCEventInfo info) {
		super.doInfoDtl_date_NC(info);

		int index = info.getEventIndex();
		if (!isNull(getInfoDtlL().get(index).date())) {
			setValueEx(columnInfoDtl_today_flg, index, false);
			setValueEx(columnInfoDtl_firstday_flg, index, false);
			setValueEx(columnInfoDtl_lastday_flg, index, false);
		}
	}

	@Override
	public void doInfoDtl_today_flg_NC(MCEventInfo info) {
		super.doInfoDtl_today_flg_NC(info);

		int index = info.getEventIndex();
		if (getInfoDtlL().get(index).today_flg()) {
			setValueEx(columnInfoDtl_date, index, null);
			setValueEx(columnInfoDtl_firstday_flg, index, false);
			setValueEx(columnInfoDtl_lastday_flg, index, false);
		}
	}

	@Override
	public void doInfoDtl_firstday_flg_NC(MCEventInfo info) {
		super.doInfoDtl_firstday_flg_NC(info);

		int index = info.getEventIndex();
		if (getInfoDtlL().get(index).firstday_flg()) {
			setValueEx(columnInfoDtl_today_flg, index, false);
			setValueEx(columnInfoDtl_date, index, null);
			setValueEx(columnInfoDtl_lastday_flg, index, false);
		}
	}

	@Override
	public void doInfoDtl_lastday_flg_NC(MCEventInfo info) {
		super.doInfoDtl_lastday_flg_NC(info);

		int index = info.getEventIndex();
		if (getInfoDtlL().get(index).lastday_flg()) {
			setValueEx(columnInfoDtl_today_flg, index, false);
			setValueEx(columnInfoDtl_date, index, null);
			setValueEx(columnInfoDtl_firstday_flg, index, false);
		}
	}


	@Override
	public void doInfoDtl_focus_flg_NC(MCEventInfo info) {
		super.doInfoDtl_focus_flg_NC(info);

		int idx = info.getEventIndex();
		if (getInfoDtlL().get(idx).focus_flg()) {
			getInfoDtlL().clear(SrchCndR.$focus_flg);
			getInfoDtlL().get(idx).focus_flg(true);
		}
	}

	@Override
	public void doInfoBtn_srch_flg_NC(MCEventInfo info) {
		super.doInfoBtn_srch_flg_NC(info);

		if (getInfoBtnR().srch_flg()) {
			getInfoDtlL().clear(SrchCndR.$focus_flg);
		}
	}

	@Override
	public void doInfoDtl_week_NC(MCEventInfo info) {
		super.doInfoDtl_week_NC(info);

		int i = info.getEventIndex();
		SrchCndR o = getInfoDtlL().get(i);
		if (isNull(o.week())) {
			setValueEx(columnInfoDtl_day_of_week_type, i, null);
		}

	}

	@Override
	public void doListDtl_NC(MCEventInfo info) {
		super.doListDtl_NC(info);

		ListDtlR o = ListDtlTable.getSelectedMCRow();
		// 行が選択されなかった場合
		if (o == null) {
			getInfoDtlL().clear();
			getInfoBtnR().clearAll();
			getListHdrR().clearAll();
			setStatus(INIT);
			return;
		}

		setInitListData(o);
		setInitInfoData(o);

		setStatus(EDIT);

	}

	@Override
	public boolean doListDtl_VC(MCEventInfo info) {
		if (!super.doListDtl_VC(info)) {
			return false;
		}

		if (!getInfoDtlL().isStatusNone() || !getInfoBtnR().isStatusNone()
				|| !getListHdrR().isStatusNone()) {
			if (confirm(FSBAC0059) != MCMessageBox.YES_OPTION) {
				return false;
			}

			setInitListData(ListDtlTable.getSelectedMCRow());

		}

		return true;
	}



	@Override
	protected void setCellConfig() {
		super.setCellConfig();

		InfoDtlTable.setCellConfig(createInfoDtlCellConfig());
	}

	/**
	 * 検索条件テーブルに設定するセルコンフィグを作成します。
	 *
	 * @return 検索条件テーブルに設定するセルコンフィグ
	 */
	protected FXBAP_CellConfig createInfoDtlCellConfig() {
		return new WBP_InfoDtlCellConfig();
	}

	public class WBP_InfoDtlCellConfig extends FXBAP_CellConfig {

		@Override
		public MCMode getPriorMode(int index, MCColumnConfig column,
				MCTable table) {
			if (!isDefaultModeEditable(column)) {
				return super.getPriorMode(index, column, table);
			}

			List<Object[]> a = _compos;

			SrchCndR o = getInfoDtlL().get(index);

			if (a == null || a.size() <= index) {
				return super.getPriorMode(index, column, table);
			}
			if (column != columnInfoDtl_set_flg && !o.set_flg()) {
				return MCMode.READ_ONLY;
			}

			MCRowBeans c = getRowBeans(o);
			if(c == null) { //　640 一覧にない場合にエラーになる
				return MCMode.READ_ONLY;
			}
			MCDataType t = c.getDataType();
			if (column == columnInfoDtl_required_flg) {
				if (c instanceof MCButtonGroup) {
					return MCMode.READ_ONLY;
				}
				else if (c instanceof MCCheckBox) {
					return MCMode.READ_ONLY;
				}
				else if (c instanceof MCModeBeans) {
					if (!c.getRequiredFlg()
							&& isReqMode(((MCModeBeans)c).getMode())) {
						return MCMode.READ_ONLY;
					}
				}
				else {
					return MCMode.READ_ONLY;
				}
			}
			else if (column == columnInfoDtl_text) {
				if (MCDataType.STRING != t || (c instanceof MCButtonGroup)) {
					return MCMode.READ_ONLY;
				}
			}
			else if (column == columnInfoDtl_check) {
				if (MCDataType.BOOLEAN != t) {
					return MCMode.READ_ONLY;
				}
			}
			else if (column == columnInfoDtl_radio) {
				if (!(c instanceof MCButtonGroup)) {
					return MCMode.READ_ONLY;
				}
			}
			else if (column == columnInfoDtl_today_flg) {
				if (MCDataType.DATE != t && MCDataType.TIMESTAMP != t) {
					return MCMode.READ_ONLY;
				}

				if (c instanceof MCCalendarDocumentBeans) {
					MCCalendarDocumentBeans<?> cf = (MCCalendarDocumentBeans<?>)c;
					String f = cf.getCalendarFormat().getInputPattern();
					if (!f.contains("y") && !f.contains("M") && !f.contains("d")){
						return MCMode.READ_ONLY;
					}
				}
			}
			else if (column == columnInfoDtl_date) {
				if (MCDataType.DATE != t && MCDataType.TIMESTAMP != t) {
					return MCMode.READ_ONLY;
				}
			}
			else if (column == columnInfoDtl_firstday_flg) {
				if (MCDataType.DATE != t && MCDataType.TIMESTAMP != t) {
					return MCMode.READ_ONLY;
				}

				if (c instanceof MCCalendarDocumentBeans) {
					MCCalendarDocumentBeans<?> cf = (MCCalendarDocumentBeans<?>)c;
					String f = cf.getCalendarFormat().getInputPattern();
					if (!f.contains("d")){
						return MCMode.READ_ONLY;
					}
				}

			}
			else if (column == columnInfoDtl_lastday_flg) {
				if (MCDataType.DATE != t && MCDataType.TIMESTAMP != t) {
					return MCMode.READ_ONLY;
				}

				if (c instanceof MCCalendarDocumentBeans) {
					MCCalendarDocumentBeans<?> cf = (MCCalendarDocumentBeans<?>)c;
					String f = cf.getCalendarFormat().getInputPattern();
					if (!f.contains("d")){
						return MCMode.READ_ONLY;
					}
				}

			}
			else if (column == columnInfoDtl_month) {
				if (MCDataType.DATE != t && MCDataType.TIMESTAMP != t) {
					return MCMode.READ_ONLY;
				}

				if (c instanceof MCCalendarDocumentBeans) {
					MCCalendarDocumentBeans<?> cf = (MCCalendarDocumentBeans<?>)c;
					String f = cf.getCalendarFormat().getInputPattern();
					if (!f.contains("M")){
						return MCMode.READ_ONLY;
					}
				}

			}
			else if (column == columnInfoDtl_day || column == columnInfoDtl_week) {
				if (MCDataType.DATE != t && MCDataType.TIMESTAMP != t) {
					return MCMode.READ_ONLY;
				}

				if (c instanceof MCCalendarDocumentBeans) {
					MCCalendarDocumentBeans<?> cf = (MCCalendarDocumentBeans<?>)c;
					String f = cf.getCalendarFormat().getInputPattern();
					if (!f.contains("d")){
						return MCMode.READ_ONLY;
					}
				}

			}
			else if (column == columnInfoDtl_day_of_week_type) {
				if (isNull(o.week())) {
					return MCMode.READ_ONLY;
				}
			}

			else if (column == columnInfoDtl_hour) {
				if (MCDataType.DATE != t && MCDataType.TIMESTAMP != t) {
					return MCMode.READ_ONLY;
				}

				if (c instanceof MCCalendarDocumentBeans) {
					MCCalendarDocumentBeans<?> cf = (MCCalendarDocumentBeans<?>)c;
					String f = cf.getCalendarFormat().getInputPattern();
					if (!f.contains("h") && !f.contains("H") &&
							!f.contains("k") && !f.contains("K")){
						return MCMode.READ_ONLY;
					}
				}

			}
			else if (column == columnInfoDtl_minute) {
				if (MCDataType.DATE != t && MCDataType.TIMESTAMP != t) {
					return MCMode.READ_ONLY;
				}

				if (c instanceof MCCalendarDocumentBeans) {
					MCCalendarDocumentBeans<?> cf = (MCCalendarDocumentBeans<?>)c;
					String f = cf.getCalendarFormat().getInputPattern();
					if (!f.contains("m")){
						return MCMode.READ_ONLY;
					}
				}
			}
			else if (column == columnInfoDtl_num) {
				if (MCDataType.NUMBER != t) {
					return MCMode.READ_ONLY;
				}
			}
			else if (column == columnInfoDtl_focus_flg) {
				if (getInfoBtnR().srch_flg()) {
					return MCMode.READ_ONLY;
				}
			}

			return super.getPriorMode(index, column, table);
		}

		@Override
		protected MCTimestampFormat getCustomTimestampFormat(int index,
				MCColumnConfig column, MCTable table) {
			if (column == columnInfoDtl_date) {
				MCTimestampFormat f = new MCTimestampFormat();

				MCRowBeans c = getRowBeans(getInfoDtlL().get(index));
				if (c instanceof MCCalendarDocumentBeans) {
					MCCalendarDocumentBeans<?> cf = (MCCalendarDocumentBeans<?>)c;
					f.setCalendarPattern(cf.getCalendarFormat().getCalendarPattern());
					return f;
				}
			}
			return super.getCustomTimestampFormat(index, column, table);
		}
	}

	@Override
	protected FSBAP_SrchCndInfo getSettingInfo(ListDtlR data) {
		return (FSBAP_SrchCndInfo)super.getSettingInfo(data);
	}

	@Override
	protected boolean isSearchedProgram(String type, String pgmid) {
		return FXUCP_SrchCndUtil.isSearchedProgram(type, pgmid);
	}

	@Override
	protected int getSettingInfoNO(ListDtlR data) {
		return MCPersonalizeResourceIO.getSettingInfoNO(data.setting_unit_type(), data.setting_info_id());
	}

	/**
	 * 削除処理を実行します。
	 */
	@Override
	protected void doDel() {
		// 汎用テーブル編集の場合、ステータスをDELETEにする
		// リソース更新後にリストから対象行を削除する
		if (isTargetGeneralTable()) {
			// 選択中の行を取得
			ListDtlR s = ListDtlTable.getSelectedMCRow();
			
			s.setStatus(Status.DELETE);
			writeResource();
			getListDtlL().remove(s);
			clearSelection(ListDtlTable);
		}
		// 汎用テーブル編集以外の場合、親クラスのメソッドを呼び出す。
		else {
			super.doDel();
		}
	}

	/**
	 * 対象画面が汎用テーブル編集かどうかを返します。
	 * 
	 * @return 汎用テーブル編集の場合はtrue、それ以外の場合はfalse
	 */
	private boolean isTargetGeneralTable() {
		IfSrchCndBase p = getTargetPanel();

		if (p != null && ((MCRootPanel)p).isGeneralTable()) {
			return true;
		}
		return false;
	}

	/**
	 * 設定情報を格納します。
	 */
	public class FSBAP_SrchCndInfo extends WBP_PersonalizeInfo {

		/**
		 * 検索条件情報のリストです。
		 */
		protected MCList<SrchCndR> _srch_cnd_list = null;

		/**
		 * 検索情報です。
		 */
		protected InfoBtnR _srch_info = null;

		/**
		 * コンストラクタです。
		 */
		public FSBAP_SrchCndInfo() {}

		/**
		 * 検索条件情報のリストを設定します。
		 *
		 * @param list 検索条件情報のリスト
		 */
		public void setSrchCndList(MCList<SrchCndR> list) {
			_srch_cnd_list = list;
		}

		/**
		 * 検索条件情報のリストを返します。
		 *
		 * @return 検索条件情報のリスト
		 */
		public MCList<SrchCndR> getSrchCndList() {
			return _srch_cnd_list;
		}

		/**
		 * 検索情報を設定します。
		 *
		 * @param info 検索情報
		 */
		public void setSrchInfo(InfoBtnR info) {
			_srch_info = info;
		}

		/**
		 * 検索情報を返します。
		 *
		 * @return 検索情報
		 */
		public InfoBtnR getSrchInfo() {
			return _srch_info;
		}

	}

}