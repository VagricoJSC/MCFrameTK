package mcframe.clientFSBA.FSBAP0310;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBAP_SrchCnd"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP_SrchCnd_FW_A extends mcframe.clientFSBA.FSBAP0030.FSBAP_PersonalizeBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0310";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Info]ブロック関連のField定義
	// [Info]ブロックの項目のField定義
	// [InfoDtl]ブロック関連のField定義
	public MCPanel InfoDtlPanel = null;
	public MCScrollPane InfoDtlScrollPane = null;
	public MCTable2<mcframe.clientFXUC.FXUCP0070.SrchCndR> InfoDtlTable = null;
	// [InfoDtl]ブロックの項目のField定義
	/**
	 *  設定.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_set_flg = null;
	/**
	 *  枠名.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_panel_name = null;
	/**
	 *  メッセージ用名称.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_name = null;
	/**
	 *  初期フォーカス.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_focus_flg = null;
	/**
	 *  必須にする.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_required_flg = null;
	/**
	 *  テキスト.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_text = null;
	/**
	 *  チェックボックス.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_check = null;
	/**
	 *  ラジオボタン.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_radio = null;
	/**
	 *  ラジオボタン名.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_radio_nm = null;
	/**
	 *  日付（今日）.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_today_flg = null;
	/**
	 *  日付（月初）.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_firstday_flg = null;
	/**
	 *  日付（月末）.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_lastday_flg = null;
	/**
	 *  日付（固定値）.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_date = null;
	/**
	 *  差分（月）.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_month = null;
	/**
	 *  差分（週）.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_week = null;
	/**
	 *  曜日.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_day_of_week_type = null;
	/**
	 *  曜日名.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_day_of_week_type_nm = null;
	/**
	 *  差分（日）.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_day = null;
	/**
	 *  差分（時）.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_hour = null;
	/**
	 *  差分（分）.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_minute = null;
	/**
	 *  数値.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_num = null;
	// [InfoBtn]ブロック関連のField定義
	public MCPanel InfoBtnPanel = null;
	// [InfoBtn]ブロックの項目のField定義
	/**
	 *  全選択.<p>
	 *
	 */
	public MCButton InfoBtn_select_all = null;
	/**
	 *  全解除.<p>
	 *
	 */
	public MCButton InfoBtn_deselect_all = null;
	/**
	 *  初期検索.<p>
	 *
	 */
	public MCCheckBox InfoBtn_srch_flg = null;
	/**
	 *  画面クリア時も設定する.<p>
	 *
	 */
	public MCCheckBox InfoBtn_clear_flg = null;
	/** [INIT]モードを表す定数 */
	public static final String INIT = "INIT";
	/** [EDIT]モードを表す定数 */
	public static final String EDIT = "EDIT";
	/** [DISABLE]モードを表す定数 */
	public static final String DISABLE = "DISABLE";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{INIT, EDIT, DISABLE};
	
	/** [InfoDtl]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFXUC.FXUCP0070.SrchCndR> aInfoDtlL;
	/** [InfoBtn]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0310.InfoBtnR aInfoBtnR;

	/**
	 * コピーによってaInfoDtlLを設定します。
	 *
	 * aInfoDtlLのインスタンスは変更されません。
	 *
	 * @param dataset InfoDtlL
	 */
	public void setInfoDtlL(MCList<mcframe.clientFXUC.FXUCP0070.SrchCndR> aList) {
		if (getInfoDtlL() != aList) {
			getInfoDtlL().setAll(aList);
		}
	}

	/**
	 * [InfoDtl]ブロックのコンテナaInfoDtlLを返します。
	 *
	 * @return InfoDtlL
	 */
	public MCList<mcframe.clientFXUC.FXUCP0070.SrchCndR> getInfoDtlL() {
		return aInfoDtlL;
	}

	/**
	 * aInfoDtlRを作成します。
	 *
	 * @return InfoDtlR
	 */
	public mcframe.clientFXUC.FXUCP0070.SrchCndR createInfoDtlR() {
		return mcframe.clientFXUC.FXUCP0070.SrchCndR.create();
	}

	/**
	 * aInfoDtlLを作成します。
	 *
	 * @return InfoDtlL
	 */
	public MCList<mcframe.clientFXUC.FXUCP0070.SrchCndR> createInfoDtlL() {
		return MCList.create(mcframe.clientFXUC.FXUCP0070.SrchCndR.class);
	}

	/**
	 * InfoDtlTableを初期化します。
	 */
	protected void createInfoDtlTable(){
		if(InfoDtlTable == null){
			InfoDtlTable = beansFactory.createTable2("InfoDtl.table");
		}
	}

	/**
	 * 項目コピーによってaInfoBtnRを設定します。
	 *
	 * aInfoBtnRのインスタンスは変更されません。
	 *
	 * @param row InfoBtnR
	 */
	public void setInfoBtnR(mcframe.clientFSBA.FSBAP0310.InfoBtnR row) {
		if (row != null) {
			MCRow.copyall(getInfoBtnR(), row);
		}
	}

	/**
	 * [InfoBtn]ブロックのコンテナaInfoBtnRを返します。
	 *
	 * @return InfoBtnR
	 */
	public mcframe.clientFSBA.FSBAP0310.InfoBtnR getInfoBtnR() {
		return aInfoBtnR;
	}

	/**
	 * aInfoBtnRを作成します。
	 *
	 * @return InfoBtnR
	 */
	public mcframe.clientFSBA.FSBAP0310.InfoBtnR createInfoBtnR() {
		return mcframe.clientFSBA.FSBAP0310.InfoBtnR.create();
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getInfoDtlL())) ret.add(getInfoDtlL());
		if(!MCCollectionUtil.contains(ret, getInfoBtnR())) ret.add(getInfoBtnR());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getInfoDtlL()) return "InfoDtl";
		if(aCnt == getInfoBtnR()) return "InfoBtn";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("InfoDtl")) return getInfoDtlL();
		if(bId.equals("InfoBtn")) return getInfoBtnR();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(InfoDtlPanel);
		ret.add(InfoBtnPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_SrchCnd_FW_A() {
		aInfoDtlL = createInfoDtlL();
		aInfoBtnR = createInfoBtnR();

	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_SrchCnd_FW_A(String name) {
		aInfoDtlL = createInfoDtlL();
		createInfoDtlTable();
		InfoDtlTable.setRowName(name);
		aInfoBtnR = createInfoBtnR();
	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP_SrchCnd_FW.jbCreateInfo((FSBAP_SrchCnd)this);
		FSBAP_SrchCnd_FW.jbCreateInfoDtl((FSBAP_SrchCnd)this);
		FSBAP_SrchCnd_FW.jbCreateInfoBtn((FSBAP_SrchCnd)this);
	}

	/**
	 * [Info]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateInfo(FSBAP_SrchCnd p) {
	}

	/**
	 * [InfoDtl]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateInfoDtl(FSBAP_SrchCnd p) {
	}

	/**
	 * [InfoBtn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateInfoBtn(FSBAP_SrchCnd p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}

	
	/** [InfoDtl_radio_ListPutter]の定義 */
	private MCListPutter InfoDtl_radio_p = null;

	/**
	 * [InfoDtl_radio_ListPutter]の取得
	 */
	protected MCListPutter getInfoDtl_radio_ListPutter() {
		if (InfoDtl_radio_p == null) {
			InfoDtl_radio_p = createInfoDtl_radio_ListPutter(columnInfoDtl_radio, "radio", "radio_nm");

		}
		return InfoDtl_radio_p;
	}
	
	
	/** [InfoDtl_day_of_week_type_ListPutter]の定義 */
	private MCListPutter InfoDtl_day_of_week_type_p = null;

	/**
	 * [InfoDtl_day_of_week_type_ListPutter]の取得
	 */
	protected MCListPutter getInfoDtl_day_of_week_type_ListPutter() {
		if (InfoDtl_day_of_week_type_p == null) {
			InfoDtl_day_of_week_type_p = createInfoDtl_day_of_week_type_ListPutter(columnInfoDtl_day_of_week_type, "day_of_week_type", "day_of_week_type_nm");

		}
		return InfoDtl_day_of_week_type_p;
	}
	

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP_SrchCnd create(){
		FSBAP_SrchCnd p = new FSBAP_SrchCnd();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP_SrchCnd create(String name){
		FSBAP_SrchCnd p = new FSBAP_SrchCnd(name);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP_SrchCnd_FW.jbfInitInfo((FSBAP_SrchCnd)this);
		FSBAP_SrchCnd_FW.jbfInitInfoDtl((FSBAP_SrchCnd)this);
		FSBAP_SrchCnd_FW.jbfInitInfoBtn((FSBAP_SrchCnd)this);
		FSBAP_SrchCnd_FW.jbInitInfo((FSBAP_SrchCnd)this);
		FSBAP_SrchCnd_FW.jbInitInfoDtl((FSBAP_SrchCnd)this);
		FSBAP_SrchCnd_FW.jbInitInfoBtn((FSBAP_SrchCnd)this);
	}

	/**
	 * [Info]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitInfo(FSBAP_SrchCnd p) {
		// ブロック関連の初期化
		// ブロックの項目の初期化
	}

	/**
	 * [InfoDtl]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitInfoDtl(FSBAP_SrchCnd p) {
		// ブロック関連の初期化
		p.InfoDtlPanel = p.beansFactory.createPanel("InfoDtl");
		p.InfoDtlScrollPane = p.beansFactory.createScrollPane("InfoDtl.scroll");
		p.createInfoDtlTable();
		// ブロックの項目の初期化
		p.columnInfoDtl_set_flg = p.beansFactory.createTableColumn("InfoDtl.set_flg", MCColumnType.CHECK);
		p.columnInfoDtl_panel_name = p.beansFactory.createTableColumn("InfoDtl.panel_name", MCColumnType.TEXT);
		p.columnInfoDtl_name = p.beansFactory.createTableColumn("InfoDtl.name", MCColumnType.TEXT);
		p.columnInfoDtl_focus_flg = p.beansFactory.createTableColumn("InfoDtl.focus_flg", MCColumnType.CHECK);
		p.columnInfoDtl_required_flg = p.beansFactory.createTableColumn("InfoDtl.required_flg", MCColumnType.CHECK);
		p.columnInfoDtl_text = p.beansFactory.createTableColumn("InfoDtl.text", MCColumnType.TEXT);
		p.columnInfoDtl_check = p.beansFactory.createTableColumn("InfoDtl.check", MCColumnType.CHECK);
		p.columnInfoDtl_radio = p.beansFactory.createTableColumn("InfoDtl.radio", MCColumnType.TEXT_COMBO);
		p.columnInfoDtl_radio_nm = p.beansFactory.createTableColumn("InfoDtl.radio_nm", MCColumnType.TEXT);
		p.columnInfoDtl_today_flg = p.beansFactory.createTableColumn("InfoDtl.today_flg", MCColumnType.CHECK);
		p.columnInfoDtl_firstday_flg = p.beansFactory.createTableColumn("InfoDtl.firstday_flg", MCColumnType.CHECK);
		p.columnInfoDtl_lastday_flg = p.beansFactory.createTableColumn("InfoDtl.lastday_flg", MCColumnType.CHECK);
		p.columnInfoDtl_date = p.beansFactory.createTableColumn("InfoDtl.date", MCColumnType.TIMESTAMP);
		p.columnInfoDtl_month = p.beansFactory.createTableColumn("InfoDtl.month", MCColumnType.NUMBER);
		p.columnInfoDtl_week = p.beansFactory.createTableColumn("InfoDtl.week", MCColumnType.NUMBER);
		p.columnInfoDtl_day_of_week_type = p.beansFactory.createTableColumn("InfoDtl.day_of_week_type", MCColumnType.TEXT_COMBO);
		p.columnInfoDtl_day_of_week_type_nm = p.beansFactory.createTableColumn("InfoDtl.day_of_week_type_nm", MCColumnType.TEXT);
		p.columnInfoDtl_day = p.beansFactory.createTableColumn("InfoDtl.day", MCColumnType.NUMBER);
		p.columnInfoDtl_hour = p.beansFactory.createTableColumn("InfoDtl.hour", MCColumnType.NUMBER);
		p.columnInfoDtl_minute = p.beansFactory.createTableColumn("InfoDtl.minute", MCColumnType.NUMBER);
		p.columnInfoDtl_num = p.beansFactory.createTableColumn("InfoDtl.num", MCColumnType.NUMBER);
	}

	/**
	 * [InfoBtn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitInfoBtn(FSBAP_SrchCnd p) {
		// ブロック関連の初期化
		p.InfoBtnPanel = p.beansFactory.createPanel("InfoBtn");
		// ブロックの項目の初期化
		p.InfoBtn_select_all = p.beansFactory.createButton("InfoBtn.select_all", "no_border");
		p.InfoBtn_deselect_all = p.beansFactory.createButton("InfoBtn.deselect_all", "no_border");
		p.InfoBtn_srch_flg = p.beansFactory.createCheckBox("InfoBtn.srch_flg");
		p.InfoBtn_clear_flg = p.beansFactory.createCheckBox("InfoBtn.clear_flg");
	}

	/**
	 * [Info]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitInfo(FSBAP_SrchCnd p) {
		// ブロック関連の初期化
		// ブロックの項目の初期化
		p.InfoPanel.add(p.InfoDtlPanel, null);
		p.InfoPanel.setLastBeans(p.InfoDtlPanel);
		p.InfoDtlPanel.setNextBeans(p.InfoBtnPanel);
		p.InfoPanel.add(p.InfoBtnPanel, null);
	}

	/**
	 * [InfoDtl]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitInfoDtl(FSBAP_SrchCnd p) {
		// ブロック関連の初期化
		p.InfoDtlPanel.add(p.InfoDtlScrollPane);
		p.InfoDtlPanel.setLastBeans(p.InfoDtlTable);
		p.InfoDtlScrollPane.setViewportView(p.InfoDtlTable);
		p.InfoDtlTable.setList(p.getInfoDtlL());
		p.InfoDtlPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * [InfoBtn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitInfoBtn(FSBAP_SrchCnd p) {
		// ブロック関連の初期化
		p.InfoBtnPanel.setLayoutPosition("S");
		// ブロックの項目の初期化
		p.InfoBtn_select_all.setIcon("SELECT_ALL");
		p.InfoBtn_select_all.setFunctionKey(MCFunctionKey.F13);
		p.InfoBtnPanel.add(p.InfoBtn_select_all);
		p.InfoBtnPanel.setLastBeans(p.InfoBtn_select_all);
		p.InfoBtn_select_all.setNextBeans(p.InfoBtn_deselect_all);
		p.InfoBtn_deselect_all.setIcon("DESELECT_ALL");
		p.InfoBtn_deselect_all.setFunctionKey(MCFunctionKey.F14);
		p.InfoBtnPanel.add(p.InfoBtn_deselect_all);
		p.InfoBtn_deselect_all.setNextBeans(p.InfoBtn_srch_flg);
		p.InfoBtnPanel.add(p.InfoBtn_srch_flg);
		p.InfoBtn_srch_flg.setNextBeans(p.InfoBtn_clear_flg);
		p.InfoBtn_srch_flg.setRow(p.getInfoBtnR(), mcframe.clientFSBA.FSBAP0310.InfoBtnR.srch_flg_META);
		p.InfoBtnPanel.add(p.InfoBtn_clear_flg);
		p.InfoBtn_clear_flg.setRow(p.getInfoBtnR(), mcframe.clientFSBA.FSBAP0310.InfoBtnR.clear_flg_META);
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "G";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP_SrchCnd_FW.mcInitInfo((FSBAP_SrchCnd)this);
		FSBAP_SrchCnd_FW.mcInitInfoDtl((FSBAP_SrchCnd)this);
		FSBAP_SrchCnd_FW.mcInitInfoBtn((FSBAP_SrchCnd)this);

		// [INIT]ステータスのモードの設定
		FSBAP_SrchCnd_FW.statusInitINIT_Info((FSBAP_SrchCnd)this);
		FSBAP_SrchCnd_FW.statusInitINIT_InfoDtl((FSBAP_SrchCnd)this);
		FSBAP_SrchCnd_FW.statusInitINIT_InfoBtn((FSBAP_SrchCnd)this);

		// [EDIT]ステータスのモードの設定
		FSBAP_SrchCnd_FW.statusInitEDIT_Info((FSBAP_SrchCnd)this);
		FSBAP_SrchCnd_FW.statusInitEDIT_InfoDtl((FSBAP_SrchCnd)this);
		FSBAP_SrchCnd_FW.statusInitEDIT_InfoBtn((FSBAP_SrchCnd)this);

		// [DISABLE]ステータスのモードの設定
		FSBAP_SrchCnd_FW.statusInitDISABLE_Info((FSBAP_SrchCnd)this);
		FSBAP_SrchCnd_FW.statusInitDISABLE_InfoDtl((FSBAP_SrchCnd)this);
		FSBAP_SrchCnd_FW.statusInitDISABLE_InfoBtn((FSBAP_SrchCnd)this);

	}

	/**
	 *  [Info]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitInfo(FSBAP_SrchCnd p) {
	}

	/**
	 *  [InfoDtl]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitInfoDtl(FSBAP_SrchCnd p) {
		p.InfoDtlTable.addAllListener(p);
		p.columnInfoDtl_set_flg.addAllListener(p);
		p.columnInfoDtl_panel_name.addAllListener(p);
		p.columnInfoDtl_panel_name.setListListener(p);
		p.columnInfoDtl_name.addAllListener(p);
		p.columnInfoDtl_name.setListListener(p);
		p.columnInfoDtl_focus_flg.addAllListener(p);
		p.columnInfoDtl_required_flg.addAllListener(p);
		p.columnInfoDtl_text.addAllListener(p);
		p.columnInfoDtl_text.setListListener(p);
		p.columnInfoDtl_check.addAllListener(p);
		p.columnInfoDtl_radio.addAllListener(p);
		p.columnInfoDtl_radio.setListListener(p);
		p.columnInfoDtl_radio_nm.addAllListener(p);
		p.columnInfoDtl_radio_nm.setListListener(p);
		p.columnInfoDtl_today_flg.addAllListener(p);
		p.columnInfoDtl_firstday_flg.addAllListener(p);
		p.columnInfoDtl_lastday_flg.addAllListener(p);
		p.columnInfoDtl_date.addAllListener(p);
		p.columnInfoDtl_date.setListListener(p);
		p.columnInfoDtl_month.addAllListener(p);
		p.columnInfoDtl_month.setListListener(p);
		p.columnInfoDtl_week.addAllListener(p);
		p.columnInfoDtl_week.setListListener(p);
		p.columnInfoDtl_day_of_week_type.addAllListener(p);
		p.columnInfoDtl_day_of_week_type.setListListener(p);
		p.columnInfoDtl_day_of_week_type_nm.addAllListener(p);
		p.columnInfoDtl_day_of_week_type_nm.setListListener(p);
		p.columnInfoDtl_day.addAllListener(p);
		p.columnInfoDtl_day.setListListener(p);
		p.columnInfoDtl_hour.addAllListener(p);
		p.columnInfoDtl_hour.setListListener(p);
		p.columnInfoDtl_minute.addAllListener(p);
		p.columnInfoDtl_minute.setListListener(p);
		p.columnInfoDtl_num.addAllListener(p);
		p.columnInfoDtl_num.setListListener(p);
	}

	/**
	 *  [InfoBtn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitInfoBtn(FSBAP_SrchCnd p) {
		p.InfoBtn_select_all.addAllListener(p);
		p.InfoBtn_select_all.setAPMethodName("doInfoBtn_select_all");
		p.InfoBtn_deselect_all.addAllListener(p);
		p.InfoBtn_deselect_all.setAPMethodName("doInfoBtn_deselect_all");
		p.InfoBtn_srch_flg.addAllListener(p);
		p.InfoBtn_clear_flg.addAllListener(p);
	}

	/**
	 * [INIT]ステータスの[Info]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Info(FSBAP_SrchCnd p){

	}

	/**
	 * [INIT]ステータスの[InfoDtl]ブロックのモードの設定
	 */
	protected static void statusInitINIT_InfoDtl(FSBAP_SrchCnd p){
		p.columnInfoDtl_set_flg.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfoDtl_panel_name.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfoDtl_name.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfoDtl_focus_flg.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfoDtl_required_flg.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfoDtl_text.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfoDtl_check.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfoDtl_radio.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfoDtl_radio_nm.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfoDtl_today_flg.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfoDtl_firstday_flg.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfoDtl_lastday_flg.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfoDtl_date.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfoDtl_month.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfoDtl_week.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfoDtl_day_of_week_type.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfoDtl_day_of_week_type_nm.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfoDtl_day.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfoDtl_hour.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfoDtl_minute.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfoDtl_num.putMode(p, INIT, MCMode.READ_ONLY);

	}

	/**
	 * [INIT]ステータスの[InfoBtn]ブロックのモードの設定
	 */
	protected static void statusInitINIT_InfoBtn(FSBAP_SrchCnd p){
		p.InfoBtn_select_all.putMode(p, INIT, MCMode.DISABLE);
		p.InfoBtn_deselect_all.putMode(p, INIT, MCMode.DISABLE);
		p.InfoBtn_srch_flg.putMode(p, INIT, MCMode.READ_ONLY);
		p.InfoBtn_clear_flg.putMode(p, INIT, MCMode.READ_ONLY);

	}

	/**
	 * [EDIT]ステータスの[Info]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_Info(FSBAP_SrchCnd p){

	}

	/**
	 * [EDIT]ステータスの[InfoDtl]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_InfoDtl(FSBAP_SrchCnd p){
		p.columnInfoDtl_set_flg.putMode(p, EDIT, MCMode.REQUIRED);
		p.columnInfoDtl_panel_name.putMode(p, EDIT, MCMode.READ_ONLY);
		p.columnInfoDtl_name.putMode(p, EDIT, MCMode.READ_ONLY);
		p.columnInfoDtl_focus_flg.putMode(p, EDIT, MCMode.REQUIRED);
		p.columnInfoDtl_required_flg.putMode(p, EDIT, MCMode.REQUIRED);
		p.columnInfoDtl_text.putMode(p, EDIT, MCMode.ENABLE);
		p.columnInfoDtl_check.putMode(p, EDIT, MCMode.REQUIRED);
		p.columnInfoDtl_radio.putMode(p, EDIT, MCMode.ENABLE);
		p.columnInfoDtl_radio_nm.putMode(p, EDIT, MCMode.READ_ONLY);
		p.columnInfoDtl_today_flg.putMode(p, EDIT, MCMode.REQUIRED);
		p.columnInfoDtl_firstday_flg.putMode(p, EDIT, MCMode.REQUIRED);
		p.columnInfoDtl_lastday_flg.putMode(p, EDIT, MCMode.REQUIRED);
		p.columnInfoDtl_date.putMode(p, EDIT, MCMode.ENABLE);
		p.columnInfoDtl_month.putMode(p, EDIT, MCMode.ENABLE);
		p.columnInfoDtl_week.putMode(p, EDIT, MCMode.ENABLE);
		p.columnInfoDtl_day_of_week_type.putMode(p, EDIT, MCMode.ENABLE);
		p.columnInfoDtl_day_of_week_type_nm.putMode(p, EDIT, MCMode.READ_ONLY);
		p.columnInfoDtl_day.putMode(p, EDIT, MCMode.ENABLE);
		p.columnInfoDtl_hour.putMode(p, EDIT, MCMode.ENABLE);
		p.columnInfoDtl_minute.putMode(p, EDIT, MCMode.ENABLE);
		p.columnInfoDtl_num.putMode(p, EDIT, MCMode.ENABLE);

	}

	/**
	 * [EDIT]ステータスの[InfoBtn]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_InfoBtn(FSBAP_SrchCnd p){
		p.InfoBtn_select_all.putMode(p, EDIT, MCMode.ENABLE);
		p.InfoBtn_deselect_all.putMode(p, EDIT, MCMode.ENABLE);
		p.InfoBtn_srch_flg.putMode(p, EDIT, MCMode.REQUIRED);
		p.InfoBtn_clear_flg.putMode(p, EDIT, MCMode.REQUIRED);

	}

	/**
	 * [DISABLE]ステータスの[Info]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_Info(FSBAP_SrchCnd p){

	}

	/**
	 * [DISABLE]ステータスの[InfoDtl]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_InfoDtl(FSBAP_SrchCnd p){
		p.columnInfoDtl_set_flg.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnInfoDtl_panel_name.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnInfoDtl_name.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnInfoDtl_focus_flg.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnInfoDtl_required_flg.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnInfoDtl_text.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnInfoDtl_check.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnInfoDtl_radio.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnInfoDtl_radio_nm.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnInfoDtl_today_flg.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnInfoDtl_firstday_flg.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnInfoDtl_lastday_flg.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnInfoDtl_date.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnInfoDtl_month.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnInfoDtl_week.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnInfoDtl_day_of_week_type.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnInfoDtl_day_of_week_type_nm.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnInfoDtl_day.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnInfoDtl_hour.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnInfoDtl_minute.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnInfoDtl_num.putMode(p, DISABLE, MCMode.READ_ONLY);

	}

	/**
	 * [DISABLE]ステータスの[InfoBtn]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_InfoBtn(FSBAP_SrchCnd p){
		p.InfoBtn_select_all.putMode(p, DISABLE, MCMode.DISABLE);
		p.InfoBtn_deselect_all.putMode(p, DISABLE, MCMode.DISABLE);
		p.InfoBtn_srch_flg.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.InfoBtn_clear_flg.putMode(p, DISABLE, MCMode.READ_ONLY);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return INIT;
	}

	/**
	 * Table/Tree/GanttChartの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
		FSBAP_SrchCnd_FW.setTableConfigInfoDtl((FSBAP_SrchCnd)this);
	}

	/**
	 * [InfoDtl]ブロックのTableの設定
	 */
	protected static void setTableConfigInfoDtl(FSBAP_SrchCnd p) {
		p.columnInfoDtl_set_flg.setMeta(mcframe.clientFXUC.FXUCP0070.SrchCndR.set_flg_META);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_set_flg);
		p.columnInfoDtl_panel_name.setMeta(mcframe.clientFXUC.FXUCP0070.SrchCndR.panel_name_META);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_panel_name);
		p.columnInfoDtl_name.setMeta(mcframe.clientFXUC.FXUCP0070.SrchCndR.name_META);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_name);
		p.columnInfoDtl_focus_flg.setMeta(mcframe.clientFXUC.FXUCP0070.SrchCndR.focus_flg_META);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_focus_flg);
		p.columnInfoDtl_required_flg.setMeta(mcframe.clientFXUC.FXUCP0070.SrchCndR.required_flg_META);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_required_flg);
		p.columnInfoDtl_text.setMeta(mcframe.clientFXUC.FXUCP0070.SrchCndR.text_META);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_text);
		p.columnInfoDtl_check.setMeta(mcframe.clientFXUC.FXUCP0070.SrchCndR.check_META);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_check);
		p.columnInfoDtl_radio.setMeta(mcframe.clientFXUC.FXUCP0070.SrchCndR.radio_META);
		p.columnInfoDtl_radio.addLinkBeans(p.columnInfoDtl_radio_nm);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_radio);
		p.columnInfoDtl_radio_nm.setMeta(mcframe.clientFXUC.FXUCP0070.SrchCndR.radio_nm_META);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_radio_nm);
		p.columnInfoDtl_today_flg.setMeta(mcframe.clientFXUC.FXUCP0070.SrchCndR.today_flg_META);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_today_flg);
		p.columnInfoDtl_firstday_flg.setMeta(mcframe.clientFXUC.FXUCP0070.SrchCndR.firstday_flg_META);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_firstday_flg);
		p.columnInfoDtl_lastday_flg.setMeta(mcframe.clientFXUC.FXUCP0070.SrchCndR.lastday_flg_META);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_lastday_flg);
		p.columnInfoDtl_date.setMeta(mcframe.clientFXUC.FXUCP0070.SrchCndR.date_META);
		p.columnInfoDtl_date.setFormatID("YMDHMSS");
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_date);
		p.columnInfoDtl_month.setMeta(mcframe.clientFXUC.FXUCP0070.SrchCndR.month_META);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_month);
		p.columnInfoDtl_week.setMeta(mcframe.clientFXUC.FXUCP0070.SrchCndR.week_META);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_week);
		p.columnInfoDtl_day_of_week_type.setMeta(mcframe.clientFXUC.FXUCP0070.SrchCndR.day_of_week_type_META);
		p.columnInfoDtl_day_of_week_type.addLinkBeans(p.columnInfoDtl_day_of_week_type_nm);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_day_of_week_type);
		p.columnInfoDtl_day_of_week_type_nm.setMeta(mcframe.clientFXUC.FXUCP0070.SrchCndR.day_of_week_type_nm_META);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_day_of_week_type_nm);
		p.columnInfoDtl_day.setMeta(mcframe.clientFXUC.FXUCP0070.SrchCndR.day_META);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_day);
		p.columnInfoDtl_hour.setMeta(mcframe.clientFXUC.FXUCP0070.SrchCndR.hour_META);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_hour);
		p.columnInfoDtl_minute.setMeta(mcframe.clientFXUC.FXUCP0070.SrchCndR.minute_META);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_minute);
		p.columnInfoDtl_num.setMeta(mcframe.clientFXUC.FXUCP0070.SrchCndR.num_META);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_num);
		// スクロール固定カラムの指定
		p.InfoDtlTable.setUnscrollColumn(p.columnInfoDtl_name);
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
		columnInfoDtl_radio.setListVisibleColumn(MCListLogic.getViewColumnName());
		columnInfoDtl_radio.getListConfig().setPutter(getInfoDtl_radio_ListPutter());
		columnInfoDtl_day_of_week_type.setListVisibleColumn(MCListLogic.getViewColumnName());
		columnInfoDtl_day_of_week_type.getListConfig().setPutter(getInfoDtl_day_of_week_type_ListPutter());
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
	}

	/**
	 * [InfoDtl_radio_ListPutter]の作成
	 */
	protected MCListPutter createInfoDtl_radio_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("");
		return lp;
	}
	 
	/**
	 * [InfoDtl_day_of_week_type_ListPutter]の作成
	 */
	protected MCListPutter createInfoDtl_day_of_week_type_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("FS.FSUAP0010.DayOfWeekType");
		return lp;
	}
	 

	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		if(combo == columnInfoDtl_radio) return getInfoDtl_radio(row, info);
		if(combo == columnInfoDtl_day_of_week_type) return getInfoDtl_day_of_week_type(row, info);
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == InfoBtn_select_all) doInfoBtn_select_all(info);
		else if (ap == InfoBtn_deselect_all) doInfoBtn_deselect_all(info);
	}

	/**
	 * [InfoBtn]パネルの[select_all]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doInfoBtn_select_all(MCEventInfo info);

	/**
	 * [InfoBtn]パネルの[deselect_all]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doInfoBtn_deselect_all(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == InfoDtlTable) return doInfoDtl_VC(info);
		if (vc == columnInfoDtl_set_flg) return doInfoDtl_set_flg_VC(info);
		if (vc == columnInfoDtl_panel_name) return doInfoDtl_panel_name_VC(info);
		if (vc == columnInfoDtl_name) return doInfoDtl_name_VC(info);
		if (vc == columnInfoDtl_focus_flg) return doInfoDtl_focus_flg_VC(info);
		if (vc == columnInfoDtl_required_flg) return doInfoDtl_required_flg_VC(info);
		if (vc == columnInfoDtl_text) return doInfoDtl_text_VC(info);
		if (vc == columnInfoDtl_check) return doInfoDtl_check_VC(info);
		if (vc == columnInfoDtl_radio) return doInfoDtl_radio_VC(info);
		if (vc == columnInfoDtl_radio_nm) return doInfoDtl_radio_nm_VC(info);
		if (vc == columnInfoDtl_today_flg) return doInfoDtl_today_flg_VC(info);
		if (vc == columnInfoDtl_firstday_flg) return doInfoDtl_firstday_flg_VC(info);
		if (vc == columnInfoDtl_lastday_flg) return doInfoDtl_lastday_flg_VC(info);
		if (vc == columnInfoDtl_date) return doInfoDtl_date_VC(info);
		if (vc == columnInfoDtl_month) return doInfoDtl_month_VC(info);
		if (vc == columnInfoDtl_week) return doInfoDtl_week_VC(info);
		if (vc == columnInfoDtl_day_of_week_type) return doInfoDtl_day_of_week_type_VC(info);
		if (vc == columnInfoDtl_day_of_week_type_nm) return doInfoDtl_day_of_week_type_nm_VC(info);
		if (vc == columnInfoDtl_day) return doInfoDtl_day_VC(info);
		if (vc == columnInfoDtl_hour) return doInfoDtl_hour_VC(info);
		if (vc == columnInfoDtl_minute) return doInfoDtl_minute_VC(info);
		if (vc == columnInfoDtl_num) return doInfoDtl_num_VC(info);
		if (vc == InfoBtn_srch_flg) return doInfoBtn_srch_flg_VC(info);
		if (vc == InfoBtn_clear_flg) return doInfoBtn_clear_flg_VC(info);
		return true;
	}

	/**
	 * [InfoDtl]Tableの選択行が変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[set_flg]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_set_flg_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[panel_name]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_panel_name_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[name]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_name_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[focus_flg]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_focus_flg_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[required_flg]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_required_flg_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[text]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_text_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[check]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_check_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[radio]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_radio_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[radio_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_radio_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[today_flg]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_today_flg_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[firstday_flg]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_firstday_flg_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[lastday_flg]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_lastday_flg_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[date]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_date_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[month]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_month_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[week]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_week_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[day_of_week_type]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_day_of_week_type_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[day_of_week_type_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_day_of_week_type_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[day]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_day_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[hour]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_hour_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[minute]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_minute_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[num]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_num_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoBtn]パネルの[srch_flg]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoBtn_srch_flg_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoBtn]パネルの[clear_flg]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoBtn_clear_flg_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == InfoDtlTable) doInfoDtl_NC(info);
		else if (nc == columnInfoDtl_set_flg) doInfoDtl_set_flg_NC(info);
		else if (nc == columnInfoDtl_panel_name) doInfoDtl_panel_name_NC(info);
		else if (nc == columnInfoDtl_name) doInfoDtl_name_NC(info);
		else if (nc == columnInfoDtl_focus_flg) doInfoDtl_focus_flg_NC(info);
		else if (nc == columnInfoDtl_required_flg) doInfoDtl_required_flg_NC(info);
		else if (nc == columnInfoDtl_text) doInfoDtl_text_NC(info);
		else if (nc == columnInfoDtl_check) doInfoDtl_check_NC(info);
		else if (nc == columnInfoDtl_radio) doInfoDtl_radio_NC(info);
		else if (nc == columnInfoDtl_radio_nm) doInfoDtl_radio_nm_NC(info);
		else if (nc == columnInfoDtl_today_flg) doInfoDtl_today_flg_NC(info);
		else if (nc == columnInfoDtl_firstday_flg) doInfoDtl_firstday_flg_NC(info);
		else if (nc == columnInfoDtl_lastday_flg) doInfoDtl_lastday_flg_NC(info);
		else if (nc == columnInfoDtl_date) doInfoDtl_date_NC(info);
		else if (nc == columnInfoDtl_month) doInfoDtl_month_NC(info);
		else if (nc == columnInfoDtl_week) doInfoDtl_week_NC(info);
		else if (nc == columnInfoDtl_day_of_week_type) doInfoDtl_day_of_week_type_NC(info);
		else if (nc == columnInfoDtl_day_of_week_type_nm) doInfoDtl_day_of_week_type_nm_NC(info);
		else if (nc == columnInfoDtl_day) doInfoDtl_day_NC(info);
		else if (nc == columnInfoDtl_hour) doInfoDtl_hour_NC(info);
		else if (nc == columnInfoDtl_minute) doInfoDtl_minute_NC(info);
		else if (nc == columnInfoDtl_num) doInfoDtl_num_NC(info);
		else if (nc == InfoBtn_srch_flg) doInfoBtn_srch_flg_NC(info);
		else if (nc == InfoBtn_clear_flg) doInfoBtn_clear_flg_NC(info);
	}

	/**
	 * [InfoDtl]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[set_flg]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_set_flg_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[panel_name]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_panel_name_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[name]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_name_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[focus_flg]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_focus_flg_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[required_flg]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_required_flg_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[text]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_text_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[check]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_check_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[radio]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_radio_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[radio_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_radio_nm_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[today_flg]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_today_flg_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[firstday_flg]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_firstday_flg_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[lastday_flg]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_lastday_flg_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[date]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_date_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[month]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_month_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[week]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_week_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[day_of_week_type]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_day_of_week_type_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[day_of_week_type_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_day_of_week_type_nm_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[day]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_day_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[hour]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_hour_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[minute]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_minute_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[num]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_num_NC(MCEventInfo info){
	}

	/**
	 * [InfoBtn]パネルの[srch_flg]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoBtn_srch_flg_NC(MCEventInfo info){
	}

	/**
	 * [InfoBtn]パネルの[clear_flg]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoBtn_clear_flg_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == InfoDtlTable) doInfoDtl_NE(info);
		else if (ne == columnInfoDtl_set_flg) doInfoDtl_set_flg_NE(info);
		else if (ne == columnInfoDtl_panel_name) doInfoDtl_panel_name_NE(info);
		else if (ne == columnInfoDtl_name) doInfoDtl_name_NE(info);
		else if (ne == columnInfoDtl_focus_flg) doInfoDtl_focus_flg_NE(info);
		else if (ne == columnInfoDtl_required_flg) doInfoDtl_required_flg_NE(info);
		else if (ne == columnInfoDtl_text) doInfoDtl_text_NE(info);
		else if (ne == columnInfoDtl_check) doInfoDtl_check_NE(info);
		else if (ne == columnInfoDtl_radio) doInfoDtl_radio_NE(info);
		else if (ne == columnInfoDtl_radio_nm) doInfoDtl_radio_nm_NE(info);
		else if (ne == columnInfoDtl_today_flg) doInfoDtl_today_flg_NE(info);
		else if (ne == columnInfoDtl_firstday_flg) doInfoDtl_firstday_flg_NE(info);
		else if (ne == columnInfoDtl_lastday_flg) doInfoDtl_lastday_flg_NE(info);
		else if (ne == columnInfoDtl_date) doInfoDtl_date_NE(info);
		else if (ne == columnInfoDtl_month) doInfoDtl_month_NE(info);
		else if (ne == columnInfoDtl_week) doInfoDtl_week_NE(info);
		else if (ne == columnInfoDtl_day_of_week_type) doInfoDtl_day_of_week_type_NE(info);
		else if (ne == columnInfoDtl_day_of_week_type_nm) doInfoDtl_day_of_week_type_nm_NE(info);
		else if (ne == columnInfoDtl_day) doInfoDtl_day_NE(info);
		else if (ne == columnInfoDtl_hour) doInfoDtl_hour_NE(info);
		else if (ne == columnInfoDtl_minute) doInfoDtl_minute_NE(info);
		else if (ne == columnInfoDtl_num) doInfoDtl_num_NE(info);
		else if (ne == InfoBtn_srch_flg) doInfoBtn_srch_flg_NE(info);
		else if (ne == InfoBtn_clear_flg) doInfoBtn_clear_flg_NE(info);
	}

	/**
	 * [InfoDtl]TableのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[set_flg]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_set_flg_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[panel_name]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_panel_name_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[name]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_name_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[focus_flg]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_focus_flg_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[required_flg]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_required_flg_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[text]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_text_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[check]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_check_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[radio]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_radio_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[radio_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_radio_nm_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[today_flg]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_today_flg_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[firstday_flg]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_firstday_flg_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[lastday_flg]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_lastday_flg_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[date]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_date_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[month]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_month_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[week]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_week_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[day_of_week_type]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_day_of_week_type_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[day_of_week_type_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_day_of_week_type_nm_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[day]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_day_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[hour]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_hour_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[minute]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_minute_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[num]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_num_NE(MCEventInfo info){
	}

	/**
	 * [InfoBtn]パネルの[srch_flg]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoBtn_srch_flg_NE(MCEventInfo info){
	}

	/**
	 * [InfoBtn]パネルの[clear_flg]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoBtn_clear_flg_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == InfoDtlTable) doInfoDtl_NX(info);
		else if (nx == columnInfoDtl_set_flg) doInfoDtl_set_flg_NX(info);
		else if (nx == columnInfoDtl_panel_name) doInfoDtl_panel_name_NX(info);
		else if (nx == columnInfoDtl_name) doInfoDtl_name_NX(info);
		else if (nx == columnInfoDtl_focus_flg) doInfoDtl_focus_flg_NX(info);
		else if (nx == columnInfoDtl_required_flg) doInfoDtl_required_flg_NX(info);
		else if (nx == columnInfoDtl_text) doInfoDtl_text_NX(info);
		else if (nx == columnInfoDtl_check) doInfoDtl_check_NX(info);
		else if (nx == columnInfoDtl_radio) doInfoDtl_radio_NX(info);
		else if (nx == columnInfoDtl_radio_nm) doInfoDtl_radio_nm_NX(info);
		else if (nx == columnInfoDtl_today_flg) doInfoDtl_today_flg_NX(info);
		else if (nx == columnInfoDtl_firstday_flg) doInfoDtl_firstday_flg_NX(info);
		else if (nx == columnInfoDtl_lastday_flg) doInfoDtl_lastday_flg_NX(info);
		else if (nx == columnInfoDtl_date) doInfoDtl_date_NX(info);
		else if (nx == columnInfoDtl_month) doInfoDtl_month_NX(info);
		else if (nx == columnInfoDtl_week) doInfoDtl_week_NX(info);
		else if (nx == columnInfoDtl_day_of_week_type) doInfoDtl_day_of_week_type_NX(info);
		else if (nx == columnInfoDtl_day_of_week_type_nm) doInfoDtl_day_of_week_type_nm_NX(info);
		else if (nx == columnInfoDtl_day) doInfoDtl_day_NX(info);
		else if (nx == columnInfoDtl_hour) doInfoDtl_hour_NX(info);
		else if (nx == columnInfoDtl_minute) doInfoDtl_minute_NX(info);
		else if (nx == columnInfoDtl_num) doInfoDtl_num_NX(info);
		else if (nx == InfoBtn_srch_flg) doInfoBtn_srch_flg_NX(info);
		else if (nx == InfoBtn_clear_flg) doInfoBtn_clear_flg_NX(info);
	}

	/**
	 * [InfoDtl]TableのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[set_flg]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_set_flg_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[panel_name]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_panel_name_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[name]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_name_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[focus_flg]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_focus_flg_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[required_flg]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_required_flg_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[text]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_text_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[check]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_check_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[radio]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_radio_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[radio_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_radio_nm_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[today_flg]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_today_flg_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[firstday_flg]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_firstday_flg_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[lastday_flg]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_lastday_flg_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[date]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_date_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[month]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_month_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[week]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_week_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[day_of_week_type]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_day_of_week_type_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[day_of_week_type_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_day_of_week_type_nm_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[day]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_day_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[hour]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_hour_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[minute]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_minute_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[num]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_num_NX(MCEventInfo info){
	}

	/**
	 * [InfoBtn]パネルの[srch_flg]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoBtn_srch_flg_NX(MCEventInfo info){
	}

	/**
	 * [InfoBtn]パネルの[clear_flg]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoBtn_clear_flg_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == columnInfoDtl_panel_name) doInfoDtl_panel_name_LC(info);
		else if (lc == columnInfoDtl_name) doInfoDtl_name_LC(info);
		else if (lc == columnInfoDtl_text) doInfoDtl_text_LC(info);
		else if (lc == columnInfoDtl_radio) doInfoDtl_radio_LC(info);
		else if (lc == columnInfoDtl_radio_nm) doInfoDtl_radio_nm_LC(info);
		else if (lc == columnInfoDtl_date) doInfoDtl_date_LC(info);
		else if (lc == columnInfoDtl_month) doInfoDtl_month_LC(info);
		else if (lc == columnInfoDtl_week) doInfoDtl_week_LC(info);
		else if (lc == columnInfoDtl_day_of_week_type) doInfoDtl_day_of_week_type_LC(info);
		else if (lc == columnInfoDtl_day_of_week_type_nm) doInfoDtl_day_of_week_type_nm_LC(info);
		else if (lc == columnInfoDtl_day) doInfoDtl_day_LC(info);
		else if (lc == columnInfoDtl_hour) doInfoDtl_hour_LC(info);
		else if (lc == columnInfoDtl_minute) doInfoDtl_minute_LC(info);
		else if (lc == columnInfoDtl_num) doInfoDtl_num_LC(info);
	}

	/**
	 * [InfoDtl]パネルの[panel_name]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_panel_name_LC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[name]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_name_LC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[text]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_text_LC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[radio]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_radio_LC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[radio_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_radio_nm_LC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[date]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_date_LC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[month]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_month_LC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[week]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_week_LC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[day_of_week_type]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_day_of_week_type_LC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[day_of_week_type_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_day_of_week_type_nm_LC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[day]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_day_LC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[hour]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_hour_LC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[minute]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_minute_LC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[num]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_num_LC(MCEventInfo info){
	}

	/**
	 * コンボ／リストのリスト[columnInfoDtl_radio]の作成メソッド
	 */
	public MCList getInfoDtl_radio(MCRow row, MCEventInfo info){
		return null;
	}

	/**
	 * コンボ／リストのリスト[columnInfoDtl_day_of_week_type]の作成メソッド
	 */
	public MCList getInfoDtl_day_of_week_type(MCRow row, MCEventInfo info){
		return ((mcframe.clientFSUA.FSUAP0010.FSUAP_List)MCListLogic.create("mcframe.clientFSUA.FSUAP0010.FSUAP_List", this)).getDayOfWeekType(row, info);
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}