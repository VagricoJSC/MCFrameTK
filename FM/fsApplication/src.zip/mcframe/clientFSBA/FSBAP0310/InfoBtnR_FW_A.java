package mcframe.clientFSBA.FSBAP0310;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"InfoBtn"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class InfoBtnR_FW_A extends MCConstRow {

	/**
	 *  初期検索.<p>
	 *
	 */
	public static final String $srch_flg = "srch_flg";
	/**
	 *  画面クリア時も設定する.<p>
	 *
	 */
	public static final String $clear_flg = "clear_flg";


	public static final MCMeta srch_flg_META = createBooleanMeta($srch_flg);
	public static final MCMeta clear_flg_META = createBooleanMeta($clear_flg);

	protected static final ConstMetaList<InfoBtnR> constMetas = new ConstMetaList<InfoBtnR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			srch_flg_META,
			clear_flg_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected InfoBtnR_FW_A(ConstMetaList<? extends InfoBtnR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public InfoBtnR clone() {
		return (InfoBtnR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public InfoBtnR createInstance() {
		return (InfoBtnR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public InfoBtnR getValues(String... names) {
		return (InfoBtnR) super.getValues(names);
	}



	/**
	 *  初期検索.<p>
	 *
	 */
	public boolean srch_flg() {
		return getConstBoolean(offset + 0, $srch_flg);
	}

	/**
	 *  初期検索.<p>
	 *
	 */
	public void srch_flg(boolean value) {
		setConstBoolean(offset + 0, $srch_flg, value);
	}


	/**
	 *  画面クリア時も設定する.<p>
	 *
	 */
	public boolean clear_flg() {
		return getConstBoolean(offset + 1, $clear_flg);
	}

	/**
	 *  画面クリア時も設定する.<p>
	 *
	 */
	public void clear_flg(boolean value) {
		setConstBoolean(offset + 1, $clear_flg, value);
	}


	public boolean getBoolean(String name) {
		if ($srch_flg.equalsIgnoreCase(name)) {
			return srch_flg();
		}
		if ($clear_flg.equalsIgnoreCase(name)) {
			return clear_flg();
		}
		return super.getBoolean(name);
	}

	public boolean getBooleanNE(String name) {
		if ($srch_flg.equalsIgnoreCase(name)) {
			return srch_flg();
		}
		if ($clear_flg.equalsIgnoreCase(name)) {
			return clear_flg();
		}
		return super.getBooleanNE(name);
	}

	public void setBoolean(String name, boolean value) {
		if ($srch_flg.equalsIgnoreCase(name)) {
			srch_flg(value);
			return;
		}
		if ($clear_flg.equalsIgnoreCase(name)) {
			clear_flg(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setBooleanNE(String name, boolean value) {
		if ($srch_flg.equalsIgnoreCase(name)) {
			srch_flg(value);
			return;
		}
		if ($clear_flg.equalsIgnoreCase(name)) {
			clear_flg(value);
			return;
		}
		super.setBooleanNE(name, value);
	}



}

