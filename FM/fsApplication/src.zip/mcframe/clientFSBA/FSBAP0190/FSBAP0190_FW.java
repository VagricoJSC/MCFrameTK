package mcframe.clientFSBA.FSBAP0190;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;

import mcframe.clientFSBA.FSBAP0150.*;

import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START

import mcframe.clientFXBA.FXBAP0100.FXBAP_PopupConfig;

import mcframe.clientFSUC.FSUCP0000.FSUCP_PopupConfig;

import mcframe.clientCore.resource.MCConst;
import mcframe.clientCore.beans.popup.MCPopupBeans;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP0190"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP0190_FW extends FSBAP0190_FW_A implements MCMemoPanel {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0190_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	@Override
	public void doSearchMemo() {
		Memo_MemoPanel_PPanel.showCacheMemo();
	}

	@Override
	public void setMemoKey(String... parts) {
		Memo_MemoPanel_PPanel.setMemoKey(parts);
	}

	@Override
	public void setTargetName(String id, String name) {
		Memo_MemoPanel_PPanel.setTargetName(id, name);
	}

	@Override
	public void layoutInit() {
		// 7.0.1 S画面の上部のラベル欄が自動レイアウトで崩れる場合の対応
		// 7.0.2 多言語対応 ラベルがみきれてしまう。
//		MemoPanel.isEnableAutoLayout(false);
//		Memo_MemoPanel_PPanel.LabelPanel.isEnableAutoLayout(false);
		super.layoutInit();
		MemoPanel.remove(Memo_MemoPanel_PPanel);
		MemoPanel.setLayout(new BorderLayout());
		MemoPanel.add(Memo_MemoPanel_PPanel, BorderLayout.CENTER);
	}

	@Override
	protected void setDefaultScreenPosition() {
		super.setDefaultScreenPosition();

		MCRootPanel p = getParentPanel();
		if (p != null) {
			setArrangementCenter(p);
		}
	}

	@Override
	public void mcInitStatus() {
		super.mcInitStatus();

		Memo_MemoPanel_PPanel.adjustStatus();
	}

	@Override
	protected void mcInit() {
		super.mcInit();

		Memo_MemoPanel_PPanel.Command_Update.addAPListener(this);
		Memo_MemoPanel_PPanel.Command_Delete.addAPListener(this);
		Memo_MemoPanel_PPanel.Command_Refresh.addAPListener(this);
	}

	@Override
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);

		if (ap == Memo_MemoPanel_PPanel.Command_Update) {
			doMemo_MemoPanel_PPanel_Command_Update(info);
		}
		else if (ap == Memo_MemoPanel_PPanel.Command_Delete) {
			doMemo_MemoPanel_PPanel_Command_Delete(info);
		}
		else if (ap == Memo_MemoPanel_PPanel.Command_Refresh) {
			doMemo_MemoPanel_PPanel_Command_Refresh(info);
		}
	}

	public void doMemo_MemoPanel_PPanel_Command_Update(MCEventInfo info) {
		Memo_MemoPanel_PPanel.Memo_UserMemo.mcRequestFocus();
	}

	public void doMemo_MemoPanel_PPanel_Command_Delete(MCEventInfo info) {
		Memo_MemoPanel_PPanel.Memo_UserMemo.mcRequestFocus();
	}

	public void doMemo_MemoPanel_PPanel_Command_Refresh(MCEventInfo info) {
		Memo_MemoPanel_PPanel.Memo_UserMemo.mcRequestFocus();
	}

	@Override
	protected FXBAP_PopupConfig createFXBAP_PopupConfig(MCPopupBeans beans) {
		return new WBP_PopupConfig();
	}

	/**
	 * ポップアップコンフィグです。
	 */
	public class WBP_PopupConfig extends FSUCP_PopupConfig {

		public WBP_PopupConfig() {
			super(IGNORE_TABLE_SIZE_CHANGE);
		}

		@Override
		protected boolean ignoreMemo() {
			String k = Memo_MemoPanel_PPanel.getMemoKey();
			if (k != null &&
					k.equals(MCConst.createKey("FS", "FSBAP0190", "memo"))) {
				return true;
			}

			return super.ignoreMemo();
		}

		@Override
		protected boolean ignoreSrchCnd(MCRootPanel panel) {
			return true;
		}

	}

}