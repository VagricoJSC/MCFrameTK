package mcframe.clientFSBA.FSBAP0790;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBAP0790"パネルクラスです。<p>
 *
 * バーコード一覧非表示設定<br>
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP0790_FW_A extends mcframe.clientFSBA.FSBAP0090.FSBAP_ColOdr{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0790";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [InfoDtl]ブロック関連のField定義
	// [InfoDtl]ブロックの項目のField定義
	/**
	 *  フォーカス有.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_focus_flg = null;
	/**
	 *  桁数.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_column_size = null;
	/** [INIT]モードを表す定数 */
	public static final String INIT = "INIT";
	/** [EDIT]モードを表す定数 */
	public static final String EDIT = "EDIT";
	/** [DISABLE]モードを表す定数 */
	public static final String DISABLE = "DISABLE";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{INIT, EDIT, DISABLE};
	
	/** [InfoDtl]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0790.InfoDtlR> aInfoDtlL;

	/**
	 * コピーによってaInfoDtlLを設定します。
	 *
	 * aInfoDtlLのインスタンスは変更されません。
	 *
	 * @param dataset InfoDtlL
	 */
	public void setInfoDtlL(MCList aList) {
		if (getInfoDtlL() != aList) {
			getInfoDtlL().setAll(aList);
		}
	}

	/**
	 * [InfoDtl]ブロックのコンテナaInfoDtlLを返します。
	 *
	 * @return InfoDtlL
	 */
	public MCList getInfoDtlL() {
		return aInfoDtlL;
	}

	/**
	 * aInfoDtlRを作成します。
	 *
	 * @return InfoDtlR
	 */
	public mcframe.clientFSBA.FSBAP0790.InfoDtlR createInfoDtlR() {
		return mcframe.clientFSBA.FSBAP0790.InfoDtlR.create();
	}

	/**
	 * aInfoDtlLを作成します。
	 *
	 * @return InfoDtlL
	 */
	public MCList createInfoDtlL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0790.InfoDtlR.class);
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getInfoDtlL())) ret.add(getInfoDtlL());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getInfoDtlL()) return "InfoDtl";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("InfoDtl")) return getInfoDtlL();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0790_FW_A() {
		aInfoDtlL = createInfoDtlL();

	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP0790_FW_A(String name) {
		aInfoDtlL = createInfoDtlL();
		createInfoDtlTable();
		InfoDtlTable.setRowName(name);
	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP0790_FW.jbCreateInfoDtl((FSBAP0790)this);
	}

	/**
	 * [InfoDtl]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateInfoDtl(FSBAP0790 p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}


	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP0790 create(){
		FSBAP0790 p = new FSBAP0790();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP0790 create(String name){
		FSBAP0790 p = new FSBAP0790(name);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP0790_FW.jbfInitInfoDtl((FSBAP0790)this);
		FSBAP0790_FW.jbInitInfoDtl((FSBAP0790)this);
	}

	/**
	 * [InfoDtl]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitInfoDtl(FSBAP0790 p) {
		// ブロック関連の初期化
		// ブロックの項目の初期化
		p.columnInfoDtl_focus_flg = p.beansFactory.createTableColumn("InfoDtl.focus_flg", MCColumnType.CHECK);
		p.columnInfoDtl_column_size = p.beansFactory.createTableColumn("InfoDtl.column_size", MCColumnType.NUMBER);
	}

	/**
	 * [InfoDtl]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitInfoDtl(FSBAP0790 p) {
		// ブロック関連の初期化
		p.InfoDtlPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "G";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP0790_FW.mcInitInfoDtl((FSBAP0790)this);

		// [INIT]ステータスのモードの設定
		FSBAP0790_FW.statusInitINIT_InfoDtl((FSBAP0790)this);

		// [EDIT]ステータスのモードの設定
		FSBAP0790_FW.statusInitEDIT_InfoDtl((FSBAP0790)this);

		// [DISABLE]ステータスのモードの設定
		FSBAP0790_FW.statusInitDISABLE_InfoDtl((FSBAP0790)this);

	}

	/**
	 *  [InfoDtl]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitInfoDtl(FSBAP0790 p) {
		p.columnInfoDtl_focus_flg.addAllListener(p);
		p.columnInfoDtl_column_size.addAllListener(p);
		p.columnInfoDtl_column_size.setListListener(p);
	}

	/**
	 * [INIT]ステータスの[InfoDtl]ブロックのモードの設定
	 */
	protected static void statusInitINIT_InfoDtl(FSBAP0790 p){
		p.columnInfoDtl_focus_flg.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnInfoDtl_column_size.putMode(p, INIT, MCMode.READ_ONLY);

	}

	/**
	 * [EDIT]ステータスの[InfoDtl]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_InfoDtl(FSBAP0790 p){
		p.columnInfoDtl_focus_flg.putMode(p, EDIT, MCMode.REQUIRED);
		p.columnInfoDtl_column_size.putMode(p, EDIT, MCMode.REQUIRED);

	}

	/**
	 * [DISABLE]ステータスの[InfoDtl]ブロックのモードの設定
	 */
	protected static void statusInitDISABLE_InfoDtl(FSBAP0790 p){
		p.columnInfoDtl_focus_flg.putMode(p, DISABLE, MCMode.READ_ONLY);
		p.columnInfoDtl_column_size.putMode(p, DISABLE, MCMode.READ_ONLY);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return INIT;
	}

	/**
	 * Table/Tree/GanttChartの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
		FSBAP0790_FW.setTableConfigInfoDtl((FSBAP0790)this);
	}

	/**
	 * [InfoDtl]ブロックのTableの設定
	 */
	protected static void setTableConfigInfoDtl(FSBAP0790 p) {
		p.columnInfoDtl_focus_flg.setMeta(mcframe.clientFSBA.FSBAP0790.InfoDtlR.focus_flg_META);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_focus_flg);
		p.columnInfoDtl_column_size.setMeta(mcframe.clientFSBA.FSBAP0790.InfoDtlR.column_size_META);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_column_size);
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
	}


	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
	}

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == columnInfoDtl_focus_flg) return doInfoDtl_focus_flg_VC(info);
		if (vc == columnInfoDtl_column_size) return doInfoDtl_column_size_VC(info);
		return true;
	}

	/**
	 * [InfoDtl]パネルの[focus_flg]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_focus_flg_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[column_size]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_column_size_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == columnInfoDtl_focus_flg) doInfoDtl_focus_flg_NC(info);
		else if (nc == columnInfoDtl_column_size) doInfoDtl_column_size_NC(info);
	}

	/**
	 * [InfoDtl]パネルの[focus_flg]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_focus_flg_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[column_size]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_column_size_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == columnInfoDtl_focus_flg) doInfoDtl_focus_flg_NE(info);
		else if (ne == columnInfoDtl_column_size) doInfoDtl_column_size_NE(info);
	}

	/**
	 * [InfoDtl]パネルの[focus_flg]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_focus_flg_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[column_size]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_column_size_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == columnInfoDtl_focus_flg) doInfoDtl_focus_flg_NX(info);
		else if (nx == columnInfoDtl_column_size) doInfoDtl_column_size_NX(info);
	}

	/**
	 * [InfoDtl]パネルの[focus_flg]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_focus_flg_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[column_size]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_column_size_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == columnInfoDtl_column_size) doInfoDtl_column_size_LC(info);
	}

	/**
	 * [InfoDtl]パネルの[column_size]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_column_size_LC(MCEventInfo info){
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}