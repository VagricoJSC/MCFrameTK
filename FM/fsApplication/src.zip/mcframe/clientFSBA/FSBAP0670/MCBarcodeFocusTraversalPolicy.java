package mcframe.clientFSBA.FSBAP0670;

import java.awt.Component;
import java.awt.Container;
import java.awt.FocusTraversalPolicy;
import java.util.HashMap;
import java.util.Map;

import javax.swing.InternalFrameFocusTraversalPolicy;

import mcframe.clientCore.beans.MCListBeans;
import mcframe.clientCore.beans.MCRootPanel;
import mcframe.clientCore.beans.MCTabOrderBeans;
import mcframe.clientCore.beans.MCTabbedPane;

public class MCBarcodeFocusTraversalPolicy extends InternalFrameFocusTraversalPolicy {

	private final FocusTraversalPolicy _policy;

	public MCBarcodeFocusTraversalPolicy(MCRootPanel p) {
		_policy = p.getFocusTraversalPolicy();
	}

	// フォーカスアウト後の次のフォーカスの設定
	// key : 移動元コンポーネント
	// value : 次のフォーカス遷移先
	Map<Component, Component> _focusoutMap = new HashMap<>();

	/**
	 * フォーカスアウト後の次のフォーカスの設定を追加します。
	 * @param comp 遷移元の画面部品
	 * @param next　遷移先の画面部品
	 */
	public void setFocuoutNext(Component comp, Component next) {
		_focusoutMap.put(comp, next);
	}

	/**
	 * aComponentの次にフォーカスを受け取るComponentを返します。
	 *
	 * @author    shimao
	 * @since     7.0.2.3
	 * @param aContainer 画面
	 * @param aComponent 遷移元の画面部品
	 * @return aComponentの次にフォーカスを受け取るComponent。遷移先が無い場合はnull。
	 */
	@Override
	@SuppressWarnings("deprecation")
	public Component getComponentAfter(Container aContainer, Component aComponent) {
		Component next = _focusoutMap.get(aComponent);
		if (next != null) {
			MCTabOrderBeans tNext = (MCTabOrderBeans) next;
			if (isFocusable(tNext, true)) {
				// このif文はMCFocusTraversalPolicyに合わせて記述しておいた（7023-3292）。
				// しかし、MCListBeansはMCTable、またはMCTreeが継承しているので、フォーカスアウト後の次のフォーカスで設定されることはない。
				// 将来的に別の設定などでMCBarcodeFucusTraversalPolicyが動くようになった場合に、このif文が書いてあると期待されてしまうことを
				// 想定して記述を残しておく。
				if (tNext instanceof MCListBeans) {
					((MCListBeans<?>) tNext).setCellFocusPattern(MCListBeans.NEXT);
				}
				tNext.afterRequestFocus();
				return tNext.getTargetComponent();
			}
			else {
				if (aComponent instanceof MCTabOrderBeans) {
					return ((MCTabOrderBeans) aComponent).getTargetComponent();
				}
				return aComponent;
			}
		}
		return _policy.getComponentAfter(aContainer, aComponent);
	}

	/**
	 * GUI 部品がフォーカスを受け付ける場合は true を返します。
	 *
	 * @author    shimao
	 * @since     7.0.2.3
	 * @param compo GUI 部品
	 * @return GUI 部品がフォーカスを受け付けない場合は false
	 */
	@SuppressWarnings("deprecation")
	private boolean isFocusable(MCTabOrderBeans compo, boolean tab) {
		return ((Component) compo).isVisible() && compo.isTabOrderEnabled()
				&& compo.isFocusableByKeybord() && (!tab || checkTab((Component) compo));
	}

	/**
	 * <p>
	 * タブの選択状態をチェックします。
	 * compo が配置されているパネルが前面に表示されている
	 * （タブが選択されている）場合は true を返します。
	 * </p>
	 * <p>
	 * compo がタブペインに配置されていない場合は true を返します。
	 * </p>
	 * 
	 * @author    shimao
	 * @since     7.0.2.3
	 * @param compo GUI 部品
	 * @return compo が配置されているパネルが前面に表示されていない（タブが選択されていない）場合は false
	 */
	private boolean checkTab(Component compo) {
		while (compo != null) {
			Component p = compo.getParent();
			if (p instanceof MCTabbedPane) {
				MCTabbedPane tp = (MCTabbedPane) p;
				if (tp.getSelectedComponent() != compo) {
					return false;
				}
			}
			compo = p;
		}
		return true;
	}

	@Override
	public Component getComponentBefore(Container aContainer, Component aComponent) {
		return _policy.getComponentBefore(aContainer, aComponent);
	}

	@Override
	public Component getDefaultComponent(Container aContainer) {
		return _policy.getDefaultComponent(aContainer);
	}

	@Override
	public Component getFirstComponent(Container aContainer) {
		return _policy.getFirstComponent(aContainer);
	}

	@Override
	public Component getLastComponent(Container aContainer) {
		return _policy.getLastComponent(aContainer);
	}

}
