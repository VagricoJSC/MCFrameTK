package mcframe.clientFSBA.FSBAP0670;

import mcframe.commonCore.container.MCList;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.notice.MCMessage;
import mcframe.commonCore.notice.MCMessageList;
import mcframe.commonFX.constant.FXC_RESOURCE_SETTING_UNIT;

import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil_FW.*;
import static mcframe.commonFS.notice.FS_Msg.*;

import mcframe.clientCore.beans.MCMessageBox;
import mcframe.clientCore.beans.MCMode;
import mcframe.clientCore.beans.MCRootPanel;
import mcframe.clientCore.event.MCEventInfo;
import mcframe.clientFSBA.FSBAP0030.ListDtlR;
import mcframe.clientFSBA.FSBAP0310.FSBAP_SrchCnd;
import mcframe.clientFXBA.FXBAP0010.IfSrchCndBase;

@SuppressWarnings("serial")
public class FSBAP0310_Sub extends FSBAP_SrchCnd {

	protected boolean isSaveMode = false;

	protected String saveNM = "default";

	@Override
	public void setStatus(String status) {
		super.setStatus(status);
		// infoのtypeが違うDISABLEになるため戻す。
		if (EDIT.equals(status)) {
			setEDITStatus();
		}
	}

	// 初期行選択
	@Override
	protected void setInitInfoData(ListDtlR data) {
		super.setInitInfoData(data);
		if (saveNM != null) {
			if (isSaveMode == true) {
				// set_flgをすべてチェックする。
				setValueEx(columnInfoDtl_set_flg, true);
			}
		}
		if (isSaveMode == true) {
			doUpdAction();
		}
	}

	/**
	 * 親画面を設定します。
	 */
	public void setTargetPanel(MCRootPanel p) {
		_target_panel = (IfSrchCndBase) p;
	}

	/**
	 * 登録ボタンの処理を実行します。
	 */
	@Override
	protected void doUpdAction() {
		if (isSaveMode == false) {
			if (!execUpdComfirm() || !checkForUpd()) {
				return;
			}
		}

		beforeUpd();
		doUpd();

		// 親画面を書き換え
		if (mainPanelForBarcode != null) {
			String n = getListHdrR().setting_info_nm();
			if (n == null) {
				n = "";
			}
			mainPanelForBarcode.setSearchNM(this,n);
		}

		afterUpd();

		// 閉じるときの変更の警告を出さないようにする。
		getInfoDtlL().clear();
		getListDtlL().clear();

		// バーコード画面対応
		if (mainPanelForBarcode == null) {
			showUpdEndMsg();
		}

		// 登録後に閉じる。
		requestCloseWindow();
	}

	protected void mcInit() {
		super.mcInit();
		// 全invisibleで画面上から消す。
		// 自動レイアウト機能で表示されない。

		String [] modeList = {INIT,EDIT,DISABLE};
		for(String m : modeList) {
			Setting_setting_PPanel.Setting_setting_unit_USER.putMode(this,m, MCMode.INVISIBLE);
			Setting_setting_PPanel.Setting_setting_unit_EXT.putMode(this,m, MCMode.INVISIBLE);
			Setting_setting_PPanel.Setting_setting_unit_SYS.putMode(this,m, MCMode.INVISIBLE);

			ListDtlBtn_apply.putMode(this,m, MCMode.INVISIBLE);
			ListDtlBtn_apply_close.putMode(this,m, MCMode.INVISIBLE);
			ListHdr_init_flg.putMode(this,m, MCMode.INVISIBLE);

			InfoBtn_srch_flg.putMode(this,m, MCMode.INVISIBLE);
			InfoBtn_clear_flg.putMode(this,m, MCMode.INVISIBLE);

			ListBtn_upd_apply.putMode(this,m, MCMode.INVISIBLE);
		}

		Setting_setting_PPanel.Setting_setting_unit_Group.setValue("SYS");
	}

	protected String setting_unit() {
		return "BARCODE";
	}

	@Override
	public void doListHdr_setting_info_nm_LC(MCEventInfo info) {
		ListDtlR s = ListDtlTable.getSelectedMCRow();
		if (s != null) {
			setValueEx(columnListDtl_setting_info_nm,
					s.getGUIIndex(), getListHdrR().setting_info_nm());

			if (isNull(s.setting_unit_type())) {
				// BARCODE以外不可
				s.setting_unit_type(setting_unit());
				FXC_RESOURCE_SETTING_UNIT.putNameNE(s,
						ListDtlR.$setting_unit_type,
						ListDtlR.$setting_unit_type_nm);
			}
		}

	}

	/**
	 * 登録処理の実行確認メッセージを表示します。<p>
	 * 登録処理を続行する場合は true を返します。
	 *
	 * @return 登録処理を中断する場合は false
	 */
	@Override
	protected boolean execUpdComfirm() {
		// BARCODE以外不可
		return confirm(FSBAC0063,
				FXC_RESOURCE_SETTING_UNIT.get(setting_unit()).name(),
				getListHdrR().setting_info_nm())
				== MCMessageBox.YES_OPTION;
	}

	/**
	 * 登録処理の実行可否を判断します。<p>
	 * 登録処理を続行する場合は true を返します。
	 *
	 * @return 登録処理を中断する場合は false
	 */
	protected boolean checkForUpd() {
		// 空行のステータスをクリアする
		clearEmptyRowStatus(getListDtlL());

		// 設定情報の必須項目をチェックする
		MCMessageList l = checkReq(getListHdrR());

		// 設定情報の必須項目が入力されていない場合
		if (l.size() > 0) {
			message(l);
			return false;
		}

		// 有効な設定情報
		MCList<ListDtlR> el = exceptEmpty(getListDtlL());
//
//		el = el.subList(ListDtlR.$setting_unit_type, getSettingR().setting_unit());
//
//		// 有効な設定情報が存在しない場合
//		if (el.size() == 0) {
//			dialog(FSBAC0061);
//			return false;
//		}

		// 初期ＦＬＧが複数行に設定されている場合
		if (el.subList(ListDtlR.$init_flg, true).size() > 1) {
			dialog(FSBAC0060);
			return false;
		}

		// 設定情報名をチェックする
		MCList<ListDtlR> sl = el.subList(
				ListDtlR.$setting_info_nm, getListHdrR().setting_info_nm());
		sl.remove(ListDtlTable.getSelectedMCRow());

		// 設定情報名が重複している場合
		if (sl.size() > 0) {
			MCMessage m = new MCMessage(
					FSBAC0062,
					FXC_RESOURCE_SETTING_UNIT.get(getSettingR().setting_unit()).name(),
					getListHdrR().setting_info_nm());
			m.setCauseRow(getListHdrR(), ListDtlR.$setting_info_nm);
			dialog(m);
			return false;
		}

		return true;
	}
}
