package mcframe.clientFSBA.FSBAP0670;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"InfoDtl"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class InfoDtlR_FW_A extends MCConstRow {

	/**
	 *  紐付ＮＯ.<p>
	 *
	 */
	public static final String $pno = "pno";
	/**
	 *  テーブルＩＤ.<p>
	 *
	 */
	public static final String $table_id = "table_id";
	/**
	 *  カラム順・サイズ変更ＩＤ.<p>
	 *
	 */
	public static final String $init_list_settings_id = "init_list_settings_id";
	/**
	 *  カラム順・サイズ変更名.<p>
	 *
	 */
	public static final String $init_list_settings_nm = "init_list_settings_nm";


	public static final MCMeta pno_META = createCommonMeta($pno, mcframe.commonCore.meta.M_META.ROW_ID);
	public static final MCMeta table_id_META = createStringMeta($table_id);
	public static final MCMeta init_list_settings_id_META = createStringMeta($init_list_settings_id);
	public static final MCMeta init_list_settings_nm_META = createStringMeta($init_list_settings_nm);

	protected static final ConstMetaList<InfoDtlR> constMetas = new ConstMetaList<InfoDtlR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			pno_META,
			table_id_META,
			init_list_settings_id_META,
			init_list_settings_nm_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected InfoDtlR_FW_A(ConstMetaList<? extends InfoDtlR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public InfoDtlR clone() {
		return (InfoDtlR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public InfoDtlR createInstance() {
		return (InfoDtlR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public InfoDtlR getValues(String... names) {
		return (InfoDtlR) super.getValues(names);
	}



	/**
	 *  紐付ＮＯ.<p>
	 *
	 */
	public MCNumber pno() {
		return getConstNumber(offset + 0, $pno);
	}

	/**
	 *  紐付ＮＯ.<p>
	 *
	 */
	public void pno(MCNumber value) {
		setConstNumber(offset + 0, $pno, value);
	}

	/**
	 *  紐付ＮＯ.<p>
	 *
	 */
	public void pno(int value) {
		setConstNumber(offset + 0, $pno, value);
	}

	/**
	 *  紐付ＮＯ.<p>
	 *
	 */
	public void pno(long value) {
		setConstNumber(offset + 0, $pno, value);
	}

	/**
	 *  紐付ＮＯ.<p>
	 *
	 */
	public void pno(float value) {
		setConstNumber(offset + 0, $pno, value);
	}

	/**
	 *  紐付ＮＯ.<p>
	 *
	 */
	public void pno(double value) {
		setConstNumber(offset + 0, $pno, value);
	}


	/**
	 *  テーブルＩＤ.<p>
	 *
	 */
	public String table_id() {
		return getConstString(offset + 1, $table_id);
	}

	/**
	 *  テーブルＩＤ.<p>
	 *
	 */
	public void table_id(String value) {
		setConstString(offset + 1, $table_id, value);
	}


	/**
	 *  カラム順・サイズ変更ＩＤ.<p>
	 *
	 */
	public String init_list_settings_id() {
		return getConstString(offset + 2, $init_list_settings_id);
	}

	/**
	 *  カラム順・サイズ変更ＩＤ.<p>
	 *
	 */
	public void init_list_settings_id(String value) {
		setConstString(offset + 2, $init_list_settings_id, value);
	}


	/**
	 *  カラム順・サイズ変更名.<p>
	 *
	 */
	public String init_list_settings_nm() {
		return getConstString(offset + 3, $init_list_settings_nm);
	}

	/**
	 *  カラム順・サイズ変更名.<p>
	 *
	 */
	public void init_list_settings_nm(String value) {
		setConstString(offset + 3, $init_list_settings_nm, value);
	}


	public String getString(String name) {
		if ($table_id.equalsIgnoreCase(name)) {
			return table_id();
		}
		if ($init_list_settings_id.equalsIgnoreCase(name)) {
			return init_list_settings_id();
		}
		if ($init_list_settings_nm.equalsIgnoreCase(name)) {
			return init_list_settings_nm();
		}
		return super.getString(name);
	}
	public MCNumber getNumber(String name) {
		if ($pno.equalsIgnoreCase(name)) {
			return pno();
		}
		return super.getNumber(name);
	}

	public String getStringNE(String name) {
		if ($table_id.equalsIgnoreCase(name)) {
			return table_id();
		}
		if ($init_list_settings_id.equalsIgnoreCase(name)) {
			return init_list_settings_id();
		}
		if ($init_list_settings_nm.equalsIgnoreCase(name)) {
			return init_list_settings_nm();
		}
		return super.getStringNE(name);
	}
	public MCNumber getNumberNE(String name) {
		if ($pno.equalsIgnoreCase(name)) {
			return pno();
		}
		return super.getNumberNE(name);
	}

	public void setString(String name, String value) {
		if ($table_id.equalsIgnoreCase(name)) {
			table_id(value);
			return;
		}
		if ($init_list_settings_id.equalsIgnoreCase(name)) {
			init_list_settings_id(value);
			return;
		}
		if ($init_list_settings_nm.equalsIgnoreCase(name)) {
			init_list_settings_nm(value);
			return;
		}
		super.setString(name, value);
	}
	public void setNumber(String name, MCNumber value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, int value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, long value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, float value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, double value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumber(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($table_id.equalsIgnoreCase(name)) {
			table_id(value);
			return;
		}
		if ($init_list_settings_id.equalsIgnoreCase(name)) {
			init_list_settings_id(value);
			return;
		}
		if ($init_list_settings_nm.equalsIgnoreCase(name)) {
			init_list_settings_nm(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setNumberNE(String name, MCNumber value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, int value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, long value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, float value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, double value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumberNE(name, value);
	}



}

