package mcframe.clientFSBA.FSBAP0670;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;


import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START

import static mcframe.clientCore.resource.MCConst.createKey;

import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Arrays;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Map;

import javax.swing.JComponent;
import javax.swing.SwingUtilities;

import mcframe.clientCore.beans.barcode.MCBarcodeDelegate;
import mcframe.clientCore.beans.popup.MCPopupBeans;
import mcframe.clientCore.beans.resource.MCColumnWidthData;
import mcframe.clientCore.beans.resource.MCColumnWidthInfo;
import mcframe.clientCore.resource.MCConst;
import mcframe.clientCore.resource.ctrl.MCGeneralPersonalizeResource;
import mcframe.commonCore.resource.ctrl.MCResourceLayerType;
import mcframe.commonCore.sys.MCFactory;
import mcframe.clientFSBA.FSBAP0650.InfoR;
import mcframe.clientFSBA.FSBAP0650.InfoTabOrderR;
import mcframe.clientFSBA.FSBAP0040.FSBAP0040;
import mcframe.clientFSBA.FSBAP0130.FSBAP0130;
import mcframe.clientFSBA.FSBAP0650.FSBAP0650;
import mcframe.clientFSBA.FSBAP0650.FSBAP0650_FW;
import mcframe.clientFSBA.FSBAP0660.FSBAP0660;
import mcframe.clientFSBA.FSBAP0660.FSBAP0660_FW;
import mcframe.clientFSBA.FSBAP0790.FSBAP0790;
import mcframe.clientFSBA.FSBAP0790.FSBAP0790_FW;
import mcframe.clientFSBA.FSBAP0800.FSBAP0800;
import mcframe.clientFSBA.FSBAP0800.FSBAP0800_FW;
import mcframe.clientFSBE.FSBEP0320.FSBEP0320_FW;
import mcframe.clientFSBE.FSBEP0330.MCBarcodeUtil;
import mcframe.clientFSBE.FSBEP0330.MCPersonalizeLocation2;
import mcframe.clientFSUC.FSUCP0000.FSUCP_PopupConfig;
import mcframe.clientFXBA.FXBAP0010.FXBAP_PanelBase;
import mcframe.clientFXBA.FXBAP0010.IfSrchCndBase;
import mcframe.clientFXBA.FXBAP0080.FXBAP_CellConfig;
import mcframe.clientFXUC.FXUCP0070.SrchCndInfo;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP0670"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP0670_FW extends FSBAP0670_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	protected MCRootPanel targetRootPanel;

	// 紐付ＮＯのカウンタ
	protected int pno_cntr = 0;

	// 紐付ＮＯとテーブルデータのマップ
	protected Map<MCNumber, MCList<InfoDtlR>> infoDtlMap = new HashMap<>();

	protected MCList<ListDtlR> reloadDtlList;

	protected MCPersonalizeLocation2 personalizeLocation = null;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0670_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP0670_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * Panel[ListBtn]のボタン[open_FSBAP0310]の押下時の処理
	 */
	@Override
	public void doListBtn_open_FSBAP0310(MCEventInfo info) {
		ListDtlR data = ListDtlTable.getSelectedMCRow();
		if (data == null) {
			dialog(FXBAP0035);
			return;
		}

		MCRootPanel bp = targetRootPanel;
		Class<? extends MCRootPanel> c = FSBAP0310_Sub.class;
		FSBAP0310_Sub p = (FSBAP0310_Sub) bp.createPanel(c, MCRootPanel.MODELESS);
		p.setTargetPanel(targetRootPanel);
		p.setMainPanelForBarcode(this);
		p.saveNM = data.init_settings_nm();
		showChildPanel(p, MCRootPanel.SINGLE);
	}

	/**
	 * Panel[ListBtn]のボタン[rdel]の押下時の処理
	 */
	@Override
	public void doListBtn_rdel(MCEventInfo info) {
		deleteRow(ListDtlTable);
	}

	/**
	 * Panel[Reflesh]のボタン[reload]の押下時の処理
	 */
	@Override
	public void doReflesh_reload(MCEventInfo info) {
		// 登録データが変更されている場合はクリア確認メッセージを表示する
		if (isChanged(ListDtlTable) || isChanged(InfoDtlTable)) {
			if (!confirmRegDataClear()) {
				return;
			}
		}

		reloadData();
	}

	protected void reloadData() {
		String moduleID = targetRootPanel.getModuleID();
		String screenID = targetRootPanel.getScreenID();

		reloadDtlList = getBarcodeList(moduleID, screenID);
		setListDtlL(reloadDtlList);

		ListDtlTable.fillSpace();
		setPno();

		infoDtlMap = getTableMap(moduleID, screenID);

		if (!getListDtlL().isEmpty()) {
			ListDtlTable.selectLeftmostColumn(0);
		}

		ListDtlTable.adjustWidth();
	}

	/**
	 * Panel[ListBtn]のボタン[radd]の押下時の処理
	 */
	@Override
	public void doListBtn_radd(MCEventInfo info) {
		insertRow(ListDtlTable);
	}

	/**
	 * Panel[ListBtn]のボタン[upd]の押下時の処理
	 */
	@Override
	public void doListBtn_upd(MCEventInfo info) {
		if (targetRootPanel == null) {
			// 単体で動作させても何も起きないようにする。
			return;
		}

		// 登録確認メッセージ
		if (confirm(msgUpdateConfirm()) != MCMessageBox.YES_OPTION) {
			return;
		}

		// 変更された行を登録する
		// 空行は除外する
		MCList<ListDtlR> data1 = exceptEmpty(getListDtlL());
		MCList<ListDtlR> changed1 = data1.statusChangedList();

		if (changed1.isEmpty()) {
			dialog(msgNoDataChange());
			return;
		}

		changed1.forEach(o -> {
			switch (o.getStatus()) {
			case CREATE:
			case MODIFY:
				if (o.barcode_id() == null || o.barcode_id().length() == 0) {
					// 自動発番
					o.barcode_id(createBarcodeID(targetRootPanel.getModuleID(), targetRootPanel.getScreenID()));
				}
				break;
			default:
				break;
			}
		});

		// 必須入力チェック
		// バーコード名の一意性チェック
		MCMessageList l = checkReq(ListDtlTable, changed1);
		checkDuplicate(l, data1, ListDtlTable, ListDtlR.$barcode_nm);
		if (!l.isEmpty()) {
			message(l);
			return;
		}

		for (ListDtlR o : changed1) {
			String barcodeID = o.barcode_id();
			if (barcodeID != null && barcodeID.length() > 0) {
				switch (o.getStatus()) {
				case CREATE:
				case MODIFY:
					// 新規・更新
					setPersonalize(o);
					break;
				case DELETE:
					// 削除
					delPersonalize(o);
					break;
				default:
					break;
				}
			}
		}

		// リソースを保存する
		MCConst.saveResource();

		// 再検索
		reloadData();

		// 登録完了メッセージ
		dialog(FXBAP0021);
	}

	/**
	 * Panel[ListBtn]のボタン[open_FSBAP0650]の押下時の処理
	 */
	@Override
	public void doListBtn_open_FSBAP0650(MCEventInfo info) {
		ListDtlR data = ListDtlTable.getSelectedMCRow();
		if (data == null) {
			dialog(FXBAP0035);
			return;
		}

		MCRootPanel bp = targetRootPanel;
		FSBAP0650 p = (FSBAP0650) bp.createPanel("FS", "FSBAP0650", MCRootPanel.MODELESS);
		// p.mainPanelForBarcode = this;
		// p.targetRootPanel = targetRootPanel;
		// p.targetFocusID = data.init_focus_id();
		p.setMainPanelForBarcode((FSBAP0670)this);
		p.setTargetRootPanel(targetRootPanel);
		p.setTargetFocusID(data.init_focus_id());

		showChildPanel(p, MCRootPanel.SINGLE);
	}

	/**
	 * Panel[ListBtn]のボタン[open_FSBEP0320]の押下時の処理
	 */
	@Override
	public void doListBtn_open_FSBEP0320(MCEventInfo info) {
		ListDtlR data = ListDtlTable.getSelectedMCRow();
		if (data == null) {
			dialog(FXBAP0035);
			return;
		}

		MCRootPanel bp = targetRootPanel;
		Class<? extends MCRootPanel> c = FSBEP0320_Sub.class;
		FSBEP0320_Sub p = (FSBEP0320_Sub) bp.createPanel(c, MCRootPanel.MODELESS);
		p.setMainPanelForBarcode(this);
		p.setTargetRootPanel(targetRootPanel);
		p.setTargetLocationNM(data.init_screen_settings_nm());
		showChildPanel(p, MCRootPanel.SINGLE);
	}

	/**
	 * Panel[InfoBtn]のボタン[open_FSBAP0660]の押下時の処理
	 */
	@Override
	public void doInfoBtn_open_FSBAP0660(MCEventInfo info) {
		List<MCTable<?>> tables = getTargetTables(targetRootPanel);
		if (tables.size() == 0) {
			return;
		}

		InfoDtlR r = InfoDtlTable.getSelectedMCRow();
		if (r == null) {
			dialog(FXBAP0035);
			return;
		}

		for (MCTable<?> table : getTargetTables(targetRootPanel)) {
			if (table.getName().equals(r.table_id())) {

				MCRootPanel bp = targetRootPanel;

				if (table instanceof MCLayoutTable) {
					FSBAP0800 p = (FSBAP0800) bp.createPanel("FS", "FSBAP0800", MCRootPanel.MODELESS);
					p.setMainPanelForBarcode(this);
					p.setTargetSettingsNM(r.init_list_settings_nm());
					p.setTargetInfoDtlIndex(r.getGUIIndex());
					p.setTargetTable(table);
					showChildPanel(p, MCRootPanel.SINGLE);
					break;

				} else if (table instanceof MCTable2) {
					FSBAP0660 p = (FSBAP0660) bp.createPanel("FS", "FSBAP0660", MCRootPanel.MODELESS);
					p.setMainPanelForBarcode(this);
					p.setTargetSettingsNM(r.init_list_settings_nm());
					p.setTargetInfoDtlIndex(r.getGUIIndex());
					p.setTargetTable(table);
					showChildPanel(p, MCRootPanel.SINGLE);
					break;

				} else if (table instanceof MCTable) {
					FSBAP0790 p = (FSBAP0790) bp.createPanel("FS", "FSBAP0790", MCRootPanel.MODELESS);
					p.setMainPanelForBarcode(this);
					p.setTargetSettingsNM(r.init_list_settings_nm());
					p.setTargetInfoDtlIndex(r.getGUIIndex());
					p.setTargetTable(table);
					showChildPanel(p, MCRootPanel.SINGLE);
					break;
				}
			}
		}
	}

	@Override
	protected void valueInit() {
		super.valueInit();

		addDoBehind(Reflesh_reload);
	}

	protected MCResourceLayerType getResourceLayerType() {
		// バーコードはシステム共通のみ
		return MCResourceLayerType.BARCODE;
	}

	/** panelの全MCTableを取り出す。
	 *
	 * @param panel MCRootPanel
	 * @return List<MCTable<?>>
	 */
	protected List<MCTable<?>> getTargetTables(MCRootPanel panel) {
		List<MCTable<?>> result = new ArrayList<>();
		for (Component c : MCBeansUtil.getAllComponents(MCTable.class, panel)) {
			if (c instanceof MCFixedColumnTable == false) {
				result.add((MCTable<?>) c);
			}
		}
		return result;
	}

	/**
	 *  バーコードパーソナライズルートキー
	 */
	protected String createBarcodeResourceKey(String moduleID, String screenID) {
		return createKey("_0_SCR_", moduleID, screenID, "barcode", "system_barcode", "list");
	}

	/**
	 *  バーコードパーソナライズルートキー
	 */
	protected String createFocusResourceKey(String moduleID, String screenID) {
		return createKey("_0_SCR_", moduleID, screenID, "barcode", "barcode_focus", "list");
	}

	/**
	 *  バーコードパーソナライズリソース
	 */
	protected MCGeneralPersonalizeResource getResource() {
		return MCConst.app;
	}

	/**
	 *  パーソナライズ一覧を検索
	 *
	 */
	public MCList<ListDtlR> getBarcodeList(String aModuleID, String aScreenID) {
		MCList<ListDtlR> list = createListDtlL();

		String listKey = createBarcodeResourceKey(aModuleID, aScreenID);
		String[] baseKeys = findPattern(listKey, "*");
		for (String key1 : baseKeys) {
			ListDtlR r = list.createRow();

			r.pno(++pno_cntr);
			r.barcode_id(getString(key1, "barcodeID"));
			r.barcode_nm(getString(key1, "barcodeNM"));
			r.init_settings_id(getString(key1, "initSettingsID"));
			r.init_settings_nm(getInitSettingsNm(r.init_settings_id()));
			r.init_focus_id(getString(key1, "initFocusID"));
			r.init_focus_nm(getInitFocusNm(r.init_focus_id()));
			r.init_screen_settings_id(getString(key1, "initScreenSettingsID"));
			r.init_screen_settings_nm(getInitScreenSettingsNm(r.init_screen_settings_id()));
			String b = getString(key1, "useDialogMonitor");
			if (b != null) {
				r.use_dialog_monitor_flg(b.equals("1"));
			}
			String b2 = getString(key1, "useClearScreen");
			if (b2 != null) {
				r.use_clear_screen_flg(b2.equals("1"));
			}

			list.add(r);
		}

		// ソート
		Collections.sort(list, new ListDtlRComparator());

		return list;
	}

	protected class ListDtlRComparator implements Comparator<ListDtlR> {
		public int compare(ListDtlR a, ListDtlR b) {

			String a_id = a.barcode_id();
			if (a_id == null) {
				a_id = "";
			}
			String b_id = b.barcode_id();
			if (b_id == null) {
				b_id = "";
			}

			return (a_id.compareTo(b_id));
		}
	}

	/**
	 *  パーソナライズテーブル一覧を検索
	 *
	 */
	protected MCList<InfoDtlR> getTableList(MCRootPanel p, String aBarcodeID) {
		MCList<InfoDtlR> list = createInfoDtlL();

		List<MCTable<?>> tables = getTargetTables(p);

		for (MCTable<?> table : tables) {
			InfoDtlR r = list.createRow();

			r.table_id(table.getName());

			list.add(r);
		}

		// パーソナライズとパネルを合成する。
		String listKey = createKey(createBarcodeResourceKey(p.getModuleID(), p.getScreenID()), aBarcodeID,
				"initListSettingsID");
		String[] baseKeys = findPattern(listKey, "*");

		for (String key1 : baseKeys) {
			String tableID = getString(key1, "tableID");
			for (InfoDtlR r : list) {
				if (isSame(tableID, r.table_id())) {
					String initListSettingsID = getString(key1, "initListSettingsID");
					r.init_list_settings_id(initListSettingsID);
					r.init_list_settings_nm(getInitListSettingsNm(tableID, r.init_list_settings_id()));
					break;
				}
			}
		}

		return list;
	}

	/**
	 *  パーソナライズテーブル一覧を検索
	 *
	 */
	protected Map<MCNumber, MCList<InfoDtlR>> getTableMap(String aModuleID, String aScreenID) {

		Map<MCNumber, MCList<InfoDtlR>> map = new HashMap<>();

		String prefix = createBarcodeResourceKey(aModuleID, aScreenID);
		reloadDtlList.forEach(r -> {
			String listKey = createKey(prefix, r.barcode_id(), "initListSettingsID");

			MCList<InfoDtlR> list = createInfoDtlL();

			String[] baseKeys = findPattern(listKey, "*");
			for (String key1 : baseKeys) {
				InfoDtlR o = list.createRow();
				o.pno(r.pno());
				o.table_id(getString(key1, "tableID"));
				o.init_list_settings_id(getString(key1, "initListSettingsID"));
				o.init_list_settings_nm(getInitListSettingsNm(o.table_id(), o.init_list_settings_id()));
				list.add(o);
			}

			map.put(r.pno(), list);
		});

		return map;
	}

	// パーソナライズに書き込む。
	protected void setPersonalize(ListDtlR data) {
		String moduleID = targetRootPanel.getModuleID();
		String screenID = targetRootPanel.getScreenID();

		String barcodeID = prohibitionString(data.barcode_id());
		String listKey = createKey(createBarcodeResourceKey(moduleID, screenID), barcodeID);

		MCResourceLayerType type = getResourceLayerType();
		String[] ka = findPattern(listKey, "*");

		getResource().remove(type, ka);

		setString(barcodeID, listKey, "barcodeID");
		setString(data.barcode_nm(), listKey, "barcodeNM");
		setString(data.init_settings_id(), listKey, "initSettingsID");
		setString(data.init_focus_id(), listKey, "initFocusID");
		setString(data.init_screen_settings_id(), listKey, "initScreenSettingsID");
		setString(data.use_dialog_monitor_flg() ? "1" : "0", listKey, "useDialogMonitor");
		setString(data.use_clear_screen_flg() ? "1" : "0", listKey, "useClearScreen");

		MCList<InfoDtlR> list = infoDtlMap.get(data.pno());

		String listKey2 = createKey(createBarcodeResourceKey(moduleID, screenID), barcodeID, "initListSettingsID");

		MCResourceLayerType type2 = getResourceLayerType();
		String[] ka2 = findPattern(listKey2, "*");

		getResource().remove(type2, ka2);

		int idx = 0;
		for (InfoDtlR r : list) {
			String key = createKey(listKey2, "item" + idx);
			setString(r.table_id(), key, "tableID");
			setString(r.init_list_settings_id(), key, "initListSettingsID");
			idx++;
		}
	}

	protected void delPersonalize(ListDtlR data) {
		String screenID = targetRootPanel.getScreenID();
		String moduleID = targetRootPanel.getModuleID();

		String barcodeID = prohibitionString(data.barcode_id());
		String listKey = createKey(createBarcodeResourceKey(moduleID, screenID), barcodeID);

		MCResourceLayerType type = getResourceLayerType();
		String[] ka = findPattern(listKey, "**");

		getResource().remove(type, ka);
	}

	public static void doBarcodeSettings(MCRootPanel panel) {
		final String sid = "FSBAP0670";
		final String mid = "FS";

		MCRootPanel p = MCBeansUtil.createPanel(panel.getRootPanel(), mid, sid, MCFrameType.MODELESS);
		FSBAP0670 p1 = (FSBAP0670) p;
		p1.targetRootPanel = panel;
		panel.showChildPanel(p, MCRootPanel.SINGLE, new Object[0]);
	}

	/**
	 *  指定されたバーコード画面に切り替える。
	 *  ツールバーから呼ばれる。
	 * @param panel パネル
	 * @param aBarCode バーコードID
	 * @param createPanel createPanelを実行するかどうか
	 */
	public static void doBarcode(MCRootPanel panel, String aBarCode, boolean createPanel) {
		FSBAP0670 p = new FSBAP0670();
		p.showBarcode(panel, aBarCode, createPanel);
	}

	// バーコード画面に切り替える。
	protected void showBarcode(MCRootPanel panel, String aBarcodeID, boolean createPanel) {

		MCRootPanel p;

		if (createPanel == true) {
			String moduleID = panel.getModuleID();
			String screenID = panel.getScreenID();
			p = MCBeansUtil.createPanel(panel.getRootPanel(), moduleID, screenID, MCFrameType.MODELESS,
					"barcode_id=" + aBarcodeID);
		} else {
			p = panel;
		}

		// setBarcodeModeが実装されている場合は呼び出す。
		Class<?>[] argsCls = { Boolean.class };
		Object[] args = { true };
		invokeMethod(p, "setBarcodeMode", argsCls, args);

		if (createPanel == true) {
			// 画面を開く。
			MCBeansUtil.showPanel(p, MCPanelType.MULTI);
		} else {
			// バーコード対応の初期画面を構築
			setupBarcodeScreen(p, aBarcodeID);
		}

	}
	
	// リフレクションでsetBarcodeModeを呼び出す。
	private static Object invokeMethod(Object methodObject, String methodName, Class<?> argClass[], Object args[]) {
		try {
			return MCFactory.invoke(methodObject, methodName, argClass, args);
		} catch (MCException ex) {
			debugLog(ex);
		}
		return null;
	}

	// パーソナライズ
	protected String createListResourceKey(String moduleID, String screenID) {
		return createKey("barcode_focus", moduleID, screenID, "list");
	}

	// エラーフォーカス
	protected String loadPersonalizeErrorFocus(String panelModuleID, String panelScreenID, String aFocusNM) {

		String listKey1 = createListResourceKey(panelModuleID, panelScreenID);
		String[] baseKeys1 = findPattern(listKey1, "*");
		for (String key1 : baseKeys1) {
			String nm = getString(key1, "focusNM");
			if (nm != null && nm.equals(aFocusNM)) {
				String id = getString(key1, "focusID");
				String listKey = createKey(createFocusResourceKey(panelModuleID, panelScreenID), id);
				String errorFocus = getString(listKey, "initFocus");
				return errorFocus;

			}
		}
		return null;
	}

	// invokeの内からMCRootPanelアクセスするための変数
	private MCRootPanel barcodeRootPanel;

	protected void setupBarcodeScreen(MCRootPanel p, String aBarCodeID) {
		barcodeRootPanel = p;

		String moduleID = p.getModuleID();
		String screenID = p.getScreenID();

		String listKey = createBarcodeResourceKey(moduleID, screenID);

		String[] baseKeys = findPattern(listKey, "*");

		for (String key1 : baseKeys) {
			String barcodeID = getString(key1, "barcodeID");
			if (isSame(barcodeID, aBarCodeID)) {
				String initSettingsID = getString(key1, "initSettingsID");
				String initFocusID = getString(key1, "initFocusID");
				String initScreenSettingsID = getString(key1, "initScreenSettingsID");
				String useDialogMonitor = getString(key1, "useDialogMonitor");
				String useClearScreen = getString(key1, "useClearScreen");

				MCList<InfoDtlR> tabelSettingsList = getTableList(barcodeRootPanel, aBarCodeID);

				MCPersonalizeLocation2 personalizeLocation = new MCPersonalizeLocation2();
				personalizeLocation.setupTargetPanel(barcodeRootPanel);
				personalizeLocation.setupPanelList();

				// 初期検索
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						boolean b1 = "1".equals(useDialogMonitor);
						boolean b2 = "1".equals(useClearScreen);
						setupBarcodeScreen(p, aBarCodeID, initSettingsID, initFocusID, initScreenSettingsID,
								tabelSettingsList, b1, b2);
					}
				});
				break;
			}
		}
	}

	protected void setupBarcodeScreen(MCRootPanel p, String aBarCodeID,
			String initSettingsID, String initFocusID, String initScreenSettingsID,
			MCList<InfoDtlR> tabelSettingsList, boolean useDialogMonitor, boolean useClearScreen) {

		MCPersonalizeLocation2 personalizeLocation = new MCPersonalizeLocation2();
		personalizeLocation.setupTargetPanel(barcodeRootPanel);
		personalizeLocation.setupPanelList();

		// 初期値設定
		if (!isNull(initSettingsID)) {
			String n = initSettingsID;
			IfSrchCndBase p2 = (IfSrchCndBase) barcodeRootPanel;
			List<SrchCndInfo> l = p2.getSrchCndInfoList();
			for (SrchCndInfo i : l) {
				String k = createKey(i.getSettingInfoID());
				if (isSame(n, k)) {
					p2._applySrchCndInfo(i);
					break;
				}
			}
		}

		// 非表示テーブルカラム
		if (tabelSettingsList.size() > 0) {
			List<MCTable<?>> tables = getTargetTables(barcodeRootPanel);
			for (MCTable<?> table : tables) {
				for (MCColumnWidthInfo i : table.getBarcodeColumnWidthInfoList()) {
					for (InfoDtlR r : tabelSettingsList) {
						if (r.table_id().equals(table.getName())) {
							if (i.getSettingInfoID()
									.equals(r.init_list_settings_id())) {
								table._applyColumnWidthInfo(i);
								break;
							}
						}
					}
				}
			}
		}

		// タブ制限
		if (!isNull(initFocusID)) {

			// 手動の場合はタブ順を壊さない。
//			updateTabOrder(barcodeRootPanel);

			setupFocus(barcodeRootPanel, personalizeLocation, initFocusID);

			if (useDialogMonitor) {
				// エラー発生時のフォーカス当て。

				HashMap<String, String> map = MCBarcodeUtil.getDialogButtonMap();

				FSBAP0650 app = new FSBAP0650();
				boolean _useManualMode = app.loadPersonalizeManualMode(barcodeRootPanel.getModuleID(),
						barcodeRootPanel.getScreenID(), initFocusID);
				BarcodeDialogMonitor mon = new BarcodeDialogMonitor(barcodeRootPanel, map, initFocusID, _useManualMode);
				String errorFocus = MCStringUtil.nullToBlank(loadPersonalizeErrorFocus(
						barcodeRootPanel.getModuleID(), barcodeRootPanel.getScreenID(), initFocusID));
				mon.tabComponentID = errorFocus;
				mon.startTimer();
			}
		}

		// ボタンを押したあとにもとの位置に戻るためのフォーカス位置指定
		String baseFocus = MCStringUtil.nullToBlank(
				loadPersonalizeErrorFocus(p.getModuleID(), p.getScreenID(), initFocusID));
		if (baseFocus != null && baseFocus.length() > 0) {
			List<Component> components = personalizeLocation
					.getAllComponents(barcodeRootPanel);
			Object c = findComponent(barcodeRootPanel, components, personalizeLocation,
					baseFocus);
			if(c instanceof MCTableColumn) {
				barcodeRootPanel.barcodeFocusColumn = (MCTableColumn)c;
				barcodeRootPanel.barcodeFocusComponent = null;
			} else {
				barcodeRootPanel.barcodeFocusColumn = null;
				barcodeRootPanel.barcodeFocusComponent = (Component)c;
			}
		}

		// 画面クリア設定
		barcodeRootPanel.setBarcodeClearScreen(useClearScreen);

		// 初期化完了
		MCBarcodeDelegate dg = barcodeRootPanel.getBarcodeDelegate();
		if (dg != null) {
			//初期フォーカス設定
			Object startFocus = barcodeRootPanel.getBarcodeStartFocus();
//			boolean f = false;
			if (startFocus != null) {
				if (startFocus instanceof JComponent) {
					dg.setFocus((JComponent) startFocus, false);
					dg.updateStatus(); //初期フォーカスでステータス更新
//					f = true;
				}
			}
//			if (f == true) {
//				dg.setEntryMode(false);
//			} else {
//				dg.setProcessingMode();
//			}
		}

		barcodeRootPanel = null;
	}

	// タブで勝手に移動しないように全タブ情報消去
	@SuppressWarnings("deprecation")
	protected void updateTabOrder(Container c) {
		Component[] comps = c.getComponents();
		for (Component comp : comps) {
			if (comp instanceof Container) {
				updateTabOrder((Container) comp);
			}
		}

		if (c instanceof MCPanel) {
			for (Component c1 : comps) {
				if (c1 instanceof MCTabOrderBeans) {
					((MCTabOrderBeans) c1).setNextBeans(null);
					((MCTabOrderBeans) c1).setPreviousBeans(null);
				}
			}
		}
	}

	// フォーカスを設定する。
	protected void setupFocus(MCRootPanel panel, MCPersonalizeLocation2 personalizeLocation, String focusID) {

		String moduleID = panel.getModuleID();
		String screenID = panel.getScreenID();

		FSBAP0650 app = new FSBAP0650();

		boolean _useManualMode = app.loadPersonalizeManualMode(moduleID, screenID, focusID);

		panel.setBarcodeManualFocus(_useManualMode);

		if (_useManualMode == true) {
			setupFocusForManualMode(app, panel, personalizeLocation, focusID);
			return;
		}

		// これ以下は互換対応
		updateTabOrder(panel);

		MCList<InfoR> list = app.loadPersonalizeComponent(moduleID, screenID, focusID);

		// 全部品
		List<Component> components = personalizeLocation.getAllComponents(panel);

		boolean first = true;

		for (InfoR r : list) {
			String componentID = MCStringUtil.nullToBlank(r.comp_id());
			String panelID = MCStringUtil.nullToBlank(r.panel_id());
			String rootPanelID = MCStringUtil.nullToBlank(r.root_panel_id());
			String id = rootPanelID+","+panelID+","+componentID;
			Object nextButtonFocus = null; // #7022-0113

			// フォーカスアウト後の次フォーカス
			// ボタン実行後のフォーカスに変更
			if (!isNull(r.focus_out_next_focus())) {
				Object c = findComponent(panel, components, personalizeLocation, id);
				if (c != null) {
					Object c2 = findComponent(panel, components, personalizeLocation, r.focus_out_next_focus());
					if (c2 != null) {
						if (first) {
							panel.setFirstBeans((MCTabOrderBeans) c);
							first = false;
						}
						((MCTabOrderBeans) c).setNextBeans((MCTabOrderBeans) c2);
					}
				}
			}

			if (!isNull(r.focus_out_next_focus())) {
				Object c = findComponent(panel, components, personalizeLocation, id);
				if (c != null) {
					Object c2 = findComponent(panel, components, personalizeLocation, r.focus_out_next_focus());
					if (c2 != null) {
	//					if (first) {
							nextButtonFocus = c;
	//						first = false;
//						}
					}
				}
			}

			// フォーカスインでフォーカス移動する。
			if (!isNull(r.focus_in())) {
				Object c = findComponent(panel, components, personalizeLocation, id);
				if (c != null) {
					Object c2 = findComponent(panel, components, personalizeLocation, r.focus_in());
					if (c2 != null) {
						setupListenerNE((MCNEBeans) c, (MCBeans)c2);
					}
				}
			}
			
			// フォーカスアウトで実行するボタン
			// 複数指定可能
			if (!isNull(r.focus_out())) {
				Object c = findComponent(panel, components, personalizeLocation, id);
				if (c != null) {
					List<String> focusOutList = stringToList(r.focus_out());
					List<Object> clist = new ArrayList<>();

					for (String str : focusOutList) {
						Object c2 = findComponent(panel, components, personalizeLocation, str);
						if (c2 instanceof MCButton) {
							clist.add((MCButton) c2);
						} else {
							clist.add(str);
						}
					}

					if (clist.size() > 0) {
						setupListenerNX((MCNXBeans) c, clist, nextButtonFocus);
					}
				}
			}
		}
	}

	// マニュアルモード
	protected void setupFocusForManualMode(FSBAP0650 app, MCRootPanel panel, MCPersonalizeLocation2 personalizeLocation,
			String focusID) {

		String moduleID = panel.getModuleID();
		String screenID = panel.getScreenID();
		
		// FocusTraversalPolicyをバーコード用に設定する。
		MCBarcodeFocusTraversalPolicy focusPolicy = new MCBarcodeFocusTraversalPolicy(
				panel);
		panel.setFocusTraversalPolicy(focusPolicy);

		// _0_SCR_.modId.ScreenId.barcode.barcode_focus.list.focusID の情報取得
		MCList<InfoR> list = app.loadPersonalizeComponent(moduleID, screenID, focusID);

		// タブ順を退避する。
		MCBarcodeDelegate dg = panel.getBarcodeDelegate();
		dg.setSaveTabOrderList(new ArrayList<>(panel.getTabOrderBeans(true)));

		// タブ順
		// _0_SCR_.modId.ScreenId.barcode.barcode_focus.tab_order の情報取得
		MCList<InfoTabOrderR> tabOrderList = app.loadPersonalizeTabOrder(moduleID, screenID, focusID);

		// 全部品
		List<Component> components = personalizeLocation.getAllComponents(panel);

		// フォーカス順変更
		ArrayList<MCTabOrderBeans> tlist = app.getTabOrder((FSBAP0670) this, panel, tabOrderList, components,
				personalizeLocation);
		panel.updateTabOrderBeans(tlist);

		// 開始点、ユーザ操作点、終了点を算出
		Object startFocus = null;
		ArrayList<Object> endFocus = new ArrayList<>();
		ArrayList<Object> barcodeFocus = new ArrayList<>();

		for (InfoR r : list) {
			String componentID = MCStringUtil.nullToBlank(r.comp_id());
			String panelID = MCStringUtil.nullToBlank(r.panel_id());
			String rootPanelID = MCStringUtil.nullToBlank(r.root_panel_id());
			String id = rootPanelID + "," + panelID + "," + componentID;

			Object c = findComponent(panel, components, personalizeLocation, id);
			if (c != null) {
				if (r.start_focus_flg()) {
					startFocus = c;
				}
				if (r.barcode_flg()) {
					barcodeFocus.add(c);
				}
			}
		}

		panel.setBarcodeStartFocus(startFocus);
		panel.setBarcodeFocus(barcodeFocus);

		for (InfoR r : list) {
			String componentID = MCStringUtil.nullToBlank(r.comp_id());
			String panelID = MCStringUtil.nullToBlank(r.panel_id());
			String rootPanelID = MCStringUtil.nullToBlank(r.root_panel_id());
			String id = rootPanelID + "," + panelID + "," + componentID;

			Object nextButtonFocus = null;

			if (!isNull(r.focus_out_next_focus())) {
				Object c = findComponent(panel, components, personalizeLocation, id);
				if (c != null) {
					Object c2 = findComponent(panel, components, personalizeLocation,
							r.focus_out_next_focus());
					if (c2 != null) {
						if (canFocusOutNextFocus(c, c2)) {
							focusPolicy.setFocuoutNext((Component) c, (Component) c2);
						}
					}
				}
			}
			if (!isNull(r.focus_out_next_focus())) {
				Object c = findComponent(panel, components, personalizeLocation, id);
				if (c != null) {
					Object c2 = findComponent(panel, components, personalizeLocation, r.focus_out_next_focus());
					if (c2 != null) {
	//					if (first) {
							nextButtonFocus = c;
	//						first = false;
//						}
					}
				}
			}			
			
			// 連続ボタン実行後のフォーカス
			if (!isNull(r.button_next_focus())) {
				Object c1 = findComponent(panel, components, personalizeLocation, id);
				Object c2 = findComponent(panel, components, personalizeLocation, r.button_next_focus());
				if (c1 != null && c2 != null) {
					nextButtonFocus = c2;
					//ボタン実行後の次のフォーカスを設定
					if(c1 instanceof MCButton) {
						((MCButton)c1).setNextFocusForBarcode(c2);
					}
				}
			}
			
			// フォーカスインでフォーカス移動する。
			if (!isNull(r.focus_in())) {
				Object c = findComponent(panel, components, personalizeLocation, id);
				if (c != null) {
					Object c2 = findComponent(panel, components, personalizeLocation, r.focus_in());
					if (c2 != null && c instanceof MCNEBeans && c2 instanceof MCBeans) {
						setupListenerNE((MCNEBeans) c, (MCBeans)c2);
					}
				}
			}
			

			Object c3 = findComponent(panel, components, personalizeLocation, id);
			if (c3 != null) {
				setupListenerNE2(panel, (MCNEBeans) c3);
			}

			// フォーカスアウトで実行するボタン focus_outを使用する。
			// 複数指定可能
			if (!isNull(r.focus_out())) {
				Object c = findComponent(panel, components, personalizeLocation, id);
				if (c != null) {

					List<String> focusOutList = stringToList(r.focus_out());
					List<Object> clist = new ArrayList<>();
					for (String str : focusOutList) {
						Object c2 = findComponent(panel, components, personalizeLocation,
								str);
						// 使用できるのはMCButtonとフォーカス制御コマンドのみ
						if (c2 instanceof MCButton) {
							clist.add(c2);
						}
						else if (str.equals(MCBarcodeUtil.commandUser)) {
							clist.add(str);
						}
						else if (str.equals(MCBarcodeUtil.commandAuto)) {
							clist.add(str);
						}
						else if (str.equals(MCBarcodeUtil.commandEnd)) {
							clist.add(str);
						}
					}

					if (clist.size() > 0) {
						if(c instanceof MCBeans) {
							if(panel.getBarcodeButtonActions() == null) {
								panel.setBarcodeButtonActions(new HashMap<>());
							}
							panel.getBarcodeButtonActions().put((MCBeans)c, clist);
	
							setupListenerNXForManualMode((MCNXBeans) c, clist, nextButtonFocus);
						}
					}
				}
			}
		}
	}

	/**
	 * 指定されたオブジェクトが「フォーカスアウト後の次のフォーカスの設定」が可能なコンポーネントであるかチェックする。
	 * @param org 遷移元の画面コンポーネント
	 * @param next 遷移先の画面コンポーネント
	 * @return tureなら「フォーカスアウト後の次のフォーカスの設定」が設定できる。
	 */
	private boolean canFocusOutNextFocus(Object org, Object next) {
		return (org instanceof Component) && (org instanceof MCTabOrderBeans)
				&& (next instanceof Component) && (next instanceof MCTabOrderBeans);
	}

	// /で分離する。
	protected List<String> stringToList(String str) {
		String[] ids = MCStringUtil.split("^", str);
		return Arrays.asList(ids); // 7.0.1
	}

	// コンポーネントを探し出す。
	// 戻りはComponentまたはMCColumnConfig
	public Object findComponent(MCRootPanel panel, List<Component> components,
			MCPersonalizeLocation2 personalizeLocation, String componentFullID) {
		return MCBarcodeUtil.findComponent(panel, components, personalizeLocation,
				componentFullID);
	}

	// c1のNXしたときに特定のボタンをクリックするための仕込み。
//	protected void setupListenerNX(MCNXBeans c1, List<MCButton> clist, Object nextButtonFocus) {
	protected void setupListenerNX(MCNXBeans c1, List<Object> clist, Object nextButtonFocus) {
//		MCButton b = clist.get(0);
		// ボタンメソッドのcallerを同期通信にする必要がある。
//		NXButtonListener e1 = new NXButtonListener(b);
		NXButtonListener e1 = new NXButtonListener(barcodeRootPanel, clist);
		c1.addNXListener(e1);

//		for (int i = 0; i < clist.size() - 1; i++) {
//			Object c = clist.get(i);
//			if(c instanceof MCButton) {
//				MCButton b1 =(MCButton) c;
//				b1.setClistForBarcode(clist);
//			}
//		}

		
//		for (int i = 0; i < clist.size() - 1; i++) {
//			setClistForBarcode
//			MCButton b1 = clist.get(i);
//			MCButton b2 = clist.get(i + 1);
//			// 7.0.1 セッターで対応
//			b1.setNextButtonForBarcode(b2);
//			b1.setNextFocusForBarcode(null);
//		}
//		for (int i = clist.size() - 1; i <= clist.size() - 1; i++) {
//			MCButton b3 = clist.get(i);
//			// 7.0.1 セッターで対応
//			b3.setNextFocusForBarcode(nextButtonFocus);
//		}
	}

	// c1のNEしたときにc2のボタンをクリックする。
	// c1のNEしたときにc2のにフォーカス移動する。
	protected void setupListenerNE(MCNEBeans c1, MCBeans c2) {
		if(c2 instanceof Component) {
			NEListener e2 = new NEListener(c2);
			c1.addNEListener(e2);
		} else {
			// カラムへのNEは非対応
//			System.out.println("setupListenerNE "+c1+" "+c2);
		}
	}
	
	protected void setupListenerNE2(MCRootPanel rp, MCNEBeans c1) {
		if(c1 instanceof Component) {
			NEListener2 e2 = new NEListener2(rp, c1);
			c1.addNEListener(e2);
		} else {
			// カラムへのNEは非対応
//			System.out.println("setupListenerNE2 "+c1);
		}
	}

	// 画面部品にNXListenerを付与
	protected class NXButtonListener implements MCNXListener {
		protected MCRootPanel rp = null; // 7022

		protected List<Object> clist = null; // 7022

		public NXButtonListener(MCRootPanel rp, List<Object> clist) {
			this.rp = rp;
			this.clist = clist;
		}

		@Override
		public void doNXEvent(MCNXBeans compo, MCEventInfo info) {
			if (clist == null || clist.size() == 0) {
				return;
			}

			if (rp == null) {
				// ボタンのrootPanelがない場合は何もしない。
			}
			else {
				List<MCButton> blist = new ArrayList<>();
				for (Object c : clist) {
					if (c instanceof MCButton) {
						blist.add((MCButton) c);
					}
				}

				if (rp.isBarcodeManualFocus() == false) {
					// 旧ロジック
					if (blist.size() > 0) {
						MCButton btn = blist.get(0);
						btn.action(null);
					}
				}
				else {
					MCBarcodeDelegate dg = rp.getBarcodeDelegate();
					if (dg != null) {
						String s = dg.getBarcodeStatus();
						if (MCBarcodeUtil.barcodeStatusUser.equals(s)) {
							// ユーザ操作中は何もしない。
						}
						else {
							if (dg.isInitFlag() == false && dg.isInitFlag2() == false) {
								if (dg.hasHeaderBarFocus() == false) {
									try {
										//ここでフォーカス設定のボタンを実行
										dg.setDisableNextFocus2(true);

										//フィールドcompに設定されたボタンを連続実行開始

										//継続でフォーカス抜けでボタンがおされてしまうのを防ぐ
										if (dg.getDisableNextFocus4() == false) {
											dg.doButton(compo, false);
										}

									}
									finally {
										dg.setDisableNextFocus2(false);
									}
								}
							}
							else {
								// 初期化中は何もしない。
							}
						}
					}
				}
			}
		}
	}

	// 画面部品にNEListenerを付与
	protected class NEListener implements MCNEListener {
		protected MCBeans comp = null;

		public NEListener(MCBeans aComp) {
			comp = aComp;
		}

		@Override
		public void doNEEvent(MCNEBeans compo, MCEventInfo info) {
			if (comp != null) {
				//非同期でこのイベント処理を出たあとに実行されるようにする。
				FocusActionThread at = new FocusActionThread(comp);
		        at.start();
			}
		}
	}
	
	// 画面部品にNEListenerを付与
	protected class NEListener2 implements MCNEListener {
		MCRootPanel rp = null; // 7022
		protected MCBeans comp = null;

		public NEListener2(MCRootPanel rp, MCBeans aComp) {
			this.rp = rp;
			this.comp = aComp;
		}

		@Override
		public void doNEEvent(MCNEBeans compo, MCEventInfo info) {
			if (comp != null) {
				MCBarcodeDelegate dg = rp.getBarcodeDelegate();
				if (dg != null) {
					dg.updateStatus();
				}
			}
		}
	}
	
	protected class FocusActionThread extends Thread {
		protected MCBeans comp = null;
		public FocusActionThread(MCBeans aComp) {
			super();
			comp = aComp;
		}
	    public void run() {
			SwingUtilities.invokeLater(new Runnable() {
				@Override
				public void run() {
					MCRootPanel rp = comp.getBaseRootPanel();
					MCBarcodeDelegate dg = rp.getBarcodeDelegate();
					if (dg != null) {
						dg.setFocus(comp, false);
					}
				}
			});
	    }
	}

	/**
	 * [Cnd]パネルの[barcodeID]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	@Override
	public void doListDtl_barcode_id_NC(MCEventInfo info) {
		// 禁則文字
		String val = getListDtlL().get(info.getEventIndex()).barcode_id();
		setValueEx(columnListDtl_barcode_id, info.getEventIndex(),
				prohibitionString(val));
	}

	/**
	 *  入力値設定IDを設定
	 * @param app 入力値設定画面
	 * @param id 入力値設定NM
	 */
	public void setSearchNM(FSBAP0310_Sub app, String nm) {
		ListDtlR data = ListDtlTable.getSelectedMCRow();
		if (data != null) {
			setValueEx(columnListDtl_init_settings_nm, data.getGUIIndex(), nm);
		}
	}

	/**
	 *  フォーカス設定IDを設定
	 * @param app フォーカス指定画面
	 * @param nm フォーカス設定NM
	 */
	public void setFocusID(FSBAP0650_FW app, String nm) {
		ListDtlR data = ListDtlTable.getSelectedMCRow();
		if (data != null) {
			setValueEx(columnListDtl_init_focus_nm, data.getGUIIndex(), nm);
		}
	}

	/**
	 *  非表示設定IDを設定
	 * @param app 非表示指定画面
	 * @param nm 設定NM
	 */
	public void setScreenSettingsID(FSBEP0320_FW app, String nm) {
		ListDtlR data = ListDtlTable.getSelectedMCRow();
		if (data != null) {
			setValueEx(columnListDtl_init_screen_settings_nm, data.getGUIIndex(), nm);
		}
	}

	/**
	 *  非表示一覧カラム設定IDを設定
	 * @param app 非表示一覧カラム指定画面
	 * @param table 設定対象MCTable
	 * @param nm 設定NM
	 */

	public void setListSettingsID(FSBAP0660_FW app, MCTable<?> table, String nm, int index) {
		setValueEx(columnInfoDtl_init_list_settings_nm, index, nm);
	}
	public void setListSettingsID1(FSBAP0790_FW app, MCTable<?> table, String nm, int index) {
		setValueEx(columnInfoDtl_init_list_settings_nm, index, nm);
	}
	public void setListSettingsID2(FSBAP0800_FW app, MCTable<?> table, String nm, int index) {
		setValueEx(columnInfoDtl_init_list_settings_nm, index, nm);
	}

	// 禁則文字を変換
	// 禁則でコードの整合を保証する。
	protected String prohibitionString(String content) {
		StringBuilder buffer = new StringBuilder();
		for (int i = 0; i < content.length(); i++) {
			char c = content.charAt(i);
			if (c < 0x30 || (c >= 0x3a && c <= 0x40) || (c > 0x5a && c <= 0x60)
					|| c > 0x7a) {
				buffer.append("_");
			}
			else {
				buffer.append(c);
			}
		}
		return buffer.toString();
	}

	/**
	 * [BarcodeList]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	@Override
	public void doListDtl_NC(MCEventInfo info) {
		ListDtlR data = getListDtlL().get(info.getEventIndex());

		if (!infoDtlMap.containsKey(data.pno())) {
			infoDtlMap.put(data.pno(), getTableList(targetRootPanel, data.barcode_id()));
		}

		setInfoDtlL(infoDtlMap.get(data.pno()));
		InfoDtlTable.adjustWidth();
	}

	/**
	 * [InfoDtl]パネルの[init_list_settings_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	@Override
	public void doInfoDtl_init_list_settings_nm_NC(MCEventInfo info){
		ListDtlR r = ListDtlTable.getSelectedMCRow();
		if(r != null) {
			r.setStatus(Status.MODIFY);
		}
	}

	protected boolean useFindErrorDialog = true;

	/*
	 * ダイアログ監視スレッド
	 * ダイアログが表示されたら強制終了させる。
	 * ダイアログを閉じた後ユーザ操作モードに移行
	 */
	protected class BarcodeDialogMonitor extends TimerTask {

		protected MCRootPanel targetPanel = null;
		protected String _focusID = null;
		private boolean _useManualMode = false;

		protected Timer timer = null;

		// ダイアログ閉じるタイマー
		protected long interval = 3000; // 3秒

		// ESCでフォーカスを強制移動する。
		protected String tabComponentID = null;

		private int hasErrorMode = 0;
		private Window window = null;
		private Window closeWindow = null;

		protected HashMap<String, String>buttonMap = null;


		// コンストラクタ
		protected BarcodeDialogMonitor(MCRootPanel aRootPanel, HashMap<String, String> aButtonMap, String aFocusID,
				boolean aUseManualMode) {
			targetPanel = aRootPanel;
			buttonMap = aButtonMap;
			_focusID = aFocusID;
			_useManualMode = aUseManualMode;
		}

		@Override
		public void run() {
			if (targetPanel == null || targetPanel.isShowing() == false) {
				// 画面が閉じたら止める。
				stopTimer();
				return;
			}

			if (useFindErrorDialog == true) {
				if (hasErrorMode == 0) {
					// エラーダイアログを発見する。
					System.gc();
					Window windows[] = Window.getWindows();
					for (Window w : windows) {
						if (w instanceof mcframe.clientCore.beans.MCScreenModalFrame
								|| w instanceof mcframe.clientCore.beans.MCModalFrame) {
							if (w.isShowing()) {
								Window owner = w.getOwner();
								if (targetPanel != null && owner == targetPanel.getFrame()) {
									hasErrorMode = 1;
									window = w;
								}
							}
						}
					}
				}
			}

			if (hasErrorMode == 1) {
				// ESCを押して画面を閉じる。
//				SwingUtilities.invokeLater(new Runnable() {
//					@Override
//					public void run() {
//						pressESC(window);
//					}
//				});

				hasErrorMode = 2;
			}
			else if (hasErrorMode == 2) {
				// エラーダイアログが閉じられたらフォーカスの移動を行う。
				hasErrorMode = 3;

				if (_useManualMode == false) {
					System.gc();
					Window windows[] = Window.getWindows();
					for (Window w : windows) {
 						if (w instanceof MCScreenModalFrame
								|| w instanceof MCModalFrame) {
							hasErrorMode = 2;
						}
					}
				}

				if ((tabComponentID == null || tabComponentID.length() == 0) && _useManualMode == false) {
					hasErrorMode = 0;
					window = null;
				}
				else {
					if (hasErrorMode == 3) {
						checkAndClose();
					}
				}
			}
		}

		protected void checkAndClose() {
			Component c = getComponent(targetPanel, tabComponentID);
			if (c != null) {
				boolean flag = false; // 旧処理に戻す場合はtrueにする。　
				if (_useManualMode == false && flag) {
					targetPanel.moveToFront();
					c.requestFocus();
				} else {
					if (window instanceof MCScreenModalFrame || window instanceof MCModalFrame) {
						MCRootPanel rp = ((MCFrame) window).getRootPanel();
						String mid = getMsgID(rp);
						MCMessage msg = new MCMessage(mid);
						MCMessageLevel lvl = msg.getLevel();
						if (MCMessageLevel.INFO == lvl) {
							// 閉じるだけでなにもしない。
							// ESCを押して画面を閉じる。
							closeWindow = window;
							SwingUtilities.invokeLater(new Runnable() {
								@Override
								public void run() {
									pressESC(closeWindow);
								}
							});
						} else {
							// ユーザ操作モードに切り替え。
							// 不要
//							MCBarcodeDelegate dg = targetPanel.getBarcodeDelegate();
//							if (dg != null) {
//								dg.setUserMode();
//							}
							//TODO エラーでも閉じる。
							closeWindow = window;
							SwingUtilities.invokeLater(new Runnable() {
								@Override
								public void run() {
									pressESC(closeWindow);
								}
							});

						}
					}
				}
			}
			hasErrorMode = 0;
			window = null;

		}

		protected void pressESC(Window w) {
			if(w instanceof MCScreenModalFrame || w instanceof MCModalFrame) {
				MCRootPanel rp = ((MCFrame)w).getRootPanel();
				if(rp instanceof FSBAP0040) {
					if(buttonPresss(((FSBAP0040)rp).Command_OK)) {
						return;
					}
					else if(buttonPresss(((FSBAP0040)rp).Command_Yes)) {
						return;
					}
					else if(buttonPresss(((FSBAP0040)rp).Command_No)) {
						return;
					}
					else if(buttonPresss(((FSBAP0040)rp).Command_Cancel)) {
						return;
					}
				}
				else if(rp instanceof FSBAP0130) {
					String id = getButtonID(rp);
					boolean b = false;
					if(id != null) {
						switch(id) {
						case "OK":
							b = buttonPresss(((FSBAP0130)rp).Dialog_OK);
							break;
						case "Cancel":
							b = buttonPresss(((FSBAP0130)rp).Dialog_Cancel);
							break;
						case "Yes":
							b = buttonPresss(((FSBAP0130)rp).Dialog_Yes);
							break;
						case "No":
							b = buttonPresss(((FSBAP0130)rp).Dialog_No);
							break;
						case "None":
							b = true;
							break;
						}
					}
					if(b == true) {
						return;
					}
					if(buttonPresss(((FSBAP0130)rp).Dialog_OK)) {
						return;
					}
					else if(buttonPresss(((FSBAP0130)rp).Dialog_Yes)) {
						return;
					}
					else if(buttonPresss(((FSBAP0130)rp).Dialog_No)) {
						return;
					}
					else if(buttonPresss(((FSBAP0130)rp).Dialog_Cancel)) {
						return;
					}
				}
			}
		}

		// MCRootPanelからメッセージIDを取り出す。
		protected String getButtonID(MCRootPanel rp) {
			if(rp instanceof FSBAP0130) {
				String msg_id = ((FSBAP0130)rp).getMsgID();
				if(msg_id == null) {
					return null;
				}
				if(buttonMap != null) {
					if(buttonMap.containsKey(msg_id)) {
						return buttonMap.get(msg_id);
					}
				}
				return null;
			}
			return null;
		}

		protected boolean buttonPresss(MCButton b) {
			if(b != null && b.isVisible() && b.isEnabled()) {
				boolean ret = b.doButtonAction();
				if(ret == true) {
					return true;
				}
			}
			return false;
		}

		// MCRootPanelからメッセージIDを取り出す。
		protected String getMsgID(MCRootPanel rp) {
			if (rp instanceof FSBAP0130) {
				String msg_id = ((FSBAP0130) rp).getMsgID();
				return msg_id;
			}
			return null;
		}

		// 画面が開いてるかどうか
		protected boolean isShowing() {
			if (targetPanel == null) {
				return false;
			}
			return targetPanel.isShowing();
		}

		/**
		 * ポーリング開始
		 */
		protected void startTimer() {
			if (timer == null) {
				timer = new Timer(true);
			}
			timer.schedule(this, 0, interval);
		}

		/**
		 *  ポーリング終了
		 */
		protected void stopTimer() {
			if (timer != null) {
				timer.cancel();
				timer = null;
			}
		}
	}

	/**
	 * panelの全MCTableを取り出す。
	 */
	protected Component getComponent(MCRootPanel panel, String aName) {
		Component[] list = MCBeansUtil.getAllComponents(panel);
		for (Component c : list) {
			if (MCStringUtil.nullToBlank(c.getName()).equals(aName)) {
				return c;
			}
		}

		return null;
	}

	// 画面を中央に表示
	@Override
	protected void setDefaultScreenPosition() {
		super.setDefaultScreenPosition();

		setArrangementCenter();
	}

	protected void setPno() {
		getListDtlL().forEach(o -> {
			if (isNull(o.pno())) {
				o.pno(++pno_cntr);
			}
		});
	}

	/**
	 * 入力値設定名のコンボボックスのリストを返します。
	 *
	 * @return 入力値設定名のコンボボックスのリスト
	 */
	@Override
	public MCList<ListDtlR> getListDtl_init_settings_nm(MCRow row, MCEventInfo info) {
		MCList<ListDtlR> result = createListDtlL();
		result.addStringColumn(MCListLogic.getViewColumnName());

		if (targetRootPanel instanceof FXBAP_PanelBase) {
			FXBAP_PanelBase p = (FXBAP_PanelBase) targetRootPanel;
			p.getSrchCndInfoList().forEach(i -> {
				// システム共通のデータのみ表示する
				if (MCResourceLayerType.BARCODE.name().equals(i.getSettingUnitType())) {
					ListDtlR o = result.createRow();
					o.setString(MCListLogic.getViewColumnName(), i.getSettingInfoName());
					o.init_settings_id(i.getSettingInfoID());
					o.init_settings_nm(i.getSettingInfoName());
					result.add(o);
				}
			});
		}

		return result;
	}

	/**
	 * カラム順設定名のコンボボックスのリストを返します。
	 *
	 * @return カラム順設定名のコンボボックスのリスト
	 */
	@Override
	public MCList<InfoDtlR> getInfoDtl_init_list_settings_nm(MCRow row, MCEventInfo info) {
		String n = getInfoDtlL().getString(info.getEventIndex(), InfoDtlR.$table_id);

		MCList<InfoDtlR> result = createInfoDtlL();
		result.addStringColumn(MCListLogic.getViewColumnName());

		for (MCTable<?> t : getTargetTables(targetRootPanel)) {
			if (n.equals(t.getName())) {
				t.getBarcodeColumnWidthInfoList().forEach(i -> {
					// システム共通のデータのみ表示する
					if (MCResourceLayerType.BARCODE.name().equals(i.getSettingUnitType())) {
						List<MCColumnWidthData> dl = i.getColumnWidthList();
						if (!dl.isEmpty()) {
							// バーコード用の設定のみ表示する
							if (dl.get(0).getFocusColumn() != null) {
								InfoDtlR o = result.createRow();
								o.setString(MCListLogic.getViewColumnName(),
										i.getSettingInfoName());
								o.init_list_settings_id(i.getSettingInfoID());
								o.init_list_settings_nm(i.getSettingInfoName());
								result.add(o);
							}
						}
					}
				});
				break;
			}
		}

		return result;
	}

	/**
	 * フォーカス設定名のコンボボックスのリストを返します。
	 *
	 * @return フォーカス設定名のコンボボックスのリスト
	 */
	@Override
	public MCList<ListDtlR> getListDtl_init_focus_nm(MCRow row, MCEventInfo info) {
		MCList<ListDtlR> result = createListDtlL();
		result.addStringColumn(MCListLogic.getViewColumnName());

		String prefix = createKey("_0_SCR_", targetRootPanel.getModuleID(),
				targetRootPanel.getScreenID(), "barcode", "barcode_focus", "list");
		for (String key : findPattern(prefix, "*")) {
			ListDtlR o = result.createRow();
			o.init_focus_id(getString(key, "focusID"));
			o.init_focus_nm(getString(key, "focusNM"));
			o.setString(MCListLogic.getViewColumnName(), o.init_focus_nm());
			result.add(o);
		}

		return result;
	}

	/**
	 * 配置情報設定名のコンボボックスのリストを返します。
	 *
	 * @return 配置情報設定名のコンボボックスのリスト
	 */
	@Override
	public MCList<ListDtlR> getListDtl_init_screen_settings_nm(MCRow row, MCEventInfo info) {
		MCList<ListDtlR> result = createListDtlL();
		result.addStringColumn(MCListLogic.getViewColumnName());

		String prefix = createKey("_0_SCR_", targetRootPanel.getModuleID(),
				targetRootPanel.getScreenID(), "barcode", "personalize_location", "list");
		for (String key : findPattern(prefix, "*")) {
			ListDtlR o = result.createRow();
			o.init_screen_settings_id(getString(key, "locationID"));
			o.init_screen_settings_nm(getString(key, "locationNM"));
			o.setString(MCListLogic.getViewColumnName(), o.init_screen_settings_nm());
			result.add(o);
		}

		return result;
	}

	/**
	 * MCAppClientリソースのシステム共通のリソース値を返します。
	 *
	 * @param keys リソースキー
	 * @return リソース値。リソース値が殻文字の場合はnull。リソース値が見つからなかった場合はnull。
	 */
	protected String getString(String... keys) {
		return MCStringUtil.blankToNull(
				getResource().getString(getResourceLayerType(), createKey(keys)));
	}

	/**
	 * MCAppClientリソースのシステム共通のリソース情報を登録します。
	 *
	 * @param val リソース値。nullを指定した場合は空文字を登録する。
	 * @param keys リソースキー
	 */
	protected void setString(String val, String... keys) {
		getResource().setString(getResourceLayerType(), createKey(keys),
				MCStringUtil.nullToBlank(val));
	}

	protected String[] findPattern(String... keys) {
		return getResource().findPattern(getResourceLayerType(), createKey(keys));
	}

	@Override
	protected String getPopupPattern(MCPopupBeans compo) {
		return FSUCP_PopupConfig.PERSONALIZE_PANEL;
	}

	@Override
	public boolean isChanged(MCTable<?> tbl) {
		if (tbl == InfoDtlTable) {
			for (MCList<InfoDtlR> l : infoDtlMap.values()) {
				if (!l.isStatusNone()) {
					return true;
				}
			}
		}
		return super.isChanged(tbl);
	}

	@Override
	protected void setCellConfig() {
		super.setCellConfig();

		ListDtlTable.setCellConfig(createListDtlTableCellConfig());
		InfoDtlTable.setCellConfig(createInfoDtlTableCellConfig());
	}

	protected MCCellConfig createListDtlTableCellConfig() {
		return new ListDtlTableCellConfig();
	}

	protected MCCellConfig createInfoDtlTableCellConfig() {
		return new InfoDtlTableCellConfig();
	}

	protected class ListDtlTableCellConfig extends FXBAP_CellConfig {

		@Override
		public MCMode getPriorMode(int index, MCColumnConfig column, MCTable table) {

			// 登録済みのバーコードＩＤは変更させない
			if (column == columnListDtl_barcode_id) {
				ListDtlR o = getListDtlL().get(index);
				if (!reloadDtlList.subList(ListDtlR.$pno, o.pno()).isEmpty()) {
					return MCMode.READ_ONLY;
				}
			}

			return super.getPriorMode(index, column, table);
		}
	}

	protected class InfoDtlTableCellConfig extends FXBAP_CellConfig {

		@Override
		public MCMode getPriorMode(int index, MCColumnConfig column, MCTable table) {

			// 削除行のテーブル情報は入力させない
			if (column == columnInfoDtl_init_list_settings_nm) {
				InfoDtlR o = getInfoDtlL().get(index);
				MCList<ListDtlR> list = reloadDtlList.subList(ListDtlR.$pno, o.pno());
				if (list.size() == 1) {
					if (list.get(0).isStatusDelete()) {
						return MCMode.READ_ONLY;
					}
				}
			}

			return super.getPriorMode(index, column, table);
		}
	}

	public final String BARCODE = "BARCODE_";

	// 新規バーコードIDを生成する。
	public String createBarcodeID(String aModuleID, String aScreenID) {

		// すでに登録されているかどうかのチェック
		List<String>list = new ArrayList<String>();
		String listKey = createBarcodeResourceKey(aModuleID, aScreenID);
		String[] baseKeys = findPattern(listKey, "*");
		for (String key1 : baseKeys) {
			String barcode_id = getString(key1, "barcodeID");
			list.add(barcode_id);
		}

		for(int n = 1; n < 1000000000; n++) {
			String barcode_id = BARCODE+String.format("%09d", n);
			if(list.contains(barcode_id) == false) {
				// 画面上に表示されている分のチェック
				boolean b = false;
				for(ListDtlR r : ListDtlTable.getList()) {
					if(barcode_id.equals(r.barcode_id())) {
						b = true;
						break;
					}
				}

				if(b == false) {
					String id = prohibitionString(barcode_id);
					return id;
				}
			}
		}


		return BARCODE+"999999999";
	}

	/**
	 * 指定された入力値設定ＩＤに対応する入力値設定名を返します。
	 *
	 * @param id 入力値設定ＩＤ
	 * @return 入力値設定名。入力値設定名が見つからなかった場合はnull。
	 */
	protected String getInitSettingsNm(String id) {
		if (targetRootPanel instanceof FXBAP_PanelBase) {
			FXBAP_PanelBase p = (FXBAP_PanelBase) targetRootPanel;
			for (SrchCndInfo i : p.getSrchCndInfoList()) {
				if (MCResourceLayerType.BARCODE.name().equals(i.getSettingUnitType())) {
					if (isSame(id, i.getSettingInfoID())) {
						return i.getSettingInfoName();
					}
				}
			}
		}
		return null;
	}

	/**
	 * 指定されたフォーカス設定ＩＤに対応するフォーカス設定名を返します。
	 *
	 * @param id フォーカス設定ＩＤ
	 * @return フォーカス設定名。フォーカス設定名が見つからなかった場合はnull。
	 */
	protected String getInitFocusNm(String id) {
		if (targetRootPanel != null) {
			String prefix = createKey("_0_SCR_", targetRootPanel.getModuleID(),
					targetRootPanel.getScreenID(), "barcode", "barcode_focus", "list");
			for (String key : findPattern(prefix, "*")) {
				if (isSame(id, getString(key, "focusID"))) {
					return getString(key, "focusNM");
				}
			}
		}
		return null;
	}

	/**
	 * 指定された配置情報設定ＩＤに対応する配置情報設定名を返します。
	 *
	 * @param id 配置情報設定ＩＤ
	 * @return 配置情報設定名。配置情報設定名が見つからなかった場合はnull。
	 */
	protected String getInitScreenSettingsNm(String id) {
		if (targetRootPanel != null) {
			String prefix = createKey("_0_SCR_", targetRootPanel.getModuleID(),
					targetRootPanel.getScreenID(), "barcode", "personalize_location", "list");
			for (String key : findPattern(prefix, "*")) {
				if (isSame(id, getString(key, "locationID"))) {
					return getString(key, "locationNM");
				}
			}
		}
		return null;
	}

	/**
	 * 指定されたテーブルのカラム順・サイズ変更設定ＩＤに対応するカラム順・サイズ変更設定名を返します。
	 *
	 * @param tableName テーブル名
	 * @param id カラム順・サイズ変更設定ＩＤ
	 * @return カラム順・サイズ変更設定名。カラム順・サイズ変更設定名が見つからなかった場合はnull。
	 */
	protected String getInitListSettingsNm(String tableName, String id) {
		if (targetRootPanel != null) {
			for (MCTable<?> t : getTargetTables(targetRootPanel)) {
				if (tableName.equals(t.getName())) {
					for (MCColumnWidthInfo i : t.getBarcodeColumnWidthInfoList()) {
						List<MCColumnWidthData> dl = i.getColumnWidthList();
						if (!dl.isEmpty()) {
							// バーコード用の設定のみ表示する
							if (dl.get(0).getFocusColumn() != null) {
								if (isSame(id, i.getSettingInfoID())) {
									return i.getSettingInfoName();
								}
							}
						}
					}
				}
			}
		}
		return null;
	}

	// デバッグログ
	static private void debugLog(Throwable t) {
		MCLog.developDebug(t);
	}

	//# 7014-1194
	// マニュアルモード用メソッド
	// c1のNXしたときに特定のボタンをクリックするための仕込み。
	protected void setupListenerNXForManualMode(MCNXBeans c1, List<Object> clist, Object nextButtonFocus) {
//		Object b = clist.get(0);
//		MCButton b = clist.get(0);
		// ボタンメソッドのcallerを同期通信にする必要がある。

		MCRootPanel rp = c1.getBaseRootPanel();
		List<MCButton> blist = new ArrayList<>();

		if(clist != null) {
			Map<MCBeans,List<Object>> map = rp.getBarcodeButtonActions();
			if(map == null) {
				map = new HashMap<>();
				rp.setBarcodeButtonActions(map);
			}
			map.put(c1, clist);

			for(Object c : clist) {
				if(c instanceof MCButton) {
					blist.add((MCButton)c);
				}
			}
		}
		
		if(blist.size() > 0) {
			MCButton b = blist.get(0);
	
//			NXButtonListener e1 = new NXButtonListener(b);
			NXButtonListener e1 = new NXButtonListener(rp, clist);
			c1.addNXListener(e1);
			for (int i = 0; i < blist.size() - 1; i++) {
				MCButton b1 = blist.get(i);
				MCButton b2 = blist.get(i + 1);
				// 7.0.1 セッターで対応
				b1.setNextButtonForBarcode(b2);
				b1.setNextFocusForBarcode(null);
			}
			for (int i = blist.size() - 1; i >= 0; i--) {
				MCButton b3 = blist.get(i);
				// 7.0.1 セッターで対応
				b3.setNextFocusForBarcode(nextButtonFocus);
				break; // 最初の1つのみ有効
			}
		}
	}

}