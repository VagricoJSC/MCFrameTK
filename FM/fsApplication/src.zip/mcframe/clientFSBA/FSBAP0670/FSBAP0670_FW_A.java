package mcframe.clientFSBA.FSBAP0670;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBAP0670"パネルクラスです。<p>
 *
 * バーコード設定画面<br>
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP0670_FW_A extends mcframe.clientFSUC.FSUCP0000.FSUCP_PanelBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0670";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Reflesh]ブロック関連のField定義
	public MCPanel RefleshPanel = null;
	// [Reflesh]ブロックの項目のField定義
	/**
	 *  最新情報を取得.<p>
	 *
	 */
	public MCButton Reflesh_reload = null;
	// [ListPnl]ブロック関連のField定義
	public MCPanel ListPnlPanel = null;
	// [ListPnl]ブロックの項目のField定義
	// [ListDtl]ブロック関連のField定義
	public MCPanel ListDtlPanel = null;
	public MCScrollPane ListDtlScrollPane = null;
	public MCTable2<mcframe.clientFSBA.FSBAP0670.ListDtlR> ListDtlTable = null;
	// [ListDtl]ブロックの項目のField定義
	/**
	 *  バーコード設定ＩＤ.<p>
	 *
	 */
	public MCColumnConfig columnListDtl_barcode_id = null;
	/**
	 *  バーコード設定名.<p>
	 *
	 */
	public MCColumnConfig columnListDtl_barcode_nm = null;
	/**
	 *  入力値設定ＩＤ.<p>
	 *
	 */
	public MCColumnConfig columnListDtl_init_settings_id = null;
	/**
	 *  入力値設定名.<p>
	 *
	 */
	public MCColumnConfig columnListDtl_init_settings_nm = null;
	/**
	 *  フォーカス設定ＩＤ.<p>
	 *
	 */
	public MCColumnConfig columnListDtl_init_focus_id = null;
	/**
	 *  フォーカス設定名.<p>
	 *
	 */
	public MCColumnConfig columnListDtl_init_focus_nm = null;
	/**
	 *  配置情報設定ＩＤ.<p>
	 *
	 */
	public MCColumnConfig columnListDtl_init_screen_settings_id = null;
	/**
	 *  配置情報設定名.<p>
	 *
	 */
	public MCColumnConfig columnListDtl_init_screen_settings_nm = null;
	/**
	 *  ダイアログ自動クローズ.<p>
	 *
	 */
	public MCColumnConfig columnListDtl_use_dialog_monitor_flg = null;
	/**
	 *  画面クリア.<p>
	 *
	 */
	public MCColumnConfig columnListDtl_use_clear_screen_flg = null;
	// [ListBtn]ブロック関連のField定義
	public MCPanel ListBtnPanel = null;
	// [ListBtn]ブロックの項目のField定義
	/**
	 *  入力値設定.<p>
	 *
	 */
	public MCButton ListBtn_open_FSBAP0310 = null;
	/**
	 *  フォーカス設定.<p>
	 *
	 */
	public MCButton ListBtn_open_FSBAP0650 = null;
	/**
	 *  配置情報設定.<p>
	 *
	 */
	public MCButton ListBtn_open_FSBEP0320 = null;
	/**
	 *  行追加.<p>
	 *
	 */
	public MCButton ListBtn_radd = null;
	/**
	 *  行削除.<p>
	 *
	 */
	public MCButton ListBtn_rdel = null;
	/**
	 *  登録する.<p>
	 *
	 */
	public MCButton ListBtn_upd = null;
	// [InfoPnl]ブロック関連のField定義
	public MCPanel InfoPnlPanel = null;
	// [InfoPnl]ブロックの項目のField定義
	// [InfoDtl]ブロック関連のField定義
	public MCPanel InfoDtlPanel = null;
	public MCScrollPane InfoDtlScrollPane = null;
	public MCTable2<mcframe.clientFSBA.FSBAP0670.InfoDtlR> InfoDtlTable = null;
	// [InfoDtl]ブロックの項目のField定義
	/**
	 *  テーブルＩＤ.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_table_id = null;
	/**
	 *  カラム順・サイズ変更ＩＤ.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_init_list_settings_id = null;
	/**
	 *  カラム順・サイズ変更名.<p>
	 *
	 */
	public MCColumnConfig columnInfoDtl_init_list_settings_nm = null;
	// [InfoBtn]ブロック関連のField定義
	public MCPanel InfoBtnPanel = null;
	// [InfoBtn]ブロックの項目のField定義
	/**
	 *  カラム順・サイズ変更.<p>
	 *
	 */
	public MCButton InfoBtn_open_FSBAP0660 = null;
	/** [UPD]モードを表す定数 */
	public static final String UPD = "UPD";
	/** [FIX]モードを表す定数 */
	public static final String FIX = "FIX";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{UPD, FIX};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	
	/** [ListDtl]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0670.ListDtlR> aListDtlL;
	/** [InfoDtl]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0670.InfoDtlR> aInfoDtlL;

	/**
	 * コピーによってaListDtlLを設定します。
	 *
	 * aListDtlLのインスタンスは変更されません。
	 *
	 * @param dataset ListDtlL
	 */
	public void setListDtlL(MCList<mcframe.clientFSBA.FSBAP0670.ListDtlR> aList) {
		if (getListDtlL() != aList) {
			getListDtlL().setAll(aList);
		}
	}

	/**
	 * [ListDtl]ブロックのコンテナaListDtlLを返します。
	 *
	 * @return ListDtlL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0670.ListDtlR> getListDtlL() {
		return aListDtlL;
	}

	/**
	 * aListDtlRを作成します。
	 *
	 * @return ListDtlR
	 */
	public mcframe.clientFSBA.FSBAP0670.ListDtlR createListDtlR() {
		return mcframe.clientFSBA.FSBAP0670.ListDtlR.create();
	}

	/**
	 * aListDtlLを作成します。
	 *
	 * @return ListDtlL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0670.ListDtlR> createListDtlL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0670.ListDtlR.class);
	}

	/**
	 * ListDtlTableを初期化します。
	 */
	protected void createListDtlTable(){
		if(ListDtlTable == null){
			ListDtlTable = beansFactory.createTable2("ListDtl.table");
		}
	}

	/**
	 * コピーによってaInfoDtlLを設定します。
	 *
	 * aInfoDtlLのインスタンスは変更されません。
	 *
	 * @param dataset InfoDtlL
	 */
	public void setInfoDtlL(MCList<mcframe.clientFSBA.FSBAP0670.InfoDtlR> aList) {
		if (getInfoDtlL() != aList) {
			getInfoDtlL().setAll(aList);
		}
	}

	/**
	 * [InfoDtl]ブロックのコンテナaInfoDtlLを返します。
	 *
	 * @return InfoDtlL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0670.InfoDtlR> getInfoDtlL() {
		return aInfoDtlL;
	}

	/**
	 * aInfoDtlRを作成します。
	 *
	 * @return InfoDtlR
	 */
	public mcframe.clientFSBA.FSBAP0670.InfoDtlR createInfoDtlR() {
		return mcframe.clientFSBA.FSBAP0670.InfoDtlR.create();
	}

	/**
	 * aInfoDtlLを作成します。
	 *
	 * @return InfoDtlL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0670.InfoDtlR> createInfoDtlL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0670.InfoDtlR.class);
	}

	/**
	 * InfoDtlTableを初期化します。
	 */
	protected void createInfoDtlTable(){
		if(InfoDtlTable == null){
			InfoDtlTable = beansFactory.createTable2("InfoDtl.table");
		}
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getListDtlL())) ret.add(getListDtlL());
		if(!MCCollectionUtil.contains(ret, getInfoDtlL())) ret.add(getInfoDtlL());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getListDtlL()) return "ListDtl";
		if(aCnt == getInfoDtlL()) return "InfoDtl";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("ListDtl")) return getListDtlL();
		if(bId.equals("InfoDtl")) return getInfoDtlL();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(RefleshPanel);
		ret.add(ListPnlPanel);
		ret.add(ListDtlPanel);
		ret.add(ListBtnPanel);
		ret.add(InfoPnlPanel);
		ret.add(InfoDtlPanel);
		ret.add(InfoBtnPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0670_FW_A() {
		aListDtlL = createListDtlL();
		aInfoDtlL = createInfoDtlL();

	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP0670_FW_A(String name) {
		aListDtlL = createListDtlL();
		createListDtlTable();
		ListDtlTable.setRowName(name);
		aInfoDtlL = createInfoDtlL();
		createInfoDtlTable();
		InfoDtlTable.setRowName(name);
	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP0670_FW.jbCreateReflesh((FSBAP0670)this);
		FSBAP0670_FW.jbCreateListPnl((FSBAP0670)this);
		FSBAP0670_FW.jbCreateListDtl((FSBAP0670)this);
		FSBAP0670_FW.jbCreateListBtn((FSBAP0670)this);
		FSBAP0670_FW.jbCreateInfoPnl((FSBAP0670)this);
		FSBAP0670_FW.jbCreateInfoDtl((FSBAP0670)this);
		FSBAP0670_FW.jbCreateInfoBtn((FSBAP0670)this);
	}

	/**
	 * [Reflesh]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateReflesh(FSBAP0670 p) {
	}

	/**
	 * [ListPnl]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateListPnl(FSBAP0670 p) {
	}

	/**
	 * [ListDtl]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateListDtl(FSBAP0670 p) {
	}

	/**
	 * [ListBtn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateListBtn(FSBAP0670 p) {
	}

	/**
	 * [InfoPnl]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateInfoPnl(FSBAP0670 p) {
	}

	/**
	 * [InfoDtl]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateInfoDtl(FSBAP0670 p) {
	}

	/**
	 * [InfoBtn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateInfoBtn(FSBAP0670 p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}

	
	/** [ListDtl_init_settings_nm_ListPutter]の定義 */
	private MCListPutter ListDtl_init_settings_nm_p = null;

	/**
	 * [ListDtl_init_settings_nm_ListPutter]の取得
	 */
	protected MCListPutter getListDtl_init_settings_nm_ListPutter() {
		if (ListDtl_init_settings_nm_p == null) {
			ListDtl_init_settings_nm_p = createListDtl_init_settings_nm_ListPutter(columnListDtl_init_settings_nm, "init_settings_nm", "init_settings_id");

		}
		return ListDtl_init_settings_nm_p;
	}
	
	
	/** [ListDtl_init_focus_nm_ListPutter]の定義 */
	private MCListPutter ListDtl_init_focus_nm_p = null;

	/**
	 * [ListDtl_init_focus_nm_ListPutter]の取得
	 */
	protected MCListPutter getListDtl_init_focus_nm_ListPutter() {
		if (ListDtl_init_focus_nm_p == null) {
			ListDtl_init_focus_nm_p = createListDtl_init_focus_nm_ListPutter(columnListDtl_init_focus_nm, "init_focus_nm", "init_focus_id");

		}
		return ListDtl_init_focus_nm_p;
	}
	
	
	/** [ListDtl_init_screen_settings_nm_ListPutter]の定義 */
	private MCListPutter ListDtl_init_screen_settings_nm_p = null;

	/**
	 * [ListDtl_init_screen_settings_nm_ListPutter]の取得
	 */
	protected MCListPutter getListDtl_init_screen_settings_nm_ListPutter() {
		if (ListDtl_init_screen_settings_nm_p == null) {
			ListDtl_init_screen_settings_nm_p = createListDtl_init_screen_settings_nm_ListPutter(columnListDtl_init_screen_settings_nm, "init_screen_settings_nm", "init_screen_settings_id");

		}
		return ListDtl_init_screen_settings_nm_p;
	}
	
	
	/** [InfoDtl_init_list_settings_nm_ListPutter]の定義 */
	private MCListPutter InfoDtl_init_list_settings_nm_p = null;

	/**
	 * [InfoDtl_init_list_settings_nm_ListPutter]の取得
	 */
	protected MCListPutter getInfoDtl_init_list_settings_nm_ListPutter() {
		if (InfoDtl_init_list_settings_nm_p == null) {
			InfoDtl_init_list_settings_nm_p = createInfoDtl_init_list_settings_nm_ListPutter(columnInfoDtl_init_list_settings_nm, "init_list_settings_nm", "init_list_settings_id");

		}
		return InfoDtl_init_list_settings_nm_p;
	}
	

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP0670 create(){
		FSBAP0670 p = new FSBAP0670();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP0670 create(String name){
		FSBAP0670 p = new FSBAP0670(name);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP0670_FW.jbfInitReflesh((FSBAP0670)this);
		FSBAP0670_FW.jbfInitListPnl((FSBAP0670)this);
		FSBAP0670_FW.jbfInitListDtl((FSBAP0670)this);
		FSBAP0670_FW.jbfInitListBtn((FSBAP0670)this);
		FSBAP0670_FW.jbfInitInfoPnl((FSBAP0670)this);
		FSBAP0670_FW.jbfInitInfoDtl((FSBAP0670)this);
		FSBAP0670_FW.jbfInitInfoBtn((FSBAP0670)this);
		FSBAP0670_FW.jbInitReflesh((FSBAP0670)this);
		FSBAP0670_FW.jbInitListPnl((FSBAP0670)this);
		FSBAP0670_FW.jbInitListDtl((FSBAP0670)this);
		FSBAP0670_FW.jbInitListBtn((FSBAP0670)this);
		FSBAP0670_FW.jbInitInfoPnl((FSBAP0670)this);
		FSBAP0670_FW.jbInitInfoDtl((FSBAP0670)this);
		FSBAP0670_FW.jbInitInfoBtn((FSBAP0670)this);
	}

	/**
	 * [Reflesh]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitReflesh(FSBAP0670 p) {
		// ブロック関連の初期化
		p.RefleshPanel = p.beansFactory.createPanel("Reflesh");
		// ブロックの項目の初期化
		p.Reflesh_reload = p.beansFactory.createButton("Reflesh.reload", "no_border");
	}

	/**
	 * [ListPnl]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitListPnl(FSBAP0670 p) {
		// ブロック関連の初期化
		p.ListPnlPanel = p.beansFactory.createPanel("ListPnl");
		// ブロックの項目の初期化
	}

	/**
	 * [ListDtl]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitListDtl(FSBAP0670 p) {
		// ブロック関連の初期化
		p.ListDtlPanel = p.beansFactory.createPanel("ListDtl");
		p.ListDtlScrollPane = p.beansFactory.createScrollPane("ListDtl.scroll");
		p.createListDtlTable();
		// ブロックの項目の初期化
		p.columnListDtl_barcode_id = p.beansFactory.createTableColumn("ListDtl.barcode_id", MCColumnType.TEXT);
		p.columnListDtl_barcode_nm = p.beansFactory.createTableColumn("ListDtl.barcode_nm", MCColumnType.TEXT);
		p.columnListDtl_init_settings_id = p.beansFactory.createTableColumn("ListDtl.init_settings_id", MCColumnType.TEXT);
		p.columnListDtl_init_settings_nm = p.beansFactory.createTableColumn("ListDtl.init_settings_nm", MCColumnType.TEXT_COMBO);
		p.columnListDtl_init_focus_id = p.beansFactory.createTableColumn("ListDtl.init_focus_id", MCColumnType.TEXT);
		p.columnListDtl_init_focus_nm = p.beansFactory.createTableColumn("ListDtl.init_focus_nm", MCColumnType.TEXT_COMBO);
		p.columnListDtl_init_screen_settings_id = p.beansFactory.createTableColumn("ListDtl.init_screen_settings_id", MCColumnType.TEXT);
		p.columnListDtl_init_screen_settings_nm = p.beansFactory.createTableColumn("ListDtl.init_screen_settings_nm", MCColumnType.TEXT_COMBO);
		p.columnListDtl_use_dialog_monitor_flg = p.beansFactory.createTableColumn("ListDtl.use_dialog_monitor_flg", MCColumnType.CHECK);
		p.columnListDtl_use_clear_screen_flg = p.beansFactory.createTableColumn("ListDtl.use_clear_screen_flg", MCColumnType.CHECK);
	}

	/**
	 * [ListBtn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitListBtn(FSBAP0670 p) {
		// ブロック関連の初期化
		p.ListBtnPanel = p.beansFactory.createPanel("ListBtn");
		// ブロックの項目の初期化
		p.ListBtn_open_FSBAP0310 = p.beansFactory.createButton("ListBtn.open_FSBAP0310", "open");
		p.ListBtn_open_FSBAP0650 = p.beansFactory.createButton("ListBtn.open_FSBAP0650", "open");
		p.ListBtn_open_FSBEP0320 = p.beansFactory.createButton("ListBtn.open_FSBEP0320", "open");
		p.ListBtn_radd = p.beansFactory.createButton("ListBtn.radd", "no_border");
		p.ListBtn_rdel = p.beansFactory.createButton("ListBtn.rdel", "no_border");
		p.ListBtn_upd = p.beansFactory.createButton("ListBtn.upd", "upd");
	}

	/**
	 * [InfoPnl]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitInfoPnl(FSBAP0670 p) {
		// ブロック関連の初期化
		p.InfoPnlPanel = p.beansFactory.createPanel("InfoPnl");
		// ブロックの項目の初期化
	}

	/**
	 * [InfoDtl]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitInfoDtl(FSBAP0670 p) {
		// ブロック関連の初期化
		p.InfoDtlPanel = p.beansFactory.createPanel("InfoDtl");
		p.InfoDtlScrollPane = p.beansFactory.createScrollPane("InfoDtl.scroll");
		p.createInfoDtlTable();
		// ブロックの項目の初期化
		p.columnInfoDtl_table_id = p.beansFactory.createTableColumn("InfoDtl.table_id", MCColumnType.TEXT);
		p.columnInfoDtl_init_list_settings_id = p.beansFactory.createTableColumn("InfoDtl.init_list_settings_id", MCColumnType.TEXT);
		p.columnInfoDtl_init_list_settings_nm = p.beansFactory.createTableColumn("InfoDtl.init_list_settings_nm", MCColumnType.TEXT_COMBO);
	}

	/**
	 * [InfoBtn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitInfoBtn(FSBAP0670 p) {
		// ブロック関連の初期化
		p.InfoBtnPanel = p.beansFactory.createPanel("InfoBtn");
		// ブロックの項目の初期化
		p.InfoBtn_open_FSBAP0660 = p.beansFactory.createButton("InfoBtn.open_FSBAP0660", "open");
	}

	/**
	 * [Reflesh]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitReflesh(FSBAP0670 p) {
		// ブロック関連の初期化
		p.add(p.RefleshPanel);
		p.setLastBeans(p.RefleshPanel);
		p.RefleshPanel.setNextBeans(p.ListPnlPanel);
		p.RefleshPanel.setLayoutPosition("N");
		// ブロックの項目の初期化
		p.Reflesh_reload.setIcon("RELOAD");
		p.Reflesh_reload.setFunctionKey(MCFunctionKey.F1);
		p.RefleshPanel.add(p.Reflesh_reload);
		p.RefleshPanel.setLastBeans(p.Reflesh_reload);
	}

	/**
	 * [ListPnl]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitListPnl(FSBAP0670 p) {
		// ブロック関連の初期化
		p.add(p.ListPnlPanel);
		p.ListPnlPanel.setNextBeans(p.InfoPnlPanel);
		p.ListPnlPanel.setLayoutPosition("CLC+");
		// ブロックの項目の初期化
		p.ListPnlPanel.add(p.ListDtlPanel, null);
		p.ListPnlPanel.setLastBeans(p.ListDtlPanel);
		p.ListDtlPanel.setNextBeans(p.ListBtnPanel);
		p.ListPnlPanel.add(p.ListBtnPanel, null);
	}

	/**
	 * [ListDtl]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitListDtl(FSBAP0670 p) {
		// ブロック関連の初期化
		p.ListDtlPanel.add(p.ListDtlScrollPane);
		p.ListDtlPanel.setLastBeans(p.ListDtlTable);
		p.ListDtlScrollPane.setViewportView(p.ListDtlTable);
		p.ListDtlTable.setList(p.getListDtlL());
		p.ListDtlPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * [ListBtn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitListBtn(FSBAP0670 p) {
		// ブロック関連の初期化
		p.ListBtnPanel.setLayoutPosition("SW");
		// ブロックの項目の初期化
		p.ListBtn_open_FSBAP0310.setFunctionKey(MCFunctionKey.F7);
		p.ListBtnPanel.add(p.ListBtn_open_FSBAP0310);
		p.ListBtnPanel.setLastBeans(p.ListBtn_open_FSBAP0310);
		p.ListBtn_open_FSBAP0310.setNextBeans(p.ListBtn_open_FSBAP0650);
		p.ListBtn_open_FSBAP0650.setFunctionKey(MCFunctionKey.F8);
		p.ListBtnPanel.add(p.ListBtn_open_FSBAP0650);
		p.ListBtn_open_FSBAP0650.setNextBeans(p.ListBtn_open_FSBEP0320);
		p.ListBtn_open_FSBEP0320.setFunctionKey(MCFunctionKey.F11);
		p.ListBtnPanel.add(p.ListBtn_open_FSBEP0320);
		p.ListBtn_open_FSBEP0320.setNextBeans(p.ListBtn_radd);
		p.ListBtn_radd.setIcon("INSERT_RECORD");
		p.ListBtn_radd.setFunctionKey(MCFunctionKey.F5);
		p.ListBtnPanel.add(p.ListBtn_radd);
		p.ListBtn_radd.setNextBeans(p.ListBtn_rdel);
		p.ListBtn_rdel.setIcon("DELETE_RECORD");
		p.ListBtn_rdel.setFunctionKey(MCFunctionKey.F6);
		p.ListBtnPanel.add(p.ListBtn_rdel);
		p.ListBtn_rdel.setNextBeans(p.ListBtn_upd);
		p.ListBtn_upd.setIcon("REGISTER");
		p.ListBtn_upd.setFunctionKey(MCFunctionKey.F9);
		p.ListBtnPanel.add(p.ListBtn_upd);
	}

	/**
	 * [InfoPnl]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitInfoPnl(FSBAP0670 p) {
		// ブロック関連の初期化
		p.add(p.InfoPnlPanel);
		p.InfoPnlPanel.setLayoutPosition("CRC+");
		// ブロックの項目の初期化
		p.InfoPnlPanel.add(p.InfoDtlPanel, null);
		p.InfoPnlPanel.setLastBeans(p.InfoDtlPanel);
		p.InfoDtlPanel.setNextBeans(p.InfoBtnPanel);
		p.InfoPnlPanel.add(p.InfoBtnPanel, null);
	}

	/**
	 * [InfoDtl]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitInfoDtl(FSBAP0670 p) {
		// ブロック関連の初期化
		p.InfoDtlPanel.add(p.InfoDtlScrollPane);
		p.InfoDtlPanel.setLastBeans(p.InfoDtlTable);
		p.InfoDtlScrollPane.setViewportView(p.InfoDtlTable);
		p.InfoDtlTable.setList(p.getInfoDtlL());
		p.InfoDtlPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * [InfoBtn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitInfoBtn(FSBAP0670 p) {
		// ブロック関連の初期化
		p.InfoBtnPanel.setLayoutPosition("S");
		// ブロックの項目の初期化
		p.InfoBtn_open_FSBAP0660.setFunctionKey(MCFunctionKey.F12);
		p.InfoBtnPanel.add(p.InfoBtn_open_FSBAP0660);
		p.InfoBtnPanel.setLastBeans(p.InfoBtn_open_FSBAP0660);
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "G";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP0670_FW.mcInitReflesh((FSBAP0670)this);
		FSBAP0670_FW.mcInitListPnl((FSBAP0670)this);
		FSBAP0670_FW.mcInitListDtl((FSBAP0670)this);
		FSBAP0670_FW.mcInitListBtn((FSBAP0670)this);
		FSBAP0670_FW.mcInitInfoPnl((FSBAP0670)this);
		FSBAP0670_FW.mcInitInfoDtl((FSBAP0670)this);
		FSBAP0670_FW.mcInitInfoBtn((FSBAP0670)this);

		// [UPD]ステータスのモードの設定
		FSBAP0670_FW.statusInitUPD_Reflesh((FSBAP0670)this);
		FSBAP0670_FW.statusInitUPD_ListPnl((FSBAP0670)this);
		FSBAP0670_FW.statusInitUPD_ListDtl((FSBAP0670)this);
		FSBAP0670_FW.statusInitUPD_ListBtn((FSBAP0670)this);
		FSBAP0670_FW.statusInitUPD_InfoPnl((FSBAP0670)this);
		FSBAP0670_FW.statusInitUPD_InfoDtl((FSBAP0670)this);
		FSBAP0670_FW.statusInitUPD_InfoBtn((FSBAP0670)this);

		// [FIX]ステータスのモードの設定
		FSBAP0670_FW.statusInitFIX_Reflesh((FSBAP0670)this);
		FSBAP0670_FW.statusInitFIX_ListPnl((FSBAP0670)this);
		FSBAP0670_FW.statusInitFIX_ListDtl((FSBAP0670)this);
		FSBAP0670_FW.statusInitFIX_ListBtn((FSBAP0670)this);
		FSBAP0670_FW.statusInitFIX_InfoPnl((FSBAP0670)this);
		FSBAP0670_FW.statusInitFIX_InfoDtl((FSBAP0670)this);
		FSBAP0670_FW.statusInitFIX_InfoBtn((FSBAP0670)this);

	}

	/**
	 *  [Reflesh]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitReflesh(FSBAP0670 p) {
		p.Reflesh_reload.addAllListener(p);
		p.Reflesh_reload.setAPMethodName("doReflesh_reload");
	}

	/**
	 *  [ListPnl]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitListPnl(FSBAP0670 p) {
	}

	/**
	 *  [ListDtl]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitListDtl(FSBAP0670 p) {
		p.ListDtlTable.addAllListener(p);
		p.columnListDtl_barcode_id.addAllListener(p);
		p.columnListDtl_barcode_id.setListListener(p);
		p.columnListDtl_barcode_nm.addAllListener(p);
		p.columnListDtl_barcode_nm.setListListener(p);
		p.columnListDtl_init_settings_id.addAllListener(p);
		p.columnListDtl_init_settings_id.setListListener(p);
		p.columnListDtl_init_settings_nm.addAllListener(p);
		p.columnListDtl_init_settings_nm.setListListener(p);
		p.columnListDtl_init_focus_id.addAllListener(p);
		p.columnListDtl_init_focus_id.setListListener(p);
		p.columnListDtl_init_focus_nm.addAllListener(p);
		p.columnListDtl_init_focus_nm.setListListener(p);
		p.columnListDtl_init_screen_settings_id.addAllListener(p);
		p.columnListDtl_init_screen_settings_id.setListListener(p);
		p.columnListDtl_init_screen_settings_nm.addAllListener(p);
		p.columnListDtl_init_screen_settings_nm.setListListener(p);
		p.columnListDtl_use_dialog_monitor_flg.addAllListener(p);
		p.columnListDtl_use_clear_screen_flg.addAllListener(p);
	}

	/**
	 *  [ListBtn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitListBtn(FSBAP0670 p) {
		p.ListBtn_open_FSBAP0310.addAllListener(p);
		p.ListBtn_open_FSBAP0310.setAPMethodName("doListBtn_open_FSBAP0310");
		p.ListBtn_open_FSBAP0650.addAllListener(p);
		p.ListBtn_open_FSBAP0650.setAPMethodName("doListBtn_open_FSBAP0650");
		p.ListBtn_open_FSBEP0320.addAllListener(p);
		p.ListBtn_open_FSBEP0320.setAPMethodName("doListBtn_open_FSBEP0320");
		p.ListBtn_radd.addAllListener(p);
		p.ListBtn_radd.setAPMethodName("doListBtn_radd");
		p.ListBtn_rdel.addAllListener(p);
		p.ListBtn_rdel.setAPMethodName("doListBtn_rdel");
		p.ListBtn_upd.addAllListener(p);
		p.ListBtn_upd.setAPMethodName("doListBtn_upd");
	}

	/**
	 *  [InfoPnl]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitInfoPnl(FSBAP0670 p) {
	}

	/**
	 *  [InfoDtl]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitInfoDtl(FSBAP0670 p) {
		p.InfoDtlTable.addAllListener(p);
		p.columnInfoDtl_table_id.addAllListener(p);
		p.columnInfoDtl_table_id.setListListener(p);
		p.columnInfoDtl_init_list_settings_id.addAllListener(p);
		p.columnInfoDtl_init_list_settings_id.setListListener(p);
		p.columnInfoDtl_init_list_settings_nm.addAllListener(p);
		p.columnInfoDtl_init_list_settings_nm.setListListener(p);
	}

	/**
	 *  [InfoBtn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitInfoBtn(FSBAP0670 p) {
		p.InfoBtn_open_FSBAP0660.addAllListener(p);
		p.InfoBtn_open_FSBAP0660.setAPMethodName("doInfoBtn_open_FSBAP0660");
	}

	/**
	 * [UPD]ステータスの[Reflesh]ブロックのモードの設定
	 */
	protected static void statusInitUPD_Reflesh(FSBAP0670 p){
		p.Reflesh_reload.putMode(p, UPD, MCMode.ENABLE);

	}

	/**
	 * [UPD]ステータスの[ListPnl]ブロックのモードの設定
	 */
	protected static void statusInitUPD_ListPnl(FSBAP0670 p){

	}

	/**
	 * [UPD]ステータスの[ListDtl]ブロックのモードの設定
	 */
	protected static void statusInitUPD_ListDtl(FSBAP0670 p){
		p.columnListDtl_barcode_id.putMode(p, UPD, MCMode.READ_ONLY);
		p.columnListDtl_barcode_nm.putMode(p, UPD, MCMode.REQUIRED);
		p.columnListDtl_init_settings_id.putMode(p, UPD, MCMode.INVISIBLE);
		p.columnListDtl_init_settings_nm.putMode(p, UPD, MCMode.ENABLE);
		p.columnListDtl_init_focus_id.putMode(p, UPD, MCMode.INVISIBLE);
		p.columnListDtl_init_focus_nm.putMode(p, UPD, MCMode.ENABLE);
		p.columnListDtl_init_screen_settings_id.putMode(p, UPD, MCMode.INVISIBLE);
		p.columnListDtl_init_screen_settings_nm.putMode(p, UPD, MCMode.ENABLE);
		p.columnListDtl_use_dialog_monitor_flg.putMode(p, UPD, MCMode.REQUIRED);
		p.columnListDtl_use_clear_screen_flg.putMode(p, UPD, MCMode.REQUIRED);

	}

	/**
	 * [UPD]ステータスの[ListBtn]ブロックのモードの設定
	 */
	protected static void statusInitUPD_ListBtn(FSBAP0670 p){
		p.ListBtn_open_FSBAP0310.putMode(p, UPD, MCMode.ENABLE);
		p.ListBtn_open_FSBAP0650.putMode(p, UPD, MCMode.ENABLE);
		p.ListBtn_open_FSBEP0320.putMode(p, UPD, MCMode.ENABLE);
		p.ListBtn_radd.putMode(p, UPD, MCMode.ENABLE);
		p.ListBtn_rdel.putMode(p, UPD, MCMode.ENABLE);
		p.ListBtn_upd.putMode(p, UPD, MCMode.ENABLE);

	}

	/**
	 * [UPD]ステータスの[InfoPnl]ブロックのモードの設定
	 */
	protected static void statusInitUPD_InfoPnl(FSBAP0670 p){

	}

	/**
	 * [UPD]ステータスの[InfoDtl]ブロックのモードの設定
	 */
	protected static void statusInitUPD_InfoDtl(FSBAP0670 p){
		p.columnInfoDtl_table_id.putMode(p, UPD, MCMode.READ_ONLY);
		p.columnInfoDtl_init_list_settings_id.putMode(p, UPD, MCMode.INVISIBLE);
		p.columnInfoDtl_init_list_settings_nm.putMode(p, UPD, MCMode.ENABLE);

	}

	/**
	 * [UPD]ステータスの[InfoBtn]ブロックのモードの設定
	 */
	protected static void statusInitUPD_InfoBtn(FSBAP0670 p){
		p.InfoBtn_open_FSBAP0660.putMode(p, UPD, MCMode.ENABLE);

	}

	/**
	 * [FIX]ステータスの[Reflesh]ブロックのモードの設定
	 */
	protected static void statusInitFIX_Reflesh(FSBAP0670 p){
		p.Reflesh_reload.putMode(p, FIX, MCMode.ENABLE);

	}

	/**
	 * [FIX]ステータスの[ListPnl]ブロックのモードの設定
	 */
	protected static void statusInitFIX_ListPnl(FSBAP0670 p){

	}

	/**
	 * [FIX]ステータスの[ListDtl]ブロックのモードの設定
	 */
	protected static void statusInitFIX_ListDtl(FSBAP0670 p){
		p.columnListDtl_barcode_id.putMode(p, FIX, MCMode.READ_ONLY);
		p.columnListDtl_barcode_nm.putMode(p, FIX, MCMode.REQUIRED);
		p.columnListDtl_init_settings_id.putMode(p, FIX, MCMode.INVISIBLE);
		p.columnListDtl_init_settings_nm.putMode(p, FIX, MCMode.ENABLE);
		p.columnListDtl_init_focus_id.putMode(p, FIX, MCMode.INVISIBLE);
		p.columnListDtl_init_focus_nm.putMode(p, FIX, MCMode.ENABLE);
		p.columnListDtl_init_screen_settings_id.putMode(p, FIX, MCMode.INVISIBLE);
		p.columnListDtl_init_screen_settings_nm.putMode(p, FIX, MCMode.ENABLE);
		p.columnListDtl_use_dialog_monitor_flg.putMode(p, FIX, MCMode.REQUIRED);
		p.columnListDtl_use_clear_screen_flg.putMode(p, FIX, MCMode.REQUIRED);

	}

	/**
	 * [FIX]ステータスの[ListBtn]ブロックのモードの設定
	 */
	protected static void statusInitFIX_ListBtn(FSBAP0670 p){
		p.ListBtn_open_FSBAP0310.putMode(p, FIX, MCMode.ENABLE);
		p.ListBtn_open_FSBAP0650.putMode(p, FIX, MCMode.ENABLE);
		p.ListBtn_open_FSBEP0320.putMode(p, FIX, MCMode.ENABLE);
		p.ListBtn_radd.putMode(p, FIX, MCMode.ENABLE);
		p.ListBtn_rdel.putMode(p, FIX, MCMode.ENABLE);
		p.ListBtn_upd.putMode(p, FIX, MCMode.ENABLE);

	}

	/**
	 * [FIX]ステータスの[InfoPnl]ブロックのモードの設定
	 */
	protected static void statusInitFIX_InfoPnl(FSBAP0670 p){

	}

	/**
	 * [FIX]ステータスの[InfoDtl]ブロックのモードの設定
	 */
	protected static void statusInitFIX_InfoDtl(FSBAP0670 p){
		p.columnInfoDtl_table_id.putMode(p, FIX, MCMode.READ_ONLY);
		p.columnInfoDtl_init_list_settings_id.putMode(p, FIX, MCMode.INVISIBLE);
		p.columnInfoDtl_init_list_settings_nm.putMode(p, FIX, MCMode.ENABLE);

	}

	/**
	 * [FIX]ステータスの[InfoBtn]ブロックのモードの設定
	 */
	protected static void statusInitFIX_InfoBtn(FSBAP0670 p){
		p.InfoBtn_open_FSBAP0660.putMode(p, FIX, MCMode.ENABLE);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return UPD;
	}

	/**
	 * Table/Treeの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
		FSBAP0670_FW.setTableConfigListDtl((FSBAP0670)this);
		FSBAP0670_FW.setTableConfigInfoDtl((FSBAP0670)this);
	}

	/**
	 * [ListDtl]ブロックのTableの設定
	 */
	protected static void setTableConfigListDtl(FSBAP0670 p) {
		p.columnListDtl_barcode_id.setMeta(mcframe.clientFSBA.FSBAP0670.ListDtlR.barcode_id_META);
		p.ListDtlTable.addColumnConfig(p.columnListDtl_barcode_id);
		p.columnListDtl_barcode_nm.setMeta(mcframe.clientFSBA.FSBAP0670.ListDtlR.barcode_nm_META);
		p.ListDtlTable.addColumnConfig(p.columnListDtl_barcode_nm);
		p.columnListDtl_init_settings_id.setMeta(mcframe.clientFSBA.FSBAP0670.ListDtlR.init_settings_id_META);
		p.ListDtlTable.addColumnConfig(p.columnListDtl_init_settings_id);
		p.columnListDtl_init_settings_nm.setMeta(mcframe.clientFSBA.FSBAP0670.ListDtlR.init_settings_nm_META);
		p.columnListDtl_init_settings_nm.addLinkBeans(p.columnListDtl_init_settings_id);
		p.ListDtlTable.addColumnConfig(p.columnListDtl_init_settings_nm);
		p.columnListDtl_init_focus_id.setMeta(mcframe.clientFSBA.FSBAP0670.ListDtlR.init_focus_id_META);
		p.ListDtlTable.addColumnConfig(p.columnListDtl_init_focus_id);
		p.columnListDtl_init_focus_nm.setMeta(mcframe.clientFSBA.FSBAP0670.ListDtlR.init_focus_nm_META);
		p.columnListDtl_init_focus_nm.addLinkBeans(p.columnListDtl_init_focus_id);
		p.ListDtlTable.addColumnConfig(p.columnListDtl_init_focus_nm);
		p.columnListDtl_init_screen_settings_id.setMeta(mcframe.clientFSBA.FSBAP0670.ListDtlR.init_screen_settings_id_META);
		p.ListDtlTable.addColumnConfig(p.columnListDtl_init_screen_settings_id);
		p.columnListDtl_init_screen_settings_nm.setMeta(mcframe.clientFSBA.FSBAP0670.ListDtlR.init_screen_settings_nm_META);
		p.columnListDtl_init_screen_settings_nm.addLinkBeans(p.columnListDtl_init_screen_settings_id);
		p.ListDtlTable.addColumnConfig(p.columnListDtl_init_screen_settings_nm);
		p.columnListDtl_use_dialog_monitor_flg.setMeta(mcframe.clientFSBA.FSBAP0670.ListDtlR.use_dialog_monitor_flg_META);
		p.ListDtlTable.addColumnConfig(p.columnListDtl_use_dialog_monitor_flg);
		p.columnListDtl_use_clear_screen_flg.setMeta(mcframe.clientFSBA.FSBAP0670.ListDtlR.use_clear_screen_flg_META);
		p.ListDtlTable.addColumnConfig(p.columnListDtl_use_clear_screen_flg);
	}

	/**
	 * [InfoDtl]ブロックのTableの設定
	 */
	protected static void setTableConfigInfoDtl(FSBAP0670 p) {
		p.columnInfoDtl_table_id.setMeta(mcframe.clientFSBA.FSBAP0670.InfoDtlR.table_id_META);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_table_id);
		p.columnInfoDtl_init_list_settings_id.setMeta(mcframe.clientFSBA.FSBAP0670.InfoDtlR.init_list_settings_id_META);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_init_list_settings_id);
		p.columnInfoDtl_init_list_settings_nm.setMeta(mcframe.clientFSBA.FSBAP0670.InfoDtlR.init_list_settings_nm_META);
		p.columnInfoDtl_init_list_settings_nm.addLinkBeans(p.columnInfoDtl_init_list_settings_id);
		p.InfoDtlTable.addColumnConfig(p.columnInfoDtl_init_list_settings_nm);
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
		columnListDtl_init_settings_nm.setListVisibleColumn(MCListLogic.getViewColumnName());
		columnListDtl_init_settings_nm.getListConfig().setPutter(getListDtl_init_settings_nm_ListPutter());
		columnListDtl_init_focus_nm.setListVisibleColumn(MCListLogic.getViewColumnName());
		columnListDtl_init_focus_nm.getListConfig().setPutter(getListDtl_init_focus_nm_ListPutter());
		columnListDtl_init_screen_settings_nm.setListVisibleColumn(MCListLogic.getViewColumnName());
		columnListDtl_init_screen_settings_nm.getListConfig().setPutter(getListDtl_init_screen_settings_nm_ListPutter());
		columnInfoDtl_init_list_settings_nm.setListVisibleColumn(MCListLogic.getViewColumnName());
		columnInfoDtl_init_list_settings_nm.getListConfig().setPutter(getInfoDtl_init_list_settings_nm_ListPutter());
	}

	/**
	 * この画面を[UPD]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setUPDStatus() {
		status = UPD;
		setAllStatus(status);
	}

	/**
	 * この画面を[FIX]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setFIXStatus() {
		status = FIX;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (UPD.equals(status)) {
			setUPDStatus();
		}
		else if (FIX.equals(status)) {
			setFIXStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * [ListDtl_init_settings_nm_ListPutter]の作成
	 */
	protected MCListPutter createListDtl_init_settings_nm_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("");
		return lp;
	}
	 
	/**
	 * [ListDtl_init_focus_nm_ListPutter]の作成
	 */
	protected MCListPutter createListDtl_init_focus_nm_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("");
		return lp;
	}
	 
	/**
	 * [ListDtl_init_screen_settings_nm_ListPutter]の作成
	 */
	protected MCListPutter createListDtl_init_screen_settings_nm_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("");
		return lp;
	}
	 
	/**
	 * [InfoDtl_init_list_settings_nm_ListPutter]の作成
	 */
	protected MCListPutter createInfoDtl_init_list_settings_nm_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("");
		return lp;
	}
	 

	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		if(combo == columnListDtl_init_settings_nm) return getListDtl_init_settings_nm(row, info);
		if(combo == columnListDtl_init_focus_nm) return getListDtl_init_focus_nm(row, info);
		if(combo == columnListDtl_init_screen_settings_nm) return getListDtl_init_screen_settings_nm(row, info);
		if(combo == columnInfoDtl_init_list_settings_nm) return getInfoDtl_init_list_settings_nm(row, info);
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == Reflesh_reload) doReflesh_reload(info);
		else if (ap == ListBtn_open_FSBAP0310) doListBtn_open_FSBAP0310(info);
		else if (ap == ListBtn_open_FSBAP0650) doListBtn_open_FSBAP0650(info);
		else if (ap == ListBtn_open_FSBEP0320) doListBtn_open_FSBEP0320(info);
		else if (ap == ListBtn_radd) doListBtn_radd(info);
		else if (ap == ListBtn_rdel) doListBtn_rdel(info);
		else if (ap == ListBtn_upd) doListBtn_upd(info);
		else if (ap == InfoBtn_open_FSBAP0660) doInfoBtn_open_FSBAP0660(info);
	}

	/**
	 * [Reflesh]パネルの[reload]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doReflesh_reload(MCEventInfo info);

	/**
	 * [ListBtn]パネルの[open_FSBAP0310]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doListBtn_open_FSBAP0310(MCEventInfo info);

	/**
	 * [ListBtn]パネルの[open_FSBAP0650]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doListBtn_open_FSBAP0650(MCEventInfo info);

	/**
	 * [ListBtn]パネルの[open_FSBEP0320]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doListBtn_open_FSBEP0320(MCEventInfo info);

	/**
	 * [ListBtn]パネルの[radd]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doListBtn_radd(MCEventInfo info);

	/**
	 * [ListBtn]パネルの[rdel]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doListBtn_rdel(MCEventInfo info);

	/**
	 * [ListBtn]パネルの[upd]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doListBtn_upd(MCEventInfo info);

	/**
	 * [InfoBtn]パネルの[open_FSBAP0660]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doInfoBtn_open_FSBAP0660(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == ListDtlTable) return doListDtl_VC(info);
		if (vc == InfoDtlTable) return doInfoDtl_VC(info);
		if (vc == columnListDtl_barcode_id) return doListDtl_barcode_id_VC(info);
		if (vc == columnListDtl_barcode_nm) return doListDtl_barcode_nm_VC(info);
		if (vc == columnListDtl_init_settings_id) return doListDtl_init_settings_id_VC(info);
		if (vc == columnListDtl_init_settings_nm) return doListDtl_init_settings_nm_VC(info);
		if (vc == columnListDtl_init_focus_id) return doListDtl_init_focus_id_VC(info);
		if (vc == columnListDtl_init_focus_nm) return doListDtl_init_focus_nm_VC(info);
		if (vc == columnListDtl_init_screen_settings_id) return doListDtl_init_screen_settings_id_VC(info);
		if (vc == columnListDtl_init_screen_settings_nm) return doListDtl_init_screen_settings_nm_VC(info);
		if (vc == columnListDtl_use_dialog_monitor_flg) return doListDtl_use_dialog_monitor_flg_VC(info);
		if (vc == columnListDtl_use_clear_screen_flg) return doListDtl_use_clear_screen_flg_VC(info);
		if (vc == columnInfoDtl_table_id) return doInfoDtl_table_id_VC(info);
		if (vc == columnInfoDtl_init_list_settings_id) return doInfoDtl_init_list_settings_id_VC(info);
		if (vc == columnInfoDtl_init_list_settings_nm) return doInfoDtl_init_list_settings_nm_VC(info);
		return true;
	}

	/**
	 * [ListDtl]Tableの選択行が変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doListDtl_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]Tableの選択行が変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ListDtl]パネルの[barcode_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doListDtl_barcode_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ListDtl]パネルの[barcode_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doListDtl_barcode_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ListDtl]パネルの[init_settings_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doListDtl_init_settings_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ListDtl]パネルの[init_settings_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doListDtl_init_settings_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ListDtl]パネルの[init_focus_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doListDtl_init_focus_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ListDtl]パネルの[init_focus_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doListDtl_init_focus_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ListDtl]パネルの[init_screen_settings_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doListDtl_init_screen_settings_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ListDtl]パネルの[init_screen_settings_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doListDtl_init_screen_settings_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ListDtl]パネルの[use_dialog_monitor_flg]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doListDtl_use_dialog_monitor_flg_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ListDtl]パネルの[use_clear_screen_flg]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doListDtl_use_clear_screen_flg_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[table_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_table_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[init_list_settings_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_init_list_settings_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [InfoDtl]パネルの[init_list_settings_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfoDtl_init_list_settings_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == ListDtlTable) doListDtl_NC(info);
		else if (nc == InfoDtlTable) doInfoDtl_NC(info);
		else if (nc == columnListDtl_barcode_id) doListDtl_barcode_id_NC(info);
		else if (nc == columnListDtl_barcode_nm) doListDtl_barcode_nm_NC(info);
		else if (nc == columnListDtl_init_settings_id) doListDtl_init_settings_id_NC(info);
		else if (nc == columnListDtl_init_settings_nm) doListDtl_init_settings_nm_NC(info);
		else if (nc == columnListDtl_init_focus_id) doListDtl_init_focus_id_NC(info);
		else if (nc == columnListDtl_init_focus_nm) doListDtl_init_focus_nm_NC(info);
		else if (nc == columnListDtl_init_screen_settings_id) doListDtl_init_screen_settings_id_NC(info);
		else if (nc == columnListDtl_init_screen_settings_nm) doListDtl_init_screen_settings_nm_NC(info);
		else if (nc == columnListDtl_use_dialog_monitor_flg) doListDtl_use_dialog_monitor_flg_NC(info);
		else if (nc == columnListDtl_use_clear_screen_flg) doListDtl_use_clear_screen_flg_NC(info);
		else if (nc == columnInfoDtl_table_id) doInfoDtl_table_id_NC(info);
		else if (nc == columnInfoDtl_init_list_settings_id) doInfoDtl_init_list_settings_id_NC(info);
		else if (nc == columnInfoDtl_init_list_settings_nm) doInfoDtl_init_list_settings_nm_NC(info);
	}

	/**
	 * [ListDtl]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_NC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[barcode_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_barcode_id_NC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[barcode_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_barcode_nm_NC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[init_settings_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_init_settings_id_NC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[init_settings_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_init_settings_nm_NC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[init_focus_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_init_focus_id_NC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[init_focus_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_init_focus_nm_NC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[init_screen_settings_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_init_screen_settings_id_NC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[init_screen_settings_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_init_screen_settings_nm_NC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[use_dialog_monitor_flg]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_use_dialog_monitor_flg_NC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[use_clear_screen_flg]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_use_clear_screen_flg_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[table_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_table_id_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[init_list_settings_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_init_list_settings_id_NC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[init_list_settings_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_init_list_settings_nm_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == ListDtlTable) doListDtl_NE(info);
		else if (ne == InfoDtlTable) doInfoDtl_NE(info);
		else if (ne == columnListDtl_barcode_id) doListDtl_barcode_id_NE(info);
		else if (ne == columnListDtl_barcode_nm) doListDtl_barcode_nm_NE(info);
		else if (ne == columnListDtl_init_settings_id) doListDtl_init_settings_id_NE(info);
		else if (ne == columnListDtl_init_settings_nm) doListDtl_init_settings_nm_NE(info);
		else if (ne == columnListDtl_init_focus_id) doListDtl_init_focus_id_NE(info);
		else if (ne == columnListDtl_init_focus_nm) doListDtl_init_focus_nm_NE(info);
		else if (ne == columnListDtl_init_screen_settings_id) doListDtl_init_screen_settings_id_NE(info);
		else if (ne == columnListDtl_init_screen_settings_nm) doListDtl_init_screen_settings_nm_NE(info);
		else if (ne == columnListDtl_use_dialog_monitor_flg) doListDtl_use_dialog_monitor_flg_NE(info);
		else if (ne == columnListDtl_use_clear_screen_flg) doListDtl_use_clear_screen_flg_NE(info);
		else if (ne == columnInfoDtl_table_id) doInfoDtl_table_id_NE(info);
		else if (ne == columnInfoDtl_init_list_settings_id) doInfoDtl_init_list_settings_id_NE(info);
		else if (ne == columnInfoDtl_init_list_settings_nm) doInfoDtl_init_list_settings_nm_NE(info);
	}

	/**
	 * [ListDtl]TableのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]TableのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_NE(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[barcode_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_barcode_id_NE(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[barcode_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_barcode_nm_NE(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[init_settings_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_init_settings_id_NE(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[init_settings_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_init_settings_nm_NE(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[init_focus_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_init_focus_id_NE(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[init_focus_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_init_focus_nm_NE(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[init_screen_settings_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_init_screen_settings_id_NE(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[init_screen_settings_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_init_screen_settings_nm_NE(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[use_dialog_monitor_flg]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_use_dialog_monitor_flg_NE(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[use_clear_screen_flg]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_use_clear_screen_flg_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[table_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_table_id_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[init_list_settings_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_init_list_settings_id_NE(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[init_list_settings_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_init_list_settings_nm_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == ListDtlTable) doListDtl_NX(info);
		else if (nx == InfoDtlTable) doInfoDtl_NX(info);
		else if (nx == columnListDtl_barcode_id) doListDtl_barcode_id_NX(info);
		else if (nx == columnListDtl_barcode_nm) doListDtl_barcode_nm_NX(info);
		else if (nx == columnListDtl_init_settings_id) doListDtl_init_settings_id_NX(info);
		else if (nx == columnListDtl_init_settings_nm) doListDtl_init_settings_nm_NX(info);
		else if (nx == columnListDtl_init_focus_id) doListDtl_init_focus_id_NX(info);
		else if (nx == columnListDtl_init_focus_nm) doListDtl_init_focus_nm_NX(info);
		else if (nx == columnListDtl_init_screen_settings_id) doListDtl_init_screen_settings_id_NX(info);
		else if (nx == columnListDtl_init_screen_settings_nm) doListDtl_init_screen_settings_nm_NX(info);
		else if (nx == columnListDtl_use_dialog_monitor_flg) doListDtl_use_dialog_monitor_flg_NX(info);
		else if (nx == columnListDtl_use_clear_screen_flg) doListDtl_use_clear_screen_flg_NX(info);
		else if (nx == columnInfoDtl_table_id) doInfoDtl_table_id_NX(info);
		else if (nx == columnInfoDtl_init_list_settings_id) doInfoDtl_init_list_settings_id_NX(info);
		else if (nx == columnInfoDtl_init_list_settings_nm) doInfoDtl_init_list_settings_nm_NX(info);
	}

	/**
	 * [ListDtl]TableのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]TableのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_NX(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[barcode_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_barcode_id_NX(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[barcode_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_barcode_nm_NX(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[init_settings_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_init_settings_id_NX(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[init_settings_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_init_settings_nm_NX(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[init_focus_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_init_focus_id_NX(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[init_focus_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_init_focus_nm_NX(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[init_screen_settings_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_init_screen_settings_id_NX(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[init_screen_settings_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_init_screen_settings_nm_NX(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[use_dialog_monitor_flg]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_use_dialog_monitor_flg_NX(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[use_clear_screen_flg]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_use_clear_screen_flg_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[table_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_table_id_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[init_list_settings_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_init_list_settings_id_NX(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[init_list_settings_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_init_list_settings_nm_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == columnListDtl_barcode_id) doListDtl_barcode_id_LC(info);
		else if (lc == columnListDtl_barcode_nm) doListDtl_barcode_nm_LC(info);
		else if (lc == columnListDtl_init_settings_id) doListDtl_init_settings_id_LC(info);
		else if (lc == columnListDtl_init_settings_nm) doListDtl_init_settings_nm_LC(info);
		else if (lc == columnListDtl_init_focus_id) doListDtl_init_focus_id_LC(info);
		else if (lc == columnListDtl_init_focus_nm) doListDtl_init_focus_nm_LC(info);
		else if (lc == columnListDtl_init_screen_settings_id) doListDtl_init_screen_settings_id_LC(info);
		else if (lc == columnListDtl_init_screen_settings_nm) doListDtl_init_screen_settings_nm_LC(info);
		else if (lc == columnInfoDtl_table_id) doInfoDtl_table_id_LC(info);
		else if (lc == columnInfoDtl_init_list_settings_id) doInfoDtl_init_list_settings_id_LC(info);
		else if (lc == columnInfoDtl_init_list_settings_nm) doInfoDtl_init_list_settings_nm_LC(info);
	}

	/**
	 * [ListDtl]パネルの[barcode_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_barcode_id_LC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[barcode_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_barcode_nm_LC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[init_settings_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_init_settings_id_LC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[init_settings_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_init_settings_nm_LC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[init_focus_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_init_focus_id_LC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[init_focus_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_init_focus_nm_LC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[init_screen_settings_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_init_screen_settings_id_LC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[init_screen_settings_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_init_screen_settings_nm_LC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[table_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_table_id_LC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[init_list_settings_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_init_list_settings_id_LC(MCEventInfo info){
	}

	/**
	 * [InfoDtl]パネルの[init_list_settings_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfoDtl_init_list_settings_nm_LC(MCEventInfo info){
	}

	/**
	 * コンボ／リストのリスト[columnListDtl_init_settings_nm]の作成メソッド
	 */
	public MCList getListDtl_init_settings_nm(MCRow row, MCEventInfo info){
		return null;
	}

	/**
	 * コンボ／リストのリスト[columnListDtl_init_focus_nm]の作成メソッド
	 */
	public MCList getListDtl_init_focus_nm(MCRow row, MCEventInfo info){
		return null;
	}

	/**
	 * コンボ／リストのリスト[columnListDtl_init_screen_settings_nm]の作成メソッド
	 */
	public MCList getListDtl_init_screen_settings_nm(MCRow row, MCEventInfo info){
		return null;
	}

	/**
	 * コンボ／リストのリスト[columnInfoDtl_init_list_settings_nm]の作成メソッド
	 */
	public MCList getInfoDtl_init_list_settings_nm(MCRow row, MCEventInfo info){
		return null;
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}