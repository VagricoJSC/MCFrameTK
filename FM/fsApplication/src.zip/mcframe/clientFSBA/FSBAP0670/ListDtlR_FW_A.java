package mcframe.clientFSBA.FSBAP0670;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"ListDtl"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class ListDtlR_FW_A extends MCConstRow {

	/**
	 *  紐付ＮＯ.<p>
	 *
	 */
	public static final String $pno = "pno";
	/**
	 *  バーコード設定ＩＤ.<p>
	 *
	 */
	public static final String $barcode_id = "barcode_id";
	/**
	 *  バーコード設定名.<p>
	 *
	 */
	public static final String $barcode_nm = "barcode_nm";
	/**
	 *  入力値設定ＩＤ.<p>
	 *
	 */
	public static final String $init_settings_id = "init_settings_id";
	/**
	 *  入力値設定名.<p>
	 *
	 */
	public static final String $init_settings_nm = "init_settings_nm";
	/**
	 *  フォーカス設定ＩＤ.<p>
	 *
	 */
	public static final String $init_focus_id = "init_focus_id";
	/**
	 *  フォーカス設定名.<p>
	 *
	 */
	public static final String $init_focus_nm = "init_focus_nm";
	/**
	 *  配置情報設定ＩＤ.<p>
	 *
	 */
	public static final String $init_screen_settings_id = "init_screen_settings_id";
	/**
	 *  配置情報設定名.<p>
	 *
	 */
	public static final String $init_screen_settings_nm = "init_screen_settings_nm";
	/**
	 *  ダイアログ自動クローズ.<p>
	 *
	 */
	public static final String $use_dialog_monitor_flg = "use_dialog_monitor_flg";
	/**
	 *  画面クリア.<p>
	 *
	 */
	public static final String $use_clear_screen_flg = "use_clear_screen_flg";


	public static final MCMeta pno_META = createCommonMeta($pno, mcframe.commonCore.meta.M_META.ROW_ID);
	public static final MCMeta barcode_id_META = createStringMeta($barcode_id);
	public static final MCMeta barcode_nm_META = createStringMeta($barcode_nm);
	public static final MCMeta init_settings_id_META = createStringMeta($init_settings_id);
	public static final MCMeta init_settings_nm_META = createStringMeta($init_settings_nm);
	public static final MCMeta init_focus_id_META = createStringMeta($init_focus_id);
	public static final MCMeta init_focus_nm_META = createStringMeta($init_focus_nm);
	public static final MCMeta init_screen_settings_id_META = createStringMeta($init_screen_settings_id);
	public static final MCMeta init_screen_settings_nm_META = createStringMeta($init_screen_settings_nm);
	public static final MCMeta use_dialog_monitor_flg_META = createCommonMeta($use_dialog_monitor_flg, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta use_clear_screen_flg_META = createCommonMeta($use_clear_screen_flg, mcframe.commonCore.meta.M_META.FLG);

	protected static final ConstMetaList<ListDtlR> constMetas = new ConstMetaList<ListDtlR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			pno_META,
			barcode_id_META,
			barcode_nm_META,
			init_settings_id_META,
			init_settings_nm_META,
			init_focus_id_META,
			init_focus_nm_META,
			init_screen_settings_id_META,
			init_screen_settings_nm_META,
			use_dialog_monitor_flg_META,
			use_clear_screen_flg_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected ListDtlR_FW_A(ConstMetaList<? extends ListDtlR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ListDtlR clone() {
		return (ListDtlR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ListDtlR createInstance() {
		return (ListDtlR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ListDtlR getValues(String... names) {
		return (ListDtlR) super.getValues(names);
	}



	/**
	 *  紐付ＮＯ.<p>
	 *
	 */
	public MCNumber pno() {
		return getConstNumber(offset + 0, $pno);
	}

	/**
	 *  紐付ＮＯ.<p>
	 *
	 */
	public void pno(MCNumber value) {
		setConstNumber(offset + 0, $pno, value);
	}

	/**
	 *  紐付ＮＯ.<p>
	 *
	 */
	public void pno(int value) {
		setConstNumber(offset + 0, $pno, value);
	}

	/**
	 *  紐付ＮＯ.<p>
	 *
	 */
	public void pno(long value) {
		setConstNumber(offset + 0, $pno, value);
	}

	/**
	 *  紐付ＮＯ.<p>
	 *
	 */
	public void pno(float value) {
		setConstNumber(offset + 0, $pno, value);
	}

	/**
	 *  紐付ＮＯ.<p>
	 *
	 */
	public void pno(double value) {
		setConstNumber(offset + 0, $pno, value);
	}


	/**
	 *  バーコード設定ＩＤ.<p>
	 *
	 */
	public String barcode_id() {
		return getConstString(offset + 1, $barcode_id);
	}

	/**
	 *  バーコード設定ＩＤ.<p>
	 *
	 */
	public void barcode_id(String value) {
		setConstString(offset + 1, $barcode_id, value);
	}


	/**
	 *  バーコード設定名.<p>
	 *
	 */
	public String barcode_nm() {
		return getConstString(offset + 2, $barcode_nm);
	}

	/**
	 *  バーコード設定名.<p>
	 *
	 */
	public void barcode_nm(String value) {
		setConstString(offset + 2, $barcode_nm, value);
	}


	/**
	 *  入力値設定ＩＤ.<p>
	 *
	 */
	public String init_settings_id() {
		return getConstString(offset + 3, $init_settings_id);
	}

	/**
	 *  入力値設定ＩＤ.<p>
	 *
	 */
	public void init_settings_id(String value) {
		setConstString(offset + 3, $init_settings_id, value);
	}


	/**
	 *  入力値設定名.<p>
	 *
	 */
	public String init_settings_nm() {
		return getConstString(offset + 4, $init_settings_nm);
	}

	/**
	 *  入力値設定名.<p>
	 *
	 */
	public void init_settings_nm(String value) {
		setConstString(offset + 4, $init_settings_nm, value);
	}


	/**
	 *  フォーカス設定ＩＤ.<p>
	 *
	 */
	public String init_focus_id() {
		return getConstString(offset + 5, $init_focus_id);
	}

	/**
	 *  フォーカス設定ＩＤ.<p>
	 *
	 */
	public void init_focus_id(String value) {
		setConstString(offset + 5, $init_focus_id, value);
	}


	/**
	 *  フォーカス設定名.<p>
	 *
	 */
	public String init_focus_nm() {
		return getConstString(offset + 6, $init_focus_nm);
	}

	/**
	 *  フォーカス設定名.<p>
	 *
	 */
	public void init_focus_nm(String value) {
		setConstString(offset + 6, $init_focus_nm, value);
	}


	/**
	 *  配置情報設定ＩＤ.<p>
	 *
	 */
	public String init_screen_settings_id() {
		return getConstString(offset + 7, $init_screen_settings_id);
	}

	/**
	 *  配置情報設定ＩＤ.<p>
	 *
	 */
	public void init_screen_settings_id(String value) {
		setConstString(offset + 7, $init_screen_settings_id, value);
	}


	/**
	 *  配置情報設定名.<p>
	 *
	 */
	public String init_screen_settings_nm() {
		return getConstString(offset + 8, $init_screen_settings_nm);
	}

	/**
	 *  配置情報設定名.<p>
	 *
	 */
	public void init_screen_settings_nm(String value) {
		setConstString(offset + 8, $init_screen_settings_nm, value);
	}


	/**
	 *  ダイアログ自動クローズ.<p>
	 *
	 */
	public boolean use_dialog_monitor_flg() {
		return getConstBoolean(offset + 9, $use_dialog_monitor_flg);
	}

	/**
	 *  ダイアログ自動クローズ.<p>
	 *
	 */
	public void use_dialog_monitor_flg(boolean value) {
		setConstBoolean(offset + 9, $use_dialog_monitor_flg, value);
	}


	/**
	 *  画面クリア.<p>
	 *
	 */
	public boolean use_clear_screen_flg() {
		return getConstBoolean(offset + 10, $use_clear_screen_flg);
	}

	/**
	 *  画面クリア.<p>
	 *
	 */
	public void use_clear_screen_flg(boolean value) {
		setConstBoolean(offset + 10, $use_clear_screen_flg, value);
	}


	public String getString(String name) {
		if ($barcode_id.equalsIgnoreCase(name)) {
			return barcode_id();
		}
		if ($barcode_nm.equalsIgnoreCase(name)) {
			return barcode_nm();
		}
		if ($init_settings_id.equalsIgnoreCase(name)) {
			return init_settings_id();
		}
		if ($init_settings_nm.equalsIgnoreCase(name)) {
			return init_settings_nm();
		}
		if ($init_focus_id.equalsIgnoreCase(name)) {
			return init_focus_id();
		}
		if ($init_focus_nm.equalsIgnoreCase(name)) {
			return init_focus_nm();
		}
		if ($init_screen_settings_id.equalsIgnoreCase(name)) {
			return init_screen_settings_id();
		}
		if ($init_screen_settings_nm.equalsIgnoreCase(name)) {
			return init_screen_settings_nm();
		}
		return super.getString(name);
	}
	public MCNumber getNumber(String name) {
		if ($pno.equalsIgnoreCase(name)) {
			return pno();
		}
		return super.getNumber(name);
	}
	public boolean getBoolean(String name) {
		if ($use_dialog_monitor_flg.equalsIgnoreCase(name)) {
			return use_dialog_monitor_flg();
		}
		if ($use_clear_screen_flg.equalsIgnoreCase(name)) {
			return use_clear_screen_flg();
		}
		return super.getBoolean(name);
	}

	public String getStringNE(String name) {
		if ($barcode_id.equalsIgnoreCase(name)) {
			return barcode_id();
		}
		if ($barcode_nm.equalsIgnoreCase(name)) {
			return barcode_nm();
		}
		if ($init_settings_id.equalsIgnoreCase(name)) {
			return init_settings_id();
		}
		if ($init_settings_nm.equalsIgnoreCase(name)) {
			return init_settings_nm();
		}
		if ($init_focus_id.equalsIgnoreCase(name)) {
			return init_focus_id();
		}
		if ($init_focus_nm.equalsIgnoreCase(name)) {
			return init_focus_nm();
		}
		if ($init_screen_settings_id.equalsIgnoreCase(name)) {
			return init_screen_settings_id();
		}
		if ($init_screen_settings_nm.equalsIgnoreCase(name)) {
			return init_screen_settings_nm();
		}
		return super.getStringNE(name);
	}
	public MCNumber getNumberNE(String name) {
		if ($pno.equalsIgnoreCase(name)) {
			return pno();
		}
		return super.getNumberNE(name);
	}
	public boolean getBooleanNE(String name) {
		if ($use_dialog_monitor_flg.equalsIgnoreCase(name)) {
			return use_dialog_monitor_flg();
		}
		if ($use_clear_screen_flg.equalsIgnoreCase(name)) {
			return use_clear_screen_flg();
		}
		return super.getBooleanNE(name);
	}

	public void setString(String name, String value) {
		if ($barcode_id.equalsIgnoreCase(name)) {
			barcode_id(value);
			return;
		}
		if ($barcode_nm.equalsIgnoreCase(name)) {
			barcode_nm(value);
			return;
		}
		if ($init_settings_id.equalsIgnoreCase(name)) {
			init_settings_id(value);
			return;
		}
		if ($init_settings_nm.equalsIgnoreCase(name)) {
			init_settings_nm(value);
			return;
		}
		if ($init_focus_id.equalsIgnoreCase(name)) {
			init_focus_id(value);
			return;
		}
		if ($init_focus_nm.equalsIgnoreCase(name)) {
			init_focus_nm(value);
			return;
		}
		if ($init_screen_settings_id.equalsIgnoreCase(name)) {
			init_screen_settings_id(value);
			return;
		}
		if ($init_screen_settings_nm.equalsIgnoreCase(name)) {
			init_screen_settings_nm(value);
			return;
		}
		super.setString(name, value);
	}
	public void setNumber(String name, MCNumber value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, int value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, long value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, float value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, double value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setBoolean(String name, boolean value) {
		if ($use_dialog_monitor_flg.equalsIgnoreCase(name)) {
			use_dialog_monitor_flg(value);
			return;
		}
		if ($use_clear_screen_flg.equalsIgnoreCase(name)) {
			use_clear_screen_flg(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($barcode_id.equalsIgnoreCase(name)) {
			barcode_id(value);
			return;
		}
		if ($barcode_nm.equalsIgnoreCase(name)) {
			barcode_nm(value);
			return;
		}
		if ($init_settings_id.equalsIgnoreCase(name)) {
			init_settings_id(value);
			return;
		}
		if ($init_settings_nm.equalsIgnoreCase(name)) {
			init_settings_nm(value);
			return;
		}
		if ($init_focus_id.equalsIgnoreCase(name)) {
			init_focus_id(value);
			return;
		}
		if ($init_focus_nm.equalsIgnoreCase(name)) {
			init_focus_nm(value);
			return;
		}
		if ($init_screen_settings_id.equalsIgnoreCase(name)) {
			init_screen_settings_id(value);
			return;
		}
		if ($init_screen_settings_nm.equalsIgnoreCase(name)) {
			init_screen_settings_nm(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setNumberNE(String name, MCNumber value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, int value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, long value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, float value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, double value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setBooleanNE(String name, boolean value) {
		if ($use_dialog_monitor_flg.equalsIgnoreCase(name)) {
			use_dialog_monitor_flg(value);
			return;
		}
		if ($use_clear_screen_flg.equalsIgnoreCase(name)) {
			use_clear_screen_flg(value);
			return;
		}
		super.setBooleanNE(name, value);
	}



}

