package mcframe.clientFSBA.FSBAP0760;

import mcframe.commonCore.annotation.EI;

/**
 * [FSBAP_Mining]の入出力情報となる電文（上り・下り電文）と
 * 画面コンテナの間のデータ変換の定義を行うクラスです。
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズはできません。
 */
@EI
public class PDef extends PDef_FW_A {
}