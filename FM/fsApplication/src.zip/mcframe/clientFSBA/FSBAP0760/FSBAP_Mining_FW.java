package mcframe.clientFSBA.FSBAP0760;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;

import mcframe.clientFSBA.FSBAP0780.*;
import mcframe.clientFSUB.FSUBP0090.*;

import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.commonCore.resource.ctrl.MCGroupResource;
import mcframe.clientCore.beans.popup.MCPopupBeans;
import mcframe.clientCore.sys.MCSys;

import mcframe.clientFSUC.FSUCP0000.FSUCP_PopupConfig;
import mcframe.clientFXBA.FXBAP0080.FXBAP_CellConfig;

import javax.swing.ListSelectionModel;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP_Mining"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP_Mining_FW extends FSBAP_Mining_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START
	/**
	 * 追加成功時のモード
	 */
	protected static final String MODE_INS_SUCCESS = "INS_SUCCESS";
	/**
	 * 更新成功時のモード
	 */
	protected static final String MODE_UPD_SUCCESS = "UPD_SUCCESS";

	/**
	 * Setting値：システム共通
	 * Setting_setting_PPanel.Setting_setting_unit_SYS.getActionCommand() と同値
	 */
	protected static final String SETTING_UNIT_SYS = "SYS";
	/**
	 * Setting値：会社共通
	 * Setting_setting_PPanel.Setting_setting_unit_EXT.getActionCommand() と同値
	 */
	protected static final String SETTING_UNIT_EXT = "EXT";
	/**
	 * Setting値：ユーザ
	 * Setting_setting_PPanel.Setting_setting_unit_USER.getActionCommand() と同値
	 */
	protected static final String SETTING_UNIT_USER = "USER";

	/**
	 * Setting切替時の抽出用matcher：システム
	 */
	protected final MCRowMatcher<MiningR> MATCH_SYS = new MCRowMatcher<MiningR>() {
		@Override
		public boolean match(MiningR row) {
			return MCGroupResource.SYSTEM_USER_ID.equals(row.public_lv());
		}
	};
	/**
	 * Setting切替時の抽出用matcher：会社
	 */
	protected final MCRowMatcher<MiningR> MATCH_EXT = new MCRowMatcher<MiningR>() {
		@Override
		public boolean match(MiningR row) {
			return MCGroupResource.EXT_ATTR_USER_ID.equals(row.public_lv());
		}
	};
	/**
	 * Setting切替時の抽出用matcher：ユーザ
	 */
	protected final MCRowMatcher<MiningR> MATCH_USER = new MCRowMatcher<MiningR>() {
		@Override
		public boolean match(MiningR row) {
			String public_lv = row.public_lv();
			return !MCGroupResource.SYSTEM_USER_ID.equals(public_lv)
					&& !MCGroupResource.EXT_ATTR_USER_ID.equals(public_lv);
		}
	};
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_Mining_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_Mining_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * [FS_FSBAL0760_Srch01]の定型処理のInnerClass
	 */
	protected class FS_FSBAL0760_Srch01Caller<P extends FSBAP_Mining, B extends FS_FSBAL0760_Srch01Bridge> extends mcframe.clientFXBA.FXBAP0010.FXBAP_Searcher<P, B> {

		protected FS_FSBAL0760_Srch01Caller(P p, B b) {
			super(p, b);
		}

		@Override
		protected boolean execConfirm() {
			if (!super.execConfirm()) {
				return false;
			}

			// 変更のキャンセル確認
			return confirmCancelEdit(false);
		}

		@Override
		protected void show() {
			super.show();

			// 表示の更新
			updateMiningList();
		}

	}

	/**
	 * [FS_FSBAL0760_Del01]の定型処理のInnerClass
	 */
	protected class FS_FSBAL0760_Del01Caller<P extends FSBAP_Mining, B extends FS_FSBAL0760_Del01Bridge> extends mcframe.clientFXBA.FXBAP0010.FXBAP_CheckedRowDeleter<P, B> {

		protected FS_FSBAL0760_Del01Caller(P p, B b) {
			super(p, b);
		}

		@Override
		protected void show() {
			super.show();

			// 削除したID
			List<String> dellist = new ArrayList<>();

			// 削除データのコンテナを削除
			bridge.up0().forEach(miningR -> {
				dellist.add(miningR.mining_id());
				getMiningL().remove(miningR);
			});

			// 表示の更新
			updateMiningList();

			// メニューガジェット一覧更新（２層用）
			String[] dels = dellist.toArray(new String[dellist.size()]);
			MiningDtl_mining_PPanel.updateMenuGadgetListFor2tier(dels);
		}
	}


	/**
	 * Panel[SrchBtn]のボタン[srch]の押下時の処理
	 */
	@Override
	public void doSrchBtn_srch(MCEventInfo info) {
		callFS_FSBAL0760_Srch01();
	}
	/**
	 * Panel[MiningBtn]のボタン[select_all]の押下時の処理
	 */
	@Override
	public void doMiningBtn_select_all(MCEventInfo info) {
		for (MiningR r : MiningListTable.getViewRows()) {
			setValueEx(columnMiningList_check, r.getGUIIndex(), Boolean.TRUE);
		}
	}
	/**
	 * Panel[MiningBtn]のボタン[deselect_all]の押下時の処理
	 */
	@Override
	public void doMiningBtn_deselect_all(MCEventInfo info) {
		for (MiningR r : MiningListTable.getViewRows()) {
			setValueEx(columnMiningList_check, r.getGUIIndex(), Boolean.FALSE);
		}
	}
	/**
	 * Panel[MiningBtn]のボタン[del]の押下時の処理
	 */
	@Override
	public void doMiningBtn_del(MCEventInfo info) {
		callFS_FSBAL0760_Del01();
	}

	/**
	 * Panel[Btn]のボタン[upd]の押下時の処理
	 */
	@Override
	public void doBtn_upd(MCEventInfo info) {
		if (isNull(MiningDtl_mining_PPanel.getMiningR().mining_id())) {
			// コピー登録
			MiningDtl_mining_PPanel.callIns02();
		}
		else {
			// 更新
			MiningDtl_mining_PPanel.callUpd01();
		}
	}
	/**
	 * Panel[Btn]のボタン[upd_ext]の押下時の処理
	 */
	@Override
	public void doBtn_upd_ext(MCEventInfo info) {
		// 権限評価用
	}
	/**
	 * Panel[Btn]のボタン[upd_sys]の押下時の処理
	 */
	@Override
	public void doBtn_upd_sys(MCEventInfo info) {
		// 権限評価用
	}

	/**
	 * Panel[Btn]のボタン[copy_usr]の押下時の処理
	 */
	@Override
	public void doBtn_copy_usr(MCEventInfo info) {
		copyMiningData(SETTING_UNIT_USER);
	}
	/**
	 * Panel[Btn]のボタン[copy_ext]の押下時の処理
	 */
	@Override
	public void doBtn_copy_ext(MCEventInfo info) {
		copyMiningData(SETTING_UNIT_EXT);
	}
	/**
	 * Panel[Btn]のボタン[copy_sys]の押下時の処理
	 */
	@Override
	public void doBtn_copy_sys(MCEventInfo info) {
		copyMiningData(SETTING_UNIT_SYS);
	}

	/**
	 * 表示中のデータを指定されたセッティングにコピーします。
	 *
	 * @param dest_unit コピー先のセッティング
	 */
	protected void copyMiningData(String dest_unit) {
		// 変更のキャンセル確認
		if (!confirmCancelEdit(false)) {
			return;
		}

		// 選択を解除
		resetSelect();


		// データ抽出用情報
		MCRowMatcher<MiningR> matcher = null;
		String public_lv = null;
		if (dest_unit == null) {
			return;
		}
		else switch (dest_unit) {
		case SETTING_UNIT_SYS:
			matcher = MATCH_SYS;
			public_lv = MCGroupResource.SYSTEM_USER_ID;
			break;
		case SETTING_UNIT_EXT:
			matcher = MATCH_EXT;
			public_lv = MCGroupResource.EXT_ATTR_USER_ID;
			break;
		case SETTING_UNIT_USER:
			matcher = MATCH_USER;
			public_lv = MCSys.user.ID();
			break;
		}
		if (matcher == null) {
			return;
		}


		// 詳細をコピーデータ化
		MiningR miningR = MiningDtl_mining_PPanel.getMiningR();
		// 7012-2756 miyake 会社コード：ログイン中の会社コード
		miningR.co_cd(MCSys.user.coCD());
		// 公開レベル：コピー先
		miningR.public_lv(public_lv);
		if (isSame(public_lv, MCSys.user.ID())) {
			// ガジェットキャッシュデータ利用
			// ユーザにコピーする場合はフラグは常にOFF
			miningR.gadget_cache_flg(false);
			// ユーザの場合、権限文字列は空
			miningR.func_typ(null);
		}
		// マイニングID：クリア
		miningR.mining_id(null);
		MiningDtl_mining_PPanel.getCondL().setString(CondR.$mining_id, null);
		MiningDtl_mining_PPanel.getMethodL().setString(MethodR.$mining_id, null);

		// 一覧に追加
		// 区分変更（イベントなし）
		Setting_setting_PPanel.getSettingR().setting_unit(dest_unit);
		setMiningListL(getMiningL().subList(matcher));
		MiningListTable.sort();
		// 名称（重複回避）
		String mining_nm = miningR.mining_nm();
		for (int i = 2; getMiningListL().getFirst(MiningR.$mining_nm, mining_nm) != null; i++) {
			mining_nm = String.format("%1$s (%2$d)", miningR.mining_nm(), i);
		}
		miningR.mining_nm(mining_nm);
		// 追加
		MiningR copyR = miningR.clone();
		getMiningListL().add(copyR);
		MiningListTable.selectRow(getMiningListL().size() - 1);
		MiningListTable.adjustWidth();

		// 詳細のステータス：新規作成
		MiningDtl_mining_PPanel.setAllRowStatus(Status.CREATE);

		// COPYステータス
		setStatus(COPY);
	}

	/**
	 * 追加したマイニング情報を確定します。
	 *
	 */
	protected void commitInsertMiningData() {
		commitUpdateMiningData();

		// 一覧のキャッシュに追加
		MiningR listR = MiningListTable.getSelectedMCRow();
		getMiningL().add(listR);
	}

	/**
	 * 更新したマイニング情報を確定します。
	 *
	 */
	protected void commitUpdateMiningData() {
		// 登録したマイニング情報を一覧に反映
		MiningR insR = MiningDtl_mining_PPanel.getMiningR();
		MiningR listR = MiningListTable.getSelectedMCRow();
		MCRow.copyvalue(listR, insR);
		MiningListTable.sort();
	}

	/**
	 * 変更を破棄するか変更がない場合は true を返します。
	 *
	 * <p>
	 * 変更がある場合は確認ダイアログを表示します。
	 *
	 * @param dtl 詳細のみチェックする場合は true
	 * @return 破棄しない場合は false
	 */
	protected boolean confirmCancelEdit(boolean dtl) {
		// FSBAP0030参考
		if ((dtl) ? MiningDtl_mining_PPanel.isChanged() : isChanged()) {
			if (confirm(FSBAC0059) != MCMessageBox.YES_OPTION) {
				return false;
			}
		}
		return true;
	}

	/**
	 * マイニング一覧を選択されている区分で更新します。
	 *
	 * 一覧に行がある場合、先頭行が選択されます。
	 * 
	 */
	protected void updateMiningList() {
		// 選択を解除
		resetSelect();

		// 区分のデータを抽出
		MCRowMatcher<MiningR> matcher = null;
		switch (Setting_setting_PPanel.getSettingR().setting_unit()) {
		case SETTING_UNIT_SYS:
			matcher = MATCH_SYS;
			break;
		case SETTING_UNIT_EXT:
			matcher = MATCH_EXT;
			break;
		case SETTING_UNIT_USER:
			matcher = MATCH_USER;
			break;
		default:
			matcher = null;
			break;
		}
		if (matcher == null) {
			getMiningListL().clear();
		}
		else {
			setMiningListL(getMiningL().subList(matcher));
		}
		MiningListTable.sort();
		MiningListTable.adjustWidth();

		if (getMiningListL().size() > 0) {
			// 選択イベントで編集枠の検索を行う
			MiningListTable.selectRow(0);
			// 編集枠の検索時に画面ステータスが変更される
		}
		else {
			// データなし
			MiningDtl_mining_PPanel.screenClearBody();
			setStatus(INIT);
		}
	}

	/**
	 * 一覧の選択を全解除します。
	 *
	 */
	protected void resetSelect() {
		getMiningL().setBoolean(MiningR.$check, false);
		getMiningL().setStatus(Status.NONE);
	}

	@Override
	public boolean doMiningList_VC(MCEventInfo info) {
		if (!super.doMiningList_VC(info)) {
			return false;
		}
		if (info.getOldIndex() < 0) {
			// 初期表示時
			return true;
		}
		// 変更のキャンセル確認
		return confirmCancelEdit(true);
	}

	@Override
	public void doMiningList_NC(MCEventInfo info) {
		MiningR miningR = MiningListTable.getSelectedMCRow();

		int old = info.getOldIndex();
		if (0 <= old && old < getMiningListL().size()) {
			// 直前の選択行がコピー行の場合削除
			if (isNull(getMiningListL().get(old).mining_id())) {
				getMiningListL().remove(old);
			}
		}

		// マイニングIDで詳細を検索
		if (!isNull(miningR.mining_id())) {
			SrchR condR = SrchR.create();
			condR.mining_id(miningR.mining_id());
			condR.user_id(getSrchCondR().user_id());
			condR.acl_co(getSrchCondR().acl_co());
			condR.acl_sys(getSrchCondR().acl_sys());
			MiningDtl_mining_PPanel.callSrch01(condR);
		}
	}

	@Override
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		
		if (vc == Setting_setting_PPanel.Setting_setting_unit_Group) {
			return doSetting_setting_unit_VC(info);
		}
		return true;
	}

	/**
	 * [Setting]パネルの[setting]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return 
	 */
	protected boolean doSetting_setting_unit_VC(MCEventInfo info) {
		// 変更のキャンセル確認
		return confirmCancelEdit(false);
	}

	@Override
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);

		if (nc == Setting_setting_PPanel.Setting_setting_unit_Group) {
			doSetting_setting_unit_NC(info);
		}
	}

	/**
	 * [Setting]パネルの[setting]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	protected void doSetting_setting_unit_NC(MCEventInfo info){
		// 表示の更新
		updateMiningList();
	}

	@Override
	public void setStatus(String status) {
		// 追加・更新関連の処理
		if (MODE_INS_SUCCESS.equals(status)) {
			commitInsertMiningData();
			status = EDIT;
		}
		if (MODE_UPD_SUCCESS.equals(status)) {
			commitUpdateMiningData();
			status = EDIT;
		}

		super.setStatus(status);

		// 現在の設定単位
		String unit = Setting_setting_PPanel.getSettingR().setting_unit();

		switch (status) {
		case INIT:
		case COPY:
			break;
		case READ_ONLY:
		case EDIT:
		default:
			// 区分による制御
			String dtl_status = null;
			boolean sys = Btn_upd_sys.authorize();
			boolean ext = Btn_upd_ext.authorize();
			switch (unit) {
			case SETTING_UNIT_SYS:
				MiningBtn_del.setMode(sys ? MCMode.ENABLE : MCMode.DISABLE);
				Btn_upd.setMode(sys ? MCMode.ENABLE : MCMode.DISABLE);
				Btn_copy_sys.setMode(sys ? MCMode.ENABLE : MCMode.INVISIBLE);// システム管理者はコピー可能
				Btn_copy_ext.setMode(ext ? MCMode.ENABLE : MCMode.INVISIBLE);// 会社管理者はシステムからコピー可能
				Btn_copy_usr.setMode(MCMode.ENABLE);// ユーザにはコピー可能
				dtl_status = sys ? MiningDtl_mining_PPanel.ENABLE : MiningDtl_mining_PPanel.READ_ONLY;
				break;
			case SETTING_UNIT_EXT:
				MiningBtn_del.setMode(ext ? MCMode.ENABLE : MCMode.DISABLE);
				Btn_upd.setMode(ext ? MCMode.ENABLE : MCMode.DISABLE);
				Btn_copy_sys.setMode(ext ? MCMode.ENABLE : MCMode.INVISIBLE);// 会社管理者はシステムにコピー可能
				Btn_copy_ext.setMode(ext ? MCMode.ENABLE : MCMode.INVISIBLE);// 会社管理者はコピー可能
				Btn_copy_usr.setMode(MCMode.ENABLE);// ユーザにはコピー可能
				dtl_status = ext ? MiningDtl_mining_PPanel.ENABLE : MiningDtl_mining_PPanel.READ_ONLY;
				break;
			case SETTING_UNIT_USER:
			default:
				MiningBtn_del.setMode(MCMode.ENABLE);
				Btn_upd.setMode(MCMode.ENABLE);
				Btn_copy_sys.setMode(MCMode.INVISIBLE);// ユーザはシステムに直接コピーできない
				Btn_copy_ext.setMode(MCMode.ENABLE);// ユーザは自社にコピー可能
				Btn_copy_usr.setMode(MCMode.ENABLE);// ユーザにはコピー可能
				dtl_status = MiningDtl_mining_PPanel.ENABLE;
				break;
			}

			// 詳細の制御
			if (READ_ONLY.equals(status)) {
				MiningDtl_mining_PPanel.setStatus(MiningDtl_mining_PPanel.READ_ONLY);
			}
			else {
				MiningDtl_mining_PPanel.setStatus(dtl_status);
			}
			break;
		}
		if (isSame(unit, SETTING_UNIT_USER)) {
			// ユーザは権限文字列を設定できない
			MiningDtl_mining_PPanel.Mining_function.setMode(MCMode.DISABLE);
			MiningDtl_mining_PPanel.Mining_func_typ.setMode(MCMode.DISABLE);
		}
	}

	@Override
	protected void partsInit() {
		// 通信後の画面モード
		MiningDtl_mining_PPanel.setModeForFS_FSBAL0760_Srch01(EDIT);
		MiningDtl_mining_PPanel.setModeNoDataForFS_FSBAL0760_Srch01(READ_ONLY);
		MiningDtl_mining_PPanel.setModeForFS_FSBAL0760_Upd01(MODE_UPD_SUCCESS);
		MiningDtl_mining_PPanel.setModeForFS_FSBAL0760_Ins02(MODE_INS_SUCCESS);
	}

	@Override
	protected void listenerInit() {
		super.listenerInit();

		Setting_setting_PPanel.Setting_setting_unit_Group.addVCListener(this);
		Setting_setting_PPanel.Setting_setting_unit_Group.addNCListener(this);
	}

	@Override
	protected void tableInit() {
		super.tableInit();
		// 単一行選択
		MiningListTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		// 詳細部品
		// 単一行選択
		MiningDtl_mining_PPanel.CondTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		MiningDtl_mining_PPanel.MethodTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		// ソート不可
		MiningDtl_mining_PPanel.CondTable.setSortable(false);
		MiningDtl_mining_PPanel.MethodTable.setSortable(false);
	}

	@Override
	protected void setSortColumn() {
		super.setSortColumn();

		MiningListTable.addSortColumn(columnMiningList_mining_nm, MCList.SortType.ASC);

		// CondTableとMethodTableはlist_orderでソート（サーバでソート済み）
	}

	@Override
	protected String getPopupPattern(MCPopupBeans compo) {
		if (compo == MiningListTable) {
			return FSUCP_PopupConfig.MENU_PANEL;
		}
		return FSUCP_PopupConfig.REMOVE_ALL;
	}

	@Override
	protected void valueInit() {
		super.valueInit();

		// 一覧の検索条件
		// マイニングIDは未設定
		getSrchCondR().user_id(MCSys.user.ID());
		getSrchCondR().acl_co(!Btn_upd_ext.authorize());
		getSrchCondR().acl_sys(!Btn_upd_sys.authorize());

		// カラム幅調整
		MiningListTable.adjustWidth();
		MiningDtl_mining_PPanel.CondTable.adjustWidth();
		MiningDtl_mining_PPanel.MethodTable.adjustWidth();
	}


	@Override
	protected void setCellConfig() {
		super.setCellConfig();

		MiningListTable.setCellConfig(createMiningCellConfig());
	}

	/**
	 * マイニング一覧テーブルに設定するセルコンフィグを作成します。
	 *
	 * @return マイニング一覧テーブルに設定するセルコンフィグ
	 */
	protected FXBAP_CellConfig createMiningCellConfig() {
		return new FSBAP_Mining_CellConfig();
	}

	/**
	 * マイニング一覧のカラムコンフィグです。
	 *
	 */
	public class FSBAP_Mining_CellConfig extends FXBAP_CellConfig {

		@Override
		public MCMode getPriorMode(int index, MCColumnConfig column,
				MCTable table) {

			MiningR o = getMiningListL().get(index);

			if (column == columnMiningList_check) {
				if (isNull(o.mining_id())) {
					// 新規追加 or コピー時
					return MCMode.DISABLE;
				}
			}

			return super.getPriorMode(index, column, table);
		}
	}

}