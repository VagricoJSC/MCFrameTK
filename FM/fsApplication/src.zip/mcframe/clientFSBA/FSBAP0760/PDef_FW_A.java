package mcframe.clientFSBA.FSBAP0760;

import mcframe.commonCore.param.MCOperationInfo;
import mcframe.commonCore.param.MCContainerDef;
import mcframe.commonCore.param.MCGeneralContainerDef;
import mcframe.commonCore.param.MCBlockDef;
import mcframe.commonCore.param.MCItemDef;
import mcframe.commonCore.param.MCDef;

/**
 * [FSBAP_Mining]の入出力情報となる電文（上り・下り電文）と
 * 画面コンテナの間のデータ変換の定義を行うクラスです。
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズはできません。
 */
@SuppressWarnings({"all"})
abstract public class PDef_FW_A extends MCDef {
	public MCContainerDef getCustomDef(String id){
		if (id == null) {
			return null;
		} 
//FMCB GET_DEF START
		else if (id.equals("FS.FSBAL0760.Srch01.UP.BLOCK0")){
			return FS_FSBAL0760_Srch01_UP_BLOCK0();
		}
		else if (id.equals("FS.FSBAL0760.Srch01.DOWN.BLOCK0")){
			return FS_FSBAL0760_Srch01_DOWN_BLOCK0();
		}
		else if (id.equals("FS.FSBAL0760.Srch01.DOWN.BLOCK1")){
			return FS_FSBAL0760_Srch01_DOWN_BLOCK1();
		}
		else if (id.equals("FS.FSBAL0760.Srch01.DOWN.BLOCK2")){
			return FS_FSBAL0760_Srch01_DOWN_BLOCK2();
		}
		else if (id.equals("FS.FSBAL0760.Srch01.DOWN.BLOCK3")){
			return FS_FSBAL0760_Srch01_DOWN_BLOCK3();
		}
		else if (id.equals("FS.FSBAL0760.Del01.UP.BLOCK0")){
			return FS_FSBAL0760_Del01_UP_BLOCK0();
		}
//FMCB GET_DEF END
		else {
			return null;
		}
	}
	//FMCB DEF_CLASSES START
		
	
	static final MCOperationInfo FS_FSBAL0760_Srch01_INFO = new MCOperationInfo("FS", "FSBAL0760", "Srch01", "000001", new PDef());

	public static MCContainerDef FS_FSBAL0760_Srch01_UP_BLOCK0() {
		/** Ope.のBlock [SrchCond] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0760", "Srch01",
			new MCItemDef[]{
				MCItemDef.create("mining_id", "mining_id"),
				MCItemDef.create("user_id", "user_id"),
				MCItemDef.create("acl_co", "acl_co"),
				MCItemDef.create("acl_sys", "acl_sys")
			}
			,
			MCBlockDef.create("SrchCond")
		);
	}


	public static MCContainerDef FS_FSBAL0760_Srch01_DOWN_BLOCK0() {
	/** Ope.のBlock [Mining] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0760", "Srch01",
			new MCItemDef[]{
				MCItemDef.create("mining_id", "mining_id"),
				MCItemDef.create("mining_nm", "mining_nm"),
				MCItemDef.create("user_id", "user_id"),
				MCItemDef.create("co_cd", "co_cd"),
				MCItemDef.create("public_lv", "public_lv"),
				MCItemDef.create("description_text", "description_text"),
				MCItemDef.create("module_id", "module_id"),
				MCItemDef.create("logic_id", "logic_id"),
				MCItemDef.create("operation_id", "operation_id"),
				MCItemDef.create("func_typ", "func_typ"),
				MCItemDef.create("scr_module_id", "scr_module_id"),
				MCItemDef.create("screen_id", "screen_id"),
				MCItemDef.create("gadget_size", "gadget_size"),
				MCItemDef.create("gadget_icon", "gadget_icon"),
				MCItemDef.create("gadget_cache_flg", "gadget_cache_flg"),
				MCItemDef.create("md_module_id", "md_module_id"),
				MCItemDef.create("md_screen_id", "md_screen_id"),
				MCItemDef.create("md_gadget_size", "md_gadget_size"),
				MCItemDef.create("upd_cntr", "upd_cntr")
			}
			,
			MCBlockDef.create("Mining")
		);
	}
	public static MCContainerDef FS_FSBAL0760_Srch01_DOWN_BLOCK1() {
	/** Ope.のBlock [Cond] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0760", "Srch01",
			new MCItemDef[]{
				MCItemDef.IGNORE_ITEM("mining_id"),
				MCItemDef.IGNORE_ITEM("col_id"),
				MCItemDef.IGNORE_ITEM("col_nm"),
				MCItemDef.IGNORE_ITEM("list_order"),
				MCItemDef.IGNORE_ITEM("scr_itm_id"),
				MCItemDef.IGNORE_ITEM("md_itm_id"),
				MCItemDef.IGNORE_ITEM("data_typ"),
				MCItemDef.IGNORE_ITEM("require_flg"),
				MCItemDef.IGNORE_ITEM("init_val"),
				MCItemDef.IGNORE_ITEM("editable_flg")
			}
			,
			MCBlockDef.create("CondParam")
		);
	}
	public static MCContainerDef FS_FSBAL0760_Srch01_DOWN_BLOCK2() {
	/** Ope.のBlock [Method] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0760", "Srch01",
			new MCItemDef[]{
				MCItemDef.IGNORE_ITEM("mining_id"),
				MCItemDef.IGNORE_ITEM("col_id"),
				MCItemDef.IGNORE_ITEM("col_nm"),
				MCItemDef.IGNORE_ITEM("list_order"),
				MCItemDef.IGNORE_ITEM("sum_info_typ"),
				MCItemDef.IGNORE_ITEM("sumcond"),
				MCItemDef.IGNORE_ITEM("rank_flg"),
				MCItemDef.IGNORE_ITEM("rank_typ"),
				MCItemDef.IGNORE_ITEM("rank_size"),
				MCItemDef.IGNORE_ITEM("date_fmt"),
				MCItemDef.IGNORE_ITEM("fill_dt_flg"),
				MCItemDef.IGNORE_ITEM("fill_dt_fm"),
				MCItemDef.IGNORE_ITEM("fill_dt_to"),
				MCItemDef.IGNORE_ITEM("formula"),
				MCItemDef.IGNORE_ITEM("dec_place"),
				MCItemDef.IGNORE_ITEM("round_mode_typ"),
				MCItemDef.IGNORE_ITEM("null_zero"),
				MCItemDef.IGNORE_ITEM("sort_order"),
				MCItemDef.IGNORE_ITEM("sort_typ"),
				MCItemDef.IGNORE_ITEM("graph_typ"),
				MCItemDef.IGNORE_ITEM("graph_label_flg"),
				MCItemDef.IGNORE_ITEM("graph_color"),
				MCItemDef.IGNORE_ITEM("inv_flg")
			}
			,
			MCBlockDef.create("MethodParam")
		);
	}
	public static MCContainerDef FS_FSBAL0760_Srch01_DOWN_BLOCK3() {
	/** Ope.のBlock [SumCond] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0760", "Srch01",
			new MCItemDef[]{
				MCItemDef.IGNORE_ITEM("mining_id"),
				MCItemDef.IGNORE_ITEM("sumcond"),
				MCItemDef.IGNORE_ITEM("list_order"),
				MCItemDef.IGNORE_ITEM("col_id"),
				MCItemDef.IGNORE_ITEM("data_typ"),
				MCItemDef.IGNORE_ITEM("cond_val"),
				MCItemDef.IGNORE_ITEM("relative_ope"),
				MCItemDef.IGNORE_ITEM("logic_ope"),
				MCItemDef.IGNORE_ITEM("inv_flg")
			}
			,
			MCBlockDef.create("SumCondParam")
		);
	}
	
	static final MCOperationInfo FS_FSBAL0760_Del01_INFO = new MCOperationInfo("FS", "FSBAL0760", "Del01", "000001", new PDef());

	public static MCContainerDef FS_FSBAL0760_Del01_UP_BLOCK0() {
		/** Ope.のBlock [SrchCond] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0760", "Del01",
			new MCItemDef[]{
				MCItemDef.create("mining_id", "mining_id")
			}
			,
			MCBlockDef.create("MiningList")
		);
	}


	//FMCB DEF_CLASSES END
}

