package mcframe.clientFSBA.FSBAP0760;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;
import mcframe.clientFSBA.FSBAP0760.FSBAP_Mining_FW.FS_FSBAL0760_Srch01Caller;
import mcframe.clientFSBA.FSBAP0760.FSBAP_Mining_FW.FS_FSBAL0760_Del01Caller;

/**
 * 画面"FSBAP_Mining"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP_Mining_FW_A extends mcframe.clientFSUC.FSUCP0000.FSUCP_PanelBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0760";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Srch]ブロック関連のField定義
	public MCPanel SrchPanel = null;
	public MCTitledBorder SrchTitledBorder = null;
	// [Srch]ブロックの項目のField定義
	// [Setting]ブロック関連のField定義
	public MCPanel SettingPanel = null;
	// [Setting]ブロックの項目のField定義
	public mcframe.clientFSUB.FSUBP0090.FSUBP_SettingUnit_H Setting_setting_PPanel;
	// [SrchBtn]ブロック関連のField定義
	public MCPanel SrchBtnPanel = null;
	// [SrchBtn]ブロックの項目のField定義
	/**
	 *  検索する.<p>
	 *
	 */
	public MCButton SrchBtn_srch = null;
	// [Dtl]ブロック関連のField定義
	public MCPanel DtlPanel = null;
	// [Dtl]ブロックの項目のField定義
	// [MiningList]ブロック関連のField定義
	public MCPanel MiningListPanel = null;
	public MCScrollPane MiningListScrollPane = null;
	public MCTable2<mcframe.clientFSBA.FSBAP0780.MiningR> MiningListTable = null;
	// [MiningList]ブロックの項目のField定義
	/**
	 *  選択.<p>
	 *
	 */
	public MCColumnConfig columnMiningList_check = null;
	/**
	 *  マイニング名.<p>
	 *
	 */
	public MCColumnConfig columnMiningList_mining_nm = null;
	// [MiningBtn]ブロック関連のField定義
	public MCPanel MiningBtnPanel = null;
	// [MiningBtn]ブロックの項目のField定義
	/**
	 *  全選択.<p>
	 *
	 */
	public MCButton MiningBtn_select_all = null;
	/**
	 *  全解除.<p>
	 *
	 */
	public MCButton MiningBtn_deselect_all = null;
	/**
	 *  削除する.<p>
	 *
	 */
	public MCButton MiningBtn_del = null;
	// [MiningDtl]ブロック関連のField定義
	public MCPanel MiningDtlPanel = null;
	// [MiningDtl]ブロックの項目のField定義
	public mcframe.clientFSBA.FSBAP0780.FSBAP_MiningDtl MiningDtl_mining_PPanel;
	// [Btn]ブロック関連のField定義
	public MCPanel BtnPanel = null;
	// [Btn]ブロックの項目のField定義
	/**
	 *  更新する.<p>
	 *
	 */
	public MCButton Btn_upd = null;
	/**
	 *  会社共通更新権限.<p>
	 *
	 */
	public MCButton Btn_upd_ext = null;
	/**
	 *  システム共通更新権限.<p>
	 *
	 */
	public MCButton Btn_upd_sys = null;
	/**
	 *  ユーザにコピーする.<p>
	 *
	 */
	public MCButton Btn_copy_usr = null;
	/**
	 *  会社共通にコピーする.<p>
	 *
	 */
	public MCButton Btn_copy_ext = null;
	/**
	 *  システム共通にコピーする.<p>
	 *
	 */
	public MCButton Btn_copy_sys = null;
	/** [INIT]モードを表す定数 */
	public static final String INIT = "INIT";
	/** [EDIT]モードを表す定数 */
	public static final String EDIT = "EDIT";
	/** [COPY]モードを表す定数 */
	public static final String COPY = "COPY";
	/** [READ_ONLY]モードを表す定数 */
	public static final String READ_ONLY = "READ_ONLY";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{INIT, EDIT, COPY, READ_ONLY};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	
	/** [FS_FSBAL0760_Srch01]のCallerの作成 */
	protected FSBAP_Mining_FW.FS_FSBAL0760_Srch01Caller createFS_FSBAL0760_Srch01() {
		FSBAP_Mining_FW.FS_FSBAL0760_Srch01Caller<FSBAP_Mining, FS_FSBAL0760_Srch01Bridge>
		caller = ((FSBAP_Mining_FW)this).new FS_FSBAL0760_Srch01Caller<FSBAP_Mining, FS_FSBAL0760_Srch01Bridge>(
					(FSBAP_Mining)this, new FS_FSBAL0760_Srch01Bridge());
		return caller;
	}
	/** [FS_FSBAL0760_Srch01]の呼び出し */
	protected void callFS_FSBAL0760_Srch01() {
		MCCaller caller = createFS_FSBAL0760_Srch01();
		caller.exec();
	}
	/** [FS_FSBAL0760_Del01]のCallerの作成 */
	protected FSBAP_Mining_FW.FS_FSBAL0760_Del01Caller createFS_FSBAL0760_Del01() {
		FSBAP_Mining_FW.FS_FSBAL0760_Del01Caller<FSBAP_Mining, FS_FSBAL0760_Del01Bridge>
		caller = ((FSBAP_Mining_FW)this).new FS_FSBAL0760_Del01Caller<FSBAP_Mining, FS_FSBAL0760_Del01Bridge>(
					(FSBAP_Mining)this, new FS_FSBAL0760_Del01Bridge());
		return caller;
	}
	/** [FS_FSBAL0760_Del01]の呼び出し */
	protected void callFS_FSBAL0760_Del01() {
		MCCaller caller = createFS_FSBAL0760_Del01();
		caller.exec();
	}
	/** [SrchCond]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0760.SrchCondR aSrchCondR;
	/** [MiningList]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0780.MiningR> aMiningListL;
	/** [Mining]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0780.MiningR> aMiningL;
	/** [CondParam]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0780.CondR> aCondParamL;
	/** [MethodParam]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0780.MethodR> aMethodParamL;
	/** [SumCondParam]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0780.SumCondParamR> aSumCondParamL;

	/**
	 * 項目コピーによってaSrchCondRを設定します。
	 *
	 * aSrchCondRのインスタンスは変更されません。
	 *
	 * @param row SrchCondR
	 */
	public void setSrchCondR(mcframe.clientFSBA.FSBAP0760.SrchCondR row) {
		if (row != null) {
			MCRow.copyall(getSrchCondR(), row);
		}
	}

	/**
	 * [SrchCond]ブロックのコンテナaSrchCondRを返します。
	 *
	 * @return SrchCondR
	 */
	public mcframe.clientFSBA.FSBAP0760.SrchCondR getSrchCondR() {
		return aSrchCondR;
	}

	/**
	 * aSrchCondRを作成します。
	 *
	 * @return SrchCondR
	 */
	public mcframe.clientFSBA.FSBAP0760.SrchCondR createSrchCondR() {
		return mcframe.clientFSBA.FSBAP0760.SrchCondR.create();
	}

	/**
	 * コピーによってaMiningListLを設定します。
	 *
	 * aMiningListLのインスタンスは変更されません。
	 *
	 * @param dataset MiningListL
	 */
	public void setMiningListL(MCList<mcframe.clientFSBA.FSBAP0780.MiningR> aList) {
		if (getMiningListL() != aList) {
			getMiningListL().setAll(aList);
		}
	}

	/**
	 * [MiningList]ブロックのコンテナaMiningListLを返します。
	 *
	 * @return MiningListL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0780.MiningR> getMiningListL() {
		return aMiningListL;
	}

	/**
	 * aMiningListRを作成します。
	 *
	 * @return MiningListR
	 */
	public mcframe.clientFSBA.FSBAP0780.MiningR createMiningListR() {
		return mcframe.clientFSBA.FSBAP0780.MiningR.create();
	}

	/**
	 * aMiningListLを作成します。
	 *
	 * @return MiningListL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0780.MiningR> createMiningListL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0780.MiningR.class);
	}

	/**
	 * MiningListTableを初期化します。
	 */
	protected void createMiningListTable(){
		if(MiningListTable == null){
			MiningListTable = beansFactory.createTable2("MiningList.table");
		}
	}

	/**
	 * コピーによってaMiningLを設定します。
	 *
	 * aMiningLのインスタンスは変更されません。
	 *
	 * @param dataset MiningL
	 */
	public void setMiningL(MCList<mcframe.clientFSBA.FSBAP0780.MiningR> aList) {
		if (getMiningL() != aList) {
			getMiningL().setAll(aList);
		}
	}

	/**
	 * [Mining]ブロックのコンテナaMiningLを返します。
	 *
	 * @return MiningL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0780.MiningR> getMiningL() {
		return aMiningL;
	}

	/**
	 * aMiningRを作成します。
	 *
	 * @return MiningR
	 */
	public mcframe.clientFSBA.FSBAP0780.MiningR createMiningR() {
		return mcframe.clientFSBA.FSBAP0780.MiningR.create();
	}

	/**
	 * aMiningLを作成します。
	 *
	 * @return MiningL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0780.MiningR> createMiningL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0780.MiningR.class);
	}

	/**
	 * コピーによってaCondParamLを設定します。
	 *
	 * aCondParamLのインスタンスは変更されません。
	 *
	 * @param dataset CondParamL
	 */
	public void setCondParamL(MCList<mcframe.clientFSBA.FSBAP0780.CondR> aList) {
		if (getCondParamL() != aList) {
			getCondParamL().setAll(aList);
		}
	}

	/**
	 * [CondParam]ブロックのコンテナaCondParamLを返します。
	 *
	 * @return CondParamL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0780.CondR> getCondParamL() {
		return aCondParamL;
	}

	/**
	 * aCondParamRを作成します。
	 *
	 * @return CondParamR
	 */
	public mcframe.clientFSBA.FSBAP0780.CondR createCondParamR() {
		return mcframe.clientFSBA.FSBAP0780.CondR.create();
	}

	/**
	 * aCondParamLを作成します。
	 *
	 * @return CondParamL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0780.CondR> createCondParamL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0780.CondR.class);
	}

	/**
	 * コピーによってaMethodParamLを設定します。
	 *
	 * aMethodParamLのインスタンスは変更されません。
	 *
	 * @param dataset MethodParamL
	 */
	public void setMethodParamL(MCList<mcframe.clientFSBA.FSBAP0780.MethodR> aList) {
		if (getMethodParamL() != aList) {
			getMethodParamL().setAll(aList);
		}
	}

	/**
	 * [MethodParam]ブロックのコンテナaMethodParamLを返します。
	 *
	 * @return MethodParamL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0780.MethodR> getMethodParamL() {
		return aMethodParamL;
	}

	/**
	 * aMethodParamRを作成します。
	 *
	 * @return MethodParamR
	 */
	public mcframe.clientFSBA.FSBAP0780.MethodR createMethodParamR() {
		return mcframe.clientFSBA.FSBAP0780.MethodR.create();
	}

	/**
	 * aMethodParamLを作成します。
	 *
	 * @return MethodParamL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0780.MethodR> createMethodParamL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0780.MethodR.class);
	}

	/**
	 * コピーによってaSumCondParamLを設定します。
	 *
	 * aSumCondParamLのインスタンスは変更されません。
	 *
	 * @param dataset SumCondParamL
	 */
	public void setSumCondParamL(MCList<mcframe.clientFSBA.FSBAP0780.SumCondParamR> aList) {
		if (getSumCondParamL() != aList) {
			getSumCondParamL().setAll(aList);
		}
	}

	/**
	 * [SumCondParam]ブロックのコンテナaSumCondParamLを返します。
	 *
	 * @return SumCondParamL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0780.SumCondParamR> getSumCondParamL() {
		return aSumCondParamL;
	}

	/**
	 * aSumCondParamRを作成します。
	 *
	 * @return SumCondParamR
	 */
	public mcframe.clientFSBA.FSBAP0780.SumCondParamR createSumCondParamR() {
		return mcframe.clientFSBA.FSBAP0780.SumCondParamR.create();
	}

	/**
	 * aSumCondParamLを作成します。
	 *
	 * @return SumCondParamL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0780.SumCondParamR> createSumCondParamL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0780.SumCondParamR.class);
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getSrchCondR())) ret.add(getSrchCondR());
		if(!MCCollectionUtil.contains(ret, getMiningListL())) ret.add(getMiningListL());
		if(!MCCollectionUtil.contains(ret, getMiningL())) ret.add(getMiningL());
		if(!MCCollectionUtil.contains(ret, getCondParamL())) ret.add(getCondParamL());
		if(!MCCollectionUtil.contains(ret, getMethodParamL())) ret.add(getMethodParamL());
		if(!MCCollectionUtil.contains(ret, getSumCondParamL())) ret.add(getSumCondParamL());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getSrchCondR()) return "SrchCond";
		if(aCnt == getMiningListL()) return "MiningList";
		if(aCnt == getMiningL()) return "Mining";
		if(aCnt == getCondParamL()) return "CondParam";
		if(aCnt == getMethodParamL()) return "MethodParam";
		if(aCnt == getSumCondParamL()) return "SumCondParam";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("SrchCond")) return getSrchCondR();
		if(bId.equals("MiningList")) return getMiningListL();
		if(bId.equals("Mining")) return getMiningL();
		if(bId.equals("CondParam")) return getCondParamL();
		if(bId.equals("MethodParam")) return getMethodParamL();
		if(bId.equals("SumCondParam")) return getSumCondParamL();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(SrchPanel);
		ret.add(SettingPanel);
		ret.add(SrchBtnPanel);
		ret.add(DtlPanel);
		ret.add(MiningListPanel);
		ret.add(MiningBtnPanel);
		ret.add(MiningDtlPanel);
		ret.add(BtnPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_Mining_FW_A() {
		aSrchCondR = createSrchCondR();
		aMiningListL = createMiningListL();
		aMiningL = createMiningL();
		aCondParamL = createCondParamL();
		aMethodParamL = createMethodParamL();
		aSumCondParamL = createSumCondParamL();

	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_Mining_FW_A(String name) {
		aSrchCondR = createSrchCondR();
		aMiningListL = createMiningListL();
		createMiningListTable();
		MiningListTable.setRowName(name);
		aMiningL = createMiningL();
		aCondParamL = createCondParamL();
		aMethodParamL = createMethodParamL();
		aSumCondParamL = createSumCondParamL();
	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP_Mining_FW.jbCreateSrch((FSBAP_Mining)this);
		FSBAP_Mining_FW.jbCreateSetting((FSBAP_Mining)this);
		FSBAP_Mining_FW.jbCreateSrchBtn((FSBAP_Mining)this);
		FSBAP_Mining_FW.jbCreateDtl((FSBAP_Mining)this);
		FSBAP_Mining_FW.jbCreateMiningList((FSBAP_Mining)this);
		FSBAP_Mining_FW.jbCreateMiningBtn((FSBAP_Mining)this);
		FSBAP_Mining_FW.jbCreateMiningDtl((FSBAP_Mining)this);
		FSBAP_Mining_FW.jbCreateBtn((FSBAP_Mining)this);
	}

	/**
	 * [Srch]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateSrch(FSBAP_Mining p) {
	}

	/**
	 * [Setting]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateSetting(FSBAP_Mining p) {
		p.Setting_setting_PPanel = mcframe.clientFSUB.FSUBP0090.FSUBP_SettingUnit_H.create();
		p.Setting_setting_PPanel.setName("Setting.setting");
	}

	/**
	 * [SrchBtn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateSrchBtn(FSBAP_Mining p) {
	}

	/**
	 * [Dtl]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateDtl(FSBAP_Mining p) {
	}

	/**
	 * [MiningList]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateMiningList(FSBAP_Mining p) {
	}

	/**
	 * [MiningBtn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateMiningBtn(FSBAP_Mining p) {
	}

	/**
	 * [MiningDtl]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateMiningDtl(FSBAP_Mining p) {
		p.MiningDtl_mining_PPanel = mcframe.clientFSBA.FSBAP0780.FSBAP_MiningDtl.create();
		p.MiningDtl_mining_PPanel.setName("MiningDtl.mining");
	}

	/**
	 * [Btn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateBtn(FSBAP_Mining p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}


	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP_Mining create(){
		FSBAP_Mining p = new FSBAP_Mining();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP_Mining create(String name){
		FSBAP_Mining p = new FSBAP_Mining(name);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP_Mining_FW.jbfInitSrch((FSBAP_Mining)this);
		FSBAP_Mining_FW.jbfInitSetting((FSBAP_Mining)this);
		FSBAP_Mining_FW.jbfInitSrchBtn((FSBAP_Mining)this);
		FSBAP_Mining_FW.jbfInitDtl((FSBAP_Mining)this);
		FSBAP_Mining_FW.jbfInitMiningList((FSBAP_Mining)this);
		FSBAP_Mining_FW.jbfInitMiningBtn((FSBAP_Mining)this);
		FSBAP_Mining_FW.jbfInitMiningDtl((FSBAP_Mining)this);
		FSBAP_Mining_FW.jbfInitBtn((FSBAP_Mining)this);
		FSBAP_Mining_FW.jbInitSrch((FSBAP_Mining)this);
		FSBAP_Mining_FW.jbInitSetting((FSBAP_Mining)this);
		FSBAP_Mining_FW.jbInitSrchBtn((FSBAP_Mining)this);
		FSBAP_Mining_FW.jbInitDtl((FSBAP_Mining)this);
		FSBAP_Mining_FW.jbInitMiningList((FSBAP_Mining)this);
		FSBAP_Mining_FW.jbInitMiningBtn((FSBAP_Mining)this);
		FSBAP_Mining_FW.jbInitMiningDtl((FSBAP_Mining)this);
		FSBAP_Mining_FW.jbInitBtn((FSBAP_Mining)this);
	}

	/**
	 * [Srch]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitSrch(FSBAP_Mining p) {
		// ブロック関連の初期化
		p.SrchPanel = p.beansFactory.createPanel("Srch");
		p.SrchTitledBorder = p.beansFactory.createTitledBorder();
		// ブロックの項目の初期化
	}

	/**
	 * [Setting]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitSetting(FSBAP_Mining p) {
		// ブロック関連の初期化
		p.SettingPanel = p.beansFactory.createPanel("Setting");
		// ブロックの項目の初期化
	}

	/**
	 * [SrchBtn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitSrchBtn(FSBAP_Mining p) {
		// ブロック関連の初期化
		p.SrchBtnPanel = p.beansFactory.createPanel("SrchBtn");
		// ブロックの項目の初期化
		p.SrchBtn_srch = p.beansFactory.createButton("SrchBtn.srch", "srch");
	}

	/**
	 * [Dtl]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitDtl(FSBAP_Mining p) {
		// ブロック関連の初期化
		p.DtlPanel = p.beansFactory.createPanel("Dtl");
		// ブロックの項目の初期化
	}

	/**
	 * [MiningList]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitMiningList(FSBAP_Mining p) {
		// ブロック関連の初期化
		p.MiningListPanel = p.beansFactory.createPanel("MiningList");
		p.MiningListScrollPane = p.beansFactory.createScrollPane("MiningList.scroll");
		p.createMiningListTable();
		// ブロックの項目の初期化
		p.columnMiningList_check = p.beansFactory.createTableColumn("MiningList.check", MCColumnType.CHECK);
		p.columnMiningList_mining_nm = p.beansFactory.createTableColumn("MiningList.mining_nm", MCColumnType.TEXT);
	}

	/**
	 * [MiningBtn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitMiningBtn(FSBAP_Mining p) {
		// ブロック関連の初期化
		p.MiningBtnPanel = p.beansFactory.createPanel("MiningBtn");
		// ブロックの項目の初期化
		p.MiningBtn_select_all = p.beansFactory.createButton("MiningBtn.select_all", "no_border");
		p.MiningBtn_deselect_all = p.beansFactory.createButton("MiningBtn.deselect_all", "no_border");
		p.MiningBtn_del = p.beansFactory.createButton("MiningBtn.del", "del");
	}

	/**
	 * [MiningDtl]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitMiningDtl(FSBAP_Mining p) {
		// ブロック関連の初期化
		p.MiningDtlPanel = p.beansFactory.createPanel("MiningDtl");
		// ブロックの項目の初期化
	}

	/**
	 * [Btn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitBtn(FSBAP_Mining p) {
		// ブロック関連の初期化
		p.BtnPanel = p.beansFactory.createPanel("Btn");
		// ブロックの項目の初期化
		p.Btn_upd = p.beansFactory.createButton("Btn.upd", "upd");
		p.Btn_upd_ext = p.beansFactory.createButton("Btn.upd_ext");
		p.Btn_upd_sys = p.beansFactory.createButton("Btn.upd_sys");
		p.Btn_copy_usr = p.beansFactory.createButton("Btn.copy_usr");
		p.Btn_copy_ext = p.beansFactory.createButton("Btn.copy_ext");
		p.Btn_copy_sys = p.beansFactory.createButton("Btn.copy_sys");
	}

	/**
	 * [Srch]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitSrch(FSBAP_Mining p) {
		// ブロック関連の初期化
		p.SrchPanel.setBorder(p.SrchTitledBorder);
		p.add(p.SrchPanel);
		p.setLastBeans(p.SrchPanel);
		p.SrchPanel.setNextBeans(p.DtlPanel);
		p.SrchPanel.setValueCheck(false);
		p.SrchPanel.setLayoutPosition("N+");
		// ブロックの項目の初期化
		p.SrchPanel.add(p.SettingPanel, null);
		p.SrchPanel.setLastBeans(p.SettingPanel);
		p.SettingPanel.setNextBeans(p.SrchBtnPanel);
		p.SrchPanel.add(p.SrchBtnPanel, null);
	}

	/**
	 * [Setting]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitSetting(FSBAP_Mining p) {
		// ブロック関連の初期化
		p.SettingPanel.setValueCheck(false);
		p.SettingPanel.setLayoutPosition("W");
		// ブロックの項目の初期化
		p.SettingPanel.add(p.Setting_setting_PPanel);
		p.SettingPanel.setLastBeans(p.Setting_setting_PPanel);
	}

	/**
	 * [SrchBtn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitSrchBtn(FSBAP_Mining p) {
		// ブロック関連の初期化
		p.SrchBtnPanel.setValueCheck(false);
		p.SrchBtnPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
		p.SrchBtn_srch.setIcon("SEARCH");
		p.SrchBtn_srch.setFunctionKey(MCFunctionKey.F1);
		p.SrchBtnPanel.add(p.SrchBtn_srch);
		p.SrchBtnPanel.setLastBeans(p.SrchBtn_srch);
	}

	/**
	 * [Dtl]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitDtl(FSBAP_Mining p) {
		// ブロック関連の初期化
		p.add(p.DtlPanel);
		p.DtlPanel.setNextBeans(p.MiningDtlPanel);
		p.DtlPanel.setLayoutPosition("CL+");
		// ブロックの項目の初期化
		p.DtlPanel.add(p.MiningListPanel, null);
		p.DtlPanel.setLastBeans(p.MiningListPanel);
		p.MiningListPanel.setNextBeans(p.MiningBtnPanel);
		p.DtlPanel.add(p.MiningBtnPanel, null);
	}

	/**
	 * [MiningList]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitMiningList(FSBAP_Mining p) {
		// ブロック関連の初期化
		p.MiningListPanel.add(p.MiningListScrollPane);
		p.MiningListPanel.setLastBeans(p.MiningListTable);
		p.MiningListScrollPane.setViewportView(p.MiningListTable);
		p.MiningListTable.setList(p.getMiningListL());
		p.MiningListTable.setStatusColumnVisible(false);
		p.MiningListPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * [MiningBtn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitMiningBtn(FSBAP_Mining p) {
		// ブロック関連の初期化
		p.MiningBtnPanel.setValueCheck(false);
		p.MiningBtnPanel.setLayoutPosition("S");
		// ブロックの項目の初期化
		p.MiningBtn_select_all.setIcon("SELECT_ALL");
		p.MiningBtn_select_all.setFunctionKey(MCFunctionKey.F13);
		p.MiningBtnPanel.add(p.MiningBtn_select_all);
		p.MiningBtnPanel.setLastBeans(p.MiningBtn_select_all);
		p.MiningBtn_select_all.setNextBeans(p.MiningBtn_deselect_all);
		p.MiningBtn_deselect_all.setIcon("DESELECT_ALL");
		p.MiningBtn_deselect_all.setFunctionKey(MCFunctionKey.F14);
		p.MiningBtnPanel.add(p.MiningBtn_deselect_all);
		p.MiningBtn_deselect_all.setNextBeans(p.MiningBtn_del);
		p.MiningBtn_del.setIcon("DELETE");
		p.MiningBtn_del.setFunctionKey(MCFunctionKey.F12);
		p.MiningBtnPanel.add(p.MiningBtn_del);
	}

	/**
	 * [MiningDtl]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitMiningDtl(FSBAP_Mining p) {
		// ブロック関連の初期化
		p.add(p.MiningDtlPanel);
		p.MiningDtlPanel.setNextBeans(p.BtnPanel);
		p.MiningDtlPanel.setLayoutPosition("CRC+");
		// ブロックの項目の初期化
		p.MiningDtlPanel.add(p.MiningDtl_mining_PPanel);
		p.MiningDtlPanel.setLastBeans(p.MiningDtl_mining_PPanel);
	}

	/**
	 * [Btn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitBtn(FSBAP_Mining p) {
		// ブロック関連の初期化
		p.add(p.BtnPanel);
		p.BtnPanel.setValueCheck(false);
		p.BtnPanel.setLayoutPosition("CRS");
		// ブロックの項目の初期化
		p.Btn_upd.setIcon("REGISTER");
		p.Btn_upd.setFunctionKey(MCFunctionKey.F9);
		p.BtnPanel.add(p.Btn_upd);
		p.BtnPanel.setLastBeans(p.Btn_upd);
		p.Btn_upd.setNextBeans(p.Btn_upd_ext);
		p.BtnPanel.add(p.Btn_upd_ext);
		p.Btn_upd_ext.setNextBeans(p.Btn_upd_sys);
		p.BtnPanel.add(p.Btn_upd_sys);
		p.Btn_upd_sys.setNextBeans(p.Btn_copy_usr);
		p.Btn_copy_usr.setFunctionKey(MCFunctionKey.F3);
		p.BtnPanel.add(p.Btn_copy_usr);
		p.Btn_copy_usr.setNextBeans(p.Btn_copy_ext);
		p.Btn_copy_ext.setFunctionKey(MCFunctionKey.F4);
		p.BtnPanel.add(p.Btn_copy_ext);
		p.Btn_copy_ext.setNextBeans(p.Btn_copy_sys);
		p.Btn_copy_sys.setFunctionKey(MCFunctionKey.F5);
		p.BtnPanel.add(p.Btn_copy_sys);
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "G";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP_Mining_FW.mcInitSrch((FSBAP_Mining)this);
		FSBAP_Mining_FW.mcInitSetting((FSBAP_Mining)this);
		FSBAP_Mining_FW.mcInitSrchBtn((FSBAP_Mining)this);
		FSBAP_Mining_FW.mcInitDtl((FSBAP_Mining)this);
		FSBAP_Mining_FW.mcInitMiningList((FSBAP_Mining)this);
		FSBAP_Mining_FW.mcInitMiningBtn((FSBAP_Mining)this);
		FSBAP_Mining_FW.mcInitMiningDtl((FSBAP_Mining)this);
		FSBAP_Mining_FW.mcInitBtn((FSBAP_Mining)this);

		// [INIT]ステータスのモードの設定
		FSBAP_Mining_FW.statusInitINIT_Srch((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitINIT_Setting((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitINIT_SrchBtn((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitINIT_SrchCond((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitINIT_Dtl((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitINIT_MiningList((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitINIT_MiningBtn((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitINIT_MiningDtl((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitINIT_Btn((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitINIT_Mining((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitINIT_CondParam((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitINIT_MethodParam((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitINIT_SumCondParam((FSBAP_Mining)this);

		// [EDIT]ステータスのモードの設定
		FSBAP_Mining_FW.statusInitEDIT_Srch((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitEDIT_Setting((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitEDIT_SrchBtn((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitEDIT_SrchCond((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitEDIT_Dtl((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitEDIT_MiningList((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitEDIT_MiningBtn((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitEDIT_MiningDtl((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitEDIT_Btn((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitEDIT_Mining((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitEDIT_CondParam((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitEDIT_MethodParam((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitEDIT_SumCondParam((FSBAP_Mining)this);

		// [COPY]ステータスのモードの設定
		FSBAP_Mining_FW.statusInitCOPY_Srch((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitCOPY_Setting((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitCOPY_SrchBtn((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitCOPY_SrchCond((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitCOPY_Dtl((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitCOPY_MiningList((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitCOPY_MiningBtn((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitCOPY_MiningDtl((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitCOPY_Btn((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitCOPY_Mining((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitCOPY_CondParam((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitCOPY_MethodParam((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitCOPY_SumCondParam((FSBAP_Mining)this);

		// [READ_ONLY]ステータスのモードの設定
		FSBAP_Mining_FW.statusInitREAD__ONLY_Srch((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitREAD__ONLY_Setting((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitREAD__ONLY_SrchBtn((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitREAD__ONLY_SrchCond((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitREAD__ONLY_Dtl((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitREAD__ONLY_MiningList((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitREAD__ONLY_MiningBtn((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitREAD__ONLY_MiningDtl((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitREAD__ONLY_Btn((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitREAD__ONLY_Mining((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitREAD__ONLY_CondParam((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitREAD__ONLY_MethodParam((FSBAP_Mining)this);
		FSBAP_Mining_FW.statusInitREAD__ONLY_SumCondParam((FSBAP_Mining)this);

	}

	/**
	 *  [Srch]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitSrch(FSBAP_Mining p) {
	}

	/**
	 *  [Setting]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitSetting(FSBAP_Mining p) {
	}

	/**
	 *  [SrchBtn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitSrchBtn(FSBAP_Mining p) {
		p.SrchBtn_srch.addAllListener(p);
		p.SrchBtn_srch.setAPMethodName("doSrchBtn_srch");
	}

	/**
	 *  [Dtl]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitDtl(FSBAP_Mining p) {
	}

	/**
	 *  [MiningList]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitMiningList(FSBAP_Mining p) {
		p.MiningListTable.addAllListener(p);
		p.columnMiningList_check.addAllListener(p);
		p.columnMiningList_mining_nm.addAllListener(p);
		p.columnMiningList_mining_nm.setListListener(p);
	}

	/**
	 *  [MiningBtn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitMiningBtn(FSBAP_Mining p) {
		p.MiningBtn_select_all.addAllListener(p);
		p.MiningBtn_select_all.setAPMethodName("doMiningBtn_select_all");
		p.MiningBtn_deselect_all.addAllListener(p);
		p.MiningBtn_deselect_all.setAPMethodName("doMiningBtn_deselect_all");
		p.MiningBtn_del.addAllListener(p);
		p.MiningBtn_del.setAPMethodName("doMiningBtn_del");
	}

	/**
	 *  [MiningDtl]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitMiningDtl(FSBAP_Mining p) {
	}

	/**
	 *  [Btn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitBtn(FSBAP_Mining p) {
		p.Btn_upd.addAllListener(p);
		p.Btn_upd.setAPMethodName("doBtn_upd");
		p.Btn_upd_ext.addAllListener(p);
		p.Btn_upd_ext.setAPMethodName("doBtn_upd_ext");
		p.Btn_upd_sys.addAllListener(p);
		p.Btn_upd_sys.setAPMethodName("doBtn_upd_sys");
		p.Btn_copy_usr.addAllListener(p);
		p.Btn_copy_usr.setAPMethodName("doBtn_copy_usr");
		p.Btn_copy_ext.addAllListener(p);
		p.Btn_copy_ext.setAPMethodName("doBtn_copy_ext");
		p.Btn_copy_sys.addAllListener(p);
		p.Btn_copy_sys.setAPMethodName("doBtn_copy_sys");
	}

	/**
	 * [INIT]ステータスの[Srch]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Srch(FSBAP_Mining p){

	}

	/**
	 * [INIT]ステータスの[Setting]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Setting(FSBAP_Mining p){
		p.Setting_setting_PPanel.putStatus(INIT, mcframe.clientFSUB.FSUBP0090.FSUBP_SettingUnit_H.REQUIRED);

	}

	/**
	 * [INIT]ステータスの[SrchBtn]ブロックのモードの設定
	 */
	protected static void statusInitINIT_SrchBtn(FSBAP_Mining p){
		p.SrchBtn_srch.putMode(p, INIT, MCMode.ENABLE);

	}

	/**
	 * [INIT]ステータスの[SrchCond]ブロックのモードの設定
	 */
	protected static void statusInitINIT_SrchCond(FSBAP_Mining p){

	}

	/**
	 * [INIT]ステータスの[Dtl]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Dtl(FSBAP_Mining p){

	}

	/**
	 * [INIT]ステータスの[MiningList]ブロックのモードの設定
	 */
	protected static void statusInitINIT_MiningList(FSBAP_Mining p){
		p.columnMiningList_check.putMode(p, INIT, MCMode.REQUIRED);
		p.columnMiningList_mining_nm.putMode(p, INIT, MCMode.READ_ONLY);

	}

	/**
	 * [INIT]ステータスの[MiningBtn]ブロックのモードの設定
	 */
	protected static void statusInitINIT_MiningBtn(FSBAP_Mining p){
		p.MiningBtn_select_all.putMode(p, INIT, MCMode.ENABLE);
		p.MiningBtn_deselect_all.putMode(p, INIT, MCMode.ENABLE);
		p.MiningBtn_del.putMode(p, INIT, MCMode.ENABLE);

	}

	/**
	 * [INIT]ステータスの[MiningDtl]ブロックのモードの設定
	 */
	protected static void statusInitINIT_MiningDtl(FSBAP_Mining p){
		p.MiningDtl_mining_PPanel.putStatus(INIT, mcframe.clientFSBA.FSBAP0780.FSBAP_MiningDtl.READ_ONLY);

	}

	/**
	 * [INIT]ステータスの[Btn]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Btn(FSBAP_Mining p){
		p.Btn_upd.putMode(p, INIT, MCMode.INVISIBLE);
		p.Btn_upd_ext.putMode(p, INIT, MCMode.INVISIBLE);
		p.Btn_upd_sys.putMode(p, INIT, MCMode.INVISIBLE);
		p.Btn_copy_usr.putMode(p, INIT, MCMode.INVISIBLE);
		p.Btn_copy_ext.putMode(p, INIT, MCMode.INVISIBLE);
		p.Btn_copy_sys.putMode(p, INIT, MCMode.INVISIBLE);

	}

	/**
	 * [INIT]ステータスの[Mining]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Mining(FSBAP_Mining p){

	}

	/**
	 * [INIT]ステータスの[CondParam]ブロックのモードの設定
	 */
	protected static void statusInitINIT_CondParam(FSBAP_Mining p){

	}

	/**
	 * [INIT]ステータスの[MethodParam]ブロックのモードの設定
	 */
	protected static void statusInitINIT_MethodParam(FSBAP_Mining p){

	}

	/**
	 * [INIT]ステータスの[SumCondParam]ブロックのモードの設定
	 */
	protected static void statusInitINIT_SumCondParam(FSBAP_Mining p){

	}

	/**
	 * [EDIT]ステータスの[Srch]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_Srch(FSBAP_Mining p){

	}

	/**
	 * [EDIT]ステータスの[Setting]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_Setting(FSBAP_Mining p){
		p.Setting_setting_PPanel.putStatus(EDIT, mcframe.clientFSUB.FSUBP0090.FSUBP_SettingUnit_H.REQUIRED);

	}

	/**
	 * [EDIT]ステータスの[SrchBtn]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_SrchBtn(FSBAP_Mining p){
		p.SrchBtn_srch.putMode(p, EDIT, MCMode.ENABLE);

	}

	/**
	 * [EDIT]ステータスの[SrchCond]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_SrchCond(FSBAP_Mining p){

	}

	/**
	 * [EDIT]ステータスの[Dtl]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_Dtl(FSBAP_Mining p){

	}

	/**
	 * [EDIT]ステータスの[MiningList]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_MiningList(FSBAP_Mining p){
		p.columnMiningList_check.putMode(p, EDIT, MCMode.REQUIRED);
		p.columnMiningList_mining_nm.putMode(p, EDIT, MCMode.READ_ONLY);

	}

	/**
	 * [EDIT]ステータスの[MiningBtn]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_MiningBtn(FSBAP_Mining p){
		p.MiningBtn_select_all.putMode(p, EDIT, MCMode.ENABLE);
		p.MiningBtn_deselect_all.putMode(p, EDIT, MCMode.ENABLE);
		p.MiningBtn_del.putMode(p, EDIT, MCMode.ENABLE);

	}

	/**
	 * [EDIT]ステータスの[MiningDtl]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_MiningDtl(FSBAP_Mining p){
		p.MiningDtl_mining_PPanel.putStatus(EDIT, mcframe.clientFSBA.FSBAP0780.FSBAP_MiningDtl.ENABLE);

	}

	/**
	 * [EDIT]ステータスの[Btn]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_Btn(FSBAP_Mining p){
		p.Btn_upd.putMode(p, EDIT, MCMode.ENABLE);
		p.Btn_upd_ext.putMode(p, EDIT, MCMode.INVISIBLE);
		p.Btn_upd_sys.putMode(p, EDIT, MCMode.INVISIBLE);
		p.Btn_copy_usr.putMode(p, EDIT, MCMode.ENABLE);
		p.Btn_copy_ext.putMode(p, EDIT, MCMode.ENABLE);
		p.Btn_copy_sys.putMode(p, EDIT, MCMode.ENABLE);

	}

	/**
	 * [EDIT]ステータスの[Mining]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_Mining(FSBAP_Mining p){

	}

	/**
	 * [EDIT]ステータスの[CondParam]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_CondParam(FSBAP_Mining p){

	}

	/**
	 * [EDIT]ステータスの[MethodParam]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_MethodParam(FSBAP_Mining p){

	}

	/**
	 * [EDIT]ステータスの[SumCondParam]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_SumCondParam(FSBAP_Mining p){

	}

	/**
	 * [COPY]ステータスの[Srch]ブロックのモードの設定
	 */
	protected static void statusInitCOPY_Srch(FSBAP_Mining p){

	}

	/**
	 * [COPY]ステータスの[Setting]ブロックのモードの設定
	 */
	protected static void statusInitCOPY_Setting(FSBAP_Mining p){
		p.Setting_setting_PPanel.putStatus(COPY, mcframe.clientFSUB.FSUBP0090.FSUBP_SettingUnit_H.REQUIRED);

	}

	/**
	 * [COPY]ステータスの[SrchBtn]ブロックのモードの設定
	 */
	protected static void statusInitCOPY_SrchBtn(FSBAP_Mining p){
		p.SrchBtn_srch.putMode(p, COPY, MCMode.ENABLE);

	}

	/**
	 * [COPY]ステータスの[SrchCond]ブロックのモードの設定
	 */
	protected static void statusInitCOPY_SrchCond(FSBAP_Mining p){

	}

	/**
	 * [COPY]ステータスの[Dtl]ブロックのモードの設定
	 */
	protected static void statusInitCOPY_Dtl(FSBAP_Mining p){

	}

	/**
	 * [COPY]ステータスの[MiningList]ブロックのモードの設定
	 */
	protected static void statusInitCOPY_MiningList(FSBAP_Mining p){
		p.columnMiningList_check.putMode(p, COPY, MCMode.DISABLE);
		p.columnMiningList_mining_nm.putMode(p, COPY, MCMode.READ_ONLY);

	}

	/**
	 * [COPY]ステータスの[MiningBtn]ブロックのモードの設定
	 */
	protected static void statusInitCOPY_MiningBtn(FSBAP_Mining p){
		p.MiningBtn_select_all.putMode(p, COPY, MCMode.DISABLE);
		p.MiningBtn_deselect_all.putMode(p, COPY, MCMode.DISABLE);
		p.MiningBtn_del.putMode(p, COPY, MCMode.DISABLE);

	}

	/**
	 * [COPY]ステータスの[MiningDtl]ブロックのモードの設定
	 */
	protected static void statusInitCOPY_MiningDtl(FSBAP_Mining p){
		p.MiningDtl_mining_PPanel.putStatus(COPY, mcframe.clientFSBA.FSBAP0780.FSBAP_MiningDtl.ENABLE);

	}

	/**
	 * [COPY]ステータスの[Btn]ブロックのモードの設定
	 */
	protected static void statusInitCOPY_Btn(FSBAP_Mining p){
		p.Btn_upd.putMode(p, COPY, MCMode.ENABLE);
		p.Btn_upd_ext.putMode(p, COPY, MCMode.INVISIBLE);
		p.Btn_upd_sys.putMode(p, COPY, MCMode.INVISIBLE);
		p.Btn_copy_usr.putMode(p, COPY, MCMode.INVISIBLE);
		p.Btn_copy_ext.putMode(p, COPY, MCMode.INVISIBLE);
		p.Btn_copy_sys.putMode(p, COPY, MCMode.INVISIBLE);

	}

	/**
	 * [COPY]ステータスの[Mining]ブロックのモードの設定
	 */
	protected static void statusInitCOPY_Mining(FSBAP_Mining p){

	}

	/**
	 * [COPY]ステータスの[CondParam]ブロックのモードの設定
	 */
	protected static void statusInitCOPY_CondParam(FSBAP_Mining p){

	}

	/**
	 * [COPY]ステータスの[MethodParam]ブロックのモードの設定
	 */
	protected static void statusInitCOPY_MethodParam(FSBAP_Mining p){

	}

	/**
	 * [COPY]ステータスの[SumCondParam]ブロックのモードの設定
	 */
	protected static void statusInitCOPY_SumCondParam(FSBAP_Mining p){

	}

	/**
	 * [READ_ONLY]ステータスの[Srch]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_Srch(FSBAP_Mining p){

	}

	/**
	 * [READ_ONLY]ステータスの[Setting]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_Setting(FSBAP_Mining p){
		p.Setting_setting_PPanel.putStatus(READ_ONLY, mcframe.clientFSUB.FSUBP0090.FSUBP_SettingUnit_H.REQUIRED);

	}

	/**
	 * [READ_ONLY]ステータスの[SrchBtn]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_SrchBtn(FSBAP_Mining p){
		p.SrchBtn_srch.putMode(p, READ_ONLY, MCMode.ENABLE);

	}

	/**
	 * [READ_ONLY]ステータスの[SrchCond]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_SrchCond(FSBAP_Mining p){

	}

	/**
	 * [READ_ONLY]ステータスの[Dtl]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_Dtl(FSBAP_Mining p){

	}

	/**
	 * [READ_ONLY]ステータスの[MiningList]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_MiningList(FSBAP_Mining p){
		p.columnMiningList_check.putMode(p, READ_ONLY, MCMode.REQUIRED);
		p.columnMiningList_mining_nm.putMode(p, READ_ONLY, MCMode.READ_ONLY);

	}

	/**
	 * [READ_ONLY]ステータスの[MiningBtn]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_MiningBtn(FSBAP_Mining p){
		p.MiningBtn_select_all.putMode(p, READ_ONLY, MCMode.ENABLE);
		p.MiningBtn_deselect_all.putMode(p, READ_ONLY, MCMode.ENABLE);
		p.MiningBtn_del.putMode(p, READ_ONLY, MCMode.ENABLE);

	}

	/**
	 * [READ_ONLY]ステータスの[MiningDtl]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_MiningDtl(FSBAP_Mining p){
		p.MiningDtl_mining_PPanel.putStatus(READ_ONLY, mcframe.clientFSBA.FSBAP0780.FSBAP_MiningDtl.READ_ONLY);

	}

	/**
	 * [READ_ONLY]ステータスの[Btn]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_Btn(FSBAP_Mining p){
		p.Btn_upd.putMode(p, READ_ONLY, MCMode.INVISIBLE);
		p.Btn_upd_ext.putMode(p, READ_ONLY, MCMode.INVISIBLE);
		p.Btn_upd_sys.putMode(p, READ_ONLY, MCMode.INVISIBLE);
		p.Btn_copy_usr.putMode(p, READ_ONLY, MCMode.INVISIBLE);
		p.Btn_copy_ext.putMode(p, READ_ONLY, MCMode.INVISIBLE);
		p.Btn_copy_sys.putMode(p, READ_ONLY, MCMode.INVISIBLE);

	}

	/**
	 * [READ_ONLY]ステータスの[Mining]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_Mining(FSBAP_Mining p){

	}

	/**
	 * [READ_ONLY]ステータスの[CondParam]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_CondParam(FSBAP_Mining p){

	}

	/**
	 * [READ_ONLY]ステータスの[MethodParam]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_MethodParam(FSBAP_Mining p){

	}

	/**
	 * [READ_ONLY]ステータスの[SumCondParam]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_SumCondParam(FSBAP_Mining p){

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return INIT;
	}

	/**
	 * Table/Treeの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
		FSBAP_Mining_FW.setTableConfigMiningList((FSBAP_Mining)this);
	}

	/**
	 * [MiningList]ブロックのTableの設定
	 */
	protected static void setTableConfigMiningList(FSBAP_Mining p) {
		p.columnMiningList_check.setMeta(mcframe.clientFSBA.FSBAP0780.MiningR.check_META);
		p.MiningListTable.addColumnConfig(p.columnMiningList_check);
		p.columnMiningList_mining_nm.setMeta(mcframe.clientFSBA.FSBAP0780.MiningR.mining_nm_META);
		p.MiningListTable.addColumnConfig(p.columnMiningList_mining_nm);
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
	}

	/**
	 * この画面を[INIT]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setINITStatus() {
		status = INIT;
		setAllStatus(status);
	}

	/**
	 * この画面を[EDIT]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setEDITStatus() {
		status = EDIT;
		setAllStatus(status);
	}

	/**
	 * この画面を[COPY]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setCOPYStatus() {
		status = COPY;
		setAllStatus(status);
	}

	/**
	 * この画面を[READ_ONLY]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setREAD_ONLYStatus() {
		status = READ_ONLY;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (INIT.equals(status)) {
			setINITStatus();
		}
		else if (EDIT.equals(status)) {
			setEDITStatus();
		}
		else if (COPY.equals(status)) {
			setCOPYStatus();
		}
		else if (READ_ONLY.equals(status)) {
			setREAD_ONLYStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}


	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == SrchBtn_srch) doSrchBtn_srch(info);
		else if (ap == MiningBtn_select_all) doMiningBtn_select_all(info);
		else if (ap == MiningBtn_deselect_all) doMiningBtn_deselect_all(info);
		else if (ap == MiningBtn_del) doMiningBtn_del(info);
		else if (ap == Btn_upd) doBtn_upd(info);
		else if (ap == Btn_upd_ext) doBtn_upd_ext(info);
		else if (ap == Btn_upd_sys) doBtn_upd_sys(info);
		else if (ap == Btn_copy_usr) doBtn_copy_usr(info);
		else if (ap == Btn_copy_ext) doBtn_copy_ext(info);
		else if (ap == Btn_copy_sys) doBtn_copy_sys(info);
	}

	/**
	 * [SrchBtn]パネルの[srch]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doSrchBtn_srch(MCEventInfo info);

	/**
	 * [MiningBtn]パネルの[select_all]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doMiningBtn_select_all(MCEventInfo info);

	/**
	 * [MiningBtn]パネルの[deselect_all]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doMiningBtn_deselect_all(MCEventInfo info);

	/**
	 * [MiningBtn]パネルの[del]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doMiningBtn_del(MCEventInfo info);

	/**
	 * [Btn]パネルの[upd]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_upd(MCEventInfo info);

	/**
	 * [Btn]パネルの[upd_ext]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_upd_ext(MCEventInfo info);

	/**
	 * [Btn]パネルの[upd_sys]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_upd_sys(MCEventInfo info);

	/**
	 * [Btn]パネルの[copy_usr]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_copy_usr(MCEventInfo info);

	/**
	 * [Btn]パネルの[copy_ext]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_copy_ext(MCEventInfo info);

	/**
	 * [Btn]パネルの[copy_sys]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_copy_sys(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == MiningListTable) return doMiningList_VC(info);
		if (vc == columnMiningList_check) return doMiningList_check_VC(info);
		if (vc == columnMiningList_mining_nm) return doMiningList_mining_nm_VC(info);
		return true;
	}

	/**
	 * [MiningList]Tableの選択行が変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMiningList_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [MiningList]パネルの[check]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMiningList_check_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [MiningList]パネルの[mining_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMiningList_mining_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == MiningListTable) doMiningList_NC(info);
		else if (nc == columnMiningList_check) doMiningList_check_NC(info);
		else if (nc == columnMiningList_mining_nm) doMiningList_mining_nm_NC(info);
	}

	/**
	 * [MiningList]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMiningList_NC(MCEventInfo info){
	}

	/**
	 * [MiningList]パネルの[check]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMiningList_check_NC(MCEventInfo info){
	}

	/**
	 * [MiningList]パネルの[mining_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMiningList_mining_nm_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == MiningListTable) doMiningList_NE(info);
		else if (ne == columnMiningList_check) doMiningList_check_NE(info);
		else if (ne == columnMiningList_mining_nm) doMiningList_mining_nm_NE(info);
	}

	/**
	 * [MiningList]TableのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMiningList_NE(MCEventInfo info){
	}

	/**
	 * [MiningList]パネルの[check]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMiningList_check_NE(MCEventInfo info){
	}

	/**
	 * [MiningList]パネルの[mining_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMiningList_mining_nm_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == MiningListTable) doMiningList_NX(info);
		else if (nx == columnMiningList_check) doMiningList_check_NX(info);
		else if (nx == columnMiningList_mining_nm) doMiningList_mining_nm_NX(info);
	}

	/**
	 * [MiningList]TableのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMiningList_NX(MCEventInfo info){
	}

	/**
	 * [MiningList]パネルの[check]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMiningList_check_NX(MCEventInfo info){
	}

	/**
	 * [MiningList]パネルの[mining_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMiningList_mining_nm_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == columnMiningList_mining_nm) doMiningList_mining_nm_LC(info);
	}

	/**
	 * [MiningList]パネルの[mining_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMiningList_mining_nm_LC(MCEventInfo info){
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		if (id.equals("FS.FSBAL0760.Srch01")) {
			return new FS_FSBAL0760_Srch01Bridge();
		}
		if (id.equals("FS.FSBAL0760.Del01")) {
			return new FS_FSBAL0760_Del01Bridge();
		}
		return super.createBridge(id);
	}
	/**
	 * [FS_FSBAL0760_Srch01]の定型処理のInnerClass
	 */
	protected class FS_FSBAL0760_Srch01Bridge extends MCCallerPanelBridge {
		/**
		 * 電文パラメータ<p>
		 * 
		 * 参照する場合には{@link #param()}を使用してください。
		 */
		MCParam p_FS_FSBAL0760_Srch01;

		/** コンストラクタ */
		protected FS_FSBAL0760_Srch01Bridge() {
			p_FS_FSBAL0760_Srch01 = new MCParam(PDef.FS_FSBAL0760_Srch01_INFO);
		}

		@Override
		public MCParam createAsyncParam() {
			MCParam param = new MCParam(PDef.FS_FSBAL0760_Srch01_INFO);
			param.setReqSrcId(getScreenID());
			// Up
			param.addUpBlock(mcframe.clientFSBA.FSBAP0760.SrchCondR.create());
			// Down
			param.addDownBlock(MCList.create(mcframe.clientFSBA.FSBAP0780.MiningR.class));
			param.addDownBlock(MCList.create(mcframe.clientFSBA.FSBAP0780.CondR.class));
			param.addDownBlock(MCList.create(mcframe.clientFSBA.FSBAP0780.MethodR.class));
			param.addDownBlock(MCList.create(mcframe.clientFSBA.FSBAP0780.SumCondParamR.class));

			p_FS_FSBAL0760_Srch01 = param;
			return param;
		}

		/** パラメータを通信用に設定します。*/
		protected void setupParam() {
			p_FS_FSBAL0760_Srch01.setReqSrcId(getScreenID());
			setupUpParam();
			setupDownParam();
		}

		protected void setupUpParam() {
			p_FS_FSBAL0760_Srch01.addUpBlock(getSrchCondR());
		}

		protected MCContainer up(int i) {
			return p_FS_FSBAL0760_Srch01.getContainerParam().getUpBlock(i);
		}
		
		protected MCContainer down(int i) {
			return p_FS_FSBAL0760_Srch01.getContainerParam().getDownBlock(i);
		}
		
		protected mcframe.clientFSBA.FSBAP0760.SrchCondR up0() {
			return (mcframe.clientFSBA.FSBAP0760.SrchCondR)up(0);
		}

		protected MCList<mcframe.clientFSBA.FSBAP0780.MiningR> down0() {
			return (MCList<mcframe.clientFSBA.FSBAP0780.MiningR>)down(0);
		}
		protected MCList<mcframe.clientFSBA.FSBAP0780.CondR> down1() {
			return (MCList<mcframe.clientFSBA.FSBAP0780.CondR>)down(1);
		}
		protected MCList<mcframe.clientFSBA.FSBAP0780.MethodR> down2() {
			return (MCList<mcframe.clientFSBA.FSBAP0780.MethodR>)down(2);
		}
		protected MCList<mcframe.clientFSBA.FSBAP0780.SumCondParamR> down3() {
			return (MCList<mcframe.clientFSBA.FSBAP0780.SumCondParamR>)down(3);
		}

		protected void setupDownParam() {
			p_FS_FSBAL0760_Srch01.addDownBlock(MCList.create(mcframe.clientFSBA.FSBAP0780.MiningR.class));
			p_FS_FSBAL0760_Srch01.addDownBlock(MCList.create(mcframe.clientFSBA.FSBAP0780.CondR.class));
			p_FS_FSBAL0760_Srch01.addDownBlock(MCList.create(mcframe.clientFSBA.FSBAP0780.MethodR.class));
			p_FS_FSBAL0760_Srch01.addDownBlock(MCList.create(mcframe.clientFSBA.FSBAP0780.SumCondParamR.class));
		}
		protected MCParam param() {
			return p_FS_FSBAL0760_Srch01;
		}

		protected void show() {
			setMiningL((MCList<mcframe.clientFSBA.FSBAP0780.MiningR>)p_FS_FSBAL0760_Srch01.getContainerParam().getDownBlock(0));
			setCondParamL((MCList<mcframe.clientFSBA.FSBAP0780.CondR>)p_FS_FSBAL0760_Srch01.getContainerParam().getDownBlock(1));
			setMethodParamL((MCList<mcframe.clientFSBA.FSBAP0780.MethodR>)p_FS_FSBAL0760_Srch01.getContainerParam().getDownBlock(2));
			setSumCondParamL((MCList<mcframe.clientFSBA.FSBAP0780.SumCondParamR>)p_FS_FSBAL0760_Srch01.getContainerParam().getDownBlock(3));
		}

		protected void clear() {
			getMiningL().clear();
			getCondParamL().clear();
			getMethodParamL().clear();
			getSumCondParamL().clear();
		}
		
		protected List<MCContainer> getUpBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getSrchCondR());
			return result;
		}
		
		protected List<MCContainer> getDownBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getMiningL());
			result.add(getCondParamL());
			result.add(getMethodParamL());
			result.add(getSumCondParamL());
			return result;
		}
	}
	/**
	 * [FS_FSBAL0760_Del01]の定型処理のInnerClass
	 */
	protected class FS_FSBAL0760_Del01Bridge extends MCCallerPanelBridge {
		/**
		 * 電文パラメータ<p>
		 * 
		 * 参照する場合には{@link #param()}を使用してください。
		 */
		MCParam p_FS_FSBAL0760_Del01;

		/** コンストラクタ */
		protected FS_FSBAL0760_Del01Bridge() {
			p_FS_FSBAL0760_Del01 = new MCParam(PDef.FS_FSBAL0760_Del01_INFO);
		}

		@Override
		public MCParam createAsyncParam() {
			MCParam param = new MCParam(PDef.FS_FSBAL0760_Del01_INFO);
			param.setReqSrcId(getScreenID());
			// Up
			param.addUpBlock(MCList.create(mcframe.clientFSBA.FSBAP0780.MiningR.class));
			// Down

			p_FS_FSBAL0760_Del01 = param;
			return param;
		}

		/** パラメータを通信用に設定します。*/
		protected void setupParam() {
			p_FS_FSBAL0760_Del01.setReqSrcId(getScreenID());
			setupUpParam();
			setupDownParam();
		}

		protected void setupUpParam() {
			p_FS_FSBAL0760_Del01.addUpBlock(getMiningListL().shallowClone());
		}

		protected MCContainer up(int i) {
			return p_FS_FSBAL0760_Del01.getContainerParam().getUpBlock(i);
		}
		
		protected MCContainer down(int i) {
			return p_FS_FSBAL0760_Del01.getContainerParam().getDownBlock(i);
		}
		
		protected MCList<mcframe.clientFSBA.FSBAP0780.MiningR> up0() {
			return (MCList<mcframe.clientFSBA.FSBAP0780.MiningR>)up(0);
		}


		protected void setupDownParam() {
		}
		protected MCParam param() {
			return p_FS_FSBAL0760_Del01;
		}

		protected void show() {
		}

		protected void clear() {
		}
		
		protected List<MCContainer> getUpBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getMiningListL());
			return result;
		}
		
		protected List<MCContainer> getDownBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			return result;
		}
	}
}