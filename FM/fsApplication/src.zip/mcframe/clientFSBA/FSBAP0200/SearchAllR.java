package mcframe.clientFSBA.FSBAP0200;

import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.annotation.EI;

/**
 * ブロック"SearchAll"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * <table border=1 cellspacing=0 cellpadding=2 >
 *  <caption>[項目定義]</caption>
 * 	<tr bgcolor="#cccccc">
 *  	<th>alias</th>
 *  	<th>項目名</th>
 *  	<th>フルネーム</th>
 *  	<th>型</th>
 *  	<th>桁</th>
 *  	<th>INNERROW/COLUMNPATH</th>
 *  </tr>
 *  <tr bgcolor="Moccasin">
 *  	<td><br></td>
 *  	<td>UserID</td>
 *  	<td>ユーザＩＤ</td>
 *  	<td>String</td>
 *  	<td>[{@link mcframe.commonCore.meta.M_META#USR_ID USR_ID}]</td>
 *  	<td><br></td>
 *  </tr>
 *  <tr >
 *  	<td><br></td>
 *  	<td>Locale</td>
 *  	<td>ロケール</td>
 *  	<td>String</td>
 *  	<td>[{@link mcframe.commonCore.meta.M_META#LOCALE_CD LOCALE_CD}]</td>
 *  	<td><br></td>
 *  </tr>
 *  <tr bgcolor="Moccasin">
 *  	<td><br></td>
 *  	<td>CoCD</td>
 *  	<td>会社ＣＤ</td>
 *  	<td>String</td>
 *  	<td>[{@link mcframe.commonCore.meta.M_META#CO_CD CO_CD}]</td>
 *  	<td><br></td>
 *  </tr>
 *  <tr >
 *  	<td><br></td>
 *  	<td>Ext_attr1</td>
 *  	<td>拡張属性１</td>
 *  	<td>String</td>
 *  	<td>[{@link mcframe.commonCore.meta.M_META#USR_EXT_ATTR USR_EXT_ATTR}]</td>
 *  	<td><br></td>
 *  </tr>
 *  <tr bgcolor="Moccasin">
 *  	<td><br></td>
 *  	<td>Ext_attr2</td>
 *  	<td>拡張属性２</td>
 *  	<td>String</td>
 *  	<td>[{@link mcframe.commonCore.meta.M_META#USR_EXT_ATTR USR_EXT_ATTR}]</td>
 *  	<td><br></td>
 *  </tr>
 *  <tr >
 *  	<td><br></td>
 *  	<td>Ext_attr3</td>
 *  	<td>拡張属性３</td>
 *  	<td>String</td>
 *  	<td>[{@link mcframe.commonCore.meta.M_META#USR_EXT_ATTR USR_EXT_ATTR}]</td>
 *  	<td><br></td>
 *  </tr>
 * </table>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。
 */
@EI
public class SearchAllR extends SearchAllR_FW {

	/**
	 * 新しいRowを生成します。
	 *
	 * @return 新しいインスタンス
	 */
	public static SearchAllR create() {
		SearchAllR row = new SearchAllR(constMetas);
		return row;
	}

	/**
	 * 新しいRowを生成し別のRowの内容を設定します。
	 *
	 * @param proto 設定するRow
	 * @return 内容を設定した新しいインスタンス
	 */
	public static <T extends MCRow> SearchAllR createByName(T proto) {
		SearchAllR row = SearchAllR.create();
		copyByName(row, proto);
		return row;
	}

	/**
	 * コンストラクタです。
	 */
	public SearchAllR(ConstMetaList<? extends SearchAllR> metas) {
		super(metas);
	}
}