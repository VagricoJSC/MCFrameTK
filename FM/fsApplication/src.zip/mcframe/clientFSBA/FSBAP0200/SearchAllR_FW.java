package mcframe.clientFSBA.FSBAP0200;

import mcframe.commonCore.notice.*;
//FMCB IMPORT START

//FMCB IMPORT END

/**
 * ブロック"SearchAll"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
abstract public class SearchAllR_FW extends SearchAllR_FW_A {

//FMCB CUSTOM_METHOD START
	/**
	 * コンストラクタ
	 */
	protected SearchAllR_FW(ConstMetaList<? extends SearchAllR> metas) {
		super(metas);
	}
	
	@Override
	public void init() {
		super.init();
		UserID(mcframe.commonCore.sys.MCSys.user.ID());
		Locale(mcframe.commonCore.sys.MCSys.user.locale().toString());

		CoCD(mcframe.commonCore.sys.MCSys.user.coCD());
		Ext_attr1(mcframe.commonCore.sys.MCSys.user.extattr1());
		Ext_attr2(mcframe.commonCore.sys.MCSys.user.extattr2());
		Ext_attr3(mcframe.commonCore.sys.MCSys.user.extattr3());
		
	}

}