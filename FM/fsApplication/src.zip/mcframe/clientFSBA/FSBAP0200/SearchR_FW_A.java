package mcframe.clientFSBA.FSBAP0200;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Search"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class SearchR_FW_A extends MCConstRow {

	/**
	 * ユーザＩＤ ユーザＩＤ.<p>
	 *
	 */
	public static final String $UserID = "UserID";
	/**
	 * ロケール ロケール.<p>
	 *
	 */
	public static final String $Locale = "Locale";
	/**
	 * キー キー.<p>
	 *
	 */
	public static final String $Key = "Key";
	/**
	 * 会社ＣＤ 会社ＣＤ.<p>
	 *
	 */
	public static final String $CoCD = "CoCD";
	/**
	 * 拡張属性１ 拡張属性１.<p>
	 *
	 */
	public static final String $Ext_attr1 = "Ext_attr1";
	/**
	 * 拡張属性２ 拡張属性２.<p>
	 *
	 */
	public static final String $Ext_attr2 = "Ext_attr2";
	/**
	 * 拡張属性３ 拡張属性３.<p>
	 *
	 */
	public static final String $Ext_attr3 = "Ext_attr3";


	public static final MCMeta UserID_META = createCommonMeta($UserID, mcframe.commonCore.meta.M_META.USR_ID);
	public static final MCMeta Locale_META = createCommonMeta($Locale, mcframe.commonCore.meta.M_META.LOCALE_CD);
	public static final MCMeta Key_META = createCommonMeta($Key, mcframe.commonCore.meta.M_META.MEMO_KEY);
	public static final MCMeta CoCD_META = createCommonMeta($CoCD, mcframe.commonCore.meta.M_META.CO_CD);
	public static final MCMeta Ext_attr1_META = createCommonMeta($Ext_attr1, mcframe.commonCore.meta.M_META.USR_EXT_ATTR);
	public static final MCMeta Ext_attr2_META = createCommonMeta($Ext_attr2, mcframe.commonCore.meta.M_META.USR_EXT_ATTR);
	public static final MCMeta Ext_attr3_META = createCommonMeta($Ext_attr3, mcframe.commonCore.meta.M_META.USR_EXT_ATTR);

	protected static final ConstMetaList<SearchR> constMetas = new ConstMetaList<SearchR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			UserID_META,
			Locale_META,
			Key_META,
			CoCD_META,
			Ext_attr1_META,
			Ext_attr2_META,
			Ext_attr3_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected SearchR_FW_A(ConstMetaList<? extends SearchR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public SearchR clone() {
		return (SearchR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public SearchR createInstance() {
		return (SearchR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public SearchR getValues(String... names) {
		return (SearchR) super.getValues(names);
	}



	/**
	 * ユーザＩＤ ユーザＩＤ.<p>
	 *
	 */
	public String UserID() {
		return getConstString(offset + 0, $UserID);
	}

	/**
	 * ユーザＩＤ ユーザＩＤ.<p>
	 *
	 */
	public void UserID(String value) {
		setConstString(offset + 0, $UserID, value);
	}


	/**
	 * ロケール ロケール.<p>
	 *
	 */
	public String Locale() {
		return getConstString(offset + 1, $Locale);
	}

	/**
	 * ロケール ロケール.<p>
	 *
	 */
	public void Locale(String value) {
		setConstString(offset + 1, $Locale, value);
	}


	/**
	 * キー キー.<p>
	 *
	 */
	public String Key() {
		return getConstString(offset + 2, $Key);
	}

	/**
	 * キー キー.<p>
	 *
	 */
	public void Key(String value) {
		setConstString(offset + 2, $Key, value);
	}


	/**
	 * 会社ＣＤ 会社ＣＤ.<p>
	 *
	 */
	public String CoCD() {
		return getConstString(offset + 3, $CoCD);
	}

	/**
	 * 会社ＣＤ 会社ＣＤ.<p>
	 *
	 */
	public void CoCD(String value) {
		setConstString(offset + 3, $CoCD, value);
	}


	/**
	 * 拡張属性１ 拡張属性１.<p>
	 *
	 */
	public String Ext_attr1() {
		return getConstString(offset + 4, $Ext_attr1);
	}

	/**
	 * 拡張属性１ 拡張属性１.<p>
	 *
	 */
	public void Ext_attr1(String value) {
		setConstString(offset + 4, $Ext_attr1, value);
	}


	/**
	 * 拡張属性２ 拡張属性２.<p>
	 *
	 */
	public String Ext_attr2() {
		return getConstString(offset + 5, $Ext_attr2);
	}

	/**
	 * 拡張属性２ 拡張属性２.<p>
	 *
	 */
	public void Ext_attr2(String value) {
		setConstString(offset + 5, $Ext_attr2, value);
	}


	/**
	 * 拡張属性３ 拡張属性３.<p>
	 *
	 */
	public String Ext_attr3() {
		return getConstString(offset + 6, $Ext_attr3);
	}

	/**
	 * 拡張属性３ 拡張属性３.<p>
	 *
	 */
	public void Ext_attr3(String value) {
		setConstString(offset + 6, $Ext_attr3, value);
	}


	public String getString(String name) {
		if ($UserID.equalsIgnoreCase(name)) {
			return UserID();
		}
		if ($Locale.equalsIgnoreCase(name)) {
			return Locale();
		}
		if ($Key.equalsIgnoreCase(name)) {
			return Key();
		}
		if ($CoCD.equalsIgnoreCase(name)) {
			return CoCD();
		}
		if ($Ext_attr1.equalsIgnoreCase(name)) {
			return Ext_attr1();
		}
		if ($Ext_attr2.equalsIgnoreCase(name)) {
			return Ext_attr2();
		}
		if ($Ext_attr3.equalsIgnoreCase(name)) {
			return Ext_attr3();
		}
		return super.getString(name);
	}

	public String getStringNE(String name) {
		if ($UserID.equalsIgnoreCase(name)) {
			return UserID();
		}
		if ($Locale.equalsIgnoreCase(name)) {
			return Locale();
		}
		if ($Key.equalsIgnoreCase(name)) {
			return Key();
		}
		if ($CoCD.equalsIgnoreCase(name)) {
			return CoCD();
		}
		if ($Ext_attr1.equalsIgnoreCase(name)) {
			return Ext_attr1();
		}
		if ($Ext_attr2.equalsIgnoreCase(name)) {
			return Ext_attr2();
		}
		if ($Ext_attr3.equalsIgnoreCase(name)) {
			return Ext_attr3();
		}
		return super.getStringNE(name);
	}

	public void setString(String name, String value) {
		if ($UserID.equalsIgnoreCase(name)) {
			UserID(value);
			return;
		}
		if ($Locale.equalsIgnoreCase(name)) {
			Locale(value);
			return;
		}
		if ($Key.equalsIgnoreCase(name)) {
			Key(value);
			return;
		}
		if ($CoCD.equalsIgnoreCase(name)) {
			CoCD(value);
			return;
		}
		if ($Ext_attr1.equalsIgnoreCase(name)) {
			Ext_attr1(value);
			return;
		}
		if ($Ext_attr2.equalsIgnoreCase(name)) {
			Ext_attr2(value);
			return;
		}
		if ($Ext_attr3.equalsIgnoreCase(name)) {
			Ext_attr3(value);
			return;
		}
		super.setString(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($UserID.equalsIgnoreCase(name)) {
			UserID(value);
			return;
		}
		if ($Locale.equalsIgnoreCase(name)) {
			Locale(value);
			return;
		}
		if ($Key.equalsIgnoreCase(name)) {
			Key(value);
			return;
		}
		if ($CoCD.equalsIgnoreCase(name)) {
			CoCD(value);
			return;
		}
		if ($Ext_attr1.equalsIgnoreCase(name)) {
			Ext_attr1(value);
			return;
		}
		if ($Ext_attr2.equalsIgnoreCase(name)) {
			Ext_attr2(value);
			return;
		}
		if ($Ext_attr3.equalsIgnoreCase(name)) {
			Ext_attr3(value);
			return;
		}
		super.setStringNE(name, value);
	}



}

