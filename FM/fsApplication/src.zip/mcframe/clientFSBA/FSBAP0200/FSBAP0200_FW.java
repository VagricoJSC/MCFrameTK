package mcframe.clientFSBA.FSBAP0200;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;


import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START

import mcframe.clientCore.beans.menu.MCMenuBeansUtil;
import mcframe.clientCore.resource.MCMenuItemModel;
import mcframe.clientCore.resource.MCConst;
import mcframe.clientCore.sys.MCSys;
import mcframe.clientFSBC.FSBCP0000.FSBCP0000;
import mcframe.clientFSBC.FSBCP0000.MCActiveMenuListener;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP0200"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP0200_FW extends FSBAP0200_FW_A implements MCActiveMenuListener {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	/**
	 * メモを検索・更新・削除するためのキー
	 */
	protected String key = null;

	/**
	 * 関連するメニュー情報
	 */
	protected MCMenuItemModel _model = null;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0200_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP0200_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * [FS_FSBAL0150_Srch02]の定型処理のInnerClass
	 */
	protected class FS_FSBAL0150_Srch02Caller<P extends FSBAP0200, B extends FS_FSBAL0150_Srch02Bridge>
			extends MCCaller<P, B> {

		protected FS_FSBAL0150_Srch02Caller(P p, B b) {
			super(p, b);
		}
	}

	/**
	 * Panel[Command]のボタン[Update]の押下時の処理
	 */
	@Override
	public void doCommand_Update(MCEventInfo info) {
		doUpdateAction();
	}

	/**
	 * Panel[Command]のボタン[Delete]の押下時の処理
	 */
	@Override
	public void doCommand_Delete(MCEventInfo info) {
		doDeleteAction();
	}

	/**
	 * Panel[Command]のボタン[Refresh]の押下時の処理
	 */
	@Override
	public void doCommand_Refresh(MCEventInfo info) {
		doRefreshAction();
	}

	@Override
	protected void customInit() {
		super.customInit();

		Memo_CommonMemo.setLineWrap(true);
	}

	@Override
	public boolean beforeOpen() {
		boolean e = super.beforeOpen();

		// メモをクライアントにキャッシュする
		doMemoCache();

		return e;
	}

	/**
	 * 対象の ID と名前を設定します。
	 *
	 * @param id ID
	 * @param name 名前
	 */
	public void setTargetName(String id, String name) {
		getLabelR().ID(id);
		getLabelR().Name(name);
	}

	/**
	 * 更新処理を実行します。
	 */
	protected void doUpdateAction() {
		// メモが変更されていない場合
		if (!isMemoChanged()) {
			dialog(FSBAC0030);
			return;
		}

		// 更新確認メッセージ
		if (confirm(getUpdateConfirmMsgId()) != MCMessageBox.YES_OPTION) {
			return;
		}
		// 更新処理
		callUpadate();

		adjustStatus();

		// 更新完了メッセージ
		dialog(getUpdateMsgId());
	}

	/**
	 * 削除処理を実行します。
	 */
	protected void doDeleteAction() {

	}

	/**
	 * メモを再検索します。
	 */
	protected void doRefreshAction() {
		String i = isMemoChanged() ? FSBAC0032 : FSBAC0028;
		// 再取得確認メッセージ
		if (confirm(i) != MCMessageBox.YES_OPTION) {
			return;
		}

		// 最新のメモをキャッシュする
		removeMemoCache();
		doMemoCache();

		// メモを表示する
		showCacheMemo();

		// 再取得完了メッセージ
		dialog(FSBAC0031);
	}

	/**
	 * 共通メモとユーザメモを初期化します。<p>
	 * データベースに格納されている共通メモとユーザメモをクライアントにキャッシュします。
	 * 既にメモがキャッシュされている場合は何もしません。
	 */
	protected void doMemoCache() {
		MCMemoCache uc = MCCache.getInstance().getUserMemoCache();
		MCMemoCache cc = MCCache.getInstance().getCommonMemoCache();
		if (uc.isEmpty() || cc.isEmpty()) {
			SearchAllR r = createSearchAllR();

			if (MCConst.menu.isDbType()) {
				r.CoCD(mcframe.clientCore.sys.MCSys.user.coCD());
				r.Ext_attr1(mcframe.clientCore.sys.MCSys.user.extattr1());
				r.Ext_attr2(mcframe.clientCore.sys.MCSys.user.extattr2());
				r.Ext_attr3(mcframe.clientCore.sys.MCSys.user.extattr3());
			}
			else {
				r.CoCD(null);
				r.Ext_attr1(null);
				r.Ext_attr2(null);
				r.Ext_attr3(null);
			}

			setSearchAllR(r);
			callFS_FSBAL0150_Srch02();

			for (MemoAllR o : getMemoAllL().toArray()) {
				String k = o.Key();
				String u = o.UserID();
				MCTimestamp t = o.getRefTime();
				MCNumber n = o.upd_cntr();
				if (u == null) {
					if (o.Locale() != null) {
						k = createMemoKey(o.Key(), o.Locale());
					}
					cc.put(k, o.CommonMemo(), t, n);
				}
				else {
					uc.put(k, o.UserMemo(), t, n);
				}
			}
		}
	}

	/**
	 * 共通メモとユーザメモのキャッシュをクリアします。
	 */
	protected void removeMemoCache() {
		MCCache.getInstance().getUserMemoCache().clear();
		MCCache.getInstance().getCommonMemoCache().clear();
	}

	/**
	 * キャッシュされている共通メモとユーザメモを表示します。
	 */
	public void showCacheMemo() {
		MCMemoCache c = MCCache.getInstance().getCommonMemoCache();
		MemoR m = getMemoR();
		String tk = createMemoKey(key, MCSys.user.locale().toString());
		String mm = c.getValue(tk);
		if (mm != null) {
			m.CommonMemo(mm);
			m.setRefTime(c.getRefTime(tk));
			m.upd_cntr(c.getUpdCntr(tk));
		}
		else {
			m.CommonMemo(c.getValue(key));
			m.setRefTime(c.getRefTime(key));
			m.upd_cntr(c.getUpdCntr(key));
		}

		Memo_CommonMemo.moveCaretPosition(0);

		adjustStatus();
	}

	/**
	 * メモが変更されている場合は true を返します。
	 *
	 * @return メモが変更されていない場合は false
	 */
	protected boolean isMemoChanged() {
		return CommonMemoPanel.isChanged();
	}

	/**
	 * メモを検索・更新・削除するためのキーを返します。
	 *
	 * @param parts キーの構成要素の文字配列
	 */
	public void setMemoKey(String... parts) {
		key = createMemoKey(parts);
	}

	/**
	 * メモを検索・更新・削除するためのキーを返します。
	 *
	 * @param parts キーの構成要素の文字配列
	 */
	static public String createMemoKey(String... parts) {
		if (parts != null && parts.length > 0) {
			String[] a = new String[parts.length + 1];
			int i = 0;
			for (String s : parts) {
				a[i++] = s;
			}
			a[i] = "memo";
			return mcframe.clientCore.resource.MCConst.createKey(a);
		}
		else {
			return null;
		}
	}

	/**
	 * メモを検索・更新・削除するためのキーを返します。
	 *
	 * @return キー
	 */
	public String getMemoKey() {
		return key;
	}

	/**
	 * 登録時のメッセージIDを返します。
	 *
	 * @return 登録時のメッセージID 
	 */
	public String getUpdateMsgId() {
		return FSBAC0026;
	}

	/**
	 * メニューが選択されたときに実行されます。
	 *
	 * @param model メニューアイテムモデル
	 */
	@Override
	public void menuActive(MCMenuItemModel model) {
		if (isMemoChanged()) {
			if (confirm(FSBAC0029) == MCMessageBox.YES_OPTION) {
				try {
					callUpadate();
					dialog(getUpdateMsgId());
				}
				catch (MCException ex) {
					throw new MCAppException(ex, FSBAC0050);
				}
				finally {
					getMemoR().setStatus(MCRow.NONE);
				}
			}
			getMemoR().setStatus(MCRow.NONE);
		}
		String m = null;
		String s = null;
		String i = null;
		String n = null;
		String k = null;

		if (model != null) {
			_model = model;
			m = model.moduleId();
			s = model.screenId();
		}
		else {
			_model = null;
		}

		// 画面
		if (!MCStringUtil.isNull(m) && !MCStringUtil.isNull(s)) {
			k = MCConst.createKey(m, s);
			n = MCConst.label.getLabel(MCConst.createKey(k, "label"));
			i = s;
			if (!MCStringUtil.isNull(k)) {
				setMemoKey(k);
				setTargetName(i, n);
			}
			else {
				setMemoKey();
				setTargetName(null, null);
			}
		}
		// メニュー
		else {
			if (model != null) {
				if (!MCStringUtil.isNull(model.menuIndex())) {
					k = model.menuIndex();
				}
				else if (!MCConst.menu.isDbType()) {
					k = model.menuPath(".");
				}
				n = model.menuName();
				i = null;
				if (!MCStringUtil.isNull(k)) {
					setMemoKey(k);
				}
				else {
					setMemoKey();
				}
				setTargetName(i, n);
			}
			else {
				setMemoKey();
				setTargetName(null, null);
			}
		}
		showCacheMemo();
	}

	/**
	 * ステータスを調整します。
	 */
	public void adjustStatus() {
		if (key != null) {
			if (getMemoR().getRefTime() != null) {
				setStatus(EDIT);
			}
			else {
				setStatus(INSERT);
			}
		}
		else if (_model != null) {
			setStatus(INSERT);
		}
		else {
			setStatus(NOEDIT);
		}
		getMemoR().setStatus(Status.NONE);
	}

	/**
	 * メモを更新するロジックを呼び出します。
	 * 
	 */
	public void callUpadate() {

	}

	/**
	 * メニューインデックスを更新します。 
	 *
	 */
	public void updateMenuindex() {
		if (getLabelR().ID() == null && MCConst.menu.isDbType()
				&& MCStringUtil.isNull(_model.menuIndex())) {
			try {
				FSBCP0000.removeActiveMenuListener(this);
				MCMenuBeansUtil.updateMenuIndex(_model);
			}
			finally {
				FSBCP0000.addActiveMenuListener(this);
			}
			setMemoKey(_model.menuIndex());
		}
	}

	/**
	 * 登録時の確認ダイアログのメッセージIDを返します。
	 *
	 * @return 登録時のメッセージID 
	 */
	public String getUpdateConfirmMsgId() {
		return FSBAC0022;
	}

}