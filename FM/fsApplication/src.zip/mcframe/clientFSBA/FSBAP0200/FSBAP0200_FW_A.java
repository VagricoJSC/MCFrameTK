package mcframe.clientFSBA.FSBAP0200;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;
import mcframe.clientFSBA.FSBAP0200.FSBAP0200_FW.FS_FSBAL0150_Srch02Caller;

/**
 * 画面"FSBAP0200"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP0200_FW_A extends mcframe.clientFSUC.FSUCP0000.FSUCP_PanelBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0200";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Label]ブロック関連のField定義
	public MCPanel LabelPanel = null;
	// [Label]ブロックの項目のField定義
	/**
	 * メニュー・画面　共通メモ メニュー・画面　共通メモ.<p>
	 *
	 */
	public MCLabel Label_Label = null;
	public MCLabel Label_ID_Label = null;
	/**
	 * 対象ＩＤ 対象ＩＤ.<p>
	 *
	 */
	public MCTextField Label_ID = null;
	public MCLabel Label_Name_Label = null;
	/**
	 * 対象 対象.<p>
	 *
	 */
	public MCTextField Label_Name = null;
	// [Memo]ブロック関連のField定義
	public MCPanel MemoPanel = null;
	// [Memo]ブロックの項目のField定義
	public MCScrollPane Memo_CommonMemoScrollPane = null;
	/**
	 * 共通メモ 共通メモ.<p>
	 *
	 */
	public MCTextArea Memo_CommonMemo = null;
	// [CommonMemo]ブロック関連のField定義
	public MCPanel CommonMemoPanel = null;
	// [CommonMemo]ブロックの項目のField定義
	// [Command]ブロック関連のField定義
	public MCPanel CommandPanel = null;
	// [Command]ブロックの項目のField定義
	/**
	 * 更新 更新する.<p>
	 *
	 */
	public MCButton Command_Update = null;
	/**
	 * 削除 削除する.<p>
	 *
	 */
	public MCButton Command_Delete = null;
	/**
	 * 最新情報を取得 最新情報を取得.<p>
	 *
	 */
	public MCButton Command_Refresh = null;
	// [EastBtn]ブロック関連のField定義
	public MCPanel EastBtnPanel = null;
	// [EastBtn]ブロックの項目のField定義
	/** [EDIT]モードを表す定数 */
	public static final String EDIT = "EDIT";
	/** [INSERT]モードを表す定数 */
	public static final String INSERT = "INSERT";
	/** [NOEDIT]モードを表す定数 */
	public static final String NOEDIT = "NOEDIT";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{EDIT, INSERT, NOEDIT};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	
	/** [FS_FSBAL0150_Srch02]のCallerの作成 */
	protected FSBAP0200_FW.FS_FSBAL0150_Srch02Caller createFS_FSBAL0150_Srch02() {
		FSBAP0200_FW.FS_FSBAL0150_Srch02Caller<FSBAP0200, FS_FSBAL0150_Srch02Bridge>
		caller = ((FSBAP0200_FW)this).new FS_FSBAL0150_Srch02Caller<FSBAP0200, FS_FSBAL0150_Srch02Bridge>(
					(FSBAP0200)this, new FS_FSBAL0150_Srch02Bridge());
		return caller;
	}
	/** [FS_FSBAL0150_Srch02]の呼び出し */
	protected void callFS_FSBAL0150_Srch02() {
		MCCaller caller = createFS_FSBAL0150_Srch02();
		caller.exec();
	}
	/** [Search]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0200.SearchR aSearchR;
	/** [SearchAll]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0200.SearchAllR aSearchAllR;
	/** [Label]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0200.LabelR aLabelR;
	/** [Memo]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0200.MemoR aMemoR;
	/** [MemoAll]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0200.MemoAllR> aMemoAllL;

	/**
	 * 項目コピーによってaSearchRを設定します。
	 *
	 * aSearchRのインスタンスは変更されません。
	 *
	 * @param row SearchR
	 */
	public void setSearchR(mcframe.clientFSBA.FSBAP0200.SearchR row) {
		if (row != null) {
			MCRow.copyall(getSearchR(), row);
		}
	}

	/**
	 * [Search]ブロックのコンテナaSearchRを返します。
	 *
	 * @return SearchR
	 */
	public mcframe.clientFSBA.FSBAP0200.SearchR getSearchR() {
		return aSearchR;
	}

	/**
	 * aSearchRを作成します。
	 *
	 * @return SearchR
	 */
	public mcframe.clientFSBA.FSBAP0200.SearchR createSearchR() {
		return mcframe.clientFSBA.FSBAP0200.SearchR.create();
	}

	/**
	 * 項目コピーによってaSearchAllRを設定します。
	 *
	 * aSearchAllRのインスタンスは変更されません。
	 *
	 * @param row SearchAllR
	 */
	public void setSearchAllR(mcframe.clientFSBA.FSBAP0200.SearchAllR row) {
		if (row != null) {
			MCRow.copyall(getSearchAllR(), row);
		}
	}

	/**
	 * [SearchAll]ブロックのコンテナaSearchAllRを返します。
	 *
	 * @return SearchAllR
	 */
	public mcframe.clientFSBA.FSBAP0200.SearchAllR getSearchAllR() {
		return aSearchAllR;
	}

	/**
	 * aSearchAllRを作成します。
	 *
	 * @return SearchAllR
	 */
	public mcframe.clientFSBA.FSBAP0200.SearchAllR createSearchAllR() {
		return mcframe.clientFSBA.FSBAP0200.SearchAllR.create();
	}

	/**
	 * 項目コピーによってaLabelRを設定します。
	 *
	 * aLabelRのインスタンスは変更されません。
	 *
	 * @param row LabelR
	 */
	public void setLabelR(mcframe.clientFSBA.FSBAP0200.LabelR row) {
		if (row != null) {
			MCRow.copyall(getLabelR(), row);
		}
	}

	/**
	 * [Label]ブロックのコンテナaLabelRを返します。
	 *
	 * @return LabelR
	 */
	public mcframe.clientFSBA.FSBAP0200.LabelR getLabelR() {
		return aLabelR;
	}

	/**
	 * aLabelRを作成します。
	 *
	 * @return LabelR
	 */
	public mcframe.clientFSBA.FSBAP0200.LabelR createLabelR() {
		return mcframe.clientFSBA.FSBAP0200.LabelR.create();
	}

	/**
	 * 項目コピーによってaMemoRを設定します。
	 *
	 * aMemoRのインスタンスは変更されません。
	 *
	 * @param row MemoR
	 */
	public void setMemoR(mcframe.clientFSBA.FSBAP0200.MemoR row) {
		if (row != null) {
			MCRow.copyall(getMemoR(), row);
		}
	}

	/**
	 * [Memo]ブロックのコンテナaMemoRを返します。
	 *
	 * @return MemoR
	 */
	public mcframe.clientFSBA.FSBAP0200.MemoR getMemoR() {
		return aMemoR;
	}

	/**
	 * aMemoRを作成します。
	 *
	 * @return MemoR
	 */
	public mcframe.clientFSBA.FSBAP0200.MemoR createMemoR() {
		return mcframe.clientFSBA.FSBAP0200.MemoR.create();
	}

	/**
	 * コピーによってaMemoAllLを設定します。
	 *
	 * aMemoAllLのインスタンスは変更されません。
	 *
	 * @param dataset MemoAllL
	 */
	public void setMemoAllL(MCList<mcframe.clientFSBA.FSBAP0200.MemoAllR> aList) {
		if (getMemoAllL() != aList) {
			getMemoAllL().setAll(aList);
		}
	}

	/**
	 * [MemoAll]ブロックのコンテナaMemoAllLを返します。
	 *
	 * @return MemoAllL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0200.MemoAllR> getMemoAllL() {
		return aMemoAllL;
	}

	/**
	 * aMemoAllRを作成します。
	 *
	 * @return MemoAllR
	 */
	public mcframe.clientFSBA.FSBAP0200.MemoAllR createMemoAllR() {
		return mcframe.clientFSBA.FSBAP0200.MemoAllR.create();
	}

	/**
	 * aMemoAllLを作成します。
	 *
	 * @return MemoAllL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0200.MemoAllR> createMemoAllL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0200.MemoAllR.class);
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getSearchR())) ret.add(getSearchR());
		if(!MCCollectionUtil.contains(ret, getSearchAllR())) ret.add(getSearchAllR());
		if(!MCCollectionUtil.contains(ret, getLabelR())) ret.add(getLabelR());
		if(!MCCollectionUtil.contains(ret, getMemoR())) ret.add(getMemoR());
		if(!MCCollectionUtil.contains(ret, getMemoAllL())) ret.add(getMemoAllL());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getSearchR()) return "Search";
		if(aCnt == getSearchAllR()) return "SearchAll";
		if(aCnt == getLabelR()) return "Label";
		if(aCnt == getMemoR()) return "Memo";
		if(aCnt == getMemoAllL()) return "MemoAll";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("Search")) return getSearchR();
		if(bId.equals("SearchAll")) return getSearchAllR();
		if(bId.equals("Label")) return getLabelR();
		if(bId.equals("Memo")) return getMemoR();
		if(bId.equals("MemoAll")) return getMemoAllL();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(LabelPanel);
		ret.add(MemoPanel);
		ret.add(CommonMemoPanel);
		ret.add(CommandPanel);
		ret.add(EastBtnPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0200_FW_A() {
		aSearchR = createSearchR();
		aSearchAllR = createSearchAllR();
		aLabelR = createLabelR();
		aMemoR = createMemoR();
		aMemoAllL = createMemoAllL();

	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP0200_FW_A(String name) {
		aSearchR = createSearchR();
		aSearchAllR = createSearchAllR();
		aLabelR = createLabelR();
		aMemoR = createMemoR();
		aMemoAllL = createMemoAllL();
	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP0200_FW.jbCreateLabel((FSBAP0200)this);
		FSBAP0200_FW.jbCreateMemo((FSBAP0200)this);
		FSBAP0200_FW.jbCreateCommonMemo((FSBAP0200)this);
		FSBAP0200_FW.jbCreateCommand((FSBAP0200)this);
		FSBAP0200_FW.jbCreateEastBtn((FSBAP0200)this);
	}

	/**
	 * [Label]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateLabel(FSBAP0200 p) {
	}

	/**
	 * [Memo]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateMemo(FSBAP0200 p) {
	}

	/**
	 * [CommonMemo]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateCommonMemo(FSBAP0200 p) {
	}

	/**
	 * [Command]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateCommand(FSBAP0200 p) {
	}

	/**
	 * [EastBtn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateEastBtn(FSBAP0200 p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}


	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP0200 create(){
		FSBAP0200 p = new FSBAP0200();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP0200 create(String name){
		FSBAP0200 p = new FSBAP0200(name);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP0200_FW.jbfInitLabel((FSBAP0200)this);
		FSBAP0200_FW.jbfInitMemo((FSBAP0200)this);
		FSBAP0200_FW.jbfInitCommonMemo((FSBAP0200)this);
		FSBAP0200_FW.jbfInitCommand((FSBAP0200)this);
		FSBAP0200_FW.jbfInitEastBtn((FSBAP0200)this);
		FSBAP0200_FW.jbInitLabel((FSBAP0200)this);
		FSBAP0200_FW.jbInitMemo((FSBAP0200)this);
		FSBAP0200_FW.jbInitCommonMemo((FSBAP0200)this);
		FSBAP0200_FW.jbInitCommand((FSBAP0200)this);
		FSBAP0200_FW.jbInitEastBtn((FSBAP0200)this);
	}

	/**
	 * [Label]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitLabel(FSBAP0200 p) {
		// ブロック関連の初期化
		p.LabelPanel = p.beansFactory.createPanel("Label");
		// ブロックの項目の初期化
		p.Label_Label = p.beansFactory.createLabel("Label.Label");
		p.Label_ID_Label = p.beansFactory.createLabel("Label.ID_Label");
		p.Label_ID = p.beansFactory.createTextField("Label.ID");
		p.Label_ID.setLabel(p.Label_ID_Label);
		p.Label_Name_Label = p.beansFactory.createLabel("Label.Name_Label");
		p.Label_Name = p.beansFactory.createTextField("Label.Name");
		p.Label_Name.setLabel(p.Label_Name_Label);
	}

	/**
	 * [Memo]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitMemo(FSBAP0200 p) {
		// ブロック関連の初期化
		p.MemoPanel = p.beansFactory.createPanel("Memo");
		// ブロックの項目の初期化
		p.Memo_CommonMemoScrollPane = p.beansFactory.createScrollPane("Memo.CommonMemoscroll");
		p.Memo_CommonMemo = p.beansFactory.createTextArea("Memo.CommonMemo");
	}

	/**
	 * [CommonMemo]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitCommonMemo(FSBAP0200 p) {
		// ブロック関連の初期化
		p.CommonMemoPanel = p.beansFactory.createPanel("CommonMemo");
		// ブロックの項目の初期化
	}

	/**
	 * [Command]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitCommand(FSBAP0200 p) {
		// ブロック関連の初期化
		p.CommandPanel = p.beansFactory.createPanel("Command");
		// ブロックの項目の初期化
		p.Command_Update = p.beansFactory.createButton("Command.Update", "upd");
		p.Command_Delete = p.beansFactory.createButton("Command.Delete", "del");
		p.Command_Refresh = p.beansFactory.createButton("Command.Refresh", "no_border");
	}

	/**
	 * [EastBtn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitEastBtn(FSBAP0200 p) {
		// ブロック関連の初期化
		p.EastBtnPanel = p.beansFactory.createPanel("EastBtn");
		// ブロックの項目の初期化
	}

	/**
	 * [Label]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitLabel(FSBAP0200 p) {
		// ブロック関連の初期化
		p.add(p.LabelPanel);
		p.setLastBeans(p.LabelPanel);
		p.LabelPanel.setNextBeans(p.MemoPanel);
		p.LabelPanel.setLayoutPosition("N");
		// ブロックの項目の初期化
		p.LabelPanel.add(p.Label_Label);
		p.LabelPanel.add(p.Label_ID_Label);
		p.LabelPanel.add(p.Label_ID);
		p.LabelPanel.setLastBeans(p.Label_ID);
		p.Label_ID.setNextBeans(p.Label_Name);
		p.Label_ID.setRow(p.getLabelR(), mcframe.clientFSBA.FSBAP0200.LabelR.ID_META);
		p.LabelPanel.add(p.Label_Name_Label);
		p.LabelPanel.add(p.Label_Name);
		p.Label_Name.setRow(p.getLabelR(), mcframe.clientFSBA.FSBAP0200.LabelR.Name_META);
	}

	/**
	 * [Memo]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitMemo(FSBAP0200 p) {
		// ブロック関連の初期化
		p.add(p.MemoPanel);
		p.MemoPanel.setNextBeans(p.CommonMemoPanel);
		// ブロックの項目の初期化
		p.Memo_CommonMemoScrollPane.getViewport().add(p.Memo_CommonMemo);
		p.CommonMemoPanel.add(p.Memo_CommonMemoScrollPane);
		p.CommonMemoPanel.setLastBeans(p.Memo_CommonMemo);
		p.Memo_CommonMemo.setRow(p.getMemoR(), mcframe.clientFSBA.FSBAP0200.MemoR.CommonMemo_META);
	}

	/**
	 * [CommonMemo]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitCommonMemo(FSBAP0200 p) {
		// ブロック関連の初期化
		p.add(p.CommonMemoPanel);
		p.CommonMemoPanel.setNextBeans(p.CommandPanel);
		p.CommonMemoPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
	}

	/**
	 * [Command]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitCommand(FSBAP0200 p) {
		// ブロック関連の初期化
		p.add(p.CommandPanel);
		p.CommandPanel.setNextBeans(p.EastBtnPanel);
		p.CommandPanel.setLayoutPosition("SW");
		// ブロックの項目の初期化
		p.Command_Update.setIcon("REGISTER");
		p.Command_Update.setFunctionKey(MCFunctionKey.F9);
		p.CommandPanel.add(p.Command_Update);
		p.CommandPanel.setLastBeans(p.Command_Update);
		p.Command_Update.setNextBeans(p.Command_Refresh);
		p.Command_Delete.setIcon("DELETE");
		p.Command_Delete.setFunctionKey(MCFunctionKey.F12);
		p.EastBtnPanel.setLastBeans(p.Command_Delete);
		p.EastBtnPanel.add(p.Command_Delete);
		p.Command_Refresh.setIcon("RELOAD");
		p.Command_Refresh.setFunctionKey(MCFunctionKey.F7);
		p.CommandPanel.add(p.Command_Refresh);
	}

	/**
	 * [EastBtn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitEastBtn(FSBAP0200 p) {
		// ブロック関連の初期化
		p.add(p.EastBtnPanel);
		p.EastBtnPanel.setLayoutPosition("SE");
		// ブロックの項目の初期化
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "S";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP0200_FW.mcInitLabel((FSBAP0200)this);
		FSBAP0200_FW.mcInitMemo((FSBAP0200)this);
		FSBAP0200_FW.mcInitCommonMemo((FSBAP0200)this);
		FSBAP0200_FW.mcInitCommand((FSBAP0200)this);
		FSBAP0200_FW.mcInitEastBtn((FSBAP0200)this);

		// [EDIT]ステータスのモードの設定
		FSBAP0200_FW.statusInitEDIT_Search((FSBAP0200)this);
		FSBAP0200_FW.statusInitEDIT_SearchAll((FSBAP0200)this);
		FSBAP0200_FW.statusInitEDIT_Label((FSBAP0200)this);
		FSBAP0200_FW.statusInitEDIT_Memo((FSBAP0200)this);
		FSBAP0200_FW.statusInitEDIT_CommonMemo((FSBAP0200)this);
		FSBAP0200_FW.statusInitEDIT_Command((FSBAP0200)this);
		FSBAP0200_FW.statusInitEDIT_EastBtn((FSBAP0200)this);
		FSBAP0200_FW.statusInitEDIT_MemoAll((FSBAP0200)this);

		// [INSERT]ステータスのモードの設定
		FSBAP0200_FW.statusInitINSERT_Search((FSBAP0200)this);
		FSBAP0200_FW.statusInitINSERT_SearchAll((FSBAP0200)this);
		FSBAP0200_FW.statusInitINSERT_Label((FSBAP0200)this);
		FSBAP0200_FW.statusInitINSERT_Memo((FSBAP0200)this);
		FSBAP0200_FW.statusInitINSERT_CommonMemo((FSBAP0200)this);
		FSBAP0200_FW.statusInitINSERT_Command((FSBAP0200)this);
		FSBAP0200_FW.statusInitINSERT_EastBtn((FSBAP0200)this);
		FSBAP0200_FW.statusInitINSERT_MemoAll((FSBAP0200)this);

		// [NOEDIT]ステータスのモードの設定
		FSBAP0200_FW.statusInitNOEDIT_Search((FSBAP0200)this);
		FSBAP0200_FW.statusInitNOEDIT_SearchAll((FSBAP0200)this);
		FSBAP0200_FW.statusInitNOEDIT_Label((FSBAP0200)this);
		FSBAP0200_FW.statusInitNOEDIT_Memo((FSBAP0200)this);
		FSBAP0200_FW.statusInitNOEDIT_CommonMemo((FSBAP0200)this);
		FSBAP0200_FW.statusInitNOEDIT_Command((FSBAP0200)this);
		FSBAP0200_FW.statusInitNOEDIT_EastBtn((FSBAP0200)this);
		FSBAP0200_FW.statusInitNOEDIT_MemoAll((FSBAP0200)this);

	}

	/**
	 *  [Label]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitLabel(FSBAP0200 p) {
		p.Label_ID.setListListener(p);
		p.Label_ID.addAllListener(p);
		p.Label_Name.setListListener(p);
		p.Label_Name.addAllListener(p);
	}

	/**
	 *  [Memo]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitMemo(FSBAP0200 p) {
		p.Memo_CommonMemo.addAllListener(p);
	}

	/**
	 *  [CommonMemo]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitCommonMemo(FSBAP0200 p) {
	}

	/**
	 *  [Command]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitCommand(FSBAP0200 p) {
		p.Command_Update.addAllListener(p);
		p.Command_Update.setAPMethodName("doCommand_Update");
		p.Command_Delete.addAllListener(p);
		p.Command_Delete.setAPMethodName("doCommand_Delete");
		p.Command_Refresh.addAllListener(p);
		p.Command_Refresh.setAPMethodName("doCommand_Refresh");
	}

	/**
	 *  [EastBtn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitEastBtn(FSBAP0200 p) {
	}

	/**
	 * [EDIT]ステータスの[Search]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_Search(FSBAP0200 p){

	}

	/**
	 * [EDIT]ステータスの[SearchAll]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_SearchAll(FSBAP0200 p){

	}

	/**
	 * [EDIT]ステータスの[Label]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_Label(FSBAP0200 p){
		p.Label_ID.putMode(p, EDIT, MCMode.READ_ONLY);
		p.Label_Name.putMode(p, EDIT, MCMode.READ_ONLY);

	}

	/**
	 * [EDIT]ステータスの[Memo]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_Memo(FSBAP0200 p){
		p.Memo_CommonMemo.putMode(p, EDIT, MCMode.ENABLE);

	}

	/**
	 * [EDIT]ステータスの[CommonMemo]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_CommonMemo(FSBAP0200 p){

	}

	/**
	 * [EDIT]ステータスの[Command]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_Command(FSBAP0200 p){
		p.Command_Update.putMode(p, EDIT, MCMode.ENABLE);
		p.Command_Delete.putMode(p, EDIT, MCMode.ENABLE);
		p.Command_Refresh.putMode(p, EDIT, MCMode.ENABLE);

	}

	/**
	 * [EDIT]ステータスの[EastBtn]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_EastBtn(FSBAP0200 p){

	}

	/**
	 * [EDIT]ステータスの[MemoAll]ブロックのモードの設定
	 */
	protected static void statusInitEDIT_MemoAll(FSBAP0200 p){

	}

	/**
	 * [INSERT]ステータスの[Search]ブロックのモードの設定
	 */
	protected static void statusInitINSERT_Search(FSBAP0200 p){

	}

	/**
	 * [INSERT]ステータスの[SearchAll]ブロックのモードの設定
	 */
	protected static void statusInitINSERT_SearchAll(FSBAP0200 p){

	}

	/**
	 * [INSERT]ステータスの[Label]ブロックのモードの設定
	 */
	protected static void statusInitINSERT_Label(FSBAP0200 p){
		p.Label_ID.putMode(p, INSERT, MCMode.READ_ONLY);
		p.Label_Name.putMode(p, INSERT, MCMode.READ_ONLY);

	}

	/**
	 * [INSERT]ステータスの[Memo]ブロックのモードの設定
	 */
	protected static void statusInitINSERT_Memo(FSBAP0200 p){
		p.Memo_CommonMemo.putMode(p, INSERT, MCMode.ENABLE);

	}

	/**
	 * [INSERT]ステータスの[CommonMemo]ブロックのモードの設定
	 */
	protected static void statusInitINSERT_CommonMemo(FSBAP0200 p){

	}

	/**
	 * [INSERT]ステータスの[Command]ブロックのモードの設定
	 */
	protected static void statusInitINSERT_Command(FSBAP0200 p){
		p.Command_Update.putMode(p, INSERT, MCMode.ENABLE);
		p.Command_Delete.putMode(p, INSERT, MCMode.DISABLE);
		p.Command_Refresh.putMode(p, INSERT, MCMode.ENABLE);

	}

	/**
	 * [INSERT]ステータスの[EastBtn]ブロックのモードの設定
	 */
	protected static void statusInitINSERT_EastBtn(FSBAP0200 p){

	}

	/**
	 * [INSERT]ステータスの[MemoAll]ブロックのモードの設定
	 */
	protected static void statusInitINSERT_MemoAll(FSBAP0200 p){

	}

	/**
	 * [NOEDIT]ステータスの[Search]ブロックのモードの設定
	 */
	protected static void statusInitNOEDIT_Search(FSBAP0200 p){

	}

	/**
	 * [NOEDIT]ステータスの[SearchAll]ブロックのモードの設定
	 */
	protected static void statusInitNOEDIT_SearchAll(FSBAP0200 p){

	}

	/**
	 * [NOEDIT]ステータスの[Label]ブロックのモードの設定
	 */
	protected static void statusInitNOEDIT_Label(FSBAP0200 p){
		p.Label_ID.putMode(p, NOEDIT, MCMode.READ_ONLY);
		p.Label_Name.putMode(p, NOEDIT, MCMode.READ_ONLY);

	}

	/**
	 * [NOEDIT]ステータスの[Memo]ブロックのモードの設定
	 */
	protected static void statusInitNOEDIT_Memo(FSBAP0200 p){
		p.Memo_CommonMemo.putMode(p, NOEDIT, MCMode.READ_ONLY);

	}

	/**
	 * [NOEDIT]ステータスの[CommonMemo]ブロックのモードの設定
	 */
	protected static void statusInitNOEDIT_CommonMemo(FSBAP0200 p){

	}

	/**
	 * [NOEDIT]ステータスの[Command]ブロックのモードの設定
	 */
	protected static void statusInitNOEDIT_Command(FSBAP0200 p){
		p.Command_Update.putMode(p, NOEDIT, MCMode.DISABLE);
		p.Command_Delete.putMode(p, NOEDIT, MCMode.DISABLE);
		p.Command_Refresh.putMode(p, NOEDIT, MCMode.DISABLE);

	}

	/**
	 * [NOEDIT]ステータスの[EastBtn]ブロックのモードの設定
	 */
	protected static void statusInitNOEDIT_EastBtn(FSBAP0200 p){

	}

	/**
	 * [NOEDIT]ステータスの[MemoAll]ブロックのモードの設定
	 */
	protected static void statusInitNOEDIT_MemoAll(FSBAP0200 p){

	}

	/**
	 * Table/Treeの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
	}

	/**
	 * この画面を[EDIT]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setEDITStatus() {
		status = EDIT;
		setAllStatus(status);
	}

	/**
	 * この画面を[INSERT]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setINSERTStatus() {
		status = INSERT;
		setAllStatus(status);
	}

	/**
	 * この画面を[NOEDIT]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setNOEDITStatus() {
		status = NOEDIT;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (EDIT.equals(status)) {
			setEDITStatus();
		}
		else if (INSERT.equals(status)) {
			setINSERTStatus();
		}
		else if (NOEDIT.equals(status)) {
			setNOEDITStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}


	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == Command_Update) doCommand_Update(info);
		else if (ap == Command_Delete) doCommand_Delete(info);
		else if (ap == Command_Refresh) doCommand_Refresh(info);
	}

	/**
	 * [Command]パネルの[Update]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doCommand_Update(MCEventInfo info);

	/**
	 * [Command]パネルの[Delete]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doCommand_Delete(MCEventInfo info);

	/**
	 * [Command]パネルの[Refresh]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doCommand_Refresh(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == Label_ID) return doLabel_ID_VC(info);
		if (vc == Label_Name) return doLabel_Name_VC(info);
		if (vc == Memo_CommonMemo) return doMemo_CommonMemo_VC(info);
		return true;
	}

	/**
	 * [Label]パネルの[ID]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doLabel_ID_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Label]パネルの[Name]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doLabel_Name_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Memo]パネルの[CommonMemo]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMemo_CommonMemo_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == Label_ID) doLabel_ID_NC(info);
		else if (nc == Label_Name) doLabel_Name_NC(info);
		else if (nc == Memo_CommonMemo) doMemo_CommonMemo_NC(info);
	}

	/**
	 * [Label]パネルの[ID]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doLabel_ID_NC(MCEventInfo info){
	}

	/**
	 * [Label]パネルの[Name]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doLabel_Name_NC(MCEventInfo info){
	}

	/**
	 * [Memo]パネルの[CommonMemo]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMemo_CommonMemo_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == Label_ID) doLabel_ID_NE(info);
		else if (ne == Label_Name) doLabel_Name_NE(info);
		else if (ne == Memo_CommonMemo) doMemo_CommonMemo_NE(info);
	}

	/**
	 * [Label]パネルの[ID]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doLabel_ID_NE(MCEventInfo info){
	}

	/**
	 * [Label]パネルの[Name]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doLabel_Name_NE(MCEventInfo info){
	}

	/**
	 * [Memo]パネルの[CommonMemo]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMemo_CommonMemo_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == Label_ID) doLabel_ID_NX(info);
		else if (nx == Label_Name) doLabel_Name_NX(info);
		else if (nx == Memo_CommonMemo) doMemo_CommonMemo_NX(info);
	}

	/**
	 * [Label]パネルの[ID]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doLabel_ID_NX(MCEventInfo info){
	}

	/**
	 * [Label]パネルの[Name]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doLabel_Name_NX(MCEventInfo info){
	}

	/**
	 * [Memo]パネルの[CommonMemo]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMemo_CommonMemo_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == Label_ID) doLabel_ID_LC(info);
		else if (lc == Label_Name) doLabel_Name_LC(info);
	}

	/**
	 * [Label]パネルの[ID]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doLabel_ID_LC(MCEventInfo info){
	}

	/**
	 * [Label]パネルの[Name]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doLabel_Name_LC(MCEventInfo info){
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		if (id.equals("FS.FSBAL0150.Srch02")) {
			return new FS_FSBAL0150_Srch02Bridge();
		}
		return super.createBridge(id);
	}
	/**
	 * [FS_FSBAL0150_Srch02]の定型処理のInnerClass
	 */
	protected class FS_FSBAL0150_Srch02Bridge extends MCCallerPanelBridge {
		/**
		 * 電文パラメータ<p>
		 * 
		 * 参照する場合には{@link #param()}を使用してください。
		 */
		MCParam p_FS_FSBAL0150_Srch02;

		/** コンストラクタ */
		protected FS_FSBAL0150_Srch02Bridge() {
			p_FS_FSBAL0150_Srch02 = new MCParam(PDef.FS_FSBAL0150_Srch02_INFO);
		}

		@Override
		public MCParam createAsyncParam() {
			MCParam param = new MCParam(PDef.FS_FSBAL0150_Srch02_INFO);
			param.setReqSrcId(getScreenID());
			// Up
			param.addUpBlock(mcframe.clientFSBA.FSBAP0200.SearchAllR.create());
			// Down
			param.addDownBlock(MCList.create(mcframe.clientFSBA.FSBAP0200.MemoAllR.class));

			p_FS_FSBAL0150_Srch02 = param;
			return param;
		}

		/** パラメータを通信用に設定します。*/
		protected void setupParam() {
			p_FS_FSBAL0150_Srch02.setReqSrcId(getScreenID());
			setupUpParam();
			setupDownParam();
		}

		protected void setupUpParam() {
			p_FS_FSBAL0150_Srch02.addUpBlock(getSearchAllR());
		}

		protected MCContainer up(int i) {
			return p_FS_FSBAL0150_Srch02.getContainerParam().getUpBlock(i);
		}
		
		protected MCContainer down(int i) {
			return p_FS_FSBAL0150_Srch02.getContainerParam().getDownBlock(i);
		}
		
		protected mcframe.clientFSBA.FSBAP0200.SearchAllR up0() {
			return (mcframe.clientFSBA.FSBAP0200.SearchAllR)up(0);
		}

		protected MCList<mcframe.clientFSBA.FSBAP0200.MemoAllR> down0() {
			return (MCList<mcframe.clientFSBA.FSBAP0200.MemoAllR>)down(0);
		}

		protected void setupDownParam() {
			p_FS_FSBAL0150_Srch02.addDownBlock(MCList.create(mcframe.clientFSBA.FSBAP0200.MemoAllR.class));
		}
		protected MCParam param() {
			return p_FS_FSBAL0150_Srch02;
		}

		protected void show() {
			setMemoAllL((MCList<mcframe.clientFSBA.FSBAP0200.MemoAllR>)p_FS_FSBAL0150_Srch02.getContainerParam().getDownBlock(0));
		}

		protected void clear() {
			getMemoAllL().clear();
		}
		
		protected List<MCContainer> getUpBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getSearchAllR());
			return result;
		}
		
		protected List<MCContainer> getDownBlocks() {
			List<MCContainer> result = new ArrayList<MCContainer>();
			result.add(getMemoAllL());
			return result;
		}
	}
}