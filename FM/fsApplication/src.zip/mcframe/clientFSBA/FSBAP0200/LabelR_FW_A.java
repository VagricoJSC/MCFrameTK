package mcframe.clientFSBA.FSBAP0200;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Label"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class LabelR_FW_A extends MCConstRow {

	/**
	 * 対象ＩＤ 対象ＩＤ.<p>
	 *
	 */
	public static final String $ID = "ID";
	/**
	 * 対象 対象.<p>
	 *
	 */
	public static final String $Name = "Name";


	public static final MCMeta ID_META = createStringMeta($ID, 4000);
	public static final MCMeta Name_META = createStringMeta($Name, 4000);

	protected static final ConstMetaList<LabelR> constMetas = new ConstMetaList<LabelR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			ID_META,
			Name_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected LabelR_FW_A(ConstMetaList<? extends LabelR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public LabelR clone() {
		return (LabelR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public LabelR createInstance() {
		return (LabelR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public LabelR getValues(String... names) {
		return (LabelR) super.getValues(names);
	}



	/**
	 * 対象ＩＤ 対象ＩＤ.<p>
	 *
	 */
	public String ID() {
		return getConstString(offset + 0, $ID);
	}

	/**
	 * 対象ＩＤ 対象ＩＤ.<p>
	 *
	 */
	public void ID(String value) {
		setConstString(offset + 0, $ID, value);
	}


	/**
	 * 対象 対象.<p>
	 *
	 */
	public String Name() {
		return getConstString(offset + 1, $Name);
	}

	/**
	 * 対象 対象.<p>
	 *
	 */
	public void Name(String value) {
		setConstString(offset + 1, $Name, value);
	}


	public String getString(String name) {
		if ($ID.equalsIgnoreCase(name)) {
			return ID();
		}
		if ($Name.equalsIgnoreCase(name)) {
			return Name();
		}
		return super.getString(name);
	}

	public String getStringNE(String name) {
		if ($ID.equalsIgnoreCase(name)) {
			return ID();
		}
		if ($Name.equalsIgnoreCase(name)) {
			return Name();
		}
		return super.getStringNE(name);
	}

	public void setString(String name, String value) {
		if ($ID.equalsIgnoreCase(name)) {
			ID(value);
			return;
		}
		if ($Name.equalsIgnoreCase(name)) {
			Name(value);
			return;
		}
		super.setString(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($ID.equalsIgnoreCase(name)) {
			ID(value);
			return;
		}
		if ($Name.equalsIgnoreCase(name)) {
			Name(value);
			return;
		}
		super.setStringNE(name, value);
	}



}

