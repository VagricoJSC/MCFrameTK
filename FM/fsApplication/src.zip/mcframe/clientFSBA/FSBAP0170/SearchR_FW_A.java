package mcframe.clientFSBA.FSBAP0170;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Search"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class SearchR_FW_A extends MCConstRow {

	/**
	 * モジュールＩＤ モジュールＩＤ.<p>
	 *
	 */
	public static final String $ModuleID = "ModuleID";
	/**
	 * モジュール名 モジュール名.<p>
	 *
	 */
	public static final String $ModuleName = "ModuleName";
	/**
	 * 画面ＩＤ 画面ＩＤ.<p>
	 *
	 */
	public static final String $ScreenID = "ScreenID";
	/**
	 * 画面名 画面名.<p>
	 *
	 */
	public static final String $ScreenName = "ScreenName";


	public static final MCMeta ModuleID_META = createCommonMeta($ModuleID, mcframe.commonCore.meta.M_META.MODULE_ID);
	public static final MCMeta ModuleName_META = createCommonMeta($ModuleName, mcframe.commonCore.meta.M_META.MODULE_ID_NM);
	public static final MCMeta ScreenID_META = createCommonMeta($ScreenID, mcframe.commonCore.meta.M_META.SCREEN_ID);
	public static final MCMeta ScreenName_META = createCommonMeta($ScreenName, mcframe.commonCore.meta.M_META.SCREEN_NAME);

	protected static final ConstMetaList<SearchR> constMetas = new ConstMetaList<SearchR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			ModuleID_META,
			ModuleName_META,
			ScreenID_META,
			ScreenName_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected SearchR_FW_A(ConstMetaList<? extends SearchR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public SearchR clone() {
		return (SearchR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public SearchR createInstance() {
		return (SearchR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public SearchR getValues(String... names) {
		return (SearchR) super.getValues(names);
	}



	/**
	 * モジュールＩＤ モジュールＩＤ.<p>
	 *
	 */
	public String ModuleID() {
		return getConstString(offset + 0, $ModuleID);
	}

	/**
	 * モジュールＩＤ モジュールＩＤ.<p>
	 *
	 */
	public void ModuleID(String value) {
		setConstString(offset + 0, $ModuleID, value);
	}


	/**
	 * モジュール名 モジュール名.<p>
	 *
	 */
	public String ModuleName() {
		return getConstString(offset + 1, $ModuleName);
	}

	/**
	 * モジュール名 モジュール名.<p>
	 *
	 */
	public void ModuleName(String value) {
		setConstString(offset + 1, $ModuleName, value);
	}


	/**
	 * 画面ＩＤ 画面ＩＤ.<p>
	 *
	 */
	public String ScreenID() {
		return getConstString(offset + 2, $ScreenID);
	}

	/**
	 * 画面ＩＤ 画面ＩＤ.<p>
	 *
	 */
	public void ScreenID(String value) {
		setConstString(offset + 2, $ScreenID, value);
	}


	/**
	 * 画面名 画面名.<p>
	 *
	 */
	public String ScreenName() {
		return getConstString(offset + 3, $ScreenName);
	}

	/**
	 * 画面名 画面名.<p>
	 *
	 */
	public void ScreenName(String value) {
		setConstString(offset + 3, $ScreenName, value);
	}


	public String getString(String name) {
		if ($ModuleID.equalsIgnoreCase(name)) {
			return ModuleID();
		}
		if ($ModuleName.equalsIgnoreCase(name)) {
			return ModuleName();
		}
		if ($ScreenID.equalsIgnoreCase(name)) {
			return ScreenID();
		}
		if ($ScreenName.equalsIgnoreCase(name)) {
			return ScreenName();
		}
		return super.getString(name);
	}

	public String getStringNE(String name) {
		if ($ModuleID.equalsIgnoreCase(name)) {
			return ModuleID();
		}
		if ($ModuleName.equalsIgnoreCase(name)) {
			return ModuleName();
		}
		if ($ScreenID.equalsIgnoreCase(name)) {
			return ScreenID();
		}
		if ($ScreenName.equalsIgnoreCase(name)) {
			return ScreenName();
		}
		return super.getStringNE(name);
	}

	public void setString(String name, String value) {
		if ($ModuleID.equalsIgnoreCase(name)) {
			ModuleID(value);
			return;
		}
		if ($ModuleName.equalsIgnoreCase(name)) {
			ModuleName(value);
			return;
		}
		if ($ScreenID.equalsIgnoreCase(name)) {
			ScreenID(value);
			return;
		}
		if ($ScreenName.equalsIgnoreCase(name)) {
			ScreenName(value);
			return;
		}
		super.setString(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($ModuleID.equalsIgnoreCase(name)) {
			ModuleID(value);
			return;
		}
		if ($ModuleName.equalsIgnoreCase(name)) {
			ModuleName(value);
			return;
		}
		if ($ScreenID.equalsIgnoreCase(name)) {
			ScreenID(value);
			return;
		}
		if ($ScreenName.equalsIgnoreCase(name)) {
			ScreenName(value);
			return;
		}
		super.setStringNE(name, value);
	}



}

