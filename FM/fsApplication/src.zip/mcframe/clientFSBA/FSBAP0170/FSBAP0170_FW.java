package mcframe.clientFSBA.FSBAP0170;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;

import mcframe.clientFSBA.FSBAP0350.*;

import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START

import mcframe.clientCore.resource.MCConst;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP0170"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP0170_FW extends FSBAP0170_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0170_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP0170_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * Panel[Search]のボタン[Search]の押下時の処理
	 */
	@Override
	public void doSearch_Search(MCEventInfo info) {
		// メモが入力中の場合
		// クリア確認処理を実行する
		if (isMemoChanged()) {
			if (!clearMemoConfirm()) {
				return;
			}
		}
		
		// 検索処理を実行する
		MCList<ListR> l = doSearch();
		setListL(l);

		// 検索結果が 0 件の場合
		// ダイアログを表示する
		if (l.size() == 0) {
			dialog(FCBAC0099);
		}
		
		// 検索の後処理を実行する
		sort(ListTable);
		ListTable.adjustWidth();
		
		if (l.size() != 0) {
			ListTable.selectLeftmostColumn(0);
		} else {
			mcInitStatus();
		}
	}

	@Override
	protected void valueInit() {
		super.valueInit();
		getSearch_ModuleID(MCRow.create(), Search_ModuleID.getEventInfo());
		getSearch_ScreenID(MCRow.create(), Search_ScreenID.getEventInfo());
	}
	
	@Override
	protected void setSortColumn() {
		super.setSortColumn();
		
		ListTable.addSortColumn(columnList_ScreenID, SortType.ASC);
	}
	
	@Override
	protected void listInit() {
		super.listInit();
		
		Search_ModuleID.setListVisibleColumn("module_id", "module_nm");
		Search_ScreenID.setListVisibleColumn("screen_id", "screen_nm");
		
		getSearch_ModuleID_ListPutter().setColumns("module_id", "module_nm");
		getSearch_ScreenID_ListPutter().setColumns("screen_id", "screen_nm");
	}
	
	@Override
	protected void listenerInit() {
		super.listenerInit();
		
		Memo_MemoPanel_PPanel.Command_update.addAPListener(this);
	}

	@Override
	public void layoutInit() {
		super.layoutInit();
		MemoPanel.remove(Memo_MemoPanel_PPanel);
		MemoPanel.setLayout(new BorderLayout());
		MemoPanel.add(Memo_MemoPanel_PPanel, BorderLayout.CENTER);
	}
	
	@Override
	public boolean doList_VC(MCEventInfo info) {
		boolean e = super.doList_VC(info);
		
		// メモが入力中の場合
		// クリア確認処理を実行する
		if (isMemoChanged()) {
			if (!clearMemoConfirm()) {
				return false;
			}
		}
		
		return e;
	}

	@Override
	public void doList_NC(MCEventInfo info) {
		super.doList_NC(info);
		
		ListR c = ListTable.getSelectedMCRow();

		// 選択行の画面のメモを表示する
		if (c != null) {
			String m = c.ModuleID();
			String s = c.ScreenID();
			String k = MCConst.createKey(m, s, "label");
			String n = MCConst.label.getLabel(k);
			Memo_MemoPanel_PPanel.loadScreenMemo(m, s, n, useExtAttr());
		}
		else{
			Memo_MemoPanel_PPanel.loadScreenMemo(null, null, null, false);
		}
	}
	
	/**
	 * 検索に拡張属性を使用する場合は、trueを返します。 
	 *
	 * @return 検索に拡張属性を使用する場合は、true
	 */
	protected boolean useExtAttr() {
		return false;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public MCList getSearch_ScreenID(MCRow row, MCEventInfo info) {
		row.addStringColumn("module_id", getSearchR().ModuleID());
		return super.getSearch_ScreenID(row, info);
	}

	@Override
	public void doSearch_ModuleID_NC(MCEventInfo info) {
		Search_ScreenID.setValue(null);
	}

	@SuppressWarnings("unchecked")
	protected MCList<ListR> doSearch() {
		
		Memo_MemoPanel_PPanel.getMenuR().init();
		Memo_MemoPanel_PPanel.getMemoListL().init();
		Memo_MemoPanel_PPanel.getMemoR().init();
		
		MCList<ListR> result = createListL();
		
		MCList<MCRow> sl = getSearch_ScreenID(
				MCRow.create(), Search_ScreenID.getEventInfo());

		String s = getSearchR().ScreenID();
		String m = getSearchR().ModuleID();
		MCList<MCRow> l = null;
		if (!MCStringUtil.isNull(s)) {
			l = subListByLike(sl, "screen_id", s);
		} else if (!MCStringUtil.isNull(m)) {
			l = subListByLike(sl, "module_id", m);
		} else {
			l = sl;
		}

		for (MCRow c : l) {
			ListR t = createListR();
			t.ModuleID(c.getString("module_id"));
			t.ModuleName(c.getString("module_nm"));
			t.ScreenID(c.getString("screen_id"));
			t.ScreenName(c.getString("screen_nm"));
			result.add(t);
		}
		
		return result;
	}
	
	/**
	 * メモクリア確認ダイアログを表示します。
	 * メモをクリアする場合は true を返します。
	 *
	 * @return メモをクリアしない場合は false
	 */
	protected boolean clearMemoConfirm() {
		return confirm(FCBAC0113) == MCMessageBox.YES_OPTION;
	}
	
	/**
	 * メモが変更されている場合は true を返します。
	 *
	 * @return メモが変更されていない場合は false
	 */
	protected boolean isMemoChanged() {
		return Memo_MemoPanel_PPanel.isChanged();
	}
	
	/**
	 * メモを編集する対象となる画面の画面 ID の配列を返します。<p>
	 * 画面 ID の書式は 
	 * {@link mcframe.clientCore.resource.MCScreenConst#getBasePanelIDArray()} 
	 * と同じです。
	 *
	 * @return 画面 ID の配列
	 */
	protected String[] getMemoIDArray() {
		String[] a = MCConst.screen.getBasePanelIDArray();
		List<String> l = new ArrayList<String>();
		String m = "memo";
		for (String s : a) {
			String k = MCConst.createKey(s, m);
			
			// キーが定義されていない場合はメモの対象である
			// 値が false 以外の場合はメモの対象である
			if (!MCConst.screen.containsKey(k) || 
					MCConst.screen.getBoolean(k, true)) {
				l.add(s);
			}
		}
		return l.toArray(new String[l.size()]);
	}

	@Override
	public void setINITStatus() {
		super.setINITStatus();
		SearchPanel.focusFirstComponent();
	}

	@Override
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == Memo_MemoPanel_PPanel.Command_update) {
			doMemo_MemoPanel_PPanel_Command_Update(info);
		}	
	}

	public void doMemo_MemoPanel_PPanel_Command_Update(MCEventInfo info) {
		ListTable.mcRequestFocus();
	}

	public void doMemo_MemoPanel_PPanel_Command_Delete(MCEventInfo info) {
		ListTable.mcRequestFocus();
	}

}