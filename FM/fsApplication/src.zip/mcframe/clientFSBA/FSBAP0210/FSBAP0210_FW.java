package mcframe.clientFSBA.FSBAP0210;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;


import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import mcframe.clientCore.resource.MCConst;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP0210"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP0210_FW extends FSBAP0210_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	/**
	 * 画面のボーダ
	 */
	protected MCTitledBorder _screen_titled_border = null;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0210_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP0210_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	@Override
	protected void jbInit() {
		super.jbInit();
		
		_screen_titled_border = beansFactory.createTitledBorder();
		setBorder(_screen_titled_border);
	}
	
	/**
	 * フォント（比率）変更時の処理
	 */
	@Override
	public final void setFont(Font font) {
		super.setFont(font);
		// MCRootPanelにMCTitledBorderをsetBorderするこの画面だけの特別仕様のため
		// フォント比率変更時の処理にも特別実装が必要になる。
		Border b = getBorder();
		if (b instanceof TitledBorder) {
			((TitledBorder) b).setTitleFont(font);
		}
	}
	
	@Override
	public void updateResource(MCRootPanel panel) {
		super.updateResource(panel);

		updateTitleResource(panel);
	}
	
	protected void updateTitleResource(MCRootPanel panel) {
		if (_screen_titled_border != null) {
			
			_screen_titled_border.setTitleFont(LabelPanel.getFont());
			
			String label = MCConst.label.getLabel(
					getScreenTitleLabelKey());
			if (!isNull(label)) {
				_screen_titled_border.setTitle(label);
			}
		}
	}
	
	/**
	 * タイトルのラベル名を取得するためのリソースキーを返します。
	 *
	 * @return リソースキー
	 */
	protected String getScreenTitleLabelKey() {
		return MCConst.createKey(
				getModuleID(), getScreenID(), "title", "label");
	}
		
	@Override
	protected void doDeleteAction() {
		// 7012-2973(メインメニューにてクライアントエラー (#12550))
		// メインメニューでdividerが閉じられていて画面上に表示されていない場合は処理しない。
		// 閉じたまま処理するとMemo_UserMemo.mcRequestFocus();でエラーになるため。
		// メモパネルが見えない状態で登録削除すると何がおきているのかユーザがわからない。
		if(Memo_UserMemo.getWidth() == 0 || Memo_UserMemo.getHeight() == 0) {
			return;
		}

		super.doDeleteAction();
		
		Memo_UserMemo.mcRequestFocus();
	}

	@Override
	protected void doUpdateAction() {
		// 7012-2973(メインメニューにてクライアントエラー (#12550))
		// メインメニューでdividerが閉じられていて画面上に表示されていない場合は処理しない。
		// 閉じたまま処理するとMemo_UserMemo.mcRequestFocus();でエラーになるため。
		// メモパネルが見えない状態で登録削除すると何がおきているのかユーザがわからない。
		if(Memo_UserMemo.getWidth() == 0 || Memo_UserMemo.getHeight() == 0) {
			return;
		}

		super.doUpdateAction();
		
		Memo_UserMemo.mcRequestFocus();
	}
	
	@Override
	public void adjustStatus() {
		super.adjustStatus();
		if (!MCBeansUtil.authorize(Command_Update)) {
			Memo_UserMemo.setMode(MCMode.READ_ONLY);
		}
	}

}