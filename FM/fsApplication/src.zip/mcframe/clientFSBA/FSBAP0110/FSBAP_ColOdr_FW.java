package mcframe.clientFSBA.FSBAP0110;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;


import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START

import java.util.Iterator;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP_ColOdr"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP_ColOdr_FW extends FSBAP_ColOdr_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_ColOdr_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_ColOdr_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	@Override
	public void doListDtl_NC(MCEventInfo info) {
		super.doListDtl_NC(info);
		
		updateTable(getInfoDtlL());
	}
	
	@Override
	public boolean beforeClose() {
		if (!super.beforeClose()) {
			return false;
		}
		
		setCancelColumnList();
		
		return true;
	}
	
	/**
	 * キャンセル用に退避したカラム情報を設定します。
	 *
	 */
	protected void setCancelColumnList() {
		updateTable(_init_table_list);
	}
	
	@Override
	protected void setColumnPropertyDefault() {
		MCTable<?> table = getTargetTable();
		if (table instanceof MCLayoutTable<?>) {
			MCLayoutTable<?> lt = (MCLayoutTable<?>) table;
			Iterator<MCColumnLayoutMember> ite =
							lt.getColumnModel().createLayoutMemberIterator();
			while (ite.hasNext()) {
				MCColumnLayoutMember member = ite.next();
				member.setDefault();
			}
		}
		else {
			super.setColumnPropertyDefault();
		}
	}

	@Override
	public void doInfoDtl_hide_flg_NC(MCEventInfo info) {
		super.doInfoDtl_hide_flg_NC(info);

		if (getTargetTable() instanceof MCLayoutTable<?>) {
			boolean hide = ((Boolean) info.getNewValue()).booleanValue();
			int index = info.getEventIndex();
			InfoDtlR row = (InfoDtlR) getInfoDtlL().get(index);
			MCColumnConfig col = getTargetColumnConfig(row.column_key());

			// 縦レイアウトのメンバーを表示に切り替えた場合は
			// カラム幅をレイアウトの幅にする
			// そのためにレイアウトの幅を退避する
			int width = 0;
			if (!hide) {
				MCLayoutTable<?> lt = (MCLayoutTable<?>) getTargetTable();
				MCColumnLayout[] layouts = lt.getColumnLayouts();
				for (MCColumnLayout layout :layouts) {
					MCColumnLayout l = layout.getColumnLayout(col);
					if (l != null && l.isVertical()) {
						width = l.getWidth();
						break;
					}
				}
			}

			// 表示・非表示設定（表示は非表示前のカラムサイズに設定）
			col.setVisibleFromUser(!hide);
			if (width > 0) {
				// 縦レイアウト中のいずれかが表示中の場合はレイアウト幅に調整
				((MCTableColumn) col).setColumnWidthFromUser(width);
			}

			// 一覧の更新
			updateColumnList();
		}
	}

	@Override
	public void doInfoDtl_width_NC(MCEventInfo info){
		super.doInfoDtl_width_NC(info);

		// カラムの幅を更新し、必要なカラムの幅を再計算する
		InfoDtlR r = (InfoDtlR) getInfoDtlL().get(info.getEventIndex());
		MCColumnConfig col = getTargetColumnConfig(r.column_key());
		((MCTableColumn) col).setColumnWidthFromUser(
								((MCNumber) info.getNewValue()).intValue());

		// リストを更新
		updateColumnList();
	}

	/**
	 * 一覧のカラム情報を最新の状態に更新します。
	 *
	 */
	protected void updateColumnList() {
		MCList<InfoDtlR> l = getInfoDtlL();
		int size = l.size();
		for (int i = 0; i < size; i++) {
			InfoDtlR r = l.get(i);
			MCColumnConfig c = getTargetColumnConfig(r.column_key());
			if (c.isVisibleFromUser()) {
				int width = c.getColumnWidth();
				width = MCBeansUtil.adjust(
						width, getTargetTable().getRatio(), 100);
				r.width(width);
				r.hide_flg(false);
			}
			else {
				r.width(0);
				r.hide_flg(true);
			}
		}
	}

}