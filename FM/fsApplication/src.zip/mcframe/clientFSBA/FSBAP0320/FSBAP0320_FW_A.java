package mcframe.clientFSBA.FSBAP0320;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBAP0320"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP0320_FW_A extends mcframe.clientFSUC.FSUCP0000.FSUCP_PanelBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0320";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Color]ブロック関連のField定義
	public MCPanel ColorPanel = null;
	public MCTitledBorder ColorTitledBorder = null;
	// [Color]ブロックの項目のField定義
	public mcframe.clientFSUB.FSUBP0050.FSUBP_Color_H Color_color_p_PPanel;
	public MCNumberField Color_red;	// [Color]の[color_p.red]を[Color_red]としてエイリアス定義。
	public MCNumberField Color_green;	// [Color]の[color_p.green]を[Color_green]としてエイリアス定義。
	public MCNumberField Color_blue;	// [Color]の[color_p.blue]を[Color_blue]としてエイリアス定義。
	public MCButton Color_color;	// [Color]の[color_p.color]を[Color_color]としてエイリアス定義。
	/**
	 *  決定する.<p>
	 *
	 */
	public MCButton Color_upd = null;
	// [Basic]ブロック関連のField定義
	public MCPanel BasicPanel = null;
	public MCTitledBorder BasicTitledBorder = null;
	// [Basic]ブロックの項目のField定義
	// [Arrangement]ブロック関連のField定義
	public MCPanel ArrangementPanel = null;
	public MCTitledBorder ArrangementTitledBorder = null;
	// [Arrangement]ブロックの項目のField定義
	/** [INIT]モードを表す定数 */
	public static final String INIT = "INIT";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{INIT};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	
	/** [Color]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0320.ColorR aColorR;

	/**
	 * 項目コピーによってaColorRを設定します。
	 *
	 * aColorRのインスタンスは変更されません。
	 *
	 * @param row ColorR
	 */
	public void setColorR(mcframe.clientFSBA.FSBAP0320.ColorR row) {
		if (row != null) {
			MCRow.copyall(getColorR(), row);
		}
	}

	/**
	 * [Color]ブロックのコンテナaColorRを返します。
	 *
	 * @return ColorR
	 */
	public mcframe.clientFSBA.FSBAP0320.ColorR getColorR() {
		return aColorR;
	}

	/**
	 * aColorRを作成します。
	 *
	 * @return ColorR
	 */
	public mcframe.clientFSBA.FSBAP0320.ColorR createColorR() {
		return mcframe.clientFSBA.FSBAP0320.ColorR.create();
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getColorR())) ret.add(getColorR());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getColorR()) return "Color";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("Color")) return getColorR();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(ColorPanel);
		ret.add(BasicPanel);
		ret.add(ArrangementPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0320_FW_A() {
		aColorR = createColorR();

	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP0320_FW.jbCreateColor((FSBAP0320)this);
		FSBAP0320_FW.jbCreateBasic((FSBAP0320)this);
		FSBAP0320_FW.jbCreateArrangement((FSBAP0320)this);
	}

	/**
	 * [Color]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateColor(FSBAP0320 p) {
		p.Color_color_p_PPanel = mcframe.clientFSUB.FSUBP0050.FSUBP_Color_H.create(p.getColorR().color_p());
		p.Color_color_p_PPanel.setName("Color.color_p");
		p.Color_red = p.Color_color_p_PPanel.Color_red;
		p.Color_red.addAliasName("Color.red", p);
		p.Color_green = p.Color_color_p_PPanel.Color_green;
		p.Color_green.addAliasName("Color.green", p);
		p.Color_blue = p.Color_color_p_PPanel.Color_blue;
		p.Color_blue.addAliasName("Color.blue", p);
		p.Color_color = p.Color_color_p_PPanel.Color_color;
		p.Color_color.addAliasName("Color.color", p);
	}

	/**
	 * [Basic]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateBasic(FSBAP0320 p) {
	}

	/**
	 * [Arrangement]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateArrangement(FSBAP0320 p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}


	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP0320 create(){
		FSBAP0320 p = new FSBAP0320();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}


	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP0320_FW.jbfInitColor((FSBAP0320)this);
		FSBAP0320_FW.jbfInitBasic((FSBAP0320)this);
		FSBAP0320_FW.jbfInitArrangement((FSBAP0320)this);
		FSBAP0320_FW.jbInitColor((FSBAP0320)this);
		FSBAP0320_FW.jbInitBasic((FSBAP0320)this);
		FSBAP0320_FW.jbInitArrangement((FSBAP0320)this);
	}

	/**
	 * [Color]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitColor(FSBAP0320 p) {
		// ブロック関連の初期化
		p.ColorPanel = p.beansFactory.createPanel("Color");
		p.ColorTitledBorder = p.beansFactory.createTitledBorder();
		// ブロックの項目の初期化
		p.Color_upd = p.beansFactory.createButton("Color.upd", "upd");
	}

	/**
	 * [Basic]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitBasic(FSBAP0320 p) {
		// ブロック関連の初期化
		p.BasicPanel = p.beansFactory.createPanel("Basic");
		p.BasicTitledBorder = p.beansFactory.createTitledBorder();
		// ブロックの項目の初期化
	}

	/**
	 * [Arrangement]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitArrangement(FSBAP0320 p) {
		// ブロック関連の初期化
		p.ArrangementPanel = p.beansFactory.createPanel("Arrangement");
		p.ArrangementTitledBorder = p.beansFactory.createTitledBorder();
		// ブロックの項目の初期化
	}

	/**
	 * [Color]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitColor(FSBAP0320 p) {
		// ブロック関連の初期化
		p.ColorPanel.setBorder(p.ColorTitledBorder);
		p.add(p.ColorPanel);
		p.setLastBeans(p.ColorPanel);
		p.ColorPanel.setNextBeans(p.BasicPanel);
		p.ColorPanel.setValueCheck(false);
		// ブロックの項目の初期化
		p.ColorPanel.add(p.Color_color_p_PPanel);
		p.ColorPanel.setLastBeans(p.Color_color_p_PPanel);
		p.Color_color_p_PPanel.setNextBeans(p.Color_upd);
		p.Color_color_p_PPanel.Color_color.setGroup("RI");
		p.Color_upd.setIcon("REGISTER");
		p.Color_upd.setFunctionKey(MCFunctionKey.F9);
		p.ColorPanel.add(p.Color_upd);
	}

	/**
	 * [Basic]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitBasic(FSBAP0320 p) {
		// ブロック関連の初期化
		p.BasicPanel.setBorder(p.BasicTitledBorder);
		p.add(p.BasicPanel);
		p.BasicPanel.setNextBeans(p.ArrangementPanel);
		p.BasicPanel.setValueCheck(false);
		// ブロックの項目の初期化
	}

	/**
	 * [Arrangement]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitArrangement(FSBAP0320 p) {
		// ブロック関連の初期化
		p.ArrangementPanel.setBorder(p.ArrangementTitledBorder);
		p.add(p.ArrangementPanel);
		p.ArrangementPanel.setValueCheck(false);
		// ブロックの項目の初期化
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP0320_FW.mcInitColor((FSBAP0320)this);
		FSBAP0320_FW.mcInitBasic((FSBAP0320)this);
		FSBAP0320_FW.mcInitArrangement((FSBAP0320)this);

		// [INIT]ステータスのモードの設定
		FSBAP0320_FW.statusInitINIT_Color((FSBAP0320)this);
		FSBAP0320_FW.statusInitINIT_Basic((FSBAP0320)this);
		FSBAP0320_FW.statusInitINIT_Arrangement((FSBAP0320)this);

	}

	/**
	 *  [Color]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitColor(FSBAP0320 p) {
		p.Color_upd.addAllListener(p);
		p.Color_upd.setAPMethodName("doColor_upd");
	}

	/**
	 *  [Basic]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitBasic(FSBAP0320 p) {
	}

	/**
	 *  [Arrangement]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitArrangement(FSBAP0320 p) {
	}

	/**
	 * [INIT]ステータスの[Color]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Color(FSBAP0320 p){
		p.Color_color_p_PPanel.putStatus(INIT, mcframe.clientFSUB.FSUBP0050.FSUBP_Color_H.ENABLE);
		p.Color_color_p_PPanel.Color_color.putMode(p, INIT, MCMode.READ_ONLY);
		p.Color_upd.putMode(p, INIT, MCMode.ENABLE);

	}

	/**
	 * [INIT]ステータスの[Basic]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Basic(FSBAP0320 p){

	}

	/**
	 * [INIT]ステータスの[Arrangement]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Arrangement(FSBAP0320 p){

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return INIT;
	}

	/**
	 * Table/Treeの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
	}

	/**
	 * この画面を[INIT]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setINITStatus() {
		status = INIT;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (INIT.equals(status)) {
			setINITStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}


	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == Color_upd) doColor_upd(info);
	}

	/**
	 * [Color]パネルの[upd]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doColor_upd(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}