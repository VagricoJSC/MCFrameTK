package mcframe.clientFSBA.FSBAP0320;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;

import mcframe.clientFSUB.FSUBP0050.*;

import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Arrays;

import mcframe.clientCore.resource.MCConst;

import mcframe.clientFSBA.FSBAP0000.IfColorPanelBase;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP0320"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP0320_FW extends FSBAP0320_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	protected String _button_name = "_";

	/**
	 * 表示元の画面です。
	 */
	protected IfColorPanelBase _target_panel = null;
	
	/**
	 * 表示元の画面の処理対象行です。<p>
	 * 色情報を設定するときに使用します。
	 */
	protected int _target_index = -1;
	
	/**
	 * 色情報選択画面を形成するための情報です。
	 */
	protected WBP_ColorPanelInfo _color_panel_info = null;

	/**
	 * 「Basic」枠の色情報ボタンに設定するキーリスナです。
	 */
	protected KeyListener _basic_color_button_key_listener = null;
	
	/**
	 * 「Basic」枠の色情報ボタンに色を塗るときのインセット値です。
	 */
	protected int _basic_button_paint_insets = -1;
	
	/**
	 * 「Basic」枠の色情報ボタンの幅です。
	 */
	protected int _basic_button_width = -1;

	/**
	 * 「Basic」枠の色情報ボタンの高さです。
	 */
	protected int _basic_button_height = -1;

	/**
	 * 「Basic」枠の色情報ボタンの水平方向のマージンです。
	 */
	protected int _basic_horizontal_margin = -1;
	
	/**
	 * 「Basic」枠の色情報ボタンの垂直方向のマージンです。
	 */
	protected int _basic_vertical_margin = -1;
	
	/**
	 * 「Basic」枠のボタンのリストです。
	 */
	protected List<MCColorButton> _basic_button_list 
			= new ArrayList<MCColorButton>();
	
	/**
	 * 「Arrangement」枠の色情報ボタンに設定するキーリスナです。
	 */
	protected KeyListener _arrangement_color_button_key_listener = null;
	
	/**
	 * 「Arrangement」枠の色情報ボタンに色を塗るときのインセット値です。
	 */
	protected int _arrangement_button_paint_insets = -1;

	/**
	 * 「Arrangement」枠の色情報ボタンの幅です。
	 */
	protected int _arrangement_button_width = -1;

	/**
	 * 「Arrangement」枠の色情報ボタンの高さです。
	 */
	protected int _arrangement_button_height = -1;

	/**
	 * 「Arrangement」枠の色情報ボタンの水平方向のマージンです。
	 */
	protected int _arrangement_horizontal_margin = -1;
	
	/**
	 * 「Arrangement」枠の色情報ボタンの垂直方向のマージンです。
	 */
	protected int _arrangement_vertical_margin = -1;

	/**
	 * 「Arrangement」枠のボタンのリストです。
	 */
	protected List<MCColorButton> _arrangement_button_list 
			= new ArrayList<MCColorButton>();
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0320_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * Panel[Color]のボタン[upd]の押下時の処理
	 */
	@Override
	public void doColor_upd(MCEventInfo info) {
		MCMessageList l = checkReq(getColorR());
		if (l.size() > 0) {
			message(l);
			return;
		}
		
		Color c = null;
		MCNumber r = getColorR().red();
		MCNumber g = getColorR().green();
		MCNumber b = getColorR().blue();
		if (!isNullAnd(r, g, b)) {
			c = new Color(r.intValue(), g.intValue(), b.intValue());
		}
		
		getTargetPanel().setColorValue(getTargetIndex(), c);
		
		requestCloseWindow();
	}
	
	@Override
	protected void beansAttrInit() {
		super.beansAttrInit();
		
		getFrame().setResizable(false);
		Color_color_p_PPanel.setColorPanelEnabled(false);
	}
	
	/**
	 * 他の画面から呼び出された場合の初期化処理を実装します。<p>
	 * <ul>
	 * <li>起動タイプ：T1<br>
	 * <ul>
	 * <li>バインド値<br>
	 * バインド値は使用しません。
	 * </li>
	 * <li>その他の引数<br>
	 * その他の引数は下記の通り指定する必要があります。<p>
	 * <ul>
	 * <li>第一引数<br>
	 * 表示元の画面（または埋込画面）を指定してください。
	 * {@link IfColorPanelBase} インタフェースを実装している必要があります。
	 * </li>
	 * <li>第二引数<br>
	 * 処理対象行（インデックス値）を指定してください。
	 * {@link IfColorPanelBase#setColorValue(int, Color)} 
	 * で表示元の画面に色を設定するときなどに使用します。
	 * </li>
	 * <li>第三引数<br>
	 * 色情報選択画面を形成するための情報を指定してください。
	 * {@link WBP_ColorPanelInfo} を指定してください。
	 * 第三引数が存在しない、または null の場合は、デフォルトの情報が採用されます。
	 * </li>
	 * </ul>
	 * </li>
	 * </ul>
	 * </li>
	 * </ul>
	 *
	 * @param openTyp 起動タイプ
	 * @param bind バインド値
	 * @param args その他引数
	 * @throws MCAppException [FSBAC0047] 引数の指定に誤りがある場合
	 * @throws MCAppException [ {@link #msgUnknownOpenParam()} ] 
	 * 起動タイプに {@link T1} 以外が指定された場合
	 */
	@Override
	protected void initByScreenParam(
			String openTyp, MCRow bind, Object... args) {
		super.initByScreenParam(openTyp, bind, args);
		
		if (T1 == openTyp) {
			if (args == null || args.length < 2) {
				throw new MCAppException(FSBAC0047);
			}
			
			if (!(args[0] instanceof IfColorPanelBase)) {
				throw new MCAppException(FSBAC0047);
			}
			
			if (!(args[1] instanceof Integer)) {
				throw new MCAppException(FSBAC0047);
			}

			WBP_ColorPanelInfo i = null;
			if (args.length > 2) {
				Object o = args[2];
				if (o != null && !(o instanceof WBP_ColorPanelInfo)) {
					throw new MCAppException(FSBAC0047);
				}
				i = (WBP_ColorPanelInfo)o;
			}
			if (i == null) {
				i = createDefaultColorPanelInfo();
			}

			setTargetPanel((IfColorPanelBase)args[0]);
			setTargetIndex((Integer)args[1]);
			setColorPanelInfo(i);

			setInitData();
		}
		else {
			throw new MCAppException(msgUnknownOpenParam());
		}
	}
	
	
	protected WBP_ColorPanelInfo createDefaultColorPanelInfo() {
		WBP_ColorPanelInfo i = new WBP_ColorPanelInfo();
		i.setBasicButtonCount(
				getDefaultBasicHorizontalButtonCount(), 
				getDefaultBasicVerticalButtonCount());
		i.setArrangementButtonCount(
				getDefaultArrangementHorizontalButtonCount(),
				getDefaultArrangementVerticalButtonCount());
		i.setArrangementColor(getDefaultArrangementColor());
		i.setBasicColorInfoList(getDefaultBasicColorInfoList());
		return i;
	}
	
	/**
	 * 「Basic」枠の水平方向に配置する色情報ボタンの数を返します。
	 *
	 * @return 水平方向に配置する色情報ボタンの数
	 */
	protected int getDefaultBasicHorizontalButtonCount() {
		return MCConst.app.getInteger(
				getResourceKey("basic.horizontal_button_count"));
	}
	
	/**
	 * 「Basic」枠の垂直方向に配置する色情報ボタンの数を返します。
	 *
	 * @return 垂直方向に配置する色情報ボタンの数
	 */
	protected int getDefaultBasicVerticalButtonCount() {
		return MCConst.app.getInteger(
				getResourceKey("basic.vertical_button_count"));
	}
	
	/**
	 * 「Arrangement」枠の水平方向に配置する色情報ボタンの数を返します。
	 *
	 * @return 水平方向に配置する色情報ボタンの数
	 */
	protected int getDefaultArrangementHorizontalButtonCount() {
		return MCConst.app.getInteger(
				getResourceKey("arrangement.horizontal_button_count"));
	}
	
	/**
	 * 「Arrangement」枠の垂直方向に配置する色情報ボタンの数を返します。
	 *
	 * @return 垂直方向に配置する色情報ボタンの数
	 */
	protected int getDefaultArrangementVerticalButtonCount() {
		return MCConst.app.getInteger(
				getResourceKey("arrangement.vertical_button_count"));
	}
	
	/**
	 * 配合する色を返します。
	 *
	 * @return 配合する色
	 */
	protected Color getDefaultArrangementColor() {
		return MCConst.app.getColor(
				getResourceKey("arrangement.color"));
	}
	
	/**
	 * 色情報のリストを返します。
	 * 
	 * @return 色情報のリスト
	 */
	protected List<WBP_ColorInfo> getDefaultBasicColorInfoList() {
		List<WBP_ColorInfo> l = new ArrayList<WBP_ColorInfo>();
		
		List<String> kl = getBasicColorKeys("basic.color");
		for (String k : kl) {
			WBP_ColorInfo i = new WBP_ColorInfo();
			i.setColor(MCConst.app.getColor(k));
			l.add(i);
		}
		
		return l;
	}
	
	/**
	 * 画面を初期化します。
	 *
	 * @param info 色情報設定画面を形成するための情報
	 */	
	public void setInitData() {
		initBasicPanel();
		initArrangementPanel();
		
		setBlockBounds();
		
		adjustArrangementColorButton(null);

		//TOOD 7013-0007
//		setArrangementCenter(getParentPanel());
	}

	/**
	 * 「Basic」枠を初期化します。
	 */
	protected void initBasicPanel() {
		WBP_ColorPanelInfo i = getColorPanelInfo();
		if (i == null) {
			return;
		}

		int hc = i.getBasicHorizontalButtonCount();
		int idx = 0;
		List<WBP_ColorInfo> l = i.getBasicColorInfoList();
		for (WBP_ColorInfo f : l) {
			Color c = f.getColor();
			if (c == null) {
				continue;
			}
			MCColorButton o = createColorButton(_button_name);
			o.setColor(c);
			o.addAllListener(this);
			o.addKeyListener(getBasicColorButtonKeyListener());
			o.setSize(
					getBasicColorButtonWidth(), 
					getBasicColorButtonHeight());
			
			int h = idx % hc;
			int v = idx / hc;

			int x = getBasicColorButtonWidth() * h 
					+ getBasicColorButtonHorizontalMargin() * (h + 1);
			int y = getBasicColorButtonHeight() * v 
					+ getBasicColorButtonVerticalMargin() * (v + 1);

			o.setLocation(x, y);

			// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
//			o.setDefaultRatioSize(o.getBounds());

			BasicPanel.add(o);
			if (BasicPanel.getFirstBeans() == null) {
				BasicPanel.setFirstBeans(o);
			}
			else {
				BasicPanel.getLastBeans().setNextBeans(o);
			}

			o.setBackground(c);

			getBasicButtonList().add(o);
			
			idx++;
		}
	}
	
	/**
	 * 「Arrangement」枠を初期化します。
	 */
	protected void initArrangementPanel() {
		WBP_ColorPanelInfo i = getColorPanelInfo();
		if (i == null) {
			return;
		}

		int hc = i.getArrangementHorizontalButtonCount();
		int vc = i.getArrangementVerticalButtonCount();
		int mc = hc * vc;
		
		for (int j = 0; j < mc; j++) {
			MCColorButton o = createColorButton(_button_name);
			o.addAllListener(this);
			o.addKeyListener(getArrangementColorButtonKeyListener());
			o.setSize(
					getArrangementColorButtonWidth(), 
					getArrangementColorButtonHeight());
			
			int h = j % hc;
			int v = j / hc;
			
			int x = getArrangementColorButtonWidth() * h 
					+ getArrangementColorButtonHorizontalMargin() * (h + 1);
			int y = getArrangementColorButtonHeight() * v 
					+ getArrangementColorButtonVerticalMargin() * (v + 1);

			o.setLocation(x, y);
			
			ArrangementPanel.add(o);
			if (ArrangementPanel.getFirstBeans() == null) {
				ArrangementPanel.setFirstBeans(o);
			}
			else {
				ArrangementPanel.getLastBeans().setNextBeans(o);
			}
			getArrangementButtonList().add(o);
		}
	}
	
	/**
	 * 枠、画面、フレームの配置を設定します。
	 */
	protected void setBlockBounds() {
		setMCPanelBounds();
		adjustPanelWidth();
		setRootPanelBounds();
		setFrameBounds();
	}
	
	/**
	 * 枠の配置を設定します。
	 */
	protected void setMCPanelBounds() {

		// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)

		// MCConstのリソースの値がサイズ位置が正確でないため再計算する。
		List<MCPanel> l = getMCPanels();
		int left = 0;
		int top = 0;
		int right = 0;
		int bottom = 0;
		for (MCPanel p : l) {

			Component[] clist = MCBeansUtil.getAllComponents(p);
			for (Component c : clist) {
				if (clist[0] == c) {
					left = c.getX();
					top = c.getY();
					right = c.getX() + c.getWidth();
					bottom = c.getY() + c.getHeight();
				} else {
					left = Math.min(left, c.getX());
					top = Math.min(top, c.getY());
					right = Math.max(right, c.getX() + c.getWidth());
					bottom = Math.max(bottom, c.getY() + c.getHeight());
				}
			}

			// 2は壁にくっつきをなくすための値
			Dimension d2 = new Dimension(right + 2, bottom + 2);
			p.setSize(d2);
			p.setPreferredSize(d2);
		}
	}
	
	/**
	 * 枠の推奨サイズを返します。
	 * 
	 * @param panel 枠
	 * @return 推奨サイズ
	 */
	protected Dimension getPreferredSize(MCPanel panel) {
		if (panel == BasicPanel) {
			return getBasicPanelPreferredSize();
		}
		if (panel == ArrangementPanel) {
			return getArrangementPanelPreferredSize();
		}
		return null;
	}
	
	/**
	 * 枠の幅を調整します。
	 */
	protected void adjustPanelWidth() {
		// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
		// 不要
	}
	
	/**
	 * この画面の配置を設定します。
	 */
	protected void setRootPanelBounds() {
		List<MCPanel> l = getMCPanels();

		// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
		int left = 0;
		int top = 0;
		int right = 0;
		int bottom = 0;
		for (MCPanel p : l) {
			if (l.get(0) == p) {
				left = p.getX();
				top = p.getY();
				right = p.getX() + p.getWidth();
				bottom = p.getY() + p.getHeight();
			} else {
				left = Math.min(left, p.getX());
				top = Math.min(top, p.getY());
				right = Math.max(right, p.getX() + p.getWidth());
				bottom = Math.max(bottom, p.getY() + p.getHeight());
			}
		}

		Container c = l.get(0).getParent();
		Dimension d = new Dimension(right + left, bottom + top);
		while(c != null) {
			c.setSize(d);
			c.setPreferredSize(d);
			c = c.getParent();
			if(c instanceof MCRootPanel) {
				break;
			}
		}
		c.setSize(d);
		c.setPreferredSize(d);
	}
	
	/**
	 * フレームの配置を設定します。
	 */
	protected void setFrameBounds() {
		Dimension pd = getSize();
		MCFrame f = getFrame();

		// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
		// frameのpackを行うため推奨サイズをリセットする。
		f.setPreferredSize(null);

		f.pack();
//		Dimension fd = f.getPreferredSize();
		Insets fi = f.getInsets();
		
		Dimension d = new Dimension(
				pd.width + fi.left + fi.right,  pd.height+ fi.top + fi.bottom);
		f.setSize(new Dimension(d));
		f.setPreferredSize(new Dimension(d));
	}
	
	/**
	 * 色情報ボタンを作成します。
	 * 
	 * @param name 名前
	 * @return 色選択ボタン
	 */
	protected MCColorButton createColorButton(String name) {
		return new MCColorButton(name);
	}
	
	/**
	 * 「Basic」枠の色情報ボタンに色を塗るときのインセット値を返します。
	 * 
	 * @return 色情報ボタンに色を塗るときのインセット値
	 */
	protected int getBasicColorButtonPaintInsets() {
		if (_basic_button_paint_insets == -1) {
			_basic_button_paint_insets = MCConst.app.getInteger(
					getResourceKey("basic.button_paint_insets"));
		}
		return _basic_button_paint_insets;
	}
	
	/**
	 * 「Basic」枠の色情報ボタンの幅を返します。
	 *
	 * @return 色情報ボタンの幅
	 */
	protected int getBasicColorButtonWidth() {
		if (_basic_button_width == -1) {
			_basic_button_width = MCConst.app.getInteger(
					getResourceKey("basic.button_width"));
		}
		return _basic_button_width;
	}
	
	/**
	 * 「Basic」枠の色情報ボタンの高さを返します。
	 *
	 * @return 色情報ボタンの高さ
	 */
	protected int getBasicColorButtonHeight() {
		if (_basic_button_height == -1) {
			_basic_button_height = MCConst.app.getInteger(
					getResourceKey("basic.button_height"));
		}
		return _basic_button_height;
	}

	/**
	 * 「Basic」枠の色情報ボタンの水平方向のマージンを返します。
	 *
	 * @return 色情報ボタンの水平方向のマージン
	 */
	protected int getBasicColorButtonHorizontalMargin() {
		if (_basic_horizontal_margin == -1) {
			_basic_horizontal_margin = MCConst.app.getInteger(
					getResourceKey("basic.horizontal_margin"));
		}
		return _basic_horizontal_margin;
	}
	
	/**
	 * 「Basic」枠の色情報ボタンの垂直方向のマージンを返します。
	 *
	 * @return 色情報ボタンの垂直方向のマージン
	 */
	protected int getBasicColorButtonVerticalMargin() {
		if (_basic_vertical_margin == -1) {
			_basic_vertical_margin = MCConst.app.getInteger(
					getResourceKey("basic.vertical_margin"));
		}
		return _basic_vertical_margin;
	}
	
	/**
	 * 「Arrangement」枠の色情報ボタンに色を塗るときのインセット値を返します。
	 * 
	 * @return 色情報ボタンに色を塗るときのインセット値
	 */
	protected int getArrangementColorButtonPaintInsets() {
		if (_arrangement_button_paint_insets == -1) {
			_arrangement_button_paint_insets = MCConst.app.getInteger(
					getResourceKey("arrangement.button_paint_insets"));
		}
		return _arrangement_button_paint_insets;
	}
	
	/**
	 * 「Arrangement」枠の色情報ボタンの幅を返します。
	 *
	 * @return 色情報ボタンの幅
	 */
	protected int getArrangementColorButtonWidth() {
		if (_arrangement_button_width == -1) {
			_arrangement_button_width = MCConst.app.getInteger(
					getResourceKey("arrangement.button_width"));
		}
		return _arrangement_button_width;
	}
	
	/**
	 * 「Arrangement」枠の色情報ボタンの高さを返します。
	 *
	 * @return 色情報ボタンの高さ
	 */
	protected int getArrangementColorButtonHeight() {
		if (_arrangement_button_height == -1) {
			_arrangement_button_height = MCConst.app.getInteger(
					getResourceKey("arrangement.button_height"));
		}
		return _arrangement_button_height;
	}

	/**
	 * 「Arrangement」枠の色情報ボタンの水平方向のマージンを返します。
	 *
	 * @return 色情報ボタンの水平方向のマージン
	 */
	protected int getArrangementColorButtonHorizontalMargin() {
		if (_arrangement_horizontal_margin == -1) {
			_arrangement_horizontal_margin = MCConst.app.getInteger(
					getResourceKey("arrangement.horizontal_margin"));
		}
		return _arrangement_horizontal_margin;
	}
	
	/**
	 * 「Arrangement」枠の色情報ボタンの垂直方向のマージンを返します。
	 *
	 * @return 色情報ボタンの垂直方向のマージン
	 */
	protected int getArrangementColorButtonVerticalMargin() {
		if (_arrangement_vertical_margin == -1) {
			_arrangement_vertical_margin = MCConst.app.getInteger(
					getResourceKey("arrangement.vertical_margin"));
		}
		return _arrangement_vertical_margin;
	}
	
	/**
	 * 「Basic」枠の推奨サイズを返します。<p>
	 * {@link #getColorPanelInfo()} が null を返した場合は null を返します。
	 * 
	 * @return 推奨サイズ、または null
	 */
	protected Dimension getBasicPanelPreferredSize() {
		WBP_ColorPanelInfo i = getColorPanelInfo();
		if (i == null) {
			return null;
		}
		
		int hc = i.getBasicHorizontalButtonCount();
		int vc = i.getBasicVerticalButtonCount();
		int hg = getBasicColorButtonHorizontalMargin();
		int vg  = getBasicColorButtonVerticalMargin();
		int bw = getBasicColorButtonWidth();
		int bh = getBasicColorButtonHeight();
		
		int w = bw * hc;
		w += hg * (hc + 1);
		
		int h = bh * vc;
		h += vg * (vc + 1);
		
		return new Dimension(w, h);
	}
	
	/**
	 * 「Arrangement」枠の推奨サイズを返します。<p>
	 * {@link #getColorPanelInfo()} が null を返した場合は null を返します。
	 * 
	 * @return 推奨サイズ、または null
	 */
	protected Dimension getArrangementPanelPreferredSize() {
		WBP_ColorPanelInfo i = getColorPanelInfo();
		if (i == null) {
			return null;
		}

		int hc = i.getArrangementHorizontalButtonCount();
		int vc = i.getArrangementVerticalButtonCount();
		int hg = getArrangementColorButtonHorizontalMargin();
		int vg  = getArrangementColorButtonVerticalMargin();
		int bw = getArrangementColorButtonWidth();
		int bh = getArrangementColorButtonHeight();
		
		int w = bw * hc;
		w += hg * (hc + 1);
		
		int h = bh * vc;
		h += vg * (vc + 1);
		
		return new Dimension(w, h);
	}
	
	@Override
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		
		if (ap instanceof MCColorButton) {
			colorButtonAction(info);
		}
	}
	
	/**
	 * 色情報選択ボタンが押下されたときに実行されます。
	 * 
	 * @param info イベント情報
	 */
	protected void colorButtonAction(MCEventInfo info) {
		MCColorButton o = (MCColorButton) info.getComponent();
		
		if (getBasicButtonList().contains(o) 
				|| getArrangementButtonList().contains(o)) {
			setColorFieldValue(o);
		}
	}
	
	@Override
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		
		if (ne instanceof MCColorButton) {
			colorButtonFocused(info);
		}
	}
	
	/**
	 * 色情報選択ボタンにフォーカスが移動したときに実行されます。
	 * 
	 * @param info イベント情報
	 */
	protected void colorButtonFocused(MCEventInfo info) {
		MCColorButton o = (MCColorButton) info.getComponent();
		
		if (getBasicButtonList().contains(o)) {
			adjustArrangementColorButton(o);
		}
	}

	/**
	 * 「Basic」枠のボタンのリストを返します。
	 * 
	 * @return　「Basic」枠のボタンのリスト
	 */
	protected List<MCColorButton> getBasicButtonList() {
		return _basic_button_list;
	}
	
	/**
	 * 「Arrangement」枠のボタンのリストを返します。
	 *
	 * @return 「Arrangement」枠のボタンのリスト
	 */
	protected List<MCColorButton> getArrangementButtonList() {
		return _arrangement_button_list;
	}
	
	/**
	 * 「Arrangement」枠のボタンを調整します。
	 *
	 * @param compo 色情報を保持するボタン
	 */
	protected void adjustArrangementColorButton(MCColorButton compo) {
		WBP_ColorPanelInfo f = getColorPanelInfo();
		if (f == null) {
			return;
		}
		
		List<MCColorButton> l = getArrangementButtonList();
		int s = l.size();
		if (compo == null) {
			for (int i = 0; i < s; i++) {
				l.get(i).setMode(MCMode.DISABLE);
				l.get(i).setColor(null);
			}
			return;
		}
		
		Color c = compo.getColor();
		Color a = f.getArrangementColor();

		int cr = c.getRed();
		int cg = c.getGreen();
		int cb = c.getBlue();
		
		int dr = a.getRed() - c.getRed();
		int dg = a.getGreen() - c.getGreen();
		int db = a.getBlue() - c.getBlue();
		
		for (int i = 0; i < s; i++) {
			if (i == 0) {
				l.get(i).setMode(MCMode.ENABLE);
				l.get(i).setColor(c);
				continue;
			}
			
			int r = dr * (i) / (s - 1);
			int g = dg * (i) / (s - 1);
			int b = db * (i) / (s - 1);
			
			Color n = new Color(cr + r, cg + g, cb + b);
			l.get(i).setMode(MCMode.ENABLE);
			l.get(i).setColor(n);
		}
	}
	
	/**
	 * 「Color」枠のフィールドの値（色情報）を設定します。
	 *
	 * @param compo 色情報を保持するボタン
	 */
	protected void setColorFieldValue(MCColorButton compo) {
		Color c = compo.getColor();
		
		setValueEx(Color_red, MCNumber.valueOf(c.getRed()));
		setValueEx(Color_green, MCNumber.valueOf(c.getGreen()));
		setValueEx(Color_blue, MCNumber.valueOf(c.getBlue()));
	}
	
	/**
	 * 色情報選択画面を形成するための情報を設定します。
	 *
	 * @param info 色情報選択画面を形成するための情報
	 */
	protected void setColorPanelInfo(WBP_ColorPanelInfo info) {
		_color_panel_info = info;
	}
	
	/**
	 * 色情報選択画面を形成するための情報を返します。<p>
	 * 色情報選択画面を形成するための情報が設定されていない場合は null を返します。
	 *
	 * @return 色情報選択画面を形成するための情報、または null
	 */
	protected WBP_ColorPanelInfo getColorPanelInfo() {
		return _color_panel_info;
	}
	
	/**
	 * 表示元の画面を設定します。
	 *
	 * @param panel 表示元の画面
	 */
	protected void setTargetPanel(IfColorPanelBase panel) {
		_target_panel = panel;
	}
	
	/**
	 * 表示元の画面を返します。<p>
	 * 表示元の画面が設定されていない場合は null を返します。
	 * 
	 * @return 表示元の画面、または null
	 */
	protected IfColorPanelBase getTargetPanel() {
		return _target_panel;
	}
	
	/**
	 * 表示元の画面の処理対象行を設定します。
	 * 
	 * @param index 処理対象行
	 */
	protected void setTargetIndex(int index) {
		_target_index = index;
	}

	/**
	 * 表示元の画面の処理対象行を返します。
	 * 
	 * @return 表示元の画面の処理対象行
	 */
	protected int getTargetIndex() {
		return _target_index;
	}
	
	protected String getResourceKey(String key) {
		String k = MCConst.createKey(getModuleID(), getScreenID(), key);
		if (MCConst.app.containsKey(k)) {
			return k;
		}
		return null;
	}
	
	protected List<String> getBasicColorKeys(String key) {
		String k = MCConst.createKey(getModuleID(), getScreenID(), key, "*");
		String[] a = MCConst.app.findPattern(k);
		Arrays.sort(a);
		return new ArrayList<String>(Arrays.asList(a));
	}
	
	/**
	 * GUI 部品のモードをチェックします。
	 * GUI 部品のモードが入力可能なモードの場合は true を返します。
	 *
	 * @param compo GUI 部品
	 * @return GUI 部品のモードが入力可能なモードではない場合は false
	 */
	protected boolean isModeEditable(MCModeBeans compo) {
		if (compo == null) {
			return false;
		}
		MCModeInfo i = compo.getModeInfo();
		if (i == null) {
			return false;
		}
		return i.getStatus() == MCMode.ENABLE_STATUS;
	}

	/**
	 * 「Basic」枠の色情報ボタンに設定するキーリスナを返します。
	 *
	 * @return キーリスナ
	 */
	protected KeyListener getBasicColorButtonKeyListener() {
		return _basic_color_button_key_listener != null 
				? _basic_color_button_key_listener 
				: (_basic_color_button_key_listener 
						= createBasicColorButtonKeyListener());
	}
	
	/**
	 * 「Basic」枠の色情報ボタンに設定するキーリスナを作成します。
	 *
	 * @return キーリスナ
	 */
	protected KeyListener createBasicColorButtonKeyListener() {
		return new WBP_BasicColorButtonKeyListener();
	}
	
	protected class WBP_BasicColorButtonKeyListener extends KeyAdapter {

		@Override
		public void keyPressed(KeyEvent e) {
			Object o = e.getSource();
			if (!(o instanceof MCColorButton)) {
				return;
			}
			MCColorButton c = (MCColorButton)o;
			switch (e.getKeyCode()) {
				case KeyEvent.VK_UP:
					verticalKeyEvent(c, true);
					break;
				case KeyEvent.VK_DOWN:
					verticalKeyEvent(c, false);
					break;
				case KeyEvent.VK_RIGHT:
					horizontalKeyEvent(c, true);
					break;
				case KeyEvent.VK_LEFT:
					horizontalKeyEvent(c, false);
					break;
				default:
					break;
			}
		}
		
		/**
		 * ↑キー、↓キーのイベントを実行します。
		 * 
		 * @param compo GUI 部品
		 * @param up ↑キーの場合は true、↓キーの場合は false
		 */
		protected void verticalKeyEvent(MCColorButton compo, boolean up) {
			List<MCColorButton> l = getBasicButtonList();
			
			int i = l.indexOf(compo);
			if (i < 0) {
				return;
			}
			MCColorButton n = null;
			int x = l.size() - 1;
			int h = getColorPanelInfo().getBasicHorizontalButtonCount();
			while (true) {
				i = up ? i - h : i + h;
				if (i < 0 || i > x) {
					break;
				}
				
				n = l.get(i);
				if (isModeEditable(n)) {
					n.mcRequestFocus();
					break;
				}
			}
		}
		
		/**
		 * →キー、←キーのイベントを実行します。
		 * 
		 * @param compo GUI 部品
		 * @param right →キーの場合は true、←キーの場合は false
		 */
		protected void horizontalKeyEvent(
				MCColorButton compo, boolean right) {
			List<MCColorButton> l = getBasicButtonList();
			
			int i = l.indexOf(compo);
			if (i < 0) {
				return;
			}
			MCColorButton n = null;
			int x = l.size() - 1;
			int h = getColorPanelInfo().getBasicHorizontalButtonCount();
			while (true) {
				if (!right && i % h == 0) {
					break;
				}
				else if (right && i % h == (h - 1)) {
					break;
				}
				i = right ? i + 1 : i - 1;
				if (i < 0 || i > x) {
					break;
				}
				n = l.get(i);
				if (isModeEditable(n)) {
					n.mcRequestFocus();
					break;
				}
			}
		}
		
	}
	
	/**
	 * 「Arrangement」枠の色情報ボタンに設定するキーリスナを返します。
	 * 
	 * @return キーリスナ
	 */	
	protected KeyListener getArrangementColorButtonKeyListener() {
		return _arrangement_color_button_key_listener != null 
				? _arrangement_color_button_key_listener 
				: (_arrangement_color_button_key_listener 
						= createArrangementColorButtonKeyListener());
	}
	
	/**
	 * 「Arrangement」枠の色情報ボタンに設定するキーリスナを作成します。
	 * 
	 * @return キーリスナ
	 */
	protected KeyListener createArrangementColorButtonKeyListener() {
		return new WBP_ArrangementColorButtonKeyListener();
	}
	
	protected class WBP_ArrangementColorButtonKeyListener extends KeyAdapter {
		
		@Override
		public void keyPressed(KeyEvent e) {
			Object o = e.getSource();
			if (!(o instanceof MCColorButton)) {
				return;
			}
			MCColorButton c = (MCColorButton)o;
			switch (e.getKeyCode()) {
				case KeyEvent.VK_UP:
					verticalKeyEvent(c, true);
					break;
				case KeyEvent.VK_DOWN:
					verticalKeyEvent(c, false);
					break;
				case KeyEvent.VK_RIGHT:
					horizontalKeyEvent(c, true);
					break;
				case KeyEvent.VK_LEFT:
					horizontalKeyEvent(c, false);
					break;
				default:
					break;
			}
		}
		
		/**
		 * ↑キー、↓キーのイベントを実行します。
		 * 
		 * @param compo GUI 部品
		 * @param up ↑キーの場合は true、↓キーの場合は false
		 */
		protected void verticalKeyEvent(MCColorButton compo, boolean up) {
			List<MCColorButton> l = getArrangementButtonList();
			
			int i = l.indexOf(compo);
			if (i < 0) {
				return;
			}
			MCColorButton n = null;
			int x = l.size() - 1;
			int h = getColorPanelInfo().getArrangementHorizontalButtonCount();
			while (true) {
				i = up ? i - h : i + h;
				if (i < 0 || i > x) {
					break;
				}
				
				n = l.get(i);
				if (isModeEditable(n)) {
					n.mcRequestFocus();
					break;
				}
			}
		}
		
		/**
		 * →キー、←キーのイベントを実行します。
		 * 
		 * @param compo GUI 部品
		 * @param right →キーの場合は true、←キーの場合は false
		 */
		protected void horizontalKeyEvent(
				MCColorButton compo, boolean right) {
			List<MCColorButton> l = getArrangementButtonList();
			
			int i = l.indexOf(compo);
			if (i < 0) {
				return;
			}
			MCColorButton n = null;
			int x = l.size() - 1;
			int h = getColorPanelInfo().getArrangementHorizontalButtonCount();
			while (true) {
				if (!right && i % h == 0) {
					break;
				}
				else if (right && i % h == (h - 1)) {
					break;
				}
				i = right ? i + 1 : i - 1;
				if (i < 0 || i > x) {
					break;
				}
				n = l.get(i);
				if (isModeEditable(n)) {
					n.mcRequestFocus();
					break;
				}
			}
		}
	}
	
	/**
	 * 色情報ボタンです。
	 */
	protected class MCColorButton extends MCButton {
		
		/**
		 * ボタンに表示する色です。
		 */
		protected Color _color = null;
		
		/**
		 * コンストラクタです。
		 * 
		 * @param name 名前
		 */
		public MCColorButton(String name) {
			super(name);
		}
		
		protected void setColor(Color color) {
			_color = color;
		}
		
		@Override
		public void paint(Graphics g) {
			super.paint(g);

			Color o = g.getColor();
			
			Color c = getColor();
			if (c == null) {
				c = getModeInfo().getBackground();
			}
			g.setColor(c);
			
			int i = getColorButtonPaintInsets();
			g.fillRect(i, i, getWidth() - (i * 2), getHeight() - (i * 2));
			
			g.setColor(o);
		}
		
		/**
		 * ボタンに紐づく色を返します。
		 * 
		 * @return ボタンに紐づく色
		 */
		protected Color getColor() {
			return _color;
		}
		
		/**
		 * 色情報ボタンに色を塗るときのインセット値を返します。
		 *
		 * @return　色情報ボタンに色を塗るときのインセット値
		 */
		protected int getColorButtonPaintInsets() {
			Container p = getParent();
			if (p == BasicPanel) {
				return getBasicColorButtonPaintInsets();
			}
			if (p == ArrangementPanel) {
				return getArrangementColorButtonPaintInsets();
			}
			return -1;
		}
	}

	// MCLayouterの指定文字列を返します。
	// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
	@Override
	public String getLayoutKey() {
		return "S";
	}

	// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
	@Override
	public void initialized() {
		super.initialized();

		// 親画面のフォント比率を継承する。
		MCBeans rp = getParentPanel();
		int ratio = rp.getBaseRootPanel().getLayoutRatio();
		if (ratio != 100) {
			// 100以外のときはフォント比率を適用し拡大縮小を行う。
			MCLayouter.fontRatioChange(this, ratio);
			setFrameBounds();
		}

		setArrangementCenter(getParentPanel());
	}

	// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
	// スクロールバーが出る場合の自動調整を行う。
	@Override
	protected Dimension _adjistFrameSize(Dimension d) {
		// スクロールバーがでてしまうためMCRootPanelの横幅で調整する。
		if (this.getWidth() > d.width) {
			d.width = this.getWidth();
		}
		if (this.getHeight() > d.height) {
			d.height = this.getHeight();
		}
		return d;
	}

	// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
	@Override
	protected boolean hasHeaderStatusBar() {
		return false;
	}
	// 7013-0007 ここまで

}