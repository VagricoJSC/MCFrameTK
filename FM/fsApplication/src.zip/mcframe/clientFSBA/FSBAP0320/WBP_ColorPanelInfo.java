package mcframe.clientFSBA.FSBAP0320;

import java.awt.Color;
import java.util.List;

/**
 * 色情報選択画面を形成するための情報です。
 */
public class WBP_ColorPanelInfo {

	/**
	 * 色情報のリストです。
	 */
	protected List<WBP_ColorInfo> _basic_color_info_list = null;
	
	/**
	 * 配合する色です。
	 */
	protected Color _arrangement_color = null;
	
	/**
	 * 水平方向に配置する色選択ボタンの数です。
	 */
	protected int _basic_horizontal_button_count = -1;
	
	/**
	 * 垂直方向に配置する色選択ボタンの数です。
	 */
	protected int _basic_vertical_button_count = -1;
	
	/**
	 * 色情報選択画面の配合に関する色選択ボタンについて、
	 * 水平方向に配置するボタンの数です。
	 */
	protected int _arrangement_horizontal_button_count = -1;
	
	/**
	 * 色情報選択画面の配合に関する色選択ボタンについて、
	 * 垂直方向に配置するボタンの数です。
	 */
	protected int _arrangement_vertical_button_count = -1;
	
	/**
	 * コンストラクタです。
	 */
	public WBP_ColorPanelInfo() {}
	
	/**
	 * 色情報のリストを設定します。
	 * 
	 * @param list 色情報のリスト
	 */
	public void setBasicColorInfoList(List<WBP_ColorInfo> list) {
		_basic_color_info_list = list;
	}
	
	/**
	 * 色情報のリストを返します。<p>
	 * 色情報のリストが設定されていない場合は null を返します。
	 *
	 * @return 色情報のリスト、または null
	 */
	public List<WBP_ColorInfo> getBasicColorInfoList() {
		return _basic_color_info_list;
	}
	
	/**
	 * 配合する色を設定します。
	 *
	 * @param color 配合する色
	 */
	public void setArrangementColor(Color color) {
		_arrangement_color = color;
	}
	
	/**
	 * 配合する色を返します。<p>
	 * 配合する色が設定されていない場合は null を返します。
	 * 
	 * @return 配合する色、または null
	 */
	public Color getArrangementColor() {
		return _arrangement_color;
	}
	
	/**
	 * 色選択ボタンの配置を設定します。
	 *
	 * @param horizontal 水平方向に配置する色選択ボタンの数
	 * @param vertical 垂直方向に配置する色選択ボタンの数
	 */
	public void setBasicButtonCount(int horizontal, int vertical) {
		_basic_horizontal_button_count = horizontal;
		_basic_vertical_button_count = vertical;
	}

	/**
	 * 水平方向に配置する色選択ボタンの数を返します。
	 * 
	 * @return 水平方向に配置する色選択ボタンの数
	 */
	public int getBasicHorizontalButtonCount() {
		return _basic_horizontal_button_count;
	}

	/**
	 * 垂直方向に配置する色選択ボタンの数を返します。
	 *
	 * @return 垂直方向に配置する色選択ボタンの数
	 */
	public int getBasicVerticalButtonCount() {
		return _basic_vertical_button_count;
	}
	
	/**
	 * 色情報選択画面の配合に関する色選択ボタンについて、
	 * ボタンの配置情報を設定します。
	 *
	 * @param horizontal 水平方向に配置する色選択ボタンの数
	 * @param vertical 垂直方向に配置する色選択ボタンの数
	 */
	public void setArrangementButtonCount(int horizontal, int vertical) {
		_arrangement_horizontal_button_count = horizontal;
		_arrangement_vertical_button_count = vertical;
	}
	
	/**
	 * 色情報選択画面の配合に関する色選択ボタンについて、
	 * 水平方向に配置する色選択ボタンの数を返します。
	 * 
	 * @return 水平方向に配置する色選択ボタンの数
	 */
	public int getArrangementHorizontalButtonCount() {
		return _arrangement_horizontal_button_count;
	}
	
	/**
	 * 色情報選択画面の配合に関する色選択ボタンについて、
	 * 垂直方向に配置する色選択ボタンの数を返します。
	 * 
	 * @return 垂直方向に配置する色選択ボタンの数
	 */
	public int getArrangementVerticalButtonCount() {
		return _arrangement_vertical_button_count;
	}
}