package mcframe.clientFSBA.FSBAP0320;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Color"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class ColorR_FW_A extends MCConstRow {

	public static final String $color_p = "color_p";

	public static final String $red = $color_p + ".red";
	public static final String $green = $color_p + ".green";
	public static final String $blue = $color_p + ".blue";
	public static final String $color = $color_p + ".color";

	public static final MCMeta color_p_META = createInnerRowMeta($color_p, mcframe.clientFSUB.FSUBP0050.ColorR.class);

	protected static final ConstMetaList<ColorR> constMetas = new ConstMetaList<ColorR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			color_p_META
		},
		new String[][]{
			{
				"red",
				"green",
				"blue",
			},
			{
				$red,
				$green,
				$blue,
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected ColorR_FW_A(ConstMetaList<? extends ColorR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ColorR clone() {
		return (ColorR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ColorR createInstance() {
		return (ColorR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ColorR getValues(String... names) {
		return (ColorR) super.getValues(names);
	}



	public mcframe.clientFSUB.FSUBP0050.ColorR color_p(){
		return (mcframe.clientFSUB.FSUBP0050.ColorR) getConstInnerRow(offset + 0, $color_p);
	}
	
	public void color_p(mcframe.clientFSUB.FSUBP0050.ColorR row){
		setConstInnerRow(offset + 0, $color_p, row);
	}






	public MCRow getInnerRow(String name) {
		if ($color_p.equalsIgnoreCase(name)) {
			return color_p();
		}
		return super.getInnerRow(name);
	}

	public void setInnerRow(String name, MCRow value) {
		if ($color_p.equalsIgnoreCase(name)) {
			color_p(
				((MCContainerMeta) color_p_META).castInnerRow(mcframe.clientFSUB.FSUBP0050.ColorR.class, value)
			);
			return;
		}
		super.setInnerRow(name, value);
	}


	public MCNumber red() {
		return color_p().red();
	}

	public void red(MCNumber value) {
		color_p().red(value);
	}

	public void red(int value) {
		color_p().red(value);
	}

	public void red(long value) {
		color_p().red(value);
	}

	public void red(float value) {
		color_p().red(value);
	}

	public void red(double value) {
		color_p().red(value);
	}

	public MCNumber green() {
		return color_p().green();
	}

	public void green(MCNumber value) {
		color_p().green(value);
	}

	public void green(int value) {
		color_p().green(value);
	}

	public void green(long value) {
		color_p().green(value);
	}

	public void green(float value) {
		color_p().green(value);
	}

	public void green(double value) {
		color_p().green(value);
	}

	public MCNumber blue() {
		return color_p().blue();
	}

	public void blue(MCNumber value) {
		color_p().blue(value);
	}

	public void blue(int value) {
		color_p().blue(value);
	}

	public void blue(long value) {
		color_p().blue(value);
	}

	public void blue(float value) {
		color_p().blue(value);
	}

	public void blue(double value) {
		color_p().blue(value);
	}

}

