package mcframe.clientFSBA.FSBAP0320;

import java.awt.Color;

public class WBP_ColorInfo {

	/**
	 * 色情報です。
	 */
	protected Color _color = null;
	
	/**
	 * コンストラクタです。
	 */
	public WBP_ColorInfo() {}
	
	/**
	 * 色情報を設定します。
	 * 
	 * @param color 色情報
	 */
	public void setColor(Color color) {
		_color = color;
	}
	
	/**
	 * 色情報を返します。<p>
	 * 色情報が設定されていない場合は null を返します。
	 *
	 * @return 色情報、または null
	 */
	public Color getColor() {
		return _color;
	}
	
}