package mcframe.clientFSBA.FSBAP0470;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Diff"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class DiffR_FW_A extends MCConstRow {

	/**
	 * 月 月.<p>
	 *
	 */
	public static final String $month = "month";
	/**
	 * 週 週.<p>
	 *
	 */
	public static final String $week = "week";
	/**
	 * 曜日 曜日.<p>
	 *
	 */
	public static final String $day_of_week_type = "day_of_week_type";
	/**
	 * 曜日名 曜日名.<p>
	 *
	 */
	public static final String $day_of_week_type_nm = "day_of_week_type_nm";
	/**
	 * 日 日.<p>
	 *
	 */
	public static final String $day = "day";
	/**
	 * 時 時.<p>
	 *
	 */
	public static final String $hour = "hour";
	/**
	 * 分 分.<p>
	 *
	 */
	public static final String $minute = "minute";


	public static final MCMeta month_META = createNumberMeta($month);
	public static final MCMeta week_META = createNumberMeta($week);
	public static final MCMeta day_of_week_type_META = createStringMeta($day_of_week_type);
	public static final MCMeta day_of_week_type_nm_META = createStringMeta($day_of_week_type_nm);
	public static final MCMeta day_META = createNumberMeta($day);
	public static final MCMeta hour_META = createNumberMeta($hour);
	public static final MCMeta minute_META = createNumberMeta($minute);

	protected static final ConstMetaList<DiffR> constMetas = new ConstMetaList<DiffR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			month_META,
			week_META,
			day_of_week_type_META,
			day_of_week_type_nm_META,
			day_META,
			hour_META,
			minute_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected DiffR_FW_A(ConstMetaList<? extends DiffR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public DiffR clone() {
		return (DiffR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public DiffR createInstance() {
		return (DiffR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public DiffR getValues(String... names) {
		return (DiffR) super.getValues(names);
	}



	/**
	 * 月 月.<p>
	 *
	 */
	public MCNumber month() {
		return getConstNumber(offset + 0, $month);
	}

	/**
	 * 月 月.<p>
	 *
	 */
	public void month(MCNumber value) {
		setConstNumber(offset + 0, $month, value);
	}

	/**
	 * 月 月.<p>
	 *
	 */
	public void month(int value) {
		setConstNumber(offset + 0, $month, value);
	}

	/**
	 * 月 月.<p>
	 *
	 */
	public void month(long value) {
		setConstNumber(offset + 0, $month, value);
	}

	/**
	 * 月 月.<p>
	 *
	 */
	public void month(float value) {
		setConstNumber(offset + 0, $month, value);
	}

	/**
	 * 月 月.<p>
	 *
	 */
	public void month(double value) {
		setConstNumber(offset + 0, $month, value);
	}


	/**
	 * 週 週.<p>
	 *
	 */
	public MCNumber week() {
		return getConstNumber(offset + 1, $week);
	}

	/**
	 * 週 週.<p>
	 *
	 */
	public void week(MCNumber value) {
		setConstNumber(offset + 1, $week, value);
	}

	/**
	 * 週 週.<p>
	 *
	 */
	public void week(int value) {
		setConstNumber(offset + 1, $week, value);
	}

	/**
	 * 週 週.<p>
	 *
	 */
	public void week(long value) {
		setConstNumber(offset + 1, $week, value);
	}

	/**
	 * 週 週.<p>
	 *
	 */
	public void week(float value) {
		setConstNumber(offset + 1, $week, value);
	}

	/**
	 * 週 週.<p>
	 *
	 */
	public void week(double value) {
		setConstNumber(offset + 1, $week, value);
	}


	/**
	 * 曜日 曜日.<p>
	 *
	 */
	public String day_of_week_type() {
		return getConstString(offset + 2, $day_of_week_type);
	}

	/**
	 * 曜日 曜日.<p>
	 *
	 */
	public void day_of_week_type(String value) {
		setConstString(offset + 2, $day_of_week_type, value);
	}


	/**
	 * 曜日名 曜日名.<p>
	 *
	 */
	public String day_of_week_type_nm() {
		return getConstString(offset + 3, $day_of_week_type_nm);
	}

	/**
	 * 曜日名 曜日名.<p>
	 *
	 */
	public void day_of_week_type_nm(String value) {
		setConstString(offset + 3, $day_of_week_type_nm, value);
	}


	/**
	 * 日 日.<p>
	 *
	 */
	public MCNumber day() {
		return getConstNumber(offset + 4, $day);
	}

	/**
	 * 日 日.<p>
	 *
	 */
	public void day(MCNumber value) {
		setConstNumber(offset + 4, $day, value);
	}

	/**
	 * 日 日.<p>
	 *
	 */
	public void day(int value) {
		setConstNumber(offset + 4, $day, value);
	}

	/**
	 * 日 日.<p>
	 *
	 */
	public void day(long value) {
		setConstNumber(offset + 4, $day, value);
	}

	/**
	 * 日 日.<p>
	 *
	 */
	public void day(float value) {
		setConstNumber(offset + 4, $day, value);
	}

	/**
	 * 日 日.<p>
	 *
	 */
	public void day(double value) {
		setConstNumber(offset + 4, $day, value);
	}


	/**
	 * 時 時.<p>
	 *
	 */
	public MCNumber hour() {
		return getConstNumber(offset + 5, $hour);
	}

	/**
	 * 時 時.<p>
	 *
	 */
	public void hour(MCNumber value) {
		setConstNumber(offset + 5, $hour, value);
	}

	/**
	 * 時 時.<p>
	 *
	 */
	public void hour(int value) {
		setConstNumber(offset + 5, $hour, value);
	}

	/**
	 * 時 時.<p>
	 *
	 */
	public void hour(long value) {
		setConstNumber(offset + 5, $hour, value);
	}

	/**
	 * 時 時.<p>
	 *
	 */
	public void hour(float value) {
		setConstNumber(offset + 5, $hour, value);
	}

	/**
	 * 時 時.<p>
	 *
	 */
	public void hour(double value) {
		setConstNumber(offset + 5, $hour, value);
	}


	/**
	 * 分 分.<p>
	 *
	 */
	public MCNumber minute() {
		return getConstNumber(offset + 6, $minute);
	}

	/**
	 * 分 分.<p>
	 *
	 */
	public void minute(MCNumber value) {
		setConstNumber(offset + 6, $minute, value);
	}

	/**
	 * 分 分.<p>
	 *
	 */
	public void minute(int value) {
		setConstNumber(offset + 6, $minute, value);
	}

	/**
	 * 分 分.<p>
	 *
	 */
	public void minute(long value) {
		setConstNumber(offset + 6, $minute, value);
	}

	/**
	 * 分 分.<p>
	 *
	 */
	public void minute(float value) {
		setConstNumber(offset + 6, $minute, value);
	}

	/**
	 * 分 分.<p>
	 *
	 */
	public void minute(double value) {
		setConstNumber(offset + 6, $minute, value);
	}


	public String getString(String name) {
		if ($day_of_week_type.equalsIgnoreCase(name)) {
			return day_of_week_type();
		}
		if ($day_of_week_type_nm.equalsIgnoreCase(name)) {
			return day_of_week_type_nm();
		}
		return super.getString(name);
	}
	public MCNumber getNumber(String name) {
		if ($month.equalsIgnoreCase(name)) {
			return month();
		}
		if ($week.equalsIgnoreCase(name)) {
			return week();
		}
		if ($day.equalsIgnoreCase(name)) {
			return day();
		}
		if ($hour.equalsIgnoreCase(name)) {
			return hour();
		}
		if ($minute.equalsIgnoreCase(name)) {
			return minute();
		}
		return super.getNumber(name);
	}

	public String getStringNE(String name) {
		if ($day_of_week_type.equalsIgnoreCase(name)) {
			return day_of_week_type();
		}
		if ($day_of_week_type_nm.equalsIgnoreCase(name)) {
			return day_of_week_type_nm();
		}
		return super.getStringNE(name);
	}
	public MCNumber getNumberNE(String name) {
		if ($month.equalsIgnoreCase(name)) {
			return month();
		}
		if ($week.equalsIgnoreCase(name)) {
			return week();
		}
		if ($day.equalsIgnoreCase(name)) {
			return day();
		}
		if ($hour.equalsIgnoreCase(name)) {
			return hour();
		}
		if ($minute.equalsIgnoreCase(name)) {
			return minute();
		}
		return super.getNumberNE(name);
	}

	public void setString(String name, String value) {
		if ($day_of_week_type.equalsIgnoreCase(name)) {
			day_of_week_type(value);
			return;
		}
		if ($day_of_week_type_nm.equalsIgnoreCase(name)) {
			day_of_week_type_nm(value);
			return;
		}
		super.setString(name, value);
	}
	public void setNumber(String name, MCNumber value) {
		if ($month.equalsIgnoreCase(name)) {
			month(value);
			return;
		}
		if ($week.equalsIgnoreCase(name)) {
			week(value);
			return;
		}
		if ($day.equalsIgnoreCase(name)) {
			day(value);
			return;
		}
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, int value) {
		if ($month.equalsIgnoreCase(name)) {
			month(value);
			return;
		}
		if ($week.equalsIgnoreCase(name)) {
			week(value);
			return;
		}
		if ($day.equalsIgnoreCase(name)) {
			day(value);
			return;
		}
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, long value) {
		if ($month.equalsIgnoreCase(name)) {
			month(value);
			return;
		}
		if ($week.equalsIgnoreCase(name)) {
			week(value);
			return;
		}
		if ($day.equalsIgnoreCase(name)) {
			day(value);
			return;
		}
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, float value) {
		if ($month.equalsIgnoreCase(name)) {
			month(value);
			return;
		}
		if ($week.equalsIgnoreCase(name)) {
			week(value);
			return;
		}
		if ($day.equalsIgnoreCase(name)) {
			day(value);
			return;
		}
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, double value) {
		if ($month.equalsIgnoreCase(name)) {
			month(value);
			return;
		}
		if ($week.equalsIgnoreCase(name)) {
			week(value);
			return;
		}
		if ($day.equalsIgnoreCase(name)) {
			day(value);
			return;
		}
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		super.setNumber(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($day_of_week_type.equalsIgnoreCase(name)) {
			day_of_week_type(value);
			return;
		}
		if ($day_of_week_type_nm.equalsIgnoreCase(name)) {
			day_of_week_type_nm(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setNumberNE(String name, MCNumber value) {
		if ($month.equalsIgnoreCase(name)) {
			month(value);
			return;
		}
		if ($week.equalsIgnoreCase(name)) {
			week(value);
			return;
		}
		if ($day.equalsIgnoreCase(name)) {
			day(value);
			return;
		}
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, int value) {
		if ($month.equalsIgnoreCase(name)) {
			month(value);
			return;
		}
		if ($week.equalsIgnoreCase(name)) {
			week(value);
			return;
		}
		if ($day.equalsIgnoreCase(name)) {
			day(value);
			return;
		}
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, long value) {
		if ($month.equalsIgnoreCase(name)) {
			month(value);
			return;
		}
		if ($week.equalsIgnoreCase(name)) {
			week(value);
			return;
		}
		if ($day.equalsIgnoreCase(name)) {
			day(value);
			return;
		}
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, float value) {
		if ($month.equalsIgnoreCase(name)) {
			month(value);
			return;
		}
		if ($week.equalsIgnoreCase(name)) {
			week(value);
			return;
		}
		if ($day.equalsIgnoreCase(name)) {
			day(value);
			return;
		}
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, double value) {
		if ($month.equalsIgnoreCase(name)) {
			month(value);
			return;
		}
		if ($week.equalsIgnoreCase(name)) {
			week(value);
			return;
		}
		if ($day.equalsIgnoreCase(name)) {
			day(value);
			return;
		}
		if ($hour.equalsIgnoreCase(name)) {
			hour(value);
			return;
		}
		if ($minute.equalsIgnoreCase(name)) {
			minute(value);
			return;
		}
		super.setNumberNE(name, value);
	}



}

