package mcframe.clientFSBA.FSBAP0470;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBAP0470"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP0470_FW_A extends mcframe.clientFXBA.FXBAP0150.FXBAP0150{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0470";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Value]ブロック関連のField定義
	public MCPanel ValuePanel = null;
	// [Value]ブロックの項目のField定義
	// [Date]ブロック関連のField定義
	public MCPanel DatePanel = null;
	// [Date]ブロックの項目のField定義
	/**
	 * 今日 今日.<p>
	 *
	 */
	public MCCheckBox Date_today = null;
	/**
	 * 月初 月初.<p>
	 *
	 */
	public MCCheckBox Date_first = null;
	/**
	 * 月末 月末.<p>
	 *
	 */
	public MCCheckBox Date_last = null;
	public MCLabel Date_date_Label = null;
	/**
	 * 日時 日時.<p>
	 *
	 */
	public MCDateField Date_date = null;
	// [Diff]ブロック関連のField定義
	public MCPanel DiffPanel = null;
	public MCTitledBorder DiffTitledBorder = null;
	// [Diff]ブロックの項目のField定義
	public MCLabel Diff_month_Label = null;
	/**
	 * 月 月.<p>
	 *
	 */
	public MCNumberField Diff_month = null;
	public MCLabel Diff_week_Label = null;
	/**
	 * 週 週.<p>
	 *
	 */
	public MCNumberField Diff_week = null;
	public MCLabel Diff_day_of_week_type_Label = null;
	/**
	 * 曜日 曜日.<p>
	 *
	 */
	public MCTextComboBox Diff_day_of_week_type = null;
	/**
	 * 曜日名 曜日名.<p>
	 *
	 */
	public MCTextField Diff_day_of_week_type_nm = null;
	public MCLabel Diff_day_Label = null;
	/**
	 * 日 日.<p>
	 *
	 */
	public MCNumberField Diff_day = null;
	public MCLabel Diff_hour_Label = null;
	/**
	 * 時 時.<p>
	 *
	 */
	public MCNumberField Diff_hour = null;
	public MCLabel Diff_minute_Label = null;
	/**
	 * 分 分.<p>
	 *
	 */
	public MCNumberField Diff_minute = null;
	/** [EDITABLE]モードを表す定数 */
	public static final String EDITABLE = "EDITABLE";
	/** [READ_ONLY]モードを表す定数 */
	public static final String READ_ONLY = "READ_ONLY";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{EDITABLE, READ_ONLY};
	
	/** [Date]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0470.DateR aDateR;
	/** [Diff]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0470.DiffR aDiffR;

	/**
	 * 項目コピーによってaDateRを設定します。
	 *
	 * aDateRのインスタンスは変更されません。
	 *
	 * @param row DateR
	 */
	public void setDateR(mcframe.clientFSBA.FSBAP0470.DateR row) {
		if (row != null) {
			MCRow.copyall(getDateR(), row);
		}
	}

	/**
	 * [Date]ブロックのコンテナaDateRを返します。
	 *
	 * @return DateR
	 */
	public mcframe.clientFSBA.FSBAP0470.DateR getDateR() {
		return aDateR;
	}

	/**
	 * aDateRを作成します。
	 *
	 * @return DateR
	 */
	public mcframe.clientFSBA.FSBAP0470.DateR createDateR() {
		return mcframe.clientFSBA.FSBAP0470.DateR.create();
	}

	/**
	 * 項目コピーによってaDiffRを設定します。
	 *
	 * aDiffRのインスタンスは変更されません。
	 *
	 * @param row DiffR
	 */
	public void setDiffR(mcframe.clientFSBA.FSBAP0470.DiffR row) {
		if (row != null) {
			MCRow.copyall(getDiffR(), row);
		}
	}

	/**
	 * [Diff]ブロックのコンテナaDiffRを返します。
	 *
	 * @return DiffR
	 */
	public mcframe.clientFSBA.FSBAP0470.DiffR getDiffR() {
		return aDiffR;
	}

	/**
	 * aDiffRを作成します。
	 *
	 * @return DiffR
	 */
	public mcframe.clientFSBA.FSBAP0470.DiffR createDiffR() {
		return mcframe.clientFSBA.FSBAP0470.DiffR.create();
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getDateR())) ret.add(getDateR());
		if(!MCCollectionUtil.contains(ret, getDiffR())) ret.add(getDiffR());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getDateR()) return "Date";
		if(aCnt == getDiffR()) return "Diff";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("Date")) return getDateR();
		if(bId.equals("Diff")) return getDiffR();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(ValuePanel);
		ret.add(DatePanel);
		ret.add(DiffPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0470_FW_A() {
		aDateR = createDateR();
		aDiffR = createDiffR();

	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP0470_FW.jbCreateValue((FSBAP0470)this);
		FSBAP0470_FW.jbCreateDate((FSBAP0470)this);
		FSBAP0470_FW.jbCreateDiff((FSBAP0470)this);
	}

	/**
	 * [Value]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateValue(FSBAP0470 p) {
	}

	/**
	 * [Date]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateDate(FSBAP0470 p) {
	}

	/**
	 * [Diff]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateDiff(FSBAP0470 p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}

	
	/** [Diff_day_of_week_type_ListPutter]の定義 */
	private MCListPutter Diff_day_of_week_type_p = null;

	/**
	 * [Diff_day_of_week_type_ListPutter]の取得
	 */
	protected MCListPutter getDiff_day_of_week_type_ListPutter() {
		if (Diff_day_of_week_type_p == null) {
			Diff_day_of_week_type_p = createDiff_day_of_week_type_ListPutter(Diff_day_of_week_type, "day_of_week_type", "day_of_week_type_nm");

		}
		return Diff_day_of_week_type_p;
	}
	

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP0470 create(){
		FSBAP0470 p = new FSBAP0470();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}


	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP0470_FW.jbfInitValue((FSBAP0470)this);
		FSBAP0470_FW.jbfInitDate((FSBAP0470)this);
		FSBAP0470_FW.jbfInitDiff((FSBAP0470)this);
		FSBAP0470_FW.jbInitValue((FSBAP0470)this);
		FSBAP0470_FW.jbInitDate((FSBAP0470)this);
		FSBAP0470_FW.jbInitDiff((FSBAP0470)this);
	}

	/**
	 * [Value]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitValue(FSBAP0470 p) {
		// ブロック関連の初期化
		p.ValuePanel = p.beansFactory.createPanel("Value");
		// ブロックの項目の初期化
	}

	/**
	 * [Date]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitDate(FSBAP0470 p) {
		// ブロック関連の初期化
		p.DatePanel = p.beansFactory.createPanel("Date");
		// ブロックの項目の初期化
		p.Date_today = p.beansFactory.createCheckBox("Date.today");
		p.Date_first = p.beansFactory.createCheckBox("Date.first");
		p.Date_last = p.beansFactory.createCheckBox("Date.last");
		p.Date_date_Label = p.beansFactory.createLabel("Date.date_Label");
		p.Date_date = p.beansFactory.createDateField("Date.date");
		p.Date_date.setLabel(p.Date_date_Label);
	}

	/**
	 * [Diff]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitDiff(FSBAP0470 p) {
		// ブロック関連の初期化
		p.DiffPanel = p.beansFactory.createPanel("Diff");
		p.DiffTitledBorder = p.beansFactory.createTitledBorder();
		// ブロックの項目の初期化
		p.Diff_month_Label = p.beansFactory.createLabel("Diff.month_Label");
		p.Diff_month = p.beansFactory.createNumberField("Diff.month");
		p.Diff_month.setLabel(p.Diff_month_Label);
		p.Diff_week_Label = p.beansFactory.createLabel("Diff.week_Label");
		p.Diff_week = p.beansFactory.createNumberField("Diff.week");
		p.Diff_week.setLabel(p.Diff_week_Label);
		p.Diff_day_of_week_type_Label = p.beansFactory.createLabel("Diff.day_of_week_type_Label");
		p.Diff_day_of_week_type = p.beansFactory.createTextComboBox("Diff.day_of_week_type");
		p.Diff_day_of_week_type.setLabel(p.Diff_day_of_week_type_Label);
		p.Diff_day_of_week_type_nm = p.beansFactory.createTextField("Diff.day_of_week_type_nm");
		p.Diff_day_Label = p.beansFactory.createLabel("Diff.day_Label");
		p.Diff_day = p.beansFactory.createNumberField("Diff.day");
		p.Diff_day.setLabel(p.Diff_day_Label);
		p.Diff_hour_Label = p.beansFactory.createLabel("Diff.hour_Label");
		p.Diff_hour = p.beansFactory.createNumberField("Diff.hour");
		p.Diff_hour.setLabel(p.Diff_hour_Label);
		p.Diff_minute_Label = p.beansFactory.createLabel("Diff.minute_Label");
		p.Diff_minute = p.beansFactory.createNumberField("Diff.minute");
		p.Diff_minute.setLabel(p.Diff_minute_Label);
	}

	/**
	 * [Value]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitValue(FSBAP0470 p) {
		// ブロック関連の初期化
		p.add(p.ValuePanel);
		p.setLastBeans(p.ValuePanel);
		p.ValuePanel.setLayoutPosition("C");
		// ブロックの項目の初期化
		p.ValuePanel.add(p.DatePanel, null);
		p.ValuePanel.setLastBeans(p.DatePanel);
		p.DatePanel.setNextBeans(p.DiffPanel);
		p.ValuePanel.add(p.DiffPanel, null);
	}

	/**
	 * [Date]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitDate(FSBAP0470 p) {
		// ブロック関連の初期化
		p.DatePanel.setLayoutPosition("C");
		// ブロックの項目の初期化
		p.DatePanel.add(p.Date_today);
		p.DatePanel.setLastBeans(p.Date_today);
		p.Date_today.setNextBeans(p.Date_first);
		p.Date_today.setRow(p.getDateR(), mcframe.clientFSBA.FSBAP0470.DateR.today_META);
		p.DatePanel.add(p.Date_first);
		p.Date_first.setNextBeans(p.Date_last);
		p.Date_first.setRow(p.getDateR(), mcframe.clientFSBA.FSBAP0470.DateR.first_META);
		p.DatePanel.add(p.Date_last);
		p.Date_last.setNextBeans(p.Date_date);
		p.Date_last.setRow(p.getDateR(), mcframe.clientFSBA.FSBAP0470.DateR.last_META);
		p.DatePanel.add(p.Date_date_Label);
		p.DatePanel.add(p.Date_date);
		p.Date_date.setRow(p.getDateR(), mcframe.clientFSBA.FSBAP0470.DateR.date_META);
		p.Date_date.setFormatID("YMDHM");
	}

	/**
	 * [Diff]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitDiff(FSBAP0470 p) {
		// ブロック関連の初期化
		p.DiffPanel.setBorder(p.DiffTitledBorder);
		p.DiffPanel.setLayoutPosition("C");
		// ブロックの項目の初期化
		p.DiffPanel.add(p.Diff_month_Label);
		p.DiffPanel.add(p.Diff_month);
		p.DiffPanel.setLastBeans(p.Diff_month);
		p.Diff_month.setNextBeans(p.Diff_week);
		p.Diff_month.setRow(p.getDiffR(), mcframe.clientFSBA.FSBAP0470.DiffR.month_META);
		p.DiffPanel.add(p.Diff_week_Label);
		p.DiffPanel.add(p.Diff_week);
		p.Diff_week.setNextBeans(p.Diff_day_of_week_type);
		p.Diff_week.setRow(p.getDiffR(), mcframe.clientFSBA.FSBAP0470.DiffR.week_META);
		p.Diff_day_of_week_type.setListType(MCListType.STRICT);
		p.Diff_day_of_week_type.setLinkBeans(p.Diff_day_of_week_type_nm);
		p.DiffPanel.add(p.Diff_day_of_week_type_Label);
		p.DiffPanel.add(p.Diff_day_of_week_type);
		p.Diff_day_of_week_type.setNextBeans(p.Diff_day_of_week_type_nm);
		p.Diff_day_of_week_type.setRow(p.getDiffR(), mcframe.clientFSBA.FSBAP0470.DiffR.day_of_week_type_META);
		p.DiffPanel.add(p.Diff_day_of_week_type_nm);
		p.Diff_day_of_week_type_nm.setNextBeans(p.Diff_day);
		p.Diff_day_of_week_type_nm.setRow(p.getDiffR(), mcframe.clientFSBA.FSBAP0470.DiffR.day_of_week_type_nm_META);
		p.DiffPanel.add(p.Diff_day_Label);
		p.DiffPanel.add(p.Diff_day);
		p.Diff_day.setNextBeans(p.Diff_hour);
		p.Diff_day.setRow(p.getDiffR(), mcframe.clientFSBA.FSBAP0470.DiffR.day_META);
		p.DiffPanel.add(p.Diff_hour_Label);
		p.DiffPanel.add(p.Diff_hour);
		p.Diff_hour.setNextBeans(p.Diff_minute);
		p.Diff_hour.setRow(p.getDiffR(), mcframe.clientFSBA.FSBAP0470.DiffR.hour_META);
		p.DiffPanel.add(p.Diff_minute_Label);
		p.DiffPanel.add(p.Diff_minute);
		p.Diff_minute.setRow(p.getDiffR(), mcframe.clientFSBA.FSBAP0470.DiffR.minute_META);
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "G";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP0470_FW.mcInitValue((FSBAP0470)this);
		FSBAP0470_FW.mcInitDate((FSBAP0470)this);
		FSBAP0470_FW.mcInitDiff((FSBAP0470)this);

		// [EDITABLE]ステータスのモードの設定
		FSBAP0470_FW.statusInitEDITABLE_Value((FSBAP0470)this);
		FSBAP0470_FW.statusInitEDITABLE_Date((FSBAP0470)this);
		FSBAP0470_FW.statusInitEDITABLE_Diff((FSBAP0470)this);

		// [READ_ONLY]ステータスのモードの設定
		FSBAP0470_FW.statusInitREAD__ONLY_Value((FSBAP0470)this);
		FSBAP0470_FW.statusInitREAD__ONLY_Date((FSBAP0470)this);
		FSBAP0470_FW.statusInitREAD__ONLY_Diff((FSBAP0470)this);

	}

	/**
	 *  [Value]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitValue(FSBAP0470 p) {
	}

	/**
	 *  [Date]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitDate(FSBAP0470 p) {
		p.Date_today.addAllListener(p);
		p.Date_first.addAllListener(p);
		p.Date_last.addAllListener(p);
		p.Date_date.setListListener(p);
		p.Date_date.addAllListener(p);
	}

	/**
	 *  [Diff]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitDiff(FSBAP0470 p) {
		p.Diff_month.setListListener(p);
		p.Diff_month.addAllListener(p);
		p.Diff_week.setListListener(p);
		p.Diff_week.addAllListener(p);
		p.Diff_day_of_week_type.setListListener(p);
		p.Diff_day_of_week_type.addAllListener(p);
		p.Diff_day_of_week_type_nm.setListListener(p);
		p.Diff_day_of_week_type_nm.addAllListener(p);
		p.Diff_day.setListListener(p);
		p.Diff_day.addAllListener(p);
		p.Diff_hour.setListListener(p);
		p.Diff_hour.addAllListener(p);
		p.Diff_minute.setListListener(p);
		p.Diff_minute.addAllListener(p);
	}

	/**
	 * [EDITABLE]ステータスの[Value]ブロックのモードの設定
	 */
	protected static void statusInitEDITABLE_Value(FSBAP0470 p){

	}

	/**
	 * [EDITABLE]ステータスの[Date]ブロックのモードの設定
	 */
	protected static void statusInitEDITABLE_Date(FSBAP0470 p){
		p.Date_today.putMode(p, EDITABLE, MCMode.ENABLE);
		p.Date_first.putMode(p, EDITABLE, MCMode.ENABLE);
		p.Date_last.putMode(p, EDITABLE, MCMode.ENABLE);
		p.Date_date.putMode(p, EDITABLE, MCMode.ENABLE);

	}

	/**
	 * [EDITABLE]ステータスの[Diff]ブロックのモードの設定
	 */
	protected static void statusInitEDITABLE_Diff(FSBAP0470 p){
		p.Diff_month.putMode(p, EDITABLE, MCMode.ENABLE);
		p.Diff_week.putMode(p, EDITABLE, MCMode.ENABLE);
		p.Diff_day_of_week_type.putMode(p, EDITABLE, MCMode.READ_ONLY);
		p.Diff_day_of_week_type_nm.putMode(p, EDITABLE, MCMode.READ_ONLY);
		p.Diff_day.putMode(p, EDITABLE, MCMode.ENABLE);
		p.Diff_hour.putMode(p, EDITABLE, MCMode.ENABLE);
		p.Diff_minute.putMode(p, EDITABLE, MCMode.ENABLE);

	}

	/**
	 * [READ_ONLY]ステータスの[Value]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_Value(FSBAP0470 p){

	}

	/**
	 * [READ_ONLY]ステータスの[Date]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_Date(FSBAP0470 p){
		p.Date_today.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.Date_first.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.Date_last.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.Date_date.putMode(p, READ_ONLY, MCMode.READ_ONLY);

	}

	/**
	 * [READ_ONLY]ステータスの[Diff]ブロックのモードの設定
	 */
	protected static void statusInitREAD__ONLY_Diff(FSBAP0470 p){
		p.Diff_month.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.Diff_week.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.Diff_day_of_week_type.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.Diff_day_of_week_type_nm.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.Diff_day.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.Diff_hour.putMode(p, READ_ONLY, MCMode.READ_ONLY);
		p.Diff_minute.putMode(p, READ_ONLY, MCMode.READ_ONLY);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return EDITABLE;
	}

	/**
	 * Table/Tree/GanttChartの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
		Diff_day_of_week_type.setListVisibleColumn(MCListLogic.getViewColumnName());
		Diff_day_of_week_type.getListConfig().setPutter(getDiff_day_of_week_type_ListPutter());
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
	}

	/**
	 * [Diff_day_of_week_type_ListPutter]の作成
	 */
	protected MCListPutter createDiff_day_of_week_type_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("FS.FSUAP0010.DayOfWeekType");
		return lp;
	}
	 

	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		if(combo == Diff_day_of_week_type) return getDiff_day_of_week_type(row, info);
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
	}

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == Date_today) return doDate_today_VC(info);
		if (vc == Date_first) return doDate_first_VC(info);
		if (vc == Date_last) return doDate_last_VC(info);
		if (vc == Date_date) return doDate_date_VC(info);
		if (vc == Diff_month) return doDiff_month_VC(info);
		if (vc == Diff_week) return doDiff_week_VC(info);
		if (vc == Diff_day_of_week_type) return doDiff_day_of_week_type_VC(info);
		if (vc == Diff_day_of_week_type_nm) return doDiff_day_of_week_type_nm_VC(info);
		if (vc == Diff_day) return doDiff_day_VC(info);
		if (vc == Diff_hour) return doDiff_hour_VC(info);
		if (vc == Diff_minute) return doDiff_minute_VC(info);
		return true;
	}

	/**
	 * [Date]パネルの[today]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDate_today_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Date]パネルの[first]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDate_first_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Date]パネルの[last]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDate_last_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Date]パネルの[date]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDate_date_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Diff]パネルの[month]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDiff_month_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Diff]パネルの[week]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDiff_week_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Diff]パネルの[day_of_week_type]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDiff_day_of_week_type_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Diff]パネルの[day_of_week_type_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDiff_day_of_week_type_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Diff]パネルの[day]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDiff_day_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Diff]パネルの[hour]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDiff_hour_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Diff]パネルの[minute]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doDiff_minute_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == Date_today) doDate_today_NC(info);
		else if (nc == Date_first) doDate_first_NC(info);
		else if (nc == Date_last) doDate_last_NC(info);
		else if (nc == Date_date) doDate_date_NC(info);
		else if (nc == Diff_month) doDiff_month_NC(info);
		else if (nc == Diff_week) doDiff_week_NC(info);
		else if (nc == Diff_day_of_week_type) doDiff_day_of_week_type_NC(info);
		else if (nc == Diff_day_of_week_type_nm) doDiff_day_of_week_type_nm_NC(info);
		else if (nc == Diff_day) doDiff_day_NC(info);
		else if (nc == Diff_hour) doDiff_hour_NC(info);
		else if (nc == Diff_minute) doDiff_minute_NC(info);
	}

	/**
	 * [Date]パネルの[today]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDate_today_NC(MCEventInfo info){
	}

	/**
	 * [Date]パネルの[first]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDate_first_NC(MCEventInfo info){
	}

	/**
	 * [Date]パネルの[last]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDate_last_NC(MCEventInfo info){
	}

	/**
	 * [Date]パネルの[date]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDate_date_NC(MCEventInfo info){
	}

	/**
	 * [Diff]パネルの[month]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDiff_month_NC(MCEventInfo info){
	}

	/**
	 * [Diff]パネルの[week]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDiff_week_NC(MCEventInfo info){
	}

	/**
	 * [Diff]パネルの[day_of_week_type]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDiff_day_of_week_type_NC(MCEventInfo info){
	}

	/**
	 * [Diff]パネルの[day_of_week_type_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDiff_day_of_week_type_nm_NC(MCEventInfo info){
	}

	/**
	 * [Diff]パネルの[day]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDiff_day_NC(MCEventInfo info){
	}

	/**
	 * [Diff]パネルの[hour]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDiff_hour_NC(MCEventInfo info){
	}

	/**
	 * [Diff]パネルの[minute]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDiff_minute_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == Date_today) doDate_today_NE(info);
		else if (ne == Date_first) doDate_first_NE(info);
		else if (ne == Date_last) doDate_last_NE(info);
		else if (ne == Date_date) doDate_date_NE(info);
		else if (ne == Diff_month) doDiff_month_NE(info);
		else if (ne == Diff_week) doDiff_week_NE(info);
		else if (ne == Diff_day_of_week_type) doDiff_day_of_week_type_NE(info);
		else if (ne == Diff_day_of_week_type_nm) doDiff_day_of_week_type_nm_NE(info);
		else if (ne == Diff_day) doDiff_day_NE(info);
		else if (ne == Diff_hour) doDiff_hour_NE(info);
		else if (ne == Diff_minute) doDiff_minute_NE(info);
	}

	/**
	 * [Date]パネルの[today]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDate_today_NE(MCEventInfo info){
	}

	/**
	 * [Date]パネルの[first]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDate_first_NE(MCEventInfo info){
	}

	/**
	 * [Date]パネルの[last]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDate_last_NE(MCEventInfo info){
	}

	/**
	 * [Date]パネルの[date]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDate_date_NE(MCEventInfo info){
	}

	/**
	 * [Diff]パネルの[month]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDiff_month_NE(MCEventInfo info){
	}

	/**
	 * [Diff]パネルの[week]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDiff_week_NE(MCEventInfo info){
	}

	/**
	 * [Diff]パネルの[day_of_week_type]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDiff_day_of_week_type_NE(MCEventInfo info){
	}

	/**
	 * [Diff]パネルの[day_of_week_type_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDiff_day_of_week_type_nm_NE(MCEventInfo info){
	}

	/**
	 * [Diff]パネルの[day]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDiff_day_NE(MCEventInfo info){
	}

	/**
	 * [Diff]パネルの[hour]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDiff_hour_NE(MCEventInfo info){
	}

	/**
	 * [Diff]パネルの[minute]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDiff_minute_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == Date_today) doDate_today_NX(info);
		else if (nx == Date_first) doDate_first_NX(info);
		else if (nx == Date_last) doDate_last_NX(info);
		else if (nx == Date_date) doDate_date_NX(info);
		else if (nx == Diff_month) doDiff_month_NX(info);
		else if (nx == Diff_week) doDiff_week_NX(info);
		else if (nx == Diff_day_of_week_type) doDiff_day_of_week_type_NX(info);
		else if (nx == Diff_day_of_week_type_nm) doDiff_day_of_week_type_nm_NX(info);
		else if (nx == Diff_day) doDiff_day_NX(info);
		else if (nx == Diff_hour) doDiff_hour_NX(info);
		else if (nx == Diff_minute) doDiff_minute_NX(info);
	}

	/**
	 * [Date]パネルの[today]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDate_today_NX(MCEventInfo info){
	}

	/**
	 * [Date]パネルの[first]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDate_first_NX(MCEventInfo info){
	}

	/**
	 * [Date]パネルの[last]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDate_last_NX(MCEventInfo info){
	}

	/**
	 * [Date]パネルの[date]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDate_date_NX(MCEventInfo info){
	}

	/**
	 * [Diff]パネルの[month]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDiff_month_NX(MCEventInfo info){
	}

	/**
	 * [Diff]パネルの[week]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDiff_week_NX(MCEventInfo info){
	}

	/**
	 * [Diff]パネルの[day_of_week_type]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDiff_day_of_week_type_NX(MCEventInfo info){
	}

	/**
	 * [Diff]パネルの[day_of_week_type_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDiff_day_of_week_type_nm_NX(MCEventInfo info){
	}

	/**
	 * [Diff]パネルの[day]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDiff_day_NX(MCEventInfo info){
	}

	/**
	 * [Diff]パネルの[hour]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDiff_hour_NX(MCEventInfo info){
	}

	/**
	 * [Diff]パネルの[minute]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDiff_minute_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == Date_date) doDate_date_LC(info);
		else if (lc == Diff_month) doDiff_month_LC(info);
		else if (lc == Diff_week) doDiff_week_LC(info);
		else if (lc == Diff_day_of_week_type) doDiff_day_of_week_type_LC(info);
		else if (lc == Diff_day_of_week_type_nm) doDiff_day_of_week_type_nm_LC(info);
		else if (lc == Diff_day) doDiff_day_LC(info);
		else if (lc == Diff_hour) doDiff_hour_LC(info);
		else if (lc == Diff_minute) doDiff_minute_LC(info);
	}

	/**
	 * [Date]パネルの[date]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDate_date_LC(MCEventInfo info){
	}

	/**
	 * [Diff]パネルの[month]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDiff_month_LC(MCEventInfo info){
	}

	/**
	 * [Diff]パネルの[week]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDiff_week_LC(MCEventInfo info){
	}

	/**
	 * [Diff]パネルの[day_of_week_type]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDiff_day_of_week_type_LC(MCEventInfo info){
	}

	/**
	 * [Diff]パネルの[day_of_week_type_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDiff_day_of_week_type_nm_LC(MCEventInfo info){
	}

	/**
	 * [Diff]パネルの[day]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDiff_day_LC(MCEventInfo info){
	}

	/**
	 * [Diff]パネルの[hour]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDiff_hour_LC(MCEventInfo info){
	}

	/**
	 * [Diff]パネルの[minute]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doDiff_minute_LC(MCEventInfo info){
	}

	/**
	 * コンボ／リストのリスト[Diff_day_of_week_type]の作成メソッド
	 */
	public MCList getDiff_day_of_week_type(MCRow row, MCEventInfo info){
		return ((mcframe.clientFSUA.FSUAP0010.FSUAP_List)MCListLogic.create("mcframe.clientFSUA.FSUAP0010.FSUAP_List", this)).getDayOfWeekType(row, info);
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}