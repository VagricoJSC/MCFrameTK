package mcframe.clientFSBA.FSBAP0470;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Date"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class DateR_FW_A extends MCConstRow {

	/**
	 * 今日 今日.<p>
	 *
	 */
	public static final String $today = "today";
	/**
	 * 月初 月初.<p>
	 *
	 */
	public static final String $first = "first";
	/**
	 * 月末 月末.<p>
	 *
	 */
	public static final String $last = "last";
	/**
	 * 日時 日時.<p>
	 *
	 */
	public static final String $date = "date";


	public static final MCMeta today_META = createBooleanMeta($today);
	public static final MCMeta first_META = createBooleanMeta($first);
	public static final MCMeta last_META = createBooleanMeta($last);
	public static final MCMeta date_META = createDateMeta($date);

	protected static final ConstMetaList<DateR> constMetas = new ConstMetaList<DateR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			today_META,
			first_META,
			last_META,
			date_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected DateR_FW_A(ConstMetaList<? extends DateR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public DateR clone() {
		return (DateR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public DateR createInstance() {
		return (DateR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public DateR getValues(String... names) {
		return (DateR) super.getValues(names);
	}



	/**
	 * 今日 今日.<p>
	 *
	 */
	public boolean today() {
		return getConstBoolean(offset + 0, $today);
	}

	/**
	 * 今日 今日.<p>
	 *
	 */
	public void today(boolean value) {
		setConstBoolean(offset + 0, $today, value);
	}


	/**
	 * 月初 月初.<p>
	 *
	 */
	public boolean first() {
		return getConstBoolean(offset + 1, $first);
	}

	/**
	 * 月初 月初.<p>
	 *
	 */
	public void first(boolean value) {
		setConstBoolean(offset + 1, $first, value);
	}


	/**
	 * 月末 月末.<p>
	 *
	 */
	public boolean last() {
		return getConstBoolean(offset + 2, $last);
	}

	/**
	 * 月末 月末.<p>
	 *
	 */
	public void last(boolean value) {
		setConstBoolean(offset + 2, $last, value);
	}


	/**
	 * 日時 日時.<p>
	 *
	 */
	public MCDate date() {
		return getConstDate(offset + 3, $date);
	}

	/**
	 * 日時 日時.<p>
	 *
	 */
	public void date(MCDate value) {
		setConstDate(offset + 3, $date, value);
	}


	public MCDate getDate(String name) {
		if ($date.equalsIgnoreCase(name)) {
			return date();
		}
		return super.getDate(name);
	}
	public boolean getBoolean(String name) {
		if ($today.equalsIgnoreCase(name)) {
			return today();
		}
		if ($first.equalsIgnoreCase(name)) {
			return first();
		}
		if ($last.equalsIgnoreCase(name)) {
			return last();
		}
		return super.getBoolean(name);
	}

	public MCDate getDateNE(String name) {
		if ($date.equalsIgnoreCase(name)) {
			return date();
		}
		return super.getDateNE(name);
	}
	public boolean getBooleanNE(String name) {
		if ($today.equalsIgnoreCase(name)) {
			return today();
		}
		if ($first.equalsIgnoreCase(name)) {
			return first();
		}
		if ($last.equalsIgnoreCase(name)) {
			return last();
		}
		return super.getBooleanNE(name);
	}

	public void setDate(String name, MCDate value) {
		if ($date.equalsIgnoreCase(name)) {
			date(value);
			return;
		}
		super.setDate(name, value);
	}
	public void setBoolean(String name, boolean value) {
		if ($today.equalsIgnoreCase(name)) {
			today(value);
			return;
		}
		if ($first.equalsIgnoreCase(name)) {
			first(value);
			return;
		}
		if ($last.equalsIgnoreCase(name)) {
			last(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setDateNE(String name, MCDate value) {
		if ($date.equalsIgnoreCase(name)) {
			date(value);
			return;
		}
		super.setDateNE(name, value);
	}
	public void setBooleanNE(String name, boolean value) {
		if ($today.equalsIgnoreCase(name)) {
			today(value);
			return;
		}
		if ($first.equalsIgnoreCase(name)) {
			first(value);
			return;
		}
		if ($last.equalsIgnoreCase(name)) {
			last(value);
			return;
		}
		super.setBooleanNE(name, value);
	}



}

