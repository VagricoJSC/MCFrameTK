package mcframe.clientFSBA.FSBAP0470;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;


import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import javax.swing.JComponent;

import mcframe.clientCore.dashboard.MCValueSupply;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP0470"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP0470_FW extends FSBAP0470_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START
	/**
	 * ラベル
	 */
	protected MCLabel Value_value_Label = null;

	/**
	 * パラメータ
	 */
	protected MCValueSupply.DateVS _param = null;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0470_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	@Override
	public void layoutInit() {
		// 7013-0074(【アプリ多言語に伴う対応】省略改行無しラベル対応（$fit$改行機能＋α）)
		// レイアウトの限界値を拡大し幅980まで自動レイアウトできるようにする。
		_setDefaultBounds(new Rectangle(0, 0, 980, 600));
		// 7013-0074 ここまで
		super.layoutInit();

		// 7013-0074(【アプリ多言語に伴う対応】省略改行無しラベル対応（$fit$改行機能＋α）)
		// フォント比率でパネルのサイズがぶれるため固定する。
		Dimension d = _getDefaultSize();
		setDefaultRatioBounds(new Rectangle(0, 0, d.width, d.height));

		Component[] compos = ValuePanel.getComponents();

		ValuePanel.removeAll();
		ValuePanel.setLayout(new BorderLayout(LAYOUT_MARGIN, 0));

		Value_value_Label = beansFactory.createLabel("Value.value_Label");
		Value_value_Label.setVerticalAlignment(MCLabel.TOP);
		MCPanel subPanel = beansFactory.createPanel("Value.sub");
		subPanel.setOpaque(false);
		subPanel.setLayout(null);
		for (Component compo : compos) {
			subPanel.add(compo);
		}

		ValuePanel.add(Value_value_Label, BorderLayout.WEST);
		ValuePanel.add(subPanel, BorderLayout.CENTER);
	}

	// 7013-0074(【アプリ多言語に伴う対応】省略改行無しラベル対応（$fit$改行機能＋α）)
	// デフォルトの高さを正確に計算する。
	// 最大値を指定してしまうと隙間が空きすぎてしまう。
	private Dimension _getDefaultSize() {
		int w = 0;
		int h = 0;
		JComponent comps[] = MCBeansUtil.getAllComponents(JComponent.class, this);
		for (JComponent c : comps) {
			Point p = _getDefaultPoint(c, this);
			Dimension s = c.getSize();
			w = Math.max(w, p.x + s.width);
			h = Math.max(h, p.y + s.height);
		}
		return new Dimension(w, h);
	}

	// パネル座標に変換する。
	private Point _getDefaultPoint(JComponent c1, Container c2) {
		int x = c1.getX();
		int y = c1.getY();

		Container c3 = c1.getParent();
		while (c3 != c2 && c3 != null) {
			x = x + c3.getX();
			y = y + c3.getY();
			c3 = c3.getParent();
		}

		return new Point(x, y);
	}

	@Override
	public void doDate_today_NC(MCEventInfo info) {
		super.doDate_today_NC(info);

		if (getDateR().today()) {
			setValueEx(Date_first, false);
			setValueEx(Date_last, false);
			setValueEx(Date_date, null);
		}
	}

	@Override
	public void doDate_first_NC(MCEventInfo info) {
		super.doDate_first_NC(info);

		if (getDateR().first()) {
			setValueEx(Date_today, false);
			setValueEx(Date_last, false);
			setValueEx(Date_date, null);
		}
	}

	@Override
	public void doDate_last_NC(MCEventInfo info) {
		super.doDate_last_NC(info);

		if (getDateR().last()) {
			setValueEx(Date_today, false);
			setValueEx(Date_first, false);
			setValueEx(Date_date, null);
		}
	}

	@Override
	public void doDate_date_NC(MCEventInfo info) {
		super.doDate_date_NC(info);
		
		if (getDateR().date() != null) {
			setValueEx(Date_today, false);
			setValueEx(Date_first, false);
			setValueEx(Date_last, false);
		}
	}

	@Override
	public void doDiff_week_NC(MCEventInfo info) {
		super.doDiff_week_NC(info);
		
		if (getDiffR().week() == null) {
			setValueEx(Diff_day_of_week_type, null);
		}
		updateDayOfWeekTypeMode();
	}

	/**
	 * 曜日コンボボックスのモードを更新します。
	 */
	protected void updateDayOfWeekTypeMode() {
		MCMode mode = (getDiffR().week() == null) ? MCMode.READ_ONLY : MCMode.ENABLE;
		Diff_day_of_week_type.setMode(mode);
	}

	@Override
	public MCModeBeans[] getModeCtrlBeans() {
		// モードは入力状態で動的に変更する
		return null;
	}

	@Override
	public MCValueSupply[] getParam() {
		return new MCValueSupply[] { _param };
	}

	@Override
	public void setParam(MCValueSupply...param) {
		_param = (MCValueSupply.DateVS) param[0];
		Value_value_Label.setText(_param.name());	// 表示名称の設定
		Date_date.setMessageName(_param.name());	// メッセージ用表示名称の設定

		DateR dateR = getDateR();
		dateR.today(_param.today());
		dateR.first(_param.first());
		dateR.last(_param.last());
		dateR.date(_param.date());
		DiffR diffR = getDiffR();
		diffR.month(_param.diff_month());
		diffR.week(_param.diff_week());
		if (_param.diff_day_of_week() != null) {
			diffR.day_of_week_type(_param.diff_day_of_week().toSimpleString());
		}
		diffR.day(_param.diff_day());
		diffR.hour(_param.diff_hour());
		diffR.minute(_param.diff_minute());
		updateDayOfWeekTypeMode();
	}

	@Override
	public MCRowBeans checkRequiredValue() {
		if (!_param.required()) {
			return null;
		}

		DateR dateR = getDateR();
		DiffR diffR = getDiffR();
		return (_param.test(
				dateR.today(), dateR.first(), dateR.last(), dateR.date(),
				diffR.month(), diffR.week(), MCNumber.valueOf(diffR.day_of_week_type()),
				diffR.day(), diffR.hour(), diffR.minute()
			) == null) ? Date_date : null;
	}

	@Override
	public void updateParam() {
		DateR dateR = getDateR();
		DiffR diffR = getDiffR();
		_param.value(
			dateR.today(), dateR.first(), dateR.last(), dateR.date(),
			diffR.month(), diffR.week(), MCNumber.valueOf(diffR.day_of_week_type()),
			diffR.day(), diffR.hour(), diffR.minute()
		);
	}

}