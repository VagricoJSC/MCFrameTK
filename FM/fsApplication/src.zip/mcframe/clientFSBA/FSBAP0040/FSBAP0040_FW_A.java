package mcframe.clientFSBA.FSBAP0040;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBAP0040"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP0040_FW_A extends mcframe.clientFSUC.FSUCP0000.FSUCP_PanelBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0040";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [List]ブロック関連のField定義
	public MCPanel ListPanel = null;
	public MCScrollPane ListScrollPane = null;
	public MCTable2<mcframe.clientFSBA.FSBAP0040.ListR> ListTable = null;
	// [List]ブロックの項目のField定義
	/**
	 * メッセージＩＤ メッセージＩＤ.<p>
	 *
	 */
	public MCColumnConfig columnList_ID = null;
	/**
	 * メッセージレベル レベル.<p>
	 *
	 */
	public MCColumnConfig columnList_Lv = null;
	public MCColumnConfig columnList_Message = null;
	/**
	 * メッセージ メッセージ.<p>
	 *
	 */
	public MCColumnConfig columnList_MessageView = null;
	// [Icon]ブロック関連のField定義
	public MCPanel IconPanel = null;
	// [Icon]ブロックの項目のField定義
	public MCLabel Icon_Icon = null;
	// [Message]ブロック関連のField定義
	public MCPanel MessagePanel = null;
	// [Message]ブロックの項目のField定義
	public MCScrollPane Message_MessageScrollPane = null;
	/**
	 *  メッセージ.<p>
	 *
	 */
	public MCTextArea Message_Message = null;
	// [Command]ブロック関連のField定義
	public MCPanel CommandPanel = null;
	// [Command]ブロックの項目のField定義
	/**
	 * 了解 了解.<p>
	 *
	 */
	public MCButton Command_OK = null;
	/**
	 * はい はい.<p>
	 *
	 */
	public MCButton Command_Yes = null;
	/**
	 * いいえ いいえ.<p>
	 *
	 */
	public MCButton Command_No = null;
	/**
	 * キャンセル キャンセル.<p>
	 *
	 */
	public MCButton Command_Cancel = null;
	/** [INIT]モードを表す定数 */
	public static final String INIT = "INIT";
	/** [PARTS]モードを表す定数 */
	public static final String PARTS = "PARTS";
	/** [OK]モードを表す定数 */
	public static final String OK = "OK";
	/** [Y_N]モードを表す定数 */
	public static final String Y_N = "Y_N";
	/** [Y_N_C]モードを表す定数 */
	public static final String Y_N_C = "Y_N_C";
	/** [O_C]モードを表す定数 */
	public static final String O_C = "O_C";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{INIT, PARTS, OK, Y_N, Y_N_C, O_C};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	
	/** [List]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0040.ListR> aListL;
	/** [Message]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0040.MessageR aMessageR;

	/**
	 * コピーによってaListLを設定します。
	 *
	 * aListLのインスタンスは変更されません。
	 *
	 * @param dataset ListL
	 */
	public void setListL(MCList<mcframe.clientFSBA.FSBAP0040.ListR> aList) {
		if (getListL() != aList) {
			getListL().setAll(aList);
		}
	}

	/**
	 * [List]ブロックのコンテナaListLを返します。
	 *
	 * @return ListL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0040.ListR> getListL() {
		return aListL;
	}

	/**
	 * aListRを作成します。
	 *
	 * @return ListR
	 */
	public mcframe.clientFSBA.FSBAP0040.ListR createListR() {
		return mcframe.clientFSBA.FSBAP0040.ListR.create();
	}

	/**
	 * aListLを作成します。
	 *
	 * @return ListL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0040.ListR> createListL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0040.ListR.class);
	}

	/**
	 * ListTableを初期化します。
	 */
	protected void createListTable(){
		if(ListTable == null){
			ListTable = beansFactory.createTable2("List.table");
		}
	}

	/**
	 * 項目コピーによってaMessageRを設定します。
	 *
	 * aMessageRのインスタンスは変更されません。
	 *
	 * @param row MessageR
	 */
	public void setMessageR(mcframe.clientFSBA.FSBAP0040.MessageR row) {
		if (row != null) {
			MCRow.copyall(getMessageR(), row);
		}
	}

	/**
	 * [Message]ブロックのコンテナaMessageRを返します。
	 *
	 * @return MessageR
	 */
	public mcframe.clientFSBA.FSBAP0040.MessageR getMessageR() {
		return aMessageR;
	}

	/**
	 * aMessageRを作成します。
	 *
	 * @return MessageR
	 */
	public mcframe.clientFSBA.FSBAP0040.MessageR createMessageR() {
		return mcframe.clientFSBA.FSBAP0040.MessageR.create();
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getListL())) ret.add(getListL());
		if(!MCCollectionUtil.contains(ret, getMessageR())) ret.add(getMessageR());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getListL()) return "List";
		if(aCnt == getMessageR()) return "Message";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("List")) return getListL();
		if(bId.equals("Message")) return getMessageR();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(ListPanel);
		ret.add(IconPanel);
		ret.add(MessagePanel);
		ret.add(CommandPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0040_FW_A() {
		aListL = createListL();
		aMessageR = createMessageR();

	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP0040_FW_A(String name) {
		aListL = createListL();
		createListTable();
		ListTable.setRowName(name);
		aMessageR = createMessageR();
	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP0040_FW.jbCreateList((FSBAP0040)this);
		FSBAP0040_FW.jbCreateIcon((FSBAP0040)this);
		FSBAP0040_FW.jbCreateMessage((FSBAP0040)this);
		FSBAP0040_FW.jbCreateCommand((FSBAP0040)this);
	}

	/**
	 * [List]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateList(FSBAP0040 p) {
	}

	/**
	 * [Icon]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateIcon(FSBAP0040 p) {
	}

	/**
	 * [Message]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateMessage(FSBAP0040 p) {
	}

	/**
	 * [Command]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateCommand(FSBAP0040 p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}


	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP0040 create(){
		FSBAP0040 p = new FSBAP0040();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP0040 create(String name){
		FSBAP0040 p = new FSBAP0040(name);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP0040_FW.jbfInitList((FSBAP0040)this);
		FSBAP0040_FW.jbfInitIcon((FSBAP0040)this);
		FSBAP0040_FW.jbfInitMessage((FSBAP0040)this);
		FSBAP0040_FW.jbfInitCommand((FSBAP0040)this);
		FSBAP0040_FW.jbInitList((FSBAP0040)this);
		FSBAP0040_FW.jbInitIcon((FSBAP0040)this);
		FSBAP0040_FW.jbInitMessage((FSBAP0040)this);
		FSBAP0040_FW.jbInitCommand((FSBAP0040)this);
	}

	/**
	 * [List]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitList(FSBAP0040 p) {
		// ブロック関連の初期化
		p.ListPanel = p.beansFactory.createPanel("List");
		p.ListScrollPane = p.beansFactory.createScrollPane("List.scroll");
		p.createListTable();
		// ブロックの項目の初期化
		p.columnList_ID = p.beansFactory.createTableColumn("List.ID", MCColumnType.TEXT);
		p.columnList_Lv = p.beansFactory.createTableColumn("List.Lv", MCColumnType.TEXT);
		p.columnList_Message = p.beansFactory.createTableColumn("List.Message", MCColumnType.TEXT);
		p.columnList_MessageView = p.beansFactory.createTableColumn("List.MessageView", MCColumnType.TEXT);
	}

	/**
	 * [Icon]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitIcon(FSBAP0040 p) {
		// ブロック関連の初期化
		p.IconPanel = p.beansFactory.createPanel("Icon");
		// ブロックの項目の初期化
		p.Icon_Icon = p.beansFactory.createLabel("Icon.Icon");
	}

	/**
	 * [Message]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitMessage(FSBAP0040 p) {
		// ブロック関連の初期化
		p.MessagePanel = p.beansFactory.createPanel("Message");
		// ブロックの項目の初期化
		p.Message_MessageScrollPane = p.beansFactory.createScrollPane("Message.Messagescroll");
		p.Message_Message = p.beansFactory.createTextArea("Message.Message");
	}

	/**
	 * [Command]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitCommand(FSBAP0040 p) {
		// ブロック関連の初期化
		p.CommandPanel = p.beansFactory.createPanel("Command");
		// ブロックの項目の初期化
		p.Command_OK = p.beansFactory.createButton("Command.OK");
		p.Command_Yes = p.beansFactory.createButton("Command.Yes");
		p.Command_No = p.beansFactory.createButton("Command.No");
		p.Command_Cancel = p.beansFactory.createButton("Command.Cancel");
	}

	/**
	 * [List]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitList(FSBAP0040 p) {
		// ブロック関連の初期化
		p.add(p.ListPanel);
		p.setLastBeans(p.ListPanel);
		p.ListPanel.setNextBeans(p.IconPanel);
		p.ListPanel.add(p.ListScrollPane);
		p.ListPanel.setLastBeans(p.ListTable);
		p.ListScrollPane.setViewportView(p.ListTable);
		p.ListTable.setList(p.getListL());
		p.ListPanel.setValueCheck(false);
		p.ListPanel.setLayoutPosition("CTC");
		// ブロックの項目の初期化
	}

	/**
	 * [Icon]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitIcon(FSBAP0040 p) {
		// ブロック関連の初期化
		p.add(p.IconPanel);
		p.IconPanel.setNextBeans(p.MessagePanel);
		p.IconPanel.setValueCheck(false);
		p.IconPanel.setLayoutPosition("CBW");
		// ブロックの項目の初期化
		p.IconPanel.add(p.Icon_Icon);
	}

	/**
	 * [Message]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitMessage(FSBAP0040 p) {
		// ブロック関連の初期化
		p.add(p.MessagePanel);
		p.MessagePanel.setNextBeans(p.CommandPanel);
		p.MessagePanel.setValueCheck(false);
		p.MessagePanel.setLayoutPosition("CBC");
		// ブロックの項目の初期化
		p.Message_MessageScrollPane.getViewport().add(p.Message_Message);
		p.MessagePanel.add(p.Message_MessageScrollPane);
		p.MessagePanel.setLastBeans(p.Message_Message);
		p.Message_Message.setRow(p.getMessageR(), mcframe.clientFSBA.FSBAP0040.MessageR.Message_META);
	}

	/**
	 * [Command]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitCommand(FSBAP0040 p) {
		// ブロック関連の初期化
		p.add(p.CommandPanel);
		p.CommandPanel.setValueCheck(false);
		p.CommandPanel.setLayoutPosition("S");
		// ブロックの項目の初期化
		p.CommandPanel.add(p.Command_OK);
		p.CommandPanel.setLastBeans(p.Command_OK);
		p.Command_OK.setNextBeans(p.Command_Yes);
		p.CommandPanel.add(p.Command_Yes);
		p.Command_Yes.setNextBeans(p.Command_No);
		p.CommandPanel.add(p.Command_No);
		p.Command_No.setNextBeans(p.Command_Cancel);
		p.CommandPanel.add(p.Command_Cancel);
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "S";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP0040_FW.mcInitList((FSBAP0040)this);
		FSBAP0040_FW.mcInitIcon((FSBAP0040)this);
		FSBAP0040_FW.mcInitMessage((FSBAP0040)this);
		FSBAP0040_FW.mcInitCommand((FSBAP0040)this);

		// [INIT]ステータスのモードの設定
		FSBAP0040_FW.statusInitINIT_List((FSBAP0040)this);
		FSBAP0040_FW.statusInitINIT_Icon((FSBAP0040)this);
		FSBAP0040_FW.statusInitINIT_Message((FSBAP0040)this);
		FSBAP0040_FW.statusInitINIT_Command((FSBAP0040)this);

		// [PARTS]ステータスのモードの設定
		FSBAP0040_FW.statusInitPARTS_List((FSBAP0040)this);
		FSBAP0040_FW.statusInitPARTS_Icon((FSBAP0040)this);
		FSBAP0040_FW.statusInitPARTS_Message((FSBAP0040)this);
		FSBAP0040_FW.statusInitPARTS_Command((FSBAP0040)this);

		// [OK]ステータスのモードの設定
		FSBAP0040_FW.statusInitOK_List((FSBAP0040)this);
		FSBAP0040_FW.statusInitOK_Icon((FSBAP0040)this);
		FSBAP0040_FW.statusInitOK_Message((FSBAP0040)this);
		FSBAP0040_FW.statusInitOK_Command((FSBAP0040)this);

		// [Y_N]ステータスのモードの設定
		FSBAP0040_FW.statusInitY__N_List((FSBAP0040)this);
		FSBAP0040_FW.statusInitY__N_Icon((FSBAP0040)this);
		FSBAP0040_FW.statusInitY__N_Message((FSBAP0040)this);
		FSBAP0040_FW.statusInitY__N_Command((FSBAP0040)this);

		// [Y_N_C]ステータスのモードの設定
		FSBAP0040_FW.statusInitY__N__C_List((FSBAP0040)this);
		FSBAP0040_FW.statusInitY__N__C_Icon((FSBAP0040)this);
		FSBAP0040_FW.statusInitY__N__C_Message((FSBAP0040)this);
		FSBAP0040_FW.statusInitY__N__C_Command((FSBAP0040)this);

		// [O_C]ステータスのモードの設定
		FSBAP0040_FW.statusInitO__C_List((FSBAP0040)this);
		FSBAP0040_FW.statusInitO__C_Icon((FSBAP0040)this);
		FSBAP0040_FW.statusInitO__C_Message((FSBAP0040)this);
		FSBAP0040_FW.statusInitO__C_Command((FSBAP0040)this);

	}

	/**
	 *  [List]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitList(FSBAP0040 p) {
		p.ListTable.addAllListener(p);
		p.columnList_ID.addAllListener(p);
		p.columnList_ID.setListListener(p);
		p.columnList_Lv.addAllListener(p);
		p.columnList_Lv.setListListener(p);
		p.columnList_Message.addAllListener(p);
		p.columnList_Message.setListListener(p);
		p.columnList_MessageView.addAllListener(p);
		p.columnList_MessageView.setListListener(p);
	}

	/**
	 *  [Icon]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitIcon(FSBAP0040 p) {
	}

	/**
	 *  [Message]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitMessage(FSBAP0040 p) {
		p.Message_Message.addAllListener(p);
	}

	/**
	 *  [Command]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitCommand(FSBAP0040 p) {
		p.Command_OK.addAllListener(p);
		p.Command_OK.setAPMethodName("doCommand_OK");
		p.Command_Yes.addAllListener(p);
		p.Command_Yes.setAPMethodName("doCommand_Yes");
		p.Command_No.addAllListener(p);
		p.Command_No.setAPMethodName("doCommand_No");
		p.Command_Cancel.addAllListener(p);
		p.Command_Cancel.setAPMethodName("doCommand_Cancel");
	}

	/**
	 * [INIT]ステータスの[List]ブロックのモードの設定
	 */
	protected static void statusInitINIT_List(FSBAP0040 p){
		p.columnList_ID.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnList_Lv.putMode(p, INIT, MCMode.READ_ONLY);
		p.columnList_Message.putMode(p, INIT, MCMode.INVISIBLE);
		p.columnList_MessageView.putMode(p, INIT, MCMode.READ_ONLY);

	}

	/**
	 * [INIT]ステータスの[Icon]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Icon(FSBAP0040 p){
		p.Icon_Icon.putMode(p, INIT, MCMode.ENABLE);

	}

	/**
	 * [INIT]ステータスの[Message]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Message(FSBAP0040 p){
		p.Message_Message.putMode(p, INIT, MCMode.READ_ONLY);

	}

	/**
	 * [INIT]ステータスの[Command]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Command(FSBAP0040 p){
		p.Command_OK.putMode(p, INIT, MCMode.ENABLE);
		p.Command_Yes.putMode(p, INIT, MCMode.ENABLE);
		p.Command_No.putMode(p, INIT, MCMode.ENABLE);
		p.Command_Cancel.putMode(p, INIT, MCMode.ENABLE);

	}

	/**
	 * [PARTS]ステータスの[List]ブロックのモードの設定
	 */
	protected static void statusInitPARTS_List(FSBAP0040 p){
		p.columnList_ID.putMode(p, PARTS, MCMode.READ_ONLY);
		p.columnList_Lv.putMode(p, PARTS, MCMode.READ_ONLY);
		p.columnList_Message.putMode(p, PARTS, MCMode.INVISIBLE);
		p.columnList_MessageView.putMode(p, PARTS, MCMode.READ_ONLY);

	}

	/**
	 * [PARTS]ステータスの[Icon]ブロックのモードの設定
	 */
	protected static void statusInitPARTS_Icon(FSBAP0040 p){
		p.Icon_Icon.putMode(p, PARTS, MCMode.ENABLE);

	}

	/**
	 * [PARTS]ステータスの[Message]ブロックのモードの設定
	 */
	protected static void statusInitPARTS_Message(FSBAP0040 p){
		p.Message_Message.putMode(p, PARTS, MCMode.READ_ONLY);

	}

	/**
	 * [PARTS]ステータスの[Command]ブロックのモードの設定
	 */
	protected static void statusInitPARTS_Command(FSBAP0040 p){
		p.Command_OK.putMode(p, PARTS, MCMode.INVISIBLE);
		p.Command_Yes.putMode(p, PARTS, MCMode.INVISIBLE);
		p.Command_No.putMode(p, PARTS, MCMode.INVISIBLE);
		p.Command_Cancel.putMode(p, PARTS, MCMode.INVISIBLE);

	}

	/**
	 * [OK]ステータスの[List]ブロックのモードの設定
	 */
	protected static void statusInitOK_List(FSBAP0040 p){
		p.columnList_ID.putMode(p, OK, MCMode.READ_ONLY);
		p.columnList_Lv.putMode(p, OK, MCMode.READ_ONLY);
		p.columnList_Message.putMode(p, OK, MCMode.INVISIBLE);
		p.columnList_MessageView.putMode(p, OK, MCMode.READ_ONLY);

	}

	/**
	 * [OK]ステータスの[Icon]ブロックのモードの設定
	 */
	protected static void statusInitOK_Icon(FSBAP0040 p){
		p.Icon_Icon.putMode(p, OK, MCMode.ENABLE);

	}

	/**
	 * [OK]ステータスの[Message]ブロックのモードの設定
	 */
	protected static void statusInitOK_Message(FSBAP0040 p){
		p.Message_Message.putMode(p, OK, MCMode.READ_ONLY);

	}

	/**
	 * [OK]ステータスの[Command]ブロックのモードの設定
	 */
	protected static void statusInitOK_Command(FSBAP0040 p){
		p.Command_OK.putMode(p, OK, MCMode.ENABLE);
		p.Command_Yes.putMode(p, OK, MCMode.INVISIBLE);
		p.Command_No.putMode(p, OK, MCMode.INVISIBLE);
		p.Command_Cancel.putMode(p, OK, MCMode.INVISIBLE);

	}

	/**
	 * [Y_N]ステータスの[List]ブロックのモードの設定
	 */
	protected static void statusInitY__N_List(FSBAP0040 p){
		p.columnList_ID.putMode(p, Y_N, MCMode.READ_ONLY);
		p.columnList_Lv.putMode(p, Y_N, MCMode.READ_ONLY);
		p.columnList_Message.putMode(p, Y_N, MCMode.INVISIBLE);
		p.columnList_MessageView.putMode(p, Y_N, MCMode.READ_ONLY);

	}

	/**
	 * [Y_N]ステータスの[Icon]ブロックのモードの設定
	 */
	protected static void statusInitY__N_Icon(FSBAP0040 p){
		p.Icon_Icon.putMode(p, Y_N, MCMode.ENABLE);

	}

	/**
	 * [Y_N]ステータスの[Message]ブロックのモードの設定
	 */
	protected static void statusInitY__N_Message(FSBAP0040 p){
		p.Message_Message.putMode(p, Y_N, MCMode.READ_ONLY);

	}

	/**
	 * [Y_N]ステータスの[Command]ブロックのモードの設定
	 */
	protected static void statusInitY__N_Command(FSBAP0040 p){
		p.Command_OK.putMode(p, Y_N, MCMode.INVISIBLE);
		p.Command_Yes.putMode(p, Y_N, MCMode.ENABLE);
		p.Command_No.putMode(p, Y_N, MCMode.ENABLE);
		p.Command_Cancel.putMode(p, Y_N, MCMode.INVISIBLE);

	}

	/**
	 * [Y_N_C]ステータスの[List]ブロックのモードの設定
	 */
	protected static void statusInitY__N__C_List(FSBAP0040 p){
		p.columnList_ID.putMode(p, Y_N_C, MCMode.READ_ONLY);
		p.columnList_Lv.putMode(p, Y_N_C, MCMode.READ_ONLY);
		p.columnList_Message.putMode(p, Y_N_C, MCMode.INVISIBLE);
		p.columnList_MessageView.putMode(p, Y_N_C, MCMode.READ_ONLY);

	}

	/**
	 * [Y_N_C]ステータスの[Icon]ブロックのモードの設定
	 */
	protected static void statusInitY__N__C_Icon(FSBAP0040 p){
		p.Icon_Icon.putMode(p, Y_N_C, MCMode.ENABLE);

	}

	/**
	 * [Y_N_C]ステータスの[Message]ブロックのモードの設定
	 */
	protected static void statusInitY__N__C_Message(FSBAP0040 p){
		p.Message_Message.putMode(p, Y_N_C, MCMode.READ_ONLY);

	}

	/**
	 * [Y_N_C]ステータスの[Command]ブロックのモードの設定
	 */
	protected static void statusInitY__N__C_Command(FSBAP0040 p){
		p.Command_OK.putMode(p, Y_N_C, MCMode.INVISIBLE);
		p.Command_Yes.putMode(p, Y_N_C, MCMode.ENABLE);
		p.Command_No.putMode(p, Y_N_C, MCMode.ENABLE);
		p.Command_Cancel.putMode(p, Y_N_C, MCMode.ENABLE);

	}

	/**
	 * [O_C]ステータスの[List]ブロックのモードの設定
	 */
	protected static void statusInitO__C_List(FSBAP0040 p){
		p.columnList_ID.putMode(p, O_C, MCMode.READ_ONLY);
		p.columnList_Lv.putMode(p, O_C, MCMode.READ_ONLY);
		p.columnList_Message.putMode(p, O_C, MCMode.INVISIBLE);
		p.columnList_MessageView.putMode(p, O_C, MCMode.READ_ONLY);

	}

	/**
	 * [O_C]ステータスの[Icon]ブロックのモードの設定
	 */
	protected static void statusInitO__C_Icon(FSBAP0040 p){
		p.Icon_Icon.putMode(p, O_C, MCMode.ENABLE);

	}

	/**
	 * [O_C]ステータスの[Message]ブロックのモードの設定
	 */
	protected static void statusInitO__C_Message(FSBAP0040 p){
		p.Message_Message.putMode(p, O_C, MCMode.READ_ONLY);

	}

	/**
	 * [O_C]ステータスの[Command]ブロックのモードの設定
	 */
	protected static void statusInitO__C_Command(FSBAP0040 p){
		p.Command_OK.putMode(p, O_C, MCMode.ENABLE);
		p.Command_Yes.putMode(p, O_C, MCMode.INVISIBLE);
		p.Command_No.putMode(p, O_C, MCMode.INVISIBLE);
		p.Command_Cancel.putMode(p, O_C, MCMode.ENABLE);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return INIT;
	}

	/**
	 * Table/Tree/GanttChartの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
		FSBAP0040_FW.setTableConfigList((FSBAP0040)this);
	}

	/**
	 * [List]ブロックのTableの設定
	 */
	protected static void setTableConfigList(FSBAP0040 p) {
		p.columnList_ID.setMeta(mcframe.clientFSBA.FSBAP0040.ListR.ID_META);
		p.ListTable.addColumnConfig(p.columnList_ID);
		p.columnList_Lv.setMeta(mcframe.clientFSBA.FSBAP0040.ListR.Lv_META);
		p.ListTable.addColumnConfig(p.columnList_Lv);
		p.columnList_Message.setMeta(mcframe.clientFSBA.FSBAP0040.ListR.Message_META);
		p.ListTable.addColumnConfig(p.columnList_Message);
		p.columnList_MessageView.setMeta(mcframe.clientFSBA.FSBAP0040.ListR.MessageView_META);
		p.ListTable.addColumnConfig(p.columnList_MessageView);
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
	}

	/**
	 * この画面を[INIT]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setINITStatus() {
		status = INIT;
		setAllStatus(status);
	}

	/**
	 * この画面を[PARTS]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setPARTSStatus() {
		status = PARTS;
		setAllStatus(status);
	}

	/**
	 * この画面を[OK]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setOKStatus() {
		status = OK;
		setAllStatus(status);
	}

	/**
	 * この画面を[Y_N]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setY_NStatus() {
		status = Y_N;
		setAllStatus(status);
	}

	/**
	 * この画面を[Y_N_C]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setY_N_CStatus() {
		status = Y_N_C;
		setAllStatus(status);
	}

	/**
	 * この画面を[O_C]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setO_CStatus() {
		status = O_C;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (INIT.equals(status)) {
			setINITStatus();
		}
		else if (PARTS.equals(status)) {
			setPARTSStatus();
		}
		else if (OK.equals(status)) {
			setOKStatus();
		}
		else if (Y_N.equals(status)) {
			setY_NStatus();
		}
		else if (Y_N_C.equals(status)) {
			setY_N_CStatus();
		}
		else if (O_C.equals(status)) {
			setO_CStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}


	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == Command_OK) doCommand_OK(info);
		else if (ap == Command_Yes) doCommand_Yes(info);
		else if (ap == Command_No) doCommand_No(info);
		else if (ap == Command_Cancel) doCommand_Cancel(info);
	}

	/**
	 * [Command]パネルの[OK]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doCommand_OK(MCEventInfo info);

	/**
	 * [Command]パネルの[Yes]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doCommand_Yes(MCEventInfo info);

	/**
	 * [Command]パネルの[No]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doCommand_No(MCEventInfo info);

	/**
	 * [Command]パネルの[Cancel]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doCommand_Cancel(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == ListTable) return doList_VC(info);
		if (vc == columnList_ID) return doList_ID_VC(info);
		if (vc == columnList_Lv) return doList_Lv_VC(info);
		if (vc == columnList_Message) return doList_Message_VC(info);
		if (vc == columnList_MessageView) return doList_MessageView_VC(info);
		if (vc == Message_Message) return doMessage_Message_VC(info);
		return true;
	}

	/**
	 * [List]Tableの選択行が変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doList_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [List]パネルの[ID]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doList_ID_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [List]パネルの[Lv]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doList_Lv_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [List]パネルの[Message]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doList_Message_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [List]パネルの[MessageView]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doList_MessageView_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Message]パネルの[Message]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doMessage_Message_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == ListTable) doList_NC(info);
		else if (nc == columnList_ID) doList_ID_NC(info);
		else if (nc == columnList_Lv) doList_Lv_NC(info);
		else if (nc == columnList_Message) doList_Message_NC(info);
		else if (nc == columnList_MessageView) doList_MessageView_NC(info);
		else if (nc == Message_Message) doMessage_Message_NC(info);
	}

	/**
	 * [List]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_NC(MCEventInfo info){
	}

	/**
	 * [List]パネルの[ID]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_ID_NC(MCEventInfo info){
	}

	/**
	 * [List]パネルの[Lv]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_Lv_NC(MCEventInfo info){
	}

	/**
	 * [List]パネルの[Message]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_Message_NC(MCEventInfo info){
	}

	/**
	 * [List]パネルの[MessageView]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_MessageView_NC(MCEventInfo info){
	}

	/**
	 * [Message]パネルの[Message]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMessage_Message_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == ListTable) doList_NE(info);
		else if (ne == columnList_ID) doList_ID_NE(info);
		else if (ne == columnList_Lv) doList_Lv_NE(info);
		else if (ne == columnList_Message) doList_Message_NE(info);
		else if (ne == columnList_MessageView) doList_MessageView_NE(info);
		else if (ne == Message_Message) doMessage_Message_NE(info);
	}

	/**
	 * [List]TableのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_NE(MCEventInfo info){
	}

	/**
	 * [List]パネルの[ID]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_ID_NE(MCEventInfo info){
	}

	/**
	 * [List]パネルの[Lv]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_Lv_NE(MCEventInfo info){
	}

	/**
	 * [List]パネルの[Message]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_Message_NE(MCEventInfo info){
	}

	/**
	 * [List]パネルの[MessageView]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_MessageView_NE(MCEventInfo info){
	}

	/**
	 * [Message]パネルの[Message]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMessage_Message_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == ListTable) doList_NX(info);
		else if (nx == columnList_ID) doList_ID_NX(info);
		else if (nx == columnList_Lv) doList_Lv_NX(info);
		else if (nx == columnList_Message) doList_Message_NX(info);
		else if (nx == columnList_MessageView) doList_MessageView_NX(info);
		else if (nx == Message_Message) doMessage_Message_NX(info);
	}

	/**
	 * [List]TableのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_NX(MCEventInfo info){
	}

	/**
	 * [List]パネルの[ID]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_ID_NX(MCEventInfo info){
	}

	/**
	 * [List]パネルの[Lv]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_Lv_NX(MCEventInfo info){
	}

	/**
	 * [List]パネルの[Message]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_Message_NX(MCEventInfo info){
	}

	/**
	 * [List]パネルの[MessageView]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_MessageView_NX(MCEventInfo info){
	}

	/**
	 * [Message]パネルの[Message]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doMessage_Message_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == columnList_ID) doList_ID_LC(info);
		else if (lc == columnList_Lv) doList_Lv_LC(info);
		else if (lc == columnList_Message) doList_Message_LC(info);
		else if (lc == columnList_MessageView) doList_MessageView_LC(info);
	}

	/**
	 * [List]パネルの[ID]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_ID_LC(MCEventInfo info){
	}

	/**
	 * [List]パネルの[Lv]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_Lv_LC(MCEventInfo info){
	}

	/**
	 * [List]パネルの[Message]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_Message_LC(MCEventInfo info){
	}

	/**
	 * [List]パネルの[MessageView]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doList_MessageView_LC(MCEventInfo info){
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}