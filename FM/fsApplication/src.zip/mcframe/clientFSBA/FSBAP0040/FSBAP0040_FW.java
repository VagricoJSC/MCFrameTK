package mcframe.clientFSBA.FSBAP0040;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;


import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START

import java.util.Set;

import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.JComponent;
import javax.swing.JScrollBar;
import javax.swing.JTextField;

import mcframe.clientCore.beans.message.MCDialogPanel;
import mcframe.clientCore.beans.message.MCDialogButton;
import mcframe.clientCore.beans.message.MCDialogInfo;
import mcframe.clientCore.beans.message.MCMessagePanel;
import mcframe.clientCore.beans.popup.MCPopupBeans;

import mcframe.clientFSUC.FSUCP0000.FSUCP_PopupConfig;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP0040"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP0040_FW extends FSBAP0040_FW_A implements MCMessagePanel, MCDialogPanel {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	/**
	 * メッセージＩＤを表示するかどうかを表すフラグです。
	 */
	private boolean _disp_id = true;

	/**
	 * メッセージレベルを表示するかどうかを表すフラグです。
	 */
	private boolean _disp_lv = true;

	/**
	 * 上部一覧に表示する文字列を制限する場合に使用するデリミタです。
	 */
	private String _hdr_end = null;
	/**
	 * メッセージ文字列を表示用文字列にフォーマットします。
	 *
	 * @param msg メッセージ文字列
	 * @return 表示用文字列
	 */
	public static String formatMessage(String msg) {
		return  msg + "\n";
	}
	
	/**
	 * メッセージ文字列を表示用文字列にフォーマットします。
	 *
	 * @param id メッセージID
	 * @param msg メッセージ文字列
	 * @return 表示用文字列
	 */
	public static String formatMessage(String id, String msg) {
		return "(" + id + ")\n" + msg + "\n";
	}
	
	/**
	 * メッセージリストです。
	 */
	private MCMessageList list;
	
	/**
	 * 画面表示時の親画面のフォーカスオーナです。
	 */
	protected Component _parent_focus_owner = null;
	
	/**
	 * 画面表示時の親画面のフォーカスカラムです。
	 * {@link #_parent_focus_owner} がテーブルの場合に使用します。
	 */
	protected MCColumnConfig _parent_focus_column = null;
	
	/**
	 * 画面表示時の親画面の選択行のインデックス値です。
	 * {@link #_parent_focus_owner} がテーブルの場合に使用します。
	 */
	protected int _parent_focus_index = -1;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0040_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP0040_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	@Override
	protected void jbInit() {
		super.jbInit();
		Message_MessageScrollPane.setBorder(BorderFactory.createEmptyBorder());
		Message_Message.setBorder(BorderFactory.createEmptyBorder());
	}
	
	@Override
	protected void customInit() {
		super.customInit();

		Message_MessageScrollPane.setOpaque(false);
		for (JComponent c : MCBeansUtil.getAllComponents(
				JComponent.class, Message_MessageScrollPane)) {
			c.setOpaque(false);
		}
		
		Command_Yes.setMnemonic(java.awt.event.KeyEvent.VK_Y);
		Command_No.setMnemonic(java.awt.event.KeyEvent.VK_N);
		
		IconPanel.isEnableAutoLayout(false);
		MessagePanel.isEnableAutoLayout(false);
		CommandPanel.isEnableAutoLayout(false);
	}
	
	@Override
	public boolean beforeOpen() {
		boolean e = super.beforeOpen();
		
		if (e) {
			MCRootPanel p = getParentPanel();
			if (p != null) {
				_parent_focus_owner = p.getFocusOwner();
				if (_parent_focus_owner instanceof MCTable<?>) {
					MCTable<?> t = (MCTable<?>)_parent_focus_owner;
					_parent_focus_column = t.getSelectedColumnConfig();
					_parent_focus_index = t.getMCSelectedRow();
				}
			}
		}
		
		return e;
	}

	@Override
	public void setINITStatus() {
		super.setINITStatus();
		if (getListL().size() != 0) {
			ListTable.selectLeftmostColumn(0);
		}

		if (!isPartsPanel()) {
			getFrame().setParentPanelEnable(true);
//			MCFrame f = getFrame();
//			if (f instanceof MCInternalFrame) {
//				((MCInternalFrame)f).setLayer(1);
//			}
		}
	}
	
	@Override
	public void setOpenFocus() {
		super.setOpenFocus();
		
		if (!isPartsPanel()) {
			parentPanelActive();
			moveToFront();
			getFrame().requestFocus();
		}
	}
	
	@Override
	protected void setDefaultScreenPosition() {
		super.setDefaultScreenPosition();
		
		if (!isPartsPanel()) {
			setArrangementCenter();
		}
	}

	@Override
	public void setPARTSStatus() {
		super.setPARTSStatus();
		if (getListL().size() != 0) {
			ListTable.selectLeftmostColumn(0);
		}
	}

	public final void setMessageList(MCMessageList list) {
		getListL().clear();
		// JRW-5-016-05758 2008/07/18
		getMessageR().clear();
		this.list = list;
		if (list != null) {
			int s = list.size();
			MCMessage[] a = list.toArray(new MCMessage[s]);
			MCList<ListR> l = createListL();
			for (int i=0;i<s;i++) {
				MCMessage m = a[i];
				ListR c = createListR();
				c.ID(m.getID());
				MCMessageLevel v = m.getLevel();
				if (v != null) {
					c.Lv(String.valueOf(v.getOmission()));
				}
				String t = m.toString();
				c.Message(t);
				if (_hdr_end!= null) {
					int end = t.indexOf(_hdr_end);
					if (end > 1) {
						t = t.substring(0, end);
					}
				}
				t = t.replace('\n', ' ');
				c.MessageView(t);
				c.MessageIndex(MCNumber.valueOf(i));
				l.add(c);
			}
			getListL().addAll(l);
		}
		ListTable.adjustWidth();
	}
	
	/**
	 * メッセージリストを返します。
	 * メッセージリストが設定されていない場合は null を返します。
	 *
	 * @return メッセージリストまたは null
	 */
	protected final MCMessageList getMessageList() {
		return list;
	}
	
	/**
	 * Panel[Command]のボタン[OK]の押下時の処理
	 */
	public void doCommand_OK(MCEventInfo info) {
		doButtonAction(MCMessageBox.OK_OPTION);
	}
	
	/**
	 * Panel[Command]のボタン[Yes]の押下時の処理
	 */
	public void doCommand_Yes(MCEventInfo info) {
		doButtonAction(MCMessageBox.YES_OPTION);
	}
	/**
	 * Panel[Command]のボタン[No]の押下時の処理
	 */
	public void doCommand_No(MCEventInfo info) {
		doButtonAction(MCMessageBox.NO_OPTION);
	}
	/**
	 * Panel[Command]のボタン[Cancel]の押下時の処理
	 */
	public void doCommand_Cancel(MCEventInfo info) {
		doButtonAction(MCMessageBox.CANCEL_OPTION);
	}

	@Override
	public void doList_NC(MCEventInfo info) {
		messageSelected(info.getEventIndex());
	}
	
	/**
	 * メッセージアイコンを返します。
	 * 指定されたメッセージレベルに合ったアイコンを返します。
	 * アイコンが見つからなかった場合は null を返します。
	 *
	 * @param panel 画面
	 * @param level メッセージレベル
	 * @return アイコンまたは null
	 */
	protected Icon getIcon(MCRootPanel panel, MCMessageLevel level) {
		return MCMessageBox.getDialogIcon(level);
	}
	
	/**
	 * メッセージが選択されたときの処理を実行します。
	 * 指定された行インデックスのメッセージを画面に表示します。
	 * 選択されたメッセージに原因となるコンテナやカラム名が設定されている場合は、
	 * メッセージの原因となった入力が行われた GUI 部品にフォーカスを移動します。
	 *
	 * @param index 行のインデックス値
	 */
	protected void messageSelected(int index) {
		if (index < 0) {
			return;
		}
		
		int i = getListL().get(index).MessageIndex().intValue();
		MCMessage m = getMessageList().get(i);


		// メッセージを表示する
		String msgStr = m.toString();
		if (_disp_id) {
			Message_Message.setValue(
					formatMessage(m.getID(), msgStr));
		}
		else {
			Message_Message.setValue(
					formatMessage(msgStr));
		}
		
		getMessageR().setStatus(MCRow.NONE);
		
		// アイコンを表示する
		if (_disp_lv) {
			MCMessageLevel v = m.getLevel();
			if (v != null) {
				Icon c = getIcon(getParentPanel(), v);
				if (c != null) {
					Icon_Icon.setIcon(c);
				}
			}
		}
		
		// スクロールバーの位置を初期化する
		final JScrollBar vb = Message_MessageScrollPane.getVerticalScrollBar();
		final JScrollBar hb = Message_MessageScrollPane.getHorizontalScrollBar();
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				if (vb != null) {
					vb.setValue(0);
				}
				if (hb != null) {
					hb.setValue(0);
				}
			}
		});

		if ( !isSystemModal() ) {
			// メッセージの原因である GUI 部品にフォーカスを移動する
			MCRootPanel p = getParentPanel();
			if (p != null) {
				p.setFocus(m);
			}
			
//			getFrame().active();
		}
	}
	
	@Override
	public void doDCEvent(MCDCBeans compo, MCEventInfo info) {
		super.doDCEvent(compo, info);
		if (compo == ListTable) {
			messageSelected(ListTable.getMCSelectedRow());
			if ( !isSystemModal() ) {
				parentPanelActive();
			}
			return;
		}
		for (MCColumnConfig c : ListTable.getColumnConfigs()) {
			if (compo == c) {
				messageSelected(c.getBaseTable().getMCSelectedRow());
				if ( !isSystemModal() ) {
					parentPanelActive();
				}
				return;
			}
		}
	}
	;
	private boolean isSystemModal(){
		MCFrame f = getFrame();
		return f != null && f.getFrameType() == MCFrameType.SYSTEM_MODAL;
	}
	
	/**
	 * 親画面をアクティブにします。<p>
	 * 親画面が存在しない場合は何もしません。<br>
	 * 親画面がフレームに配置されていない場合は何もしません。
	 */
	protected void parentPanelActive() {
		MCRootPanel p = getParentPanel();
		if (p != null) {
			MCFrame f = p.getFrame();
			if (f != null) {
				f.active();
			}
		}
	}
	
	/**
	 * ボタンアクションを実行します。
	 * 
	 * @param option 選択したボタンを表す定数
	 */
	protected void doButtonAction(int option) {
		result = option;
		requestCloseWindow();
	}

	/**
	 * ボタンの推奨サイズを計算するためのテキストフィールド。
	 */
	private final JTextField field = new JTextField();

	/**
	 * ダイアログ情報。
	 */
	private MCDialogInfo info = new MCDialogInfo();

	/**
	 * ユーザが選択したボタンを表す定数。
	 */
	private int result = MCMessageBox.CLOSE_OPTION;

	public int getResultOption() {
		return result;
	}

	/**
	 * メッセージダイアログ情報を設定します。
	 *
	 * 情報中の以下の情報はメッセージリストから取得するため無視されます。
	 * <ul>
	 * <li>タイトル
	 * <li>アイコン
	 * <li>メッセージ
	 * </ul>
	 *
	 * @param info メッセージダイアログ情報
	 */
	public void setMessage(MCDialogInfo info) {
		setDialogInfo(info);
		result = MCMessageBox.CLOSE_OPTION;
	}

	/**
	 * ダイアログ情報を設定します。
	 * {@link #setMessage(MCDialogInfo)} から実行されます。
	 * 
	 * @param info ダイアログ情報
	 */
	protected void setDialogInfo(MCDialogInfo info) {
		this.info = info;
	}

	@Override
	public void mcInitStatus(){
		setINITStatus();
		switch (info.getDialogType()) {
		case MCMessageBox.YES_NO_DIALOG:
			init_YES_NO_Type();
			break;
		case MCMessageBox.OK_DIALOG:
			init_OK_Type();
			break;
		case MCMessageBox.NO_YES_DIALOG:
			init_NO_YES_Type();
			break;
		case MCMessageBox.OK_CANCEL_DIALOG:
			init_OK_CANCEL_Type();
			break;
		case MCMessageBox.YES_NO_CANCEL_DIALOG:
			init_YES_NO_CANCEL_Type();
			break;
		}
	}

	/**
	 * [OK] ダイアログを表示するための設定を行います。
	 */
	protected void init_OK_Type() {
		init_Type(OK, Command_OK);
	}
	
	/**
	 * [YES]/[NO] ダイアログを表示するための設定を行います。
	 */
	protected void init_YES_NO_Type() {
		init_Type(Y_N, Command_Yes, Command_No);
	}
	
	/**
	 * [NO]/[YES] ダイアログを表示するための設定を行います。
	 */
	protected void init_NO_YES_Type() {
		init_Type(Y_N, Command_No, Command_Yes);
	}
	
	/**
	 * [OK]/[CANCEL] ダイアログを表示するための設定を行います。
	 */
	protected void init_OK_CANCEL_Type() {
		init_Type(O_C, Command_OK, Command_Cancel);
	}
	
	/**
	 * [YES]/[NO]/[CANCEL] ダイアログを表示するための設定を行います。
	 */
	protected void init_YES_NO_CANCEL_Type() {
		init_Type(Y_N_C, Command_Yes, Command_No, Command_Cancel);
	}

	/**
	 * ダイアログ表示の設定を行います。
	 *
	 * @param status 画面ステータス
	 * @param bs 表示するボタン（表示順）
	 */
	protected void init_Type(String status, MCButton...bs) {
		setStatus(status);

		final int s = 5;
		int s_w = bs.length - 1 * s;
		int p_w = getBaseRootPanel().getWidth();
		int bs_w = 0;
		Dimension[] sizes = new Dimension[bs.length];
		for (int i = 0; i < bs.length; i++) {
			sizes[i] = getButtonSize(bs[i]);
			bs_w += sizes[i].width;
		}

		int y = bs[0].getLocation().y;
		int x = (p_w - s_w - bs_w) / 2;
		for (int i = 0; i < bs.length; i++) {
			bs[i].setBounds(x, y, sizes[i].width, sizes[i].height);
			x += (sizes[i].width + s);
		}
		
		if (!isPartsPanel()) {
			setPreferredSizeToFrame(getSize());
			getFrame().pack();
		}

		// #7014-4896(マルチメッセージのフォーカス制御【#28423】)
		//タブ順を設定
		for (int i = 0; i < bs.length-1; i++) {
			if(i==0) {
				ListTable.setNextBeans(bs[i]);
			} else {
				bs[i].setNextBeans(bs[i+1]);
			}
		}
	}

	protected void setPreferredSizeToFrame(Dimension size) {
		Component compo = this;
		MCFrame frame = MCBeansUtil.getFrame(compo);
		while (compo != null) {
			if (compo != frame) {
				compo.setPreferredSize(size);
			} else {
				break;
			}
			compo = compo.getParent();
		}
	}

	/**
	 * ボタンのサイズを返します。
	 * 
	 * @param compo ボタン
	 * @return サイズ
	 */
	protected Dimension getButtonSize(MCButton compo) {
		String text = field.getText();
		Font font = field.getFont();
		try {
			field.setText(compo.getText());
			field.setFont(compo.getFont());
			Dimension size = field.getPreferredSize();
			int width = size.width + 30;
			int[] bounds = MCBeansUtil.getBounds(compo);
			int height = bounds[3];
			if (height == -1) {
				height = size.height + 3;
			}
			return new Dimension(width, height);
		} finally {
			field.setText(text);
			field.setFont(font);
		}
	}

	@SuppressWarnings("deprecation")
	@Override
	public boolean beforeClose() {
		boolean e = super.beforeClose();
		if (!e || !isSystemModal()) {
			return e;
		}
		
		int y = info.getDialogType();
		if (y == MCMessageBox.YES_NO_DIALOG 
				|| y == MCMessageBox.YES_NO_CANCEL_DIALOG) {
			if (result == MCMessageBox.YES_OPTION) {
				return e;
			}
		}
		
		MCRow o = ListTable.getSelectedMCRow();
		if (o == null) {
			return e;
		}
		
		int msgIndex = getListL().get(o.getGUIIndex()).MessageIndex().intValue();
		final MCMessage m = getMessageList().get(msgIndex);
		
		final MCRootPanel p = getParentPanel();
		if (p == null) {
			return e;
		}
		
		((MCModalFrame)getFrame())._setFrameClosedEvent(new Runnable() {
			public void run() {
				try {
					boolean f = false;
					Component of = _parent_focus_owner;
					Component nf = p.getFocusOwner();
					if (of == null && nf == null) {
						f = true;
					}
					else if (of != null 
							&& (of instanceof MCBeans) 
									? ((MCBeans)of).equalsIgnoreCase(nf) 
									: of.equals(nf)) {
						if (nf instanceof MCTable<?>) {
							MCTable<?> nt = (MCTable<?>)nf;
							MCColumnConfig oc = _parent_focus_column;
							MCColumnConfig nc = nt.getSelectedColumnConfig();
							int oi = _parent_focus_index;
							int ni = nt.getMCSelectedRow();
							if (oc == nc && oi == ni) {
								f = true;
							}
						}
						else {
							f = true;
						}
					}
					if (f) {
						p.setFocus(m);
					}
				}
				finally {
					_parent_focus_owner = null;
					_parent_focus_column = null;
					_parent_focus_index = -1;
				}
			}
		});
		
		return e;
	}
	
	@Override
	protected String getPopupPattern(MCPopupBeans compo) {
		return FSUCP_PopupConfig.IGNORE_TABLE_SIZE_CHANGE;
	}

	@Override
	public void setVisibleId(boolean v){
		_disp_id = v;
	}
	@Override
	public void setVisibleLv(boolean v){
		_disp_lv = v;
	}
	@Override
	public void setHeaderEnd(String v){
		_hdr_end = v;
	}
	@Override
	public void setMessageGroupName(String v){
		columnList_MessageView.setHeaderName(v);
		columnList_MessageView.setHeaderMessage(v);
	}

	@Override
	protected void customVisibleColumnConfigs(MCTable table, String type,
			Set<MCColumnConfig> confSet) {
		super.customVisibleColumnConfigs(table, type, confSet);
		if (!_disp_id) {
			confSet.remove(columnList_ID);
		}
		if (!_disp_lv) {
			confSet.remove(columnList_Lv);
		}
	}

	@Override
	protected void tableInit() {
		super.tableInit();
		if (!_disp_id) {
			columnList_ID.setVisible(false);
		}
		if (!_disp_lv) {
			columnList_Lv.setVisible(false);
		}
	}

	@Override
	protected void showPersonalizeLoadErrorMsg(MCException e) {
		
	}

	// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
	// divider位置の再計算
	@Override
	public void layoutVerticalSplitPane2(MCRootPanel p) {
		MCSplitPane cont[] = MCBeansUtil.getAllComponents(MCSplitPane.class, p);
		if (cont.length == 0) {
			return;
		}

		for (MCSplitPane sp : cont) {
			MCPanel p1 = (MCPanel) sp.getTopComponent();
			MCPanel p2 = (MCPanel) sp.getBottomComponent();

			int h1 = p1.getPreferredSize().height;
//			int h2 = p2.getPreferredSize().height;
//			int h3 = (h1 + h2) / 2;

			sp.setDividerLocationWithRatio(h1);
		}
	}

	// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
	@Override
	public void initialized() {
		super.initialized();
		updatePanel();
	}

	// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
	// 初期のフォント比率を適用する。
	protected void updatePanel() {
		// 親画面のフォント比率を継承する。
		MCBeans rp = getParentPanel();
		// 不具合修正追加分
		int new_ratio;
		if (rp != null) {
			new_ratio = rp.getBaseRootPanel().getLayoutRatio();
		} else {
			// 親画面がない場合は、自身のフォント比率を利用する。
			new_ratio = getBaseRootPanel().getLayoutRatio();
		}

//		int new_ratio = rp.getBaseRootPanel().getLayoutRatio();
//		int old_ratio = 100;
		int old_ratio = new_ratio;

//		if(old_ratio != new_ratio) {
			MCRootPanel p = this;
			p.updatePanel(new_ratio, old_ratio);
			// divider位置を調整
			MCSplitPane[] a = MCBeansUtil.getAllComponents(MCSplitPane.class, p);
			for (MCSplitPane sp : a) {
				sp.setDefault();
			}
//		}
	}
	// 7013-0007 ここまで

	// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
	@Override
	protected Dimension _adjistFrameSize(Dimension d) {
		// スクロールバーがでてしまうためMCRootPanelのサイズで調整する。
		if (this.getWidth() > d.width) {
			d.width = this.getWidth();
		}
		if (this.getHeight() > d.height) {
			d.height = this.getHeight();
		}
		return d;
	}
	// 7013-0007 ここまで

	// #7014-4896(マルチメッセージのフォーカス制御【#28423】)
	@Override
	public void afterOpen() {
		super.afterOpen();
		if (getDialogInfo().getFocusButton() != null) {
			setInitFocus(getDialogInfo().getFocusButton());
		}
	}
	/**
	 * ダイアログ情報を返します。
	 * ダイアログ情報が設定されていない場合は null を返します。
	 *
	 * @return ダイアログ情報
	 * @see #setDialogInfo(MCDialogInfo)
	 */
	// #7014-4896(マルチメッセージのフォーカス制御【#28423】)
	public final MCDialogInfo getDialogInfo() {
		return info;
	}
	/**
	 * 初期フォーカスを設定します。
	 *
	 * @param button ボタンを表す定数
	 */
	// #7014-4896(マルチメッセージのフォーカス制御【#28423】)
	protected void setInitFocus(MCDialogButton button) {
		switch (button) {
			case YES:
				Command_Yes.mcRequestFocus();
				break;
			case NO:
				Command_No.mcRequestFocus();
				break;
			case OK:
				Command_OK.mcRequestFocus();
				break;
			case CANCEL:
				Command_Cancel.mcRequestFocus();
				break;
		}
	}
}