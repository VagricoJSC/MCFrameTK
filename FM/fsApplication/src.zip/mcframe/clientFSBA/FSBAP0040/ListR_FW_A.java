package mcframe.clientFSBA.FSBAP0040;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"List"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class ListR_FW_A extends MCConstRow {

	/**
	 * メッセージＩＤ メッセージＩＤ.<p>
	 *
	 */
	public static final String $ID = "ID";
	/**
	 * メッセージレベル レベル.<p>
	 *
	 */
	public static final String $Lv = "Lv";
	public static final String $Message = "Message";
	/**
	 * メッセージ メッセージ.<p>
	 *
	 */
	public static final String $MessageView = "MessageView";
	/**
	 * メッセージインデックス メッセージインデックス.<p>
	 *
	 */
	public static final String $MessageIndex = "MessageIndex";


	public static final MCMeta ID_META = createCommonMeta($ID, mcframe.commonCore.meta.M_META.MSG_ID);
	public static final MCMeta Lv_META = createCommonMeta($Lv, mcframe.commonCore.meta.M_META.MSG_LVL);
	public static final MCMeta Message_META = createStringMeta($Message);
	public static final MCMeta MessageView_META = createStringMeta($MessageView);
	public static final MCMeta MessageIndex_META = createNumberMeta($MessageIndex);

	protected static final ConstMetaList<ListR> constMetas = new ConstMetaList<ListR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			ID_META,
			Lv_META,
			Message_META,
			MessageView_META,
			MessageIndex_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected ListR_FW_A(ConstMetaList<? extends ListR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ListR clone() {
		return (ListR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ListR createInstance() {
		return (ListR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ListR getValues(String... names) {
		return (ListR) super.getValues(names);
	}



	/**
	 * メッセージＩＤ メッセージＩＤ.<p>
	 *
	 */
	public String ID() {
		return getConstString(offset + 0, $ID);
	}

	/**
	 * メッセージＩＤ メッセージＩＤ.<p>
	 *
	 */
	public void ID(String value) {
		setConstString(offset + 0, $ID, value);
	}


	/**
	 * メッセージレベル レベル.<p>
	 *
	 */
	public String Lv() {
		return getConstString(offset + 1, $Lv);
	}

	/**
	 * メッセージレベル レベル.<p>
	 *
	 */
	public void Lv(String value) {
		setConstString(offset + 1, $Lv, value);
	}


	public String Message() {
		return getConstString(offset + 2, $Message);
	}

	public void Message(String value) {
		setConstString(offset + 2, $Message, value);
	}


	/**
	 * メッセージ メッセージ.<p>
	 *
	 */
	public String MessageView() {
		return getConstString(offset + 3, $MessageView);
	}

	/**
	 * メッセージ メッセージ.<p>
	 *
	 */
	public void MessageView(String value) {
		setConstString(offset + 3, $MessageView, value);
	}


	/**
	 * メッセージインデックス メッセージインデックス.<p>
	 *
	 */
	public MCNumber MessageIndex() {
		return getConstNumber(offset + 4, $MessageIndex);
	}

	/**
	 * メッセージインデックス メッセージインデックス.<p>
	 *
	 */
	public void MessageIndex(MCNumber value) {
		setConstNumber(offset + 4, $MessageIndex, value);
	}

	/**
	 * メッセージインデックス メッセージインデックス.<p>
	 *
	 */
	public void MessageIndex(int value) {
		setConstNumber(offset + 4, $MessageIndex, value);
	}

	/**
	 * メッセージインデックス メッセージインデックス.<p>
	 *
	 */
	public void MessageIndex(long value) {
		setConstNumber(offset + 4, $MessageIndex, value);
	}

	/**
	 * メッセージインデックス メッセージインデックス.<p>
	 *
	 */
	public void MessageIndex(float value) {
		setConstNumber(offset + 4, $MessageIndex, value);
	}

	/**
	 * メッセージインデックス メッセージインデックス.<p>
	 *
	 */
	public void MessageIndex(double value) {
		setConstNumber(offset + 4, $MessageIndex, value);
	}


	public String getString(String name) {
		if ($ID.equalsIgnoreCase(name)) {
			return ID();
		}
		if ($Lv.equalsIgnoreCase(name)) {
			return Lv();
		}
		if ($Message.equalsIgnoreCase(name)) {
			return Message();
		}
		if ($MessageView.equalsIgnoreCase(name)) {
			return MessageView();
		}
		return super.getString(name);
	}
	public MCNumber getNumber(String name) {
		if ($MessageIndex.equalsIgnoreCase(name)) {
			return MessageIndex();
		}
		return super.getNumber(name);
	}

	public String getStringNE(String name) {
		if ($ID.equalsIgnoreCase(name)) {
			return ID();
		}
		if ($Lv.equalsIgnoreCase(name)) {
			return Lv();
		}
		if ($Message.equalsIgnoreCase(name)) {
			return Message();
		}
		if ($MessageView.equalsIgnoreCase(name)) {
			return MessageView();
		}
		return super.getStringNE(name);
	}
	public MCNumber getNumberNE(String name) {
		if ($MessageIndex.equalsIgnoreCase(name)) {
			return MessageIndex();
		}
		return super.getNumberNE(name);
	}

	public void setString(String name, String value) {
		if ($ID.equalsIgnoreCase(name)) {
			ID(value);
			return;
		}
		if ($Lv.equalsIgnoreCase(name)) {
			Lv(value);
			return;
		}
		if ($Message.equalsIgnoreCase(name)) {
			Message(value);
			return;
		}
		if ($MessageView.equalsIgnoreCase(name)) {
			MessageView(value);
			return;
		}
		super.setString(name, value);
	}
	public void setNumber(String name, MCNumber value) {
		if ($MessageIndex.equalsIgnoreCase(name)) {
			MessageIndex(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, int value) {
		if ($MessageIndex.equalsIgnoreCase(name)) {
			MessageIndex(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, long value) {
		if ($MessageIndex.equalsIgnoreCase(name)) {
			MessageIndex(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, float value) {
		if ($MessageIndex.equalsIgnoreCase(name)) {
			MessageIndex(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, double value) {
		if ($MessageIndex.equalsIgnoreCase(name)) {
			MessageIndex(value);
			return;
		}
		super.setNumber(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($ID.equalsIgnoreCase(name)) {
			ID(value);
			return;
		}
		if ($Lv.equalsIgnoreCase(name)) {
			Lv(value);
			return;
		}
		if ($Message.equalsIgnoreCase(name)) {
			Message(value);
			return;
		}
		if ($MessageView.equalsIgnoreCase(name)) {
			MessageView(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setNumberNE(String name, MCNumber value) {
		if ($MessageIndex.equalsIgnoreCase(name)) {
			MessageIndex(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, int value) {
		if ($MessageIndex.equalsIgnoreCase(name)) {
			MessageIndex(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, long value) {
		if ($MessageIndex.equalsIgnoreCase(name)) {
			MessageIndex(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, float value) {
		if ($MessageIndex.equalsIgnoreCase(name)) {
			MessageIndex(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, double value) {
		if ($MessageIndex.equalsIgnoreCase(name)) {
			MessageIndex(value);
			return;
		}
		super.setNumberNE(name, value);
	}



}

