package mcframe.clientFSBA.FSBAP0350;

import mcframe.commonCore.param.MCOperationInfo;
import mcframe.commonCore.param.MCContainerDef;
import mcframe.commonCore.param.MCGeneralContainerDef;
import mcframe.commonCore.param.MCBlockDef;
import mcframe.commonCore.param.MCItemDef;
import mcframe.commonCore.param.MCDef;

/**
 * [FSBAP_CommonMemo_Parts]の入出力情報となる電文（上り・下り電文）と
 * 画面コンテナの間のデータ変換の定義を行うクラスです。
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズはできません。
 */
@SuppressWarnings({"all"})
abstract public class PDef_FW_A extends MCDef {
	public MCContainerDef getCustomDef(String id){
		if (id == null) {
			return null;
		} 
//FMCB GET_DEF START
		else if (id.equals("FS.FSBAL0150.Srch03.UP.BLOCK0")){
			return FS_FSBAL0150_Srch03_UP_BLOCK0();
		}
		else if (id.equals("FS.FSBAL0150.Srch03.DOWN.BLOCK0")){
			return FS_FSBAL0150_Srch03_DOWN_BLOCK0();
		}
//FMCB GET_DEF END
		else {
			return null;
		}
	}
	//FMCB DEF_CLASSES START
	
	
	static final MCOperationInfo FS_FSBAL0150_Srch03_INFO = new MCOperationInfo("FS", "FSBAL0150", "Srch03", "000000", new PDef());

	public static MCContainerDef FS_FSBAL0150_Srch03_UP_BLOCK0() {
		/** Ope.のBlock [] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0150", "Srch03",
			mcframe.clientFSBA.FSBAP0340.PDef.FS_FSBAL0150_Srch03_UP_BLOCK0(),
			new MCItemDef[]{
			}
			,
			MCBlockDef.create("Menu")
		);
	}


	public static MCContainerDef FS_FSBAL0150_Srch03_DOWN_BLOCK0() {
	/** Ope.のBlock [] に対する電文項目定義 */
		return new MCGeneralContainerDef("FS", "FSBAL0150", "Srch03",
			mcframe.clientFSBA.FSBAP0340.PDef.FS_FSBAL0150_Srch03_DOWN_BLOCK0(),
			new MCItemDef[]{
			}
			,
			MCBlockDef.create("MemoList")
		);
	}
	//FMCB DEF_CLASSES END
}

