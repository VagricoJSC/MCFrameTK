package mcframe.clientFSBA.FSBAP0650;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;


import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import static mcframe.clientCore.resource.MCConst.createKey;

import java.util.Collections;
import java.util.Comparator;
import java.util.Map;

import mcframe.clientCore.beans.layout.MCAutoLayout;
import mcframe.clientCore.beans.layout.MCLayoutLocationR;
import mcframe.clientCore.beans.message.MCDialogButton;
import mcframe.clientCore.beans.popup.MCPopupBeans;
import mcframe.clientCore.resource.MCConst;
import mcframe.clientCore.resource.ctrl.MCGeneralPersonalizeResource;
import mcframe.clientFSBA.FSBAP0670.FSBAP0670;
import mcframe.clientFSBE.FSBEP0330.MCBarcodeUtil;
import mcframe.clientFSBE.FSBEP0330.MCPersonalizeLocation2;
import mcframe.clientFSUC.FSUCP0000.FSUCP_PopupConfig;
import mcframe.commonCore.resource.ctrl.MCResourceLayerType;
import mcframe.clientFSUB.FSUBP0000.IfRowMoveBase;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP0650"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP0650_FW extends FSBAP0650_FW_A implements IfRowMoveBase {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	protected FSBAP0670 mainPanelForBarcode = null; // 親画面

	// 保存時のFocusID
	protected String targetFocusID = null;
	protected String targetFocusNM = null;

	/**
	 * 対象RootPanel
	 */
	protected MCRootPanel targetRootPanel = null;

	protected MCPersonalizeLocation2 personalizeLocation = null;

	// 紐付ＮＯのカウンタ
	protected int pno_cntr = 0;

	protected MCList<ListDtlR> reloadDtlList;

	// 旧データと区分けするためのバージョン
	private static String VERSION_10 = "1.0";
	private static String VERSION = VERSION_10;
	// デバッグ用に一時的にバージョンを変えられるようにする。
	static public void setVersion(String s) {
		VERSION = MCStringUtil.nullToBlank(s);
	}
	static public String getVersion() {
		return VERSION;
	}

	// protected static final String COMP_ID_VIEW_COLUMN = "comp_id_view";
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0650_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP0650_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	public void setMainPanelForBarcode(FSBAP0670 mainPanelForBarcode) {
		this.mainPanelForBarcode = mainPanelForBarcode;
	}

	public void setTargetFocusID(String targetFocusID) {
		this.targetFocusID = targetFocusID;
	}

	public void setTargetRootPanel(MCRootPanel targetRootPanel) {
		this.targetRootPanel = targetRootPanel;
	}

	public MCRootPanel getTargetRootPanel() {
		return this.targetRootPanel;
	}

	/**
	 * Panel[ListBtn]のボタン[radd]の押下時の処理
	 */
	@Override
	public void doListBtn_radd(MCEventInfo info) {
		ListDtlR r = insertRow(ListDtlTable);
		r.version(VERSION_10);
	}

	@Override
	protected void setDefaultScreenPosition() {
		super.setDefaultScreenPosition();

		MCRootPanel p = getParentPanel();
		if (p != null) {
			setArrangementCenter(p);
		}
	}

	protected void setPno() {
		getListDtlL().forEach(o -> {
			if (isNull(o.pno())) {
				o.pno(++pno_cntr);
			}
		});
	}

	@Override
	protected void valueInit() {
		super.valueInit();

		if (targetRootPanel != null) {
			getCndR().module_id(targetRootPanel.getModuleID());
			getCndR().screen_id(targetRootPanel.getScreenID());
		}

		addDoBehind(Cnd_reload);

		getListHdrR().version(VERSION_10);
		manualModeChanged();
	}

	/**
	 * Panel[Cnd]のボタン[reload]の押下時の処理
	 */
	@Override
	public void doCnd_reload(MCEventInfo info) {
		if (!getListHdrR().isStatusNone() || !getInfoL().isStatusNone()) {
			if (confirm(FSBAC0059) != MCMessageBox.YES_OPTION) {
				return;
			}
		}

		statusClear();

		reloadData();
	}

	protected void reloadData() {
		reloadDtlList = loadPersonalizeList(getCndR().module_id(), getCndR().screen_id());
		setListDtlL(reloadDtlList);

		ListDtlTable.fillSpace();
		setPno();

		boolean find = false;
		if (!ListDtlTable.getList().isEmpty()) {

			if (targetFocusID != null) {
				int idx2 = 0;
				for (ListDtlR r2 : ListDtlTable.getList()) {
					if (r2.focus_nm() == null) {
						ListDtlTable.selectLeftmostColumn(idx2);
						find = true;
						break;
					}
					if (r2.focus_id().equals(targetFocusID)) {
						ListDtlTable.selectLeftmostColumn(idx2);
						find = true;
						break;
					}
					idx2++;
				}
			}
			if (find == false) {
				// 初期選択
				ListDtlTable.selectLeftmostColumn(0);
			}
		}

		ListDtlTable.adjustWidth();
	}

	/**
	 * Panel[ListBtn]のボタン[del]の押下時の処理
	 */
	@Override
	public void doListEastBtn_del(MCEventInfo info) {
		// 削除確認メッセージ
		MCMessage m = new MCMessage(FSBAC0074, getListHdrR().focus_nm());
		if (confirm(MCDialogButton.NO, m) != MCMessageBox.YES_OPTION) {
			return;
		}

		// 削除
		String listKey = createListResourceKey(getCndR().module_id(), getCndR().screen_id()) + "."
				+ getListHdrR().focus_id();
		String[] ka = findPattern(listKey, "**");
		getResource().remove(getResourceLayerType(), ka);

		// タブ順情報
		String listKey2 = createTabOrderListResourceKey(getCndR().module_id(), getCndR().screen_id()) + "."
				+ getListHdrR().focus_id();
		String[] ka2 = findPattern(listKey2, "**");
		getResource().remove(getResourceLayerType(), ka2);

		MCConst.saveResource();

		// 変更ステータスクリア
		statusClear();

		// リロード
		reloadData();

		// 削除完了メッセージ
		dialog(FXBAP0022);
	}

	/**
	 * Panel[ListHdr]のボタン[upd]の押下時の処理
	 */
	@Override
	public void doListHdr_upd(MCEventInfo info) {
		// 登録確認メッセージ
		if (confirm(FSBAC0073, getListHdrR().focus_nm()) != MCMessageBox.YES_OPTION) {
			return;
		}

		// 必須入力チェック
		MCMessageList l = checkReq(getListHdrR());
		if (!l.isEmpty()) {
			message(l);
			return;
		}

		// フォーカス設定名の重複チェック
		MCList<ListDtlR> el = exceptEmpty(getListDtlL());
		MCList<ListDtlR> sl = el.subList(ListDtlR.$focus_nm, getListHdrR().focus_nm());
		if (sl.size() > 1) {
			MCMessage m = new MCMessage(FSBAC0072, getListHdrR().focus_nm());
			m.setCauseRow(getListHdrR(), ListDtlR.$focus_nm);
			dialog(m);
			return;
		}

		targetFocusID = getListHdrR().focus_id();
		targetFocusNM = getListHdrR().focus_nm();

		String focusID = prohibitionString(MCStringUtil.nullToBlank(targetFocusID));
		String focusNM = MCStringUtil.nullToBlank(targetFocusNM);

		// 新バージョン形式で強制保存される。
		String version = VERSION;
		savePersonalize(getCndR().module_id(), getCndR().screen_id(), focusID, focusNM, version);

		// focus_idが新規発番されるため再取得
		targetFocusID = getListHdrR().focus_id();
		targetFocusNM = getListHdrR().focus_nm();
		focusID = prohibitionString(MCStringUtil.nullToBlank(targetFocusID));
		focusNM = MCStringUtil.nullToBlank(targetFocusNM);

		// タブ順 保存
		tabOrderList = setTabOrderList(getInfoL());
		savePersonalizeTabOrder(getCndR().module_id(), getCndR().screen_id(), focusID, focusNM, version);

		// 変更ステータスクリア
		statusClear();

		reloadData();

		setFocusID(focusNM);

		dialog(FXBAP0021);
	}

	// メイン画面側に値を返す。
	protected void setFocusID(String nm) {
		if (mainPanelForBarcode != null) {
			mainPanelForBarcode.setFocusID(this, nm);
		}
	}

	// MCPersonalizeLocationを返す。
	protected MCPersonalizeLocation2 getPersonalizeLocation() {
		if (personalizeLocation == null) {
			personalizeLocation = new MCPersonalizeLocation2();
			personalizeLocation.setupTargetPanel(targetRootPanel);
			personalizeLocation.setupPanelList();
		}
		return personalizeLocation;
	}

	/**
	 * MCRoutePanelから一覧を生成
	 *
	 * @param moduleID
	 *            モジュールID
	 * @param screenID
	 *            画面ID
	 * @param focusID
	 *            フォーカスID
	 */
	protected MCList<InfoR> setupTableList(String moduleID, String screenID, String focusID) {
		// パーソナライズと混ぜる。

		MCList<InfoR> list2 = loadPersonalizeComponent(moduleID, screenID, focusID);
		// 画面のテーブルに転送
		MCList<InfoR> list0 = createInfoL();

		// 全部品
		List<Component> list = getPersonalizeLocation().getAllComponents(targetRootPanel);
		
		for (Component c : list) {
			Component comp = c;
			String clsName = comp.getClass().getName();
			if (clsName.equals(MCAutoLayout.textComboFieldName)) {
				comp = comp.getParent();
				continue;
			} else if (clsName.equals(MCAutoLayout.comboButtonName)) {
				comp = comp.getParent();
				continue;
			}
			Container parentPanel = getPersonalizeLocation().getParentPanel(comp);
			MCRootPanel rootPanel = getPersonalizeLocation().getRootPanel(comp);

			// _で始まるパネルに張り付く部品は除く
			if (parentPanel.getName() == null || parentPanel.getName().startsWith("_")) {
				continue;
			}

			// ブロックに属さないインフラ部品かどうか
			if (parentPanel == targetRootPanel) {
				continue;
			}

			if (comp.getName() == null) {
				continue;
			}

			if (comp instanceof MCLabel) {
				continue;
			}

			if (comp instanceof MCScrollPane) {
				continue;
			}
			
			// 7022-0113で一覧フォーカスにも対応
			//カラム指定を可能にする。

			setupTableSub(list0, list2, list, comp, parentPanel, rootPanel);
			
			if(comp instanceof MCTable) {
				MCTable<?> table = (MCTable<?>)comp;
				MCColumnConfig[] clist = table.getAllViewColumnConfigs();
				for(MCColumnConfig cc : clist) {
					if (MCBarcodeUtil.NAME_ROW_NUMBER.equals(cc.getName())) {
						continue;
					}
					if (MCBarcodeUtil.NAME_ROW_STATUS.equals(cc.getName())) {
						continue;
					}
					if (MCBarcodeUtil.NAME_ROW_SIGNAL.equals(cc.getName())) {
						continue;
					}
					
					setupTableColumn(list0, list2, list, table, cc, parentPanel, rootPanel);
				}
			}
			
		}
		list0.forEach(r -> {
			// r.focus_in_nm(getFocusInNm(r.focus_in(), list0));
			// r.focus_out_nm(getFocusOutNm(r.focus_out(), list0));
			// r.focus_out_next_focus_nm(getFocusOutNextNm(r.focus_out_next_focus(),
			// list0));
			// r.button_next_focus_nm(getFocusOutNextNm(r.button_next_focus(), list0));
			r.focus_in_nm(r.focus_in());
			r.focus_out_nm(r.focus_out());
			r.focus_out_next_focus_nm(r.focus_out_next_focus());
			r.button_next_focus_nm(r.button_next_focus());
		});

		// フォーカス順で並び替える。
		boolean b = loadPersonalizeManualMode(moduleID, screenID, focusID);
		if (focusID == null) { // 新規の場合は新バージョンになる。
			b = true;
		}
		if (b == true) {
			MCList<InfoTabOrderR> tabOrderList = loadPersonalizeTabOrder(moduleID, screenID, focusID);
			List<Component> components = personalizeLocation.getAllComponents(targetRootPanel);
			ArrayList<MCTabOrderBeans> tlist = getTabOrder(mainPanelForBarcode, targetRootPanel, tabOrderList,
					components, personalizeLocation);
			sortInfo(list0, tlist, components);
		} else {
			// 旧データでもデフォルトタブ順でソートは行う。
			MCList<InfoTabOrderR> tabOrderList = MCList.create(InfoTabOrderR.class);
			List<Component> components = personalizeLocation.getAllComponents(targetRootPanel);
			ArrayList<MCTabOrderBeans> tlist = getTabOrder(mainPanelForBarcode, targetRootPanel, tabOrderList,
					components, personalizeLocation);
			sortInfo(list0, tlist, components);
		}

		// setInfoL(list0);
		return list0;
	}
	
	
	protected void setupTableSub(MCList<InfoR> list0, MCList<InfoR> list2,
			List<Component> list, Component comp, Container parentPanel,
			MCRootPanel rootPanel) {
		InfoR findR = null;
		for (InfoR r1 : list0) {
			if (isSame(r1.comp_id(), comp.getName())) {
				if (isSame(r1.panel_id(), parentPanel.getName())) {
					String root_panel_id = MCStringUtil.nullToBlank(r1.root_panel_id());
					if (isSame(root_panel_id, rootPanel.getName())) {
						findR = r1;
						break;
					}
				}
			}
		}

		InfoR r0;
		if (findR != null) {
			r0 = findR;
		}
		else {
			r0 = InfoR.create();
		}

		r0.comp_id(comp.getName());
		r0.btn_flg(comp instanceof MCButton);
		r0.panel_id(parentPanel.getName());
		r0.root_panel_id(rootPanel.getName());

		// システム非表示は一覧に出さない。
		if (isInvisibleComponent(r0) == true) {
			return;
		}

		if (parentPanel instanceof MCPanel) {
			r0.panel_nm(((MCPanel) parentPanel).getLabelByLocale());
		}

		r0.focus_in(null);
		r0.focus_in_nm(null);
		r0.focus_out(null);
		r0.focus_out_nm(null);
		r0.focus_out_next_focus(null);
		r0.focus_out_next_focus_nm(null);
		r0.button_next_focus(null);
		r0.button_next_focus_nm(null);

		r0.start_focus_flg(false);
		r0.barcode_flg(false);

		for (InfoR r : list2) {
			if (r.comp_id().equals(r0.comp_id())) {
				if (r.panel_id().equals(r0.panel_id())) {
					String root_panel_id = MCStringUtil.nullToBlank(r.root_panel_id());
					if (root_panel_id.equals(r0.root_panel_id())) {
						r0.focus_in(r.focus_in());
						r0.focus_out(r.focus_out());
						r0.focus_out_next_focus(r.focus_out_next_focus());
						r0.button_next_focus(r.button_next_focus());
						r0.button_next_focus_nm(r.button_next_focus_nm());

						// 開始点とユーザ操作点と終了点対応
						r0.start_focus_flg(r.start_focus_flg());
						r0.barcode_flg(r.barcode_flg());
					}
				}
			}
		}

		r0.comp_nm(getComponentName(comp, list));
		r0.comp_typ(getComponentType(comp));

		if (findR == null) {
			list0.add(r0);
		}
	}
	
	protected void setupTableColumn(MCList<InfoR> list0, MCList<InfoR> list2,
			List<Component> list, MCTable<?> table, MCColumnConfig cc, Container parentPanel,
			MCRootPanel rootPanel) {
		InfoR findR = null;
		for (InfoR r1 : list0) {
			if (isSame(r1.comp_id(), cc.getName())) {
				if (isSame(r1.panel_id(), parentPanel.getName())) {
					String root_panel_id = MCStringUtil.nullToBlank(r1.root_panel_id());
					if (isSame(root_panel_id, rootPanel.getName())) {
						findR = r1;
						break;
					}
				}
			}
		}

		InfoR r0;
		if (findR != null) {
			r0 = findR;
		}
		else {
			r0 = InfoR.create();
		}

		r0.comp_id(cc.getName());
		r0.btn_flg(false);
		r0.panel_id(parentPanel.getName());
		r0.root_panel_id(rootPanel.getName());

		// システム非表示は一覧に出さない。
		if (isInvisibleComponent(r0) == true) {
			return;
		}

		if (parentPanel instanceof MCPanel) {
			r0.panel_nm(((MCPanel) parentPanel).getLabelByLocale());
		}

		r0.focus_in(null);
		r0.focus_in_nm(null);
		r0.focus_out(null);
		r0.focus_out_nm(null);
		r0.focus_out_next_focus(null);
		r0.focus_out_next_focus_nm(null);
		r0.button_next_focus(null);
		r0.button_next_focus_nm(null);

		r0.start_focus_flg(false);
		r0.barcode_flg(false);

		for (InfoR r : list2) {
			if (r.comp_id().equals(r0.comp_id())) {
				if (r.panel_id().equals(r0.panel_id())) {
					String root_panel_id = MCStringUtil.nullToBlank(r.root_panel_id());
					if (root_panel_id.equals(r0.root_panel_id())) {
						r0.focus_in(r.focus_in());
						r0.focus_out(r.focus_out());
						r0.focus_out_next_focus(r.focus_out_next_focus());
						r0.button_next_focus(r.button_next_focus());
						r0.button_next_focus_nm(r.button_next_focus_nm());

						// 開始点バーコードフォーカス対応
						r0.start_focus_flg(r.start_focus_flg());
						r0.barcode_flg(r.barcode_flg());
					}
				}
			}
		}

		r0.comp_nm(cc.getHeaderName());
		r0.comp_typ("TYPE_COLUMN");

		if (findR == null) {
			list0.add(r0);
		}
	}

	

	// タブ順リソースで並び替え
	protected void sortInfo(MCList<InfoR> list0, ArrayList<MCTabOrderBeans> tlist, List<Component> components) {
		Collections.sort(list0, new Comparator<InfoR>() {
			@Override
			public int compare(InfoR r1, InfoR r2) {
				String componentID1 = MCStringUtil.nullToBlank(r1.comp_id());
				String panelID1 = MCStringUtil.nullToBlank(r1.panel_id());
				String rootPanelID1 = MCStringUtil.nullToBlank(r1.root_panel_id());

				String componentID2 = MCStringUtil.nullToBlank(r2.comp_id());
				String panelID2 = MCStringUtil.nullToBlank(r2.panel_id());
				String rootPanelID2 = MCStringUtil.nullToBlank(r2.root_panel_id());

				String id1 = rootPanelID1 + "," + panelID1 + "," + componentID1;
				String id2 = rootPanelID2 + "," + panelID2 + "," + componentID2;

				Object c1 = MCBarcodeUtil.findComponent(targetRootPanel, components, personalizeLocation, id1);
				Object c2 = MCBarcodeUtil.findComponent(targetRootPanel, components, personalizeLocation, id2);

				int cc1 = 0;
				int cc2 = 0;
				if (c1 instanceof MCColumnConfig) {
					MCTable<?> t1 = ((MCColumnConfig) c1).getTable();
					MCColumnConfig[] a1 = t1.getAllColumnConfigs();
					for (MCColumnConfig cc : a1) {
						if (cc == c1) {
							break;
						}
						cc1++;
					}
					c1 = t1;
				}
				if (c2 instanceof MCColumnConfig) {
					MCTable<?> t2 = ((MCColumnConfig) c2).getTable();
					MCColumnConfig[] a2 = t2.getAllColumnConfigs();
					for (MCColumnConfig cc : a2) {
						if (cc == c2) {
							break;
						}
						cc2++;
					}
					c2 = t2;
				}
				
				int idx1 = tlist.indexOf(c1);
				int idx2 = tlist.indexOf(c2);
				if (idx1 == idx2) {
					if (c1 instanceof MCTable && c2 instanceof MCTable) {
						if (cc1 == cc2) {
							return 0;
						}
						else if (cc1 > cc2) {
							return 1;
						}
						else {
							return -1;
						}
					}
					return 0;
				}
				else if (idx1 > idx2) {
					return 1;
				}
				else {
					return -1;
				}
			}
		});
	}

	// フォーカス順をリソースから得て返す。
	public ArrayList<MCTabOrderBeans> getTabOrder(FSBAP0670 app2, MCRootPanel panel, MCList<InfoTabOrderR> tabOrderList,
			List<Component> components, MCPersonalizeLocation2 personalizeLocation) {
		ArrayList<MCTabOrderBeans> tlist = new ArrayList<>(panel.getTabOrderBeans(true));

		for (InfoTabOrderR r : tabOrderList) {
			String prevComponentID = MCStringUtil.nullToBlank(r.prev_component_id());
			String prevPanelID = MCStringUtil.nullToBlank(r.prev_panel_id());
			String prevRootPanelID = MCStringUtil.nullToBlank(r.prev_root_panel_id());

			String nextComponentID = MCStringUtil.nullToBlank(r.next_component_id());
			String nextPanelID = MCStringUtil.nullToBlank(r.next_panel_id());
			String nextRootPanelID = MCStringUtil.nullToBlank(r.next_root_panel_id());

			String id1 = prevRootPanelID + "," + prevPanelID + "," + prevComponentID;
			String id2 = nextRootPanelID + "," + nextPanelID + "," + nextComponentID;

			Object c1 = MCBarcodeUtil.findComponent(panel, components, personalizeLocation, id1);
			Object c2 = MCBarcodeUtil.findComponent(panel, components, personalizeLocation, id2);
			if (c1 != null && c2 != null) {
				if(c1 instanceof MCTabOrderBeans && c2 instanceof MCTabOrderBeans) {
					int idx = tlist.indexOf((MCTabOrderBeans) c1);
					if (idx < tlist.size() - 1) {
						tlist.remove((MCTabOrderBeans) c2);
						tlist.add(idx + 1, (MCTabOrderBeans) c2);
					}
				}
			}
		}
		return tlist;
	}

	protected List<Component> getAllComponents2(Container c) {
		Component[] comps = c.getComponents();
		List<Component> compList = new ArrayList<>();
		for (Component comp : comps) {
			compList.add(comp);
			if (comp instanceof Container) {
				compList.addAll(getAllComponents2((Container) comp));
			}
		}
		return compList;
	}

	// 部品名
	protected String getComponentName(Component comp, List<Component> aList) {
		if (comp instanceof MCBeans) {
			return ((MCBeans) comp).getMessageByLocale();
		}
		return null;
	}

	// 7022-0113
	// 部品形状
	protected String getComponentType(Component comp) {
		if (comp instanceof MCLabel) {
			return "TYPE_LABEL";
		} else if (comp instanceof MCButton) {
			return "TYPE_BUTTON";
		} else if (comp instanceof MCTextField) {
			return "TYPE_FIELD";
		} else if (comp instanceof MCNumberField) {
			return "TYPE_NUMBER_FIELD";
		} else if (comp instanceof MCTimestampField) {
			return "TYPE_FIELD";
		} else if (comp instanceof MCDateField) {
			return "TYPE_FIELD";
		} else if (comp instanceof MCComboField) {
			return "TYPE_COMBOBOX";
		} else if (comp instanceof MCTextComboBox) {
			return "TYPE_COMBOBOX";
		} else if (comp instanceof MCDateComboBox) {
			return "TYPE_COMBOBOX";
		} else if (comp instanceof MCNumberComboBox) {
			return "TYPE_COMBOBOX";
		} else if (comp instanceof MCCheckBox) {
			return "TYPE_CHECKBOX";
		} else if (comp instanceof MCRadioButton) {
			return "TYPE_RADIOBUTTON";
		} else if (comp instanceof MCTable) {
			return "TYPE_TABLE";
		}
		return comp.getClass().getName();
	}
	
	// 部品が非表示かどうか
	protected boolean getComponentVisible(Component comp) {
		if (comp == null) {
			return false;
		}
		if (comp.isVisible() == true) {
			return true;
		}
		return false;
	}

	// 画面部品情報を初期化
	// protected void initTableList() {
	// if(targetRootPanel == null) {
	// return;
	// }
	// String moduleID = targetRootPanel.getModuleID();
	// String screenID = targetRootPanel.getScreenID();
	//
	// setupTableList(moduleID,screenID,targetFocusID);
	// }

	// 一覧の部品名を設定する。
	// protected void setAllComponentNames() {
	// MCList<InfoR> list2 = getInfoL();
	// List<Component> list =
	// getPersonalizeLocation().getAllComponents(targetRootPanel);
	//
	// for(Component comp : list) {
	// Container parent = getPersonalizeLocation().getParentPanel(comp);
	// MCRootPanel rootPanel = getPersonalizeLocation().getRootPanel(comp);
	// String panelID = MCStringUtil.nullToBlank(parent.getName());
	// String rootPanelID = MCStringUtil.nullToBlank(rootPanel.getName());
	// String componentID = MCStringUtil.nullToBlank(comp.getName());
	//
	// for(InfoR r : list2) {
	// if(r.root_panel_id().equals(rootPanelID)) {
	// if(r.panel_id().equals(panelID)) {
	// if(r.comp_id().equals(componentID)) {
	// r.comp_nm(getComponentName(comp,list));
	// r.comp_typ(getComponentType(comp));
	// break;
	// }
	// }
	// }
	// }
	// }
	// }

	// パーソナライズ
	protected String createListResourceKey(String moduleID, String screenID) {
		return createKey("_0_SCR_", moduleID, screenID, "barcode", "barcode_focus", "list");
	}

	protected String createTabOrderListResourceKey(String moduleID, String screenID) {
		return createKey("_0_SCR_", moduleID, screenID, "barcode", "barcode_focus", "tab_order");
	}

	protected MCGeneralPersonalizeResource getResource() {
		return MCConst.app;
	}

	// フォーカス指定情報の一覧をパーソナライズから読込みする。
	protected MCList<ListDtlR> loadPersonalizeList(String moduleID, String screenID) {

		MCList<ListDtlR> list = createListDtlL();

		String listKey = createListResourceKey(moduleID, screenID);

		String[] baseKeys1 = findPattern(listKey, "*");

		for (String key1 : baseKeys1) {
			ListDtlR r = list.createRow();
			r.pno(++pno_cntr);
			r.focus_id(getString(key1, "focusID"));
			r.focus_nm(getString(key1, "focusNM"));

			// manualModeは不要
			// 自動変換するかどうかはこの値で決める。
			r.version(getString(key1, "version"));

			list.add(r);
		}

		Collections.sort(list, new FocusComparator());

		return list;
	}

	// ID順に並べ替え
	protected class FocusComparator implements Comparator<ListDtlR> {
		@Override
		public int compare(ListDtlR a1, ListDtlR a2) {
			int i = a1.focus_id().compareTo(a2.focus_id());
			return i;
		}
	}

	// 禁則文字を変換
	protected String prohibitionString(String content) {
		StringBuilder buffer = new StringBuilder();
		for (int i = 0; i < content.length(); i++) {
			char c = content.charAt(i);
			if (c < 0x30 || (c >= 0x3a && c <= 0x40) || (c > 0x5a && c <= 0x60) || c > 0x7a) {
				buffer.append("_");
			} else {
				buffer.append(c);
			}
		}
		return buffer.toString();
	}

	protected MCResourceLayerType getResourceLayerType() {
		return MCResourceLayerType.BARCODE;
	}

	// パーソナライズに書き込む。
	// バージョンを追加
	protected void savePersonalize(String aModuleID, String aScreenID, String aFocusID, String aFocusNM,
			String aVersion) {

		if (aFocusID == null || aFocusID.length() == 0) {
			aFocusID = createFocusID(aModuleID, aScreenID);
			getListHdrR().focus_id(aFocusID);
		}

		String focusID = prohibitionString(aFocusID);
		String listKey = createListResourceKey(aModuleID, aScreenID) + "." + focusID;

		MCResourceLayerType type = getResourceLayerType();
		String[] ka = findPattern(listKey, "**");
		getResource().remove(type, ka);

		setString(focusID, listKey, "focusID");
		setString(aFocusNM, listKey, "focusNM");

		// バージョン情報を付与
		setString(aVersion, listKey, "version");

		MCList<InfoR> list = getInfoL();

		int idx = 0;
		for (InfoR r : list) {
			String focus_in = MCStringUtil.nullToBlank(r.focus_in());
			String focus_out = MCStringUtil.nullToBlank(r.focus_out());
			String focus_out_next_focus = MCStringUtil.nullToBlank(r.focus_out_next_focus());
			String button_next_focus = MCStringUtil.nullToBlank(r.button_next_focus());

			String start_focus_flg = r.start_focus_flg() ? "true" : "false";
			String barcode_flg = r.barcode_flg() ? "true" : "false";

			if (focus_in.length() > 0 || focus_out.length() > 0 || focus_out_next_focus.length() > 0
					|| button_next_focus.length() > 0 || start_focus_flg.equals("true")
					|| barcode_flg.equals("true")) { // 何も設定されていないデータは保存しない。

				String resItemKey = createKey(listKey, "item" + idx);

				setString(r.comp_id(), resItemKey, "componentID");
				setString(r.panel_id(), resItemKey, "panelID");
				setString(r.root_panel_id(), resItemKey, "rootPanelID");

				setString(focus_in, resItemKey, "focusIn");
				setString(focus_out, resItemKey, "focusOut");
				setString(focus_out_next_focus, resItemKey, "focusOutNextFocus");

				setString(button_next_focus, resItemKey, "buttonNextFocus");

				setString(start_focus_flg, resItemKey, "startFocus");
				setString(barcode_flg, resItemKey, "barcode");

				idx++;
			}
		}

		for (InfoR r : list) {
			if (r.error_focus_flg() == true) {
				String k = r.root_panel_id() + "," + r.panel_id() + "," + r.comp_id();
				setString(k, listKey, "initFocus");
				break;
			}
		}

		MCConst.saveResource();
	}

	public final String FOCUS = "FOCUS_";

	// 新規フォーカス設定IDを生成する。
	public String createFocusID(String aModuleID, String aScreenID) {

		// すでに登録されているかどうかのチェック
		List<String> list = new ArrayList<String>();
		String listKey = createListResourceKey(aModuleID, aScreenID);
		String[] baseKeys = findPattern(listKey, "*");
		for (String key1 : baseKeys) {
			String barcode_id = getString(key1, "focusID");
			list.add(barcode_id);
		}

		for (int n = 1; n < 1000000000; n++) {
			String focus_id = FOCUS + String.format("%09d", n);
			if (list.contains(focus_id) == false) {
				// 画面上に表示されている分のチェック
				boolean b = false;
				for (ListDtlR r : ListDtlTable.getList()) {
					if (focus_id.equals(r.focus_id())) {
						b = true;
						break;
					}
				}

				if (b == false) {
					String id = prohibitionString(focus_id);
					return id;
				}
			}
		}

		return FOCUS + "999999999";
	}

	/**
	 * エラーフォーカスデータをパーソナライズから取得
	 *
	 * @param panelModuleID
	 *            モジュールID
	 * @param panelScreenID
	 *            画面ID
	 * @param aFocusID
	 *            フォーカスID
	 * @return
	 */
	protected String loadPersonalizeErrorFocus(String panelModuleID, String panelScreenID, String aFocusID) {
		String listKey = createListResourceKey(panelModuleID, panelScreenID);
		String errorFocus = getString(listKey, aFocusID, "initFocus");
		return errorFocus;
	}

	/**
	 * フォーカスデータをリソースから取得
	 *
	 * @param panelModuleID
	 *            モジュールID
	 * @param panelScreenID
	 *            画面ID
	 * @param aFocusID
	 *            フォーカスID
	 * @return
	 */
	public MCList<InfoR> loadPersonalizeComponent(String panelModuleID, String panelScreenID, String aFocusID) {

		MCList<InfoR> list = createInfoL();

		String listKey1 = createListResourceKey(panelModuleID, panelScreenID);
		String[] baseKeys1 = findPattern(listKey1, "*");
		for (String key1 : baseKeys1) {
			String id = getString(key1, "focusID");
			if (id != null) {
				if (id.equals(aFocusID)) {
					String listKey2 = createKey(createListResourceKey(panelModuleID, panelScreenID), id);
					String itemKey = listKey2 + ".item";
					String[] baseKeys2 = findPattern(listKey2, "*");
					for (String key2 : baseKeys2) {
						if (key2.startsWith(itemKey)) {
							InfoR r = list.createRow();
							r.comp_id(getString(key2, "componentID"));
							r.panel_id(getString(key2, "panelID"));
							r.root_panel_id(getString(key2, "rootPanelID"));
							r.focus_in(getString(key2, "focusIn"));
							r.focus_out(getString(key2, "focusOut"));
							r.focus_out_next_focus(getString(key2, "focusOutNextFocus"));
							r.button_next_focus(getString(key2, "buttonNextFocus"));

							r.start_focus_flg("true".equals(getString(key2, "startFocus")));
							r.barcode_flg("true".equals(getString(key2, "barcode")));

							list.add(r);
						}
					}
				}
			}
		}

		return list;
	}

	/**
	 * フォーカスデータをリソースから取得 タブオーダ
	 *
	 * @param panelModuleID
	 *            モジュールID
	 * @param panelScreenID
	 *            画面ID
	 * @param aFocusID
	 *            フォーカスID
	 * @return MCList<InfoTabOrderR>
	 */
	public MCList<InfoTabOrderR> loadPersonalizeTabOrder(String panelModuleID, String panelScreenID, String aFocusID) {

		MCList<InfoTabOrderR> list = MCList.create(InfoTabOrderR.class);

		String listKey1 = createTabOrderListResourceKey(panelModuleID, panelScreenID);
		String[] baseKeys1 = findPattern(listKey1, "*");
		for (String key1 : baseKeys1) {
			String id = getString(key1, "focusID");
			if (id != null) {
				if (id.equals(aFocusID)) {
					String listKey2 = createKey(createTabOrderListResourceKey(panelModuleID, panelScreenID), id);
					String itemKey = listKey2 + ".item";
					String[] baseKeys2 = findPattern(listKey2, "*");
					for (String key2 : baseKeys2) {
						if (key2.startsWith(itemKey)) {
							InfoTabOrderR r = list.createRow();
							String list1 = getString(key2, "list");
							if (list1 != null) {
								String[] list2 = list1.split(",");

								r.prev_component_id(list2[0]);
								r.prev_panel_id(list2[1]);
								r.prev_root_panel_id(list2[2]);
								r.next_component_id(list2[3]);
								r.next_panel_id(list2[4]);
								r.next_root_panel_id(list2[5]);

								list.add(r);
							}
						}
					}
				}
			}
		}

		tabOrderList = list;

		return list;
	}

	// パーソナライズリソースにタブオーダー情報書き込む。
	// バージョンを追加
	protected void savePersonalizeTabOrder(String aModuleID, String aScreenID, String aFocusID, String aFocusNM,
			String aVersion) {

		if (aFocusID == null || aFocusID.length() == 0) {
			aFocusID = createFocusID(aModuleID, aScreenID);
			getListHdrR().focus_id(aFocusID);
		}

		String focusID = prohibitionString(aFocusID);
		String listKey = createTabOrderListResourceKey(aModuleID, aScreenID) + "." + focusID;

		MCResourceLayerType type = getResourceLayerType();
		String[] ka = findPattern(listKey, "**");
		getResource().remove(type, ka);

		setString(focusID, listKey, "focusID");
		setString(aFocusNM, listKey, "focusNM");

		// バージョン情報を付与
		setString(aVersion, listKey, "version");

		MCList<InfoTabOrderR> list = getInfoTabOrderL();

		int idx = 0;
		for (InfoTabOrderR r : list) {

			String resItemKey = createKey(listKey, "item" + idx);

			String id1 = r.prev_component_id() + "," + r.prev_panel_id() + "," + r.prev_root_panel_id();
			String id2 = r.next_component_id() + "," + r.next_panel_id() + "," + r.next_root_panel_id();
			String id3 = id1 + "," + id2;

			setString(id3, resItemKey, "list");

			idx++;
		}

		MCConst.saveResource();
	}

	protected MCList<InfoTabOrderR> tabOrderList;

	protected MCList<InfoTabOrderR> getInfoTabOrderL() {
		if (tabOrderList == null) {
			tabOrderList = MCList.create(InfoTabOrderR.class);
		}
		return tabOrderList;
	}

	// タブ順のリストを生成
	protected void setInfoTabOrderL() {

	}

	@Override
	public boolean doListDtl_VC(MCEventInfo info) {
		if (!getListHdrR().isStatusNone() || !getInfoL().isStatusNone()) {
			if (confirm(FSBAC0059) != MCMessageBox.YES_OPTION) {
				return false;
			}

			ListDtlR o = ListDtlTable.getSelectedMCRow();
			MCList<ListDtlR> l = reloadDtlList.subList(ListDtlR.$pno, o.pno());
			if (!l.isEmpty()) {
				o.setValues(ListDtlR.colnames(), l.get(0), ListDtlR.colnames());
				o.setStatus(MCRow.NONE);
			} else {
				o.clearAll();
				o.setStatus(MCRow.GUICREATE);
			}

		}
		return super.doListDtl_VC(info);
	}

	@Override
	public void doListDtl_NC(MCEventInfo info) {

		String moduleID = targetRootPanel.getModuleID();
		String screenID = targetRootPanel.getScreenID();

		ListDtlR r = ListDtlTable.getSelectedMCRow();
		if (r != null) {
			// versionを1.0に固定
			if (MCStringUtil.nullToBlank(r.focus_id()).length() == 0) {
				r.version(VERSION);
			}

			getListHdrR().pno(r.pno());
			getListHdrR().focus_id(r.focus_id());
			getListHdrR().focus_nm(r.focus_nm());

			// バージョンを付与
			getListHdrR().version(r.version());

			manualModeChanged();

			getListHdrR().setStatus(MCRow.NONE);

			MCList<InfoR> list0 = setupTableList(moduleID, screenID, r.focus_id());
			setInfoL(list0);

			MCList<InfoR> list1 = loadPersonalizeComponent(moduleID, screenID, r.focus_id());
			String errorFocus = loadPersonalizeErrorFocus(moduleID, screenID, r.focus_id());
			mergeComponentList(list1, errorFocus);
		}

		setListHdrFocusIDMode();

		InfoTable.adjustWidth();

		// 新バージョンに変換、保存で新旧変換が確定する。
		convertTo10(moduleID, screenID, r.focus_id(), r.focus_nm());
	}

	protected void setListHdrFocusIDMode() {
		if (!reloadDtlList.subList(ListDtlR.$pno, getListHdrR().pno()).isEmpty()) {
			ListHdr_focus_id.setMode(MCMode.READ_ONLY);
		} else {
			setDefaultMode(ListHdr_focus_id);
		}
	}

	// listをcomponentListに混ぜる。
	protected void mergeComponentList(MCList<InfoR> list, String errorFocus) {
		MCList<InfoR> list2 = getInfoL();
		for (InfoR c : list) {
			for (InfoR c2 : list2) {
				if (isSame(c.comp_id(), c2.comp_id())) {
					if (isSame(c.panel_id(), c2.panel_id())) {
						if (isSame(c.root_panel_id(), c2.root_panel_id())) {
							c.focus_in(c.focus_in());
							c.focus_out(c.focus_out());
							c.focus_out_next_focus(c.focus_out_next_focus());
							c.button_next_focus(c.button_next_focus());
							break;
						}
					}
				}
			}
		}
		if (errorFocus != null) {
			String[] item = errorFocus.split(",", 0);
			if (item.length == 3) {
				for (InfoR c3 : list2) {
					boolean b = false;
					if (isSame(item[0], c3.root_panel_id())) {
						if (isSame(item[1], c3.panel_id())) {
							if (isSame(item[2], c3.comp_id())) {
								// error_focus_flgの機能はstart_focus_flgに統合 7.0.22
								// error_focus_flgは廃止
								c3.error_focus_flg(false);
								// start_focus_flgを自動変換する場合
								// c3.start_focus_flg(true);
								b = true;
							}
						}
					}
					if (b == false) {
						c3.error_focus_flg(false);
					}
				}
			}
		} else {
			for (InfoR c3 : list2) {
				c3.error_focus_flg(false);
			}
		}
	}

	@Override
	public void doInfo_error_focus_flg_NC(MCEventInfo info) {
		InfoR r = getInfoL().get(info.getEventIndex());

		MCList<InfoR> list2 = getInfoL();
		for (InfoR r2 : list2) {
			if (r2 != r) {
				if (r2.error_focus_flg()) {
					r2.error_focus_flg(false);
				}
			}
		}
	}

	@Override
	protected void listInit() {
		super.listInit();

		// 7.0.1 IDでコンボ
		getInfo_focus_in_nm_ListPutter().setColumns(InfoR.$comp_id, InfoR.$comp_id);
		getInfo_focus_out_nm_ListPutter().setColumns(InfoR.$comp_id, InfoR.$comp_id);
		getInfo_focus_out_next_focus_nm_ListPutter().setColumns(InfoR.$comp_id, InfoR.$comp_id);
		getInfo_button_next_focus_nm_ListPutter().setColumns(InfoR.$comp_id, InfoR.$comp_id);
//
		columnInfo_focus_in_nm.setListVisibleColumn(InfoR.$comp_id, InfoR.$comp_nm);
		columnInfo_focus_out_nm.setListVisibleColumn(InfoR.$comp_id, InfoR.$comp_nm);
		columnInfo_focus_out_next_focus_nm.setListVisibleColumn(InfoR.$comp_id, InfoR.$comp_nm);
		columnInfo_button_next_focus_nm.setListVisibleColumn(InfoR.$comp_id, InfoR.$comp_nm);
//
//		columnInfo_focus_out_nm.setListVisibleColumn(InfoR.$comp_id, InfoR.$comp_nm);
	}

	// focus_inコンボ
	@Override
	public MCList<?> getInfo_focus_in_nm(MCRow row, MCEventInfo info) {
		MCList<InfoR> list = createInfoL();
//		list.addStringColumn(COMP_ID_VIEW_COLUMN);

		for (InfoR o : getInfoL()) {
			if(isInvisibleComponent(o) == false) {
				InfoR data = list.createRow();
				String k = o.root_panel_id() + "," + o.panel_id() + "," + o.comp_id();
	//			data.setString(COMP_ID_VIEW_COLUMN, o.comp_id());
				data.comp_id(k);
				data.comp_nm(o.comp_nm());
				list.add(data);
			}
		}

		return list;
	}

	// focus_outコンボ
	@Override
	public MCList<?> getInfo_focus_out_nm(MCRow row, MCEventInfo info) {
		MCList<InfoR> list = createInfoL();
//		list.addStringColumn(COMP_ID_VIEW_COLUMN);

		for (InfoR o : getInfoL()) {
			if (o.btn_flg()) {
				if(isInvisibleComponent(o) == false) {
					InfoR data = list.createRow();
					String k = o.root_panel_id() + "," + o.panel_id() + "," + o.comp_id();
	//				data.setString(COMP_ID_VIEW_COLUMN, o.comp_id());
					data.comp_id(k);
					data.comp_nm(o.comp_nm());
					list.add(data);
				}
			}
		}

		InfoR data1 = list.createRow();
		data1.comp_id(MCBarcodeUtil.commandUser);
		list.add(data1);

		InfoR data2 = list.createRow();
		data2.comp_id(MCBarcodeUtil.commandEnd);
		list.add(data2);
		
		return list;
	}

	// 7022-0113
	//入力補助用
	public boolean isSingleBeans() {

		return false;
	}


	// 7022-0113
	//入力補助用
	public MCList<InfoR> get_component_list() {
		MCList<InfoR> list = createInfoL();
//		list.addStringColumn(COMP_ID_VIEW_COLUMN);

		for (InfoR o : getInfoL()) {
			if(isInvisibleComponent(o) == false) {
				InfoR r = list.createRow();
				String k = o.root_panel_id() + "," + o.panel_id() + "," + o.comp_id();
	//			data.setString(COMP_ID_VIEW_COLUMN, o.comp_id());
				r.comp_id(k);
				r.comp_nm(o.comp_nm());
				r.btn_flg(o.btn_flg());
				list.add(r);
			}
		}

		return list;
	}

	// focus_out_next_focusコンボ
	@Override
	public MCList<?> getInfo_focus_out_next_focus_nm(MCRow row, MCEventInfo info) {
		MCList<InfoR> list = createInfoL();
//		list.addStringColumn(COMP_ID_VIEW_COLUMN);

		for (InfoR o : getInfoL()) {
			if(isInvisibleComponent(o) == false) {
				InfoR data = list.createRow();
				String k = o.root_panel_id() + "," + o.panel_id() + "," + o.comp_id();
	//			data.setString(COMP_ID_VIEW_COLUMN, o.comp_id());
				data.comp_id(k);
				data.comp_nm(o.comp_nm());
				list.add(data);
			}
		}

		return list;
	}

	// button_next_focusコンボ
	@Override
	public MCList<?> getInfo_button_next_focus_nm(MCRow row, MCEventInfo info) {
		MCList<InfoR> list = createInfoL();
//		list.addStringColumn(COMP_ID_VIEW_COLUMN);

		for (InfoR o : getInfoL()) {
			if(isInvisibleComponent(o) == false) {
				InfoR data = list.createRow();
				String k = o.root_panel_id() + "," + o.panel_id() + "," + o.comp_id();
	//			data.setString(COMP_ID_VIEW_COLUMN, o.comp_id());
				data.comp_id(k);
				data.comp_nm(o.comp_nm());
				list.add(data);
			}
		}

		return list;
	}

	// システム非表示になっている部品かどうか
	protected boolean isInvisibleComponent(InfoR r) {
		Map<String, MCLayoutLocationR> map = targetRootPanel.getSystemLocationMap();
		MCLayoutLocationR findR = null;
		for (Map.Entry<String, MCLayoutLocationR> e : map.entrySet()) {
			MCLayoutLocationR r1 = e.getValue();
			if (r1.componentID().equals(r.comp_id())) {
				if (r1.rootPanelID().equals(r.root_panel_id())) {
					if (r1.panelID().equals(r.panel_id())) {
						findR = r1;
						break;
					}
				}
			}
		}
		if (findR != null) {
			if (findR.isVisible() == false) {
				return true;
			}
		}
		return false;
	}

	protected String getFocusInNm(String id, MCList<InfoR> list) {
		for (InfoR o : list) {
			String k = o.root_panel_id() + "," + o.panel_id() + "," + o.comp_id();
			if (isSame(id, k)) {
				return o.comp_id();
			}
		}
		return null;
	}

	protected String getFocusOutNm(String id, MCList<InfoR> list) {
//		String[] ids = MCStringUtil.split("/", id);
		String[] ids = MCStringUtil.split("^", id);
		List<String> nmList = new ArrayList<>(ids.length);
		for (String i : ids) {
			for (InfoR o : list) {
				if (o.btn_flg()) {
					String k = o.root_panel_id() + "," + o.panel_id() + "," + o.comp_id();
					if (isSame(i, k)) {
						nmList.add(o.comp_id());
					}
				}
			}
		}
		if (nmList.isEmpty()) {
			return null;
		}
		return MCStringUtil.arrayValueJoin(nmList.toArray(new String[0]));
	}

	protected String getFocusOutNextNm(String id, MCList<InfoR> list) {
		for (InfoR o : list) {
			String k = o.root_panel_id() + "," + o.panel_id() + "," + o.comp_id();
			if (isSame(id, k)) {
				return o.comp_id();
			}
		}
		return null;
	}

	protected String getButtonNextNm(String id, MCList<InfoR> list) {
		for (InfoR o : list) {
			String k = o.root_panel_id() + "," + o.panel_id() + "," + o.comp_id();
			if (isSame(id, k)) {
				return o.comp_id();
			}
		}
		return null;
	}

	@Override
	public void doListHdr_focus_id_LC(MCEventInfo info) {
		ListDtlR data = ListDtlTable.getSelectedMCRow();
		if (data != null) {
			setValueEx(columnListDtl_focus_id, data.getGUIIndex(), getListHdrR().focus_id());
		}
	}

	@Override
	public void doListHdr_focus_nm_LC(MCEventInfo info) {
		ListDtlR data = ListDtlTable.getSelectedMCRow();
		if (data != null) {
			setValueEx(columnListDtl_focus_nm, data.getGUIIndex(), getListHdrR().focus_nm());
		}
	}

	/**
	 * MCAppClientリソースのシステム共通のリソース値を返します。
	 *
	 * @param keys
	 *            リソースキー
	 * @return リソース値。リソース値が殻文字の場合はnull。リソース値が見つからなかった場合はnull。
	 */
	protected String getString(String... keys) {
		return MCStringUtil.blankToNull(getResource().getString(getResourceLayerType(), createKey(keys)));
	}

	/**
	 * MCAppClientリソースのシステム共通のリソース情報を登録します。
	 *
	 * @param val
	 *            リソース値。nullを指定した場合は空文字を登録する。
	 * @param keys
	 *            リソースキー
	 */
	protected void setString(String val, String... keys) {
		getResource().setString(getResourceLayerType(), createKey(keys), MCStringUtil.nullToBlank(val));
	}

	protected String[] findPattern(String... keys) {
		return getResource().findPattern(getResourceLayerType(), createKey(keys));
	}

	@Override
	protected String getPopupPattern(MCPopupBeans compo) {
		return FSUCP_PopupConfig.PERSONALIZE_PANEL;
	}

	@Override
	public boolean doInfo_focus_out_nm_VC(MCEventInfo info) {
		if (!super.doInfo_focus_out_nm_VC(info)) {
			return false;
		}

		String val = (String) info.getNewValue();
		if (!isNull(val)) {
			String[] vals = MCStringUtil.arrayValueSplit(val);
			for (String v : vals) {
				// ID存在チェック
				if (checkExistID(v) == false) {
					return false;
				}
			}
		}

		return true;
	}
	
	@Override
	public void doInfo_focus_out_nm_LC(MCEventInfo info) {
		super.doInfo_focus_out_nm_LC(info);

		InfoR data = getInfoL().get(info.getEventIndex());
		String val = data.focus_out_nm();
		if (isNull(val)) {
			data.focus_out(null);
		} else {
			String[] vals = MCStringUtil.arrayValueSplit(val);
			List<String> idList = new ArrayList<>(vals.length);
			for (String v : vals) {
				// MCList<InfoR> l = getInfoL().subList(InfoR.$comp_id, v);
				// if (!l.isEmpty()) {
				// InfoR o = l.get(0);
				// String id = o.root_panel_id() + "," + o.panel_id() + "," + o.comp_id();
				// idList.add(id);
				// }
				// 存在しないIDは除く
				if (checkExistID(v)) {
					idList.add(v);
				}
			}
			// data.focus_out(MCStringUtil.join("/", idList.toArray(new String[0])));
			data.focus_out(MCStringUtil.join("^", idList.toArray(new String[0])));
		}
	}


	@Override
	public boolean doInfo_focus_in_nm_VC(MCEventInfo info) {
		if (!super.doInfo_focus_in_nm_VC(info)) {
			return false;
		}

		String val = (String) info.getNewValue();
		if (!isNull(val)) {
			String[] vals = MCStringUtil.arrayValueSplit(val);
			for (String v : vals) {
				// ID存在チェック
				if (checkExistID(v) == false) {
					return false;
				}
			}
		}

		return true;
	}
	
	@Override
	public void doInfo_focus_in_nm_LC(MCEventInfo info) {
		super.doInfo_focus_in_nm_LC(info);

		InfoR data = getInfoL().get(info.getEventIndex());
		String val = data.focus_out_nm();
		if (isNull(val)) {
			data.focus_out(null);
		} else {
			String[] vals = MCStringUtil.arrayValueSplit(val);
			List<String> idList = new ArrayList<>(vals.length);
			for (String v : vals) {
				// 存在しないIDは除く
				if (checkExistID(v)) {
					idList.add(v);
				}
			}
			// data.focus_out(MCStringUtil.join("/", idList.toArray(new String[0])));
			data.focus_out(MCStringUtil.join("^", idList.toArray(new String[0])));
		}
	}
	
	
	@Override
	public boolean doInfo_focus_out_next_focus_nm_VC(MCEventInfo info) {
		if (!super.doInfo_focus_out_next_focus_nm_VC(info)) {
			return false;
		}

		String val = (String) info.getNewValue();
		if (!isNull(val)) {
			String[] vals = MCStringUtil.arrayValueSplit(val);
			for (String v : vals) {
				// ID存在チェック
				if (checkExistID(v) == false) {
					return false;
				}
			}
		}

		return true;
	}
	
	@Override
	public boolean doInfo_button_next_focus_nm_VC(MCEventInfo info) {
		if (!super.doInfo_button_next_focus_nm_VC(info)) {
			return false;
		}

		String val = (String) info.getNewValue();
		if (!isNull(val)) {
			String[] vals = MCStringUtil.arrayValueSplit(val);
			for (String v : vals) {
				// ID存在チェック
				if (checkExistID(v) == false) {
					return false;
				}
			}
		}

		return true;
	}

	@Override
	public void doInfo_button_next_focus_nm_LC(MCEventInfo info) {
		super.doInfo_button_next_focus_nm_LC(info);

		InfoR data = getInfoL().get(info.getEventIndex());
		String val = data.button_next_focus_nm();
		if (isNull(val)) {
			data.button_next_focus(null);
		} else {
			if (checkExistID(val) == false) {
				data.button_next_focus(null);
			}
		}
	}

	@Override
	public boolean doInfo_focus_out_next_focus_VC(MCEventInfo info) {
		if (!super.doInfo_focus_out_next_focus_VC(info)) {
			return false;
		}

		String val = (String) info.getNewValue();
		if (!isNull(val)) {
			String[] vals = MCStringUtil.arrayValueSplit(val);
			for (String v : vals) {
				// ID存在チェック
				if (checkExistID(v) == false) {
					return false;
				}
			}
		}

		return true;
	}

	@Override
	public void doInfo_focus_out_next_focus_LC(MCEventInfo info) {
		super.doInfo_focus_out_next_focus_LC(info);

		InfoR data = getInfoL().get(info.getEventIndex());
		String val = data.focus_out_next_focus_nm();
		if (isNull(val)) {
			data.focus_out_next_focus(null);
		} else {
			if (checkExistID(val) == false) {
				data.focus_out_next_focus(null);
			}
		}
	}

	// 画面部品ID存在チェック
	private boolean checkExistID(String id) {
		MCList<InfoR> l = getInfoL();
		for (InfoR r1 : l) {
			String id1 = r1.root_panel_id() + "," + r1.panel_id() + "," + r1.comp_id();
			if (id1.equals(id)) {
				return true;
			}
		}

		if (MCBarcodeUtil.commandUser.equals(id)) {
			return true;
		}
		if (MCBarcodeUtil.commandAuto.equals(id)) {
			return true;
		}
		if (MCBarcodeUtil.commandEnd.equals(id)) {
			return true;
		}

		return false;
	}

	@Override
	protected void tableInit() {
		super.tableInit();

		InfoTable.setSortable(false);
	}

	// 上下操作できるようにする。
	@Override
	public MCTable<?> getRowMoveTable() {
		return InfoTable;
	}

	@Override
	public boolean isStatusChange() {
		return true;
	}

	protected Integer saveDividerLocation = null;

	@Override
	public void doListHdr_version_NC(MCEventInfo info) {
		manualModeChanged();
	}

	protected void manualModeChanged() {
//		String version = MCStringUtil.nullToBlank(getListHdrR().version());
		
		//旧版も新版画面で表示
		if (MAN.equals(getStatus()) == false) {
			setMANStatus();
		}

//		
//		if (VERSION_10.equals(version)) { // 1.0 でユーザ操作機能を追加
//			if (MAN.equals(getStatus()) == false) {
//				setMANStatus();
//			}
//		} else {
//			if (AUTO.equals(getStatus()) == false) {
//				setAUTOStatus();
//			}
//		}
	}

	protected MCSplitPane getSplitPane(MCPanel p) {
		Component c = p;
		boolean b = true;
		while (b) {
			c = c.getParent();
			if (c == null) {
				break;
			}
			if (c instanceof MCSplitPane) {
				return (MCSplitPane) c;
			}
		}

		return null;
	}

	/**
	 * 手動入力かどうかをパーソナライズから取得
	 *
	 * @param panelModuleID
	 *            モジュールID
	 * @param panelScreenID
	 *            画面ID
	 * @param aFocusID
	 *            フォーカスID
	 * @return boolean
	 */
	public boolean loadPersonalizeManualMode(String panelModuleID, String panelScreenID, String aFocusID) {
		String listKey = createListResourceKey(panelModuleID, panelScreenID);
		String b = getString(listKey, aFocusID, "version");
		return VERSION_10.equals(b);
	}

	// InfoRからタブ順リストを生成する。
	protected MCList<InfoTabOrderR> setTabOrderList(MCList<InfoR> list0) {
		MCList<InfoTabOrderR> list = MCList.create(InfoTabOrderR.class);

		for (int i = 0; i < list0.size() - 1; i++) {
			InfoR r1 = list0.get(i);
			InfoR r2 = list0.get(i + 1);

			InfoTabOrderR r = InfoTabOrderR.create();
			r.prev_component_id(r1.comp_id());
			r.prev_panel_id(r1.panel_id());
			r.prev_root_panel_id(r1.root_panel_id());

			r.next_component_id(r2.comp_id());
			r.next_panel_id(r2.panel_id());
			r.next_root_panel_id(r2.root_panel_id());

			list.add(r);
		}
		return list;
	}

	// 旧データを新データに変換
	protected void convertTo10(String panelModuleID, String panelScreenID, String focusID, String focusNM) {
		boolean b = loadPersonalizeManualMode(panelModuleID, panelScreenID, focusID);
		if (b == true) {
			// version 1.0以降は不要
			return;
		}

		if (focusID == null) { // 新規の場合は変換不要
			return;
		}

		MCList<InfoR> list = setupTableList(panelModuleID, panelScreenID, focusID);
		String errorFocus = loadPersonalizeErrorFocus(panelModuleID, panelScreenID, focusID);
		mergeComponentList(list, errorFocus);

		if (tabOrderList == null) {
			tabOrderList = setTabOrderList(getInfoL());
		}

		List<Component> components = personalizeLocation.getAllComponents(targetRootPanel);
		ArrayList<MCTabOrderBeans> tlist = getTabOrder(mainPanelForBarcode, targetRootPanel, tabOrderList, components,
				personalizeLocation);
		sortInfo(list, tlist, components);

		// InfoRのリストのソート後に
		// フォーカスインで移動する画面部品
		// if(false) {
		for (InfoR r : list.shallowClone()) {
			String focus_in = r.focus_in();
			if (MCStringUtil.nullToBlank(focus_in).length() == 0) {
				continue;
			}
			String s[] = focus_in.split(",");
			if (s.length == 3) {
				String rootPanelID = s[0];
				String panelID = s[1];
				String componentID = s[2];

				for (InfoR r2 : list) {
					if (r2.root_panel_id().equals(rootPanelID) && r2.panel_id().equals(panelID)
							&& r2.comp_id().equals(componentID)) {
						// focus_inをrの後ろに移動

						list.remove(r2);
						int idx = list.indexOf(r);
						list.add(idx + 1, r2);
						break;
					}
				}
			}
			// }
		}

		// 保存する。
		// version 1.0にする。
		String version = VERSION;
		tabOrderList = setTabOrderList(list);
		savePersonalizeTabOrder(panelModuleID, panelScreenID, focusID, focusNM, version);
	}
	
	//入力補助を追加
	// 7022-0113
	@Override
	protected void linkBeansToISPanel() {
		super.linkBeansToISPanel();
		linkBeansToISPanel(columnInfo_focus_out_nm, "FS", "FSBAP0640", true);
		linkBeansToISPanel(columnInfo_button_next_focus_nm, "FS", "FSBAP0640", true);

		linkBeansToISPanel(columnInfo_focus_in_nm, "FS", "FSBAP0640", true);
		linkBeansToISPanel(columnInfo_focus_out_next_focus_nm, "FS", "FSBAP0640", true);
	}

}