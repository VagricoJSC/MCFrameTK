package mcframe.clientFSBA.FSBAP0650;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBAP0650"パネルクラスです。<p>
 *
 * バーコードフォーカス設定<br>
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP0650_FW_A extends mcframe.clientFSUC.FSUCP0000.FSUCP_PanelBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0650";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Cnd]ブロック関連のField定義
	public MCPanel CndPanel = null;
	// [Cnd]ブロックの項目のField定義
	public MCLabel Cnd_module_id_Label = null;
	/**
	 *  モジュールＩＤ.<p>
	 *
	 */
	public MCTextField Cnd_module_id = null;
	public MCLabel Cnd_screen_id_Label = null;
	/**
	 *  画面ＩＤ.<p>
	 *
	 */
	public MCTextField Cnd_screen_id = null;
	/**
	 *  最新情報を取得.<p>
	 *
	 */
	public MCButton Cnd_reload = null;
	// [ListDtl]ブロック関連のField定義
	public MCPanel ListDtlPanel = null;
	public MCScrollPane ListDtlScrollPane = null;
	public MCTable2<mcframe.clientFSBA.FSBAP0650.ListDtlR> ListDtlTable = null;
	// [ListDtl]ブロックの項目のField定義
	/**
	 *  フォーカス設定ＩＤ.<p>
	 *
	 */
	public MCColumnConfig columnListDtl_focus_id = null;
	/**
	 *  フォーカス設定名.<p>
	 *
	 */
	public MCColumnConfig columnListDtl_focus_nm = null;
	/**
	 *  バージョン.<p>
	 *
	 */
	public MCColumnConfig columnListDtl_version = null;
	// [ListBtn]ブロック関連のField定義
	public MCPanel ListBtnPanel = null;
	// [ListBtn]ブロックの項目のField定義
	/**
	 *  行追加.<p>
	 *
	 */
	public MCButton ListBtn_radd = null;
	// [ListEastBtn]ブロック関連のField定義
	public MCPanel ListEastBtnPanel = null;
	// [ListEastBtn]ブロックの項目のField定義
	/**
	 *  削除する.<p>
	 *
	 */
	public MCButton ListEastBtn_del = null;
	// [Info]ブロック関連のField定義
	public MCPanel InfoPanel = null;
	public MCScrollPane InfoScrollPane = null;
	public MCTable2<mcframe.clientFSBA.FSBAP0650.InfoR> InfoTable = null;
	// [Info]ブロックの項目のField定義
	/**
	 *  画面部品ＩＤ.<p>
	 *
	 */
	public MCColumnConfig columnInfo_comp_id = null;
	/**
	 *  画面部品名.<p>
	 *
	 */
	public MCColumnConfig columnInfo_comp_nm = null;
	/**
	 *  画面部品タイプ.<p>
	 *
	 */
	public MCColumnConfig columnInfo_comp_typ = null;
	/**
	 *  親パネルＩＤ.<p>
	 *
	 */
	public MCColumnConfig columnInfo_panel_id = null;
	/**
	 *  親パネル名.<p>
	 *
	 */
	public MCColumnConfig columnInfo_panel_nm = null;
	/**
	 *  ルートパネルＩＤ.<p>
	 *
	 */
	public MCColumnConfig columnInfo_root_panel_id = null;
	/**
	 *  フォーカスインで移動する画面部品ＩＤ.<p>
	 *
	 */
	public MCColumnConfig columnInfo_focus_in = null;
	/**
	 *  フォーカスインで移動する画面部品.<p>
	 *
	 */
	public MCColumnConfig columnInfo_focus_in_nm = null;
	/**
	 *  フォーカスアウトで実行するボタンＩＤ.<p>
	 *
	 */
	public MCColumnConfig columnInfo_focus_out = null;
	/**
	 *  フォーカスアウトで実行するボタン.<p>
	 *
	 */
	public MCColumnConfig columnInfo_focus_out_nm = null;
	/**
	 *  フォーカスアウト後の次のフォーカスＩＤ.<p>
	 *
	 */
	public MCColumnConfig columnInfo_focus_out_next_focus = null;
	/**
	 *  フォーカスアウト後の次のフォーカス.<p>
	 *
	 */
	public MCColumnConfig columnInfo_focus_out_next_focus_nm = null;
	/**
	 *  ボタン実行後の次のフォーカスＩＤ.<p>
	 *
	 */
	public MCColumnConfig columnInfo_button_next_focus = null;
	/**
	 *  ボタン実行後の次のフォーカス.<p>
	 *
	 */
	public MCColumnConfig columnInfo_button_next_focus_nm = null;
	/**
	 *  ダイアログ後に移動するフォーカス.<p>
	 *
	 */
	public MCColumnConfig columnInfo_error_focus_flg = null;
	/**
	 *  初期フォーカス.<p>
	 *
	 */
	public MCColumnConfig columnInfo_start_focus_flg = null;
	/**
	 *  バーコード入力.<p>
	 *
	 */
	public MCColumnConfig columnInfo_barcode_flg = null;
	// [InfoTabOrder]ブロック関連のField定義
	public MCPanel InfoTabOrderPanel = null;
	// [InfoTabOrder]ブロックの項目のField定義
	// [ListHdr]ブロック関連のField定義
	public MCPanel ListHdrPanel = null;
	// [ListHdr]ブロックの項目のField定義
	public MCLabel ListHdr_focus_id_Label = null;
	/**
	 *  フォーカス設定ＩＤ.<p>
	 *
	 */
	public MCTextField ListHdr_focus_id = null;
	public MCLabel ListHdr_focus_nm_Label = null;
	/**
	 *  フォーカス設定名.<p>
	 *
	 */
	public MCTextField ListHdr_focus_nm = null;
	public MCLabel ListHdr_version_Label = null;
	/**
	 *  バージョン.<p>
	 *
	 */
	public MCTextField ListHdr_version = null;
	/**
	 *  更新する.<p>
	 *
	 */
	public MCButton ListHdr_upd = null;
	/** [UPD]モードを表す定数 */
	public static final String UPD = "UPD";
	/** [FIX]モードを表す定数 */
	public static final String FIX = "FIX";
	/** [AUTO]モードを表す定数 */
	public static final String AUTO = "AUTO";
	/** [MAN]モードを表す定数 */
	public static final String MAN = "MAN";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{UPD, FIX, AUTO, MAN};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	
	/** [Cnd]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0650.CndR aCndR;
	/** [ListDtl]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0650.ListDtlR> aListDtlL;
	/** [Info]ブロックのコンテナField定義 */
	private final MCList<mcframe.clientFSBA.FSBAP0650.InfoR> aInfoL;
	/** [InfoTabOrder]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0650.InfoTabOrderR aInfoTabOrderR;
	/** [ListHdr]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0650.ListDtlR aListHdrR;

	/**
	 * 項目コピーによってaCndRを設定します。
	 *
	 * aCndRのインスタンスは変更されません。
	 *
	 * @param row CndR
	 */
	public void setCndR(mcframe.clientFSBA.FSBAP0650.CndR row) {
		if (row != null) {
			MCRow.copyall(getCndR(), row);
		}
	}

	/**
	 * [Cnd]ブロックのコンテナaCndRを返します。
	 *
	 * @return CndR
	 */
	public mcframe.clientFSBA.FSBAP0650.CndR getCndR() {
		return aCndR;
	}

	/**
	 * aCndRを作成します。
	 *
	 * @return CndR
	 */
	public mcframe.clientFSBA.FSBAP0650.CndR createCndR() {
		return mcframe.clientFSBA.FSBAP0650.CndR.create();
	}

	/**
	 * コピーによってaListDtlLを設定します。
	 *
	 * aListDtlLのインスタンスは変更されません。
	 *
	 * @param dataset ListDtlL
	 */
	public void setListDtlL(MCList<mcframe.clientFSBA.FSBAP0650.ListDtlR> aList) {
		if (getListDtlL() != aList) {
			getListDtlL().setAll(aList);
		}
	}

	/**
	 * [ListDtl]ブロックのコンテナaListDtlLを返します。
	 *
	 * @return ListDtlL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0650.ListDtlR> getListDtlL() {
		return aListDtlL;
	}

	/**
	 * aListDtlRを作成します。
	 *
	 * @return ListDtlR
	 */
	public mcframe.clientFSBA.FSBAP0650.ListDtlR createListDtlR() {
		return mcframe.clientFSBA.FSBAP0650.ListDtlR.create();
	}

	/**
	 * aListDtlLを作成します。
	 *
	 * @return ListDtlL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0650.ListDtlR> createListDtlL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0650.ListDtlR.class);
	}

	/**
	 * ListDtlTableを初期化します。
	 */
	protected void createListDtlTable(){
		if(ListDtlTable == null){
			ListDtlTable = beansFactory.createTable2("ListDtl.table");
		}
	}

	/**
	 * コピーによってaInfoLを設定します。
	 *
	 * aInfoLのインスタンスは変更されません。
	 *
	 * @param dataset InfoL
	 */
	public void setInfoL(MCList<mcframe.clientFSBA.FSBAP0650.InfoR> aList) {
		if (getInfoL() != aList) {
			getInfoL().setAll(aList);
		}
	}

	/**
	 * [Info]ブロックのコンテナaInfoLを返します。
	 *
	 * @return InfoL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0650.InfoR> getInfoL() {
		return aInfoL;
	}

	/**
	 * aInfoRを作成します。
	 *
	 * @return InfoR
	 */
	public mcframe.clientFSBA.FSBAP0650.InfoR createInfoR() {
		return mcframe.clientFSBA.FSBAP0650.InfoR.create();
	}

	/**
	 * aInfoLを作成します。
	 *
	 * @return InfoL
	 */
	public MCList<mcframe.clientFSBA.FSBAP0650.InfoR> createInfoL() {
		return MCList.create(mcframe.clientFSBA.FSBAP0650.InfoR.class);
	}

	/**
	 * InfoTableを初期化します。
	 */
	protected void createInfoTable(){
		if(InfoTable == null){
			InfoTable = beansFactory.createTable2("Info.table");
		}
	}

	/**
	 * 項目コピーによってaInfoTabOrderRを設定します。
	 *
	 * aInfoTabOrderRのインスタンスは変更されません。
	 *
	 * @param row InfoTabOrderR
	 */
	public void setInfoTabOrderR(mcframe.clientFSBA.FSBAP0650.InfoTabOrderR row) {
		if (row != null) {
			MCRow.copyall(getInfoTabOrderR(), row);
		}
	}

	/**
	 * [InfoTabOrder]ブロックのコンテナaInfoTabOrderRを返します。
	 *
	 * @return InfoTabOrderR
	 */
	public mcframe.clientFSBA.FSBAP0650.InfoTabOrderR getInfoTabOrderR() {
		return aInfoTabOrderR;
	}

	/**
	 * aInfoTabOrderRを作成します。
	 *
	 * @return InfoTabOrderR
	 */
	public mcframe.clientFSBA.FSBAP0650.InfoTabOrderR createInfoTabOrderR() {
		return mcframe.clientFSBA.FSBAP0650.InfoTabOrderR.create();
	}

	/**
	 * 項目コピーによってaListHdrRを設定します。
	 *
	 * aListHdrRのインスタンスは変更されません。
	 *
	 * @param row ListHdrR
	 */
	public void setListHdrR(mcframe.clientFSBA.FSBAP0650.ListDtlR row) {
		if (row != null) {
			MCRow.copyall(getListHdrR(), row);
		}
	}

	/**
	 * [ListHdr]ブロックのコンテナaListHdrRを返します。
	 *
	 * @return ListHdrR
	 */
	public mcframe.clientFSBA.FSBAP0650.ListDtlR getListHdrR() {
		return aListHdrR;
	}

	/**
	 * aListHdrRを作成します。
	 *
	 * @return ListHdrR
	 */
	public mcframe.clientFSBA.FSBAP0650.ListDtlR createListHdrR() {
		return mcframe.clientFSBA.FSBAP0650.ListDtlR.create();
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getCndR())) ret.add(getCndR());
		if(!MCCollectionUtil.contains(ret, getListDtlL())) ret.add(getListDtlL());
		if(!MCCollectionUtil.contains(ret, getInfoL())) ret.add(getInfoL());
		if(!MCCollectionUtil.contains(ret, getInfoTabOrderR())) ret.add(getInfoTabOrderR());
		if(!MCCollectionUtil.contains(ret, getListHdrR())) ret.add(getListHdrR());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getCndR()) return "Cnd";
		if(aCnt == getListDtlL()) return "ListDtl";
		if(aCnt == getInfoL()) return "Info";
		if(aCnt == getInfoTabOrderR()) return "InfoTabOrder";
		if(aCnt == getListHdrR()) return "ListHdr";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("Cnd")) return getCndR();
		if(bId.equals("ListDtl")) return getListDtlL();
		if(bId.equals("Info")) return getInfoL();
		if(bId.equals("InfoTabOrder")) return getInfoTabOrderR();
		if(bId.equals("ListHdr")) return getListHdrR();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(CndPanel);
		ret.add(ListDtlPanel);
		ret.add(ListBtnPanel);
		ret.add(ListEastBtnPanel);
		ret.add(InfoPanel);
		ret.add(InfoTabOrderPanel);
		ret.add(ListHdrPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0650_FW_A() {
		aCndR = createCndR();
		aListDtlL = createListDtlL();
		aInfoL = createInfoL();
		aInfoTabOrderR = createInfoTabOrderR();
		aListHdrR = createListHdrR();

	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP0650_FW_A(String name) {
		aCndR = createCndR();
		aListDtlL = createListDtlL();
		createListDtlTable();
		ListDtlTable.setRowName(name);
		aInfoL = createInfoL();
		createInfoTable();
		InfoTable.setRowName(name);
		aInfoTabOrderR = createInfoTabOrderR();
		aListHdrR = createListHdrR();
	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP0650_FW.jbCreateCnd((FSBAP0650)this);
		FSBAP0650_FW.jbCreateListDtl((FSBAP0650)this);
		FSBAP0650_FW.jbCreateListBtn((FSBAP0650)this);
		FSBAP0650_FW.jbCreateListEastBtn((FSBAP0650)this);
		FSBAP0650_FW.jbCreateInfo((FSBAP0650)this);
		FSBAP0650_FW.jbCreateInfoTabOrder((FSBAP0650)this);
		FSBAP0650_FW.jbCreateListHdr((FSBAP0650)this);
	}

	/**
	 * [Cnd]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateCnd(FSBAP0650 p) {
	}

	/**
	 * [ListDtl]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateListDtl(FSBAP0650 p) {
	}

	/**
	 * [ListBtn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateListBtn(FSBAP0650 p) {
	}

	/**
	 * [ListEastBtn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateListEastBtn(FSBAP0650 p) {
	}

	/**
	 * [Info]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateInfo(FSBAP0650 p) {
	}

	/**
	 * [InfoTabOrder]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateInfoTabOrder(FSBAP0650 p) {
	}

	/**
	 * [ListHdr]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateListHdr(FSBAP0650 p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}

	
	/** [Info_focus_in_nm_ListPutter]の定義 */
	private MCListPutter Info_focus_in_nm_p = null;

	/**
	 * [Info_focus_in_nm_ListPutter]の取得
	 */
	protected MCListPutter getInfo_focus_in_nm_ListPutter() {
		if (Info_focus_in_nm_p == null) {
			Info_focus_in_nm_p = createInfo_focus_in_nm_ListPutter(columnInfo_focus_in_nm, "focus_in_nm", "focus_in");

		}
		return Info_focus_in_nm_p;
	}
	
	
	/** [Info_focus_out_nm_ListPutter]の定義 */
	private MCListPutter Info_focus_out_nm_p = null;

	/**
	 * [Info_focus_out_nm_ListPutter]の取得
	 */
	protected MCListPutter getInfo_focus_out_nm_ListPutter() {
		if (Info_focus_out_nm_p == null) {
			Info_focus_out_nm_p = createInfo_focus_out_nm_ListPutter(columnInfo_focus_out_nm, "focus_out_nm");

		}
		return Info_focus_out_nm_p;
	}
	
	
	/** [Info_focus_out_next_focus_nm_ListPutter]の定義 */
	private MCListPutter Info_focus_out_next_focus_nm_p = null;

	/**
	 * [Info_focus_out_next_focus_nm_ListPutter]の取得
	 */
	protected MCListPutter getInfo_focus_out_next_focus_nm_ListPutter() {
		if (Info_focus_out_next_focus_nm_p == null) {
			Info_focus_out_next_focus_nm_p = createInfo_focus_out_next_focus_nm_ListPutter(columnInfo_focus_out_next_focus_nm, "focus_out_next_focus_nm", "focus_out_next_focus");

		}
		return Info_focus_out_next_focus_nm_p;
	}
	
	
	/** [Info_button_next_focus_nm_ListPutter]の定義 */
	private MCListPutter Info_button_next_focus_nm_p = null;

	/**
	 * [Info_button_next_focus_nm_ListPutter]の取得
	 */
	protected MCListPutter getInfo_button_next_focus_nm_ListPutter() {
		if (Info_button_next_focus_nm_p == null) {
			Info_button_next_focus_nm_p = createInfo_button_next_focus_nm_ListPutter(columnInfo_button_next_focus_nm, "button_next_focus_nm", "button_next_focus");

		}
		return Info_button_next_focus_nm_p;
	}
	

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP0650 create(){
		FSBAP0650 p = new FSBAP0650();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP0650 create(String name){
		FSBAP0650 p = new FSBAP0650(name);
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}

	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP0650_FW.jbfInitCnd((FSBAP0650)this);
		FSBAP0650_FW.jbfInitListDtl((FSBAP0650)this);
		FSBAP0650_FW.jbfInitListBtn((FSBAP0650)this);
		FSBAP0650_FW.jbfInitListEastBtn((FSBAP0650)this);
		FSBAP0650_FW.jbfInitInfo((FSBAP0650)this);
		FSBAP0650_FW.jbfInitInfoTabOrder((FSBAP0650)this);
		FSBAP0650_FW.jbfInitListHdr((FSBAP0650)this);
		FSBAP0650_FW.jbInitCnd((FSBAP0650)this);
		FSBAP0650_FW.jbInitListDtl((FSBAP0650)this);
		FSBAP0650_FW.jbInitListBtn((FSBAP0650)this);
		FSBAP0650_FW.jbInitListEastBtn((FSBAP0650)this);
		FSBAP0650_FW.jbInitInfo((FSBAP0650)this);
		FSBAP0650_FW.jbInitInfoTabOrder((FSBAP0650)this);
		FSBAP0650_FW.jbInitListHdr((FSBAP0650)this);
	}

	/**
	 * [Cnd]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitCnd(FSBAP0650 p) {
		// ブロック関連の初期化
		p.CndPanel = p.beansFactory.createPanel("Cnd");
		// ブロックの項目の初期化
		p.Cnd_module_id_Label = p.beansFactory.createLabel("Cnd.module_id_Label");
		p.Cnd_module_id = p.beansFactory.createTextField("Cnd.module_id");
		p.Cnd_module_id.setLabel(p.Cnd_module_id_Label);
		p.Cnd_screen_id_Label = p.beansFactory.createLabel("Cnd.screen_id_Label");
		p.Cnd_screen_id = p.beansFactory.createTextField("Cnd.screen_id");
		p.Cnd_screen_id.setLabel(p.Cnd_screen_id_Label);
		p.Cnd_reload = p.beansFactory.createButton("Cnd.reload", "no_border");
	}

	/**
	 * [ListDtl]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitListDtl(FSBAP0650 p) {
		// ブロック関連の初期化
		p.ListDtlPanel = p.beansFactory.createPanel("ListDtl");
		p.ListDtlScrollPane = p.beansFactory.createScrollPane("ListDtl.scroll");
		p.createListDtlTable();
		// ブロックの項目の初期化
		p.columnListDtl_focus_id = p.beansFactory.createTableColumn("ListDtl.focus_id", MCColumnType.TEXT);
		p.columnListDtl_focus_nm = p.beansFactory.createTableColumn("ListDtl.focus_nm", MCColumnType.TEXT);
		p.columnListDtl_version = p.beansFactory.createTableColumn("ListDtl.version", MCColumnType.TEXT);
	}

	/**
	 * [ListBtn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitListBtn(FSBAP0650 p) {
		// ブロック関連の初期化
		p.ListBtnPanel = p.beansFactory.createPanel("ListBtn");
		// ブロックの項目の初期化
		p.ListBtn_radd = p.beansFactory.createButton("ListBtn.radd", "no_border");
	}

	/**
	 * [ListEastBtn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitListEastBtn(FSBAP0650 p) {
		// ブロック関連の初期化
		p.ListEastBtnPanel = p.beansFactory.createPanel("ListEastBtn");
		// ブロックの項目の初期化
		p.ListEastBtn_del = p.beansFactory.createButton("ListEastBtn.del", "del");
	}

	/**
	 * [Info]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitInfo(FSBAP0650 p) {
		// ブロック関連の初期化
		p.InfoPanel = p.beansFactory.createPanel("Info");
		p.InfoScrollPane = p.beansFactory.createScrollPane("Info.scroll");
		p.createInfoTable();
		// ブロックの項目の初期化
		p.columnInfo_comp_id = p.beansFactory.createTableColumn("Info.comp_id", MCColumnType.TEXT);
		p.columnInfo_comp_nm = p.beansFactory.createTableColumn("Info.comp_nm", MCColumnType.TEXT);
		p.columnInfo_comp_typ = p.beansFactory.createTableColumn("Info.comp_typ", MCColumnType.TEXT);
		p.columnInfo_panel_id = p.beansFactory.createTableColumn("Info.panel_id", MCColumnType.TEXT);
		p.columnInfo_panel_nm = p.beansFactory.createTableColumn("Info.panel_nm", MCColumnType.TEXT);
		p.columnInfo_root_panel_id = p.beansFactory.createTableColumn("Info.root_panel_id", MCColumnType.TEXT);
		p.columnInfo_focus_in = p.beansFactory.createTableColumn("Info.focus_in", MCColumnType.TEXT);
		p.columnInfo_focus_in_nm = p.beansFactory.createTableColumn("Info.focus_in_nm", MCColumnType.TEXT_COMBO_FREE);
		p.columnInfo_focus_out = p.beansFactory.createTableColumn("Info.focus_out", MCColumnType.TEXT);
		p.columnInfo_focus_out_nm = p.beansFactory.createTableColumn("Info.focus_out_nm", MCColumnType.TEXT_COMBO_FREE);
		p.columnInfo_focus_out_next_focus = p.beansFactory.createTableColumn("Info.focus_out_next_focus", MCColumnType.TEXT);
		p.columnInfo_focus_out_next_focus_nm = p.beansFactory.createTableColumn("Info.focus_out_next_focus_nm", MCColumnType.TEXT_COMBO_FREE);
		p.columnInfo_button_next_focus = p.beansFactory.createTableColumn("Info.button_next_focus", MCColumnType.TEXT);
		p.columnInfo_button_next_focus_nm = p.beansFactory.createTableColumn("Info.button_next_focus_nm", MCColumnType.TEXT_COMBO_FREE);
		p.columnInfo_error_focus_flg = p.beansFactory.createTableColumn("Info.error_focus_flg", MCColumnType.CHECK);
		p.columnInfo_start_focus_flg = p.beansFactory.createTableColumn("Info.start_focus_flg", MCColumnType.CHECK);
		p.columnInfo_barcode_flg = p.beansFactory.createTableColumn("Info.barcode_flg", MCColumnType.CHECK);
	}

	/**
	 * [InfoTabOrder]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitInfoTabOrder(FSBAP0650 p) {
		// ブロック関連の初期化
		p.InfoTabOrderPanel = p.beansFactory.createPanel("InfoTabOrder");
		// ブロックの項目の初期化
	}

	/**
	 * [ListHdr]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitListHdr(FSBAP0650 p) {
		// ブロック関連の初期化
		p.ListHdrPanel = p.beansFactory.createPanel("ListHdr");
		// ブロックの項目の初期化
		p.ListHdr_focus_id_Label = p.beansFactory.createLabel("ListHdr.focus_id_Label");
		p.ListHdr_focus_id = p.beansFactory.createTextField("ListHdr.focus_id");
		p.ListHdr_focus_id.setLabel(p.ListHdr_focus_id_Label);
		p.ListHdr_focus_nm_Label = p.beansFactory.createLabel("ListHdr.focus_nm_Label");
		p.ListHdr_focus_nm = p.beansFactory.createTextField("ListHdr.focus_nm");
		p.ListHdr_focus_nm.setLabel(p.ListHdr_focus_nm_Label);
		p.ListHdr_version_Label = p.beansFactory.createLabel("ListHdr.version_Label");
		p.ListHdr_version = p.beansFactory.createTextField("ListHdr.version");
		p.ListHdr_version.setLabel(p.ListHdr_version_Label);
		p.ListHdr_upd = p.beansFactory.createButton("ListHdr.upd", "upd");
	}

	/**
	 * [Cnd]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitCnd(FSBAP0650 p) {
		// ブロック関連の初期化
		p.add(p.CndPanel);
		p.setLastBeans(p.CndPanel);
		p.CndPanel.setNextBeans(p.ListDtlPanel);
		p.CndPanel.setLayoutPosition("N");
		// ブロックの項目の初期化
		p.CndPanel.add(p.Cnd_module_id_Label);
		p.CndPanel.add(p.Cnd_module_id);
		p.CndPanel.setLastBeans(p.Cnd_module_id);
		p.Cnd_module_id.setNextBeans(p.Cnd_screen_id);
		p.Cnd_module_id.setRow(p.getCndR(), mcframe.clientFSBA.FSBAP0650.CndR.module_id_META);
		p.CndPanel.add(p.Cnd_screen_id_Label);
		p.CndPanel.add(p.Cnd_screen_id);
		p.Cnd_screen_id.setNextBeans(p.Cnd_reload);
		p.Cnd_screen_id.setRow(p.getCndR(), mcframe.clientFSBA.FSBAP0650.CndR.screen_id_META);
		p.Cnd_reload.setIcon("RELOAD");
		p.Cnd_reload.setFunctionKey(MCFunctionKey.F1);
		p.CndPanel.add(p.Cnd_reload);
	}

	/**
	 * [ListDtl]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitListDtl(FSBAP0650 p) {
		// ブロック関連の初期化
		p.add(p.ListDtlPanel);
		p.ListDtlPanel.setNextBeans(p.ListBtnPanel);
		p.ListDtlPanel.add(p.ListDtlScrollPane);
		p.ListDtlPanel.setLastBeans(p.ListDtlTable);
		p.ListDtlScrollPane.setViewportView(p.ListDtlTable);
		p.ListDtlTable.setList(p.getListDtlL());
		p.ListDtlPanel.setLayoutPosition("CTC");
		// ブロックの項目の初期化
	}

	/**
	 * [ListBtn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitListBtn(FSBAP0650 p) {
		// ブロック関連の初期化
		p.add(p.ListBtnPanel);
		p.ListBtnPanel.setNextBeans(p.ListEastBtnPanel);
		p.ListBtnPanel.setLayoutPosition("CTSW");
		// ブロックの項目の初期化
		p.ListBtn_radd.setIcon("INSERT_RECORD");
		p.ListBtn_radd.setFunctionKey(MCFunctionKey.F5);
		p.ListBtnPanel.add(p.ListBtn_radd);
		p.ListBtnPanel.setLastBeans(p.ListBtn_radd);
	}

	/**
	 * [ListEastBtn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitListEastBtn(FSBAP0650 p) {
		// ブロック関連の初期化
		p.add(p.ListEastBtnPanel);
		p.ListEastBtnPanel.setNextBeans(p.InfoPanel);
		p.ListEastBtnPanel.setLayoutPosition("CTSE");
		// ブロックの項目の初期化
		p.ListEastBtn_del.setIcon("DELETE");
		p.ListEastBtn_del.setFunctionKey(MCFunctionKey.F12);
		p.ListEastBtnPanel.add(p.ListEastBtn_del);
		p.ListEastBtnPanel.setLastBeans(p.ListEastBtn_del);
	}

	/**
	 * [Info]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitInfo(FSBAP0650 p) {
		// ブロック関連の初期化
		p.add(p.InfoPanel);
		p.InfoPanel.setNextBeans(p.InfoTabOrderPanel);
		p.InfoPanel.add(p.InfoScrollPane);
		p.InfoPanel.setLastBeans(p.InfoTable);
		p.InfoScrollPane.setViewportView(p.InfoTable);
		p.InfoTable.setList(p.getInfoL());
		p.InfoPanel.setLayoutPosition("CB");
		// ブロックの項目の初期化
	}

	/**
	 * [InfoTabOrder]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitInfoTabOrder(FSBAP0650 p) {
		// ブロック関連の初期化
		p.add(p.InfoTabOrderPanel);
		p.InfoTabOrderPanel.setNextBeans(p.ListHdrPanel);
		// ブロックの項目の初期化
	}

	/**
	 * [ListHdr]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitListHdr(FSBAP0650 p) {
		// ブロック関連の初期化
		p.add(p.ListHdrPanel);
		p.ListHdrPanel.setLayoutPosition("S");
		// ブロックの項目の初期化
		p.ListHdrPanel.add(p.ListHdr_focus_id_Label);
		p.ListHdrPanel.add(p.ListHdr_focus_id);
		p.ListHdrPanel.setLastBeans(p.ListHdr_focus_id);
		p.ListHdr_focus_id.setNextBeans(p.ListHdr_focus_nm);
		p.ListHdr_focus_id.setRow(p.getListHdrR(), mcframe.clientFSBA.FSBAP0650.ListDtlR.focus_id_META);
		p.ListHdrPanel.add(p.ListHdr_focus_nm_Label);
		p.ListHdrPanel.add(p.ListHdr_focus_nm);
		p.ListHdr_focus_nm.setNextBeans(p.ListHdr_version);
		p.ListHdr_focus_nm.setRow(p.getListHdrR(), mcframe.clientFSBA.FSBAP0650.ListDtlR.focus_nm_META);
		p.ListHdrPanel.add(p.ListHdr_version_Label);
		p.ListHdrPanel.add(p.ListHdr_version);
		p.ListHdr_version.setNextBeans(p.ListHdr_upd);
		p.ListHdr_version.setRow(p.getListHdrR(), mcframe.clientFSBA.FSBAP0650.ListDtlR.version_META);
		p.ListHdr_upd.setIcon("REGISTER");
		p.ListHdr_upd.setFunctionKey(MCFunctionKey.F9);
		p.ListHdrPanel.add(p.ListHdr_upd);
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "G";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP0650_FW.mcInitCnd((FSBAP0650)this);
		FSBAP0650_FW.mcInitListDtl((FSBAP0650)this);
		FSBAP0650_FW.mcInitListBtn((FSBAP0650)this);
		FSBAP0650_FW.mcInitListEastBtn((FSBAP0650)this);
		FSBAP0650_FW.mcInitInfo((FSBAP0650)this);
		FSBAP0650_FW.mcInitInfoTabOrder((FSBAP0650)this);
		FSBAP0650_FW.mcInitListHdr((FSBAP0650)this);

		// [UPD]ステータスのモードの設定
		FSBAP0650_FW.statusInitUPD_Cnd((FSBAP0650)this);
		FSBAP0650_FW.statusInitUPD_ListDtl((FSBAP0650)this);
		FSBAP0650_FW.statusInitUPD_ListBtn((FSBAP0650)this);
		FSBAP0650_FW.statusInitUPD_ListEastBtn((FSBAP0650)this);
		FSBAP0650_FW.statusInitUPD_Info((FSBAP0650)this);
		FSBAP0650_FW.statusInitUPD_InfoTabOrder((FSBAP0650)this);
		FSBAP0650_FW.statusInitUPD_ListHdr((FSBAP0650)this);

		// [FIX]ステータスのモードの設定
		FSBAP0650_FW.statusInitFIX_Cnd((FSBAP0650)this);
		FSBAP0650_FW.statusInitFIX_ListDtl((FSBAP0650)this);
		FSBAP0650_FW.statusInitFIX_ListBtn((FSBAP0650)this);
		FSBAP0650_FW.statusInitFIX_ListEastBtn((FSBAP0650)this);
		FSBAP0650_FW.statusInitFIX_Info((FSBAP0650)this);
		FSBAP0650_FW.statusInitFIX_InfoTabOrder((FSBAP0650)this);
		FSBAP0650_FW.statusInitFIX_ListHdr((FSBAP0650)this);

		// [AUTO]ステータスのモードの設定
		FSBAP0650_FW.statusInitAUTO_Cnd((FSBAP0650)this);
		FSBAP0650_FW.statusInitAUTO_ListDtl((FSBAP0650)this);
		FSBAP0650_FW.statusInitAUTO_ListBtn((FSBAP0650)this);
		FSBAP0650_FW.statusInitAUTO_ListEastBtn((FSBAP0650)this);
		FSBAP0650_FW.statusInitAUTO_Info((FSBAP0650)this);
		FSBAP0650_FW.statusInitAUTO_InfoTabOrder((FSBAP0650)this);
		FSBAP0650_FW.statusInitAUTO_ListHdr((FSBAP0650)this);

		// [MAN]ステータスのモードの設定
		FSBAP0650_FW.statusInitMAN_Cnd((FSBAP0650)this);
		FSBAP0650_FW.statusInitMAN_ListDtl((FSBAP0650)this);
		FSBAP0650_FW.statusInitMAN_ListBtn((FSBAP0650)this);
		FSBAP0650_FW.statusInitMAN_ListEastBtn((FSBAP0650)this);
		FSBAP0650_FW.statusInitMAN_Info((FSBAP0650)this);
		FSBAP0650_FW.statusInitMAN_InfoTabOrder((FSBAP0650)this);
		FSBAP0650_FW.statusInitMAN_ListHdr((FSBAP0650)this);

	}

	/**
	 *  [Cnd]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitCnd(FSBAP0650 p) {
		p.Cnd_module_id.setListListener(p);
		p.Cnd_module_id.addAllListener(p);
		p.Cnd_screen_id.setListListener(p);
		p.Cnd_screen_id.addAllListener(p);
		p.Cnd_reload.addAllListener(p);
		p.Cnd_reload.setAPMethodName("doCnd_reload");
	}

	/**
	 *  [ListDtl]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitListDtl(FSBAP0650 p) {
		p.ListDtlTable.addAllListener(p);
		p.columnListDtl_focus_id.addAllListener(p);
		p.columnListDtl_focus_id.setListListener(p);
		p.columnListDtl_focus_nm.addAllListener(p);
		p.columnListDtl_focus_nm.setListListener(p);
		p.columnListDtl_version.addAllListener(p);
		p.columnListDtl_version.setListListener(p);
	}

	/**
	 *  [ListBtn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitListBtn(FSBAP0650 p) {
		p.ListBtn_radd.addAllListener(p);
		p.ListBtn_radd.setAPMethodName("doListBtn_radd");
	}

	/**
	 *  [ListEastBtn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitListEastBtn(FSBAP0650 p) {
		p.ListEastBtn_del.addAllListener(p);
		p.ListEastBtn_del.setAPMethodName("doListEastBtn_del");
	}

	/**
	 *  [Info]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitInfo(FSBAP0650 p) {
		p.InfoTable.addAllListener(p);
		p.columnInfo_comp_id.addAllListener(p);
		p.columnInfo_comp_id.setListListener(p);
		p.columnInfo_comp_nm.addAllListener(p);
		p.columnInfo_comp_nm.setListListener(p);
		p.columnInfo_comp_typ.addAllListener(p);
		p.columnInfo_comp_typ.setListListener(p);
		p.columnInfo_panel_id.addAllListener(p);
		p.columnInfo_panel_id.setListListener(p);
		p.columnInfo_panel_nm.addAllListener(p);
		p.columnInfo_panel_nm.setListListener(p);
		p.columnInfo_root_panel_id.addAllListener(p);
		p.columnInfo_root_panel_id.setListListener(p);
		p.columnInfo_focus_in.addAllListener(p);
		p.columnInfo_focus_in.setListListener(p);
		p.columnInfo_focus_in_nm.addAllListener(p);
		p.columnInfo_focus_in_nm.setListListener(p);
		p.columnInfo_focus_out.addAllListener(p);
		p.columnInfo_focus_out.setListListener(p);
		p.columnInfo_focus_out_nm.addAllListener(p);
		p.columnInfo_focus_out_nm.setListListener(p);
		p.columnInfo_focus_out_next_focus.addAllListener(p);
		p.columnInfo_focus_out_next_focus.setListListener(p);
		p.columnInfo_focus_out_next_focus_nm.addAllListener(p);
		p.columnInfo_focus_out_next_focus_nm.setListListener(p);
		p.columnInfo_button_next_focus.addAllListener(p);
		p.columnInfo_button_next_focus.setListListener(p);
		p.columnInfo_button_next_focus_nm.addAllListener(p);
		p.columnInfo_button_next_focus_nm.setListListener(p);
		p.columnInfo_error_focus_flg.addAllListener(p);
		p.columnInfo_start_focus_flg.addAllListener(p);
		p.columnInfo_barcode_flg.addAllListener(p);
	}

	/**
	 *  [InfoTabOrder]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitInfoTabOrder(FSBAP0650 p) {
	}

	/**
	 *  [ListHdr]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitListHdr(FSBAP0650 p) {
		p.ListHdr_focus_id.setListListener(p);
		p.ListHdr_focus_id.addAllListener(p);
		p.ListHdr_focus_nm.setListListener(p);
		p.ListHdr_focus_nm.addAllListener(p);
		p.ListHdr_version.setListListener(p);
		p.ListHdr_version.addAllListener(p);
		p.ListHdr_upd.addAllListener(p);
		p.ListHdr_upd.setAPMethodName("doListHdr_upd");
	}

	/**
	 * [UPD]ステータスの[Cnd]ブロックのモードの設定
	 */
	protected static void statusInitUPD_Cnd(FSBAP0650 p){
		p.Cnd_module_id.putMode(p, UPD, MCMode.READ_ONLY);
		p.Cnd_screen_id.putMode(p, UPD, MCMode.READ_ONLY);
		p.Cnd_reload.putMode(p, UPD, MCMode.ENABLE);

	}

	/**
	 * [UPD]ステータスの[ListDtl]ブロックのモードの設定
	 */
	protected static void statusInitUPD_ListDtl(FSBAP0650 p){
		p.columnListDtl_focus_id.putMode(p, UPD, MCMode.INVISIBLE);
		p.columnListDtl_focus_nm.putMode(p, UPD, MCMode.READ_ONLY);
		p.columnListDtl_version.putMode(p, UPD, MCMode.INVISIBLE);

	}

	/**
	 * [UPD]ステータスの[ListBtn]ブロックのモードの設定
	 */
	protected static void statusInitUPD_ListBtn(FSBAP0650 p){
		p.ListBtn_radd.putMode(p, UPD, MCMode.ENABLE);

	}

	/**
	 * [UPD]ステータスの[ListEastBtn]ブロックのモードの設定
	 */
	protected static void statusInitUPD_ListEastBtn(FSBAP0650 p){
		p.ListEastBtn_del.putMode(p, UPD, MCMode.ENABLE);

	}

	/**
	 * [UPD]ステータスの[Info]ブロックのモードの設定
	 */
	protected static void statusInitUPD_Info(FSBAP0650 p){
		p.columnInfo_comp_id.putMode(p, UPD, MCMode.READ_ONLY);
		p.columnInfo_comp_nm.putMode(p, UPD, MCMode.READ_ONLY);
		p.columnInfo_comp_typ.putMode(p, UPD, MCMode.READ_ONLY);
		p.columnInfo_panel_id.putMode(p, UPD, MCMode.READ_ONLY);
		p.columnInfo_panel_nm.putMode(p, UPD, MCMode.READ_ONLY);
		p.columnInfo_root_panel_id.putMode(p, UPD, MCMode.READ_ONLY);
		p.columnInfo_focus_in.putMode(p, UPD, MCMode.INVISIBLE);
		p.columnInfo_focus_in_nm.putMode(p, UPD, MCMode.INVISIBLE);
		p.columnInfo_focus_out.putMode(p, UPD, MCMode.INVISIBLE);
		p.columnInfo_focus_out_nm.putMode(p, UPD, MCMode.ENABLE);
		p.columnInfo_focus_out_next_focus.putMode(p, UPD, MCMode.INVISIBLE);
		p.columnInfo_focus_out_next_focus_nm.putMode(p, UPD, MCMode.INVISIBLE);
		p.columnInfo_button_next_focus.putMode(p, UPD, MCMode.INVISIBLE);
		p.columnInfo_button_next_focus_nm.putMode(p, UPD, MCMode.ENABLE);
		p.columnInfo_error_focus_flg.putMode(p, UPD, MCMode.INVISIBLE);
		p.columnInfo_start_focus_flg.putMode(p, UPD, MCMode.ENABLE);
		p.columnInfo_barcode_flg.putMode(p, UPD, MCMode.ENABLE);

	}

	/**
	 * [UPD]ステータスの[InfoTabOrder]ブロックのモードの設定
	 */
	protected static void statusInitUPD_InfoTabOrder(FSBAP0650 p){

	}

	/**
	 * [UPD]ステータスの[ListHdr]ブロックのモードの設定
	 */
	protected static void statusInitUPD_ListHdr(FSBAP0650 p){
		p.ListHdr_focus_id.putMode(p, UPD, MCMode.INVISIBLE);
		p.ListHdr_focus_nm.putMode(p, UPD, MCMode.REQUIRED);
		p.ListHdr_version.putMode(p, UPD, MCMode.INVISIBLE);
		p.ListHdr_upd.putMode(p, UPD, MCMode.ENABLE);

	}

	/**
	 * [FIX]ステータスの[Cnd]ブロックのモードの設定
	 */
	protected static void statusInitFIX_Cnd(FSBAP0650 p){
		p.Cnd_module_id.putMode(p, FIX, MCMode.READ_ONLY);
		p.Cnd_screen_id.putMode(p, FIX, MCMode.READ_ONLY);
		p.Cnd_reload.putMode(p, FIX, MCMode.ENABLE);

	}

	/**
	 * [FIX]ステータスの[ListDtl]ブロックのモードの設定
	 */
	protected static void statusInitFIX_ListDtl(FSBAP0650 p){
		p.columnListDtl_focus_id.putMode(p, FIX, MCMode.INVISIBLE);
		p.columnListDtl_focus_nm.putMode(p, FIX, MCMode.READ_ONLY);
		p.columnListDtl_version.putMode(p, FIX, MCMode.INVISIBLE);

	}

	/**
	 * [FIX]ステータスの[ListBtn]ブロックのモードの設定
	 */
	protected static void statusInitFIX_ListBtn(FSBAP0650 p){
		p.ListBtn_radd.putMode(p, FIX, MCMode.ENABLE);

	}

	/**
	 * [FIX]ステータスの[ListEastBtn]ブロックのモードの設定
	 */
	protected static void statusInitFIX_ListEastBtn(FSBAP0650 p){
		p.ListEastBtn_del.putMode(p, FIX, MCMode.ENABLE);

	}

	/**
	 * [FIX]ステータスの[Info]ブロックのモードの設定
	 */
	protected static void statusInitFIX_Info(FSBAP0650 p){
		p.columnInfo_comp_id.putMode(p, FIX, MCMode.READ_ONLY);
		p.columnInfo_comp_nm.putMode(p, FIX, MCMode.READ_ONLY);
		p.columnInfo_comp_typ.putMode(p, FIX, MCMode.READ_ONLY);
		p.columnInfo_panel_id.putMode(p, FIX, MCMode.READ_ONLY);
		p.columnInfo_panel_nm.putMode(p, FIX, MCMode.READ_ONLY);
		p.columnInfo_root_panel_id.putMode(p, FIX, MCMode.READ_ONLY);
		p.columnInfo_focus_in.putMode(p, FIX, MCMode.INVISIBLE);
		p.columnInfo_focus_in_nm.putMode(p, FIX, MCMode.INVISIBLE);
		p.columnInfo_focus_out.putMode(p, FIX, MCMode.INVISIBLE);
		p.columnInfo_focus_out_nm.putMode(p, FIX, MCMode.ENABLE);
		p.columnInfo_focus_out_next_focus.putMode(p, FIX, MCMode.INVISIBLE);
		p.columnInfo_focus_out_next_focus_nm.putMode(p, FIX, MCMode.INVISIBLE);
		p.columnInfo_button_next_focus.putMode(p, FIX, MCMode.INVISIBLE);
		p.columnInfo_button_next_focus_nm.putMode(p, FIX, MCMode.ENABLE);
		p.columnInfo_error_focus_flg.putMode(p, FIX, MCMode.INVISIBLE);
		p.columnInfo_start_focus_flg.putMode(p, FIX, MCMode.ENABLE);
		p.columnInfo_barcode_flg.putMode(p, FIX, MCMode.ENABLE);

	}

	/**
	 * [FIX]ステータスの[InfoTabOrder]ブロックのモードの設定
	 */
	protected static void statusInitFIX_InfoTabOrder(FSBAP0650 p){

	}

	/**
	 * [FIX]ステータスの[ListHdr]ブロックのモードの設定
	 */
	protected static void statusInitFIX_ListHdr(FSBAP0650 p){
		p.ListHdr_focus_id.putMode(p, FIX, MCMode.INVISIBLE);
		p.ListHdr_focus_nm.putMode(p, FIX, MCMode.REQUIRED);
		p.ListHdr_version.putMode(p, FIX, MCMode.INVISIBLE);
		p.ListHdr_upd.putMode(p, FIX, MCMode.ENABLE);

	}

	/**
	 * [AUTO]ステータスの[Cnd]ブロックのモードの設定
	 */
	protected static void statusInitAUTO_Cnd(FSBAP0650 p){
		p.Cnd_module_id.putMode(p, AUTO, MCMode.READ_ONLY);
		p.Cnd_screen_id.putMode(p, AUTO, MCMode.READ_ONLY);
		p.Cnd_reload.putMode(p, AUTO, MCMode.ENABLE);

	}

	/**
	 * [AUTO]ステータスの[ListDtl]ブロックのモードの設定
	 */
	protected static void statusInitAUTO_ListDtl(FSBAP0650 p){
		p.columnListDtl_focus_id.putMode(p, AUTO, MCMode.INVISIBLE);
		p.columnListDtl_focus_nm.putMode(p, AUTO, MCMode.READ_ONLY);
		p.columnListDtl_version.putMode(p, AUTO, MCMode.INVISIBLE);

	}

	/**
	 * [AUTO]ステータスの[ListBtn]ブロックのモードの設定
	 */
	protected static void statusInitAUTO_ListBtn(FSBAP0650 p){
		p.ListBtn_radd.putMode(p, AUTO, MCMode.ENABLE);

	}

	/**
	 * [AUTO]ステータスの[ListEastBtn]ブロックのモードの設定
	 */
	protected static void statusInitAUTO_ListEastBtn(FSBAP0650 p){
		p.ListEastBtn_del.putMode(p, AUTO, MCMode.ENABLE);

	}

	/**
	 * [AUTO]ステータスの[Info]ブロックのモードの設定
	 */
	protected static void statusInitAUTO_Info(FSBAP0650 p){
		p.columnInfo_comp_id.putMode(p, AUTO, MCMode.READ_ONLY);
		p.columnInfo_comp_nm.putMode(p, AUTO, MCMode.READ_ONLY);
		p.columnInfo_comp_typ.putMode(p, AUTO, MCMode.READ_ONLY);
		p.columnInfo_panel_id.putMode(p, AUTO, MCMode.READ_ONLY);
		p.columnInfo_panel_nm.putMode(p, AUTO, MCMode.READ_ONLY);
		p.columnInfo_root_panel_id.putMode(p, AUTO, MCMode.READ_ONLY);
		p.columnInfo_focus_in.putMode(p, AUTO, MCMode.INVISIBLE);
		p.columnInfo_focus_in_nm.putMode(p, AUTO, MCMode.ENABLE);
		p.columnInfo_focus_out.putMode(p, AUTO, MCMode.INVISIBLE);
		p.columnInfo_focus_out_nm.putMode(p, AUTO, MCMode.ENABLE);
		p.columnInfo_focus_out_next_focus.putMode(p, AUTO, MCMode.INVISIBLE);
		p.columnInfo_focus_out_next_focus_nm.putMode(p, AUTO, MCMode.ENABLE);
		p.columnInfo_button_next_focus.putMode(p, AUTO, MCMode.INVISIBLE);
		p.columnInfo_button_next_focus_nm.putMode(p, AUTO, MCMode.ENABLE);
		p.columnInfo_error_focus_flg.putMode(p, AUTO, MCMode.INVISIBLE);
		p.columnInfo_start_focus_flg.putMode(p, AUTO, MCMode.INVISIBLE);
		p.columnInfo_barcode_flg.putMode(p, AUTO, MCMode.INVISIBLE);

	}

	/**
	 * [AUTO]ステータスの[InfoTabOrder]ブロックのモードの設定
	 */
	protected static void statusInitAUTO_InfoTabOrder(FSBAP0650 p){

	}

	/**
	 * [AUTO]ステータスの[ListHdr]ブロックのモードの設定
	 */
	protected static void statusInitAUTO_ListHdr(FSBAP0650 p){
		p.ListHdr_focus_id.putMode(p, AUTO, MCMode.INVISIBLE);
		p.ListHdr_focus_nm.putMode(p, AUTO, MCMode.REQUIRED);
		p.ListHdr_version.putMode(p, AUTO, MCMode.INVISIBLE);
		p.ListHdr_upd.putMode(p, AUTO, MCMode.ENABLE);

	}

	/**
	 * [MAN]ステータスの[Cnd]ブロックのモードの設定
	 */
	protected static void statusInitMAN_Cnd(FSBAP0650 p){
		p.Cnd_module_id.putMode(p, MAN, MCMode.READ_ONLY);
		p.Cnd_screen_id.putMode(p, MAN, MCMode.READ_ONLY);
		p.Cnd_reload.putMode(p, MAN, MCMode.ENABLE);

	}

	/**
	 * [MAN]ステータスの[ListDtl]ブロックのモードの設定
	 */
	protected static void statusInitMAN_ListDtl(FSBAP0650 p){
		p.columnListDtl_focus_id.putMode(p, MAN, MCMode.INVISIBLE);
		p.columnListDtl_focus_nm.putMode(p, MAN, MCMode.READ_ONLY);
		p.columnListDtl_version.putMode(p, MAN, MCMode.INVISIBLE);

	}

	/**
	 * [MAN]ステータスの[ListBtn]ブロックのモードの設定
	 */
	protected static void statusInitMAN_ListBtn(FSBAP0650 p){
		p.ListBtn_radd.putMode(p, MAN, MCMode.ENABLE);

	}

	/**
	 * [MAN]ステータスの[ListEastBtn]ブロックのモードの設定
	 */
	protected static void statusInitMAN_ListEastBtn(FSBAP0650 p){
		p.ListEastBtn_del.putMode(p, MAN, MCMode.ENABLE);

	}

	/**
	 * [MAN]ステータスの[Info]ブロックのモードの設定
	 */
	protected static void statusInitMAN_Info(FSBAP0650 p){
		p.columnInfo_comp_id.putMode(p, MAN, MCMode.READ_ONLY);
		p.columnInfo_comp_nm.putMode(p, MAN, MCMode.READ_ONLY);
		p.columnInfo_comp_typ.putMode(p, MAN, MCMode.READ_ONLY);
		p.columnInfo_panel_id.putMode(p, MAN, MCMode.READ_ONLY);
		p.columnInfo_panel_nm.putMode(p, MAN, MCMode.READ_ONLY);
		p.columnInfo_root_panel_id.putMode(p, MAN, MCMode.READ_ONLY);
		p.columnInfo_focus_in.putMode(p, MAN, MCMode.INVISIBLE);
		p.columnInfo_focus_in_nm.putMode(p, MAN, MCMode.ENABLE);
		p.columnInfo_focus_out.putMode(p, MAN, MCMode.INVISIBLE);
		p.columnInfo_focus_out_nm.putMode(p, MAN, MCMode.ENABLE);
		p.columnInfo_focus_out_next_focus.putMode(p, MAN, MCMode.INVISIBLE);
		p.columnInfo_focus_out_next_focus_nm.putMode(p, MAN, MCMode.ENABLE);
		p.columnInfo_button_next_focus.putMode(p, MAN, MCMode.INVISIBLE);
		p.columnInfo_button_next_focus_nm.putMode(p, MAN, MCMode.ENABLE);
		p.columnInfo_error_focus_flg.putMode(p, MAN, MCMode.INVISIBLE);
		p.columnInfo_start_focus_flg.putMode(p, MAN, MCMode.ENABLE);
		p.columnInfo_barcode_flg.putMode(p, MAN, MCMode.ENABLE);

	}

	/**
	 * [MAN]ステータスの[InfoTabOrder]ブロックのモードの設定
	 */
	protected static void statusInitMAN_InfoTabOrder(FSBAP0650 p){

	}

	/**
	 * [MAN]ステータスの[ListHdr]ブロックのモードの設定
	 */
	protected static void statusInitMAN_ListHdr(FSBAP0650 p){
		p.ListHdr_focus_id.putMode(p, MAN, MCMode.INVISIBLE);
		p.ListHdr_focus_nm.putMode(p, MAN, MCMode.REQUIRED);
		p.ListHdr_version.putMode(p, MAN, MCMode.INVISIBLE);
		p.ListHdr_upd.putMode(p, MAN, MCMode.ENABLE);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return MAN;
	}

	/**
	 * Table/Treeの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
		FSBAP0650_FW.setTableConfigListDtl((FSBAP0650)this);
		FSBAP0650_FW.setTableConfigInfo((FSBAP0650)this);
	}

	/**
	 * [ListDtl]ブロックのTableの設定
	 */
	protected static void setTableConfigListDtl(FSBAP0650 p) {
		p.columnListDtl_focus_id.setMeta(mcframe.clientFSBA.FSBAP0650.ListDtlR.focus_id_META);
		p.ListDtlTable.addColumnConfig(p.columnListDtl_focus_id);
		p.columnListDtl_focus_nm.setMeta(mcframe.clientFSBA.FSBAP0650.ListDtlR.focus_nm_META);
		p.ListDtlTable.addColumnConfig(p.columnListDtl_focus_nm);
		p.columnListDtl_version.setMeta(mcframe.clientFSBA.FSBAP0650.ListDtlR.version_META);
		p.ListDtlTable.addColumnConfig(p.columnListDtl_version);
	}

	/**
	 * [Info]ブロックのTableの設定
	 */
	protected static void setTableConfigInfo(FSBAP0650 p) {
		p.columnInfo_comp_id.setMeta(mcframe.clientFSBA.FSBAP0650.InfoR.comp_id_META);
		p.InfoTable.addColumnConfig(p.columnInfo_comp_id);
		p.columnInfo_comp_nm.setMeta(mcframe.clientFSBA.FSBAP0650.InfoR.comp_nm_META);
		p.InfoTable.addColumnConfig(p.columnInfo_comp_nm);
		p.columnInfo_comp_typ.setMeta(mcframe.clientFSBA.FSBAP0650.InfoR.comp_typ_META);
		p.InfoTable.addColumnConfig(p.columnInfo_comp_typ);
		p.columnInfo_panel_id.setMeta(mcframe.clientFSBA.FSBAP0650.InfoR.panel_id_META);
		p.InfoTable.addColumnConfig(p.columnInfo_panel_id);
		p.columnInfo_panel_nm.setMeta(mcframe.clientFSBA.FSBAP0650.InfoR.panel_nm_META);
		p.InfoTable.addColumnConfig(p.columnInfo_panel_nm);
		p.columnInfo_root_panel_id.setMeta(mcframe.clientFSBA.FSBAP0650.InfoR.root_panel_id_META);
		p.InfoTable.addColumnConfig(p.columnInfo_root_panel_id);
		p.columnInfo_focus_in.setMeta(mcframe.clientFSBA.FSBAP0650.InfoR.focus_in_META);
		p.InfoTable.addColumnConfig(p.columnInfo_focus_in);
		p.columnInfo_focus_in_nm.setMeta(mcframe.clientFSBA.FSBAP0650.InfoR.focus_in_nm_META);
		p.columnInfo_focus_in_nm.addLinkBeans(p.columnInfo_focus_in);
		p.InfoTable.addColumnConfig(p.columnInfo_focus_in_nm);
		p.columnInfo_focus_out.setMeta(mcframe.clientFSBA.FSBAP0650.InfoR.focus_out_META);
		p.InfoTable.addColumnConfig(p.columnInfo_focus_out);
		p.columnInfo_focus_out_nm.setMeta(mcframe.clientFSBA.FSBAP0650.InfoR.focus_out_nm_META);
		p.InfoTable.addColumnConfig(p.columnInfo_focus_out_nm);
		p.columnInfo_focus_out_next_focus.setMeta(mcframe.clientFSBA.FSBAP0650.InfoR.focus_out_next_focus_META);
		p.InfoTable.addColumnConfig(p.columnInfo_focus_out_next_focus);
		p.columnInfo_focus_out_next_focus_nm.setMeta(mcframe.clientFSBA.FSBAP0650.InfoR.focus_out_next_focus_nm_META);
		p.columnInfo_focus_out_next_focus_nm.addLinkBeans(p.columnInfo_focus_out_next_focus);
		p.InfoTable.addColumnConfig(p.columnInfo_focus_out_next_focus_nm);
		p.columnInfo_button_next_focus.setMeta(mcframe.clientFSBA.FSBAP0650.InfoR.button_next_focus_META);
		p.InfoTable.addColumnConfig(p.columnInfo_button_next_focus);
		p.columnInfo_button_next_focus_nm.setMeta(mcframe.clientFSBA.FSBAP0650.InfoR.button_next_focus_nm_META);
		p.columnInfo_button_next_focus_nm.addLinkBeans(p.columnInfo_button_next_focus);
		p.InfoTable.addColumnConfig(p.columnInfo_button_next_focus_nm);
		p.columnInfo_error_focus_flg.setMeta(mcframe.clientFSBA.FSBAP0650.InfoR.error_focus_flg_META);
		p.InfoTable.addColumnConfig(p.columnInfo_error_focus_flg);
		p.columnInfo_start_focus_flg.setMeta(mcframe.clientFSBA.FSBAP0650.InfoR.start_focus_flg_META);
		p.InfoTable.addColumnConfig(p.columnInfo_start_focus_flg);
		p.columnInfo_barcode_flg.setMeta(mcframe.clientFSBA.FSBAP0650.InfoR.barcode_flg_META);
		p.InfoTable.addColumnConfig(p.columnInfo_barcode_flg);
		// スクロール固定カラムの指定
		p.InfoTable.setUnscrollColumn(p.columnInfo_comp_nm);
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
		columnInfo_focus_in_nm.setListVisibleColumn(MCListLogic.getViewColumnName());
		columnInfo_focus_in_nm.getListConfig().setPutter(getInfo_focus_in_nm_ListPutter());
		columnInfo_focus_out_nm.setListVisibleColumn(MCListLogic.getViewColumnName());
		columnInfo_focus_out_nm.getListConfig().setPutter(getInfo_focus_out_nm_ListPutter());
		columnInfo_focus_out_next_focus_nm.setListVisibleColumn(MCListLogic.getViewColumnName());
		columnInfo_focus_out_next_focus_nm.getListConfig().setPutter(getInfo_focus_out_next_focus_nm_ListPutter());
		columnInfo_button_next_focus_nm.setListVisibleColumn(MCListLogic.getViewColumnName());
		columnInfo_button_next_focus_nm.getListConfig().setPutter(getInfo_button_next_focus_nm_ListPutter());
	}

	/**
	 * この画面を[UPD]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setUPDStatus() {
		status = UPD;
		setAllStatus(status);
	}

	/**
	 * この画面を[FIX]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setFIXStatus() {
		status = FIX;
		setAllStatus(status);
	}

	/**
	 * この画面を[AUTO]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setAUTOStatus() {
		status = AUTO;
		setAllStatus(status);
	}

	/**
	 * この画面を[MAN]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setMANStatus() {
		status = MAN;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (UPD.equals(status)) {
			setUPDStatus();
		}
		else if (FIX.equals(status)) {
			setFIXStatus();
		}
		else if (AUTO.equals(status)) {
			setAUTOStatus();
		}
		else if (MAN.equals(status)) {
			setMANStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * [Info_focus_in_nm_ListPutter]の作成
	 */
	protected MCListPutter createInfo_focus_in_nm_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("");
		return lp;
	}
	 
	/**
	 * [Info_focus_out_nm_ListPutter]の作成
	 */
	protected MCListPutter createInfo_focus_out_nm_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("");
		return lp;
	}
	 
	/**
	 * [Info_focus_out_next_focus_nm_ListPutter]の作成
	 */
	protected MCListPutter createInfo_focus_out_next_focus_nm_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("");
		return lp;
	}
	 
	/**
	 * [Info_button_next_focus_nm_ListPutter]の作成
	 */
	protected MCListPutter createInfo_button_next_focus_nm_ListPutter(MCLinkBeans compo, String... columns) {
		MCListPutter lp = new MCListPutter(compo, columns);
		lp.setListLogicId("");
		return lp;
	}
	 

	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		if(combo == columnInfo_focus_in_nm) return getInfo_focus_in_nm(row, info);
		if(combo == columnInfo_focus_out_nm) return getInfo_focus_out_nm(row, info);
		if(combo == columnInfo_focus_out_next_focus_nm) return getInfo_focus_out_next_focus_nm(row, info);
		if(combo == columnInfo_button_next_focus_nm) return getInfo_button_next_focus_nm(row, info);
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == Cnd_reload) doCnd_reload(info);
		else if (ap == ListBtn_radd) doListBtn_radd(info);
		else if (ap == ListEastBtn_del) doListEastBtn_del(info);
		else if (ap == ListHdr_upd) doListHdr_upd(info);
	}

	/**
	 * [Cnd]パネルの[reload]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doCnd_reload(MCEventInfo info);

	/**
	 * [ListBtn]パネルの[radd]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doListBtn_radd(MCEventInfo info);

	/**
	 * [ListEastBtn]パネルの[del]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doListEastBtn_del(MCEventInfo info);

	/**
	 * [ListHdr]パネルの[upd]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doListHdr_upd(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == ListDtlTable) return doListDtl_VC(info);
		if (vc == InfoTable) return doInfo_VC(info);
		if (vc == Cnd_module_id) return doCnd_module_id_VC(info);
		if (vc == Cnd_screen_id) return doCnd_screen_id_VC(info);
		if (vc == columnListDtl_focus_id) return doListDtl_focus_id_VC(info);
		if (vc == columnListDtl_focus_nm) return doListDtl_focus_nm_VC(info);
		if (vc == columnListDtl_version) return doListDtl_version_VC(info);
		if (vc == columnInfo_comp_id) return doInfo_comp_id_VC(info);
		if (vc == columnInfo_comp_nm) return doInfo_comp_nm_VC(info);
		if (vc == columnInfo_comp_typ) return doInfo_comp_typ_VC(info);
		if (vc == columnInfo_panel_id) return doInfo_panel_id_VC(info);
		if (vc == columnInfo_panel_nm) return doInfo_panel_nm_VC(info);
		if (vc == columnInfo_root_panel_id) return doInfo_root_panel_id_VC(info);
		if (vc == columnInfo_focus_in) return doInfo_focus_in_VC(info);
		if (vc == columnInfo_focus_in_nm) return doInfo_focus_in_nm_VC(info);
		if (vc == columnInfo_focus_out) return doInfo_focus_out_VC(info);
		if (vc == columnInfo_focus_out_nm) return doInfo_focus_out_nm_VC(info);
		if (vc == columnInfo_focus_out_next_focus) return doInfo_focus_out_next_focus_VC(info);
		if (vc == columnInfo_focus_out_next_focus_nm) return doInfo_focus_out_next_focus_nm_VC(info);
		if (vc == columnInfo_button_next_focus) return doInfo_button_next_focus_VC(info);
		if (vc == columnInfo_button_next_focus_nm) return doInfo_button_next_focus_nm_VC(info);
		if (vc == columnInfo_error_focus_flg) return doInfo_error_focus_flg_VC(info);
		if (vc == columnInfo_start_focus_flg) return doInfo_start_focus_flg_VC(info);
		if (vc == columnInfo_barcode_flg) return doInfo_barcode_flg_VC(info);
		if (vc == ListHdr_focus_id) return doListHdr_focus_id_VC(info);
		if (vc == ListHdr_focus_nm) return doListHdr_focus_nm_VC(info);
		if (vc == ListHdr_version) return doListHdr_version_VC(info);
		return true;
	}

	/**
	 * [ListDtl]Tableの選択行が変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doListDtl_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Info]Tableの選択行が変更される際のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfo_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Cnd]パネルの[module_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doCnd_module_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Cnd]パネルの[screen_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doCnd_screen_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ListDtl]パネルの[focus_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doListDtl_focus_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ListDtl]パネルの[focus_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doListDtl_focus_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ListDtl]パネルの[version]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doListDtl_version_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Info]パネルの[comp_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfo_comp_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Info]パネルの[comp_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfo_comp_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Info]パネルの[comp_typ]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfo_comp_typ_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Info]パネルの[panel_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfo_panel_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Info]パネルの[panel_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfo_panel_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Info]パネルの[root_panel_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfo_root_panel_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Info]パネルの[focus_in]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfo_focus_in_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Info]パネルの[focus_in_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfo_focus_in_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Info]パネルの[focus_out]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfo_focus_out_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Info]パネルの[focus_out_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfo_focus_out_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Info]パネルの[focus_out_next_focus]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfo_focus_out_next_focus_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Info]パネルの[focus_out_next_focus_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfo_focus_out_next_focus_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Info]パネルの[button_next_focus]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfo_button_next_focus_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Info]パネルの[button_next_focus_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfo_button_next_focus_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Info]パネルの[error_focus_flg]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfo_error_focus_flg_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Info]パネルの[start_focus_flg]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfo_start_focus_flg_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [Info]パネルの[barcode_flg]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfo_barcode_flg_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ListHdr]パネルの[focus_id]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doListHdr_focus_id_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ListHdr]パネルの[focus_nm]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doListHdr_focus_nm_VC(MCEventInfo info){
		return true;
	}

	/**
	 * [ListHdr]パネルの[version]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doListHdr_version_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == ListDtlTable) doListDtl_NC(info);
		else if (nc == InfoTable) doInfo_NC(info);
		else if (nc == Cnd_module_id) doCnd_module_id_NC(info);
		else if (nc == Cnd_screen_id) doCnd_screen_id_NC(info);
		else if (nc == columnListDtl_focus_id) doListDtl_focus_id_NC(info);
		else if (nc == columnListDtl_focus_nm) doListDtl_focus_nm_NC(info);
		else if (nc == columnListDtl_version) doListDtl_version_NC(info);
		else if (nc == columnInfo_comp_id) doInfo_comp_id_NC(info);
		else if (nc == columnInfo_comp_nm) doInfo_comp_nm_NC(info);
		else if (nc == columnInfo_comp_typ) doInfo_comp_typ_NC(info);
		else if (nc == columnInfo_panel_id) doInfo_panel_id_NC(info);
		else if (nc == columnInfo_panel_nm) doInfo_panel_nm_NC(info);
		else if (nc == columnInfo_root_panel_id) doInfo_root_panel_id_NC(info);
		else if (nc == columnInfo_focus_in) doInfo_focus_in_NC(info);
		else if (nc == columnInfo_focus_in_nm) doInfo_focus_in_nm_NC(info);
		else if (nc == columnInfo_focus_out) doInfo_focus_out_NC(info);
		else if (nc == columnInfo_focus_out_nm) doInfo_focus_out_nm_NC(info);
		else if (nc == columnInfo_focus_out_next_focus) doInfo_focus_out_next_focus_NC(info);
		else if (nc == columnInfo_focus_out_next_focus_nm) doInfo_focus_out_next_focus_nm_NC(info);
		else if (nc == columnInfo_button_next_focus) doInfo_button_next_focus_NC(info);
		else if (nc == columnInfo_button_next_focus_nm) doInfo_button_next_focus_nm_NC(info);
		else if (nc == columnInfo_error_focus_flg) doInfo_error_focus_flg_NC(info);
		else if (nc == columnInfo_start_focus_flg) doInfo_start_focus_flg_NC(info);
		else if (nc == columnInfo_barcode_flg) doInfo_barcode_flg_NC(info);
		else if (nc == ListHdr_focus_id) doListHdr_focus_id_NC(info);
		else if (nc == ListHdr_focus_nm) doListHdr_focus_nm_NC(info);
		else if (nc == ListHdr_version) doListHdr_version_NC(info);
	}

	/**
	 * [ListDtl]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_NC(MCEventInfo info){
	}

	/**
	 * [Info]Tableの選択行が変更された際のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_NC(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[module_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_module_id_NC(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[screen_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_screen_id_NC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[focus_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_focus_id_NC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[focus_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_focus_nm_NC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[version]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_version_NC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[comp_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_comp_id_NC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[comp_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_comp_nm_NC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[comp_typ]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_comp_typ_NC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[panel_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_panel_id_NC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[panel_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_panel_nm_NC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[root_panel_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_root_panel_id_NC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[focus_in]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_focus_in_NC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[focus_in_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_focus_in_nm_NC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[focus_out]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_focus_out_NC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[focus_out_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_focus_out_nm_NC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[focus_out_next_focus]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_focus_out_next_focus_NC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[focus_out_next_focus_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_focus_out_next_focus_nm_NC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[button_next_focus]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_button_next_focus_NC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[button_next_focus_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_button_next_focus_nm_NC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[error_focus_flg]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_error_focus_flg_NC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[start_focus_flg]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_start_focus_flg_NC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[barcode_flg]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_barcode_flg_NC(MCEventInfo info){
	}

	/**
	 * [ListHdr]パネルの[focus_id]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListHdr_focus_id_NC(MCEventInfo info){
	}

	/**
	 * [ListHdr]パネルの[focus_nm]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListHdr_focus_nm_NC(MCEventInfo info){
	}

	/**
	 * [ListHdr]パネルの[version]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListHdr_version_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == ListDtlTable) doListDtl_NE(info);
		else if (ne == InfoTable) doInfo_NE(info);
		else if (ne == Cnd_module_id) doCnd_module_id_NE(info);
		else if (ne == Cnd_screen_id) doCnd_screen_id_NE(info);
		else if (ne == columnListDtl_focus_id) doListDtl_focus_id_NE(info);
		else if (ne == columnListDtl_focus_nm) doListDtl_focus_nm_NE(info);
		else if (ne == columnListDtl_version) doListDtl_version_NE(info);
		else if (ne == columnInfo_comp_id) doInfo_comp_id_NE(info);
		else if (ne == columnInfo_comp_nm) doInfo_comp_nm_NE(info);
		else if (ne == columnInfo_comp_typ) doInfo_comp_typ_NE(info);
		else if (ne == columnInfo_panel_id) doInfo_panel_id_NE(info);
		else if (ne == columnInfo_panel_nm) doInfo_panel_nm_NE(info);
		else if (ne == columnInfo_root_panel_id) doInfo_root_panel_id_NE(info);
		else if (ne == columnInfo_focus_in) doInfo_focus_in_NE(info);
		else if (ne == columnInfo_focus_in_nm) doInfo_focus_in_nm_NE(info);
		else if (ne == columnInfo_focus_out) doInfo_focus_out_NE(info);
		else if (ne == columnInfo_focus_out_nm) doInfo_focus_out_nm_NE(info);
		else if (ne == columnInfo_focus_out_next_focus) doInfo_focus_out_next_focus_NE(info);
		else if (ne == columnInfo_focus_out_next_focus_nm) doInfo_focus_out_next_focus_nm_NE(info);
		else if (ne == columnInfo_button_next_focus) doInfo_button_next_focus_NE(info);
		else if (ne == columnInfo_button_next_focus_nm) doInfo_button_next_focus_nm_NE(info);
		else if (ne == columnInfo_error_focus_flg) doInfo_error_focus_flg_NE(info);
		else if (ne == columnInfo_start_focus_flg) doInfo_start_focus_flg_NE(info);
		else if (ne == columnInfo_barcode_flg) doInfo_barcode_flg_NE(info);
		else if (ne == ListHdr_focus_id) doListHdr_focus_id_NE(info);
		else if (ne == ListHdr_focus_nm) doListHdr_focus_nm_NE(info);
		else if (ne == ListHdr_version) doListHdr_version_NE(info);
	}

	/**
	 * [ListDtl]TableのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_NE(MCEventInfo info){
	}

	/**
	 * [Info]TableのNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_NE(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[module_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_module_id_NE(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[screen_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_screen_id_NE(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[focus_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_focus_id_NE(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[focus_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_focus_nm_NE(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[version]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_version_NE(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[comp_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_comp_id_NE(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[comp_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_comp_nm_NE(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[comp_typ]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_comp_typ_NE(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[panel_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_panel_id_NE(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[panel_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_panel_nm_NE(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[root_panel_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_root_panel_id_NE(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[focus_in]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_focus_in_NE(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[focus_in_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_focus_in_nm_NE(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[focus_out]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_focus_out_NE(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[focus_out_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_focus_out_nm_NE(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[focus_out_next_focus]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_focus_out_next_focus_NE(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[focus_out_next_focus_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_focus_out_next_focus_nm_NE(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[button_next_focus]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_button_next_focus_NE(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[button_next_focus_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_button_next_focus_nm_NE(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[error_focus_flg]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_error_focus_flg_NE(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[start_focus_flg]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_start_focus_flg_NE(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[barcode_flg]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_barcode_flg_NE(MCEventInfo info){
	}

	/**
	 * [ListHdr]パネルの[focus_id]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListHdr_focus_id_NE(MCEventInfo info){
	}

	/**
	 * [ListHdr]パネルの[focus_nm]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListHdr_focus_nm_NE(MCEventInfo info){
	}

	/**
	 * [ListHdr]パネルの[version]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListHdr_version_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == ListDtlTable) doListDtl_NX(info);
		else if (nx == InfoTable) doInfo_NX(info);
		else if (nx == Cnd_module_id) doCnd_module_id_NX(info);
		else if (nx == Cnd_screen_id) doCnd_screen_id_NX(info);
		else if (nx == columnListDtl_focus_id) doListDtl_focus_id_NX(info);
		else if (nx == columnListDtl_focus_nm) doListDtl_focus_nm_NX(info);
		else if (nx == columnListDtl_version) doListDtl_version_NX(info);
		else if (nx == columnInfo_comp_id) doInfo_comp_id_NX(info);
		else if (nx == columnInfo_comp_nm) doInfo_comp_nm_NX(info);
		else if (nx == columnInfo_comp_typ) doInfo_comp_typ_NX(info);
		else if (nx == columnInfo_panel_id) doInfo_panel_id_NX(info);
		else if (nx == columnInfo_panel_nm) doInfo_panel_nm_NX(info);
		else if (nx == columnInfo_root_panel_id) doInfo_root_panel_id_NX(info);
		else if (nx == columnInfo_focus_in) doInfo_focus_in_NX(info);
		else if (nx == columnInfo_focus_in_nm) doInfo_focus_in_nm_NX(info);
		else if (nx == columnInfo_focus_out) doInfo_focus_out_NX(info);
		else if (nx == columnInfo_focus_out_nm) doInfo_focus_out_nm_NX(info);
		else if (nx == columnInfo_focus_out_next_focus) doInfo_focus_out_next_focus_NX(info);
		else if (nx == columnInfo_focus_out_next_focus_nm) doInfo_focus_out_next_focus_nm_NX(info);
		else if (nx == columnInfo_button_next_focus) doInfo_button_next_focus_NX(info);
		else if (nx == columnInfo_button_next_focus_nm) doInfo_button_next_focus_nm_NX(info);
		else if (nx == columnInfo_error_focus_flg) doInfo_error_focus_flg_NX(info);
		else if (nx == columnInfo_start_focus_flg) doInfo_start_focus_flg_NX(info);
		else if (nx == columnInfo_barcode_flg) doInfo_barcode_flg_NX(info);
		else if (nx == ListHdr_focus_id) doListHdr_focus_id_NX(info);
		else if (nx == ListHdr_focus_nm) doListHdr_focus_nm_NX(info);
		else if (nx == ListHdr_version) doListHdr_version_NX(info);
	}

	/**
	 * [ListDtl]TableのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_NX(MCEventInfo info){
	}

	/**
	 * [Info]TableのNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_NX(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[module_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_module_id_NX(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[screen_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_screen_id_NX(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[focus_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_focus_id_NX(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[focus_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_focus_nm_NX(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[version]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_version_NX(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[comp_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_comp_id_NX(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[comp_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_comp_nm_NX(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[comp_typ]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_comp_typ_NX(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[panel_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_panel_id_NX(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[panel_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_panel_nm_NX(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[root_panel_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_root_panel_id_NX(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[focus_in]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_focus_in_NX(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[focus_in_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_focus_in_nm_NX(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[focus_out]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_focus_out_NX(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[focus_out_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_focus_out_nm_NX(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[focus_out_next_focus]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_focus_out_next_focus_NX(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[focus_out_next_focus_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_focus_out_next_focus_nm_NX(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[button_next_focus]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_button_next_focus_NX(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[button_next_focus_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_button_next_focus_nm_NX(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[error_focus_flg]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_error_focus_flg_NX(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[start_focus_flg]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_start_focus_flg_NX(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[barcode_flg]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_barcode_flg_NX(MCEventInfo info){
	}

	/**
	 * [ListHdr]パネルの[focus_id]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListHdr_focus_id_NX(MCEventInfo info){
	}

	/**
	 * [ListHdr]パネルの[focus_nm]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListHdr_focus_nm_NX(MCEventInfo info){
	}

	/**
	 * [ListHdr]パネルの[version]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListHdr_version_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
		if (lc == Cnd_module_id) doCnd_module_id_LC(info);
		else if (lc == Cnd_screen_id) doCnd_screen_id_LC(info);
		else if (lc == columnListDtl_focus_id) doListDtl_focus_id_LC(info);
		else if (lc == columnListDtl_focus_nm) doListDtl_focus_nm_LC(info);
		else if (lc == columnListDtl_version) doListDtl_version_LC(info);
		else if (lc == columnInfo_comp_id) doInfo_comp_id_LC(info);
		else if (lc == columnInfo_comp_nm) doInfo_comp_nm_LC(info);
		else if (lc == columnInfo_comp_typ) doInfo_comp_typ_LC(info);
		else if (lc == columnInfo_panel_id) doInfo_panel_id_LC(info);
		else if (lc == columnInfo_panel_nm) doInfo_panel_nm_LC(info);
		else if (lc == columnInfo_root_panel_id) doInfo_root_panel_id_LC(info);
		else if (lc == columnInfo_focus_in) doInfo_focus_in_LC(info);
		else if (lc == columnInfo_focus_in_nm) doInfo_focus_in_nm_LC(info);
		else if (lc == columnInfo_focus_out) doInfo_focus_out_LC(info);
		else if (lc == columnInfo_focus_out_nm) doInfo_focus_out_nm_LC(info);
		else if (lc == columnInfo_focus_out_next_focus) doInfo_focus_out_next_focus_LC(info);
		else if (lc == columnInfo_focus_out_next_focus_nm) doInfo_focus_out_next_focus_nm_LC(info);
		else if (lc == columnInfo_button_next_focus) doInfo_button_next_focus_LC(info);
		else if (lc == columnInfo_button_next_focus_nm) doInfo_button_next_focus_nm_LC(info);
		else if (lc == ListHdr_focus_id) doListHdr_focus_id_LC(info);
		else if (lc == ListHdr_focus_nm) doListHdr_focus_nm_LC(info);
		else if (lc == ListHdr_version) doListHdr_version_LC(info);
	}

	/**
	 * [Cnd]パネルの[module_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_module_id_LC(MCEventInfo info){
	}

	/**
	 * [Cnd]パネルの[screen_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doCnd_screen_id_LC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[focus_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_focus_id_LC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[focus_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_focus_nm_LC(MCEventInfo info){
	}

	/**
	 * [ListDtl]パネルの[version]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListDtl_version_LC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[comp_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_comp_id_LC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[comp_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_comp_nm_LC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[comp_typ]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_comp_typ_LC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[panel_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_panel_id_LC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[panel_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_panel_nm_LC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[root_panel_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_root_panel_id_LC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[focus_in]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_focus_in_LC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[focus_in_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_focus_in_nm_LC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[focus_out]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_focus_out_LC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[focus_out_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_focus_out_nm_LC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[focus_out_next_focus]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_focus_out_next_focus_LC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[focus_out_next_focus_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_focus_out_next_focus_nm_LC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[button_next_focus]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_button_next_focus_LC(MCEventInfo info){
	}

	/**
	 * [Info]パネルの[button_next_focus_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_button_next_focus_nm_LC(MCEventInfo info){
	}

	/**
	 * [ListHdr]パネルの[focus_id]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListHdr_focus_id_LC(MCEventInfo info){
	}

	/**
	 * [ListHdr]パネルの[focus_nm]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListHdr_focus_nm_LC(MCEventInfo info){
	}

	/**
	 * [ListHdr]パネルの[version]のListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doListHdr_version_LC(MCEventInfo info){
	}

	/**
	 * コンボ／リストのリスト[columnInfo_focus_in_nm]の作成メソッド
	 */
	public MCList getInfo_focus_in_nm(MCRow row, MCEventInfo info){
		return null;
	}

	/**
	 * コンボ／リストのリスト[columnInfo_focus_out_nm]の作成メソッド
	 */
	public MCList getInfo_focus_out_nm(MCRow row, MCEventInfo info){
		return null;
	}

	/**
	 * コンボ／リストのリスト[columnInfo_focus_out_next_focus_nm]の作成メソッド
	 */
	public MCList getInfo_focus_out_next_focus_nm(MCRow row, MCEventInfo info){
		return null;
	}

	/**
	 * コンボ／リストのリスト[columnInfo_button_next_focus_nm]の作成メソッド
	 */
	public MCList getInfo_button_next_focus_nm(MCRow row, MCEventInfo info){
		return null;
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}