package mcframe.clientFSBA.FSBAP0650;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"ListDtl"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class ListDtlR_FW_A extends MCConstRow {

	/**
	 *  紐付ＮＯ.<p>
	 *
	 */
	public static final String $pno = "pno";
	/**
	 *  フォーカス設定ＩＤ.<p>
	 *
	 */
	public static final String $focus_id = "focus_id";
	/**
	 *  フォーカス設定名.<p>
	 *
	 */
	public static final String $focus_nm = "focus_nm";
	/**
	 *  バージョン.<p>
	 *
	 */
	public static final String $version = "version";


	public static final MCMeta pno_META = createCommonMeta($pno, mcframe.commonCore.meta.M_META.ROW_ID);
	public static final MCMeta focus_id_META = createStringMeta($focus_id);
	public static final MCMeta focus_nm_META = createStringMeta($focus_nm);
	public static final MCMeta version_META = createStringMeta($version);

	protected static final ConstMetaList<ListDtlR> constMetas = new ConstMetaList<ListDtlR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			pno_META,
			focus_id_META,
			focus_nm_META,
			version_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected ListDtlR_FW_A(ConstMetaList<? extends ListDtlR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ListDtlR clone() {
		return (ListDtlR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ListDtlR createInstance() {
		return (ListDtlR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public ListDtlR getValues(String... names) {
		return (ListDtlR) super.getValues(names);
	}



	/**
	 *  紐付ＮＯ.<p>
	 *
	 */
	public MCNumber pno() {
		return getConstNumber(offset + 0, $pno);
	}

	/**
	 *  紐付ＮＯ.<p>
	 *
	 */
	public void pno(MCNumber value) {
		setConstNumber(offset + 0, $pno, value);
	}

	/**
	 *  紐付ＮＯ.<p>
	 *
	 */
	public void pno(int value) {
		setConstNumber(offset + 0, $pno, value);
	}

	/**
	 *  紐付ＮＯ.<p>
	 *
	 */
	public void pno(long value) {
		setConstNumber(offset + 0, $pno, value);
	}

	/**
	 *  紐付ＮＯ.<p>
	 *
	 */
	public void pno(float value) {
		setConstNumber(offset + 0, $pno, value);
	}

	/**
	 *  紐付ＮＯ.<p>
	 *
	 */
	public void pno(double value) {
		setConstNumber(offset + 0, $pno, value);
	}


	/**
	 *  フォーカス設定ＩＤ.<p>
	 *
	 */
	public String focus_id() {
		return getConstString(offset + 1, $focus_id);
	}

	/**
	 *  フォーカス設定ＩＤ.<p>
	 *
	 */
	public void focus_id(String value) {
		setConstString(offset + 1, $focus_id, value);
	}


	/**
	 *  フォーカス設定名.<p>
	 *
	 */
	public String focus_nm() {
		return getConstString(offset + 2, $focus_nm);
	}

	/**
	 *  フォーカス設定名.<p>
	 *
	 */
	public void focus_nm(String value) {
		setConstString(offset + 2, $focus_nm, value);
	}


	/**
	 *  バージョン.<p>
	 *
	 */
	public String version() {
		return getConstString(offset + 3, $version);
	}

	/**
	 *  バージョン.<p>
	 *
	 */
	public void version(String value) {
		setConstString(offset + 3, $version, value);
	}


	public String getString(String name) {
		if ($focus_id.equalsIgnoreCase(name)) {
			return focus_id();
		}
		if ($focus_nm.equalsIgnoreCase(name)) {
			return focus_nm();
		}
		if ($version.equalsIgnoreCase(name)) {
			return version();
		}
		return super.getString(name);
	}
	public MCNumber getNumber(String name) {
		if ($pno.equalsIgnoreCase(name)) {
			return pno();
		}
		return super.getNumber(name);
	}

	public String getStringNE(String name) {
		if ($focus_id.equalsIgnoreCase(name)) {
			return focus_id();
		}
		if ($focus_nm.equalsIgnoreCase(name)) {
			return focus_nm();
		}
		if ($version.equalsIgnoreCase(name)) {
			return version();
		}
		return super.getStringNE(name);
	}
	public MCNumber getNumberNE(String name) {
		if ($pno.equalsIgnoreCase(name)) {
			return pno();
		}
		return super.getNumberNE(name);
	}

	public void setString(String name, String value) {
		if ($focus_id.equalsIgnoreCase(name)) {
			focus_id(value);
			return;
		}
		if ($focus_nm.equalsIgnoreCase(name)) {
			focus_nm(value);
			return;
		}
		if ($version.equalsIgnoreCase(name)) {
			version(value);
			return;
		}
		super.setString(name, value);
	}
	public void setNumber(String name, MCNumber value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, int value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, long value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, float value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, double value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumber(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($focus_id.equalsIgnoreCase(name)) {
			focus_id(value);
			return;
		}
		if ($focus_nm.equalsIgnoreCase(name)) {
			focus_nm(value);
			return;
		}
		if ($version.equalsIgnoreCase(name)) {
			version(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setNumberNE(String name, MCNumber value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, int value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, long value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, float value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, double value) {
		if ($pno.equalsIgnoreCase(name)) {
			pno(value);
			return;
		}
		super.setNumberNE(name, value);
	}



}

