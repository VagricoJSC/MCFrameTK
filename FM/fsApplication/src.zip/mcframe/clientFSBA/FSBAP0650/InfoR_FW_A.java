package mcframe.clientFSBA.FSBAP0650;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Info"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class InfoR_FW_A extends MCConstRow {

	/**
	 *  画面部品ＩＤ.<p>
	 *
	 */
	public static final String $comp_id = "comp_id";
	public static final String $btn_flg = "btn_flg";
	/**
	 *  画面部品名.<p>
	 *
	 */
	public static final String $comp_nm = "comp_nm";
	/**
	 *  画面部品タイプ.<p>
	 *
	 */
	public static final String $comp_typ = "comp_typ";
	/**
	 *  親パネルＩＤ.<p>
	 *
	 */
	public static final String $panel_id = "panel_id";
	/**
	 *  親パネル名.<p>
	 *
	 */
	public static final String $panel_nm = "panel_nm";
	/**
	 *  ルートパネルＩＤ.<p>
	 *
	 */
	public static final String $root_panel_id = "root_panel_id";
	/**
	 *  フォーカスインで移動する画面部品ＩＤ.<p>
	 *
	 */
	public static final String $focus_in = "focus_in";
	/**
	 *  フォーカスインで移動する画面部品.<p>
	 *
	 */
	public static final String $focus_in_nm = "focus_in_nm";
	/**
	 *  フォーカスアウトで実行するボタンＩＤ.<p>
	 *
	 */
	public static final String $focus_out = "focus_out";
	/**
	 *  フォーカスアウトで実行するボタン.<p>
	 *
	 */
	public static final String $focus_out_nm = "focus_out_nm";
	/**
	 *  フォーカスアウト後の次のフォーカスＩＤ.<p>
	 *
	 */
	public static final String $focus_out_next_focus = "focus_out_next_focus";
	/**
	 *  フォーカスアウト後の次のフォーカス.<p>
	 *
	 */
	public static final String $focus_out_next_focus_nm = "focus_out_next_focus_nm";
	/**
	 *  ボタン実行後の次のフォーカスＩＤ.<p>
	 *
	 */
	public static final String $button_next_focus = "button_next_focus";
	/**
	 *  ボタン実行後の次のフォーカス.<p>
	 *
	 */
	public static final String $button_next_focus_nm = "button_next_focus_nm";
	/**
	 *  ダイアログ後に移動するフォーカス.<p>
	 *
	 */
	public static final String $error_focus_flg = "error_focus_flg";
	/**
	 *  初期フォーカス.<p>
	 *
	 */
	public static final String $start_focus_flg = "start_focus_flg";
	/**
	 *  バーコード入力.<p>
	 *
	 */
	public static final String $barcode_flg = "barcode_flg";


	public static final MCMeta comp_id_META = createStringMeta($comp_id);
	public static final MCMeta btn_flg_META = createCommonMeta($btn_flg, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta comp_nm_META = createStringMeta($comp_nm);
	public static final MCMeta comp_typ_META = createStringMeta($comp_typ);
	public static final MCMeta panel_id_META = createCommonMeta($panel_id, mcframe.commonCore.meta.M_META.PANEL_ID);
	public static final MCMeta panel_nm_META = createStringMeta($panel_nm);
	public static final MCMeta root_panel_id_META = createCommonMeta($root_panel_id, mcframe.commonCore.meta.M_META.PANEL_ID);
	public static final MCMeta focus_in_META = createStringMeta($focus_in);
	public static final MCMeta focus_in_nm_META = createStringMeta($focus_in_nm);
	public static final MCMeta focus_out_META = createStringMeta($focus_out);
	public static final MCMeta focus_out_nm_META = createStringMeta($focus_out_nm);
	public static final MCMeta focus_out_next_focus_META = createStringMeta($focus_out_next_focus);
	public static final MCMeta focus_out_next_focus_nm_META = createStringMeta($focus_out_next_focus_nm);
	public static final MCMeta button_next_focus_META = createStringMeta($button_next_focus);
	public static final MCMeta button_next_focus_nm_META = createStringMeta($button_next_focus_nm);
	public static final MCMeta error_focus_flg_META = createCommonMeta($error_focus_flg, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta start_focus_flg_META = createCommonMeta($start_focus_flg, mcframe.commonCore.meta.M_META.FLG);
	public static final MCMeta barcode_flg_META = createCommonMeta($barcode_flg, mcframe.commonCore.meta.M_META.FLG);

	protected static final ConstMetaList<InfoR> constMetas = new ConstMetaList<InfoR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			comp_id_META,
			btn_flg_META,
			comp_nm_META,
			comp_typ_META,
			panel_id_META,
			panel_nm_META,
			root_panel_id_META,
			focus_in_META,
			focus_in_nm_META,
			focus_out_META,
			focus_out_nm_META,
			focus_out_next_focus_META,
			focus_out_next_focus_nm_META,
			button_next_focus_META,
			button_next_focus_nm_META,
			error_focus_flg_META,
			start_focus_flg_META,
			barcode_flg_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected InfoR_FW_A(ConstMetaList<? extends InfoR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public InfoR clone() {
		return (InfoR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public InfoR createInstance() {
		return (InfoR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public InfoR getValues(String... names) {
		return (InfoR) super.getValues(names);
	}



	/**
	 *  画面部品ＩＤ.<p>
	 *
	 */
	public String comp_id() {
		return getConstString(offset + 0, $comp_id);
	}

	/**
	 *  画面部品ＩＤ.<p>
	 *
	 */
	public void comp_id(String value) {
		setConstString(offset + 0, $comp_id, value);
	}


	public boolean btn_flg() {
		return getConstBoolean(offset + 1, $btn_flg);
	}

	public void btn_flg(boolean value) {
		setConstBoolean(offset + 1, $btn_flg, value);
	}


	/**
	 *  画面部品名.<p>
	 *
	 */
	public String comp_nm() {
		return getConstString(offset + 2, $comp_nm);
	}

	/**
	 *  画面部品名.<p>
	 *
	 */
	public void comp_nm(String value) {
		setConstString(offset + 2, $comp_nm, value);
	}


	/**
	 *  画面部品タイプ.<p>
	 *
	 */
	public String comp_typ() {
		return getConstString(offset + 3, $comp_typ);
	}

	/**
	 *  画面部品タイプ.<p>
	 *
	 */
	public void comp_typ(String value) {
		setConstString(offset + 3, $comp_typ, value);
	}


	/**
	 *  親パネルＩＤ.<p>
	 *
	 */
	public String panel_id() {
		return getConstString(offset + 4, $panel_id);
	}

	/**
	 *  親パネルＩＤ.<p>
	 *
	 */
	public void panel_id(String value) {
		setConstString(offset + 4, $panel_id, value);
	}


	/**
	 *  親パネル名.<p>
	 *
	 */
	public String panel_nm() {
		return getConstString(offset + 5, $panel_nm);
	}

	/**
	 *  親パネル名.<p>
	 *
	 */
	public void panel_nm(String value) {
		setConstString(offset + 5, $panel_nm, value);
	}


	/**
	 *  ルートパネルＩＤ.<p>
	 *
	 */
	public String root_panel_id() {
		return getConstString(offset + 6, $root_panel_id);
	}

	/**
	 *  ルートパネルＩＤ.<p>
	 *
	 */
	public void root_panel_id(String value) {
		setConstString(offset + 6, $root_panel_id, value);
	}


	/**
	 *  フォーカスインで移動する画面部品ＩＤ.<p>
	 *
	 */
	public String focus_in() {
		return getConstString(offset + 7, $focus_in);
	}

	/**
	 *  フォーカスインで移動する画面部品ＩＤ.<p>
	 *
	 */
	public void focus_in(String value) {
		setConstString(offset + 7, $focus_in, value);
	}


	/**
	 *  フォーカスインで移動する画面部品.<p>
	 *
	 */
	public String focus_in_nm() {
		return getConstString(offset + 8, $focus_in_nm);
	}

	/**
	 *  フォーカスインで移動する画面部品.<p>
	 *
	 */
	public void focus_in_nm(String value) {
		setConstString(offset + 8, $focus_in_nm, value);
	}


	/**
	 *  フォーカスアウトで実行するボタンＩＤ.<p>
	 *
	 */
	public String focus_out() {
		return getConstString(offset + 9, $focus_out);
	}

	/**
	 *  フォーカスアウトで実行するボタンＩＤ.<p>
	 *
	 */
	public void focus_out(String value) {
		setConstString(offset + 9, $focus_out, value);
	}


	/**
	 *  フォーカスアウトで実行するボタン.<p>
	 *
	 */
	public String focus_out_nm() {
		return getConstString(offset + 10, $focus_out_nm);
	}

	/**
	 *  フォーカスアウトで実行するボタン.<p>
	 *
	 */
	public void focus_out_nm(String value) {
		setConstString(offset + 10, $focus_out_nm, value);
	}


	/**
	 *  フォーカスアウト後の次のフォーカスＩＤ.<p>
	 *
	 */
	public String focus_out_next_focus() {
		return getConstString(offset + 11, $focus_out_next_focus);
	}

	/**
	 *  フォーカスアウト後の次のフォーカスＩＤ.<p>
	 *
	 */
	public void focus_out_next_focus(String value) {
		setConstString(offset + 11, $focus_out_next_focus, value);
	}


	/**
	 *  フォーカスアウト後の次のフォーカス.<p>
	 *
	 */
	public String focus_out_next_focus_nm() {
		return getConstString(offset + 12, $focus_out_next_focus_nm);
	}

	/**
	 *  フォーカスアウト後の次のフォーカス.<p>
	 *
	 */
	public void focus_out_next_focus_nm(String value) {
		setConstString(offset + 12, $focus_out_next_focus_nm, value);
	}


	/**
	 *  ボタン実行後の次のフォーカスＩＤ.<p>
	 *
	 */
	public String button_next_focus() {
		return getConstString(offset + 13, $button_next_focus);
	}

	/**
	 *  ボタン実行後の次のフォーカスＩＤ.<p>
	 *
	 */
	public void button_next_focus(String value) {
		setConstString(offset + 13, $button_next_focus, value);
	}


	/**
	 *  ボタン実行後の次のフォーカス.<p>
	 *
	 */
	public String button_next_focus_nm() {
		return getConstString(offset + 14, $button_next_focus_nm);
	}

	/**
	 *  ボタン実行後の次のフォーカス.<p>
	 *
	 */
	public void button_next_focus_nm(String value) {
		setConstString(offset + 14, $button_next_focus_nm, value);
	}


	/**
	 *  ダイアログ後に移動するフォーカス.<p>
	 *
	 */
	public boolean error_focus_flg() {
		return getConstBoolean(offset + 15, $error_focus_flg);
	}

	/**
	 *  ダイアログ後に移動するフォーカス.<p>
	 *
	 */
	public void error_focus_flg(boolean value) {
		setConstBoolean(offset + 15, $error_focus_flg, value);
	}


	/**
	 *  初期フォーカス.<p>
	 *
	 */
	public boolean start_focus_flg() {
		return getConstBoolean(offset + 16, $start_focus_flg);
	}

	/**
	 *  初期フォーカス.<p>
	 *
	 */
	public void start_focus_flg(boolean value) {
		setConstBoolean(offset + 16, $start_focus_flg, value);
	}


	/**
	 *  バーコード入力.<p>
	 *
	 */
	public boolean barcode_flg() {
		return getConstBoolean(offset + 17, $barcode_flg);
	}

	/**
	 *  バーコード入力.<p>
	 *
	 */
	public void barcode_flg(boolean value) {
		setConstBoolean(offset + 17, $barcode_flg, value);
	}


	public String getString(String name) {
		if ($comp_id.equalsIgnoreCase(name)) {
			return comp_id();
		}
		if ($comp_nm.equalsIgnoreCase(name)) {
			return comp_nm();
		}
		if ($comp_typ.equalsIgnoreCase(name)) {
			return comp_typ();
		}
		if ($panel_id.equalsIgnoreCase(name)) {
			return panel_id();
		}
		if ($panel_nm.equalsIgnoreCase(name)) {
			return panel_nm();
		}
		if ($root_panel_id.equalsIgnoreCase(name)) {
			return root_panel_id();
		}
		if ($focus_in.equalsIgnoreCase(name)) {
			return focus_in();
		}
		if ($focus_in_nm.equalsIgnoreCase(name)) {
			return focus_in_nm();
		}
		if ($focus_out.equalsIgnoreCase(name)) {
			return focus_out();
		}
		if ($focus_out_nm.equalsIgnoreCase(name)) {
			return focus_out_nm();
		}
		if ($focus_out_next_focus.equalsIgnoreCase(name)) {
			return focus_out_next_focus();
		}
		if ($focus_out_next_focus_nm.equalsIgnoreCase(name)) {
			return focus_out_next_focus_nm();
		}
		if ($button_next_focus.equalsIgnoreCase(name)) {
			return button_next_focus();
		}
		if ($button_next_focus_nm.equalsIgnoreCase(name)) {
			return button_next_focus_nm();
		}
		return super.getString(name);
	}
	public boolean getBoolean(String name) {
		if ($btn_flg.equalsIgnoreCase(name)) {
			return btn_flg();
		}
		if ($error_focus_flg.equalsIgnoreCase(name)) {
			return error_focus_flg();
		}
		if ($start_focus_flg.equalsIgnoreCase(name)) {
			return start_focus_flg();
		}
		if ($barcode_flg.equalsIgnoreCase(name)) {
			return barcode_flg();
		}
		return super.getBoolean(name);
	}

	public String getStringNE(String name) {
		if ($comp_id.equalsIgnoreCase(name)) {
			return comp_id();
		}
		if ($comp_nm.equalsIgnoreCase(name)) {
			return comp_nm();
		}
		if ($comp_typ.equalsIgnoreCase(name)) {
			return comp_typ();
		}
		if ($panel_id.equalsIgnoreCase(name)) {
			return panel_id();
		}
		if ($panel_nm.equalsIgnoreCase(name)) {
			return panel_nm();
		}
		if ($root_panel_id.equalsIgnoreCase(name)) {
			return root_panel_id();
		}
		if ($focus_in.equalsIgnoreCase(name)) {
			return focus_in();
		}
		if ($focus_in_nm.equalsIgnoreCase(name)) {
			return focus_in_nm();
		}
		if ($focus_out.equalsIgnoreCase(name)) {
			return focus_out();
		}
		if ($focus_out_nm.equalsIgnoreCase(name)) {
			return focus_out_nm();
		}
		if ($focus_out_next_focus.equalsIgnoreCase(name)) {
			return focus_out_next_focus();
		}
		if ($focus_out_next_focus_nm.equalsIgnoreCase(name)) {
			return focus_out_next_focus_nm();
		}
		if ($button_next_focus.equalsIgnoreCase(name)) {
			return button_next_focus();
		}
		if ($button_next_focus_nm.equalsIgnoreCase(name)) {
			return button_next_focus_nm();
		}
		return super.getStringNE(name);
	}
	public boolean getBooleanNE(String name) {
		if ($btn_flg.equalsIgnoreCase(name)) {
			return btn_flg();
		}
		if ($error_focus_flg.equalsIgnoreCase(name)) {
			return error_focus_flg();
		}
		if ($start_focus_flg.equalsIgnoreCase(name)) {
			return start_focus_flg();
		}
		if ($barcode_flg.equalsIgnoreCase(name)) {
			return barcode_flg();
		}
		return super.getBooleanNE(name);
	}

	public void setString(String name, String value) {
		if ($comp_id.equalsIgnoreCase(name)) {
			comp_id(value);
			return;
		}
		if ($comp_nm.equalsIgnoreCase(name)) {
			comp_nm(value);
			return;
		}
		if ($comp_typ.equalsIgnoreCase(name)) {
			comp_typ(value);
			return;
		}
		if ($panel_id.equalsIgnoreCase(name)) {
			panel_id(value);
			return;
		}
		if ($panel_nm.equalsIgnoreCase(name)) {
			panel_nm(value);
			return;
		}
		if ($root_panel_id.equalsIgnoreCase(name)) {
			root_panel_id(value);
			return;
		}
		if ($focus_in.equalsIgnoreCase(name)) {
			focus_in(value);
			return;
		}
		if ($focus_in_nm.equalsIgnoreCase(name)) {
			focus_in_nm(value);
			return;
		}
		if ($focus_out.equalsIgnoreCase(name)) {
			focus_out(value);
			return;
		}
		if ($focus_out_nm.equalsIgnoreCase(name)) {
			focus_out_nm(value);
			return;
		}
		if ($focus_out_next_focus.equalsIgnoreCase(name)) {
			focus_out_next_focus(value);
			return;
		}
		if ($focus_out_next_focus_nm.equalsIgnoreCase(name)) {
			focus_out_next_focus_nm(value);
			return;
		}
		if ($button_next_focus.equalsIgnoreCase(name)) {
			button_next_focus(value);
			return;
		}
		if ($button_next_focus_nm.equalsIgnoreCase(name)) {
			button_next_focus_nm(value);
			return;
		}
		super.setString(name, value);
	}
	public void setBoolean(String name, boolean value) {
		if ($btn_flg.equalsIgnoreCase(name)) {
			btn_flg(value);
			return;
		}
		if ($error_focus_flg.equalsIgnoreCase(name)) {
			error_focus_flg(value);
			return;
		}
		if ($start_focus_flg.equalsIgnoreCase(name)) {
			start_focus_flg(value);
			return;
		}
		if ($barcode_flg.equalsIgnoreCase(name)) {
			barcode_flg(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($comp_id.equalsIgnoreCase(name)) {
			comp_id(value);
			return;
		}
		if ($comp_nm.equalsIgnoreCase(name)) {
			comp_nm(value);
			return;
		}
		if ($comp_typ.equalsIgnoreCase(name)) {
			comp_typ(value);
			return;
		}
		if ($panel_id.equalsIgnoreCase(name)) {
			panel_id(value);
			return;
		}
		if ($panel_nm.equalsIgnoreCase(name)) {
			panel_nm(value);
			return;
		}
		if ($root_panel_id.equalsIgnoreCase(name)) {
			root_panel_id(value);
			return;
		}
		if ($focus_in.equalsIgnoreCase(name)) {
			focus_in(value);
			return;
		}
		if ($focus_in_nm.equalsIgnoreCase(name)) {
			focus_in_nm(value);
			return;
		}
		if ($focus_out.equalsIgnoreCase(name)) {
			focus_out(value);
			return;
		}
		if ($focus_out_nm.equalsIgnoreCase(name)) {
			focus_out_nm(value);
			return;
		}
		if ($focus_out_next_focus.equalsIgnoreCase(name)) {
			focus_out_next_focus(value);
			return;
		}
		if ($focus_out_next_focus_nm.equalsIgnoreCase(name)) {
			focus_out_next_focus_nm(value);
			return;
		}
		if ($button_next_focus.equalsIgnoreCase(name)) {
			button_next_focus(value);
			return;
		}
		if ($button_next_focus_nm.equalsIgnoreCase(name)) {
			button_next_focus_nm(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setBooleanNE(String name, boolean value) {
		if ($btn_flg.equalsIgnoreCase(name)) {
			btn_flg(value);
			return;
		}
		if ($error_focus_flg.equalsIgnoreCase(name)) {
			error_focus_flg(value);
			return;
		}
		if ($start_focus_flg.equalsIgnoreCase(name)) {
			start_focus_flg(value);
			return;
		}
		if ($barcode_flg.equalsIgnoreCase(name)) {
			barcode_flg(value);
			return;
		}
		super.setBooleanNE(name, value);
	}



}

