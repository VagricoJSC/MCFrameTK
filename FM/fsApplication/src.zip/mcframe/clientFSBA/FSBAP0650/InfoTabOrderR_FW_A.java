package mcframe.clientFSBA.FSBAP0650;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"InfoTabOrder"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class InfoTabOrderR_FW_A extends MCConstRow {

	/**
	 *  ID.<p>
	 *
	 */
	public static final String $id = "id";
	/**
	 *  ComponentID前.<p>
	 *
	 */
	public static final String $prev_component_id = "prev_component_id";
	/**
	 *  PanelID前.<p>
	 *
	 */
	public static final String $prev_panel_id = "prev_panel_id";
	/**
	 *  RootPanelID前.<p>
	 *
	 */
	public static final String $prev_root_panel_id = "prev_root_panel_id";
	/**
	 *  ComponentID後.<p>
	 *
	 */
	public static final String $next_component_id = "next_component_id";
	/**
	 *  PanelID後.<p>
	 *
	 */
	public static final String $next_panel_id = "next_panel_id";
	/**
	 *  RootPanelID後.<p>
	 *
	 */
	public static final String $next_root_panel_id = "next_root_panel_id";


	public static final MCMeta id_META = createNumberMeta($id);
	public static final MCMeta prev_component_id_META = createStringMeta($prev_component_id);
	public static final MCMeta prev_panel_id_META = createStringMeta($prev_panel_id);
	public static final MCMeta prev_root_panel_id_META = createStringMeta($prev_root_panel_id);
	public static final MCMeta next_component_id_META = createStringMeta($next_component_id);
	public static final MCMeta next_panel_id_META = createStringMeta($next_panel_id);
	public static final MCMeta next_root_panel_id_META = createStringMeta($next_root_panel_id);

	protected static final ConstMetaList<InfoTabOrderR> constMetas = new ConstMetaList<InfoTabOrderR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			id_META,
			prev_component_id_META,
			prev_panel_id_META,
			prev_root_panel_id_META,
			next_component_id_META,
			next_panel_id_META,
			next_root_panel_id_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected InfoTabOrderR_FW_A(ConstMetaList<? extends InfoTabOrderR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public InfoTabOrderR clone() {
		return (InfoTabOrderR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public InfoTabOrderR createInstance() {
		return (InfoTabOrderR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public InfoTabOrderR getValues(String... names) {
		return (InfoTabOrderR) super.getValues(names);
	}



	/**
	 *  ID.<p>
	 *
	 */
	public MCNumber id() {
		return getConstNumber(offset + 0, $id);
	}

	/**
	 *  ID.<p>
	 *
	 */
	public void id(MCNumber value) {
		setConstNumber(offset + 0, $id, value);
	}

	/**
	 *  ID.<p>
	 *
	 */
	public void id(int value) {
		setConstNumber(offset + 0, $id, value);
	}

	/**
	 *  ID.<p>
	 *
	 */
	public void id(long value) {
		setConstNumber(offset + 0, $id, value);
	}

	/**
	 *  ID.<p>
	 *
	 */
	public void id(float value) {
		setConstNumber(offset + 0, $id, value);
	}

	/**
	 *  ID.<p>
	 *
	 */
	public void id(double value) {
		setConstNumber(offset + 0, $id, value);
	}


	/**
	 *  ComponentID前.<p>
	 *
	 */
	public String prev_component_id() {
		return getConstString(offset + 1, $prev_component_id);
	}

	/**
	 *  ComponentID前.<p>
	 *
	 */
	public void prev_component_id(String value) {
		setConstString(offset + 1, $prev_component_id, value);
	}


	/**
	 *  PanelID前.<p>
	 *
	 */
	public String prev_panel_id() {
		return getConstString(offset + 2, $prev_panel_id);
	}

	/**
	 *  PanelID前.<p>
	 *
	 */
	public void prev_panel_id(String value) {
		setConstString(offset + 2, $prev_panel_id, value);
	}


	/**
	 *  RootPanelID前.<p>
	 *
	 */
	public String prev_root_panel_id() {
		return getConstString(offset + 3, $prev_root_panel_id);
	}

	/**
	 *  RootPanelID前.<p>
	 *
	 */
	public void prev_root_panel_id(String value) {
		setConstString(offset + 3, $prev_root_panel_id, value);
	}


	/**
	 *  ComponentID後.<p>
	 *
	 */
	public String next_component_id() {
		return getConstString(offset + 4, $next_component_id);
	}

	/**
	 *  ComponentID後.<p>
	 *
	 */
	public void next_component_id(String value) {
		setConstString(offset + 4, $next_component_id, value);
	}


	/**
	 *  PanelID後.<p>
	 *
	 */
	public String next_panel_id() {
		return getConstString(offset + 5, $next_panel_id);
	}

	/**
	 *  PanelID後.<p>
	 *
	 */
	public void next_panel_id(String value) {
		setConstString(offset + 5, $next_panel_id, value);
	}


	/**
	 *  RootPanelID後.<p>
	 *
	 */
	public String next_root_panel_id() {
		return getConstString(offset + 6, $next_root_panel_id);
	}

	/**
	 *  RootPanelID後.<p>
	 *
	 */
	public void next_root_panel_id(String value) {
		setConstString(offset + 6, $next_root_panel_id, value);
	}


	public String getString(String name) {
		if ($prev_component_id.equalsIgnoreCase(name)) {
			return prev_component_id();
		}
		if ($prev_panel_id.equalsIgnoreCase(name)) {
			return prev_panel_id();
		}
		if ($prev_root_panel_id.equalsIgnoreCase(name)) {
			return prev_root_panel_id();
		}
		if ($next_component_id.equalsIgnoreCase(name)) {
			return next_component_id();
		}
		if ($next_panel_id.equalsIgnoreCase(name)) {
			return next_panel_id();
		}
		if ($next_root_panel_id.equalsIgnoreCase(name)) {
			return next_root_panel_id();
		}
		return super.getString(name);
	}
	public MCNumber getNumber(String name) {
		if ($id.equalsIgnoreCase(name)) {
			return id();
		}
		return super.getNumber(name);
	}

	public String getStringNE(String name) {
		if ($prev_component_id.equalsIgnoreCase(name)) {
			return prev_component_id();
		}
		if ($prev_panel_id.equalsIgnoreCase(name)) {
			return prev_panel_id();
		}
		if ($prev_root_panel_id.equalsIgnoreCase(name)) {
			return prev_root_panel_id();
		}
		if ($next_component_id.equalsIgnoreCase(name)) {
			return next_component_id();
		}
		if ($next_panel_id.equalsIgnoreCase(name)) {
			return next_panel_id();
		}
		if ($next_root_panel_id.equalsIgnoreCase(name)) {
			return next_root_panel_id();
		}
		return super.getStringNE(name);
	}
	public MCNumber getNumberNE(String name) {
		if ($id.equalsIgnoreCase(name)) {
			return id();
		}
		return super.getNumberNE(name);
	}

	public void setString(String name, String value) {
		if ($prev_component_id.equalsIgnoreCase(name)) {
			prev_component_id(value);
			return;
		}
		if ($prev_panel_id.equalsIgnoreCase(name)) {
			prev_panel_id(value);
			return;
		}
		if ($prev_root_panel_id.equalsIgnoreCase(name)) {
			prev_root_panel_id(value);
			return;
		}
		if ($next_component_id.equalsIgnoreCase(name)) {
			next_component_id(value);
			return;
		}
		if ($next_panel_id.equalsIgnoreCase(name)) {
			next_panel_id(value);
			return;
		}
		if ($next_root_panel_id.equalsIgnoreCase(name)) {
			next_root_panel_id(value);
			return;
		}
		super.setString(name, value);
	}
	public void setNumber(String name, MCNumber value) {
		if ($id.equalsIgnoreCase(name)) {
			id(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, int value) {
		if ($id.equalsIgnoreCase(name)) {
			id(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, long value) {
		if ($id.equalsIgnoreCase(name)) {
			id(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, float value) {
		if ($id.equalsIgnoreCase(name)) {
			id(value);
			return;
		}
		super.setNumber(name, value);
	}
	public void setNumber(String name, double value) {
		if ($id.equalsIgnoreCase(name)) {
			id(value);
			return;
		}
		super.setNumber(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($prev_component_id.equalsIgnoreCase(name)) {
			prev_component_id(value);
			return;
		}
		if ($prev_panel_id.equalsIgnoreCase(name)) {
			prev_panel_id(value);
			return;
		}
		if ($prev_root_panel_id.equalsIgnoreCase(name)) {
			prev_root_panel_id(value);
			return;
		}
		if ($next_component_id.equalsIgnoreCase(name)) {
			next_component_id(value);
			return;
		}
		if ($next_panel_id.equalsIgnoreCase(name)) {
			next_panel_id(value);
			return;
		}
		if ($next_root_panel_id.equalsIgnoreCase(name)) {
			next_root_panel_id(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setNumberNE(String name, MCNumber value) {
		if ($id.equalsIgnoreCase(name)) {
			id(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, int value) {
		if ($id.equalsIgnoreCase(name)) {
			id(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, long value) {
		if ($id.equalsIgnoreCase(name)) {
			id(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, float value) {
		if ($id.equalsIgnoreCase(name)) {
			id(value);
			return;
		}
		super.setNumberNE(name, value);
	}
	public void setNumberNE(String name, double value) {
		if ($id.equalsIgnoreCase(name)) {
			id(value);
			return;
		}
		super.setNumberNE(name, value);
	}



}

