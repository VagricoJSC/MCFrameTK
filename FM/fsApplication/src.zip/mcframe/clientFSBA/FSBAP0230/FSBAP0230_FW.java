package mcframe.clientFSBA.FSBAP0230;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.layout.MCGeneralLayout;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;


import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START

import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.JComponent;
//import javax.swing.JFrame;
import javax.swing.WindowConstants;

import mcframe.clientCore.beans.message.MCProgressThread;
import mcframe.clientFSBA.FSBAP0040.FSBAP0040;
import mcframe.clientFXBA.FXBAP0010.IfProgressInfo;
import mcframe.commonCore.notice.MCMessage;
import mcframe.clientCore.beans.message.MCDialogButton;
import mcframe.clientCore.beans.message.MCProgressInfo;
import mcframe.clientCore.beans.message.MCProgressPanel;
import mcframe.clientCore.beans.popup.MCPopupBeans;
import mcframe.clientCore.resource.MCConfig;
import mcframe.clientCore.resource.MCConst;
import mcframe.clientFSUC.FSUCP0000.FSUCP_PopupConfig;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP0230"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP0230_FW extends FSBAP0230_FW_A implements MCProgressPanel {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	public final MCProgressBar Progress_progressBar = new MCProgressBar("ProgressBar");

	/**
	 * ユーザが選択したボタンを表す定数
	 * 
	 * デフォルトがMCMessageBox.CANCEL_OPTION であってはならない
	 */
	private int result = MCMessageBox.CLOSE_OPTION;

	/**
	 * ダイアログ情報
	 */
	private MCProgressInfo info = null;
	
	
	/**
	 * 幅の最小値
	 */
	// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
//	private int minWidth = 250;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0230_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START
		MCBeansUtil.setMouseCursorDefault(this);
		//FMCB CUSTOM_CONSTRUCTOR END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	/**
	 * Panel[Btn]のボタン[cancel]の押下時の処理
	 */
	@Override
	public void doBtn_cancel(MCEventInfo info) {
		doButtonAction(MCMessageBox.CANCEL_OPTION);
	}

	/**
	 * ボタンアクションを実行します。
	 * 
	 * @param option 選択したボタンを表す定数
	 */
	protected void doButtonAction(int option) {
		result = option;
		requestCloseWindow();
	}

	/**
	 * 初期フォーカスを設定します。
	 * 
	 * @param button ボタンを表す定数
	 */
	protected void setInitFocus(MCDialogButton button) {
		if (button != null) {
			switch (button) {
				case CANCEL:
					Btn_cancel.mcRequestFocus();
					break;
			}
		}
		else {
			MCFrame f =  getFrame();
			if (f != null) {
				((MCModalFrame) f).setFocusable(false);
			}
		}
	}

	/**
	 * ダイアログ情報を設定します。
	 * 
	 * @param info ダイアログ情報
	 * @see #getDialogInfo()
	 */
	@Override
	public void setDialogInfo(MCProgressInfo info) {
		this.info = info;
	}

	// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
	// 単体で動作テストする場合はtrueにする。
	private boolean _isTestMode = false;

	/**
	 * ダイアログ情報を返します。
	 * ダイアログ情報が設定されていない場合は null を返します。
	 * 
	 * @return ダイアログ情報
	 */
	public final MCProgressInfo getDialogInfo() {
		// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
		// 単体でテストできるようにダミーでインスタンスを生成
		if(info == null) {
			_isTestMode = true;
			info = new MCProgressInfo(this);
			info.setDialogType(MCMessageBox.CANCEL_DIALOG);
		}
		return info;
	}

	@Override
	protected String getPopupPattern(MCPopupBeans compo) {
		return FSUCP_PopupConfig.REMOVE_ALL;
	}

	@Override
	protected void jbInit() {
		super.jbInit();
		IconPanel.setOpaque(true);
		InfoPanel.setOpaque(true);
		BtnPanel.setOpaque(true);
		ProgressPanel.setOpaque(true);
		// プログレスバー設定
		Progress_progressBar.setOrientation(MCProgressBar.HORIZONTAL);
		Progress_progressBar.setIndeterminate(true);
		Progress_progressBar.setStringPainted(false);
		Progress_progressBar.setOpaque(true);
		ProgressPanel.setLayout(new BorderLayout());
		ProgressPanel.add(Progress_progressBar, BorderLayout.CENTER);

		// テキストエリア設定
		// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
//		InfoPanel.setLayout(new BorderLayout());
		Info_messageScrollPane.setOpaque(false);
//		Info_messageScrollPane.setOpaque(true);

		for (JComponent c : MCBeansUtil.getAllComponents(JComponent.class,
				Info_messageScrollPane)) {
			c.setOpaque(false);
		}
		Info_message.setBorder(null);
		Info_messageScrollPane.setBorder(null);
		// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
		// packメソッドで処理するため不要
//		InfoPanel.remove(Info_messageScrollPane);
//		InfoPanel.add(Info_messageScrollPane, BorderLayout.CENTER);
	}

	@Override
	protected void mcInit() {
		super.mcInit();
	}

	@Override
	public boolean beforeOpen() {
		

		MCProgressInfo progInfo = getDialogInfo();
		if (super.beforeOpen()) {


			
			//ボーダ設定
			if (progInfo.isUndecoratedFrame()) {
				setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY, 3));
			}
			else {
				setBorder(BorderFactory.createEmptyBorder(1, 1, 1, 1));
			}

			// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
			if(_isTestMode == false) {
				//フレームの設定
				MCFrame dialog = getFrame();
				if (dialog != null) {
					dialog.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
					if (progInfo != null && progInfo.isUndecoratedFrame()) {
						dialog.dispose();
						dialog.setUndecorated(true);
						dialog.pack();
					}
				}
			}

			//ボタンの制御
			switch (progInfo.getDialogType()) {
				case MCMessageBox.CANCEL_DIALOG:
					Btn_cancel.setMode(MCMode.ENABLE);
					break;
				default:
					Btn_cancel.setMode(MCMode.INVISIBLE);
			}

			//プログレスバーの制御
			if (!progInfo.isProgessBarAvailable()) {
				ProgressPanel.getParent().remove(ProgressPanel);
			}

			//title
			String ttl = progInfo.getTitle();
			if (ttl != null) {
				setFrameTitle(ttl);
			}

			//message,icon
			setMessage(progInfo.getMessage(), progInfo.getIcon());

			// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
			// 単体テスト対応
			if(_isTestMode) {
				pack();
			}

			setArrangementCenter();

			MCProgressThread t = progInfo.getAction();
			//処理開始
			if (t != null && t.doMultiThread()) {
				t.start();
				int delay = getDelay();
				int cnt = 0;
				if (delay != 0) {
					int deno = 100;
					int remain = delay%deno;
					int last = (delay-remain)/deno + 1;
					while(cnt <= last){
						try {
							if (cnt < last) {
								Thread.sleep(deno);
							}
							else {
								Thread.sleep(remain);
							}
						}
						catch (InterruptedException e) {
							throw new MCAppException(e);
						}
						if(t.isAlive()){
							cnt++;
						}
						else {
							if (progInfo instanceof IfProgressInfo) {
								((IfProgressInfo)progInfo).usedProgress(false);
							}
							return false;
						}
					}
				}
			}
			
			return true;
		}
		
		return false;
	}

	@Override
	public void afterOpen() {

		super.afterOpen();
		MCProgressInfo progInfo = getDialogInfo();
		if (progInfo != null){
			MCProgressThread t = progInfo.getAction();
			
			if (t != null && (!t.doMultiThread() || t.isAlive())) {
			
				setInitFocus(progInfo.getFocusButton());

				//カーソル変更
				if (progInfo.getDialogType() == MCMessageBox.NO_BUTTON_DIALOG) {
					Cursor c = Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR);
					setCursor(c);
				}
				
				//処理開始
				if (t.doMultiThread()) {
		//			t.start();
				}
				else{
					t.run();
				}
			}
		}
		// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
		if(_isTestMode) {
//			int fontRatio = getFontRatio();
//			getFrame().setSize(131 * fontRatio / 100, 103 * fontRatio / 100);
			setArrangementCenter();
		}
	}

	/**
	 * メッセージを表示します。
	 * 
	 * @param msg メッセージ
	 */
	protected void setMessage(MCMessage msg, Icon icon) {
		setMessage(FSBAP0040.formatMessage(msg.getID(), msg.toString()), icon);
	}

	// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
	// アイコンとテキストとの隙間
	protected int icon_gap = 5;
	protected int info_offset = 6;

	/**
	 * メッセージを表示します。
	 *
	 * @param msg メッセージ
	 * @param icon アイコン
	 */
	protected void setMessage(String msg, Icon icon) {

		//iconの設定
		Icon_icon.setIcon((Icon) null);

		int[] i_bounds = MCBeansUtil.getBounds(Icon_icon);
		int i_x = Icon_icon.getX();
		int i_y = Icon_icon.getY();
		int i_width = i_bounds[2];
		int i_height = i_bounds[3];
		if (i_width < 0) {
			i_width = icon.getIconWidth();
		}
		if (i_height < 0) {
			i_height = icon.getIconHeight();
		}

		Icon_icon.setBounds(i_x, i_y, i_width, i_height);
		Icon_icon.setIcon(icon);

		IconPanel.setBounds(i_x, i_y, i_width + icon_gap*2, i_height + icon_gap*2);

		//messageの設定

		// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
		// 全てレイアウトで位置決めするため不要
//		Info_messageScrollPane.setLocation(
//				Icon_icon.getLocation().x + Icon_icon.getSize().width + 10, 10);
		Info_message.setValue(msg);
//		Dimension size = Info_message.getPreferredSize();


		// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
		// スクロールバーが出てしまう場合の対応
		Info_messageScrollPane.setHorizontalScrollBarPolicy(MCScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		Info_messageScrollPane.setVerticalScrollBarPolicy(MCScrollPane.VERTICAL_SCROLLBAR_NEVER);

		// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
		// 全てレイアウトで位置決めするため不要

//		int[] bounds = MCBeansUtil.getBounds(this);
//		int m_width = bounds[2];
//		int m_height = bounds[3];
//		if (m_width < 0) {
//			m_width = 640;
//		}
//		if (m_height < 0) {
//			m_height = 480;
//		}
//		if (size.width > m_width - 60) {
//			size.width = m_width - 60;
//		}
//		if (size.height > m_height - 50) {
//			size.height = m_height - 50;
//		}
//
//		Dimension s_size = Info_messageScrollPane.getPreferredSize();
//		int s_x = Info_messageScrollPane.getLocation().x + s_size.width;
//		int m_x = minWidth - s_x;
//		if (m_x > 0) {
//			s_size.width+=m_x;
//		}
//		Info_messageScrollPane.setSize(s_size);

	}

	// 7013-0007(【A1】【FM-08】高解像度ディスプレイ対応)
	@Override
	public void pack() {
		setPreferredSize(null);
		for (JComponent c : MCBeansUtil.getAllComponents(JComponent.class, this)) {
			if (!(c instanceof MCButton) && !(c instanceof MCLabel)) {
				c.setPreferredSize(null);
			}
		}

		removeAll();

		// BorderLayoutで再計算するためサイズを0,0にする。
		if (_isTestMode) {
			Btn_cancel.setPreferredSize(new Dimension(0, 0));
			Icon_icon.setPreferredSize(new Dimension(0, 0));
			Info_messageScrollPane.setPreferredSize(new Dimension(0, 0));
		}

		ProgressPanel.setPreferredSize(new Dimension(0, 0));
		IconPanel.setPreferredSize(IconPanel.getPreferredSize());
		if (_isTestMode) {
			// 単体テストでボタンパネルの幅は必須
			BtnPanel.setPreferredSize(BtnPanel.getPreferredSize());
			// 高さが1ドット不足するため加算。
			InfoPanel.setPreferredSize(new Dimension(InfoPanel.getPreferredSize().width,
					InfoPanel.getPreferredSize().height + info_offset));
		}

		BtnPanel.remove(Btn_cancel);
		BtnPanel.setLayout(new BorderLayout());
		BtnPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		BtnPanel.add(Btn_cancel, BorderLayout.EAST);

		IconPanel.remove(Icon_icon);
		IconPanel.setLayout(new BorderLayout());
		IconPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		IconPanel.add(Icon_icon, BorderLayout.CENTER);

		InfoPanel.remove(Info_messageScrollPane);
		InfoPanel.setLayout(new BorderLayout());
		InfoPanel.add(Info_messageScrollPane, BorderLayout.CENTER);

		MCPanel jp1 = new MCPanel("icon_info");
		jp1.setLayout(new BorderLayout());
		jp1.setOpaque(true);
		jp1.add(IconPanel, BorderLayout.WEST);
		jp1.add(InfoPanel, BorderLayout.CENTER);
		add(jp1, BorderLayout.CENTER);

		MCPanel jp2 = new MCPanel("_progress_btn");
		jp2.setLayout(new BorderLayout());
		jp2.setOpaque(true);
		jp2.add(ProgressPanel, BorderLayout.CENTER);
		// キャンセルボタンなしの場合
		if (Btn_cancel.isVisible()) {
			jp2.add(BtnPanel, BorderLayout.SOUTH);
		}
		add(jp2, BorderLayout.SOUTH);

		// JFrame jf = new JFrame();
		// jf.add(this);
		// jf.pack();
		// jf.remove(this);

		// initialized必須
		initialized();
		// 7012-2037 (メインメニューがメモリーリークする)
		// jf廃止
		// jf.dispose();
		// 7012-2037 ここまで

		// 7013-2275(SP3高解像度対応不具合まとめ)
		// 画面の最小サイズ指定 このサイズ以下にはしない。
		Dimension d1 = getPreferredSize();
		int fontRatio = getFontRatio();
		d1 = new Dimension(d1.width * 100 / fontRatio, d1.height * 100 / fontRatio);
		Dimension d2 = new Dimension(Math.max(d1.width, 150), Math.max(d1.height, 100));
		setDefPrefSize(d2);
	}

	@Override
	public int getResultOption() {
		return result;
	}
	@Override
	public MCButton getEnableCancelButton() {
		if (Btn_cancel.getModeInfo().getStatus() == MCMode.ENABLE_STATUS) {
			return Btn_cancel;
		}
		return null;
	}

	@Override
	public int getDelay() {
		return MCConfig.client.getInteger(
				mcframe.clientFSBB.FSBBP0020.FSBBP0020.progDialogDelay_key,
				mcframe.clientFSBB.FSBBP0020.FSBBP0020.progDialogDelay);
	}

	/**
	 * 自動レイアウトで位置調整を行うかどうか。
	 * Sを返す場合はレイアウトの位置調整を行いません。
	 *
	 * @since 7.0.1
	 */
	@Override
	public String getAutoLayoutType() {
		return "S";
	}
}