package mcframe.clientFSBA.FSBAP0230;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.text.*;
import mcframe.clientCore.beans.list.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.param.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.util.MCCollectionUtil;
import mcframe.commonCore.meta.MCMeta;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.beans.popup.MCTextPopupMenuItem;
import mcframe.clientCore.beans.text.MCInputMethodType;

/**
 * 画面"FSBAP0230"パネルクラスです。<p>
 *
 * <br>
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract public class FSBAP0230_FW_A extends mcframe.clientFSUC.FSUCP0000.FSUCP_PanelBase{
	/** 
	 * モジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getModuleID()}を使用してください。
	 */
	public static final String MODULE_ID = "FS";
	/** 
	 * サブモジュールID<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getSubmoduleID()}を使用してください。
	 */
	public static final String SUBMODULE_ID = "FSBA";
	/** 
	 * 画面ID<p>
	 *
	 * 画面はモジュールIDと画面IDで一意に特定できます。<br>
	 * 画面インスタンスから参照する場合には{@link #getScreenID()}を使用してください。
	 */
	public static final String SCREEN_ID = "FSBAP0230";

	/** モジュールIDを取得します。 */
	public String getModuleID(){ return MODULE_ID; }
	/** サブモジュールIDを取得します。 */
	public String getSubmoduleID(){ return SUBMODULE_ID; }
	/** 画面IDを取得します。 */
	public String getScreenID(){ return SCREEN_ID; }
	// [Icon]ブロック関連のField定義
	public MCPanel IconPanel = null;
	// [Icon]ブロックの項目のField定義
	public MCLabel Icon_icon = null;
	// [Info]ブロック関連のField定義
	public MCPanel InfoPanel = null;
	// [Info]ブロックの項目のField定義
	public MCScrollPane Info_messageScrollPane = null;
	/**
	 * メッセージ メッセージ.<p>
	 *
	 */
	public MCTextArea Info_message = null;
	// [Progress]ブロック関連のField定義
	public MCPanel ProgressPanel = null;
	// [Progress]ブロックの項目のField定義
	// [Btn]ブロック関連のField定義
	public MCPanel BtnPanel = null;
	// [Btn]ブロックの項目のField定義
	/**
	 * キャンセル キャンセル.<p>
	 *
	 */
	public MCButton Btn_cancel = null;
	/** [INIT]モードを表す定数 */
	public static final String INIT = "INIT";

	/** 
	 * ステータスの配列<p>
	 *
	 * 画面インスタンスから参照する場合には{@link #getStatusSet()}を使用してください。
	 */
	public static final String[] statusArray = new String[]{INIT};

	/** 
	 * 有効になっているステータス
	 *
	 * @deprecated 参照する場合には{@link #getStatus()}を使用してください。
	 */
	@Deprecated
	protected String status = null;
	
	/** [Info]ブロックのコンテナField定義 */
	private final mcframe.clientFSBA.FSBAP0230.InfoR aInfoR;

	/**
	 * 項目コピーによってaInfoRを設定します。
	 *
	 * aInfoRのインスタンスは変更されません。
	 *
	 * @param row InfoR
	 */
	public void setInfoR(mcframe.clientFSBA.FSBAP0230.InfoR row) {
		if (row != null) {
			MCRow.copyall(getInfoR(), row);
		}
	}

	/**
	 * [Info]ブロックのコンテナaInfoRを返します。
	 *
	 * @return InfoR
	 */
	public mcframe.clientFSBA.FSBAP0230.InfoR getInfoR() {
		return aInfoR;
	}

	/**
	 * aInfoRを作成します。
	 *
	 * @return InfoR
	 */
	public mcframe.clientFSBA.FSBAP0230.InfoR createInfoR() {
		return mcframe.clientFSBA.FSBAP0230.InfoR.create();
	}

	/**
	 * 保持するコンテナのListを返します。
	 *
	 * @return コンテナのList
	 */
	public List<MCContainer> getContainers(){
		List<MCContainer> ret = super.getContainers();
		if(!MCCollectionUtil.contains(ret, getInfoR())) ret.add(getInfoR());
		return ret;
	}

	/**
	 * コンテナに対応したブロックのIDを返します。
	 *
	 * 引数のコンテナに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return ブロックID
	 */
	public String getBlockId(MCContainer aCnt){
		if(aCnt == null) return null;
		if(aCnt == getInfoR()) return "Info";
		return super.getBlockId(aCnt);
	}

	/**
	 * ブロックIDに対応したコンテナを返します。
	 *
	 * 引数のブロックIDに対応するブロックがない場合にはnullを返します。<br>
	 * 引数がnullの場合にはnullを返します。<br>
	 *
	 * @return コンテナ
	 */
	public MCContainer getContainer(String bId){
		if(bId == null) return null;
		if(bId.equals("Info")) return getInfoR();
		return super.getContainer(bId);
	}

	/**
	 * 保持するPanel(枠)のListを返します。
	 *
	 * @return MCPanelのList
	 */
	public List<MCPanel> getMCPanels(){
		List<MCPanel> ret = super.getMCPanels();
		ret.add(IconPanel);
		ret.add(InfoPanel);
		ret.add(ProgressPanel);
		ret.add(BtnPanel);
		return ret;
	}

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0230_FW_A() {
		aInfoR = createInfoR();

	}


	/**
	 * 埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	public void jbCreate(){
		super.jbCreate();
		FSBAP0230_FW.jbCreateIcon((FSBAP0230)this);
		FSBAP0230_FW.jbCreateInfo((FSBAP0230)this);
		FSBAP0230_FW.jbCreateProgress((FSBAP0230)this);
		FSBAP0230_FW.jbCreateBtn((FSBAP0230)this);
	}

	/**
	 * [Icon]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateIcon(FSBAP0230 p) {
	}

	/**
	 * [Info]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateInfo(FSBAP0230 p) {
	}

	/**
	 * [Progress]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateProgress(FSBAP0230 p) {
	}

	/**
	 * [Btn]ブロック関連の埋め込み画面Fieldとエイリアス定義されたGUI部品Fieldの初期化を行います。
	 */
	protected static void jbCreateBtn(FSBAP0230 p) {
	}

	/**
	 * この画面のステータスのSet集合を返します。
	 * 
	 * @return ステータスのSet
	 */
	@Override
	public Set<String> getStatusSet(){
		Set<String> sSet = super.getStatusSet();
		for(String aStr : statusArray) sSet.add(aStr);
		return sSet;
	}


	/**
	 * この画面を埋め込み画面として作成します。
	 */
	public static FSBAP0230 create(){
		FSBAP0230 p = new FSBAP0230();
		p.jbCreate();
		setParts(p);
		p.appInit();
		return p;
	}


	/**
	 * 画面部品初期設定
	 */
	protected void jbInit() {
		super.jbInit();
		FSBAP0230_FW.jbfInitIcon((FSBAP0230)this);
		FSBAP0230_FW.jbfInitInfo((FSBAP0230)this);
		FSBAP0230_FW.jbfInitProgress((FSBAP0230)this);
		FSBAP0230_FW.jbfInitBtn((FSBAP0230)this);
		FSBAP0230_FW.jbInitIcon((FSBAP0230)this);
		FSBAP0230_FW.jbInitInfo((FSBAP0230)this);
		FSBAP0230_FW.jbInitProgress((FSBAP0230)this);
		FSBAP0230_FW.jbInitBtn((FSBAP0230)this);
	}

	/**
	 * [Icon]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitIcon(FSBAP0230 p) {
		// ブロック関連の初期化
		p.IconPanel = p.beansFactory.createPanel("Icon");
		// ブロックの項目の初期化
		p.Icon_icon = p.beansFactory.createLabel("Icon.icon");
	}

	/**
	 * [Info]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitInfo(FSBAP0230 p) {
		// ブロック関連の初期化
		p.InfoPanel = p.beansFactory.createPanel("Info");
		// ブロックの項目の初期化
		p.Info_messageScrollPane = p.beansFactory.createScrollPane("Info.messagescroll");
		p.Info_message = p.beansFactory.createTextArea("Info.message");
	}

	/**
	 * [Progress]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitProgress(FSBAP0230 p) {
		// ブロック関連の初期化
		p.ProgressPanel = p.beansFactory.createPanel("Progress");
		// ブロックの項目の初期化
	}

	/**
	 * [Btn]ブロック関連の画面部品初期設定１
	 */
	protected static void jbfInitBtn(FSBAP0230 p) {
		// ブロック関連の初期化
		p.BtnPanel = p.beansFactory.createPanel("Btn");
		// ブロックの項目の初期化
		p.Btn_cancel = p.beansFactory.createButton("Btn.cancel");
	}

	/**
	 * [Icon]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitIcon(FSBAP0230 p) {
		// ブロック関連の初期化
		p.add(p.IconPanel);
		p.setLastBeans(p.IconPanel);
		p.IconPanel.setNextBeans(p.InfoPanel);
		p.IconPanel.setValueCheck(false);
		p.IconPanel.setLayoutPosition("CW");
		// ブロックの項目の初期化
		p.IconPanel.add(p.Icon_icon);
	}

	/**
	 * [Info]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitInfo(FSBAP0230 p) {
		// ブロック関連の初期化
		p.add(p.InfoPanel);
		p.InfoPanel.setNextBeans(p.ProgressPanel);
		p.InfoPanel.setValueCheck(false);
		p.InfoPanel.setLayoutPosition("CC");
		// ブロックの項目の初期化
		p.Info_messageScrollPane.getViewport().add(p.Info_message);
		p.InfoPanel.add(p.Info_messageScrollPane);
		p.InfoPanel.setLastBeans(p.Info_message);
		p.Info_message.setRow(p.getInfoR(), mcframe.clientFSBA.FSBAP0230.InfoR.message_META);
	}

	/**
	 * [Progress]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitProgress(FSBAP0230 p) {
		// ブロック関連の初期化
		p.add(p.ProgressPanel);
		p.ProgressPanel.setNextBeans(p.BtnPanel);
		p.ProgressPanel.setValueCheck(false);
		p.ProgressPanel.setLayoutPosition("S");
		// ブロックの項目の初期化
	}

	/**
	 * [Btn]ブロック関連の画面部品初期設定２
	 */
	protected static void jbInitBtn(FSBAP0230 p) {
		// ブロック関連の初期化
		p.add(p.BtnPanel);
		p.BtnPanel.setValueCheck(false);
		p.BtnPanel.setLayoutPosition("S");
		// ブロックの項目の初期化
		p.BtnPanel.add(p.Btn_cancel);
		p.BtnPanel.setLastBeans(p.Btn_cancel);
	}

	/**
	 * MCLayouterの指定文字列を返します。
	 */
	public String getLayoutKey() {
		return "S";
	}

	/**
	 * 画面部品初期設定（MCFrame仕様）
	 */
	protected void mcInit() {
		super.mcInit();
		FSBAP0230_FW.mcInitIcon((FSBAP0230)this);
		FSBAP0230_FW.mcInitInfo((FSBAP0230)this);
		FSBAP0230_FW.mcInitProgress((FSBAP0230)this);
		FSBAP0230_FW.mcInitBtn((FSBAP0230)this);

		// [INIT]ステータスのモードの設定
		FSBAP0230_FW.statusInitINIT_Icon((FSBAP0230)this);
		FSBAP0230_FW.statusInitINIT_Info((FSBAP0230)this);
		FSBAP0230_FW.statusInitINIT_Progress((FSBAP0230)this);
		FSBAP0230_FW.statusInitINIT_Btn((FSBAP0230)this);

	}

	/**
	 *  [Icon]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitIcon(FSBAP0230 p) {
	}

	/**
	 *  [Info]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitInfo(FSBAP0230 p) {
		p.Info_message.addAllListener(p);
	}

	/**
	 *  [Progress]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitProgress(FSBAP0230 p) {
	}

	/**
	 *  [Btn]ブロックの画面部品初期設定（MCFrame仕様）
	 */
	protected static void mcInitBtn(FSBAP0230 p) {
		p.Btn_cancel.addAllListener(p);
		p.Btn_cancel.setAPMethodName("doBtn_cancel");
	}

	/**
	 * [INIT]ステータスの[Icon]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Icon(FSBAP0230 p){
		p.Icon_icon.putMode(p, INIT, MCMode.ENABLE);

	}

	/**
	 * [INIT]ステータスの[Info]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Info(FSBAP0230 p){
		p.Info_message.putMode(p, INIT, MCMode.READ_ONLY);

	}

	/**
	 * [INIT]ステータスの[Progress]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Progress(FSBAP0230 p){

	}

	/**
	 * [INIT]ステータスの[Btn]ブロックのモードの設定
	 */
	protected static void statusInitINIT_Btn(FSBAP0230 p){
		p.Btn_cancel.putMode(p, INIT, MCMode.READ_ONLY);

	}

	/**
	 * 初期ステータスの文字列を返します。
	 */
	public String getInitStatus() {
		return INIT;
	}

	/**
	 * Table/Treeの設定
	 */
	protected void setTableConfig() {
		super.setTableConfig();
	}

	/**
	 * コンボボックスの初期設定
	 */
	protected void listInit() {
		super.listInit();
	}

	/**
	 * この画面を[INIT]ステータスに設定します。
	 */
	@SuppressWarnings("deprecation")
	public void setINITStatus() {
		status = INIT;
		setAllStatus(status);
	}


	/**
	 * この画面のステータスを設定します。
	 *
	 * @param status ステータス
	 */
	public void setStatus(String status) {
		super.setStatus(status);
		if (INIT.equals(status)) {
			setINITStatus();
		}
	}

	/**
	 * この画面のステータスを返します。
	 *
	 * @return ステータス
	 */
	public String getStatus() {
		return status;
	}


	/**
	 * リストを保持する画面部品のリストを返します。
	 */
	public MCList getList(MCEventBeans combo, MCRow row, MCEventInfo info) {
		MCList list = super.getList(combo, row, info);
		if(list != null) return list;
		return null;
	}

	/**
	 * ActionPerformedイベントが実行されたときに呼び出されます。
	 *
	 * @param ap ActionPerformedイベントが実行されたGUI部品
	 */
	public void doAPEvent(MCAPBeans ap, MCEventInfo info) {
		super.doAPEvent(ap, info);
		if (ap == Btn_cancel) doBtn_cancel(info);
	}

	/**
	 * [Btn]パネルの[cancel]ボタンが押下されたときに呼び出されます。
	 */
	abstract public void doBtn_cancel(MCEventInfo info);

	/**
	 * ValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param vc イベント対象のGUI部品
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doVCEvent(MCVCBeans vc, MCEventInfo info) {
		if (!super.doVCEvent(vc, info)) {
			return false;
		}
		if (vc == Info_message) return doInfo_message_VC(info);
		return true;
	}

	/**
	 * [Info]パネルの[message]のValidationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 * @return ValidationChangeイベントの結果
	 */
	public boolean doInfo_message_VC(MCEventInfo info){
		return true;
	}

	/**
	 * NotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param nc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNCEvent(MCNCBeans nc, MCEventInfo info) {
		super.doNCEvent(nc, info);
		if (nc == Info_message) doInfo_message_NC(info);
	}

	/**
	 * [Info]パネルの[message]のNotificationChangeイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_message_NC(MCEventInfo info){
	}

	/**
	 * NotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param ne イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNEEvent(MCNEBeans ne, MCEventInfo info) {
		super.doNEEvent(ne, info);
		if (ne == Info_message) doInfo_message_NE(info);
	}

	/**
	 * [Info]パネルの[message]のNotificationEntryイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_message_NE(MCEventInfo info){
	}

	/**
	 * NotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param nx イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doNXEvent(MCNXBeans nx, MCEventInfo info) {
		super.doNXEvent(nx, info);
		if (nx == Info_message) doInfo_message_NX(info);
	}

	/**
	 * [Info]パネルの[message]のNotificationExitイベントが実行されたときに呼び出されます。
	 *
	 * @param info イベント情報
	 */
	public void doInfo_message_NX(MCEventInfo info){
	}

	/**
	 * ListChangedイベントが実行されたときに呼び出されます。
	 *
	 * @param lc イベント対象のGUI部品
	 * @param info イベント情報
	 */
	public void doLCEvent(MCLCBeans lc, MCEventInfo info) {
		super.doLCEvent(lc, info);
	}

	@Override
	public MCCallerPanelBridge createBridge(String id) {
		return super.createBridge(id);
	}
}