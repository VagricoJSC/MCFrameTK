package mcframe.clientFSBA.FSBAP0230;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Info"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class InfoR_FW_A extends MCConstRow {

	/**
	 * メッセージ メッセージ.<p>
	 *
	 */
	public static final String $message = "message";


	public static final MCMeta message_META = createStringMeta($message);

	protected static final ConstMetaList<InfoR> constMetas = new ConstMetaList<InfoR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			message_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected InfoR_FW_A(ConstMetaList<? extends InfoR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public InfoR clone() {
		return (InfoR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public InfoR createInstance() {
		return (InfoR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public InfoR getValues(String... names) {
		return (InfoR) super.getValues(names);
	}



	/**
	 * メッセージ メッセージ.<p>
	 *
	 */
	public String message() {
		return getConstString(offset + 0, $message);
	}

	/**
	 * メッセージ メッセージ.<p>
	 *
	 */
	public void message(String value) {
		setConstString(offset + 0, $message, value);
	}


	public String getString(String name) {
		if ($message.equalsIgnoreCase(name)) {
			return message();
		}
		return super.getString(name);
	}

	public String getStringNE(String name) {
		if ($message.equalsIgnoreCase(name)) {
			return message();
		}
		return super.getStringNE(name);
	}

	public void setString(String name, String value) {
		if ($message.equalsIgnoreCase(name)) {
			message(value);
			return;
		}
		super.setString(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($message.equalsIgnoreCase(name)) {
			message(value);
			return;
		}
		super.setStringNE(name, value);
	}



}

