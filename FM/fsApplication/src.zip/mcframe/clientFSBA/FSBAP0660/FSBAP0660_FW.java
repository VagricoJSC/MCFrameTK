package mcframe.clientFSBA.FSBAP0660;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;


import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START
import mcframe.commonFX.constant.FXC_RESOURCE_SETTING_UNIT;
import mcframe.clientCore.beans.resource.MCColumnWidthData;
import mcframe.clientFSBA.FSBAP0030.ListDtlR;
import mcframe.clientFSBA.FSBAP0670.FSBAP0670_FW;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP0660"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP0660_FW extends FSBAP0660_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	protected String targetSettingsNM = null;

	// FSBAP0670画面のテーブルの書き戻す行index
	protected int targetInfoDtlIndex = 0;

	protected boolean isSaveMode = false;
	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP0660_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP0660_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	public void setTargetSettingsNM(String targetSettingsNM) {
		this.targetSettingsNM = targetSettingsNM;
	}

	public void setTargetInfoDtlIndex(int targetInfoDtlIndex) {
		this.targetInfoDtlIndex = targetInfoDtlIndex;
	}

	@Override
	public void setStatus(String status) {
		super.setStatus(status);
		// infoのtypeが違うDISABLEになるため戻す。
		if (EDIT.equals(status)) {
			setEDITStatus();
		}
	}

	// 初期行選択
	@Override
	protected void setInitInfoData(ListDtlR data) {
		super.setInitInfoData(data);
		if (isSaveMode == true) {
			doUpdAction();
		}
	}

	/**
	 * カラム情報設定対象のテーブルを設定します。
	 *
	 * @param table カラム情報設定対象のテーブル
	 */
	public void setTargetTable(MCTable<?> table) {
		_target_table = table;
	}

	@Override
	protected InfoDtlR getColumnData(MCColumnConfig column) {
		InfoDtlR o = (InfoDtlR) super.getColumnData(column);

		o.focus_flg(getTargetTable().isFocusColumn(column));
		o.column_size(getTargetTable().getColumnSize(column));
		return o;
	}

	@Override
	protected InfoDtlR getInitRowData(MCColumnConfig column, MCColumnWidthData data) {
		InfoDtlR o = (InfoDtlR) super.getInitRowData(column, data);

		Boolean r = data.getFocusColumn();
		if (r == null) {
			r = getTargetTable().isFocusColumn(column);
		}
		o.focus_flg(r);

		int s = data.getColumnSize();
		if (s < 0) {
			s = getTargetTable().getColumnSize(column);
		}
		o.column_size(s);

		return o;
	}

	@Override
	protected void setWriteResourceInfo(MCColumnWidthData data, MCColumnConfig column,
			MCList<?> list, int index) {

		super.setWriteResourceInfo(data, column, list, index);

		data.setFocusColumn(((InfoDtlR) list.get(index)).focus_flg());
		MCNumber n = ((InfoDtlR) list.get(index)).column_size();
		if (n != null) {
			data.setColumnSize(n.intValue());
		}
		else {
			data.setColumnSize(0);
		}
	}

	@Override
	protected void execUpdateTable(MCList<?> list) {
		// フォーカス情報の更新
		MCTable2<?> t = (MCTable2<?>)getTargetTable();
		t.removeAllReturnColumns();

		super.execUpdateTable(list);
	}

	/**
	 * 登録ボタンの処理を実行します。
	 */
	@Override
	protected void doUpdAction() {
		if (isSaveMode == false) {
			if (!execUpdComfirm() || !checkForUpd()) {
				return;
			}
		}

		beforeUpd();
		doUpd();

		// 親画面を書き換え
		if (mainPanelForBarcode != null) {
			String n = getListHdrR().setting_info_nm();
			if (n == null) {
				n = "";
			}
			mainPanelForBarcode.setListSettingsID(this, _target_table, n, targetInfoDtlIndex);
		}

		afterUpd();

		// 閉じるときの変更の警告を出さないようにする。
		getInfoDtlL().clear();
		getListDtlL().clear();

		// バーコード画面対応
		if (mainPanelForBarcode == null) {
			showUpdEndMsg();
		}

		// 登録後に閉じる。
		requestCloseWindow();
	}

	protected void mcInit() {
		super.mcInit();
		// 全invisibleで画面上から消す。
		// 自動レイアウト機能で表示されない。

		String[] modeList = { INIT, EDIT, DISABLE };
		for (String m : modeList) {
			Setting_setting_PPanel.Setting_setting_unit_USER.putMode(this, m, MCMode.INVISIBLE);
			Setting_setting_PPanel.Setting_setting_unit_EXT.putMode(this, m, MCMode.INVISIBLE);
			Setting_setting_PPanel.Setting_setting_unit_SYS.putMode(this, m, MCMode.INVISIBLE);

			ListDtlBtn_apply.putMode(this, m, MCMode.INVISIBLE);
			ListDtlBtn_apply_close.putMode(this, m, MCMode.INVISIBLE);
			ListHdr_init_flg.putMode(this, m, MCMode.INVISIBLE);

			ListBtn_upd_apply.putMode(this, m, MCMode.INVISIBLE);
		}

		Setting_setting_PPanel.Setting_setting_unit_Group.setValue("SYS");
	}

	protected String setting_unit() {
		return "BARCODE";
	}

	@Override
	public void doListHdr_setting_info_nm_LC(MCEventInfo info) {
		ListDtlR s = ListDtlTable.getSelectedMCRow();
		if (s != null) {
			setValueEx(columnListDtl_setting_info_nm, s.getGUIIndex(), getListHdrR().setting_info_nm());

			if (isNull(s.setting_unit_type())) {
				// BARCODE以外不可
				s.setting_unit_type(setting_unit());
				FXC_RESOURCE_SETTING_UNIT.putNameNE(s, ListDtlR.$setting_unit_type, ListDtlR.$setting_unit_type_nm);
			}
		}

	}

	/**
	 * 登録処理の実行確認メッセージを表示します。<p>
	 * 登録処理を続行する場合は true を返します。
	 *
	 * @return 登録処理を中断する場合は false
	 */
	@Override
	protected boolean execUpdComfirm() {
		// BARCODE以外不可
		return confirm(FSBAC0063, FXC_RESOURCE_SETTING_UNIT.get(setting_unit()).name(),
				getListHdrR().setting_info_nm()) == MCMessageBox.YES_OPTION;
	}

	/**
	 * 登録処理の実行可否を判断します。<p>
	 * 登録処理を続行する場合は true を返します。
	 *
	 * @return 登録処理を中断する場合は false
	 */
	protected boolean checkForUpd() {
		// 空行のステータスをクリアする
		clearEmptyRowStatus(getListDtlL());

		// 設定情報の必須項目をチェックする
		MCMessageList l = checkReq(getListHdrR());

		// 設定情報の必須項目が入力されていない場合
		if (l.size() > 0) {
			message(l);
			return false;
		}

		// 有効な設定情報
		MCList<ListDtlR> el = exceptEmpty(getListDtlL());

		// 初期ＦＬＧが複数行に設定されている場合
		if (el.subList(ListDtlR.$init_flg, true).size() > 1) {
			dialog(FSBAC0060);
			return false;
		}

		// 設定情報名をチェックする
		MCList<ListDtlR> sl = el.subList(ListDtlR.$setting_info_nm, getListHdrR().setting_info_nm());
		sl.remove(ListDtlTable.getSelectedMCRow());

		// 設定情報名が重複している場合
		if (sl.size() > 0) {
			MCMessage m = new MCMessage(FSBAC0062, FXC_RESOURCE_SETTING_UNIT.get(getSettingR().setting_unit()).name(),
					getListHdrR().setting_info_nm());
			m.setCauseRow(getListHdrR(), ListDtlR.$setting_info_nm);
			dialog(m);
			return false;
		}

		return true;
	}

}