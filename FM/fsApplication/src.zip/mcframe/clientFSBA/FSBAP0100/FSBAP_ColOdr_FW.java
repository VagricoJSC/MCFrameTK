package mcframe.clientFSBA.FSBAP0100;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import mcframe.clientCore.beans.action.*;
import mcframe.clientCore.beans.combobox.*;
import mcframe.clientCore.beans.*;
import mcframe.clientCore.event.*;
import mcframe.commonCore.lang.*;
import mcframe.commonCore.notice.*;
import mcframe.commonCore.container.*;
import mcframe.commonCore.container.MCRow.Status;
import mcframe.commonCore.container.MCList.SortType;
import mcframe.clientCore.beans.table.*;
import mcframe.clientCore.beans.tree.*;
import mcframe.clientCore.container.MCConstRow;


import mcframe.commonFXUC.FXUCC0090.FXUCC_RowMapperWith;
import static mcframe.commonCore.notice.Core_Msg.*;
import static mcframe.commonFX.notice.FX_Msg.*;
import static mcframe.commonFS.notice.FS_Msg.*;
import static mcframe.clientFXUC.FXUCP0010.FXUCP_DataUtil.*;

//カスタマイズのimportはこの間に記述してください。
//FMCB CUSTOM_IMPORT START

import mcframe.clientCore.beans.resource.MCColumnWidthData;
//FMCB CUSTOM_IMPORT END

/**
 * 画面"FSBAP_ColOdr"パネルクラスです。<p>
 *
 * 実装仕様書から自動生成されるクラスです。このクラスにカスタマイズを行ってください。
 */
@SuppressWarnings("serial")
abstract public class FSBAP_ColOdr_FW extends FSBAP_ColOdr_FW_A {

	//カスタマイズのfieldはこの間に記述してください。
	//FMCB CUSTOM_FIELD START

	//FMCB CUSTOM_FIELD END

	/**
	 * コンストラクタです。通常の画面として作成するときに使用します。
	 */
	public FSBAP_ColOdr_FW() {
		super();
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR START

		//FMCB CUSTOM_CONSTRUCTOR END
	}

	/**
	 * コンストラクタです。埋込カラムとして作成するときに使用します。
	 *
	 * @param name 対応するInnerRow項目名
	 */
	public FSBAP_ColOdr_FW(String name) {
		super(name);
		//コンストラクタのカスタマイズ処理はこの間に記述してください。
		//FMCB CUSTOM_CONSTRUCTOR_LIST START

		//FMCB CUSTOM_CONSTRUCTOR_LIST END
	}

	//画面処理メソッドはこれより下に定義してください。
	//FMCB CUSTOM_METHOD START

	@Override
	protected MCTable2<?> getTargetTable() {
		return (MCTable2<?>)super.getTargetTable();
	}
	
	@Override
	protected InfoDtlR getColumnData(MCColumnConfig column) {
		InfoDtlR o = (InfoDtlR) super.getColumnData(column);
		// 改行の設定
		o.return_flg(getTargetTable().isReturnColumn(column));
		return o;
	}

	@Override
	protected InfoDtlR getInitRowData(
			MCColumnConfig column, MCColumnWidthData data) {
		InfoDtlR o = (InfoDtlR) super.getInitRowData(column, data);
		// 改行の設定
		
		Boolean r = data.getReturnColumn();
		if (r == null) {
			r = getTargetTable().isReturnColumn(column);
		}
		o.return_flg(r);
		return o;
	}

	@Override
	protected void setWriteResourceInfo(
			MCColumnWidthData data, MCColumnConfig column, 
			MCList<?> list, int index) {
		
		super.setWriteResourceInfo(data, column, list, index);

		data.setReturnColumn(((InfoDtlR)list.get(index)).return_flg());
	}
	
	@Override
	protected void execUpdateTable(MCList<?> list) {
		
		// 改行位置の更新
		MCTable2<?> t = getTargetTable();
		t.removeAllReturnColumns();
		
		MCList<InfoDtlR> rl = (MCList<InfoDtlR>)list.subList(
				InfoDtlR.$return_flg, true);
		
		for (InfoDtlR o : rl) {
			MCColumnConfig c = getTargetColumnConfig(o.column_key());
			t.addReturnColumn(c);
		}

		super.execUpdateTable(list);
	}

	@Override
	protected void setTargetPanelDefault() {
		// 改行のデフォルト設定
		MCTable2<?> t = getTargetTable();
		t.removeAllReturnColumns();

		// 更新後処理を実行するため、superクラスの実装は後に呼ぶ
		super.setTargetPanelDefault();
	}

}