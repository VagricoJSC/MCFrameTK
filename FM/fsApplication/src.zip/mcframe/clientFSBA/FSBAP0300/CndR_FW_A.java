package mcframe.clientFSBA.FSBAP0300;

import java.util.List;
import java.util.Map;
import java.util.Set;
import mcframe.commonCore.container.MCExtMap;
import mcframe.commonCore.container.MCExtList;
import mcframe.clientCore.container.MCKeyList;
import mcframe.clientCore.container.MCConstRow;
import mcframe.commonCore.container.MCRow;
import mcframe.commonCore.container.MCContainerMeta;
import mcframe.commonCore.meta.MCMeta;
import mcframe.commonCore.lang.MCNumber;
import mcframe.commonCore.lang.MCDate;
import mcframe.commonCore.lang.MCTimestamp;
import mcframe.commonCore.lang.MCDataType;
import mcframe.commonCore.lang.MCBinary;

/**
 * ブロック"Cnd"コンテナRowクラスです。<p>
 *
 * <br>
 *
 * 実装仕様書から自動生成されるクラスです。カスタマイズできません。
 */
@SuppressWarnings({"all"})
abstract class CndR_FW_A extends MCConstRow {

	/**
	 *  モジュールＩＤ.<p>
	 *
	 */
	public static final String $to_module_id = "to_module_id";
	/**
	 *  連携先画面ＩＤ.<p>
	 *
	 */
	public static final String $to_screen_id = "to_screen_id";
	/**
	 *  連携先画面名.<p>
	 *
	 */
	public static final String $to_screen_nm = "to_screen_nm";
	/**
	 *  モジュールＩＤ.<p>
	 *
	 */
	public static final String $from_module_id = "from_module_id";
	/**
	 *  連携元画面ＩＤ.<p>
	 *
	 */
	public static final String $from_screen_id = "from_screen_id";
	/**
	 *  連携元画面名.<p>
	 *
	 */
	public static final String $from_screen_nm = "from_screen_nm";
	/**
	 *  識別キーを表示する.<p>
	 *
	 */
	public static final String $key_view = "key_view";
	/**
	 *  設定単位ＣＤ.<p>
	 *
	 */
	public static final String $setting_unit_type = "setting_unit_type";


	public static final MCMeta to_module_id_META = createCommonMeta($to_module_id, mcframe.commonCore.meta.M_META.MODULE_ID);
	public static final MCMeta to_screen_id_META = createCommonMeta($to_screen_id, mcframe.commonCore.meta.M_META.SCREEN_ID);
	public static final MCMeta to_screen_nm_META = createCommonMeta($to_screen_nm, mcframe.commonCore.meta.M_META.SCREEN_NAME);
	public static final MCMeta from_module_id_META = createCommonMeta($from_module_id, mcframe.commonCore.meta.M_META.MODULE_ID);
	public static final MCMeta from_screen_id_META = createCommonMeta($from_screen_id, mcframe.commonCore.meta.M_META.SCREEN_ID);
	public static final MCMeta from_screen_nm_META = createCommonMeta($from_screen_nm, mcframe.commonCore.meta.M_META.SCREEN_NAME);
	public static final MCMeta key_view_META = createBooleanMeta($key_view);
	public static final MCMeta setting_unit_type_META = createStringMeta($setting_unit_type);

	protected static final ConstMetaList<CndR> constMetas = new ConstMetaList<CndR>(
		MCConstRow.constMetas,
		new MCMeta[]{
			to_module_id_META,
			to_screen_id_META,
			to_screen_nm_META,
			from_module_id_META,
			from_screen_id_META,
			from_screen_nm_META,
			key_view_META,
			setting_unit_type_META
		},
		new String[][]{
			{
			},
			{
			}
		}
	);

	/**
	 * "KEYS"グループのキー項目情報です。
	 */
	protected static final MCKeyList KEYS = new MCKeyList(
		null,
		new String[]{
		}
	);


	/**
	 * グループ毎に定義される項目属性情報です。
	 */
	protected static final MCExtMap EXTMAP = new MCExtMap(
		null
	);

	/**
	 * クラスに定義されている固定カラム名を配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラム名の配列
	 */
	public static String[] colnames() {
		return constMetas.toNameArray();
	}

	/**
	 * クラスに定義されている固定カラムメタを配列で返します。
	 *
	 * 並び順は定義順と同じです。
	 * 固定カラムがない場合は要素0の配列が返ります。
	 * 
	 * @return 固定カラムメタの配列
	 */
	public static MCMeta[] colmetas() {
		return constMetas.toMetaArray();
	}

	/**
	 * 実際のカラム位置を知るためオフセットです。
	 */
	private static final int offset = constMetas.offset();

	/**
	 * "KEYS"グループのキー項目情報を返します。
	 */
	public MCKeyList getKeys(){
		return KEYS;
	}

	/**
	 * 指定グループの項目属性情報を返します。
	 */
	public Map<String, String> getExtMap(String aGroup){
		if(aGroup == null) return null;
		return EXTMAP.get(aGroup);
	}

	/**
	 * 指定グループの項目属性が登録された項目リストを返します。
	 */
	public MCKeyList getKeys(String aGroup){
		if(aGroup == null) return null;
		return new MCKeyList(EXTMAP.getKeyList(aGroup));
	}

	/**
	 * 項目属性のグループのSet情報を返します。
	 */
	public Set<String> getExtGroups(){
		Set<String> ret = EXTMAP.keySet();
		return ret;
	}

	/**
	 * コンストラクタです。
	 */
	protected CndR_FW_A(ConstMetaList<? extends CndR> metas) {
		super(metas);
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public CndR clone() {
		return (CndR) super.clone();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public CndR createInstance() {
		return (CndR) super.createInstance();
	}

	/*
	 * MCRowのオーバーライドメソッドです。
	 */
	public CndR getValues(String... names) {
		return (CndR) super.getValues(names);
	}



	/**
	 *  モジュールＩＤ.<p>
	 *
	 */
	public String to_module_id() {
		return getConstString(offset + 0, $to_module_id);
	}

	/**
	 *  モジュールＩＤ.<p>
	 *
	 */
	public void to_module_id(String value) {
		setConstString(offset + 0, $to_module_id, value);
	}


	/**
	 *  連携先画面ＩＤ.<p>
	 *
	 */
	public String to_screen_id() {
		return getConstString(offset + 1, $to_screen_id);
	}

	/**
	 *  連携先画面ＩＤ.<p>
	 *
	 */
	public void to_screen_id(String value) {
		setConstString(offset + 1, $to_screen_id, value);
	}


	/**
	 *  連携先画面名.<p>
	 *
	 */
	public String to_screen_nm() {
		return getConstString(offset + 2, $to_screen_nm);
	}

	/**
	 *  連携先画面名.<p>
	 *
	 */
	public void to_screen_nm(String value) {
		setConstString(offset + 2, $to_screen_nm, value);
	}


	/**
	 *  モジュールＩＤ.<p>
	 *
	 */
	public String from_module_id() {
		return getConstString(offset + 3, $from_module_id);
	}

	/**
	 *  モジュールＩＤ.<p>
	 *
	 */
	public void from_module_id(String value) {
		setConstString(offset + 3, $from_module_id, value);
	}


	/**
	 *  連携元画面ＩＤ.<p>
	 *
	 */
	public String from_screen_id() {
		return getConstString(offset + 4, $from_screen_id);
	}

	/**
	 *  連携元画面ＩＤ.<p>
	 *
	 */
	public void from_screen_id(String value) {
		setConstString(offset + 4, $from_screen_id, value);
	}


	/**
	 *  連携元画面名.<p>
	 *
	 */
	public String from_screen_nm() {
		return getConstString(offset + 5, $from_screen_nm);
	}

	/**
	 *  連携元画面名.<p>
	 *
	 */
	public void from_screen_nm(String value) {
		setConstString(offset + 5, $from_screen_nm, value);
	}


	/**
	 *  識別キーを表示する.<p>
	 *
	 */
	public boolean key_view() {
		return getConstBoolean(offset + 6, $key_view);
	}

	/**
	 *  識別キーを表示する.<p>
	 *
	 */
	public void key_view(boolean value) {
		setConstBoolean(offset + 6, $key_view, value);
	}


	/**
	 *  設定単位ＣＤ.<p>
	 *
	 */
	public String setting_unit_type() {
		return getConstString(offset + 7, $setting_unit_type);
	}

	/**
	 *  設定単位ＣＤ.<p>
	 *
	 */
	public void setting_unit_type(String value) {
		setConstString(offset + 7, $setting_unit_type, value);
	}


	public String getString(String name) {
		if ($to_module_id.equalsIgnoreCase(name)) {
			return to_module_id();
		}
		if ($to_screen_id.equalsIgnoreCase(name)) {
			return to_screen_id();
		}
		if ($to_screen_nm.equalsIgnoreCase(name)) {
			return to_screen_nm();
		}
		if ($from_module_id.equalsIgnoreCase(name)) {
			return from_module_id();
		}
		if ($from_screen_id.equalsIgnoreCase(name)) {
			return from_screen_id();
		}
		if ($from_screen_nm.equalsIgnoreCase(name)) {
			return from_screen_nm();
		}
		if ($setting_unit_type.equalsIgnoreCase(name)) {
			return setting_unit_type();
		}
		return super.getString(name);
	}
	public boolean getBoolean(String name) {
		if ($key_view.equalsIgnoreCase(name)) {
			return key_view();
		}
		return super.getBoolean(name);
	}

	public String getStringNE(String name) {
		if ($to_module_id.equalsIgnoreCase(name)) {
			return to_module_id();
		}
		if ($to_screen_id.equalsIgnoreCase(name)) {
			return to_screen_id();
		}
		if ($to_screen_nm.equalsIgnoreCase(name)) {
			return to_screen_nm();
		}
		if ($from_module_id.equalsIgnoreCase(name)) {
			return from_module_id();
		}
		if ($from_screen_id.equalsIgnoreCase(name)) {
			return from_screen_id();
		}
		if ($from_screen_nm.equalsIgnoreCase(name)) {
			return from_screen_nm();
		}
		if ($setting_unit_type.equalsIgnoreCase(name)) {
			return setting_unit_type();
		}
		return super.getStringNE(name);
	}
	public boolean getBooleanNE(String name) {
		if ($key_view.equalsIgnoreCase(name)) {
			return key_view();
		}
		return super.getBooleanNE(name);
	}

	public void setString(String name, String value) {
		if ($to_module_id.equalsIgnoreCase(name)) {
			to_module_id(value);
			return;
		}
		if ($to_screen_id.equalsIgnoreCase(name)) {
			to_screen_id(value);
			return;
		}
		if ($to_screen_nm.equalsIgnoreCase(name)) {
			to_screen_nm(value);
			return;
		}
		if ($from_module_id.equalsIgnoreCase(name)) {
			from_module_id(value);
			return;
		}
		if ($from_screen_id.equalsIgnoreCase(name)) {
			from_screen_id(value);
			return;
		}
		if ($from_screen_nm.equalsIgnoreCase(name)) {
			from_screen_nm(value);
			return;
		}
		if ($setting_unit_type.equalsIgnoreCase(name)) {
			setting_unit_type(value);
			return;
		}
		super.setString(name, value);
	}
	public void setBoolean(String name, boolean value) {
		if ($key_view.equalsIgnoreCase(name)) {
			key_view(value);
			return;
		}
		super.setBoolean(name, value);
	}

	public void setStringNE(String name, String value) {
		if ($to_module_id.equalsIgnoreCase(name)) {
			to_module_id(value);
			return;
		}
		if ($to_screen_id.equalsIgnoreCase(name)) {
			to_screen_id(value);
			return;
		}
		if ($to_screen_nm.equalsIgnoreCase(name)) {
			to_screen_nm(value);
			return;
		}
		if ($from_module_id.equalsIgnoreCase(name)) {
			from_module_id(value);
			return;
		}
		if ($from_screen_id.equalsIgnoreCase(name)) {
			from_screen_id(value);
			return;
		}
		if ($from_screen_nm.equalsIgnoreCase(name)) {
			from_screen_nm(value);
			return;
		}
		if ($setting_unit_type.equalsIgnoreCase(name)) {
			setting_unit_type(value);
			return;
		}
		super.setStringNE(name, value);
	}
	public void setBooleanNE(String name, boolean value) {
		if ($key_view.equalsIgnoreCase(name)) {
			key_view(value);
			return;
		}
		super.setBooleanNE(name, value);
	}



}

